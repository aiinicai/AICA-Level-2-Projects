import React, { useState, useMemo } from 'react';
import * as d3 from 'd3';
import { PieChart as PieIcon, Calendar, ArrowRight, Layers, Sparkles, Filter, ChevronLeft, ChevronRight, AlertOctagon } from 'lucide-react';
import { Receipt, Category } from '../types';

interface CategoryPieChartProps {
  receipts: Receipt[];
  categories: Category[];
  selectedCategoryId?: string | null;
  onSelectCategory?: (categoryId: string | null) => void;
  onNavigateToCapture?: () => void;
}

interface SliceData {
  categoryId: string;
  categoryName: string;
  glCode: string;
  totalMinor: number;
  count: number;
  percentage: number;
  spendLimitMinor?: number;
  isBreached: boolean;
  color: string;
}

// Sophisticated, vibrant and accessible color palette for category slices
const PALETTE = [
  '#4f46e5', // vibrant indigo
  '#10b981', // emerald-500
  '#8b5cf6', // violet-500
  '#06b6d4', // cyan-500
  '#f59e0b', // amber-500
  '#ec4899', // pink-500
  '#f97316', // orange-500
  '#6366f1', // electric indigo
  '#14b8a6', // teal-500
  '#a855f7', // purple-500
  '#84cc16', // lime-500
  '#e11d48', // rose-600
  '#0284c7', // sky-600
  '#d97706', // amber-600
  '#059669', // emerald-600
];

export const CategoryPieChart: React.FC<CategoryPieChartProps> = ({
  receipts,
  categories,
  selectedCategoryId,
  onSelectCategory,
  onNavigateToCapture,
}) => {
  // Mode: strictly 'current_month' by default (as required), with ability to see 'all' or navigate months
  const [viewScope, setViewScope] = useState<'current_month' | 'all'>('current_month');
  
  // Current active date reference
  const now = new Date();
  const [activeYear, setActiveYear] = useState<number>(now.getFullYear());
  const [activeMonth, setActiveMonth] = useState<number>(now.getMonth()); // 0-indexed

  // Active hover slice for interactive donut center & tooltip
  const [hoveredSlice, setHoveredSlice] = useState<SliceData | null>(null);

  // Month string prefix YYYY-MM
  const monthPrefix = `${activeYear}-${String(activeMonth + 1).padStart(2, '0')}`;
  
  const monthName = new Intl.DateTimeFormat('en-US', {
    month: 'long',
    year: 'numeric',
  }).format(new Date(activeYear, activeMonth, 1));

  const isCurrentCalendarMonth =
    activeYear === now.getFullYear() && activeMonth === now.getMonth();

  // Filter receipts based on selected scope
  const filteredReceipts = useMemo(() => {
    if (viewScope === 'all') {
      return receipts;
    }
    return receipts.filter((r) => {
      // Check invoiceDate first, fallback to uploadedAt
      const dateToCheck = r.invoiceDate || r.uploadedAt.substring(0, 10);
      return dateToCheck.startsWith(monthPrefix);
    });
  }, [receipts, viewScope, monthPrefix]);

  // Aggregate category spend for the filtered receipts
  const { slices, totalSpendMinor, totalCount } = useMemo(() => {
    const map = new Map<string, { totalMinor: number; count: number; name: string; glCode: string }>();

    let total = 0;
    let count = 0;

    filteredReceipts.forEach((r) => {
      const catId = r.categoryId || 'uncat';
      const existing = map.get(catId) || {
        totalMinor: 0,
        count: 0,
        name: r.categoryName || 'Uncategorised',
        glCode: r.glCode || '9990',
      };

      existing.totalMinor += r.totalAedMinor;
      existing.count += 1;
      map.set(catId, existing);

      total += r.totalAedMinor;
      count += 1;
    });

    const entries = Array.from(map.entries()).sort((a, b) => b[1].totalMinor - a[1].totalMinor);

    const slicesData: SliceData[] = entries.map(([id, d], idx) => {
      const matchingCat = categories.find((c) => c.id === id);
      const spendLimitMinor = matchingCat?.spendLimitMinor;
      const isBreached = typeof spendLimitMinor === 'number' && spendLimitMinor > 0 && d.totalMinor > spendLimitMinor;
      const percentage = total > 0 ? (d.totalMinor / total) * 100 : 0;

      return {
        categoryId: id,
        categoryName: d.name,
        glCode: d.glCode,
        totalMinor: d.totalMinor,
        count: d.count,
        percentage,
        spendLimitMinor,
        isBreached,
        color: PALETTE[idx % PALETTE.length],
      };
    });

    return {
      slices: slicesData,
      totalSpendMinor: total,
      totalCount: count,
    };
  }, [filteredReceipts, categories]);

  // Generate D3 Pie and Arc generators
  const width = 320;
  const height = 320;
  const radius = Math.min(width, height) / 2;
  const innerRadius = radius * 0.58; // Donut style for modern aesthetics
  const outerRadius = radius - 10;

  const pieGenerator = useMemo(() => {
    return d3
      .pie<SliceData>()
      .value((d) => d.totalMinor)
      .sort(null)
      .padAngle(0.02);
  }, []);

  const arcGenerator = useMemo(() => {
    return d3
      .arc<d3.PieArcDatum<SliceData>>()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius)
      .cornerRadius(4);
  }, [innerRadius, outerRadius]);

  const arcHoverGenerator = useMemo(() => {
    return d3
      .arc<d3.PieArcDatum<SliceData>>()
      .innerRadius(innerRadius)
      .outerRadius(outerRadius + 8)
      .cornerRadius(5);
  }, [innerRadius, outerRadius]);

  const pieArcs = useMemo(() => {
    if (slices.length === 0 || totalSpendMinor === 0) return [];
    return pieGenerator(slices);
  }, [slices, totalSpendMinor, pieGenerator]);

  // Navigation handlers for months
  const handlePrevMonth = () => {
    if (activeMonth === 0) {
      setActiveYear((y) => y - 1);
      setActiveMonth(11);
    } else {
      setActiveMonth((m) => m - 1);
    }
  };

  const handleNextMonth = () => {
    if (activeMonth === 11) {
      setActiveYear((y) => y + 1);
      setActiveMonth(0);
    } else {
      setActiveMonth((m) => m + 1);
    }
  };

  const handleResetToCurrentMonth = () => {
    setActiveYear(now.getFullYear());
    setActiveMonth(now.getMonth());
    setViewScope('current_month');
  };

  const activeDisplaySlice = hoveredSlice || (selectedCategoryId ? slices.find(s => s.categoryId === selectedCategoryId) : null);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
      {/* Header with Title and Scope Selector */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <PieIcon className="w-5 h-5" />
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Current Month Category Expenses
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            D3-powered expense distribution by category for {monthName}
          </p>
        </div>

        {/* Scope and Month Navigation Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Month selector navigation */}
          {viewScope === 'current_month' && (
            <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-0.5 text-xs">
              <button
                onClick={handlePrevMonth}
                className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition cursor-pointer"
                title="Previous Month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <span className="px-2 font-semibold text-slate-800 dark:text-slate-200 min-w-[100px] text-center">
                {monthName}
              </span>
              <button
                onClick={handleNextMonth}
                className="p-1.5 hover:bg-white dark:hover:bg-slate-700 rounded-lg text-slate-600 dark:text-slate-300 transition cursor-pointer"
                title="Next Month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Toggle between Current Month & All Time */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 rounded-xl p-1 text-xs font-semibold">
            <button
              onClick={() => {
                setViewScope('current_month');
                if (!isCurrentCalendarMonth) handleResetToCurrentMonth();
              }}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                viewScope === 'current_month'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              Current Month
            </button>
            <button
              onClick={() => setViewScope('all')}
              className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                viewScope === 'all'
                  ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              All Time
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area: Chart + Legend */}
      {slices.length === 0 || totalSpendMinor === 0 ? (
        <div className="py-12 px-6 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800 space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-400 flex items-center justify-center mx-auto">
            <PieIcon className="w-6 h-6" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-200">
              No Expenses Found for {viewScope === 'current_month' ? monthName : 'Selected Scope'}
            </h4>
            <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
              {viewScope === 'current_month'
                ? `There are no receipts dated in ${monthName}. Upload receipts for this month or toggle to 'All Time' to view historical charts.`
                : 'Upload your first invoice to view category distributions.'}
            </p>
          </div>
          <div className="pt-2 flex items-center justify-center gap-3">
            {viewScope === 'current_month' && receipts.length > 0 && (
              <button
                onClick={() => setViewScope('all')}
                className="px-3.5 py-2 rounded-xl bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-800 dark:text-slate-200 text-xs font-bold transition cursor-pointer"
              >
                View All Time Data ({receipts.length} receipts)
              </button>
            )}
            {onNavigateToCapture && (
              <button
                onClick={onNavigateToCapture}
                className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition shadow-xs inline-flex items-center gap-1.5 cursor-pointer"
              >
                Upload Invoices <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* D3 Donut Chart SVG (5 cols) */}
          <div className="lg:col-span-5 flex flex-col items-center justify-center relative">
            <div className="relative w-[320px] h-[320px] flex items-center justify-center select-none">
              <svg
                width={width}
                height={height}
                viewBox={`0 0 ${width} ${height}`}
                className="overflow-visible"
              >
                <g transform={`translate(${width / 2}, ${height / 2})`}>
                  {pieArcs.map((arcData, i) => {
                    const slice = arcData.data;
                    const isHovered = hoveredSlice?.categoryId === slice.categoryId;
                    const isSelected = selectedCategoryId === slice.categoryId;
                    const isHighlighted = isHovered || isSelected;

                    const path = isHighlighted
                      ? arcHoverGenerator(arcData)
                      : arcGenerator(arcData);

                    return (
                      <path
                        key={slice.categoryId}
                        d={path || undefined}
                        fill={slice.color}
                        stroke="var(--color-slate-900, #0f172a)"
                        strokeWidth={isHighlighted ? 3 : 1.5}
                        className="transition-all duration-200 cursor-pointer focus:outline-none"
                        style={{
                          opacity: hoveredSlice && !isHighlighted ? 0.45 : 1,
                          filter: isHighlighted
                            ? 'drop-shadow(0 4px 8px rgba(0, 0, 0, 0.25))'
                            : 'none',
                          transform: isHighlighted ? 'scale(1.02)' : 'scale(1)',
                          transformOrigin: '0 0',
                        }}
                        onMouseEnter={() => setHoveredSlice(slice)}
                        onMouseLeave={() => setHoveredSlice(null)}
                        onClick={() => {
                          if (onSelectCategory) {
                            onSelectCategory(
                              selectedCategoryId === slice.categoryId ? null : slice.categoryId
                            );
                          }
                        }}
                      >
                        <title>
                          {`${slice.categoryName}: ${(slice.totalMinor / 100).toFixed(2)} AED (${slice.percentage.toFixed(1)}%)`}
                        </title>
                      </path>
                    );
                  })}
                </g>
              </svg>

              {/* Centered Donut Hole Label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center pointer-events-none px-6">
                {activeDisplaySlice ? (
                  <div className="space-y-0.5 animate-in fade-in">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block truncate max-w-[130px]">
                      {activeDisplaySlice.categoryName}
                    </span>
                    <span className="text-lg font-mono font-black text-slate-900 dark:text-white block">
                      {(activeDisplaySlice.totalMinor / 100).toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                      })}
                      <span className="text-xs font-normal text-slate-400 ml-1">AED</span>
                    </span>
                    <span className="text-xs font-bold text-indigo-600 dark:text-indigo-400 block">
                      {activeDisplaySlice.percentage.toFixed(1)}% of month
                    </span>
                    <span className="text-[10px] text-slate-400 block">
                      {activeDisplaySlice.count} receipt{activeDisplaySlice.count > 1 ? 's' : ''}
                    </span>
                  </div>
                ) : (
                  <div className="space-y-0.5">
                    <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                      {viewScope === 'current_month' ? 'Month Total' : 'All Spend'}
                    </span>
                    <span className="text-xl font-mono font-black text-slate-900 dark:text-white block">
                      {(totalSpendMinor / 100).toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                      })}
                      <span className="text-xs font-normal text-slate-400 ml-1">AED</span>
                    </span>
                    <span className="text-xs text-slate-500 font-semibold block">
                      {totalCount} transaction{totalCount > 1 ? 's' : ''}
                    </span>
                    <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold block">
                      {slices.length} active categories
                    </span>
                  </div>
                )}
              </div>
            </div>

            <p className="text-[11px] text-slate-400 mt-2 text-center">
              Hover over slices or click to filter line items below
            </p>
          </div>

          {/* Slices Breakdown Legend & Analytics (7 cols) */}
          <div className="lg:col-span-7 space-y-3">
            <div className="flex items-center justify-between text-xs font-semibold text-slate-500 px-1 pb-1 border-b border-slate-100 dark:border-slate-800">
              <span>Category & GL Code</span>
              <div className="flex items-center gap-6">
                <span>Distribution</span>
                <span className="w-24 text-right">Amount</span>
              </div>
            </div>

            <div className="max-h-[300px] overflow-y-auto space-y-2 pr-1">
              {slices.map((slice) => {
                const isHovered = hoveredSlice?.categoryId === slice.categoryId;
                const isSelected = selectedCategoryId === slice.categoryId;

                return (
                  <div
                    key={slice.categoryId}
                    onMouseEnter={() => setHoveredSlice(slice)}
                    onMouseLeave={() => setHoveredSlice(null)}
                    onClick={() => {
                      if (onSelectCategory) {
                        onSelectCategory(isSelected ? null : slice.categoryId);
                      }
                    }}
                    className={`p-2.5 rounded-xl border transition-all cursor-pointer flex items-center justify-between gap-3 text-xs ${
                      isSelected
                        ? 'border-sky-500 bg-sky-50/70 dark:bg-sky-950/40 shadow-xs'
                        : isHovered
                        ? 'border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60'
                        : 'border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700'
                    }`}
                  >
                    {/* Left: Color Dot, Category Name & GL Code */}
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className="w-3.5 h-3.5 rounded-md shrink-0 shadow-xs"
                        style={{ backgroundColor: slice.color }}
                      />
                      <div className="truncate">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-slate-800 dark:text-slate-200 truncate">
                            {slice.categoryName}
                          </span>
                          {slice.isBreached && (
                            <span className="inline-flex items-center gap-0.5 text-[9px] font-bold px-1.5 py-0.2 rounded-full bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300 shrink-0">
                              <AlertOctagon className="w-2.5 h-2.5" /> Breached
                            </span>
                          )}
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono">
                          GL {slice.glCode} • {slice.count} receipt{slice.count > 1 ? 's' : ''}
                        </span>
                      </div>
                    </div>

                    {/* Right: Progress bar & Minor Amount */}
                    <div className="flex items-center gap-4 shrink-0">
                      <div className="w-20 hidden sm:block">
                        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-1.5 overflow-hidden">
                          <div
                            className="h-1.5 rounded-full transition-all duration-300"
                            style={{
                              width: `${Math.min(100, Math.max(4, slice.percentage))}%`,
                              backgroundColor: slice.color,
                            }}
                          />
                        </div>
                        <span className="text-[10px] text-slate-400 font-mono text-right block mt-0.5">
                          {slice.percentage.toFixed(1)}%
                        </span>
                      </div>

                      <div className="text-right w-24">
                        <span className="font-mono font-bold text-slate-900 dark:text-white block">
                          {(slice.totalMinor / 100).toFixed(2)}
                          <span className="text-[10px] font-normal text-slate-400 ml-1">AED</span>
                        </span>
                        {slice.spendLimitMinor ? (
                          <span
                            className={`text-[9px] font-mono block ${
                              slice.isBreached ? 'text-red-600 font-bold' : 'text-slate-400'
                            }`}
                          >
                            Limit: {(slice.spendLimitMinor / 100).toFixed(0)}
                          </span>
                        ) : null}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Filter Reset if category is selected */}
            {selectedCategoryId && (
              <div className="pt-2 flex items-center justify-between text-xs bg-indigo-50/60 dark:bg-indigo-950/30 px-3 py-2 rounded-xl border border-indigo-200 dark:border-indigo-900/50">
                <span className="text-indigo-900 dark:text-indigo-300 text-[11px]">
                  Filtered to category: <strong>{slices.find(s => s.categoryId === selectedCategoryId)?.categoryName}</strong>
                </span>
                <button
                  onClick={() => onSelectCategory && onSelectCategory(null)}
                  className="text-xs text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer"
                >
                  Clear Selection
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
