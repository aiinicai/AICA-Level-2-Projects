import React from 'react';
import { AlertTriangle, Sparkles, RefreshCw, ArrowRight } from 'lucide-react';
import { QualityCheckResult } from '../types';
import { useLanguage } from '../context/LanguageContext';

interface ImageQualityModalProps {
  imagePreview: string;
  quality: QualityCheckResult;
  onRetake: () => void;
  onProceed: () => void;
}

export const ImageQualityModal: React.FC<ImageQualityModalProps> = ({
  imagePreview,
  quality,
  onRetake,
  onProceed,
}) => {
  const { t } = useLanguage();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-amber-200 dark:border-amber-900/40 p-6 overflow-hidden">
        <div className="flex items-center gap-3 text-amber-600 dark:text-amber-400 mb-4">
          <div className="p-2 rounded-xl bg-amber-500/10">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {t('qualityWarningTitle')}
            </h3>
            <p className="text-xs text-slate-500">
              Pre-flight capture evaluation detected clarity issues
            </p>
          </div>
        </div>

        {/* Thumbnail preview */}
        <div className="relative mb-4 rounded-xl overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 max-h-48 flex items-center justify-center">
          <img
            src={imagePreview}
            alt="Captured Receipt"
            className="w-full h-48 object-contain"
          />
          <div className="absolute top-2 right-2 flex flex-col gap-1 items-end">
            {quality.isBlurry && (
              <span className="bg-red-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                Blurry ({quality.blurVariance} / 45)
              </span>
            )}
            {quality.hasGlare && (
              <span className="bg-amber-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                Glare ({quality.glarePercentage}%)
              </span>
            )}
          </div>
        </div>

        <div className="rounded-xl bg-amber-50 dark:bg-amber-950/20 p-3.5 border border-amber-200/60 dark:border-amber-900/30 text-xs text-amber-900 dark:text-amber-200 mb-5 leading-relaxed">
          <div className="flex items-start gap-2">
            <Sparkles className="w-4 h-4 shrink-0 mt-0.5 text-amber-600 dark:text-amber-400" />
            <div>
              <p className="font-semibold mb-0.5">Recommendation:</p>
              <p>{quality.recommendation || 'The receipt is difficult to read. AI extraction works best with high contrast and sharp focus.'}</p>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={onRetake}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl bg-sky-600 text-white font-semibold text-xs py-2.5 px-4 shadow-sm hover:bg-sky-700 transition cursor-pointer active:scale-95"
          >
            <RefreshCw className="w-4 h-4" />
            {t('qualityRetake')}
          </button>
          <button
            onClick={onProceed}
            className="flex-1 flex items-center justify-center gap-2 rounded-xl border border-slate-300 dark:border-slate-700 font-semibold text-xs py-2.5 px-4 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            {t('qualityProceed')}
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
