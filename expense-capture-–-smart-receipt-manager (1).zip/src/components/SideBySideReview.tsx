import React, { useState } from 'react';
import {
  X,
  ZoomIn,
  ZoomOut,
  RotateCw,
  Maximize2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Split,
  Building2,
  Hash,
  Calendar,
  DollarSign,
  Tag,
  ShieldAlert,
  Info,
  Check,
  Edit2
} from 'lucide-react';
import { Receipt, Category } from '../types';
import { api } from '../services/api';
import { LineItemSplitModal } from './LineItemSplitModal';

interface SideBySideReviewProps {
  receipt: Receipt;
  categories: Category[];
  onClose: () => void;
  onReceiptUpdated: (updated: Receipt) => void;
}

export const SideBySideReview: React.FC<SideBySideReviewProps> = ({
  receipt,
  categories,
  onClose,
  onReceiptUpdated,
}) => {
  // Document viewer transform state
  const [zoom, setZoom] = useState(1);
  const [rotation, setRotation] = useState(0);

  // Form editing state
  const [formData, setFormData] = useState({
    supplierName: receipt.supplierName || '',
    trn: receipt.trn || '',
    invoiceNumber: receipt.invoiceNumber || '',
    invoiceDate: receipt.invoiceDate || '',
    total: (receipt.totalMinor / 100).toFixed(2),
    vatAmount: (receipt.vatAmountMinor / 100).toFixed(2),
    categoryId: receipt.categoryId,
    costCentre: receipt.costCentre || 'General Operations',
  });

  const [saving, setSaving] = useState(false);
  const [showSplitModal, setShowSplitModal] = useState(false);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState(false);
  const [reviewNotes, setReviewNotes] = useState('');

  const activeCats = categories.filter((c) => c.active);
  const selectedCat = categories.find((c) => c.id === formData.categoryId) || activeCats[0];

  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 3.0));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.5));
  const handleRotate = () => setRotation((r) => (r + 90) % 360);
  const handleReset = () => {
    setZoom(1);
    setRotation(0);
  };

  const handleFieldChange = (field: string, val: string) => {
    setFormData((prev) => ({ ...prev, [field]: val }));
  };

  const handleSaveEdits = async () => {
    setSaving(true);
    try {
      const totalMinor = Math.round((parseFloat(formData.total) || 0) * 100);
      const vatAmountMinor = Math.round((parseFloat(formData.vatAmount) || 0) * 100);

      const res = await api.updateReceipt(receipt.id, {
        supplierName: formData.supplierName,
        trn: formData.trn,
        invoiceNumber: formData.invoiceNumber,
        invoiceDate: formData.invoiceDate,
        totalMinor,
        vatAmountMinor,
        categoryId: formData.categoryId,
        costCentre: formData.costCentre,
      });

      onReceiptUpdated(res.receipt);
      setSaveSuccessNotice(true);
      setTimeout(() => setSaveSuccessNotice(false), 2500);
    } catch (err: any) {
      alert(`Error updating receipt: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleAccept = async () => {
    setSaving(true);
    try {
      // First save pending edits if any
      const totalMinor = Math.round((parseFloat(formData.total) || 0) * 100);
      const vatAmountMinor = Math.round((parseFloat(formData.vatAmount) || 0) * 100);
      await api.updateReceipt(receipt.id, {
        supplierName: formData.supplierName,
        trn: formData.trn,
        invoiceNumber: formData.invoiceNumber,
        invoiceDate: formData.invoiceDate,
        totalMinor,
        vatAmountMinor,
        categoryId: formData.categoryId,
        costCentre: formData.costCentre,
      });

      const res = await api.acceptReceipt(receipt.id, reviewNotes);
      onReceiptUpdated(res.receipt);
      onClose();
    } catch (err: any) {
      alert(`Approval error: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  const handleReject = async () => {
    const reason = prompt('Please specify rejection reason for audit trail:', 'Illegible receipt or invalid business expense');
    if (!reason) return;
    setSaving(true);
    try {
      const res = await api.rejectReceipt(receipt.id, reason);
      onReceiptUpdated(res.receipt);
      onClose();
    } catch (err: any) {
      alert(`Rejection error: ${err.message}`);
    } finally {
      setSaving(false);
    }
  };

  // Confidence pill helper: fields with confidence < 0.85 are highlighted
  const getConfidenceBadge = (score: number | undefined) => {
    const val = score !== undefined ? score : 0.85;
    const isLow = val < 0.85;
    return (
      <span
        className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded ${
          isLow
            ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 ring-1 ring-amber-400/40'
            : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
        }`}
        title={`Extraction confidence: ${(val * 100).toFixed(0)}%`}
      >
        {(val * 100).toFixed(0)}%
      </span>
    );
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-2 sm:p-4 animate-in fade-in">
      <div className="w-full h-full max-w-7xl rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
          <div className="flex items-center gap-3">
            <h2 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <span>Review Receipt #{receipt.id.substring(0, 8)}</span>
              <span
                className={`text-xs px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider ${
                  receipt.status === 'approved'
                    ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                    : receipt.status === 'rejected'
                    ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                    : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                }`}
              >
                {receipt.status.replace('_', ' ')}
              </span>
            </h2>
            <span className="text-xs text-slate-400 font-mono hidden sm:inline">
              Taxonomy {`v${receipt.taxonomyVersion || 1}`}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {saveSuccessNotice && (
              <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1 animate-in fade-in">
                <Check className="w-3.5 h-3.5" /> Edits Saved
              </span>
            )}
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Side-by-Side Main Container */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 overflow-hidden">
          {/* Left Column: Document Image & Controls */}
          <div className="lg:col-span-6 bg-slate-950 flex flex-col relative border-b lg:border-b-0 lg:border-r border-slate-800 min-h-[320px] lg:min-h-0">
            {/* Viewer Controls Toolbar */}
            <div className="absolute top-3 left-3 z-10 flex items-center gap-1 rounded-xl bg-slate-900/80 p-1 backdrop-blur-md border border-slate-700/60 shadow-lg text-white">
              <button
                onClick={handleZoomIn}
                className="p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
                title="Zoom In"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={handleZoomOut}
                className="p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
                title="Zoom Out"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={handleRotate}
                className="p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer"
                title="Rotate 90° Clockwise"
              >
                <RotateCw className="w-4 h-4" />
              </button>
              <button
                onClick={handleReset}
                className="p-1.5 rounded-lg hover:bg-slate-800 transition cursor-pointer text-xs font-mono px-2"
                title="Reset View"
              >
                100%
              </button>
            </div>

            {/* Document Render Canvas / Area */}
            <div className="flex-1 overflow-auto flex items-center justify-center p-4 select-none">
              <div
                style={{
                  transform: `scale(${zoom}) rotate(${rotation}deg)`,
                  transformOrigin: 'center center',
                  transition: 'transform 0.15s ease-out',
                }}
                className="max-w-full max-h-full flex items-center justify-center"
              >
                {receipt.fileType === 'application/pdf' ? (
                  <iframe
                    src={receipt.fileUrl}
                    title="PDF Invoice Preview"
                    className="w-[500px] h-[700px] rounded-lg shadow-2xl bg-white"
                  />
                ) : (
                  <img
                    src={receipt.fileUrl}
                    alt="Original Receipt Scan"
                    className="max-h-[80vh] max-w-full object-contain rounded-lg shadow-2xl"
                  />
                )}
              </div>
            </div>

            <div className="p-2.5 bg-slate-900/90 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
              <span className="truncate max-w-[280px]">File: {receipt.fileName}</span>
              <span className="font-mono">SHA-256: {receipt.fileHash.substring(0, 12)}...</span>
            </div>
          </div>

          {/* Right Column: Extracted Fields, Tax Reconciliation, Line Items */}
          <div className="lg:col-span-6 flex flex-col bg-slate-50/40 dark:bg-slate-900 overflow-y-auto">
            <div className="p-5 space-y-5 flex-1">
              {/* Policy Flags Banner */}
              {receipt.policyFlags && receipt.policyFlags.length > 0 && (
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wide">
                    <ShieldAlert className="w-4 h-4 text-amber-500" />
                    <span>Compliance & Tax Policy Alerts ({receipt.policyFlags.length})</span>
                  </div>
                  {receipt.policyFlags.map((flag, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
                        flag.severity === 'error'
                          ? 'bg-red-50 dark:bg-red-950/20 border-red-200 dark:border-red-900/40 text-red-900 dark:text-red-300'
                          : flag.severity === 'warning'
                          ? 'bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-300'
                          : 'bg-blue-50 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900/40 text-blue-900 dark:text-blue-300'
                      }`}
                    >
                      <AlertTriangle
                        className={`w-4 h-4 shrink-0 mt-0.5 ${
                          flag.severity === 'error' ? 'text-red-600' : 'text-amber-600'
                        }`}
                      />
                      <div className="flex-1">
                        <p className="font-semibold">{flag.message}</p>
                        <p className="text-[10px] opacity-75 mt-0.5">Rule: {flag.rule}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Extraction Confidence Summary */}
              <div className="p-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <div className="p-1.5 rounded-lg bg-sky-50 dark:bg-sky-950 text-sky-600">
                    <Info className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-slate-800 dark:text-white block">
                      AI Vision Extraction
                    </span>
                    <span className="text-[11px] text-slate-500">
                      Model: {receipt.aiModelName} ({receipt.promptVersion})
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 text-[11px]">Category Confidence:</span>
                  {getConfidenceBadge(receipt.categoryConfidence)}
                </div>
              </div>

              {/* Form Fields: Side-by-Side Review */}
              <div className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-700/60 pb-2">
                  <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider flex items-center gap-1.5">
                    <Edit2 className="w-3.5 h-3.5 text-sky-600" />
                    <span>Extracted Particulars (Edits Tracked in Audit Log)</span>
                  </h3>
                  <button
                    onClick={handleSaveEdits}
                    disabled={saving}
                    className="text-xs font-bold text-sky-600 hover:text-sky-700 disabled:opacity-50 cursor-pointer"
                  >
                    Save Changes
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 text-xs">
                  {/* Supplier Name */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" />
                        Supplier Name
                      </label>
                      {getConfidenceBadge(receipt.fieldConfidence?.supplier)}
                    </div>
                    <input
                      type="text"
                      value={formData.supplierName}
                      onChange={(e) => handleFieldChange('supplierName', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 p-2 text-slate-900 dark:text-white focus:bg-white"
                      placeholder="e.g. ADNOC Fuel Station"
                    />
                    {receipt.supplierNameArabic && (
                      <span className="text-[11px] text-slate-500 mt-0.5 block font-arabic" dir="rtl">
                        {receipt.supplierNameArabic}
                      </span>
                    )}
                  </div>

                  {/* TRN */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        <Hash className="w-3.5 h-3.5 text-slate-400" />
                        Supplier TRN (15 digits)
                      </label>
                      {getConfidenceBadge(receipt.fieldConfidence?.trn)}
                    </div>
                    <input
                      type="text"
                      value={formData.trn}
                      onChange={(e) => handleFieldChange('trn', e.target.value)}
                      className={`w-full rounded-lg border p-2 text-slate-900 dark:text-white font-mono ${
                        formData.trn && formData.trn.replace(/\D/g, '').length !== 15
                          ? 'border-red-400 bg-red-50/50 dark:bg-red-950/30'
                          : 'border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900'
                      }`}
                      placeholder="100XXXXXXXXX003"
                    />
                  </div>

                  {/* Invoice / Bill # */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        <Tag className="w-3.5 h-3.5 text-slate-400" />
                        Invoice / Bill Number
                      </label>
                      {getConfidenceBadge(receipt.fieldConfidence?.invoiceNumber)}
                    </div>
                    <input
                      type="text"
                      value={formData.invoiceNumber}
                      onChange={(e) => handleFieldChange('invoiceNumber', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 p-2 text-slate-900 dark:text-white font-mono"
                      placeholder="INV-2026-001"
                    />
                  </div>

                  {/* Invoice Date */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        <Calendar className="w-3.5 h-3.5 text-slate-400" />
                        Date
                      </label>
                      {getConfidenceBadge(receipt.fieldConfidence?.date)}
                    </div>
                    <input
                      type="date"
                      value={formData.invoiceDate}
                      onChange={(e) => handleFieldChange('invoiceDate', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 p-2 text-slate-900 dark:text-white"
                    />
                  </div>

                  {/* Total Amount */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                        Total ({receipt.currency})
                      </label>
                      {getConfidenceBadge(receipt.fieldConfidence?.total)}
                    </div>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.total}
                      onChange={(e) => handleFieldChange('total', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 p-2 text-slate-900 dark:text-white font-mono font-bold text-sm"
                    />
                  </div>

                  {/* VAT Amount */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <label className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1">
                        <DollarSign className="w-3.5 h-3.5 text-slate-400" />
                        VAT Amount (5%)
                      </label>
                      {getConfidenceBadge(receipt.fieldConfidence?.vatAmount)}
                    </div>
                    <input
                      type="number"
                      step="0.01"
                      value={formData.vatAmount}
                      onChange={(e) => handleFieldChange('vatAmount', e.target.value)}
                      className="w-full rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 p-2 text-slate-900 dark:text-white font-mono"
                    />
                  </div>
                </div>

                {/* Controlled Category Selection */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-700/60">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-semibold text-xs text-slate-700 dark:text-slate-300">
                      Assigned Category (Controlled List Only)
                    </label>
                    <span className="text-[11px] text-slate-500">
                      Source: <strong className="text-sky-600">{receipt.classificationSource}</strong>
                    </span>
                  </div>
                  <select
                    value={formData.categoryId}
                    onChange={(e) => handleFieldChange('categoryId', e.target.value)}
                    className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-900 p-2 text-slate-900 dark:text-white font-semibold"
                  >
                    {activeCats.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name} (GL: {cat.glCode} | VAT: {cat.vatRecoverability} | CT: {cat.corporateTaxTreatment})
                      </option>
                    ))}
                  </select>
                  <p className="text-[11px] text-slate-500 mt-1 italic">
                    Reason: {receipt.categoryReason}
                  </p>
                </div>
              </div>

              {/* Tax & Corporate Tax Treatment Summary */}
              <div className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-2.5 text-xs">
                <h4 className="font-bold text-slate-800 dark:text-white uppercase tracking-wider text-[11px]">
                  Tax Recoverability & Corporate Tax Treatment
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] text-slate-500 block">VAT Recoverability</span>
                    <span className="font-semibold text-slate-800 dark:text-white capitalize">
                      {selectedCat.vatRecoverability} ({(receipt.recoverableVatMinor / 100).toFixed(2)} AED)
                    </span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-100 dark:border-slate-800">
                    <span className="text-[11px] text-slate-500 block">Corporate Tax Treatment</span>
                    <span className="font-semibold text-slate-800 dark:text-white">
                      {selectedCat.corporateTaxTreatment === 'fifty_percent_limited'
                        ? '50% Limited (Deductible: ' + (receipt.ctDeductibleAmountMinor / 100).toFixed(2) + ' AED)'
                        : selectedCat.corporateTaxTreatment === 'fully_deductible'
                        ? '100% Deductible'
                        : 'Non-Deductible'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Line Items List */}
              <div className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs space-y-2 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-bold text-slate-800 dark:text-white uppercase tracking-wider text-[11px]">
                    Line Items ({receipt.lineItems?.length || 0})
                  </h4>
                  <button
                    onClick={() => setShowSplitModal(true)}
                    className="flex items-center gap-1 text-[11px] font-bold text-sky-600 hover:text-sky-700"
                  >
                    <Split className="w-3.5 h-3.5" />
                    Split Categories
                  </button>
                </div>

                {receipt.lineItems && receipt.lineItems.length > 0 ? (
                  <div className="space-y-1.5 divide-y divide-slate-100 dark:divide-slate-700/40">
                    {receipt.lineItems.map((item, idx) => (
                      <div key={idx} className="pt-1.5 flex items-center justify-between text-xs">
                        <div className="truncate max-w-[220px]">
                          <span className="font-medium text-slate-800 dark:text-slate-200 block truncate">
                            {item.description}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            Qty: {item.quantity} × {(item.unitPriceMinor / 100).toFixed(2)}
                          </span>
                        </div>
                        <span className="font-mono font-semibold text-slate-900 dark:text-white">
                          {(item.lineTotalMinor / 100).toFixed(2)} {receipt.currency}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-slate-400 italic text-xs py-2">No line items itemized on document.</p>
                )}
              </div>

              {/* Review notes input */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  Reviewer Notes / Justification
                </label>
                <input
                  type="text"
                  value={reviewNotes}
                  onChange={(e) => setReviewNotes(e.target.value)}
                  placeholder="Optional review sign-off notes..."
                  className="w-full text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {/* Bottom Actions Bar */}
            <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between gap-3">
              <button
                onClick={handleReject}
                disabled={saving}
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl border border-red-200 dark:border-red-900/60 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/30 text-xs font-bold transition cursor-pointer"
              >
                <XCircle className="w-4 h-4" />
                Reject
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowSplitModal(true)}
                  className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  <Split className="w-4 h-4" />
                  Split Bill
                </button>

                <button
                  onClick={handleAccept}
                  disabled={saving}
                  className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-emerald-600 text-white text-xs font-bold shadow-sm hover:bg-emerald-700 transition cursor-pointer active:scale-95 disabled:opacity-50"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  {saving ? 'Processing...' : 'Accept & Approve'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showSplitModal && (
        <LineItemSplitModal
          receipt={receipt}
          categories={categories}
          onClose={() => setShowSplitModal(false)}
          onSaveSplit={async (splits) => {
            const res = await api.splitReceipt(receipt.id, splits);
            onReceiptUpdated(res.receipt);
          }}
        />
      )}
    </div>
  );
};
