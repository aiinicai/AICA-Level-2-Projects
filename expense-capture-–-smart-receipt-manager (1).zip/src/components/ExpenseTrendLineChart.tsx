import React, { useState, useMemo } from 'react';
import * as d3 from 'd3';
import {
  TrendingUp,
  Calendar,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Eye,
  EyeOff,
  Filter,
  BarChart3,
  Sparkles,
  ChevronRight,
  Table as TableIcon,
  RotateCcw,
} from 'lucide-react';
import { Receipt, Category } from '../types';

interface ExpenseTrendLineChartProps {
  receipts: Receipt[];
  categories: Category[];
  onSelectCategory?: (categoryId: string | null) => void;
  onNavigateToCapture?: () => void;
}

// Distinct high-contrast palette for high-volume category trend lines
const CATEGORY_COLORS = [
  '#10b981', // emerald-500
  '#f59e0b', // amber-500
  '#8b5cf6', // violet-500
  '#f43f5e', // rose-500
  '#06b6d4', // cyan-500
  '#ec4899', // pink-500
  '#14b8a6', // teal-500
  '#eab308', // yellow-500
  '#3b82f6', // blue-500
];

const TOTAL_SPEND_COLOR = '#4f46e5'; // vibrant electric indigo

type TimeframeOption = '6M' | '12M' | 'YTD' | 'ALL';

interface MonthDataPoint {
  monthKey: string; // "YYYY-MM"
  monthLabel: string; // "Jan '26"
  fullMonthLabel: string; // "January 2026"
  totalSpendMinor: number;
  totalVatMinor: number;
  transactionCount: number;
  categorySpends: Record<string, number>; // categoryId -> spendMinor
  topCategoryName?: string;
  topCategorySpendMinor?: number;
  momGrowthPercent: number | null; // vs previous month
}

export const ExpenseTrendLineChart: React.FC<ExpenseTrendLineChartProps> = ({
  receipts,
  categories,
  onSelectCategory,
  onNavigateToCapture,
}) => {
  const [timeframe, setTimeframe] = useState<TimeframeOption>('6M');
  const [showTotalSpend, setShowTotalSpend] = useState<boolean>(true);
  const [activeCategoryIds, setActiveCategoryIds] = useState<Set<string>>(new Set());
  const [hoveredMonthIndex, setHoveredMonthIndex] = useState<number | null>(null);
  const [showDataTable, setShowDataTable] = useState<boolean>(false);
  const [additionalCategoryToAdd, setAdditionalCategoryToAdd] = useState<string>('');

  // 1. Identify overall high-volume categories across all receipts
  const rankedCategories = useMemo(() => {
    const totals = new Map<string, { spendMinor: number; name: string; count: number }>();

    receipts.forEach((r) => {
      const catId = r.categoryId || 'uncategorised';
      const catName = r.categoryName || 'Uncategorised';
      const existing = totals.get(catId) || { spendMinor: 0, name: catName, count: 0 };
      existing.spendMinor += r.totalMinor || 0;
      existing.count += 1;
      totals.set(catId, existing);
    });

    return Array.from(totals.entries())
      .sort((a, b) => b[1].spendMinor - a[1].spendMinor)
      .map(([id, data], idx) => ({
        id,
        name: data.name,
        spendMinor: data.spendMinor,
        count: data.count,
        color: CATEGORY_COLORS[idx % CATEGORY_COLORS.length],
      }));
  }, [receipts]);

  // Top 4 categories are high-volume categories
  const topHighVolumeCategories = useMemo(() => {
    return rankedCategories.slice(0, 4);
  }, [rankedCategories]);

  // Initialize active categories to top 2 high-volume categories on first load
  const effectiveActiveCategories = useMemo(() => {
    if (activeCategoryIds.size === 0 && topHighVolumeCategories.length > 0) {
      // Default to top 2 categories
      return new Set(topHighVolumeCategories.slice(0, 2).map((c) => c.id));
    }
    return activeCategoryIds;
  }, [activeCategoryIds, topHighVolumeCategories]);

  // Toggle category visibility
  const toggleCategory = (catId: string) => {
    const next = new Set(effectiveActiveCategories);
    if (next.has(catId)) {
      next.delete(catId);
    } else {
      next.add(catId);
    }
    setActiveCategoryIds(next);
  };

  // 2. Generate list of month keys based on timeframe
  const monthlyData = useMemo<MonthDataPoint[]>(() => {
    if (receipts.length === 0) return [];

    // Find date range
    const validDates: Date[] = [];
    receipts.forEach((r) => {
      const dStr = r.invoiceDate || (r.uploadedAt ? r.uploadedAt.substring(0, 10) : null);
      if (dStr) {
        const d = new Date(dStr);
        if (!isNaN(d.getTime())) validDates.push(d);
      }
    });

    if (validDates.length === 0) return [];

    const now = new Date();
    let startMonthDate: Date;
    let endMonthDate = new Date(now.getFullYear(), now.getMonth(), 1);

    // If receipts have dates later than current month, extend endMonthDate
    validDates.forEach((d) => {
      const dMonth = new Date(d.getFullYear(), d.getMonth(), 1);
      if (dMonth > endMonthDate) endMonthDate = dMonth;
    });

    if (timeframe === '6M') {
      startMonthDate = new Date(endMonthDate.getFullYear(), endMonthDate.getMonth() - 5, 1);
    } else if (timeframe === '12M') {
      startMonthDate = new Date(endMonthDate.getFullYear(), endMonthDate.getMonth() - 11, 1);
    } else if (timeframe === 'YTD') {
      startMonthDate = new Date(endMonthDate.getFullYear(), 0, 1);
    } else {
      // ALL: find earliest
      let earliest = validDates[0];
      validDates.forEach((d) => {
        if (d < earliest) earliest = d;
      });
      startMonthDate = new Date(earliest.getFullYear(), earliest.getMonth(), 1);
    }

    // Build contiguous months array
    const months: MonthDataPoint[] = [];
    const cur = new Date(startMonthDate);

    while (cur <= endMonthDate) {
      const year = cur.getFullYear();
      const monthNum = cur.getMonth() + 1;
      const monthKey = `${year}-${String(monthNum).padStart(2, '0')}`;
      const monthLabel = cur.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
      const fullMonthLabel = cur.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

      months.push({
        monthKey,
        monthLabel,
        fullMonthLabel,
        totalSpendMinor: 0,
        totalVatMinor: 0,
        transactionCount: 0,
        categorySpends: {},
        momGrowthPercent: null,
      });

      cur.setMonth(cur.getMonth() + 1);
    }

    // Populate data from receipts
    const monthMap = new Map<string, MonthDataPoint>();
    months.forEach((m) => monthMap.set(m.monthKey, m));

    receipts.forEach((r) => {
      const dStr = r.invoiceDate || (r.uploadedAt ? r.uploadedAt.substring(0, 10) : null);
      if (!dStr) return;
      const key = dStr.substring(0, 7);
      const mPoint = monthMap.get(key);
      if (mPoint) {
        mPoint.totalSpendMinor += r.totalMinor || 0;
        mPoint.totalVatMinor += r.vatAmountMinor || 0;
        mPoint.transactionCount += 1;

        const catId = r.categoryId || 'uncategorised';
        mPoint.categorySpends[catId] = (mPoint.categorySpends[catId] || 0) + (r.totalMinor || 0);
      }
    });

    // Compute top category and MoM growth for each month
    for (let i = 0; i < months.length; i++) {
      const curMonth = months[i];

      // Top category in this month
      let topCatId = '';
      let topSpend = 0;
      Object.entries(curMonth.categorySpends).forEach(([catId, spend]) => {
        if (spend > topSpend) {
          topSpend = spend;
          topCatId = catId;
        }
      });
      if (topCatId) {
        const found = categories.find((c) => c.id === topCatId);
        curMonth.topCategoryName = found ? found.name : 'Other';
        curMonth.topCategorySpendMinor = topSpend;
      }

      // MoM calculation
      if (i > 0) {
        const prevMonth = months[i - 1];
        if (prevMonth.totalSpendMinor > 0) {
          const delta = curMonth.totalSpendMinor - prevMonth.totalSpendMinor;
          curMonth.momGrowthPercent = Math.round((delta / prevMonth.totalSpendMinor) * 1000) / 10;
        } else if (curMonth.totalSpendMinor > 0) {
          curMonth.momGrowthPercent = 100;
        } else {
          curMonth.momGrowthPercent = 0;
        }
      }
    }

    return months;
  }, [receipts, timeframe, categories]);

  // Overall summary metrics across the displayed timeframe
  const summaryMetrics = useMemo(() => {
    if (monthlyData.length === 0) {
      return {
        totalPeriodSpendMinor: 0,
        averageMonthlySpendMinor: 0,
        latestMomPercent: null,
        peakMonth: null,
      };
    }

    let total = 0;
    let peak = monthlyData[0];

    monthlyData.forEach((m) => {
      total += m.totalSpendMinor;
      if (m.totalSpendMinor > peak.totalSpendMinor) {
        peak = m;
      }
    });

    const avg = total / monthlyData.length;
    const latest = monthlyData[monthlyData.length - 1];

    return {
      totalPeriodSpendMinor: total,
      averageMonthlySpendMinor: avg,
      latestMomPercent: latest.momGrowthPercent,
      peakMonth: peak,
    };
  }, [monthlyData]);

  // SVG Chart Geometry & Dimensions
  const svgWidth = 840;
  const svgHeight = 320;
  const margin = { top: 30, right: 30, bottom: 40, left: 65 };
  const innerWidth = svgWidth - margin.left - margin.right;
  const innerHeight = svgHeight - margin.top - margin.bottom;

  // D3 Scales & Paths
  const { xScale, yScale, yTicks, totalSpendPath, totalAreaPath, categoryPaths, maxVal } =
    useMemo(() => {
      if (monthlyData.length === 0) {
        return {
          xScale: null,
          yScale: null,
          yTicks: [],
          totalSpendPath: '',
          totalAreaPath: '',
          categoryPaths: [],
          maxVal: 0,
        };
      }

      // Determine max value for Y-scale
      let calculatedMax = 0;
      monthlyData.forEach((m) => {
        if (showTotalSpend && m.totalSpendMinor > calculatedMax) {
          calculatedMax = m.totalSpendMinor;
        }
        effectiveActiveCategories.forEach((catId) => {
          const catSpend = m.categorySpends[catId] || 0;
          if (catSpend > calculatedMax) calculatedMax = catSpend;
        });
      });

      // Default minimum buffer if 0 spend
      if (calculatedMax === 0) calculatedMax = 100000; // 1,000 AED
      // Add 15% headroom for aesthetic spacing
      calculatedMax = calculatedMax * 1.15;

      const x = d3
        .scalePoint<string>()
        .domain(monthlyData.map((d) => d.monthKey))
        .range([0, innerWidth])
        .padding(0.1);

      const y = d3.scaleLinear().domain([0, calculatedMax]).range([innerHeight, 0]);

      const ticks = y.ticks(5);

      // Line generator with smooth cubic curves
      const lineGen = d3
        .line<{ xVal: string; yVal: number }>()
        .x((d) => x(d.xVal) || 0)
        .y((d) => y(d.yVal))
        .curve(d3.curveMonotoneX);

      // Area generator for Total Spend gradient
      const areaGen = d3
        .area<{ xVal: string; yVal: number }>()
        .x((d) => x(d.xVal) || 0)
        .y0(innerHeight)
        .y1((d) => y(d.yVal))
        .curve(d3.curveMonotoneX);

      // Total Spend Line & Area
      const totalSpendPoints = monthlyData.map((m) => ({
        xVal: m.monthKey,
        yVal: m.totalSpendMinor,
      }));

      const tPath = showTotalSpend ? lineGen(totalSpendPoints) || '' : '';
      const aPath = showTotalSpend ? areaGen(totalSpendPoints) || '' : '';

      // Category Paths
      const catPaths: {
        id: string;
        name: string;
        color: string;
        path: string;
        points: { x: number; y: number; val: number; month: MonthDataPoint }[];
      }[] = [];

      effectiveActiveCategories.forEach((catId) => {
        const catMeta = rankedCategories.find((c) => c.id === catId);
        const color = catMeta?.color || '#6366f1';
        const name = catMeta?.name || 'Category';

        const points = monthlyData.map((m) => {
          const val = m.categorySpends[catId] || 0;
          return {
            xVal: m.monthKey,
            yVal: val,
            x: x(m.monthKey) || 0,
            y: y(val),
            val,
            month: m,
          };
        });

        const p = lineGen(points) || '';
        catPaths.push({
          id: catId,
          name,
          color,
          path: p,
          points,
        });
      });

      return {
        xScale: x,
        yScale: y,
        yTicks: ticks,
        totalSpendPath: tPath,
        totalAreaPath: aPath,
        categoryPaths: catPaths,
        maxVal: calculatedMax,
      };
    }, [monthlyData, showTotalSpend, effectiveActiveCategories, innerWidth, innerHeight, rankedCategories]);

  // Format minor units to compact currency label (e.g. 1.5k AED)
  const formatYAxisTick = (valMinor: number) => {
    const valAed = valMinor / 100;
    if (valAed >= 1000000) return `${(valAed / 1000000).toFixed(1)}M`;
    if (valAed >= 1000) return `${(valAed / 1000).toFixed(0)}k`;
    return `${valAed.toFixed(0)}`;
  };

  // Hovered active month data
  const hoveredMonthData =
    hoveredMonthIndex !== null && monthlyData[hoveredMonthIndex]
      ? monthlyData[hoveredMonthIndex]
      : null;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5 animate-in fade-in">
      {/* ----------------- Top Header Section ----------------- */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
              <TrendingUp className="w-5 h-5" />
            </span>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Month-over-Month Expense Trends
            </h3>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            Track multi-month expense trajectories, MoM growth rates, and category spend dynamics.
          </p>
        </div>

        {/* Controls: Timeframe selector and View Mode */}
        <div className="flex flex-wrap items-center gap-2 self-start lg:self-auto">
          {/* Timeframe selector */}
          <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex items-center gap-1 text-xs font-semibold">
            {(['6M', '12M', 'YTD', 'ALL'] as TimeframeOption[]).map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  timeframe === tf
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tf === '6M'
                  ? 'Last 6 Months'
                  : tf === '12M'
                  ? 'Last 12 Months'
                  : tf === 'YTD'
                  ? 'YTD'
                  : 'All Time'}
              </button>
            ))}
          </div>

          {/* Toggle Table View Button */}
          <button
            onClick={() => setShowDataTable(!showDataTable)}
            className={`px-3 py-2 rounded-xl text-xs font-bold border transition inline-flex items-center gap-1.5 cursor-pointer ${
              showDataTable
                ? 'bg-indigo-50 border-indigo-300 text-indigo-700 dark:bg-indigo-950 dark:border-indigo-800 dark:text-indigo-300'
                : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-50'
            }`}
          >
            <TableIcon className="w-3.5 h-3.5" />
            <span>{showDataTable ? 'Hide Table' : 'MoM Table'}</span>
          </button>
        </div>
      </div>

      {/* ----------------- Key Performance Metrics Strip ----------------- */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Total Timeframe Spend */}
        <div className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 block mb-0.5">
            Total Spend ({timeframe})
          </span>
          <span className="text-base sm:text-lg font-mono font-bold text-slate-900 dark:text-white">
            {(summaryMetrics.totalPeriodSpendMinor / 100).toLocaleString('en-US', {
              minimumFractionDigits: 2,
            })}{' '}
            <span className="text-[10px] font-normal text-slate-400">AED</span>
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            {monthlyData.reduce((acc, m) => acc + m.transactionCount, 0)} receipts total
          </div>
        </div>

        {/* Monthly Average Spend */}
        <div className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 block mb-0.5">
            Avg Monthly Burn
          </span>
          <span className="text-base sm:text-lg font-mono font-bold text-indigo-600 dark:text-indigo-400">
            {(summaryMetrics.averageMonthlySpendMinor / 100).toLocaleString('en-US', {
              minimumFractionDigits: 2,
            })}{' '}
            <span className="text-[10px] font-normal text-slate-400">AED</span>
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5">
            Across {monthlyData.length} monthly cycles
          </div>
        </div>

        {/* Latest Month MoM Trend */}
        <div className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 block mb-0.5">
            Latest MoM Velocity
          </span>
          {summaryMetrics.latestMomPercent !== null ? (
            <div className="flex items-baseline gap-1.5">
              <span
                className={`text-base sm:text-lg font-mono font-bold inline-flex items-center ${
                  summaryMetrics.latestMomPercent > 0
                    ? 'text-red-600 dark:text-red-400'
                    : summaryMetrics.latestMomPercent < 0
                    ? 'text-emerald-600 dark:text-emerald-400'
                    : 'text-slate-600'
                }`}
              >
                {summaryMetrics.latestMomPercent > 0 ? (
                  <ArrowUpRight className="w-4 h-4 mr-0.5 inline" />
                ) : summaryMetrics.latestMomPercent < 0 ? (
                  <ArrowDownRight className="w-4 h-4 mr-0.5 inline" />
                ) : null}
                {summaryMetrics.latestMomPercent > 0 ? '+' : ''}
                {summaryMetrics.latestMomPercent}%
              </span>
              <span className="text-[10px] text-slate-400 font-medium">vs prior mo.</span>
            </div>
          ) : (
            <span className="text-sm font-semibold text-slate-400">Baseline</span>
          )}
          <div className="text-[10px] text-slate-400 mt-0.5">
            {monthlyData[monthlyData.length - 1]?.monthLabel || 'Current'}
          </div>
        </div>

        {/* Peak Month */}
        <div className="p-3.5 rounded-xl bg-slate-50/80 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
          <span className="text-[11px] font-medium text-slate-500 block mb-0.5">
            Peak Spend Cycle
          </span>
          <span className="text-base sm:text-lg font-mono font-bold text-amber-600 dark:text-amber-400 truncate block">
            {summaryMetrics.peakMonth
              ? `${(summaryMetrics.peakMonth.totalSpendMinor / 100).toLocaleString('en-US', {
                  maximumFractionDigits: 0,
                })} AED`
              : '0 AED'}
          </span>
          <div className="text-[10px] text-slate-400 mt-0.5 truncate">
            {summaryMetrics.peakMonth ? summaryMetrics.peakMonth.fullMonthLabel : 'N/A'}
          </div>
        </div>
      </div>

      {/* ----------------- Interactive Series Toggles & Filter Bar ----------------- */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-1 border-t border-slate-100 dark:border-slate-800/80">
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <span className="text-slate-400 font-semibold flex items-center gap-1 mr-1">
            <Filter className="w-3.5 h-3.5" /> Series:
          </span>

          {/* Toggle: Total Spend */}
          <button
            onClick={() => setShowTotalSpend(!showTotalSpend)}
            className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer flex items-center gap-2 ${
              showTotalSpend
                ? 'border-indigo-600 bg-indigo-50 text-indigo-900 dark:bg-indigo-950/80 dark:border-indigo-500 dark:text-indigo-200'
                : 'border-slate-200 dark:border-slate-800 text-slate-400 hover:text-slate-600 bg-transparent'
            }`}
          >
            <span
              className="w-2.5 h-2.5 rounded-full"
              style={{ backgroundColor: TOTAL_SPEND_COLOR }}
            />
            <span>Total Spend</span>
            {showTotalSpend ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
          </button>

          {/* High-Volume Category Toggles */}
          {topHighVolumeCategories.map((cat) => {
            const isVisible = effectiveActiveCategories.has(cat.id);
            return (
              <button
                key={cat.id}
                onClick={() => toggleCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer flex items-center gap-2 ${
                  isVisible
                    ? 'border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 shadow-xs'
                    : 'border-slate-200 dark:border-slate-800/60 text-slate-400 hover:text-slate-600 dark:hover:text-slate-300 bg-transparent'
                }`}
              >
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: cat.color }}
                />
                <span className="max-w-[130px] truncate">{cat.name}</span>
                {isVisible ? <Eye className="w-3 h-3 text-slate-500" /> : <EyeOff className="w-3 h-3" />}
              </button>
            );
          })}

          {/* Add more categories selector if there are more than 4 */}
          {rankedCategories.length > 4 && (
            <select
              value={additionalCategoryToAdd}
              onChange={(e) => {
                const val = e.target.value;
                if (val) {
                  toggleCategory(val);
                  setAdditionalCategoryToAdd('');
                }
              }}
              className="px-2.5 py-1.5 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 text-xs font-semibold hover:border-slate-400 focus:outline-none cursor-pointer"
            >
              <option value="">+ Add category...</option>
              {rankedCategories
                .filter((c) => !effectiveActiveCategories.has(c.id))
                .map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
            </select>
          )}
        </div>

        {/* Quick Reset / Solo actions */}
        <div className="flex items-center gap-2 text-xs">
          <button
            onClick={() => {
              setShowTotalSpend(true);
              setActiveCategoryIds(new Set(topHighVolumeCategories.map((c) => c.id)));
            }}
            className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline font-semibold cursor-pointer"
          >
            Show All Top
          </button>
          <span className="text-slate-300 dark:text-slate-700">•</span>
          <button
            onClick={() => {
              setShowTotalSpend(true);
              setActiveCategoryIds(new Set());
            }}
            className="text-[11px] text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 cursor-pointer"
          >
            Total Only
          </button>
        </div>
      </div>

      {/* ----------------- SVG Line Chart Canvas ----------------- */}
      {monthlyData.length === 0 ? (
        <div className="py-16 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-dashed border-slate-200 dark:border-slate-800">
          <p className="text-xs text-slate-400">
            No transaction records found for the selected timeframe ({timeframe}).
          </p>
        </div>
      ) : (
        <div className="relative w-full overflow-hidden">
          <svg
            viewBox={`0 0 ${svgWidth} ${svgHeight}`}
            className="w-full h-auto select-none overflow-visible"
            style={{ maxHeight: '380px' }}
            onMouseLeave={() => setHoveredMonthIndex(null)}
          >
            <defs>
              {/* Electric Indigo Area Fill Gradient */}
              <linearGradient id="totalSpendGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.28" />
                <stop offset="60%" stopColor="#6366f1" stopOpacity="0.08" />
                <stop offset="100%" stopColor="#818cf8" stopOpacity="0.0" />
              </linearGradient>

              {/* Drop Shadow filter for total line glow */}
              <filter id="lineGlow" x="-20%" y="-20%" width="140%" height="140%">
                <feDropShadow dx="0" dy="2" stdDeviation="3" floodColor="#4f46e5" floodOpacity="0.3" />
              </filter>
            </defs>

            {/* Chart Canvas Content wrapped in margin coordinates */}
            <g transform={`translate(${margin.left}, ${margin.top})`}>
              {/* Horizontal Gridlines & Y-Axis Ticks */}
              {yTicks.map((tickVal) => {
                const yPos = yScale ? yScale(tickVal) : 0;
                return (
                  <g key={tickVal} className="text-slate-400 dark:text-slate-600">
                    <line
                      x1={0}
                      x2={innerWidth}
                      y1={yPos}
                      y2={yPos}
                      stroke="currentColor"
                      strokeDasharray="4 4"
                      strokeOpacity={0.25}
                    />
                    <text
                      x={-12}
                      y={yPos + 4}
                      textAnchor="end"
                      fontSize={11}
                      fontFamily="monospace"
                      className="fill-slate-400 dark:fill-slate-500 font-medium select-none"
                    >
                      {formatYAxisTick(tickVal)}
                    </text>
                  </g>
                );
              })}

              {/* Currency label on Y axis */}
              <text
                x={-12}
                y={-12}
                textAnchor="end"
                fontSize={10}
                className="fill-slate-400 dark:fill-slate-500 font-bold select-none uppercase tracking-wider"
              >
                AED
              </text>

              {/* Area fill under Total Spend */}
              {showTotalSpend && totalAreaPath && (
                <path d={totalAreaPath} fill="url(#totalSpendGradient)" />
              )}

              {/* Category Lines */}
              {categoryPaths.map((cat) => (
                <path
                  key={cat.id}
                  d={cat.path}
                  fill="none"
                  stroke={cat.color}
                  strokeWidth={2.2}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  opacity={0.9}
                />
              ))}

              {/* Total Spend Stroke Line */}
              {showTotalSpend && totalSpendPath && (
                <path
                  d={totalSpendPath}
                  fill="none"
                  stroke={TOTAL_SPEND_COLOR}
                  strokeWidth={3.5}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  filter="url(#lineGlow)"
                />
              )}

              {/* Data Points / Circles on Nodes */}
              {monthlyData.map((m, idx) => {
                const xPos = xScale ? xScale(m.monthKey) || 0 : 0;
                const isHovered = hoveredMonthIndex === idx;

                return (
                  <g key={m.monthKey}>
                    {/* Category node dots */}
                    {categoryPaths.map((cat) => {
                      const pt = cat.points[idx];
                      if (!pt || pt.val === 0) return null;
                      return (
                        <circle
                          key={cat.id}
                          cx={xPos}
                          cy={pt.y}
                          r={isHovered ? 4.5 : 3}
                          fill={cat.color}
                          stroke="#ffffff"
                          strokeWidth={1.5}
                          className="transition-all duration-200"
                        />
                      );
                    })}

                    {/* Total spend node dot */}
                    {showTotalSpend && yScale && (
                      <circle
                        cx={xPos}
                        cy={yScale(m.totalSpendMinor)}
                        r={isHovered ? 6 : 4}
                        fill={TOTAL_SPEND_COLOR}
                        stroke="#ffffff"
                        strokeWidth={2}
                        className="transition-all duration-200"
                      />
                    )}
                  </g>
                );
              })}

              {/* Hover Guideline & Interactive Cursor Tracker */}
              {hoveredMonthIndex !== null && xScale && (
                <g>
                  {/* Vertical dashed crosshair line */}
                  <line
                    x1={xScale(monthlyData[hoveredMonthIndex].monthKey) || 0}
                    x2={xScale(monthlyData[hoveredMonthIndex].monthKey) || 0}
                    y1={0}
                    y2={innerHeight}
                    stroke="#6366f1"
                    strokeWidth={1.5}
                    strokeDasharray="3 3"
                    className="pointer-events-none"
                  />
                </g>
              )}

              {/* X-Axis Month Labels */}
              {monthlyData.map((m, idx) => {
                const xPos = xScale ? xScale(m.monthKey) || 0 : 0;
                const isHovered = hoveredMonthIndex === idx;

                return (
                  <g
                    key={m.monthKey}
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredMonthIndex(idx)}
                  >
                    <text
                      x={xPos}
                      y={innerHeight + 24}
                      textAnchor="middle"
                      fontSize={11}
                      fontWeight={isHovered ? 'bold' : 'normal'}
                      className={`select-none transition-colors ${
                        isHovered
                          ? 'fill-indigo-600 dark:fill-indigo-400 font-bold'
                          : 'fill-slate-500 dark:fill-slate-400'
                      }`}
                    >
                      {m.monthLabel}
                    </text>
                  </g>
                );
              })}

              {/* Transparent hit boxes across columns for smooth cursor hover */}
              {monthlyData.map((m, idx) => {
                const xPos = xScale ? xScale(m.monthKey) || 0 : 0;
                const colWidth = innerWidth / monthlyData.length;
                return (
                  <rect
                    key={`hit-${m.monthKey}`}
                    x={xPos - colWidth / 2}
                    y={0}
                    width={colWidth}
                    height={innerHeight + 30}
                    fill="transparent"
                    className="cursor-pointer"
                    onMouseEnter={() => setHoveredMonthIndex(idx)}
                  />
                );
              })}
            </g>
          </svg>

          {/* Floating Rich Tooltip when hovering over a node */}
          {hoveredMonthData && xScale && (
            <div
              className="absolute z-20 pointer-events-none transition-all duration-150 transform -translate-x-1/2"
              style={{
                left: `${((margin.left + (xScale(hoveredMonthData.monthKey) || 0)) / svgWidth) * 100}%`,
                top: '12px',
              }}
            >
              <div className="bg-slate-900/95 dark:bg-slate-800/95 backdrop-blur-md text-white p-3.5 rounded-xl shadow-xl border border-slate-700 text-xs min-w-[210px] space-y-2">
                {/* Month header & MoM indicator */}
                <div className="flex items-center justify-between border-b border-slate-700/80 pb-2">
                  <div>
                    <span className="font-bold text-slate-100 block">
                      {hoveredMonthData.fullMonthLabel}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {hoveredMonthData.transactionCount} receipt
                      {hoveredMonthData.transactionCount !== 1 ? 's' : ''}
                    </span>
                  </div>
                  {hoveredMonthData.momGrowthPercent !== null && (
                    <span
                      className={`text-[10px] font-mono font-bold px-1.5 py-0.5 rounded flex items-center gap-0.5 ${
                        hoveredMonthData.momGrowthPercent > 0
                          ? 'bg-red-950/80 text-red-300'
                          : hoveredMonthData.momGrowthPercent < 0
                          ? 'bg-emerald-950/80 text-emerald-300'
                          : 'bg-slate-800 text-slate-300'
                      }`}
                    >
                      {hoveredMonthData.momGrowthPercent > 0 ? '+' : ''}
                      {hoveredMonthData.momGrowthPercent}% MoM
                    </span>
                  )}
                </div>

                {/* Total Spend */}
                {showTotalSpend && (
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-300 flex items-center gap-1.5 font-medium">
                      <span
                        className="w-2 h-2 rounded-full"
                        style={{ backgroundColor: TOTAL_SPEND_COLOR }}
                      />
                      Total Spend:
                    </span>
                    <span className="font-mono font-bold text-white">
                      {(hoveredMonthData.totalSpendMinor / 100).toLocaleString('en-US', {
                        minimumFractionDigits: 2,
                      })}{' '}
                      <span className="text-[10px] text-slate-400 font-normal">AED</span>
                    </span>
                  </div>
                )}

                {/* Active Categories Breakdown for this Month */}
                {effectiveActiveCategories.size > 0 && (
                  <div className="pt-1.5 border-t border-slate-800 space-y-1">
                    {Array.from(effectiveActiveCategories).map((catId) => {
                      const catMeta = rankedCategories.find((c) => c.id === catId);
                      const catSpend = hoveredMonthData.categorySpends[catId] || 0;
                      const catPercent =
                        hoveredMonthData.totalSpendMinor > 0
                          ? Math.round((catSpend / hoveredMonthData.totalSpendMinor) * 100)
                          : 0;

                      return (
                        <div
                          key={catId}
                          className="flex items-center justify-between text-[11px]"
                        >
                          <span className="text-slate-300 flex items-center gap-1.5 truncate max-w-[120px]">
                            <span
                              className="w-1.5 h-1.5 rounded-full shrink-0"
                              style={{ backgroundColor: catMeta?.color || '#94a3b8' }}
                            />
                            <span className="truncate">{catMeta?.name || 'Category'}</span>
                          </span>
                          <span className="font-mono text-slate-200 shrink-0">
                            {(catSpend / 100).toFixed(0)} AED{' '}
                            <span className="text-[9px] text-slate-400">({catPercent}%)</span>
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* ----------------- Expandable Month-over-Month Data Table ----------------- */}
      {showDataTable && monthlyData.length > 0 && (
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 animate-in fade-in">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold uppercase text-[10px] tracking-wider">
                  <th className="pb-2.5 font-semibold">Month</th>
                  <th className="pb-2.5 font-semibold text-right">Total Spend</th>
                  <th className="pb-2.5 font-semibold text-right">MoM Growth</th>
                  <th className="pb-2.5 font-semibold text-right">Recoverable VAT</th>
                  <th className="pb-2.5 font-semibold">Highest Category</th>
                  <th className="pb-2.5 font-semibold text-right">Volume</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {monthlyData.map((m) => {
                  return (
                    <tr
                      key={m.monthKey}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition"
                    >
                      <td className="py-2.5 font-semibold text-slate-900 dark:text-white">
                        {m.fullMonthLabel}
                      </td>
                      <td className="py-2.5 text-right font-mono font-bold text-slate-900 dark:text-white">
                        {(m.totalSpendMinor / 100).toLocaleString('en-US', {
                          minimumFractionDigits: 2,
                        })}{' '}
                        AED
                      </td>
                      <td className="py-2.5 text-right font-mono">
                        {m.momGrowthPercent !== null ? (
                          <span
                            className={`inline-flex items-center gap-0.5 font-bold ${
                              m.momGrowthPercent > 0
                                ? 'text-red-600 dark:text-red-400'
                                : m.momGrowthPercent < 0
                                ? 'text-emerald-600 dark:text-emerald-400'
                                : 'text-slate-400'
                            }`}
                          >
                            {m.momGrowthPercent > 0 ? (
                              <ArrowUpRight className="w-3 h-3 text-red-500" />
                            ) : m.momGrowthPercent < 0 ? (
                              <ArrowDownRight className="w-3 h-3 text-emerald-500" />
                            ) : null}
                            {m.momGrowthPercent > 0 ? '+' : ''}
                            {m.momGrowthPercent}%
                          </span>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </td>
                      <td className="py-2.5 text-right font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        {(m.totalVatMinor / 100).toFixed(2)} AED
                      </td>
                      <td className="py-2.5 text-slate-600 dark:text-slate-300">
                        {m.topCategoryName ? (
                          <span className="inline-flex items-center gap-1.5">
                            <span className="font-medium">{m.topCategoryName}</span>
                            <span className="text-[10px] font-mono text-slate-400">
                              ({((m.topCategorySpendMinor || 0) / 100).toFixed(0)} AED)
                            </span>
                          </span>
                        ) : (
                          <span className="text-slate-400 italic">None</span>
                        )}
                      </td>
                      <td className="py-2.5 text-right font-mono text-slate-500">
                        {m.transactionCount}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ----------------- Contextual Guidance ----------------- */}
      <div className="pt-2 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-800/80">
        <span className="flex items-center gap-1.5">
          <Calendar className="w-3.5 h-3.5 text-indigo-500" />
          <span>
            Aggregated by invoice date. Missing dates default to receipt capture timestamp.
          </span>
        </span>
        <span className="font-medium text-slate-500">
          Showing {rankedCategories.length} tracked categories · Currency: AED
        </span>
      </div>
    </div>
  );
};
