import React, { useState } from 'react';
import { X, Split, Plus, Trash2, CheckCircle2, AlertCircle } from 'lucide-react';
import { Receipt, Category } from '../types';

interface LineItemSplitModalProps {
  receipt: Receipt;
  categories: Category[];
  onClose: () => void;
  onSaveSplit: (splits: Array<{ categoryId: string; categoryName: string; amountMinor: number; lineItemIds: string[] }>) => Promise<void>;
}

export const LineItemSplitModal: React.FC<LineItemSplitModalProps> = ({
  receipt,
  categories,
  onClose,
  onSaveSplit,
}) => {
  const activeCats = categories.filter((c) => c.active);

  // Initialize with two splits
  const [splits, setSplits] = useState<Array<{
    categoryId: string;
    amount: string;
    description: string;
  }>>([
    {
      categoryId: receipt.categoryId || activeCats[0]?.id || '',
      amount: ((receipt.totalMinor * 0.7) / 100).toFixed(2),
      description: 'Primary Category (e.g. Accommodation)',
    },
    {
      categoryId: activeCats.find((c) => c.name === 'Meals and Entertainment')?.id || activeCats[1]?.id || '',
      amount: ((receipt.totalMinor * 0.3) / 100).toFixed(2),
      description: 'Secondary Category (e.g. Meals)',
    },
  ]);

  const [saving, setSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const totalSplitMinor = splits.reduce((acc, s) => acc + Math.round((parseFloat(s.amount) || 0) * 100), 0);
  const remainingMinor = receipt.totalMinor - totalSplitMinor;
  const isReconciled = Math.abs(remainingMinor) <= 1;

  const handleAddSplit = () => {
    setSplits([
      ...splits,
      {
        categoryId: activeCats[0]?.id || '',
        amount: (Math.max(0, remainingMinor) / 100).toFixed(2),
        description: '',
      },
    ]);
  };

  const handleRemoveSplit = (idx: number) => {
    if (splits.length <= 2) return;
    setSplits(splits.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!isReconciled) {
      setErrorMsg(`Splits must reconcile exactly to the total invoice amount of ${(receipt.totalMinor / 100).toFixed(2)} AED.`);
      return;
    }
    setSaving(true);
    try {
      const payload = splits.map((s) => {
        const cat = activeCats.find((c) => c.id === s.categoryId);
        return {
          categoryId: s.categoryId,
          categoryName: cat?.name || 'Uncategorised',
          amountMinor: Math.round(parseFloat(s.amount) * 100),
          lineItemIds: [],
        };
      });
      await onSaveSplit(payload);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to apply category split');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
      <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600">
              <Split className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Split Mixed Receipt Categories
              </h3>
              <p className="text-xs text-slate-500">
                Allocate multi-category invoices (e.g. Hotel with meals and room)
              </p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Invoice Summary Card */}
        <div className="my-4 p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs">
          <div>
            <span className="text-slate-500 block">Invoice Total</span>
            <span className="text-sm font-bold text-slate-900 dark:text-white">
              {(receipt.totalMinor / 100).toFixed(2)} {receipt.currency}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">Allocated</span>
            <span className={`text-sm font-bold ${isReconciled ? 'text-emerald-600' : 'text-amber-600'}`}>
              {(totalSplitMinor / 100).toFixed(2)} {receipt.currency}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block">Unallocated / Delta</span>
            <span className={`text-sm font-bold ${isReconciled ? 'text-emerald-600' : 'text-red-600'}`}>
              {(remainingMinor / 100).toFixed(2)} {receipt.currency}
            </span>
          </div>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900/40 text-xs text-red-700 dark:text-red-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Splits List */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-1">
          {splits.map((split, idx) => (
            <div key={idx} className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 space-y-2">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-600 dark:text-slate-400">
                <span>Split Item #{idx + 1}</span>
                {splits.length > 2 && (
                  <button
                    onClick={() => handleRemoveSplit(idx)}
                    className="text-red-500 hover:text-red-700 p-1"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <div>
                  <label className="text-[11px] font-medium text-slate-500 block mb-1">Target Category</label>
                  <select
                    value={split.categoryId}
                    onChange={(e) => {
                      const newSplits = [...splits];
                      newSplits[idx].categoryId = e.target.value;
                      setSplits(newSplits);
                    }}
                    className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white"
                  >
                    {activeCats.map((cat) => (
                      <option key={cat.id} value={cat.id}>
                        {cat.name} (GL: {cat.glCode})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="text-[11px] font-medium text-slate-500 block mb-1">Amount ({receipt.currency})</label>
                  <input
                    type="number"
                    step="0.01"
                    value={split.amount}
                    onChange={(e) => {
                      const newSplits = [...splits];
                      newSplits[idx].amount = e.target.value;
                      setSplits(newSplits);
                    }}
                    className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2 text-slate-900 dark:text-white font-mono"
                  />
                </div>
              </div>
            </div>
          ))}

          <button
            onClick={handleAddSplit}
            className="w-full py-2.5 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-800 hover:border-sky-500 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:text-sky-600 flex items-center justify-center gap-2 transition"
          >
            <Plus className="w-4 h-4" />
            Add Another Category Split
          </button>
        </div>

        {/* Footer actions */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3 mt-4">
          <div className="text-xs">
            {isReconciled ? (
              <span className="flex items-center gap-1.5 text-emerald-600 font-semibold">
                <CheckCircle2 className="w-4 h-4" />
                Totals Reconciled
              </span>
            ) : (
              <span className="text-amber-600 font-semibold">
                Delta: {(Math.abs(remainingMinor) / 100).toFixed(2)} {receipt.currency}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              disabled={!isReconciled || saving}
              className="px-5 py-2 rounded-xl text-xs font-bold bg-sky-600 text-white hover:bg-sky-700 disabled:opacity-40 disabled:cursor-not-allowed shadow-sm transition"
            >
              {saving ? 'Saving...' : 'Apply Split'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
