import React, { useState, useEffect } from 'react';
import {
  AlertOctagon,
  Mail,
  ShieldAlert,
  Bell,
  CheckCircle2,
  AlertTriangle,
  Sliders,
  DollarSign,
  TrendingUp,
  RefreshCw,
  Send,
  Trash2,
  Check,
  Search,
  Filter,
  Sparkles,
  Layers,
  ArrowRight,
  ChevronRight,
  ExternalLink,
  Copy,
} from 'lucide-react';
import { Category, Receipt, RedFlagEmailAlert } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface BudgetAlertsProps {
  categories: Category[];
  receipts: Receipt[];
  onCategoriesUpdated: (categories: Category[], taxonomyVersion: number) => void;
  onNavigateToCapture?: () => void;
}

export const BudgetAlerts: React.FC<BudgetAlertsProps> = ({
  categories,
  receipts,
  onCategoriesUpdated,
  onNavigateToCapture,
}) => {
  const { user } = useAuth();
  const isAdmin = user?.role === 'Admin' || user?.role === 'Reviewer';

  // Alerts state
  const [alerts, setAlerts] = useState<RedFlagEmailAlert[]>([]);
  const [loadingAlerts, setLoadingAlerts] = useState(false);
  const [selectedAlertForModal, setSelectedAlertForModal] = useState<RedFlagEmailAlert | null>(null);

  // Search & Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'breached' | 'healthy' | 'no_limit'>('all');
  const [alertFilter, setAlertFilter] = useState<'all' | 'unacknowledged' | 'acknowledged'>('all');

  // Inline editing of spend limit
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [limitInputValue, setLimitInputValue] = useState<string>('');
  const [savingLimit, setSavingLimit] = useState(false);

  // Notification / Test email trigger state
  const [triggeringCheck, setTriggeringCheck] = useState(false);
  const [actionSuccessMessage, setActionSuccessMessage] = useState<string | null>(null);
  const [copiedEmail, setCopiedEmail] = useState(false);

  // Current calendar month string (YYYY-MM)
  const currentMonth = new Date().toISOString().substring(0, 7);
  const currentMonthLabel = new Date().toLocaleString('default', { month: 'long', year: 'numeric' });

  // Load email alerts from server
  const loadAlerts = async () => {
    setLoadingAlerts(true);
    try {
      const res = await api.getEmailAlerts();
      setAlerts(res.alerts || []);
    } catch (err) {
      console.error('Failed to load email alerts:', err);
    } finally {
      setLoadingAlerts(false);
    }
  };

  useEffect(() => {
    loadAlerts();
  }, []);

  // Compute monthly spend per category
  const categorySpendMap = new Map<string, number>();
  receipts
    .filter((r) => r.status !== 'rejected' && (r.invoiceDate || r.uploadedAt || '').substring(0, 7) === currentMonth)
    .forEach((r) => {
      const catId = r.categoryId || 'uncat';
      const cur = categorySpendMap.get(catId) || 0;
      categorySpendMap.set(catId, cur + (r.totalAedMinor || 0));
    });

  // Calculate statistics
  const activeCategories = categories.filter((c) => c.active);
  const categoriesWithLimits = activeCategories.filter((c) => c.spendLimitMinor && c.spendLimitMinor > 0);
  const breachedCategories = activeCategories.filter((c) => {
    if (!c.spendLimitMinor) return false;
    const spend = categorySpendMap.get(c.id) || 0;
    return spend > c.spendLimitMinor;
  });

  // Inline spend limit save handler
  const handleSaveLimit = async (category: Category) => {
    setSavingLimit(true);
    try {
      const parsedAed = parseFloat(limitInputValue);
      const spendLimitMinor = !isNaN(parsedAed) && parsedAed > 0 ? Math.round(parsedAed * 100) : undefined;
      const res = await api.updateCategoryLimit(category.id, spendLimitMinor);

      // Update parent categories state
      const updatedList = categories.map((c) => (c.id === category.id ? res.category : c));
      onCategoriesUpdated(updatedList, category.version);

      if (res.triggeredAlert) {
        setAlerts((prev) => [res.triggeredAlert!, ...prev]);
        setActionSuccessMessage(`Spend limit updated to ${parsedAed} AED. Current spend exceeded limit: Red Flag alert email dispatched!`);
      } else {
        setActionSuccessMessage(`Spend limit for "${category.name}" updated to ${spendLimitMinor ? (spendLimitMinor / 100).toFixed(2) + ' AED' : 'No Limit'}.`);
      }
      setTimeout(() => setActionSuccessMessage(null), 5000);
      setEditingCategoryId(null);
    } catch (err: any) {
      alert(`Failed to update spend limit: ${err.message}`);
    } finally {
      setSavingLimit(false);
    }
  };

  // Run automated breach check across all categories
  const handleTriggerBreachCheck = async () => {
    setTriggeringCheck(true);
    try {
      const res = await api.triggerAlertCheck({ targetEmail: user?.email });
      loadAlerts();
      if (res.alertsTriggered > 0) {
        setActionSuccessMessage(`Breach check complete: ${res.alertsTriggered} Red Flag email alert(s) dispatched to ${user?.email || 'registered address'}.`);
      } else {
        setActionSuccessMessage(`Audit complete: All active categories with limits are currently within budget.`);
      }
      setTimeout(() => setActionSuccessMessage(null), 6000);
    } catch (err: any) {
      alert(`Audit check error: ${err.message}`);
    } finally {
      setTriggeringCheck(false);
    }
  };

  // Send a test email notification for a specific category
  const handleSendTestNotification = async (category: Category) => {
    try {
      const res = await api.triggerAlertCheck({
        categoryId: category.id,
        targetEmail: user?.email,
        forceSimulate: true,
      });
      loadAlerts();
      setActionSuccessMessage(`Simulated Red Flag Alert email dispatched to ${user?.email} for "${category.name}".`);
      setTimeout(() => setActionSuccessMessage(null), 5000);
    } catch (err: any) {
      alert(`Test notification error: ${err.message}`);
    }
  };

  // Acknowledge an alert
  const handleAcknowledgeAlert = async (alertId: string) => {
    try {
      const res = await api.acknowledgeAlert(alertId);
      setAlerts((prev) => prev.map((a) => (a.id === alertId ? res.alert : a)));
      setActionSuccessMessage('Alert acknowledged by reviewer.');
      setTimeout(() => setActionSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(`Failed to acknowledge alert: ${err.message}`);
    }
  };

  // Delete an alert
  const handleDeleteAlert = async (alertId: string) => {
    try {
      await api.deleteAlert(alertId);
      setAlerts((prev) => prev.filter((a) => a.id !== alertId));
      if (selectedAlertForModal?.id === alertId) setSelectedAlertForModal(null);
      setActionSuccessMessage('Alert cleared from log.');
      setTimeout(() => setActionSuccessMessage(null), 3000);
    } catch (err: any) {
      alert(`Failed to delete alert: ${err.message}`);
    }
  };

  // Filter categories
  const filteredCategories = activeCategories.filter((cat) => {
    const matchesSearch = cat.name.toLowerCase().includes(searchQuery.toLowerCase()) || cat.glCode.includes(searchQuery);
    if (!matchesSearch) return false;

    const spend = categorySpendMap.get(cat.id) || 0;
    const hasLimit = typeof cat.spendLimitMinor === 'number' && cat.spendLimitMinor > 0;
    const isBreached = hasLimit && spend > (cat.spendLimitMinor || 0);

    if (filterStatus === 'breached') return isBreached;
    if (filterStatus === 'healthy') return hasLimit && !isBreached;
    if (filterStatus === 'no_limit') return !hasLimit;
    return true;
  });

  // Filter alerts
  const filteredAlerts = alerts.filter((alert) => {
    if (alertFilter === 'acknowledged') return !!alert.acknowledged;
    if (alertFilter === 'unacknowledged') return !alert.acknowledged;
    return true;
  });

  return (
    <div className="space-y-6 animate-in fade-in max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-red-50 dark:bg-red-950/60 text-red-600 border border-red-200 dark:border-red-900/60">
              <AlertOctagon className="w-5 h-5" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                Category Budget Sentinel & Email Alerts
              </h2>
              <p className="text-xs text-slate-500">
                Monitors spend limits across all categories and triggers automated Red Flag email notifications when thresholds are breached ({currentMonthLabel})
              </p>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
          <button
            onClick={handleTriggerBreachCheck}
            disabled={triggeringCheck}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition shadow-xs cursor-pointer disabled:opacity-50"
            title="Evaluate all current month expenses against category limits and dispatch alerts"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${triggeringCheck ? 'animate-spin' : ''}`} />
            <span>{triggeringCheck ? 'Auditing...' : 'Run Breach Audit & Dispatch'}</span>
          </button>
        </div>
      </div>

      {/* Action Notification Toast Banner */}
      {actionSuccessMessage && (
        <div className="p-3.5 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/50 dark:to-teal-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center justify-between gap-2 shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>{actionSuccessMessage}</span>
          </div>
          <button
            onClick={() => setActionSuccessMessage(null)}
            className="text-emerald-600 hover:text-emerald-800 dark:hover:text-emerald-300 font-bold px-2 py-0.5 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Monitored Categories */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Active Categories
          </span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {activeCategories.length}
          </span>
          <div className="mt-1.5 text-[11px] text-slate-400">
            {categoriesWithLimits.length} with spend limits configured
          </div>
        </div>

        {/* Categories Breached */}
        <div className={`p-4 rounded-2xl border shadow-xs ${
          breachedCategories.length > 0
            ? 'bg-red-50/50 dark:bg-red-950/30 border-red-200 dark:border-red-900/60'
            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
        }`}>
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Budget Breaches ({currentMonthLabel})
          </span>
          <div className="flex items-baseline gap-2">
            <span className={`text-2xl font-bold font-mono ${
              breachedCategories.length > 0 ? 'text-red-600 dark:text-red-400' : 'text-emerald-600'
            }`}>
              {breachedCategories.length}
            </span>
            {breachedCategories.length > 0 && (
              <span className="text-[10px] font-bold px-1.5 py-0.2 rounded-full bg-red-600 text-white animate-pulse">
                RED FLAG ACTIVE
              </span>
            )}
          </div>
          <div className="mt-1.5 text-[11px] text-slate-400">
            {breachedCategories.length === 0 ? 'All categories in compliance' : `${breachedCategories.map((c) => c.name).join(', ')}`}
          </div>
        </div>

        {/* Dispatched Email Notifications */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Dispatched Email Alerts
          </span>
          <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white flex items-center gap-1.5">
            <Mail className="w-5 h-5 text-red-500 inline" />
            <span>{alerts.length}</span>
          </span>
          <div className="mt-1.5 text-[11px] text-slate-400">
            {alerts.filter((a) => !a.acknowledged).length} pending finance acknowledgment
          </div>
        </div>

        {/* Automated Trigger Policy */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Automated Enforcement
          </span>
          <span className="text-sm font-bold text-emerald-600 flex items-center gap-1 mt-1">
            <CheckCircle2 className="w-4 h-4" /> Live Rule 10 Active
          </span>
          <p className="mt-1.5 text-[10px] text-slate-400 leading-tight">
            Triggers email notifications immediately on receipt processing, review correction, or limit update.
          </p>
        </div>
      </div>

      {/* Main Grid: Category Budget Limit Monitors (Left 7 cols) & Dispatched Emails (Right 5 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* ========================================================== */}
        {/* LEFT: CATEGORY SPEND LIMITS & BUDGET UTILIZATION PROGRESS  */}
        {/* ========================================================== */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Sliders className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>Category Spend Limits ({currentMonthLabel})</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Configure monthly limits per category. Expenses breaching these thresholds dispatch automated Red Flag emails.
              </p>
            </div>

            {/* Filter buttons */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-[11px] font-semibold self-start sm:self-auto">
              <button
                onClick={() => setFilterStatus('all')}
                className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                  filterStatus === 'all'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                All ({activeCategories.length})
              </button>
              <button
                onClick={() => setFilterStatus('breached')}
                className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                  filterStatus === 'breached'
                    ? 'bg-red-600 text-white shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Breached ({breachedCategories.length})
              </button>
              <button
                onClick={() => setFilterStatus('healthy')}
                className={`px-2.5 py-1 rounded-lg transition cursor-pointer ${
                  filterStatus === 'healthy'
                    ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400'
                }`}
              >
                Within Budget
              </button>
            </div>
          </div>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search category name or GL code..."
              className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 text-slate-900 dark:text-white"
            />
          </div>

          {/* Categories List */}
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
            {filteredCategories.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 italic">
                No categories match the selected filter.
              </div>
            ) : (
              filteredCategories.map((cat) => {
                const spendMinor = categorySpendMap.get(cat.id) || 0;
                const hasLimit = typeof cat.spendLimitMinor === 'number' && cat.spendLimitMinor > 0;
                const limitMinor = cat.spendLimitMinor || 0;
                const percent = hasLimit ? Math.round((spendMinor / limitMinor) * 100) : 0;
                const isBreached = hasLimit && spendMinor > limitMinor;
                const isEditing = editingCategoryId === cat.id;

                return (
                  <div
                    key={cat.id}
                    className={`p-3.5 rounded-xl border transition ${
                      isBreached
                        ? 'border-red-300 dark:border-red-900 bg-red-50/40 dark:bg-red-950/20 shadow-xs'
                        : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/60 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        {isBreached ? (
                          <span className="p-1 rounded bg-red-100 dark:bg-red-900/60 text-red-600">
                            <AlertOctagon className="w-3.5 h-3.5" />
                          </span>
                        ) : (
                          <span className="p-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                            <Layers className="w-3.5 h-3.5" />
                          </span>
                        )}
                        <div>
                          <span className="font-bold text-xs text-slate-900 dark:text-white">
                            {cat.name}
                          </span>
                          <span className="ml-2 font-mono text-[10px] text-slate-400">
                            GL {cat.glCode}
                          </span>
                        </div>
                      </div>

                      {/* Right Status Badge */}
                      <div className="flex items-center gap-1.5 self-start sm:self-auto">
                        {isBreached ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-600 text-white flex items-center gap-1">
                            <span>🚨 Breached (+{((spendMinor - limitMinor) / 100).toFixed(0)} AED)</span>
                          </span>
                        ) : hasLimit ? (
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              percent > 80
                                ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                                : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                            }`}
                          >
                            {percent}% of limit
                          </span>
                        ) : (
                          <span className="text-[10px] text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full">
                            No limit set
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Spend vs Limit figures */}
                    <div className="flex items-baseline justify-between text-xs mb-2">
                      <span className="text-slate-600 dark:text-slate-400 text-[11px]">
                        Spend this month:{' '}
                        <strong className="text-slate-900 dark:text-white font-mono">
                          {(spendMinor / 100).toFixed(2)} AED
                        </strong>
                      </span>

                      <span className="text-slate-600 dark:text-slate-400 text-[11px]">
                        Monthly Limit:{' '}
                        <strong className="text-slate-900 dark:text-white font-mono">
                          {hasLimit ? `${(limitMinor / 100).toFixed(2)} AED` : 'None'}
                        </strong>
                      </span>
                    </div>

                    {/* Progress Bar */}
                    {hasLimit && (
                      <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden mb-2">
                        <div
                          className={`h-2 rounded-full transition-all duration-500 ${
                            isBreached
                              ? 'bg-red-600'
                              : percent > 80
                              ? 'bg-amber-500'
                              : 'bg-gradient-to-r from-indigo-600 to-violet-600'
                          }`}
                          style={{ width: `${Math.min(100, Math.max(3, percent))}%` }}
                        />
                      </div>
                    )}

                    {/* Inline Editor & Quick Trigger Bar */}
                    <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                      {isEditing ? (
                        <div className="flex items-center gap-2 w-full sm:w-auto">
                          <input
                            type="number"
                            value={limitInputValue}
                            onChange={(e) => setLimitInputValue(e.target.value)}
                            placeholder="Limit in AED (e.g. 1500)"
                            className="w-36 px-2.5 py-1 text-xs font-mono rounded-lg border border-indigo-400 dark:border-indigo-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                            autoFocus
                          />
                          <button
                            onClick={() => handleSaveLimit(cat)}
                            disabled={savingLimit}
                            className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-[11px] cursor-pointer shadow-xs"
                          >
                            {savingLimit ? 'Saving...' : 'Save Limit'}
                          </button>
                          <button
                            onClick={() => setEditingCategoryId(null)}
                            className="px-2 py-1 text-slate-400 hover:text-slate-600 text-[11px] cursor-pointer"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="flex items-center gap-3">
                          {isAdmin && (
                            <button
                              onClick={() => {
                                setEditingCategoryId(cat.id);
                                setLimitInputValue(cat.spendLimitMinor ? (cat.spendLimitMinor / 100).toString() : '');
                              }}
                              className="text-[11px] text-sky-600 hover:underline font-semibold inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Sliders className="w-3 h-3" />
                              <span>{hasLimit ? 'Edit Limit' : '+ Set Spend Limit'}</span>
                            </button>
                          )}

                          {/* Quick test notification trigger */}
                          <button
                            onClick={() => handleSendTestNotification(cat)}
                            className="text-[11px] text-slate-500 hover:text-red-600 inline-flex items-center gap-1 transition cursor-pointer"
                            title="Dispatch simulated Red Flag email for this category to test alerts"
                          >
                            <Mail className="w-3 h-3 text-red-500" />
                            <span>Test Email Alert</span>
                          </button>
                        </div>
                      )}

                      {/* Over-budget indicator label */}
                      {isBreached && (
                        <span className="text-[10px] text-red-700 dark:text-red-400 font-bold font-mono">
                          🚨 Over Limit by +{((spendMinor - limitMinor) / 100).toFixed(2)} AED
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* ========================================================== */}
        {/* RIGHT: DISPATCHED RED FLAG EMAIL NOTIFICATIONS LOG         */}
        {/* ========================================================== */}
        <div className="lg:col-span-5 bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Mail className="w-4 h-4 text-red-600" />
                <span>Dispatched Email Alerts ({alerts.length})</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Official Red Flag notices dispatched to users & finance team
              </p>
            </div>

            <button
              onClick={loadAlerts}
              className="text-xs text-slate-400 hover:text-sky-600 cursor-pointer"
              title="Refresh alerts"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Filter sub-tabs */}
          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl text-[11px] font-semibold">
            <button
              onClick={() => setAlertFilter('all')}
              className={`flex-1 py-1 rounded-lg text-center transition cursor-pointer ${
                alertFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs font-bold'
                  : 'text-slate-500'
              }`}
            >
              All ({alerts.length})
            </button>
            <button
              onClick={() => setAlertFilter('unacknowledged')}
              className={`flex-1 py-1 rounded-lg text-center transition cursor-pointer ${
                alertFilter === 'unacknowledged'
                  ? 'bg-red-600 text-white shadow-xs font-bold'
                  : 'text-slate-500'
              }`}
            >
              Pending ({alerts.filter((a) => !a.acknowledged).length})
            </button>
            <button
              onClick={() => setAlertFilter('acknowledged')}
              className={`flex-1 py-1 rounded-lg text-center transition cursor-pointer ${
                alertFilter === 'acknowledged'
                  ? 'bg-white dark:bg-slate-900 text-emerald-600 shadow-xs font-bold'
                  : 'text-slate-500'
              }`}
            >
              Reviewed ({alerts.filter((a) => a.acknowledged).length})
            </button>
          </div>

          {/* Alerts Feed */}
          {loadingAlerts ? (
            <div className="py-12 flex justify-center">
              <div className="w-6 h-6 border-2 border-red-600 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : filteredAlerts.length === 0 ? (
            <div className="p-8 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-400 space-y-2">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
              <p className="font-semibold text-slate-600 dark:text-slate-300">No email alerts found</p>
              <p className="text-[11px]">
                When an expense causes any category to exceed its spend limit, the automated Red Flag notice will appear here with delivery details.
              </p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[560px] overflow-y-auto pr-1">
              {filteredAlerts.map((alert) => (
                <div
                  key={alert.id}
                  className={`p-3.5 rounded-xl border text-xs space-y-2 transition ${
                    alert.acknowledged
                      ? 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 opacity-75'
                      : 'border-red-200 dark:border-red-900/70 bg-red-50/30 dark:bg-red-950/20 shadow-xs'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="font-bold text-red-800 dark:text-red-300 line-clamp-1 block">
                        {alert.subject}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono block mt-0.5">
                        To: {alert.recipientName} ({alert.recipientEmail})
                      </span>
                    </div>

                    <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded-full bg-red-600 text-white shrink-0">
                      +{(alert.breachAmountMinor / 100).toFixed(0)} AED
                    </span>
                  </div>

                  {/* Summary metric box */}
                  <div className="grid grid-cols-2 gap-2 p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/60 dark:border-slate-800 font-mono text-[11px]">
                    <div>
                      <span className="text-slate-400 block text-[9px] uppercase font-sans">Category Limit</span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {(alert.spendLimitMinor / 100).toFixed(2)} AED
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[9px] uppercase font-sans">Total Spend</span>
                      <span className="font-bold text-red-600">
                        {(alert.currentSpendMinor / 100).toFixed(2)} AED
                      </span>
                    </div>
                  </div>

                  {/* Footer & Actions */}
                  <div className="flex items-center justify-between pt-1 text-[11px]">
                    <span className="text-slate-400 text-[10px]">
                      {new Date(alert.triggeredAt).toLocaleString()}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedAlertForModal(alert)}
                        className="text-sky-600 hover:underline font-bold inline-flex items-center gap-0.5 cursor-pointer"
                      >
                        <ExternalLink className="w-3 h-3" /> View Email
                      </button>

                      {!alert.acknowledged && (
                        <button
                          onClick={() => handleAcknowledgeAlert(alert.id)}
                          className="text-emerald-600 hover:text-emerald-700 font-bold inline-flex items-center gap-0.5 cursor-pointer ml-1"
                          title="Mark as reviewed by finance"
                        >
                          <Check className="w-3 h-3" /> Review
                        </button>
                      )}

                      {isAdmin && (
                        <button
                          onClick={() => handleDeleteAlert(alert.id)}
                          className="text-slate-400 hover:text-red-600 p-0.5 cursor-pointer"
                          title="Dismiss alert"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ========================================================== */}
      {/* MODAL: PIXEL-PERFECT CORPORATE RED FLAG EMAIL VIEWER       */}
      {/* ========================================================== */}
      {selectedAlertForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-xl rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-red-200 dark:border-red-900 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <AlertOctagon className="w-5 h-5" />
                <h3 className="text-base font-bold">Dispatched Red Flag Email Notification</h3>
              </div>
              <button
                onClick={() => setSelectedAlertForModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Email Metadata */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 font-mono">
              <div className="flex">
                <span className="w-20 text-slate-400 font-sans">From:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  Budget Sentinel &lt;budget-alerts@expensecapture.ae&gt;
                </span>
              </div>
              <div className="flex">
                <span className="w-20 text-slate-400 font-sans">To:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {selectedAlertForModal.recipientName} &lt;{selectedAlertForModal.recipientEmail}&gt;
                </span>
              </div>
              <div className="flex">
                <span className="w-20 text-slate-400 font-sans">Subject:</span>
                <strong className="text-red-700 dark:text-red-400">
                  {selectedAlertForModal.subject}
                </strong>
              </div>
              <div className="flex">
                <span className="w-20 text-slate-400 font-sans">Date:</span>
                <span className="text-slate-600 dark:text-slate-300">
                  {new Date(selectedAlertForModal.triggeredAt).toLocaleString()}
                </span>
              </div>
              <div className="flex">
                <span className="w-20 text-slate-400 font-sans">Status:</span>
                <span className="text-emerald-600 font-bold uppercase">
                  ✓ {selectedAlertForModal.status} (Automated Dispatch Engine)
                </span>
              </div>
            </div>

            {/* Email Body Content */}
            <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/90 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-mono leading-relaxed border border-slate-200 dark:border-slate-700 max-h-72 overflow-y-auto">
              {selectedAlertForModal.body}
            </div>

            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(selectedAlertForModal.body);
                  setCopiedEmail(true);
                  setTimeout(() => setCopiedEmail(false), 2000);
                }}
                className="px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 inline-flex items-center gap-1.5 cursor-pointer"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>{copiedEmail ? 'Copied!' : 'Copy Email Body'}</span>
              </button>

              <div className="flex items-center gap-2">
                {!selectedAlertForModal.acknowledged && (
                  <button
                    onClick={() => {
                      handleAcknowledgeAlert(selectedAlertForModal.id);
                      setSelectedAlertForModal(null);
                    }}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold cursor-pointer inline-flex items-center gap-1"
                  >
                    <Check className="w-3.5 h-3.5" /> Acknowledge Alert
                  </button>
                )}
                <button
                  onClick={() => setSelectedAlertForModal(null)}
                  className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-xs font-bold cursor-pointer"
                >
                  Close Notice
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
