import React, { useState, useEffect } from 'react';
import { WifiOff, CloudUpload } from 'lucide-react';
import { getOfflineQueue } from '../services/offlineQueue';
import { useLanguage } from '../context/LanguageContext';

export const OfflineIndicator: React.FC<{ onSyncNeeded?: () => void }> = ({ onSyncNeeded }) => {
  const [isOnline, setIsOnline] = useState(typeof navigator !== 'undefined' ? navigator.onLine : true);
  const [queueCount, setQueueCount] = useState(0);
  const { t } = useLanguage();

  useEffect(() => {
    const updateStatus = () => {
      const online = navigator.onLine;
      setIsOnline(online);
      const queue = getOfflineQueue();
      setQueueCount(queue.length);
      if (online && queue.length > 0 && onSyncNeeded) {
        onSyncNeeded();
      }
    };

    window.addEventListener('online', updateStatus);
    window.addEventListener('offline', updateStatus);
    updateStatus();

    const interval = setInterval(updateStatus, 3000);

    return () => {
      window.removeEventListener('online', updateStatus);
      window.removeEventListener('offline', updateStatus);
      clearInterval(interval);
    };
  }, [onSyncNeeded]);

  if (isOnline && queueCount === 0) return null;

  return (
    <aside aria-label="Network Status" className="fixed bottom-4 left-4 z-50 flex items-center gap-2.5 rounded-xl bg-slate-900/90 text-white px-3.5 py-2 text-xs font-semibold shadow-xl backdrop-blur-md border border-slate-700/50 animate-in fade-in slide-in-from-bottom-2">
      {!isOnline ? (
        <>
          <div className="relative flex items-center justify-center">
            <span className="absolute h-3 w-3 rounded-full bg-amber-400 opacity-75 animate-ping" />
            <WifiOff className="w-4 h-4 text-amber-400 relative" />
          </div>
          <span>{t('offlineBanner')}</span>
          {queueCount > 0 && (
            <span className="bg-amber-500/20 text-amber-300 px-1.5 py-0.5 rounded text-[10px] font-bold">
              {queueCount} stored
            </span>
          )}
        </>
      ) : queueCount > 0 ? (
        <>
          <CloudUpload className="w-4 h-4 text-sky-400 animate-bounce" />
          <span>Syncing {queueCount} offline receipt(s)...</span>
        </>
      ) : null}
    </aside>
  );
};
