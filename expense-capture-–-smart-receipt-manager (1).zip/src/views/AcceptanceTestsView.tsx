import React, { useState } from 'react';
import {
  FlaskConical,
  Play,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  FileCode,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { api } from '../services/api';

export const AcceptanceTestsView: React.FC = () => {
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [allPassed, setAllPassed] = useState<boolean | null>(null);
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const runAllTests = async () => {
    setRunning(true);
    try {
      const res = await api.runTestSuite();
      setResults(res.results);
      setAllPassed(res.allPassed);
    } catch (err: any) {
      alert(`Test runner error: ${err.message}`);
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <FlaskConical className="w-5 h-5 text-sky-600" />
            <span>Statutory & Acceptance Test Suite</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Automated verification of all 12 mandatory product acceptance criteria
          </p>
        </div>

        <button
          onClick={runAllTests}
          disabled={running}
          className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs shadow-md shadow-sky-600/20 transition active:scale-95 disabled:opacity-50 cursor-pointer"
        >
          {running ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Executing Test Suite...</span>
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              <span>Run All 12 Acceptance Tests</span>
            </>
          )}
        </button>
      </div>

      {/* Overview Banner */}
      {allPassed !== null && (
        <div
          className={`p-4 rounded-2xl border text-xs flex items-center justify-between ${
            allPassed
              ? 'bg-emerald-50 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
              : 'bg-red-50 dark:bg-red-950/30 border-red-200 dark:border-red-800 text-red-900 dark:text-red-200'
          }`}
        >
          <div className="flex items-center gap-3">
            {allPassed ? (
              <CheckCircle2 className="w-6 h-6 text-emerald-600 shrink-0" />
            ) : (
              <XCircle className="w-6 h-6 text-red-600 shrink-0" />
            )}
            <div>
              <span className="font-bold text-sm block">
                {allPassed ? 'All 12 Acceptance Tests Passed Successfully!' : 'Some Acceptance Tests Failed'}
              </span>
              <span className="text-[11px] opacity-80">
                {results.filter((r) => r.passed).length} of {results.length} tests verified with empirical proof.
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Tests List */}
      <div className="space-y-3">
        {results.length > 0 ? (
          results.map((test) => {
            const isExpanded = expandedId === test.id;
            return (
              <div
                key={test.id}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xs overflow-hidden"
              >
                <div
                  onClick={() => setExpandedId(isExpanded ? null : test.id)}
                  className="p-4 flex items-center justify-between cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/40 transition"
                >
                  <div className="flex items-start gap-3">
                    {test.passed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-600 mt-0.5 shrink-0" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600 mt-0.5 shrink-0" />
                    )}
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs sm:text-sm text-slate-900 dark:text-white">
                          #{test.id}: {test.title}
                        </span>
                        <span
                          className={`text-[10px] font-bold px-2 py-0.2 rounded-full uppercase tracking-wider ${
                            test.passed
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                          }`}
                        >
                          {test.passed ? 'PASSED' : 'FAILED'}
                        </span>
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{test.description}</p>
                    </div>
                  </div>

                  <button className="p-1 rounded-lg text-slate-400 hover:text-slate-600">
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                </div>

                {isExpanded && test.evidence && (
                  <div className="p-4 bg-slate-50 dark:bg-slate-950/60 border-t border-slate-100 dark:border-slate-800 text-xs font-mono">
                    <span className="font-sans font-bold text-slate-700 dark:text-slate-300 block mb-2">
                      Empirical Execution Proof & Payload:
                    </span>
                    <pre className="p-3 rounded-xl bg-slate-900 text-slate-200 overflow-x-auto text-[11px] leading-relaxed">
                      {JSON.stringify(test.evidence, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <FlaskConical className="w-12 h-12 text-slate-400 mx-auto" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Ready to Execute Test Suite
            </h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              Click the button above to run all 12 forensic acceptance tests including English fuel receipt VAT verification, Arabic extraction, date hallucination suppression, closed taxonomy enforcement, supplier memory auto-classification, prompt injection neutralisation, hotel bill multi-category splitting, perceptual visual duplicates, and the 100-receipt benchmark accuracy curve.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
