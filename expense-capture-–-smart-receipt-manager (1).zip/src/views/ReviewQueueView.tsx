import React, { useState } from 'react';
import {
  FileCheck2,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Eye,
  Building2,
  Calendar,
  Sparkles,
  Inbox,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { Receipt, Category } from '../types';
import { SideBySideReview } from '../components/SideBySideReview';
import { api } from '../services/api';
import { useLanguage } from '../context/LanguageContext';

interface ReviewQueueViewProps {
  receipts: Receipt[];
  categories: Category[];
  onReceiptUpdated: (updated: Receipt) => void;
  onNavigateToCapture?: () => void;
}

export const ReviewQueueView: React.FC<ReviewQueueViewProps> = ({
  receipts,
  categories,
  onReceiptUpdated,
  onNavigateToCapture,
}) => {
  const { t } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'low_confidence' | 'mismatches' | 'new_suppliers' | 'flagged'>('all');
  const [selectedReceipt, setSelectedReceipt] = useState<Receipt | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [bulkProcessing, setBulkProcessing] = useState(false);

  // Review Queue only shows receipts with status 'in_review'
  const inReviewReceipts = receipts.filter((r) => r.status === 'in_review');

  // Filter items
  const filteredReceipts = inReviewReceipts.filter((r) => {
    if (filter === 'low_confidence') {
      return r.categoryConfidence < 0.85 || Object.values(r.fieldConfidence || {}).some((c) => c < 0.85);
    }
    if (filter === 'mismatches') {
      return r.mathMismatch;
    }
    if (filter === 'flagged') {
      return r.policyFlags && r.policyFlags.length > 0;
    }
    if (filter === 'new_suppliers') {
      // New supplier: not matched by supplier memory
      return r.classificationSource !== 'supplier_memory';
    }
    return true;
  });

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(filteredReceipts.map((r) => r.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleToggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleBulkAccept = async () => {
    if (selectedIds.length === 0) return;
    setBulkProcessing(true);
    try {
      await api.bulkAccept(selectedIds);
      // Update local state
      for (const id of selectedIds) {
        const found = receipts.find((r) => r.id === id);
        if (found) {
          onReceiptUpdated({ ...found, status: 'approved' });
        }
      }
      setSelectedIds([]);
    } catch (err: any) {
      alert(`Bulk accept failed: ${err.message}`);
    } finally {
      setBulkProcessing(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in max-w-7xl mx-auto">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <span>{t('navReview')}</span>
            <span className="bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 text-xs font-mono font-bold px-2 py-0.5 rounded-full">
              {inReviewReceipts.length} pending
            </span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Side-by-side document verification, field corrections, and compliance sign-off
          </p>
        </div>

        {/* Bulk Action Button */}
        {selectedIds.length > 0 && (
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-500 font-semibold">
              {selectedIds.length} selected
            </span>
            <button
              onClick={handleBulkAccept}
              disabled={bulkProcessing}
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-md shadow-emerald-600/20 transition cursor-pointer active:scale-95 disabled:opacity-50"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>{bulkProcessing ? 'Accepting...' : t('btnBulkAccept')}</span>
            </button>
          </div>
        )}
      </div>

      {/* Filter Chips */}
      <div className="flex flex-wrap items-center gap-2">
        <button
          onClick={() => setFilter('all')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
            filter === 'all'
              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
              : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400 hover:bg-slate-200'
          }`}
        >
          All Items ({inReviewReceipts.length})
        </button>

        <button
          onClick={() => setFilter('low_confidence')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
            filter === 'low_confidence'
              ? 'bg-amber-500 text-white'
              : 'bg-amber-50 text-amber-800 dark:bg-amber-950/40 dark:text-amber-300 hover:bg-amber-100'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          Low Confidence (&lt;85%)
        </button>

        <button
          onClick={() => setFilter('mismatches')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
            filter === 'mismatches'
              ? 'bg-red-500 text-white'
              : 'bg-red-50 text-red-800 dark:bg-red-950/40 dark:text-red-300 hover:bg-red-100'
          }`}
        >
          <AlertTriangle className="w-3.5 h-3.5" />
          Math Mismatches
        </button>

        <button
          onClick={() => setFilter('flagged')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
            filter === 'flagged'
              ? 'bg-purple-600 text-white'
              : 'bg-purple-50 text-purple-800 dark:bg-purple-950/40 dark:text-purple-300 hover:bg-purple-100'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          Policy Flagged
        </button>

        <button
          onClick={() => setFilter('new_suppliers')}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer flex items-center gap-1.5 ${
            filter === 'new_suppliers'
              ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white'
              : 'bg-indigo-50 text-indigo-800 dark:bg-indigo-950/40 dark:text-indigo-300 hover:bg-indigo-100'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>New Suppliers</span>
        </button>
      </div>

      {/* Review Queue List */}
      {filteredReceipts.length > 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                  <th className="p-3.5 w-10 text-center">
                    <input
                      type="checkbox"
                      checked={selectedIds.length === filteredReceipts.length && filteredReceipts.length > 0}
                      onChange={handleSelectAll}
                      className="rounded text-sky-600"
                    />
                  </th>
                  <th className="p-3.5">Document / Supplier</th>
                  <th className="p-3.5">Date</th>
                  <th className="p-3.5">Category (AI / Rule)</th>
                  <th className="p-3.5">Confidence</th>
                  <th className="p-3.5">Total Amount</th>
                  <th className="p-3.5">Flags</th>
                  <th className="p-3.5 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredReceipts.map((rcpt) => {
                  const isLowConf = rcpt.categoryConfidence < 0.85;
                  const hasFlags = rcpt.policyFlags && rcpt.policyFlags.length > 0;
                  const isSelected = selectedIds.includes(rcpt.id);

                  return (
                    <tr
                      key={rcpt.id}
                      className={`hover:bg-slate-50 dark:hover:bg-slate-800/50 transition ${
                        isSelected ? 'bg-indigo-50/40 dark:bg-indigo-950/20' : ''
                      }`}
                    >
                      <td className="p-3.5 text-center">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => handleToggleSelect(rcpt.id)}
                          className="rounded text-indigo-600 focus:ring-indigo-500"
                        />
                      </td>

                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 rounded-lg overflow-hidden bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0 flex items-center justify-center">
                            {rcpt.fileType === 'application/pdf' ? (
                              <span className="text-[10px] font-bold text-red-500">PDF</span>
                            ) : (
                              <img
                                src={rcpt.fileUrl}
                                alt="thumb"
                                className="w-full h-full object-cover"
                              />
                            )}
                          </div>
                          <div>
                            <span className="font-bold text-slate-900 dark:text-white block">
                              {rcpt.supplierName || 'Unknown Supplier'}
                            </span>
                            <span className="text-[11px] text-slate-400 font-mono">
                              TRN: {rcpt.trn || 'None'} • #{rcpt.invoiceNumber || 'No bill #'}
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="p-3.5 text-slate-600 dark:text-slate-300 font-mono whitespace-nowrap">
                        {rcpt.invoiceDate || <span className="text-amber-500 italic">null (missing)</span>}
                      </td>

                      <td className="p-3.5">
                        <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                          {rcpt.categoryName}
                        </span>
                        <span className="text-[10px] text-slate-400">
                          GL {rcpt.glCode} • via {rcpt.classificationSource}
                        </span>
                      </td>

                      <td className="p-3.5">
                        <span
                          className={`font-mono font-bold text-[11px] px-2 py-0.5 rounded-full inline-block ${
                            isLowConf
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          }`}
                        >
                          {(rcpt.categoryConfidence * 100).toFixed(0)}%
                        </span>
                      </td>

                      <td className="p-3.5">
                        <span className="font-bold font-mono text-slate-900 dark:text-white block">
                          {(rcpt.totalMinor / 100).toFixed(2)} {rcpt.currency}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">
                          VAT: {(rcpt.vatAmountMinor / 100).toFixed(2)}
                        </span>
                      </td>

                      <td className="p-3.5">
                        {rcpt.mathMismatch && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-600 bg-red-50 dark:bg-red-950/40 px-2 py-0.5 rounded-full mr-1 mb-1">
                            Math Mismatch
                          </span>
                        )}
                        {hasFlags && (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full">
                            {rcpt.policyFlags.length} flag(s)
                          </span>
                        )}
                        {!rcpt.mathMismatch && !hasFlags && (
                          <span className="text-emerald-600 text-[11px] font-medium">Clean</span>
                        )}
                      </td>

                      <td className="p-3.5 text-right whitespace-nowrap">
                        <button
                          onClick={() => setSelectedReceipt(rcpt)}
                          className="flex items-center gap-1.5 ml-auto px-3 py-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white font-bold text-xs shadow-xs transition cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Review</span>
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        /* Empty State with plain words explanation */
        <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
          <div className="w-14 h-14 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 dark:text-white">
            {t('emptyReviewTitle')}
          </h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            {t('emptyReviewSubtitle')}. New receipts uploaded via the Capture view will appear here for side-by-side reconciliation if they require human review.
          </p>
          {onNavigateToCapture && (
            <button
              onClick={onNavigateToCapture}
              className="mt-3 px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold transition inline-flex items-center gap-2 cursor-pointer"
            >
              Upload More Receipts <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      )}

      {/* Side-by-Side Review Modal */}
      {selectedReceipt && (
        <SideBySideReview
          receipt={selectedReceipt}
          categories={categories}
          onClose={() => setSelectedReceipt(null)}
          onReceiptUpdated={(updated) => {
            onReceiptUpdated(updated);
            setSelectedReceipt(null);
          }}
        />
      )}
    </div>
  );
};
