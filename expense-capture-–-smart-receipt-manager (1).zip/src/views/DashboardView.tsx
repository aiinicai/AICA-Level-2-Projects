import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  TrendingUp,
  Receipt,
  Building2,
  Calendar,
  Layers,
  Sparkles,
  PieChart,
  ShieldCheck,
  AlertTriangle,
  ChevronRight,
  ArrowRight,
  Coins,
  CheckCircle2,
  XCircle,
  ShieldAlert,
  Bell,
  Mail,
  AlertOctagon,
  ArrowUpRight,
  ArrowDownRight,
  Sliders,
  DollarSign,
  Info,
} from 'lucide-react';
import { Receipt as ReceiptType, Category, CategoryInsight, RedFlagEmailAlert } from '../types';
import { useLanguage } from '../context/LanguageContext';
import { api } from '../services/api';
import { CategoryPieChart } from '../components/CategoryPieChart';

interface DashboardViewProps {
  receipts: ReceiptType[];
  categories: Category[];
  onNavigateToCapture?: () => void;
  onNavigateToSettings?: () => void;
  onNavigateToBudget?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  receipts,
  categories,
  onNavigateToCapture,
  onNavigateToSettings,
  onNavigateToBudget,
}) => {
  const { t } = useLanguage();
  const [selectedCategoryDrilldown, setSelectedCategoryDrilldown] = useState<string | null>(null);

  // Insights state (Weekly and Monthly)
  const [insightPeriod, setInsightPeriod] = useState<'monthly' | 'weekly'>('monthly');
  const [insightsData, setInsightsData] = useState<{
    weekly: { periodLabel: string; topCategories: CategoryInsight[]; totalSpendMinor: number };
    monthly: { periodLabel: string; topCategories: CategoryInsight[]; totalSpendMinor: number };
  } | null>(null);
  const [loadingInsights, setLoadingInsights] = useState(false);

  // Red Flag Email Alerts state
  const [emailAlerts, setEmailAlerts] = useState<RedFlagEmailAlert[]>([]);
  const [selectedAlertForModal, setSelectedAlertForModal] = useState<RedFlagEmailAlert | null>(null);
  const [showAllAlertsModal, setShowAllAlertsModal] = useState(false);

  // Fetch insights and email alerts
  useEffect(() => {
    let isMounted = true;
    async function loadData() {
      if (receipts.length === 0) return;
      setLoadingInsights(true);
      try {
        const [insightsRes, alertsRes] = await Promise.all([
          api.getInsights(),
          api.getEmailAlerts(),
        ]);
        if (isMounted) {
          setInsightsData(insightsRes);
          setEmailAlerts(alertsRes.alerts || []);
        }
      } catch (err) {
        console.error('Failed to load insights or email alerts:', err);
      } finally {
        if (isMounted) setLoadingInsights(false);
      }
    }
    loadData();
    return () => {
      isMounted = false;
    };
  }, [receipts]);

  // If no transactions exist, show required empty screen explaining next step
  if (receipts.length === 0) {
    return (
      <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs max-w-xl mx-auto space-y-4 my-8 animate-in fade-in">
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
          <LayoutDashboard className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">
          {t('emptyDashboardTitle')}
        </h3>
        <p className="text-sm text-slate-500 leading-relaxed">
          {t('emptySubtitle')}. Once invoices are uploaded, this dashboard will present real-time category spend breakdowns, weekly and monthly insights on highest expense categories, line item drill-downs, budget limit monitoring with red flag email alerts, and recoverable VAT analytics.
        </p>
        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3">
          {onNavigateToCapture && (
            <button
              onClick={onNavigateToCapture}
              className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition inline-flex items-center gap-2 cursor-pointer"
            >
              {t('navCapture')} <ArrowRight className="w-4 h-4" />
            </button>
          )}
          {onNavigateToSettings && (
            <button
              onClick={onNavigateToSettings}
              className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-semibold transition inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5" /> Configure Spend Limits
            </button>
          )}
        </div>
      </div>
    );
  }

  // Approved receipts or all active receipts
  const approved = receipts.filter((r) => r.status === 'approved');
  const dataset = approved.length > 0 ? approved : receipts;

  // 1. Spend Metrics (Minor units to Major AED)
  const totalSpendMinor = dataset.reduce((sum, r) => sum + r.totalAedMinor, 0);
  const totalVatMinor = dataset.reduce((sum, r) => sum + r.vatAmountMinor, 0);
  const totalRecoverableVatMinor = dataset.reduce((sum, r) => sum + r.recoverableVatMinor, 0);
  const totalNonRecoverableVatMinor = Math.max(0, totalVatMinor - totalRecoverableVatMinor);

  // Corporate Tax deductible vs non-deductible
  const totalCtDeductibleMinor = dataset.reduce((sum, r) => sum + r.ctDeductibleAmountMinor, 0);
  const totalCtNonDeductibleMinor = Math.max(0, totalSpendMinor - totalCtDeductibleMinor);

  // 2. Spend by Category
  const categorySpendMap = new Map<string, { categoryName: string; totalMinor: number; count: number; glCode: string }>();
  dataset.forEach((r) => {
    const key = r.categoryId || 'uncat';
    const existing = categorySpendMap.get(key) || {
      categoryName: r.categoryName || 'Uncategorised',
      totalMinor: 0,
      count: 0,
      glCode: r.glCode || '9990',
    };
    existing.totalMinor += r.totalAedMinor;
    existing.count += 1;
    categorySpendMap.set(key, existing);
  });
  const categorySpends = Array.from(categorySpendMap.entries()).sort((a, b) => b[1].totalMinor - a[1].totalMinor);

  // 3. Spend by Supplier & New Suppliers this month
  const supplierSpendMap = new Map<string, { totalMinor: number; count: number; trn?: string }>();
  const currentMonthPrefix = new Date().toISOString().substring(0, 7); // YYYY-MM
  const newSuppliersThisMonthSet = new Set<string>();

  dataset.forEach((r) => {
    const name = r.supplierName || 'Unknown Supplier';
    const entry = supplierSpendMap.get(name) || { totalMinor: 0, count: 0, trn: r.trn || undefined };
    entry.totalMinor += r.totalAedMinor;
    entry.count += 1;
    supplierSpendMap.set(name, entry);

    if (r.uploadedAt.startsWith(currentMonthPrefix)) {
      newSuppliersThisMonthSet.add(name);
    }
  });

  const topSuppliers = Array.from(supplierSpendMap.entries())
    .sort((a, b) => b[1].totalMinor - a[1].totalMinor)
    .slice(0, 5);

  // 4. Spend by Cost Centre
  const costCentreMap = new Map<string, number>();
  dataset.forEach((r) => {
    const cc = r.costCentre || 'General Operations';
    costCentreMap.set(cc, (costCentreMap.get(cc) || 0) + r.totalAedMinor);
  });
  const costCentres = Array.from(costCentreMap.entries()).sort((a, b) => b[1] - a[1]);

  // 5. Classification Quality Metrics
  const autoAcceptedCount = receipts.filter((r) => r.classificationSource === 'ai_proposal' && r.status === 'approved' && r.reviewedBy === 'system').length;
  const autoAcceptRate = receipts.length > 0 ? (autoAcceptedCount / receipts.length) * 100 : 0;
  const lowConfidenceVolume = receipts.filter((r) => r.categoryConfidence < 0.85).length;

  // 6. Flags by rule
  const flagsByRuleMap = new Map<string, number>();
  receipts.forEach((r) => {
    (r.policyFlags || []).forEach((f) => {
      flagsByRuleMap.set(f.rule, (flagsByRuleMap.get(f.rule) || 0) + 1);
    });
  });
  const flagsByRule = Array.from(flagsByRuleMap.entries()).sort((a, b) => b[1] - a[1]);

  // Drilldown items for selected category
  const drilldownReceipts = selectedCategoryDrilldown
    ? dataset.filter((r) => r.categoryId === selectedCategoryDrilldown)
    : [];

  // Current active insights data
  const currentInsight = insightsData ? insightsData[insightPeriod] : null;
  const topExpenseCategories = currentInsight?.topCategories || [];
  const breachedCount = topExpenseCategories.filter((c) => c.isBreached).length;

  return (
    <div className="space-y-6 animate-in fade-in max-w-7xl mx-auto">
      {/* Title & Red Flag Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <LayoutDashboard className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Financial & Tax Compliance Dashboard</span>
          </h2>
          <p className="text-xs text-slate-500">
            Real-time analytics across {receipts.length} receipts with automated category budget monitoring and UAE compliance
          </p>
        </div>

        {emailAlerts.length > 0 && (
          <button
            onClick={() => setShowAllAlertsModal(true)}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-900/60 text-red-700 dark:text-red-400 text-xs font-bold hover:bg-red-100 transition shadow-xs cursor-pointer animate-pulse"
          >
            <AlertOctagon className="w-4 h-4 text-red-600" />
            <span>{emailAlerts.length} Red Flag Email Alert{emailAlerts.length > 1 ? 's' : ''}</span>
          </button>
        )}
      </div>

      {/* Red Flag Alert Notice if any limit breached */}
      {breachedCount > 0 && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-red-50 to-orange-50 dark:from-red-950/40 dark:to-orange-950/30 border border-red-200 dark:border-red-900/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-300 flex items-center justify-center shrink-0">
              <AlertOctagon className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-red-900 dark:text-red-200 uppercase tracking-wider flex items-center gap-1.5">
                <span>Category Budget Limit Breach Detected</span>
                <span className="bg-red-600 text-white text-[10px] px-1.5 py-0.2 rounded-full font-bold">
                  {breachedCount} Category{breachedCount > 1 ? 's' : ''} Breached
                </span>
              </h4>
              <p className="text-xs text-red-800 dark:text-red-300 mt-0.5">
                Automated Red Flag email alerts have been generated and dispatched to submitters and finance review team.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 self-start sm:self-auto">
            {onNavigateToBudget && (
              <button
                onClick={onNavigateToBudget}
                className="px-3 py-1.5 rounded-xl border border-red-300 dark:border-red-800 bg-white dark:bg-slate-900 text-red-700 dark:text-red-300 text-xs font-bold transition shadow-xs whitespace-nowrap cursor-pointer flex items-center gap-1.5 hover:bg-red-50"
              >
                <Sliders className="w-3.5 h-3.5" /> Budget Alerts Sentinel
              </button>
            )}
            <button
              onClick={() => setShowAllAlertsModal(true)}
              className="px-3 py-1.5 rounded-xl bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition shadow-xs whitespace-nowrap cursor-pointer flex items-center gap-1.5"
            >
              <Mail className="w-3.5 h-3.5" /> View Dispatched Emails
            </button>
          </div>
        </div>
      )}

      {/* Top Summary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Spend */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Total Spend
          </span>
          <span className="text-xl sm:text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {(totalSpendMinor / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })} <span className="text-xs font-normal text-slate-400">AED</span>
          </span>
          <div className="mt-2 text-[11px] text-slate-400">
            {dataset.length} transactions reconciled
          </div>
        </div>

        {/* Recoverable VAT */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Recoverable VAT (Input Tax)
          </span>
          <span className="text-xl sm:text-2xl font-bold font-mono text-emerald-600">
            {(totalRecoverableVatMinor / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })} <span className="text-xs font-normal text-slate-400">AED</span>
          </span>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Blocked / Non-recoverable:</span>
            <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">
              {(totalNonRecoverableVatMinor / 100).toFixed(2)} AED
            </span>
          </div>
        </div>

        {/* Corporate Tax Deductibility */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            Corporate Tax Deductible
          </span>
          <span className="text-xl sm:text-2xl font-bold font-mono text-sky-600">
            {(totalCtDeductibleMinor / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })} <span className="text-xs font-normal text-slate-400">AED</span>
          </span>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>50% Limited / Blocked:</span>
            <span className="font-mono font-semibold text-slate-700 dark:text-slate-300">
              {(totalCtNonDeductibleMinor / 100).toFixed(2)} AED
            </span>
          </div>
        </div>

        {/* Quality: Auto-Accept Rate */}
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            AI Classification Quality
          </span>
          <span className="text-xl sm:text-2xl font-bold font-mono text-slate-900 dark:text-white">
            {autoAcceptRate.toFixed(0)}% <span className="text-xs font-normal text-slate-400">auto-accept</span>
          </span>
          <div className="mt-2 text-[11px] text-slate-500 flex items-center justify-between">
            <span>Low-confidence volume:</span>
            <span className="font-mono font-semibold text-amber-600">
              {lowConfidenceVolume} items
            </span>
          </div>
        </div>
      </div>

      {/* ============================================================== */}
      {/* D3 VISUALIZATION: CURRENT MONTH CATEGORY EXPENSES PIE CHART    */}
      {/* ============================================================== */}
      <CategoryPieChart
        receipts={dataset}
        categories={categories}
        selectedCategoryId={selectedCategoryDrilldown}
        onSelectCategory={(catId) => setSelectedCategoryDrilldown(catId)}
        onNavigateToCapture={onNavigateToCapture}
      />

      {/* ============================================================== */}
      {/* FEATURED: WEEKLY & MONTHLY CATEGORY INSIGHTS (HIGHEST EXPENSES) */}
      {/* ============================================================== */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400">
                <TrendingUp className="w-5 h-5" />
              </span>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Category Expense Insights & Spend Limits
              </h3>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Top spending categories ranked by volume, growth trajectory, ticket sizes, and spend limit breaches.
            </p>
          </div>

          {/* Timeframe Selector & Period Label */}
          <div className="flex items-center gap-2 self-start sm:self-auto">
            <div className="bg-slate-100 dark:bg-slate-800 p-1 rounded-xl flex items-center gap-1 text-xs font-semibold">
              <button
                onClick={() => setInsightPeriod('monthly')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  insightPeriod === 'monthly'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Monthly Insights
              </button>
              <button
                onClick={() => setInsightPeriod('weekly')}
                className={`px-3 py-1.5 rounded-lg transition cursor-pointer ${
                  insightPeriod === 'weekly'
                    ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 shadow-xs font-bold'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                Weekly Insights
              </button>
            </div>
          </div>
        </div>

        {/* Period Summary Indicator */}
        {currentInsight && (
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs">
            <span className="font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-sky-600" />
              <span>Reporting Period: <strong>{currentInsight.periodLabel}</strong></span>
            </span>
            <span className="font-mono text-slate-900 dark:text-white">
              Period Total: <strong>{(currentInsight.totalSpendMinor / 100).toFixed(2)} AED</strong>
            </span>
          </div>
        )}

        {/* Highest Expenses Ranking Grid */}
        {loadingInsights ? (
          <div className="py-12 flex flex-col items-center justify-center gap-2">
            <div className="w-8 h-8 border-3 border-sky-600 border-t-transparent rounded-full animate-spin" />
            <span className="text-xs text-slate-400">Computing spend insights...</span>
          </div>
        ) : topExpenseCategories.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400 italic">
            No expenses recorded during this {insightPeriod === 'monthly' ? 'month' : 'week'}.
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {topExpenseCategories.map((cat, idx) => {
              const hasLimit = typeof cat.spendLimitMinor === 'number' && cat.spendLimitMinor > 0;
              const limitMinor = cat.spendLimitMinor || 0;
              const limitPercent = hasLimit ? Math.round((cat.currentSpendMinor / limitMinor) * 100) : 0;
              const isBreached = cat.isBreached || (hasLimit && cat.currentSpendMinor > limitMinor);

              return (
                <div
                  key={cat.categoryId}
                  className={`p-4 rounded-2xl border transition relative overflow-hidden flex flex-col justify-between ${
                    isBreached
                      ? 'border-red-300 dark:border-red-900/80 bg-red-50/40 dark:bg-red-950/20 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/80 hover:border-slate-300'
                  }`}
                >
                  {/* Top Bar: Rank Badge, Category Name, GL Code */}
                  <div>
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`w-6 h-6 rounded-lg text-xs font-black flex items-center justify-center ${
                            idx === 0
                              ? 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              : idx === 1
                              ? 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                              : idx === 2
                              ? 'bg-orange-100 text-orange-800 dark:bg-orange-950 dark:text-orange-300'
                              : 'bg-slate-100 text-slate-500 dark:bg-slate-800/60 dark:text-slate-400'
                          }`}
                        >
                          #{idx + 1}
                        </span>
                        <div>
                          <h4 className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                            {cat.categoryName}
                          </h4>
                          <span className="text-[10px] text-slate-400 font-mono">GL {cat.glCode}</span>
                        </div>
                      </div>

                      {/* Growth Trend */}
                      {cat.growthPercentage !== 0 && (
                        <span
                          className={`inline-flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            cat.growthPercentage > 0
                              ? 'bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300'
                              : 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                          }`}
                          title={`Spend changed by ${cat.growthPercentage > 0 ? '+' : ''}${cat.growthPercentage}% vs previous period`}
                        >
                          {cat.growthPercentage > 0 ? (
                            <ArrowUpRight className="w-3 h-3 text-red-600" />
                          ) : (
                            <ArrowDownRight className="w-3 h-3 text-emerald-600" />
                          )}
                          <span>{cat.growthPercentage > 0 ? `+${cat.growthPercentage}%` : `${cat.growthPercentage}%`}</span>
                        </span>
                      )}
                    </div>

                    {/* Main Amount */}
                    <div className="mt-2 mb-3">
                      <div className="flex items-baseline justify-between">
                        <span className="text-xl font-mono font-black text-slate-900 dark:text-white">
                          {(cat.currentSpendMinor / 100).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                          <span className="text-xs font-normal text-slate-400 ml-1">AED</span>
                        </span>
                        <span className="text-xs font-semibold text-slate-500">
                          {cat.percentOfTotal.toFixed(1)}% of total
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-400 mt-1">
                        <span>{cat.spendCount} receipt{cat.spendCount > 1 ? 's' : ''}</span>
                        <span>•</span>
                        <span>Avg: {(cat.averageTicketMinor / 100).toFixed(0)} AED</span>
                        <span>•</span>
                        <span>Max: {(cat.highestSingleTicketMinor / 100).toFixed(0)} AED</span>
                      </div>
                    </div>
                  </div>

                  {/* Spend Limit & Breach Status */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80">
                    {hasLimit ? (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-500 font-medium flex items-center gap-1">
                            <span>Limit:</span>
                            <span className="font-mono text-slate-700 dark:text-slate-300 font-semibold">
                              {(limitMinor / 100).toLocaleString()} AED
                            </span>
                          </span>
                          <span
                            className={`font-mono font-bold ${
                              isBreached
                                ? 'text-red-600 dark:text-red-400'
                                : limitPercent > 80
                                ? 'text-amber-600'
                                : 'text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {limitPercent}%
                          </span>
                        </div>

                        {/* Limit progress bar */}
                        <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-2 rounded-full transition-all duration-500 ${
                              isBreached
                                ? 'bg-red-600'
                                : limitPercent > 80
                                ? 'bg-amber-500'
                                : 'bg-sky-600'
                            }`}
                            style={{ width: `${Math.min(100, Math.max(3, limitPercent))}%` }}
                          />
                        </div>

                        {/* Breach Badge & Alert trigger notice */}
                        {isBreached && (
                          <div className="mt-2 pt-1 flex items-center justify-between">
                            <span className="inline-flex items-center gap-1 text-[10px] font-bold text-red-600 dark:text-red-400 bg-red-100/70 dark:bg-red-950/60 px-2 py-0.5 rounded-full">
                              <AlertOctagon className="w-3 h-3 text-red-600" />
                              Limit Breached (+{((cat.currentSpendMinor - limitMinor) / 100).toFixed(0)} AED)
                            </span>
                            <button
                              onClick={() => {
                                const related = emailAlerts.find((a) => a.categoryId === cat.categoryId);
                                if (related) setSelectedAlertForModal(related);
                                else setShowAllAlertsModal(true);
                              }}
                              className="text-[10px] text-red-600 hover:underline font-bold inline-flex items-center gap-0.5 cursor-pointer"
                            >
                              <Mail className="w-3 h-3" /> View Email
                            </button>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center justify-between text-[11px] text-slate-400">
                        <span>No monthly limit set</span>
                        {onNavigateToSettings && (
                          <button
                            onClick={onNavigateToSettings}
                            className="text-[10px] text-sky-600 hover:underline font-semibold cursor-pointer"
                          >
                            + Set Limit
                          </button>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Middle Grid: Category Breakdown with Line Item Drilldown & Spend by Supplier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Category Breakdown (7 cols) */}
        <div className="lg:col-span-7 bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>Spend by Category (Click to Drill-Down Line Items)</span>
              </h3>
              <p className="text-[11px] text-slate-500">
                Controlled taxonomy classification with GL Codes
              </p>
            </div>
            {selectedCategoryDrilldown && (
              <button
                onClick={() => setSelectedCategoryDrilldown(null)}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-bold cursor-pointer"
              >
                Clear Drill-down
              </button>
            )}
          </div>

          <div className="space-y-2.5">
            {categorySpends.map(([catId, data]) => {
              const pct = totalSpendMinor > 0 ? (data.totalMinor / totalSpendMinor) * 100 : 0;
              const isSelected = selectedCategoryDrilldown === catId;
              const matchingCat = categories.find((c) => c.id === catId);
              const isLimitBreached = matchingCat?.spendLimitMinor && data.totalMinor > matchingCat.spendLimitMinor;

              return (
                <div
                  key={catId}
                  onClick={() => setSelectedCategoryDrilldown(isSelected ? null : catId)}
                  className={`p-3 rounded-xl border transition cursor-pointer ${
                    isSelected
                      ? 'border-indigo-500 bg-indigo-50/50 dark:bg-indigo-950/30'
                      : 'border-slate-100 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                      <span>{data.categoryName}</span>
                      <span className="text-[10px] text-slate-400 font-mono">GL {data.glCode}</span>
                      {isLimitBreached && (
                        <span className="text-[9px] font-bold px-1.5 py-0.2 rounded bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300">
                          Breached
                        </span>
                      )}
                    </span>
                    <span className="font-mono font-bold text-slate-900 dark:text-white">
                      {(data.totalMinor / 100).toFixed(2)} AED ({pct.toFixed(1)}%)
                    </span>
                  </div>
                  {/* Progress bar */}
                  <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all duration-500 ${isLimitBreached ? 'bg-red-600' : 'bg-gradient-to-r from-indigo-600 to-violet-600'}`}
                      style={{ width: `${Math.min(100, Math.max(3, pct))}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Drill-down panel */}
          {selectedCategoryDrilldown && (
            <div className="mt-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-indigo-200 dark:border-indigo-900/60 animate-in fade-in space-y-3">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Line Items in Selected Category ({drilldownReceipts.length} documents)
              </h4>
              <div className="max-h-48 overflow-y-auto space-y-2 divide-y divide-slate-200/60 dark:divide-slate-700/60 text-xs">
                {drilldownReceipts.length === 0 ? (
                  <p className="text-slate-400 italic">No line items extracted for this category.</p>
                ) : (
                  drilldownReceipts.flatMap((r) =>
                    (r.lineItems || []).map((li, idx) => (
                      <div key={`${r.id}-${idx}`} className="pt-2 flex items-center justify-between">
                        <div>
                          <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                            {li.description}
                          </span>
                          <span className="text-[10px] text-slate-500">
                            {r.supplierName} • {r.invoiceDate} • Qty {li.quantity}
                          </span>
                        </div>
                        <span className="font-mono font-bold text-slate-900 dark:text-white">
                          {(li.lineTotalMinor / 100).toFixed(2)} AED
                        </span>
                      </div>
                    ))
                  )
                )}
              </div>
            </div>
          )}
        </div>

        {/* Top Suppliers & New Suppliers This Month (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Top Suppliers */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Building2 className="w-4 h-4 text-sky-600" />
              <span>Top Suppliers by Volume</span>
            </h3>

            <div className="space-y-2 text-xs">
              {topSuppliers.map(([name, data], idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 rounded-xl border border-slate-100 dark:border-slate-800"
                >
                  <div className="truncate max-w-[180px]">
                    <span className="font-bold text-slate-800 dark:text-slate-200 block truncate">
                      {name}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {data.count} transaction(s) {data.trn ? `• TRN ${data.trn}` : ''}
                    </span>
                  </div>
                  <span className="font-mono font-bold text-slate-900 dark:text-white">
                    {(data.totalMinor / 100).toFixed(2)} AED
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* New Suppliers This Month */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-500" />
              <span>New Suppliers This Month ({newSuppliersThisMonthSet.size})</span>
            </h3>
            <div className="flex flex-wrap gap-1.5">
              {Array.from(newSuppliersThisMonthSet).map((s, idx) => (
                <span
                  key={idx}
                  className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-100 dark:border-indigo-900"
                >
                  {s}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Spend by Cost Centre & Compliance Flags Breakdown */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Cost Centres */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white">
            Spend by Cost Centre
          </h3>
          <div className="space-y-2">
            {costCentres.map(([cc, amt], idx) => (
              <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-slate-50 dark:bg-slate-800/50">
                <span className="font-medium text-slate-700 dark:text-slate-300">{cc}</span>
                <span className="font-mono font-bold text-slate-900 dark:text-white">
                  {(amt / 100).toFixed(2)} AED
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Policy Flags Breakdown */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3 text-xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-500" />
            <span>Policy Flags Triggered by Rule</span>
          </h3>
          {flagsByRule.length > 0 ? (
            <div className="space-y-2">
              {flagsByRule.map(([rule, count], idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded-lg bg-amber-50/50 dark:bg-amber-950/20 border border-amber-100 dark:border-amber-900/30">
                  <span className="font-medium text-amber-900 dark:text-amber-200 truncate max-w-[280px]">
                    {rule}
                  </span>
                  <span className="font-mono font-bold text-amber-700 dark:text-amber-300">
                    {count} incident(s)
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-slate-400 italic">No policy exceptions flagged across current receipts.</p>
          )}
        </div>
      </div>

      {/* ============================================================== */}
      {/* MODAL: SINGLE RED FLAG EMAIL ALERT PREVIEW */}
      {/* ============================================================== */}
      {selectedAlertForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-red-200 dark:border-red-900 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <AlertOctagon className="w-5 h-5" />
                <h3 className="text-sm font-bold">Red Flag Email Alert</h3>
              </div>
              <button
                onClick={() => setSelectedAlertForModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            {/* Email Header Simulation */}
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5 font-mono">
              <div className="flex">
                <span className="w-16 text-slate-400">To:</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {selectedAlertForModal.recipientName} &lt;{selectedAlertForModal.recipientEmail}&gt;
                </span>
              </div>
              <div className="flex">
                <span className="w-16 text-slate-400">Subject:</span>
                <span className="font-bold text-red-700 dark:text-red-400">
                  {selectedAlertForModal.subject}
                </span>
              </div>
              <div className="flex">
                <span className="w-16 text-slate-400">Date:</span>
                <span className="text-slate-600 dark:text-slate-300">
                  {new Date(selectedAlertForModal.triggeredAt).toLocaleString()}
                </span>
              </div>
              <div className="flex">
                <span className="w-16 text-slate-400">Status:</span>
                <span className="text-emerald-600 font-bold uppercase">
                  ✓ {selectedAlertForModal.status} (Automated Dispatch)
                </span>
              </div>
            </div>

            {/* Email Body Content */}
            <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/90 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-mono leading-relaxed border border-slate-200 dark:border-slate-700">
              {selectedAlertForModal.body}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedAlertForModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-xs font-bold cursor-pointer"
              >
                Close Notice
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* MODAL: ALL DISPATCHED RED FLAG EMAIL ALERTS */}
      {/* ============================================================== */}
      {showAllAlertsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-2xl max-h-[85vh] rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-red-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Dispatched Red Flag Email Alerts ({emailAlerts.length})
                </h3>
              </div>
              <button
                onClick={() => setShowAllAlertsModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-500">
              The system automatically sends these email notifications whenever an expense causes a category to breach its configured monthly spend limit.
            </p>

            {emailAlerts.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400 italic">
                No red flag email alerts have been triggered yet. Spend limits remain unbreached.
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto space-y-3 pr-1">
                {emailAlerts.map((alert) => (
                  <div
                    key={alert.id}
                    className="p-4 rounded-xl border border-red-200 dark:border-red-900/60 bg-red-50/30 dark:bg-red-950/20 space-y-2 text-xs"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="font-bold text-red-800 dark:text-red-300 block">
                          {alert.subject}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          To: {alert.recipientName} ({alert.recipientEmail}) • {new Date(alert.triggeredAt).toLocaleString()}
                        </span>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-red-600 text-white shrink-0">
                        Breach: +{(alert.breachAmountMinor / 100).toFixed(2)} AED
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 border border-slate-200/60 dark:border-slate-800 font-mono text-[11px]">
                      <div>
                        <span className="text-slate-400 block text-[10px]">Category:</span>
                        <span className="font-semibold">{alert.categoryName}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Spend Limit:</span>
                        <span className="font-semibold">{(alert.spendLimitMinor / 100).toFixed(2)} AED</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block text-[10px]">Current Spend:</span>
                        <span className="font-bold text-red-600">{(alert.currentSpendMinor / 100).toFixed(2)} AED</span>
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedAlertForModal(alert)}
                      className="text-xs text-sky-600 hover:underline font-bold inline-flex items-center gap-1 cursor-pointer pt-1"
                    >
                      <Mail className="w-3.5 h-3.5" /> Read full email message
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex justify-end pt-3 border-t border-slate-200 dark:border-slate-800">
              <button
                onClick={() => setShowAllAlertsModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
