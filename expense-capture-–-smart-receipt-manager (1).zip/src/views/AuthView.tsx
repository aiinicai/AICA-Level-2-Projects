import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';
import { Receipt, ShieldCheck, Lock, Mail, User, AlertCircle, ArrowRight, Sparkles } from 'lucide-react';

export const AuthView: React.FC = () => {
  const { login, register } = useAuth();
  const { t } = useLanguage();

  const [isRegistering, setIsRegistering] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    setSuccessNotice(null);
    setLoading(true);

    try {
      if (isRegistering) {
        if (!name.trim()) {
          setErrorMessage('Please enter your full name');
          setLoading(false);
          return;
        }
        if (password.length < 8) {
          setErrorMessage('Password must be at least 8 characters (NIST SP 800-63B standard)');
          setLoading(false);
          return;
        }
        const res = await register(name, email, password);
        if (!res.success) {
          setErrorMessage(res.error || 'Registration failed');
        } else if (res.pendingApproval) {
          setSuccessNotice(res.message || 'Account registered successfully! Your account is pending administrator approval. You will be able to log in once an administrator approves your account.');
          setIsRegistering(false);
          setName('');
          setPassword('');
        } else if (res.isFirstAdmin) {
          setSuccessNotice('System administrator setup complete! Welcome to Expense Tracker.');
        }
      } else {
        const res = await login(email, password);
        if (!res.success) {
          setErrorMessage(res.error || 'Failed to sign in. Please check your credentials.');
        }
      }
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950 flex flex-col justify-center items-center p-4 selection:bg-indigo-500/30">
      <div className="w-full max-w-md">
        {/* Brand Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-500 via-indigo-600 to-violet-600 text-white shadow-xl shadow-indigo-500/30 mb-4 ring-4 ring-indigo-400/20">
            <Receipt className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight">
            Expense Tracker
          </h1>
          <p className="text-sm text-slate-300 mt-1">
            Smart Receipt & Financial Manager with UAE/GCC Tax Compliance
          </p>
        </div>

        {/* Card */}
        <div className="bg-slate-900/80 backdrop-blur-xl border border-indigo-900/40 rounded-2xl p-6 sm:p-8 shadow-2xl text-white">
          <div className="flex items-center justify-between pb-4 mb-6 border-b border-slate-800">
            <h2 className="text-lg font-bold text-white">
              {isRegistering ? 'Create Your Account' : 'Welcome Back'}
            </h2>
            <button
              onClick={() => {
                setIsRegistering(!isRegistering);
                setErrorMessage(null);
                setSuccessNotice(null);
              }}
              className="text-xs font-bold text-indigo-400 hover:text-indigo-300 transition cursor-pointer"
            >
              {isRegistering ? 'Have an account? Sign In' : 'New here? Register'}
            </button>
          </div>

          {/* Privacy & Security Guarantee */}
          {isRegistering && (
            <div className="mb-5 p-3 rounded-xl bg-indigo-500/10 border border-indigo-400/30 text-indigo-200 text-xs flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <span>
                <strong>Privacy-First Architecture:</strong> Your personal receipts and financial data remain strictly private to you. Administrators only manage user approvals and category taxonomy, with zero access to your uploaded documents.
              </span>
            </div>
          )}

          {errorMessage && (
            <div className="mb-5 p-3.5 rounded-xl bg-red-500/15 border border-red-500/30 text-red-200 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successNotice && (
            <div className="mb-5 p-3.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-200 text-xs flex items-start gap-2.5">
              <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <span>{successNotice}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegistering && (
              <div>
                <label className="text-xs font-medium text-slate-300 block mb-1.5">
                  Full Name
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Sarah Al Hashimi"
                    className="w-full bg-black/20 border border-white/15 rounded-xl px-3.5 pl-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-xs font-medium text-slate-300 block mb-1.5">
                Work Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="finance@company.ae"
                  className="w-full bg-black/20 border border-white/15 rounded-xl px-3.5 pl-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-medium text-slate-300">
                  Password
                </label>
                <span className="text-[10px] text-slate-400">
                  NIST SP 800-63B (min 8 chars)
                </span>
              </div>
              <div className="relative">
                <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••"
                  className="w-full bg-black/30 border border-slate-700 rounded-xl px-3.5 pl-10 py-2.5 text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full mt-2 flex items-center justify-center gap-2 bg-gradient-to-r from-indigo-500 via-indigo-600 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white font-bold text-sm py-3 px-4 rounded-xl shadow-lg shadow-indigo-500/30 transition active:scale-98 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                'Processing...'
              ) : (
                <>
                  <span>{isRegistering ? 'Create Account' : 'Sign In to Workspace'}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Security & Roles Footer */}
          <div className="mt-6 pt-5 border-t border-white/10 text-center text-[11px] text-slate-400 space-y-1">
            <p className="flex items-center justify-center gap-1.5 text-slate-400 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              Role-Based Access: Submitter, Reviewer, Admin, Auditor
            </p>
            <p className="text-[10px] text-slate-500">
              Passwords hashed with bcrypt • Rate-limited authentication
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
