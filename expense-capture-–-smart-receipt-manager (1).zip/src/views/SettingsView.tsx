import React, { useState, useEffect } from 'react';
import {
  Settings,
  Layers,
  Sliders,
  Users,
  ShieldAlert,
  GitMerge,
  Plus,
  Edit2,
  Trash2,
  Check,
  AlertTriangle,
  History,
  Building2,
  Save,
  Cpu,
  Clock,
  Coins,
  Sparkles,
  AlertOctagon,
  Mail,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  UserCheck,
} from 'lucide-react';
import { Category, AppSettings, RuleOverride, User, UserRole, RedFlagEmailAlert } from '../types';
import { api } from '../services/api';
import { useAuth } from '../context/AuthContext';

interface SettingsViewProps {
  categories: Category[];
  settings: AppSettings;
  rules: RuleOverride[];
  users: User[];
  taxonomyVersion: number;
  onCategoriesUpdated: (cats: Category[], ver: number) => void;
  onSettingsUpdated: (newSettings: AppSettings) => void;
  onRulesUpdated: (rules: RuleOverride[]) => void;
  onUsersUpdated: (users: User[]) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({
  categories,
  settings,
  rules,
  users,
  taxonomyVersion,
  onCategoriesUpdated,
  onSettingsUpdated,
  onRulesUpdated,
  onUsersUpdated,
}) => {
  const { user: currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'Admin';

  const [activeSection, setActiveSection] = useState<'categories' | 'tax' | 'rules' | 'ai' | 'users' | 'alerts'>('categories');

  // Category Edit / Add Modal state
  const [editingCategory, setEditingCategory] = useState<Partial<Category> | null>(null);
  const [isNewCategory, setIsNewCategory] = useState(false);
  const [mergeSourceId, setMergeSourceId] = useState('');
  const [mergeTargetId, setMergeTargetId] = useState('');
  const [showMergeModal, setShowMergeModal] = useState(false);

  // Preset categories addition state
  const [addingPresets, setAddingPresets] = useState(false);
  const [presetSuccessMessage, setPresetSuccessMessage] = useState<string | null>(null);

  // Red Flag Email Alerts state
  const [emailAlerts, setEmailAlerts] = useState<RedFlagEmailAlert[]>([]);
  const [loadingAlerts, setLoadingAlerts] = useState(false);
  const [selectedAlertForModal, setSelectedAlertForModal] = useState<RedFlagEmailAlert | null>(null);

  // Policy Settings state
  const [localSettings, setLocalSettings] = useState<AppSettings>({ ...settings });
  const [savingSettings, setSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // New Rule state
  const [newKeyword, setNewKeyword] = useState('');
  const [newRuleCatId, setNewRuleCatId] = useState(categories[0]?.id || '');

  // Load email alerts on mount or when alerts tab is active
  const loadAlerts = async () => {
    setLoadingAlerts(true);
    try {
      const res = await api.getEmailAlerts();
      setEmailAlerts(res.alerts || []);
    } catch (err) {
      console.error('Failed to load email alerts:', err);
    } finally {
      setLoadingAlerts(false);
    }
  };

  useEffect(() => {
    loadAlerts();
  }, [activeSection]);

  const handleAddPresetBundle = async () => {
    setAddingPresets(true);
    try {
      const res = await api.addCategoryPresetBundle();
      onCategoriesUpdated(res.categories, res.taxonomyVersion);
      setPresetSuccessMessage(`Successfully added ${res.addedCount} categories (Groceries, Sports, Entertainment, Food, Transportation, Travelling, Charity) to taxonomy v${res.taxonomyVersion}!`);
      setTimeout(() => setPresetSuccessMessage(null), 5000);
    } catch (err: any) {
      alert(`Error adding preset bundle: ${err.message}`);
    } finally {
      setAddingPresets(false);
    }
  };

  const handleSaveCategory = async () => {
    if (!editingCategory?.name || !editingCategory?.glCode) {
      alert('Name and GL code are required');
      return;
    }
    try {
      if (isNewCategory) {
        const res = await api.createCategory(editingCategory);
        onCategoriesUpdated([...categories, res.category], res.taxonomyVersion);
      } else if (editingCategory.id) {
        const res = await api.updateCategory(editingCategory.id, editingCategory);
        const updatedList = categories.map((c) => (c.id === res.category.id ? res.category : c));
        onCategoriesUpdated(updatedList, res.taxonomyVersion);
      }
      setEditingCategory(null);
    } catch (err: any) {
      alert(`Error saving category: ${err.message}`);
    }
  };

  const handleDeactivateCategory = async (cat: Category) => {
    if (!confirm(`Are you sure you want to deactivate "${cat.name}"? Categories with history cannot be deleted.`)) return;
    try {
      const res = await api.updateCategory(cat.id, { active: false });
      const updatedList = categories.map((c) => (c.id === res.category.id ? res.category : c));
      onCategoriesUpdated(updatedList, res.taxonomyVersion);
    } catch (err: any) {
      alert(`Deactivation error: ${err.message}`);
    }
  };

  const handleExecuteMerge = async () => {
    if (!mergeSourceId || !mergeTargetId || mergeSourceId === mergeTargetId) {
      alert('Select two distinct categories to merge');
      return;
    }
    try {
      const res = await api.mergeCategories(mergeSourceId, mergeTargetId);
      const catRes = await api.getCategories();
      onCategoriesUpdated(catRes.categories, res.taxonomyVersion);
      setShowMergeModal(false);
      alert(`Merged successfully! ${res.remappedCount} historical records remapped to target category.`);
    } catch (err: any) {
      alert(`Merge error: ${err.message}`);
    }
  };

  const handleSavePolicySettings = async () => {
    setSavingSettings(true);
    try {
      const res = await api.updateSettings(localSettings);
      onSettingsUpdated(res.settings);
      setSettingsSuccess(true);
      setTimeout(() => setSettingsSuccess(false), 2500);
    } catch (err: any) {
      alert(`Settings update failed: ${err.message}`);
    } finally {
      setSavingSettings(false);
    }
  };

  const handleAddRule = async () => {
    if (!newKeyword.trim()) return;
    try {
      const res = await api.addRule({ keyword: newKeyword.trim(), categoryId: newRuleCatId });
      onRulesUpdated([...rules, res.rule]);
      setNewKeyword('');
    } catch (err: any) {
      alert(`Rule error: ${err.message}`);
    }
  };

  const handleDeleteRule = async (id: string) => {
    try {
      await api.deleteRule(id);
      onRulesUpdated(rules.filter((r) => r.id !== id));
    } catch (err: any) {
      alert(`Delete rule error: ${err.message}`);
    }
  };

  const handleChangeUserRole = async (userId: string, newRole: UserRole) => {
    try {
      const res = await fetch(`/api/users/${userId}/role`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('expense_capture_token')}`,
        },
        body: JSON.stringify({ role: newRole }),
      });
      if (res.ok) {
        onUsersUpdated(users.map((u) => (u.id === userId ? { ...u, role: newRole } : u)));
      }
    } catch (err: any) {
      alert(`Failed to update role: ${err.message}`);
    }
  };

  const handleToggleApproval = async (userId: string, approved: boolean) => {
    try {
      const res = await api.approveUser(userId, approved);
      if (res.success) {
        onUsersUpdated(
          users.map((u) =>
            u.id === userId
              ? { ...u, isApproved: res.user.isApproved, status: res.user.status }
              : u
          )
        );
      }
    } catch (err: any) {
      alert(`Failed to update approval status: ${err.message}`);
    }
  };

  const pendingUsersCount = users.filter((u) => u.status === 'pending_approval' || u.isApproved === false).length;

  return (
    <div className="space-y-6 animate-in fade-in max-w-7xl mx-auto">
      {/* Settings Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Settings className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Governance & Administration</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Category taxonomy versioning, UAE tax particulars thresholds, keyword rules, and RBAC
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 px-3 py-1.5 rounded-xl border border-indigo-200 dark:border-indigo-800">
            Taxonomy Version: v{taxonomyVersion}
          </span>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar border-b border-slate-200 dark:border-slate-800">
        <button
          onClick={() => setActiveSection('categories')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeSection === 'categories'
              ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Layers className="w-3.5 h-3.5" />
          <span>Category Taxonomy ({categories.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('tax')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeSection === 'tax'
              ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5" />
          <span>Tax & Compliance Rules</span>
        </button>

        <button
          onClick={() => setActiveSection('rules')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeSection === 'rules'
              ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Building2 className="w-3.5 h-3.5" />
          <span>Keyword Overrides ({rules.length})</span>
        </button>

        <button
          onClick={() => setActiveSection('ai')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeSection === 'ai'
              ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-xs font-bold'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>AI Model & Retention</span>
        </button>

        {isAdmin && (
          <button
            onClick={() => setActiveSection('users')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
              activeSection === 'users'
                ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-xs font-bold'
                : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>User Management ({users.length})</span>
            {pendingUsersCount > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full text-[10px] bg-amber-500 text-white font-bold animate-pulse">
                {pendingUsersCount} pending
              </span>
            )}
          </button>
        )}

        <button
          onClick={() => setActiveSection('alerts')}
          className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
            activeSection === 'alerts'
              ? 'bg-red-600 text-white shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
          }`}
        >
          <AlertOctagon className="w-3.5 h-3.5" />
          <span>Red Flag Email Alerts ({emailAlerts.length})</span>
        </button>
      </div>

      {/* SECTION 1: CATEGORIES TAXONOMY */}
      {activeSection === 'categories' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-slate-900 dark:text-white">
                Controlled Starter Taxonomy
              </h3>
              <p className="text-xs text-slate-500">
                AI may strictly choose only from active categories. Categories with history cannot be deleted, only deactivated or merged.
              </p>
            </div>
            {isAdmin && (
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleAddPresetBundle}
                  disabled={addingPresets}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 border border-indigo-200 dark:border-indigo-800 text-indigo-700 dark:text-indigo-300 text-xs font-bold hover:bg-indigo-100 transition cursor-pointer"
                  title="Adds Groceries, Sports, Entertainment, Food, Transportation, Travelling, Charity"
                >
                  <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
                  <span>{addingPresets ? 'Adding Bundle...' : '+ Add Categories Bundle'}</span>
                </button>
                <button
                  onClick={() => setShowMergeModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-300 dark:border-slate-700 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800"
                >
                  <GitMerge className="w-3.5 h-3.5" />
                  Merge Categories
                </button>
                <button
                  onClick={() => {
                    setIsNewCategory(true);
                    setEditingCategory({
                      name: '',
                      glCode: '',
                      vatRecoverability: 'full',
                      corporateTaxTreatment: 'fully_deductible',
                      active: true,
                    });
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-sky-600 text-white text-xs font-bold hover:bg-sky-700"
                >
                  <Plus className="w-3.5 h-3.5" />
                  Add Category
                </button>
              </div>
            )}
          </div>

          {presetSuccessMessage && (
            <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-medium flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{presetSuccessMessage}</span>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                    <th className="p-3.5">Category Name</th>
                    <th className="p-3.5">GL Code</th>
                    <th className="p-3.5">VAT Recoverability</th>
                    <th className="p-3.5">Corporate Tax Treatment</th>
                    <th className="p-3.5">Spend Limit</th>
                    <th className="p-3.5">Status</th>
                    {isAdmin && <th className="p-3.5 text-right">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {categories.map((c) => (
                    <tr
                      key={c.id}
                      className={`hover:bg-slate-50 dark:hover:bg-slate-800/40 ${
                        !c.active ? 'opacity-50 bg-slate-50/30' : ''
                      }`}
                    >
                      <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                        {c.name}
                      </td>
                      <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                        {c.glCode}
                      </td>
                      <td className="p-3.5 capitalize font-semibold text-slate-700 dark:text-slate-300">
                        {c.vatRecoverability}
                      </td>
                      <td className="p-3.5">
                        <span className="text-[11px] font-medium text-slate-700 dark:text-slate-300">
                          {c.corporateTaxTreatment === 'fifty_percent_limited'
                            ? '50% Limited'
                            : c.corporateTaxTreatment === 'fully_deductible'
                            ? '100% Deductible'
                            : 'Non-Deductible'}
                        </span>
                      </td>
                      <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                        {c.spendLimitMinor ? (
                          <span className="inline-flex items-center gap-1 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800/60 px-2 py-0.5 rounded text-[11px] font-semibold text-amber-900 dark:text-amber-200" title="Automated Red Flag email sent on limit breach">
                            <span>{(c.spendLimitMinor / 100).toFixed(2)} AED</span>
                            <span className="text-[10px]">🚨</span>
                          </span>
                        ) : (
                          <span className="text-slate-400">None</span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            c.active
                              ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                              : 'bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                          }`}
                        >
                          {c.active ? 'Active' : 'Deactivated'}
                        </span>
                      </td>
                      {isAdmin && (
                        <td className="p-3.5 text-right whitespace-nowrap">
                          <button
                            onClick={() => {
                              setIsNewCategory(false);
                              setEditingCategory({ ...c });
                            }}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-slate-800 mr-1"
                            title="Edit Category"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          {c.active && (
                            <button
                              onClick={() => handleDeactivateCategory(c)}
                              className="p-1.5 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-slate-800"
                              title="Deactivate Category"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SECTION 2: TAX & COMPLIANCE RULES */}
      {activeSection === 'tax' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6 max-w-3xl">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              UAE / GCC Statutory Tax & Threshold Settings
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Fixed policy checks enforced deterministically in code (not inferred by AI)
            </p>
          </div>

          <div className="space-y-4 text-xs">
            {/* 15-Digit TRN enforcement */}
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-1">
              <span className="font-bold text-slate-800 dark:text-white block">
                15-Digit Tax Registration Number (TRN) Rule
              </span>
              <p className="text-slate-500">
                Mandatory FTA requirement. If VAT is charged without a valid 15-digit TRN, the receipt is automatically flagged as invalid tax invoice.
              </p>
            </div>

            {/* Simplified invoice threshold */}
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Simplified Tax Invoice Threshold (AED)
              </label>
              <input
                type="number"
                disabled={!isAdmin}
                value={localSettings.simplifiedInvoiceThresholdMinor / 100}
                onChange={(e) =>
                  setLocalSettings({
                    ...localSettings,
                    simplifiedInvoiceThresholdMinor: Math.round((parseFloat(e.target.value) || 0) * 100),
                  })
                }
                className="w-full sm:w-64 rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Standard FTA default is 10,000 AED. Invoices above this threshold must include buyer particulars and full itemization.
              </p>
            </div>

            {/* Approval limit threshold */}
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Finance Reviewer Approval Limit (AED)
              </label>
              <input
                type="number"
                disabled={!isAdmin}
                value={localSettings.approvalLimitMinor / 100}
                onChange={(e) =>
                  setLocalSettings({
                    ...localSettings,
                    approvalLimitMinor: Math.round((parseFloat(e.target.value) || 0) * 100),
                  })
                }
                className="w-full sm:w-64 rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Expenses above this threshold require human Reviewer approval even if AI confidence is 100%.
              </p>
            </div>

            {/* Document age threshold */}
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Maximum Document Age (Days)
              </label>
              <input
                type="number"
                disabled={!isAdmin}
                value={localSettings.oldDocumentDays}
                onChange={(e) =>
                  setLocalSettings({
                    ...localSettings,
                    oldDocumentDays: parseInt(e.target.value) || 90,
                  })
                }
                className="w-full sm:w-64 rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Flags expenses older than configured days for statutory claim period audit.
              </p>
            </div>

            {/* Weekend Mode */}
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Weekend Non-Working Days Policy
              </label>
              <select
                disabled={!isAdmin}
                value={localSettings.uaeWeekendMode}
                onChange={(e) =>
                  setLocalSettings({
                    ...localSettings,
                    uaeWeekendMode: e.target.value as 'sat_sun' | 'fri_sat',
                  })
                }
                className="w-full sm:w-64 rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 text-slate-900 dark:text-white"
              >
                <option value="sat_sun">Saturday & Sunday (Current UAE Federal Standard)</option>
                <option value="fri_sat">Friday & Saturday (Regional Alternate)</option>
              </select>
            </div>
          </div>

          {isAdmin && (
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-3">
              <button
                onClick={handleSavePolicySettings}
                disabled={savingSettings}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sky-600 text-white font-bold text-xs shadow-sm hover:bg-sky-700 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>{savingSettings ? 'Saving...' : 'Save Policy Settings'}</span>
              </button>
              {settingsSuccess && (
                <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                  <Check className="w-4 h-4" /> Settings updated
                </span>
              )}
            </div>
          )}
        </div>
      )}

      {/* SECTION 3: KEYWORD OVERRIDE RULES */}
      {activeSection === 'rules' && (
        <div className="space-y-4 max-w-3xl">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Supplier Keyword Override Rules
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Precedence level 3: Matches keywords in supplier name (e.g. ADNOC leads to Fuel) before evaluating AI proposals.
            </p>
          </div>

          {isAdmin && (
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-end gap-3 text-xs">
              <div className="flex-1 w-full">
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Supplier Keyword (e.g. ADNOC, ENOC, Careem)
                </label>
                <input
                  type="text"
                  value={newKeyword}
                  onChange={(e) => setNewKeyword(e.target.value)}
                  placeholder="Keyword to match..."
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 text-slate-900 dark:text-white"
                />
              </div>
              <div className="flex-1 w-full">
                <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  Target Category
                </label>
                <select
                  value={newRuleCatId}
                  onChange={(e) => setNewRuleCatId(e.target.value)}
                  className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 text-slate-900 dark:text-white"
                >
                  {categories.filter((c) => c.active).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              <button
                onClick={handleAddRule}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-sky-600 text-white font-bold text-xs hover:bg-sky-700 shrink-0 cursor-pointer"
              >
                Add Rule
              </button>
            </div>
          )}

          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {rules.map((rule) => (
              <div key={rule.id} className="p-3.5 flex items-center justify-between">
                <div>
                  <span className="font-bold text-slate-900 dark:text-white">
                    "{rule.keyword}"
                  </span>
                  <span className="text-slate-500 mx-2">→</span>
                  <span className="font-semibold text-sky-600 dark:text-sky-400">
                    {rule.categoryName}
                  </span>
                </div>
                {isAdmin && (
                  <button
                    onClick={() => handleDeleteRule(rule.id)}
                    className="p-1 rounded-lg text-slate-400 hover:text-red-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECTION 4: AI MODEL & RETENTION */}
      {activeSection === 'ai' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6 max-w-2xl text-xs">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              AI Vision Model & Retention Governance
            </h3>
            <p className="text-slate-500 mt-0.5">
              Configurable model engine and statutory audit retention policy
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Vision Extraction & Classification Model
              </label>
              <input
                type="text"
                disabled={!isAdmin}
                value={localSettings.geminiModel}
                onChange={(e) => setLocalSettings({ ...localSettings, geminiModel: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Configured Flash-class model: default <code>gemini-3.8-flash</code>. Structured JSON schema enforced at temperature 0.
              </p>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Auto-Approval Confidence Threshold (0.0 to 1.0)
              </label>
              <input
                type="number"
                step="0.05"
                min="0.5"
                max="0.99"
                disabled={!isAdmin}
                value={localSettings.confidenceThreshold}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, confidenceThreshold: parseFloat(e.target.value) || 0.8 })
                }
                className="w-full sm:w-64 rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Below this threshold (default 0.80), receipts route to the Review queue and are not auto-approved.
              </p>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Statutory Document Retention Period (Years)
              </label>
              <input
                type="number"
                disabled={!isAdmin}
                value={localSettings.retentionYears}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, retentionYears: parseInt(e.target.value) || 5 })
                }
                className="w-full sm:w-64 rounded-xl border border-slate-300 dark:border-slate-700 p-2.5 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Default 5 years aligned with UAE Federal Decree-Law No. 28 of 2022 on Tax Procedures (7 years for real estate).
              </p>
            </div>

            {isAdmin && (
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                <button
                  onClick={handleSavePolicySettings}
                  disabled={savingSettings}
                  className="px-5 py-2.5 rounded-xl bg-sky-600 text-white font-bold text-xs hover:bg-sky-700 shadow-sm"
                >
                  Save Model & Retention Settings
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* SECTION 5: USER ROLE & APPROVAL MANAGEMENT */}
      {activeSection === 'users' && isAdmin && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden space-y-0">
          {/* Privacy Guarantee Header */}
          <div className="p-4 sm:p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/20">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Users className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                  <span>User Accounts & Approval Console</span>
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Manage user approvals, account activation, and role assignments (Submitter, Reviewer, Admin, Auditor)
                </p>
              </div>
              {pendingUsersCount > 0 && (
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-xl bg-amber-50 dark:bg-amber-950/60 border border-amber-200 dark:border-amber-800 text-amber-800 dark:text-amber-300 text-xs font-bold">
                  <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>{pendingUsersCount} account{pendingUsersCount > 1 ? 's' : ''} awaiting your approval</span>
                </div>
              )}
            </div>
          </div>

          {/* Zero-Knowledge Privacy Architecture Notice */}
          <div className="p-4 bg-emerald-50/80 dark:bg-emerald-950/30 border-b border-emerald-100 dark:border-emerald-900/40 flex items-start gap-3 text-xs text-emerald-900 dark:text-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="font-bold">Zero-Knowledge Privacy Protection:</strong> System Administrators manage account approvals, permissions, and category taxonomy only. In accordance with organizational privacy controls, Administrators have <strong>zero visibility</strong> into users' personal receipts, invoices, line items, or financial claims.
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-500 font-semibold uppercase text-[11px]">
                  <th className="p-3.5">User Details</th>
                  <th className="p-3.5">Approval Status</th>
                  <th className="p-3.5">Assigned Role</th>
                  <th className="p-3.5">Registered</th>
                  <th className="p-3.5 text-right">Approval Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {users.map((u) => {
                  const isPending = u.status === 'pending_approval' || u.isApproved === false;
                  const isCurrent = u.id === currentUser?.id;

                  return (
                    <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                          <span>{u.name}</span>
                          {isCurrent && (
                            <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-semibold">
                              You
                            </span>
                          )}
                        </div>
                        <div className="text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                          {u.email}
                        </div>
                      </td>
                      <td className="p-3.5">
                        {isPending ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 animate-pulse">
                            <Clock className="w-3 h-3 text-amber-500" />
                            Pending Approval
                          </span>
                        ) : u.status === 'suspended' ? (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800">
                            <XCircle className="w-3 h-3 text-red-500" />
                            Suspended
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-semibold bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
                            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
                            Active & Approved
                          </span>
                        )}
                      </td>
                      <td className="p-3.5">
                        <select
                          value={u.role}
                          disabled={isCurrent}
                          onChange={(e) => handleChangeUserRole(u.id, e.target.value as UserRole)}
                          className="p-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold text-slate-900 dark:text-white disabled:opacity-60 cursor-pointer"
                        >
                          <option value="Submitter">Submitter</option>
                          <option value="Reviewer">Reviewer (Finance Team)</option>
                          <option value="Admin">Admin (User & Rules Mgmt)</option>
                          <option value="Auditor">Auditor (Read-Only)</option>
                        </select>
                      </td>
                      <td className="p-3.5 text-slate-500 text-[11px] font-mono">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </td>
                      <td className="p-3.5 text-right">
                        {isPending ? (
                          <button
                            onClick={() => handleToggleApproval(u.id, true)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition active:scale-98 cursor-pointer"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>Approve User</span>
                          </button>
                        ) : isCurrent ? (
                          <span className="text-[11px] text-slate-400 font-medium">System Admin</span>
                        ) : (
                          <button
                            onClick={() => handleToggleApproval(u.id, false)}
                            className="text-xs text-slate-500 hover:text-red-600 font-semibold transition cursor-pointer px-2 py-1 rounded-lg hover:bg-red-50 dark:hover:bg-red-950/40"
                          >
                            Revoke Access
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* SECTION 6: RED FLAG EMAIL ALERTS AUDIT */}
      {activeSection === 'alerts' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <AlertOctagon className="w-5 h-5 text-red-600" />
                <span>Dispatched Red Flag Email Alerts</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Automated email notices dispatched whenever a transaction causes a category to breach its monthly spend limit.
              </p>
            </div>
            <button
              onClick={loadAlerts}
              className="text-xs text-sky-600 hover:underline font-semibold self-start sm:self-auto cursor-pointer"
            >
              Refresh Log
            </button>
          </div>

          {loadingAlerts ? (
            <div className="py-12 flex justify-center">
              <div className="w-8 h-8 border-3 border-sky-600 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : emailAlerts.length === 0 ? (
            <div className="p-12 text-center rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs text-slate-400 space-y-2">
              <Check className="w-8 h-8 text-emerald-500 mx-auto" />
              <p className="font-semibold text-slate-600 dark:text-slate-300">No budget breaches detected</p>
              <p>All category expenditures remain within their configured spend limits. When a breach occurs, automated Red Flag email records will appear here.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                    <th className="p-3.5">Timestamp</th>
                    <th className="p-3.5">Recipient</th>
                    <th className="p-3.5">Category</th>
                    <th className="p-3.5">Spend Limit</th>
                    <th className="p-3.5">Total Spend</th>
                    <th className="p-3.5">Breach Amount</th>
                    <th className="p-3.5">Status</th>
                    <th className="p-3.5 text-right">Email Notice</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-mono">
                  {emailAlerts.map((a) => (
                    <tr key={a.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                      <td className="p-3.5 text-slate-500 text-[11px]">
                        {new Date(a.triggeredAt).toLocaleString()}
                      </td>
                      <td className="p-3.5 font-sans font-semibold text-slate-800 dark:text-slate-200">
                        {a.recipientName}
                        <span className="block text-[10px] text-slate-400 font-mono">{a.recipientEmail}</span>
                      </td>
                      <td className="p-3.5 font-sans font-bold text-slate-900 dark:text-white">
                        {a.categoryName}
                      </td>
                      <td className="p-3.5 text-slate-600 dark:text-slate-300">
                        {(a.spendLimitMinor / 100).toFixed(2)} AED
                      </td>
                      <td className="p-3.5 font-bold text-red-600">
                        {(a.currentSpendMinor / 100).toFixed(2)} AED
                      </td>
                      <td className="p-3.5 font-bold text-red-600">
                        +{(a.breachAmountMinor / 100).toFixed(2)} AED
                      </td>
                      <td className="p-3.5">
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 uppercase">
                          {a.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-right">
                        <button
                          onClick={() => setSelectedAlertForModal(a)}
                          className="px-2.5 py-1 rounded-lg bg-red-50 hover:bg-red-100 dark:bg-red-950 dark:hover:bg-red-900 text-red-700 dark:text-red-300 text-[11px] font-bold font-sans inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Mail className="w-3 h-3" /> View Email
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Dispatched Alert Preview Modal */}
      {selectedAlertForModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-lg rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-red-200 dark:border-red-900 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2 text-red-600 dark:text-red-400">
                <AlertOctagon className="w-5 h-5" />
                <h3 className="text-sm font-bold">Red Flag Email Dispatch</h3>
              </div>
              <button
                onClick={() => setSelectedAlertForModal(null)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-sm font-bold p-1 cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs space-y-1 font-mono">
              <div><span className="text-slate-400">To:</span> {selectedAlertForModal.recipientName} &lt;{selectedAlertForModal.recipientEmail}&gt;</div>
              <div><span className="text-slate-400">Subject:</span> <strong className="text-red-700 dark:text-red-400">{selectedAlertForModal.subject}</strong></div>
              <div><span className="text-slate-400">Date:</span> {new Date(selectedAlertForModal.triggeredAt).toLocaleString()}</div>
              <div><span className="text-slate-400">Delivery:</span> <span className="text-emerald-600 font-bold">Delivered (Automated Alert Engine)</span></div>
            </div>

            <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/90 text-xs text-slate-800 dark:text-slate-200 whitespace-pre-wrap font-mono leading-relaxed border border-slate-200 dark:border-slate-700">
              {selectedAlertForModal.body}
            </div>

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedAlertForModal(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 text-white dark:bg-white dark:text-slate-900 text-xs font-bold cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Edit / Add Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {isNewCategory ? 'Add New Category' : `Edit Category: ${editingCategory.name}`}
            </h3>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Category Name
              </label>
              <input
                type="text"
                value={editingCategory.name || ''}
                onChange={(e) => setEditingCategory({ ...editingCategory, name: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                GL Code
              </label>
              <input
                type="text"
                value={editingCategory.glCode || ''}
                onChange={(e) => setEditingCategory({ ...editingCategory, glCode: e.target.value })}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 font-mono text-slate-900 dark:text-white"
              />
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                VAT Recoverability
              </label>
              <select
                value={editingCategory.vatRecoverability || 'full'}
                onChange={(e) =>
                  setEditingCategory({
                    ...editingCategory,
                    vatRecoverability: e.target.value as any,
                  })
                }
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
              >
                <option value="full">Full (100% recoverable input tax)</option>
                <option value="none">None (Blocked / Entertainment / Personal)</option>
                <option value="exempt">Exempt (0% VAT)</option>
                <option value="review">Review (Requires manual tax review)</option>
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Corporate Tax Treatment
              </label>
              <select
                value={editingCategory.corporateTaxTreatment || 'fully_deductible'}
                onChange={(e) =>
                  setEditingCategory({
                    ...editingCategory,
                    corporateTaxTreatment: e.target.value as any,
                  })
                }
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
              >
                <option value="fully_deductible">Fully Deductible (100%)</option>
                <option value="fifty_percent_limited">50% Limited (Meals & Entertainment Art. 32)</option>
                <option value="non_deductible">Non-Deductible (Personal / Fines)</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="font-semibold text-slate-700 dark:text-slate-300 block">
                  Monthly Spend Limit (AED)
                </label>
                <span className="text-[10px] text-amber-600 dark:text-amber-400 font-medium">
                  🚨 Red Flag alert on breach
                </span>
              </div>
              <input
                type="number"
                value={editingCategory.spendLimitMinor ? editingCategory.spendLimitMinor / 100 : ''}
                onChange={(e) =>
                  setEditingCategory({
                    ...editingCategory,
                    spendLimitMinor: e.target.value ? Math.round(parseFloat(e.target.value) * 100) : undefined,
                  })
                }
                placeholder="e.g. 1500 (Optional)"
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 font-mono text-slate-900 dark:text-white"
              />
              <p className="text-[10px] text-slate-500 mt-1">
                When calendar-month expenses in this category exceed this limit, an automated Red Flag alert email is sent to the submitter and finance team.
              </p>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setEditingCategory(null)}
                className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCategory}
                className="px-5 py-2 rounded-xl bg-sky-600 text-white font-bold hover:bg-sky-700"
              >
                Save Category
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Category Merge Modal */}
      {showMergeModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-md rounded-2xl bg-white dark:bg-slate-900 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 space-y-4 text-xs">
            <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <GitMerge className="w-5 h-5 text-purple-600" />
              <span>Merge Two Categories</span>
            </h3>
            <p className="text-slate-500">
              Merging remaps all old transaction records to the target category while deactivating the source category. The original value is preserved in the audit trail.
            </p>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Source Category (Will be deactivated & remapped)
              </label>
              <select
                value={mergeSourceId}
                onChange={(e) => setMergeSourceId(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
              >
                <option value="">Select source category...</option>
                {categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} (GL: {c.glCode})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                Target Category (Will absorb records)
              </label>
              <select
                value={mergeTargetId}
                onChange={(e) => setMergeTargetId(e.target.value)}
                className="w-full rounded-xl border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
              >
                <option value="">Select target category...</option>
                {categories
                  .filter((c) => c.id !== mergeSourceId && c.active)
                  .map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} (GL: {c.glCode})
                    </option>
                  ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={() => setShowMergeModal(false)}
                className="px-4 py-2 rounded-xl text-slate-600 dark:text-slate-300 font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleExecuteMerge}
                className="px-5 py-2 rounded-xl bg-purple-600 text-white font-bold hover:bg-purple-700"
              >
                Execute Merge
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
