import React, { useState } from 'react';
import {
  TableProperties,
  Search,
  Filter,
  Download,
  FileSpreadsheet,
  History,
  Eye,
  Calendar,
  Building2,
  Tag,
  ArrowRight,
  X,
  ShieldCheck,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { Receipt, Category, AuditLogEntry } from '../types';
import { api } from '../services/api';
import { SideBySideReview } from '../components/SideBySideReview';
import { useLanguage } from '../context/LanguageContext';

interface TransactionsTableViewProps {
  receipts: Receipt[];
  categories: Category[];
  auditLogs: AuditLogEntry[];
  onReceiptUpdated: (updated: Receipt) => void;
  onNavigateToCapture?: () => void;
}

export const TransactionsTableView: React.FC<TransactionsTableViewProps> = ({
  receipts,
  categories,
  auditLogs,
  onReceiptUpdated,
  onNavigateToCapture,
}) => {
  const { t } = useLanguage();
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedReceiptForReview, setSelectedReceiptForReview] = useState<Receipt | null>(null);
  const [selectedAuditReceiptId, setSelectedAuditReceiptId] = useState<string | null>(null);
  const [showGlobalAuditModal, setShowGlobalAuditModal] = useState(false);

  // If no receipts, render plain-words empty state
  if (receipts.length === 0) {
    return (
      <div className="p-12 text-center rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs max-w-xl mx-auto space-y-4 my-8 animate-in fade-in">
        <div className="w-16 h-16 rounded-2xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto">
          <TableProperties className="w-8 h-8" />
        </div>
        <h3 className="text-lg font-bold text-slate-900 dark:text-white">
          {t('emptyTitle')}
        </h3>
        <p className="text-sm text-slate-500 leading-relaxed">
          {t('emptySubtitle')}. All receipts, line-item splits, GL codes, tax classifications, and CSV/Excel exports will be tabulated here with searchable filters.
        </p>
        {onNavigateToCapture && (
          <button
            onClick={onNavigateToCapture}
            className="mt-4 px-5 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition inline-flex items-center gap-2 cursor-pointer"
          >
            {t('navCapture')} <ArrowRight className="w-4 h-4" />
          </button>
        )}
      </div>
    );
  }

  // Filter receipts
  const filtered = receipts.filter((r) => {
    const q = searchTerm.toLowerCase();
    const matchesSearch =
      !searchTerm ||
      (r.supplierName && r.supplierName.toLowerCase().includes(q)) ||
      (r.invoiceNumber && r.invoiceNumber.toLowerCase().includes(q)) ||
      (r.trn && r.trn.includes(q)) ||
      (r.categoryName && r.categoryName.toLowerCase().includes(q));

    const matchesCategory = categoryFilter === 'all' || r.categoryId === categoryFilter;
    const matchesStatus = statusFilter === 'all' || r.status === statusFilter;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  const handleExportCsv = () => {
    window.location.href = '/api/export/csv';
  };

  const handleExportAccounting = () => {
    window.location.href = '/api/export/accounting';
  };

  const receiptAuditLogs = selectedAuditReceiptId
    ? auditLogs.filter((log) => log.receiptId === selectedAuditReceiptId)
    : [];

  return (
    <div className="space-y-6 animate-in fade-in max-w-7xl mx-auto">
      {/* Header and Export Toolbar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <TableProperties className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <span>Master Transaction Ledger & Audit</span>
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Full GL ledger with tax treatment columns, export options, and immutable audit logs
          </p>
        </div>

        {/* Export Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowGlobalAuditModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition cursor-pointer"
            title="Inspect full immutable system audit log"
          >
            <History className="w-3.5 h-3.5" />
            <span>Audit Trail</span>
          </button>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-300 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-300 transition cursor-pointer"
            title="Export CSV (Sanitized against formula injection)"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{t('exportCsv')}</span>
          </button>

          <button
            onClick={handleExportAccounting}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition cursor-pointer active:scale-95"
            title="Export journal entries ready for ERP / accounting system"
          >
            <FileSpreadsheet className="w-3.5 h-3.5" />
            <span>{t('exportAccounting')}</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs">
        <div className="sm:col-span-5 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by supplier, invoice #, 15-digit TRN, or category..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
          />
        </div>

        <div className="sm:col-span-4">
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-medium"
          >
            <option value="all">All Categories ({categories.length})</option>
            {categories.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} (GL: {c.glCode})
              </option>
            ))}
          </select>
        </div>

        <div className="sm:col-span-3">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full p-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-medium capitalize"
          >
            <option value="all">All Statuses</option>
            <option value="approved">Approved</option>
            <option value="in_review">In Review</option>
            <option value="rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Main Ledger Table */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 font-semibold uppercase tracking-wider text-[11px]">
                <th className="p-3.5">Date</th>
                <th className="p-3.5">Supplier / TRN</th>
                <th className="p-3.5">Invoice #</th>
                <th className="p-3.5">Category & GL</th>
                <th className="p-3.5">Net (AED)</th>
                <th className="p-3.5">VAT (AED)</th>
                <th className="p-3.5">Total (AED)</th>
                <th className="p-3.5">VAT Recov.</th>
                <th className="p-3.5">CT Treatment</th>
                <th className="p-3.5">Status</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {filtered.map((r) => (
                <tr
                  key={r.id}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition"
                >
                  <td className="p-3.5 font-mono text-slate-600 dark:text-slate-300 whitespace-nowrap">
                    {r.invoiceDate || <span className="text-amber-500 italic">null</span>}
                  </td>

                  <td className="p-3.5">
                    <span className="font-bold text-slate-900 dark:text-white block">
                      {r.supplierName || 'Unknown'}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {r.trn ? `TRN: ${r.trn}` : 'No TRN'}
                    </span>
                  </td>

                  <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                    {r.invoiceNumber || '—'}
                  </td>

                  <td className="p-3.5">
                    <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                      {r.categoryName}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      GL {r.glCode} • v{r.taxonomyVersion || 1}
                    </span>
                  </td>

                  <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                    {(r.netAmountMinor / 100).toFixed(2)}
                  </td>

                  <td className="p-3.5 font-mono text-slate-700 dark:text-slate-300">
                    {(r.vatAmountMinor / 100).toFixed(2)}
                  </td>

                  <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">
                    {(r.totalAedMinor / 100).toFixed(2)}
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded capitalize ${
                        r.vatRecoverability === 'full'
                          ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300'
                          : r.vatRecoverability === 'none'
                          ? 'bg-red-50 text-red-700 dark:bg-red-950 dark:text-red-300'
                          : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {r.vatRecoverability} ({(r.recoverableVatMinor / 100).toFixed(2)})
                    </span>
                  </td>

                  <td className="p-3.5">
                    <span className="text-[10px] font-medium text-slate-600 dark:text-slate-400">
                      {r.corporateTaxTreatment === 'fifty_percent_limited'
                        ? '50% Limited'
                        : r.corporateTaxTreatment === 'fully_deductible'
                        ? '100% Deductible'
                        : 'Non-Deductible'}
                    </span>
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                        r.status === 'approved'
                          ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                          : r.status === 'rejected'
                          ? 'bg-red-100 text-red-800 dark:bg-red-950 dark:text-red-300'
                          : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                      }`}
                    >
                      {r.status.replace('_', ' ')}
                    </span>
                  </td>

                  <td className="p-3.5 text-right whitespace-nowrap">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        onClick={() => setSelectedReceiptForReview(r)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-sky-600 hover:bg-sky-50 dark:hover:bg-slate-800"
                        title="View Document & Particulars"
                      >
                        <Eye className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setSelectedAuditReceiptId(r.id)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-purple-600 hover:bg-purple-50 dark:hover:bg-slate-800"
                        title="View Audit Trail for this receipt"
                      >
                        <History className="w-4 h-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Side-by-Side Review Modal */}
      {selectedReceiptForReview && (
        <SideBySideReview
          receipt={selectedReceiptForReview}
          categories={categories}
          onClose={() => setSelectedReceiptForReview(null)}
          onReceiptUpdated={(updated) => {
            onReceiptUpdated(updated);
            setSelectedReceiptForReview(null);
          }}
        />
      )}

      {/* Receipt Specific Audit Trail Drawer/Modal */}
      {selectedAuditReceiptId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-2xl rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-purple-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Audit History for Receipt #{selectedAuditReceiptId.substring(0, 8)}
                </h3>
              </div>
              <button
                onClick={() => setSelectedAuditReceiptId(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto my-4 space-y-3 pr-1 text-xs">
              {receiptAuditLogs.length > 0 ? (
                receiptAuditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-1.5"
                  >
                    <div className="flex items-center justify-between font-semibold text-slate-800 dark:text-slate-200">
                      <span className="capitalize text-indigo-600 dark:text-indigo-400 font-bold">
                        {log.action.replace('_', ' ')}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">
                        {new Date(log.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <p className="text-slate-700 dark:text-slate-300">{log.details}</p>
                    <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1 border-t border-slate-100 dark:border-slate-700/60">
                      <span>User: {log.userName} ({log.userRole})</span>
                      {log.aiModelName && (
                        <span>Model: {log.aiModelName} ({log.promptVersion})</span>
                      )}
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-slate-400 italic text-center py-6">No historical audit events logged for this item.</p>
              )}
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 text-right">
              <button
                onClick={() => setSelectedAuditReceiptId(null)}
                className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Global Immutable System Audit Trail Modal */}
      {showGlobalAuditModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="w-full max-w-3xl rounded-2xl bg-white dark:bg-slate-900 shadow-2xl border border-slate-200 dark:border-slate-800 p-6 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-purple-600" />
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  Immutable System Audit Trail ({auditLogs.length} events)
                </h3>
              </div>
              <button
                onClick={() => setShowGlobalAuditModal(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto my-4 space-y-2.5 pr-1 text-xs font-mono">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40 space-y-1"
                >
                  <div className="flex items-center justify-between text-slate-500 text-[10px]">
                    <span className="font-bold text-purple-600 dark:text-purple-400 uppercase">
                      [{log.action}]
                    </span>
                    <span>{new Date(log.timestamp).toISOString()}</span>
                  </div>
                  <p className="text-slate-900 dark:text-white font-sans text-xs">{log.details}</p>
                  <div className="text-[10px] text-slate-400 flex items-center justify-between">
                    <span>By: {log.userName} ({log.userRole})</span>
                    {log.receiptId && <span>Receipt #{log.receiptId.substring(0, 8)}</span>}
                  </div>
                </div>
              ))}
            </div>

            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
              <button
                onClick={() => setShowGlobalAuditModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-bold"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
