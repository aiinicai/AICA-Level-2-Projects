import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Mail,
  FileText,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  RefreshCw,
  FolderOpen,
  ArrowRight,
  Info,
  ShieldCheck,
  Zap,
  Clock,
  X,
  FileUp,
  RotateCw,
  ShieldAlert,
  ChevronRight,
  Eye,
} from 'lucide-react';
import { analyzeImageQuality } from '../services/imageQuality';
import { saveToOfflineQueue } from '../services/offlineQueue';
import { api } from '../services/api';
import { QualityCheckResult, Receipt, BulkUploadItem } from '../types';
import { ImageQualityModal } from '../components/ImageQualityModal';
import { useLanguage } from '../context/LanguageContext';

interface CaptureViewProps {
  onReceiptProcessed: (receipt: Receipt) => void;
  hasExistingTransactions: boolean;
  onNavigateToReview?: () => void;
}

export const CaptureView: React.FC<CaptureViewProps> = ({
  onReceiptProcessed,
  hasExistingTransactions,
  onNavigateToReview,
}) => {
  const { t } = useLanguage();
  const [activeTab, setActiveTab] = useState<'upload' | 'camera' | 'email'>('upload');

  // File Upload State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragActive, setDragActive] = useState(false);
  const [dragCount, setDragCount] = useState(0);

  // Individual item progress tracking queue
  const [uploadQueue, setUploadQueue] = useState<BulkUploadItem[]>([]);
  const [isProcessingQueue, setIsProcessingQueue] = useState(false);

  // Quality check modal state for manual single-file inspection
  const [pendingFile, setPendingFile] = useState<{
    file: File;
    base64: string;
    quality: QualityCheckResult & { perceptualHash: string };
    queueItemId?: string;
  } | null>(null);

  // Live Camera state
  const videoRef = useRef<HTMLVideoElement>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);

  // Email Forwarding simulator state
  const [forwardSender, setForwardSender] = useState('employee@company.ae');
  const [forwardSubject, setForwardSubject] = useState('Invoice from ADNOC Oasis Station');
  const [forwarding, setForwarding] = useState(false);
  const [forwardSuccess, setForwardSuccess] = useState(false);

  // Format file size
  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // -------------------------------------------------------------
  // CAMERA CAPTURE LOGIC
  // -------------------------------------------------------------
  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      });
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch (err: any) {
      console.error('Camera access failed:', err);
      alert('Camera access was denied or not supported by this browser. You can still upload photos from your device.');
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((t) => t.stop());
      setCameraStream(null);
    }
    setCameraActive(false);
  };

  const capturePhoto = async () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 1280;
    canvas.height = videoRef.current.videoHeight || 720;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
    const base64 = canvas.toDataURL('image/jpeg', 0.92);
    stopCamera();

    const blob = await (await fetch(base64)).blob();
    const file = new File([blob], `camera_capture_${Date.now()}.jpg`, { type: 'image/jpeg' });
    handleFilesSelected([file]);
  };

  // -------------------------------------------------------------
  // ENHANCED MULTI-FILE UPLOAD & INDIVIDUAL ITEM PROGRESS QUEUE
  // -------------------------------------------------------------
  const handleFilesSelected = (files: FileList | File[]) => {
    const fileList = Array.from(files);
    if (fileList.length === 0) return;

    // Create item entries with initial queued state
    const newItems: BulkUploadItem[] = fileList.map((file) => {
      const isImage = file.type.startsWith('image/');
      let previewUrl: string | undefined = undefined;
      if (isImage) {
        previewUrl = URL.createObjectURL(file);
      }

      return {
        id: `upload-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        file,
        fileName: file.name,
        fileSize: file.size,
        fileType: file.type || 'image/jpeg',
        previewUrl,
        status: 'queued',
        progress: 10,
        stageMessage: 'Queued for processing...',
      };
    });

    setUploadQueue((prev) => [...prev, ...newItems]);

    // Process new items sequentially with live per-item updates
    processBatchQueue(newItems);
  };

  const updateItemInQueue = (id: string, updates: Partial<BulkUploadItem>) => {
    setUploadQueue((prev) => prev.map((item) => (item.id === id ? { ...item, ...updates } : item)));
  };

  const processBatchQueue = async (itemsToProcess: BulkUploadItem[]) => {
    setIsProcessingQueue(true);

    for (const item of itemsToProcess) {
      await processSingleQueueItem(item);
    }

    setIsProcessingQueue(false);
  };

  const processSingleQueueItem = async (item: BulkUploadItem) => {
    const file = item.file;
    const isPdf = file.type === 'application/pdf';

    try {
      // Stage 1: Reading file
      updateItemInQueue(item.id, {
        status: 'checking_quality',
        progress: 25,
        stageMessage: isPdf ? 'Reading PDF document...' : 'Analyzing image clarity, blur & glare...',
      });

      const base64 = await readFileAsBase64(file);

      // Stage 2: Quality Inspection for images
      let pHash: string | undefined = undefined;
      let qualityResult: QualityCheckResult | undefined = undefined;

      if (!isPdf) {
        try {
          const q = await analyzeImageQuality(base64);
          qualityResult = q;
          pHash = q.perceptualHash;

          if (!q.isAcceptable) {
            // Document has blur or glare issues
            updateItemInQueue(item.id, {
              quality: q,
              stageMessage: q.isBlurry
                ? `Clarity alert: Blur detected (${q.blurVariance} / 45 variance)`
                : `Clarity alert: Overexposure/glare detected (${q.glarePercentage}%)`,
              progress: 40,
            });
          }
        } catch (qErr) {
          console.warn('Quality analysis skipped:', qErr);
        }
      }

      // Check if offline
      if (!navigator.onLine) {
        saveToOfflineQueue({
          imageBase64: base64,
          fileName: file.name,
          fileType: file.type,
          costCentre: 'Field Expense',
        });
        updateItemInQueue(item.id, {
          status: 'completed',
          progress: 100,
          stageMessage: 'Stored in offline queue (Will auto-sync when online)',
        });
        return;
      }

      // Stage 3: Vision AI Extraction & Tax Verification
      updateItemInQueue(item.id, {
        status: 'extracting_ai',
        progress: 65,
        stageMessage: 'Extracting printed text via Gemini Flash Vision & verifying 5% VAT...',
      });

      const res = await api.processReceipt({
        imageBase64: base64,
        fileName: file.name,
        fileType: file.type,
        perceptualHash: pHash,
        costCentre: 'General Operations',
      });

      // Stage 4: Completed
      const rcpt = res.receipt;
      const flagsCount = rcpt.policyFlags?.length || 0;
      const budgetBreached = rcpt.policyFlags?.some((f) => f.code === 'CATEGORY_BUDGET_BREACHED');

      updateItemInQueue(item.id, {
        status: 'completed',
        progress: 100,
        receipt: rcpt,
        stageMessage: budgetBreached
          ? `🚨 Breached: ${rcpt.categoryName} (${(rcpt.totalAedMinor / 100).toFixed(2)} AED) - Red flag alert sent!`
          : flagsCount > 0
          ? `Verified: ${rcpt.supplierName || 'Merchant'} • ${(rcpt.totalAedMinor / 100).toFixed(2)} AED (${flagsCount} flag${flagsCount > 1 ? 's' : ''})`
          : `Verified: ${rcpt.supplierName || 'Merchant'} • ${(rcpt.totalAedMinor / 100).toFixed(2)} AED (${rcpt.categoryName})`,
      });

      onReceiptProcessed(rcpt);
    } catch (err: any) {
      console.error(`Error processing ${file.name}:`, err);
      updateItemInQueue(item.id, {
        status: 'error',
        progress: 0,
        error: err.message || 'AI extraction failed',
        stageMessage: `Error: ${err.message || 'AI extraction failed'}`,
      });
    }
  };

  const handleRetryItem = async (itemId: string) => {
    const item = uploadQueue.find((i) => i.id === itemId);
    if (!item) return;

    updateItemInQueue(itemId, {
      status: 'queued',
      progress: 10,
      stageMessage: 'Retrying processing...',
      error: undefined,
    });

    await processSingleQueueItem(item);
  };

  const handleRemoveItem = (itemId: string) => {
    setUploadQueue((prev) => prev.filter((i) => i.id !== itemId));
  };

  const handleClearCompleted = () => {
    setUploadQueue((prev) => prev.filter((i) => i.status !== 'completed'));
  };

  const readFileAsBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target?.result as string);
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  };

  // Overall batch statistics
  const totalQueueCount = uploadQueue.length;
  const completedQueueCount = uploadQueue.filter((i) => i.status === 'completed').length;
  const errorQueueCount = uploadQueue.filter((i) => i.status === 'error').length;
  const inProgressQueueCount = uploadQueue.filter((i) => i.status === 'checking_quality' || i.status === 'extracting_ai' || i.status === 'queued').length;
  const batchOverallProgress = totalQueueCount > 0 ? Math.round((completedQueueCount / totalQueueCount) * 100) : 0;

  return (
    <div className="space-y-6 animate-in fade-in max-w-5xl mx-auto">
      {/* Empty State Banner (Required by prompt: plain words explaining next step) */}
      {!hasExistingTransactions && (
        <div className="p-6 rounded-2xl bg-gradient-to-r from-indigo-500/10 via-violet-500/5 to-transparent border border-indigo-200 dark:border-indigo-900/60 shadow-xs">
          <div className="flex items-start gap-4">
            <div className="p-3 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white shadow-md shadow-indigo-600/30 shrink-0">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                {t('emptySubtitle')}
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-300 mt-1 leading-relaxed">
                Take a photo of a physical receipt, upload multiple scans at once, or drop multi-page PDF invoices.
                The Gemini Vision model extracts printed supplier names, 15-digit TRNs, line items, and VAT amounts, while automated code validates UAE/GCC tax rules and budget limits.
              </p>
              <div className="flex flex-wrap gap-2 mt-3 text-[11px] font-semibold text-indigo-700 dark:text-indigo-300">
                <span className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded-md border border-indigo-100 dark:border-indigo-800 shadow-2xs">
                  ✓ Bulk Drag-and-Drop with Live Progress
                </span>
                <span className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded-md border border-indigo-100 dark:border-indigo-800 shadow-2xs">
                  ✓ English & Arabic Document Extraction
                </span>
                <span className="bg-white dark:bg-slate-800 px-2.5 py-1 rounded-md border border-indigo-100 dark:border-indigo-800 shadow-2xs">
                  ✓ Red Flag Alert on Category Budget Breach
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Capture Mode Tabs */}
      <div className="flex items-center justify-center sm:justify-start gap-1 p-1 bg-slate-200/60 dark:bg-slate-800/60 rounded-xl w-fit mx-auto sm:mx-0">
        <button
          onClick={() => {
            stopCamera();
            setActiveTab('upload');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeTab === 'upload'
              ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-300 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Upload className="w-3.5 h-3.5" />
          <span>Enhanced Bulk Upload</span>
          {uploadQueue.length > 0 && (
            <span className="bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 text-[10px] font-bold px-1.5 py-0.2 rounded-full">
              {uploadQueue.length}
            </span>
          )}
        </button>

        <button
          onClick={() => {
            setActiveTab('camera');
            startCamera();
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeTab === 'camera'
              ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-300 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Camera className="w-3.5 h-3.5" />
          <span>{t('captureTabCamera')}</span>
        </button>

        <button
          onClick={() => {
            stopCamera();
            setActiveTab('email');
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
            activeTab === 'email'
              ? 'bg-white dark:bg-slate-900 text-indigo-700 dark:text-indigo-300 shadow-xs'
              : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
          }`}
        >
          <Mail className="w-3.5 h-3.5" />
          <span>{t('captureTabEmail')}</span>
        </button>
      </div>

      {/* TAB 1: ENHANCED MULTI-FILE DRAG-AND-DROP ZONE WITH LIVE PROGRESS */}
      {activeTab === 'upload' && (
        <div className="space-y-6">
          {/* Enhanced Dropzone */}
          <div
            onDragEnter={(e) => {
              e.preventDefault();
              setDragActive(true);
              setDragCount(e.dataTransfer.items ? e.dataTransfer.items.length : 1);
            }}
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={(e) => {
              e.preventDefault();
              setDragActive(false);
            }}
            onDrop={(e) => {
              e.preventDefault();
              setDragActive(false);
              if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
                handleFilesSelected(e.dataTransfer.files);
              }
            }}
            onClick={() => fileInputRef.current?.click()}
            className={`relative rounded-3xl p-8 sm:p-12 text-center transition-all duration-200 cursor-pointer flex flex-col items-center justify-center gap-4 border-2 border-dashed ${
              dragActive
                ? 'border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/40 ring-8 ring-indigo-500/10 scale-[1.01]'
                : 'border-slate-300 dark:border-slate-700 hover:border-indigo-500 hover:bg-slate-50/70 dark:hover:bg-slate-800/40 bg-white dark:bg-slate-900 shadow-xs'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              multiple
              accept="image/jpeg,image/png,image/webp,application/pdf"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files.length > 0) {
                  handleFilesSelected(e.target.files);
                  // Reset input so re-selecting same files triggers change
                  e.target.value = '';
                }
              }}
            />

            {/* Icon & Counter Badge */}
            <div className="relative">
              <div className="w-18 h-18 rounded-3xl bg-gradient-to-tr from-indigo-600 via-indigo-500 to-violet-500 text-white flex items-center justify-center shadow-lg shadow-indigo-500/25">
                <FileUp className="w-9 h-9" />
              </div>
              {dragActive && (
                <div className="absolute -top-2 -right-2 bg-emerald-600 text-white text-xs font-bold px-2 py-0.5 rounded-full shadow-md animate-bounce">
                  Drop {dragCount > 1 ? `${dragCount} files` : 'file'}
                </div>
              )}
            </div>

            {/* Typography */}
            <div className="space-y-1.5 max-w-lg">
              <h3 className="text-base sm:text-xl font-bold text-slate-900 dark:text-white tracking-tight">
                Drop multiple invoices or receipts here
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                Supports bulk uploading of high-resolution JPG, PNG, WebP, and multi-page PDF documents.
                Each file is processed through AI extraction with individual progress tracking.
              </p>
            </div>

            {/* Button */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-1">
              <button
                type="button"
                className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 text-white text-xs font-bold shadow-md shadow-indigo-600/25 transition active:scale-95 flex items-center gap-2 cursor-pointer"
              >
                <FolderOpen className="w-4 h-4" />
                <span>Browse Multiple Files</span>
              </button>
            </div>

            {/* Format Badges */}
            <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400 dark:text-slate-500">
              <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">PDF</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">JPEG</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">PNG</span>
              <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded">WEBP</span>
              <span>• Max 35MB per file</span>
            </div>
          </div>

          {/* INDIVIDUAL ITEM PROGRESS QUEUE */}
          {uploadQueue.length > 0 && (
            <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 shadow-xs space-y-4">
              {/* Batch Summary Bar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      Upload & Processing Queue
                    </h4>
                    <span className="text-xs font-mono font-semibold text-slate-500">
                      ({completedQueueCount} of {totalQueueCount} completed)
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-slate-500 mt-1">
                    {inProgressQueueCount > 0 && (
                      <span className="text-sky-600 dark:text-sky-400 font-semibold flex items-center gap-1">
                        <RefreshCw className="w-3 h-3 animate-spin" />
                        {inProgressQueueCount} in progress
                      </span>
                    )}
                    {errorQueueCount > 0 && (
                      <span className="text-red-600 font-semibold flex items-center gap-1">
                        <AlertCircle className="w-3 h-3" />
                        {errorQueueCount} failed
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {completedQueueCount > 0 && onNavigateToReview && (
                    <button
                      onClick={onNavigateToReview}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <span>Review Invoices</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                  {completedQueueCount > 0 && (
                    <button
                      onClick={handleClearCompleted}
                      className="px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 text-xs font-semibold hover:bg-slate-50 dark:hover:bg-slate-800 transition cursor-pointer"
                    >
                      Clear Completed
                    </button>
                  )}
                </div>
              </div>

              {/* Overall Batch Progress Meter */}
              <div className="w-full bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-indigo-500 via-violet-500 to-emerald-500 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${batchOverallProgress}%` }}
                />
              </div>

              {/* Individual Item Cards */}
              <div className="space-y-3 max-h-[500px] overflow-y-auto pr-1">
                {uploadQueue.map((item) => {
                  const isCompleted = item.status === 'completed';
                  const isError = item.status === 'error';
                  const isExtracting = item.status === 'extracting_ai';
                  const isCheckingQuality = item.status === 'checking_quality';
                  const budgetBreached = item.receipt?.policyFlags?.some(
                    (f) => f.code === 'CATEGORY_BUDGET_BREACHED'
                  );

                  return (
                    <div
                      key={item.id}
                      className={`p-3.5 rounded-2xl border transition-all ${
                        isError
                          ? 'border-red-200 dark:border-red-900/40 bg-red-50/30 dark:bg-red-950/20'
                          : budgetBreached
                          ? 'border-amber-300 dark:border-amber-800 bg-amber-50/40 dark:bg-amber-950/20'
                          : isCompleted
                          ? 'border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/20 dark:bg-emerald-950/10'
                          : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/40'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        {/* Thumbnail / Icon */}
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <div className="w-12 h-12 rounded-xl bg-slate-200 dark:bg-slate-800 overflow-hidden shrink-0 flex items-center justify-center border border-slate-300 dark:border-slate-700">
                            {item.previewUrl ? (
                              <img
                                src={item.previewUrl}
                                alt="thumb"
                                className="w-full h-full object-cover"
                              />
                            ) : item.fileType === 'application/pdf' ? (
                              <div className="text-center">
                                <span className="text-[10px] font-bold text-red-500 block">PDF</span>
                                <FileText className="w-4 h-4 text-slate-400 mx-auto" />
                              </div>
                            ) : (
                              <FileText className="w-6 h-6 text-slate-400" />
                            )}
                          </div>

                          {/* File details & stage */}
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2">
                              <span className="font-bold text-xs text-slate-900 dark:text-white truncate">
                                {item.fileName}
                              </span>
                              <span className="text-[10px] text-slate-400 font-mono shrink-0">
                                {formatFileSize(item.fileSize)}
                              </span>
                            </div>

                            {/* Stage Message with Live Status */}
                            <div className="mt-1 flex items-center gap-2">
                              {isCheckingQuality && (
                                <RefreshCw className="w-3.5 h-3.5 text-sky-500 animate-spin shrink-0" />
                              )}
                              {isExtracting && (
                                <Sparkles className="w-3.5 h-3.5 text-sky-600 animate-pulse shrink-0" />
                              )}
                              {isCompleted && (
                                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                              )}
                              {isError && (
                                <AlertCircle className="w-3.5 h-3.5 text-red-600 shrink-0" />
                              )}
                              <span
                                className={`text-xs truncate ${
                                  isError
                                    ? 'text-red-600 font-medium'
                                    : isCompleted
                                    ? 'text-emerald-700 dark:text-emerald-300 font-medium'
                                    : 'text-slate-600 dark:text-slate-300'
                                }`}
                              >
                                {item.stageMessage}
                              </span>
                            </div>

                            {/* Extracted Receipt Summary Pill */}
                            {item.receipt && (
                              <div className="mt-2 flex flex-wrap items-center gap-1.5 text-[11px]">
                                <span className="bg-white dark:bg-slate-800 px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700 font-bold text-slate-800 dark:text-slate-200">
                                  {item.receipt.supplierName || 'Unknown Merchant'}
                                </span>
                                <span className="bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded-md border border-indigo-200 dark:border-indigo-800 font-mono font-bold text-indigo-700 dark:text-indigo-300">
                                  {(item.receipt.totalAedMinor / 100).toFixed(2)} AED
                                </span>
                                <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-md text-slate-600 dark:text-slate-300 font-medium">
                                  {item.receipt.categoryName}
                                </span>
                                {budgetBreached && (
                                  <span className="bg-red-500 text-white font-bold px-2 py-0.5 rounded-md text-[10px] animate-pulse">
                                    🚨 Budget Limit Breached (Alert Dispatched)
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>

                        {/* Right Actions & Status Badges */}
                        <div className="flex items-center gap-2 shrink-0">
                          {isError && (
                            <button
                              onClick={() => handleRetryItem(item.id)}
                              className="px-2.5 py-1 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 text-xs font-semibold flex items-center gap-1 cursor-pointer"
                              title="Retry extraction"
                            >
                              <RotateCw className="w-3 h-3" />
                              Retry
                            </button>
                          )}

                          <button
                            onClick={() => handleRemoveItem(item.id)}
                            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
                            title="Remove from queue"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* Individual Progress Bar */}
                      <div className="mt-2.5 flex items-center gap-3">
                        <div className="flex-1 bg-slate-200/70 dark:bg-slate-700/60 rounded-full h-1.5 overflow-hidden">
                          <div
                            className={`h-1.5 rounded-full transition-all duration-300 ${
                              isError
                                ? 'bg-red-500'
                                : isCompleted
                                ? 'bg-emerald-500'
                                : 'bg-gradient-to-r from-indigo-500 to-violet-500'
                            }`}
                            style={{ width: `${item.progress}%` }}
                          />
                        </div>
                        <span className="text-[10px] font-mono text-slate-400 font-semibold w-8 text-right">
                          {item.progress}%
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* TAB 2: LIVE CAMERA SCANNER */}
      {activeTab === 'camera' && (
        <div className="bg-slate-950 rounded-3xl p-4 sm:p-6 shadow-2xl border border-slate-800 text-white flex flex-col items-center">
          <div className="relative w-full max-w-xl aspect-[3/4] sm:aspect-[4/3] rounded-2xl overflow-hidden bg-black flex items-center justify-center border border-slate-800">
            {cameraActive ? (
              <>
                <video
                  ref={videoRef}
                  playsInline
                  autoPlay
                  muted
                  className="w-full h-full object-cover"
                />
                {/* Viewfinder guidelines overlay */}
                <div className="absolute inset-8 border-2 border-white/40 rounded-xl pointer-events-none flex flex-col justify-between p-3">
                  <div className="flex justify-between">
                    <div className="w-6 h-6 border-t-4 border-l-4 border-indigo-400 rounded-tl-md" />
                    <div className="w-6 h-6 border-t-4 border-r-4 border-indigo-400 rounded-tr-md" />
                  </div>
                  <div className="text-center">
                    <span className="bg-black/60 backdrop-blur-xs text-white text-[11px] font-semibold px-3 py-1 rounded-full">
                      Align receipt inside frame
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <div className="w-6 h-6 border-b-4 border-l-4 border-indigo-400 rounded-bl-md" />
                    <div className="w-6 h-6 border-b-4 border-r-4 border-indigo-400 rounded-br-md" />
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center p-6 text-slate-400">
                <Camera className="w-12 h-12 mx-auto mb-2 text-slate-600" />
                <p className="text-sm">Camera inactive</p>
                <button
                  onClick={startCamera}
                  className="mt-3 px-4 py-2 rounded-xl bg-gradient-to-r from-indigo-600 to-violet-600 text-white text-xs font-bold shadow-md shadow-indigo-600/30"
                >
                  Start Camera
                </button>
              </div>
            )}
          </div>

          {cameraActive && (
            <div className="mt-5 flex items-center gap-4">
              <button
                onClick={capturePhoto}
                className="w-16 h-16 rounded-full bg-white text-slate-900 flex items-center justify-center p-1.5 shadow-xl hover:scale-105 active:scale-95 transition cursor-pointer"
                title="Take photo"
              >
                <div className="w-full h-full rounded-full border-4 border-slate-900 bg-gradient-to-tr from-indigo-500 to-violet-500" />
              </button>
              <button
                onClick={stopCamera}
                className="px-4 py-2 rounded-xl border border-slate-700 text-xs font-semibold text-slate-300 hover:bg-slate-800"
              >
                Stop Camera
              </button>
            </div>
          )}
        </div>
      )}

      {/* TAB 3: DEDICATED INVOICE EMAIL FORWARDING */}
      {activeTab === 'email' && (
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-6">
          <div className="flex items-start gap-3.5">
            <div className="p-3 rounded-2xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600 shrink-0">
              <Mail className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                Dedicated Inbound Invoice Forwarding Address
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Staff members and suppliers can forward digital PDF invoices or scanned attachments directly to this inbox to generate drafts automatically.
              </p>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
                Company Inbound Email Address
              </span>
              <span className="text-sm font-mono font-bold text-indigo-600 dark:text-indigo-400 select-all">
                invoices-capture@receipts.local
              </span>
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText('invoices-capture@receipts.local');
                alert('Email address copied to clipboard!');
              }}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-600 text-xs font-semibold hover:bg-white dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200"
            >
              Copy Address
            </button>
          </div>

          {/* Forwarding Inbound Simulator for Demo & Testing */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Simulate Inbound Email Forwarding</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="text-[11px] font-medium text-slate-500 block mb-1">Sender Email</label>
                <input
                  type="email"
                  value={forwardSender}
                  onChange={(e) => setForwardSender(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
                />
              </div>
              <div>
                <label className="text-[11px] font-medium text-slate-500 block mb-1">Email Subject (Supplier Hint)</label>
                <input
                  type="text"
                  value={forwardSubject}
                  onChange={(e) => setForwardSubject(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 dark:border-slate-700 p-2 text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="pt-2">
              <label className="text-[11px] font-medium text-slate-500 block mb-1">Attach Sample Receipt</label>
              <input
                type="file"
                accept="image/*,application/pdf"
                onChange={async (e) => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  setForwarding(true);
                  try {
                    const base64 = await readFileAsBase64(file);
                    const res = await api.processReceipt({
                      imageBase64: base64,
                      fileName: file.name,
                      fileType: file.type,
                      manualSupplier: forwardSubject,
                      costCentre: 'Email Inbound',
                    });
                    onReceiptProcessed(res.receipt);
                    setForwardSuccess(true);
                    setTimeout(() => setForwardSuccess(false), 3000);
                  } catch (err: any) {
                    alert(`Email forward error: ${err.message}`);
                  } finally {
                    setForwarding(false);
                  }
                }}
                className="text-xs text-slate-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-sky-50 file:text-sky-700 hover:file:bg-sky-100"
              />
            </div>

            {forwardSuccess && (
              <div className="p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>Forwarded email receipt successfully processed!</span>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Pre-flight Quality Modal */}
      {pendingFile && (
        <ImageQualityModal
          imagePreview={pendingFile.base64}
          quality={pendingFile.quality}
          onRetake={() => {
            setPendingFile(null);
            fileInputRef.current?.click();
          }}
          onProceed={async () => {
            const { base64, file, quality } = pendingFile;
            setPendingFile(null);
            handleFilesSelected([file]);
          }}
        />
      )}
    </div>
  );
};
