import { Category, Receipt, AppSettings, RuleOverride, AuditLogEntry, RedFlagEmailAlert, User, UserRole } from '../types';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('expense_capture_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export const api = {
  // Receipts
  async getReceipts(): Promise<{ receipts: Receipt[] }> {
    const res = await fetch('/api/receipts', {
      headers: { ...getAuthHeader() },
    });
    if (!res.ok) throw new Error('Failed to fetch receipts');
    return res.json();
  },

  async getReceipt(id: string): Promise<{ receipt: Receipt }> {
    const res = await fetch(`/api/receipts/${id}`, {
      headers: { ...getAuthHeader() },
    });
    if (!res.ok) throw new Error('Failed to fetch receipt');
    return res.json();
  },

  async processReceipt(payload: {
    imageBase64: string;
    fileName: string;
    fileType: string;
    perceptualHash?: string;
    manualSupplier?: string;
    manualInvoiceNumber?: string;
    costCentre?: string;
  }): Promise<{ receipt: Receipt }> {
    const res = await fetch('/api/receipts/process', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(payload),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to process document');
    return data;
  },

  async updateReceipt(id: string, updates: Partial<Receipt>): Promise<{ receipt: Receipt }> {
    const res = await fetch(`/api/receipts/${id}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update receipt');
    return data;
  },

  async acceptReceipt(id: string, notes?: string): Promise<{ success: boolean; receipt: Receipt }> {
    const res = await fetch(`/api/receipts/${id}/accept`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ notes }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to accept receipt');
    return data;
  },

  async rejectReceipt(id: string, reason?: string): Promise<{ success: boolean; receipt: Receipt }> {
    const res = await fetch(`/api/receipts/${id}/reject`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ reason }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to reject receipt');
    return data;
  },

  async bulkAccept(ids: string[]): Promise<{ success: boolean; approvedCount: number }> {
    const res = await fetch('/api/receipts/bulk-accept', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ ids }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed bulk accept');
    return data;
  },

  async splitReceipt(id: string, splits: Array<{ categoryId: string; categoryName: string; amountMinor: number; lineItemIds: string[] }>): Promise<{ success: boolean; receipt: Receipt }> {
    const res = await fetch(`/api/receipts/${id}/split`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ splits }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to split receipt');
    return data;
  },

  // Categories
  async getCategories(): Promise<{ categories: Category[]; taxonomyVersion: number }> {
    const res = await fetch('/api/categories');
    if (!res.ok) throw new Error('Failed to fetch categories');
    return res.json();
  },

  async createCategory(cat: Partial<Category>): Promise<{ category: Category; taxonomyVersion: number }> {
    const res = await fetch('/api/categories', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(cat),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to create category');
    return data;
  },

  async updateCategory(id: string, updates: Partial<Category>): Promise<{ category: Category; taxonomyVersion: number }> {
    const res = await fetch(`/api/categories/${id}`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(updates),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update category');
    return data;
  },

  async mergeCategories(sourceCategoryId: string, targetCategoryId: string): Promise<{ success: boolean; remappedCount: number; taxonomyVersion: number }> {
    const res = await fetch('/api/categories/merge', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ sourceCategoryId, targetCategoryId }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to merge categories');
    return data;
  },

  // Settings & Rules
  async getSettings(): Promise<{ settings: AppSettings; ruleOverrides: RuleOverride[] }> {
    const res = await fetch('/api/settings');
    if (!res.ok) throw new Error('Failed to fetch settings');
    return res.json();
  },

  async updateSettings(settings: Partial<AppSettings>): Promise<{ settings: AppSettings }> {
    const res = await fetch('/api/settings', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(settings),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update settings');
    return data;
  },

  async addRule(rule: { keyword: string; categoryId: string }): Promise<{ rule: RuleOverride }> {
    const res = await fetch('/api/rules', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(rule),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add rule');
    return data;
  },

  async deleteRule(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/rules/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    return res.json();
  },

  // Audit Logs
  async getAuditLogs(): Promise<{ logs: AuditLogEntry[] }> {
    const res = await fetch('/api/audit-logs', {
      headers: { ...getAuthHeader() },
    });
    if (!res.ok) throw new Error('Failed to fetch audit logs');
    return res.json();
  },

  // Users Management (Admin)
  async getUsers(): Promise<{ users: User[] }> {
    const res = await fetch('/api/users', {
      headers: { ...getAuthHeader() },
    });
    if (!res.ok) throw new Error('Failed to fetch users');
    return res.json();
  },

  async updateUserRole(userId: string, role: UserRole): Promise<{ success: boolean; user: User }> {
    const res = await fetch(`/api/users/${userId}/role`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ role }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update user role');
    return data;
  },

  async approveUser(userId: string, approved: boolean): Promise<{ success: boolean; user: User }> {
    const res = await fetch(`/api/users/${userId}/approve`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ approved }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update user approval status');
    return data;
  },

  // Test Suite Runner
  async runTestSuite(): Promise<{ results: any[]; allPassed: boolean }> {
    const res = await fetch('/api/test-suite/run', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to run test suite');
    return data;
  },

  // Red Flag Email Alerts
  async getEmailAlerts(): Promise<{ alerts: any[] }> {
    const res = await fetch('/api/alerts/emails', {
      headers: { ...getAuthHeader() },
    });
    if (!res.ok) throw new Error('Failed to fetch email alerts');
    return res.json();
  },

  // Preset Category Bundle
  async addCategoryPresetBundle(): Promise<{ success: boolean; addedCount: number; categories: Category[]; taxonomyVersion: number }> {
    const res = await fetch('/api/categories/preset-bundle', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to add preset categories');
    return data;
  },

  // Category Spend Limit
  async updateCategoryLimit(id: string, spendLimitMinor?: number): Promise<{ success: boolean; category: Category; triggeredAlert?: RedFlagEmailAlert }> {
    const res = await fetch(`/api/categories/${id}/limit`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify({ spendLimitMinor }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to update category spend limit');
    return data;
  },

  // Trigger alert check / dispatch test notification
  async triggerAlertCheck(params?: { categoryId?: string; targetEmail?: string; forceSimulate?: boolean }): Promise<{ success: boolean; alertsTriggered: number; alerts: RedFlagEmailAlert[] }> {
    const res = await fetch('/api/alerts/trigger-check', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...getAuthHeader(),
      },
      body: JSON.stringify(params || {}),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to trigger alert check');
    return data;
  },

  async acknowledgeAlert(id: string): Promise<{ success: boolean; alert: RedFlagEmailAlert }> {
    const res = await fetch(`/api/alerts/${id}/acknowledge`, {
      method: 'POST',
      headers: { ...getAuthHeader() },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to acknowledge alert');
    return data;
  },

  async deleteAlert(id: string): Promise<{ success: boolean }> {
    const res = await fetch(`/api/alerts/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete alert');
    return data;
  },

  // Category Insights (Weekly & Monthly highest expenses)
  async getInsights(): Promise<{
    weekly: { periodLabel: string; topCategories: any[]; totalSpendMinor: number };
    monthly: { periodLabel: string; topCategories: any[]; totalSpendMinor: number };
  }> {
    const res = await fetch('/api/insights', {
      headers: { ...getAuthHeader() },
    });
    if (!res.ok) throw new Error('Failed to fetch category insights');
    return res.json();
  },
};

