export interface QueuedReceipt {
  id: string;
  capturedAt: string;
  imageBase64: string;
  fileName: string;
  fileType: string;
  costCentre: string;
  status: 'pending' | 'syncing' | 'failed';
  error?: string;
}

const QUEUE_KEY = 'expense_capture_offline_queue_v1';

export function getOfflineQueue(): QueuedReceipt[] {
  try {
    const raw = localStorage.getItem(QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Failed to load offline queue:', err);
    return [];
  }
}

export function saveToOfflineQueue(item: Omit<QueuedReceipt, 'id' | 'capturedAt' | 'status'>): QueuedReceipt {
  const queue = getOfflineQueue();
  const queuedItem: QueuedReceipt = {
    ...item,
    id: `offline-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    capturedAt: new Date().toISOString(),
    status: 'pending',
  };
  queue.push(queuedItem);
  localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  return queuedItem;
}

export function removeFromOfflineQueue(id: string) {
  const queue = getOfflineQueue().filter((item) => item.id !== id);
  localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
}

export function updateOfflineQueueItemStatus(id: string, status: 'pending' | 'syncing' | 'failed', error?: string) {
  const queue = getOfflineQueue();
  const item = queue.find((i) => i.id === id);
  if (item) {
    item.status = status;
    item.error = error;
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  }
}
