import { QualityCheckResult } from '../types';

/**
 * Client-side image quality and perceptual hash analysis
 * Uses HTML5 Canvas for fast, zero-dependency client image evaluation:
 * - Blur detection: Laplacian variance of grayscale pixels
 * - Glare detection: Percentage of overexposed / clipped pixels (>250 luminance)
 * - Perceptual hash: dHash (difference hash) for detecting re-photographed identical copies
 */

export async function analyzeImageQuality(
  imageSource: string | HTMLImageElement | File | Blob
): Promise<QualityCheckResult & { perceptualHash: string }> {
  const img = await loadImage(imageSource);

  // Downsample to manageable analysis size
  const maxDim = 600;
  let width = img.naturalWidth || img.width || 600;
  let height = img.naturalHeight || img.height || 800;

  if (width > maxDim || height > maxDim) {
    if (width > height) {
      height = Math.round((height * maxDim) / width);
      width = maxDim;
    } else {
      width = Math.round((width * maxDim) / height);
      height = maxDim;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d', { willReadFrequently: true });

  if (!ctx) {
    return {
      isAcceptable: true,
      blurVariance: 100,
      glarePercentage: 0,
      isBlurry: false,
      hasGlare: false,
      perceptualHash: 'hash-default',
    };
  }

  ctx.drawImage(img, 0, 0, width, height);
  const imgData = ctx.getImageData(0, 0, width, height);
  const pixels = imgData.data;

  // Convert to grayscale
  const gray = new Float32Array(width * height);
  let overexposedCount = 0;

  for (let i = 0, j = 0; i < pixels.length; i += 4, j++) {
    const r = pixels[i];
    const g = pixels[i + 1];
    const b = pixels[i + 2];
    const lum = 0.299 * r + 0.587 * g + 0.114 * b;
    gray[j] = lum;
    if (lum > 248) {
      overexposedCount++;
    }
  }

  const glarePercentage = (overexposedCount / (width * height)) * 100;

  // Compute Laplacian variance for blur detection
  // Laplacian kernel: [0, 1, 0, 1, -4, 1, 0, 1, 0]
  let laplacianSum = 0;
  let laplacianSqSum = 0;
  let count = 0;

  for (let y = 1; y < height - 1; y++) {
    for (let x = 1; x < width - 1; x++) {
      const idx = y * width + x;
      const center = gray[idx];
      const top = gray[idx - width];
      const bottom = gray[idx + width];
      const left = gray[idx - 1];
      const right = gray[idx + 1];

      const lap = top + bottom + left + right - 4 * center;
      laplacianSum += lap;
      laplacianSqSum += lap * lap;
      count++;
    }
  }

  const mean = laplacianSum / count;
  const variance = laplacianSqSum / count - mean * mean;

  // Perceptual dHash (difference hash 9x8)
  const dHashCanvas = document.createElement('canvas');
  dHashCanvas.width = 9;
  dHashCanvas.height = 8;
  const dHashCtx = dHashCanvas.getContext('2d');
  let perceptualHash = 'pHash-0';

  if (dHashCtx) {
    dHashCtx.drawImage(img, 0, 0, 9, 8);
    const dData = dHashCtx.getImageData(0, 0, 9, 8).data;
    const dGray: number[] = [];
    for (let i = 0; i < dData.length; i += 4) {
      dGray.push(0.299 * dData[i] + 0.587 * dData[i + 1] + 0.114 * dData[i + 2]);
    }

    let hashBits = '';
    for (let row = 0; row < 8; row++) {
      for (let col = 0; col < 8; col++) {
        const leftVal = dGray[row * 9 + col];
        const rightVal = dGray[row * 9 + col + 1];
        hashBits += leftVal > rightVal ? '1' : '0';
      }
    }
    perceptualHash = `dHash-${hashBits}`;
  }

  // Thresholds:
  // Variance < 45 indicates significant motion or lens blur
  // Glare > 15% indicates severe wash-out / flash reflection
  const isBlurry = variance < 45;
  const hasGlare = glarePercentage > 15;
  const isAcceptable = !isBlurry && !hasGlare;

  let recommendation: string | undefined;
  if (isBlurry && hasGlare) {
    recommendation = 'The document appears blurry with harsh glare reflection. Please hold steady and angle away from direct lights for optimal extraction.';
  } else if (isBlurry) {
    recommendation = 'The document is out of focus or blurred. Numbers and dates may be missed. Please retake with a stable camera.';
  } else if (hasGlare) {
    recommendation = 'Direct glare or flash reflection obscures text. Please retake at a slight angle or turn off flash.';
  }

  return {
    isAcceptable,
    blurVariance: Math.round(variance * 10) / 10,
    glarePercentage: Math.round(glarePercentage * 10) / 10,
    isBlurry,
    hasGlare,
    perceptualHash,
    recommendation,
  };
}

function loadImage(source: string | HTMLImageElement | File | Blob): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    if (source instanceof HTMLImageElement) {
      if (source.complete && source.naturalWidth > 0) return resolve(source);
      source.onload = () => resolve(source);
      source.onerror = reject;
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => resolve(img);
    img.onerror = reject;

    if (typeof source === 'string') {
      img.src = source;
    } else {
      const reader = new FileReader();
      reader.onload = (e) => {
        img.src = e.target?.result as string;
      };
      reader.onerror = reject;
      reader.readAsDataURL(source);
    }
  });
}
