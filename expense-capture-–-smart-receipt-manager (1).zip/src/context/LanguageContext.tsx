import React, { createContext, useContext, useState, useEffect } from 'react';

export type Language = 'en' | 'ar';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  isRtl: boolean;
  t: (key: string) => string;
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    appName: 'Expense Tracker',
    appTagline: 'Smart Financial & Receipt Manager',
    navCapture: 'Capture',
    navReview: 'Review Queue',
    navDashboard: 'Dashboard',
    navTransactions: 'Transactions',
    navSettings: 'Settings',
    navTests: 'Acceptance Tests',
    roleSubmitter: 'Submitter',
    roleReviewer: 'Reviewer',
    roleAdmin: 'Admin',
    roleAuditor: 'Auditor',
    emptyTitle: 'No transactions yet',
    emptySubtitle: 'Upload your first invoice to get started',
    emptyReviewTitle: 'Queue is clear',
    emptyReviewSubtitle: 'All receipts have been reviewed and reconciled',
    emptyDashboardTitle: 'No financial data yet',
    emptyDashboardSubtitle: 'Processed invoices will automatically populate category spend and tax summaries here',
    captureTabCamera: 'Scan with Camera',
    captureTabUpload: 'Upload Files',
    captureTabEmail: 'Email Forwarding',
    takePhoto: 'Capture Photo',
    dropFiles: 'Drop invoice photos or PDFs here, or click to browse',
    bulkSupported: 'Supports JPG, PNG, WebP, and multi-page PDF documents. Bulk upload enabled.',
    qualityWarningTitle: 'Document Quality Alert',
    qualityRetake: 'Retake Photo',
    qualityProceed: 'Proceed Anyway',
    reviewSideBySide: 'Side-by-Side Review',
    statusDraft: 'Draft',
    statusInReview: 'In Review',
    statusApproved: 'Approved',
    statusRejected: 'Rejected',
    statusSplit: 'Split',
    btnAccept: 'Accept & Approve',
    btnReject: 'Reject',
    btnBulkAccept: 'Bulk Accept High-Confidence',
    btnSplit: 'Split Categories',
    fieldSupplier: 'Supplier / Merchant',
    fieldTrn: 'Tax Registration No. (TRN)',
    fieldInvoiceNo: 'Invoice / Bill Number',
    fieldDate: 'Invoice Date',
    fieldTotal: 'Total Amount',
    fieldVat: 'VAT Amount (5%)',
    fieldCategory: 'Category (Controlled)',
    fieldGlCode: 'GL Code',
    taxRecoverable: 'Recoverable VAT',
    taxNonRecoverable: 'Blocked / Non-recoverable VAT',
    ctDeductible: 'Corporate Tax Deductible',
    ctLimited: '50% Limited (Entertainment)',
    ctNonDeductible: 'Non-Deductible',
    exportCsv: 'Export CSV',
    exportAccounting: 'Export Accounting Journal (XLSX)',
    installApp: 'Install App',
    offlineBanner: 'Offline Mode – Receipts will sync automatically when online',
    auditTrail: 'Audit Trail',
  },
  ar: {
    appName: 'متتبع المصروفات (Expense Tracker)',
    appTagline: 'الإدارة الذكية للنفقات والإيصالات والامتثال المالي',
    navCapture: 'التقاط الإيصال',
    navReview: 'قائمة المراجعة',
    navDashboard: 'لوحة المؤشرات',
    navTransactions: 'سجل العمليات',
    navSettings: 'الإعدادات',
    navTests: 'اختبارات القبول',
    roleSubmitter: 'مُرسل',
    roleReviewer: 'مُراجع مالي',
    roleAdmin: 'مسؤول النظام',
    roleAuditor: 'مدقق حسابات',
    emptyTitle: 'لا توجد عمليات بعد',
    emptySubtitle: 'قم برفع فاتورتك الأولى للبدء',
    emptyReviewTitle: 'القائمة مكتملة',
    emptyReviewSubtitle: 'تمت مراجعة واعتماد جميع الإيصالات المسجلة',
    emptyDashboardTitle: 'لا توجد بيانات مالية حتى الآن',
    emptyDashboardSubtitle: 'ستظهر النفقات حسب الفئات وملخص ضريبة القيمة المضافة فور معالجة الفواتير',
    captureTabCamera: 'مسح بالكاميرا',
    captureTabUpload: 'رفع الملفات',
    captureTabEmail: 'إعادة توجيه البريد',
    takePhoto: 'التقاط صورة',
    dropFiles: 'اسحب صور الفواتير أو ملفات PDF هنا أو انقر للاختيار',
    bulkSupported: 'يدعم صور JPG وPNG وWebP ومستندات PDF متعددة الصفحات مع الرفع الجماعي.',
    qualityWarningTitle: 'تنبيه جودة المستند',
    qualityRetake: 'إعادة الالتقاط',
    qualityProceed: 'المتابعة على أي حال',
    reviewSideBySide: 'مراجعة جنباً إلى جنب',
    statusDraft: 'مسودة',
    statusInReview: 'قيد المراجعة',
    statusApproved: 'معتمد',
    statusRejected: 'مرفوض',
    statusSplit: 'موزع',
    btnAccept: 'قبول واعتماد',
    btnReject: 'رفض الفاتورة',
    btnBulkAccept: 'قبول جماعي للثقة العالية',
    btnSplit: 'توزيع على عدة بنود',
    fieldSupplier: 'المورّد / التاجر',
    fieldTrn: 'الرقم الضريبي (TRN)',
    fieldInvoiceNo: 'رقم الفاتورة / الإيصال',
    fieldDate: 'تاريخ الفاتورة',
    fieldTotal: 'المبلغ الإجمالي',
    fieldVat: 'ضريبة القيمة المضافة (5%)',
    fieldCategory: 'الفئة (المعتمدة)',
    fieldGlCode: 'رمز دليل الحسابات (GL)',
    taxRecoverable: 'ضريبة قابلة للاسترداد',
    taxNonRecoverable: 'ضريبة محظورة / غير مستردة',
    ctDeductible: 'معفى لضريبة الشركات',
    ctLimited: 'خاضع لنسبة 50% (ضيافة وترفيه)',
    ctNonDeductible: 'غير قابل للخصم',
    exportCsv: 'تصدير ملف CSV',
    exportAccounting: 'تصدير قيود اليومية (XLSX)',
    installApp: 'تثبيت التطبيق',
    offlineBanner: 'وضع عدم الاتصال – سيتم رفع الإيصالات تلقائياً فور عودة الاتصال',
    auditTrail: 'سجل التدقيق',
  },
};

const LanguageContext = createContext<LanguageContextType>({
  language: 'en',
  setLanguage: () => {},
  isRtl: false,
  t: (key: string) => key,
});

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    return (localStorage.getItem('expense_capture_lang') as Language) || 'en';
  });

  const isRtl = language === 'ar';

  useEffect(() => {
    localStorage.setItem('expense_capture_lang', language);
    document.documentElement.lang = language;
    document.documentElement.dir = isRtl ? 'rtl' : 'ltr';
    if (isRtl) {
      document.body.classList.add('font-arabic');
    } else {
      document.body.classList.remove('font-arabic');
    }
  }, [language, isRtl]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = (key: string): string => {
    return translations[language][key] || translations['en'][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, isRtl, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => useContext(LanguageContext);
