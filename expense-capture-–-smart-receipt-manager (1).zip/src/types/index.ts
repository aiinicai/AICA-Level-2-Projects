export type UserRole = 'Admin' | 'Reviewer' | 'Submitter' | 'Auditor';
export type UserStatus = 'active' | 'pending_approval' | 'suspended';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  status?: UserStatus;
  isApproved?: boolean;
  createdAt: string;
}

export type VatRecoverability = 'full' | 'none' | 'review' | 'exempt';
export type CorporateTaxTreatment = 'fully_deductible' | 'fifty_percent_limited' | 'non_deductible';

export interface Category {
  id: string;
  name: string;
  glCode: string;
  vatRecoverability: VatRecoverability;
  corporateTaxTreatment: CorporateTaxTreatment;
  spendLimitMinor?: number; // In minor units (e.g. 50000 = 500 AED)
  active: boolean;
  version: number;
}

export interface SupplierMemory {
  id: string;
  supplierKey: string; // Normalised TRN or normalized name
  supplierName: string;
  trn?: string;
  categoryId: string;
  categoryName: string;
  confirmedCount: number;
  lastConfirmedAt: string;
}

export interface RuleOverride {
  id: string;
  keyword: string;
  categoryId: string;
  categoryName: string;
  exactMatch?: boolean;
}

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  unitPriceMinor: number;
  lineTotalMinor: number;
  categoryId?: string;
  categoryName?: string;
}

export type ReceiptStatus = 'draft' | 'in_review' | 'approved' | 'rejected' | 'split';

export interface PolicyFlag {
  code: string;
  severity: 'info' | 'warning' | 'error';
  message: string;
  rule: string;
}

export interface FieldConfidence {
  supplier: number;
  trn: number;
  invoiceNumber: number;
  date: number;
  currency: number;
  lineItems: number;
  vatAmount: number;
  total: number;
  category: number;
}

export interface Receipt {
  id: string;
  submitterId: string;
  submitterName: string;
  submitterEmail: string;
  status: ReceiptStatus;
  
  // Storage & file info
  fileUrl: string;
  fileName: string;
  fileType: string; // 'image/jpeg', 'image/png', 'application/pdf', etc.
  fileHash: string; // SHA-256
  perceptualHash?: string; // Visual dHash
  fileSize: number;
  uploadedAt: string;

  // Extracted fields
  supplierName: string | null;
  supplierNameArabic?: string | null;
  trn: string | null;
  invoiceNumber: string | null;
  invoiceDate: string | null; // ISO YYYY-MM-DD
  currency: string; // Default AED
  exchangeRate: number; // For foreign currencies, e.g. 3.6725
  
  // Amounts stored in integer minor units (e.g. 100 AED = 10000)
  totalMinor: number;
  vatAmountMinor: number;
  netAmountMinor: number;
  totalAedMinor: number;
  vatRatePercent: number | null; // e.g. 5

  // Category classification
  categoryId: string;
  categoryName: string;
  glCode: string;
  categoryConfidence: number;
  categoryReason: string;
  secondBestCategory?: string;
  classificationSource: 'manual' | 'supplier_memory' | 'keyword_rule' | 'ai_proposal';
  taxonomyVersion: number;

  // Line items
  lineItems: LineItem[];

  // Tax calculations
  vatRecoverability: VatRecoverability;
  recoverableVatMinor: number;
  corporateTaxTreatment: CorporateTaxTreatment;
  ctDeductibleAmountMinor: number;

  // Validation & policy
  fieldConfidence: FieldConfidence;
  policyFlags: PolicyFlag[];
  mathMismatch: boolean; // items + VAT != total
  isSimplifiedInvoice: boolean;
  costCentre: string;

  // AI execution metadata
  aiModelName: string;
  promptVersion: string;

  // Timestamps & reviews
  reviewedBy?: string;
  reviewedByName?: string;
  reviewedAt?: string;
  reviewNotes?: string;
}

export interface AuditLogEntry {
  id: string;
  receiptId?: string;
  action: 'upload' | 'extraction' | 'ai_proposal' | 'user_correction' | 'approval' | 'rejection' | 'category_merge' | 'category_change' | 'export' | 'rule_added';
  userId: string;
  userName: string;
  userRole: UserRole;
  timestamp: string;
  details: string;
  oldValue?: string | number | null;
  newValue?: string | number | null;
  field?: string;
  aiModelName?: string;
  promptVersion?: string;
  confidence?: number;
}

export interface AppSettings {
  geminiModel: string;
  confidenceThreshold: number; // default 0.80
  retentionYears: number; // default 5
  simplifiedInvoiceThresholdMinor: number; // default 10,000 AED = 1000000
  approvalLimitMinor: number; // default 1,000 AED = 100000
  oldDocumentDays: number; // default 90
  uaeWeekendMode: 'sat_sun' | 'fri_sat';
  dedicatedEmail: string;
  taxonomyVersion: number;
}

export interface QualityCheckResult {
  isAcceptable: boolean;
  blurVariance: number;
  glarePercentage: number;
  isBlurry: boolean;
  hasGlare: boolean;
  recommendation?: string;
}

// Red Flag Email Alert for Category Budget Breaches
export interface RedFlagEmailAlert {
  id: string;
  recipientEmail: string;
  recipientName: string;
  categoryId: string;
  categoryName: string;
  spendLimitMinor: number;
  currentSpendMinor: number;
  breachAmountMinor: number;
  subject: string;
  body: string;
  triggeredAt: string;
  receiptId?: string;
  status: 'sent' | 'delivered';
  acknowledged?: boolean;
  acknowledgedAt?: string;
}

// Bulk Upload Item for Drag & Drop Zone Progress Tracking
export interface BulkUploadItem {
  id: string;
  file: File;
  fileName: string;
  fileSize: number;
  fileType: string;
  previewUrl?: string;
  status: 'queued' | 'checking_quality' | 'extracting_ai' | 'completed' | 'error';
  progress: number; // 0 to 100
  stageMessage: string;
  quality?: QualityCheckResult;
  receipt?: Receipt;
  error?: string;
}

// Weekly & Monthly Insights on Categories
export interface CategoryInsight {
  categoryId: string;
  categoryName: string;
  glCode: string;
  spendLimitMinor?: number;
  currentSpendMinor: number;
  previousSpendMinor: number;
  growthPercentage: number;
  spendCount: number;
  percentOfTotal: number;
  isBreached: boolean;
  highestSingleTicketMinor: number;
  averageTicketMinor: number;
}
