
import csv
import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP, InvalidOperation


APP_TITLE = "Lease Accounting Tool | Multi-Branch | Ind AS 116"
ZERO = Decimal("0")
CENT = Decimal("0.01")


# ============================================================
# NUMBER / DATE HELPERS
# ============================================================

def D(value):
    """Safe Decimal conversion."""
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def money(value):
    """Indian grouping with 2 decimals."""
    try:
        x = D(value).quantize(CENT, rounding=ROUND_HALF_UP)
    except Exception:
        x = ZERO

    sign = "-" if x < ZERO else ""
    x = abs(x)

    integer, decimal = f"{x:.2f}".split(".")
    if len(integer) <= 3:
        grouped = integer
    else:
        last = integer[-3:]
        rem = integer[:-3]
        chunks = []
        while rem:
            chunks.insert(0, rem[-2:])
            rem = rem[:-2]
        grouped = ",".join(chunks + [last])

    return f"Rs {sign}{grouped}.{decimal}"


def number_text(value):
    """Indian grouped number without Rs prefix."""
    return money(value).replace("Rs ", "")


def parse_decimal(text, label, minimum=ZERO):
    raw = str(text).strip().replace(",", "")
    if raw == "":
        raise ValueError(f"Please enter {label}.")
    try:
        x = Decimal(raw)
    except InvalidOperation:
        raise ValueError(f"{label} must be a valid number.")
    if not x.is_finite():
        raise ValueError(f"{label} must be a valid number.")
    if x < minimum:
        if minimum == ZERO:
            raise ValueError(f"{label} cannot be negative.")
        raise ValueError(f"{label} must be at least {minimum}.")
    return x


def parse_int(text, label, minimum=1):
    raw = str(text).strip()
    if raw == "":
        raise ValueError(f"Please enter {label}.")
    try:
        x = int(raw)
    except ValueError:
        raise ValueError(f"{label} must be a whole number.")
    if x < minimum:
        raise ValueError(f"{label} must be at least {minimum}.")
    return x


def parse_date(text, label):
    raw = str(text).strip()
    try:
        return datetime.strptime(raw, "%d-%m-%Y").date()
    except ValueError:
        raise ValueError(
            f"{label} must be in DD-MM-YYYY format.\nExample: 01-04-2026"
        )


def fmt_date(x):
    return x.strftime("%d-%m-%Y")


def add_months(year, month, add):
    n = year * 12 + (month - 1) + add
    return n // 12, n % 12 + 1


def month_end(year, month):
    if month == 12:
        return date(year + 1, 1, 1).fromordinal(
            date(year + 1, 1, 1).toordinal() - 1
        )
    return date(year, month + 1, 1).fromordinal(
        date(year, month + 1, 1).toordinal() - 1
    )


def month_start(d):
    return date(d.year, d.month, 1)


def months_between(start, end):
    """Inclusive calendar month index."""
    return (end.year - start.year) * 12 + end.month - start.month


def annual_to_monthly(rate_percent):
    return D(rate_percent) / D("100") / D("12")


def annual_to_periodic(rate_percent, frequency):
    rate = D(rate_percent) / D("100")
    div = {
        "Monthly": 12,
        "Quarterly": 4,
        "Half-Yearly": 2,
        "Yearly": 1,
    }[frequency]
    return rate / D(div)


# ============================================================
# CORE CALCULATIONS
# ============================================================

def pv_of_payments(payment, periodic_rate, periods, beginning=False):
    payment = D(payment)
    r = D(periodic_rate)
    n = int(periods)

    if r == ZERO:
        pv = payment * D(n)
    else:
        pv = payment * (
            (D("1") - (D("1") + r) ** D(-n)) / r
        )

    if beginning:
        pv *= (D("1") + r)

    return pv


def monthly_payment_from_frequency(payment, frequency):
    """Convert periodic contractual rent to monthly equivalent."""
    payment = D(payment)
    if frequency == "Monthly":
        return payment
    if frequency == "Quarterly":
        return payment / D(3)
    if frequency == "Half-Yearly":
        return payment / D(6)
    if frequency == "Yearly":
        return payment / D(12)
    return payment


def build_monthly_lease_schedule(rec):
    """
    Build a monthly schedule from commencement month through
    the contractual lease period.

    For payment frequencies other than monthly, payment occurs
    in the appropriate month:
      Monthly       -> every month
      Quarterly     -> every 3rd month
      Half-Yearly   -> every 6th month
      Yearly        -> every 12th month

    The annual discount rate is converted to an effective
    monthly rate for monthly reporting.
    """
    start = rec["commencement_date"]
    total_months = rec["periods"] * {
        "Monthly": 1,
        "Quarterly": 3,
        "Half-Yearly": 6,
        "Yearly": 12,
    }[rec["frequency"]]

    monthly_rate = annual_to_monthly(rec["annual_rate"])
    payment = rec["payment"]

    beginning = rec["payment_timing"] == "Beginning of Period"

    lease_liability = rec["initial_lease_liability"]
    rou = rec["initial_rou_asset"]

    dep_monthly = (
        rec["initial_rou_asset"]
        / D(rec["depreciation_months"])
        if rec["depreciation_months"] > 0 else ZERO
    )

    rows = []

    for i in range(total_months):
        y, m = add_months(start.year, start.month, i)
        period_date = month_end(y, m)

        opening_ll = lease_liability
        opening_rou = rou

        # Payment occurs at beginning or end of contractual period.
        is_payment_month = (
            i % {
                "Monthly": 1,
                "Quarterly": 3,
                "Half-Yearly": 6,
                "Yearly": 12,
            }[rec["frequency"]] == 0
        )

        actual_payment = payment if is_payment_month else ZERO

        if beginning and is_payment_month:
            paid_before_interest = min(actual_payment, lease_liability)
            lease_liability -= paid_before_interest
            interest = lease_liability * monthly_rate
            lease_liability += interest
        else:
            interest = lease_liability * monthly_rate
            lease_liability += interest
            if is_payment_month:
                paid = min(actual_payment, lease_liability)
                lease_liability -= paid
                actual_payment = paid

        if not beginning and not is_payment_month:
            actual_payment = ZERO

        # Depreciation starts from commencement month.
        depreciation = ZERO
        if i < rec["depreciation_months"] and rou > ZERO:
            depreciation = min(dep_monthly, rou)
            rou -= depreciation

        if lease_liability < Decimal("0.005"):
            lease_liability = ZERO
        if rou < Decimal("0.005"):
            rou = ZERO

        # Security deposit monthly EIR unwinding.
        sec_open = rec["security_initial_pv"] if i == 0 else rows[-1]["security_closing"]
        sec_interest = sec_open * rec["security_monthly_rate"]
        sec_close = sec_open + sec_interest

        # Force face value in final security period.
        if rec["security_months"] > 0 and i + 1 == rec["security_months"]:
            sec_close = rec["security_deposit"]
            sec_interest = sec_close - sec_open

        # After security deposit maturity, keep at face value.
        if i + 1 > rec["security_months"]:
            sec_open = rec["security_deposit"]
            sec_interest = ZERO
            sec_close = rec["security_deposit"]

        # Deferred tax based on explicit assumptions.
        tax_rate = rec["tax_rate"] / D("100")
        dta = lease_liability * tax_rate if rec["tax_base_lease_liability_zero"] else ZERO
        dtl = rou * tax_rate if rec["tax_base_rou_zero"] else ZERO

        rows.append({
            "period_no": i + 1,
            "date": period_date,
            "opening_liability": opening_ll,
            "interest": interest,
            "payment": actual_payment,
            "closing_liability": lease_liability,
            "opening_rou": opening_rou,
            "depreciation": depreciation,
            "closing_rou": rou,
            "security_opening": sec_open,
            "security_interest": sec_interest,
            "security_closing": sec_close,
            "dta": dta,
            "dtl": dtl,
            "net_deferred_tax": dta - dtl,
        })

    return rows


def period_bucket(d, basis):
    """Return reporting period label."""
    if basis == "Monthly":
        return d.strftime("%b-%Y")
    if basis == "Quarterly":
        q = (d.month - 1) // 3 + 1
        return f"Q{q} FY {d.year}"
    if basis == "Half-Yearly":
        h = 1 if d.month <= 6 else 2
        return f"H{h} FY {d.year}"
    if basis == "Yearly":
        return f"FY {d.year}"
    return d.strftime("%b-%Y")


def aggregate_rows(rows, as_of, basis):
    """Aggregate monthly rows into selected reporting periods."""
    filtered = [r for r in rows if r["date"] <= as_of]
    if not filtered:
        return []

    groups = {}
    for r in filtered:
        key = period_bucket(r["date"], basis)
        groups.setdefault(key, []).append(r)

    output = []
    for key, rs_ in groups.items():
        first = rs_[0]
        last = rs_[-1]
        output.append({
            "period": key,
            "date": last["date"],
            "opening_liability": first["opening_liability"],
            "interest": sum((r["interest"] for r in rs_), ZERO),
            "payment": sum((r["payment"] for r in rs_), ZERO),
            "closing_liability": last["closing_liability"],
            "opening_rou": first["opening_rou"],
            "depreciation": sum((r["depreciation"] for r in rs_), ZERO),
            "closing_rou": last["closing_rou"],
            "security_opening": first["security_opening"],
            "security_interest": sum(
                (r["security_interest"] for r in rs_), ZERO
            ),
            "security_closing": last["security_closing"],
            "dta": last["dta"],
            "dtl": last["dtl"],
            "net_deferred_tax": last["net_deferred_tax"],
        })

    return output


# ============================================================
# APPLICATION
# ============================================================

class LeaseApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1550x930")
        self.root.minsize(1250, 760)

        self.branches = {}
        self.selected_branch = None
        self.selected_lease = None

        self.vars = {}
        self.create_variables()
        self.build_style()
        self.build_ui()
        self.refresh_all()

    # --------------------------------------------------------
    # VARIABLES
    # --------------------------------------------------------

    def create_variables(self):
        names = [
            "branch_code", "branch_name",
            "lease_id", "lease_name", "commencement_date",
            "payment", "frequency", "annual_rate", "periods",
            "payment_timing", "direct_cost", "prepaid",
            "incentive", "depreciation_months",
            "security_deposit", "security_months",
            "borrowing_rate", "tax_rate",
            "report_date", "report_basis"
        ]
        for n in names:
            self.vars[n] = tk.StringVar()

        self.vars["frequency"].set("Monthly")
        self.vars["payment_timing"].set("End of Period")
        self.vars["direct_cost"].set("0")
        self.vars["prepaid"].set("0")
        self.vars["incentive"].set("0")
        self.vars["security_deposit"].set("0")
        self.vars["report_basis"].set("Monthly")
        self.vars["report_date"].set(date.today().strftime("%d-%m-%Y"))
        self.vars["tax_rate"].set("25")

    # --------------------------------------------------------
    # STYLE
    # --------------------------------------------------------

    def build_style(self):
        style = ttk.Style()
        try:
            if "vista" in style.theme_names():
                style.theme_use("vista")
            elif "clam" in style.theme_names():
                style.theme_use("clam")
        except Exception:
            pass

        style.configure("Title.TLabel", font=("Segoe UI", 20, "bold"))
        style.configure("Sub.TLabel", font=("Segoe UI", 10))
        style.configure("Head.TLabel", font=("Segoe UI", 10, "bold"))
        style.configure("KPI.TLabel", font=("Segoe UI", 12, "bold"))
        style.configure("Small.TLabel", font=("Segoe UI", 9))

    # --------------------------------------------------------
    # UI
    # --------------------------------------------------------

    def build_ui(self):
        root_frame = ttk.Frame(self.root, padding=10)
        root_frame.pack(fill="both", expand=True)

        ttk.Label(
            root_frame,
            text="Lease Accounting Dashboard",
            style="Title.TLabel"
        ).pack(anchor="w")

        ttk.Label(
            root_frame,
            text=(
                "Multi-branch lease register | Monthly / Quarterly / "
                "Half-Yearly / Yearly reporting | ROU | Lease Liability | "
                "Interest | Depreciation | DTA / DTL"
            ),
            style="Sub.TLabel"
        ).pack(anchor="w", pady=(0, 8))

        self.build_branch_bar(root_frame)
        self.build_input_notebook(root_frame)
        self.build_kpis(root_frame)
        self.build_report_controls(root_frame)
        self.build_output_notebook(root_frame)

    def build_branch_bar(self, parent):
        f = ttk.LabelFrame(parent, text="Branch Master / Selection", padding=8)
        f.pack(fill="x", pady=(0, 8))

        ttk.Label(f, text="Branch Code").grid(row=0, column=0, padx=5)
        ttk.Entry(
            f, textvariable=self.vars["branch_code"], width=16
        ).grid(row=0, column=1, padx=5)

        ttk.Label(f, text="Branch Name").grid(row=0, column=2, padx=5)
        ttk.Entry(
            f, textvariable=self.vars["branch_name"], width=28
        ).grid(row=0, column=3, padx=5)

        ttk.Button(
            f, text="Add / Update Branch", command=self.add_branch
        ).grid(row=0, column=4, padx=5)

        ttk.Button(
            f, text="Delete Branch", command=self.delete_branch
        ).grid(row=0, column=5, padx=5)

        ttk.Label(f, text="Selected Branch").grid(row=0, column=6, padx=5)
        self.branch_combo = ttk.Combobox(
            f, state="readonly", width=36
        )
        self.branch_combo.grid(row=0, column=7, padx=5)
        self.branch_combo.bind("<<ComboboxSelected>>", self.branch_changed)

        self.branch_count_label = ttk.Label(
            f, text="Branches: 0", style="Head.TLabel"
        )
        self.branch_count_label.grid(row=0, column=8, padx=15)

    def build_input_notebook(self, parent):
        nb = ttk.Notebook(parent)
        nb.pack(fill="x", pady=(0, 8))

        lease_tab = ttk.Frame(nb, padding=10)
        security_tab = ttk.Frame(nb, padding=10)
        tax_tab = ttk.Frame(nb, padding=10)

        nb.add(lease_tab, text="Lease Master")
        nb.add(security_tab, text="Security Deposit")
        nb.add(tax_tab, text="Deferred Tax / Reporting")

        self.add_entry(lease_tab, 0, 0, "Lease ID", "lease_id")
        self.add_entry(lease_tab, 0, 2, "Lease / Contract Name", "lease_name")
        self.add_entry(lease_tab, 1, 0, "Commencement Date", "commencement_date")
        self.add_entry(lease_tab, 1, 2, "Rent per Payment Period", "payment")

        self.add_combo(
            lease_tab, 2, 0, "Payment Frequency", "frequency",
            ["Monthly", "Quarterly", "Half-Yearly", "Yearly"]
        )
        self.add_combo(
            lease_tab, 2, 2, "Payment Timing", "payment_timing",
            ["End of Period", "Beginning of Period"]
        )

        self.add_entry(lease_tab, 3, 0, "Annual Discount / IBR %", "annual_rate")
        self.add_entry(lease_tab, 3, 2, "Number of Payment Periods", "periods")
        self.add_entry(lease_tab, 4, 0, "Initial Direct Costs", "direct_cost")
        self.add_entry(lease_tab, 4, 2, "Prepaid Lease Payments", "prepaid")
        self.add_entry(lease_tab, 5, 0, "Lease Incentives", "incentive")
        self.add_entry(
            lease_tab, 5, 2, "ROU Depreciation Months", "depreciation_months"
        )

        ttk.Label(
            lease_tab,
            text=(
                "For a 5-year monthly lease: Periods = 60 and "
                "ROU depreciation months normally = 60, unless "
                "another depreciation period is justified."
            ),
            wraplength=900
        ).grid(row=6, column=0, columnspan=4, sticky="w", pady=8)

        self.add_entry(
            security_tab, 0, 0,
            "Rent Security Deposit Paid", "security_deposit"
        )
        self.add_entry(
            security_tab, 0, 2,
            "Refund Period (Months)", "security_months"
        )
        self.add_entry(
            security_tab, 1, 0,
            "Borrowing / Market Rate %", "borrowing_rate"
        )

        ttk.Label(
            security_tab,
            text=(
                "The borrowing / market rate is used to discount the "
                "refundable security deposit and calculate subsequent "
                "effective-interest unwinding."
            ),
            wraplength=900
        ).grid(row=2, column=0, columnspan=4, sticky="w", pady=8)

        self.add_entry(
            tax_tab, 0, 0,
            "Deferred Tax Rate %", "tax_rate"
        )
        self.add_entry(
            tax_tab, 1, 0,
            "Report As-Of Date", "report_date"
        )
        self.add_combo(
            tax_tab, 1, 2,
            "Report Frequency", "report_basis",
            ["Monthly", "Quarterly", "Half-Yearly", "Yearly"]
        )

        ttk.Label(
            tax_tab,
            text=(
                "DTA / DTL working in this tool assumes, by default, "
                "that the ROU asset tax base and lease-liability tax base "
                "are zero. This is a working-paper assumption and must "
                "be checked against the company's actual tax treatment."
            ),
            wraplength=1000
        ).grid(row=2, column=0, columnspan=4, sticky="w", pady=8)

    def add_entry(self, parent, row, col, label, key):
        ttk.Label(parent, text=label).grid(
            row=row, column=col, sticky="w", padx=5, pady=4
        )
        ttk.Entry(
            parent, textvariable=self.vars[key], width=30
        ).grid(
            row=row, column=col + 1, sticky="ew", padx=5, pady=4
        )

    def add_combo(self, parent, row, col, label, key, values):
        ttk.Label(parent, text=label).grid(
            row=row, column=col, sticky="w", padx=5, pady=4
        )
        ttk.Combobox(
            parent, textvariable=self.vars[key],
            values=values, state="readonly", width=28
        ).grid(
            row=row, column=col + 1, sticky="ew", padx=5, pady=4
        )

    def build_kpis(self, parent):
        f = ttk.LabelFrame(parent, text="Selected Lease / Reporting Snapshot", padding=8)
        f.pack(fill="x", pady=(0, 8))

        self.kpi_vars = {
            "liability": tk.StringVar(value=money(0)),
            "rou": tk.StringVar(value=money(0)),
            "interest": tk.StringVar(value=money(0)),
            "depreciation": tk.StringVar(value=money(0)),
            "dta": tk.StringVar(value=money(0)),
            "dtl": tk.StringVar(value=money(0)),
            "security": tk.StringVar(value=money(0)),
        }

        labels = [
            ("Lease Liability", "liability"),
            ("ROU Asset", "rou"),
            ("Interest", "interest"),
            ("Depreciation", "depreciation"),
            ("DTA", "dta"),
            ("DTL", "dtl"),
            ("Security Deposit Asset", "security"),
        ]

        for i, (title, key) in enumerate(labels):
            box = ttk.Frame(f)
            box.grid(row=0, column=i, sticky="ew", padx=8)
            ttk.Label(box, text=title, style="Small.TLabel").pack(anchor="w")
            ttk.Label(
                box, textvariable=self.kpi_vars[key], style="KPI.TLabel"
            ).pack(anchor="w")
            f.grid_columnconfigure(i, weight=1)

    def build_report_controls(self, parent):
        f = ttk.Frame(parent)
        f.pack(fill="x", pady=(0, 8))

        ttk.Button(
            f, text="Calculate / Save Lease",
            command=self.calculate_save
        ).pack(side="left", padx=(0, 5))

        ttk.Button(
            f, text="Load Selected Lease",
            command=self.load_selected_lease
        ).pack(side="left", padx=5)

        ttk.Button(
            f, text="New Lease",
            command=self.new_lease
        ).pack(side="left", padx=5)

        ttk.Button(
            f, text="Refresh Report",
            command=self.refresh_report
        ).pack(side="left", padx=5)

        ttk.Button(
            f, text="Export Current Report",
            command=self.export_current_report
        ).pack(side="left", padx=5)

        ttk.Button(
            f, text="Export Consolidated Report",
            command=self.export_consolidated
        ).pack(side="left", padx=5)

        ttk.Button(
            f, text="Clear",
            command=self.clear_all
        ).pack(side="left", padx=5)

        ttk.Label(
            f,
            text="Report frequency is controlled under Deferred Tax / Reporting."
        ).pack(side="left", padx=15)

    def build_output_notebook(self, parent):
        self.output_nb = ttk.Notebook(parent)
        self.output_nb.pack(fill="both", expand=True)

        self.dashboard_tab = ttk.Frame(self.output_nb)
        self.register_tab = ttk.Frame(self.output_nb)
        self.liability_tab = ttk.Frame(self.output_nb)
        self.rou_tab = ttk.Frame(self.output_nb)
        self.tax_tab = ttk.Frame(self.output_nb)
        self.security_tab = ttk.Frame(self.output_nb)
        self.journal_tab = ttk.Frame(self.output_nb)

        self.output_nb.add(self.dashboard_tab, text="Branch / Consolidated Dashboard")
        self.output_nb.add(self.register_tab, text="Lease Register")
        self.output_nb.add(self.liability_tab, text="Lease Liability")
        self.output_nb.add(self.rou_tab, text="ROU & Depreciation")
        self.output_nb.add(self.tax_tab, text="DTA / DTL")
        self.output_nb.add(self.security_tab, text="Security Deposit")
        self.output_nb.add(self.journal_tab, text="Accounting Summary")

        self.trees = {}
        self.trees["dashboard"] = self.make_tree(
            self.dashboard_tab,
            [
                ("branch", "Branch", 120),
                ("leases", "Leases", 70),
                ("liability", "Lease Liability", 150),
                ("rou", "ROU Asset", 150),
                ("interest", "Interest", 140),
                ("depreciation", "Depreciation", 140),
                ("dta", "DTA", 140),
                ("dtl", "DTL", 140),
            ]
        )

        self.trees["register"] = self.make_tree(
            self.register_tab,
            [
                ("branch", "Branch", 100),
                ("lease_id", "Lease ID", 100),
                ("lease", "Lease Name", 170),
                ("date", "Commencement", 110),
                ("payment", "Rent / Period", 130),
                ("rate", "IBR %", 80),
                ("liability", "Initial Liability", 150),
                ("security", "Security Deposit", 150),
                ("security_pv", "Security PV", 150),
                ("rou", "Initial ROU", 150),
            ]
        )

        self.trees["liability"] = self.make_tree(
            self.liability_tab,
            [
                ("period", "Period", 90),
                ("date", "Date", 100),
                ("opening", "Opening Liability", 160),
                ("interest", "Interest", 140),
                ("payment", "Payment", 140),
                ("closing", "Closing Liability", 160),
            ]
        )

        self.trees["rou"] = self.make_tree(
            self.rou_tab,
            [
                ("period", "Period", 90),
                ("date", "Date", 100),
                ("opening", "Opening ROU", 150),
                ("depreciation", "Depreciation", 150),
                ("closing", "Closing ROU", 150),
            ]
        )

        self.trees["tax"] = self.make_tree(
            self.tax_tab,
            [
                ("period", "Period", 100),
                ("date", "Date", 100),
                ("dta", "DTA", 150),
                ("dtl", "DTL", 150),
                ("net", "Net DTA / (DTL)", 170),
            ]
        )

        self.trees["security"] = self.make_tree(
            self.security_tab,
            [
                ("period", "Period", 90),
                ("date", "Date", 100),
                ("opening", "Opening Asset", 150),
                ("interest", "EIR Unwinding", 150),
                ("closing", "Closing Asset", 150),
            ]
        )

        self.trees["journal"] = self.make_tree(
            self.journal_tab,
            [
                ("particular", "Particular", 260),
                ("debit", "Debit", 180),
                ("credit", "Credit", 180),
                ("note", "Accounting Note", 650),
            ]
        )

    def make_tree(self, parent, columns):
        frame = ttk.Frame(parent)
        frame.pack(fill="both", expand=True)

        ids = [c[0] for c in columns]
        tree = ttk.Treeview(frame, columns=ids, show="headings")

        for cid, title, width in columns:
            tree.heading(cid, text=title)
            tree.column(
                cid,
                width=width,
                anchor="center" if cid in ("period", "date", "rate") else "e"
            )

        vs = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        hs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)

        tree.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")

        frame.grid_rowconfigure(0, weight=1)
        frame.grid_columnconfigure(0, weight=1)

        return tree

    # --------------------------------------------------------
    # BRANCH MANAGEMENT
    # --------------------------------------------------------

    def add_branch(self):
        try:
            code = self.vars["branch_code"].get().strip().upper()
            name = self.vars["branch_name"].get().strip()

            if not code:
                raise ValueError("Please enter Branch Code.")
            if not name:
                raise ValueError("Please enter Branch Name.")
            if "," in code:
                raise ValueError("Branch Code should not contain comma.")

            if code not in self.branches:
                self.branches[code] = {"name": name, "leases": {}}
                msg = "Branch added successfully."
            else:
                self.branches[code]["name"] = name
                msg = "Branch updated successfully."

            self.selected_branch = code
            self.refresh_all()
            messagebox.showinfo("Branch Master", msg)

        except ValueError as e:
            messagebox.showerror("Branch Error", str(e))

    def delete_branch(self):
        code = self.selected_branch
        if not code or code not in self.branches:
            messagebox.showwarning("Branch", "Please select a branch.")
            return

        leases = self.branches[code]["leases"]
        if leases:
            if not messagebox.askyesno(
                "Delete Branch",
                f"Branch contains {len(leases)} lease(s).\n"
                "Delete branch and all its lease data from this session?"
            ):
                return

        del self.branches[code]
        self.selected_branch = None
        self.selected_lease = None
        self.clear_lease_fields()
        self.refresh_all()

    def branch_changed(self, event=None):
        selected = self.branch_combo.get().strip()
        if not selected:
            return
        self.selected_branch = selected.split(" | ", 1)[0]
        self.selected_lease = None

        branch = self.branches[self.selected_branch]
        self.vars["branch_code"].set(self.selected_branch)
        self.vars["branch_name"].set(branch["name"])

        self.clear_lease_fields(preserve_branch=True)
        self.refresh_all()

    # --------------------------------------------------------
    # INPUT / RECORD
    # --------------------------------------------------------

    def collect_record(self):
        if not self.selected_branch:
            raise ValueError("Please add and select a branch first.")

        lease_id = self.vars["lease_id"].get().strip()
        lease_name = self.vars["lease_name"].get().strip()

        if not lease_id:
            raise ValueError("Please enter Lease ID.")
        if not lease_name:
            raise ValueError("Please enter Lease / Contract Name.")

        start = parse_date(
            self.vars["commencement_date"].get(),
            "Commencement Date"
        )

        payment = parse_decimal(
            self.vars["payment"].get(),
            "Rent / Lease Payment",
            D("0.01")
        )

        frequency = self.vars["frequency"].get()
        timing = self.vars["payment_timing"].get()

        annual_rate = parse_decimal(
            self.vars["annual_rate"].get(),
            "Annual Discount / IBR Rate"
        )
        if annual_rate >= D("100"):
            raise ValueError("Annual Discount / IBR Rate should normally be below 100%.")

        periods = parse_int(
            self.vars["periods"].get(),
            "Number of Payment Periods"
        )

        direct_cost = parse_decimal(
            self.vars["direct_cost"].get(), "Initial Direct Costs"
        )
        prepaid = parse_decimal(
            self.vars["prepaid"].get(), "Prepaid Lease Payments"
        )
        incentive = parse_decimal(
            self.vars["incentive"].get(), "Lease Incentives"
        )

        depreciation_months = parse_int(
            self.vars["depreciation_months"].get(),
            "ROU Depreciation Months"
        )

        security_deposit = parse_decimal(
            self.vars["security_deposit"].get(),
            "Rent Security Deposit"
        )

        if security_deposit > ZERO:
            security_months = parse_int(
                self.vars["security_months"].get(),
                "Security Deposit Refund Period (Months)"
            )
            borrowing_rate = parse_decimal(
                self.vars["borrowing_rate"].get(),
                "Borrowing / Market Rate"
            )
            if borrowing_rate >= D("100"):
                raise ValueError("Borrowing / Market Rate should normally be below 100%.")
        else:
            security_months = 1
            borrowing_rate = ZERO

        tax_rate = parse_decimal(
            self.vars["tax_rate"].get(),
            "Deferred Tax Rate"
        )
        if tax_rate > D("100"):
            raise ValueError("Deferred Tax Rate cannot exceed 100%.")

        # Lease PV is calculated using the contractual payment frequency.
        periodic_rate = annual_to_periodic(annual_rate, frequency)
        beginning = timing == "Beginning of Period"

        lease_liability = pv_of_payments(
            payment,
            periodic_rate,
            periods,
            beginning
        )

        # Security deposit PV.
        if security_deposit > ZERO:
            security_periodic_rate = annual_to_periodic(
                borrowing_rate, "Monthly"
            )
            security_pv = (
                security_deposit /
                ((D("1") + security_periodic_rate) ** D(security_months))
            )
        else:
            security_periodic_rate = ZERO
            security_pv = ZERO

        security_difference = security_deposit - security_pv

        # Initial ROU:
        # Lease liability + direct costs + prepayments - incentives
        # + lease-related security deposit discount.
        rou = (
            lease_liability
            + direct_cost
            + prepaid
            - incentive
            + security_difference
        )

        if rou < ZERO:
            raise ValueError(
                "Initial ROU asset is negative. "
                "Please verify lease incentives / other inputs."
            )

        return {
            "branch_code": self.selected_branch,
            "branch_name": self.branches[self.selected_branch]["name"],
            "lease_id": lease_id,
            "lease_name": lease_name,
            "commencement_date": start,
            "payment": payment,
            "frequency": frequency,
            "payment_timing": timing,
            "annual_rate": annual_rate,
            "periods": periods,
            "direct_cost": direct_cost,
            "prepaid": prepaid,
            "incentive": incentive,
            "depreciation_months": depreciation_months,
            "security_deposit": security_deposit,
            "security_months": security_months,
            "borrowing_rate": borrowing_rate,
            "security_monthly_rate": security_periodic_rate,
            "security_initial_pv": security_pv,
            "security_difference": security_difference,
            "initial_lease_liability": lease_liability,
            "initial_rou_asset": rou,
            "tax_rate": tax_rate,
            "tax_base_rou_zero": True,
            "tax_base_lease_liability_zero": True,
        }

    def calculate_save(self):
        try:
            rec = self.collect_record()
            rows = build_monthly_lease_schedule(rec)
            rec["schedule"] = rows

            self.branches[self.selected_branch]["leases"][rec["lease_id"]] = rec
            self.selected_lease = rec["lease_id"]

            self.populate_register()
            self.refresh_report()
            self.update_kpis()

            messagebox.showinfo(
                "Lease Saved",
                "Lease calculated and saved successfully.\n\n"
                f"Branch: {rec['branch_code']}\n"
                f"Lease: {rec['lease_name']}\n"
                f"Initial Lease Liability: {money(rec['initial_lease_liability'])}\n"
                f"Security Deposit PV: {money(rec['security_initial_pv'])}\n"
                f"Initial ROU Asset: {money(rec['initial_rou_asset'])}"
            )

        except ValueError as e:
            messagebox.showerror("Input / Calculation Error", str(e))
        except Exception as e:
            messagebox.showerror(
                "Unexpected Error",
                f"The lease could not be calculated.\n\nDetails: {e}"
            )

    def load_selected_lease(self):
        tree = self.trees["register"]
        selection = tree.selection()
        if not selection:
            messagebox.showwarning(
                "Lease Selection",
                "Please select a lease from the Lease Register."
            )
            return

        values = tree.item(selection[0], "values")
        branch = str(values[0])
        lease_id = str(values[1])

        if branch not in self.branches:
            return
        rec = self.branches[branch]["leases"].get(lease_id)
        if not rec:
            messagebox.showerror("Lease", "Lease record could not be found.")
            return

        self.selected_branch = branch
        self.selected_lease = lease_id

        self.vars["branch_code"].set(branch)
        self.vars["branch_name"].set(rec["branch_name"])
        self.vars["lease_id"].set(rec["lease_id"])
        self.vars["lease_name"].set(rec["lease_name"])
        self.vars["commencement_date"].set(fmt_date(rec["commencement_date"]))
        self.vars["payment"].set(str(rec["payment"]))
        self.vars["frequency"].set(rec["frequency"])
        self.vars["payment_timing"].set(rec["payment_timing"])
        self.vars["annual_rate"].set(str(rec["annual_rate"]))
        self.vars["periods"].set(str(rec["periods"]))
        self.vars["direct_cost"].set(str(rec["direct_cost"]))
        self.vars["prepaid"].set(str(rec["prepaid"]))
        self.vars["incentive"].set(str(rec["incentive"]))
        self.vars["depreciation_months"].set(str(rec["depreciation_months"]))
        self.vars["security_deposit"].set(str(rec["security_deposit"]))
        self.vars["security_months"].set(str(rec["security_months"]))
        self.vars["borrowing_rate"].set(str(rec["borrowing_rate"]))
        self.vars["tax_rate"].set(str(rec["tax_rate"]))

        self.refresh_all()

    def new_lease(self):
        self.selected_lease = None
        self.clear_lease_fields(preserve_branch=True)
        self.clear_output_tables()
        self.update_kpis()

    # --------------------------------------------------------
    # REPORTING
    # --------------------------------------------------------

    def get_report_date(self):
        return parse_date(
            self.vars["report_date"].get(),
            "Report As-Of Date"
        )

    def get_selected_record(self):
        if not self.selected_branch:
            return None
        branch = self.branches.get(self.selected_branch)
        if not branch:
            return None
        if not self.selected_lease:
            return None
        return branch["leases"].get(self.selected_lease)

    def refresh_report(self):
        try:
            as_of = self.get_report_date()
        except ValueError as e:
            messagebox.showerror("Reporting Date", str(e))
            return

        rec = self.get_selected_record()

        if rec:
            rows = [r for r in rec["schedule"] if r["date"] <= as_of]
            self.populate_schedule_tables(
                rows,
                self.vars["report_basis"].get()
            )
        else:
            self.populate_consolidated_dashboard(as_of)
            self.populate_register()

        self.update_kpis()

    def populate_schedule_tables(self, rows, basis):
        agg = aggregate_rows(rows, rows[-1]["date"], basis) if rows else []

        self.fill_tree(
            self.trees["liability"],
            [
                (
                    x["period"], fmt_date(x["date"]),
                    money(x["opening_liability"]),
                    money(x["interest"]),
                    money(x["payment"]),
                    money(x["closing_liability"])
                )
                for x in agg
            ]
        )

        self.fill_tree(
            self.trees["rou"],
            [
                (
                    x["period"], fmt_date(x["date"]),
                    money(x["opening_rou"]),
                    money(x["depreciation"]),
                    money(x["closing_rou"])
                )
                for x in agg
            ]
        )

        self.fill_tree(
            self.trees["tax"],
            [
                (
                    x["period"], fmt_date(x["date"]),
                    money(x["dta"]),
                    money(x["dtl"]),
                    money(x["net_deferred_tax"])
                )
                for x in agg
            ]
        )

        self.fill_tree(
            self.trees["security"],
            [
                (
                    x["period"], fmt_date(x["date"]),
                    money(x["security_opening"]),
                    money(x["security_interest"]),
                    money(x["security_closing"])
                )
                for x in agg
            ]
        )

        self.populate_journal(rows[-1] if rows else None)

        if rows:
            self.output_nb.select(self.liability_tab)

    def populate_journal(self, row):
        self.clear_tree(self.trees["journal"])

        if not row:
            return

        entries = [
            (
                "Right-of-use asset",
                money(row["closing_rou"]),
                "",
                "Closing ROU asset balance."
            ),
            (
                "Lease liability",
                "",
                money(row["closing_liability"]),
                "Closing lease liability balance."
            ),
            (
                "Lease finance cost / interest",
                money(row["interest"]),
                "",
                "Interest accretion for reporting period."
            ),
            (
                "ROU depreciation expense",
                money(row["depreciation"]),
                "",
                "Depreciation of ROU asset."
            ),
            (
                "Security deposit financial asset",
                money(row["security_closing"]),
                "",
                "Closing financial asset for refundable deposit."
            ),
            (
                "Security deposit EIR income / unwinding",
                "",
                money(row["security_interest"]),
                "Effective interest unwinding; presentation should be reviewed."
            ),
            (
                "Deferred tax asset",
                money(row["dta"]),
                "",
                "Based on assumed tax base of lease liability."
            ),
            (
                "Deferred tax liability",
                "",
                money(row["dtl"]),
                "Based on assumed tax base of ROU asset."
            ),
        ]
        self.fill_tree(self.trees["journal"], entries)

    def populate_consolidated_dashboard(self, as_of):
        rows = []

        for code, branch in sorted(self.branches.items()):
            leases = branch["leases"]

            liability = rou = interest = depreciation = dta = dtl = ZERO

            for rec in leases.values():
                valid = [r for r in rec["schedule"] if r["date"] <= as_of]
                if not valid:
                    continue
                last = valid[-1]
                liability += last["closing_liability"]
                rou += last["closing_rou"]
                dta += last["dta"]
                dtl += last["dtl"]

                if self.vars["report_basis"].get() == "Monthly":
                    current = valid[-1:]
                else:
                    current = aggregate_rows(
                        valid, valid[-1]["date"],
                        self.vars["report_basis"].get()
                    )[-1:]

                for x in current:
                    interest += x["interest"]
                    depreciation += x["depreciation"]

            rows.append((
                code,
                len(leases),
                money(liability),
                money(rou),
                money(interest),
                money(depreciation),
                money(dta),
                money(dtl)
            ))

        self.fill_tree(self.trees["dashboard"], rows)

    def populate_register(self):
        rows = []

        for code, branch in sorted(self.branches.items()):
            for lease_id, rec in sorted(branch["leases"].items()):
                rows.append((
                    code,
                    lease_id,
                    rec["lease_name"],
                    fmt_date(rec["commencement_date"]),
                    money(rec["payment"]),
                    f"{rec['annual_rate']:.2f}%",
                    money(rec["initial_lease_liability"]),
                    money(rec["security_deposit"]),
                    money(rec["security_initial_pv"]),
                    money(rec["initial_rou_asset"]),
                ))

        self.fill_tree(self.trees["register"], rows)

    def update_kpis(self):
        rec = self.get_selected_record()

        if not rec:
            for v in self.kpi_vars.values():
                v.set(money(0))
            return

        try:
            as_of = self.get_report_date()
        except ValueError:
            return

        valid = [r for r in rec["schedule"] if r["date"] <= as_of]
        if not valid:
            for v in self.kpi_vars.values():
                v.set(money(0))
            return

        last = valid[-1]
        basis = self.vars["report_basis"].get()

        if basis == "Monthly":
            report_rows = valid[-1:]
        else:
            report_rows = aggregate_rows(valid, last["date"], basis)[-1:]

        x = report_rows[-1] if report_rows else last

        self.kpi_vars["liability"].set(money(last["closing_liability"]))
        self.kpi_vars["rou"].set(money(last["closing_rou"]))
        self.kpi_vars["interest"].set(money(x["interest"]))
        self.kpi_vars["depreciation"].set(money(x["depreciation"]))
        self.kpi_vars["dta"].set(money(last["dta"]))
        self.kpi_vars["dtl"].set(money(last["dtl"]))
        self.kpi_vars["security"].set(money(last["security_closing"]))

    # --------------------------------------------------------
    # REFRESH / CLEAR
    # --------------------------------------------------------

    def refresh_all(self):
        values = [
            f"{c} | {self.branches[c]['name']}"
            for c in sorted(self.branches)
        ]
        self.branch_combo["values"] = values

        if self.selected_branch in self.branches:
            self.branch_combo.set(
                f"{self.selected_branch} | "
                f"{self.branches[self.selected_branch]['name']}"
            )
        else:
            self.branch_combo.set("")

        self.branch_count_label.config(
            text=f"Branches: {len(self.branches)}"
        )

        self.populate_register()

        try:
            self.refresh_report()
        except Exception:
            pass

    def clear_lease_fields(self, preserve_branch=False):
        branch_code = self.vars["branch_code"].get()
        branch_name = self.vars["branch_name"].get()

        defaults = {
            "lease_id": "",
            "lease_name": "",
            "commencement_date": "",
            "payment": "",
            "frequency": "Monthly",
            "payment_timing": "End of Period",
            "annual_rate": "",
            "periods": "",
            "direct_cost": "0",
            "prepaid": "0",
            "incentive": "0",
            "depreciation_months": "",
            "security_deposit": "0",
            "security_months": "",
            "borrowing_rate": "",
        }

        for k, v in defaults.items():
            self.vars[k].set(v)

        if preserve_branch:
            self.vars["branch_code"].set(branch_code)
            self.vars["branch_name"].set(branch_name)
        else:
            self.vars["branch_code"].set("")
            self.vars["branch_name"].set("")

    def clear_all(self):
        self.selected_branch = None
        self.selected_lease = None
        self.clear_lease_fields()
        self.clear_output_tables()
        self.refresh_all()

    def clear_output_tables(self):
        for tree in self.trees.values():
            self.clear_tree(tree)

    @staticmethod
    def clear_tree(tree):
        for item in tree.get_children():
            tree.delete(item)

    @staticmethod
    def fill_tree(tree, rows):
        for item in tree.get_children():
            tree.delete(item)
        for row in rows:
            tree.insert("", "end", values=row)

    # --------------------------------------------------------
    # EXPORT
    # --------------------------------------------------------

    def export_current_report(self):
        try:
            as_of = self.get_report_date()
        except ValueError as e:
            messagebox.showerror("Reporting Date", str(e))
            return

        rec = self.get_selected_record()
        if not rec:
            messagebox.showwarning(
                "Export",
                "Please select a lease to export the current lease report."
            )
            return

        path = filedialog.asksaveasfilename(
            title="Export Current Lease Report",
            defaultextension=".csv",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if not path:
            return

        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)

                w.writerow(["LEASE ACCOUNTING REPORT"])
                w.writerow(["Branch", rec["branch_code"]])
                w.writerow(["Branch Name", rec["branch_name"]])
                w.writerow(["Lease ID", rec["lease_id"]])
                w.writerow(["Lease", rec["lease_name"]])
                w.writerow(["As of Date", fmt_date(as_of)])
                w.writerow(["Reporting Basis", self.vars["report_basis"].get()])
                w.writerow([])

                w.writerow([
                    "Period", "Date", "Opening Lease Liability",
                    "Interest", "Payment", "Closing Lease Liability",
                    "Opening ROU", "Depreciation", "Closing ROU",
                    "Security Opening", "Security EIR",
                    "Security Closing", "DTA", "DTL", "Net DTA/(DTL)"
                ])

                rows = [
                    r for r in rec["schedule"]
                    if r["date"] <= as_of
                ]
                agg = aggregate_rows(
                    rows,
                    as_of,
                    self.vars["report_basis"].get()
                )

                for x in agg:
                    w.writerow([
                        x["period"], fmt_date(x["date"]),
                        number_text(x["opening_liability"]),
                        number_text(x["interest"]),
                        number_text(x["payment"]),
                        number_text(x["closing_liability"]),
                        number_text(x["opening_rou"]),
                        number_text(x["depreciation"]),
                        number_text(x["closing_rou"]),
                        number_text(x["security_opening"]),
                        number_text(x["security_interest"]),
                        number_text(x["security_closing"]),
                        number_text(x["dta"]),
                        number_text(x["dtl"]),
                        number_text(x["net_deferred_tax"]),
                    ])

            messagebox.showinfo(
                "Export Successful",
                f"Current lease report exported successfully.\n\n{path}"
            )

        except PermissionError:
            messagebox.showerror(
                "File Access Error",
                "The CSV file is open or locked by another application.\n\n"
                "Please close it in Excel and try again."
            )
        except OSError as e:
            messagebox.showerror("File Error", f"Could not save CSV.\n\n{e}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    def export_consolidated(self):
        total_leases = sum(
            len(b["leases"]) for b in self.branches.values()
        )
        if total_leases == 0:
            messagebox.showwarning(
                "Export",
                "There is no lease data to export."
            )
            return

        try:
            as_of = self.get_report_date()
        except ValueError as e:
            messagebox.showerror("Reporting Date", str(e))
            return

        path = filedialog.asksaveasfilename(
            title="Export Consolidated Lease Accounting Report",
            defaultextension=".csv",
            filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
        )
        if not path:
            return

        try:
            with open(path, "w", newline="", encoding="utf-8-sig") as f:
                w = csv.writer(f)

                w.writerow(["CONSOLIDATED LEASE REGISTER"])
                w.writerow([
                    "Branch Code", "Branch Name", "Lease ID", "Lease Name",
                    "Commencement", "Frequency", "Payment Timing",
                    "Rent / Period", "IBR %", "Periods",
                    "Initial Lease Liability",
                    "Security Deposit", "Borrowing Rate %",
                    "Security PV", "Security Discount",
                    "Initial ROU", "ROU Depreciation Months",
                    "Tax Rate %"
                ])

                for code, branch in sorted(self.branches.items()):
                    for rec in branch["leases"].values():
                        w.writerow([
                            code,
                            branch["name"],
                            rec["lease_id"],
                            rec["lease_name"],
                            fmt_date(rec["commencement_date"]),
                            rec["frequency"],
                            rec["payment_timing"],
                            number_text(rec["payment"]),
                            f"{rec['annual_rate']:.2f}",
                            rec["periods"],
                            number_text(rec["initial_lease_liability"]),
                            number_text(rec["security_deposit"]),
                            f"{rec['borrowing_rate']:.2f}",
                            number_text(rec["security_initial_pv"]),
                            number_text(rec["security_difference"]),
                            number_text(rec["initial_rou_asset"]),
                            rec["depreciation_months"],
                            f"{rec['tax_rate']:.2f}",
                        ])

                w.writerow([])

                w.writerow([
                    "CONSOLIDATED PERIODIC REPORT",
                    f"As of {fmt_date(as_of)}",
                    self.vars["report_basis"].get()
                ])
                w.writerow([
                    "Branch Code", "Branch Name", "Lease ID", "Lease Name",
                    "Period", "Date",
                    "Opening Lease Liability", "Interest", "Payment",
                    "Closing Lease Liability",
                    "Opening ROU", "Depreciation", "Closing ROU",
                    "Security Opening", "Security EIR",
                    "Security Closing", "DTA", "DTL", "Net DTA/(DTL)"
                ])

                for code, branch in sorted(self.branches.items()):
                    for rec in branch["leases"].values():
                        rows = [
                            r for r in rec["schedule"]
                            if r["date"] <= as_of
                        ]
                        agg = aggregate_rows(
                            rows,
                            as_of,
                            self.vars["report_basis"].get()
                        )

                        for x in agg:
                            w.writerow([
                                code,
                                branch["name"],
                                rec["lease_id"],
                                rec["lease_name"],
                                x["period"],
                                fmt_date(x["date"]),
                                number_text(x["opening_liability"]),
                                number_text(x["interest"]),
                                number_text(x["payment"]),
                                number_text(x["closing_liability"]),
                                number_text(x["opening_rou"]),
                                number_text(x["depreciation"]),
                                number_text(x["closing_rou"]),
                                number_text(x["security_opening"]),
                                number_text(x["security_interest"]),
                                number_text(x["security_closing"]),
                                number_text(x["dta"]),
                                number_text(x["dtl"]),
                                number_text(x["net_deferred_tax"]),
                            ])

                w.writerow([])

                w.writerow(["BRANCH-WISE CLOSING SUMMARY"])
                w.writerow([
                    "Branch Code", "Branch Name", "No. of Leases",
                    "Lease Liability", "ROU Asset",
                    "DTA", "DTL", "Net DTA/(DTL)"
                ])

                for code, branch in sorted(self.branches.items()):
                    liability = rou = dta = dtl = ZERO

                    for rec in branch["leases"].values():
                        valid = [
                            r for r in rec["schedule"]
                            if r["date"] <= as_of
                        ]
                        if not valid:
                            continue
                        last = valid[-1]
                        liability += last["closing_liability"]
                        rou += last["closing_rou"]
                        dta += last["dta"]
                        dtl += last["dtl"]

                    w.writerow([
                        code,
                        branch["name"],
                        len(branch["leases"]),
                        number_text(liability),
                        number_text(rou),
                        number_text(dta),
                        number_text(dtl),
                        number_text(dta - dtl)
                    ])

                w.writerow([])

                liability = rou = dta = dtl = ZERO

                for branch in self.branches.values():
                    for rec in branch["leases"].values():
                        valid = [
                            r for r in rec["schedule"]
                            if r["date"] <= as_of
                        ]
                        if not valid:
                            continue
                        last = valid[-1]
                        liability += last["closing_liability"]
                        rou += last["closing_rou"]
                        dta += last["dta"]
                        dtl += last["dtl"]

                w.writerow(["CONSOLIDATED CLOSING SUMMARY"])
                w.writerow([
                    "No. of Branches", len(self.branches),
                    "No. of Leases", total_leases
                ])
                w.writerow(["Lease Liability", number_text(liability)])
                w.writerow(["ROU Asset", number_text(rou)])
                w.writerow(["DTA", number_text(dta)])
                w.writerow(["DTL", number_text(dtl)])
                w.writerow(["Net DTA/(DTL)", number_text(dta - dtl)])

            messagebox.showinfo(
                "Export Successful",
                "Consolidated report exported successfully.\n\n"
                f"Branches: {len(self.branches)}\n"
                f"Leases: {total_leases}\n"
                f"File: {path}"
            )

        except PermissionError:
            messagebox.showerror(
                "File Access Error",
                "The CSV file is open or locked by another application.\n\n"
                "Please close it in Excel and try again."
            )
        except OSError as e:
            messagebox.showerror("File Error", f"Could not save CSV.\n\n{e}")
        except Exception as e:
            messagebox.showerror("Export Error", str(e))


def main():
    root = tk.Tk()
    app = LeaseApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()