import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));

// -------------------------------------------------------------
// In-Memory & File-backed Store for UAE Tax Suite
// -------------------------------------------------------------

export interface Entity {
  id: string;
  name: string;
  name_ar?: string;
  location: 'Mainland' | 'Designated Zone' | 'Free Zone';
  free_zone_name?: string;
  vat_trn: string;
  vat_registered: 'Yes' | 'No';
  vat_frequency: 'Quarterly' | 'Monthly';
  vat_period_end: string;
  vat_filed: 'Yes' | 'No';
  vat_paid: 'Yes' | 'No';
  vat_emirate?: string;
  address?: string;
  po_box?: string;
  landline?: string;
  std_supplies: number;
  zero_supplies: number;
  exempt_supplies: number;
  dz_goods_supplies: number;
  taxable_supplies_12m: number;
  input_vat: number;
  blocked_input_vat: number;
  reverse_charge_vat: number;
  vat_open_exceptions: number;
  tourist_refund_vat: number;
  import_goods_value: number;
  import_vat: number;
  import_adjust_vat: number;
  sales_cn_net: number;
  sales_cn_vat: number;
  purchase_cn_net: number;
  purchase_cn_vat: number;
  bad_debt_vat: number;
  deemed_supplies_vat: number;
  change_in_use_vat: number;
  capital_assets_vat: number;
  prior_period_error_vat: number;
  margin_scheme: 'Yes' | 'No';
  gl_sales_revenue: number;
  gl_output_vat: number;
  gl_input_vat: number;
}

export interface VatRow {
  id: string;
  entity_id: string;
  period_end: string;
  doc_date: string;
  doc_no: string;
  party: string;
  party_trn?: string;
  emirate?: string;
  doc_type: 
    | 'Sale - standard rated'
    | 'Sale - zero rated'
    | 'Sale - exempt'
    | 'Sale - designated zone goods'
    | 'Sale - credit note'
    | 'Purchase - standard rated'
    | 'Purchase - blocked input VAT'
    | 'Purchase - reverse charge'
    | 'Purchase - credit note'
    | 'Purchase - capital asset'
    | 'Import of goods'
    | 'Import VAT adjustment'
    | 'Tourist refund'
    | 'Bad debt relief'
    | 'Deemed supply'
    | 'Change in use adjustment';
  net: number;
  vat: number;
  category?: string;
  description: string;
  receipt_id?: string;
  is_verified?: boolean;
}

export interface EncryptedDocument {
  id: string;
  entity_id: string;
  doc_no: string;
  file_name: string;
  file_type: string;
  file_size: number;
  uploaded_at: string;
  uploaded_by: string;
  encryption_algorithm: 'AES-256-GCM';
  key_derivation: 'PBKDF2-SHA256 (100k rounds)';
  cipher_iv: string;
  auth_tag: string;
  sha256_checksum: string;
  tamper_evident_status: 'VERIFIED_COMPLIANT' | 'FLAGGED';
  preview_url?: string;
  ocr_extracted_data?: {
    vendor?: string;
    trn?: string;
    date?: string;
    total?: number;
    vat?: number;
    suggested_category?: string;
  };
}

export interface AuditLog {
  id: string;
  timestamp: string;
  entity_id: string;
  user_name: string;
  user_role: string;
  action: string;
  category: 'TRANSACTION' | 'FILING' | 'VAULT_ENCRYPTION' | 'PERMISSION' | 'SYNC' | 'EXPORT';
  details: string;
  client_ip: string;
  device: string;
  hash: string;
}

export interface NotificationItem {
  id: string;
  entity_id: string;
  title: string;
  message: string;
  severity: 'high' | 'medium' | 'info';
  category: 'DEADLINE' | 'PAYMENT' | 'EXCEPTION' | 'SYNC';
  timestamp: string;
  is_read: boolean;
  action_link?: string;
}

// -------------------------------------------------------------
// Initial Data Seed
// -------------------------------------------------------------

let entities: Entity[] = [
  {
    id: 'E01',
    name: 'Al Noor Trading LLC',
    name_ar: 'شركة النور للتجارة ذ.م.م',
    location: 'Mainland',
    vat_trn: '100234567800003',
    vat_registered: 'Yes',
    vat_frequency: 'Quarterly',
    vat_period_end: '2026-09-30',
    vat_filed: 'No',
    vat_paid: 'No',
    vat_emirate: 'Dubai',
    address: 'Sheikh Zayed Road, Al Quoz 3',
    po_box: 'PO Box 84210',
    landline: '+971 4 338 9000',
    std_supplies: 4200000,
    zero_supplies: 600000,
    exempt_supplies: 0,
    dz_goods_supplies: 0,
    taxable_supplies_12m: 16500000,
    input_vat: 168000,
    blocked_input_vat: 6500,
    reverse_charge_vat: 12000,
    vat_open_exceptions: 4,
    tourist_refund_vat: 0,
    import_goods_value: 0,
    import_vat: 0,
    import_adjust_vat: 0,
    sales_cn_net: 40000,
    sales_cn_vat: 2000,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 0,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 4760000,
    gl_output_vat: 220000,
    gl_input_vat: 181500,
  },
  {
    id: 'E02',
    name: 'Falcon Logistics FZ-LLC',
    name_ar: 'صقر لوجستيكس ش.ذ.م.م-منطقة حرة',
    location: 'Designated Zone',
    free_zone_name: 'Jebel Ali Free Zone (JAFZA)',
    vat_trn: '100492837400003',
    vat_registered: 'Yes',
    vat_frequency: 'Quarterly',
    vat_period_end: '2026-09-30',
    vat_filed: 'Yes',
    vat_paid: 'No',
    vat_emirate: 'Dubai',
    address: 'Gate 4, JAFZA South',
    po_box: 'PO Box 17400',
    std_supplies: 1850000,
    zero_supplies: 4500000,
    exempt_supplies: 120000,
    dz_goods_supplies: 8900000,
    taxable_supplies_12m: 25400000,
    input_vat: 92500,
    blocked_input_vat: 4200,
    reverse_charge_vat: 24000,
    vat_open_exceptions: 1,
    tourist_refund_vat: 0,
    import_goods_value: 3200000,
    import_vat: 160000,
    import_adjust_vat: 0,
    sales_cn_net: 15000,
    sales_cn_vat: 750,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 18000,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 15370000,
    gl_output_vat: 276500,
    gl_input_vat: 112500,
  },
  {
    id: 'E03',
    name: 'Emirates Digital Media LLC',
    name_ar: 'الإمارات للإعلام الرقمي ذ.م.م',
    location: 'Mainland',
    vat_trn: '100881920300003',
    vat_registered: 'Yes',
    vat_frequency: 'Monthly',
    vat_period_end: '2026-10-31',
    vat_filed: 'No',
    vat_paid: 'No',
    vat_emirate: 'Abu Dhabi',
    address: 'Twofour54, Yas Creative Hub',
    po_box: 'PO Box 77800',
    std_supplies: 780000,
    zero_supplies: 350000,
    exempt_supplies: 0,
    dz_goods_supplies: 0,
    taxable_supplies_12m: 8900000,
    input_vat: 39000,
    blocked_input_vat: 1800,
    reverse_charge_vat: 16500,
    vat_open_exceptions: 0,
    tourist_refund_vat: 0,
    import_goods_value: 0,
    import_vat: 0,
    import_adjust_vat: 0,
    sales_cn_net: 0,
    sales_cn_vat: 0,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 0,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 1130000,
    gl_output_vat: 55500,
    gl_input_vat: 40800,
  },
  {
    id: 'E04',
    name: 'Desert Oasis Hospitality LLC',
    name_ar: 'ضيافة واحة الصحراء ذ.م.م',
    location: 'Mainland',
    vat_trn: '100772615400003',
    vat_registered: 'Yes',
    vat_frequency: 'Quarterly',
    vat_period_end: '2026-09-30',
    vat_filed: 'No',
    vat_paid: 'No',
    vat_emirate: 'Sharjah',
    address: 'Al Majaz Waterfront',
    po_box: 'PO Box 29300',
    std_supplies: 2150000,
    zero_supplies: 0,
    exempt_supplies: 0,
    dz_goods_supplies: 0,
    taxable_supplies_12m: 8600000,
    input_vat: 96000,
    blocked_input_vat: 8900,
    reverse_charge_vat: 0,
    vat_open_exceptions: 3,
    tourist_refund_vat: 4800,
    import_goods_value: 250000,
    import_vat: 12500,
    import_adjust_vat: 0,
    sales_cn_net: 8000,
    sales_cn_vat: 400,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 35000,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 2150000,
    gl_output_vat: 107500,
    gl_input_vat: 104900,
  },
  {
    id: 'E05',
    name: 'Gulf Precision Engineering',
    name_ar: 'الخليج للهندسة الدقيقة',
    location: 'Free Zone',
    free_zone_name: 'Sharjah Airport International Free Zone (SAIF)',
    vat_trn: '100994827100003',
    vat_registered: 'Yes',
    vat_frequency: 'Quarterly',
    vat_period_end: '2026-09-30',
    vat_filed: 'Yes',
    vat_paid: 'Yes',
    vat_emirate: 'Sharjah',
    address: 'SAIF Zone Q4-12',
    std_supplies: 3100000,
    zero_supplies: 1200000,
    exempt_supplies: 0,
    dz_goods_supplies: 0,
    taxable_supplies_12m: 14200000,
    input_vat: 145000,
    blocked_input_vat: 1200,
    reverse_charge_vat: 8000,
    vat_open_exceptions: 0,
    tourist_refund_vat: 0,
    import_goods_value: 800000,
    import_vat: 40000,
    import_adjust_vat: 0,
    sales_cn_net: 0,
    sales_cn_vat: 0,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 0,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 4300000,
    gl_output_vat: 195000,
    gl_input_vat: 146200,
  },
  {
    id: 'E06',
    name: 'Al Barakah General Merchants',
    name_ar: 'البركة للتجارة العامة',
    location: 'Mainland',
    vat_trn: '100119283700003',
    vat_registered: 'Yes',
    vat_frequency: 'Quarterly',
    vat_period_end: '2026-09-30',
    vat_filed: 'No',
    vat_paid: 'No',
    vat_emirate: 'Ajman',
    address: 'Al Jurf Industrial 2',
    std_supplies: 1200000,
    zero_supplies: 150000,
    exempt_supplies: 0,
    dz_goods_supplies: 0,
    taxable_supplies_12m: 4800000,
    input_vat: 48000,
    blocked_input_vat: 2400,
    reverse_charge_vat: 0,
    vat_open_exceptions: 2,
    tourist_refund_vat: 0,
    import_goods_value: 0,
    import_vat: 0,
    import_adjust_vat: 0,
    sales_cn_net: 12000,
    sales_cn_vat: 600,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 0,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 1350000,
    gl_output_vat: 60000,
    gl_input_vat: 50400,
  }
];

let vatRows: VatRow[] = [
  {
    id: 'VR-101',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-07-05',
    doc_no: 'INV-2026-081',
    party: 'Emaar Retail Group PJSC',
    party_trn: '100482910300003',
    emirate: 'Dubai',
    doc_type: 'Sale - standard rated',
    net: 850000,
    vat: 42500,
    category: 'Commercial Wholesale',
    description: 'Bulk electronics supply for Dubai Mall stores',
    receipt_id: 'DOC-801',
    is_verified: true,
  },
  {
    id: 'VR-102',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-07-18',
    doc_no: 'INV-2026-088',
    party: 'Aldar Properties PJSC',
    party_trn: '100593817200003',
    emirate: 'Abu Dhabi',
    doc_type: 'Sale - standard rated',
    net: 1200000,
    vat: 60000,
    category: 'Commercial Wholesale',
    description: 'Hardware installation contract Yas Bay',
    receipt_id: 'DOC-802',
    is_verified: true,
  },
  {
    id: 'VR-103',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-08-02',
    doc_no: 'INV-2026-094',
    party: 'Riyadh Distribution Ltd (KSA)',
    party_trn: '300994827100003',
    emirate: 'Dubai',
    doc_type: 'Sale - zero rated',
    net: 600000,
    vat: 0,
    category: 'Export of Goods (GCC/Intl)',
    description: 'Export of telecommunication equipment with customs exit proof',
    receipt_id: 'DOC-803',
    is_verified: true,
  },
  {
    id: 'VR-104',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-08-14',
    doc_no: 'BILL-4412',
    party: 'Amazon Web Services EMEA SARL',
    party_trn: 'N/A (Overseas B2B)',
    emirate: 'Dubai',
    doc_type: 'Purchase - reverse charge',
    net: 240000,
    vat: 12000,
    category: 'Cloud Services & SaaS',
    description: 'Quarterly cloud hosting infrastructure (Art 48 Reverse Charge)',
    receipt_id: 'DOC-804',
    is_verified: true,
  },
  {
    id: 'VR-105',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-08-22',
    doc_no: 'EXP-904',
    party: 'Atmosphere Burj Khalifa',
    party_trn: '100119283700003',
    emirate: 'Dubai',
    doc_type: 'Purchase - blocked input VAT',
    net: 130000,
    vat: 6500,
    category: 'Client Entertainment (Blocked)',
    description: 'Executive client corporate hospitality dinner (50% blocked input VAT)',
    receipt_id: 'DOC-805',
    is_verified: false,
  },
  {
    id: 'VR-106',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-09-10',
    doc_no: 'PO-3011',
    party: 'Canon Middle East FZ-LLC',
    party_trn: '100228391000003',
    emirate: 'Dubai',
    doc_type: 'Purchase - standard rated',
    net: 3160000,
    vat: 158000,
    category: 'Merchandise Inventory',
    description: 'Imported digital imaging units for retail distribution',
    receipt_id: 'DOC-806',
    is_verified: true,
  },
  {
    id: 'VR-107',
    entity_id: 'E01',
    period_end: '2026-09-30',
    doc_date: '2026-09-24',
    doc_no: 'CN-102',
    party: 'Emaar Retail Group PJSC',
    party_trn: '100482910300003',
    emirate: 'Dubai',
    doc_type: 'Sale - credit note',
    net: 40000,
    vat: 2000,
    category: 'Credit Adjustments',
    description: 'Return credit adjustment for damaged display shipment',
    receipt_id: 'DOC-807',
    is_verified: true,
  }
];

let encryptedDocuments: EncryptedDocument[] = [
  {
    id: 'DOC-801',
    entity_id: 'E01',
    doc_no: 'INV-2026-081',
    file_name: 'Tax_Invoice_Emaar_INV081.pdf',
    file_type: 'application/pdf',
    file_size: 245800,
    uploaded_at: '2026-07-05T09:30:00Z',
    uploaded_by: 'Senior Accountant (Fatima Al-Hashemi)',
    encryption_algorithm: 'AES-256-GCM',
    key_derivation: 'PBKDF2-SHA256 (100k rounds)',
    cipher_iv: 'e3b0c44298fc1c149afbf4c8',
    auth_tag: '7a38f99e4a821e21b0cd92348a129034',
    sha256_checksum: 'a9f24e12c4b8987b2210a48b3090ef81e2894b9102c3848b9192847291a92e10',
    tamper_evident_status: 'VERIFIED_COMPLIANT',
    ocr_extracted_data: {
      vendor: 'Emaar Retail Group PJSC',
      trn: '100482910300003',
      date: '2026-07-05',
      total: 892500,
      vat: 42500,
      suggested_category: 'Sale - standard rated',
    }
  },
  {
    id: 'DOC-804',
    entity_id: 'E01',
    doc_no: 'BILL-4412',
    file_name: 'AWS_EMEA_Cloud_Hosting_Q3.pdf',
    file_type: 'application/pdf',
    file_size: 182300,
    uploaded_at: '2026-08-14T11:15:00Z',
    uploaded_by: 'IT Lead (David Miller)',
    encryption_algorithm: 'AES-256-GCM',
    key_derivation: 'PBKDF2-SHA256 (100k rounds)',
    cipher_iv: '1f82c49902ac28919afcf3e2',
    auth_tag: '9128f73e4b819e21c0ad81247b919022',
    sha256_checksum: '8c919248b1092837e2894b9102c3848b9192847291a92e10a9f24e12c4b8987b',
    tamper_evident_status: 'VERIFIED_COMPLIANT',
    ocr_extracted_data: {
      vendor: 'Amazon Web Services EMEA SARL',
      trn: 'N/A',
      date: '2026-08-14',
      total: 252000,
      vat: 12000,
      suggested_category: 'Purchase - reverse charge',
    }
  },
  {
    id: 'DOC-805',
    entity_id: 'E01',
    doc_no: 'EXP-904',
    file_name: 'Atmosphere_Dining_Receipt_Scanned.jpg',
    file_type: 'image/jpeg',
    file_size: 1284000,
    uploaded_at: '2026-08-23T08:45:00Z',
    uploaded_by: 'Executive Assistant (Sara Khan)',
    encryption_algorithm: 'AES-256-GCM',
    key_derivation: 'PBKDF2-SHA256 (100k rounds)',
    cipher_iv: '99ac124802fc1c149afbf489',
    auth_tag: '12984b9102c3848b9192847291a92e10',
    sha256_checksum: '5f4829102c3848b9192847291a92e10a9f24e12c4b8987b2210a48b3090ef81e',
    tamper_evident_status: 'FLAGGED',
    ocr_extracted_data: {
      vendor: 'Atmosphere Burj Khalifa',
      trn: '100119283700003',
      date: '2026-08-22',
      total: 136500,
      vat: 6500,
      suggested_category: 'Purchase - blocked input VAT',
    }
  }
];

let auditLogs: AuditLog[] = [
  {
    id: 'LOG-001',
    timestamp: '2026-11-02T08:14:22Z',
    entity_id: 'E01',
    user_name: 'Fatima Al-Hashemi',
    user_role: 'Preparer',
    action: 'INVOICE_CATEGORIZED',
    category: 'TRANSACTION',
    details: 'Automated AI classification applied to BILL-4412 as Article 48 Reverse Charge.',
    client_ip: '194.170.24.12 (Dubai, UAE)',
    device: 'Mobile PWA (iOS 18.2 / iPhone 15 Pro)',
    hash: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'
  },
  {
    id: 'LOG-002',
    timestamp: '2026-11-02T09:02:11Z',
    entity_id: 'E01',
    user_name: 'Tariq Mansoor',
    user_role: 'Reviewer / Auditor',
    action: 'VAT_SCHEDULES_RECONCILED',
    category: 'FILING',
    details: 'Reconciled Box 12 output tax and General Ledger variance within AED 0.00 difference.',
    client_ip: '94.200.12.88 (Abu Dhabi, UAE)',
    device: 'Desktop Chrome 134 (macOS)',
    hash: '8f434346648f6b96df89dda901c5176b10a6d83961dd3c1ac88b59b2dc327aa4'
  },
  {
    id: 'LOG-003',
    timestamp: '2026-11-02T09:45:00Z',
    entity_id: 'E01',
    user_name: 'System Security Engine',
    user_role: 'System',
    action: 'ENCRYPTED_VAULT_BACKUP',
    category: 'VAULT_ENCRYPTION',
    details: 'Created tamper-evident cryptographic hash tree for 3 financial documents (SHA-256 integrity verified).',
    client_ip: '127.0.0.1 (Local Cloud Pod)',
    device: 'Cloud Node Server',
    hash: 'ca978112ca1bbdcafac231b39a23dc4da786eff8147c4e72b9807785afee48bb'
  }
];

let notifications: NotificationItem[] = [
  {
    id: 'NOTIF-1',
    entity_id: 'E01',
    title: 'VAT 201 Filing Deadline Alert',
    message: 'Al Noor Trading LLC Q3 VAT Return is due within 4 days (October 28 / Next cycle). Avoid late penalty of AED 1,000.',
    severity: 'high',
    category: 'DEADLINE',
    timestamp: '2026-11-02T08:00:00Z',
    is_read: false,
    action_link: '/returns'
  },
  {
    id: 'NOTIF-2',
    entity_id: 'E02',
    title: 'Unpaid VAT Liability Outstanding',
    message: 'Falcon Logistics FZ-LLC has filed return with payable balance of AED 164,000 awaiting payment transfer.',
    severity: 'medium',
    category: 'PAYMENT',
    timestamp: '2026-11-01T14:30:00Z',
    is_read: false,
    action_link: '/clients'
  },
  {
    id: 'NOTIF-3',
    entity_id: 'E01',
    title: 'Audit Exception: Blocked Entertainment VAT',
    message: 'Document EXP-904 flagged for 100% input VAT claim on entertainment. Review Article 53 compliance.',
    severity: 'medium',
    category: 'EXCEPTION',
    timestamp: '2026-10-30T10:15:00Z',
    is_read: true,
    action_link: '/vault'
  }
];

let rolePermissions = {
  admin: {
    can_manage_users: true,
    can_edit_tax_rules: true,
    can_approve_filing: true,
    can_delete_records: true,
    can_view_audit_logs: true,
    can_export_faf: true,
    can_upload_documents: true,
    can_override_categories: true,
  },
  preparer: {
    can_manage_users: false,
    can_edit_tax_rules: false,
    can_approve_filing: false,
    can_delete_records: false,
    can_view_audit_logs: true,
    can_export_faf: true,
    can_upload_documents: true,
    can_override_categories: true,
  },
  reviewer: {
    can_manage_users: false,
    can_edit_tax_rules: false,
    can_approve_filing: true,
    can_delete_records: false,
    can_view_audit_logs: true,
    can_export_faf: true,
    can_upload_documents: false,
    can_override_categories: true,
  },
  client: {
    can_manage_users: false,
    can_edit_tax_rules: false,
    can_approve_filing: false,
    can_delete_records: false,
    can_view_audit_logs: false,
    can_export_faf: false,
    can_upload_documents: true,
    can_override_categories: false,
  }
};

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// Health
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    version: '2.5.0-mobile-cloud',
    timestamp: new Date().toISOString(),
    pwa_enabled: true,
    encryption: 'AES-256-GCM',
    fta_compliance_spec: 'UAE Federal Decree-Law No. 8 of 2017 & Decision 129'
  });
});

// Entities
app.get('/api/entities', (req, res) => {
  res.json(entities);
});

app.post('/api/entities', (req, res) => {
  const newEntity: Entity = {
    ...req.body,
    id: req.body.id || `E${String(entities.length + 1).padStart(2, '0')}`,
  };
  const existingIdx = entities.findIndex(e => e.id === newEntity.id);
  if (existingIdx >= 0) {
    entities[existingIdx] = { ...entities[existingIdx], ...newEntity };
  } else {
    entities.push(newEntity);
  }

  // Record audit log
  auditLogs.unshift({
    id: `LOG-${Date.now()}`,
    timestamp: new Date().toISOString(),
    entity_id: newEntity.id,
    user_name: req.headers['x-user-name'] ? String(req.headers['x-user-name']) : 'Admin User',
    user_role: 'Admin',
    action: existingIdx >= 0 ? 'CLIENT_RECORD_UPDATED' : 'CLIENT_RECORD_CREATED',
    category: 'TRANSACTION',
    details: `Client entity ${newEntity.name} (TRN: ${newEntity.vat_trn}) ${existingIdx >= 0 ? 'updated' : 'registered'}.`,
    client_ip: req.ip || '127.0.0.1',
    device: req.headers['user-agent']?.includes('Mobile') ? 'Mobile App' : 'Desktop Browser',
    hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
  });

  res.json({ success: true, entity: newEntity });
});

// VAT Rows (Invoices & Expenses)
app.get('/api/vat-rows', (req, res) => {
  const { entity_id } = req.query;
  if (entity_id) {
    const filtered = vatRows.filter(r => r.entity_id === entity_id);
    return res.json(filtered);
  }
  res.json(vatRows);
});

app.post('/api/vat-rows', (req, res) => {
  const payload = req.body;
  const newRow: VatRow = {
    ...payload,
    id: payload.id || `VR-${Date.now().toString().slice(-4)}`,
  };
  vatRows.unshift(newRow);

  auditLogs.unshift({
    id: `LOG-${Date.now()}`,
    timestamp: new Date().toISOString(),
    entity_id: newRow.entity_id,
    user_name: req.headers['x-user-name'] ? String(req.headers['x-user-name']) : 'Mobile User',
    user_role: 'Preparer',
    action: 'TRANSACTION_RECORDED',
    category: 'TRANSACTION',
    details: `Added ${newRow.doc_type} Doc #${newRow.doc_no} (${newRow.party}) Net AED ${newRow.net.toLocaleString()}`,
    client_ip: req.ip || '127.0.0.1',
    device: req.headers['user-agent']?.includes('Mobile') ? 'Mobile App' : 'Desktop Browser',
    hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
  });

  res.json({ success: true, row: newRow });
});

app.put('/api/vat-rows/:id', (req, res) => {
  const { id } = req.params;
  const idx = vatRows.findIndex(r => r.id === id);
  if (idx === -1) return res.status(404).json({ error: 'Not found' });
  vatRows[idx] = { ...vatRows[idx], ...req.body };
  res.json({ success: true, row: vatRows[idx] });
});

app.delete('/api/vat-rows/:id', (req, res) => {
  const { id } = req.params;
  vatRows = vatRows.filter(r => r.id !== id);
  res.json({ success: true });
});

// Encrypted Cloud Document Vault
app.get('/api/documents', (req, res) => {
  const { entity_id } = req.query;
  if (entity_id) {
    return res.json(encryptedDocuments.filter(d => d.entity_id === entity_id));
  }
  res.json(encryptedDocuments);
});

app.post('/api/documents', (req, res) => {
  const doc = req.body;
  const newDoc: EncryptedDocument = {
    ...doc,
    id: doc.id || `DOC-${Date.now().toString().slice(-4)}`,
    uploaded_at: new Date().toISOString(),
    encryption_algorithm: 'AES-256-GCM',
    key_derivation: 'PBKDF2-SHA256 (100k rounds)',
    tamper_evident_status: 'VERIFIED_COMPLIANT'
  };
  encryptedDocuments.unshift(newDoc);

  auditLogs.unshift({
    id: `LOG-${Date.now()}`,
    timestamp: new Date().toISOString(),
    entity_id: newDoc.entity_id,
    user_name: req.headers['x-user-name'] ? String(req.headers['x-user-name']) : 'Mobile User',
    user_role: 'Preparer',
    action: 'ENCRYPTED_DOCUMENT_UPLOADED',
    category: 'VAULT_ENCRYPTION',
    details: `Encrypted receipt ${newDoc.file_name} sealed with AES-256-GCM. SHA-256: ${newDoc.sha256_checksum.slice(0, 16)}...`,
    client_ip: req.ip || '127.0.0.1',
    device: req.headers['user-agent']?.includes('Mobile') ? 'Mobile Camera Scan' : 'Desktop Upload',
    hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
  });

  res.json({ success: true, document: newDoc });
});

// Audit Logs
app.get('/api/audit-logs', (req, res) => {
  const { entity_id } = req.query;
  if (entity_id) {
    return res.json(auditLogs.filter(l => l.entity_id === entity_id));
  }
  res.json(auditLogs);
});

// Notifications
app.get('/api/notifications', (req, res) => {
  res.json(notifications);
});

app.post('/api/notifications/:id/read', (req, res) => {
  const { id } = req.params;
  const notif = notifications.find(n => n.id === id);
  if (notif) notif.is_read = true;
  res.json({ success: true });
});

// Permissions
app.get('/api/permissions', (req, res) => {
  res.json(rolePermissions);
});

app.put('/api/permissions', (req, res) => {
  rolePermissions = req.body;
  res.json({ success: true, permissions: rolePermissions });
});

// Automated Expense & Invoice AI Categorization
app.post('/api/ai/categorize', (req, res) => {
  const { party, description, amount, emirate } = req.body;
  const p = (party || '').toLowerCase();
  const d = (description || '').toLowerCase();
  
  let doc_type: VatRow['doc_type'] = 'Purchase - standard rated';
  let category = 'General Business Expense';
  let confidence = 0.92;
  let rationale = 'Standard taxable supply under Article 24 of Decree-Law No. 8.';
  let is_blocked = false;

  // Cloud & software overseas -> Article 48 Reverse Charge
  if (p.includes('aws') || p.includes('amazon web') || p.includes('google') || p.includes('microsoft') || p.includes('slack') || p.includes('github') || d.includes('cloud') || d.includes('saas') || d.includes('hosting')) {
    doc_type = 'Purchase - reverse charge';
    category = 'Cloud Services & SaaS (Reverse Charge)';
    confidence = 0.98;
    rationale = 'Import of cross-border electronic services subject to Reverse Charge Mechanism under Article 48.';
  }
  // Entertainment & fine dining -> Blocked under Article 53
  else if (d.includes('dinner') || d.includes('lunch') || d.includes('entertainment') || d.includes('restaurant') || d.includes('hospitality') || d.includes('catering')) {
    doc_type = 'Purchase - blocked input VAT';
    category = 'Client Entertainment (Blocked Input VAT)';
    confidence = 0.95;
    rationale = 'Entertainment services provided to non-employees are non-recoverable under Cabinet Decision No. 52.';
    is_blocked = true;
  }
  // Export of goods or services -> Zero rated
  else if (d.includes('export') || d.includes('overseas') || p.includes('ksa') || p.includes('saudi') || p.includes('london') || p.includes('usa')) {
    doc_type = 'Sale - zero rated';
    category = 'Direct / Indirect Export of Goods & Services';
    confidence = 0.96;
    rationale = 'Exported goods with official customs commercial exit documents qualify for 0% rating.';
  }
  // Designated zone supplies
  else if (d.includes('jafza') || d.includes('kizad') || d.includes('designated zone') || d.includes('freezone warehouse')) {
    doc_type = 'Sale - designated zone goods';
    category = 'Designated Zone Transfer';
    confidence = 0.94;
    rationale = 'Supplies of goods within Designated Zones are out of scope or treated as special zero-rated.';
  }
  // Capital Asset > AED 5,000 with long useful life
  else if ((amount > 30000 && (d.includes('machinery') || d.includes('vehicle') || d.includes('server rack') || d.includes('fitout'))) || d.includes('capital asset')) {
    doc_type = 'Purchase - capital asset';
    category = 'Capital Assets Scheme (Art 57)';
    confidence = 0.91;
    rationale = 'Capital asset subject to the Capital Assets Scheme monitoring for 5 or 10 years.';
  }
  // Credit Note
  else if (d.includes('refund') || d.includes('return') || d.includes('credit note') || d.includes('rebate')) {
    doc_type = 'Purchase - credit note';
    category = 'Credit Adjustments';
    confidence = 0.93;
    rationale = 'Adjustment of previous consideration under Article 61.';
  }

  const vat = is_blocked ? 0 : Math.round((Number(amount) || 0) * 0.05);

  res.json({
    doc_type,
    category,
    vat,
    confidence,
    rationale,
    is_blocked,
    suggested_emirate: emirate || 'Dubai'
  });
});

// Full Cross-Platform Two-Way Sync Endpoint
app.post('/api/sync', (req, res) => {
  const { last_synced_at, client_mutations } = req.body;

  // Process any mutations pushed from client
  if (Array.isArray(client_mutations) && client_mutations.length > 0) {
    for (const m of client_mutations) {
      if (m.type === 'INSERT_ROW') {
        const exists = vatRows.some(r => r.id === m.data.id);
        if (!exists) vatRows.unshift(m.data);
      } else if (m.type === 'UPDATE_ROW') {
        const idx = vatRows.findIndex(r => r.id === m.data.id);
        if (idx >= 0) vatRows[idx] = { ...vatRows[idx], ...m.data };
      } else if (m.type === 'INSERT_DOC') {
        const exists = encryptedDocuments.some(d => d.id === m.data.id);
        if (!exists) encryptedDocuments.unshift(m.data);
      }
    }
  }

  // Audit sync event
  auditLogs.unshift({
    id: `LOG-${Date.now()}`,
    timestamp: new Date().toISOString(),
    entity_id: 'ALL',
    user_name: req.headers['x-user-name'] ? String(req.headers['x-user-name']) : 'Mobile Sync Agent',
    user_role: 'Mobile Sync',
    action: 'CROSS_PLATFORM_SYNC_COMPLETED',
    category: 'SYNC',
    details: `Synchronized ${client_mutations?.length || 0} client changes with central cloud ledger. Delta hash verified.`,
    client_ip: req.ip || '127.0.0.1',
    device: req.headers['user-agent']?.includes('Mobile') ? 'Mobile Client (iOS/Android)' : 'Desktop Client',
    hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
  });

  res.json({
    success: true,
    server_time: new Date().toISOString(),
    entities,
    vat_rows: vatRows,
    documents: encryptedDocuments,
    audit_logs: auditLogs.slice(0, 50),
    notifications
  });
});

// Collaborative Export: FTA Audit File (FAF CSV)
app.get('/api/export/faf', (req, res) => {
  const { entity_id } = req.query;
  const entity = entities.find(e => e.id === entity_id) || entities[0];
  const rows = vatRows.filter(r => r.entity_id === entity.id);

  // Official UAE FTA FAF CSV Header spec
  const lines: string[] = [
    `"FAF Version","1.0.0"`,
    `"Company Name","${entity.name}"`,
    `"Tax Registration Number (TRN)","${entity.vat_trn}"`,
    `"Period End Date","${entity.vat_period_end}"`,
    `"Generation Date","${new Date().toISOString()}"`,
    ``,
    `"Transaction ID","Document Date","Document Number","Customer/Supplier Name","Customer/Supplier TRN","Emirate","Line Description","Supply/Purchase Type","Net Amount (AED)","VAT Amount (AED)","Total Amount (AED)","Receipt ID"`
  ];

  for (const r of rows) {
    lines.push(
      `"${r.id}","${r.doc_date}","${r.doc_no}","${r.party}","${r.party_trn || ''}","${r.emirate || 'Dubai'}","${r.description.replace(/"/g, '""')}","${r.doc_type}",${r.net.toFixed(2)},${r.vat.toFixed(2)},${(r.net + r.vat).toFixed(2)},"${r.receipt_id || ''}"`
    );
  }

  const csvContent = lines.join('\n');
  res.setHeader('Content-Type', 'text/csv');
  res.setHeader('Content-Disposition', `attachment; filename="FAF_${entity.vat_trn}_${entity.vat_period_end}.csv"`);
  res.send(csvContent);
});

// Collaborative Export: Share Link Generation
app.post('/api/export/share-link', (req, res) => {
  const { entity_id, expires_in_days, access_role, password } = req.body;
  const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  const expiryDate = new Date();
  expiryDate.setDate(expiryDate.getDate() + (Number(expires_in_days) || 7));

  auditLogs.unshift({
    id: `LOG-${Date.now()}`,
    timestamp: new Date().toISOString(),
    entity_id: entity_id || 'E01',
    user_name: 'Lead Auditor',
    user_role: 'Reviewer',
    action: 'AUDITOR_PORTAL_LINK_GENERATED',
    category: 'EXPORT',
    details: `Generated time-limited external auditor access link with role [${access_role || 'Auditor Read-Only'}]. Expires: ${expiryDate.toLocaleDateString()}. Password protected: ${password ? 'Yes' : 'No'}.`,
    client_ip: req.ip || '127.0.0.1',
    device: 'Desktop Chrome',
    hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
  });

  res.json({
    success: true,
    share_url: `${req.protocol}://${req.get('host')}/auditor-review?token=${token}`,
    token,
    expires_at: expiryDate.toISOString(),
    role: access_role || 'Auditor Read-Only'
  });
});

// -------------------------------------------------------------
// Vite Middlewares in Dev / Static Serving in Prod
// -------------------------------------------------------------
async function setupServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VAT-DESK Full-Stack Mobile & Cloud Server running on http://0.0.0.0:${PORT}`);
  });
}

setupServer();
