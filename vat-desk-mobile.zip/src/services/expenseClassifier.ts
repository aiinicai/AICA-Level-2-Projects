import { VatRow } from '../types';

export interface CategorizationResult {
  doc_type: VatRow['doc_type'];
  category: string;
  vat: number;
  confidence: number;
  rationale: string;
  is_blocked: boolean;
  suggested_emirate: string;
  exceptions: string[];
}

export interface OCRScanResult {
  vendor: string;
  trn: string;
  invoice_number: string;
  date: string;
  net_amount: number;
  vat_amount: number;
  total_amount: number;
  emirate: string;
  description: string;
  suggested_category: CategorizationResult;
}

export function classifyExpense(party: string, description: string, amount: number, emirate: string = 'Dubai'): CategorizationResult {
  const p = (party || '').toLowerCase();
  const d = (description || '').toLowerCase();
  const net = Number(amount) || 0;

  let doc_type: VatRow['doc_type'] = 'Purchase - standard rated';
  let category = 'Standard Operating Expense';
  let confidence = 0.92;
  let rationale = 'Standard taxable purchase under UAE VAT (Federal Decree-Law No. 8). Deductible at 5%.';
  let is_blocked = false;
  const exceptions: string[] = [];

  // Rule 1: Overseas Cloud / SaaS / Electronic Services -> Reverse Charge Art. 48
  if (
    p.includes('aws') || p.includes('amazon web') || p.includes('google') || 
    p.includes('microsoft') || p.includes('slack') || p.includes('zoom') || 
    p.includes('atlassian') || p.includes('github') || p.includes('adobe') ||
    d.includes('software') || d.includes('cloud') || d.includes('saas') || d.includes('hosting') || d.includes('license')
  ) {
    doc_type = 'Purchase - reverse charge';
    category = 'Cloud Software & SaaS (Reverse Charge Art. 48)';
    confidence = 0.98;
    rationale = 'Import of cross-border electronic services subject to Reverse Charge Mechanism under Article 48.';
  }
  // Rule 2: Entertainment / Dining / Luxury -> Blocked Input VAT Art. 53
  else if (
    d.includes('dinner') || d.includes('lunch') || d.includes('meal') || 
    d.includes('entertainment') || d.includes('restaurant') || d.includes('cafe') || 
    d.includes('catering') || d.includes('party') || d.includes('hospitality') ||
    p.includes('restaurant') || p.includes('hotel') || p.includes('lounge') || p.includes('cafe')
  ) {
    doc_type = 'Purchase - blocked input VAT';
    category = 'Client Hospitality & Entertainment (Blocked VAT)';
    confidence = 0.96;
    rationale = 'Under Article 53 of Cabinet Decision No. 52, entertainment services provided to non-employees are non-recoverable.';
    is_blocked = true;
    exceptions.push('Input VAT non-deductible under Article 53 (Entertainment). VAT set to AED 0 recoverable.');
  }
  // Rule 3: Capital Asset (> AED 30,000 or machinery / vehicle / hardware)
  else if (
    (net >= 30000 && (d.includes('machine') || d.includes('equipment') || d.includes('vehicle') || d.includes('server') || d.includes('fitout') || d.includes('furniture'))) ||
    d.includes('capital asset')
  ) {
    doc_type = 'Purchase - capital asset';
    category = 'Capital Assets Scheme (Art. 57)';
    confidence = 0.94;
    rationale = 'Purchases of single capital assets qualifying for monitoring under the 5/10 year Capital Assets Scheme.';
  }
  // Rule 4: International Freight & Exports -> Zero Rated
  else if (
    d.includes('export') || d.includes('freight') || d.includes('air cargo') || 
    d.includes('shipping') || p.includes('logistics') || p.includes('cargo')
  ) {
    if (d.includes('export')) {
      doc_type = 'Sale - zero rated';
      category = 'Direct Export of Goods (0% Tax)';
      confidence = 0.95;
      rationale = 'Exported goods backed by official customs clearance documents are zero-rated under Article 45.';
    } else {
      doc_type = 'Purchase - standard rated';
      category = 'Freight & Domestic Transportation';
      confidence = 0.90;
      rationale = 'Domestic transport & logistics services subject to standard 5% VAT.';
    }
  }
  // Rule 5: Credit Notes & Adjustments
  else if (d.includes('credit note') || d.includes('refund') || d.includes('return') || d.includes('discount')) {
    doc_type = 'Purchase - credit note';
    category = 'Supplier Credit Note (Adjustment)';
    confidence = 0.93;
    rationale = 'Adjustment of previous supply value under Article 61 of the VAT Law.';
  }
  // Rule 6: Government Fees & Fines -> Out of Scope / Exempt
  else if (
    p.includes('ministry') || p.includes('ded') || p.includes('municipality') || 
    p.includes('court') || d.includes('license renewal') || d.includes('visa fee')
  ) {
    doc_type = 'Purchase - standard rated'; // Standard or out of scope
    category = 'Statutory Fees / Government Fees';
    confidence = 0.95;
    rationale = 'Sovereign governmental charges without commercial consideration are typically exempt or outside scope.';
    is_blocked = true;
  }

  // Large transaction threshold check
  if (net > 10000 && doc_type === 'Purchase - standard rated') {
    exceptions.push('Full Tax Invoice with buyer and seller TRN required (amount exceeds simplified limit AED 10,000).');
  }

  const vat = is_blocked ? 0 : Math.round(net * 0.05);

  return {
    doc_type,
    category,
    vat,
    confidence,
    rationale,
    is_blocked,
    suggested_emirate: emirate || 'Dubai',
    exceptions
  };
}

// Simulates smart mobile camera receipt scan
export function simulateReceiptScan(fileName: string): OCRScanResult {
  const name = fileName.toLowerCase();

  if (name.includes('aws') || name.includes('cloud')) {
    const net = 14500;
    return {
      vendor: 'Amazon Web Services EMEA SARL',
      trn: '998822001100003',
      invoice_number: `INV-AWS-${Math.floor(10000 + Math.random() * 90000)}`,
      date: new Date().toISOString().split('T')[0],
      net_amount: net,
      vat_amount: Math.round(net * 0.05),
      total_amount: Math.round(net * 1.05),
      emirate: 'Dubai',
      description: 'Monthly cloud computation instances & container cluster',
      suggested_category: classifyExpense('AWS', 'cloud compute server', net)
    };
  }

  if (name.includes('dinner') || name.includes('restaurant') || name.includes('meal')) {
    const net = 2850;
    return {
      vendor: 'Zuma Dubai DIFC',
      trn: '100349827100003',
      invoice_number: `REC-ZM-${Math.floor(1000 + Math.random() * 9000)}`,
      date: new Date().toISOString().split('T')[0],
      net_amount: net,
      vat_amount: Math.round(net * 0.05),
      total_amount: Math.round(net * 1.05),
      emirate: 'Dubai',
      description: 'Corporate client dinner meeting at Gate Village DIFC',
      suggested_category: classifyExpense('Zuma Dubai', 'client dinner entertainment', net)
    };
  }

  if (name.includes('hardware') || name.includes('canon') || name.includes('tech')) {
    const net = 48500;
    return {
      vendor: 'Sharaf DG Commercial Supplies LLC',
      trn: '100492837400003',
      invoice_number: `TAX-INV-${Math.floor(100000 + Math.random() * 900000)}`,
      date: new Date().toISOString().split('T')[0],
      net_amount: net,
      vat_amount: Math.round(net * 0.05),
      total_amount: Math.round(net * 1.05),
      emirate: 'Dubai',
      description: 'Enterprise server hardware, router rack & network switch',
      suggested_category: classifyExpense('Sharaf DG', 'server equipment capital asset', net)
    };
  }

  // Generic UAE Tax Invoice default
  const net = 5200;
  return {
    vendor: 'Al Futtaim Engineering & Technologies',
    trn: '100228391000003',
    invoice_number: `AF-INV-${Math.floor(10000 + Math.random() * 90000)}`,
    date: new Date().toISOString().split('T')[0],
    net_amount: net,
    vat_amount: Math.round(net * 0.05),
    total_amount: Math.round(net * 1.05),
    emirate: 'Dubai',
    description: 'Quarterly office maintenance, AC filters & facilities service',
    suggested_category: classifyExpense('Al Futtaim', 'office maintenance facilities', net)
  };
}
