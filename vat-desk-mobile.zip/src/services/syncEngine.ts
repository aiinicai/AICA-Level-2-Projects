import { Entity, VatRow, EncryptedDocument, AuditLog, NotificationItem } from '../types';

export interface SyncMutation {
  id: string;
  type: 'INSERT_ROW' | 'UPDATE_ROW' | 'DELETE_ROW' | 'INSERT_DOC' | 'UPDATE_ENTITY';
  timestamp: string;
  data: any;
}

export interface PairedDevice {
  id: string;
  name: string;
  platform: 'iOS' | 'Android' | 'Desktop Windows' | 'macOS Web';
  last_active: string;
  ip_address: string;
  is_current: boolean;
}

const STORAGE_KEY_ENTITIES = 'vatdesk_entities';
const STORAGE_KEY_ROWS = 'vatdesk_vat_rows';
const STORAGE_KEY_DOCS = 'vatdesk_documents';
const STORAGE_KEY_AUDIT = 'vatdesk_audit_logs';
const STORAGE_KEY_NOTIFS = 'vatdesk_notifications';
const STORAGE_KEY_QUEUE = 'vatdesk_offline_queue';
const STORAGE_KEY_LAST_SYNC = 'vatdesk_last_sync_time';

export class SyncEngine {
  private static instance: SyncEngine;
  private offlineQueue: SyncMutation[] = [];
  private syncListeners: ((status: 'synced' | 'syncing' | 'offline' | 'error', queueCount: number) => void)[] = [];
  private status: 'synced' | 'syncing' | 'offline' | 'error' = 'synced';

  private constructor() {
    this.loadQueue();
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange(true));
      window.addEventListener('offline', () => this.handleNetworkChange(false));
      this.status = navigator.onLine ? 'synced' : 'offline';
    }
  }

  public static getInstance(): SyncEngine {
    if (!SyncEngine.instance) {
      SyncEngine.instance = new SyncEngine();
    }
    return SyncEngine.instance;
  }

  public subscribe(listener: (status: 'synced' | 'syncing' | 'offline' | 'error', queueCount: number) => void) {
    this.syncListeners.push(listener);
    listener(this.status, this.offlineQueue.length);
    return () => {
      this.syncListeners = this.syncListeners.filter(l => l !== listener);
    };
  }

  private notify() {
    this.syncListeners.forEach(listener => listener(this.status, this.offlineQueue.length));
  }

  private loadQueue() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_QUEUE);
      if (saved) {
        this.offlineQueue = JSON.parse(saved);
      }
    } catch {
      this.offlineQueue = [];
    }
  }

  private saveQueue() {
    try {
      localStorage.setItem(STORAGE_KEY_QUEUE, JSON.stringify(this.offlineQueue));
    } catch (e) {
      console.error('Failed to save offline queue', e);
    }
  }

  public queueMutation(type: SyncMutation['type'], data: any) {
    const mutation: SyncMutation = {
      id: `MUT-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      type,
      timestamp: new Date().toISOString(),
      data
    };
    this.offlineQueue.push(mutation);
    this.saveQueue();

    // If online, try to push immediately; if offline, remain queued
    if (typeof navigator !== 'undefined' && navigator.onLine) {
      this.sync();
    } else {
      this.status = 'offline';
      this.notify();
    }
  }

  public async sync(): Promise<boolean> {
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      this.status = 'offline';
      this.notify();
      return false;
    }

    this.status = 'syncing';
    this.notify();

    try {
      const lastSync = localStorage.getItem(STORAGE_KEY_LAST_SYNC) || '';
      const response = await fetch('/api/sync', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          last_synced_at: lastSync,
          client_mutations: this.offlineQueue
        })
      });

      if (!response.ok) throw new Error('Sync server response error');

      const data = await response.json();

      // Clear processed mutations
      this.offlineQueue = [];
      this.saveQueue();

      // Save latest server state locally for offline resilience
      if (data.entities) localStorage.setItem(STORAGE_KEY_ENTITIES, JSON.stringify(data.entities));
      if (data.vat_rows) localStorage.setItem(STORAGE_KEY_ROWS, JSON.stringify(data.vat_rows));
      if (data.documents) localStorage.setItem(STORAGE_KEY_DOCS, JSON.stringify(data.documents));
      if (data.audit_logs) localStorage.setItem(STORAGE_KEY_AUDIT, JSON.stringify(data.audit_logs));
      if (data.notifications) localStorage.setItem(STORAGE_KEY_NOTIFS, JSON.stringify(data.notifications));

      localStorage.setItem(STORAGE_KEY_LAST_SYNC, data.server_time || new Date().toISOString());

      this.status = 'synced';
      this.notify();
      return true;
    } catch (err) {
      console.warn('Sync failed, running in cached offline mode:', err);
      this.status = typeof navigator !== 'undefined' && navigator.onLine ? 'error' : 'offline';
      this.notify();
      return false;
    }
  }

  private handleNetworkChange(isOnline: boolean) {
    if (isOnline) {
      this.sync();
    } else {
      this.status = 'offline';
      this.notify();
    }
  }

  public getCachedData<T>(key: 'entities' | 'vat_rows' | 'documents' | 'audit_logs' | 'notifications'): T[] | null {
    try {
      const map = {
        entities: STORAGE_KEY_ENTITIES,
        vat_rows: STORAGE_KEY_ROWS,
        documents: STORAGE_KEY_DOCS,
        audit_logs: STORAGE_KEY_AUDIT,
        notifications: STORAGE_KEY_NOTIFS,
      };
      const raw = localStorage.getItem(map[key]);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }

  public getPairedDevices(): PairedDevice[] {
    return [
      {
        id: 'DEV-1',
        name: 'iPhone 15 Pro (Mobile PWA)',
        platform: 'iOS',
        last_active: 'Active now',
        ip_address: '194.170.24.12 (Dubai Du)',
        is_current: true
      },
      {
        id: 'DEV-2',
        name: 'MacBook Pro 16" (Finance Desk)',
        platform: 'macOS Web',
        last_active: '24 mins ago',
        ip_address: '94.200.12.88 (Abu Dhabi Etisalat)',
        is_current: false
      },
      {
        id: 'DEV-3',
        name: 'Samsung Galaxy Tab S9 (Warehouse)',
        platform: 'Android',
        last_active: 'Yesterday, 16:40',
        ip_address: '194.170.24.12 (Dubai Du)',
        is_current: false
      }
    ];
  }
}

export const syncEngine = SyncEngine.getInstance();
