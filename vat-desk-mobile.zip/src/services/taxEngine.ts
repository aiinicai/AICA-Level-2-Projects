import { Entity, VatRow, VatCalculationResult, Vat201BoxLine } from '../types';

export const VAT_RATE = 0.05;
export const MANDATORY_REG_THRESHOLD = 375000;
export const VOLUNTARY_REG_THRESHOLD = 187500;
export const VAT_DUE_DAYS = 28;
export const VAT_DUE_SOON_DAYS = 14;
export const LATE_FILING_PENALTY = 1000;
export const LATE_PAYMENT_ANNUAL_RATE = 0.48; // 4% per month

// Helpers
function n(val: any): number {
  if (val === null || val === undefined || typeof val === 'boolean') return 0;
  const parsed = Number(val);
  return isFinite(parsed) ? parsed : 0;
}

function jr(x: number): number {
  return Math.round(x);
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().split('T')[0];
}

function diffDays(a: string, b: string): number {
  const da = new Date(a);
  const db = new Date(b);
  return Math.round((db.getTime() - da.getTime()) / (1000 * 60 * 60 * 24));
}

export function calculateEntityTax(entity: Entity, rows: VatRow[] = [], asOfDate: string = new Date().toISOString().split('T')[0]): VatCalculationResult {
  const entityRows = rows.filter(r => r.entity_id === entity.id);
  
  // If transaction rows exist, calculate aggregate figures dynamically; otherwise use master record
  let std = entity.std_supplies;
  let zero = entity.zero_supplies;
  let exempt = entity.exempt_supplies;
  let dz = entity.dz_goods_supplies;
  let inputVat = entity.input_vat;
  let blockedInput = entity.blocked_input_vat;
  let reverseCharge = entity.reverse_charge_vat;
  let salesCnNet = entity.sales_cn_net;
  let salesCnVat = entity.sales_cn_vat;
  let purchaseCnVat = entity.purchase_cn_vat;
  let importVat = entity.import_vat;
  let importAdjustVat = entity.import_adjust_vat;
  let touristRefund = entity.tourist_refund_vat;
  let deemedSupplies = entity.deemed_supplies_vat;
  let badDebt = entity.bad_debt_vat;
  let changeInUse = entity.change_in_use_vat;

  if (entityRows.length > 0) {
    std = entityRows.filter(r => r.doc_type === 'Sale - standard rated').reduce((acc, r) => acc + n(r.net), 0);
    zero = entityRows.filter(r => r.doc_type === 'Sale - zero rated').reduce((acc, r) => acc + n(r.net), 0);
    exempt = entityRows.filter(r => r.doc_type === 'Sale - exempt').reduce((acc, r) => acc + n(r.net), 0);
    dz = entityRows.filter(r => r.doc_type === 'Sale - designated zone goods').reduce((acc, r) => acc + n(r.net), 0);
    salesCnNet = entityRows.filter(r => r.doc_type === 'Sale - credit note').reduce((acc, r) => acc + n(r.net), 0);
    salesCnVat = entityRows.filter(r => r.doc_type === 'Sale - credit note').reduce((acc, r) => acc + n(r.vat), 0);
    
    inputVat = entityRows.filter(r => r.doc_type === 'Purchase - standard rated' || r.doc_type === 'Purchase - capital asset').reduce((acc, r) => acc + n(r.vat), 0);
    blockedInput = entityRows.filter(r => r.doc_type === 'Purchase - blocked input VAT').reduce((acc, r) => acc + n(r.vat), 0);
    reverseCharge = entityRows.filter(r => r.doc_type === 'Purchase - reverse charge').reduce((acc, r) => acc + n(r.vat), 0);
    purchaseCnVat = entityRows.filter(r => r.doc_type === 'Purchase - credit note').reduce((acc, r) => acc + n(r.vat), 0);
    importVat = entityRows.filter(r => r.doc_type === 'Import of goods').reduce((acc, r) => acc + n(r.vat), 0);
  }

  const isReg = entity.vat_registered === 'Yes';
  const isFiled = entity.vat_filed === 'Yes';
  const isPaid = entity.vat_paid === 'Yes';

  const taxable = std + zero;
  const ratio = (exempt > 0 && taxable + exempt > 0) ? taxable / (taxable + exempt) : 1;

  const rc = isReg ? reverseCharge : 0;
  const outVat = isReg ? std * VAT_RATE : 0;
  const imp = isReg ? importVat + importAdjustVat : 0;
  const adjOut = isReg ? (-salesCnVat - badDebt + deemedSupplies - touristRefund) : 0;
  const dueTotal = outVat + rc + imp + adjOut;

  const grossIn = Math.max(0, inputVat - purchaseCnVat + changeInUse + imp) + rc;
  const recoverable = isReg ? (Math.max(0, inputVat - blockedInput - purchaseCnVat + changeInUse + imp) + rc) * ratio : 0;
  const netVat = dueTotal - recoverable;

  // General Ledger Reconciliations
  const dSales = entity.gl_sales_revenue ? jr(entity.gl_sales_revenue - (std + zero + exempt + dz - salesCnNet)) : null;
  const dOut = entity.gl_output_vat ? jr(entity.gl_output_vat - dueTotal) : null;
  const dIn = entity.gl_input_vat ? jr(entity.gl_input_vat - grossIn) : null;

  const diffs = [dSales, dOut, dIn].filter(v => v !== null) as number[];
  let reconStatus: VatCalculationResult['recon_status'] = 'Not provided';
  if (!isReg) {
    reconStatus = 'Not registered';
  } else if (diffs.length > 0) {
    reconStatus = Math.max(...diffs.map(Math.abs)) <= 2 ? 'Reconciled' : 'Difference';
  }

  // Deadlines & Penalties
  const periodEnd = entity.vat_period_end;
  const dueDate = addDays(periodEnd, VAT_DUE_DAYS);
  const daysToDue = diffDays(asOfDate, dueDate);
  const isLate = isReg && !isFiled && daysToDue < 0;
  const lateDays = isLate ? Math.abs(daysToDue) : 0;

  // Status & Flags
  let status: VatCalculationResult['vat_status'] = 'On track';
  let flag: VatCalculationResult['vat_flag'] = 'green';

  if (!isReg) {
    if (entity.taxable_supplies_12m >= MANDATORY_REG_THRESHOLD) {
      status = 'Registration required';
      flag = 'red';
    } else if (entity.taxable_supplies_12m >= VOLUNTARY_REG_THRESHOLD) {
      status = 'Voluntary eligible';
      flag = 'grey';
    } else {
      status = 'Not registered';
      flag = 'grey';
    }
  } else if (isFiled) {
    if (netVat > 0 && !isPaid) {
      if (daysToDue < 0) {
        status = 'Overdue (unpaid)';
        flag = 'red';
      } else {
        status = 'Filed, payment due';
        flag = 'amber';
      }
    } else {
      status = 'Filed';
      flag = 'green';
    }
  } else if (daysToDue < 0) {
    status = 'Overdue';
    flag = 'red';
  } else if (daysToDue <= VAT_DUE_SOON_DAYS) {
    status = 'Due soon';
    flag = 'amber';
  } else {
    status = 'On track';
    flag = 'green';
  }

  // Penalty Calculation (Cabinet Decision 40 / 129)
  let penalty = 0;
  const unpaid = isReg && netVat > 0 && !isPaid;
  const baseOverdueTax = (unpaid && daysToDue < 0) ? netVat : 0;
  if (isLate) {
    penalty += LATE_FILING_PENALTY;
  }
  if (baseOverdueTax > 0) {
    const overdueMonths = Math.ceil(lateDays / 30);
    const latePayInterest = baseOverdueTax * (LATE_PAYMENT_ANNUAL_RATE / 12) * Math.max(1, overdueMonths);
    penalty += latePayInterest;
  }

  // Risk Score (0 - 100)
  let riskScore = 0;
  if (flag === 'red') riskScore += status === 'Registration required' ? 35 : 45;
  if (flag === 'amber') riskScore += 18;
  riskScore += Math.min(20, (entity.vat_open_exceptions || 0) * 5);
  if (reconStatus === 'Difference') riskScore += 20;
  riskScore = Math.min(100, riskScore);

  const rag: VatCalculationResult['rag'] = riskScore >= 40 ? 'Red' : riskScore >= 15 ? 'Amber' : 'Green';

  // 30 Schedules Count
  let schedulesCount = 8;
  if (std > 0) schedulesCount += 2;
  if (salesCnNet > 0 || salesCnVat > 0) schedulesCount += 1;
  if (rc > 0) schedulesCount += 2;
  if (zero > 0) schedulesCount += 1;
  if (exempt > 0) schedulesCount += 2;
  if (blockedInput > 0) schedulesCount += 1;
  if (importVat > 0) schedulesCount += 1;
  if (touristRefund > 0) schedulesCount += 1;

  return {
    id: entity.id,
    name: entity.name,
    location: entity.location,
    vat_status: status,
    vat_flag: flag,
    registered: entity.vat_registered,
    taxable_supplies: jr(taxable),
    dz_goods: jr(dz),
    output_vat: jr(outVat),
    total_due: jr(dueTotal),
    recoverable_vat: jr(recoverable),
    recovery_pct: ratio,
    net_vat: jr(netVat),
    period_end: periodEnd,
    due: dueDate,
    days_to_due: daysToDue,
    late_days: lateDays,
    vat_penalty: jr(penalty),
    vat_overdue_tax: jr(baseOverdueTax),
    open_exceptions: entity.vat_open_exceptions || 0,
    recon_status: reconStatus,
    recon_sales_diff: dSales,
    recon_output_diff: dOut,
    recon_input_diff: dIn,
    vat_schedules_required: schedulesCount,
    risk_score: riskScore,
    rag
  };
}

export function generateVat201Breakdown(entity: Entity, rows: VatRow[] = []): Vat201BoxLine[] {
  const entityRows = rows.filter(r => r.entity_id === entity.id);
  const std = entity.std_supplies;
  const zero = entity.zero_supplies;
  const exempt = entity.exempt_supplies;
  const rc = entity.reverse_charge_vat;
  const imp = entity.import_vat + entity.import_adjust_vat;
  const tourist = entity.tourist_refund_vat;
  const salesCnVat = entity.sales_cn_vat;
  const inputVat = entity.input_vat;
  const blocked = entity.blocked_input_vat;

  // Distribute standard supplies across Emirates based on rows or default weighting
  const defaultEmirates = [
    { code: '1a', emirate: 'Abu Dhabi', pct: 0.25 },
    { code: '1b', emirate: 'Dubai', pct: 0.55 },
    { code: '1c', emirate: 'Sharjah', pct: 0.12 },
    { code: '1d', emirate: 'Ajman', pct: 0.04 },
    { code: '1e', emirate: 'Umm Al Quwain', pct: 0.01 },
    { code: '1f', emirate: 'Ras Al Khaimah', pct: 0.02 },
    { code: '1g', emirate: 'Fujairah', pct: 0.01 },
  ];

  const lines: Vat201BoxLine[] = [];

  // Box 1a - 1g: Standard Rated Supplies per Emirate
  for (const item of defaultEmirates) {
    let amt = Math.round(std * item.pct);
    let vat = Math.round(amt * VAT_RATE);
    
    // If we have actual rows for this emirate:
    const emRows = entityRows.filter(r => r.emirate === item.emirate && r.doc_type === 'Sale - standard rated');
    if (emRows.length > 0) {
      amt = emRows.reduce((sum, r) => sum + n(r.net), 0);
      vat = emRows.reduce((sum, r) => sum + n(r.vat), 0);
    }

    lines.push({
      box: item.code,
      title: `Standard rated supplies in ${item.emirate}`,
      description: `Taxable supplies of goods and services delivered in ${item.emirate}`,
      amount: amt,
      vat: vat,
      adjustment: 0
    });
  }

  // Box 2: Tourist refunds
  lines.push({
    box: '2',
    title: 'Tax Refunds provided to Tourists under Scheme',
    description: 'Approved tourist tax refunds processed through Planet payment system',
    amount: tourist > 0 ? tourist * 20 : 0,
    vat: -tourist,
  });

  // Box 3: Supplies subject to Reverse Charge (Output)
  lines.push({
    box: '3',
    title: 'Supplies subject to the Reverse Charge',
    description: 'Services & goods acquired from abroad with output tax accounted for by recipient (Art. 48)',
    amount: rc > 0 ? rc * 20 : 0,
    vat: rc,
  });

  // Box 4: Zero rated supplies
  lines.push({
    box: '4',
    title: 'Zero rated supplies',
    description: 'Direct/indirect exports, international transport, qualifying education/health',
    amount: zero,
    vat: 0,
  });

  // Box 5: Exempt supplies
  lines.push({
    box: '5',
    title: 'Exempt supplies',
    description: 'Financial services, residential leases, bare land without output VAT credit',
    amount: exempt,
    vat: 0,
  });

  // Box 6: Goods imported into the UAE
  lines.push({
    box: '6',
    title: 'Goods imported into the UAE',
    description: 'Imports cleared through customs under TRN with customs declaration value',
    amount: entity.import_goods_value || (imp > 0 ? imp * 20 : 0),
    vat: imp,
  });

  // Box 7: Adjustments to goods imported
  lines.push({
    box: '7',
    title: 'Adjustments to goods imported into the UAE',
    description: 'Errors, exchange rate adjustments or freight differences on import declarations',
    amount: 0,
    vat: entity.import_adjust_vat,
  });

  // Box 8: Total due tax (Output Tax Total)
  const totalDue = (std * VAT_RATE) + rc + imp - tourist - salesCnVat;
  lines.push({
    box: '8',
    title: 'Total Value of due tax for the period',
    description: 'Total output tax liability accrued from Box 1 through Box 7',
    amount: std + zero + exempt + (rc * 20),
    vat: Math.round(totalDue),
    is_total: true
  });

  // Box 9: Standard rated expenses & Recoverable Input Tax
  const netInput = Math.max(0, inputVat - blocked);
  lines.push({
    box: '9',
    title: 'Standard rated expenses',
    description: 'Business purchases incurred with standard 5% tax invoice from registered suppliers',
    amount: inputVat * 20,
    vat: inputVat,
    recoverable: Math.round(netInput)
  });

  // Box 10: Supplies subject to reverse charge provisions (Input)
  lines.push({
    box: '10',
    title: 'Supplies subject to reverse charge provisions (Expenses)',
    description: 'Recoverable input tax portion on reverse charge acquisitions',
    amount: rc * 20,
    vat: rc,
    recoverable: rc
  });

  // Box 11: Adjustments to recoverable tax
  lines.push({
    box: '11',
    title: 'Adjustments to recoverable tax',
    description: 'Annual input tax apportionment, bad debt recovery, or capital asset adjustment',
    amount: 0,
    vat: 0,
    recoverable: entity.change_in_use_vat || 0
  });

  // Box 12: Total value of due tax
  lines.push({
    box: '12',
    title: 'Total Value of Due Tax for the Period',
    description: 'Net Output tax liability payable to the Federal Tax Authority',
    amount: Math.round(totalDue),
    is_total: true
  });

  // Box 13: Total value of recoverable tax
  const totalRecoverable = netInput + rc + (entity.change_in_use_vat || 0);
  lines.push({
    box: '13',
    title: 'Total Value of Recoverable Tax for the Period',
    description: 'Total legitimate input tax deductible for this tax period',
    amount: Math.round(totalRecoverable),
    is_total: true
  });

  // Box 14: Payable tax / (Net Refundable)
  const payable = Math.round(totalDue - totalRecoverable);
  lines.push({
    box: '14',
    title: payable >= 0 ? 'Payable Tax for the Period' : 'Net Refundable Tax for the Period',
    description: payable >= 0 
      ? 'Amount to be paid to the FTA via e-Dirham / GIBAN before the deadline'
      : 'Net refund balance eligible for carry forward or FTA bank refund application',
    amount: payable,
    is_total: true
  });

  return lines;
}
