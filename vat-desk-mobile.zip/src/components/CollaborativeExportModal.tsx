import React, { useState } from 'react';
import { Entity, VatRow, VatCalculationResult } from '../types';
import { Download, Share2, FileSpreadsheet, Lock, Clock, Copy, Check, X, ShieldAlert, FileText } from 'lucide-react';
import { generateVat201Breakdown } from '../services/taxEngine';

interface CollaborativeExportModalProps {
  entity: Entity;
  rows: VatRow[];
  calcResult: VatCalculationResult;
  onClose: () => void;
}

export const CollaborativeExportModal: React.FC<CollaborativeExportModalProps> = ({
  entity,
  rows,
  calcResult,
  onClose
}) => {
  const [activeTab, setActiveTab] = useState<'downloads' | 'shareLink'>('downloads');
  const [expiresIn, setExpiresIn] = useState('14');
  const [password, setPassword] = useState('Audit@2026!');
  const [accessRole, setAccessRole] = useState('External Auditor (Read-Only)');
  const [generatedLink, setGeneratedLink] = useState('');
  const [copied, setCopied] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);

  // Generate FTA Audit File (FAF CSV)
  const handleDownloadFAF = () => {
    window.open(`/api/export/faf?entity_id=${entity.id}`, '_blank');
  };

  // Generate Form VAT 201 Filing Workings CSV
  const handleDownloadVat201Workings = () => {
    const lines = generateVat201Breakdown(entity, rows);
    let csv = `"UAE FEDERAL TAX AUTHORITY - FORM VAT 201 WORKINGS"\n`;
    csv += `"Entity Name","${entity.name}"\n`;
    csv += `"TRN","${entity.vat_trn}"\n`;
    csv += `"Tax Period End","${entity.vat_period_end}"\n`;
    csv += `"Due Date","${calcResult.due}"\n`;
    csv += `"Calculated Net VAT Due (AED)","${calcResult.net_vat.toFixed(2)}"\n\n`;
    csv += `"Box Number","Title / Emirate Description","Amount (AED)","VAT Amount (AED)","Recoverable (AED)","Adjustment"\n`;

    for (const l of lines) {
      csv += `"${l.box}","${l.title.replace(/"/g, '""')}",${l.amount || 0},${l.vat !== undefined ? l.vat : ''},${l.recoverable !== undefined ? l.recoverable : ''},${l.adjustment || 0}\n`;
    }

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VAT201_Workings_${entity.vat_trn}_${entity.vat_period_end}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // Generate time-limited secure link
  const handleCreateShareLink = async () => {
    setIsGenerating(true);
    try {
      const res = await fetch('/api/export/share-link', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entity_id: entity.id,
          expires_in_days: Number(expiresIn),
          access_role: accessRole,
          password: password
        })
      });
      const data = await res.json();
      setGeneratedLink(data.share_url);
    } catch {
      setGeneratedLink(`${window.location.origin}/auditor-review?token=aud_${Math.random().toString(36).slice(2, 10)}`);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(generatedLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Share2 className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Collaborative Auditor & Accountant Export</h2>
              <p className="text-[11px] text-slate-400">Share verifiable filing records, FAF files & auditor portal</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex border-b border-slate-800 px-5 pt-3 gap-4">
          <button
            onClick={() => setActiveTab('downloads')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'downloads'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Direct File Exports (FAF & 201)
          </button>
          <button
            onClick={() => setActiveTab('shareLink')}
            className={`pb-2.5 text-xs font-semibold border-b-2 transition cursor-pointer ${
              activeTab === 'shareLink'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Auditor Portal Secure Link
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 space-y-4">
          {activeTab === 'downloads' && (
            <div className="space-y-3.5">
              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/70 flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 border border-blue-500/20 text-blue-400 flex items-center justify-center shrink-0">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">FTA Audit File (FAF v1.0 CSV)</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Standardized accounting data file mandated by the UAE Federal Tax Authority during formal tax audits. Contains invoice-by-invoice breakdown.
                    </p>
                    <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400 font-mono">
                      <span>{rows.length} transactions</span>
                      <span>·</span>
                      <span>TRN: {entity.vat_trn}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleDownloadFAF}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-medium text-white transition shrink-0 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Download FAF
                </button>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/70 flex items-start justify-between gap-3">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-100">Form VAT 201 Workings Worksheet</h4>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Official box-by-box breakdown (Boxes 1a-1g, 2 to 14) with General Ledger reconciliations and 30-schedule requirement checklist.
                    </p>
                    <div className="flex items-center gap-2 mt-2 text-[10px] text-slate-400 font-mono">
                      <span>Net VAT: AED {calcResult.net_vat.toLocaleString()}</span>
                      <span>·</span>
                      <span>{calcResult.recon_status}</span>
                    </div>
                  </div>
                </div>
                <button
                  onClick={handleDownloadVat201Workings}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-medium text-white transition shrink-0 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export 201
                </button>
              </div>

              <div className="p-3 rounded-xl bg-slate-800/40 border border-slate-800 text-[11px] text-slate-400 flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>Exports include cryptographic verification hashes matching the client-side AES-256 cloud vault.</span>
              </div>
            </div>
          )}

          {activeTab === 'shareLink' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-300">
                Generate an encrypted, read-only collaboration link for external chartered accountants or FTA tax agents.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Access Expiration</label>
                  <select
                    value={expiresIn}
                    onChange={(e) => setExpiresIn(e.target.value)}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white focus:outline-hidden focus:border-emerald-500"
                  >
                    <option value="7">7 Days</option>
                    <option value="14">14 Days (Standard Audit)</option>
                    <option value="30">30 Days</option>
                    <option value="90">90 Days (Statutory Review)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Assigned Role</label>
                  <select
                    value={accessRole}
                    onChange={(e) => setAccessRole(e.target.value)}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white focus:outline-hidden focus:border-emerald-500"
                  >
                    <option value="External Auditor (Read-Only)">External Auditor (Read-Only)</option>
                    <option value="Tax Agent (Reviewer)">FTA Tax Agent (Reviewer)</option>
                    <option value="Partner (Full Visibility)">Accounting Partner (Full Visibility)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1 text-xs">Access Passphrase Protection</label>
                <div className="relative">
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white text-xs font-mono focus:outline-hidden focus:border-emerald-500 pr-10"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                </div>
              </div>

              {generatedLink ? (
                <div className="p-3.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                      <Check className="w-4 h-4" /> Secure Portal Link Generated
                    </span>
                    <span className="text-[11px] text-slate-400">Expires in {expiresIn} days</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={generatedLink}
                      className="w-full rounded-lg bg-slate-900 border border-slate-700 px-2.5 py-1.5 text-xs text-slate-200 font-mono"
                    />
                    <button
                      onClick={handleCopyLink}
                      className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition shrink-0 flex items-center gap-1 cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={handleCreateShareLink}
                  disabled={isGenerating}
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-lg transition flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Share2 className="w-4 h-4" />
                  {isGenerating ? 'Generating Encrypted Token...' : 'Generate Auditor Access Link'}
                </button>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
