import React, { useState } from 'react';
import { NotificationItem } from '../types';
import { Bell, AlertCircle, Clock, DollarSign, Check, X, ShieldAlert, Sparkles } from 'lucide-react';

interface NotificationCenterModalProps {
  notifications: NotificationItem[];
  onMarkRead: (id: string) => void;
  onSelectAction: (link: string) => void;
  onClose: () => void;
}

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({
  notifications,
  onMarkRead,
  onSelectAction,
  onClose
}) => {
  const [filter, setFilter] = useState<'all' | 'high' | 'unread'>('all');
  const [pushEnabled, setPushEnabled] = useState(true);

  const filteredNotifs = notifications.filter(n => {
    if (filter === 'high') return n.severity === 'high';
    if (filter === 'unread') return !n.is_read;
    return true;
  });

  const getIcon = (cat: NotificationItem['category'], sev: NotificationItem['severity']) => {
    if (cat === 'DEADLINE') return <Clock className="w-4 h-4 text-amber-400" />;
    if (cat === 'PAYMENT') return <DollarSign className="w-4 h-4 text-rose-400" />;
    if (cat === 'EXCEPTION') return <ShieldAlert className="w-4 h-4 text-blue-400" />;
    return <Bell className="w-4 h-4 text-emerald-400" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-lg rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Compliance Alerts & Deadlines</h2>
              <p className="text-[11px] text-slate-400">Real-time alerts for overdue payments & filing countdowns</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Bar & Push Notification Toggle */}
        <div className="px-5 py-3 border-b border-slate-800/80 bg-slate-950/30 flex items-center justify-between gap-2 flex-wrap">
          <div className="flex items-center gap-1">
            <button
              onClick={() => setFilter('all')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                filter === 'all' ? 'bg-slate-800 text-white border border-slate-700' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              All ({notifications.length})
            </button>
            <button
              onClick={() => setFilter('high')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                filter === 'high' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Critical
            </button>
            <button
              onClick={() => setFilter('unread')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                filter === 'unread' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Unread
            </button>
          </div>

          <label className="flex items-center gap-1.5 text-[11px] text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={pushEnabled}
              onChange={(e) => setPushEnabled(e.target.checked)}
              className="w-3.5 h-3.5 rounded text-emerald-600 focus:ring-emerald-500"
            />
            <span>Push alerts enabled</span>
          </label>
        </div>

        {/* Notification List */}
        <div className="p-4 overflow-y-auto flex-1 space-y-2.5">
          {filteredNotifs.length === 0 ? (
            <div className="py-8 text-center text-slate-400 text-xs">
              No notifications matching this filter.
            </div>
          ) : (
            filteredNotifs.map(n => (
              <div
                key={n.id}
                className={`p-3 rounded-xl border transition flex items-start gap-3 ${
                  n.is_read
                    ? 'bg-slate-800/40 border-slate-800/80 text-slate-400'
                    : n.severity === 'high'
                    ? 'bg-rose-950/20 border-rose-500/30 text-slate-200'
                    : 'bg-slate-800/70 border-slate-700 text-slate-200'
                }`}
              >
                <div className="p-2 rounded-lg bg-slate-900 border border-slate-800 shrink-0 mt-0.5">
                  {getIcon(n.category, n.severity)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <h4 className="text-xs font-bold text-white truncate">{n.title}</h4>
                    <span className="text-[10px] text-slate-400 shrink-0">
                      {new Date(n.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">{n.message}</p>
                  
                  <div className="flex items-center justify-between mt-2.5 pt-2 border-t border-slate-800/60">
                    {n.action_link ? (
                      <button
                        onClick={() => {
                          onSelectAction(n.action_link!);
                          onClose();
                        }}
                        className="text-[11px] font-semibold text-emerald-400 hover:text-emerald-300 transition cursor-pointer"
                      >
                        Take Action →
                      </button>
                    ) : (
                      <span />
                    )}

                    {!n.is_read && (
                      <button
                        onClick={() => onMarkRead(n.id)}
                        className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1 transition cursor-pointer"
                      >
                        <Check className="w-3 h-3" /> Mark as read
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
