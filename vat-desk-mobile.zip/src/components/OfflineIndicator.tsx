import React from 'react';
import { WifiOff, CloudUpload } from 'lucide-react';

interface OfflineIndicatorProps {
  isOnline: boolean;
  queuedCount: number;
  onSyncNow: () => void;
}

export const OfflineIndicator: React.FC<OfflineIndicatorProps> = ({ isOnline, queuedCount, onSyncNow }) => {
  if (isOnline && queuedCount === 0) return null;

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-40 flex items-center gap-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white px-3.5 py-2 text-xs shadow-xl animate-in slide-in-from-bottom duration-300">
      {!isOnline ? (
        <>
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-500"></span>
          </span>
          <WifiOff className="w-4 h-4 text-amber-400" />
          <span className="font-medium text-slate-200">
            Offline Mode <span className="text-slate-400">({queuedCount} queued)</span>
          </span>
        </>
      ) : (
        <>
          <CloudUpload className="w-4 h-4 text-emerald-400 animate-bounce" />
          <span className="font-medium text-slate-200">
            {queuedCount} changes ready to sync
          </span>
          <button
            onClick={onSyncNow}
            className="ml-1 px-2 py-0.5 rounded bg-emerald-600 hover:bg-emerald-500 text-[11px] font-semibold text-white transition cursor-pointer"
          >
            Sync
          </button>
        </>
      )}
    </div>
  );
};
