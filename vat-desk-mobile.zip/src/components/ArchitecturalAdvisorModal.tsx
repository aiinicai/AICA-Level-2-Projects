import React, { useState } from 'react';
import { Lightbulb, Smartphone, Shield, Layers, Cpu, CheckCircle, ExternalLink, X, ChevronRight, Zap } from 'lucide-react';

interface ArchitecturalAdvisorModalProps {
  onClose: () => void;
}

export const ArchitecturalAdvisorModal: React.FC<ArchitecturalAdvisorModalProps> = ({ onClose }) => {
  const [activeCategory, setActiveCategory] = useState<'mobile' | 'security' | 'einvoicing' | 'sync'>('mobile');

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-2xl rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
              <Lightbulb className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">VAT-DESK Architecture & Deployment Strategy</h2>
              <p className="text-[11px] text-slate-400">Expert enhancements for iOS, Android, and Scalable Cloud Compliance</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Category Navigation */}
        <div className="flex border-b border-slate-800 px-5 pt-3 gap-2 overflow-x-auto">
          {[
            { id: 'mobile', label: '1. iOS & Android Deployment', icon: Smartphone },
            { id: 'security', label: '2. Zero-Knowledge E2EE', icon: Shield },
            { id: 'einvoicing', label: '3. UAE FTA Phase 2 e-Invoice', icon: Cpu },
            { id: 'sync', label: '4. Offline Travel & CRDTs', icon: Layers },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as any)}
                className={`pb-2.5 px-2 text-xs font-semibold border-b-2 flex items-center gap-1.5 whitespace-nowrap transition cursor-pointer ${
                  activeCategory === tab.id
                    ? 'border-emerald-500 text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Content Area */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4 text-xs text-slate-300">
          {activeCategory === 'mobile' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80">
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-1.5">
                  <Zap className="w-4 h-4" /> Recommended: Dual PWA + Capacitor 6 Hybrid Engine
                </div>
                <p className="leading-relaxed text-slate-300">
                  To achieve the best of both worlds (instant zero-install web distribution + official Apple App Store & Google Play Store availability), we recommend pairing this PWA with <strong>Capacitor</strong>:
                </p>
                <div className="mt-3 space-y-2">
                  <div className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Zero-Code Rewrite:</strong> The identical React + Vite codebase builds directly into native Xcode (iOS `.ipa`) and Android Studio (`.aab`) projects via <code className="bg-slate-900 px-1 py-0.5 rounded text-emerald-300">npx cap add ios && npx cap add android</code>.
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Hardware Biometric Authentication:</strong> Integrates iOS FaceID & TouchID and Android BiometricPrompt via <code className="bg-slate-900 px-1 py-0.5 rounded text-emerald-300">@capacitor/biometrics</code> before decrypting financial vaults.
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Native Camera Receipt Snapping:</strong> Direct camera sensor capture without browser permission dialogs using <code className="bg-slate-900 px-1 py-0.5 rounded text-emerald-300">@capacitor/camera</code> with edge detection.
                    </div>
                  </div>
                  <div className="flex items-start gap-2.5">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <strong className="text-white">Push Notifications (APNs & FCM):</strong> Native background notifications alert users even when the app is completely terminated when filing deadlines approach.
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-950/60 border border-slate-800">
                <h4 className="font-bold text-white mb-1">Architecture Comparison:</h4>
                <div className="grid grid-cols-3 gap-2 mt-2 text-[11px]">
                  <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                    <span className="font-bold text-emerald-400">PWA (Current)</span>
                    <p className="text-slate-400 mt-1">Instant updates, 0% app store fees, works on Safari & Chrome.</p>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                    <span className="font-bold text-blue-400">Capacitor Wrapper</span>
                    <p className="text-slate-400 mt-1">App Store distribution, FaceID, native push, 100% code reuse.</p>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900/90 border border-slate-800">
                    <span className="font-bold text-amber-400">React Native</span>
                    <p className="text-slate-400 mt-1">Requires dual UI components, separate desktop codebase.</p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeCategory === 'security' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2.5">
                <div className="text-emerald-400 font-bold text-sm">
                  Client-Side Envelope Encryption & Zero-Knowledge Vault
                </div>
                <p className="leading-relaxed">
                  For strict paperless audit compliance under UAE Federal Law, sensitive financial records should never be readable by backend cloud servers in plain text.
                </p>
                <ul className="space-y-2 mt-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Envelope Encryption:</strong> Generate random 256-bit Document Data Keys (DEK) for every receipt, encrypted with a master Key Encryption Key (KEK) derived from user credentials via PBKDF2/Argon2.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Immutable Hash Chaining:</strong> Maintain a cryptographic Merkle tree of receipt SHA-256 digests. Any database tampering immediately fails validation during FTA audit inquiries.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>5-Year Statutory Retention Enforcer:</strong> Automated cloud retention locks (WORM - Write Once, Read Many) to comply with Article 78 of Executive Regulations.</span>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeCategory === 'einvoicing' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2.5">
                <div className="text-emerald-400 font-bold text-sm">
                  UAE FTA e-Invoicing (Phase 2 & Peppol Network Integration)
                </div>
                <p className="leading-relaxed">
                  The UAE Ministry of Finance has mandated electronic invoicing compliance across the UAE. Enhancing VAT-DESK with e-Invoicing capabilities ensures future-proofing:
                </p>
                <ul className="space-y-2 mt-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>UBL 2.1 / Peppol BIS Billing 3.0:</strong> Automatic transformation of standard transactions into standardized XML schemas required by UAE accredited Service Providers (ASPs).</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Cryptographic B2B QR Codes:</strong> Generation of Base64 TLV (Tag-Length-Value) QR stamps containing seller TRN, timestamp, total and VAT for instant point-of-sale verification.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Pre-Clearance Gateway:</strong> Integration with FTA tax clearing engines before invoices are issued to buyers.</span>
                  </li>
                </ul>
              </div>
            </div>
          )}

          {activeCategory === 'sync' && (
            <div className="space-y-4">
              <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/80 space-y-2.5">
                <div className="text-emerald-400 font-bold text-sm">
                  High-Resilience Travel Mode with CRDT Delta Synchronization
                </div>
                <p className="leading-relaxed">
                  Small business owners frequently travel internationally without constant mobile data. The sync architecture is optimized for disconnected scenarios:
                </p>
                <ul className="space-y-2 mt-2">
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Local-First IndexedDB Persistence:</strong> Complete transactional database resides on the device, allowing calculations and audits during long flights.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Conflict-Free Delta Queue:</strong> When offline changes are merged upon landing, timestamp vector clocks prevent overwriting edits made simultaneously by the desktop accountant.</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span><strong>Background Fetch API:</strong> Automatically queues large receipt image uploads when Wi-Fi becomes available without draining cellular battery.</span>
                  </li>
                </ul>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition cursor-pointer"
          >
            Understood
          </button>
        </div>
      </div>
    </div>
  );
};
