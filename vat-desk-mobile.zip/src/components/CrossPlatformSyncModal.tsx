import React, { useState } from 'react';
import { RefreshCw, QrCode, Smartphone, Laptop, Tablet, CheckCircle, Wifi, WifiOff, X, ArrowUpRight } from 'lucide-react';
import { syncEngine, PairedDevice } from '../services/syncEngine';

interface CrossPlatformSyncModalProps {
  isOnline: boolean;
  syncStatus: 'synced' | 'syncing' | 'offline' | 'error';
  queuedCount: number;
  onSyncNow: () => Promise<void>;
  onClose: () => void;
}

export const CrossPlatformSyncModal: React.FC<CrossPlatformSyncModalProps> = ({
  isOnline,
  syncStatus,
  queuedCount,
  onSyncNow,
  onClose
}) => {
  const [isSyncing, setIsSyncing] = useState(false);
  const [pairedDevices] = useState<PairedDevice[]>(syncEngine.getPairedDevices());
  const [showQrCode, setShowQrCode] = useState(false);

  const handleManualSync = async () => {
    setIsSyncing(true);
    await onSyncNow();
    setIsSyncing(false);
  };

  const getDeviceIcon = (platform: PairedDevice['platform']) => {
    if (platform === 'iOS') return <Smartphone className="w-4 h-4 text-emerald-400" />;
    if (platform === 'Android') return <Tablet className="w-4 h-4 text-emerald-400" />;
    return <Laptop className="w-4 h-4 text-blue-400" />;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <RefreshCw className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Cross-Platform Sync & Device Pairing</h2>
              <p className="text-[11px] text-slate-400">Real-time delta synchronization between Desktop & Mobile PWA</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-5">
          {/* Status Card */}
          <div className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                !isOnline
                  ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
                  : syncStatus === 'syncing' || isSyncing
                  ? 'bg-blue-500/10 text-blue-400 border border-blue-500/20'
                  : 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
              }`}>
                {!isOnline ? <WifiOff className="w-5 h-5" /> : <Wifi className="w-5 h-5" />}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="text-xs font-bold text-white">
                    {!isOnline ? 'Offline Travel Mode' : syncStatus === 'syncing' || isSyncing ? 'Synchronizing Cloud Ledger...' : 'Fully Synchronized'}
                  </h4>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                    !isOnline ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-400'
                  }`}>
                    {syncStatus}
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  {queuedCount > 0 ? `${queuedCount} transactions stored in local offline queue` : 'All changes mirrored across your paired devices'}
                </p>
              </div>
            </div>

            <button
              onClick={handleManualSync}
              disabled={isSyncing || !isOnline}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-xs font-semibold text-white shadow-md transition active:scale-95 cursor-pointer shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              Sync Now
            </button>
          </div>

          {/* QR Code Desktop Pairing Simulation */}
          <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-200">Pair Mobile Phone with Desktop</h4>
                <p className="text-[11px] text-slate-400">Scan QR Code from desktop to log in instantly on iOS/Android PWA</p>
              </div>
              <button
                onClick={() => setShowQrCode(!showQrCode)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-medium text-slate-200 transition cursor-pointer"
              >
                <QrCode className="w-3.5 h-3.5 text-emerald-400" />
                {showQrCode ? 'Hide QR' : 'Show QR Code'}
              </button>
            </div>

            {showQrCode && (
              <div className="py-4 flex flex-col items-center justify-center bg-slate-900 rounded-xl border border-slate-800">
                {/* Clean SVG QR Code Representation */}
                <div className="w-40 h-40 bg-white p-3 rounded-xl shadow-lg flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-full h-full text-slate-900 fill-current">
                    <path d="M0,0 h30 v30 h-30 z M5,5 v20 h20 v-20 z M10,10 h10 v10 h-10 z" />
                    <path d="M70,0 h30 v30 h-30 z M75,5 v20 h20 v-20 z M80,10 h10 v10 h-10 z" />
                    <path d="M0,70 h30 v30 h-30 z M5,75 v20 h20 v-20 z M10,80 h10 v10 h-10 z" />
                    <rect x="40" y="10" width="10" height="20" />
                    <rect x="55" y="15" width="10" height="10" />
                    <rect x="35" y="40" width="30" height="10" />
                    <rect x="45" y="55" width="10" height="35" />
                    <rect x="65" y="45" width="25" height="10" />
                    <rect x="75" y="65" width="15" height="15" />
                    <rect x="15" y="45" width="10" height="15" />
                  </svg>
                </div>
                <p className="text-[11px] text-slate-400 mt-3 font-mono">
                  SESSION KEY: VAT-DESK-SECURE-SYNC-Q3-2026
                </p>
                <p className="text-[10px] text-emerald-400 mt-1">
                  End-to-End Encrypted Handshake
                </p>
              </div>
            )}
          </div>

          {/* Active Paired Devices */}
          <div>
            <h4 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">Active Authorized Devices</h4>
            <div className="space-y-2">
              {pairedDevices.map(d => (
                <div
                  key={d.id}
                  className="p-3 rounded-xl bg-slate-800/50 border border-slate-700/60 flex items-center justify-between text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center">
                      {getDeviceIcon(d.platform)}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <span className="font-semibold text-white">{d.name}</span>
                        {d.is_current && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] bg-emerald-500/20 text-emerald-300 font-medium">
                            This Device
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-400 mt-0.5">{d.ip_address} · {d.last_active}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 text-emerald-400 text-[11px] font-medium">
                    <CheckCircle className="w-3.5 h-3.5" />
                    <span>Connected</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
