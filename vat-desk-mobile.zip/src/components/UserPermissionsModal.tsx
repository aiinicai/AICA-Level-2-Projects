import React, { useState } from 'react';
import { RolePermissions } from '../types';
import { Shield, UserCheck, Check, X, Lock, Sliders } from 'lucide-react';

interface UserPermissionsModalProps {
  currentRole: 'admin' | 'preparer' | 'reviewer' | 'client';
  permissions: Record<string, RolePermissions>;
  onSelectRole: (role: 'admin' | 'preparer' | 'reviewer' | 'client') => void;
  onUpdatePermissions: (newPerms: Record<string, RolePermissions>) => void;
  onClose: () => void;
}

export const UserPermissionsModal: React.FC<UserPermissionsModalProps> = ({
  currentRole,
  permissions,
  onSelectRole,
  onUpdatePermissions,
  onClose
}) => {
  const [selectedRole, setSelectedRole] = useState<'admin' | 'preparer' | 'reviewer' | 'client'>(currentRole);
  const [localPerms, setLocalPerms] = useState<Record<string, RolePermissions>>(permissions);

  const togglePermission = (roleKey: string, permKey: keyof RolePermissions) => {
    const updated = {
      ...localPerms,
      [roleKey]: {
        ...localPerms[roleKey],
        [permKey]: !localPerms[roleKey][permKey]
      }
    };
    setLocalPerms(updated);
    onUpdatePermissions(updated);
  };

  const permissionLabels: { key: keyof RolePermissions; label: string; desc: string }[] = [
    { key: 'can_approve_filing', label: 'Approve & Sign-Off VAT 201 Return', desc: 'Allows submitting and locking final return calculations.' },
    { key: 'can_upload_documents', label: 'Upload & Scan Financial Receipts', desc: 'Allows mobile camera scan and AES-256 cloud vault additions.' },
    { key: 'can_override_categories', label: 'Override Automated Expense Categories', desc: 'Allows altering AI classifications and blocked VAT decisions.' },
    { key: 'can_export_faf', label: 'Export FTA Audit Files (FAF CSV)', desc: 'Allows downloading detailed transactional audit ledgers.' },
    { key: 'can_view_audit_logs', label: 'View Immutable Audit Logs', desc: 'Access to system security records, IP addresses, and hash audits.' },
    { key: 'can_edit_tax_rules', label: 'Modify VAT Thresholds & Penalty Rules', desc: 'Edit Cabinet Decision parameters and mandatory thresholds.' },
    { key: 'can_delete_records', label: 'Delete Invoices / Receipts', desc: 'Permanent purging of unsealed transactions.' },
    { key: 'can_manage_users', label: 'Manage Team Roles & Permissions', desc: 'Invite team members and alter authorization matrix.' },
  ];

  const roleDescriptions = {
    admin: 'Full administrative access across all client entities, rules, and system configuration.',
    preparer: 'Day-to-day bookkeeping, receipt scanning, invoice entry, and automated categorization.',
    reviewer: 'Certified tax agent or senior auditor performing reviews, reconciliations, and filing sign-off.',
    client: 'Business owner view with read-only dashboard, pending payment approvals, and receipt upload.'
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Customizable User Roles & Permissions</h2>
              <p className="text-[11px] text-slate-400">Granular role-based access control (RBAC) for financial compliance</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-5">
          {/* Active Role Switcher */}
          <div>
            <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2">
              Current Session Role (Switch to Test)
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['admin', 'preparer', 'reviewer', 'client'] as const).map(role => (
                <button
                  key={role}
                  type="button"
                  onClick={() => {
                    setSelectedRole(role);
                    onSelectRole(role);
                  }}
                  className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                    currentRole === role
                      ? 'bg-emerald-500/10 border-emerald-500 text-white'
                      : 'bg-slate-800/60 border-slate-700/70 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                  }`}
                >
                  <p className="font-bold text-xs capitalize flex items-center justify-between">
                    <span>{role}</span>
                    {currentRole === role && <UserCheck className="w-3.5 h-3.5 text-emerald-400" />}
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1 line-clamp-1">{roleDescriptions[role].slice(0, 30)}...</p>
                </button>
              ))}
            </div>
          </div>

          {/* Role Customization Tabs */}
          <div className="space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-semibold text-slate-300">
                Configuring Permissions for: <span className="text-emerald-400 uppercase font-bold">{selectedRole}</span>
              </span>
              <span className="text-[11px] text-slate-400">Toggle to customize</span>
            </div>

            <p className="text-xs text-slate-400">{roleDescriptions[selectedRole]}</p>

            {/* Permission Checklist */}
            <div className="space-y-2 mt-2">
              {permissionLabels.map(({ key, label, desc }) => {
                const isEnabled = localPerms[selectedRole]?.[key] ?? false;
                return (
                  <div
                    key={key}
                    onClick={() => togglePermission(selectedRole, key)}
                    className="p-3 rounded-xl bg-slate-800/50 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between gap-3 transition cursor-pointer select-none"
                  >
                    <div>
                      <p className="text-xs font-semibold text-slate-200">{label}</p>
                      <p className="text-[11px] text-slate-400 mt-0.5">{desc}</p>
                    </div>
                    <div
                      className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 transition ${
                        isEnabled
                          ? 'bg-emerald-500 text-white shadow-xs'
                          : 'bg-slate-700 text-slate-500'
                      }`}
                    >
                      {isEnabled ? <Check className="w-4 h-4 stroke-[2.5]" /> : <Lock className="w-3 h-3" />}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white transition cursor-pointer"
          >
            Apply & Save Role Policy
          </button>
        </div>
      </div>
    </div>
  );
};
