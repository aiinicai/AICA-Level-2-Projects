import React, { useState, useRef } from 'react';
import { Camera, Upload, ShieldCheck, CheckCircle2, AlertTriangle, ArrowRight, X, Sparkles, FileText } from 'lucide-react';
import { Entity, VatRow } from '../types';
import { simulateReceiptScan, classifyExpense } from '../services/expenseClassifier';
import { encryptAndSealDocument } from '../services/documentVault';

interface ReceiptScannerModalProps {
  entities: Entity[];
  selectedEntityId: string;
  onClose: () => void;
  onSaveTransaction: (row: Partial<VatRow>, docFile?: File) => void;
}

export const ReceiptScannerModal: React.FC<ReceiptScannerModalProps> = ({
  entities,
  selectedEntityId,
  onClose,
  onSaveTransaction
}) => {
  const [activeEntityId, setActiveEntityId] = useState(selectedEntityId);
  const [step, setStep] = useState<'upload' | 'scanning' | 'review'>('upload');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>('');
  
  // OCR & classification states
  const [vendor, setVendor] = useState('');
  const [trn, setTrn] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [docDate, setDocDate] = useState(new Date().toISOString().split('T')[0]);
  const [emirate, setEmirate] = useState('Dubai');
  const [netAmount, setNetAmount] = useState<number>(0);
  const [vatAmount, setVatAmount] = useState<number>(0);
  const [docType, setDocType] = useState<VatRow['doc_type']>('Purchase - standard rated');
  const [category, setCategory] = useState('General Business Expense');
  const [description, setDescription] = useState('');
  const [exceptions, setExceptions] = useState<string[]>([]);
  const [rationale, setRationale] = useState('');
  const [confidence, setConfidence] = useState(0.95);
  const [isEncrypted, setIsEncrypted] = useState(true);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    if (file.type.startsWith('image/')) {
      setPreviewUrl(URL.createObjectURL(file));
    } else {
      setPreviewUrl('');
    }

    setStep('scanning');

    // Simulate smart OCR + AI categorization
    setTimeout(() => {
      const scan = simulateReceiptScan(file.name);
      setVendor(scan.vendor);
      setTrn(scan.trn);
      setInvoiceNumber(scan.invoice_number);
      setDocDate(scan.date);
      setEmirate(scan.emirate);
      setNetAmount(scan.net_amount);
      setVatAmount(scan.suggested_category.is_blocked ? 0 : scan.vat_amount);
      setDocType(scan.suggested_category.doc_type);
      setCategory(scan.suggested_category.category);
      setDescription(scan.description);
      setExceptions(scan.suggested_category.exceptions);
      setRationale(scan.suggested_category.rationale);
      setConfidence(scan.suggested_category.confidence);
      setStep('review');
    }, 1200);
  };

  const handleManualRecalculate = (newParty: string, newDesc: string, newNet: number, newEmirate: string) => {
    const res = classifyExpense(newParty, newDesc, newNet, newEmirate);
    setDocType(res.doc_type);
    setCategory(res.category);
    setVatAmount(res.vat);
    setExceptions(res.exceptions);
    setRationale(res.rationale);
    setConfidence(res.confidence);
  };

  const handleSave = async () => {
    const activeEntity = entities.find(e => e.id === activeEntityId) || entities[0];
    const rowPayload: Partial<VatRow> = {
      entity_id: activeEntityId,
      period_end: activeEntity.vat_period_end,
      doc_date: docDate,
      doc_no: invoiceNumber || `INV-${Date.now().toString().slice(-4)}`,
      party: vendor || 'Commercial Supplier',
      party_trn: trn,
      emirate: emirate,
      doc_type: docType,
      net: Number(netAmount) || 0,
      vat: Number(vatAmount) || 0,
      category,
      description: description || `${category} - ${vendor}`,
      is_verified: exceptions.length === 0
    };

    onSaveTransaction(rowPayload, selectedFile || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 md:p-6 overflow-y-auto">
      <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-bold text-white">Smart Receipt & Invoice Scanner</h2>
              <p className="text-[11px] text-slate-400">Automated UAE VAT categorization & encrypted audit vault</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 overflow-y-auto flex-1 space-y-4">
          {/* Entity Selector */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1">Taxable Client Entity</label>
            <select
              value={activeEntityId}
              onChange={(e) => setActiveEntityId(e.target.value)}
              className="w-full rounded-xl bg-slate-800/80 border border-slate-700 px-3 py-2 text-xs text-white focus:outline-hidden focus:border-emerald-500"
            >
              {entities.map(e => (
                <option key={e.id} value={e.id}>
                  {e.name} (TRN: {e.vat_trn} · {e.location})
                </option>
              ))}
            </select>
          </div>

          {step === 'upload' && (
            <div className="space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-slate-700 hover:border-emerald-500/60 rounded-2xl p-8 text-center bg-slate-800/30 hover:bg-slate-800/50 transition cursor-pointer flex flex-col items-center justify-center gap-3"
              >
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <Camera className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">Tap to Scan or Upload Receipt</p>
                  <p className="text-xs text-slate-400 mt-1">Supports camera snapshot, JPG, PNG or PDF tax invoice</p>
                </div>
                <div className="flex items-center gap-2 text-[11px] text-emerald-400/90 bg-emerald-500/10 px-3 py-1 rounded-full border border-emerald-500/20">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>Client-side AES-256 encrypted before cloud sync</span>
                </div>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,application/pdf"
                capture="environment"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileSelect(e.target.files[0]);
                  }
                }}
              />

              {/* Quick Sample Presets */}
              <div>
                <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">Or test sample UAE invoice:</p>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => handleFileSelect(new File(['aws-bill'], 'AWS_Cloud_Hosting_Bill.pdf', { type: 'application/pdf' }))}
                    className="p-2.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700 text-left transition text-xs"
                  >
                    <p className="font-semibold text-slate-200">AWS Cloud Bill</p>
                    <p className="text-[11px] text-slate-400">Reverse Charge Art. 48</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleFileSelect(new File(['restaurant-dining'], 'Zuma_DIFC_Dinner_Receipt.jpg', { type: 'image/jpeg' }))}
                    className="p-2.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700 text-left transition text-xs"
                  >
                    <p className="font-semibold text-slate-200">Client Dinner</p>
                    <p className="text-[11px] text-amber-400">Blocked Input VAT Art. 53</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleFileSelect(new File(['server-hardware'], 'Sharaf_DG_Server_Hardware.jpg', { type: 'image/jpeg' }))}
                    className="p-2.5 rounded-xl bg-slate-800/70 hover:bg-slate-800 border border-slate-700 text-left transition text-xs"
                  >
                    <p className="font-semibold text-slate-200">Server Hardware</p>
                    <p className="text-[11px] text-emerald-400">Capital Asset AED 48.5k</p>
                  </button>
                </div>
              </div>
            </div>
          )}

          {step === 'scanning' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-3">
              <div className="relative">
                <div className="w-16 h-16 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center animate-pulse">
                  <Sparkles className="w-8 h-8 animate-spin" />
                </div>
              </div>
              <h3 className="text-sm font-semibold text-white">Extracting Invoice Data & Applying Tax Rules...</h3>
              <p className="text-xs text-slate-400 max-w-sm">
                Scanning TRN, vendor, invoice lines, and running automated classification under UAE Decree-Law No. 8.
              </p>
            </div>
          )}

          {step === 'review' && (
            <div className="space-y-4">
              {/* Classification Confidence Banner */}
              <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-start gap-3">
                <div className="p-1 rounded bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <Sparkles className="w-4 h-4" />
                </div>
                <div className="text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-emerald-400">Auto-Categorized: {category}</span>
                    <span className="text-[11px] text-emerald-300/80">({Math.round(confidence * 100)}% match)</span>
                  </div>
                  <p className="text-slate-300 text-[11px] mt-0.5">{rationale}</p>
                </div>
              </div>

              {exceptions.length > 0 && (
                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold">Compliance Exception Flag:</span>
                    <ul className="list-disc list-inside mt-0.5 text-[11px] text-amber-200/90">
                      {exceptions.map((ex, i) => (
                        <li key={i}>{ex}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              )}

              {/* Form Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-medium mb-1">Vendor / Counterparty</label>
                  <input
                    type="text"
                    value={vendor}
                    onChange={(e) => {
                      setVendor(e.target.value);
                      handleManualRecalculate(e.target.value, description, netAmount, emirate);
                    }}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Tax Registration Number (TRN)</label>
                  <input
                    type="text"
                    value={trn}
                    onChange={(e) => setTrn(e.target.value)}
                    placeholder="15-digit TRN"
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white font-mono focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Invoice / Receipt #</label>
                  <input
                    type="text"
                    value={invoiceNumber}
                    onChange={(e) => setInvoiceNumber(e.target.value)}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white font-mono focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Document Date</label>
                  <input
                    type="date"
                    value={docDate}
                    onChange={(e) => setDocDate(e.target.value)}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Net Amount (AED)</label>
                  <input
                    type="number"
                    value={netAmount}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setNetAmount(val);
                      handleManualRecalculate(vendor, description, val, emirate);
                    }}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white font-mono font-semibold text-sm focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Calculated VAT 5% (AED)</label>
                  <input
                    type="number"
                    value={vatAmount}
                    onChange={(e) => setVatAmount(Number(e.target.value))}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-emerald-400 font-mono font-semibold text-sm focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">Emirate of Supply</label>
                  <select
                    value={emirate}
                    onChange={(e) => {
                      setEmirate(e.target.value);
                      handleManualRecalculate(vendor, description, netAmount, e.target.value);
                    }}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white focus:outline-hidden focus:border-emerald-500"
                  >
                    {['Abu Dhabi', 'Dubai', 'Sharjah', 'Ajman', 'Umm Al Quwain', 'Ras Al Khaimah', 'Fujairah'].map(em => (
                      <option key={em} value={em}>{em}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 font-medium mb-1">VAT Return Classification</label>
                  <select
                    value={docType}
                    onChange={(e) => setDocType(e.target.value as any)}
                    className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white focus:outline-hidden focus:border-emerald-500"
                  >
                    <option value="Purchase - standard rated">Purchase - Standard Rated (Box 9)</option>
                    <option value="Purchase - blocked input VAT">Purchase - Blocked Input VAT (Article 53)</option>
                    <option value="Purchase - reverse charge">Purchase - Reverse Charge (Box 10 / Box 3)</option>
                    <option value="Purchase - capital asset">Purchase - Capital Asset (Box 9 / Art 57)</option>
                    <option value="Sale - standard rated">Sale - Standard Rated (Box 1a-1g)</option>
                    <option value="Sale - zero rated">Sale - Zero Rated (Box 4)</option>
                    <option value="Sale - designated zone goods">Sale - Designated Zone (Box 4/Out of Scope)</option>
                    <option value="Import of goods">Import of Goods (Box 6)</option>
                    <option value="Purchase - credit note">Purchase - Credit Note</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-medium mb-1 text-xs">Description & Working Notes</label>
                <input
                  type="text"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full rounded-xl bg-slate-800 border border-slate-700 px-3 py-2 text-white text-xs focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              {/* Encryption Seal Checkbox */}
              <div className="flex items-center gap-2 p-3 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <input
                  type="checkbox"
                  id="encCheck"
                  checked={isEncrypted}
                  onChange={(e) => setIsEncrypted(e.target.checked)}
                  className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="encCheck" className="text-xs text-slate-300 flex items-center gap-1.5 cursor-pointer">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span>Store original receipt in AES-256 Encrypted Cloud Vault for 5-Year FTA Audit Retention</span>
                </label>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-5 py-3.5 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between">
          {step === 'review' ? (
            <>
              <button
                type="button"
                onClick={() => setStep('upload')}
                className="px-3.5 py-2 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition"
              >
                Scan Another
              </button>
              <button
                type="button"
                onClick={handleSave}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-lg transition active:scale-95 cursor-pointer"
              >
                <CheckCircle2 className="w-4 h-4" />
                Save & Seal Transaction
              </button>
            </>
          ) : (
            <div className="w-full flex justify-end">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-xs font-medium text-slate-400 hover:bg-slate-800 transition"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
