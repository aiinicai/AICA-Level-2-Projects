export interface Entity {
  id: string;
  name: string;
  name_ar?: string;
  location: 'Mainland' | 'Designated Zone' | 'Free Zone';
  free_zone_name?: string;
  vat_trn: string;
  vat_registered: 'Yes' | 'No';
  vat_frequency: 'Quarterly' | 'Monthly';
  vat_period_end: string;
  vat_filed: 'Yes' | 'No';
  vat_paid: 'Yes' | 'No';
  vat_emirate?: string;
  address?: string;
  po_box?: string;
  landline?: string;
  std_supplies: number;
  zero_supplies: number;
  exempt_supplies: number;
  dz_goods_supplies: number;
  taxable_supplies_12m: number;
  input_vat: number;
  blocked_input_vat: number;
  reverse_charge_vat: number;
  vat_open_exceptions: number;
  tourist_refund_vat: number;
  import_goods_value: number;
  import_vat: number;
  import_adjust_vat: number;
  sales_cn_net: number;
  sales_cn_vat: number;
  purchase_cn_net: number;
  purchase_cn_vat: number;
  bad_debt_vat: number;
  deemed_supplies_vat: number;
  change_in_use_vat: number;
  capital_assets_vat: number;
  prior_period_error_vat: number;
  margin_scheme: 'Yes' | 'No';
  gl_sales_revenue: number;
  gl_output_vat: number;
  gl_input_vat: number;
}

export interface VatRow {
  id: string;
  entity_id: string;
  period_end: string;
  doc_date: string;
  doc_no: string;
  party: string;
  party_trn?: string;
  emirate?: string;
  doc_type: 
    | 'Sale - standard rated'
    | 'Sale - zero rated'
    | 'Sale - exempt'
    | 'Sale - designated zone goods'
    | 'Sale - credit note'
    | 'Purchase - standard rated'
    | 'Purchase - blocked input VAT'
    | 'Purchase - reverse charge'
    | 'Purchase - credit note'
    | 'Purchase - capital asset'
    | 'Import of goods'
    | 'Import VAT adjustment'
    | 'Tourist refund'
    | 'Bad debt relief'
    | 'Deemed supply'
    | 'Change in use adjustment';
  net: number;
  vat: number;
  category?: string;
  description: string;
  receipt_id?: string;
  is_verified?: boolean;
}

export interface EncryptedDocument {
  id: string;
  entity_id: string;
  doc_no: string;
  file_name: string;
  file_type: string;
  file_size: number;
  uploaded_at: string;
  uploaded_by: string;
  encryption_algorithm: 'AES-256-GCM';
  key_derivation: 'PBKDF2-SHA256 (100k rounds)';
  cipher_iv: string;
  auth_tag: string;
  sha256_checksum: string;
  tamper_evident_status: 'VERIFIED_COMPLIANT' | 'FLAGGED';
  preview_url?: string;
  ocr_extracted_data?: {
    vendor?: string;
    trn?: string;
    date?: string;
    total?: number;
    vat?: number;
    suggested_category?: string;
  };
}

export interface AuditLog {
  id: string;
  timestamp: string;
  entity_id: string;
  user_name: string;
  user_role: string;
  action: string;
  category: 'TRANSACTION' | 'FILING' | 'VAULT_ENCRYPTION' | 'PERMISSION' | 'SYNC' | 'EXPORT';
  details: string;
  client_ip: string;
  device: string;
  hash: string;
}

export interface NotificationItem {
  id: string;
  entity_id: string;
  title: string;
  message: string;
  severity: 'high' | 'medium' | 'info';
  category: 'DEADLINE' | 'PAYMENT' | 'EXCEPTION' | 'SYNC';
  timestamp: string;
  is_read: boolean;
  action_link?: string;
}

export interface RolePermissions {
  can_manage_users: boolean;
  can_edit_tax_rules: boolean;
  can_approve_filing: boolean;
  can_delete_records: boolean;
  can_view_audit_logs: boolean;
  can_export_faf: boolean;
  can_upload_documents: boolean;
  can_override_categories: boolean;
}

export interface VatCalculationResult {
  id: string;
  name: string;
  location: string;
  vat_status: 'On track' | 'Due soon' | 'Overdue' | 'Filed' | 'Filed, payment due' | 'Overdue (unpaid)' | 'Registration required' | 'Voluntary eligible' | 'Not registered';
  vat_flag: 'green' | 'amber' | 'red' | 'grey';
  registered: 'Yes' | 'No';
  taxable_supplies: number;
  dz_goods: number;
  output_vat: number;
  total_due: number;
  recoverable_vat: number;
  recovery_pct: number;
  net_vat: number;
  period_end: string;
  due: string;
  days_to_due: number;
  late_days: number;
  vat_penalty: number;
  vat_overdue_tax: number;
  open_exceptions: number;
  recon_status: 'Reconciled' | 'Difference' | 'Not provided' | 'Not registered';
  recon_sales_diff: number | null;
  recon_output_diff: number | null;
  recon_input_diff: number | null;
  vat_schedules_required: number;
  risk_score: number;
  rag: 'Red' | 'Amber' | 'Green';
}

export interface Vat201BoxLine {
  box: string;
  title: string;
  description: string;
  amount: number;
  vat?: number;
  adjustment?: number;
  recoverable?: number;
  is_total?: boolean;
}
