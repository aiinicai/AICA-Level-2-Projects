import React, { useState } from 'react';
import { Entity, VatRow, VatCalculationResult } from '../types';
import { generateVat201Breakdown } from '../services/taxEngine';
import { 
  FileSpreadsheet, 
  CheckCircle2, 
  Download, 
  AlertCircle, 
  ShieldCheck, 
  Layers, 
  Building2, 
  Info,
  Calendar,
  Lock
} from 'lucide-react';

interface VAT201ViewProps {
  entity: Entity;
  rows: VatRow[];
  calcResult: VatCalculationResult;
  onOpenExport: () => void;
  onSignOffReturn: () => void;
}

export const VAT201View: React.FC<VAT201ViewProps> = ({
  entity,
  rows,
  calcResult,
  onOpenExport,
  onSignOffReturn
}) => {
  const [activeTab, setActiveTab] = useState<'boxes' | 'reconciliations' | 'schedules'>('boxes');
  const [signedOff, setSignedOff] = useState(entity ? entity.vat_filed === 'Yes' : false);

  if (!entity || !calcResult) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin mx-auto" />
        <p className="text-sm font-semibold text-slate-800">Loading Form VAT 201 Return...</p>
        <p className="text-xs text-slate-400">Computing 14-box schedule breakdown</p>
      </div>
    );
  }

  const lines = generateVat201Breakdown(entity, rows);

  const outputLines = lines.filter(l => ['1a', '1b', '1c', '1d', '1e', '1f', '1g', '2', '3', '4', '5', '6', '7', '8'].includes(l.box));
  const inputLines = lines.filter(l => ['9', '10', '11'].includes(l.box));
  const summaryLines = lines.filter(l => ['12', '13', '14'].includes(l.box));

  const handleSignOff = () => {
    setSignedOff(true);
    onSignOffReturn();
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Return Header Banner */}
      <div className="p-4 rounded-2xl bg-slate-900 text-white shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                FTA FORM VAT 201
              </span>
              <span className="text-xs text-slate-400">EmaraTax Compatible</span>
            </div>
            <h2 className="text-base font-bold text-white mt-1">{entity.name}</h2>
            {entity.name_ar && <p className="text-xs text-slate-400 font-sans">{entity.name_ar}</p>}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onOpenExport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 border border-slate-700 transition cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Return Pack</span>
            </button>

            {!signedOff ? (
              <button
                onClick={handleSignOff}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-sm transition active:scale-95 cursor-pointer"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Sign Off & Lock</span>
              </button>
            ) : (
              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-semibold">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                <span>Return Signed Off</span>
              </div>
            )}
          </div>
        </div>

        {/* Legal Entity Metadata */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">Tax Registration No. (TRN)</span>
            <span className="font-mono font-bold text-slate-100">{entity.vat_trn}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">VAT Return Period</span>
            <span className="font-semibold text-slate-100">Period ending {entity.vat_period_end}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Statutory Due Date</span>
            <span className="font-mono font-bold text-emerald-400">{calcResult.due}</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Net Payable to FTA</span>
            <span className="font-mono font-bold text-emerald-300">AED {calcResult.net_vat.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200 gap-4 px-1">
        <button
          onClick={() => setActiveTab('boxes')}
          className={`pb-2.5 text-xs font-semibold border-b-2 transition cursor-pointer ${
            activeTab === 'boxes'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          VAT 201 Return Boxes (1 to 14)
        </button>
        <button
          onClick={() => setActiveTab('reconciliations')}
          className={`pb-2.5 text-xs font-semibold border-b-2 transition cursor-pointer flex items-center gap-1.5 ${
            activeTab === 'reconciliations'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          <span>GL Reconciliations</span>
          <span className={`w-2 h-2 rounded-full ${calcResult.recon_status === 'Reconciled' ? 'bg-emerald-500' : 'bg-amber-500'}`} />
        </button>
        <button
          onClick={() => setActiveTab('schedules')}
          className={`pb-2.5 text-xs font-semibold border-b-2 transition cursor-pointer ${
            activeTab === 'schedules'
              ? 'border-emerald-600 text-emerald-700'
              : 'border-transparent text-slate-500 hover:text-slate-800'
          }`}
        >
          30 Schedules Checklist ({calcResult.vat_schedules_required} Active)
        </button>
      </div>

      {activeTab === 'boxes' && (
        <div className="space-y-4">
          {/* Section 1: VAT on Sales and all other Outputs */}
          <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Section 1: VAT on Sales and all other Outputs
                </h3>
                <p className="text-[11px] text-slate-500">Standard rated supplies by Emirate (1a - 1g), Exports (4), Exempt (5) & Imports (6)</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/30">
                    <th className="py-2.5 px-4 w-12">Box</th>
                    <th className="py-2.5 px-4">Description</th>
                    <th className="py-2.5 px-4 text-right">Amount (AED)</th>
                    <th className="py-2.5 px-4 text-right">VAT Amount (AED)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {outputLines.map(line => (
                    <tr 
                      key={line.box} 
                      className={`hover:bg-slate-50/80 transition ${line.is_total ? 'bg-emerald-50/40 font-bold border-t-2 border-slate-200' : ''}`}
                    >
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                        {line.box}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="font-semibold text-slate-800">{line.title}</span>
                        <p className="text-[11px] text-slate-400">{line.description}</p>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-semibold text-slate-900">
                        AED {line.amount?.toLocaleString() || '0'}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-bold text-emerald-700">
                        {line.vat !== undefined ? `AED ${line.vat.toLocaleString()}` : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 2: VAT on Expenses and all other Inputs */}
          <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
            <div className="p-3.5 bg-slate-50 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Section 2: VAT on Expenses and all other Inputs
                </h3>
                <p className="text-[11px] text-slate-500">Standard purchases (Box 9), Reverse charge expenses (Box 10), Adjustments (Box 11)</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-semibold bg-slate-50/30">
                    <th className="py-2.5 px-4 w-12">Box</th>
                    <th className="py-2.5 px-4">Description</th>
                    <th className="py-2.5 px-4 text-right">Amount (AED)</th>
                    <th className="py-2.5 px-4 text-right">Recoverable VAT (AED)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {inputLines.map(line => (
                    <tr key={line.box} className="hover:bg-slate-50/80 transition">
                      <td className="py-2.5 px-4 font-mono font-bold text-slate-900">
                        {line.box}
                      </td>
                      <td className="py-2.5 px-4">
                        <span className="font-semibold text-slate-800">{line.title}</span>
                        <p className="text-[11px] text-slate-400">{line.description}</p>
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-semibold text-slate-900">
                        AED {line.amount?.toLocaleString() || '0'}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono font-bold text-emerald-700">
                        AED {line.recoverable?.toLocaleString() || '0'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Net VAT Due Summary (Boxes 12, 13, 14) */}
          <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs p-5 space-y-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              Section 3: Net VAT Calculation (Due / Recoverable)
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 block">Box 12: Total Due Tax</span>
                <span className="text-lg font-mono font-extrabold text-slate-900">
                  AED {calcResult.total_due.toLocaleString()}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200">
                <span className="text-[11px] font-semibold text-slate-500 block">Box 13: Total Recoverable Tax</span>
                <span className="text-lg font-mono font-extrabold text-slate-900">
                  AED {calcResult.recoverable_vat.toLocaleString()}
                </span>
              </div>

              <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200">
                <span className="text-[11px] font-semibold text-emerald-800 block">
                  {calcResult.net_vat >= 0 ? 'Box 14: Payable Tax' : 'Box 14: Net Refundable'}
                </span>
                <span className="text-lg font-mono font-extrabold text-emerald-900">
                  AED {calcResult.net_vat.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'reconciliations' && (
        <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
            <div>
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                General Ledger (GL) vs. VAT 201 Reconciliations
              </h3>
              <p className="text-[11px] text-slate-500">Compares reported revenue & VAT with trial balance ledgers</p>
            </div>
            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
              calcResult.recon_status === 'Reconciled' 
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                : 'bg-amber-50 text-amber-700 border border-amber-200'
            }`}>
              {calcResult.recon_status}
            </span>
          </div>

          <div className="space-y-3">
            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-800">Sales Revenue Reconciliation</span>
                <p className="text-[11px] text-slate-500">GL Revenue: AED {entity.gl_sales_revenue.toLocaleString()}</p>
              </div>
              <span className="font-mono font-bold text-slate-900">
                Diff: {calcResult.recon_sales_diff !== null ? `AED ${calcResult.recon_sales_diff.toLocaleString()}` : 'Not provided'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-800">Output VAT Control Account</span>
                <p className="text-[11px] text-slate-500">GL Output VAT: AED {entity.gl_output_vat.toLocaleString()}</p>
              </div>
              <span className="font-mono font-bold text-slate-900">
                Diff: {calcResult.recon_output_diff !== null ? `AED ${calcResult.recon_output_diff.toLocaleString()}` : 'Not provided'}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-800">Input VAT Control Account</span>
                <p className="text-[11px] text-slate-500">GL Input VAT: AED {entity.gl_input_vat.toLocaleString()}</p>
              </div>
              <span className="font-mono font-bold text-slate-900">
                Diff: {calcResult.recon_input_diff !== null ? `AED ${calcResult.recon_input_diff.toLocaleString()}` : 'Not provided'}
              </span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'schedules' && (
        <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs p-5 space-y-4">
          <div className="border-b border-slate-100 pb-3">
            <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
              30 Statutory VAT Schedules Checklist
            </h3>
            <p className="text-[11px] text-slate-500">Supporting schedules automatically triggered based on transactional activity</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            {[
              { id: 'S01', name: 'Standard rated supplies register', req: true },
              { id: 'S02', name: 'Emirate-by-Emirate apportionment', req: true },
              { id: 'S03', name: 'Credit notes issued ledger', req: (entity.sales_cn_net || 0) > 0 },
              { id: 'S04', name: 'Planet Tourist Refund reconciliation', req: (entity.tourist_refund_vat || 0) > 0 },
              { id: 'S05', name: 'Article 48 Reverse Charge Schedule', req: (entity.reverse_charge_vat || 0) > 0 },
              { id: 'S06', name: 'Export exit certificates & bill of lading', req: (entity.zero_supplies || 0) > 0 },
              { id: 'S07', name: 'Exempt supply input apportionment', req: (entity.exempt_supplies || 0) > 0 },
              { id: 'S08', name: 'Purchases standard rated control register', req: true },
              { id: 'S09', name: 'Article 53 Blocked Entertainment analysis', req: (entity.blocked_input_vat || 0) > 0 },
              { id: 'S10', name: 'Capital Assets Scheme 5/10-year tracking', req: (entity.capital_assets_vat || 0) > 0 },
              { id: 'S11', name: 'Customs declaration import reconciliation', req: (entity.import_vat || 0) > 0 },
              { id: 'S12', name: 'Designated Zone physical movements proof', req: entity.location === 'Designated Zone' },
              { id: 'S13', name: 'Bad Debt Relief claim file', req: (entity.bad_debt_vat || 0) > 0 },
              { id: 'S14', name: 'Prior period error adjustments', req: false },
              { id: 'S15', name: 'Tax Agent Representation & Sign-off', req: true },
            ].map(item => (
              <div 
                key={item.id}
                className={`p-2.5 rounded-xl border flex items-center justify-between ${
                  item.req ? 'bg-emerald-50/40 border-emerald-200 text-slate-800' : 'bg-slate-50 border-slate-200 text-slate-400'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="font-mono text-[11px] font-bold text-slate-500">{item.id}</span>
                  <span className="font-medium">{item.name}</span>
                </div>
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  item.req ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-600'
                }`}>
                  {item.req ? 'Required' : 'N/A'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
