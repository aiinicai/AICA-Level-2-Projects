import React from 'react';
import { Entity, VatRow, VatCalculationResult, NotificationItem } from '../types';
import { 
  Building2, 
  Calendar, 
  AlertTriangle, 
  ShieldCheck, 
  TrendingUp, 
  ArrowUpRight, 
  Camera, 
  Plus, 
  FileSpreadsheet, 
  Clock, 
  DollarSign, 
  CheckCircle2, 
  ChevronRight,
  ExternalLink
} from 'lucide-react';

interface DashboardViewProps {
  entities: Entity[];
  selectedEntityId: string;
  calculations: VatCalculationResult[];
  vatRows: VatRow[];
  notifications: NotificationItem[];
  onSelectEntity: (id: string) => void;
  onOpenScanner: () => void;
  onOpenExport: () => void;
  onNavigateTab: (tab: 'dashboard' | 'invoices' | 'vat201' | 'vault' | 'audit') => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  entities,
  selectedEntityId,
  calculations,
  vatRows,
  notifications,
  onSelectEntity,
  onOpenScanner,
  onOpenExport,
  onNavigateTab
}) => {
  const currentCalc = calculations.find(c => c.id === selectedEntityId) || calculations[0];
  const currentEntity = entities.find(e => e.id === selectedEntityId) || entities[0];

  if (!currentEntity || !currentCalc) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin mx-auto" />
        <p className="text-sm font-semibold text-slate-800">Loading VAT-DESK Portfolio...</p>
        <p className="text-xs text-slate-400">Synchronizing client entities and tax ledgers</p>
      </div>
    );
  }

  // Aggregate stats across all client entities
  const totalNetVat = calculations.reduce((sum, c) => sum + (c.registered === 'Yes' && c.net_vat > 0 ? c.net_vat : 0), 0);
  const totalPenaltyExposure = calculations.reduce((sum, c) => sum + c.vat_penalty, 0);
  const totalExceptions = calculations.reduce((sum, c) => sum + c.open_exceptions, 0);
  const overdueEntities = calculations.filter(c => c.vat_status.includes('Overdue') || c.vat_flag === 'red');
  const dueSoonEntities = calculations.filter(c => c.vat_status === 'Due soon');

  // Closest deadline
  const nextDeadlineCalc = [...calculations]
    .filter(c => c.registered === 'Yes' && c.days_to_due >= 0)
    .sort((a, b) => a.days_to_due - b.days_to_due)[0];

  return (
    <div className="space-y-5 pb-10">
      {/* Top Welcome & Entity Selector Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-900 text-white flex items-center justify-center font-bold text-sm shadow-xs">
            {currentEntity.name.slice(0, 2).toUpperCase()}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-bold text-slate-900">{currentEntity.name}</h2>
              <span className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                currentEntity.location === 'Designated Zone' 
                  ? 'bg-amber-50 text-amber-700 border border-amber-200' 
                  : 'bg-slate-100 text-slate-700'
              }`}>
                {currentEntity.location}
              </span>
            </div>
            <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
              <span>TRN: <strong className="font-mono text-slate-700">{currentEntity.vat_trn}</strong></span>
              <span aria-hidden="true">·</span>
              <span>{currentEntity.vat_frequency} Filing</span>
              <span aria-hidden="true">·</span>
              <span>Period End: {currentEntity.vat_period_end}</span>
            </div>
          </div>
        </div>

        {/* Entity Switcher dropdown */}
        <div className="flex items-center gap-2">
          <select
            value={selectedEntityId}
            onChange={(e) => onSelectEntity(e.target.value)}
            className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-1.5 text-xs text-slate-800 font-medium focus:outline-hidden focus:border-emerald-500 cursor-pointer"
          >
            {entities.map(e => (
              <option key={e.id} value={e.id}>
                {e.name} ({e.location})
              </option>
            ))}
          </select>

          <button
            onClick={onOpenScanner}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-xs transition active:scale-95 cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Scan Receipt</span>
          </button>
        </div>
      </div>

      {/* Critical Alerts Banner (if overdue or due soon) */}
      {currentCalc.vat_flag === 'red' && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 flex items-start gap-3 shadow-xs">
          <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
          <div className="flex-1 text-xs">
            <h4 className="font-bold text-rose-900">Immediate Action Required: VAT Filing Status is Overdue</h4>
            <p className="text-rose-700 mt-0.5">
              Filing period ending {currentCalc.period_end} is {currentCalc.late_days} days past the statutory 28-day deadline. 
              Estimated penalty exposure is <strong>AED {currentCalc.vat_penalty.toLocaleString()}</strong> under UAE Cabinet Decision 129.
            </p>
            <div className="flex items-center gap-3 mt-2.5">
              <button
                onClick={() => onNavigateTab('vat201')}
                className="px-3 py-1 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-semibold text-[11px] transition cursor-pointer"
              >
                Review Form VAT 201 →
              </button>
            </div>
          </div>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Net VAT Due */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Net VAT Payable</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2">
            <span className="text-xl font-extrabold text-slate-900 font-mono tracking-tight">
              AED {currentCalc.net_vat.toLocaleString()}
            </span>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Output: AED {currentCalc.output_vat.toLocaleString()}</span>
              <span>·</span>
              <span>Input: AED {currentCalc.recoverable_vat.toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Penalty Exposure */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Penalty Exposure</span>
            <AlertTriangle className={`w-4 h-4 ${currentCalc.vat_penalty > 0 ? 'text-rose-500' : 'text-slate-400'}`} />
          </div>
          <div className="mt-2">
            <span className={`text-xl font-extrabold font-mono tracking-tight ${currentCalc.vat_penalty > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              AED {currentCalc.vat_penalty.toLocaleString()}
            </span>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Status: <strong className="font-semibold text-slate-700">{currentCalc.vat_status}</strong></span>
            </div>
          </div>
        </div>

        {/* Filing Deadline Countdown */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Next Filing Due</span>
            <Clock className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2">
            <span className="text-xl font-extrabold text-slate-900 font-mono tracking-tight">
              {currentCalc.days_to_due >= 0 ? `${currentCalc.days_to_due} Days` : `${Math.abs(currentCalc.days_to_due)}d Overdue`}
            </span>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1">
              <span>Due: <strong className="text-slate-700">{currentCalc.due}</strong></span>
            </div>
          </div>
        </div>

        {/* GL Reconciliation & Risk */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>General Ledger Recon</span>
            <ShieldCheck className={`w-4 h-4 ${currentCalc.recon_status === 'Reconciled' ? 'text-emerald-500' : 'text-amber-500'}`} />
          </div>
          <div className="mt-2">
            <span className={`text-base font-bold ${currentCalc.recon_status === 'Reconciled' ? 'text-emerald-700' : 'text-amber-700'}`}>
              {currentCalc.recon_status}
            </span>
            <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-1.5">
              <span>Risk Score: {currentCalc.risk_score}/100</span>
              <span>·</span>
              <span>{currentCalc.vat_schedules_required} Schedules</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Grid: All Client Overview & Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Left Column (2 Cols on desktop): Client Entities Portfolio Table */}
        <div className="lg:col-span-2 space-y-4">
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Client Entities Portfolio Status</h3>
                <p className="text-[11px] text-slate-500">Live VAT position across all registered businesses</p>
              </div>
              <button
                onClick={onOpenExport}
                className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 transition cursor-pointer"
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Export FAF / Workings</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 text-slate-400 font-medium">
                    <th className="pb-2">Entity</th>
                    <th className="pb-2">Location</th>
                    <th className="pb-2 text-right">Net VAT</th>
                    <th className="pb-2">Status</th>
                    <th className="pb-2 text-right">Deadline</th>
                    <th className="pb-2 text-right">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {calculations.map(calc => {
                    const isSelected = calc.id === selectedEntityId;
                    return (
                      <tr 
                        key={calc.id}
                        onClick={() => onSelectEntity(calc.id)}
                        className={`hover:bg-slate-50/80 transition cursor-pointer ${isSelected ? 'bg-emerald-50/40' : ''}`}
                      >
                        <td className="py-2.5 font-semibold text-slate-900 max-w-[150px] truncate">
                          {calc.name}
                        </td>
                        <td className="py-2.5 text-slate-500">
                          {calc.location}
                        </td>
                        <td className="py-2.5 text-right font-mono font-semibold text-slate-800">
                          AED {calc.net_vat.toLocaleString()}
                        </td>
                        <td className="py-2.5">
                          <span className={`inline-flex items-center gap-1 text-[11px] font-semibold ${
                            calc.vat_flag === 'red' ? 'text-rose-600' :
                            calc.vat_flag === 'amber' ? 'text-amber-600' :
                            calc.vat_flag === 'green' ? 'text-emerald-600' : 'text-slate-500'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${
                              calc.vat_flag === 'red' ? 'bg-rose-500' :
                              calc.vat_flag === 'amber' ? 'bg-amber-500' :
                              calc.vat_flag === 'green' ? 'bg-emerald-500' : 'bg-slate-400'
                            }`} />
                            {calc.vat_status}
                          </span>
                        </td>
                        <td className="py-2.5 text-right font-mono text-slate-600 text-[11px]">
                          {calc.due}
                        </td>
                        <td className="py-2.5 text-right">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectEntity(calc.id);
                              onNavigateTab('vat201');
                            }}
                            className="p-1 rounded hover:bg-slate-200 text-slate-400 hover:text-slate-800 transition"
                            title="View VAT 201"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Invoice & Expense Feed Preview */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Recent Transactions & Receipts</h3>
                <p className="text-[11px] text-slate-500">Automated categorization applied for {currentEntity.name}</p>
              </div>
              <button
                onClick={() => onNavigateTab('invoices')}
                className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 transition cursor-pointer"
              >
                <span>View All ({vatRows.filter(r => r.entity_id === currentEntity.id).length})</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="divide-y divide-slate-100">
              {vatRows.filter(r => r.entity_id === currentEntity.id).slice(0, 4).map(row => (
                <div key={row.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-slate-900">{row.party}</span>
                      <span className="text-[10px] text-slate-400 font-mono">#{row.doc_no}</span>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500 mt-0.5">
                      <span>{row.doc_type}</span>
                      <span aria-hidden="true">·</span>
                      <span>{row.emirate || 'Dubai'}</span>
                      <span aria-hidden="true">·</span>
                      <span>{row.doc_date}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-bold text-slate-900">AED {row.net.toLocaleString()}</p>
                    <p className="font-mono text-[11px] text-emerald-600">+AED {row.vat.toLocaleString()} VAT</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Quick Compliance Actions & Paperless Vault Health */}
        <div className="space-y-4">
          {/* Quick Actions Card */}
          <div className="p-4 rounded-2xl bg-slate-900 text-white shadow-xs">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 mb-3">Mobile Quick Actions</h3>
            <div className="space-y-2">
              <button
                onClick={onOpenScanner}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-left transition cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                    <Camera className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-xs text-white">Scan Receipt / Invoice</p>
                    <p className="text-[11px] text-slate-400">OCR extraction & instant 5% calculation</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={() => onNavigateTab('vat201')}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-left transition cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center">
                    <FileSpreadsheet className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-xs text-white">Form VAT 201 Return</p>
                    <p className="text-[11px] text-slate-400">Box 1 to Box 14 review & sign-off</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>

              <button
                onClick={onOpenExport}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-800 hover:bg-slate-700/80 border border-slate-700 text-left transition cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center">
                    <ExternalLink className="w-4 h-4" />
                  </div>
                  <div>
                    <p className="font-semibold text-xs text-white">Auditor Export & Share</p>
                    <p className="text-[11px] text-slate-400">Generate FAF file & auditor link</p>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Paperless Audit Vault Card */}
          <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">Encrypted Cloud Vault</h3>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-semibold flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> AES-256
              </span>
            </div>
            <p className="text-xs text-slate-500 leading-relaxed">
              Paperless receipts and tax invoices for {currentEntity.name} are sealed with client-side encryption and SHA-256 tamper-evident digests for 5-year FTA statutory compliance.
            </p>
            <div className="mt-3.5 pt-3 border-t border-slate-100 flex items-center justify-between">
              <button
                onClick={() => onNavigateTab('vault')}
                className="text-xs font-semibold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 cursor-pointer"
              >
                <span>Open Document Vault</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onNavigateTab('audit')}
                className="text-xs text-slate-500 hover:text-slate-800 cursor-pointer"
              >
                Audit Trail
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
