import React, { useState } from 'react';
import { Entity, VatRow } from '../types';
import { 
  Plus, 
  Search, 
  Filter, 
  Camera, 
  FileText, 
  ShieldCheck, 
  AlertTriangle, 
  Trash2, 
  Download, 
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

interface InvoicesViewProps {
  entity: Entity;
  rows: VatRow[];
  onOpenScanner: () => void;
  onDeleteRow: (id: string) => void;
  onOpenVaultDoc: (docId?: string) => void;
}

export const InvoicesView: React.FC<InvoicesViewProps> = ({
  entity,
  rows,
  onOpenScanner,
  onDeleteRow,
  onOpenVaultDoc
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedEmirate, setSelectedEmirate] = useState<string>('all');

  if (!entity) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin mx-auto" />
        <p className="text-sm font-semibold text-slate-800">Loading Invoices Ledger...</p>
      </div>
    );
  }

  const filteredRows = rows.filter(r => {
    if (r.entity_id !== entity.id) return false;
    
    // Search
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      const match = 
        r.doc_no.toLowerCase().includes(q) ||
        r.party.toLowerCase().includes(q) ||
        r.description.toLowerCase().includes(q) ||
        (r.category || '').toLowerCase().includes(q) ||
        (r.party_trn || '').toLowerCase().includes(q);
      if (!match) return false;
    }

    // Type filter
    if (selectedType !== 'all') {
      if (selectedType === 'sales' && !r.doc_type.startsWith('Sale')) return false;
      if (selectedType === 'purchases' && !r.doc_type.startsWith('Purchase')) return false;
      if (selectedType === 'blocked' && r.doc_type !== 'Purchase - blocked input VAT') return false;
      if (selectedType === 'reverse_charge' && r.doc_type !== 'Purchase - reverse charge') return false;
      if (selectedType === 'capital_asset' && r.doc_type !== 'Purchase - capital asset') return false;
    }

    // Emirate filter
    if (selectedEmirate !== 'all' && r.emirate !== selectedEmirate) return false;

    return true;
  });

  const totalNet = filteredRows.reduce((acc, r) => acc + (Number(r.net) || 0), 0);
  const totalVat = filteredRows.reduce((acc, r) => acc + (Number(r.vat) || 0), 0);

  return (
    <div className="space-y-4 pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div>
          <h2 className="text-sm font-bold text-slate-900">Invoices, Expenses & Receipts Ledger</h2>
          <div className="flex items-center gap-2 text-xs text-slate-500 mt-0.5">
            <span>{entity.name}</span>
            <span aria-hidden="true">·</span>
            <span>{filteredRows.length} filtered items</span>
            <span aria-hidden="true">·</span>
            <span>Period End: {entity.vat_period_end}</span>
          </div>
        </div>

        <button
          onClick={onOpenScanner}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-xs transition active:scale-95 cursor-pointer self-start sm:self-auto"
        >
          <Camera className="w-4 h-4" />
          <span>Scan / Add Invoice</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by doc #, supplier, customer, TRN or category..."
            className="w-full rounded-xl bg-slate-50 border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-emerald-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 md:pb-0">
          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2 text-xs text-slate-700 font-medium focus:outline-hidden focus:border-emerald-500 cursor-pointer"
          >
            <option value="all">All Document Types</option>
            <option value="sales">Sales (Outputs)</option>
            <option value="purchases">Standard Purchases (Inputs)</option>
            <option value="reverse_charge">Reverse Charge (Art 48)</option>
            <option value="blocked">Blocked Input VAT (Art 53)</option>
            <option value="capital_asset">Capital Assets (Art 57)</option>
          </select>

          <select
            value={selectedEmirate}
            onChange={(e) => setSelectedEmirate(e.target.value)}
            className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2 text-xs text-slate-700 font-medium focus:outline-hidden focus:border-emerald-500 cursor-pointer"
          >
            <option value="all">All Emirates</option>
            <option value="Abu Dhabi">Abu Dhabi</option>
            <option value="Dubai">Dubai</option>
            <option value="Sharjah">Sharjah</option>
            <option value="Ajman">Ajman</option>
            <option value="Ras Al Khaimah">Ras Al Khaimah</option>
            <option value="Fujairah">Fujairah</option>
            <option value="Umm Al Quwain">Umm Al Quwain</option>
          </select>
        </div>
      </div>

      {/* Summary Chips (Unboxed text with separators per design constitution) */}
      <div className="flex items-center gap-3 text-xs text-slate-600 px-1">
        <span>Filtered Total Net: <strong className="font-mono text-slate-900 font-bold">AED {totalNet.toLocaleString()}</strong></span>
        <span aria-hidden="true">·</span>
        <span>Filtered Total VAT: <strong className="font-mono text-emerald-600 font-bold">AED {totalVat.toLocaleString()}</strong></span>
        <span aria-hidden="true">·</span>
        <span>Auto-categorization active</span>
      </div>

      {/* Table / Card List */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        {filteredRows.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <FileText className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No transactions found</p>
            <p className="text-xs text-slate-400">Try adjusting your search terms or upload a new receipt</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Date / Doc #</th>
                  <th className="py-3 px-4">Counterparty & TRN</th>
                  <th className="py-3 px-4">Type & Category</th>
                  <th className="py-3 px-4">Emirate</th>
                  <th className="py-3 px-4 text-right">Net Amount</th>
                  <th className="py-3 px-4 text-right">VAT 5%</th>
                  <th className="py-3 px-4 text-center">Receipt Vault</th>
                  <th className="py-3 px-4 text-center">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredRows.map(row => {
                  const isBlocked = row.doc_type === 'Purchase - blocked input VAT';
                  const isReverseCharge = row.doc_type === 'Purchase - reverse charge';
                  const isSale = row.doc_type.startsWith('Sale');

                  return (
                    <tr key={row.id} className="hover:bg-slate-50/70 transition">
                      <td className="py-3 px-4 whitespace-nowrap">
                        <span className="font-bold text-slate-900 font-mono">{row.doc_no}</span>
                        <div className="text-[11px] text-slate-500">{row.doc_date}</div>
                      </td>

                      <td className="py-3 px-4 max-w-[180px]">
                        <span className="font-semibold text-slate-900 truncate block">{row.party}</span>
                        {row.party_trn ? (
                          <span className="text-[10px] text-slate-400 font-mono block">TRN: {row.party_trn}</span>
                        ) : (
                          <span className="text-[10px] text-amber-500 block">TRN Not Provided</span>
                        )}
                      </td>

                      <td className="py-3 px-4 max-w-[200px]">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-[11px] font-semibold ${
                            isSale ? 'text-blue-700' :
                            isBlocked ? 'text-rose-700' :
                            isReverseCharge ? 'text-amber-700' : 'text-slate-800'
                          }`}>
                            {row.doc_type}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-500 truncate" title={row.description}>
                          {row.category || row.description}
                        </div>
                      </td>

                      <td className="py-3 px-4 whitespace-nowrap text-slate-600">
                        {row.emirate || 'Dubai'}
                      </td>

                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 whitespace-nowrap">
                        AED {row.net.toLocaleString()}
                      </td>

                      <td className="py-3 px-4 text-right font-mono whitespace-nowrap">
                        {isBlocked ? (
                          <span className="text-slate-400 font-semibold" title="Blocked input VAT under Art 53">AED 0 (Blocked)</span>
                        ) : (
                          <span className="font-bold text-emerald-600">AED {row.vat.toLocaleString()}</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        {row.receipt_id ? (
                          <button
                            onClick={() => onOpenVaultDoc(row.receipt_id)}
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-[10px] font-semibold border border-emerald-200 transition cursor-pointer"
                          >
                            <ShieldCheck className="w-3 h-3 text-emerald-600" />
                            <span>AES-256 Sealed</span>
                          </button>
                        ) : (
                          <span className="text-[11px] text-slate-400">Paperless pending</span>
                        )}
                      </td>

                      <td className="py-3 px-4 text-center whitespace-nowrap">
                        <button
                          onClick={() => onDeleteRow(row.id)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition cursor-pointer"
                          title="Delete transaction"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
