import React, { useState } from 'react';
import { Entity, EncryptedDocument } from '../types';
import { 
  ShieldCheck, 
  Lock, 
  FileText, 
  Download, 
  Eye, 
  CheckCircle, 
  AlertTriangle, 
  Key, 
  Hash, 
  Clock, 
  ExternalLink,
  Camera,
  X
} from 'lucide-react';
import { generateComplianceVerificationCertificate } from '../services/documentVault';

interface EncryptedVaultViewProps {
  entity: Entity;
  documents: EncryptedDocument[];
  onOpenScanner: () => void;
}

export const EncryptedVaultView: React.FC<EncryptedVaultViewProps> = ({
  entity,
  documents,
  onOpenScanner
}) => {
  const [selectedDoc, setSelectedDoc] = useState<EncryptedDocument | null>(null);
  const [showCertificate, setShowCertificate] = useState(false);

  if (!entity) {
    return (
      <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 shadow-xs space-y-2">
        <div className="w-8 h-8 rounded-full border-2 border-emerald-500 border-t-transparent animate-spin mx-auto" />
        <p className="text-sm font-semibold text-slate-800">Loading Document Vault...</p>
      </div>
    );
  }

  const entityDocs = documents.filter(d => d.entity_id === entity.id);

  const handleDownloadCertificate = (doc: EncryptedDocument) => {
    const certText = generateComplianceVerificationCertificate(doc, entity.name, entity.vat_trn);
    const blob = new Blob([certText], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `FTA_Audit_Certificate_${doc.doc_no}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Vault Header Banner */}
      <div className="p-4 rounded-2xl bg-slate-900 text-white shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm font-bold text-white">Paperless Encrypted Document Vault</h2>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                  AES-256-GCM
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                5-Year statutory record retention compliant with UAE Federal Law Article 78
              </p>
            </div>
          </div>

          <button
            onClick={onOpenScanner}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-xs transition active:scale-95 cursor-pointer self-start sm:self-auto"
          >
            <Camera className="w-3.5 h-3.5" />
            <span>Upload & Seal Document</span>
          </button>
        </div>

        {/* Security Parameters Metric */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-3 text-xs">
          <div>
            <span className="text-slate-400 block text-[11px]">Encryption Cipher</span>
            <span className="font-mono font-bold text-slate-100">AES-256-GCM</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Integrity Digest</span>
            <span className="font-mono font-bold text-slate-100">SHA-256 Checksum</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Sealed Documents</span>
            <span className="font-mono font-bold text-emerald-400">{entityDocs.length} Receipts & Invoices</span>
          </div>
          <div>
            <span className="text-slate-400 block text-[11px]">Audit Tamper Status</span>
            <span className="font-semibold text-emerald-400 flex items-center gap-1">
              <CheckCircle className="w-3.5 h-3.5" /> 100% Verified
            </span>
          </div>
        </div>
      </div>

      {/* Documents Grid / List */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
            Sealed Financial Records for {entity.name}
          </h3>
          <span className="text-xs text-slate-500">TRN: {entity.vat_trn}</span>
        </div>

        {entityDocs.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <Lock className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No documents in vault for this entity</p>
            <p className="text-xs text-slate-400">Scan receipts or tax invoices to archive them in the encrypted vault</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {entityDocs.map(doc => (
              <div 
                key={doc.id}
                className="p-4 hover:bg-slate-50/70 transition flex flex-col md:flex-row md:items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center shrink-0">
                    <FileText className="w-5 h-5 text-emerald-600" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-slate-900">{doc.file_name}</span>
                      <span className="font-mono text-[10px] text-slate-400 font-semibold">#{doc.doc_no}</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                        {doc.tamper_evident_status}
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-500 mt-1">
                      <span>Size: {(doc.file_size / 1024).toFixed(1)} KB</span>
                      <span aria-hidden="true">·</span>
                      <span>Uploaded by {doc.uploaded_by}</span>
                      <span aria-hidden="true">·</span>
                      <span>{new Date(doc.uploaded_at).toLocaleDateString()}</span>
                    </div>

                    {/* Hash & Cipher line */}
                    <div className="flex items-center gap-2 font-mono text-[10px] text-slate-400 mt-1.5">
                      <Hash className="w-3 h-3 text-emerald-600 shrink-0" />
                      <span className="truncate max-w-[280px]">SHA-256: {doc.sha256_checksum}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end md:self-auto shrink-0">
                  <button
                    onClick={() => {
                      setSelectedDoc(doc);
                      setShowCertificate(true);
                    }}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium transition cursor-pointer"
                  >
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                    <span>View Certificate</span>
                  </button>

                  <button
                    onClick={() => handleDownloadCertificate(doc)}
                    className="p-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 transition cursor-pointer"
                    title="Download FTA Audit Verification Certificate"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Compliance Certificate Modal */}
      {showCertificate && selectedDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-xs p-4 overflow-y-auto">
          <div className="w-full max-w-xl rounded-2xl bg-slate-900 border border-slate-800 text-white shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2.5">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-bold text-white">FTA Audit Compliance Certificate</h3>
              </div>
              <button onClick={() => setShowCertificate(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-[11px] font-mono text-emerald-300 whitespace-pre-wrap overflow-x-auto leading-relaxed">
              {generateComplianceVerificationCertificate(selectedDoc, entity.name, entity.vat_trn)}
            </pre>

            <div className="flex justify-between items-center pt-2">
              <button
                onClick={() => handleDownloadCertificate(selectedDoc)}
                className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white shadow-sm transition cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                Download Certificate (.txt)
              </button>
              <button
                onClick={() => setShowCertificate(false)}
                className="px-4 py-1.5 rounded-xl text-xs font-medium text-slate-300 hover:bg-slate-800 transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
