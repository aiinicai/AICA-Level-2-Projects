import React, { useState } from 'react';
import { AuditLog } from '../types';
import { ShieldCheck, Search, Filter, Hash, Download, Laptop, Smartphone, Server, FileText } from 'lucide-react';

interface AuditLogsViewProps {
  logs: AuditLog[];
}

export const AuditLogsView: React.FC<AuditLogsViewProps> = ({ logs }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredLogs = logs.filter(log => {
    if (selectedCategory !== 'all' && log.category !== selectedCategory) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        log.action.toLowerCase().includes(q) ||
        log.user_name.toLowerCase().includes(q) ||
        log.details.toLowerCase().includes(q) ||
        log.entity_id.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleExportLogs = () => {
    let csv = `"Audit ID","Timestamp (UTC)","Entity ID","User Name","User Role","Action","Category","Details","Client IP","Device","SHA-256 Hash"\n`;
    for (const l of filteredLogs) {
      csv += `"${l.id}","${l.timestamp}","${l.entity_id}","${l.user_name}","${l.user_role}","${l.action}","${l.category}","${l.details.replace(/"/g, '""')}","${l.client_ip}","${l.device}","${l.hash}"\n`;
    }
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VAT_DESK_Audit_Ledger_${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getDeviceIcon = (device: string) => {
    if (device.includes('Mobile') || device.includes('iOS') || device.includes('Android')) {
      return <Smartphone className="w-3.5 h-3.5 text-emerald-600" />;
    }
    if (device.includes('Cloud') || device.includes('Node')) {
      return <Server className="w-3.5 h-3.5 text-blue-600" />;
    }
    return <Laptop className="w-3.5 h-3.5 text-slate-600" />;
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-bold text-slate-900">Immutable Compliance Audit Logs</h2>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 font-bold border border-emerald-200">
              Cryptographically Chained
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Tamper-evident system activity ledger for UAE Federal Tax Authority compliance audits
          </p>
        </div>

        <button
          onClick={handleExportLogs}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-semibold text-white shadow-xs transition active:scale-95 cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Audit CSV</span>
        </button>
      </div>

      {/* Filter & Search Bar */}
      <div className="p-3.5 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex flex-col md:flex-row gap-3 items-stretch md:items-center justify-between">
        <div className="relative flex-1">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search audit actions, user name, entity, or details..."
            className="w-full rounded-xl bg-slate-50 border border-slate-200 pl-9 pr-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-emerald-500"
          />
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
        </div>

        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="rounded-xl bg-slate-50 border border-slate-200 px-3 py-2 text-xs text-slate-700 font-medium focus:outline-hidden focus:border-emerald-500 cursor-pointer"
        >
          <option value="all">All Audit Categories</option>
          <option value="TRANSACTION">Transactions & Invoices</option>
          <option value="FILING">Filing & Return Sign-off</option>
          <option value="VAULT_ENCRYPTION">Vault Encryption & Ciphers</option>
          <option value="SYNC">Cross-Platform Sync</option>
          <option value="EXPORT">Auditor Exports & Links</option>
          <option value="PERMISSION">Permissions & Roles</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className="rounded-2xl bg-white border border-slate-200/80 shadow-xs overflow-hidden">
        {filteredLogs.length === 0 ? (
          <div className="py-16 text-center text-slate-400 space-y-2">
            <FileText className="w-8 h-8 mx-auto text-slate-300" />
            <p className="text-sm font-semibold text-slate-600">No audit records match the filter</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 bg-slate-50/50 text-slate-500 font-semibold">
                  <th className="py-3 px-4">Timestamp (UTC)</th>
                  <th className="py-3 px-4">User & Role</th>
                  <th className="py-3 px-4">Action & Category</th>
                  <th className="py-3 px-4">Audit Details</th>
                  <th className="py-3 px-4">Origin Device / IP</th>
                  <th className="py-3 px-4 text-right">Hash Signature</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-50/70 transition">
                    <td className="py-3 px-4 whitespace-nowrap font-mono text-slate-600 text-[11px]">
                      {new Date(log.timestamp).toLocaleString([], {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit'
                      })}
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-semibold text-slate-900 block">{log.user_name}</span>
                      <span className="text-[10px] text-slate-400 font-medium">{log.user_role}</span>
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <span className="font-mono font-bold text-slate-800 text-[11px] block">{log.action}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-semibold inline-block mt-0.5">
                        {log.category}
                      </span>
                    </td>

                    <td className="py-3 px-4 max-w-[280px]">
                      <p className="text-slate-700 text-[11px] leading-relaxed line-clamp-2" title={log.details}>
                        {log.details}
                      </p>
                      {log.entity_id && log.entity_id !== 'ALL' && (
                        <span className="text-[10px] text-emerald-600 font-mono font-semibold">
                          Client: {log.entity_id}
                        </span>
                      )}
                    </td>

                    <td className="py-3 px-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5 text-slate-700">
                        {getDeviceIcon(log.device)}
                        <span className="text-[11px]">{log.device}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 font-mono block mt-0.5">{log.client_ip}</span>
                    </td>

                    <td className="py-3 px-4 text-right whitespace-nowrap font-mono text-[10px] text-slate-400">
                      <span title={log.hash}>
                        {log.hash.slice(0, 10)}...{log.hash.slice(-6)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
