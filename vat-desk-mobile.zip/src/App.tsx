import React, { useState, useEffect } from 'react';
import { 
  Entity, 
  VatRow, 
  EncryptedDocument, 
  AuditLog, 
  NotificationItem, 
  RolePermissions, 
  VatCalculationResult 
} from './types';
import { calculateEntityTax } from './services/taxEngine';
import { syncEngine } from './services/syncEngine';
import { encryptAndSealDocument } from './services/documentVault';
import { useOnlineStatus } from './hooks/useOnlineStatus';
import { PWAInstallBanner } from './components/PWAInstallBanner';
import { OfflineIndicator } from './components/OfflineIndicator';
import { ReceiptScannerModal } from './components/ReceiptScannerModal';
import { CollaborativeExportModal } from './components/CollaborativeExportModal';
import { UserPermissionsModal } from './components/UserPermissionsModal';
import { NotificationCenterModal } from './components/NotificationCenterModal';
import { CrossPlatformSyncModal } from './components/CrossPlatformSyncModal';
import { ArchitecturalAdvisorModal } from './components/ArchitecturalAdvisorModal';

import { 
  INITIAL_ENTITIES, 
  INITIAL_VAT_ROWS, 
  INITIAL_DOCUMENTS, 
  INITIAL_AUDIT_LOGS, 
  INITIAL_NOTIFICATIONS 
} from './data/initialData';

import { DashboardView } from './views/DashboardView';
import { InvoicesView } from './views/InvoicesView';
import { VAT201View } from './views/VAT201View';
import { EncryptedVaultView } from './views/EncryptedVaultView';
import { AuditLogsView } from './views/AuditLogsView';

import { 
  LayoutDashboard, 
  Receipt, 
  FileSpreadsheet, 
  ShieldCheck, 
  History, 
  Camera, 
  Bell, 
  RefreshCw, 
  Smartphone, 
  Monitor, 
  Shield, 
  Lightbulb, 
  Share2, 
  CheckCircle, 
  Wifi, 
  WifiOff,
  User,
  Menu,
  X
} from 'lucide-react';

export default function App() {
  const isOnline = useOnlineStatus();
  
  // App state with safe synchronous seed defaults
  const [entities, setEntities] = useState<Entity[]>(INITIAL_ENTITIES);
  const [vatRows, setVatRows] = useState<VatRow[]>(INITIAL_VAT_ROWS);
  const [documents, setDocuments] = useState<EncryptedDocument[]>(INITIAL_DOCUMENTS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);
  const [selectedEntityId, setSelectedEntityId] = useState<string>('E01');
  const [activeTab, setActiveTab] = useState<'dashboard' | 'invoices' | 'vat201' | 'vault' | 'audit'>('dashboard');

  // Viewport mode: mobile native frame vs full responsive desktop
  const [isMobileFrameMode, setIsMobileFrameMode] = useState<boolean>(false);

  // Sync state
  const [syncStatus, setSyncStatus] = useState<'synced' | 'syncing' | 'offline' | 'error'>('synced');
  const [queuedCount, setQueuedCount] = useState<number>(0);

  // Role & Permissions
  const [currentRole, setCurrentRole] = useState<'admin' | 'preparer' | 'reviewer' | 'client'>('admin');
  const [permissions, setPermissions] = useState<Record<string, RolePermissions>>({
    admin: {
      can_manage_users: true,
      can_edit_tax_rules: true,
      can_approve_filing: true,
      can_delete_records: true,
      can_view_audit_logs: true,
      can_export_faf: true,
      can_upload_documents: true,
      can_override_categories: true,
    },
    preparer: {
      can_manage_users: false,
      can_edit_tax_rules: false,
      can_approve_filing: false,
      can_delete_records: false,
      can_view_audit_logs: true,
      can_export_faf: true,
      can_upload_documents: true,
      can_override_categories: true,
    },
    reviewer: {
      can_manage_users: false,
      can_edit_tax_rules: false,
      can_approve_filing: true,
      can_delete_records: false,
      can_view_audit_logs: true,
      can_export_faf: true,
      can_upload_documents: false,
      can_override_categories: true,
    },
    client: {
      can_manage_users: false,
      can_edit_tax_rules: false,
      can_approve_filing: false,
      can_delete_records: false,
      can_view_audit_logs: false,
      can_export_faf: false,
      can_upload_documents: true,
      can_override_categories: false,
    }
  });

  // Modals
  const [showScannerModal, setShowScannerModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showPermissionsModal, setShowPermissionsModal] = useState(false);
  const [showNotificationModal, setShowNotificationModal] = useState(false);
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [showAdvisorModal, setShowAdvisorModal] = useState(false);

  // Initial Data Fetch & Sync
  useEffect(() => {
    // 1. Try local cache first for instant offline startup
    const cachedEntities = syncEngine.getCachedData<Entity>('entities');
    const cachedRows = syncEngine.getCachedData<VatRow>('vat_rows');
    const cachedDocs = syncEngine.getCachedData<EncryptedDocument>('documents');
    const cachedAudit = syncEngine.getCachedData<AuditLog>('audit_logs');
    const cachedNotifs = syncEngine.getCachedData<NotificationItem>('notifications');

    if (cachedEntities && cachedEntities.length > 0) setEntities(cachedEntities);
    if (cachedRows && cachedRows.length > 0) setVatRows(cachedRows);
    if (cachedDocs && cachedDocs.length > 0) setDocuments(cachedDocs);
    if (cachedAudit && cachedAudit.length > 0) setAuditLogs(cachedAudit);
    if (cachedNotifs && cachedNotifs.length > 0) setNotifications(cachedNotifs);

    // 2. Subscribe to sync engine
    const unsubscribe = syncEngine.subscribe((status, queueLength) => {
      setSyncStatus(status);
      setQueuedCount(queueLength);
    });

    // 3. Trigger initial sync with backend
    syncEngine.sync().then(() => {
      // Re-read updated state
      fetchLatestData();
    });

    return () => unsubscribe();
  }, []);

  const fetchLatestData = async () => {
    try {
      const [entRes, rowRes, docRes, auditRes, notifRes, permRes] = await Promise.all([
        fetch('/api/entities'),
        fetch('/api/vat-rows'),
        fetch('/api/documents'),
        fetch('/api/audit-logs'),
        fetch('/api/notifications'),
        fetch('/api/permissions'),
      ]);

      if (entRes.ok) setEntities(await entRes.json());
      if (rowRes.ok) setVatRows(await rowRes.json());
      if (docRes.ok) setDocuments(await docRes.json());
      if (auditRes.ok) setAuditLogs(await auditRes.json());
      if (notifRes.ok) setNotifications(await notifRes.json());
      if (permRes.ok) setPermissions(await permRes.json());
    } catch (err) {
      console.warn('Backend unavailable, using cached state:', err);
    }
  };

  // Run real-time UAE VAT calculation engine for all entities
  const calculations: VatCalculationResult[] = entities.map(e => calculateEntityTax(e, vatRows));
  const currentCalc = calculations.find(c => c.id === selectedEntityId) || calculations[0] || {
    id: 'E01',
    name: 'Al Noor Trading LLC',
    location: 'Mainland',
    vat_status: 'On track',
    vat_flag: 'green',
    registered: 'Yes',
    taxable_supplies: 0,
    dz_goods: 0,
    output_vat: 0,
    total_due: 0,
    recoverable_vat: 0,
    recovery_pct: 1,
    net_vat: 0,
    period_end: '2026-09-30',
    due: '2026-10-28',
    days_to_due: 0,
    late_days: 0,
    vat_penalty: 0,
    vat_overdue_tax: 0,
    open_exceptions: 0,
    recon_status: 'Not provided',
    recon_sales_diff: null,
    recon_output_diff: null,
    recon_input_diff: null,
    vat_schedules_required: 8,
    risk_score: 10,
    rag: 'Green'
  };

  const currentEntity = entities.find(e => e.id === selectedEntityId) || entities[0] || {
    id: 'E01',
    name: 'Al Noor Trading LLC',
    location: 'Mainland',
    vat_trn: '100234567800003',
    vat_registered: 'Yes',
    vat_frequency: 'Quarterly',
    vat_period_end: '2026-09-30',
    vat_filed: 'No',
    vat_paid: 'No',
    std_supplies: 0,
    zero_supplies: 0,
    exempt_supplies: 0,
    dz_goods_supplies: 0,
    taxable_supplies_12m: 0,
    input_vat: 0,
    blocked_input_vat: 0,
    reverse_charge_vat: 0,
    vat_open_exceptions: 0,
    tourist_refund_vat: 0,
    import_goods_value: 0,
    import_vat: 0,
    import_adjust_vat: 0,
    sales_cn_net: 0,
    sales_cn_vat: 0,
    purchase_cn_net: 0,
    purchase_cn_vat: 0,
    bad_debt_vat: 0,
    deemed_supplies_vat: 0,
    change_in_use_vat: 0,
    capital_assets_vat: 0,
    prior_period_error_vat: 0,
    margin_scheme: 'No',
    gl_sales_revenue: 0,
    gl_output_vat: 0,
    gl_input_vat: 0,
  };

  // Add / Save transaction from scanner or form
  const handleSaveTransaction = async (rowPayload: Partial<VatRow>, docFile?: File) => {
    let receiptId = '';

    // If receipt file was attached, encrypt it client-side first
    if (docFile) {
      const encryptedDoc = await encryptAndSealDocument(
        docFile,
        rowPayload.entity_id || selectedEntityId,
        rowPayload.doc_no || 'DOC',
        `User (${currentRole})`
      );
      receiptId = encryptedDoc.id;
      setDocuments(prev => [encryptedDoc, ...prev]);

      // Push document to sync engine
      syncEngine.queueMutation('INSERT_DOC', encryptedDoc);
    }

    const newRow: VatRow = {
      id: `VR-${Date.now().toString().slice(-4)}`,
      entity_id: rowPayload.entity_id || selectedEntityId,
      period_end: rowPayload.period_end || currentEntity.vat_period_end,
      doc_date: rowPayload.doc_date || new Date().toISOString().split('T')[0],
      doc_no: rowPayload.doc_no || `INV-${Date.now().toString().slice(-4)}`,
      party: rowPayload.party || 'Supplier',
      party_trn: rowPayload.party_trn || '',
      emirate: rowPayload.emirate || 'Dubai',
      doc_type: rowPayload.doc_type || 'Purchase - standard rated',
      net: Number(rowPayload.net) || 0,
      vat: Number(rowPayload.vat) || 0,
      category: rowPayload.category || 'General',
      description: rowPayload.description || '',
      receipt_id: receiptId || undefined,
      is_verified: rowPayload.is_verified ?? true
    };

    setVatRows(prev => [newRow, ...prev]);

    // Push row to sync engine
    syncEngine.queueMutation('INSERT_ROW', newRow);

    // Refresh audit logs
    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      entity_id: newRow.entity_id,
      user_name: `Active User (${currentRole})`,
      user_role: currentRole,
      action: 'TRANSACTION_RECORDED',
      category: 'TRANSACTION',
      details: `Added ${newRow.doc_type} #${newRow.doc_no} (${newRow.party}) Net AED ${newRow.net.toLocaleString()}`,
      client_ip: '194.170.24.12',
      device: isMobileFrameMode ? 'Mobile PWA' : 'Desktop Browser',
      hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const handleDeleteRow = (id: string) => {
    setVatRows(prev => prev.filter(r => r.id !== id));
    syncEngine.queueMutation('DELETE_ROW', { id });
  };

  const handleSignOffReturn = () => {
    setEntities(prev => prev.map(e => e.id === selectedEntityId ? { ...e, vat_filed: 'Yes' } : e));
    syncEngine.queueMutation('UPDATE_ENTITY', { id: selectedEntityId, vat_filed: 'Yes' });

    const newLog: AuditLog = {
      id: `LOG-${Date.now()}`,
      timestamp: new Date().toISOString(),
      entity_id: selectedEntityId,
      user_name: `Active User (${currentRole})`,
      user_role: currentRole,
      action: 'RETURN_SIGNED_OFF',
      category: 'FILING',
      details: `Locked and certified Form VAT 201 for period ending ${currentEntity.vat_period_end}. Net VAT AED ${currentCalc.net_vat.toLocaleString()}.`,
      client_ip: '194.170.24.12',
      device: isMobileFrameMode ? 'Mobile PWA' : 'Desktop Browser',
      hash: Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15)
    };
    setAuditLogs(prev => [newLog, ...prev]);
  };

  const unreadNotifCount = notifications.filter(n => !n.is_read).length;

  // View selector router
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            entities={entities}
            selectedEntityId={selectedEntityId}
            calculations={calculations}
            vatRows={vatRows}
            notifications={notifications}
            onSelectEntity={setSelectedEntityId}
            onOpenScanner={() => setShowScannerModal(true)}
            onOpenExport={() => setShowExportModal(true)}
            onNavigateTab={setActiveTab}
          />
        );
      case 'invoices':
        return (
          <InvoicesView
            entity={currentEntity}
            rows={vatRows}
            onOpenScanner={() => setShowScannerModal(true)}
            onDeleteRow={handleDeleteRow}
            onOpenVaultDoc={(docId) => {
              setActiveTab('vault');
            }}
          />
        );
      case 'vat201':
        return (
          <VAT201View
            entity={currentEntity}
            rows={vatRows}
            calcResult={currentCalc}
            onOpenExport={() => setShowExportModal(true)}
            onSignOffReturn={handleSignOffReturn}
          />
        );
      case 'vault':
        return (
          <EncryptedVaultView
            entity={currentEntity}
            documents={documents}
            onOpenScanner={() => setShowScannerModal(true)}
          />
        );
      case 'audit':
        return (
          <AuditLogsView logs={auditLogs} />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-slate-100/90 text-slate-900 flex flex-col antialiased">
      {/* 1. Mandatory PWA Install Banner */}
      <PWAInstallBanner />

      {/* 2. Top Header Navigation Bar */}
      <header className="sticky top-0 z-30 bg-slate-900 text-white border-b border-slate-800 shadow-md">
        <div className="max-w-7xl mx-auto px-3 sm:px-6 h-14 flex items-center justify-between gap-3">
          {/* Logo & Platform Name */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center font-extrabold text-white shadow-xs">
              V
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-extrabold tracking-tight text-white">VAT-DESK</h1>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono font-bold">
                  MOBILE SUITE
                </span>
              </div>
              <p className="text-[10px] text-slate-400 hidden sm:block">UAE VAT Real-Time Filing & Encrypted Audit Vault</p>
            </div>
          </div>

          {/* Center Navigation Tabs (Desktop & Tablet) */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-950/60 p-1 rounded-xl border border-slate-800">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
              { id: 'invoices', label: 'Invoices & Expenses', icon: Receipt },
              { id: 'vat201', label: 'Form VAT 201', icon: FileSpreadsheet },
              { id: 'vault', label: 'Encrypted Vault', icon: ShieldCheck },
              { id: 'audit', label: 'Audit Trail', icon: History },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Right Action Controls: Sync status, Notifications, Roles, Advisor, View Mode */}
          <div className="flex items-center gap-2">
            {/* Sync Indicator Button */}
            <button
              onClick={() => setShowSyncModal(true)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition cursor-pointer ${
                !isOnline
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-300'
                  : syncStatus === 'syncing'
                  ? 'bg-blue-500/10 border-blue-500/30 text-blue-300'
                  : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
              }`}
              title="Click for Cross-Platform Sync & Device Pairing"
            >
              {!isOnline ? (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                  <span className="hidden sm:inline">Offline ({queuedCount})</span>
                </>
              ) : (
                <>
                  <RefreshCw className={`w-3.5 h-3.5 ${syncStatus === 'syncing' ? 'animate-spin text-blue-400' : 'text-emerald-400'}`} />
                  <span className="hidden sm:inline">Synced</span>
                </>
              )}
            </button>

            {/* Notification Bell */}
            <button
              onClick={() => setShowNotificationModal(true)}
              className="relative p-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 transition cursor-pointer"
              aria-label="Compliance notifications"
            >
              <Bell className="w-4 h-4" />
              {unreadNotifCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {unreadNotifCount}
                </span>
              )}
            </button>

            {/* Role Permissions Button */}
            <button
              onClick={() => setShowPermissionsModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-slate-200 transition cursor-pointer"
              title="Change user role & customize permissions"
            >
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline capitalize">{currentRole}</span>
            </button>

            {/* Architectural Recommendations Advisor Button */}
            <button
              onClick={() => setShowAdvisorModal(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 text-xs font-semibold transition cursor-pointer"
              title="iOS & Android Architecture Guidance"
            >
              <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden lg:inline">Architecture</span>
            </button>

            {/* Mobile Device Frame vs Full Responsive Toggle */}
            <button
              onClick={() => setIsMobileFrameMode(!isMobileFrameMode)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-semibold transition cursor-pointer ${
                isMobileFrameMode
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title="Toggle iPhone / Android Native App Preview frame"
            >
              <Smartphone className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{isMobileFrameMode ? 'Mobile Frame' : 'Full Screen'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* 3. Main App Container: Either Native Mobile Frame or Full Responsive Container */}
      <main className="flex-1 flex flex-col">
        {isMobileFrameMode ? (
          /* Mobile Device Frame Simulation Container */
          <div className="flex-1 flex items-center justify-center p-3 sm:p-6 bg-slate-800/40">
            <div className="w-full max-w-[420px] h-[840px] max-h-[92vh] bg-slate-900 rounded-[44px] p-3 shadow-2xl border-[6px] border-slate-700 flex flex-col relative overflow-hidden">
              {/* iPhone Notch / Dynamic Island */}
              <div className="w-28 h-5 bg-black rounded-full mx-auto mb-2 shrink-0 flex items-center justify-center">
                <div className="w-2.5 h-2.5 rounded-full bg-slate-800" />
              </div>

              {/* Status bar */}
              <div className="px-4 py-1 flex items-center justify-between text-[11px] font-semibold text-slate-400 shrink-0 select-none">
                <span>9:41</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px]">5G</span>
                  <Wifi className="w-3 h-3" />
                  <div className="w-4 h-2 rounded-xs border border-slate-400 flex items-center p-0.5">
                    <div className="h-full w-full bg-slate-400 rounded-xs" />
                  </div>
                </div>
              </div>

              {/* Screen Inner Viewport (Scrollable) */}
              <div className="flex-1 overflow-y-auto bg-slate-100 rounded-3xl p-3 text-slate-900 relative">
                {renderActiveView()}
              </div>

              {/* Mobile Native Bottom Navigation Bar */}
              <div className="pt-2 px-3 pb-1 shrink-0 flex items-center justify-around text-slate-400 text-[10px]">
                <button
                  onClick={() => setActiveTab('dashboard')}
                  className={`flex flex-col items-center gap-0.5 p-1 transition cursor-pointer ${
                    activeTab === 'dashboard' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
                  }`}
                >
                  <LayoutDashboard className="w-4 h-4" />
                  <span>Home</span>
                </button>

                <button
                  onClick={() => setActiveTab('invoices')}
                  className={`flex flex-col items-center gap-0.5 p-1 transition cursor-pointer ${
                    activeTab === 'invoices' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
                  }`}
                >
                  <Receipt className="w-4 h-4" />
                  <span>Invoices</span>
                </button>

                {/* Center Floating Action Button (Camera Scan) */}
                <button
                  onClick={() => setShowScannerModal(true)}
                  className="w-10 h-10 -mt-3 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-lg transition active:scale-95 cursor-pointer"
                  title="Scan Receipt"
                >
                  <Camera className="w-5 h-5" />
                </button>

                <button
                  onClick={() => setActiveTab('vat201')}
                  className={`flex flex-col items-center gap-0.5 p-1 transition cursor-pointer ${
                    activeTab === 'vat201' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
                  }`}
                >
                  <FileSpreadsheet className="w-4 h-4" />
                  <span>VAT 201</span>
                </button>

                <button
                  onClick={() => setActiveTab('vault')}
                  className={`flex flex-col items-center gap-0.5 p-1 transition cursor-pointer ${
                    activeTab === 'vault' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
                  }`}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Vault</span>
                </button>
              </div>

              {/* iPhone Home Indicator bar */}
              <div className="w-28 h-1 bg-slate-600 rounded-full mx-auto mt-1 shrink-0" />
            </div>
          </div>
        ) : (
          /* Full Responsive Suite Container (For desktop/tablet or browser view) */
          <div className="flex-1 max-w-7xl mx-auto w-full px-3 sm:px-6 py-5">
            {renderActiveView()}
          </div>
        )}
      </main>

      {/* 4. Mobile Bottom Tab Bar (Only visible on small screens when not in Mobile Frame mode) */}
      {!isMobileFrameMode && (
        <div className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-slate-400 text-[10px]">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center gap-1 transition cursor-pointer ${
              activeTab === 'dashboard' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            <LayoutDashboard className="w-4 h-4" />
            <span>Home</span>
          </button>

          <button
            onClick={() => setActiveTab('invoices')}
            className={`flex flex-col items-center gap-1 transition cursor-pointer ${
              activeTab === 'invoices' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            <Receipt className="w-4 h-4" />
            <span>Invoices</span>
          </button>

          <button
            onClick={() => setShowScannerModal(true)}
            className="w-11 h-11 -mt-4 rounded-full bg-emerald-500 hover:bg-emerald-400 text-white flex items-center justify-center shadow-xl transition active:scale-95 cursor-pointer"
            title="Scan Receipt"
          >
            <Camera className="w-5 h-5" />
          </button>

          <button
            onClick={() => setActiveTab('vat201')}
            className={`flex flex-col items-center gap-1 transition cursor-pointer ${
              activeTab === 'vat201' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>VAT 201</span>
          </button>

          <button
            onClick={() => setActiveTab('vault')}
            className={`flex flex-col items-center gap-1 transition cursor-pointer ${
              activeTab === 'vault' ? 'text-emerald-400 font-bold' : 'hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Vault</span>
          </button>
        </div>
      )}

      {/* 5. Non-intrusive Offline & Sync Queue Floating Pill */}
      <OfflineIndicator
        isOnline={isOnline}
        queuedCount={queuedCount}
        onSyncNow={() => syncEngine.sync()}
      />

      {/* Modals */}
      {showScannerModal && (
        <ReceiptScannerModal
          entities={entities}
          selectedEntityId={selectedEntityId}
          onClose={() => setShowScannerModal(false)}
          onSaveTransaction={handleSaveTransaction}
        />
      )}

      {showExportModal && (
        <CollaborativeExportModal
          entity={currentEntity}
          rows={vatRows}
          calcResult={currentCalc}
          onClose={() => setShowExportModal(false)}
        />
      )}

      {showPermissionsModal && (
        <UserPermissionsModal
          currentRole={currentRole}
          permissions={permissions}
          onSelectRole={setCurrentRole}
          onUpdatePermissions={setPermissions}
          onClose={() => setShowPermissionsModal(false)}
        />
      )}

      {showNotificationModal && (
        <NotificationCenterModal
          notifications={notifications}
          onMarkRead={(id) => {
            setNotifications(prev => prev.map(n => n.id === id ? { ...n, is_read: true } : n));
            fetch(`/api/notifications/${id}/read`, { method: 'POST' }).catch(() => {});
          }}
          onSelectAction={(link) => {
            if (link.includes('returns')) setActiveTab('vat201');
            if (link.includes('clients') || link.includes('invoices')) setActiveTab('invoices');
            if (link.includes('vault')) setActiveTab('vault');
          }}
          onClose={() => setShowNotificationModal(false)}
        />
      )}

      {showSyncModal && (
        <CrossPlatformSyncModal
          isOnline={isOnline}
          syncStatus={syncStatus}
          queuedCount={queuedCount}
          onSyncNow={async () => {
            await syncEngine.sync();
          }}
          onClose={() => setShowSyncModal(false)}
        />
      )}

      {showAdvisorModal && (
        <ArchitecturalAdvisorModal
          onClose={() => setShowAdvisorModal(false)}
        />
      )}
    </div>
  );
}
