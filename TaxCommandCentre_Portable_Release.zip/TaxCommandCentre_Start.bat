@echo off
cd /d "%~dp0"
title Launching TAX COMMAND CENTRE
if exist "%~dp0TaxCommandCentre.exe" (
    start "" "%~dp0TaxCommandCentre.exe"
) else if exist "%~dp0dist\server.cjs" (
    start http://localhost:3000
    node "%~dp0dist\server.cjs"
)
exit
