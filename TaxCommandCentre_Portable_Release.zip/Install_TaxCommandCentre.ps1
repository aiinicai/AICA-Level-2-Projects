# TAX COMMAND CENTRE - PowerShell Automated Installer & Desktop Shortcut Setup
Write-Host "====================================================================" -ForegroundColor Cyan
Write-Host "   TAX COMMAND CENTRE - Corporate Direct Tax Management System" -ForegroundColor Yellow
Write-Host "   Automated Windows Desktop Setup & Environment Registration" -ForegroundColor White
Write-Host "====================================================================" -ForegroundColor Cyan

$CurrentDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExePath = Join-Path $CurrentDir "TaxCommandCentre.exe"
$DesktopPath = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::Desktop)
$ShortcutPath = Join-Path $DesktopPath "Tax Command Centre.lnk"

if (-not (Test-Path $ExePath)) {
    Write-Host "[ERROR] TaxCommandCentre.exe not found at $ExePath" -ForegroundColor Red
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "`n[1/3] Validating portable standalone executable..." -ForegroundColor Green
Write-Host "      Executable location: $ExePath" -ForegroundColor Gray

Write-Host "`n[2/3] Creating Windows Desktop Shortcut..." -ForegroundColor Green
try {
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut($ShortcutPath)
    $Shortcut.TargetPath = $ExePath
    $Shortcut.WorkingDirectory = $CurrentDir
    $Shortcut.Description = "TAX COMMAND CENTRE - AI-Powered Corporate Direct Tax Management System"
    $Shortcut.IconLocation = "$ExePath,0"
    $Shortcut.Save()
    Write-Host "      [SUCCESS] Desktop shortcut created: $ShortcutPath" -ForegroundColor Yellow
} catch {
    Write-Host "      [WARNING] Could not create shortcut: $_" -ForegroundColor DarkYellow
}

Write-Host "`n[3/3] Launching Tax Command Centre..." -ForegroundColor Green
Start-Process -FilePath $ExePath -WorkingDirectory $CurrentDir

Write-Host "`n====================================================================" -ForegroundColor Cyan
Write-Host "   Setup Completed! Server running at http://localhost:3000" -ForegroundColor Green
Write-Host "====================================================================" -ForegroundColor Cyan
Start-Sleep -Seconds 3
