@echo off
setlocal EnableDelayedExpansion
title TAX COMMAND CENTRE - Automated Setup & Launcher
color 1F

:: Ensure current working directory is the script folder
cd /d "%~dp0"
set "INSTALL_DIR=%~dp0"
set "EXE_PATH=%INSTALL_DIR%TaxCommandCentre.exe"
set "DESKTOP=%USERPROFILE%\Desktop"
set "SHORTCUT_PATH=%DESKTOP%\Tax Command Centre.lnk"

echo ====================================================================
echo   TAX COMMAND CENTRE - Corporate Direct Tax Management System
echo   Standalone Windows Setup & Environment Launcher
echo ====================================================================
echo.
echo  Install Directory : %INSTALL_DIR%
echo  Target Executable : %EXE_PATH%
echo  Desktop Target    : %SHORTCUT_PATH%
echo.

echo [1/3] Checking application binaries...
if not exist "%EXE_PATH%" (
    echo [WARNING] TaxCommandCentre.exe not found in current folder.
    echo Attempting to launch via Node.js server fallback...
    if exist "%INSTALL_DIR%dist\server.cjs" (
        echo [OK] Found dist\server.cjs. Launching application...
        start http://localhost:3000
        node "%INSTALL_DIR%dist\server.cjs"
        pause
        exit /b 0
    ) else (
        echo [ERROR] Required files not found. Please run setup from the tax-command-centre folder.
        pause
        exit /b 1
    )
)
echo       [OK] Executable binary verified.

echo.
echo [2/3] Creating Windows Desktop Shortcut...
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ws = New-Object -ComObject WScript.Shell; $s = $ws.CreateShortcut('%SHORTCUT_PATH%'); $s.TargetPath = '%EXE_PATH%'; $s.WorkingDirectory = '%INSTALL_DIR%'; $s.Description = 'TAX COMMAND CENTRE - Corporate Direct Tax Management System'; $s.Save()"

if exist "%SHORTCUT_PATH%" (
    echo       [SUCCESS] Desktop Shortcut created successfully at:
    echo       "%SHORTCUT_PATH%"
) else (
    echo       [NOTE] Could not write to Desktop. You can run TaxCommandCentre.exe directly from this folder.
)

echo.
echo [3/3] Starting TAX COMMAND CENTRE...
echo       Initializing server and opening default web browser...
echo.
echo ====================================================================
echo   The application is running at http://localhost:3000
echo   Keep this window open or minimize it.
echo   Press Ctrl+C to stop the server when done.
echo ====================================================================
echo.

"%EXE_PATH%"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [NOTE] Standalone exe exited with code %ERRORLEVEL%.
    echo Launching Node.js fallback server...
    if exist "%INSTALL_DIR%dist\server.cjs" (
        node "%INSTALL_DIR%dist\server.cjs"
    )
)

pause
