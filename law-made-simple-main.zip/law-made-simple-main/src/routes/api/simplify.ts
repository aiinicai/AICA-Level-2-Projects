import { createFileRoute } from "@tanstack/react-router";

const schema = {
  type: "object",
  additionalProperties: false,
  required: ["title", "court", "date", "oneLine", "summary", "parties", "keyFacts", "question", "verdict", "reasons", "whatItMeans", "glossary"],
  properties: {
    title: { type: "string" },
    court: { type: "string" },
    date: { type: "string" },
    oneLine: { type: "string" },
    summary: { type: "string" },
    parties: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["name", "role", "plain"],
        properties: { name: { type: "string" }, role: { type: "string" }, plain: { type: "string" } },
      },
    },
    keyFacts: { type: "array", items: { type: "string" } },
    question: { type: "string" },
    verdict: { type: "string" },
    reasons: { type: "array", items: { type: "string" } },
    whatItMeans: { type: "string" },
    glossary: {
      type: "array",
      items: {
        type: "object",
        additionalProperties: false,
        required: ["term", "meaning"],
        properties: { term: { type: "string" }, meaning: { type: "string" } },
      },
    },
  },
};

const PROMPT = `You explain Indian court/tribunal judgments to ordinary people with no legal training.
Read the attached judgment and fill every field in plain, friendly English (aim for a 12-year-old's reading level). Avoid jargon; if a legal term is unavoidable, add it to the glossary.
- title: short human title, e.g. "Builder vs Tax Department"
- court, date: as stated (empty string if unknown)
- oneLine: the whole case in one sentence
- summary: 1-2 short paragraphs telling the story of what happened
- parties: each side, their legal role, and who they are in plain words
- keyFacts: 4-8 timeline-style facts
- question: the main question the court had to answer
- verdict: what the court decided, in plain words
- reasons: 3-6 simple reasons why
- whatItMeans: practical takeaway for an ordinary person
- glossary: 5-10 legal terms/sections from the case explained simply`;

export const Route = createFileRoute("/api/simplify")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const key = process.env["LOVABLE_API_KEY"];
        if (!key) return Response.json({ error: "AI is not configured." }, { status: 500 });
        const form = await request.formData();
        const file = form.get("file");
        if (!(file instanceof File) || file.size === 0) return Response.json({ error: "Please upload a PDF." }, { status: 400 });
        if (file.type !== "application/pdf") return Response.json({ error: "Only PDF files are supported." }, { status: 400 });
        if (file.size > 15 * 1024 * 1024) return Response.json({ error: "PDF must be under 15MB." }, { status: 400 });

        const bytes = new Uint8Array(await file.arrayBuffer());
        let bin = "";
        for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
        const b64 = btoa(bin);

        const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
          method: "POST",
          signal: request.signal,
          headers: { "Content-Type": "application/json", "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "fetch" },
          body: JSON.stringify({
            model: "openai/gpt-6-astra",
            stream: true,
            store: false,
            reasoning: { effort: "low" },
            text: { format: { type: "json_schema", name: "case", strict: true, schema } },
            input: [
              {
                role: "user",
                content: [
                  { type: "input_text", text: PROMPT },
                  { type: "input_file", filename: file.name || "case.pdf", file_data: `data:application/pdf;base64,${b64}` },
                ],
              },
            ],
          }),
        });

        if (!res.ok || !res.body) {
          let msg = "The AI could not read this case right now.";
          try { const j = await res.json(); msg = j?.error?.message || j?.message || msg; } catch {}
          if (res.status === 429) msg = "Too many requests — please wait a moment and try again.";
          if (res.status === 402) msg = "AI credits have run out for this workspace.";
          return Response.json({ error: msg }, { status: res.status || 500 });
        }

        const reader = res.body.getReader();
        const dec = new TextDecoder();
        let buf = "", out = "", failed = "";
        for (;;) {
          const { done, value } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          const lines = buf.split("\n");
          buf = lines.pop() ?? "";
          for (const line of lines) {
            if (!line.startsWith("data:")) continue;
            const data = line.slice(5).trim();
            if (!data || data === "[DONE]") continue;
            try {
              const ev = JSON.parse(data);
              if (ev.type === "response.output_text.delta") out += ev.delta;
              if (ev.type === "response.failed" || ev.type === "error") failed = ev.response?.error?.message || ev.message || "AI failed.";
            } catch {}
          }
        }
        if (failed) return Response.json({ error: failed }, { status: 502 });
        try {
          return Response.json({ result: JSON.parse(out) });
        } catch {
          return Response.json({ error: "The AI didn't return a readable explanation. Try another file." }, { status: 502 });
        }
      },
    },
  },
});
