import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Plain Law — Court judgments in simple words" },
      { name: "description", content: "Upload a court judgment PDF and get a plain-English explanation: story, parties, verdict and legal terms." },
      { property: "og:title", content: "Plain Law — Court judgments in simple words" },
      { property: "og:description", content: "Upload any case law PDF and understand it in minutes." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

type CaseResult = {
  title: string; court: string; date: string; oneLine: string; summary: string;
  parties: { name: string; role: string; plain: string }[];
  keyFacts: string[]; question: string; verdict: string; reasons: string[];
  whatItMeans: string; glossary: { term: string; meaning: string }[];
};

function Index() {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<CaseResult | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  async function run() {
    if (!file) return;
    setLoading(true); setError(""); setResult(null);
    try {
      const fd = new FormData(); fd.append("file", file);
      const res = await fetch("/api/simplify", { method: "POST", body: fd });
      const j = await res.json();
      if (!res.ok) throw new Error(j.error || "Something went wrong.");
      setResult(j.result);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    } finally { setLoading(false); }
  }

  return (
    <main className="mx-auto max-w-3xl px-5 py-12 md:py-20">
      <header className="mb-10">
        <p className="text-sm font-semibold uppercase tracking-widest text-accent">Plain Law</p>
        <h1 className="mt-3 text-4xl font-semibold leading-tight md:text-6xl">
          Court judgments, <span className="marker">in words you understand.</span>
        </h1>
        <p className="mt-4 text-lg text-muted-foreground">Upload a case law PDF. We'll tell you the story, who's who, what was decided and why.</p>
      </header>

      <section className="rounded-xl border bg-card p-6 shadow-sm">
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); const f = e.dataTransfer.files[0]; if (f) setFile(f); }}
          className="cursor-pointer rounded-lg border-2 border-dashed p-8 text-center transition-colors hover:bg-secondary"
        >
          <input ref={inputRef} type="file" accept="application/pdf" className="hidden"
            onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
          <p className="font-medium">{file ? file.name : "Drop a judgment PDF here, or click to choose"}</p>
          <p className="mt-1 text-sm text-muted-foreground">PDF up to 15MB</p>
        </div>
        <button onClick={run} disabled={!file || loading}
          className="mt-4 w-full rounded-lg bg-primary px-5 py-3 font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40">
          {loading ? "Reading the judgment… (up to a minute)" : "Explain this case"}
        </button>
        {error && <p className="mt-3 text-sm text-destructive">{error}</p>}
      </section>

      {result && <ResultView r={result} />}
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mt-10">
      <h2 className="mb-3 text-2xl font-semibold">{title}</h2>
      {children}
    </section>
  );
}

function ResultView({ r }: { r: CaseResult }) {
  return (
    <article className="mt-14 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <p className="text-sm text-muted-foreground">{[r.court, r.date].filter(Boolean).join(" · ")}</p>
      <h2 className="mt-1 text-3xl font-semibold md:text-4xl">{r.title}</h2>
      <p className="mt-4 rounded-lg bg-highlight/60 p-4 text-lg font-medium">{r.oneLine}</p>

      <Section title="What happened">
        {r.summary.split(/\n+/).map((p, i) => <p key={i} className="mb-3 leading-relaxed">{p}</p>)}
      </Section>

      <Section title="Who's involved">
        <div className="grid gap-3 md:grid-cols-2">
          {r.parties.map((p, i) => (
            <div key={i} className="rounded-lg border bg-card p-4">
              <p className="text-xs font-semibold uppercase tracking-wide text-accent">{p.role}</p>
              <p className="mt-1 font-semibold">{p.name}</p>
              <p className="mt-1 text-sm text-muted-foreground">{p.plain}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Key facts">
        <ol className="space-y-3 border-l-2 border-primary/30 pl-5">
          {r.keyFacts.map((f, i) => <li key={i} className="leading-relaxed">{f}</li>)}
        </ol>
      </Section>

      <Section title="The big question">
        <p className="font-serif text-xl italic">“{r.question}”</p>
      </Section>

      <Section title="The verdict">
        <div className="rounded-xl bg-primary p-6 text-primary-foreground">
          <p className="text-lg leading-relaxed">{r.verdict}</p>
        </div>
        <h3 className="mt-6 mb-2 text-lg font-semibold">Why the court decided this</h3>
        <ul className="list-disc space-y-2 pl-5">{r.reasons.map((x, i) => <li key={i}>{x}</li>)}</ul>
      </Section>

      <Section title="What this means for you">
        <p className="leading-relaxed">{r.whatItMeans}</p>
      </Section>

      <Section title="Legal words, explained">
        <dl className="divide-y rounded-lg border bg-card">
          {r.glossary.map((g, i) => (
            <div key={i} className="p-4">
              <dt className="font-semibold">{g.term}</dt>
              <dd className="mt-1 text-sm text-muted-foreground">{g.meaning}</dd>
            </div>
          ))}
        </dl>
      </Section>
      <p className="mt-10 text-xs text-muted-foreground">This is a simplified explanation, not legal advice.</p>
    </article>
  );
}
