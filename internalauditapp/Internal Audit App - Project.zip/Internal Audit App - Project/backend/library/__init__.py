"""Internal audit procedure library.

Aggregates the Risk & Control Matrices (RACM) for common business processes and
industry-specific processes. Each module exposes a PROCESSES list; see
common_a.py for the schema.
"""
import importlib

INDUSTRIES = [
    "Home Retail",
    "E-commerce",
    "Building Material Trading",
    "Real Estate Developer",
]

_MODULES = ["common_a", "common_b", "home_retail", "ecommerce",
            "building_materials", "real_estate"]

PROCESSES = []
LOAD_ERRORS = []

for _name in _MODULES:
    try:
        _mod = importlib.import_module(f"{__name__}.{_name}")
        PROCESSES.extend(getattr(_mod, "PROCESSES", []))
    except Exception as exc:  # keep the app running if one library file is broken
        LOAD_ERRORS.append(f"{_name}: {exc}")

_BY_CODE = {p["code"]: p for p in PROCESSES}


def get_process(code):
    return _BY_CODE.get(code)


def processes_for_industries(industries):
    """Common processes plus those of the selected industries."""
    wanted = set(industries or []) | {"Common"}
    return [p for p in PROCESSES if p.get("industry") in wanted]


def summary():
    return [{
        "code": p["code"],
        "name": p["name"],
        "industry": p["industry"],
        "description": p.get("description", ""),
        "items": len(p.get("items", [])),
        "key_controls": sum(1 for i in p.get("items", []) if i.get("key_control")),
        "default_risk": p.get("default_risk", {"impact": 3, "likelihood": 3}),
    } for p in PROCESSES]
