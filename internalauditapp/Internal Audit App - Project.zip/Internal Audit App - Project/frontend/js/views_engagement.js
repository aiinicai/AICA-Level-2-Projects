/* Engagement workspace: overview, work program (RACM + workpapers), PBC, findings, review notes, time, documents, report. */
'use strict';

const ENG_TABS = [
  ['overview', 'Overview'], ['workprogram', 'Work Program (RACM)'], ['pbc', 'PBC Requests'], ['findings', 'Findings'],
  ['notes', 'Review Notes'], ['time', 'Time'], ['documents', 'Documents'], ['report', 'Report'],
];

async function viewEngagement(el, args) {
  const id = args[0], tab = args[1] || 'overview';
  await ensureLibrary();
  const d = await API.get(`/engagements/${id}/full`);
  const e = d.engagement;
  const counts = {
    workprogram: d.procedures.length, pbc: d.pbc.length, findings: d.findings.length,
    notes: d.review_notes.filter(n => n.status === 'Open').length, time: d.time_entries.length, documents: d.attachments.length,
  };
  el.innerHTML = `<div class="page-head"><div class="titles"><div class="small muted"><a href="#/engagements">Engagements</a> / ${esc(e.ref)}</div>
      <h1>${esc(e.title)}</h1><p>${esc(e.audit_type)} &middot; ${esc(e.entity_name || State.company.name)} &middot; Period ${fmtDate(e.period_from)} - ${fmtDate(e.period_to)}</p></div>
    <div class="actions">${badge(e.status)} ${e.overall_rating ? badge(e.overall_rating) : ''}
      <select id="st" style="width:auto">${enums('engagement_statuses').map(s => `<option ${s === e.status ? 'selected' : ''}>${s}</option>`).join('')}</select>
      <button class="btn" id="edit">Edit</button><button class="btn danger" id="del">Delete</button></div></div>
    <div class="tabs">${ENG_TABS.map(([k, l]) => `<a href="#/engagement/${id}/${k}" class="${k === tab ? 'active' : ''}">${l}${counts[k] ? `<span class="count">${counts[k]}</span>` : ''}</a>`).join('')}</div>
    <div id="tab"></div>`;
  $('#st', el).onchange = async ev => {
    const upd = { status: ev.target.value };
    if (ev.target.value === 'Fieldwork' && !e.actual_start) upd.actual_start = today();
    if (ev.target.value === 'Closed' && !e.actual_end) upd.actual_end = today();
    await guard(() => API.put('/engagements/' + id, upd), 'Status updated'); render();
  };
  $('#edit', el).onclick = () => editEngagement(e);
  $('#del', el).onclick = async () => {
    if (!await confirmBox(`Delete engagement ${e.ref} including its work program, findings and documents?`, 'Delete')) return;
    await guard(() => API.del('/engagements/' + id), 'Engagement deleted'); go('#/engagements');
  };
  const fn = { overview: tabOverview, workprogram: tabWorkProgram, pbc: tabPbc, findings: tabFindings, notes: tabNotes, time: tabTime, documents: tabDocuments, report: tabReport }[tab] || tabOverview;
  fn($('#tab', el), d);
}

async function editEngagement(e) {
  const plans = await API.get('/plans?company_id=' + State.companyId);
  await formModal({ title: 'Edit engagement', wide: true, values: e, fields: [
    { k: 'title', label: 'Title', required: true, full: true }, { k: 'ref', label: 'Reference' },
    { k: 'entity_id', label: 'Entity', type: 'select', options: entityOptions() },
    { k: 'plan_id', label: 'Audit plan', type: 'select', options: plans.map(p => ({ value: p.id, label: p.title || p.year })) },
    { k: 'audit_type', label: 'Type', type: 'select', options: enums('audit_types'), blank: false },
    { k: 'quarter', label: 'Quarter', type: 'select', options: enums('quarters') },
    { k: 'budget_hours', label: 'Budget hours', type: 'number' },
    { k: 'period_from', label: 'Period from', type: 'date' }, { k: 'period_to', label: 'Period to', type: 'date' },
    { k: 'planned_start', label: 'Planned start', type: 'date' }, { k: 'planned_end', label: 'Planned end', type: 'date' },
    { k: 'actual_start', label: 'Actual start', type: 'date' }, { k: 'actual_end', label: 'Actual end', type: 'date' },
    { k: 'lead_auditor', label: 'Engagement lead', type: 'select', options: auditorOptions() },
    { k: 'reviewer', label: 'Reviewer', type: 'select', options: auditorOptions() },
    { k: 'team', label: 'Team' }, { k: 'auditee_contact', label: 'Auditee / process owner' },
    { k: 'objective', label: 'Objectives', type: 'textarea', rows: 5 }, { k: 'scope', label: 'Scope', type: 'textarea' },
    { k: 'out_of_scope', label: 'Out of scope', type: 'textarea' }, { k: 'methodology', label: 'Approach / methodology', type: 'textarea' }],
    onSave: d => API.put('/engagements/' + e.id, d) });
  toast('Engagement updated'); render();
}

/* ---------------- overview */
function tabOverview(el, d) {
  const e = d.engagement, P = d.procedures;
  const res = {}; P.forEach(p => { res[p.oe_result] = (res[p.oe_result] || 0) + 1; });
  const st = {}; P.forEach(p => { st[p.status] = (st[p.status] || 0) + 1; });
  const pbcRecv = d.pbc.filter(x => x.status === 'Received').length;
  const hrs = d.time_entries.reduce((s, t) => s + (t.hours || 0), 0);
  el.innerHTML = `<div class="grid g4 mb">
      <div class="card kpi"><div class="label">Work program</div><div class="value">${e.progress}%</div><div class="hint">${e.procedure_done} of ${e.procedure_total} procedures signed off</div></div>
      <div class="card kpi" style="--kpi-c:#e67e22"><div class="label">PBC received</div><div class="value">${pbcRecv}/${d.pbc.length}</div><div class="hint">document requests</div></div>
      <div class="card kpi" style="--kpi-c:#c0392b"><div class="label">Findings</div><div class="value">${d.findings.length}</div><div class="hint">${d.findings.filter(f => ['Critical', 'High'].includes(f.rating)).length} Critical / High</div></div>
      <div class="card kpi" style="--kpi-c:#27ae60"><div class="label">Hours</div><div class="value">${fmtNum(hrs, 1)}</div><div class="hint">of ${fmtNum(e.budget_hours)} budgeted</div></div></div>
    <div class="grid g3">
      <div class="card span2"><div class="card-h"><h3>Engagement details</h3></div><div class="card-b"><div class="kv">
        <div class="k">Reference</div><div>${esc(e.ref)}</div>
        <div class="k">Entity</div><div>${esc(e.entity_name || '-')}</div>
        <div class="k">Plan / quarter</div><div>${esc(e.plan_year || '-')} ${esc(e.quarter || '')}</div>
        <div class="k">Planned dates</div><div>${fmtDate(e.planned_start)} - ${fmtDate(e.planned_end)}</div>
        <div class="k">Actual dates</div><div>${fmtDate(e.actual_start)} - ${fmtDate(e.actual_end)}</div>
        <div class="k">Engagement lead</div><div>${esc(e.lead_auditor || '-')}</div>
        <div class="k">Reviewer</div><div>${esc(e.reviewer || '-')}</div>
        <div class="k">Team</div><div>${esc(e.team || '-')}</div>
        <div class="k">Auditee contact</div><div>${esc(e.auditee_contact || '-')}</div>
        <div class="k">Processes</div><div class="pill-list">${e.process_codes.map(c => `<span class="badge b-blue">${esc(procName(c))}</span>`).join('') || '-'}</div>
        <div class="k">Objectives</div><div class="pre">${esc(e.objective || '-')}</div>
        <div class="k">Scope</div><div class="pre">${esc(e.scope || '-')}</div>
        ${e.out_of_scope ? `<div class="k">Out of scope</div><div class="pre">${esc(e.out_of_scope)}</div>` : ''}
      </div></div></div>
      <div><div class="card mb"><div class="card-h"><h3>Test results</h3></div><div class="card-b">${donut(res, { label: 'Controls' })}</div></div>
        <div class="card"><div class="card-h"><h3>Sign-off status</h3></div><div class="card-b">${donut(st, { label: 'Procedures' })}</div></div></div>
    </div>`;
}
function procName(code) { const p = (window._libCache || []).find(x => x.code === code); return p ? p.name : code; }

/* ---------------- work program */
function tabWorkProgram(el, d) {
  const e = d.engagement;
  el.innerHTML = `<div class="card"><div class="toolbar">
      <input type="search" class="search" id="q" placeholder="Search risks, controls...">
      <select id="fp"><option value="">All processes</option>${e.process_codes.map(c => `<option value="${esc(c)}">${esc(procName(c))}</option>`).join('')}</select>
      <select id="fr"><option value="">All results</option>${enums('test_results').map(s => `<option>${s}</option>`).join('')}</select>
      <label class="check"><input type="checkbox" id="fk"> Key controls only</label>
      <span style="flex:1"></span>
      <button class="btn sm" id="addproc">+ Add processes</button><button class="btn sm" id="addcustom">+ Custom procedure</button>
      <button class="btn sm" onclick="API.download('/reports/engagement/${e.id}/racm')">⬇ RACM Excel</button></div>
    <div id="tbl"></div></div>`;
  const draw = () => {
    const q = $('#q', el).value.toLowerCase(), fp = $('#fp', el).value, fr = $('#fr', el).value, fk = $('#fk', el).checked;
    const list = d.procedures.filter(p => (!q || [p.risk, p.control, p.subprocess, p.control_id].join(' ').toLowerCase().includes(q))
      && (!fp || p.process_code === fp) && (!fr || p.oe_result === fr) && (!fk || p.key_control));
    $('#tbl', el).innerHTML = tableHtml([
      { label: 'Ref', render: p => `<b class="nowrap">${esc(p.control_id || p.risk_id || p.id)}</b><div class="small muted">${esc(p.wp_ref || '')}</div>` },
      { label: 'Sub-process', render: p => esc(p.subprocess) },
      { label: 'Risk', cls: 'wrap', render: p => `${esc(truncate(p.risk, 120))}<div>${badge(p.risk_rating, p.risk_rating === 'High' ? 'b-high' : p.risk_rating === 'Low' ? 'b-low' : 'b-medium')} ${p.fraud_risk ? badge('Fraud', 'b-red') : ''}</div>` },
      { label: 'Control', cls: 'wrap', render: p => `${esc(truncate(p.control, 130))}<div class="small muted">${esc(p.control_type || '')} &middot; ${esc(p.control_nature || '')} &middot; ${esc(p.frequency || '')} ${p.key_control ? '&middot; <b>Key</b>' : ''}</div>` },
      { label: 'Sample', cls: 'center', render: p => p.sample_size || '-' },
      { label: 'Design', render: p => badge(p.design_result) },
      { label: 'Operating', render: p => badge(p.oe_result) },
      { label: 'Sign-off', render: p => `${badge(p.status)}<div class="small muted">${esc(p.prepared_by || '')}${p.reviewed_by ? ' / ' + esc(p.reviewed_by) : ''}</div>` },
    ], list, { onRow: true, empty: 'No procedures. Add processes from the library or a custom procedure.' });
    bindRows($('#tbl', el), list, p => workpaper(p, d));
  };
  ['q', 'fp', 'fr', 'fk'].forEach(id => $('#' + id, el).addEventListener('input', draw));
  draw();
  $('#addproc', el).onclick = async () => {
    const inds = ['Common'].concat(State.company.industries);
    const lib = (await ensureLibrary()).filter(p => inds.includes(p.industry) && !e.process_codes.includes(p.code));
    await formModal({ title: 'Add processes from library', wide: true, saveLabel: 'Add to work program',
      fields: [{ k: 'process_codes', label: 'Processes', type: 'checks', required: true, options: lib.map(p => ({ value: p.code, label: `${p.name} (${p.industry})` })) },
        { k: 'load_pbc', label: '', type: 'checkbox', text: 'Also add PBC requests', default: 1 }],
      onSave: f => API.post(`/engagements/${e.id}/processes`, { process_codes: f.process_codes, load_pbc: !!f.load_pbc }) });
    toast('Processes added'); render();
  };
  $('#addcustom', el).onclick = async () => {
    await formModal({ title: 'Custom audit procedure', wide: true, values: { risk_rating: 'Medium', key_control: 1, control_type: 'Preventive', control_nature: 'Manual' }, fields: [
      { k: 'process_code', label: 'Process', type: 'select', options: e.process_codes.map(c => ({ value: c, label: procName(c) })) },
      { k: 'subprocess', label: 'Sub-process' }, { k: 'risk_id', label: 'Risk ID' }, { k: 'control_id', label: 'Control ID' },
      { k: 'risk_rating', label: 'Risk rating', type: 'select', options: ['High', 'Medium', 'Low'], blank: false },
      { k: 'assertion', label: 'Assertion' },
      { k: 'risk', label: 'Risk', type: 'textarea', required: true }, { k: 'control', label: 'Control', type: 'textarea' },
      { k: 'control_type', label: 'Control type', type: 'select', options: ['Preventive', 'Detective', 'Corrective'] },
      { k: 'control_nature', label: 'Nature', type: 'select', options: ['Manual', 'Automated', 'IT-dependent Manual'] },
      { k: 'frequency', label: 'Frequency', type: 'select', options: ['Annual', 'Quarterly', 'Monthly', 'Weekly', 'Daily', 'Multiple times a day', 'Event-driven'] },
      { k: 'key_control', label: '', type: 'checkbox', text: 'Key control' }, { k: 'fraud_risk', label: '', type: 'checkbox', text: 'Fraud risk' },
      { k: 'steps', label: 'Test steps (one per line)', type: 'textarea', rows: 5 }],
      onSave: f => { f.engagement_id = e.id; f.sort = d.procedures.length + 1; return API.post('/procedures', f); } });
    toast('Procedure added'); render();
  };
}

function workpaper(p, d) {
  const fields = [
    { k: 'population', label: 'Population size', type: 'number' },
    { k: 'sample_size', label: 'Sample size', type: 'number' },
    { k: 'sample_method', label: 'Sample selection method', type: 'select', options: ['Random', 'Systematic', 'Haphazard', 'Judgemental', 'Monetary Unit', '100% / Data analytics'] },
    { k: 'wp_ref', label: 'Workpaper reference' },
    { k: 'design_result', label: 'Test of design', type: 'select', options: enums('test_results'), blank: false },
    { k: 'oe_result', label: 'Test of operating effectiveness', type: 'select', options: enums('test_results'), blank: false },
    { k: 'steps', label: 'Audit procedures / test steps', type: 'textarea', rows: 6 },
    { k: 'testing_notes', label: 'Work performed & results (exceptions noted, sample details)', type: 'textarea', rows: 6 },
    { k: 'conclusion', label: 'Conclusion', type: 'textarea', rows: 2 },
  ];
  const notes = d.review_notes.filter(n => n.procedure_id === p.id);
  const atts = d.attachments.filter(a => a.procedure_id === p.id);
  const m = modal({ title: `Workpaper ${p.control_id || ''} - ${p.subprocess || ''}`, wide: true,
    body: `<div class="wp mb">
        <div class="box"><h4>Risk ${esc(p.risk_id || '')} ${badge(p.risk_rating, p.risk_rating === 'High' ? 'b-high' : 'b-medium')} ${p.fraud_risk ? badge('Fraud risk', 'b-red') : ''}</h4><div>${esc(p.risk)}</div>
          <div class="small muted" style="margin-top:6px">Assertion: ${esc(p.assertion || '-')}</div></div>
        <div class="box"><h4>Control ${esc(p.control_id || '')} ${p.key_control ? badge('Key', 'b-navy') : ''}</h4><div>${esc(p.control || '-')}</div>
          <div class="small muted" style="margin-top:6px">${esc(p.control_type || '')} &middot; ${esc(p.control_nature || '')} &middot; ${esc(p.frequency || '')}</div></div></div>
      ${formHtml(fields, p)}
      <div class="actions mb"><button class="btn sm" id="wp-sugg">⚖ Suggest sample size</button><button class="btn sm" id="wp-pick">\u{1F3B2} Random selection</button>
        <span id="wp-pick-out" class="small muted"></span></div>
      <div class="grid g2 mb">
        <div class="signoff"><div style="flex:1"><div class="small muted">Prepared by</div><b>${esc(p.prepared_by || 'Not signed')}</b> <span class="small muted">${fmtDate(p.prepared_on)}</span></div><button class="btn sm" id="wp-prep">Sign as preparer</button></div>
        <div class="signoff"><div style="flex:1"><div class="small muted">Reviewed by</div><b>${esc(p.reviewed_by || 'Not reviewed')}</b> <span class="small muted">${fmtDate(p.reviewed_on)}</span></div><button class="btn sm" id="wp-rev">Sign as reviewer</button></div></div>
      <h3 style="margin-bottom:6px">Review notes</h3>
      ${notes.length ? notes.map(n => `<div class="lib-item"><div class="hdr">${badge(n.status)} <b>${esc(n.raised_by || '')}</b> <span class="small muted">${fmtDate(n.raised_on)}</span></div><div class="pre">${esc(n.note)}</div>${n.response ? `<div class="small" style="margin-top:6px"><b>Response:</b> ${esc(n.response)}</div>` : ''}</div>`).join('') : '<p class="muted small">No review notes.</p>'}
      <h3 style="margin:10px 0 6px">Evidence</h3>
      ${atts.length ? atts.map(a => `<div><a onclick="API.download('/attachments/${a.id}/download')">\u{1F4CE} ${esc(a.filename)}</a> <span class="small muted">${esc(a.description || '')}</span></div>`).join('') : '<p class="muted small">No evidence attached.</p>'}
      <div class="actions" style="margin-top:6px"><input type="file" id="wp-file" style="width:auto"><button class="btn sm" id="wp-up">Upload evidence</button></div>`,
    footer: `<button class="btn danger" id="wp-del">Delete</button><button class="btn" id="wp-clear">Clear sign-offs</button><span style="flex:1"></span>
      <button class="btn" id="wp-note">+ Review note</button><button class="btn" id="wp-find">⚠ Raise finding</button><button class="btn primary" id="wp-save">Save workpaper</button>`,
  });
  const save = async (silent) => {
    const data = readForm(m.el, fields);
    if (p.status === 'Not Started') data.status = 'In Progress';
    await API.put('/procedures/' + p.id, data);
    Object.assign(p, data);
    if (!silent) toast('Workpaper saved');
  };
  $('#wp-save', m.el).onclick = async () => { await guard(() => save()); m.close(); render(); };
  $('#wp-sugg', m.el).onclick = async () => {
    const r = await guard(() => API.post('/sampling/size', { method: 'frequency', frequency: p.frequency, nature: p.control_nature, risk: p.risk_rating, population: $('#f_population', m.el).value }));
    $('#f_sample_size', m.el).value = r.sample_size; toast(r.basis);
  };
  $('#wp-pick', m.el).onclick = async () => {
    const pop = $('#f_population', m.el).value, n = $('#f_sample_size', m.el).value;
    const r = await guard(() => API.post('/sampling/select', { population: pop, size: n }));
    const txt = `Random selection (seed ${r.seed}) of ${r.items.length} from population ${pop}: items #${r.items.join(', #')}`;
    $('#wp-pick-out', m.el).textContent = 'Added to testing notes.';
    const tn = $('#f_testing_notes', m.el); tn.value = (tn.value ? tn.value + '\n' : '') + txt;
  };
  const sign = role => formModal({ title: role === 'preparer' ? 'Preparer sign-off' : 'Reviewer sign-off', saveLabel: 'Sign off',
    fields: [{ k: 'name', label: 'Name', type: 'select', options: auditorOptions(), required: true, help: auditorOptions().length ? '' : 'Add team members under Audit Team first' }],
    onSave: async f => { await save(true); return API.post(`/procedures/${p.id}/signoff`, { role, name: f.name }); } })
    .then(() => { toast('Signed off'); m.close(); render(); });
  $('#wp-prep', m.el).onclick = () => sign('preparer');
  $('#wp-rev', m.el).onclick = () => sign('reviewer');
  $('#wp-clear', m.el).onclick = async () => { await guard(() => API.post(`/procedures/${p.id}/signoff`, { role: 'clear' }), 'Sign-offs cleared'); m.close(); render(); };
  $('#wp-del', m.el).onclick = async () => { if (!await confirmBox('Delete this procedure?', 'Delete')) return; await guard(() => API.del('/procedures/' + p.id), 'Deleted'); m.close(); render(); };
  $('#wp-note', m.el).onclick = async () => {
    await formModal({ title: 'Raise review note', fields: [{ k: 'raised_by', label: 'Raised by', type: 'select', options: auditorOptions() }, { k: 'note', label: 'Review note', type: 'textarea', required: true }],
      onSave: f => { f.engagement_id = p.engagement_id; f.procedure_id = p.id; return API.post('/review_notes', f); } });
    toast('Review note raised'); m.close(); render();
  };
  $('#wp-find', m.el).onclick = async () => {
    await guard(() => save(true));
    const f = await guard(() => API.post(`/procedures/${p.id}/finding`), 'Draft finding created from workpaper');
    m.close(); await findingForm(f); go(`#/engagement/${p.engagement_id}/findings`); render();
  };
  $('#wp-up', m.el).onclick = async () => {
    const file = $('#wp-file', m.el).files[0];
    if (!file) return toast('Choose a file first', true);
    const fd = new FormData();
    fd.append('file', file); fd.append('company_id', State.companyId); fd.append('engagement_id', p.engagement_id); fd.append('procedure_id', p.id);
    fd.append('description', 'Evidence for ' + (p.control_id || 'procedure'));
    await guard(() => API.upload('/attachments/upload', fd), 'Evidence uploaded'); m.close(); render();
  };
}

/* ---------------- PBC */
function tabPbc(el, d) {
  const e = d.engagement;
  el.innerHTML = `<div class="card"><div class="card-h"><h3>Prepared-by-client (PBC) document requests</h3><button class="btn sm primary" id="add">+ Add request</button></div>
    <div class="card-b flush">${tableHtml([
      { label: '#', render: x => d.pbc.indexOf(x) + 1 },
      { label: 'Item requested', cls: 'wrap', render: x => `${esc(x.item)}<div class="small muted">${esc(procName(x.process_code) || '')}</div>` },
      { label: 'Requested from', key: 'requested_from' }, { label: 'Requested', render: x => fmtDate(x.requested_on) },
      { label: 'Due', render: x => fmtDate(x.due_on) },
      { label: 'Status', render: x => `<select data-st="${x.id}" style="width:auto">${enums('pbc_statuses').map(s => `<option ${s === x.status ? 'selected' : ''}>${s}</option>`).join('')}</select>` },
      { label: 'Received', render: x => fmtDate(x.received_on) }, { label: 'Remarks', key: 'remarks' },
      { label: '', render: x => `<button class="icon-btn" data-edit="${x.id}">✎</button><button class="icon-btn" data-del="${x.id}">✕</button>` },
    ], d.pbc, { empty: 'No PBC requests' })}</div></div>`;
  const form = x => formModal({ title: x ? 'Edit request' : 'New PBC request', values: x || { requested_on: today(), status: 'Requested', requested_from: e.auditee_contact }, fields: [
    { k: 'item', label: 'Item requested', type: 'textarea', required: true },
    { k: 'process_code', label: 'Process', type: 'select', options: e.process_codes.map(c => ({ value: c, label: procName(c) })) },
    { k: 'requested_from', label: 'Requested from' }, { k: 'requested_on', label: 'Requested on', type: 'date' },
    { k: 'due_on', label: 'Due on', type: 'date' }, { k: 'status', label: 'Status', type: 'select', options: enums('pbc_statuses'), blank: false },
    { k: 'remarks', label: 'Remarks', full: true }],
    onSave: f => { f.engagement_id = e.id; return x ? API.put('/pbc/' + x.id, f) : API.post('/pbc', f); } }).then(render);
  $('#add', el).onclick = () => form();
  $$('[data-edit]', el).forEach(b => b.onclick = () => form(d.pbc.find(x => String(x.id) === b.dataset.edit)));
  $$('[data-del]', el).forEach(b => b.onclick = async () => { await guard(() => API.del('/pbc/' + b.dataset.del)); render(); });
  $$('[data-st]', el).forEach(s => s.onchange = async () => { await guard(() => API.put('/pbc/' + s.dataset.st, { status: s.value }), 'Updated'); render(); });
}

/* ---------------- findings */
function tabFindings(el, d) {
  const e = d.engagement;
  el.innerHTML = `<div class="card"><div class="card-h"><h3>Findings &amp; observations</h3>
      <span class="small muted">Suggested overall rating: ${badge(d.suggested_rating)}</span><button class="btn sm primary" id="add">+ New finding</button></div>
    <div class="card-b flush">${tableHtml([
      { label: 'Ref', render: f => `<b>${esc(f.ref)}</b>` }, { label: 'Finding', cls: 'wrap', render: f => `${esc(f.title)}<div class="small muted">${esc(f.process_name)}</div>` },
      { label: 'Rating', render: f => badge(f.rating) }, { label: 'Owner', key: 'owner' },
      { label: 'Due', render: f => fmtDate(f.revised_due_date || f.due_date) }, { label: 'Status', render: f => badge(f.overdue ? 'Overdue' : f.status) },
      { label: 'Mgmt response', render: f => f.mgmt_response ? badge('Received', 'b-green') : badge('Pending', 'b-amber') },
    ], d.findings, { onRow: true, empty: 'No findings. Raise findings from workpapers or add them here.' })}</div></div>`;
  bindRows(el, d.findings, findingDetail);
  $('#add', el).onclick = async () => { await findingForm({ rating: 'Medium', status: 'Open', entity_id: e.entity_id, process_code: e.process_codes[0] }, e.id).catch(() => {}); render(); };
}

/* ---------------- review notes */
function tabNotes(el, d) {
  const procRef = id => { const p = d.procedures.find(x => x.id === id); return p ? (p.control_id || 'Procedure ' + p.id) : 'General'; };
  el.innerHTML = `<div class="card"><div class="card-h"><h3>Review notes</h3><button class="btn sm primary" id="add">+ Review note</button></div>
    <div class="card-b flush">${tableHtml([
      { label: 'Workpaper', render: n => esc(procRef(n.procedure_id)) }, { label: 'Note', cls: 'wrap', render: n => nl2br(n.note) },
      { label: 'Raised by', render: n => `${esc(n.raised_by || '')}<div class="small muted">${fmtDate(n.raised_on)}</div>` },
      { label: 'Response', cls: 'wrap', render: n => nl2br(n.response || '') }, { label: 'Status', render: n => badge(n.status) },
      { label: '', render: n => `<button class="btn sm" data-resp="${n.id}">Respond / clear</button>` },
    ], d.review_notes, { empty: 'No review notes' })}</div></div>`;
  $('#add', el).onclick = async () => {
    await formModal({ title: 'Review note', fields: [
      { k: 'procedure_id', label: 'Workpaper', type: 'select', options: d.procedures.map(p => ({ value: p.id, label: `${p.control_id || p.id} - ${truncate(p.control || p.risk, 60)}` })) },
      { k: 'raised_by', label: 'Raised by', type: 'select', options: auditorOptions() }, { k: 'note', label: 'Note', type: 'textarea', required: true }],
      onSave: f => { f.engagement_id = d.engagement.id; f.procedure_id = f.procedure_id || null; return API.post('/review_notes', f); } });
    render();
  };
  $$('[data-resp]', el).forEach(b => b.onclick = async () => {
    const n = d.review_notes.find(x => String(x.id) === b.dataset.resp);
    await formModal({ title: 'Respond to review note', values: n, intro: `<p class="pre">${esc(n.note)}</p>`, fields: [
      { k: 'response', label: 'Preparer response', type: 'textarea' }, { k: 'status', label: 'Status', type: 'select', options: ['Open', 'Cleared'], blank: false },
      { k: 'cleared_by', label: 'Cleared by', type: 'select', options: auditorOptions() }],
      onSave: f => API.put('/review_notes/' + n.id, f) });
    render();
  });
}

/* ---------------- time */
function tabTime(el, d) {
  const e = d.engagement;
  const byPhase = {}; d.time_entries.forEach(t => { byPhase[t.phase] = (byPhase[t.phase] || 0) + (t.hours || 0); });
  const total = d.time_entries.reduce((s, t) => s + (t.hours || 0), 0);
  el.innerHTML = `<div class="grid g3"><div class="card span2"><div class="card-h"><h3>Time entries</h3><button class="btn sm primary" id="add">+ Log time</button></div>
      <div class="card-b flush">${tableHtml([
        { label: 'Date', render: t => fmtDate(t.entry_date) }, { label: 'Auditor', key: 'auditor' }, { label: 'Phase', key: 'phase' },
        { label: 'Hours', cls: 'right', render: t => fmtNum(t.hours, 1) }, { label: 'Description', key: 'description' },
        { label: '', render: t => `<button class="icon-btn" data-del="${t.id}">✕</button>` },
      ], d.time_entries, { empty: 'No time logged' })}</div></div>
    <div class="card"><div class="card-h"><h3>Budget vs actual</h3></div><div class="card-b">
      <h2>${fmtNum(total, 1)} <span class="muted small">of ${fmtNum(e.budget_hours)} hours</span></h2>${progress(e.budget_hours ? total / e.budget_hours * 100 : 0)}
      <div class="mt">${hbars(Object.entries(byPhase), { color: '#2e75b6' })}</div></div></div></div>`;
  $('#add', el).onclick = async () => {
    await formModal({ title: 'Log time', values: { entry_date: today(), phase: 'Fieldwork' }, fields: [
      { k: 'auditor', label: 'Auditor', type: 'select', options: auditorOptions(), required: true }, { k: 'entry_date', label: 'Date', type: 'date' },
      { k: 'phase', label: 'Phase', type: 'select', options: enums('phases'), blank: false }, { k: 'hours', label: 'Hours', type: 'number', step: '0.5', required: true },
      { k: 'description', label: 'Description', full: true }],
      onSave: f => { f.engagement_id = e.id; return API.post('/time_entries', f); } });
    render();
  };
  $$('[data-del]', el).forEach(b => b.onclick = async () => { await guard(() => API.del('/time_entries/' + b.dataset.del)); render(); });
}

/* ---------------- documents */
function tabDocuments(el, d) {
  const e = d.engagement;
  el.innerHTML = `<div class="card"><div class="card-h"><h3>Engagement documents &amp; evidence</h3></div>
    <div class="toolbar"><input type="file" id="file" style="width:auto"><input type="text" id="desc" placeholder="Description (e.g. Planning memo, Signed report)" style="min-width:320px"><button class="btn primary sm" id="up">Upload</button></div>
    <div class="card-b flush">${tableHtml([
      { label: 'File', render: a => `<a onclick="API.download('/attachments/${a.id}/download')">\u{1F4CE} ${esc(a.filename)}</a>` },
      { label: 'Description', key: 'description' }, { label: 'Linked to', render: a => a.procedure_id ? 'Workpaper' : a.finding_id ? 'Finding' : 'Engagement' },
      { label: 'Size', render: a => fmtNum((a.size || 0) / 1024, 1) + ' KB' }, { label: 'Uploaded', key: 'uploaded_on' },
      { label: '', render: a => `<button class="icon-btn" data-del="${a.id}">✕</button>` },
    ], d.attachments, { empty: 'No documents uploaded' })}</div></div>`;
  $('#up', el).onclick = async () => {
    const file = $('#file', el).files[0];
    if (!file) return toast('Choose a file first', true);
    const fd = new FormData();
    fd.append('file', file); fd.append('company_id', State.companyId); fd.append('engagement_id', e.id); fd.append('description', $('#desc', el).value);
    await guard(() => API.upload('/attachments/upload', fd), 'Uploaded'); render();
  };
  $$('[data-del]', el).forEach(b => b.onclick = async () => { if (!await confirmBox('Delete this document?', 'Delete')) return; await guard(() => API.del('/attachments/' + b.dataset.del)); render(); });
}

/* ---------------- report */
function tabReport(el, d) {
  const e = d.engagement;
  const notSigned = d.procedures.filter(p => p.status !== 'Reviewed').length;
  const openNotes = d.review_notes.filter(n => n.status === 'Open').length;
  const noResp = d.findings.filter(f => !f.mgmt_response).length;
  const check = (okk, label) => `<div style="margin-bottom:6px">${okk ? '✅' : '⚠️'} ${label}</div>`;
  el.innerHTML = `<div class="grid g3"><div class="card span2"><div class="card-h"><h3>Audit report</h3></div><div class="card-b">
      ${formHtml([
        { k: 'overall_rating', label: 'Overall rating', type: 'select', options: ['Satisfactory', 'Needs Improvement', 'Needs Significant Improvement', 'Unsatisfactory'] },
        { k: 'report_date', label: 'Report date', type: 'date' },
        { k: 'executive_summary', label: 'Executive summary (leave blank to auto-generate)', type: 'textarea', rows: 8 }], e)}
      <div class="actions"><button class="btn" id="calc">Apply suggested rating (${esc(d.suggested_rating)})</button><button class="btn" id="save">Save</button>
        <span style="flex:1"></span><button class="btn primary" id="docx">⬇ Download Word report</button>
        <button class="btn" onclick="API.download('/reports/engagement/${e.id}/racm')">⬇ RACM &amp; PBC Excel</button></div></div></div>
    <div class="card"><div class="card-h"><h3>Quality checklist</h3></div><div class="card-b">
      ${check(notSigned === 0, `${notSigned} procedure(s) not yet reviewed`)}
      ${check(openNotes === 0, `${openNotes} open review note(s)`)}
      ${check(noResp === 0, `${noResp} finding(s) without management response`)}
      ${check(d.pbc.every(x => x.status !== 'Requested'), 'All PBC items received or N/A')}
      ${check(!!e.overall_rating, 'Overall rating assigned')}
      <p class="small muted mt">The report includes: cover, distribution, executive summary, objectives &amp; scope, findings summary, detailed findings (condition, criteria, cause, effect, recommendation, management action), work-performed summary and rating definitions.</p></div></div></div>`;
  const fields = [{ k: 'overall_rating', type: 'select' }, { k: 'report_date', type: 'date' }, { k: 'executive_summary', type: 'textarea' }];
  const save = () => API.put('/engagements/' + e.id, readForm(el, fields));
  $('#save', el).onclick = async () => { await guard(save, 'Saved'); render(); };
  $('#calc', el).onclick = () => { $('#f_overall_rating', el).value = d.suggested_rating; };
  $('#docx', el).onclick = async () => { await guard(save); API.download(`/reports/engagement/${e.id}/docx`); };
}

route('engagement', viewEngagement);
