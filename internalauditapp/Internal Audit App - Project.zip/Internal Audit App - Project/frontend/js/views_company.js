/* Company selection, company setup, entities and audit team. */
'use strict';

const COMPANY_FIELDS = () => [
  { k: 'name', label: 'Company / Group name', required: true, full: true },
  { k: 'short_code', label: 'Short code', placeholder: 'e.g. ABC' },
  { k: 'company_type', label: 'Structure', type: 'select', options: enums('company_types'), blank: false },
  { k: 'country', label: 'Country of incorporation', type: 'select', options: enums('countries') },
  { k: 'base_currency', label: 'Reporting currency', type: 'select', options: enums('currencies'), blank: false, default: 'AED' },
  { k: 'fiscal_year_end', label: 'Fiscal year end', default: '31-Dec' },
  { k: 'reg_no', label: 'Trade licence / Registration no.' },
  { k: 'head_of_audit', label: 'Head of Internal Audit' },
  { k: 'audit_committee_chair', label: 'Audit Committee Chair' },
  { k: 'address', label: 'Address', full: true },
  { k: 'industries', label: 'Industries / business lines', type: 'checks', options: State.meta.industries, required: true,
    help: 'Common processes (P2P, O2C, Inventory, Treasury, Payroll, IT, Tax, Governance ...) are always included.' },
];

async function viewLanding(el) {
  const list = await API.get('/companies');
  el.innerHTML = `<div class="landing"><div class="inner">
    <div class="hero"><div class="logo">IA</div><div><h1>AuditPro</h1></div></div>
    <div class="tag">Internal Audit Management System &middot; Risk-based planning, RACM work programs, findings tracking, analytics and board reporting</div>
    <div style="display:flex;gap:10px;margin-bottom:18px;align-items:center">
      <h2 style="flex:1">Select a company to load</h2>
      <button class="btn" id="demo-btn">✨ Load demo company</button>
      <button class="btn primary" id="new-btn">+ Create new company</button>
    </div>
    ${State.meta.library_errors && State.meta.library_errors.length ? `<div class="card card-b mb" style="color:#c0392b">Library load warnings: ${esc(State.meta.library_errors.join('; '))}</div>` : ''}
    <div class="co-grid">
      ${list.map(c => `<div class="co-card" data-id="${c.id}">
        <button class="icon-btn del" data-del="${c.id}" title="Delete company">\u{1F5D1}</button>
        <div class="small muted">${esc(c.company_type)} &middot; ${esc(c.country || '')}</div>
        <h2 style="margin:4px 30px 6px 0">${esc(c.name)}</h2>
        <div class="pill-list">${(c.industries || []).map(i => `<span class="badge b-blue">${esc(i)}</span>`).join('')}</div>
        <div class="stats"><div><b>${c.entity_count}</b>Entities</div><div><b>${c.engagement_count}</b>Engagements</div><div><b>${c.open_findings}</b>Open findings</div></div>
      </div>`).join('')}
      <div class="co-card new" id="new-card"><div style="font-size:30px">+</div><div><b>Create new company</b></div><div class="small" style="color:#b8cbe0">Single entity or multinational group</div></div>
    </div>
    <p class="small" style="color:#8ea6c2;margin-top:30px">Procedure library: ${State.meta.library_processes} business processes across ${State.meta.industries.length} industries plus common processes. Data stored locally in SQLite.</p>
  </div></div>`;
  $$('.co-card[data-id]', el).forEach(c => c.addEventListener('click', e => {
    if (e.target.closest('[data-del]')) return;
    loadCompany(c.dataset.id);
  }));
  $$('[data-del]', el).forEach(b => b.addEventListener('click', async () => {
    const c = list.find(x => String(x.id) === b.dataset.del);
    if (!await confirmBox(`Permanently delete "${c.name}" and ALL its audit data (engagements, findings, workpapers)?`, 'Delete')) return;
    await guard(() => API.del('/companies/' + c.id), 'Company deleted');
    render();
  }));
  $('#new-btn', el).onclick = $('#new-card', el).onclick = () => companyWizard();
  $('#demo-btn', el).onclick = async () => {
    $('#demo-btn', el).disabled = true;
    $('#demo-btn', el).textContent = 'Generating...';
    const c = await guard(() => API.post('/companies/demo'), 'Demo company created');
    loadCompany(c.id);
  };
}

async function loadCompany(id) {
  try {
    State.company = await API.get('/companies/' + id);
  } catch (e) { State.company = null; State.remember(''); return render(); }
  State.remember(id);
  await refreshCompanyLists();
  go('#/dashboard');
}
async function refreshCompanyLists() {
  const [ents, auds] = await Promise.all([API.get('/entities?company_id=' + State.companyId), API.get('/auditors?company_id=' + State.companyId)]);
  State.entities = ents;
  State.auditors = auds;
}

function entityRowHtml(e) {
  e = e || {};
  const sel = (opts, v) => opts.map(o => `<option ${o === v ? 'selected' : ''}>${esc(o)}</option>`).join('');
  return `<div class="entity-row">
    <input type="text" data-k="name" placeholder="Legal entity name" value="${esc(e.name || '')}">
    <select data-k="entity_type">${sel(enums('entity_types'), e.entity_type || 'Subsidiary')}</select>
    <select data-k="country"><option value="">Country</option>${sel(enums('countries'), e.country)}</select>
    <select data-k="currency">${sel(enums('currencies'), e.currency || 'AED')}</select>
    <select data-k="industry"><option value="">All selected industries</option>${sel(State.meta.industries, e.industry)}</select>
    <button class="icon-btn" data-rm title="Remove">✕</button></div>`;
}

function companyWizard() {
  const fields = COMPANY_FIELDS();
  const m = modal({
    title: 'Create new company', wide: true,
    body: formHtml(fields, { company_type: 'Single Entity', base_currency: 'AED', fiscal_year_end: '31-Dec', country: 'United Arab Emirates' }) +
      `<div id="ent-sec" class="hidden"><h3 style="margin:8px 0 6px">Group entities (subsidiaries, branches, JVs)</h3>
       <p class="small muted">Each entity gets its own audit universe. Leave industry blank to apply all selected industries.</p>
       <div class="entity-row small muted"><span>Name</span><span>Type</span><span>Country</span><span>Currency</span><span>Industry</span><span></span></div>
       <div id="ent-rows"></div><button class="btn sm" id="add-ent">+ Add entity</button></div>
       <div class="field mt"><label class="check"><input type="checkbox" id="pop-uni" checked> Auto-build audit universe &amp; risk assessment from the procedure library</label></div>`,
    footer: `<button class="btn" data-close>Cancel</button><button class="btn primary" id="cw-save">Create company</button>`,
  });
  const typeSel = $('#f_company_type', m.el);
  const rows = $('#ent-rows', m.el);
  const toggle = () => {
    const multi = typeSel.value === 'Multinational Group';
    $('#ent-sec', m.el).classList.toggle('hidden', !multi);
    if (multi && !rows.children.length) {
      rows.insertAdjacentHTML('beforeend', entityRowHtml({ name: ($('#f_name', m.el).value || 'Group') + ' Holding', entity_type: 'Holding', country: $('#f_country', m.el).value }));
      rows.insertAdjacentHTML('beforeend', entityRowHtml({ country: $('#f_country', m.el).value }));
    }
  };
  typeSel.onchange = toggle;
  $('#add-ent', m.el).onclick = () => rows.insertAdjacentHTML('beforeend', entityRowHtml({}));
  rows.addEventListener('click', e => { if (e.target.closest('[data-rm]')) e.target.closest('.entity-row').remove(); });
  $('#cw-save', m.el).onclick = async () => {
    const data = readForm(m.el, fields);
    if (!data.name) return toast('Company name is required', true);
    if (!data.industries.length) return toast('Select at least one industry', true);
    data.populate_universe = $('#pop-uni', m.el).checked;
    if (data.company_type === 'Multinational Group') {
      data.entities = $$('.entity-row', rows).map(r => {
        const o = {}; $$('[data-k]', r).forEach(i => { o[i.dataset.k] = i.value; }); return o;
      }).filter(o => o.name.trim());
    }
    $('#cw-save', m.el).disabled = true;
    try {
      const c = await API.post('/companies', data);
      m.close();
      toast('Company created');
      loadCompany(c.id);
    } catch (e) { toast(e.message, true); $('#cw-save', m.el).disabled = false; }
  };
}

/* ---------------- company & entities page */
async function viewCompany(el) {
  const c = State.company = await API.get('/companies/' + State.companyId);
  await refreshCompanyLists();
  const uni = await API.get('/universe?company_id=' + c.id);
  const cnt = {};
  uni.forEach(u => { cnt[u.entity_id] = (cnt[u.entity_id] || 0) + 1; });
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>${esc(c.name)}</h1><p>${esc(c.company_type)} &middot; ${esc(c.country || '')} &middot; Reporting currency ${esc(c.base_currency || '')} &middot; FYE ${esc(c.fiscal_year_end || '')}</p></div>
    <div class="actions"><button class="btn" id="edit-co">Edit company</button><button class="btn primary" id="add-ent">+ Add entity</button></div></div>
    <div class="grid g3 mb">
      <div class="card card-b"><div class="kv">
        <div class="k">Short code</div><div>${esc(c.short_code || '-')}</div>
        <div class="k">Registration no.</div><div>${esc(c.reg_no || '-')}</div>
        <div class="k">Head of Internal Audit</div><div>${esc(c.head_of_audit || '-')}</div>
        <div class="k">Audit Committee Chair</div><div>${esc(c.audit_committee_chair || '-')}</div>
        <div class="k">Address</div><div>${esc(c.address || '-')}</div></div></div>
      <div class="card card-b span2"><h3 style="margin-bottom:10px">Industries &amp; business lines</h3>
        <div class="pill-list mb">${c.industries.map(i => `<span class="badge b-blue">${esc(i)}</span>`).join('')}<span class="badge b-grey">Common processes</span></div>
        <p class="muted small">Audit universe: <b>${uni.length}</b> auditable units across <b>${State.entities.length}</b> entities. Use "Sync universe" after adding entities or industries.</p>
        <button class="btn sm" id="sync-uni">↻ Sync universe from library</button></div>
    </div>
    <div class="card"><div class="card-h"><h3>Legal entities / group structure</h3></div>
      <div class="card-b flush">${tableHtml([
        { label: 'Entity', render: e => `<b>${esc(e.name)}</b>` },
        { label: 'Type', key: 'entity_type' },
        { label: 'Parent', render: e => esc(entityName(e.parent_id) || '-') },
        { label: 'Country', key: 'country' },
        { label: 'Currency', key: 'currency' },
        { label: 'Industry', render: e => esc(e.industry || 'All company industries') },
        { label: 'Ownership', render: e => (e.ownership_pct || 100) + '%' },
        { label: 'Auditable units', render: e => cnt[e.id] || 0 },
        { label: '', cls: 'right', render: e => `<button class="btn sm" data-edit="${e.id}">Edit</button> <button class="btn sm danger" data-del="${e.id}">Delete</button>` },
      ], State.entities)}</div></div>`;
  $('#edit-co', el).onclick = async () => {
    await formModal({ title: 'Edit company', wide: true, fields: COMPANY_FIELDS(), values: c,
      onSave: d => API.put('/companies/' + c.id, d) });
    toast('Company updated'); render();
  };
  $('#add-ent', el).onclick = () => entityForm();
  $('#sync-uni', el).onclick = async () => { const r = await guard(() => API.post(`/companies/${c.id}/universe/populate`)); toast(`${r.added} auditable units added`); render(); };
  $$('[data-edit]', el).forEach(b => b.onclick = () => entityForm(State.entities.find(e => String(e.id) === b.dataset.edit)));
  $$('[data-del]', el).forEach(b => b.onclick = async () => {
    if (!await confirmBox('Delete this entity and its audit universe entries?', 'Delete')) return;
    await guard(() => API.del('/entities/' + b.dataset.del), 'Entity deleted'); render();
  });
}

async function entityForm(e) {
  const fields = [
    { k: 'name', label: 'Entity name', required: true, full: true },
    { k: 'entity_type', label: 'Type', type: 'select', options: enums('entity_types'), blank: false },
    { k: 'parent_id', label: 'Parent entity', type: 'select', options: entityOptions().filter(o => !e || o.value !== e.id) },
    { k: 'country', label: 'Country', type: 'select', options: enums('countries') },
    { k: 'currency', label: 'Functional currency', type: 'select', options: enums('currencies'), blank: false },
    { k: 'industry', label: 'Industry', type: 'select', options: State.meta.industries, help: 'Blank = all company industries' },
    { k: 'ownership_pct', label: 'Ownership %', type: 'number', default: 100 },
    { k: 'entity_head', label: 'Entity head / CEO' },
  ];
  await formModal({ title: e ? 'Edit entity' : 'Add entity', fields, values: e || { currency: State.company.base_currency, entity_type: 'Subsidiary' },
    onSave: d => { d.company_id = State.companyId; return e ? API.put('/entities/' + e.id, d) : API.post('/entities', d); } });
  toast('Entity saved');
  if (!e) await API.post(`/companies/${State.companyId}/universe/populate`);
  render();
}

/* ---------------- team */
async function viewTeam(el) {
  await refreshCompanyLists();
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Audit Team</h1><p>Internal auditors, reviewers and co-source resources</p></div>
    <div class="actions"><button class="btn primary" id="add">+ Add team member</button></div></div>
    <div class="card"><div class="card-b flush">${tableHtml([
      { label: 'Name', render: a => `<b>${esc(a.name)}</b>` }, { label: 'Role', key: 'role' },
      { label: 'Designation', key: 'designation' }, { label: 'Email', key: 'email' }, { label: 'Certifications', key: 'certifications' },
      { label: '', cls: 'right', render: a => `<button class="btn sm" data-edit="${a.id}">Edit</button> <button class="btn sm danger" data-del="${a.id}">Remove</button>` },
    ], State.auditors, { empty: 'Add your audit team so you can assign engagements and sign off workpapers' })}</div></div>`;
  const form = a => formModal({ title: a ? 'Edit team member' : 'Add team member', values: a, fields: [
    { k: 'name', label: 'Full name', required: true }, { k: 'role', label: 'Role', type: 'select', options: enums('auditor_roles') },
    { k: 'designation', label: 'Designation' }, { k: 'email', label: 'Email', type: 'email' },
    { k: 'certifications', label: 'Certifications', placeholder: 'CIA, CISA, ACCA ...', full: true }],
    onSave: d => { d.company_id = State.companyId; return a ? API.put('/auditors/' + a.id, d) : API.post('/auditors', d); } }).then(render);
  $('#add', el).onclick = () => form();
  $$('[data-edit]', el).forEach(b => b.onclick = () => form(State.auditors.find(a => String(a.id) === b.dataset.edit)));
  $$('[data-del]', el).forEach(b => b.onclick = async () => { await guard(() => API.del('/auditors/' + b.dataset.del), 'Removed'); render(); });
}

route('company', viewCompany);
route('team', viewTeam);
