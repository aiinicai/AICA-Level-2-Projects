/* App bootstrap, shell layout and routing. */
'use strict';

const NAV = [
  ['Overview', [['dashboard', '▣', 'Dashboard']]],
  ['Setup', [['company', '\u{1F3E2}', 'Company & Entities'], ['team', '\u{1F465}', 'Audit Team']]],
  ['Planning', [['universe', '\u{1F310}', 'Audit Universe & Risk'], ['plans', '\u{1F5D3}', 'Audit Plans']]],
  ['Execution', [['engagements', '\u{1F4C1}', 'Engagements'], ['findings', '⚠', 'Findings & Actions'], ['analytics', '\u{1F4C8}', 'Data Analytics'], ['sampling', '\u{1F3B2}', 'Sampling']]],
  ['Knowledge & Reporting', [['library', '\u{1F4DA}', 'Procedure Library'], ['reports', '\u{1F4CA}', 'Reports Centre'], ['activity', '\u{1F552}', 'Audit Trail']]],
];

function shellHtml(active) {
  const c = State.company;
  return `<div class="shell"><aside class="sidebar">
      <div class="brand"><div class="logo">IA</div><div><div class="name">AuditPro</div><div class="sub">Internal Audit Management</div></div></div>
      <div class="company-chip" id="switch" title="Switch company"><div class="cname">${esc(c.name)}</div><div class="ctype">${esc(c.company_type)} &middot; ${State.entities.length} entit${State.entities.length === 1 ? 'y' : 'ies'} &middot; switch ⇄</div></div>
      ${NAV.map(([sec, items]) => `<div class="nav-section">${sec}</div><nav class="nav">${items.map(([k, ico, label]) =>
        `<a href="#/${k}" class="${active === k || (active === 'engagement' && k === 'engagements') ? 'active' : ''}"><span class="ico">${ico}</span>${label}</a>`).join('')}</nav>`).join('')}
      <div class="foot">Local SQLite database &middot; v1.0</div></aside>
    <main class="main"><div class="topbar"><div class="crumbs"><b>${esc(c.name)}</b> &middot; ${esc((c.industries || []).join(', '))}</div><div class="spacer"></div>
      <button class="btn sm" onclick="newEngagement()">+ Engagement</button><button class="btn sm" id="switch2">Switch company</button></div>
      <div class="content" id="view"><div class="spinner"></div></div></main></div>`;
}

async function render() {
  const app = $('#app');
  if (!State.company) {
    if (location.hash) history.replaceState(null, '', location.pathname);
    app.innerHTML = '<div class="spinner"></div>';
    try { await viewLanding(app); } catch (e) { app.innerHTML = `<div class="empty">Failed to load: ${esc(e.message)}</div>`; }
    return;
  }
  const parts = (location.hash || '#/dashboard').replace(/^#\/?/, '').split('/');
  const name = Routes[parts[0]] ? parts[0] : 'dashboard';
  app.innerHTML = shellHtml(name);
  const switchCo = () => { State.company = null; State.remember(''); render(); };
  $('#switch').onclick = switchCo;
  $('#switch2').onclick = switchCo;
  const view = $('#view');
  try {
    await Routes[name](view, parts.slice(1));
  } catch (e) {
    console.error(e);
    view.innerHTML = `<div class="card"><div class="empty"><div class="big">⚠</div>${esc(e.message)}</div></div>`;
  }
}

window.addEventListener('hashchange', () => { $('#modal-root').innerHTML = ''; render(); });

(async function boot() {
  try {
    State.meta = await API.get('/meta');
  } catch (e) {
    $('#app').innerHTML = `<div class="empty">Cannot reach the AuditPro server. Start it with run_app.bat.<br>${esc(e.message)}</div>`;
    return;
  }
  const saved = State.recall();
  if (saved) {
    try {
      State.company = await API.get('/companies/' + saved);
      await refreshCompanyLists();
    } catch (e) { State.company = null; State.remember(''); }
  }
  render();
})();
