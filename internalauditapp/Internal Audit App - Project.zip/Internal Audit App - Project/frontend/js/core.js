/* AuditPro core: API client, state, UI helpers, form builder, charts, router. */
'use strict';

const API = {
  async req(method, url, data, isForm) {
    const opts = { method, headers: {} };
    if (data !== undefined) {
      if (isForm) opts.body = data;
      else { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(data); }
    }
    const res = await fetch('/api' + url, opts);
    let json;
    try { json = await res.json(); } catch (e) { throw new Error('Server error (' + res.status + ')'); }
    if (!res.ok || json.ok === false) throw new Error(json.error || 'Request failed');
    return json.data;
  },
  get(u) { return this.req('GET', u); },
  post(u, d) { return this.req('POST', u, d || {}); },
  put(u, d) { return this.req('PUT', u, d); },
  del(u) { return this.req('DELETE', u); },
  upload(u, form) { return this.req('POST', u, form, true); },
  download(u) { window.location.href = '/api' + u; },
};

const State = {
  meta: null,
  company: null,
  auditors: [],
  entities: [],
  get companyId() { return this.company ? this.company.id : null; },
  remember(id) { try { localStorage.setItem('auditpro.company', id || ''); } catch (e) { /* storage unavailable */ } },
  recall() { try { return localStorage.getItem('auditpro.company'); } catch (e) { return null; } },
};

/* ---------------- helpers */
const $ = (sel, root) => (root || document).querySelector(sel);
const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
function fmtDate(s) {
  if (!s) return '-';
  const d = new Date(String(s).slice(0, 10) + 'T00:00:00');
  if (isNaN(d)) return esc(s);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}
function fmtNum(n, dp) { if (n === null || n === undefined || n === '') return '-'; return Number(n).toLocaleString('en-US', { maximumFractionDigits: dp === undefined ? 0 : dp, minimumFractionDigits: dp || 0 }); }
function today() { return new Date().toISOString().slice(0, 10); }
function truncate(s, n) { s = s || ''; return s.length > n ? s.slice(0, n - 1) + '…' : s; }
function nl2br(s) { return esc(s).replace(/\n/g, '<br>'); }

const RATING_CLASS = { Critical: 'b-critical', High: 'b-high', Medium: 'b-medium', Low: 'b-low' };
const STATUS_CLASS = {
  Planned: 'b-grey', Planning: 'b-blue', Fieldwork: 'b-amber', Reporting: 'b-navy', Closed: 'b-green', Cancelled: 'b-grey',
  Open: 'b-red', 'In Progress': 'b-amber', Implemented: 'b-green', 'Risk Accepted': 'b-grey', Overdue: 'b-critical',
  'Not Started': 'b-grey', Prepared: 'b-blue', Reviewed: 'b-green',
  'Not Tested': 'b-grey', Effective: 'b-green', 'Partially Effective': 'b-amber', Ineffective: 'b-red', 'Not Applicable': 'b-grey',
  Requested: 'b-amber', 'Partially Received': 'b-blue', Received: 'b-green',
  Draft: 'b-grey', Submitted: 'b-blue', Approved: 'b-green', 'In Execution': 'b-amber', Cleared: 'b-green',
  Satisfactory: 'b-green', 'Needs Improvement': 'b-amber', 'Needs Significant Improvement': 'b-medium', Unsatisfactory: 'b-red',
};
function badge(v, cls) { if (!v) return '<span class="muted">-</span>'; return `<span class="badge ${cls || RATING_CLASS[v] || STATUS_CLASS[v] || ''}">${esc(v)}</span>`; }
function riskBadge(level, score) { const c = level === 'High' ? 'b-high' : level === 'Medium' ? 'b-medium' : 'b-low'; return `<span class="badge ${c}">${esc(level)}${score !== undefined ? ' · ' + score : ''}</span>`; }
function progress(pct) { return `<div class="progress" title="${pct}%"><div style="width:${Math.min(100, pct || 0)}%"></div></div>`; }

function toast(msg, isErr) {
  const el = document.createElement('div');
  el.className = 'toast' + (isErr ? ' err' : '');
  el.textContent = msg;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), isErr ? 6000 : 3000);
}
async function guard(fn, okMsg) {
  try { const r = await fn(); if (okMsg) toast(okMsg); return r; }
  catch (e) { toast(e.message, true); throw e; }
}

/* ---------------- modal */
function modal({ title, body, footer, wide, onOpen }) {
  const root = $('#modal-root');
  const bg = document.createElement('div');
  bg.className = 'modal-bg';
  bg.innerHTML = `<div class="modal ${wide ? 'wide' : ''}"><div class="modal-h"><h2>${esc(title)}</h2>
    <button class="icon-btn" data-close>✕</button></div><div class="modal-b">${body}</div>
    ${footer !== false ? `<div class="modal-f">${footer || '<button class="btn" data-close>Close</button>'}</div>` : ''}</div>`;
  const close = () => bg.remove();
  bg.addEventListener('click', e => { if (e.target === bg || e.target.closest('[data-close]')) close(); });
  root.appendChild(bg);
  if (onOpen) onOpen(bg, close);
  return { el: bg, close };
}
function confirmBox(message, okLabel) {
  return new Promise(resolve => {
    const m = modal({
      title: 'Please confirm', body: `<p>${esc(message)}</p>`,
      footer: `<button class="btn" data-close>Cancel</button><button class="btn primary" id="cf-ok">${esc(okLabel || 'Confirm')}</button>`,
    });
    $('#cf-ok', m.el).onclick = () => { m.close(); resolve(true); };
  });
}

/* ---------------- form builder
   field: {k, label, type: text|textarea|select|date|number|checkbox|checks|email, options, full, required, help} */
function fieldHtml(f, val) {
  const id = 'f_' + f.k;
  const v = val === undefined || val === null ? (f.default !== undefined ? f.default : '') : val;
  let input;
  const opts = typeof f.options === 'function' ? f.options() : (f.options || []);
  const optHtml = (selected) => opts.map(o => {
    const ov = typeof o === 'object' ? o.value : o, ol = typeof o === 'object' ? o.label : o;
    return `<option value="${esc(ov)}" ${String(ov) === String(selected) ? 'selected' : ''}>${esc(ol)}</option>`;
  }).join('');
  switch (f.type) {
    case 'textarea': input = `<textarea id="${id}" name="${f.k}" rows="${f.rows || 3}">${esc(v)}</textarea>`; break;
    case 'select': input = `<select id="${id}" name="${f.k}">${f.blank !== false ? '<option value="">-- Select --</option>' : ''}${optHtml(v)}</select>`; break;
    case 'checkbox': input = `<label class="check"><input type="checkbox" id="${id}" name="${f.k}" ${v ? 'checked' : ''}> ${esc(f.text || 'Yes')}</label>`; break;
    case 'checks': {
      const sel = Array.isArray(v) ? v.map(String) : [];
      input = `<div class="checks" data-checks="${f.k}">${opts.map(o => {
        const ov = typeof o === 'object' ? o.value : o, ol = typeof o === 'object' ? o.label : o;
        return `<label class="check"><input type="checkbox" value="${esc(ov)}" ${sel.includes(String(ov)) ? 'checked' : ''}> ${esc(ol)}</label>`;
      }).join('')}</div>`;
      break;
    }
    default: input = `<input type="${f.type || 'text'}" id="${id}" name="${f.k}" value="${esc(v)}" ${f.step ? `step="${f.step}"` : ''} ${f.min !== undefined ? `min="${f.min}"` : ''} ${f.max !== undefined ? `max="${f.max}"` : ''} ${f.placeholder ? `placeholder="${esc(f.placeholder)}"` : ''}>`;
  }
  return `<div class="field ${f.full || f.type === 'textarea' || f.type === 'checks' ? 'full' : ''}">
    ${f.type === 'checkbox' ? '' : `<label class="f" for="${id}">${esc(f.label)}${f.required ? ' *' : ''}</label>`}${input}
    ${f.help ? `<div class="small muted" style="margin-top:4px">${esc(f.help)}</div>` : ''}</div>`;
}
function formHtml(fields, values) {
  return `<div class="form-grid">${fields.map(f => fieldHtml(f, (values || {})[f.k])).join('')}</div>`;
}
function readForm(root, fields) {
  const out = {};
  fields.forEach(f => {
    if (f.type === 'checks') {
      out[f.k] = $$(`[data-checks="${f.k}"] input:checked`, root).map(i => i.value);
    } else if (f.type === 'checkbox') {
      out[f.k] = $(`#f_${f.k}`, root).checked ? 1 : 0;
    } else {
      const el = $(`#f_${f.k}`, root);
      if (!el) return;
      let v = el.value;
      if (f.type === 'number') v = v === '' ? null : Number(v);
      out[f.k] = v;
    }
  });
  return out;
}
/* Opens a modal form; resolves the saved result of onSave. */
function formModal({ title, fields, values, onSave, wide, saveLabel, intro }) {
  return new Promise(resolve => {
    const m = modal({
      title, wide,
      body: (intro || '') + formHtml(fields, values),
      footer: `<button class="btn" data-close>Cancel</button><button class="btn primary" id="fm-save">${esc(saveLabel || 'Save')}</button>`,
    });
    $('#fm-save', m.el).onclick = async () => {
      const data = readForm(m.el, fields);
      const missing = fields.filter(f => f.required && (data[f.k] === '' || data[f.k] === null || (Array.isArray(data[f.k]) && !data[f.k].length)));
      if (missing.length) { toast('Required: ' + missing.map(f => f.label).join(', '), true); return; }
      const btn = $('#fm-save', m.el);
      btn.disabled = true;
      try { const r = await onSave(data); m.close(); resolve(r); }
      catch (e) { toast(e.message, true); btn.disabled = false; }
    };
  });
}

/* ---------------- table builder
   cols: [{label, render(row) | key, cls}] */
function tableHtml(cols, rows, opts) {
  opts = opts || {};
  if (!rows || !rows.length) return `<div class="empty"><div class="big">${opts.emptyIcon || '\u{1F4C2}'}</div>${esc(opts.empty || 'No records yet')}</div>`;
  return `<div class="table-wrap"><table class="t"><thead><tr>${cols.map(c => `<th class="${c.cls || ''}">${esc(c.label)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map((r, i) => `<tr class="${opts.onRow ? 'click' : ''}" data-i="${i}">${cols.map(c => `<td class="${c.cls || ''}">${c.render ? c.render(r) : esc(r[c.key])}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function bindRows(root, rows, fn) {
  $$('tbody tr[data-i]', root).forEach(tr => tr.addEventListener('click', e => {
    if (e.target.closest('button, a, input, select')) return;
    fn(rows[Number(tr.dataset.i)]);
  }));
}

/* ---------------- charts (inline SVG, no external libraries) */
const PALETTE = ['#2e75b6', '#1f3a5f', '#e67e22', '#27ae60', '#c0392b', '#8e44ad', '#16a085', '#7f8c8d'];
const COLOR_FOR = {
  Critical: '#7b1e1e', High: '#c0392b', Medium: '#e67e22', Low: '#2e8b57',
  Planned: '#bdc3c7', Planning: '#85c1e9', Fieldwork: '#2e75b6', Reporting: '#f5b041', Closed: '#27ae60', Cancelled: '#7f8c8d',
  Open: '#85c1e9', 'In Progress': '#2e75b6', Overdue: '#c0392b', Implemented: '#27ae60', 'Risk Accepted': '#95a5a6',
};
function donut(data, opts) {
  opts = opts || {};
  const entries = Object.entries(data || {}).filter(([, v]) => v > 0);
  const total = entries.reduce((s, [, v]) => s + v, 0);
  if (!total) return `<div class="empty">No data</div>`;
  const R = 62, r = 40, cx = 80, cy = 80;
  let a0 = -Math.PI / 2, paths = '';
  entries.forEach(([k, v], i) => {
    const a1 = a0 + (v / total) * Math.PI * 2;
    const large = a1 - a0 > Math.PI ? 1 : 0;
    const p = (rad, ang) => `${cx + rad * Math.cos(ang)},${cy + rad * Math.sin(ang)}`;
    const col = COLOR_FOR[k] || PALETTE[i % PALETTE.length];
    if (entries.length === 1) {
      paths += `<circle cx="${cx}" cy="${cy}" r="${(R + r) / 2}" fill="none" stroke="${col}" stroke-width="${R - r}"/>`;
    } else {
      paths += `<path d="M${p(R, a0)} A${R},${R} 0 ${large} 1 ${p(R, a1)} L${p(r, a1)} A${r},${r} 0 ${large} 0 ${p(r, a0)} Z" fill="${col}"><title>${esc(k)}: ${v}</title></path>`;
    }
    a0 = a1;
  });
  return `<div style="display:flex;align-items:center;gap:18px;flex-wrap:wrap">
    <svg viewBox="0 0 160 160" width="150" height="150">${paths}
      <text x="80" y="78" text-anchor="middle" font-size="24" font-weight="700" fill="#1e2a38">${total}</text>
      <text x="80" y="96" text-anchor="middle" font-size="10" fill="#6b7a8c">${esc(opts.label || 'Total')}</text></svg>
    <div class="legend" style="flex-direction:column;margin:0">${entries.map(([k, v], i) =>
      `<div><span class="dot" style="background:${COLOR_FOR[k] || PALETTE[i % PALETTE.length]}"></span>${esc(k)} <b style="color:#1e2a38">${v}</b></div>`).join('')}</div></div>`;
}
function hbars(pairs, opts) {
  opts = opts || {};
  if (!pairs || !pairs.length) return `<div class="empty">No data</div>`;
  const max = Math.max(...pairs.map(p => p[1])) || 1;
  return `<div class="bars">${pairs.map(([k, v]) => `<div class="row"><div class="lbl" title="${esc(k)}">${esc(k)}</div>
    <div><div class="bar" style="width:${(v / max) * 100}%;background:${opts.color || COLOR_FOR[k] || 'var(--accent)'}"></div></div><div class="right"><b>${fmtNum(v)}</b></div></div>`).join('')}</div>`;
}
function columns(labels, series, opts) {
  opts = opts || {};
  const W = 560, H = 220, pad = 30;
  const max = Math.max(1, ...series.flatMap(s => s.values));
  const gw = (W - pad * 2) / labels.length;
  const bw = Math.min(28, (gw - 8) / series.length);
  let bars = '';
  labels.forEach((l, i) => {
    series.forEach((s, j) => {
      const v = s.values[i] || 0, h = (v / max) * (H - 60);
      const x = pad + i * gw + (gw - bw * series.length) / 2 + j * bw;
      bars += `<rect x="${x}" y="${H - 30 - h}" width="${bw - 2}" height="${h}" rx="2" fill="${s.color}"><title>${esc(s.name)} ${esc(l)}: ${v}</title></rect>`;
      if (opts.values) bars += `<text x="${x + bw / 2 - 1}" y="${H - 34 - h}" font-size="9" text-anchor="middle" fill="#6b7a8c">${v}</text>`;
    });
    bars += `<text x="${pad + i * gw + gw / 2}" y="${H - 12}" font-size="10" text-anchor="middle" fill="#6b7a8c">${esc(truncate(l, 14))}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}"><line x1="${pad}" y1="${H - 30}" x2="${W - pad}" y2="${H - 30}" stroke="#e1e6ee"/>${bars}</svg>
    <div class="legend">${series.map(s => `<span><span class="dot" style="background:${s.color}"></span>${esc(s.name)}</span>`).join('')}</div>`;
}
function heatmap(cells) {
  // cells: {"impact-likelihood": count}
  let html = '<div class="heat">';
  for (let imp = 5; imp >= 1; imp--) {
    html += `<div class="ax">${imp}</div>`;
    for (let lik = 1; lik <= 5; lik++) {
      const s = imp * lik;
      const col = s >= 15 ? '#c0392b' : s >= 8 ? '#e67e22' : s >= 4 ? '#f1c40f' : '#58d68d';
      const n = (cells || {})[imp + '-' + lik] || '';
      html += `<div class="c" style="background:${col}" title="Impact ${imp} x Likelihood ${lik}: ${n || 0} unit(s)">${n}</div>`;
    }
  }
  html += '<div></div>' + [1, 2, 3, 4, 5].map(i => `<div class="ax">${i}</div>`).join('') + '</div>';
  return html + '<div class="legend" style="justify-content:space-between"><span>↑ Impact</span><span>Likelihood →</span></div>';
}

/* ---------------- router */
const Routes = {};
function route(name, fn) { Routes[name] = fn; }
function go(hash) { if (location.hash === hash) render(); else location.hash = hash; }

function auditorOptions() { return State.auditors.map(a => a.name); }
function entityOptions() { return State.entities.map(e => ({ value: e.id, label: e.name })); }
function entityName(id) { const e = State.entities.find(x => String(x.id) === String(id)); return e ? e.name : ''; }
function enums(k) { return (State.meta && State.meta.enums[k]) || []; }
