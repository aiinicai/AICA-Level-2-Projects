/* Data analytics, sampling, procedure library, reports centre, audit trail. */
'use strict';

/* ---------------- data analytics */
const MAP_FIELDS = [['amount', 'Amount'], ['date', 'Date'], ['party', 'Vendor / Customer / Party'], ['doc_no', 'Document no.'], ['user', 'Created by (user)'], ['approver', 'Approved by']];
let AN = null; // current upload

async function viewAnalytics(el) {
  const [runs, engs] = await Promise.all([API.get('/analytics/runs?company_id=' + State.companyId), API.get('/engagements?company_id=' + State.companyId)]);
  const tests = State.meta.analytics_tests;
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Data Analytics (CAATs)</h1>
      <p>Upload a transaction extract (CSV or Excel - AP invoices, payments, journals, sales, receipts ...) and run full-population tests.</p></div></div>
    <div class="grid g3 mb">
      <div class="card"><div class="card-h"><h3>1. Upload data</h3></div><div class="card-b">
        <input type="file" id="file" accept=".csv,.txt,.xlsx,.xlsm"><div class="mt"><button class="btn primary" id="up">Upload &amp; preview</button></div>
        <div id="upinfo" class="small muted mt">${AN ? `Loaded <b>${esc(AN.file_name)}</b> - ${fmtNum(AN.rows)} records, ${AN.headers.length} columns` : 'No file loaded'}</div></div></div>
      <div class="card"><div class="card-h"><h3>2. Map columns</h3></div><div class="card-b" id="mapping">${AN ? mappingHtml() : '<p class="muted">Upload a file first.</p>'}</div></div>
      <div class="card"><div class="card-h"><h3>3. Choose test</h3></div><div class="card-b">
        <div class="field"><select id="test">${tests.map(t => `<option value="${t.key}">${esc(t.name)}</option>`).join('')}</select></div>
        <p class="small muted" id="tdesc"></p><div id="params"></div>
        <div class="field"><label class="f">Link to engagement (optional)</label><select id="eng"><option value="">-- None --</option>${engs.map(e => `<option value="${e.id}">${esc(e.ref)} ${esc(truncate(e.title, 40))}</option>`).join('')}</select></div>
        <button class="btn primary" id="run" ${AN ? '' : 'disabled'}>▶ Run test</button></div></div></div>
    <div id="result"></div>
    ${AN ? `<div class="card mb"><div class="card-h"><h3>Data preview (first 15 rows)</h3></div><div class="card-b flush">${tableHtml(AN.headers.map(h => ({ label: h, render: r => esc(truncate(r[h], 40)) })), AN.preview)}</div></div>` : ''}
    <div class="card"><div class="card-h"><h3>Analytics history</h3></div><div class="card-b flush">${tableHtml([
      { label: 'Run on', key: 'run_on' }, { label: 'Test', render: r => esc((tests.find(t => t.key === r.test) || {}).name || r.test) },
      { label: 'File', key: 'file_name' }, { label: 'Records', cls: 'right', render: r => fmtNum(r.total_records) },
      { label: 'Exceptions', cls: 'right', render: r => r.exceptions ? `<b style="color:#c0392b">${fmtNum(r.exceptions)}</b>` : '0' },
      { label: '', cls: 'right', render: r => `<button class="btn sm" onclick="API.download('/analytics/runs/${r.id}/export')">⬇ Excel</button> <button class="btn sm danger" data-del="${r.id}">✕</button>` },
    ], runs, { empty: 'No analytics run yet' })}</div></div>`;
  const showParams = () => {
    const t = tests.find(x => x.key === $('#test', el).value);
    $('#tdesc', el).innerHTML = `${esc(t.description)}<br><b>Requires:</b> ${t.needs.join(', ')}${t.optional.length ? ' &middot; optional: ' + t.optional.join(', ') : ''}`;
    $('#params', el).innerHTML = Object.entries(t.params).map(([k, v]) => `<div class="field"><label class="f">${esc(k.replace(/_/g, ' '))}</label><input type="text" data-p="${k}" value="${esc(v)}"></div>`).join('');
  };
  $('#test', el).onchange = showParams;
  showParams();
  $('#up', el).onclick = async () => {
    const f = $('#file', el).files[0];
    if (!f) return toast('Choose a file', true);
    const fd = new FormData(); fd.append('file', f);
    $('#up', el).disabled = true;
    try { AN = await API.upload('/analytics/upload', fd); toast(`Loaded ${AN.rows} records`); render(); }
    catch (e) { toast(e.message, true); $('#up', el).disabled = false; }
  };
  $('#run', el).onclick = async () => {
    const mapping = {}; $$('[data-map]', el).forEach(s => { if (s.value) mapping[s.dataset.map] = s.value; });
    const params = {}; $$('[data-p]', el).forEach(i => { params[i.dataset.p] = i.value; });
    $('#result', el).innerHTML = '<div class="spinner"></div>';
    try {
      const r = await API.post('/analytics/run', { token: AN.token, file_name: AN.file_name, test: $('#test', el).value, mapping, params, company_id: State.companyId, engagement_id: $('#eng', el).value || null });
      $('#result', el).innerHTML = resultHtml(r, tests.find(t => t.key === $('#test', el).value));
      el.querySelector('#result').scrollIntoView({ behavior: 'smooth' });
    } catch (e) { $('#result', el).innerHTML = ''; toast(e.message, true); }
  };
  $$('[data-del]', el).forEach(b => b.onclick = async () => { await guard(() => API.del('/analytics/runs/' + b.dataset.del)); render(); });
}
function mappingHtml() {
  return MAP_FIELDS.map(([k, l]) => `<div class="field"><label class="f">${l}</label><select data-map="${k}"><option value="">-- not mapped --</option>
    ${AN.headers.map(h => `<option ${AN.mapping[k] === h ? 'selected' : ''}>${esc(h)}</option>`).join('')}</select></div>`).join('');
}
function resultHtml(r, t) {
  const s = r.summary;
  let chart = '';
  if (r.chart && r.chart.type === 'benford') chart = columns(r.chart.labels, [{ name: 'Actual %', values: r.chart.actual, color: '#2e75b6' }, { name: 'Benford expected %', values: r.chart.expected, color: '#bdc3c7' }], { values: true });
  if (r.chart && r.chart.type === 'bars') chart = hbars(r.chart.labels.map((l, i) => [l, r.chart.values[i]]), { color: '#1f3a5f' });
  const cols = (r.columns || []).slice(0, 14);
  return `<div class="card mb"><div class="card-h"><h3>Results - ${esc(t.name)}</h3>
      <button class="btn sm primary" onclick="API.download('/analytics/runs/${r.run_id}/export')">⬇ Export exceptions to Excel</button></div>
    <div class="card-b"><div class="grid g4 mb">${Object.entries(s).map(([k, v]) => `<div><div class="small muted">${esc(k.replace(/_/g, ' '))}</div><h2>${typeof v === 'number' ? fmtNum(v, Number.isInteger(v) ? 0 : 2) : esc(v)}</h2></div>`).join('')}</div>
      ${chart ? `<div class="mb">${chart}</div>` : ''}
      ${r.table ? `<div class="mb">${tableHtml(Object.keys(r.table[0]).map(k => ({ label: k.replace(/_/g, ' '), render: row => esc(typeof row[k] === 'number' ? fmtNum(row[k], 2) : row[k]) })), r.table)}</div>` : ''}
      <h3 style="margin-bottom:8px">Exceptions ${r.exceptions_total > 500 ? `(showing 500 of ${fmtNum(r.exceptions_total)})` : `(${r.exceptions_total})`}</h3>
      ${tableHtml(cols.map(c => ({ label: c === '_reason' ? 'Reason' : c, render: row => c === '_reason' ? `<span class="badge b-red">${esc(row[c])}</span>` : esc(truncate(row[c] === null || row[c] === undefined ? '' : String(row[c]), 50)) })), r.exceptions_preview, { empty: 'No exceptions identified', emptyIcon: '✅' })}
    </div></div>`;
}

/* ---------------- sampling */
function viewSampling(el) {
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Sampling Calculator</h1><p>Determine and document sample sizes and perform reproducible random selections</p></div></div>
    <div class="grid g3">
      <div class="card"><div class="card-h"><h3>Control frequency method</h3></div><div class="card-b">
        ${formHtml([{ k: 'frequency', label: 'Control frequency', type: 'select', blank: false, options: ['Annual', 'Quarterly', 'Monthly', 'Weekly', 'Daily', 'Multiple times a day', 'Event-driven'] },
          { k: 'nature', label: 'Control nature', type: 'select', blank: false, options: ['Manual', 'IT-dependent Manual', 'Automated'] },
          { k: 'risk', label: 'Risk of failure', type: 'select', blank: false, options: ['Low', 'Medium', 'High'], default: 'Medium' },
          { k: 'population', label: 'Population (optional)', type: 'number' }])}
        <button class="btn primary" data-m="frequency">Calculate</button><div class="mt" id="out-frequency"></div>
        <p class="small muted mt">Guidance: Annual 1, Quarterly 2, Monthly 2-5, Weekly 5-15, Daily 20-40, Multiple/day 25-60, Automated 1 (with effective ITGCs).</p></div></div>
      <div class="card"><div class="card-h"><h3>Attribute (statistical) sampling</h3></div><div class="card-b" id="attr">
        ${formHtml([{ k: 'confidence', label: 'Confidence level %', type: 'select', blank: false, options: ['90', '95', '99'], default: '95' },
          { k: 'tolerable_rate', label: 'Tolerable deviation rate %', type: 'number', default: 10 },
          { k: 'expected_errors', label: 'Expected deviations', type: 'number', default: 0 },
          { k: 'population', label: 'Population (optional)', type: 'number' }])}
        <button class="btn primary" data-m="attribute">Calculate</button><div class="mt" id="out-attribute"></div></div></div>
      <div class="card"><div class="card-h"><h3>Monetary unit sampling</h3></div><div class="card-b" id="mus">
        ${formHtml([{ k: 'book_value', label: 'Population book value', type: 'number' }, { k: 'tolerable_misstatement', label: 'Tolerable misstatement', type: 'number' },
          { k: 'confidence', label: 'Confidence level %', type: 'select', blank: false, options: ['90', '95', '99'], default: '95' }])}
        <button class="btn primary" data-m="mus">Calculate</button><div class="mt" id="out-mus"></div></div></div>
    </div>
    <div class="card mt"><div class="card-h"><h3>Random sample selection</h3></div><div class="card-b">
      <div class="grid g4"><div class="field"><label class="f">Population size</label><input type="number" id="rs-pop"></div>
        <div class="field"><label class="f">Sample size</label><input type="number" id="rs-n"></div>
        <div class="field"><label class="f">Seed (optional, for re-performance)</label><input type="number" id="rs-seed"></div>
        <div class="field"><label class="f">&nbsp;</label><button class="btn primary" id="rs-go">Select items</button></div></div>
      <div id="rs-out"></div></div></div>`;
  $$('[data-m]', el).forEach(b => b.onclick = async () => {
    const card = b.closest('.card-b');
    const data = { method: b.dataset.m };
    $$('input, select', card).forEach(i => { if (i.name) data[i.name] = i.value; });
    const r = await guard(() => API.post('/sampling/size', data));
    $('#out-' + b.dataset.m, el).innerHTML = `<div class="kpi card" style="--kpi-c:#27ae60"><div class="label">Sample size</div><div class="value">${r.sample_size}</div><div class="hint">${esc(r.basis)}</div></div>`;
  });
  $('#rs-go', el).onclick = async () => {
    const r = await guard(() => API.post('/sampling/select', { population: $('#rs-pop', el).value, size: $('#rs-n', el).value, seed: $('#rs-seed', el).value }));
    $('#rs-out', el).innerHTML = `<p><b>Seed:</b> ${r.seed} &nbsp; <b>Items selected:</b> ${r.items.length}</p><div class="pill-list">${r.items.map(i => `<span class="badge b-blue">#${i}</span>`).join('')}</div>`;
  };
}

/* ---------------- procedure library */
async function viewLibrary(el) {
  const lib = await ensureLibrary();
  const industries = ['Common'].concat(State.meta.industries);
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Audit Procedure Library</h1>
      <p>${lib.length} processes &middot; ${lib.reduce((s, p) => s + p.items, 0)} risks, controls &amp; test procedures (RACM) &middot; aligned to IIA Standards &amp; COSO 2013</p></div></div>
    <div class="card mb"><div class="toolbar"><input type="search" class="search" id="q" placeholder="Search processes...">
      <select id="fi"><option value="">All industries</option>${industries.map(i => `<option>${esc(i)}</option>`).join('')}</select></div></div>
    <div id="list"></div>`;
  const draw = () => {
    const q = $('#q', el).value.toLowerCase(), fi = $('#fi', el).value;
    $('#list', el).innerHTML = industries.filter(i => !fi || i === fi).map(ind => {
      const ps = lib.filter(p => p.industry === ind && (!q || (p.name + ' ' + p.description).toLowerCase().includes(q)));
      if (!ps.length) return '';
      return `<h2 style="margin:14px 0 10px">${esc(ind === 'Common' ? 'Common business processes' : ind)}</h2><div class="grid g3">${ps.map(p => `
        <div class="card card-b" style="cursor:pointer" data-code="${esc(p.code)}"><div class="small muted">${esc(p.code)}</div><h3 style="margin:3px 0 6px">${esc(p.name)}</h3>
          <p class="small muted">${esc(truncate(p.description, 160))}</p>
          <div class="pill-list"><span class="badge b-blue">${p.items} controls</span><span class="badge b-navy">${p.key_controls} key</span></div></div>`).join('')}</div>`;
    }).join('') || '<div class="card"><div class="empty">No processes match</div></div>';
    $$('[data-code]', el).forEach(c => c.onclick = () => libraryDetail(c.dataset.code));
  };
  $('#q', el).oninput = draw; $('#fi', el).onchange = draw;
  draw();
}
async function libraryDetail(code) {
  const p = await API.get('/library/' + code);
  const list = arr => `<ul class="steps">${(arr || []).map(x => `<li>${esc(x)}</li>`).join('')}</ul>`;
  const m = modal({ title: `${p.code} - ${p.name}`, wide: true,
    body: `<p>${esc(p.description)}</p>
      <div class="grid g3 mb"><div><h3>Audit objectives</h3>${list(p.objectives)}</div><div><h3>PBC / documents</h3>${list(p.pbc)}</div><div><h3>Analytics &amp; KPIs</h3>${list(p.analytics)}${list(p.kpis)}</div></div>
      <h3 style="margin-bottom:8px">Risk &amp; Control Matrix (${p.items.length})</h3>
      ${p.items.map(i => `<div class="lib-item"><div class="hdr"><b>${esc(i.risk_id)} / ${esc(i.control_id)}</b><span class="badge b-grey">${esc(i.subprocess)}</span>
          ${badge(i.risk_rating, i.risk_rating === 'High' ? 'b-high' : i.risk_rating === 'Low' ? 'b-low' : 'b-medium')} ${i.key_control ? badge('Key', 'b-navy') : ''} ${i.fraud_risk ? badge('Fraud', 'b-red') : ''}
          <span class="small muted">${esc(i.assertion)} &middot; ${esc(i.control_type)} &middot; ${esc(i.control_nature)} &middot; ${esc(i.frequency)}</span></div>
        <div class="wp"><div><div class="small muted">Risk</div>${esc(i.risk)}</div><div><div class="small muted">Control</div>${esc(i.control)}</div></div>
        <div class="small muted" style="margin-top:8px">Audit procedures</div><ol class="steps">${(i.procedures || []).map(s => `<li>${esc(s)}</li>`).join('')}</ol></div>`).join('')}`,
    footer: `<button class="btn" data-close>Close</button><button class="btn primary" id="lib-eng">+ Create engagement for this process</button>`,
  });
  $('#lib-eng', m.el).onclick = () => { m.close(); newEngagement({ title: p.name + ' Review', process_codes: [p.code] }); };
}

/* ---------------- reports centre */
async function viewReports(el) {
  const [engs, plans] = await Promise.all([API.get('/engagements?company_id=' + State.companyId), API.get('/plans?company_id=' + State.companyId)]);
  const years = Array.from(new Set(plans.map(p => p.year).concat([new Date().getFullYear()]))).sort().reverse();
  const cid = State.companyId;
  const tile = (icon, title, desc, action) => `<div class="card card-b"><div style="font-size:26px">${icon}</div><h3 style="margin:6px 0">${title}</h3><p class="small muted">${desc}</p>${action}</div>`;
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Reports Centre</h1><p>Board / Audit Committee packs, audit reports and trackers generated by the Python engine</p></div></div>
    <div class="grid g4 mb">
      ${tile('\u{1F4CA}', 'Board / Audit Committee presentation', 'PowerPoint pack: executive summary, plan progress, findings charts, significant findings, overdue actions, heat map, resources, matters for attention.',
        `<div class="actions"><select id="yr" style="width:auto"><option value="">All periods</option>${years.map(y => `<option>${y}</option>`).join('')}</select><button class="btn primary" id="ppt">⬇ PPTX</button></div>`)}
      ${tile('\u{1F4CB}', 'Findings & action tracker', 'Excel tracker of all findings with CCCER, management actions, due dates, overdue flags and follow-up history.', `<button class="btn primary" onclick="API.download('/reports/findings/${cid}/xlsx')">⬇ Excel</button>`)}
      ${tile('\u{1F310}', 'Audit universe & plan register', 'Excel export of the risk assessment for every auditable unit plus the engagement register.', `<button class="btn primary" onclick="API.download('/reports/universe/${cid}/xlsx')">⬇ Excel</button>`)}
      ${tile('\u{1F5D3}', 'Annual audit plan document', 'Word document of the risk-based audit plan for Audit Committee approval.',
        plans.length ? `<div class="actions"><select id="pl" style="width:auto">${plans.map(p => `<option value="${p.id}">${esc(p.title || p.year)}</option>`).join('')}</select><button class="btn primary" id="pdoc">⬇ DOCX</button></div>` : '<span class="muted small">Create a plan first</span>')}
    </div>
    <div class="card"><div class="card-h"><h3>Engagement reports</h3></div><div class="card-b flush">${tableHtml([
      { label: 'Ref', key: 'ref' }, { label: 'Engagement', key: 'title' }, { label: 'Entity', key: 'entity_name' },
      { label: 'Status', render: e => badge(e.status) }, { label: 'Rating', render: e => badge(e.overall_rating) },
      { label: '', cls: 'right', render: e => `<button class="btn sm" onclick="API.download('/reports/engagement/${e.id}/docx')">⬇ Audit report (Word)</button> <button class="btn sm" onclick="API.download('/reports/engagement/${e.id}/racm')">⬇ RACM (Excel)</button>` },
    ], engs, { empty: 'No engagements' })}</div></div>`;
  $('#ppt', el).onclick = () => API.download(`/reports/board/${cid}/pptx` + ($('#yr', el).value ? '?year=' + $('#yr', el).value : ''));
  if ($('#pdoc', el)) $('#pdoc', el).onclick = () => API.download(`/reports/plan/${cid}/${$('#pl', el).value}/docx`);
}

/* ---------------- audit trail */
async function viewActivity(el) {
  const rows = await API.get('/activity?company_id=' + State.companyId);
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Audit Trail</h1><p>Chronological log of changes made in this company file (last 500 events)</p></div></div>
    <div class="card"><div class="card-b flush">${tableHtml([
      { label: 'Timestamp', key: 'ts' }, { label: 'Object', key: 'entity' }, { label: 'ID', key: 'entity_id' },
      { label: 'Action', render: a => `<b>${esc(a.action)}</b>` }, { label: 'Details', cls: 'wrap', key: 'details' },
    ], rows, { empty: 'No activity yet' })}</div></div>`;
}

route('analytics', viewAnalytics);
route('sampling', viewSampling);
route('library', viewLibrary);
route('reports', viewReports);
route('activity', viewActivity);
