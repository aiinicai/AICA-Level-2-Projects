/* Dashboard, audit universe, plans, engagement list, findings tracker. */
'use strict';

/* ---------------- dashboard */
async function viewDashboard(el) {
  const d = await API.get('/dashboard?company_id=' + State.companyId);
  const k = d.kpis;
  const kpi = (label, value, hint, color) => `<div class="card kpi" style="--kpi-c:${color}"><div class="label">${label}</div><div class="value">${value}</div><div class="hint">${hint || ''}</div></div>`;
  const statusOrder = ['Planned', 'Planning', 'Fieldwork', 'Reporting', 'Closed'];
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Audit Dashboard</h1><p>${esc(State.company.name)} &middot; as of ${fmtDate(today())}</p></div>
    <div class="actions"><button class="btn" onclick="go('#/reports')">\u{1F4CA} Board presentation</button><button class="btn primary" onclick="newEngagement()">+ New engagement</button></div></div>
    <div class="grid g6 mb">
      ${kpi('Plan completion', k.plan_completion + '%', `${k.completed} of ${k.engagements} engagements`, '#2e75b6')}
      ${kpi('Open findings', k.open_findings, `${k.findings} raised in total`, '#1f3a5f')}
      ${kpi('Open Critical / High', k.open_high, 'Require senior attention', '#c0392b')}
      ${kpi('Overdue actions', k.overdue, 'Past agreed date', '#e67e22')}
      ${kpi('Implementation rate', k.implementation_rate + '%', 'Actions implemented / closed', '#27ae60')}
      ${kpi('High-risk units', k.high_risk_units, `of ${k.universe} in audit universe`, '#8e44ad')}
    </div>
    <div class="grid g3 mb">
      <div class="card"><div class="card-h"><h3>Engagement status</h3></div><div class="card-b">${donut(Object.fromEntries(statusOrder.map(s => [s, d.engagement_status[s] || 0])), { label: 'Engagements' })}</div></div>
      <div class="card"><div class="card-h"><h3>Findings by rating</h3></div><div class="card-b">${donut(Object.fromEntries(['Critical', 'High', 'Medium', 'Low'].map(s => [s, d.finding_ratings[s] || 0])), { label: 'Findings' })}</div></div>
      <div class="card"><div class="card-h"><h3>Action status</h3></div><div class="card-b">${donut(d.finding_status, { label: 'Actions' })}</div></div>
    </div>
    <div class="grid g3 mb">
      <div class="card"><div class="card-h"><h3>Inherent risk heat map</h3><a class="small" href="#/universe">Universe →</a></div><div class="card-b">${heatmap(d.heatmap)}</div></div>
      <div class="card"><div class="card-h"><h3>Findings by process</h3></div><div class="card-b">${hbars(d.by_process, { color: '#1f3a5f' })}</div></div>
      <div class="card"><div class="card-h"><h3>Open findings by entity</h3></div><div class="card-b">${hbars(d.by_entity, { color: '#2e75b6' })}</div></div>
    </div>
    <div class="grid g2 mb">
      <div class="card"><div class="card-h"><h3>Active engagements</h3><a class="small" href="#/engagements">All →</a></div><div class="card-b flush">${tableHtml([
        { label: 'Ref', render: e => `<a href="#/engagement/${e.id}">${esc(e.ref)}</a>` },
        { label: 'Engagement', render: e => esc(truncate(e.title, 46)) },
        { label: 'Status', render: e => badge(e.status) },
        { label: 'Progress', render: e => progress(e.progress) },
        { label: 'Hours', render: e => `${fmtNum(e.actual_hours)} / ${fmtNum(e.budget_hours)}` },
      ], d.active_engagements, { empty: 'No engagements in progress' })}</div></div>
      <div class="card"><div class="card-h"><h3>Overdue management actions</h3><a class="small" href="#/findings">Tracker →</a></div><div class="card-b flush">${tableHtml([
        { label: 'Ref', key: 'ref' }, { label: 'Finding', render: f => esc(truncate(f.title, 42)) },
        { label: 'Rating', render: f => badge(f.rating) }, { label: 'Owner', key: 'owner' },
        { label: 'Due', render: f => fmtDate(f.revised_due_date || f.due_date) },
      ], d.overdue_actions, { empty: 'No overdue actions', emptyIcon: '✅' })}</div></div>
    </div>
    <div class="grid g2">
      <div class="card"><div class="card-h"><h3>Upcoming action due dates</h3></div><div class="card-b flush">${tableHtml([
        { label: 'Ref', key: 'ref' }, { label: 'Finding', render: f => esc(truncate(f.title, 46)) },
        { label: 'Rating', render: f => badge(f.rating) }, { label: 'Due', render: f => fmtDate(f.revised_due_date || f.due_date) },
      ], d.upcoming_actions, { empty: 'Nothing due' })}</div></div>
      <div class="card"><div class="card-h"><h3>Recent activity</h3><a class="small" href="#/activity">Audit trail →</a></div><div class="card-b timeline">
        ${d.activity.length ? d.activity.map(a => `<div class="ev"><div class="when">${esc(a.ts)}</div><div>${esc(a.entity)} <b>${esc(a.action)}</b> ${esc(truncate(a.details, 70))}</div></div>`).join('') : '<div class="empty">No activity yet</div>'}
      </div></div>
    </div>`;
}

/* ---------------- audit universe & risk assessment */
async function viewUniverse(el) {
  const rows = await API.get('/universe?company_id=' + State.companyId);
  const factors = enums('risk_factors');
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Audit Universe &amp; Risk Assessment</h1>
      <p>Inherent risk scoring per auditable unit. Score = weighted average of six factors (1-5), scaled to 100. High ≥ 80, Medium ≥ 60.</p></div>
    <div class="actions"><button class="btn" onclick="API.download('/reports/universe/${State.companyId}/xlsx')">⬇ Export Excel</button>
      <button class="btn primary" id="add">+ Add auditable unit</button></div></div>
    <div class="grid g4 mb">
      <div class="card kpi" style="--kpi-c:#1f3a5f"><div class="label">Auditable units</div><div class="value">${rows.length}</div></div>
      <div class="card kpi" style="--kpi-c:#c0392b"><div class="label">High risk</div><div class="value">${rows.filter(r => r.risk_level === 'High').length}</div></div>
      <div class="card kpi" style="--kpi-c:#e67e22"><div class="label">Medium risk</div><div class="value">${rows.filter(r => r.risk_level === 'Medium').length}</div></div>
      <div class="card kpi" style="--kpi-c:#2e8b57"><div class="label">Low risk</div><div class="value">${rows.filter(r => r.risk_level === 'Low').length}</div></div>
    </div>
    <div class="card"><div class="toolbar">
      <input type="search" class="search" id="q" placeholder="Search process...">
      <select id="fe"><option value="">All entities</option>${State.entities.map(e => `<option value="${e.id}">${esc(e.name)}</option>`).join('')}</select>
      <select id="fl"><option value="">All risk levels</option><option>High</option><option>Medium</option><option>Low</option></select>
      <select id="fi"><option value="">All industries</option><option>Common</option>${State.meta.industries.map(i => `<option>${esc(i)}</option>`).join('')}</select>
      <span class="muted small" id="cnt"></span></div><div id="tbl"></div></div>`;
  const draw = () => {
    const q = $('#q', el).value.toLowerCase(), fe = $('#fe', el).value, fl = $('#fl', el).value, fi = $('#fi', el).value;
    const list = rows.filter(r => (!q || (r.process_name || '').toLowerCase().includes(q)) && (!fe || String(r.entity_id) === fe) && (!fl || r.risk_level === fl) && (!fi || r.industry === fi));
    $('#cnt', el).textContent = `${list.length} units`;
    $('#tbl', el).innerHTML = tableHtml([
      { label: 'Process', render: r => `<b>${esc(r.process_name)}</b><div class="small muted">${esc(r.process_code || '')} &middot; ${esc(r.industry || '')}</div>` },
      { label: 'Entity', render: r => esc(r.entity_name) },
      ...factors.map(f => ({ label: f.label.split(' ')[0], cls: 'center', render: r => r[f.key] })),
      { label: 'Score', render: r => riskBadge(r.risk_level, r.risk_score) },
      { label: 'Frequency', key: 'audit_frequency' },
      { label: 'Last audit', render: r => fmtDate(r.last_audit_date) },
      { label: '', cls: 'right', render: r => `<button class="btn sm" data-del="${r.id}">✕</button>` },
    ], list, { onRow: true, empty: 'No auditable units. Use Company → Sync universe.' });
    bindRows($('#tbl', el), list, r => universeForm(r));
    $$('[data-del]', el).forEach(b => b.onclick = async () => { await guard(() => API.del('/universe/' + b.dataset.del), 'Removed'); render(); });
  };
  ['q', 'fe', 'fl', 'fi'].forEach(id => $('#' + id, el).addEventListener('input', draw));
  draw();
  $('#add', el).onclick = () => universeForm();
}

function universeForm(u) {
  const score = { type: 'number', min: 1, max: 5 };
  const fields = [
    { k: 'process_name', label: 'Auditable unit / process', required: true, full: true },
    { k: 'entity_id', label: 'Entity', type: 'select', options: entityOptions() },
    { k: 'industry', label: 'Industry', type: 'select', options: ['Common'].concat(State.meta.industries) },
    { k: 'process_code', label: 'Library process', type: 'select', options: () => (window._libCache || []).map(p => ({ value: p.code, label: `${p.code} - ${p.name}` })) },
    { k: 'process_owner', label: 'Process owner' },
    ...enums('risk_factors').map(f => Object.assign({ k: f.key, label: `${f.label} (${f.weight}%)` }, score)),
    { k: 'audit_frequency', label: 'Audit frequency', type: 'select', options: enums('frequencies'), help: 'Blank = based on risk level' },
    { k: 'last_audit_date', label: 'Last audit date', type: 'date' },
    { k: 'last_rating', label: 'Last audit rating' },
    { k: 'notes', label: 'Risk assessment rationale / notes', type: 'textarea' },
  ];
  ensureLibrary().then(() => formModal({ title: u ? 'Risk assessment - ' + u.process_name : 'Add auditable unit', wide: true, fields,
    values: u || { f_financial: 3, f_fraud: 3, f_regulatory: 3, f_complexity: 3, f_change: 3, f_control_env: 3 },
    onSave: d => { d.company_id = State.companyId; return u ? API.put('/universe/' + u.id, d) : API.post('/universe', d); } })
    .then(() => { toast('Risk assessment saved'); render(); }));
}
async function ensureLibrary() { if (!window._libCache) window._libCache = await API.get('/library'); return window._libCache; }

/* ---------------- audit plans */
async function viewPlans(el) {
  const [plans, engs] = await Promise.all([API.get('/plans?company_id=' + State.companyId), API.get('/engagements?company_id=' + State.companyId)]);
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Risk-Based Audit Plans</h1><p>Annual / multi-year plans, coverage and resource allocation</p></div>
    <div class="actions"><button class="btn primary" id="add">+ New audit plan</button></div></div>
    ${plans.length ? plans.slice().reverse().map(p => {
      const list = engs.filter(e => e.plan_id === p.id);
      const budget = list.reduce((s, e) => s + (e.budget_hours || 0), 0);
      const actual = list.reduce((s, e) => s + (e.actual_hours || 0), 0);
      const done = list.filter(e => ['Reporting', 'Closed'].includes(e.status)).length;
      return `<div class="card mb"><div class="card-h"><h3>${esc(p.title || 'Audit Plan ' + p.year)} ${badge(p.status)}</h3>
        <button class="btn sm" data-gen="${p.id}">⚙ Generate from risk assessment</button>
        <button class="btn sm" data-doc="${p.id}">⬇ Plan document</button>
        <button class="btn sm" data-edit="${p.id}">Edit</button><button class="btn sm danger" data-del="${p.id}">Delete</button></div>
        <div class="card-b"><div class="grid g4 mb">
          <div><div class="small muted">Engagements</div><h2>${list.length}</h2></div>
          <div><div class="small muted">Completed / reporting</div><h2>${done}</h2></div>
          <div><div class="small muted">Budget vs available hours</div><h2>${fmtNum(budget)} / ${fmtNum(p.available_hours)}</h2>${progress(p.available_hours ? budget / p.available_hours * 100 : 0)}</div>
          <div><div class="small muted">Actual hours</div><h2>${fmtNum(actual, 1)}</h2>${progress(budget ? actual / budget * 100 : 0)}</div></div>
          ${['Q1', 'Q2', 'Q3', 'Q4'].map(q => {
            const ql = list.filter(e => e.quarter === q);
            return `<h4 style="margin:10px 0 6px">${q} <span class="muted small">(${ql.length})</span></h4>` + tableHtml([
              { label: 'Ref', render: e => `<a href="#/engagement/${e.id}">${esc(e.ref)}</a>` },
              { label: 'Engagement', key: 'title' }, { label: 'Entity', key: 'entity_name' }, { label: 'Type', key: 'audit_type' },
              { label: 'Status', render: e => badge(e.status) }, { label: 'Progress', render: e => progress(e.progress) },
              { label: 'Budget hrs', cls: 'right', render: e => fmtNum(e.budget_hours) }, { label: 'Rating', render: e => badge(e.overall_rating) },
            ], ql, { empty: 'No engagements scheduled' });
          }).join('')}
          ${p.approved_by ? `<p class="small muted mt">Approved by ${esc(p.approved_by)} on ${fmtDate(p.approved_on)}</p>` : ''}</div></div>`;
    }).join('') : '<div class="card"><div class="empty"><div class="big">\u{1F5D3}</div>No audit plans yet. Create a plan, then generate engagements from your risk assessment.</div></div>'}`;
  const form = p => formModal({ title: p ? 'Edit plan' : 'New audit plan', values: p || { year: new Date().getFullYear(), status: 'Draft', available_hours: 3600 }, fields: [
    { k: 'year', label: 'Plan year', type: 'number', required: true }, { k: 'title', label: 'Title' },
    { k: 'status', label: 'Status', type: 'select', options: enums('plan_statuses'), blank: false },
    { k: 'available_hours', label: 'Available audit hours', type: 'number' },
    { k: 'approved_by', label: 'Approved by' }, { k: 'approved_on', label: 'Approval date', type: 'date' },
    { k: 'notes', label: 'Notes / basis of preparation', type: 'textarea' }],
    onSave: d => { d.company_id = State.companyId; if (!d.title) d.title = 'Risk-Based Audit Plan ' + d.year; return p ? API.put('/plans/' + p.id, d) : API.post('/plans', d); } }).then(render);
  $('#add', el).onclick = () => form();
  $$('[data-edit]', el).forEach(b => b.onclick = () => form(plans.find(p => String(p.id) === b.dataset.edit)));
  $$('[data-doc]', el).forEach(b => b.onclick = () => API.download(`/reports/plan/${State.companyId}/${b.dataset.doc}/docx`));
  $$('[data-del]', el).forEach(b => b.onclick = async () => {
    if (!await confirmBox('Delete this plan? Engagements are kept but unlinked from the plan.', 'Delete')) return;
    await guard(() => API.del('/plans/' + b.dataset.del), 'Plan deleted'); render();
  });
  $$('[data-gen]', el).forEach(b => b.onclick = () => formModal({
    title: 'Generate engagements from risk assessment', saveLabel: 'Generate',
    intro: '<p class="muted">Creates one engagement per auditable unit at the selected risk levels (highest score first), spread across quarters, with the RACM work program and PBC list loaded from the library.</p>',
    fields: [{ k: 'levels', label: 'Risk levels to cover', type: 'checks', options: ['High', 'Medium', 'Low'], default: ['High'] },
      { k: 'max_engagements', label: 'Maximum engagements', type: 'number', default: 20 }],
    onSave: d => API.post(`/plans/${b.dataset.gen}/generate`, d),
  }).then(r => { toast(`${r.created} engagements created`); render(); }));
}

/* ---------------- engagements list */
async function viewEngagements(el) {
  const engs = await API.get('/engagements?company_id=' + State.companyId);
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Audit Engagements</h1><p>Assurance, advisory, compliance and investigation assignments</p></div>
    <div class="actions"><button class="btn primary" onclick="newEngagement()">+ New engagement</button></div></div>
    <div class="card"><div class="toolbar"><input type="search" class="search" id="q" placeholder="Search engagements...">
      <select id="fs"><option value="">All statuses</option>${enums('engagement_statuses').map(s => `<option>${s}</option>`).join('')}</select>
      <select id="fe"><option value="">All entities</option>${State.entities.map(e => `<option value="${e.id}">${esc(e.name)}</option>`).join('')}</select></div>
    <div id="tbl"></div></div>`;
  const draw = () => {
    const q = $('#q', el).value.toLowerCase(), fs = $('#fs', el).value, fe = $('#fe', el).value;
    const list = engs.filter(e => (!q || (e.title + ' ' + e.ref).toLowerCase().includes(q)) && (!fs || e.status === fs) && (!fe || String(e.entity_id) === fe));
    $('#tbl', el).innerHTML = tableHtml([
      { label: 'Ref', render: e => `<b>${esc(e.ref)}</b>` },
      { label: 'Engagement', render: e => `${esc(e.title)}<div class="small muted">${esc(e.audit_type)} &middot; ${esc(e.entity_name || '')}</div>` },
      { label: 'Plan', render: e => e.plan_year ? `${e.plan_year} ${esc(e.quarter || '')}` : '-' },
      { label: 'Lead', key: 'lead_auditor' },
      { label: 'Dates', render: e => `<span class="small">${fmtDate(e.planned_start)} - ${fmtDate(e.planned_end)}</span>` },
      { label: 'Status', render: e => badge(e.status) },
      { label: 'Work program', render: e => `${progress(e.progress)}<div class="small muted">${e.procedure_done}/${e.procedure_total} signed off</div>` },
      { label: 'Findings', render: e => ['Critical', 'High', 'Medium', 'Low'].filter(r => e.findings[r]).map(r => badge(e.findings[r] + ' ' + r[0], RATING_CLASS[r])).join(' ') || '<span class="muted">-</span>' },
      { label: 'Rating', render: e => badge(e.overall_rating) },
    ], list, { onRow: true, empty: 'No engagements yet' });
    bindRows($('#tbl', el), list, e => go('#/engagement/' + e.id));
  };
  ['q', 'fs', 'fe'].forEach(id => $('#' + id, el).addEventListener('input', draw));
  draw();
}

async function newEngagement(prefill) {
  const [lib, plans] = await Promise.all([ensureLibrary(), API.get('/plans?company_id=' + State.companyId)]);
  const inds = ['Common'].concat(State.company.industries);
  const procOptions = lib.filter(p => inds.includes(p.industry)).map(p => ({ value: p.code, label: `${p.name} (${p.industry}, ${p.items} controls)` }));
  const year = new Date().getFullYear();
  const fields = [
    { k: 'title', label: 'Engagement title', required: true, full: true },
    { k: 'entity_id', label: 'Entity', type: 'select', options: entityOptions() },
    { k: 'plan_id', label: 'Audit plan', type: 'select', options: plans.map(p => ({ value: p.id, label: p.title || p.year })) },
    { k: 'audit_type', label: 'Engagement type', type: 'select', options: enums('audit_types'), blank: false },
    { k: 'quarter', label: 'Quarter', type: 'select', options: enums('quarters') },
    { k: 'period_from', label: 'Audit period from', type: 'date' }, { k: 'period_to', label: 'Audit period to', type: 'date' },
    { k: 'planned_start', label: 'Planned start', type: 'date' }, { k: 'planned_end', label: 'Planned end', type: 'date' },
    { k: 'lead_auditor', label: 'Engagement lead', type: 'select', options: auditorOptions() },
    { k: 'reviewer', label: 'Reviewer', type: 'select', options: auditorOptions() },
    { k: 'team', label: 'Team members' }, { k: 'auditee_contact', label: 'Auditee / process owner' },
    { k: 'budget_hours', label: 'Budget hours', type: 'number', default: 160 },
    { k: 'process_codes', label: 'Processes in scope - RACM & audit procedures will be loaded from the library', type: 'checks', options: procOptions },
    { k: 'load_pbc', label: '', type: 'checkbox', text: 'Generate PBC (document request) list from library', default: 1 },
    { k: 'objective', label: 'Objectives (leave blank to use library defaults)', type: 'textarea' },
    { k: 'scope', label: 'Scope (leave blank to auto-generate)', type: 'textarea' },
  ];
  const e = await formModal({ title: 'New audit engagement', wide: true, fields, saveLabel: 'Create engagement',
    values: Object.assign({ audit_type: 'Assurance', period_from: `${year - 1}-01-01`, period_to: `${year - 1}-12-31`, budget_hours: 160, load_pbc: 1 }, prefill || {}),
    onSave: d => { d.company_id = State.companyId; d.status = 'Planning'; d.load_library = true; d.load_pbc = !!d.load_pbc; return API.post('/engagements', d); } });
  toast('Engagement created with work program');
  go('#/engagement/' + e.id);
}

/* ---------------- findings & action tracker */
const FINDING_FIELDS = () => [
  { k: 'title', label: 'Finding title', required: true, full: true },
  { k: 'rating', label: 'Risk rating', type: 'select', options: enums('finding_ratings'), blank: false },
  { k: 'status', label: 'Status', type: 'select', options: enums('finding_statuses'), blank: false },
  { k: 'category', label: 'Category', type: 'select', options: enums('finding_categories') },
  { k: 'root_cause_category', label: 'Root cause category', type: 'select', options: enums('root_causes') },
  { k: 'process_code', label: 'Process', type: 'select', options: () => (window._libCache || []).map(p => ({ value: p.code, label: p.name })) },
  { k: 'entity_id', label: 'Entity', type: 'select', options: entityOptions() },
  { k: 'condition', label: 'Condition - what we found', type: 'textarea', rows: 4 },
  { k: 'criteria', label: 'Criteria - policy / standard / expected control', type: 'textarea' },
  { k: 'cause', label: 'Cause - why it happened', type: 'textarea' },
  { k: 'effect', label: 'Effect - risk / impact', type: 'textarea' },
  { k: 'recommendation', label: 'Recommendation', type: 'textarea' },
  { k: 'financial_impact', label: 'Quantified financial impact', type: 'number' },
  { k: 'repeat_finding', label: '', type: 'checkbox', text: 'Repeat finding (raised in prior audit)' },
  { k: 'mgmt_response', label: 'Management response', type: 'textarea' },
  { k: 'action_plan', label: 'Agreed action plan', type: 'textarea' },
  { k: 'owner', label: 'Action owner' }, { k: 'owner_email', label: 'Owner email', type: 'email' },
  { k: 'due_date', label: 'Target date', type: 'date' }, { k: 'revised_due_date', label: 'Revised target date', type: 'date' },
];

async function findingForm(f, engagementId) {
  await ensureLibrary();
  const existing = f && f.id;
  const saved = await formModal({ title: existing ? `${f.ref} - Edit finding` : 'New finding', wide: true, fields: FINDING_FIELDS(),
    values: f || { rating: 'Medium', status: 'Open' },
    onSave: d => {
      d.company_id = State.companyId;
      if (!existing && engagementId) d.engagement_id = engagementId;
      return existing ? API.put('/findings/' + f.id, d) : API.post('/findings', d);
    } });
  toast('Finding saved');
  return saved;
}

async function findingDetail(f) {
  const hist = await API.get('/followups?finding_id=' + f.id);
  const m = modal({ title: `${f.ref} - ${f.title}`, wide: true,
    body: `<div class="pill-list mb">${badge(f.rating)} ${badge(f.overdue ? 'Overdue' : f.status)} ${f.repeat_finding ? badge('Repeat', 'b-red') : ''}
      <span class="badge b-grey">${esc(f.process_name || '')}</span><span class="badge b-grey">${esc(f.entity_name || '')}</span></div>
      <div class="kv mb">
        <div class="k">Engagement</div><div>${esc(f.engagement_ref)} ${esc(f.engagement_title)}</div>
        <div class="k">Condition</div><div class="pre">${esc(f.condition || '-')}</div>
        <div class="k">Criteria</div><div class="pre">${esc(f.criteria || '-')}</div>
        <div class="k">Cause</div><div class="pre">${esc(f.cause || '-')}</div>
        <div class="k">Effect</div><div class="pre">${esc(f.effect || '-')}</div>
        <div class="k">Recommendation</div><div class="pre">${esc(f.recommendation || '-')}</div>
        <div class="k">Management response</div><div class="pre">${esc(f.mgmt_response || '-')}</div>
        <div class="k">Action plan</div><div class="pre">${esc(f.action_plan || '-')}</div>
        <div class="k">Owner / due</div><div>${esc(f.owner || '-')} &middot; ${fmtDate(f.due_date)}${f.revised_due_date ? ' (revised ' + fmtDate(f.revised_due_date) + ')' : ''}</div>
      </div>
      <h3 style="margin-bottom:8px">Follow-up history</h3>
      <div class="timeline">${hist.length ? hist.map(h => `<div class="ev"><div class="when">${fmtDate(h.update_date)} &middot; ${esc(h.updated_by || '')} ${badge(h.status)}</div><div class="pre">${esc(h.update_text)}</div></div>`).join('') : '<p class="muted">No follow-ups recorded.</p>'}</div>`,
    footer: `<button class="btn danger" id="fd-del">Delete</button><span style="flex:1"></span><button class="btn" id="fd-edit">Edit</button><button class="btn primary" id="fd-fu">+ Record follow-up</button>`,
  });
  $('#fd-edit', m.el).onclick = async () => { m.close(); await findingForm(f); render(); };
  $('#fd-del', m.el).onclick = async () => {
    if (!await confirmBox('Delete this finding and its follow-up history?', 'Delete')) return;
    await guard(() => API.del('/findings/' + f.id), 'Finding deleted'); m.close(); render();
  };
  $('#fd-fu', m.el).onclick = async () => {
    m.close();
    await formModal({ title: 'Record follow-up - ' + f.ref, fields: [
      { k: 'update_date', label: 'Date', type: 'date', default: today() },
      { k: 'status', label: 'Updated status', type: 'select', options: enums('finding_statuses'), blank: false, default: f.status },
      { k: 'updated_by', label: 'Validated by', type: 'select', options: auditorOptions() },
      { k: 'update_text', label: 'Follow-up notes / evidence reviewed', type: 'textarea', required: true }],
      onSave: d => { d.finding_id = f.id; return API.post('/followups', d); } });
    toast('Follow-up recorded'); render();
  };
}

async function viewFindings(el) {
  await ensureLibrary();
  const rows = await API.get('/findings?company_id=' + State.companyId);
  el.innerHTML = `<div class="page-head"><div class="titles"><h1>Findings &amp; Action Tracker</h1><p>All audit observations, management actions and follow-up across engagements</p></div>
    <div class="actions"><button class="btn" onclick="API.download('/reports/findings/${State.companyId}/xlsx')">⬇ Export tracker</button>
      <button class="btn primary" id="add">+ New finding</button></div></div>
    <div class="grid g4 mb">
      <div class="card kpi" style="--kpi-c:#1f3a5f"><div class="label">Total</div><div class="value">${rows.length}</div></div>
      <div class="card kpi" style="--kpi-c:#2e75b6"><div class="label">Open / in progress</div><div class="value">${rows.filter(r => ['Open', 'In Progress'].includes(r.status)).length}</div></div>
      <div class="card kpi" style="--kpi-c:#c0392b"><div class="label">Overdue</div><div class="value">${rows.filter(r => r.overdue).length}</div></div>
      <div class="card kpi" style="--kpi-c:#27ae60"><div class="label">Implemented / closed</div><div class="value">${rows.filter(r => ['Implemented', 'Closed'].includes(r.status)).length}</div></div></div>
    <div class="card"><div class="toolbar"><input type="search" class="search" id="q" placeholder="Search findings...">
      <select id="fr"><option value="">All ratings</option>${enums('finding_ratings').map(s => `<option>${s}</option>`).join('')}</select>
      <select id="fs"><option value="">All statuses</option><option value="__overdue">Overdue only</option>${enums('finding_statuses').map(s => `<option>${s}</option>`).join('')}</select>
      <select id="fe"><option value="">All entities</option>${State.entities.map(e => `<option value="${e.id}">${esc(e.name)}</option>`).join('')}</select></div>
    <div id="tbl"></div></div>`;
  const draw = () => {
    const q = $('#q', el).value.toLowerCase(), fr = $('#fr', el).value, fs = $('#fs', el).value, fe = $('#fe', el).value;
    const list = rows.filter(r => (!q || (r.title + ' ' + r.ref + ' ' + (r.owner || '')).toLowerCase().includes(q)) && (!fr || r.rating === fr)
      && (!fs || (fs === '__overdue' ? r.overdue : r.status === fs)) && (!fe || String(r.entity_id) === fe));
    $('#tbl', el).innerHTML = tableHtml([
      { label: 'Ref', render: r => `<b>${esc(r.ref)}</b>` },
      { label: 'Finding', cls: 'wrap', render: r => `${esc(r.title)}<div class="small muted">${esc(r.engagement_ref)} &middot; ${esc(r.process_name)}</div>` },
      { label: 'Entity', key: 'entity_name' },
      { label: 'Rating', render: r => badge(r.rating) },
      { label: 'Owner', key: 'owner' },
      { label: 'Due', render: r => `<span class="${r.overdue ? 'badge b-red' : ''}">${fmtDate(r.revised_due_date || r.due_date)}</span>` },
      { label: 'Status', render: r => badge(r.status) },
      { label: 'Follow-ups', cls: 'center', render: r => r.followup_count },
    ], list, { onRow: true, empty: 'No findings recorded' });
    bindRows($('#tbl', el), list, findingDetail);
  };
  ['q', 'fr', 'fs', 'fe'].forEach(id => $('#' + id, el).addEventListener('input', draw));
  draw();
  $('#add', el).onclick = async () => { await findingForm(null); render(); };
}

route('dashboard', viewDashboard);
route('universe', viewUniverse);
route('plans', viewPlans);
route('engagements', viewEngagements);
route('findings', viewFindings);
