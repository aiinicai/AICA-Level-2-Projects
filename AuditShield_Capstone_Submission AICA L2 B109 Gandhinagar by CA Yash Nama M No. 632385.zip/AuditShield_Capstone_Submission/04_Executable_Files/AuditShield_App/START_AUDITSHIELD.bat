@echo off
rem Starts AuditShield on this computer and opens it in the browser.
rem No installation needed: the prebuilt app in "dist" is served by Windows PowerShell at
rem http://127.0.0.1:4173 (this computer only). Close the black window to stop it.
cd /d "%~dp0"
if not exist dist\index.html (
  echo The prebuilt app ^(dist folder^) is missing.
  echo If Node.js is installed, run:  npm ci  then  npm run build
  pause
  exit /b 1
)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0serve.ps1"
pause
