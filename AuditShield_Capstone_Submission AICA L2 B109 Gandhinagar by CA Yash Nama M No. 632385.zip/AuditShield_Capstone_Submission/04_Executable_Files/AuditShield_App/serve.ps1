# Serves the prebuilt AuditShield app (the dist folder) at http://127.0.0.1:4173 using only
# Windows PowerShell: no Node.js, no installation, no administrator rights. It listens on this
# computer only (127.0.0.1), so nothing is reachable from the network. Close the window to stop.
param([int]$Port = 4173)
$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot 'dist'
if (-not (Test-Path (Join-Path $root 'index.html'))) { Write-Host "dist\index.html not found next to this script."; exit 1 }
$rootFull = [IO.Path]::GetFullPath($root)
$types = @{ '.html'='text/html; charset=utf-8'; '.js'='text/javascript; charset=utf-8'; '.css'='text/css; charset=utf-8';
  '.json'='application/json'; '.webmanifest'='application/manifest+json'; '.svg'='image/svg+xml'; '.png'='image/png'; '.ico'='image/x-icon'; '.txt'='text/plain' }

$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $Port)
try { $listener.Start() } catch { Write-Host "Port $Port is already in use. AuditShield may already be running: open http://127.0.0.1:$Port"; exit 1 }
Write-Host "AuditShield is running at http://127.0.0.1:$Port  (keep this window open; close it to stop)"
Start-Process "http://127.0.0.1:$Port/"

while ($true) {
  $client = $listener.AcceptTcpClient()
  try {
    $stream = $client.GetStream()
    $reader = [IO.StreamReader]::new($stream, [Text.Encoding]::ASCII, $false, 8192, $true)
    $requestLine = $reader.ReadLine()
    while (($line = $reader.ReadLine()) -ne $null -and $line -ne '') { }
    if (-not $requestLine) { continue }
    $parts = $requestLine.Split(' ')
    $method = $parts[0]; $path = [Uri]::UnescapeDataString(($parts[1] -split '\?')[0])
    if ($path -eq '/') { $path = '/index.html' }
    $file = [IO.Path]::GetFullPath((Join-Path $rootFull ($path.TrimStart('/') -replace '/', '\')))
    if (-not $file.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $file -PathType Leaf)) {
      # Single-page app: unknown paths get the app shell.
      $file = Join-Path $rootFull 'index.html'
    }
    $body = if ($method -eq 'HEAD') { [byte[]]@() } else { [IO.File]::ReadAllBytes($file) }
    $ext = [IO.Path]::GetExtension($file).ToLowerInvariant()
    $type = if ($types.ContainsKey($ext)) { $types[$ext] } else { 'application/octet-stream' }
    $cache = if ($ext -eq '.html' -or $file.EndsWith('sw.js') -or $ext -eq '.webmanifest') { 'no-cache' } else { 'public, max-age=31536000, immutable' }
    $length = if ($method -eq 'HEAD') { (Get-Item $file).Length } else { $body.Length }
    $header = "HTTP/1.1 200 OK`r`nContent-Type: $type`r`nContent-Length: $length`r`nCache-Control: $cache`r`nX-Content-Type-Options: nosniff`r`nReferrer-Policy: no-referrer`r`nConnection: close`r`n`r`n"
    $bytes = [Text.Encoding]::ASCII.GetBytes($header)
    $stream.Write($bytes, 0, $bytes.Length)
    if ($body.Length) { $stream.Write($body, 0, $body.Length) }
    $stream.Flush()
  } catch { } finally { $client.Close() }
}
