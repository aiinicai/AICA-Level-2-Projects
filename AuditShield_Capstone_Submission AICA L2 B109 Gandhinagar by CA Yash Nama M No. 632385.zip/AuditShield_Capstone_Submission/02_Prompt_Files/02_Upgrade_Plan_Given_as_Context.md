# AuditShield Upgrade Plan

Prepared 15 November 2026. This is a project-specific implementation plan for upgrading with Claude Fable 5.2. The recommendations assume an offline-first browser application for an individual CA or a small firm, with optional external AI. A desktop alternative is specified below if an installed Windows application and an ordinary SQLite file are requirements.

## 1. Recommendation

Build **AuditShield**, one application containing VendorShield and CA-Safe AI Gateway, organised around client engagements. Start with **React, TypeScript, Vite, shadcn/ui, Tailwind CSS and Dexie over IndexedDB**. Keep the existing deterministic detection logic, improve its correctness and privacy boundaries, and move expensive operations into workers.

The most valuable change is a complete workflow: create engagement → validate data → protect data → analyse → investigate → save conclusions → export workpapers → back up. A second workflow handles text: compose → detect → review masking → validate the exact outbound request → send → inspect and optionally restore the answer.

The database should preserve useful engagement state without automatically retaining every raw identifier or prompt. Persist protected records and workpapers by default; make encrypted raw-data and vault retention explicit options. Keep the offline demo available.

## 2. What was inspected and verified

Reviewed both top-level HTML applications, source and tests in `AuditShield_Project.zip`, the capstone guide, and the pitch deck's text. The two pitch deck files are byte-identical. Both top-level HTML files are byte-identical to their corresponding archive builds. The temporary Word lock file is not project content.

The archive already separates domain logic from UI:

- `ghost_vendor/core.js`, `ui.js`, `template.html`.
- `ai_gateway/core.js`, `ui.js`, `template.html`.
- Four sample CSV files, Node tests, documentation and build scripts.

Executed the two supplied Node logic scripts and both fake-DOM smoke runs. They completed successfully. VendorShield's sample yields 10 employees, 12 vendors, 3 directors, 86 payments, 14 flags, including 2 critical and 10 high. Total sample payments are INR 11,033,700; payments to vendors with critical/high flags are INR 5,116,715. Gateway evaluation gives 21 true positives, 1 false negative and 0 false positives across 18 test sentences: 95.45% recall and 100% precision on that tiny dataset.

These tests are useful baselines, not proof of real-world accuracy. Many current checks print results rather than fail on unexpected behaviour. The smoke tests use a fake DOM; no real-browser visual, accessibility or network test was performed in this review. UI recommendations are based on the markup, styles and interaction code.

## 3. Findings that should drive the work

Line references below refer to source members inside `AuditShield_Project.zip`.

| Priority | Evidence | Improvement |
| --- | --- | --- |
| P0 | `ai_gateway/ui.js:51–71` enables Send after scanning and offers a send-anyway confirmation on a leak warning | Block sending when checks fail. Enforce this in the request service, not only a button. |
| P0 | `ghost_vendor/core.js:108–124` copies whole input rows and transforms only named sensitive fields | Build exports from explicit allowlists. Reject or explicitly classify unknown columns. A probe confirmed that an added `extra_notes` field survives protection unchanged. |
| P0 | `ai_gateway/core.js:154–160` checks vault values and repeats the same detector | Display the scope of the check honestly. An undetected lowercase name remains visible while both leak-check lists are empty. Add manual review and broader tests. |
| P0 | `ai_gateway/ui.js:105–115` uses a checkbox for reveal | Rename this as a local reveal control until real enforcement exists. Add workspace unlock, timed reveal and logged reasons. A browser role label cannot establish multi-user authorisation. |
| P1 | VendorShield stores `RAW`, `PROT`, `RESULT` in memory; Gateway stores a vault and `LOG` in memory | Add engagement persistence, transactions, migrations, retention controls and tested backups. |
| P1 | `ghost_vendor/ui.js:39–54` loads new data without clearing prior protected data/results | Invalidate derived state on source changes; tie each result to an immutable import snapshot. |
| P1 | Gateway watch-list changes do not call the input reset handler | Invalidate scan approval whenever text, watch-list, policy, provider or relevant settings change. |
| P1 | `ghost_vendor/core.js:85` strips bank-account leading zeros | Preserve account strings. Do not assume `00123` and `123` identify the same account. Add IFSC/bank context when available. |
| P1 | `ghost_vendor/core.js:90` removes non-Latin characters from addresses | Preserve Unicode. A probe showed `पुणे` becomes empty. Version the normalisation scheme and test Indian scripts. |
| P1 | `ghost_vendor/core.js:121` truncates HMAC to 16 hexadecimal characters | Use full HMAC-SHA256 in new packages; attach algorithm and key versions. Preserve legacy import compatibility rather than silently changing old packages. |
| P1 | `ghost_vendor/ui.js` downloads a protected JSON file but has no protected-package import/parser flow | Add a genuine auditor-only protected import, validation and independent analysis workflow. |
| P1 | `ai_gateway/core.js:55` detects GSTIN by pattern; the checksum helper is separate | Wire checksum confidence into detection. An invalid-checksum GSTIN was still detected. Mask likely sensitive identifiers even when invalid; distinguish detection from validation. |
| P1 | `ai_gateway/ui.js:79–84` calls a user-entered endpoint directly | Add provider adapters, outbound host policy, timeout/cancellation, response validation and safe errors. Account for browser CORS. |
| P2 | Tables render all rows; graph layout and core processing run synchronously | Add workers, indexed queries, virtualised rows and graph neighbourhood limits after benchmarking. |
| P2 | Risk score is a capped sum; R6 treats repeated invoice numbers as duplicate payments | Describe scores as heuristic priority. Handle instalments, credit notes and recurring invoice-number reuse through evidence and review. |

Vendor and director names, DINs, organisational fields and payment references are not all protected by the current field list. Decide deliberately which may appear in each export profile. The existing zero-leak counter checks only the chosen sensitive fields; it is not a statement that the package contains no identifying information.

## 4. Scope and product structure

Keep one brand and a shared design system, with these areas:

1. **Engagements**: client label, financial year, status, recent activity, backup status.
2. **Overview**: current dataset, analysis run, unresolved findings and next action.
3. **Data Imports**: file mapping, validation, data-quality report, protected packages.
4. **VendorShield**: findings table, entity details, relationships, payment evidence.
5. **AI Gateway**: compose, masking review, provider selection, response and history.
6. **Workpapers**: investigation notes, evidence, conclusions and review sign-off.
7. **Activity**: metadata-only audit events and exports.
8. **Settings**: local storage, locking, policies, providers, backup and retention.

Move privacy demonstrations, fraud coverage explanations and detector benchmarks into a clearly labelled Demo / Learn area. Routine work should open on actionable engagement information.

Client preparation and auditor analysis are separate trust contexts. The auditor must be able to use a protected package without the original CSVs, raw vault or HMAC key. A mode toggle in one unlocked workspace does not establish that boundary. Demonstrate transfer into a fresh browser profile or a separate workspace containing only protected material.

## 5. Local database decision

| Choice | Suitable use | Main trade-off | Recommendation |
| --- | --- | --- | --- |
| Dexie + IndexedDB | Continue in the browser; installable offline web app | Browser-origin storage, quota and clearing/eviction risks; explicit backup is essential | Default for this upgrade |
| Tauri + SQLite | Installed Windows app with a managed local database file and native capabilities | Rust/native toolchain, installer and OS-specific testing | Choose from the start if an executable/database file is required |
| SQLite in the browser through WASM/OPFS | SQL is specifically needed while remaining in-browser | Additional worker, storage and compatibility decisions | Defer unless a measured requirement justifies it |

IndexedDB is a real local database, but it is not an ordinary `.db` file. Dexie provides a useful API over it and reactive React queries. Browser storage remains tied to the application's origin and profile. Request persistent storage when supported, show its result, detect private-browsing/storage failures and provide encrypted backups. A user can still clear site data. See [Dexie React guide](https://dexie.org/docs/Tutorial/React) and [storage persistence guidance](https://dexie.org/docs/StorageManager).

Use a fixed development origin/port; changing the origin can appear to lose the database. A production PWA needs an initial installation/load before it can run offline. Serve development from localhost and production from a secure origin; do not assume the new app can run by double-clicking `index.html`.

Do not implement both persistence engines in the first release. Define a small repository interface so a later desktop adapter can replace Dexie without changing rules or screens.

### Suggested stores and records

The names below are logical collections; relational child collections can also be used in IndexedDB. All engagement data needs an engagement identifier. Include a workspace identifier when more than one local workspace can exist.

| Store | Main fields | Key/index requirements |
| --- | --- | --- |
| `workspaces` | id, local label, crypto envelope metadata, settings version | Primary id; labels may be encrypted or generic |
| `engagements` | id, workspaceId, financialYear, status, encrypted client label, createdAt | workspaceId + status |
| `imports` | id, engagementId, source type, digest, schema version, row counts, validation summary, createdAt | engagementId + createdAt; explicit duplicate-import policy |
| `rawPayloads` | id, importId, encrypted payload, retention expiry | Optional only; never plaintext identifiers |
| `entities` | id, engagementId, importId, kind, sourceRecordId, approved display label | importId + kind; unique importId + kind + sourceRecordId |
| `entityAttributes` | id, entityId, importId, field, token, normalisationVersion, keyVersion | importId + field + token; entityId |
| `payments` | id, engagementId, importId, sourcePaymentId, vendorEntityId, invoiceRef, date, amountPaise, currency, approverRef | importId + vendorEntityId + date; unique importId + sourcePaymentId |
| `ruleSets` | id, version, enabled rules, thresholds, configuration digest | Versioned immutable records |
| `analysisRuns` | id, importId, ruleSetVersion, engineVersion, status, summary, startedAt, finishedAt | importId + startedAt |
| `findings` | id, runId, stable fingerprint, ruleId, severity, score, explanation, status | runId + severity; runId + status |
| `findingEntities` / `findingPayments` | findingId, referenced id | Unique pair; indexes on both directions |
| `workpapers` | id, engagementId, finding fingerprint, notes, conclusion, reviewer label, revision | engagementId; preserve edit history where needed |
| `gatewaySessions` | id, engagementId, policyVersion, createdAt, retention settings | engagementId + createdAt |
| `vaultEntries` | id, sessionId, token, encrypted original, type, expiry | Unique sessionId + token; no plaintext original-value index |
| `aiRequests` | id, sessionId, provider, model, policy/scan version, status, counts, time, optional encrypted retained content | sessionId + createdAt; metadata by default |
| `auditEvents` | id, engagementId, action, actor label, targetId, timestamp, redacted metadata | engagementId + timestamp |
| `settings` | key, nonsecret value, version | Never use for raw provider secrets |

Protect invoice references and display labels according to policy; they can identify a client even though they are not conventional PII fields. Searchable plaintext metadata is a deliberate exposure, not magically protected by encrypting a payload.

### Data integrity and lifecycle

- Import into a staging area, validate, then atomically commit a new immutable snapshot. On failure or cancellation, leave no half-imported engagement state.
- Store money as integer paise within JavaScript's safe integer range; reject overflow and invalid decimals. Preserve identifiers as strings. Store business dates as ISO calendar dates; event timestamps as UTC instants displayed locally.
- Enforce referential integrity and uniqueness in repositories; IndexedDB does not provide SQL foreign-key constraints. Use transactions across related stores.
- Persist runs against their exact input snapshot, rule version, policy version and engine version. Never recompute an old result silently.
- Use a stable finding fingerprint so review status can carry forward between runs only when evidence matches. Keep prior runs available.
- Use explicit schema migrations. Test an upgrade from the previous database version and recovery from a failed migration. An older app must refuse an unsupported newer backup safely.
- Add storage status, encrypted backup export/import, restore preview, archive and retention controls. Verify a backup by restoring it into an empty profile.
- Deletion should remove application records and vault data. Do not promise forensic secure erasure from browsers, SSDs or existing backups.

### Encryption and locking

Use platform Web Crypto primitives rather than maintaining custom cryptography for the new app. Generate a random data-encryption key; encrypt sensitive retained payloads with AES-GCM and a unique nonce per encryption. Bind ciphertext to workspace/engagement/record identity with authenticated additional data. Use a passphrase-derived wrapping key with a random salt and a versioned, benchmarked KDF configuration; store only the wrapped data key and public envelope metadata.

Keep the engagement HMAC key independent of the storage-encryption key. Scope matching to an engagement, field and algorithm version, using the same field context across entity types so legitimate comparisons still work. Use cryptographic random generation, not a short fixed demo password. New exports should use full tokens. Key rotation must create a new version and require re-protection of data, rather than mixing incomparable tokens.

Keep unlocked keys in memory, lock after inactivity, and clear application references and sensitive views on lock. Browser JavaScript cannot guarantee complete memory erasure. Encryption at rest does not protect data from malicious code executing inside an unlocked application. Apply CSP, avoid unsafe HTML injection, and bundle runtime assets locally. See [Web Crypto](https://developer.mozilla.org/en-US/docs/Web/API/Web_Crypto_API), [key derivation](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/deriveKey) and [encryption](https://developer.mozilla.org/en-US/docs/Web/API/SubtleCrypto/encrypt).

A local audit log can document workflow, but a local administrator can alter the database. Do not describe it as tamper-proof. Stronger attestations require a separately controlled trust anchor.

### Desktop alternative

If you choose Tauri + SQLite, replace the Dexie repository with a SQLite repository. Use foreign keys, parameterised statements, transactions and schema migrations. Keep the database in the OS application-data directory. Back up through a consistent SQLite backup mechanism rather than copying an active database file without accounting for its journal/WAL.

Expose narrow native commands and minimum capabilities. Avoid granting arbitrary filesystem, shell or database access to every webview. Put cloud-provider requests and long-lived secrets behind the native boundary, with appropriate OS credential storage. Plain SQLite is not encrypted; choose and test field encryption or a compatible encrypted SQLite build explicitly. Tauri's SQL plugin supports SQLite but does not by itself provide a complete secret-management or encryption design. See [SQL plugin](https://v2.tauri.app/plugin/sql/) and [capabilities](https://v2.tauri.app/security/capabilities/).

## 6. Recommended libraries

Use current compatible stable releases, check peer dependencies at implementation time and commit one lockfile. The list is a project-specific selection, not a ranking of every library. Install optional packages only when the relevant phase begins.

| Area | Selection | Purpose and boundary |
| --- | --- | --- |
| App foundation | React + TypeScript + [Vite](https://vite.dev/guide/) | Modular screens and typed domain models; no server-rendering requirement |
| Components/styles | [shadcn/ui + Tailwind](https://ui.shadcn.com/docs/installation/vite) | Consistent dialogs, sheets, tables, forms and navigation; retain and review component source |
| Icons | [Lucide React](https://lucide.dev/guide/react) | Consistent labelled icons; replace decorative emoji in routine controls |
| Persistence | [Dexie + dexie-react-hooks](https://dexie.org/docs/Tutorial/React) | Transactions, schema versions and reactive local queries |
| Data tables | [TanStack Table + TanStack Virtual](https://tanstack.com/table/latest/docs/framework/react/guide/virtualization) | Sorting, filters, column controls and virtual rows; table virtualisation does not accelerate the rule engine |
| Relationship graph | [Cytoscape.js](https://js.cytoscape.org/) | Entity/attribute relationships, layouts, pan/zoom and evidence selection |
| CSV | [Papa Parse](https://www.papaparse.com/docs) | Robust parsing, streaming/workers and formula-safe spreadsheet exports |
| Validation | [Zod](https://zod.dev/) | Validate imports, protected packages, settings and provider responses |
| Forms | [React Hook Form](https://react-hook-form.com/) | Mapping/settings forms with accessible field-level errors |
| Optional charts | [Recharts](https://recharts.github.io/) | Severity distribution and payment timelines; add only useful charts |
| Offline installation | [vite-plugin-pwa](https://vite-pwa-org.netlify.app/) | Cache application assets and provide a controlled update experience |
| Verification | [Vitest](https://vitest.dev/guide/) + [Playwright](https://playwright.dev/docs/intro) | Failing logic assertions plus real-browser workflow and network checks |

Use React state/context for small UI state and Dexie queries for persisted state. Add a state library only if complexity requires it. Keep graphs behind a thin React adapter and dispose instances on unmount. Do not install multiple competing UI systems or database layers.

Cache static application assets only. Exclude prompts, provider responses, credentials and sensitive downloads from service-worker caches. An update should wait until unsaved work is protected; database migrations need their own compatibility checks.

## 7. UI and UX specification

### Visual direction

Use a restrained audit-workspace design: neutral surfaces, a navy/indigo primary colour and severity colours reserved for risk. Use a legible locally bundled font or the system stack, a consistent spacing scale, aligned numeric columns and Indian currency formatting. Build desktop-first for dense analysis, then make the workflow usable on tablets and phones. Avoid decorative charts that do not answer a review question.

The top bar shows the current engagement, financial year, workspace lock, storage status and explicit AI connection mode. Distinguish **offline demo**, **local model** and **external provider**. Never label an external-AI session as entirely offline.

### Screen-by-screen behaviour

**Engagement list:** searchable recent engagements, status, last saved time and a clear Create engagement action. Provide sample engagement creation without mixing demo records with real workspaces. A first-use screen explains where local data is stored and how to back it up.

**Import wizard:** select CSVs → assign dataset type → map columns → preview → resolve validation errors → confirm import. Do not depend on filenames. Provide downloadable templates, required-column guidance and row-level errors with downloadable error CSV. Detect duplicate IDs, unknown vendors, missing masters, invalid dates/amounts, malformed CSV, empty identifiers and conflicting column mappings. Keep PANs, accounts, IDs and phone numbers as strings. Unknown fields must not flow into exports by default.

**Findings workspace:** make a sortable/filterable table the main triage surface. Columns: severity, rule, entity, affected payment count, clearly defined amount, review status and latest note. Support saved filters, keyboard navigation, column visibility and density. A right-side details panel shows the reason, source rows, linked payments, policy thresholds, graph and suggested follow-up. Review actions are Open, Investigating, Needs information, Confirmed issue, False positive and Closed, with required explanations for material decisions.

**Relationships:** show the selected finding's neighbourhood first. Add fit/reset, zoom, search, entity-type filters, relationship labels and a legend. Graph selection and table selection stay synchronised. Provide a structured relationship list as an accessible alternative; graph colour alone must not carry meaning.

**Gateway:** default to a clear three-stage process: Compose → Review masked request → Answer. Show identifiers by type and allow a user to select missed text and mask it manually. Present source and outbound text side-by-side on desktop and in labelled tabs on narrow screens. The final action includes the destination/provider. Display remaining warnings and disabled-action reasons beside the Send button.

The answer starts masked; authorised local users may reveal selected values temporarily. Unknown, altered or invented tokens remain visible as warnings. Keep restoration scoped to the request's authorised tokens so a model cannot retrieve unrelated entries from a long-lived vault. Use session-specific token namespaces to prevent collisions with literal user text such as `[PERSON_1]`.

**Workpapers:** autosave comments and conclusions with a visible save status. Include rule/version, evidence references, scope, threshold configuration, preparer/reviewer labels and unresolved questions in exports. Clearly define whether an amount means payments under review, potential duplicate amount or confirmed issue. The current amount-at-risk figure is total payments to high-risk vendors, not established loss.

**Settings and recovery:** show storage usage/persistence, backup age, retention settings, export/restore controls and provider setup. Provide a connection test using synthetic data only. Explain safe recovery from a failed restore without overwriting the current workspace.

### Interaction standards

- Every screen has purposeful empty, loading, error and success states.
- Show progress and cancellation for large imports and analyses; keep navigation responsive.
- Preserve drafts and filters across navigation, and invalidate scans/results when their inputs change.
- Use visible focus, semantic labels, adequate contrast, focus-managed dialogs, keyboard support and reduced-motion behaviour. Aim for WCAG 2.2 AA and verify the rendered screens.
- Support common desktop widths and 360px mobile without page-level horizontal scrolling; dense data tables may scroll within their own region.
- Keep confirmations for destructive actions. Use inline validation for routine errors. Avoid a chain of blocking alerts.
- Read-only evidence should not look editable; distinguish autosave failure from success.

## 8. Improve VendorShield's analysis

1. Preserve R1–R10 as the baseline. Build explicit fixtures that assert expected entities, payment references, severities and summaries; investigate any intentional changes.
2. Fix normalisation carefully. Preserve bank zeros; handle phone country codes deliberately; retain Unicode addresses; validate GSTIN before deriving PAN. Treat values that cannot be normalised as data-quality issues, never matching every empty value together.
3. Make thresholds configurable and versioned: approval limit, split window, near-limit percentage, minimum count and business-calendar assumptions. Validate all settings.
4. Define invoice-number normalisation. Repeated vendor/invoice combinations are candidates; legitimate instalments and reused numbering across financial years need review. Add invoice date/year and adjustment fields when supported by the source data.
5. Improve split-payment evidence and overlapping-window handling. Expose the exact window and payments. Avoid creating multiple findings for the same economic event without explaining the overlap.
6. Distinguish relationship evidence strength: exact PAN/account matches, shared contact details and shared addresses have different implications. The score is a heuristic review priority, not a fraud probability.
7. Deduplicate monetary summaries by payment ID for payment-level exposure. Keep vendor-wide payments under review as a separate metric. Never sum overlapping finding amounts as if they were independent losses.
8. Add bank-account-change and dormant-vendor rules only after adding the required history/status data. Do not infer unavailable facts from a current master snapshot.
9. Perform fuzzy name/address matching inside the client environment before protection and export approved candidate links if needed. Hashes do not preserve edit distance. Defer specialised privacy-preserving fuzzy matching until there is a reviewed threat model.
10. Add ML anomaly scoring only after a meaningful benchmark exists, with independent holdout cases, explanations and a clear measure of improvement over the deterministic rules.

## 9. Improve the gateway's data boundary

Centralise outbound requests. The provider adapter should receive an approved, immutable masked-request object rather than read raw text from UI state.

Before sending, validate that text, watch-list, policy and target configuration match the reviewed scan; rerun policy checks against the exact request body; block detected leaks; record the attempt; then dispatch. Check all outbound user-controlled fields, including conversation history and future attachments. Disallow hidden automatic cloud fallback and raw identifiers in URLs, logs or error reports. Never queue an external send for automatic replay when connectivity returns.

Separate regex detection, checksum validity and confidence. A misspelled or invalid PAN/GSTIN/account can still be sensitive. Retain watch-lists and manual masking, and introduce NER as an optional local component only after evaluating its model licence, disk/memory requirements and accuracy on Indian names and scripts. Bundle or explicitly download its assets; do not silently call a remote model for detection.

Use separate provider adapters for offline demo, local OpenAI-compatible endpoints, and any selected external APIs. Do not assume a native Claude endpoint accepts an OpenAI-style request. Treat a successful JSON response as untrusted data and validate it. Add cancellation, timeout, clear rate-limit/authentication errors and a bounded retry policy that prevents duplicate sends.

In the browser edition, use session-only API keys by default. Frontend environment variables are public bundle contents, not secret storage. Long-lived server credentials belong behind a separately designed trusted boundary. A user-entered key is still exposed to the running page; never describe it as hidden from frontend code. Local model connections may require CORS configuration. Restrict allowed destinations and schemes; allow HTTP only for explicitly selected local endpoints.

Evaluate masking accuracy and answer usefulness separately. Build a larger held-out synthetic corpus containing lowercase names, regional scripts, spacing/OCR variations, ambiguous numbers, invalid checksums, overlapping identifiers and intentional bypass attempts. Report per-type recall and precision, dataset size and unresolved misses. A second pass with the same recogniser cannot guarantee zero leakage.

## 10. Implementation sequence and release gates

Estimates assume one developer actively reviewing AI-generated changes. They are planning ranges, not measured delivery guarantees. Integrations, encryption review and native packaging can expand them.

| Phase | Work | Exit check | Indicative effort |
| --- | --- | --- | --- |
| 0 | Extract a working copy; document baseline; add regression assertions and high-priority bug reproductions | Existing samples reproduced; bugs captured; originals preserved | 1–2 days |
| 1 | Vite/React/TypeScript foundation, core module ports, shared app shell | Both core modules usable from new UI; typecheck/build/tests pass | 2–3 days |
| 2 | Dexie repositories, transactions, migrations, encrypted optional retention, locking and backup/restore | Engagement survives restart; no half-imports; encrypted backup restores in a fresh profile | 3–5 days |
| 3 | Import wizard, protected package format, standalone auditor import, stale-state invalidation | Separate auditor profile analyses protected input without raw files/key | 2–4 days |
| 4 | Findings table, details, graph, review statuses and workpapers | End-to-end investigation persists and exports with traceable evidence | 3–5 days |
| 5 | Gateway review flow, send enforcement, request-scoped restoration and provider adapters | Network tests prove blocked sends do not execute and approved payloads are masked | 3–5 days |
| 6 | Workers, large fixtures, accessibility, PWA, recovery and final documentation | Offline cold restart after installation; performance recorded; backup and migration checks pass | 2–4 days |

A focused first browser release is roughly 3–6 working weeks, depending on scope and review quality. Defer advanced NER/OCR, multi-user roles, cloud sync, anomaly models and browser extensions until the first release is stable. If time is limited, finish VendorShield's end-to-end workflow and retain the Gateway as a clearly labelled demo before extending it.

### Protected package contract

Create a versioned package with a manifest: package version, engagement-safe reference, import schema, engine compatibility, normalisation version, token algorithm/key reference, row counts, creation time and integrity metadata. Include allowlisted entities, attributes, payments and approved relationship candidates only. Never include a raw-data vault, key material or arbitrary uploaded columns. Checksums detect accidental corruption; they do not establish a trusted sender without a separate authentication/signature design.

Validate the package on import, enforce size limits and referential integrity, reject unsupported versions and show a contents preview. Decide explicitly which labels remain readable. Keep legacy package support separate from the new schema and document its privacy limitations.

### Repository layout

```text
src/
  app/                 # shell, navigation, providers, error boundary
  components/ui/       # chosen shadcn components
  features/
    engagements/
    imports/
    vendorshield/
    gateway/
    workpapers/
    settings/
  domain/
    vendor/            # normalisation, protection, rules, scoring
    privacy/           # detection, policy, vault, masking, restoration
  data/
    db/                # schema and migrations
    repositories/      # persistent operations and transactions
  services/
    crypto/
    providers/
    packages/
    backup/
  workers/
tests/
  fixtures/
  unit/
  integration/
  e2e/
legacy/                # unchanged reference source/builds
```

Keep domain functions independent of React and database APIs. React components call repositories/services; they should not contain cryptographic key-management or fraud-rule implementations.

## 11. Acceptance checklist

### Correctness and isolation

- Baseline sample findings are asserted, not merely printed; intentional differences have a documented cause.
- Missing columns, unknown fields, duplicate IDs, invalid dates/amounts and orphan references produce actionable errors.
- Loading another dataset or changing policy/thresholds cannot present old outputs as current.
- Engagement A's queries, vault entries and exports never include engagement B's records.
- A protected package contains only permitted fields, and a fresh auditor workspace can analyse it independently.
- Leading-zero bank accounts and regional-script addresses have meaningful regression tests.

### Persistence and recovery

- Refresh/restart preserves configured engagement records and workpapers.
- Raw data is not persisted by default; opted-in retained sensitive payloads are encrypted.
- Wrong-passphrase/tampered-ciphertext restore fails safely without modifying existing data.
- Backup restoration into an empty profile matches counts, notes, settings and expected findings.
- Previous-schema migrations and failed/cancelled imports leave consistent data.
- Storage failure, quota exhaustion and persistence refusal have usable recovery messages.

### Gateway

- Failed leak checks result in zero provider calls, including direct service invocation outside the UI.
- Editing text, watch-list, policy or destination invalidates prior approval.
- Intercepted outbound requests contain only the reviewed masked content and permitted metadata.
- Unknown/malformed/invented tokens cannot reveal unrelated values from the vault.
- Timeouts, cancellation, invalid JSON, authentication failures and rate limits preserve drafts safely.
- No production API key is embedded in the frontend bundle or included in backup/log exports.

### UI, offline and performance

- Real-browser checks cover import → protection → analysis → conclusion → restart → export.
- Keyboard navigation and focus work across the import wizard, findings panel and gateway.
- Table, graph and details selection remain synchronised; an accessible relationship list exists.
- The installed/previously loaded app restarts offline without runtime CDN dependencies.
- Offline mode makes no external API calls; external mode displays its destination explicitly.
- Benchmark 10k and 100k payments on a recorded reference machine; measure import/analysis time, peak memory and UI responsiveness. Dense shared-attribute groups must not trigger uncontrolled pairwise expansion. Treat larger-scale support as unproven until measured.

## 12. Standout features after the foundation

Prioritise these in order: reproducible evidence trails; a genuine client-to-auditor package transfer; reviewable masking with enforced sending; encrypted backup and restore; a useful relationship explorer; per-rule precision/recall reporting on a credible dataset; and a polished guided demo.

Only then consider bank-change history, local NER/OCR and anomaly models. Update the guide and pitch deck to describe the implemented architecture and measured results. Keep the statement that red flags require investigation, and avoid presenting pseudonymisation or a small benchmark as a blanket confidentiality or compliance guarantee.

## 13. How to work with Claude Fable 5.2

Give Claude the project ZIP, both HTML files, this plan and `CLAUDE_UPGRADE_PROMPT.md`. Start with Phase 0 and work in reviewable increments. Each phase should produce runnable code, focused tests, a short description of changed behaviour and updated implementation notes. Keep an `IMPLEMENTATION_STATUS.md` recording completed phases, commands, decisions and known issues so progress survives a new chat.

Review concrete acceptance checks before expanding scope. Do not accept attractive screens backed by static sample objects, a database that never receives actual writes, a role selector presented as security, or a passing test suite that does not exercise the network/persistence boundary. Demonstrate refresh, restore and the protected-data transfer using separate workspaces.
