# Example user prompts for the AI Gateway

These three fictional prompts are built into the app (AI Gateway → buttons above the text box).
`03_Example_Files/example_ai_gateway_masking.md` shows, for each one, exactly what is sent to the
model after masking and how the answer is restored.

## GST notice reply
Draft a reply to the GST notice below for our client.

Client: Shubham Textiles Pvt Ltd, GSTIN 27AAKCS4321M1Z1, PAN AAKCS4321M
Authorised signatory: Mr. Rajesh Kulkarni (Director), mobile +91 98201 45678, email rajesh.k@shubhamtextiles.in

Notice ref ASMT-10 dated 12-08-2026 states that ITC of Rs. 4,82,350 claimed in GSTR-3B for FY 2025-26 exceeds GSTR-2B by Rs. 1,12,900.
The difference relates to invoices from Mahalaxmi Traders (GSTIN 27ABHFM7788K1ZD) which filed GSTR-1 late.
Payments to Mahalaxmi Traders were made from HDFC A/c No. 50200012345678, IFSC HDFC0001234.

## Vendor ledger review
Review this vendor payment extract and tell me what looks suspicious.

Vendor: Sai Enterprises, PAN AFZPS1234Q, Bank a/c 60112233445566, IFSC SBIN0004567, UPI saient@okaxis
Proprietor: Shri Rohit Shinde, mobile 9822011107
Note: Rohit Shinde is also our employee in Accounts Payable (Employee name: Rohit Shinde).
Payments: 12-06-2025 Rs. 98,500; 18-07-2025 Rs. 99,200; 03-09-2025 Rs. 97,800 (approval limit Rs. 1,00,000)
All payments approved by Mrs. Anita Deshpande.

## Payroll / KYC query
Employee name: Priya Nair
Aadhaar: 7341 5298 0167, PAN BQNPN6655K
Salary credited to ICICI account 001101556677, IFSC ICIC0000011
Reimbursement claim of Rs. 46,000 submitted by Ms. Priya Nair; card used 4111 1111 1111 1111.
Question: Is this reimbursement taxable as a perquisite and how should it be shown in Form 16?

## A prompt that must be blocked (try it)
Copy any code from the "Outgoing text" panel, for example `[PERSON_1_XXXX]`, and type:
`Who is [PERSON_1_XXXX]?` — the review shows "Sending is blocked" and the Send button is disabled.

## A name the patterns cannot see (try it)
`the director ramesh gupta approved it` — nothing is detected automatically; select "ramesh gupta"
and press "Mask selected text" (or type it in "Something still readable?") before sending.
