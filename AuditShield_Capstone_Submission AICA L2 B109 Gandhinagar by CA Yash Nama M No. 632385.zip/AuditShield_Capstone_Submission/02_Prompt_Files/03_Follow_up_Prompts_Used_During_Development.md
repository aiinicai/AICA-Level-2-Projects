# Follow-up prompts used during development

AuditShield was built with an AI coding agent (Claude Code) inside the IDE. The main engineering
prompt (`01_Main_Engineering_Prompt_to_AI_Agent.md`) and the upgrade plan
(`02_Upgrade_Plan_Given_as_Context.md`) were given first. Work then proceeded in phases, each one
verified by automated tests before the next. The follow-up prompts below steered the agent; they
are listed in order, lightly edited for spelling.

| # | Prompt (participant → agent) | What the agent did |
| --- | --- | --- |
| 1 | *Main engineering prompt*: "Act as the lead engineer upgrading my existing AuditShield capstone… Implement working features in phases and verify each phase… Begin now with Phase 0." | Froze the original project, reproduced its results (14 findings; 21/22 masking) as automated assertions, recorded 20 known defects as reproducible tests. Then built the typed React/TypeScript foundation and ported both modules with parity tests. |
| 2 | "Start Phase 2" | Encrypted local database, versioned migrations, lock/unlock, encrypted backup and restore into a fresh browser profile, real-browser tests. |
| 3 | "Is it ready to use for demo?" | Gave an honest readiness assessment: what could be shown and what was still missing. |
| 4 | "Complete the whole project… I want the theme colors to be fully changed, appropriate to the idea and concept… also give me how do I present the project." | New "ledger and seal" teal theme; finding review with written conclusions; workpaper export; presentation script. |
| 5 | "Package handoff" | Protected package format with checksum and strict validation; export on the client side, import in a separate auditor workspace. |
| 6 | "Give me final files… I have to submit my project urgently." | Packaged the tested app into a submission ZIP. |
| 7 | "Make sure it is complete… I have to present this to judges by recording the walkthrough… attaching my AICA guidelines." | Read the AICA Level 2 guidelines; added CSV import, the auditor handoff screens, an LM Studio offline-GPT connection (Module 5), installable offline PWA (Module 7), relationship graph, no-install launcher; produced this submission (summary, prompts, examples, executable, source, video script). |

## Prompting techniques used (Module 2: advanced prompting)

- **Role + context + constraints**: the agent was given a role (lead engineer), the source project as
  the "source of truth", a written plan, and explicit non-negotiables (14 critical requirements).
- **Phased, verifiable steps**: each phase had an exit check; "do not claim completion for
  placeholder screens or mocked persistence".
- **Evidence over assertion**: the prompt required exact commands and results, and asked that
  limitations be reported, not hidden.
- **Guardrails for privacy**: "fix the send-anyway path", "export from explicit allowlists",
  "scope restoration to tokens authorised for that request" — written as testable requirements.
