# Claude Fable 5.2 AuditShield Upgrade Prompt

Paste the following into Claude with the original project files and `AuditShield_Upgrade_Plan.md` available.

---

Act as the lead engineer upgrading my existing AuditShield capstone into a maintainable, polished, offline-first local application for CA audit work. Implement working features in phases and verify each phase. Use the attached project as the source of truth. Read `AuditShield_Upgrade_Plan.md` before coding.

## Current project

The attached `AuditShield_Project.zip` contains:

- `ghost_vendor/core.js`, `ui.js`, `template.html`: VendorShield, HMAC-based matching plus ten audit rules and a canvas graph.
- `ai_gateway/core.js`, `ui.js`, `template.html`: Indian identifier detection, masking, local vault, mock AI and an OpenAI-compatible HTTP request path.
- `sample_data`, `tests`, `build.py`, `dist`, documentation generators and diagrams.

The top-level HTML files match the archive builds. Keep an unchanged legacy reference. Reuse the existing domain logic where appropriate; do not recreate it blindly or change findings merely to make the screen look impressive.

The observed baseline is 10 employees, 12 vendors, 3 directors, 86 payments and 14 flags, including 2 critical, on VendorShield's synthetic sample. Total paid is INR 11,033,700; paid to vendors with high/critical findings is INR 5,116,715. Gateway's tiny built-in evaluation has 21 true positives, 1 false negative and 0 false positives. Reproduce these, then replace console-only checks with meaningful assertions. These numbers are sample results, not real-world accuracy guarantees.

## Platform decision

Default: React + TypeScript + Vite, Tailwind + shadcn/ui, Dexie + dexie-react-hooks for IndexedDB, TanStack Table + Virtual, Cytoscape.js, Papa Parse, Zod, React Hook Form, Vitest and Playwright. Use Web Crypto for new cryptographic operations. Add Recharts and a PWA plugin only when required by a phase. Check compatible stable versions and commit a lockfile. Avoid duplicate UI/state/database libraries.

Use one browser database engine in this release. If I explicitly require an installed Windows app and an ordinary SQLite database file, select the plan's Tauri + SQLite path before implementing persistence. Do not implement both databases or silently add cloud services.

## Product and interface

Build one AuditShield shell with engagement switching and navigation for Overview, Imports, VendorShield, AI Gateway, Workpapers, Activity and Settings. Move educational/privacy demonstrations to Demo / Learn.

Use a restrained professional design: neutral surfaces, navy/indigo primary colour, readable locally available typography, consistent spacing, aligned currency amounts, labelled Lucide icons and severity colours reserved for risk. Make every button work against real application state. Include empty/loading/error/success states, keyboard focus, accessible labels and responsive layouts.

VendorShield needs a sortable/filterable findings table, details panel, linked payment evidence, relationship graph/list, saved review status, notes and traceable workpaper export. The import wizard must support file-to-dataset assignment, column mapping, validation, error rows and immutable committed snapshots. A protected package must be importable in a fresh auditor workspace without raw files or HMAC keys.

The Gateway needs Compose → Review masked request → Answer, manual masking, clearly displayed destination, an enforced send gate, request-scoped token restoration, separate provider adapters and useful failure states. Offline demo/local model/external provider must be visually distinct.

## Critical requirements

1. Fix the current Gateway send-anyway path. Failed checks must block the request at the service boundary; disabled buttons alone are insufficient.
2. A scan is valid only for its exact text, watch-list, policy and destination. Changes invalidate approval. Check the complete outbound body, including any history, immediately before dispatch.
3. Export protected data from explicit allowlists. Current protection copies unknown input columns, and a probe confirmed an arbitrary private note survives unchanged. Decide explicitly whether names, DINs and references remain readable. Never export keys/vaults accidentally.
4. Client preparation and auditor analysis are separate trust contexts. A role/mode toggle or reveal checkbox is not security. Preserve a genuine protected-package handoff.
5. Preserve bank-account leading zeros and Unicode addresses; version normalisation and tokens. Validate GSTIN before deriving PAN. Mask likely identifiers even if their checksums fail; separate detection confidence from identifier validity.
6. Keep the deterministic rules as the baseline. Scores are heuristic review priorities, not fraud probabilities. Avoid double-counting payments across findings. Label payments under review separately from confirmed losses.
7. Persist engagements, protected entities/payments, immutable runs, findings, workpapers, settings and metadata audit events with transactions, indexes and migrations. Raw data and vault/prompt retention must be explicit and encrypted when enabled.
8. Use integer paise within safe numeric limits, string identifiers, ISO business dates and UTC event timestamps. Validate input and references before atomic commit.
9. Separate engagement HMAC keys from storage encryption. Use random keys, full new-format HMAC tokens, AES-GCM with unique nonces, versioned KDF/wrapping metadata and memory-held unlock keys. Do not invent cryptography or promise forensic erasure.
10. Add encrypted backup/restore, storage status, retention and safe migration failure handling. Test restore into a fresh profile. Do not rely on localStorage or browser persistence alone for irreplaceable work.
11. Do not embed API keys in source or frontend environment variables. Browser API keys are session-only by default. CORS, destination restrictions, timeout, cancellation and response validation must be handled explicitly.
12. Scope restoration to tokens authorised for that request. Invented or unrelated tokens must not reveal other vault entries. Use session-specific token namespaces.
13. Bundle runtime assets for offline use. Cache app assets only; never service-worker-cache prompts, secrets or AI responses. Never automatically replay queued cloud sends.
14. Keep pure domain functions independent of React/database APIs. Put persistence behind repositories, network calls behind provider services, and heavy processing behind worker interfaces.

## Implementation phases

Start by inspecting the actual files, recording known issues and creating `IMPLEMENTATION_STATUS.md`. Work in a separate upgrade directory or branch so original reference artifacts remain available.

**Phase 0:** Reproduce baseline results; add assertions and regression cases for unknown-column exports, stale state, leading-zero accounts, regional-script addresses, undetected names and send blocking. Record intentional future behaviour changes.

**Phase 1:** Build the typed application foundation and shared navigation. Port domain modules with verified behaviour. Deliver an app that launches and connects both modules to real state.

**Phase 2:** Implement repositories, database versions, transactions, locking, optional encrypted retention and encrypted backup/restore. Prove refresh/restart and fresh-profile restore.

**Phase 3:** Implement validated imports, protected-package schema/export/import and an independent auditor workflow. Prove that the auditor can analyse without raw data or keys.

**Phase 4:** Implement findings triage, graph/list, evidence details, persisted review decisions and workpaper exports. Define monetary metrics precisely.

**Phase 5:** Implement Gateway review, enforced outbound policy, request-scoped restoration, provider adapters and network verification. Do not assume all AI APIs use the same protocol.

**Phase 6:** Add worker-based processing, measured large-fixture performance, accessibility checks, offline installation/update behaviour and final documentation/demo updates.

For each phase, run the relevant unit/integration/browser checks, typecheck and production build. Report what changed, exact commands/results, any untested behaviour and the next bounded task. Keep `IMPLEMENTATION_STATUS.md` current. Do not claim completion for placeholder screens or mocked persistence. Keep progressing through agreed phases when the environment allows; if work spans chats, leave a precise resumable state.

## Completion evidence

Show an end-to-end run: create engagement → import validated CSVs → protect → open package in separate auditor workspace → analyse → review a finding → save a conclusion → restart → export → back up → restore into a fresh profile.

For the Gateway, intercept outbound requests and prove blocked attempts make no provider call, approved requests contain only reviewed masked content, setting changes invalidate scans, and invented tokens cannot reveal unrelated vault data. Test failures and cancellation as well as success.

Report masking accuracy by identifier type on a larger held-out synthetic corpus. Keep remaining misses visible. Benchmark representative 10k and 100k payment fixtures with the machine specification and actual timings; do not infer scalability from table virtualisation.

Begin now with Phase 0. Inspect the repository before proposing edits and base the implementation on the actual source.

---

## Optional follow-up prompts

Use these to steer a later phase without asking Claude to start over:

- **Persistence review:** “Review the current database implementation against the upgrade plan. Demonstrate transactional import, restart persistence, schema migration, encrypted backup and fresh-profile restore. Fix actual gaps and record results.”
- **UI refinement:** “Use the existing app and real data flows. Improve spacing, navigation, findings triage and gateway review. Verify keyboard focus, narrow layouts and error states. Preserve working persistence and domain behaviour.”
- **Privacy review:** “Trace every export and network path. Add tests showing unknown fields cannot escape, leak failures cannot send, stale scans cannot authorise a request and response tokens cannot reveal unrelated vault entries. Fix failures.”
- **Release review:** “Run the plan's acceptance checks. Report verified results separately from assumptions, fix release blockers, and update README, the demo script and implementation status to match the finished software.”
