# AuditShield — AICA Level 2 Capstone Project

**Private, offline vendor-fraud analysis and AI masking for Chartered Accountants.**

## Run it in one step (no installation)

Open `04_Executable_Files\AuditShield_App` and double-click **`START_AUDITSHIELD.bat`**.
The app opens at http://127.0.0.1:4173 in your browser (Edge or Chrome). Keep the small window open
while using it. Nothing is sent to the internet; all data stays in the browser on this computer.

Then: create a workspace (choose a passphrase) → **Create sample engagement** → Imports → **Load
sample data** → VendorShield → **Protect and save** → **Run analysis**.

## What is in this ZIP

| Folder | Contents |
| --- | --- |
| `01_Project_Summary_Document` | `AuditShield_Project_Summary.pdf`: problem, solution, mapping to the AICA Level 2 modules, architecture, results, how to run, limitations |
| `02_Prompt_Files` | The engineering prompt and plan given to the AI coding agent, the follow-up prompts, the AI Gateway system prompt, example user prompts |
| `03_Example_Files` | Sample client CSVs, CSVs with errors plus the generated error report, a protected package (`.aspackage`), an audit workpaper (`.html`), a masked AI request/answer walkthrough |
| `04_Executable_Files` | `AuditShield_App` (ready to run, no install) and the original single-file capstone apps |
| `05_Source_Code` | Complete source code and the automated tests |
| `06_Supporting_Documents` | Video recording script, full test results, engineering status report, screenshots |

## Verified

299 automated tests and 6 real-browser (Microsoft Edge) tests pass, including:
- CSV import → protection → protected package → **separate auditor workspace** reproduces all 14
  findings with no source data and no key;
- a local model (LM Studio–compatible) receives only the reviewed masked text; blocked requests
  never reach it;
- data survives reload, browser restart, and encrypted backup/restore into a fresh profile;
- the installed app starts with the network switched off; no request ever goes to another website.

All data in this project is synthetic. Findings are indicators for investigation, not conclusions.
