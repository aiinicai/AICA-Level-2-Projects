# AuditShield — presentation speech

**Presenter:** CA Yash Nama · Membership No. 632385 · AICA Level 2, Batch B109, Gandhinagar
**Length:** about 11–12 minutes · **Format:** recorded video, face visible throughout

How to read this script:
- *[Square brackets in italics]* = what to do on screen. Do not read them aloud.
- Normal text = what to say. Speak slowly; pause at each full stop.
- Lines marked **(optional)** can be dropped if you run long.

---

## Part 1 — Introduction (face to camera, about 1 minute)

Greetings for the day, Respected Sir / Ma'am.

My name is **Yash Nama**. My membership number is **632385**, and I am a participant of
**AICA Level 2, Batch B109, Gandhinagar**.

The title of my capstone project is **AuditShield — private, offline vendor-fraud analysis and
AI masking for Chartered Accountants.**

In one line: AuditShield lets a CA **test a client's vendors and payments for fraud**, and **use AI
on client documents**, *without ever exposing the client's confidential identifiers* — and it runs
completely offline, on my own laptop.

In the next few minutes I will explain the problem, show you the working application end to end,
and explain how it uses what we learnt across the five days of Level 2.

---

## Part 2 — The problem (face to camera or app setup screen, about 1 minute)

*[Optional: switch to the AuditShield setup screen while speaking.]*

As auditors, two everyday situations put client data at risk.

**First**, when we test for **ghost vendors, related parties, duplicate payments or split
payments** — areas covered by SA 240 and SA 550 — we need the most sensitive data a client has:
PAN numbers, bank account numbers, GSTINs, phone numbers and addresses of employees, vendors and
directors. That data gets copied into Excel files, emailed around, and stored on many laptops.

**Second**, we all want to use AI — to draft a reply to a GST notice, review a vendor ledger, or
answer a payroll query. But the moment we paste client text into a chatbot, those identifiers
leave our control.

Both situations conflict with our **duty of confidentiality** and with the principle of **data
minimisation** under the Digital Personal Data Protection Act, 2023.

So the question I asked was: **can we get the audit insight and the AI help, without exposing
the identifiers?** AuditShield is my answer.

---

## Part 3 — Setting up (about 30 seconds)

*[Setup screen: type your passphrase twice → click "Create workspace".]*

AuditShield is an installable web application that works without the internet. Everything is
stored in an **encrypted local database** inside this browser — engagement names, my notes and
conclusions are encrypted with AES-256, using a key that is protected by this passphrase.
Nothing is sent to any server.

---

## Part 4 — Importing client data (about 1 minute)

*[Overview → type "Mehta Industries audit" → Create engagement → Imports → choose the four
sample CSV files → point at "This file contains" and the column mapping → Validate → Load into
this engagement.]*

I have created an engagement for a **fictional** client, Mehta Industries. All data in this
demonstration is synthetic.

These four CSV files are what a client would export from Tally or Excel: employees, the vendor
master, directors, and payments.

AuditShield recognises each file from its **column names**, maps the columns, and **validates
every row** — duplicate IDs, impossible dates, wrong amounts, payments to vendors that do not
exist in the master. If there are problems, it lists them with row numbers and gives a
downloadable error report.

Two details matter to us as accountants: **leading zeros in bank account numbers are kept
exactly**, and **addresses in Hindi or Marathi are kept as they are**. And any column the app does
not recognise — say, an "internal remarks" column — is **dropped, never carried along**.

---

## Part 5 — Protecting the data and finding the red flags (about 2 minutes)

*[VendorShield → keep "Minimal" → click "Protect and save" → point at the 8 data-quality
warnings → click "Run analysis".]*

Now the key step: **protection**.

Every bank account, PAN, GSTIN, phone number and address is replaced by a **keyed token** —
technically an HMAC-SHA256 code made with a random secret key.

The idea is simple: **the same value always gives the same token, but you cannot get the value
back from the token.** So if a vendor and an employee have the same bank account, their tokens
will match — and we can detect it — but nobody looking at this data can see the account number.

It also flags data-quality issues — here, **8 GSTINs fail their check digit**.

*[Click "Run analysis".]*

Ten audit rules now run **only on the tokens**. The result: **14 findings — 2 critical, 10 high,
1 medium and 1 low.**

*[Click "Vendor V105 ↔ employee E107 (Accounts Payable): same bank account, PAN, phone number
and address".]*

Look at this critical finding. **Vendor V105 shares the same bank account, PAN, phone number and
address as employee E107, who works in Accounts Payable.** That is the classic **ghost vendor**
pattern. And it was detected without comparing a single real value.

*[Scroll to the relationship graph — it highlights the finding.]*

The relationship graph shows it visually: the vendor, the employee, and the four details they
share, highlighted in red.

*[Click the R7 split-payment finding, then the R6 duplicate-invoice finding.]*

Here are three payments to one vendor within three days, each just under the one-lakh approval
limit, but together above it — **invoice splitting**. And here, **the same invoice paid twice**.

*[Point at "Payments to vendors under review ₹51,16,715".]*

One important point of professional care: this figure, **₹51,16,715**, is the total paid to the
vendors under review. **It is spend to examine, not a loss.** AuditShield never calls anything
"fraud" — a finding is an **indicator for investigation**, and the conclusion is always the
auditor's.

---

## Part 6 — Recording the auditor's conclusion (about 45 seconds)

*[Open the duplicate-invoice finding → Status: "Confirmed issue" → click "Save review" (it asks
for a conclusion) → type a short conclusion → Save review → Workpapers → Export workpaper.]*

That is why every finding has a **review**. If I mark it as a confirmed issue, the app **insists
on a written conclusion** — just as our working papers should. Each review is versioned and
stored encrypted.

*[Open the exported workpaper.]*

The workpaper is generated in one click — with scope, thresholds, the payment evidence and my
conclusions — ready for the audit file.

---

## Part 7 — The client-to-auditor handoff (about 1.5 minutes)

*[Imports → scroll to "Hand over to the auditor" → point at the three lists → Export protected
package → briefly open the downloaded file in Notepad.]*

Now the most important idea of the project: **separating the client side from the auditor side.**

The client prepares the data and exports a **protected package**. The app states exactly what is
**readable**, what is **replaced by tokens**, and what is **not included at all**. You can open the
file in Notepad and check: there are **no names, no PAN, no bank numbers — and no secret key**.

*[Switch to the Edge InPrivate window → create a workspace → Overview → "Open a protected
package" → choose the file → point at "Package verified" → Open as new engagement → Run
analysis.]*

This InPrivate window is a completely separate workspace — think of it as **the auditor's
laptop**. When the package is opened, AuditShield verifies its checksum, its structure, and that
it contains nothing beyond what it declares.

*[After analysis.]*

And here is the result: **the same 14 findings** — but this workspace has **no source data and no
key.** The auditor gets the full insight, and the client's identifiers never left the client.

---

## Part 8 — The AI Gateway with an offline GPT (about 2 minutes)

*[Main window → AI Gateway. If LM Studio is running: "Set up a local model" → Check connection →
Save → select "Local model". Otherwise stay on "Offline demo".]*

The second module is the **AI Gateway** — how to use AI safely.

*(If using LM Studio:)* This is an **offline GPT running in LM Studio** on this same laptop —
exactly what we learnt in Module 5. The text never goes to the internet.

*(If not using LM Studio:)* For this recording I am using the built-in offline demo; the same
screen connects to an offline GPT in LM Studio, as we learnt in Module 5.

*[Click "Vendor ledger review" → Scan and mask.]*

I take a real-looking vendor ledger query. The gateway detects and masks the **PAN, bank account,
IFSC, UPI ID, phone number, the company name and the people's names.**

On the left is what I typed — it stays on my computer. On the right is **exactly** what the AI
will receive. Notice that amounts and dates are kept, so the AI can still do useful work.

*[Point at the Send button.]*

The Send button **names the destination**, so there is never any doubt where data is going.

*[Click Send → tick "Show real values on this screen".]*

The AI answers using only the codes. The real names are restored **only on my screen**, and only
for codes that were part of this request.

*[Copy a code like [PERSON_1_XXXX] from the right panel → type "Who is [PERSON_1_XXXX]?" →
Scan and mask → point at "Sending is blocked".]*

And here is the safety guarantee. If anything fails the checks, **sending is blocked by the
system itself** — there is **no "send anyway" button**. A model also cannot trick the app into
revealing people from earlier requests.

---

## Part 9 — Reliability (about 30 seconds)

*[Settings → show storage status and "Create backup file" → point at the Lock button.]*

Everything **survives a restart**, the workspace **locks itself** after inactivity, and the whole
workspace can be **backed up into one encrypted file** and restored on a fresh computer.

---

## Part 10 — How it connects to the AICA Level 2 learning (about 45 seconds)

*[Face to camera.]*

This project brings together what we learnt over the five days:

- From **Day 1**, AI agents and advanced prompting — I built this application with an AI coding
  agent, guiding it in phases with structured prompts, and verifying each phase with tests.
- From **Day 2**, **offline GPTs with LM Studio** — the gateway connects to a local model so
  client data stays on the machine; and system instructions with controlled model parameters.
- From **Day 3**, IDE-based development fundamentals.
- From **Day 4**, a **full-stack web application delivered as a Progressive Web App** — it can be
  installed and it starts even with the internet switched off.
- And from **Day 5**, **workflow automation** — import, validate, protect, analyse, review and
  report, as one connected workflow.

The application is verified by **299 automated tests and 6 real-browser tests**, including tests
that prove nothing is ever sent to the internet.

---

## Part 11 — Limitations and closing (face to camera, about 45 seconds)

I want to be transparent about the limits:

- The findings are **indicators**, not conclusions; professional judgement remains essential.
- Tokens are **pseudonyms, not anonymity** — record IDs, amounts and dates are still visible, so
  packages must still be shared confidentially.
- Accuracy has been measured on **synthetic sample data**, not on real client data.

To conclude: **AuditShield shows that we do not have to choose between using technology and
protecting our clients.** We can detect ghost vendors and use AI — while the client's identifiers
stay protected.

Thank you, Respected Sir / Ma'am, for your time and consideration.

---

## Quick answers if asked (keep for reference)

| Question | Short answer |
| --- | --- |
| Can the token be reversed? | Not without the secret key, which stays with the client. A plain hash of a phone number can be cracked in seconds; a keyed HMAC cannot be checked without the key. |
| What does the auditor see? | Record IDs, amounts, dates and departments; vendor and director names only if the client chooses the "Named" profile. |
| What if a name is missed by masking? | The user reviews the exact outgoing text and can mask anything by selecting it. Nothing the app recognises can ever be sent. |
| Why offline AI? | Client data never leaves the laptop — LM Studio runs the model locally. |
| Is it legally compliant? | It supports confidentiality and data minimisation; it does not by itself make anyone compliant. |

## Numbers to remember

- **14 findings**: 2 critical, 10 high, 1 medium, 1 low
- Total paid **₹1,10,33,700**; under review **₹51,16,715** (not a loss)
- Masking test: **21 of 22** identifiers caught, 0 false alarms (small synthetic set)
- **299 automated tests + 6 browser tests** pass
