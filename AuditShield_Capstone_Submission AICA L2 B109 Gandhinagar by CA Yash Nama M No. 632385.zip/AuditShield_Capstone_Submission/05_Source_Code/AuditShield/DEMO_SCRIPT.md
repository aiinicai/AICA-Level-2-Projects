# AuditShield — video recording script (AICA Level 2 capstone)

The guidelines ask for a video that shows **both your face and the technical content**, uploaded to
YouTube (Unlisted) or Google Drive with "Anyone with the link" access, and the link submitted in
the Google Form with the ZIP. Target length: **10–12 minutes**.

## 1. Before you record (15 minutes)

1. **Recording tool with webcam overlay**: any of these works on Windows —
   - **Clipchamp** (built into Windows 11): Record → *Screen and camera*.
   - **OBS Studio** (free): add *Display Capture* + *Video Capture Device*, put the webcam in a corner.
   - **Microsoft PowerPoint**: Record → *Screen Recording* does not show the face; use Clipchamp or OBS instead.
   Keep your face visible in a corner for the **whole** video; look at the camera for the intro and close.
2. **Start the app**: double-click `04_Executable_Files\AuditShield_App\START_AUDITSHIELD.bat`.
   The browser opens at `http://127.0.0.1:4173`. Keep the black window open.
3. **Second "auditor" window**: in Edge press **Ctrl+Shift+N** (InPrivate) and open the same address.
   InPrivate has separate storage, so it behaves as a different person's workspace.
   (In Chrome: Ctrl+Shift+N for Incognito.)
4. **Optional — LM Studio** (shows Module 5, Offline GPTs): open LM Studio, load a small instruct model
   (e.g. a 3–8 B model), Developer tab → start server, switch on **Enable CORS**. If you skip this,
   use the offline demo destination; say so in the video.
5. Have `03_Example_Files\sample_csv` open in File Explorer.
6. Browser zoom 110–125 %. Close unrelated tabs and notifications. Use only the synthetic sample data.
7. If you practised earlier: Settings → Delete data → "Delete all local data…" → type DELETE, so you
   start from the setup screen. Pick a passphrase you can type on camera (there is no recovery).

## 2. Running order and script

| Time | Screen / action | What to say (adapt in your own words) |
| --- | --- | --- |
| 0:00–0:45 | **Face to camera**, then the app's setup screen | "I am ___. My AICA Level 2 capstone is **AuditShield**: it lets a CA test vendor payments for fraud and use AI on client documents **without exposing client identifiers**. Everything runs offline on this laptop." |
| 0:45–1:45 | Stay on setup screen | "Two problems. One: ghost-vendor and related-party testing needs PANs, bank accounts and phone numbers. Two: pasting client text into a chatbot sends those identifiers outside. Our confidentiality duty and the DPDP Act both say minimise this. AuditShield solves both with pseudonymisation and an enforced review before anything leaves." |
| 1:45–2:15 | Create workspace (type passphrase twice) | "The workspace is an encrypted local database in the browser. Labels, notes and any retained data are AES-256 encrypted with a key protected by this passphrase. It is an installable app that also works with the internet off." |
| 2:15–3:30 | Overview → type label "Mehta Industries audit", **Create engagement** → **Imports** → choose the 4 sample CSVs → show **This file contains** and the column mapping → **Validate** → **Load into this engagement** | "These are exports a client would give us from Tally or Excel. The app suggests which file is which from its columns, maps them, and validates every row: duplicate IDs, impossible dates, amounts, vendors missing from the master. Columns it does not know are dropped, never carried along. Leading zeros and Hindi or Marathi addresses are kept exactly." *(Optional: load the files in `sample_csv_with_errors` first to show the row-level error report, then the good ones.)* |
| 3:30–4:30 | VendorShield → keep **Minimal** → **Protect and save** → point at data-quality warnings → **Run analysis** | "Protection replaces bank account, PAN, GSTIN, phone and address with keyed HMAC tokens. Equal values give equal tokens, so matches still work, but the values are gone and cannot be guessed without the key. It even warns that 8 GSTINs fail their check digit. Ten audit rules now run on the tokens: **14 findings, 2 critical**." |
| 4:30–5:45 | Click **Vendor V105 ↔ employee E107** → show reason, payments, then the **relationship graph** (it highlights) → click R7 split payment and R6 duplicate invoice | "Vendor V105 shares a bank account, PAN, phone and address with an employee in Accounts Payable — the classic ghost vendor — found without comparing a single real value. The graph shows the links; red is what this finding involves. Here is a split payment kept under the approval limit, and the same invoice paid twice." Point at **₹51,16,715**: "That is spend to examine, not a loss — the app never calls it fraud." |
| 5:45–6:30 | On the R6 finding: Status **Confirmed issue** → Save (shows the conclusion is required) → type a conclusion → Save | "A finding is only an indicator. My decision needs a written conclusion, it is versioned and stored encrypted." |
| 6:30–7:45 | Imports → **Hand over to the auditor** lists → **Export protected package** → open the downloaded file in Notepad briefly → switch to the **InPrivate window** → create a workspace → Overview → **Open a protected package** → show **Package verified** → **Open as new engagement** → **Run analysis** | "This is the client-to-auditor handoff. The package says exactly what is readable, tokenised and excluded — you can open it in Notepad: no names, no PAN, no bank numbers, no key. In a completely separate workspace the auditor opens it, the app verifies the checksum and structure, and the same 14 findings appear — with no source data and no key on this side." |
| 7:45–8:15 | Back in the main window → Workpapers → **Export workpaper (HTML)** → open it | "The workpaper has scope, thresholds, versions, payment evidence and my conclusions, ready for the audit file." |
| 8:15–10:00 | AI Gateway → (if LM Studio is running: **Set up a local model** → **Check connection** → **Save** → select **Local model**) → **Vendor ledger review** → **Scan and mask** → show left/right panels → **Send to: …** → tick **Show real values** | "Now AI. This is an offline GPT in LM Studio on this same laptop — Module 5. The gateway masks PAN, bank account, UPI, phone, names. Left is what I typed, right is exactly what the model receives. The Send button names the destination. The model answers in codes; the names come back only on my screen, and only for codes from this request." |
| 10:00–10:45 | Type `Who is [PERSON_1_XXXX]?` (copy a code from the right panel) → Scan → show **Sending is blocked** and the disabled button | "If anything fails the checks, the request service refuses — there is no send-anyway button and no override. A model cannot trick it into revealing other people from earlier requests either." |
| 10:45–11:15 | Settings: storage status, **Create backup file**; show the **Lock** button | "Everything survives a restart, locks on inactivity, and backs up to one encrypted file that restores into a fresh computer." |
| 11:15–12:00 | **Face to camera** | "Built with React, TypeScript and Web Crypto as a PWA, using an AI coding agent with a phased plan; **299 automated tests and 6 real-browser tests** verify it, including that nothing ever goes to the internet. Limits: findings are indicators, tokens are pseudonyms not anonymity, and accuracy is measured on a small synthetic set. Thank you." |

## 3. Numbers you may quote

- 14 findings: 2 critical, 10 high, 1 medium, 1 low (synthetic sample with planted patterns).
- Total paid ₹1,10,33,700; **payments to vendors under review ₹51,16,715** — never "fraud" or "loss".
- Masking: 21 of 22 identifiers on the built-in 18-sentence set, 0 false alarms; the one miss is shown in Demo / Learn.
- 299 automated tests, 6 real-browser tests, all passing.

## 4. Do not say

"Zero leakage", "anonymised", "fraud detected", "amount at risk", "tamper-proof", "secure deletion",
"guaranteed compliance", or any accuracy figure without "on our small synthetic set".

## 5. If something goes wrong while recording

- Reload the page and unlock — saved work is still there.
- LM Studio not responding: choose **Offline demo** and say the local model is optional.
- App will not start: open `04_Executable_Files\Original_Capstone_Single_File_Apps` and the example
  files (workpaper, package) to show the outputs, then re-record.

## 6. Likely judge questions

- **Can the hash be reversed?** A plain hash of a phone number can be cracked in seconds; these are HMAC tokens under a random 256-bit key that stays with the preparer.
- **What can the auditor see?** Record IDs, amounts, dates, departments, and — only if the preparer chooses the Named profile — vendor and director names.
- **What if masking misses a name?** The user reviews the exact outgoing text and can mask anything by selecting it; known values are re-masked everywhere. The guarantee is narrower: nothing the app recognises can be sent.
- **Why offline / local AI?** Client data never leaves the laptop; LM Studio runs the model locally (Module 5).
- **Is it compliant?** It supports confidentiality and data minimisation; it does not by itself make anyone compliant.
