/**
 * Writes the "Example Files" of the capstone submission from the app's own code, so every example
 * is a real output. Runs only when EXAMPLES_DIR is set:
 *   PowerShell:  $env:EXAMPLES_DIR='..\out'; npx vitest run tests/tools
 */
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { it } from 'vitest';
import { SAMPLE_PROMPTS } from '../../src/domain/privacy/evaluate';
import { buildOutboundMessages } from '../../src/domain/privacy/messages';
import { offlineDemoReply } from '../../src/domain/privacy/offlineDemo';
import { POLICY_VERSION, reviewScan } from '../../src/domain/privacy/policy';
import { restore, SessionVault } from '../../src/domain/privacy/vault';
import { buildDataset, errorsToCsv, type FileInput, suggestDataset, suggestMapping } from '../../src/domain/vendor/csvImport';
import { DEFAULT_RULE_CONFIG, MINIMAL_PROFILE } from '../../src/domain/vendor/types';
import { generateEngagementKey } from '../../src/services/crypto/tokeniser';
import { parseCsv } from '../../src/services/imports/csv';
import { OFFLINE_DEMO_DESTINATION } from '../../src/services/providers/offlineDemoProvider';
import { buildWorkpaperHtml } from '../../src/services/workpaper/exportHtml';
import { analyseSnapshot, exportPackage, getRuleConfig, protectAndCommit, setupWorkspace } from '../../src/services/workspace/useCases';
import { LEGACY_ROOT } from '../helpers/legacy';
import { newProfile, testClock, TEST_ITERATIONS } from '../helpers/profile';

const OUT = process.env['EXAMPLES_DIR'];

it.skipIf(!OUT)('generates the example files', async () => {
  const out = OUT as string;
  mkdirSync(join(out, 'sample_csv'), { recursive: true });
  mkdirSync(join(out, 'sample_csv_with_errors'), { recursive: true });

  // 1. Sample CSVs (the input) and an import that fails validation, with its error report.
  const files: FileInput[] = [];
  for (const t of ['employees', 'vendors', 'directors', 'payments']) {
    const text = readFileSync(join(LEGACY_ROOT, 'sample_data', `${t}.csv`), 'utf8');
    writeFileSync(join(out, 'sample_csv', `${t}.csv`), text);
    const parsed = parseCsv(text);
    const dataset = suggestDataset(parsed.headers);
    files.push({ name: `${t}.csv`, dataset, headers: parsed.headers, rows: parsed.rows, mapping: suggestMapping(dataset, parsed.headers) });
  }
  const badVendors = 'Supplier Code,Supplier Name,GST No,Bank A/c No,internal_remarks\nV1,Alpha Traders,27AAKCS4321M1Z1,000123456789,"owner is the purchase manager\'s cousin"\nV1,Beta Supplies,,11122233344401,\n,Gamma Co,,,';
  const badPayments = 'voucher_no,vendor_code,payment_date,amount\nP1,V1,31-02-2026,"₹1,25,000"\nP2,V9,05-01-2026,98500\nP3,V1,2026-01-07,abc';
  writeFileSync(join(out, 'sample_csv_with_errors', 'vendors_with_errors.csv'), badVendors);
  writeFileSync(join(out, 'sample_csv_with_errors', 'payments_with_errors.csv'), badPayments);
  const badFiles = [badVendors, badPayments].map((text, i) => {
    const parsed = parseCsv(text);
    const dataset = suggestDataset(parsed.headers);
    return { name: i ? 'payments_with_errors.csv' : 'vendors_with_errors.csv', dataset, headers: parsed.headers, rows: parsed.rows, mapping: suggestMapping(dataset, parsed.headers) };
  });
  writeFileSync(join(out, 'sample_csv_with_errors', 'example_import_error_report.csv'), errorsToCsv(buildDataset(badFiles).errors));

  // 2. Protect → snapshot → analyse → review two findings → package + workpaper.
  const clock = testClock('2026-11-16T09:00:00.000Z');
  const { repos } = await newProfile().open();
  const session = await setupWorkspace(repos, 'example passphrase 2026', clock, TEST_ITERATIONS);
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() },
    { name: 'Mehta Industries Pvt Ltd (fictional) - statutory audit', financialYear: '2025-26', kind: 'sample' }, clock.id());
  const raw = buildDataset(files).raw;
  const snapshot = await protectAndCommit(repos, session, { engagementId: engagement.id, raw, sourceType: 'csv', sourceLabel: 'sample CSVs', profile: MINIMAL_PROFILE, key: await generateEngagementKey(), retainDays: null }, clock);
  const run = await analyseSnapshot(repos, { engagementId: engagement.id, importId: snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, clock);
  const findings = await repos.runs.findings(run.id);
  const ghost = findings.find((f) => f.ruleId === 'R1')!;
  const duplicate = findings.find((f) => f.ruleId === 'R6')!;
  await repos.workpapers.save(session.dek, session.workspace.id, engagement.id, ghost.fingerprint,
    { status: 'confirmed-issue', notes: 'Vendor KYC and bank confirmation obtained; account holder matches the employee record.', conclusion: 'Vendor V105 is controlled by employee E107. Reported to the audit committee; payments under SA 240 follow-up.' }, { id: clock.id(), at: clock.now() });
  await repos.workpapers.save(session.dek, session.workspace.id, engagement.id, duplicate.fingerprint,
    { status: 'needs-information', notes: 'Requested credit note or recovery evidence for P0085 from accounts payable.', conclusion: '' }, { id: clock.id(), at: clock.now() });

  const pkg = await exportPackage(repos, { engagementId: engagement.id, importId: snapshot.id, financialYear: '2025-26' }, clock);
  writeFileSync(join(out, 'example_protected_package.aspackage'), pkg.text);

  const reviews = new Map();
  for (const record of await repos.workpapers.list(engagement.id)) {
    const view = await repos.workpapers.view(session.dek, session.workspace.id, record);
    reviews.set(view.fingerprint, view);
  }
  writeFileSync(join(out, 'example_workpaper.html'), buildWorkpaperHtml({
    engagementName: 'Mehta Industries Pvt Ltd (fictional) - statutory audit', financialYear: '2025-26', preparedAt: clock.now(),
    snapshot, run, ruleConfig: await getRuleConfig(repos, engagement.id), findings, reviews,
  }));

  // 3. AI Gateway: original prompt, masked outbound request, model answer, restored answer.
  const vault = new SessionVault('DEMO');
  const parts: string[] = ['# AI Gateway example (generated by the app\'s own code)', '',
    'Codes look like `[PERSON_1_DEMO]`: type, number, and a random per-session suffix. Only codes that were in the outgoing request are restored.', ''];
  for (const [name, text] of Object.entries(SAMPLE_PROMPTS)) {
    const scan = reviewScan({ text, watchlist: [], manualTerms: [], policyVersion: POLICY_VERSION, destination: OFFLINE_DEMO_DESTINATION, vaultNamespace: vault.namespace }, vault);
    const outbound = buildOutboundMessages(scan.masked);
    const answer = offlineDemoReply(scan.masked);
    const restored = restore(answer, vault, new Set(scan.tokens));
    parts.push(`## ${name}`, '', '### 1. What the user typed (stays on the computer)', '', '```text', text, '```', '',
      `### 2. Exactly what is sent (${scan.spans.length} items masked, ${scan.violations.length} unresolved checks)`, '', '```json', JSON.stringify({ messages: outbound }, null, 2), '```', '',
      '### 3. Answer as received (codes only)', '', '```text', answer, '```', '', '### 4. Answer shown to the user after local restoration', '', '```text', restored.text, '```', '');
  }
  writeFileSync(join(out, 'example_ai_gateway_masking.md'), parts.join('\n'));
});
