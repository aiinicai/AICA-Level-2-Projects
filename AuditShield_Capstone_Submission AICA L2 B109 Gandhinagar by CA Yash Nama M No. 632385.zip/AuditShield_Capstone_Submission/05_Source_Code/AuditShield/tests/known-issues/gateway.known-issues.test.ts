/**
 * KNOWN ISSUES — legacy Gateway core, reproduced as passing assertions.
 * See the header of vendorshield.known-issues.test.ts for how to read these. IDs match
 * IMPLEMENTATION_STATUS.md. UI-level issues (send-anyway, stale scans) are in
 * legacy-ui.known-issues.test.ts.
 * Phase 1 update: targets already met by the new modules were removed from the todo lists below
 * and are asserted in tests/unit/gateway.domain.test.ts and tests/parity/privacy.parity.test.ts.
 * The remaining it.todo entries are still open.
 */
import { describe, expect, it } from 'vitest';
import { type LegacyAG, loadLegacyCore, plain } from '../helpers/legacy';

const AG = loadLegacyCore<LegacyAG>('ai_gateway');

function scan(text: string, watchlist?: string[]) {
  const vault = new AG.Vault();
  const masked = AG.mask(text, vault, { watchlist });
  const leak = AG.leakCheck(masked.masked, vault, { watchlist });
  return { vault, masked: masked.masked, detections: plain(masked.detections.map((d) => [d.type, d.value])), leak };
}

describe('KI-G03 [P0] the leak check only re-runs the same detector', () => {
  it('a lowercase untitled name is not detected and both leak lists are empty', () => {
    const r = scan('the director ramesh gupta approved it');
    expect(r.detections).toEqual([]);
    expect(r.masked).toContain('ramesh gupta');
    expect(r.leak.leaks).toHaveLength(0);
    expect(r.leak.redetect).toHaveLength(0);
  });

  it('a Devanagari name with an honorific is not detected either', () => {
    const r = scan('श्री राजेश कुलकर्णी ने भुगतान स्वीकृत किया');
    expect(r.detections).toEqual([]);
    expect(r.leak.leaks.length + r.leak.redetect.length).toBe(0);
  });

  it('an unlisted project/client name passes untouched unless someone adds it to the watch-list', () => {
    expect(scan('Project Falcon budget for Zenith Corp').masked).toBe('Project Falcon budget for Zenith Corp');
  });

  it.todo('TARGET [Phase 5/6]: per-type recall on a held-out corpus with lowercase and regional-script names is reported, misses included');
});

describe('KI-G04 [P1] checksum failure silently drops a likely identifier', () => {
  it('a 12-digit Aadhaar-shaped number with a wrong check digit and no keyword is sent in clear', () => {
    const base = '7341 5298 016';
    const wrong = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
      .map((d) => base + d)
      .filter((n) => !AG.verhoeff.valid(n.replace(/\D/g, '')));
    expect(wrong).toHaveLength(9);
    for (const number of wrong) {
      const r = scan(`ref ${number} submitted by the employee`);
      expect(r.detections, number).toEqual([]);
      expect(r.masked).toContain(number);
    }
  });

  it('a 16-digit card-shaped number that fails Luhn is sent in clear, even after the word "card"', () => {
    for (const text of ['paid by 4111 1111 1111 1112', 'card 4111 1111 1111 1112']) {
      const r = scan(text);
      expect(r.detections, text).toEqual([]);
      expect(r.masked).toBe(text);
    }
  });

  it('detections carry no validity or confidence information', () => {
    const [valid] = AG.detect('GSTIN 27AAKCS4321M1Z1');
    const [invalid] = AG.detect('GSTIN 27AAKCS4321M1Z9');
    expect(Object.keys(valid ?? {}).sort()).toEqual(['end', 'start', 'type', 'value']);
    expect(Object.keys(invalid ?? {}).sort()).toEqual(['end', 'start', 'type', 'value']);
  });

});

describe('KI-G05 [P0] restoration is global: any token-shaped text reveals vault entries', () => {
  // One long-lived vault, as in the legacy UI: request A stored these people.
  const vault = new AG.Vault();
  AG.mask(AG.SAMPLES['Vendor ledger review'] ?? '', vault, {});

  it('an answer to an unrelated request can pull out values it was never given', () => {
    const laterRequest = AG.mask('Summarise the TDS position for FY 2025-26.', vault, {});
    expect(laterRequest.detections).toHaveLength(0);
    const hostileAnswer = 'As noted, [PERSON_2] approved it and the PAN is [PAN_1].';
    expect(AG.unmask(hostileAnswer, vault)).toBe('As noted, Anita Deshpande approved it and the PAN is AFZPS1234Q.');
  });

  it('even a bare PERSON_1 without brackets is restored', () => {
    expect(AG.unmask('Ask PERSON_1 about it', vault)).toBe('Ask Rohit Shinde about it');
  });

  it('tokens are guessable sequential names shared by every request in the session', () => {
    expect(Object.keys(vault.rev)).toEqual([
      '[ORG_1]', '[PAN_1]', '[BANK_AC_1]', '[IFSC_1]', '[UPI_1]', '[PERSON_1]', '[PHONE_1]', '[PERSON_2]',
    ]);
  });

  it('literal "[PERSON_1]" typed by the user collides with a real token and is "restored" to a name', () => {
    const fresh = new AG.Vault();
    const m = AG.mask('Refer to [PERSON_1] placeholder in the template for Mr. Amit Shah', fresh, {});
    expect(m.masked).toBe('Refer to [PERSON_1] placeholder in the template for Mr. [PERSON_1]');
    expect(AG.unmask(m.masked, fresh)).toBe('Refer to Amit Shah placeholder in the template for Mr. Amit Shah');
  });

});

describe('KI-G06 [P1] name propagation is case-sensitive while the leak check is not', () => {
  it('a later lowercase mention stays visible; only the leak list notices it', () => {
    const r = scan('Mr. Rohit Shinde approved it. Later rohit shinde called.');
    expect(r.masked).toBe('Mr. [PERSON_1] approved it. Later rohit shinde called.');
    expect(plain(r.leak.leaks)).toEqual([{ tok: '[PERSON_1]', val: 'Rohit Shinde' }]);
  });

});

describe('KI-G07 [P2] watch-list handling', () => {
  it('terms of one or two characters are ignored without any message', () => {
    expect(scan('Client AB owes Rs. 5,000', ['AB']).detections).toEqual([]);
  });

  it('terms match inside other words', () => {
    expect(scan('Mehtab Stores invoice', ['Mehta']).masked).toBe('[CUSTOM_1]b Stores invoice');
  });

});
