/**
 * KNOWN ISSUES — legacy UI behaviour (legacy/dist/*.html run against a fake DOM).
 *
 * These reproduce the state-handling and send-path defects that live in ui.js rather than core.js.
 * The fake DOM is the legacy smoke harness made observable; it proves what the handlers do with
 * application state and whether fetch is called. It is not a rendering or accessibility test.
 * Phase 1 update: targets already met by the new modules were removed from the todo lists below
 * and are asserted in tests/unit/gateway.domain.test.ts and tests/unit/app.state.test.ts.
 * The remaining it.todo entries are still open.
 */
import { describe, expect, it } from 'vitest';
import { bootLegacyApp, stripTags } from '../helpers/legacy';

const GATEWAY = 'CA_Safe_AI_Gateway.html';
const VENDORSHIELD = 'VendorShield_GhostVendorDetector.html';
const click = (el: { onclick?: (ev?: unknown) => unknown } | undefined) => {
  if (!el?.onclick) throw new Error('element has no click handler');
  return el.onclick();
};
const bodyOf = (call: { init: { body?: string } } | undefined) =>
  JSON.parse(call?.init.body ?? '{}') as { model: string; messages: { role: string; content: string }[] };

describe('KI-G01 [P0] the Gateway sends despite a failed leak check', () => {
  const LEAKY = 'Mr. Rohit Shinde approved it. Later rohit shinde called.';

  function scanLeaky() {
    const app = bootLegacyApp(GATEWAY);
    app.control.provider = 'api';
    app.els['input']!.value = LEAKY;
    click(app.els['scanBtn']);
    return app;
  }

  it('Send is enabled right after a scan that reported a possible leak', () => {
    const app = scanLeaky();
    expect(stripTags(app.els['leak']!.innerHTML)).toContain('Possible leak: 1 item(s) still visible');
    expect(app.els['sendBtn']!.disabled).toBe(false);
  });

  it('one OK on a confirm() dialog transmits the leaking text to the provider', async () => {
    const app = scanLeaky();
    app.control.confirmAnswer = true;
    await click(app.els['sendBtn']);
    expect(app.confirms).toEqual(['Leak warning: send anyway?']);
    expect(app.fetchCalls).toHaveLength(1);
    expect(app.fetchCalls[0]?.url).toBe('https://api.openai.com/v1/chat/completions');
    expect(bodyOf(app.fetchCalls[0]).messages[1]?.content).toContain('rohit shinde');
  });

  it('the only barrier is that dialog: there is no service-level gate', async () => {
    const app = scanLeaky();
    app.control.confirmAnswer = false;
    await click(app.els['sendBtn']);
    expect(app.fetchCalls).toHaveLength(0);
  });

  it.todo('TARGET [Phase 5]: calling the provider service directly with an unapproved request makes zero network calls');
});

describe('KI-G02 [P1] a scan stays "approved" after its inputs change', () => {
  it('editing the watch-list after scanning does not invalidate the scan, and the term is sent', async () => {
    const app = bootLegacyApp(GATEWAY);
    app.control.provider = 'api';
    app.els['input']!.value = 'Project Falcon budget for Zenith Corp';
    click(app.els['scanBtn']);

    app.els['watch']!.value = 'Project Falcon';
    expect(app.els['watch']!.oninput).toBeUndefined();
    expect(app.els['watch']!.onchange).toBeUndefined();
    expect(app.els['sendBtn']!.disabled).toBe(false);

    await click(app.els['sendBtn']);
    expect(app.confirms).toEqual([]);
    expect(bodyOf(app.fetchCalls[0]).messages[1]?.content).toBe('Project Falcon budget for Zenith Corp');
  });

  it('changing the destination and model after scanning sends the old scan to the new destination', async () => {
    const app = bootLegacyApp(GATEWAY);
    app.control.provider = 'api';
    click(app.els['scanBtn']);
    app.els['apiUrl']!.value = 'http://other-host.example/v1/chat/completions';
    app.els['apiModel']!.value = 'some-other-model';
    await click(app.els['sendBtn']);
    expect(app.fetchCalls[0]?.url).toBe('http://other-host.example/v1/chat/completions');
    expect(bodyOf(app.fetchCalls[0]).model).toBe('some-other-model');
  });

  it('switching from the offline demo to the external provider after scanning also needs no rescan', async () => {
    const app = bootLegacyApp(GATEWAY);
    click(app.els['scanBtn']);
    app.control.provider = 'api';
    await click(app.els['sendBtn']);
    expect(app.fetchCalls).toHaveLength(1);
  });

  it('editing the prompt text does reset the scan (the one input that is wired)', () => {
    const app = bootLegacyApp(GATEWAY);
    click(app.els['scanBtn']);
    expect(app.els['sendBtn']!.disabled).toBe(false);
    app.els['input']!.value += ' more';
    app.els['input']!.oninput?.();
    expect(app.els['sendBtn']!.disabled).toBe(true);
  });

});

describe('KI-G08 [P0] an undetected name is presented as a passed leak test', () => {
  it('the UI says "Leak test passed … 0 found" while the name is still in the outgoing text', () => {
    const app = bootLegacyApp(GATEWAY);
    app.els['input']!.value = 'the director ramesh gupta approved it';
    click(app.els['scanBtn']);
    expect(stripTags(app.els['leak']!.innerHTML)).toMatch(/Leak test passed.*0 found/);
    expect(stripTags(app.els['chips']!.innerHTML)).toBe('No identifiers found');
    expect(stripTags(app.els['masked']!.innerHTML)).toContain('ramesh gupta');
  });

});

describe('KI-G09 [P1] the provider call has no destination policy, timeout, cancellation or response validation', () => {
  it('any URL is accepted (plain http to an arbitrary host) and no AbortSignal is passed', async () => {
    const app = bootLegacyApp(GATEWAY);
    app.control.provider = 'api';
    app.els['apiUrl']!.value = 'http://collector.example/anything';
    app.els['apiKey']!.value = 'sk-test-not-a-real-key';
    click(app.els['scanBtn']);
    await click(app.els['sendBtn']);
    const call = app.fetchCalls[0];
    expect(call?.url).toBe('http://collector.example/anything');
    expect(call?.init.signal).toBeUndefined();
    expect(call?.init.headers?.['Authorization']).toBe('Bearer sk-test-not-a-real-key');
  });

  it('an unexpected 200 response shape surfaces as a raw JavaScript error message', async () => {
    const app = bootLegacyApp(GATEWAY);
    app.control.provider = 'api';
    app.control.fetchImpl = async () => ({ ok: true, json: async () => ({ unexpected: true }) });
    click(app.els['scanBtn']);
    await click(app.els['sendBtn']);
    expect(stripTags(app.els['final']!.innerHTML)).toMatch(/^AI call failed: .*(undefined|reading)/);
  });

  it('a non-JSON error body hides the HTTP status behind a parse error', async () => {
    const app = bootLegacyApp(GATEWAY);
    app.control.provider = 'api';
    app.control.fetchImpl = async () => ({
      ok: false,
      statusText: 'Too Many Requests',
      json: async () => {
        throw new SyntaxError('Unexpected token < in JSON');
      },
    });
    click(app.els['scanBtn']);
    await click(app.els['sendBtn']);
    const message = stripTags(app.els['final']!.innerHTML);
    expect(message).toContain('Unexpected token');
    expect(message).not.toContain('Too Many Requests');
  });

  it.todo('TARGET [Phase 5]: destinations are restricted by scheme/host policy; http only for an explicitly chosen local endpoint');
  it.todo('TARGET [Phase 5]: every request has a timeout and a user-visible Cancel wired to AbortController');
  it.todo('TARGET [Phase 5]: provider responses are schema-validated; auth, rate-limit and invalid-JSON errors are distinct');
  it.todo('TARGET [Phase 5]: OpenAI-compatible and other provider protocols live in separate adapters');
});

describe('KI-G10 [P0] "Reveal real values (partner/manager only)" is an unguarded checkbox', () => {
  it('ticking it shows every vault value; nothing checks who is asking', async () => {
    const app = bootLegacyApp(GATEWAY);
    click(app.els['scanBtn']);
    await click(app.els['sendBtn']);

    app.els['reveal']!.onchange?.();
    expect(app.els['vault']!.innerHTML).not.toContain('Rohit Shinde');
    app.els['reveal']!.checked = true;
    app.els['reveal']!.onchange?.();
    expect(app.els['vault']!.innerHTML).toContain('Rohit Shinde');
    expect(app.els['vault']!.innerHTML).toContain('60112233445566');
  });

  it('the session log keeps a 90-character preview of whatever was sent', async () => {
    const app = bootLegacyApp(GATEWAY);
    app.els['input']!.value = 'the director ramesh gupta approved it';
    click(app.els['scanBtn']);
    await click(app.els['sendBtn']);
    app.els['reveal']!.onchange?.();
    expect(app.els['log']!.innerHTML).toContain('ramesh gupta');
  });

  // Phase 2: reveal now exists only inside an unlocked workspace, reverts after 60 seconds and writes a
  // metadata activity event (asserted in tests/e2e/gateway-storage.spec.ts; the 60-second revert is not
  // covered by an automated test).
  it.todo('TARGET [Phase 5]: activity records hold counts and metadata only; prompt text is retained only when explicitly enabled, encrypted');
});

describe('KI-V10 [P1] VendorShield keeps showing results for data that is no longer loaded', () => {
  async function loadProtectAnalyse() {
    const app = bootLegacyApp(VENDORSHIELD);
    click(app.els['loadSample']);
    click(app.els['protect']);
    click(app.els['runBtn']);
    return app;
  }
  const flagCards = (html: string) => (html.match(/class="flag /g) ?? []).length;

  it('after uploading a different dataset, Analyse and Download still use the previous protected data', async () => {
    const app = await loadProtectAnalyse();
    expect(flagCards(app.els['flags']!.innerHTML)).toBe(14);

    await app.els['upload']!.onchange?.({
      target: { files: [{ name: 'employees.csv', text: async () => 'emp_id,name\nE900,Solo Person' }] },
    });
    expect(app.els['loadMsg']!.textContent).toBe('Loaded: employees (1)');

    // Nothing was invalidated: the auditor tabs stay enabled and re-running analyses stale data.
    expect(app.els['nav3']!.disabled).toBe(false);
    app.els['flags']!.innerHTML = '';
    click(app.els['runBtn']);
    expect(flagCards(app.els['flags']!.innerHTML)).toBe(14);

    click(app.els['dlProtected']);
    const exported = JSON.parse(app.downloads.at(-1)?.text ?? '{}') as { vendors: unknown[]; employees: unknown[] };
    expect(exported.vendors).toHaveLength(12);
    expect(exported.employees).toHaveLength(10);
  });

  it('upload assigns files to datasets purely by filename; other names are rejected with an alert', async () => {
    const app = bootLegacyApp(VENDORSHIELD);
    await app.els['upload']!.onchange?.({
      target: { files: [{ name: 'master_export_2026.csv', text: async () => 'vendor_id,vendor_name\nV1,A' }] },
    });
    expect(app.alerts).toEqual([
      'No recognised files. Name them employees.csv, vendors.csv, directors.csv, payments.csv',
    ]);
  });

  it('the page ships with a default HMAC key in its HTML', () => {
    expect(bootLegacyApp(VENDORSHIELD).els['key']!.value).toBe('Client@Secret#2026');
  });

  it('client preparation and auditor analysis share one page and one memory; there is no package import', () => {
    const app = bootLegacyApp(VENDORSHIELD);
    const ids = Object.keys(app.els);
    expect(ids).toContain('dlProtected');
    expect(ids.filter((id) => /import|openpackage|loadprotected/i.test(id))).toEqual([]);
  });

  it.todo('TARGET [Phase 3]: every result is tied to an immutable import snapshot; new source data cannot be shown with old results');
  it.todo('TARGET [Phase 3]: datasets are assigned in the wizard by the user, never inferred from filenames');
  it.todo('TARGET [Phase 3]: a protected package opens in a fresh auditor workspace holding no raw rows and no HMAC key');
});
