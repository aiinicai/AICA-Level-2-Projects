/**
 * KNOWN ISSUES — legacy VendorShield core, reproduced as passing assertions.
 *
 * Each `KI-Vnn` test pins down a defect of the frozen legacy code so that it is documented by
 * something executable. They pass because the legacy code is wrong in exactly this way. The
 * `it.todo` entries below each one state the behaviour the upgraded modules must have; they turn
 * into real tests against the new code in the phase named in brackets.
 * IDs match IMPLEMENTATION_STATUS.md.
 * Phase 1 update: targets already met by the new modules were removed from the todo lists below
 * and are asserted in tests/unit/vendor.domain.test.ts and tests/parity/vendor.parity.test.ts.
 * The remaining it.todo entries are still open.
 */
import { describe, expect, it } from 'vitest';
import { type LegacyAG, type LegacyGV, loadLegacyCore, plain } from '../helpers/legacy';

const GV = loadLegacyCore<LegacyGV>('ghost_vendor');
const AG = loadLegacyCore<LegacyAG>('ai_gateway');
const KEY = 'ClientSecret#2026';
const rules = (flags: { rule: string }[]) => flags.map((f) => f.rule.split(' ')[0]);

describe('KI-V01 [P0] protection copies unknown input columns', () => {
  it('an unmapped vendor column survives protection unchanged', () => {
    const data = GV.sampleData();
    const first = data.vendors[0];
    if (!first) throw new Error('sample has no vendors');
    first['extra_notes'] = 'Owner Mr. X, PAN ABCDE1234F, cell 9811122233';
    const prot = GV.protect(data, KEY);
    expect(prot.vendors[0]?.['extra_notes']).toBe('Owner Mr. X, PAN ABCDE1234F, cell 9811122233');
  });

  it('the payments table is copied wholesale, so a narration carrying an account number escapes', () => {
    const data = GV.sampleData();
    const first = data.payments[0];
    if (!first) throw new Error('sample has no payments');
    first['narration'] = 'NEFT to a/c 50100234567812 (Anita Deshpande)';
    expect(GV.SENSITIVE.payments).toEqual([]);
    expect(JSON.stringify(GV.protect(data, KEY).payments)).toContain('50100234567812 (Anita Deshpande)');
  });

  it.todo('TARGET [Phase 3]: the import wizard reports unmapped columns and requires them to be dropped or classified');
});

describe('KI-V02 [P0] names, DINs, departments and references stay readable', () => {
  const blob = JSON.stringify(GV.protect(GV.sampleData(), KEY));

  it.each([
    ['director name', 'Prakash Mehta'],
    ['DIN', 'DIN01234567'],
    ['vendor name', 'Sai Traders'],
    ['employee department', 'Accounts Payable'],
    ['invoice reference', 'INV-107-100'],
  ])('%s is present in the "protected" file', (_label, value) => {
    expect(blob).toContain(value);
  });

  it('the legacy "0 leaks" counter cannot notice this: it only searches SENSITIVE columns', () => {
    expect(GV.SENSITIVE.directors).not.toContain('director_name');
    expect(GV.SENSITIVE.directors).not.toContain('din');
    expect(GV.SENSITIVE.vendors).not.toContain('vendor_name');
  });

  it.todo('TARGET [Phase 3]: the package preview lists every readable field before export');
});

describe('KI-V03 [P1] bank-account normalisation strips leading zeros', () => {
  it('00123456789 and 123456789 normalise to the same string', () => {
    expect(GV.normalize('bank_account', '00123456789')).toBe('123456789');
    expect(GV.normalize('bank_account', '123456789')).toBe('123456789');
  });

  it('two different accounts therefore raise a false Critical ghost-vendor finding', () => {
    const prot = GV.protect(
      {
        employees: [{ emp_id: 'E1', name: 'A', bank_account: '123456789' }],
        vendors: [{ vendor_id: 'V1', vendor_name: 'Zed Supplies', bank_account: '00123456789' }],
      },
      KEY,
    );
    const result = GV.analyze(prot);
    expect(prot.vendors[0]?.['bank_account']).toBe(prot.employees[0]?.['bank_account']);
    expect(plain(result.flags.map((f) => [f.rule.split(' ')[0], f.severity]))).toEqual([['R1', 'Critical']]);
  });

  it('an all-zero account normalises to empty and is silently unmatched', () => {
    expect(GV.normalize('bank_account', '0000')).toBe('');
  });

  it.todo('TARGET [Phase 3]: placeholder accounts (all zeros, too short) are data-quality errors, not silent blanks');
});

describe('KI-V04 [P1] address normalisation deletes non-Latin text', () => {
  it('a Devanagari address normalises to an empty string', () => {
    expect(GV.normalize('address', 'पुणे')).toBe('');
  });

  it('two different Devanagari addresses sharing a house number collapse to "12" and falsely match', () => {
    expect(GV.normalize('address', '12 गणेश सोसायटी, पुणे')).toBe('12');
    expect(GV.normalize('address', '12 शांति नगर, मुंबई')).toBe('12');
    const result = GV.analyze(
      GV.protect(
        {
          employees: [{ emp_id: 'E1', name: 'A', address: '12 शांति नगर, मुंबई' }],
          vendors: [{ vendor_id: 'V1', vendor_name: 'Zed Supplies', address: '12 गणेश सोसायटी, पुणे' }],
        },
        KEY,
      ),
    );
    expect(rules(result.flags)).toEqual(['R3']);
  });

  it('a genuinely shared pure-script address is never matched (false negative)', () => {
    const result = GV.analyze(
      GV.protect(
        {
          employees: [{ emp_id: 'E1', name: 'A', address: 'गणेश सोसायटी, पुणे' }],
          vendors: [{ vendor_id: 'V1', vendor_name: 'Zed Supplies', address: 'गणेश सोसायटी, पुणे' }],
        },
        KEY,
      ),
    );
    expect(result.flags).toHaveLength(0);
  });

  it('accented Latin letters are dropped as well', () => {
    expect(GV.normalize('address', 'Café Road 5')).toBe('caf road 5');
  });

});

describe('KI-V05 [P1] tokens are HMAC-SHA256 truncated to 64 bits', () => {
  it('every token is "H:" + 16 hex characters with no algorithm, key or normalisation version', () => {
    const prot = GV.protect(GV.sampleData(), KEY);
    expect(prot.vendors[0]?.['pan']).toMatch(/^H:[0-9a-f]{16}$/);
    expect(prot.vendors[0]?.['pan']).toBe('H:' + GV.hmacHex(KEY, 'pan|AABCD1234E').slice(0, 16));
  });

  it('the key is a typed password used directly as the HMAC key; any 8 characters are accepted', () => {
    expect(() => GV.protect(GV.sampleData(), 'password')).not.toThrow();
  });

  it.todo('TARGET [Phase 3]: legacy 16-hex packages import only through a separate, clearly labelled legacy path');
});

describe('KI-V06 [P1] PAN is derived from GSTIN without validating the GSTIN', () => {
  it('derives a "PAN" from a string that is not a GSTIN at all, and it can match a real field', () => {
    const prot = GV.protect(
      {
        employees: [{ emp_id: 'E1', pan: 'T-A-GSTIN-' }],
        vendors: [{ vendor_id: 'V1', vendor_name: 'Zed Supplies', gstin: 'NOT-A-GSTIN-AT-ALL', pan: '' }],
      },
      KEY,
    );
    expect(prot.vendors[0]?.['pan']).toBe(prot.employees[0]?.['pan']);
  });

  it('slices before normalising, so a spaced but genuine GSTIN yields the wrong PAN and the match is lost', () => {
    const prot = GV.protect(
      {
        employees: [{ emp_id: 'E1', pan: 'AAKCS4321M' }],
        vendors: [
          { vendor_id: 'V1', vendor_name: 'Spaced', gstin: '27 AAKCS4321M 1Z1', pan: '' },
          { vendor_id: 'V2', vendor_name: 'Compact', gstin: '27AAKCS4321M1Z1', pan: '' },
        ],
      },
      KEY,
    );
    expect(prot.vendors[1]?.['pan']).toBe(prot.employees[0]?.['pan']);
    expect(prot.vendors[0]?.['pan']).not.toBe(prot.employees[0]?.['pan']);
  });

  it('8 of the 10 GSTINs in the synthetic sample fail the GSTIN check digit', () => {
    // Relevant to the planned validation: the sample vendors all carry an explicit PAN, so no
    // derivation happens and findings are unaffected, but import validation will warn on these.
    const gstins = GV.sampleData().vendors.map((v) => v['gstin'] ?? '').filter(Boolean);
    expect(gstins).toHaveLength(10);
    expect(gstins.filter((g) => AG.gstinValid(g))).toEqual(['27AABCD1234E1Z8', '27AADCP3456M1Z1']);
  });

});

describe('KI-V07 [P1] no input validation before analysis', () => {
  it('an Indian-formatted amount ("1,25,000") turns the population total into NaN', () => {
    const result = GV.analyze({
      vendors: [{ vendor_id: 'V1', vendor_name: 'A' }],
      payments: [{ payment_id: 'P1', vendor_id: 'V1', invoice_no: 'I1', date: '2025-04-01', amount: '1,25,000' }],
    });
    expect(result.summary.totalPaid).toBeNaN();
  });

  it('duplicate payment IDs and a payment to an unknown vendor are accepted silently', () => {
    const result = GV.analyze({
      vendors: [{ vendor_id: 'V1', vendor_name: 'A' }],
      payments: [
        { payment_id: 'P1', vendor_id: 'V1', invoice_no: 'I1', date: '2025-04-01', amount: 100 },
        { payment_id: 'P1', vendor_id: 'V-UNKNOWN', invoice_no: 'I2', date: '2025-04-02', amount: 200 },
      ],
    });
    expect(result.summary.payments).toBe(2);
    expect(result.flags).toHaveLength(0);
  });

  it('a payment without a date crashes the whole analysis', () => {
    expect(() =>
      GV.analyze({
        payments: [
          { payment_id: 'P1', vendor_id: 'V1', amount: 5 },
          { payment_id: 'P2', vendor_id: 'V1', amount: 5 },
        ],
      }),
    ).toThrow(/localeCompare/); // TypeError raised inside the vm realm
  });

  it('amounts are binary floating-point rupees, not integer paise', () => {
    const result = GV.analyze({
      payments: [
        { payment_id: 'P1', vendor_id: 'V1', invoice_no: 'A', date: '2025-04-01', amount: '0.10' },
        { payment_id: 'P2', vendor_id: 'V1', invoice_no: 'B', date: '2025-05-01', amount: '0.20' },
      ],
    });
    expect(result.summary.totalPaid).not.toBe(0.3);
    expect(result.summary.totalPaid).toBeCloseTo(0.3, 10);
  });

  it.todo('TARGET [Phase 3]: invalid amounts/dates, duplicate IDs and orphan vendor references block the atomic commit');
});

describe('KI-V08 [P2] R6 treats any repeated vendor + invoice number as a double payment', () => {
  const result = GV.analyze({
    vendors: [{ vendor_id: 'V1', vendor_name: 'A' }],
    payments: [
      { payment_id: 'P1', vendor_id: 'V1', invoice_no: 'I1', date: '2025-04-01', amount: 40000 },
      { payment_id: 'P2', vendor_id: 'V1', invoice_no: 'I1', date: '2025-06-02', amount: 60000 },
      { payment_id: 'P3', vendor_id: 'V1', invoice_no: 'I1', date: '2025-08-01', amount: 10000 },
    ],
  });
  const r6 = result.flags.filter((f) => f.rule.startsWith('R6'));

  it('three instalments of different amounts produce two "paid twice" findings', () => {
    expect(plain(r6.map((f) => ({ amount: f.amount, payments: f.payments, title: f.title })))).toEqual([
      { amount: 60000, payments: ['P1', 'P2'], title: 'Invoice I1 of A paid twice (P1 and P2)' },
      { amount: 10000, payments: ['P1', 'P3'], title: 'Invoice I1 of A paid twice (P1 and P3)' },
    ]);
  });

  it.todo('TARGET [Phase 4]: repeated vendor + invoice is one candidate group with all payments and amounts as evidence');
  it.todo('TARGET [Phase 4]: differing amounts are labelled "possible instalments", not "paid twice"');
});

describe('KI-V09 [P2] monetary figures overlap and relationship findings carry no payment evidence', () => {
  const data = GV.sampleData();
  const result = GV.analyze(GV.protect(data, KEY));

  it('Sai Traders (V105) is paid INR 593,550 once but appears in findings totalling INR 2,509,700', () => {
    const v105 = result.flags.filter((f) => f.entities.includes('vendor:V105'));
    expect(rules(v105)).toEqual(['R1', 'R4', 'R9', 'R8']);
    expect(v105.reduce((s, f) => s + f.amount, 0)).toBe(2_509_700);
    expect(data.payments.filter((p) => p.vendor_id === 'V105').reduce((s, p) => s + p.amount, 0)).toBe(593_550);
  });

  it('R1–R5 and R9 findings list no payment IDs at all', () => {
    const withoutEvidence = result.flags.filter((f) => !f.payments);
    expect(new Set(rules(withoutEvidence))).toEqual(new Set(['R1', 'R2', 'R3', 'R4', 'R5', 'R9']));
    expect(withoutEvidence).toHaveLength(10);
  });

  it('finding IDs are positional (F1…F14), so they change whenever input order changes', () => {
    expect(result.flags.map((f) => f.id).sort()).toEqual(
      Array.from({ length: 14 }, (_, i) => `F${i + 1}`).sort(),
    );
  });

  it.todo('TARGET [Phase 4]: "payments under review" is deduplicated by payment ID and reported apart from vendor-wide spend');
  it.todo('TARGET [Phase 4]: no metric is labelled as loss or amount at risk without a confirmed-issue decision');
});
