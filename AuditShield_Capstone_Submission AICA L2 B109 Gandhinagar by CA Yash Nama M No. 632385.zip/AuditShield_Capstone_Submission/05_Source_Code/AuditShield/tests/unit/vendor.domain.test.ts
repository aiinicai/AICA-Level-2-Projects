/**
 * New VendorShield domain behaviour. These are the Phase 1 targets recorded against the legacy
 * known issues (KI-V01, V03–V07, V09) now asserted against the TypeScript modules.
 */
import { describe, expect, it } from 'vitest';
import { isIsoDate } from '../../src/domain/shared/dates';
import { isValidGstin, panFromGstin } from '../../src/domain/shared/identifiers';
import { formatINR, parseRupeesToPaise, sumPaise } from '../../src/domain/shared/money';
import { NORMALISATION_VERSION, normaliseField } from '../../src/domain/vendor/normalise';
import { protectDataset } from '../../src/domain/vendor/protect';
import { analyse } from '../../src/domain/vendor/rules';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { MINIMAL_PROFILE, NAMED_PROFILE, type ExportProfile, type RawDataset } from '../../src/domain/vendor/types';
import { createTokeniser, generateEngagementKey } from '../../src/services/crypto/tokeniser';
import { type LegacyGV, loadLegacyCore } from '../helpers/legacy';

const GV = loadLegacyCore<LegacyGV>('ghost_vendor');

async function protect(raw: RawDataset, profile: ExportProfile = MINIMAL_PROFILE) {
  const key = await generateEngagementKey();
  return protectDataset(raw, { tokenise: createTokeniser(key), keyId: key.keyId, profile });
}
const EMPTY: RawDataset = { employees: [], vendors: [], directors: [], payments: [] };
const employee = (id: string, over: Partial<RawDataset['employees'][number]> = {}) => ({
  id, name: 'Emp', department: '', bankAccount: '', pan: '', phone: '', address: '', ...over,
});
const vendor = (id: string, over: Partial<RawDataset['vendors'][number]> = {}) => ({
  id, name: 'Vendor', gstin: '', bankAccount: '', pan: '', phone: '', address: '', createdBy: '', ...over,
});

describe('normalisation v2', () => {
  it('is version 2', () => expect(NORMALISATION_VERSION).toBe(2));

  it('[KI-V03] keeps leading zeros of bank accounts', () => {
    expect(normaliseField('bank_account', '00123456789').value).toBe('00123456789');
    expect(normaliseField('bank_account', '123456789').value).toBe('123456789');
    expect(normaliseField('bank_account', ' 0012-3456 789 ').value).toBe('00123456789');
  });

  it('[KI-V03] reports placeholder and too-short accounts instead of matching them', () => {
    expect(normaliseField('bank_account', '0000000')).toEqual({ value: '', issue: expect.objectContaining({ code: 'placeholder-value' }) });
    expect(normaliseField('bank_account', '0012')).toEqual({ value: '', issue: expect.objectContaining({ code: 'too-short' }) });
  });

  it('[KI-V04] preserves regional-script addresses', () => {
    expect(normaliseField('address', 'पुणे').value).toBe('पुणे');
    expect(normaliseField('address', '12 गणेश सोसायटी, पुणे').value).toBe('12 गणेश सोसायटी पुणे');
    expect(normaliseField('address', '12 शांति नगर, मुंबई').value).toBe('12 शांति नगर मुंबई');
    expect(normaliseField('address', 'ಎಂ.ಜಿ. ರಸ್ತೆ, ಬೆಂಗಳೂರು').value).toBe('ಎಂಜಿ ರಸ್ತೆ ಬೆಂಗಳೂರು');
    expect(normaliseField('address', 'Café Road 5').value).toBe('café road 5');
  });

  it('[KI-V04] reads Indian-script digits as digits', () => {
    expect(normaliseField('address', '१२ गणेश सोसायटी').value).toBe('12 गणेश सोसायटी');
    expect(normaliseField('phone', '९८२२०१११०४').value).toBe('9822011104');
  });

  it('[KI-V04] refuses to match on a bare house number', () => {
    expect(normaliseField('address', 'Flat No. 12')).toEqual({ value: '', issue: expect.objectContaining({ code: 'too-short' }) });
  });

  it('handles Indian phone country codes deliberately', () => {
    expect(normaliseField('phone', '+91 98220 11104').value).toBe('9822011104');
    expect(normaliseField('phone', '098220 11104').value).toBe('9822011104');
    expect(normaliseField('phone', '9822011104').value).toBe('9822011104');
    expect(normaliseField('phone', '0000000000').issue?.code).toBe('placeholder-value');
    expect(normaliseField('phone', 'N/A').issue?.code).toBe('not-normalisable');
  });

  it('an empty value is empty, not an issue', () => {
    expect(normaliseField('pan', '   ')).toEqual({ value: '' });
    expect(normaliseField('address', undefined)).toEqual({ value: '' });
  });

  it('[BC-01/BC-02] every attribute value in the ASCII sample normalises exactly as the legacy scheme did', () => {
    const s = sampleRawDataset();
    const rows = [...s.employees, ...s.vendors, ...s.directors];
    for (const r of rows) {
      expect(normaliseField('bank_account', r.bankAccount).value).toBe(GV.normalize('bank_account', r.bankAccount));
      expect(normaliseField('pan', r.pan).value).toBe(GV.normalize('pan', r.pan));
      expect(normaliseField('phone', r.phone).value).toBe(GV.normalize('phone', r.phone));
      expect(normaliseField('address', r.address).value).toBe(GV.normalize('address', r.address));
    }
    for (const v of s.vendors) expect(normaliseField('gstin', v.gstin).value).toBe(GV.normalize('gstin', v.gstin));
  });
});

describe('false and missed matches caused by legacy normalisation are gone', () => {
  it('[KI-V03] 00123456789 and 123456789 are different accounts: no ghost-vendor finding', async () => {
    const { data } = await protect({
      ...EMPTY,
      employees: [employee('E1', { bankAccount: '123456789' })],
      vendors: [vendor('V1', { bankAccount: '00123456789' })],
    });
    expect(analyse(data).findings).toHaveLength(0);
  });

  it('[KI-V04] different Devanagari addresses with the same house number do not match', async () => {
    const { data } = await protect({
      ...EMPTY,
      employees: [employee('E1', { address: '12 शांति नगर, मुंबई' })],
      vendors: [vendor('V1', { address: '12 गणेश सोसायटी, पुणे' })],
    });
    expect(analyse(data).findings).toHaveLength(0);
  });

  it('[KI-V04] an identical Devanagari address shared by a vendor and an employee is found', async () => {
    const { data } = await protect({
      ...EMPTY,
      employees: [employee('E1', { address: 'गणेश सोसायटी, पुणे' })],
      vendors: [vendor('V1', { address: 'गणेश   सोसायटी पुणे.' })],
    });
    expect(analyse(data).findings.map((f) => [f.ruleId, f.matchedFields])).toEqual([['R3', ['address']]]);
  });
});

describe('protection is built from allowlists', () => {
  it('[KI-V01] a column the model does not name cannot reach the protected dataset', async () => {
    const raw = sampleRawDataset();
    Object.assign(raw.vendors[0] as object, { extra_notes: 'Owner Mr. X, PAN ABCDE1234F' });
    Object.assign(raw.payments[0] as object, { narration: 'NEFT to a/c 50100234567812 (Anita Deshpande)' });
    Object.assign(raw.employees[0] as object, { salary: '185000' });
    const blob = JSON.stringify((await protect(raw, NAMED_PROFILE)).data);
    for (const leaked of ['extra_notes', 'Owner Mr. X', 'narration', 'NEFT to', 'salary', '185000']) {
      expect(blob, leaked).not.toContain(leaked);
    }
  });

  it('entities and payments expose exactly the allowlisted keys', async () => {
    const { data } = await protect(sampleRawDataset(), NAMED_PROFILE);
    const keys = new Set(data.entities.flatMap((e) => Object.keys(e)));
    expect([...keys].sort()).toEqual(['attributes', 'createdBy', 'id', 'kind', 'label']);
    expect(new Set(data.entities.flatMap((e) => Object.keys(e.attributes)))).toEqual(
      new Set(['bank_account', 'pan', 'gstin', 'phone', 'address']),
    );
    expect(Object.keys(data.payments[0] ?? {}).sort()).toEqual(['amountPaise', 'approvedBy', 'date', 'id', 'invoiceRef', 'vendorId']);
  });

  it('[KI-V02] minimal profile: no names, no DINs, no invoice numbers, no raw identifiers', async () => {
    const raw = sampleRawDataset();
    const blob = JSON.stringify((await protect(raw, MINIMAL_PROFILE)).data);
    const mustBeAbsent = [
      ...raw.employees.flatMap((e) => [e.name, e.bankAccount, e.pan, e.phone, e.address]),
      ...raw.vendors.flatMap((v) => [v.name, v.gstin, v.bankAccount, v.pan, v.phone, v.address]),
      ...raw.directors.flatMap((d) => [d.id, d.name, d.bankAccount, d.pan, d.phone, d.address]),
      ...raw.payments.map((p) => p.invoiceNo),
    ].filter(Boolean);
    expect(mustBeAbsent).toHaveLength(224); // 50 employee + 70 vendor + 18 director values + 86 invoice numbers
    for (const value of mustBeAbsent) expect(blob, value).not.toContain(value);
  });

  it('[KI-V02] named profile: vendor and director names are readable by explicit choice; employee names never', async () => {
    const raw = sampleRawDataset();
    const blob = JSON.stringify((await protect(raw, NAMED_PROFILE)).data);
    expect(blob).toContain('Sai Traders');
    expect(blob).toContain('Mrs. Sunita Mehta');
    for (const e of raw.employees) expect(blob).not.toContain(e.name);
    for (const r of [...raw.employees, ...raw.vendors, ...raw.directors]) {
      expect(blob).not.toContain(r.bankAccount);
      expect(blob).not.toContain(r.pan);
    }
  });

  it('[KI-V05] tokens are 64 hex characters and the dataset records the scheme, not the key', async () => {
    const { data } = await protect(sampleRawDataset());
    expect(data.scheme).toEqual({
      algorithm: 'HMAC-SHA256', tokenVersion: 2, normalisationVersion: 2, keyId: expect.stringMatching(/^k_[0-9a-f]{16}$/),
    });
    const tokens = data.entities.flatMap((e) => Object.values(e.attributes));
    expect(tokens.length).toBeGreaterThan(100);
    for (const t of tokens) expect(t).toMatch(/^[0-9a-f]{64}$/);
  });
});

describe('PAN derivation from GSTIN', () => {
  it('helper derives only from a structurally valid, checksum-valid GSTIN', () => {
    expect(isValidGstin('27AAKCS4321M1Z1')).toBe(true);
    expect(panFromGstin('27AAKCS4321M1Z1')).toBe('AAKCS4321M');
    expect(panFromGstin('27AAKCS4321M1Z9')).toBeNull();
    expect(panFromGstin('NOT-A-GSTIN-AT-ALL')).toBeNull();
  });

  it('[KI-V06] a spaced, lower-case but genuine GSTIN still links the vendor to the employee PAN', async () => {
    const { data, issues } = await protect({
      ...EMPTY,
      employees: [employee('E1', { pan: 'AAKCS4321M' })],
      vendors: [vendor('V1', { gstin: '27 aakcs4321m 1z1' })],
    });
    expect(analyse(data).findings.map((f) => [f.ruleId, f.severity, f.matchedFields])).toEqual([['R1', 'Critical', ['pan']]]);
    expect(issues).toEqual([]);
  });

  it('[KI-V06] an invalid GSTIN derives nothing and is reported', async () => {
    const { data, issues } = await protect({
      ...EMPTY,
      employees: [employee('E1', { pan: 'T-A-GSTIN-' })],
      vendors: [vendor('V1', { gstin: 'NOT-A-GSTIN-AT-ALL' })],
    });
    expect(data.entities.find((e) => e.id === 'V1')?.attributes.pan).toBeUndefined();
    expect(analyse(data).findings).toHaveLength(0);
    expect(issues.map((i) => [i.recordId, i.field, i.code])).toContainEqual(['V1', 'gstin', 'invalid-checksum']);
  });

  it('a warning about a director names the exported reference, never the DIN, under the minimal profile', async () => {
    const director = { id: 'DIN09998887', name: 'Mr. X', bankAccount: '', pan: 'NOTAPAN', phone: '', address: '' };
    const minimal = await protect({ ...EMPTY, directors: [director] }, MINIMAL_PROFILE);
    expect(minimal.issues.map((i) => [i.table, i.recordId, i.code])).toEqual([['directors', 'D-001', 'invalid-structure']]);
    expect(JSON.stringify(minimal)).not.toContain('DIN09998887');
    const named = await protect({ ...EMPTY, directors: [director] }, NAMED_PROFILE);
    expect(named.issues[0]?.recordId).toBe('DIN09998887');
  });

  it('the synthetic sample raises exactly 8 GSTIN check-character warnings and nothing else', async () => {
    const { issues } = await protect(sampleRawDataset());
    expect(issues.map((i) => `${i.recordId}:${i.field}:${i.code}`)).toEqual(
      ['V102', 'V103', 'V106', 'V107', 'V108', 'V109', 'V111', 'V112'].map((v) => `${v}:gstin:invalid-checksum`),
    );
  });
});

describe('money and dates', () => {
  it('[KI-V07] parses rupee text to integer paise', () => {
    expect(parseRupeesToPaise('132450')).toEqual({ ok: true, value: 13_245_000 });
    expect(parseRupeesToPaise('1,25,000')).toEqual({ ok: true, value: 12_500_000 });
    expect(parseRupeesToPaise('125,000.5')).toEqual({ ok: true, value: 12_500_050 });
    expect(parseRupeesToPaise('0.10')).toEqual({ ok: true, value: 10 });
    expect(parseRupeesToPaise('-450.25')).toEqual({ ok: true, value: -45_025 });
    expect(parseRupeesToPaise(98500)).toEqual({ ok: true, value: 9_850_000 });
  });

  it('[KI-V07] rejects what the legacy code silently turned into NaN or a wrong number', () => {
    for (const bad of ['', '  ', 'abc', '12.345', '1e5', '1,2,3', '₹500', '12,50', '--5', '90071992547409.92']) {
      expect(parseRupeesToPaise(bad).ok, JSON.stringify(bad)).toBe(false);
    }
  });

  it('[KI-V07] 0.10 + 0.20 is exactly 30 paise', () => {
    const a = parseRupeesToPaise('0.10');
    const b = parseRupeesToPaise('0.20');
    expect(a.ok && b.ok && sumPaise([a.value, b.value])).toBe(30);
  });

  it('sumPaise refuses non-integers and overflow', () => {
    expect(() => sumPaise([1.5])).toThrow(RangeError);
    expect(() => sumPaise([Number.MAX_SAFE_INTEGER, 1])).toThrow(RangeError);
  });

  it('formats with Indian digit grouping exactly like the legacy formatter for whole rupees', () => {
    for (const rupees of [0, 7, 999, 1000, 99999, 100000, 1234567, 11033700, 5116715]) {
      expect(formatINR(rupees * 100)).toBe(GV.fmtINR(rupees));
    }
    expect(formatINR(123_456_50)).toBe('₹1,23,456.50');
    expect(formatINR(-5_00)).toBe('-₹5');
  });

  it('accepts only real ISO calendar dates', () => {
    expect(isIsoDate('2025-12-28')).toBe(true);
    expect(isIsoDate('2024-02-29')).toBe(true);
    for (const bad of ['2025-02-29', '28-12-2025', '2025-13-01', '2025-1-5', '', '2025-12-28T00:00:00Z']) {
      expect(isIsoDate(bad), bad).toBe(false);
    }
  });
});

describe('findings carry evidence and stable identity', () => {
  it('[KI-V09] every finding with an amount lists the payments that make it up', async () => {
    const raw = sampleRawDataset();
    const { data } = await protect(raw);
    const amountOf = new Map(raw.payments.map((p) => [p.id, p.amountPaise]));
    for (const f of analyse(data).findings) {
      if (f.amountBasis === 'none') {
        expect(f.paymentIds).toEqual([]);
        expect(f.amountPaise).toBe(0);
      } else if (f.amountBasis === 'repeat-payment') {
        expect(f.amountPaise).toBe(amountOf.get(f.paymentIds.at(-1) ?? ''));
      } else {
        expect(new Set(f.paymentIds).size, f.title).toBe(f.paymentIds.length);
        expect(sumPaise(f.paymentIds.map((id) => amountOf.get(id) ?? Number.NaN)), f.title).toBe(f.amountPaise);
      }
    }
  });

  it('[KI-V09] fingerprints are unique, hex, and unchanged when the input rows are shuffled', async () => {
    const raw = sampleRawDataset();
    const first = analyse((await protect(raw)).data);
    const shuffled: RawDataset = {
      employees: [...raw.employees].reverse(),
      vendors: [...raw.vendors].reverse(),
      directors: raw.directors, // order defines D-00n references in the minimal profile
      payments: raw.payments,
    };
    const second = analyse((await protect(shuffled)).data);
    const prints = first.findings.map((f) => f.fingerprint);
    expect(new Set(prints).size).toBe(14);
    for (const p of prints) expect(p).toMatch(/^[0-9a-f]{16}$/);
    expect(new Set(second.findings.map((f) => f.fingerprint))).toEqual(new Set(prints));
  });

  it('the summary names its money honestly: vendor-wide payments under review, not a loss', async () => {
    const { summary } = analyse((await protect(sampleRawDataset())).data);
    expect(Object.keys(summary)).not.toContain('amountAtRisk');
    expect(summary.vendorsUnderReview.sort()).toEqual(['V102', 'V105', 'V108', 'V109', 'V110', 'V111']);
    expect(summary.paymentsToVendorsUnderReviewPaise).toBe(5_116_715_00);
  });
});
