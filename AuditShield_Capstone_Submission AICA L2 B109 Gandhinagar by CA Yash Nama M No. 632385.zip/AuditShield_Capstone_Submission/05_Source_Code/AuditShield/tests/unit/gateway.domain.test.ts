/**
 * New Gateway domain and request-service behaviour. Phase 1 targets recorded against the legacy
 * known issues (KI-G01–G07), asserted against the TypeScript modules. Network-level interception
 * with real provider adapters is a Phase 5 deliverable; here the provider is a recording spy, and
 * the property proved is "the adapter is not invoked".
 */
import { describe, expect, it } from 'vitest';
import { cleanTerms, detect } from '../../src/domain/privacy/detect';
import { buildOutboundMessages, SYSTEM_PROMPT } from '../../src/domain/privacy/messages';
import {
  checkOutbound,
  type Destination,
  maskText,
  POLICY_VERSION,
  reviewScan,
  type ScanInputs,
  scanKey,
} from '../../src/domain/privacy/policy';
import { restore, SessionVault } from '../../src/domain/privacy/vault';
import { GatewayRequestService, newVaultNamespace } from '../../src/services/gateway/requestService';
import { createOfflineDemoProvider, OFFLINE_DEMO_DESTINATION } from '../../src/services/providers/offlineDemoProvider';
import type { ProviderAdapter, ProviderRequest } from '../../src/services/providers/types';

const SPY_DESTINATION: Destination = {
  providerId: 'spy', kind: 'external', label: 'Spy provider', endpoint: 'https://provider.test/v1/chat', model: 'spy-1',
};

function spyProvider(reply: string | ((r: ProviderRequest) => string) = 'ok', destination = SPY_DESTINATION) {
  const calls: ProviderRequest[] = [];
  const adapter: ProviderAdapter = {
    destination,
    async complete(request) {
      calls.push(request);
      return typeof reply === 'function' ? reply(request) : reply;
    },
  };
  return { adapter, calls };
}

function inputs(vault: SessionVault, text: string, over: Partial<ScanInputs> = {}): ScanInputs {
  return {
    text, watchlist: [], manualTerms: [], policyVersion: POLICY_VERSION,
    destination: SPY_DESTINATION, vaultNamespace: vault.namespace, ...over,
  };
}

const LEDGER = 'Vendor: Sai Enterprises, PAN AFZPS1234Q. Proprietor: Shri Rohit Shinde, mobile 9822011107. Approved by Mrs. Anita Deshpande.';

describe('detection: validity and confidence are separate facts', () => {
  const one = (text: string) => detect(text)[0];

  it('[KI-G04] a valid and an invalid GSTIN are both masked, with different validity', () => {
    expect(one('GSTIN 27AAKCS4321M1Z1')).toMatchObject({ type: 'GSTIN', validity: 'valid', confidence: 'high' });
    expect(one('GSTIN 27AAKCS4321M1Z9')).toMatchObject({ type: 'GSTIN', validity: 'invalid', confidence: 'medium' });
  });

  it('[KI-G04] an Aadhaar-shaped grouped number is masked for every possible last digit', () => {
    const results = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((d) => one(`ref 7341 5298 016${d} submitted by the employee`));
    expect(results.map((r) => r?.type)).toEqual(Array(10).fill('AADHAAR'));
    expect(results.filter((r) => r?.validity === 'valid')).toHaveLength(1);
    expect(results.filter((r) => r?.validity === 'invalid' && r.confidence === 'low')).toHaveLength(9);
  });

  it('[KI-G04] a card-shaped number that fails Luhn is masked as an invalid card', () => {
    for (const text of ['paid by 4111 1111 1111 1112', 'card 4111 1111 1111 1112', 'card 4111111111111112']) {
      expect(one(text), text).toMatchObject({ type: 'CARD', validity: 'invalid', confidence: 'low' });
    }
    expect(one('card used 4111 1111 1111 1111')).toMatchObject({ type: 'CARD', validity: 'valid', confidence: 'high' });
  });

  it('a PAN-shaped value with an unissued fourth letter is masked as an invalid PAN', () => {
    expect(one('PAN ABCDE1234F quoted')).toMatchObject({ type: 'PAN', value: 'ABCDE1234F', validity: 'invalid' });
    expect(one('PAN ABCPK1234D quoted')).toMatchObject({ type: 'PAN', validity: 'valid' });
  });

  it('an ungrouped 12-digit run that fails Verhoeff is still masked, as an account number', () => {
    expect(one('number 734152980168 here')).toMatchObject({ type: 'BANK_AC', value: '734152980168' });
  });

  it('types with no checksum report "unverifiable"', () => {
    expect(one('Contact Mr. Suresh Patil')).toMatchObject({ type: 'PERSON', validity: 'unverifiable' });
  });
});

describe('masking of known values', () => {
  it('[KI-G06] a later lowercase or re-spaced mention of a detected name is masked too', () => {
    const vault = new SessionVault('AB12');
    const { masked } = maskText('Mr. Rohit Shinde approved it. Later rohit   shinde called, then ROHIT SHINDE left.', vault);
    expect(masked).toBe('Mr. [PERSON_1_AB12] approved it. Later [PERSON_1_AB12] called, then [PERSON_1_AB12] left.');
    expect(checkOutbound([masked], vault)).toEqual([]);
  });

  it('a value pseudonymised earlier in the session is masked when it reappears without its title', () => {
    const vault = new SessionVault('AB12');
    maskText('Contact Mr. Suresh Patil.', vault);
    expect(maskText('suresh patil signed the cheque', vault).masked).toBe('[PERSON_1_AB12] signed the cheque');
  });

  it('manual masks cover text the patterns cannot see, including regional scripts', () => {
    const vault = new SessionVault('AB12');
    const text = 'the director ramesh gupta approved it; श्री राजेश कुलकर्णी ने भुगतान स्वीकृत किया';
    expect(detect(text)).toEqual([]);
    const { masked } = maskText(text, vault, { manualTerms: ['ramesh gupta', 'राजेश कुलकर्णी'] });
    expect(masked).toBe('the director [MANUAL_1_AB12] approved it; श्री [MANUAL_2_AB12] ने भुगतान स्वीकृत किया');
  });

  it('[KI-G07] watch-list terms shorter than 2 characters are reported back, not silently dropped', () => {
    expect(cleanTerms([' AB ', 'x', '', 'ab', 'Mehta Group'])).toEqual({ accepted: ['AB', 'Mehta Group'], rejected: ['x'] });
    const vault = new SessionVault('AB12');
    expect(maskText('Client AB owes Rs. 5,000', vault, { watchlist: ['AB'] }).masked).toBe('Client [CUSTOM_1_AB12] owes Rs. 5,000');
    const scan = reviewScan(inputs(vault, 'hello', { watchlist: ['x'] }), vault);
    expect(scan.rejectedTerms).toEqual(['x']);
  });
});

describe('tokens and request-scoped restoration', () => {
  it('[KI-G05] tokens carry the session namespace and vault namespaces are validated', () => {
    const vault = new SessionVault('K7F3');
    expect(vault.tokenFor('PERSON', 'Rohit Shinde')).toBe('[PERSON_1_K7F3]');
    expect(vault.tokenFor('PERSON', 'rohit  shinde')).toBe('[PERSON_1_K7F3]');
    expect(() => new SessionVault('k7')).toThrow();
    expect(newVaultNamespace()).toMatch(/^[A-HJ-NP-Z2-9]{4}$/);
  });

  it('[KI-G05] literal "[PERSON_1]" typed by a user is not a token and is never restored', () => {
    const vault = new SessionVault('K7F3');
    const { masked, tokens } = maskText('Refer to [PERSON_1] placeholder in the template for Mr. Amit Shah', vault);
    expect(masked).toBe('Refer to [PERSON_1] placeholder in the template for Mr. [PERSON_1_K7F3]');
    const back = restore(masked, vault, new Set(tokens));
    expect(back.text).toBe('Refer to [PERSON_1] placeholder in the template for Mr. Amit Shah');
    expect(back.unknownTokens).toEqual(['[PERSON_1]']);
  });

  it('[KI-G05] invented, bracket-less, foreign-session and unauthorised tokens reveal nothing', () => {
    const vault = new SessionVault('K7F3');
    maskText(LEDGER, vault); // earlier request put PERSON_1, PERSON_2, PAN_1 … in the vault
    const later = maskText('Summarise the TDS position for Sai Enterprises.', vault);
    expect(later.tokens).toEqual(['[ORG_1_K7F3]']);

    const hostile =
      'About [ORG_1_K7F3]: [PERSON_2_K7F3] approved it, PAN [PAN_1_K7F3], see PERSON_1_K7F3, [PERSON_1], [PERSON_9_K7F3] and [PERSON_1_ZZZZ].';
    const back = restore(hostile, vault, new Set(later.tokens));
    expect(back.text).toBe(
      'About Sai Enterprises: [PERSON_2_K7F3] approved it, PAN [PAN_1_K7F3], see PERSON_1_K7F3, [PERSON_1], [PERSON_9_K7F3] and [PERSON_1_ZZZZ].',
    );
    expect(back.restoredTokens).toEqual(['[ORG_1_K7F3]']);
    expect(back.unknownTokens).toEqual([
      '[PERSON_2_K7F3]', '[PAN_1_K7F3]', 'PERSON_1_K7F3', '[PERSON_1]', '[PERSON_9_K7F3]', '[PERSON_1_ZZZZ]',
    ]);
    for (const secret of ['Rohit Shinde', 'Anita Deshpande', 'AFZPS1234Q']) expect(back.text).not.toContain(secret);
  });
});

describe('outbound policy', () => {
  it('the system prompt itself passes the outbound check', () => {
    expect(checkOutbound([SYSTEM_PROMPT], new SessionVault('AB12'))).toEqual([]);
  });

  it('[KI-G03] reports what remains readable, with a log-safe message and a local-only excerpt', () => {
    const vault = new SessionVault('AB12');
    maskText('Contact Mr. Suresh Patil.', vault);
    const violations = checkOutbound(['Please ask SURESH PATIL about PAN ABCPK1234D'], vault);
    expect(violations.map((v) => v.code)).toEqual(['vault-value-visible', 'identifier-detected']);
    for (const v of violations) expect(v.message).not.toMatch(/suresh|ABCPK1234D/i);
    expect(violations.map((v) => v.sensitiveExcerpt)).toEqual(['Suresh Patil', 'ABCPK1234D']);
  });

  it('inspects every part of the body, including history', () => {
    const vault = new SessionVault('AB12');
    const messages = buildOutboundMessages('What next?', [{ role: 'user', content: 'Earlier I mentioned PAN ABCPK1234D' }]);
    expect(checkOutbound(messages.map((m) => m.content), vault).map((v) => v.code)).toEqual(['identifier-detected']);
  });

  it('scan keys change with text, watch-list, manual masks, policy, destination and vault session', () => {
    const vault = new SessionVault('AB12');
    const base = inputs(vault, 'hello world');
    const key = scanKey(base);
    expect(scanKey({ ...base })).toBe(key);
    expect(scanKey({ ...base, watchlist: [' Falcon ', 'falcon'] })).toBe(scanKey({ ...base, watchlist: ['FALCON'] }));
    const changed: Partial<ScanInputs>[] = [
      { text: 'hello world ' },
      { watchlist: ['Falcon'] },
      { manualTerms: ['world'] },
      { policyVersion: 'outbound-policy-2' },
      { destination: { ...SPY_DESTINATION, endpoint: 'https://other.test/v1/chat' } },
      { destination: { ...SPY_DESTINATION, model: 'spy-2' } },
      { destination: OFFLINE_DEMO_DESTINATION },
      { vaultNamespace: 'ZZ99' },
    ];
    for (const change of changed) expect(scanKey({ ...base, ...change }), JSON.stringify(change)).not.toBe(key);
  });
});

describe('GatewayRequestService: the send gate lives in the service', () => {
  it('sends an approved request: the provider sees only masked content, and the answer is restored', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider((r) => `Check ${r.messages.at(-1)?.content.match(/\[PERSON_1_AB12\]/)?.[0]} first.`);
    const service = new GatewayRequestService([adapter]);
    const current = inputs(vault, LEDGER);
    const scan = reviewScan(current, vault);
    expect(scan.violations).toEqual([]);

    const outcome = await service.dispatch(scan, current, vault);
    expect(calls).toHaveLength(1);
    const sent = calls[0]?.messages.map((m) => m.content).join('\n') ?? '';
    expect(calls[0]?.messages.map((m) => m.role)).toEqual(['system', 'user']);
    expect(calls[0]?.messages.at(-1)?.content).toBe(scan.masked);
    for (const secret of ['Sai Enterprises', 'AFZPS1234Q', 'Rohit Shinde', '9822011107', 'Anita Deshpande']) {
      expect(sent).not.toContain(secret);
    }
    expect(Object.isFrozen(calls[0]?.messages)).toBe(true);
    expect(outcome).toMatchObject({ status: 'answered', answerMasked: 'Check [PERSON_1_AB12] first.' });
    expect(outcome.status === 'answered' && outcome.restoration.text).toBe('Check Rohit Shinde first.');
  });

  it('[KI-G01] a failed check blocks the request: the provider is never called and there is no override', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const service = new GatewayRequestService([adapter]);
    // A reviewed scan whose masked text was tampered with after review (or produced by a faulty UI).
    const current = inputs(vault, LEDGER);
    const scan = { ...reviewScan(current, vault), masked: `${LEDGER}` };
    const outcome = await service.dispatch(scan, current, vault);
    expect(outcome.status).toBe('blocked');
    expect(calls).toHaveLength(0);
    expect(outcome.status === 'blocked' && outcome.reasons.every((r) => r.code === 'policy-violation')).toBe(true);
    expect(GatewayRequestService.prototype.dispatch.length).toBeLessThanOrEqual(4);
    expect(JSON.stringify(Object.getOwnPropertyNames(GatewayRequestService.prototype))).not.toMatch(/force|override|anyway/i);
  });

  it('[KI-G03] an undetected value that is on the watch-list or manually masked can never be sent in clear', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const service = new GatewayRequestService([adapter]);
    const text = 'the director ramesh gupta approved it';
    const withoutMask = inputs(vault, text);
    const stale = reviewScan(withoutMask, vault);
    // The user then marks the name for masking but tries to send the earlier scan.
    const withMask = { ...withoutMask, manualTerms: ['ramesh gupta'] };
    const outcome = await service.dispatch(stale, withMask, vault);
    expect(outcome.status).toBe('blocked');
    expect(outcome.status === 'blocked' && outcome.reasons.map((r) => r.code)).toEqual(['stale-scan', 'policy-violation']);
    expect(calls).toHaveLength(0);

    const fresh = reviewScan(withMask, vault);
    expect((await service.dispatch(fresh, withMask, vault)).status).toBe('answered');
    expect(calls[0]?.messages.at(-1)?.content).toBe('the director [MANUAL_1_AB12] approved it');
  });

  it.each<[string, (i: ScanInputs) => ScanInputs]>([
    ['text edited', (i) => ({ ...i, text: `${i.text} More.` })],
    ['watch-list edited', (i) => ({ ...i, watchlist: ['Falcon'] })],
    ['manual mask added', (i) => ({ ...i, manualTerms: ['extract'] })],
    ['policy version changed', (i) => ({ ...i, policyVersion: 'outbound-policy-2' })],
    ['model changed', (i) => ({ ...i, destination: { ...i.destination, model: 'spy-2' } })],
    ['endpoint changed', (i) => ({ ...i, destination: { ...i.destination, endpoint: 'https://elsewhere.test/v1' } })],
  ])('[KI-G02] %s after the scan → stale, zero provider calls', async (_name, change) => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const service = new GatewayRequestService([adapter]);
    const reviewed = inputs(vault, 'Review this vendor payment extract for Mr. Amit Shah.');
    const scan = reviewScan(reviewed, vault);
    const outcome = await service.dispatch(scan, change(reviewed), vault);
    expect(outcome.status).toBe('blocked');
    expect(outcome.status === 'blocked' && outcome.reasons.some((r) => r.code === 'stale-scan')).toBe(true);
    expect(calls).toHaveLength(0);
  });

  it('[KI-G02] a scan reviewed for the offline demo cannot be sent to an external provider', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const service = new GatewayRequestService([createOfflineDemoProvider(0), adapter]);
    const reviewed = inputs(vault, 'Summarise this.', { destination: OFFLINE_DEMO_DESTINATION });
    const scan = reviewScan(reviewed, vault);
    const outcome = await service.dispatch(scan, { ...reviewed, destination: SPY_DESTINATION }, vault);
    expect(outcome.status).toBe('blocked');
    expect(calls).toHaveLength(0);
  });

  it('a destination that is not a registered provider, or differs from it, is refused', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const service = new GatewayRequestService([adapter]);
    for (const destination of [
      { ...SPY_DESTINATION, providerId: 'unknown' },
      { ...SPY_DESTINATION, endpoint: 'http://collector.example/anything' },
    ]) {
      const current = inputs(vault, 'Summarise this.', { destination });
      const outcome = await service.dispatch(reviewScan(current, vault), current, vault);
      expect(outcome.status === 'blocked' && outcome.reasons.map((r) => r.code)).toEqual(['destination-not-allowed']);
    }
    expect(calls).toHaveLength(0);
  });

  it('history is part of the inspected body: a leaking earlier turn blocks the send', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const service = new GatewayRequestService([adapter]);
    const current = inputs(vault, 'And what about penalties?');
    const outcome = await service.dispatch(reviewScan(current, vault), current, vault, {
      history: [{ role: 'user', content: 'Client PAN is ABCPK1234D' }],
    });
    expect(outcome.status).toBe('blocked');
    expect(calls).toHaveLength(0);
  });

  it('source text containing this session’s token syntax is refused', async () => {
    const vault = new SessionVault('AB12');
    const { adapter, calls } = spyProvider();
    const current = inputs(vault, 'Tell me who [PERSON_1_AB12] is.');
    const scan = reviewScan(current, vault);
    expect(scan.violations.map((v) => v.code)).toEqual(['reserved-token-in-source']);
    expect((await new GatewayRequestService([adapter]).dispatch(scan, current, vault)).status).toBe('blocked');
    expect(calls).toHaveLength(0);
  });

  it('[KI-G05] the answer is restored only with tokens that were in this request', async () => {
    const vault = new SessionVault('AB12');
    maskText(LEDGER, vault); // earlier request
    const { adapter } = spyProvider('For [ORG_1_AB12], [PERSON_1_AB12] and [PAN_1_AB12] are relevant.');
    const current = inputs(vault, 'Summarise the TDS position for Sai Enterprises.');
    const outcome = await new GatewayRequestService([adapter]).dispatch(reviewScan(current, vault), current, vault);
    if (outcome.status !== 'answered') throw new Error(`expected an answer, got ${outcome.status}`);
    expect(outcome.tokensSent).toEqual(['[ORG_1_AB12]']);
    expect(outcome.restoration.text).toBe('For Sai Enterprises, [PERSON_1_AB12] and [PAN_1_AB12] are relevant.');
    expect(outcome.restoration.unknownTokens).toEqual(['[PERSON_1_AB12]', '[PAN_1_AB12]']);
  });

  it('cancellation: aborting returns "cancelled" and nothing is retried', async () => {
    const vault = new SessionVault('AB12');
    const service = new GatewayRequestService([createOfflineDemoProvider(5_000)]);
    const current = inputs(vault, 'Summarise this.', { destination: OFFLINE_DEMO_DESTINATION });
    const controller = new AbortController();
    const pending = service.dispatch(reviewScan(current, vault), current, vault, { signal: controller.signal });
    controller.abort();
    expect(await pending).toEqual({ status: 'cancelled' });
  });

  it('timeout: a provider that never answers yields a timeout failure', async () => {
    const vault = new SessionVault('AB12');
    const service = new GatewayRequestService([createOfflineDemoProvider(5_000)]);
    const current = inputs(vault, 'Summarise this.', { destination: OFFLINE_DEMO_DESTINATION });
    const outcome = await service.dispatch(reviewScan(current, vault), current, vault, { timeoutMs: 20 });
    expect(outcome).toMatchObject({ status: 'failed', code: 'timeout' });
  });

  it('provider failure and empty responses are reported without echoing provider text', async () => {
    const vault = new SessionVault('AB12');
    const current = inputs(vault, 'Summarise this.');
    const failing: ProviderAdapter = {
      destination: SPY_DESTINATION,
      complete: async () => {
        throw new Error('upstream said: PAN ABCPK1234D rejected');
      },
    };
    const failed = await new GatewayRequestService([failing]).dispatch(reviewScan(current, vault), current, vault);
    expect(failed).toMatchObject({ status: 'failed', code: 'provider-error' });
    expect(JSON.stringify(failed)).not.toContain('ABCPK1234D');

    const empty = await new GatewayRequestService([spyProvider('   ').adapter]).dispatch(reviewScan(current, vault), current, vault);
    expect(empty).toMatchObject({ status: 'failed', code: 'invalid-response' });
  });
});
