/**
 * Session reducer (memory-only state): gateway scan invalidation (legacy KI-G02), lock reset,
 * engagement isolation, and metadata-only activity text. Persisted state is covered by
 * tests/integration.
 */
import { describe, expect, it } from 'vitest';
import { type Action, initialState, outcomeAuditDetail, reducer, scanAuditDetail, selectGateway, type SessionState } from '../../src/app/state';
import { POLICY_VERSION, reviewScan } from '../../src/domain/privacy/policy';
import { SessionVault } from '../../src/domain/privacy/vault';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { OFFLINE_DEMO_DESTINATION } from '../../src/services/providers/offlineDemoProvider';

const vault = new SessionVault('AB12');
const scanFor = (text: string, watchlist: string[] = []) =>
  reviewScan({ text, watchlist, manualTerms: [], policyVersion: POLICY_VERSION, destination: OFFLINE_DEMO_DESTINATION, vaultNamespace: 'AB12' }, vault);
const run = (actions: Action[], from: SessionState = initialState) => actions.reduce(reducer, from);
const source = { raw: sampleRawDataset(), label: 'sample', sourceType: 'sample' as const, digest: 'd1' };

describe('gateway: any change to the request voids the reviewed scan', () => {
  it.each<[string, Extract<Action, { type: 'gateway/edit' }>['patch']]>([
    ['draft', { draft: 'changed text' }],
    ['watch-list', { watchlistText: 'Falcon' }],
    ['manual masks', { manualTerms: ['extract'] }],
    ['destination', { destinationId: 'some-other-provider' }],
  ])('[KI-G02] editing the %s clears the scan and the previous answer', (_name, patch) => {
    const reviewed = run([
      { type: 'gateway/edit', engagementId: 'A', patch: { draft: 'Contact Mr. Suresh Patil' } },
      { type: 'gateway/scanned', engagementId: 'A', scan: scanFor('Contact Mr. Suresh Patil') },
      { type: 'gateway/outcome', engagementId: 'A', outcome: { status: 'cancelled' } },
    ]);
    expect(selectGateway(reviewed, 'A').scan).not.toBeNull();
    const edited = reducer(reviewed, { type: 'gateway/edit', engagementId: 'A', patch });
    expect(selectGateway(edited, 'A').scan).toBeNull();
    expect(selectGateway(edited, 'A').outcome).toBeNull();
  });

  it('a new scan clears the previous answer', () => {
    const state = run([
      { type: 'gateway/scanned', engagementId: 'A', scan: scanFor('one') },
      { type: 'gateway/outcome', engagementId: 'A', outcome: { status: 'cancelled' } },
      { type: 'gateway/scanned', engagementId: 'A', scan: scanFor('two') },
    ]);
    expect(selectGateway(state, 'A').outcome).toBeNull();
  });
});

describe('memory-only state is per engagement and is dropped on lock', () => {
  const loaded = run([
    { type: 'engagement/select', engagementId: 'A' },
    { type: 'source/loaded', engagementId: 'A', source },
    { type: 'gateway/edit', engagementId: 'A', patch: { draft: 'draft for A' } },
    { type: 'gateway/edit', engagementId: 'B', patch: { draft: 'draft for B' } },
  ]);

  it('one engagement’s source data and draft are not visible from another', () => {
    expect(loaded.source['B']).toBeUndefined();
    expect(selectGateway(loaded, 'A').draft).toBe('draft for A');
    expect(selectGateway(loaded, 'B').draft).toBe('draft for B');
    expect(selectGateway(loaded, 'C').draft).toBe('');
  });

  it('locking resets everything: no source data, drafts, scans or selection remain', () => {
    expect(reducer(loaded, { type: 'session/reset' })).toEqual({ currentId: null, source: {}, gateway: {} });
  });

  it('removing an engagement drops its memory-only state and deselects it', () => {
    const after = reducer(loaded, { type: 'engagement/removed', engagementId: 'A' });
    expect(after.currentId).toBeNull();
    expect(after.source).toEqual({});
    expect(Object.keys(after.gateway)).toEqual(['B']);
  });

  it('clearing source data removes it from memory', () => {
    expect(reducer(loaded, { type: 'source/cleared', engagementId: 'A' }).source).toEqual({});
  });
});

describe('gateway activity text holds metadata only', () => {
  const text = 'Vendor: Sai Enterprises, PAN AFZPS1234Q. Proprietor: Shri Rohit Shinde, mobile 9822011107.';
  const scan = scanFor(text, ['Sai']);
  const secrets = ['Sai Enterprises', 'AFZPS1234Q', 'Rohit Shinde', '9822011107'];

  it('scan: counts by type and unresolved checks', () => {
    const detail = scanAuditDetail(scan);
    expect(detail).toMatch(/^\d+ items masked \(.*\), 0 unresolved checks$/);
    for (const s of secrets) expect(detail).not.toContain(s);
  });

  it('outcomes: sizes and reason codes, never excerpts, values or answers', () => {
    const blocked = outcomeAuditDetail({
      status: 'blocked',
      reasons: [{ code: 'policy-violation', message: 'PAN is still readable in the outgoing text.', violation: { code: 'identifier-detected', message: 'x', sensitiveExcerpt: 'AFZPS1234Q' } }],
    }, 'Offline demo');
    expect(blocked).toBe('Offline demo; blocked before any provider call: policy-violation');

    const answered = outcomeAuditDetail({
      status: 'answered', answerMasked: 'About [PERSON_1_AB12]', tokensSent: ['[PERSON_1_AB12]'], charactersSent: 120,
      restoration: { text: 'About Rohit Shinde', segments: [], restoredTokens: ['[PERSON_1_AB12]'], unknownTokens: [] },
    }, 'Offline demo');
    expect(answered).toBe('Offline demo; sent 120 masked characters, 1 tokens; 0 unrecognised tokens in answer');
    expect(outcomeAuditDetail({ status: 'failed', code: 'timeout', message: 'x' }, 'Offline demo')).toBe('Offline demo; failed: timeout');
    expect(outcomeAuditDetail({ status: 'cancelled' }, 'Offline demo')).toBe('Offline demo; cancelled by user');
    for (const s of secrets) expect(`${blocked} ${answered}`).not.toContain(s);
  });
});
