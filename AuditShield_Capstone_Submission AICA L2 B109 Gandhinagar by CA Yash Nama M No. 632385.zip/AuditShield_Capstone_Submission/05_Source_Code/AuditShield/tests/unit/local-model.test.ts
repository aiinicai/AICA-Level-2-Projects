/**
 * Local model adapter (LM Studio / Ollama, OpenAI-compatible) at the network boundary: requests
 * are intercepted with a fake fetch, so these tests prove what would actually go over the wire.
 */
import { describe, expect, it } from 'vitest';
import { POLICY_VERSION, reviewScan, type ScanInputs } from '../../src/domain/privacy/policy';
import { SessionVault } from '../../src/domain/privacy/vault';
import { GatewayRequestService } from '../../src/services/gateway/requestService';
import {
  createLocalModelProvider, LOCAL_MODEL_PROVIDER_ID, listLocalModels, localEndpointProblem, localModelDestination,
} from '../../src/services/providers/openAiCompatible';

const CONFIG = { endpoint: 'http://127.0.0.1:1234/v1/chat/completions', model: 'qwen2.5-7b-instruct' };
const TEXT = 'Vendor: Sai Enterprises, PAN AFZPS1234Q, Bank a/c 60112233445566. Proprietor: Shri Rohit Shinde, mobile 9822011107.';
const SECRETS = ['Sai Enterprises', 'AFZPS1234Q', '60112233445566', 'Rohit Shinde', '9822011107'];

function interceptor(reply: (body: { messages: { content: string }[] }) => Response | Promise<Response>) {
  const calls: { url: string; init: RequestInit }[] = [];
  const fetchImpl = async (url: string, init?: RequestInit) => {
    calls.push({ url, init: init ?? {} });
    if (init?.signal?.aborted) throw new DOMException('aborted', 'AbortError');
    return reply(JSON.parse(String(init?.body ?? '{}')));
  };
  return { calls, fetchImpl };
}
const chat = (content: string) => new Response(JSON.stringify({ choices: [{ message: { role: 'assistant', content } }] }), { status: 200 });

function setup(reply: Parameters<typeof interceptor>[0], text = TEXT) {
  const net = interceptor(reply);
  const vault = new SessionVault('LM01');
  const service = new GatewayRequestService([createLocalModelProvider(CONFIG, net.fetchImpl)]);
  const inputs: ScanInputs = {
    text, watchlist: [], manualTerms: [], policyVersion: POLICY_VERSION, destination: localModelDestination(CONFIG), vaultNamespace: vault.namespace,
  };
  return { ...net, vault, service, inputs, scan: reviewScan(inputs, vault) };
}

describe('destination policy', () => {
  it('accepts only chat endpoints on this computer', () => {
    expect(localEndpointProblem(CONFIG.endpoint)).toBeNull();
    expect(localEndpointProblem('http://localhost:11434/v1/chat/completions')).toBeNull();
    for (const bad of ['https://api.openai.com/v1/chat/completions', 'http://192.168.1.5:1234/v1/chat/completions', 'http://evil.localhost.example.com/v1/chat/completions',
      'ftp://127.0.0.1/v1/chat/completions', 'http://user:pw@127.0.0.1:1234/v1/chat/completions', 'http://127.0.0.1:1234/v1/models', 'not a url']) {
      expect(localEndpointProblem(bad), bad).not.toBeNull();
    }
    expect(() => createLocalModelProvider({ endpoint: 'https://api.openai.com/v1/chat/completions', model: 'x' })).toThrow();
  });
});

describe('what goes over the wire', () => {
  it('an approved request sends only the reviewed masked text, to the configured local address, without credentials', async () => {
    const s = setup((body) => chat(`The key person is ${body.messages.at(-1)?.content.match(/\[PERSON_1_LM01\]/)?.[0]}.`));
    const outcome = await s.service.dispatch(s.scan, s.inputs, s.vault);
    expect(s.calls).toHaveLength(1);
    const call = s.calls[0]!;
    expect(call.url).toBe(CONFIG.endpoint);
    expect(call.init).toMatchObject({ method: 'POST', credentials: 'omit', referrerPolicy: 'no-referrer' });
    expect(JSON.stringify(call.init.headers)).not.toMatch(/authorization/i);
    const body = JSON.parse(String(call.init.body));
    expect(body.model).toBe(CONFIG.model);
    expect(body.messages.at(-1).content).toBe(s.scan.masked);
    for (const secret of SECRETS) expect(String(call.init.body)).not.toContain(secret);
    expect(outcome).toMatchObject({ status: 'answered' });
    expect(outcome.status === 'answered' && outcome.restoration.text).toBe('The key person is Rohit Shinde.');
  });

  it('a request that fails its checks makes zero network calls', async () => {
    const s = setup(() => chat('never'));
    const tampered = { ...s.scan, masked: TEXT };
    expect((await s.service.dispatch(tampered, s.inputs, s.vault)).status).toBe('blocked');
    expect((await s.service.dispatch(s.scan, { ...s.inputs, text: `${TEXT} edited` }, s.vault)).status).toBe('blocked');
    expect((await s.service.dispatch(s.scan, { ...s.inputs, destination: localModelDestination({ ...CONFIG, model: 'other' }) }, s.vault)).status).toBe('blocked');
    expect(s.calls).toHaveLength(0);
  });

  it('invented codes in the model answer reveal nothing', async () => {
    const s = setup(() => chat('See [PERSON_2_LM01], [PAN_7_LM01] and [PERSON_1].'));
    const other = new SessionVault('LM01');
    void other;
    s.vault.tokenFor('PERSON', 'Unrelated Person'); // a value from an earlier request, never sent now
    const outcome = await s.service.dispatch(reviewScan(s.inputs, s.vault), s.inputs, s.vault);
    expect(outcome.status === 'answered' && outcome.restoration.unknownTokens.length).toBeGreaterThan(0);
    expect(outcome.status === 'answered' && outcome.restoration.text).not.toContain('Unrelated Person');
  });
});

describe('failures are reported without retries and without echoing provider text', () => {
  it.each([
    ['server not running', () => { throw new TypeError('Failed to fetch'); }, 'provider-error', /did not respond/],
    ['authentication', () => new Response('{"error":"Rohit Shinde"}', { status: 401 }), 'provider-error', /authentication/],
    ['rate limit', () => new Response('{}', { status: 429 }), 'provider-error', /busy/],
    ['server error', () => new Response('oops', { status: 500 }), 'provider-error', /HTTP 500/],
    ['not JSON', () => new Response('<html>', { status: 200 }), 'invalid-response', /not valid JSON/],
    ['wrong shape', () => new Response('{"answer":"x"}', { status: 200 }), 'invalid-response', /expected chat-completion shape/],
  ] as const)('%s', async (_name, reply, code, message) => {
    const s = setup(reply as () => Response);
    const outcome = await s.service.dispatch(s.scan, s.inputs, s.vault);
    expect(outcome).toMatchObject({ status: 'failed', code });
    expect(outcome.status === 'failed' && outcome.message).toMatch(message);
    expect(JSON.stringify(outcome)).not.toContain('Rohit Shinde');
    expect(s.calls).toHaveLength(1);
  });

  it('cancellation aborts the request', async () => {
    let seen: AbortSignal | undefined;
    const fetchImpl = (_url: string, init?: RequestInit) => new Promise<Response>((_, reject) => {
      seen = init?.signal ?? undefined;
      init?.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')));
    });
    const vault = new SessionVault('LM01');
    const service = new GatewayRequestService([createLocalModelProvider(CONFIG, fetchImpl)]);
    const inputs: ScanInputs = { text: 'hello', watchlist: [], manualTerms: [], policyVersion: POLICY_VERSION, destination: localModelDestination(CONFIG), vaultNamespace: vault.namespace };
    const controller = new AbortController();
    const pending = service.dispatch(reviewScan(inputs, vault), inputs, vault, { signal: controller.signal });
    await Promise.resolve();
    controller.abort();
    expect(await pending).toEqual({ status: 'cancelled' });
    expect(seen?.aborted).toBe(true);
  });

  it('a request that takes too long times out', async () => {
    const net = interceptor(() => new Promise<Response>(() => undefined));
    const fetchImpl = (url: string, init?: RequestInit) => new Promise<Response>((_, reject) => {
      init?.signal?.addEventListener('abort', () => reject(new DOMException('aborted', 'AbortError')));
      void net.fetchImpl(url, init);
    });
    const vault = new SessionVault('LM01');
    const service = new GatewayRequestService([createLocalModelProvider(CONFIG, fetchImpl)]);
    const inputs: ScanInputs = { text: 'hello', watchlist: [], manualTerms: [], policyVersion: POLICY_VERSION, destination: localModelDestination(CONFIG), vaultNamespace: vault.namespace };
    expect(await service.dispatch(reviewScan(inputs, vault), inputs, vault, { timeoutMs: 20 })).toMatchObject({ status: 'failed', code: 'timeout' });
  });
});

describe('model list and registration', () => {
  it('lists models from /models without sending any user data', async () => {
    const net = interceptor(() => new Response(JSON.stringify({ data: [{ id: 'qwen2.5-7b-instruct' }, { id: 'llama-3.2-3b' }] }), { status: 200 }));
    expect(await listLocalModels(CONFIG.endpoint, net.fetchImpl)).toEqual(['qwen2.5-7b-instruct', 'llama-3.2-3b']);
    expect(net.calls[0]).toMatchObject({ url: 'http://127.0.0.1:1234/v1/models', init: { method: 'GET' } });
    expect(net.calls[0]?.init.body).toBeUndefined();
  });

  it('an unregistered local model is refused by the service', async () => {
    const vault = new SessionVault('LM01');
    const service = new GatewayRequestService([]);
    const inputs: ScanInputs = { text: 'hello', watchlist: [], manualTerms: [], policyVersion: POLICY_VERSION, destination: localModelDestination(CONFIG), vaultNamespace: vault.namespace };
    expect((await service.dispatch(reviewScan(inputs, vault), inputs, vault)).status).toBe('blocked');
    service.register(LOCAL_MODEL_PROVIDER_ID, createLocalModelProvider(CONFIG, async () => chat('ok')));
    expect((await service.dispatch(reviewScan(inputs, vault), inputs, vault)).status).toBe('answered');
  });
});
