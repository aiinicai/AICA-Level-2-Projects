/**
 * CSV import (on the original capstone's own sample CSV files) and the client → auditor package
 * handoff between two independent profiles.
 */
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import { amountToPaise, buildDataset, errorsToCsv, type FileInput, suggestDataset, suggestMapping, toIsoDate } from '../../src/domain/vendor/csvImport';
import { analyse } from '../../src/domain/vendor/rules';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { DEFAULT_RULE_CONFIG, MINIMAL_PROFILE, NAMED_PROFILE, type RawDataset } from '../../src/domain/vendor/types';
import { generateEngagementKey } from '../../src/services/crypto/tokeniser';
import { parseCsv } from '../../src/services/imports/csv';
import { buildPackage, PackageError, readPackage } from '../../src/services/packages/protectedPackage';
import { analyseSnapshot, exportPackage, openPackage, protectAndCommit, setupWorkspace } from '../../src/services/workspace/useCases';
import { LEGACY_ROOT } from '../helpers/legacy';
import { dumpDatabase, newProfile, PASSPHRASE, testClock, TEST_ITERATIONS } from '../helpers/profile';

const csvFile = (name: string, text: string): FileInput => {
  const parsed = parseCsv(text);
  const dataset = suggestDataset(parsed.headers);
  return { name, dataset, headers: parsed.headers, rows: parsed.rows, mapping: suggestMapping(dataset, parsed.headers) };
};
const sampleFiles = () =>
  ['employees', 'vendors', 'directors', 'payments'].map((t) => csvFile(`${t}.csv`, readFileSync(join(LEGACY_ROOT, 'sample_data', `${t}.csv`), 'utf8')));

describe('CSV import', () => {
  it('reads the original sample CSVs into exactly the built-in sample, datasets suggested from headers', () => {
    const files = sampleFiles();
    expect(files.map((f) => f.dataset)).toEqual(['employees', 'vendors', 'directors', 'payments']);
    const result = buildDataset(files);
    expect(result.errors).toEqual([]);
    expect(result.raw).toEqual(sampleRawDataset());
    expect(Object.values(result.dropped).flat()).toEqual([]);
  });

  it('suggests the dataset from columns, not the file name', () => {
    const f = csvFile('export_2026.csv', 'Supplier Code,Supplier Name,GST No,Bank A/c No\nV1,A,27AAKCS4321M1Z1,001');
    expect(f.dataset).toBe('vendors');
    expect(f.mapping).toMatchObject({ id: 'Supplier Code', name: 'Supplier Name', gstin: 'GST No' });
  });

  it('keeps leading zeros and regional scripts, accepts Indian dates and rupee formats', () => {
    const vendors = csvFile('v.csv', 'vendor_id,vendor_name,bank_account,address\nV1,श्री गणेश ट्रेडर्स,000123456789,"12 गणेश सोसायटी, पुणे"');
    const payments = csvFile('p.csv', 'payment_id,vendor_id,date,amount\nP1,V1,28-12-2025,"₹1,25,000.50"\nP2,V1,05/01/2026,Rs. 98500');
    const r = buildDataset([vendors, payments]);
    expect(r.errors).toEqual([]);
    expect(r.raw.vendors[0]).toMatchObject({ bankAccount: '000123456789', name: 'श्री गणेश ट्रेडर्स', address: '12 गणेश सोसायटी, पुणे' });
    expect(r.raw.payments.map((p) => [p.date, p.amountPaise])).toEqual([['2025-12-28', 12_500_050], ['2026-01-05', 9_850_000]]);
    expect(toIsoDate('31-02-2025')).toBeNull();
    expect(amountToPaise('-500').ok).toBe(false);
  });

  it('[KI-V01] unmapped columns are dropped and listed, never imported', () => {
    const v = csvFile('v.csv', 'vendor_id,vendor_name,extra_notes,owner_pan_note\nV1,A,"Owner Mr X PAN ABCDE1234F",x');
    const r = buildDataset([v]);
    expect(r.dropped['v.csv']).toEqual(['extra_notes', 'owner_pan_note']);
    expect(JSON.stringify(r.raw)).not.toContain('ABCDE1234F');
  });

  it('[KI-V07] reports every bad row with its spreadsheet row number and blocks loading', () => {
    const v = csvFile('v.csv', 'vendor_id,vendor_name\nV1,A\nV1,B\n,C');
    const p = csvFile('p.csv', 'payment_id,vendor_id,date,amount\nP1,V1,2025-02-30,100\nP2,V9,2025-04-01,abc\nP3,V1,2025-04-01,');
    const r = buildDataset([v, p]);
    const lines = r.errors.map((e) => `${e.file}:${e.row}:${e.column}`);
    expect(lines).toEqual(expect.arrayContaining([
      'v.csv:3:Vendor ID', 'v.csv:4:Vendor ID', 'p.csv:2:Payment date', 'p.csv:3:Amount (₹)', 'p.csv:4:Amount (₹)', 'p.csv:3:Vendor ID',
    ]));
    expect(buildDataset([p]).errors.map((e) => e.message)).toContain('A vendor master file is required.');
  });

  it('missing required mappings and a dataset assigned twice are reported', () => {
    const noId = csvFile('v.csv', 'name,pan\nA,AAAPA1234A');
    noId.dataset = 'vendors';
    noId.mapping = suggestMapping('vendors', noId.headers);
    expect(buildDataset([noId]).errors[0]?.message).toMatch(/Required field "Vendor ID"/);
    const [a, b] = [csvFile('a.csv', 'vendor_id\nV1'), csvFile('b.csv', 'vendor_id\nV2')];
    expect(buildDataset([a!, b!]).errors[0]?.message).toMatch(/Two files are assigned to vendors/);
  });

  it('[KI-X01] the error report neutralises formula-like cells', () => {
    const csv = errorsToCsv([{ file: '=HYPERLINK("x")', dataset: 'vendors', row: 2, column: '+cmd', message: 'bad, "quoted"' }]);
    expect(csv).toContain(`"'=HYPERLINK(""x"")"`);
    expect(csv).toContain("'+cmd");
    expect(csv).toContain('"bad, ""quoted"""');
  });
});

async function preparerWithSnapshot(profileChoice = MINIMAL_PROFILE, raw: RawDataset = sampleRawDataset()) {
  const profile = newProfile();
  const clock = testClock();
  const { db, repos } = await profile.open();
  const session = await setupWorkspace(repos, PASSPHRASE, clock, TEST_ITERATIONS);
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() }, { name: 'Mehta Industries audit', financialYear: '2025-26', kind: 'client' }, clock.id());
  const snapshot = await protectAndCommit(repos, session, { engagementId: engagement.id, raw, sourceType: 'csv', sourceLabel: 'vendors_master.csv', profile: profileChoice, key: await generateEngagementKey(), retainDays: 30 }, clock);
  const run = await analyseSnapshot(repos, { engagementId: engagement.id, importId: snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, clock);
  return { db, repos, clock, session, engagement, snapshot, run, raw };
}

const secretsOf = (raw: RawDataset) => [
  ...raw.employees.flatMap((e) => [e.name, e.bankAccount, e.pan, e.phone, e.address]),
  ...raw.vendors.flatMap((v) => [v.name, v.gstin, v.bankAccount, v.pan, v.phone, v.address]),
  ...raw.directors.flatMap((d) => [d.id, d.name, d.bankAccount, d.pan, d.phone, d.address]),
  ...raw.payments.map((p) => p.invoiceNo),
].filter(Boolean);

describe('protected package handoff', () => {
  it('the package holds no source value, label or key, and a separate auditor profile reproduces the analysis', async () => {
    const client = await preparerWithSnapshot();
    const built = await exportPackage(client.repos, { engagementId: client.engagement.id, importId: client.snapshot.id, financialYear: '2025-26' }, client.clock);
    for (const s of [...secretsOf(client.raw), 'Mehta Industries audit', 'vendors_master', PASSPHRASE]) expect(built.text, s).not.toContain(s);
    expect(built.manifest.counts).toEqual({ employees: 10, vendors: 12, directors: 3, payments: 86, issues: 8 });

    // ---- auditor: a different, independent profile with its own passphrase
    const auditorProfile = newProfile();
    const clock = testClock('2026-12-01T09:00:00.000Z');
    const { db, repos } = await auditorProfile.open();
    const auditor = await setupWorkspace(repos, 'auditor passphrase 99', clock, TEST_ITERATIONS);
    const opened = await openPackage(repos, auditor, { bytes: new TextEncoder().encode(built.text), label: 'Received from client' }, clock);
    const run = await analyseSnapshot(repos, { engagementId: opened.engagementId, importId: opened.snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, clock);

    const clientFindings = await client.repos.runs.findings(client.run.id);
    const auditorFindings = await repos.runs.findings(run.id);
    expect(auditorFindings.map((f) => [f.fingerprint, f.ruleId, f.severity, f.amountPaise, f.paymentIds, f.title]))
      .toEqual(clientFindings.map((f) => [f.fingerprint, f.ruleId, f.severity, f.amountPaise, f.paymentIds, f.title]));
    expect(run.summary).toEqual(client.run.summary);
    expect(opened.snapshot).toMatchObject({ sourceType: 'package', scheme: { keyId: client.snapshot.scheme.keyId } });

    // Nothing in the auditor's storage can reverse a token.
    expect(await db.rawPayloads.count()).toBe(0);
    expect(await db.engagementKeys.count()).toBe(0);
    const dump = await dumpDatabase(db);
    for (const s of secretsOf(client.raw)) expect(dump, s).not.toContain(s);
    expect((await repos.audit.list()).map((e) => e.action)).toEqual(expect.arrayContaining(['Protected package opened', 'Snapshot committed', 'Analysis run']));
  });

  it('the named profile keeps vendor and director names readable, as declared', async () => {
    const client = await preparerWithSnapshot(NAMED_PROFILE);
    const built = await exportPackage(client.repos, { engagementId: client.engagement.id, importId: client.snapshot.id, financialYear: '2025-26' }, client.clock);
    expect(built.text).toContain('Sai Traders');
    expect(built.manifest.disclosure.readable).toContain('Vendor names');
    for (const e of client.raw.employees) expect(built.text).not.toContain(e.name);
    expect((await readPackage(new TextEncoder().encode(built.text))).data.profile.id).toBe('named');
  });

  async function rejected(edit: (file: { manifest: Record<string, unknown>; content: { entities: Record<string, unknown>[]; payments: Record<string, unknown>[]; issues: unknown[] } }) => void, code: PackageError['code'], redigest = true) {
    const client = await preparerWithSnapshot();
    const built = await exportPackage(client.repos, { engagementId: client.engagement.id, importId: client.snapshot.id, financialYear: '2025-26' }, client.clock);
    const file = JSON.parse(built.text);
    edit(file);
    if (redigest) {
      const { digestJson } = await import('../../src/services/crypto/tokeniser');
      file.manifest.contentDigest.value = await digestJson(file.content);
    }
    const auditorProfile = newProfile();
    const { db, repos } = await auditorProfile.open();
    const auditor = await setupWorkspace(repos, 'auditor passphrase 99', testClock(), TEST_ITERATIONS);
    const before = await db.engagements.count();
    const error = await openPackage(repos, auditor, { bytes: new TextEncoder().encode(JSON.stringify(file)), label: 'x label' }).then(() => null, (e: unknown) => e);
    expect(error).toBeInstanceOf(PackageError);
    expect((error as PackageError).code).toBe(code);
    expect(await db.engagements.count()).toBe(before);
    expect(await db.imports.count()).toBe(0);
  }

  it('rejects a smuggled extra column on any record', () => rejected((f) => { f.content.entities[0]!['extra_notes'] = 'Owner PAN ABCDE1234F'; }, 'malformed'));
  it('rejects content altered after export (checksum)', () => rejected((f) => { f.content.payments[0]!['amountPaise'] = 1; }, 'digest-mismatch', false));
  it('rejects a readable vendor name inside a minimal-profile package', () => rejected((f) => { f.content.entities.find((e) => e['kind'] === 'vendor')!['label'] = 'Sai Traders'; }, 'inconsistent-profile'));
  it('rejects a director identified by DIN inside a minimal-profile package', () => rejected((f) => {
    const d = f.content.entities.find((e) => e['kind'] === 'director')!;
    d['id'] = 'DIN01234567';
    d['label'] = 'DIN01234567';
  }, 'inconsistent-profile'));
  it('rejects counts that do not match', () => rejected((f) => { f.content.payments.pop(); }, 'count-mismatch'));
  it('rejects an orphan payment', () => rejected((f) => {
    f.content.payments[0]!['vendorId'] = 'V999';
  }, 'invalid-data'));
  it('rejects a package from a newer format, an old token scheme, and non-packages', async () => {
    await rejected((f) => { f.manifest['formatVersion'] = 2; }, 'newer-format');
    await rejected((f) => { (f.manifest['scheme'] as Record<string, unknown>)['tokenVersion'] = 1; }, 'unsupported-scheme');
    await expect(readPackage(new TextEncoder().encode('vendor_id,name\nV1,A'))).rejects.toMatchObject({ code: 'not-a-package' });
  });

  it('export drops warnings that name records outside the package', async () => {
    const client = await preparerWithSnapshot();
    const data = await client.repos.datasets.loadProtected(client.snapshot.id);
    const built = await buildPackage({
      data, issues: [{ table: 'directors', recordId: 'DIN01234567', field: 'pan', severity: 'warning', code: 'invalid-structure', message: 'x' }],
      financialYear: '2025-26', packageId: 'pkg_t', createdAt: '2026-11-16T10:00:00.000Z',
    });
    expect(built.droppedIssues).toBe(1);
    expect(built.text).not.toContain('DIN01234567');
  });

  it('the analysis of a package uses tokens only: findings match without the key', async () => {
    const client = await preparerWithSnapshot();
    const built = await exportPackage(client.repos, { engagementId: client.engagement.id, importId: client.snapshot.id, financialYear: '2025-26' }, client.clock);
    const { data } = await readPackage(new TextEncoder().encode(built.text));
    expect(analyse(data).summary.findings).toBe(14);
  });
});
