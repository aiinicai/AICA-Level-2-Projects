/**
 * Encrypted backup and restore: export from one profile, restore into a completely separate,
 * empty profile, and every way a restore must fail without changing anything.
 */
import { describe, expect, it } from 'vitest';
import type { AuditShieldDb } from '../../src/data/db/schema';
import { analyse } from '../../src/domain/vendor/rules';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { DEFAULT_RULE_CONFIG, NAMED_PROFILE } from '../../src/domain/vendor/types';
import { BackupError, exportBackup, readBackupHeader, restoreBackup } from '../../src/services/backup/backup';
import { generateEngagementKey } from '../../src/services/crypto/tokeniser';
import { analyseSnapshot, currentRun, getRuleConfig, protectAndCommit, SETTING, setupWorkspace, unlockWorkspace } from '../../src/services/workspace/useCases';
import { dumpDatabase, newProfile, PASSPHRASE, testClock, TEST_ITERATIONS } from '../helpers/profile';

const ENGAGEMENT_NAME = 'Zenith Forgings Ltd audit';
const tableCounts = async (db: AuditShieldDb) => Object.fromEntries(await Promise.all(db.tables.map(async (t) => [t.name, await t.count()] as const)));

async function sourceProfile() {
  const profile = newProfile();
  const clock = testClock();
  const { db, repos } = await profile.open();
  const session = await setupWorkspace(repos, PASSPHRASE, clock, TEST_ITERATIONS);
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() }, { name: ENGAGEMENT_NAME, financialYear: '2025-26', kind: 'client' }, clock.id());
  const raw = sampleRawDataset();
  const snapshot = await protectAndCommit(repos, session, { engagementId: engagement.id, raw, sourceType: 'sample', sourceLabel: 'zenith_master.csv', profile: NAMED_PROFILE, key: await generateEngagementKey(), retainDays: 30 }, clock);
  const stricter = { ...DEFAULT_RULE_CONFIG, version: 'rules-1.0.0/limit=15000000', approvalLimitPaise: 150_000_00 };
  await repos.settings.set(SETTING.ruleConfig(engagement.id), stricter, clock.now());
  await repos.settings.set(SETTING.autoLockMinutes, 5, clock.now());
  const run = await analyseSnapshot(repos, { engagementId: engagement.id, importId: snapshot.id, ruleConfig: stricter }, clock);
  return { profile, clock, db, repos, session, engagement, snapshot, run, raw, stricter };
}

const backupOf = async (s: Awaited<ReturnType<typeof sourceProfile>>, includeRetainedSource = true) =>
  exportBackup(s.db, s.session.dek, { passphrase: PASSPHRASE, includeRetainedSource, createdAt: s.clock.now(), iterations: TEST_ITERATIONS });

const restoreInto = (db: AuditShieldDb, bytes: Uint8Array, passphrase = PASSPHRASE) =>
  restoreBackup(db, bytes, { passphrase, at: '2026-12-01T10:00:00.000Z', auditId: 'restore-audit', iterations: TEST_ITERATIONS });

describe('backup file', () => {
  it('has a readable header with versions and counts, and nothing identifying in clear', async () => {
    const s = await sourceProfile();
    const { bytes, header } = await backupOf(s);
    expect(header).toMatchObject({
      format: 'auditshield-backup', formatVersion: 1, schemaVersion: 2, includesRetainedSource: true,
      counts: { engagements: 1, imports: 1, entities: 25, payments: 86, analysisRuns: 1, rawPayloads: 1, engagementKeys: 1 },
      kdf: { name: 'PBKDF2', hash: 'SHA-256' }, cipher: { name: 'AES-GCM' },
    });
    expect(readBackupHeader(bytes).header).toEqual(header);

    const text = Buffer.from(bytes).toString('utf8');
    const secrets = [
      ENGAGEMENT_NAME, 'zenith_master', PASSPHRASE, 'Sai Traders', 'Mrs. Sunita Mehta',
      ...s.raw.employees.flatMap((e) => [e.name, e.pan, e.bankAccount]),
      ...s.raw.vendors.flatMap((v) => [v.pan, v.bankAccount]),
    ];
    for (const secret of secrets) expect(text, secret).not.toContain(secret);
  });

  it('two backups of the same data differ entirely (fresh salt and nonce each time)', async () => {
    const s = await sourceProfile();
    const [a, b] = [await backupOf(s), await backupOf(s)];
    expect(a.header.kdf.salt).not.toBe(b.header.kdf.salt);
    expect(a.header.cipher.iv).not.toBe(b.header.cipher.iv);
  });

  it('leaves retained source data and HMAC keys out unless they are explicitly included', async () => {
    const s = await sourceProfile();
    const { header, bytes } = await backupOf(s, false);
    expect(header.includesRetainedSource).toBe(false);
    expect(header.counts).toMatchObject({ rawPayloads: 0, engagementKeys: 0, payments: 86 });
    const fresh = await newProfile().open();
    const { dek } = await restoreInto(fresh.db, bytes);
    expect(await fresh.db.rawPayloads.count()).toBe(0);
    expect(await fresh.db.engagementKeys.count()).toBe(0);
    expect(await fresh.repos.datasets.loadRetained(dek, s.session.workspace.id, s.snapshot.id)).toBeNull();
  });
});

describe('restore into a fresh profile', () => {
  it('reproduces engagements, snapshot, findings, settings and retained source, and unlocks after restart', async () => {
    const s = await sourceProfile();
    const { bytes } = await backupOf(s);
    const expectedCounts = await tableCounts(s.db);
    const expectedFindings = await s.repos.runs.findings(s.run.id);
    s.profile.closeAll(); // the source profile is gone from here on

    const target = newProfile();
    const first = await target.open();
    expect(await tableCounts(first.db)).toEqual(Object.fromEntries(Object.keys(expectedCounts).map((k) => [k, 0])));
    const restored = await restoreInto(first.db, bytes);
    expect(restored.header.counts['findings']).toBe(expectedFindings.length);
    expect(await tableCounts(first.db)).toEqual({ ...expectedCounts, auditEvents: expectedCounts['auditEvents']! + 1 });
    target.closeAll();

    // ---- restart of the restored profile
    const { db, repos } = await target.open();
    const session = await unlockWorkspace(repos, PASSPHRASE);
    expect(session.workspace.id).toBe(s.session.workspace.id);
    const [record] = await repos.engagements.list(session.workspace.id);
    expect(await repos.engagements.view(session.dek, record!)).toMatchObject({ id: s.engagement.id, name: ENGAGEMENT_NAME, kind: 'client' });

    const snapshot = await repos.datasets.latestImport(s.engagement.id);
    expect(await repos.datasets.sourceLabel(session.dek, session.workspace.id, snapshot!)).toBe('zenith_master.csv');
    const config = await getRuleConfig(repos, s.engagement.id);
    expect(config).toEqual(s.stricter);
    expect(await repos.settings.get(SETTING.autoLockMinutes, 0)).toBe(5);

    const run = await currentRun(repos, s.snapshot.id, config);
    expect(run).toEqual(await Promise.resolve(s.run));
    expect(await repos.runs.findings(run!.id)).toEqual(expectedFindings);
    // The restored snapshot is analysable on its own and gives the stored result again.
    const reanalysed = analyse(await repos.datasets.loadProtected(s.snapshot.id), config);
    expect(reanalysed.findings.map((f) => f.fingerprint)).toEqual(expectedFindings.map((f) => f.fingerprint));
    expect(reanalysed.summary).toEqual(run!.summary);

    expect((await repos.datasets.loadRetained(session.dek, session.workspace.id, s.snapshot.id))?.raw).toEqual(s.raw);
    expect((await repos.audit.list())[0]).toMatchObject({ action: 'Workspace restored from backup' });
    // At rest in the new profile, the label is again ciphertext under the new workspace key.
    expect(await dumpDatabase(db)).not.toContain(ENGAGEMENT_NAME);
  });

  it('the restored workspace has its own data key: the old profile’s key cannot read it', async () => {
    const s = await sourceProfile();
    const { bytes } = await backupOf(s);
    const target = await newProfile().open();
    await restoreInto(target.db, bytes);
    const [record] = await target.repos.engagements.list(s.session.workspace.id);
    await expect(target.repos.engagements.view(s.session.dek, record!)).rejects.toThrow();
  });
});

describe('restores that must fail and change nothing', () => {
  async function expectUntouched(bytes: Uint8Array, code: BackupError['code'], passphrase = PASSPHRASE) {
    const target = await newProfile().open();
    const attempt = await restoreInto(target.db, bytes, passphrase).then(() => null, (e: unknown) => e);
    expect(attempt).toBeInstanceOf(BackupError);
    expect((attempt as BackupError).code).toBe(code);
    expect((attempt as BackupError).message).toMatch(/Nothing was changed|not an AuditShield backup/);
    expect(Object.values(await tableCounts(target.db)).every((n) => n === 0)).toBe(true);
  }
  const edit = (bytes: Uint8Array, change: (file: Record<string, unknown>) => void) => {
    const file = JSON.parse(Buffer.from(bytes).toString('utf8')) as Record<string, unknown>;
    change(file);
    return new TextEncoder().encode(JSON.stringify(file));
  };

  it('wrong passphrase', async () => {
    const { bytes } = await backupOf(await sourceProfile());
    await expectUntouched(bytes, 'wrong-passphrase-or-damaged', 'a different passphrase');
  });

  it('ciphertext altered by one character', async () => {
    const { bytes } = await backupOf(await sourceProfile());
    const tampered = edit(bytes, (f) => {
      const p = f['payload'] as string;
      f['payload'] = `${p.slice(0, 1000)}${p[1000] === 'A' ? 'B' : 'A'}${p.slice(1001)}`;
    });
    await expectUntouched(tampered, 'wrong-passphrase-or-damaged');
  });

  it('truncated file contents', async () => {
    const { bytes } = await backupOf(await sourceProfile());
    await expectUntouched(edit(bytes, (f) => (f['payload'] = (f['payload'] as string).slice(0, 4000))), 'wrong-passphrase-or-damaged');
  });

  it('header altered (the header is authenticated with the ciphertext)', async () => {
    const { bytes } = await backupOf(await sourceProfile());
    await expectUntouched(edit(bytes, (f) => ((f['counts'] as Record<string, number>)['payments'] = 85)), 'wrong-passphrase-or-damaged');
    await expectUntouched(edit(bytes, (f) => (f['createdAt'] = '2020-01-01T00:00:00.000Z')), 'wrong-passphrase-or-damaged');
    await expectUntouched(edit(bytes, (f) => (f['includesRetainedSource'] = false)), 'wrong-passphrase-or-damaged');
  });

  it('a backup from a newer app is refused before any decryption', async () => {
    const { bytes } = await backupOf(await sourceProfile());
    await expectUntouched(edit(bytes, (f) => (f['formatVersion'] = 2)), 'newer-format');
    await expectUntouched(edit(bytes, (f) => (f['schemaVersion'] = 3)), 'unsupported-schema');
    await expectUntouched(edit(bytes, (f) => (f['schemaVersion'] = 1)), 'unsupported-schema');
  });

  it('files that are not backups', async () => {
    await expectUntouched(new TextEncoder().encode('vendor_id,vendor_name\nV1,A'), 'not-a-backup');
    await expectUntouched(new TextEncoder().encode('{"format":"something-else"}'), 'not-a-backup');
    const { bytes } = await backupOf(await sourceProfile());
    await expectUntouched(edit(bytes, (f) => delete f['kdf']), 'not-a-backup');
  });

  it('a backup whose records do not fit together', async () => {
    const s = await sourceProfile();
    // Corrupt the source so the (correctly encrypted) backup carries an orphan finding.
    const [finding] = await s.db.findings.toArray();
    await s.db.findings.add({ ...finding!, id: 'orphan', runId: 'missing-run' });
    const { bytes } = await backupOf(s);
    await expectUntouched(bytes, 'invalid-content');
  });

  it('an existing workspace is never overwritten', async () => {
    const { bytes } = await backupOf(await sourceProfile());
    const occupied = await newProfile().open();
    await setupWorkspace(occupied.repos, 'another passphrase 123', testClock(), TEST_ITERATIONS);
    const before = await dumpDatabase(occupied.db);
    const attempt = await restoreInto(occupied.db, bytes).then(() => null, (e: unknown) => e);
    expect((attempt as BackupError).code).toBe('workspace-exists');
    expect(await dumpDatabase(occupied.db)).toBe(before);
  });
});
