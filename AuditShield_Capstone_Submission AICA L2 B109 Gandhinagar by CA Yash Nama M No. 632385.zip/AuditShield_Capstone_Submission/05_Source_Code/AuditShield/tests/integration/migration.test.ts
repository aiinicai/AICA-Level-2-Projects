/**
 * Schema versions: upgrading a database written by the previous version, a migration that fails
 * half-way, a database newer than the app, and storage that is not available at all.
 */
import { IDBKeyRange } from 'fake-indexeddb';
import { describe, expect, it } from 'vitest';
import { createDb, openDb, SCHEMA_VERSION } from '../../src/data/db/schema';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { DEFAULT_RULE_CONFIG, MINIMAL_PROFILE } from '../../src/domain/vendor/types';
import { generateEngagementKey } from '../../src/services/crypto/tokeniser';
import { analyseSnapshot, protectAndCommit, setupWorkspace, unlockWorkspace } from '../../src/services/workspace/useCases';
import { dumpDatabase, newProfile, PASSPHRASE, testClock, TEST_ITERATIONS } from '../helpers/profile';

/** A profile holding real data written while the schema was at version 1. */
async function version1Profile() {
  const profile = newProfile();
  const clock = testClock();
  const { db, repos, result } = await profile.open({ maxVersion: 1 });
  expect(result).toEqual({ ok: true });
  expect(db.verno).toBe(1);
  const session = await setupWorkspace(repos, PASSPHRASE, clock, TEST_ITERATIONS);
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() }, { name: 'Client from v1', financialYear: '2025-26', kind: 'client' }, clock.id());
  const snapshot = await protectAndCommit(repos, session, { engagementId: engagement.id, raw: sampleRawDataset(), sourceType: 'sample', sourceLabel: 'v1 data', profile: MINIMAL_PROFILE, key: await generateEngagementKey(), retainDays: 30 }, clock);
  const run = await analyseSnapshot(repos, { engagementId: engagement.id, importId: snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, clock);
  // Version 1 findings had no reviewStatus field.
  await db.findings.toCollection().modify((f) => {
    delete (f as { reviewStatus?: unknown }).reviewStatus;
  });
  expect(db.tables.map((t) => t.name)).not.toContain('workpapers');
  const dump = await dumpDatabase(db);
  profile.closeAll();
  return { profile, engagement, snapshot, run, dump };
}

describe('upgrade from schema version 1', () => {
  it('opens, backfills the new field, adds the new store and index, and keeps every record', async () => {
    const v1 = await version1Profile();
    const { db, repos, result } = await v1.profile.open();
    expect(result).toEqual({ ok: true });
    expect(db.verno).toBe(SCHEMA_VERSION);
    expect(db.tables.map((t) => t.name)).toContain('workpapers');

    const session = await unlockWorkspace(repos, PASSPHRASE);
    const [record] = await repos.engagements.list(session.workspace.id);
    expect((await repos.engagements.view(session.dek, record!)).name).toBe('Client from v1');
    const findings = await repos.runs.findings(v1.run.id);
    expect(findings).toHaveLength(14);
    expect(findings.every((f) => f.reviewStatus === 'open')).toBe(true);
    expect(await db.findings.where('[runId+reviewStatus]').equals([v1.run.id, 'open']).count()).toBe(14);
    expect((await repos.datasets.loadProtected(v1.snapshot.id)).payments).toHaveLength(86);
    expect((await repos.datasets.loadRetained(session.dek, session.workspace.id, v1.snapshot.id))?.raw.vendors).toHaveLength(12);
    expect(await db.auditEvents.count()).toBe(4);
  });
});

describe('a migration that fails', () => {
  it('is rolled back: the app reports it, and the version 1 data is byte-for-byte unchanged', async () => {
    const v1 = await version1Profile();
    const failed = await v1.profile.open({
      beforeUpgradeV2: () => {
        throw new Error('simulated failure inside the upgrade');
      },
    });
    expect(failed.result).toMatchObject({ ok: false, reason: 'migration-failed' });
    expect(failed.result.ok === false && failed.result.message).toMatch(/rolled back.*unchanged/);
    v1.profile.closeAll();

    const again = await v1.profile.open({ maxVersion: 1 });
    expect(again.result).toEqual({ ok: true });
    expect(again.db.verno).toBe(1);
    expect(await dumpDatabase(again.db)).toBe(v1.dump);
    v1.profile.closeAll();

    // And a later, working upgrade still succeeds on that same data.
    const upgraded = await v1.profile.open();
    expect(upgraded.result).toEqual({ ok: true });
    expect(await upgraded.db.findings.count()).toBe(14);
  });
});

describe('a database newer than the app', () => {
  it('is refused without being modified', async () => {
    const profile = newProfile();
    const current = await profile.open();
    await setupWorkspace(current.repos, PASSPHRASE, testClock(), TEST_ITERATIONS);
    const dump = await dumpDatabase(current.db);
    profile.closeAll();

    const older = await profile.open({ maxVersion: 1 });
    expect(older.result).toMatchObject({ ok: false, reason: 'newer-version' });
    expect(older.result.ok === false && older.result.message).toMatch(/newer version of AuditShield/);
    profile.closeAll();

    const back = await profile.open();
    expect(back.result).toEqual({ ok: true });
    expect(await dumpDatabase(back.db)).toBe(dump);
  });
});

describe('storage that is not available', () => {
  it('a browser that refuses IndexedDB gets an explanation, not a crash', async () => {
    const refusing = {
      open() {
        throw new DOMException('The user denied permission to access the database.', 'SecurityError');
      },
    } as unknown as IDBFactory;
    const result = await openDb(createDb({ indexedDB: refusing, IDBKeyRange }));
    expect(result).toMatchObject({ ok: false, reason: 'unavailable' });
    expect(result.ok === false && result.message).toMatch(/Private or guest windows/);
  });
});
