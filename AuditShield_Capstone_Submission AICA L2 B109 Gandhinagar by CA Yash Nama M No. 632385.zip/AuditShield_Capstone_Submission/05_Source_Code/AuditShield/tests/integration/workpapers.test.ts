/** Finding reviews: saved encrypted, survive restart and backup/restore, and export traceably. */
import { describe, expect, it } from 'vitest';
import { IntegrityError } from '../../src/data/repositories/repositories';
import { reviewProblem } from '../../src/domain/vendor/review';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { DEFAULT_RULE_CONFIG, NAMED_PROFILE } from '../../src/domain/vendor/types';
import { exportBackup, restoreBackup } from '../../src/services/backup/backup';
import { generateEngagementKey } from '../../src/services/crypto/tokeniser';
import { buildWorkpaperHtml } from '../../src/services/workpaper/exportHtml';
import { analyseSnapshot, protectAndCommit, setupWorkspace, unlockWorkspace } from '../../src/services/workspace/useCases';
import { dumpDatabase, newProfile, PASSPHRASE, testClock, TEST_ITERATIONS } from '../helpers/profile';

const CONCLUSION = 'Vendor Sai Traders is operated by employee Rohit Shinde <AP>; referred to those charged with governance.';

async function reviewedProfile() {
  const profile = newProfile();
  const clock = testClock();
  const { db, repos } = await profile.open();
  const session = await setupWorkspace(repos, PASSPHRASE, clock, TEST_ITERATIONS);
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() }, { name: 'Zenith audit', financialYear: '2025-26', kind: 'client' }, clock.id());
  const snapshot = await protectAndCommit(repos, session, { engagementId: engagement.id, raw: sampleRawDataset(), sourceType: 'sample', sourceLabel: 'x', profile: NAMED_PROFILE, key: await generateEngagementKey(), retainDays: null }, clock);
  const run = await analyseSnapshot(repos, { engagementId: engagement.id, importId: snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, clock);
  const findings = await repos.runs.findings(run.id);
  const ghost = findings[0]!;
  await repos.workpapers.save(session.dek, session.workspace.id, engagement.id, ghost.fingerprint, { status: 'investigating', notes: 'KYC requested', conclusion: '' }, { id: clock.id(), at: clock.now() });
  await repos.workpapers.save(session.dek, session.workspace.id, engagement.id, ghost.fingerprint, { status: 'confirmed-issue', notes: 'KYC received 12 Nov', conclusion: CONCLUSION }, { id: clock.id(), at: clock.now() });
  return { profile, clock, db, repos, session, engagement, snapshot, run, findings, ghost };
}

describe('review rules', () => {
  it('a settling decision needs a written conclusion; a working status does not', () => {
    expect(reviewProblem({ status: 'investigating', notes: '', conclusion: '' })).toBeNull();
    expect(reviewProblem({ status: 'needs-information', notes: 'asked', conclusion: '' })).toBeNull();
    for (const status of ['confirmed-issue', 'false-positive', 'closed'] as const) {
      expect(reviewProblem({ status, notes: 'x', conclusion: 'too short' })).toMatch(/needs a conclusion/);
      expect(reviewProblem({ status, notes: '', conclusion: 'Supported by vendor KYC and bank confirmation.' })).toBeNull();
    }
  });

  it('the repository refuses an invalid review and a review for a missing engagement', async () => {
    const s = await reviewedProfile();
    const stamp = { id: 'x', at: s.clock.now() };
    await expect(s.repos.workpapers.save(s.session.dek, s.session.workspace.id, s.engagement.id, 'f', { status: 'closed', notes: '', conclusion: '' }, stamp)).rejects.toBeInstanceOf(IntegrityError);
    await expect(s.repos.workpapers.save(s.session.dek, s.session.workspace.id, 'missing', 'f', { status: 'open', notes: '', conclusion: '' }, stamp)).rejects.toBeInstanceOf(IntegrityError);
    expect(await s.db.workpapers.count()).toBe(1);
  });
});

describe('saved reviews', () => {
  it('keep revisions, are encrypted at rest, and survive a restart', async () => {
    const s = await reviewedProfile();
    const dump = await dumpDatabase(s.db);
    expect(dump).not.toContain('Rohit Shinde');
    expect(dump).not.toContain('KYC received');
    expect((await s.repos.audit.list()).filter((e) => e.action === 'Finding reviewed').map((e) => e.detail)).toEqual([
      `finding ${s.ghost.fingerprint}: investigating → confirmed-issue, revision 2`,
      `finding ${s.ghost.fingerprint}: investigating, revision 1`,
    ]);
    s.profile.closeAll();

    const { repos } = await s.profile.open();
    const session = await unlockWorkspace(repos, PASSPHRASE);
    const [record] = await repos.workpapers.list(s.engagement.id);
    expect(await repos.workpapers.view(session.dek, session.workspace.id, record!)).toMatchObject({
      fingerprint: s.ghost.fingerprint, status: 'confirmed-issue', notes: 'KYC received 12 Nov', conclusion: CONCLUSION, revision: 2,
    });
    expect(await repos.workpapers.list('another-engagement')).toEqual([]);
  });

  it('come back readable after backup and restore into a fresh profile', async () => {
    const s = await reviewedProfile();
    const { bytes, header } = await exportBackup(s.db, s.session.dek, { passphrase: PASSPHRASE, includeRetainedSource: false, createdAt: s.clock.now(), iterations: TEST_ITERATIONS });
    expect(header.counts['workpapers']).toBe(1);
    expect(Buffer.from(bytes).toString('utf8')).not.toContain('Rohit Shinde');

    const target = await newProfile().open();
    const { dek } = await restoreBackup(target.db, bytes, { passphrase: PASSPHRASE, at: s.clock.now(), auditId: 'r', iterations: TEST_ITERATIONS });
    const [record] = await target.repos.workpapers.list(s.engagement.id);
    expect(await target.repos.workpapers.view(dek, s.session.workspace.id, record!)).toMatchObject({ status: 'confirmed-issue', conclusion: CONCLUSION, revision: 2 });
    // Re-encrypted under the new workspace key: the old key no longer opens it.
    await expect(target.repos.workpapers.view(s.session.dek, s.session.workspace.id, record!)).rejects.toThrow();
    expect(await dumpDatabase(target.db)).not.toContain('Rohit Shinde');
  });
});

describe('workpaper export', () => {
  it('lists every finding with scope, thresholds, versions, evidence, status and conclusion, safely escaped', async () => {
    const s = await reviewedProfile();
    const [record] = await s.repos.workpapers.list(s.engagement.id);
    const view = await s.repos.workpapers.view(s.session.dek, s.session.workspace.id, record!);
    const html = buildWorkpaperHtml({
      engagementName: 'Zenith <b>audit</b>', financialYear: '2025-26', preparedAt: '2026-11-16T10:00:00.000Z',
      snapshot: s.snapshot, run: s.run, ruleConfig: DEFAULT_RULE_CONFIG, findings: s.findings, reviews: new Map([[view.fingerprint, view]]),
    });
    expect(html.match(/<tr>/g)).toHaveLength(15); // header row + 14 findings
    for (const expected of [
      '12 vendors, 10 employees, 3 directors, 86 payments totalling ₹1,10,33,700',
      'Approval limit ₹1,00,000; split window 3 days; near-limit band from 90% of the limit',
      s.run.id, s.snapshot.id, s.run.ruleSetId, 'vendor-rules-engine-2.0.0', s.snapshot.scheme.keyId,
      '14: 2 critical, 10 high, 1 medium, 1 low', '1 / 13', 'Confirmed issue', 'rev. 2',
      '₹51,16,715', 'not an estimate of loss', 'must not be added together',
      'P0081, P0082, P0083', s.ghost.fingerprint, 'KYC received 12 Nov',
    ]) expect(html, expected).toContain(expected);
    // Auditor text and labels cannot inject markup.
    expect(html).toContain('Zenith &lt;b&gt;audit&lt;/b&gt;');
    expect(html).toContain('Rohit Shinde &lt;AP&gt;');
    expect(html).not.toContain('<b>audit</b>');
    expect(html).not.toMatch(/<script/i);
  });
});
