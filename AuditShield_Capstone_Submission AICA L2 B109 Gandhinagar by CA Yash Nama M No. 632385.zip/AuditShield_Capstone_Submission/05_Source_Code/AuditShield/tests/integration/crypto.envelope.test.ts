/** Workspace key envelope and record encryption (Web Crypto, as shipped). */
import { describe, expect, it } from 'vitest';
import {
  createEnvelope, DecryptionError, decryptJson, encryptJson, KDF_V1, openEnvelope, passphraseProblem, recordAad, WrongPassphraseError,
} from '../../src/services/crypto/envelope';
import { WorkspaceSession } from '../../src/services/workspace/session';
import { PASSPHRASE, TEST_ITERATIONS } from '../helpers/profile';

describe('key envelope', () => {
  it('the right passphrase opens it; a wrong one is rejected without revealing anything', async () => {
    const { envelope, dek } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    expect(dek.extractable).toBe(false);
    expect(dek.usages.sort()).toEqual(['decrypt', 'encrypt']);
    await expect(openEnvelope(envelope, PASSPHRASE)).resolves.toBeDefined();
    await expect(openEnvelope(envelope, `${PASSPHRASE}!`)).rejects.toBeInstanceOf(WrongPassphraseError);
    await expect(openEnvelope(envelope, '')).rejects.toBeInstanceOf(WrongPassphraseError);
  });

  it('stores only public parameters and the wrapped key', async () => {
    const { envelope } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    expect(Object.keys(envelope).sort()).toEqual(['kdf', 'version', 'wrap', 'wrappedKey']);
    expect(envelope.kdf).toMatchObject({ name: 'PBKDF2', hash: 'SHA-256', iterations: TEST_ITERATIONS });
    expect(envelope.kdf.salt).toHaveLength(16);
    expect(envelope.wrap.iv).toHaveLength(12);
    expect(envelope.wrappedKey).toHaveLength(32 + 16); // 256-bit key + GCM tag
    expect(JSON.stringify(envelope)).not.toContain(PASSPHRASE);
  });

  it('two workspaces with the same passphrase get different salts, nonces and keys', async () => {
    const [a, b] = await Promise.all([createEnvelope(PASSPHRASE, TEST_ITERATIONS), createEnvelope(PASSPHRASE, TEST_ITERATIONS)]);
    expect(a.envelope.kdf.salt).not.toEqual(b.envelope.kdf.salt);
    expect(a.envelope.wrappedKey).not.toEqual(b.envelope.wrappedKey);
    const aad = recordAad('w', 's', 'r', 'f');
    await expect(decryptJson(b.dek, aad, await encryptJson(a.dek, aad, 'secret'))).rejects.toBeInstanceOf(DecryptionError);
  });

  it('a tampered envelope does not open', async () => {
    const { envelope } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    const flipped = { ...envelope, wrappedKey: envelope.wrappedKey.map((b, i) => (i === 0 ? b ^ 1 : b)) };
    await expect(openEnvelope(flipped, PASSPHRASE)).rejects.toBeInstanceOf(WrongPassphraseError);
    await expect(openEnvelope({ ...envelope, kdf: { ...envelope.kdf, iterations: TEST_ITERATIONS + 1 } }, PASSPHRASE)).rejects.toBeInstanceOf(WrongPassphraseError);
  });

  it('normalises the passphrase (NFKC), and rejects weak ones before any key is made', async () => {
    const { envelope } = await createEnvelope('pässphrase-ａｂｃ', TEST_ITERATIONS);
    await expect(openEnvelope(envelope, 'pässphrase-abc')).resolves.toBeDefined();
    expect(passphraseProblem('short')).toMatch(/at least 10/);
    expect(passphraseProblem('aaaaaaaaaaaa')).toMatch(/repeated/);
    expect(passphraseProblem(PASSPHRASE)).toBeNull();
  });

  it(`production KDF cost (PBKDF2-SHA256 × ${KDF_V1.iterations}) is measured on this machine`, async () => {
    const started = performance.now();
    const { envelope } = await createEnvelope(PASSPHRASE);
    const createMs = performance.now() - started;
    const again = performance.now();
    await openEnvelope(envelope, PASSPHRASE);
    const unlockMs = performance.now() - again;
    console.info(`[kdf-benchmark] create ${createMs.toFixed(0)} ms, unlock ${unlockMs.toFixed(0)} ms (Node ${process.version})`);
    expect(envelope.kdf.iterations).toBe(600_000);
    expect(unlockMs).toBeGreaterThan(5); // a derivation this cheap would mean the cost parameter is not applied
  });
});

describe('record encryption', () => {
  it('round-trips JSON, including regional scripts', async () => {
    const { dek } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    const aad = recordAad('ws1', 'engagements', 'e1', 'label');
    const value = { name: 'मेहता इंडस्ट्रीज़ प्रा. लि.', n: 42 };
    expect(await decryptJson(dek, aad, await encryptJson(dek, aad, value))).toEqual(value);
  });

  it('uses a fresh nonce every time: equal plaintexts give different ciphertexts', async () => {
    const { dek } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    const aad = recordAad('ws1', 'engagements', 'e1', 'label');
    const boxes = await Promise.all(Array.from({ length: 200 }, () => encryptJson(dek, aad, 'same')));
    expect(new Set(boxes.map((b) => Buffer.from(b.iv).toString('hex'))).size).toBe(200);
    expect(new Set(boxes.map((b) => Buffer.from(b.ct).toString('hex'))).size).toBe(200);
    for (const b of boxes) expect(b.iv).toHaveLength(12);
  });

  it('a ciphertext moved to another workspace, store, record or field does not decrypt', async () => {
    const { dek } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    const box = await encryptJson(dek, recordAad('ws1', 'engagements', 'e1', 'label'), 'Client A');
    for (const aad of [
      recordAad('ws2', 'engagements', 'e1', 'label'),
      recordAad('ws1', 'imports', 'e1', 'label'),
      recordAad('ws1', 'engagements', 'e2', 'label'),
      recordAad('ws1', 'engagements', 'e1', 'sourceLabel'),
    ]) {
      await expect(decryptJson(dek, aad, box)).rejects.toBeInstanceOf(DecryptionError);
    }
  });

  it('any modified ciphertext or nonce byte is detected', async () => {
    const { dek } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    const aad = recordAad('ws1', 'engagements', 'e1', 'label');
    const box = await encryptJson(dek, aad, 'Client A');
    await expect(decryptJson(dek, aad, { ...box, ct: box.ct.map((b, i) => (i === 3 ? b ^ 0x80 : b)) })).rejects.toBeInstanceOf(DecryptionError);
    await expect(decryptJson(dek, aad, { ...box, iv: box.iv.map((b, i) => (i === 0 ? b ^ 1 : b)) })).rejects.toBeInstanceOf(DecryptionError);
  });
});

describe('workspace session locking', () => {
  function harness() {
    let pending: { fn: () => void; ms: number } | null = null;
    const session = new WorkspaceSession({
      set: (fn, ms) => (pending = { fn, ms }),
      clear: () => (pending = null),
    });
    return { session, fire: () => pending?.fn(), delay: () => pending?.ms ?? null };
  }
  const unlocked = async () => {
    const { dek } = await createEnvelope(PASSPHRASE, TEST_ITERATIONS);
    return { dek, workspace: { id: 'w', createdAt: '', envelope: {} as never } };
  };

  it('starts locked; unlocking holds the key in memory; locking drops it and tells listeners', async () => {
    const { session } = harness();
    let notified = 0;
    session.subscribe(() => notified++);
    expect(session.isUnlocked).toBe(false);
    session.unlock(await unlocked(), 15);
    expect(session.current?.dek).toBeDefined();
    session.lock('manual');
    expect(session.current).toBeNull();
    expect(session.lastLockReason).toBe('manual');
    expect(notified).toBe(2);
  });

  it('locks after the configured inactivity; activity restarts the countdown; 0 disables it', async () => {
    const h = harness();
    h.session.unlock(await unlocked(), 15);
    expect(h.delay()).toBe(15 * 60_000);
    h.session.touch();
    expect(h.delay()).toBe(15 * 60_000);
    h.fire();
    expect(h.session.isUnlocked).toBe(false);
    expect(h.session.lastLockReason).toBe('inactivity');
    expect(h.delay()).toBeNull();

    h.session.unlock(await unlocked(), 0);
    expect(h.delay()).toBeNull();
    h.session.setAutoLock(5);
    expect(h.delay()).toBe(5 * 60_000);
  });
});
