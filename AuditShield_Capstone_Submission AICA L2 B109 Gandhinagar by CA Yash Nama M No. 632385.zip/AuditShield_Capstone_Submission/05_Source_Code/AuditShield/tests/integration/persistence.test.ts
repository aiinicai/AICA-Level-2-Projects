/**
 * Persistence through the real repositories and Dexie, on fake-indexeddb.
 * "Restart" = close every connection and open a new one over the same stored data.
 */
import { describe, expect, it } from 'vitest';
import { ImportValidationError, IntegrityError, ruleSetIdFor } from '../../src/data/repositories/repositories';
import { analyse } from '../../src/domain/vendor/rules';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { DEFAULT_RULE_CONFIG, MINIMAL_PROFILE, NAMED_PROFILE, type RawDataset } from '../../src/domain/vendor/types';
import { WrongPassphraseError } from '../../src/services/crypto/envelope';
import { createTokeniser, generateEngagementKey, importEngagementKey } from '../../src/services/crypto/tokeniser';
import {
  analyseSnapshot, currentRun, getRuleConfig, protectAndCommit, purgeExpiredSource, SETTING, setupWorkspace, unlockWorkspace,
} from '../../src/services/workspace/useCases';
import { dumpDatabase, newProfile, PASSPHRASE, testClock, TEST_ITERATIONS } from '../helpers/profile';

const ENGAGEMENT_NAME = 'Zenith Forgings Ltd audit';

async function seeded(options: { retainDays?: number | null; raw?: RawDataset } = {}) {
  const profile = newProfile();
  const clock = testClock();
  const { db, repos } = await profile.open();
  const session = await setupWorkspace(repos, PASSPHRASE, clock, TEST_ITERATIONS);
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() }, { name: ENGAGEMENT_NAME, financialYear: '2025-26', kind: 'client' }, clock.id());
  const key = await generateEngagementKey();
  const raw = options.raw ?? sampleRawDataset();
  const snapshot = await protectAndCommit(repos, session, {
    engagementId: engagement.id, raw, sourceType: 'sample', sourceLabel: 'vendors_master_zenith.csv', profile: MINIMAL_PROFILE, key,
    retainDays: options.retainDays ?? null,
  }, clock);
  return { profile, clock, db, repos, session, engagement, key, raw, snapshot };
}

const rawSecrets = (raw: RawDataset) => [
  ...raw.employees.flatMap((e) => [e.name, e.bankAccount, e.pan, e.phone, e.address]),
  ...raw.vendors.flatMap((v) => [v.name, v.gstin, v.bankAccount, v.pan, v.phone, v.address]),
  ...raw.directors.flatMap((d) => [d.id, d.name, d.bankAccount, d.pan, d.phone, d.address]),
  ...raw.payments.map((p) => p.invoiceNo),
].filter(Boolean);

describe('restart persistence', () => {
  it('engagement, snapshot, run, findings, settings and activity survive closing and reopening', async () => {
    const s = await seeded();
    const run = await analyseSnapshot(s.repos, { engagementId: s.engagement.id, importId: s.snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, s.clock);
    await s.repos.settings.set(SETTING.currentEngagement, s.engagement.id, s.clock.now());
    const expected = analyse(await s.repos.datasets.loadProtected(s.snapshot.id));
    s.profile.closeAll();

    // ---- "restart": nothing is carried over in memory
    const { repos, result, db } = await s.profile.open();
    expect(result).toEqual({ ok: true });
    expect(db.verno).toBe(2);
    const session = await unlockWorkspace(repos, PASSPHRASE);
    const [record] = await repos.engagements.list(session.workspace.id);
    expect(await repos.engagements.view(session.dek, record!)).toMatchObject({ name: ENGAGEMENT_NAME, financialYear: '2025-26', kind: 'client', status: 'active' });
    expect(await repos.settings.get(SETTING.currentEngagement, null)).toBe(s.engagement.id);

    const snapshot = await repos.datasets.latestImport(s.engagement.id);
    expect(snapshot).toMatchObject({ id: s.snapshot.id, rowCounts: { employees: 10, vendors: 12, directors: 3, payments: 86 }, sourceType: 'sample' });
    expect(await repos.datasets.sourceLabel(session.dek, session.workspace.id, snapshot!)).toBe('vendors_master_zenith.csv');

    const stored = await currentRun(repos, s.snapshot.id, await getRuleConfig(repos, s.engagement.id));
    expect(stored).toMatchObject({ id: run.id, status: 'completed', ruleSetId: ruleSetIdFor(DEFAULT_RULE_CONFIG) });
    expect(stored?.summary).toEqual(expected.summary);
    expect(stored?.summary.totalPaidPaise).toBe(11_033_700_00);
    const findings = await repos.runs.findings(run.id);
    expect(findings.map((f) => f.fingerprint)).toEqual(expected.findings.map((f) => f.fingerprint));
    expect(findings).toHaveLength(14);
    expect(findings.every((f) => f.reviewStatus === 'open')).toBe(true);

    expect((await repos.audit.list()).map((e) => e.action)).toEqual(['Analysis run', 'Snapshot committed', 'Engagement created', 'Workspace created']);
  });

  it('a stored snapshot reloads exactly: analysing it after restart gives the same findings', async () => {
    const s = await seeded();
    const before = await s.repos.datasets.loadProtected(s.snapshot.id);
    s.profile.closeAll();
    const { repos } = await s.profile.open();
    const after = await repos.datasets.loadProtected(s.snapshot.id);
    expect(after).toEqual(before);
    expect(analyse(after).findings.map((f) => [f.ruleId, f.severity, f.amountPaise, f.paymentIds])).toEqual(
      analyse(before).findings.map((f) => [f.ruleId, f.severity, f.amountPaise, f.paymentIds]),
    );
  });

  it('a wrong passphrase does not unlock and changes nothing', async () => {
    const s = await seeded();
    const before = await dumpDatabase(s.db);
    await expect(unlockWorkspace(s.repos, 'not the passphrase')).rejects.toBeInstanceOf(WrongPassphraseError);
    expect(await dumpDatabase(s.db)).toBe(before);
  });
});

describe('what is at rest in the database', () => {
  it('by default: no source values, no engagement label, no source label, no key material', async () => {
    const s = await seeded();
    const dump = await dumpDatabase(s.db);
    for (const secret of rawSecrets(s.raw)) expect(dump, secret).not.toContain(secret);
    expect(dump).not.toContain(ENGAGEMENT_NAME);
    expect(dump).not.toContain('vendors_master_zenith');
    expect(dump).not.toContain(PASSPHRASE);
    expect(await s.db.rawPayloads.count()).toBe(0);
    expect(await s.db.engagementKeys.count()).toBe(0);
    expect(await s.repos.datasets.loadRetained(s.session.dek, s.session.workspace.id, s.snapshot.id)).toBeNull();
  });

  it('with retention opted in: source and key are stored, encrypted, and come back intact after restart', async () => {
    const s = await seeded({ retainDays: 30 });
    const dump = await dumpDatabase(s.db);
    for (const secret of rawSecrets(s.raw)) expect(dump, secret).not.toContain(secret);
    expect(await s.db.rawPayloads.count()).toBe(1);
    expect(await s.db.engagementKeys.count()).toBe(1);
    s.profile.closeAll();

    const { repos } = await s.profile.open();
    const session = await unlockWorkspace(repos, PASSPHRASE);
    const retained = await repos.datasets.loadRetained(session.dek, session.workspace.id, s.snapshot.id);
    expect(retained?.raw).toEqual(s.raw);
    // The retained key reproduces the stored tokens, so later data can be matched with this snapshot.
    const tokenise = createTokeniser(await importEngagementKey(retained!.keyId, retained!.keyBytes));
    const stored = await repos.datasets.loadProtected(s.snapshot.id);
    expect(await tokenise('pan', 'DRSPS5532H')).toBe(stored.entities.find((e) => e.id === 'V105')?.attributes.pan);
  });

  it('retained source is purged once its retention period ends, together with its key', async () => {
    const s = await seeded({ retainDays: 30 });
    s.clock.advance(29 * 86_400_000);
    expect(await purgeExpiredSource(s.repos, s.clock)).toBe(0);
    expect(await s.db.rawPayloads.count()).toBe(1);
    s.clock.advance(2 * 86_400_000);
    expect(await purgeExpiredSource(s.repos, s.clock)).toBe(1);
    expect(await s.db.rawPayloads.count()).toBe(0);
    expect(await s.db.engagementKeys.count()).toBe(0);
    expect((await s.repos.audit.list())[0]).toMatchObject({ action: 'Retained source data deleted', detail: '1 encrypted source copy removed (retention period ended)' });
    // The protected snapshot is not affected.
    expect((await s.repos.datasets.loadProtected(s.snapshot.id)).payments).toHaveLength(86);
  });

  it('"keep until deleted" (0 days) never expires on its own, and can be deleted on request', async () => {
    const s = await seeded({ retainDays: 0 });
    s.clock.advance(3650 * 86_400_000);
    expect(await purgeExpiredSource(s.repos, s.clock)).toBe(0);
    expect(await s.repos.datasets.deleteRetained([s.snapshot.id], { id: 'x', at: s.clock.now() }, s.engagement.id, 'requested by user')).toBe(1);
    expect(await s.db.rawPayloads.count()).toBe(0);
  });
});

describe('imports are atomic and validated', () => {
  const counts = async (db: Awaited<ReturnType<typeof seeded>>['db']) =>
    Object.fromEntries(await Promise.all(db.tables.map(async (t) => [t.name, await t.count()] as const)));

  it('a dataset with a duplicate payment ID, bad date or orphan vendor is rejected and nothing is written', async () => {
    const s = await seeded();
    const before = await counts(s.db);
    const bad = sampleRawDataset();
    bad.payments[1]!.id = bad.payments[0]!.id;
    bad.payments[2]!.date = '2025-02-30';
    bad.payments[3]!.vendorId = 'V999';
    const attempt = protectAndCommit(s.repos, s.session, { engagementId: s.engagement.id, raw: bad, sourceType: 'sample', sourceLabel: 'bad', profile: MINIMAL_PROFILE, key: s.key, retainDays: 30 }, s.clock);
    await expect(attempt).rejects.toBeInstanceOf(ImportValidationError);
    const error = await attempt.then(() => null, (e: unknown) => e as ImportValidationError);
    expect(error?.errors.map((e) => e.code).sort()).toEqual(['duplicate-payment', 'invalid-date', 'unknown-vendor']);
    expect(await counts(s.db)).toEqual(before);
  });

  it('a failure in the middle of the write rolls the whole snapshot back', async () => {
    const s = await seeded();
    const before = await counts(s.db);
    // Make the 50th payment insert collide after the import, entities and attributes were added.
    const clock = testClock('2027-01-01T00:00:00.000Z');
    const nextImportId = 'id-0001'; // first id handed out by this clock
    await s.db.payments.add({ id: `${nextImportId}|P0050`, engagementId: 'other', importId: 'other', seq: 0, sourcePaymentId: 'P0050', vendorId: 'V', invoiceRef: '', date: '2025-01-01', amountPaise: 1, currency: 'INR', approverRef: '' });
    await expect(
      protectAndCommit(s.repos, s.session, { engagementId: s.engagement.id, raw: sampleRawDataset(), sourceType: 'sample', sourceLabel: 'x', profile: MINIMAL_PROFILE, key: s.key, retainDays: 30 }, clock),
    ).rejects.toThrow();
    expect(await counts(s.db)).toEqual({ ...before, payments: before['payments']! + 1 });
    expect(await s.db.imports.get(nextImportId)).toBeUndefined();
    expect(await s.db.entities.where('importId').equals(nextImportId).count().catch(() => 0)).toBe(0);
  });

  it('a snapshot cannot be committed to an engagement that does not exist', async () => {
    const s = await seeded();
    const before = await counts(s.db);
    await expect(
      protectAndCommit(s.repos, s.session, { engagementId: 'missing', raw: sampleRawDataset(), sourceType: 'sample', sourceLabel: 'x', profile: MINIMAL_PROFILE, key: s.key, retainDays: null }, s.clock),
    ).rejects.toBeInstanceOf(IntegrityError);
    expect(await counts(s.db)).toEqual(before);
  });

  it('a run cannot be stored against another engagement’s snapshot', async () => {
    const s = await seeded();
    await expect(analyseSnapshot(s.repos, { engagementId: 'someone-else', importId: s.snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, s.clock)).rejects.toBeInstanceOf(IntegrityError);
    expect(await s.db.analysisRuns.count()).toBe(0);
    expect(await s.db.findings.count()).toBe(0);
  });
});

describe('runs are immutable and tied to their snapshot and rule set', () => {
  it('changing thresholds does not present the old run as current; both runs stay stored', async () => {
    const s = await seeded();
    const first = await analyseSnapshot(s.repos, { engagementId: s.engagement.id, importId: s.snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, s.clock);
    const stricter = { ...DEFAULT_RULE_CONFIG, version: 'rules-1.0.0/limit=5000000', approvalLimitPaise: 50_000_00 };
    await s.repos.settings.set(SETTING.ruleConfig(s.engagement.id), stricter, s.clock.now());

    const config = await getRuleConfig(s.repos, s.engagement.id);
    expect(config).toEqual(stricter);
    expect(await currentRun(s.repos, s.snapshot.id, config)).toBeUndefined();

    const second = await analyseSnapshot(s.repos, { engagementId: s.engagement.id, importId: s.snapshot.id, ruleConfig: config }, s.clock);
    expect((await currentRun(s.repos, s.snapshot.id, config))?.id).toBe(second.id);
    expect((await currentRun(s.repos, s.snapshot.id, DEFAULT_RULE_CONFIG))?.id).toBe(first.id);
    expect(await s.repos.runs.forImport(s.snapshot.id)).toHaveLength(2);
    expect((await s.repos.runs.ruleSet(first.ruleSetId))?.config).toEqual(DEFAULT_RULE_CONFIG);
    expect((await s.repos.runs.ruleSet(second.ruleSetId))?.config).toEqual(stricter);
    expect(second.summary.findings).not.toBe(first.summary.findings);
    expect(await s.repos.runs.findings(first.id)).toHaveLength(14);
  });

  it('a new snapshot of the same engagement has no run until it is analysed', async () => {
    const s = await seeded();
    await analyseSnapshot(s.repos, { engagementId: s.engagement.id, importId: s.snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, s.clock);
    const second = await protectAndCommit(s.repos, s.session, { engagementId: s.engagement.id, raw: sampleRawDataset(), sourceType: 'sample', sourceLabel: 'again', profile: NAMED_PROFILE, key: s.key, retainDays: null }, s.clock);
    expect((await s.repos.datasets.latestImport(s.engagement.id))?.id).toBe(second.id);
    expect(await currentRun(s.repos, second.id, DEFAULT_RULE_CONFIG)).toBeUndefined();
    expect(second.sourceDigest).toBe(s.snapshot.sourceDigest);
    expect(await s.repos.datasets.imports(s.engagement.id)).toHaveLength(2);
  });
});

describe('engagement isolation', () => {
  it('queries for one engagement never return another’s records, and deleting one leaves the other intact', async () => {
    const s = await seeded({ retainDays: 30 });
    const other = await s.repos.engagements.create(s.session.dek, s.session.workspace.id, { id: s.clock.id(), at: s.clock.now() }, { name: 'Other client', financialYear: '2025-26', kind: 'client' }, s.clock.id());
    const small: RawDataset = {
      employees: [], directors: [],
      vendors: [{ id: 'V105', name: 'Unrelated V105', gstin: '', bankAccount: '998877665544', pan: '', phone: '', address: '', createdBy: '' }],
      payments: [{ id: 'P0001', vendorId: 'V105', invoiceNo: 'X-1', date: '2025-05-05', amountPaise: 5_00, approvedBy: '' }],
    };
    const otherSnapshot = await protectAndCommit(s.repos, s.session, { engagementId: other.id, raw: small, sourceType: 'sample', sourceLabel: 'small', profile: MINIMAL_PROFILE, key: await generateEngagementKey(), retainDays: 30 }, s.clock);
    const runA = await analyseSnapshot(s.repos, { engagementId: s.engagement.id, importId: s.snapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, s.clock);
    const runB = await analyseSnapshot(s.repos, { engagementId: other.id, importId: otherSnapshot.id, ruleConfig: DEFAULT_RULE_CONFIG }, s.clock);

    // Same source IDs (V105, P0001) exist in both engagements without colliding.
    expect((await s.repos.datasets.loadProtected(otherSnapshot.id)).payments).toEqual([expect.objectContaining({ id: 'P0001', amountPaise: 5_00 })]);
    expect((await s.repos.datasets.loadProtected(s.snapshot.id)).payments).toHaveLength(86);
    expect((await s.repos.datasets.paymentsByIds(otherSnapshot.id, ['P0001', 'P0002'])).map((p) => p.engagementId)).toEqual([other.id]);
    expect((await s.repos.datasets.latestImport(other.id))?.id).toBe(otherSnapshot.id);
    expect(await s.repos.runs.findings(runB.id)).toHaveLength(0);
    expect((await s.repos.runs.findings(runA.id)).every((f) => f.engagementId === s.engagement.id)).toBe(true);
    // Different engagement keys: the same PAN would not even produce the same token.
    expect(otherSnapshot.scheme.keyId).not.toBe(s.snapshot.scheme.keyId);

    await s.repos.engagements.remove(s.engagement.id, { id: s.clock.id(), at: s.clock.now() });
    for (const table of ['imports', 'entities', 'entityAttributes', 'payments', 'analysisRuns', 'findings', 'rawPayloads', 'engagementKeys'] as const) {
      const remaining = await s.db.table(table).toArray() as { engagementId: string }[];
      // The other engagement's run has no findings, so that store is simply empty afterwards.
      if (table !== 'findings') expect(remaining.length, table).toBeGreaterThan(0);
      expect(remaining.every((r) => r.engagementId === other.id), table).toBe(true);
    }
    expect((await s.db.analysisRuns.toArray()).map((r) => r.id)).toEqual([runB.id]);
    expect((await s.repos.engagements.list(s.session.workspace.id)).map((e) => e.id)).toEqual([other.id]);
    expect((await s.repos.audit.list())[0]).toMatchObject({ action: 'Engagement deleted', engagementId: '' });
  });
});
