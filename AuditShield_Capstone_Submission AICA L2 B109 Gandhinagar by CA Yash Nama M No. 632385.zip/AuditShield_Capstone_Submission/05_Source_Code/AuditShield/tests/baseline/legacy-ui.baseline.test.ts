/**
 * BASELINE — legacy built apps driven through a fake DOM.
 *
 * Asserted replacement for the two console-only `node tests/smoke.js dist/<app>.html` runs.
 * Proves the legacy click handlers still produce the baseline numbers end to end.
 */
import { describe, expect, it } from 'vitest';
import { bootLegacyApp, stripTags } from '../helpers/legacy';

const click = (el: { onclick?: (ev?: unknown) => unknown } | undefined) => {
  if (!el?.onclick) throw new Error('element has no click handler');
  return el.onclick();
};
const rows = (html: string) => (html.match(/<tr>/g) ?? []).length - 1;

describe('legacy VendorShield app — sample flow', () => {
  const app = bootLegacyApp('VendorShield_GhostVendorDetector.html');

  it('load sample → protect → analyse → export workpaper', () => {
    click(app.els['loadSample']);
    expect(app.els['loadMsg']!.textContent).toBe(
      'Loaded fictional "Mehta Industries Pvt Ltd": 10 employees, 12 vendors, 3 directors, 86 payments.',
    );

    click(app.els['protect']);
    expect(stripTags(app.els['leakCheck']!.innerHTML)).toBe(
      'Automatic leak test: searched the shared file for all 120 original sensitive values → 0 found .',
    );

    click(app.els['runBtn']);
    const kpis = stripTags(app.els['kpis']!.innerHTML);
    expect(kpis).toContain('12 / 86 Vendors / payments scanned');
    expect(kpis).toContain('₹1,10,33,700 Total paid');
    expect(kpis).toContain('2 Critical flags');
    expect(kpis).toContain('14 Total red flags');
    expect(kpis).toContain('₹51,16,715 Paid to 6 high-risk vendors');
    expect((app.els['flags']!.innerHTML.match(/class="flag /g) ?? []).length).toBe(14);

    click(app.els['dlReport']);
    const report = app.downloads.at(-1);
    expect(report?.name).toBe('VendorShield_workpaper.html');
    expect(rows(report?.text ?? '')).toBe(14);
    expect(report?.text).toContain('Red flags are indicators, not conclusions.');
    expect(app.alerts).toEqual([]);
  });
});

describe('legacy Gateway app — default sample with the offline demo AI', () => {
  const app = bootLegacyApp('CA_Safe_AI_Gateway.html');

  it('scan → send → restore → vault/log → evaluation', async () => {
    click(app.els['scanBtn']);
    expect(stripTags(app.els['chips']!.innerHTML)).toBe(
      'Organisation / client: 1 PAN: 1 Bank account no.: 1 IFSC: 1 UPI ID: 1 Person name: 4 Phone: 1',
    );
    expect(stripTags(app.els['leak']!.innerHTML)).toMatch(/Leak test passed.*all 8 vault values → 0 found/);

    await click(app.els['sendBtn']);
    expect(app.fetchCalls).toHaveLength(0); // offline demo never touches the network
    expect(app.els['aiRaw']!.textContent).not.toContain('Rohit Shinde');
    expect(app.els['aiRaw']!.textContent).toContain('[PERSON_1]');
    expect(stripTags(app.els['final']!.innerHTML)).toContain('Individuals referred to: Rohit Shinde , Anita Deshpande');

    app.els['reveal']!.onchange?.();
    expect(rows(app.els['vault']!.innerHTML)).toBe(8);
    expect(rows(app.els['log']!.innerHTML)).toBe(1);

    click(app.els['evalBtn']);
    const evalText = stripTags(app.els['evalOut']!.innerHTML);
    expect(evalText).toContain('95% Recall (caught)');
    expect(evalText).toContain('100% Precision (correct flags)');
    expect(evalText).toContain('21/22 identifiers caught');
    expect(evalText).toContain('0 false alarms');
  });
});
