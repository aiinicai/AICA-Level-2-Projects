/**
 * BASELINE — legacy VendorShield core (legacy/ghost_vendor/core.js).
 *
 * Replaces the console-only checks in legacy/tests/test_gv.js with assertions. These describe the
 * synthetic sample only. They are a regression reference, not evidence of real-world accuracy.
 */
import { createHash, createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { type LegacyFlag, type LegacyGV, legacyText, loadLegacyCore, plain } from '../helpers/legacy';

const GV = loadLegacyCore<LegacyGV>('ghost_vendor');
const KEY = 'ClientSecret#2026';
const TABLES = ['employees', 'vendors', 'directors', 'payments'] as const;

const project = (f: LegacyFlag) => ({
  rule: f.rule,
  severity: f.severity,
  entities: f.entities,
  amount: f.amount,
  ...(f.fields ? { fields: f.fields } : {}),
  ...(f.payments ? { payments: f.payments } : {}),
  title: f.title,
});

/** Golden findings for the built-in sample, in the legacy display order (severity, then amount). */
const EXPECTED_FLAGS = [
  { rule: 'R1 Employee-as-Vendor / Ghost Vendor', severity: 'Critical', entities: ['vendor:V105', 'employee:E107'], amount: 593550, fields: ['bank_account', 'pan', 'phone', 'address'], title: 'Vendor Sai Traders ↔ employee E107 (Accounts Payable): same bank account, PAN, phone number and address' },
  { rule: 'R1 Employee-as-Vendor / Ghost Vendor', severity: 'Critical', entities: ['vendor:V110', 'employee:E107'], amount: 135500, fields: ['pan'], title: 'Vendor Shri Sai Trading Co ↔ employee E107 (Accounts Payable): same PAN' },
  { rule: 'R2 Undisclosed Related Party', severity: 'High', entities: ['vendor:V108', 'director:DIN07654321'], amount: 1109581, fields: ['phone', 'address'], title: 'Vendor Om Enterprises ↔ director Mrs. Sunita Mehta: same phone number and address' },
  { rule: 'R2 Undisclosed Related Party', severity: 'High', entities: ['vendor:V108', 'director:DIN01234567'], amount: 1109581, fields: ['address'], title: 'Vendor Om Enterprises ↔ director Mr. Prakash Mehta: same address' },
  { rule: 'R3 Possible Conflict of Interest', severity: 'High', entities: ['vendor:V111', 'employee:E104'], amount: 1102680, fields: ['phone'], title: 'Vendor Kumar Hardware & Tools ↔ employee E104 (Stores): same phone number' },
  { rule: 'R9 Segregation-of-Duties Breach', severity: 'High', entities: ['vendor:V108', 'employee:E102'], amount: 757000, title: 'E102 created vendor Om Enterprises AND approved 2 of its payments' },
  { rule: 'R4 Duplicate / Shell Vendors', severity: 'High', entities: ['vendor:V105', 'vendor:V110'], amount: 729050, fields: ['pan'], title: 'Vendors Sai Traders and Shri Sai Trading Co: same PAN' },
  { rule: 'R9 Segregation-of-Duties Breach', severity: 'High', entities: ['vendor:V105', 'employee:E107'], amount: 593550, title: 'E107 created vendor Sai Traders AND approved 6 of its payments' },
  { rule: 'R7 Split Payment', severity: 'High', entities: ['vendor:V109'], amount: 163000, payments: ['P0081', 'P0082', 'P0083'], title: '3 payments to Quick Fix Maintenance within 3 days total ₹1,63,000 (limit ₹1,00,000)' },
  { rule: 'R6 Duplicate Payment', severity: 'High', entities: ['vendor:V102'], amount: 132450, payments: ['P0084', 'P0085'], title: 'Invoice SP-2207 of Sahyadri Packaging paid twice (P0084 and P0085)' },
  { rule: 'R9 Segregation-of-Duties Breach', severity: 'High', entities: ['vendor:V110', 'employee:E107'], amount: 64000, title: 'E107 created vendor Shri Sai Trading Co AND approved 1 of its payments' },
  { rule: 'R5 Ghost Employee (Payroll)', severity: 'High', entities: ['employee:E109', 'employee:E110'], amount: 0, fields: ['bank_account', 'address'], title: 'Employees E109 (Production) and E110 (Production): salary to the same bank account' },
  { rule: 'R8 Just-Below-Limit Pattern', severity: 'Medium', entities: ['vendor:V105'], amount: 593550, payments: ['P0071', 'P0072', 'P0073', 'P0074', 'P0075', 'P0076'], title: '6 payments to Sai Traders are just below the approval limit' },
  { rule: 'R10 Weekend Round-Amount Payment', severity: 'Low', entities: ['vendor:V106'], amount: 150000, payments: ['P0086'], title: 'P0086: ₹1,50,000 to Pune Office Supplies on a Sunday' },
];

describe('legacy VendorShield — hashing primitives', () => {
  const inputs = ['', 'abc', 'x'.repeat(200), 'ಪುಣೆ ₹'];
  it.each(inputs)('SHA-256 matches node:crypto for %j', (s) => {
    expect(GV.sha256Hex(s)).toBe(createHash('sha256').update(s).digest('hex'));
  });
  it.each(inputs)('HMAC-SHA256 matches node:crypto for %j (short and >64-byte keys)', (s) => {
    const long = 'k'.repeat(70);
    expect(GV.hmacHex('secretkey1', s)).toBe(createHmac('sha256', 'secretkey1').update(s).digest('hex'));
    expect(GV.hmacHex(long, s)).toBe(createHmac('sha256', long).update(s).digest('hex'));
  });
});

describe('legacy VendorShield — normalisation on ASCII input', () => {
  it('reduces differently punctuated Latin addresses to the same string', () => {
    const a = GV.normalize('address', 'Flat No. 12, Ganesh Society, M.G. Rd., Pune');
    const b = GV.normalize('address', 'Flat 12 Ganesh Society MG Road Pune');
    expect(a).toBe('12 ganesh society mg road pune');
    expect(b).toBe(a);
  });
  it('keeps the last ten digits of a phone number and upper-cases PAN/GSTIN', () => {
    expect(GV.normalize('phone', '+91 98220 11104')).toBe('9822011104');
    expect(GV.normalize('pan', ' drsps5532h ')).toBe('DRSPS5532H');
    expect(GV.normalize('gstin', '27aabcd1234e1z8')).toBe('27AABCD1234E1Z8');
  });
  it('returns an empty string for missing values', () => {
    expect(GV.normalize('pan', undefined)).toBe('');
    expect(GV.normalize('address', '   ')).toBe('');
  });
});

describe('legacy VendorShield — synthetic sample', () => {
  const data = GV.sampleData();

  it('contains 10 employees, 12 vendors, 3 directors and 86 payments', () => {
    expect(TABLES.map((t) => data[t].length)).toEqual([10, 12, 3, 86]);
  });

  it('sample_data/*.csv is the same dataset as the built-in sample', () => {
    for (const t of TABLES) {
      const fromCsv = GV.parseCSV(legacyText('sample_data', `${t}.csv`));
      const builtIn = plain(data[t]).map((row) =>
        Object.fromEntries(Object.entries(row).map(([k, v]) => [k, String(v)])),
      );
      expect(plain(fromCsv), t).toEqual(builtIn);
    }
  });

  it('toCSV → parseCSV round-trips the vendor master', () => {
    expect(plain(GV.parseCSV(GV.toCSV(data.vendors)))).toEqual(plain(data.vendors));
  });

  it('total paid is INR 11,033,700', () => {
    expect(data.payments.reduce((s, p) => s + p.amount, 0)).toBe(11_033_700);
  });
});

describe('legacy VendorShield — protection of the declared sensitive fields', () => {
  const data = GV.sampleData();
  const prot = GV.protect(data, KEY);

  it('replaces each non-empty declared sensitive field with an H:<16 hex> token', () => {
    for (const t of ['employees', 'vendors', 'directors'] as const) {
      prot[t].forEach((row, i) => {
        for (const f of GV.SENSITIVE[t]) {
          if (!(f in row)) continue;
          const raw = data[t][i]?.[f];
          if (raw) expect(row[f], `${t}[${i}].${f}`).toMatch(/^H:[0-9a-f]{16}$/);
          else expect(row[f]).toBe('');
        }
      });
    }
  });

  it('the legacy leak test passes: none of the 120 declared sensitive values appear in the output', () => {
    // Scope note: this only searches for values in GV.SENSITIVE columns. See the known-issue suite
    // for what it does not cover (names, DINs, references, unknown columns).
    const blob = JSON.stringify(prot);
    let total = 0;
    let leaked = 0;
    for (const t of ['employees', 'vendors', 'directors'] as const) {
      for (const row of data[t]) {
        for (const f of GV.SENSITIVE[t]) {
          if (!row[f]) continue;
          total++;
          if (blob.includes(String(row[f]))) leaked++;
        }
      }
    }
    expect({ total, leaked }).toEqual({ total: 120, leaked: 0 });
  });

  it('rejects a key shorter than 8 characters', () => {
    expect(() => GV.protect(data, 'short')).toThrow('Secret key must be at least 8 characters');
  });
});

describe('legacy VendorShield — analysis of the protected sample', () => {
  const data = GV.sampleData();
  const result = GV.analyze(GV.protect(data, KEY));

  it('summary matches the recorded baseline', () => {
    expect(plain(result.summary)).toEqual({
      employees: 10,
      vendors: 12,
      directors: 3,
      payments: 86,
      totalPaid: 11_033_700,
      flags: 14,
      critical: 2,
      high: 10,
      amountAtRisk: 5_116_715,
      riskyVendors: 6,
    });
  });

  it('produces exactly the 14 golden findings with their entities, amounts and payment references', () => {
    expect(plain(result.flags.map(project))).toEqual(EXPECTED_FLAGS);
  });

  it('fires each rule R1–R10 the expected number of times', () => {
    const perRule: Record<string, number> = {};
    for (const f of result.flags) {
      const id = f.rule.split(' ')[0] ?? '';
      perRule[id] = (perRule[id] ?? 0) + 1;
    }
    expect(perRule).toEqual({ R1: 2, R2: 2, R3: 1, R4: 1, R5: 1, R6: 1, R7: 1, R8: 1, R9: 3, R10: 1 });
  });

  it('heuristic vendor scores are the capped severity-weight sums', () => {
    expect(plain(result.vendorRisk)).toEqual({
      'vendor:V105': 100,
      'vendor:V110': 90,
      'vendor:V108': 75,
      'vendor:V111': 25,
      'vendor:V102': 25,
      'vendor:V109': 25,
      'vendor:V106': 5,
    });
  });

  it('relationship graph has 20 nodes and 23 edges', () => {
    expect(result.graph.nodes).toHaveLength(20);
    expect(result.graph.edges).toHaveLength(23);
  });

  it('findings do not depend on the key (tokens differ, matches do not)', () => {
    const other = GV.analyze(GV.protect(data, 'AnotherKey#999'));
    expect(plain(other.flags.map(project))).toEqual(EXPECTED_FLAGS);
    expect(GV.protect(data, 'AnotherKey#999').vendors[0]?.pan).not.toBe(GV.protect(data, KEY).vendors[0]?.pan);
  });

  it('the CSV sample files give the same findings as the built-in sample', () => {
    const csv = Object.fromEntries(TABLES.map((t) => [t, GV.parseCSV(legacyText('sample_data', `${t}.csv`))]));
    const fromCsv = GV.analyze(GV.protect(csv, KEY));
    expect(plain(fromCsv.summary)).toEqual(plain(result.summary));
    expect(plain(fromCsv.flags.map(project))).toEqual(EXPECTED_FLAGS);
  });
});

describe('legacy VendorShield — what the monetary figures actually measure', () => {
  const data = GV.sampleData();
  const result = GV.analyze(GV.protect(data, KEY));
  const paidTo = (vendorId: string) =>
    data.payments.filter((p) => p.vendor_id === vendorId).reduce((s, p) => s + p.amount, 0);

  it('"amountAtRisk" = ALL payments to the six vendors having any Critical/High finding', () => {
    const vendors = ['V102', 'V105', 'V108', 'V109', 'V110', 'V111'];
    expect(vendors.map(paidTo).reduce((a, b) => a + b, 0)).toBe(5_116_715);
    expect(result.summary.amountAtRisk).toBe(5_116_715);
    expect(result.summary.riskyVendors).toBe(vendors.length);
    // It is vendor-wide spend under review, not an established loss: 46% of all sample payments.
    expect(result.summary.amountAtRisk / result.summary.totalPaid).toBeCloseTo(0.4637, 4);
  });

  it('per-finding amounts overlap, so their sum (INR 7,233,492) is not a meaningful total', () => {
    expect(result.flags.reduce((s, f) => s + f.amount, 0)).toBe(7_233_492);
  });

  it('only 12 distinct payments (INR 1,171,450) are referenced as payment-level evidence', () => {
    const ids = new Set(result.flags.flatMap((f) => f.payments ?? []));
    expect(ids.size).toBe(12);
    expect(data.payments.filter((p) => ids.has(String(p.payment_id))).reduce((s, p) => s + p.amount, 0)).toBe(1_171_450);
  });
});
