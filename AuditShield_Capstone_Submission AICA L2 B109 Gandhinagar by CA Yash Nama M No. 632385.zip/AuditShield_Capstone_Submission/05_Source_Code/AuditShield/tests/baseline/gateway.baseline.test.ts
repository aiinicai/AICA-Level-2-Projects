/**
 * BASELINE — legacy CA-Safe AI Gateway core (legacy/ai_gateway/core.js).
 *
 * Replaces the console-only checks in legacy/tests/test_ag.js with assertions. The built-in
 * evaluation set has 18 sentences and 22 labelled identifiers. It is far too small to support any
 * real-world accuracy statement; a larger held-out corpus is a Phase 5/6 deliverable.
 */
import { describe, expect, it } from 'vitest';
import { type LegacyAG, loadLegacyCore, plain } from '../helpers/legacy';

const AG = loadLegacyCore<LegacyAG>('ai_gateway');

describe('legacy Gateway — checksum helpers', () => {
  it('Verhoeff accepts the sample Aadhaar and rejects a one-digit change', () => {
    expect(AG.verhoeff.valid('734152980167')).toBe(true);
    expect(AG.verhoeff.valid('734152980168')).toBe(false);
  });
  it('GSTIN check digit helper accepts a valid GSTIN and rejects a wrong check digit', () => {
    expect(AG.gstinValid('27AAKCS4321M1Z1')).toBe(true);
    expect(AG.gstinValid('27AAKCS4321M1Z9')).toBe(false);
  });
  it('Luhn accepts the standard test card and rejects a one-digit change', () => {
    expect(AG.luhn('4111 1111 1111 1111')).toBe(true);
    expect(AG.luhn('4111 1111 1111 1112')).toBe(false);
  });
});

describe('legacy Gateway — built-in evaluation set', () => {
  const e = AG.evaluate();

  it('has 18 sentences carrying 22 labelled identifiers', () => {
    expect(AG.EVAL).toHaveLength(18);
    expect(AG.EVAL.reduce((n, [, expected]) => n + expected.length, 0)).toBe(22);
  });

  it('scores 21 true positives, 1 false negative, 0 false positives', () => {
    expect({ tp: e.tp, fn: e.fn, fp: e.fp }).toEqual({ tp: 21, fn: 1, fp: 0 });
    expect(e.recall).toBeCloseTo(21 / 22, 10);
    expect(e.precision).toBe(1);
  });

  it('per-type counts match the recorded baseline', () => {
    expect(plain(e.per)).toEqual({
      PAN: { tp: 2, fp: 0, fn: 0 },
      ORG: { tp: 3, fp: 0, fn: 0 },
      PERSON: { tp: 6, fp: 0, fn: 1 },
      PHONE: { tp: 3, fp: 0, fn: 0 },
      EMAIL: { tp: 1, fp: 0, fn: 0 },
      BANK_AC: { tp: 2, fp: 0, fn: 0 },
      IFSC: { tp: 1, fp: 0, fn: 0 },
      UPI: { tp: 1, fp: 0, fn: 0 },
      GSTIN: { tp: 1, fp: 0, fn: 0 },
      CARD: { tp: 1, fp: 0, fn: 0 },
    });
  });

  it('the single miss is the lowercase untitled name', () => {
    const misses = e.rows.filter((r) => r.miss.length || r.extra.length);
    expect(plain(misses.map((r) => ({ text: r.text, miss: r.miss, extra: r.extra })))).toEqual([
      { text: 'the director ramesh gupta approved it', miss: ['PERSON|ramesh gupta'], extra: [] },
    ]);
  });
});

describe('legacy Gateway — the three sample prompts', () => {
  const EXPECTED: Record<string, [string, string][]> = {
    'GST notice reply': [
      ['ORG', 'Shubham Textiles Pvt Ltd'],
      ['GSTIN', '27AAKCS4321M1Z1'],
      ['PAN', 'AAKCS4321M'],
      ['PERSON', 'Rajesh Kulkarni'],
      ['PHONE', '+91 98201 45678'],
      ['EMAIL', 'rajesh.k@shubhamtextiles.in'],
      ['ORG', 'Mahalaxmi Traders'],
      ['GSTIN', '27ABHFM7788K1ZD'],
      ['ORG', 'Mahalaxmi Traders'],
      ['BANK_AC', '50200012345678'],
      ['IFSC', 'HDFC0001234'],
    ],
    'Vendor ledger review': [
      ['ORG', 'Sai Enterprises'],
      ['PAN', 'AFZPS1234Q'],
      ['BANK_AC', '60112233445566'],
      ['IFSC', 'SBIN0004567'],
      ['UPI', 'saient@okaxis'],
      ['PERSON', 'Rohit Shinde'],
      ['PHONE', '9822011107'],
      ['PERSON', 'Rohit Shinde'],
      ['PERSON', 'Rohit Shinde'],
      ['PERSON', 'Anita Deshpande'],
    ],
    'Payroll / KYC query': [
      ['PERSON', 'Priya Nair'],
      ['AADHAAR', '7341 5298 0167'],
      ['PAN', 'BQNPN6655K'],
      ['BANK_AC', '001101556677'],
      ['IFSC', 'ICIC0000011'],
      ['PERSON', 'Priya Nair'],
      ['CARD', '4111 1111 1111 1111'],
    ],
  };

  it('ships exactly these three samples', () => {
    expect(Object.keys(AG.SAMPLES)).toEqual(Object.keys(EXPECTED));
  });

  describe.each(Object.keys(EXPECTED))('%s', (name) => {
    const text = AG.SAMPLES[name] ?? '';
    const vault = new AG.Vault();
    const masked = AG.mask(text, vault, {});

    it('detects the expected identifiers in order', () => {
      expect(plain(masked.detections.map((d) => [d.type, d.value]))).toEqual(EXPECTED[name]);
    });

    it('none of the detected values remain in the masked text', () => {
      for (const d of masked.detections) expect(masked.masked).not.toContain(d.value);
    });

    it('the same value always receives the same token', () => {
      const byValue = new Map<string, Set<string>>();
      for (const s of masked.spans) {
        const key = `${s.type}|${s.value}`;
        byValue.set(key, (byValue.get(key) ?? new Set()).add(s.token));
      }
      for (const tokens of byValue.values()) expect(tokens.size).toBe(1);
    });

    it('the legacy leak check reports nothing', () => {
      const lc = AG.leakCheck(masked.masked, vault, {});
      expect(lc.leaks).toHaveLength(0);
      expect(lc.redetect).toHaveLength(0);
    });

    it('unmask restores the original text exactly', () => {
      expect(AG.unmask(masked.masked, vault)).toBe(text);
    });

    it('the offline demo reply is built from the masked prompt and contains no vault value', () => {
      const reply = AG.mockAI(masked.masked);
      for (const value of Object.values(vault.rev)) expect(reply).not.toContain(value);
      expect(reply).toMatch(/\[[A-Z_]+_\d+\]/);
    });
  });
});

describe('legacy Gateway — detection behaviours worth preserving', () => {
  const types = (text: string, watchlist?: string[]) =>
    plain(AG.detect(text, { watchlist }).map((d) => [d.type, d.value]));

  it('masks a GSTIN-shaped value even when its check digit is wrong', () => {
    // Desired: a mistyped GSTIN is still sensitive. What is missing is a validity/confidence field.
    expect(types('GSTIN 27AAKCS4321M1Z9 on invoice')).toEqual([['GSTIN', '27AAKCS4321M1Z9']]);
  });
  it('detects lowercase PAN', () => {
    expect(types('pan abcpk1234d on record')).toEqual([['PAN', 'abcpk1234d']]);
  });
  it('keeps leading zeros of a bank account inside the vault value', () => {
    const vault = new AG.Vault();
    const m = AG.mask('A/c 00123456789 credited', vault, {});
    expect(m.masked).toBe('A/c [BANK_AC_1] credited');
    expect(vault.rev['[BANK_AC_1]']).toBe('00123456789');
  });
  it('honours a watch-list term', () => {
    expect(types('Project Falcon budget for Zenith Corp', ['Project Falcon'])).toEqual([['CUSTOM', 'Project Falcon']]);
  });
  it('does not flag invoice numbers, turnover figures or section references', () => {
    expect(types('Invoice INV-2026-00981 dated 05-04-2026 for Rs 45,000')).toEqual([]);
    expect(types('Total turnover 4,82,35,000 for FY 2025-26')).toEqual([]);
    expect(types('Section 194C TDS at 2% on Rs. 3,40,000')).toEqual([]);
  });
});
