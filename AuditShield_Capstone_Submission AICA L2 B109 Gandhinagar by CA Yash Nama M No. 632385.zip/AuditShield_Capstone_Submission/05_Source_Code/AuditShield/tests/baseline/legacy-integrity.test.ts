import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join, relative } from 'node:path';
import { describe, expect, it } from 'vitest';
import manifest from '../fixtures/baseline/legacy-manifest.json' with { type: 'json' };
import { LEGACY_ROOT } from '../helpers/legacy';

function walk(dir: string): string[] {
  return readdirSync(dir)
    .sort()
    .flatMap((name) => {
      const p = join(dir, name);
      return statSync(p).isDirectory() ? walk(p) : [p];
    });
}
const sha256 = (path: string) => createHash('sha256').update(readFileSync(path)).digest('hex');

describe('legacy reference stays unchanged', () => {
  it('every legacy file matches the SHA-256 digest recorded in Phase 0', () => {
    const current = Object.fromEntries(
      walk(LEGACY_ROOT).map((p) => [relative(LEGACY_ROOT, p).split('\\').join('/'), sha256(p)]),
    );
    expect(current).toEqual(manifest.files);
    expect(Object.keys(current)).toHaveLength(23);
  });

  it('the built HTML apps are what build.py produces from template + core + ui', () => {
    // build.py inlines core.js and ui.js into template.html (with one guarded module.exports line).
    for (const [folder, out] of [
      ['ghost_vendor', 'VendorShield_GhostVendorDetector.html'],
      ['ai_gateway', 'CA_Safe_AI_Gateway.html'],
    ] as const) {
      const read = (name: string) => readFileSync(join(LEGACY_ROOT, folder, name), 'utf8');
      const core = read('core.js').replace(
        "if (typeof module !== 'undefined') module.exports",
        "if (typeof module !== 'undefined' && module.exports) module.exports",
      );
      // Function replacers: the sources contain `$&`, which a string replacement would expand.
      const rebuilt = read('template.html')
        .replace('/*__CORE__*/', () => core)
        .replace('/*__UI__*/', () => read('ui.js'));
      expect(rebuilt, out).toBe(readFileSync(join(LEGACY_ROOT, 'dist', out), 'utf8'));
    }
  });
});
