/**
 * Gateway in a real browser after the move to persistent storage: the flow still works, makes no
 * network request, records metadata only, and writes no prompt, answer or vault value to the
 * database. Lock and reload both clear the draft.
 */
import { expect, type Page, test } from '@playwright/test';

const PASSPHRASE = 'e2e passphrase 2026';
const ORIGIN = 'http://127.0.0.1:4173';

/** Every record of every object store, as text: what is actually at rest in this profile. */
async function databaseText(page: Page): Promise<string> {
  return page.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((resolve, reject) => {
      const request = indexedDB.open('auditshield');
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const parts: string[] = [];
    for (const name of Array.from(db.objectStoreNames)) {
      const rows = await new Promise<unknown[]>((resolve, reject) => {
        const request = db.transaction(name, 'readonly').objectStore(name).getAll();
        request.onsuccess = () => resolve(request.result as unknown[]);
        request.onerror = () => reject(request.error);
      });
      parts.push(JSON.stringify(rows, (_k, v: unknown) => (v instanceof Uint8Array ? String.fromCharCode(...v.subarray(0, 4096)) : v)));
    }
    db.close();
    return parts.join('\n');
  });
}

test('gateway: answer, timed reveal, metadata-only activity, nothing sensitive stored', async ({ page }) => {
  const offOrigin: string[] = [];
  page.on('request', (r) => !r.url().startsWith(ORIGIN) && !r.url().startsWith('data:') && offOrigin.push(r.url()));
  page.on('dialog', (d) => void d.accept());

  await page.goto('/');
  await page.getByLabel('Passphrase (at least 10 characters)').fill(PASSPHRASE);
  await page.getByLabel('Repeat the passphrase').fill(PASSPHRASE);
  await page.getByRole('button', { name: 'Create workspace' }).click();
  await page.getByRole('button', { name: 'Create sample engagement' }).click();
  await expect(page.getByLabel('Engagement', { exact: true })).toContainText('Mehta Industries');

  await page.getByRole('link', { name: 'AI Gateway' }).click();
  await page.getByRole('button', { name: 'Vendor ledger review' }).click();
  await page.getByRole('button', { name: 'Scan and mask' }).click();
  await expect(page.getByText('10 occurrences replaced by 8 codes')).toBeVisible();
  await page.getByRole('button', { name: /Send to: Offline demo/ }).click();
  await expect(page.getByRole('heading', { name: '3. Answer' })).toBeVisible();

  // The answer starts masked; reveal shows values and is noted in Activity.
  const answer = page.locator('section', { has: page.getByRole('heading', { name: '3. Answer' }) });
  await expect(answer).not.toContainText('Rohit Shinde');
  await answer.getByRole('checkbox', { name: /Show real values on this screen/ }).check();
  await expect(answer).toContainText('Rohit Shinde');

  // A blocked request never reaches a provider and is recorded as blocked... by not being sendable.
  await page.getByLabel(/Text for the AI/).fill('Who is [PERSON_1_ZZZZ]? PAN ABCPK1234D belongs to ramesh gupta.');
  await page.getByRole('button', { name: 'Scan and mask' }).click();
  await expect(page.getByText('Automatic checks found nothing in scope')).toBeVisible();
  await expect(page.getByText('ramesh gupta').first()).toBeVisible(); // still readable: the user must mask it
  await page.getByLabel(/Something still readable/).fill('ramesh gupta');
  await page.getByRole('button', { name: 'Mask and rescan' }).click();
  await expect(page.getByText(/\[MANUAL_1_[A-Z0-9]{4}\]/).first()).toBeVisible();

  await page.getByRole('link', { name: 'Activity' }).click();
  await expect(page.getByRole('cell', { name: 'Gateway request answered' })).toBeVisible();
  await expect(page.getByRole('cell', { name: 'Gateway values revealed on screen' })).toBeVisible();
  const activity = await page.locator('table').innerText();
  for (const secret of ['Rohit Shinde', 'AFZPS1234Q', '9822011107', 'ramesh gupta', 'ABCPK1234D']) expect(activity).not.toContain(secret);

  const stored = await databaseText(page);
  expect(stored).toContain('Gateway request answered');
  for (const secret of ['Rohit Shinde', 'Anita Deshpande', 'AFZPS1234Q', '60112233445566', 'saient@okaxis', 'ramesh gupta', 'ABCPK1234D', 'Mehta Industries', PASSPHRASE]) {
    expect(stored, secret).not.toContain(secret);
  }

  // Lock clears the draft from memory.
  await page.getByRole('link', { name: 'AI Gateway' }).click();
  await expect(page.getByLabel(/Text for the AI/)).toHaveValue(/ramesh gupta/);
  await page.getByRole('button', { name: 'Lock' }).click();
  await page.getByLabel('Passphrase', { exact: true }).fill(PASSPHRASE);
  await page.getByRole('button', { name: 'Unlock' }).click();
  await page.getByRole('link', { name: 'AI Gateway' }).click();
  await expect(page.getByLabel(/Text for the AI/)).toHaveValue('');

  expect(offOrigin).toEqual([]);
});
