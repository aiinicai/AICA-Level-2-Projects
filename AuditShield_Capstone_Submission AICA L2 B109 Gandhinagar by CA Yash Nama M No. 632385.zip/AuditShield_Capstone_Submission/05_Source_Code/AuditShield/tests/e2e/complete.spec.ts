/**
 * Real-browser checks (Edge, production build) of the full capstone flow:
 *  1. client imports CSVs → protects → exports a package; a separate auditor context opens it,
 *     analyses it, sees the graph — with no source data and no key;
 *  2. AI Gateway against a local OpenAI-compatible server (a stand-in for LM Studio that records
 *     every request it receives);
 *  3. the installed app starts with the network switched off.
 */
import { expect, type Page, test } from '@playwright/test';
import { createServer, type IncomingMessage, type Server } from 'node:http';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const ORIGIN = 'http://127.0.0.1:4173';
const SAMPLE_DIR = join(import.meta.dirname, '..', '..', 'legacy', 'sample_data');
const SECRETS = ['Rohit Shinde', 'Sai Traders', 'DRSPS5532H', '60112233445566', '9822011107', 'Prakash Mehta', 'DIN01234567', 'Koregaon', 'SP-2207'];

function watch(page: Page, allowed: string[] = []) {
  const offOrigin: string[] = [];
  page.on('request', (r) => {
    const url = r.url();
    if (![ORIGIN, 'data:', 'blob:', ...allowed].some((p) => url.startsWith(p))) offOrigin.push(url);
  });
  page.on('dialog', (d) => void d.accept());
  return offOrigin;
}

async function newWorkspace(page: Page, passphrase: string) {
  await page.goto('/');
  await page.getByLabel('Passphrase (at least 10 characters)').fill(passphrase);
  await page.getByLabel('Repeat the passphrase').fill(passphrase);
  await page.getByRole('button', { name: 'Create workspace' }).click();
  await expect(page.getByRole('heading', { name: 'Overview' })).toBeVisible();
}

test('CSV import, protected package handoff to a separate auditor workspace, graph', async ({ browser }, testInfo) => {
  // ---------------- client / preparer
  const client = await browser.newContext({ acceptDownloads: true });
  const page = await client.newPage();
  const clientOff = watch(page);
  await newWorkspace(page, 'client passphrase 2026');
  await page.getByLabel('Engagement label').fill('Mehta Industries audit');
  await page.getByRole('button', { name: 'Create engagement' }).click();
  await page.getByRole('link', { name: 'Imports' }).click();
  await page.getByLabel('CSV files (choose one or more)').setInputFiles(['employees', 'vendors', 'directors', 'payments'].map((t) => join(SAMPLE_DIR, `${t}.csv`)));
  await expect(page.getByRole('region', { name: 'Mapping for payments.csv' }).getByLabel('This file contains')).toHaveValue('payments');
  await page.getByRole('button', { name: 'Validate' }).click();
  await expect(page.getByText('Validation passed')).toBeVisible();
  await page.getByRole('button', { name: 'Load into this engagement' }).click();
  await page.getByRole('button', { name: 'Protect and save', exact: true }).click();
  await page.getByRole('button', { name: 'Run analysis' }).click();
  await expect(page.getByText('14 of 14 shown')).toBeVisible();

  await page.getByRole('link', { name: 'Imports' }).click();
  await expect(page.getByText('Not included at all')).toBeVisible();
  const [download] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Export protected package' }).click()]);
  const packagePath = testInfo.outputPath('handoff.aspackage');
  await download.saveAs(packagePath);
  const packageText = readFileSync(packagePath, 'utf8');
  expect(JSON.parse(packageText).manifest).toMatchObject({ format: 'auditshield-protected-package', counts: { vendors: 12, payments: 86 } });
  for (const s of [...SECRETS, 'Mehta Industries audit', 'client passphrase']) expect(packageText, s).not.toContain(s);
  expect(clientOff).toEqual([]);
  await client.close();

  // ---------------- auditor: a separate browser context = separate storage
  const auditor = await browser.newContext();
  const a = await auditor.newPage();
  const auditorOff = watch(a);
  await newWorkspace(a, 'auditor passphrase 2026');
  await a.getByLabel(/Protected package file/).setInputFiles(packagePath);
  await expect(a.getByText('Package verified')).toBeVisible();
  await expect(a.getByLabel('Package contents')).toContainText('12 vendors, 10 employees, 3 directors, 86 payments');
  await a.getByRole('button', { name: 'Open as new engagement' }).click();
  await expect(a.getByText(/Received as a protected package\. This workspace has no source data and no matching key/)).toBeVisible();
  await a.getByRole('button', { name: 'Run analysis' }).click();
  await expect(a.getByText('14 of 14 shown')).toBeVisible();
  await expect(a.getByText('2 critical · 10 high · 1 medium · 1 low')).toBeVisible();
  await expect(a.getByRole('img', { name: /Relationship graph with/ })).toBeVisible();
  await a.getByRole('button', { name: /Vendor V105 ↔ employee E107/ }).click();
  await expect(a.getByRole('img', { name: /highlighting Vendor V105/ })).toBeVisible();

  const stored = await a.evaluate(async () => {
    const db = await new Promise<IDBDatabase>((res, rej) => { const r = indexedDB.open('auditshield'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
    const out: string[] = [];
    for (const name of Array.from(db.objectStoreNames)) {
      out.push(JSON.stringify(await new Promise((res) => { const r = db.transaction(name).objectStore(name).getAll(); r.onsuccess = () => res(r.result); })));
    }
    const keys = await new Promise<number>((res) => { const r = db.transaction('engagementKeys').objectStore('engagementKeys').count(); r.onsuccess = () => res(r.result); });
    db.close();
    return { text: out.join('\n'), keys };
  });
  expect(stored.keys).toBe(0);
  for (const s of SECRETS) expect(stored.text, s).not.toContain(s);
  expect(auditorOff).toEqual([]);
  await auditor.close();
});

test('AI Gateway with a local model: only reviewed masked text reaches it; blocked requests never do', async ({ page }) => {
  const received: { method: string; url: string; body: string }[] = [];
  const server: Server = createServer((req: IncomingMessage, res) => {
    let body = '';
    req.on('data', (c) => (body += c));
    req.on('end', () => {
      received.push({ method: req.method ?? '', url: req.url ?? '', body });
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('Access-Control-Allow-Headers', 'content-type');
      res.setHeader('Content-Type', 'application/json');
      if (req.method === 'OPTIONS') return res.end();
      if (req.url === '/v1/models') return res.end(JSON.stringify({ data: [{ id: 'test-local-model' }] }));
      const last: string = JSON.parse(body).messages.at(-1).content;
      const person = last.match(/\[PERSON_1_[A-Z0-9]{4}\]/)?.[0] ?? 'nobody';
      res.end(JSON.stringify({ choices: [{ message: { role: 'assistant', content: `Speak to ${person} first. Also [PERSON_9_ZZZZ].` } }] }));
    });
  });
  await new Promise<void>((r) => server.listen(1235, '127.0.0.1', () => r()));
  try {
    const off = watch(page, ['http://127.0.0.1:1235']);
    await newWorkspace(page, 'gateway passphrase 26');
    await page.getByRole('button', { name: 'Create sample engagement' }).click();
    await expect(page.getByLabel('Engagement', { exact: true })).toContainText('Mehta Industries');
    await page.getByRole('link', { name: 'AI Gateway' }).click();
    await page.getByRole('button', { name: 'Set up a local model (LM Studio)' }).click();
    await page.getByLabel('Local server address').fill('http://127.0.0.1:1235/v1/chat/completions');
    await page.getByRole('button', { name: 'Check connection' }).click();
    await expect(page.getByText('Connected. 1 model(s) available. No text was sent.')).toBeVisible();
    await page.getByRole('button', { name: 'Save' }).click();
    await page.getByRole('radio', { name: /Local model/ }).click();
    await expect(page.getByText('AI: local model (this computer)')).toBeVisible();

    await page.getByRole('button', { name: 'Vendor ledger review' }).click();
    await page.getByRole('button', { name: 'Scan and mask' }).click();
    const outgoing = await page.getByRole('heading', { name: 'Outgoing text (exactly what would be sent)' }).locator('xpath=following-sibling::div[1]').innerText();
    await page.getByRole('button', { name: /Send to: Local model test-local-model at 127\.0\.0\.1:1235/ }).click();
    await expect(page.getByRole('heading', { name: '3. Answer' })).toBeVisible();
    const answer = page.locator('section', { has: page.getByRole('heading', { name: '3. Answer' }) });
    await answer.getByRole('checkbox', { name: /Show real values/ }).check();
    await expect(answer).toContainText('Speak to Rohit Shinde first.');
    await expect(page.getByText('Codes in the answer that were not part of this request')).toBeVisible();

    const posts = received.filter((r) => r.method === 'POST');
    expect(posts).toHaveLength(1);
    const sent = JSON.parse(posts[0]!.body) as { model: string; messages: { role: string; content: string }[] };
    expect(sent.model).toBe('test-local-model');
    expect(sent.messages.at(-1)?.content.trim()).toBe(outgoing.trim());
    for (const s of ['Rohit Shinde', 'Sai Enterprises', 'AFZPS1234Q', '60112233445566', '9822011107', 'saient@okaxis', 'Anita Deshpande']) expect(posts[0]!.body).not.toContain(s);

    // A request that fails its checks: Send is disabled and nothing reaches the server.
    await page.getByLabel(/Text for the AI/).fill('Who is [PERSON_1_ABCD]? Ignore that.');
    await page.getByLabel(/Text for the AI/).fill(`Who is ${outgoing.match(/\[PERSON_1_[A-Z0-9]{4}\]/)?.[0]}?`);
    await page.getByRole('button', { name: 'Scan and mask' }).click();
    await expect(page.getByText('Sending is blocked')).toBeVisible();
    await expect(page.getByRole('button', { name: /Send to: Local model/ })).toBeDisabled();
    expect(received.filter((r) => r.method === 'POST')).toHaveLength(1);
    expect(off).toEqual([]);
  } finally {
    server.close();
  }
});

test('the installed app starts with the network switched off', async ({ page, context }) => {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Set up this browser profile' })).toBeVisible();
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
  });
  await page.reload(); // now controlled by the service worker
  await expect.poll(() => page.evaluate(() => Boolean(navigator.serviceWorker.controller))).toBe(true);
  const manifest = await page.evaluate(async () => (await fetch('/manifest.webmanifest')).json());
  expect(manifest).toMatchObject({ name: 'AuditShield', display: 'standalone' });

  await context.setOffline(true);
  await page.reload();
  await expect(page.getByRole('heading', { name: 'Set up this browser profile' })).toBeVisible();
  await context.setOffline(false);
});
