/** Captures screenshots of the main screens for visual review (runs only when SHOTS_DIR is set). */
import { expect, test } from '@playwright/test';
import { join } from 'node:path';

const DIR = process.env['SHOTS_DIR'];

test.skip(!DIR, 'set SHOTS_DIR to capture screenshots');

test('capture main screens', async ({ page }) => {
  const dir = DIR as string;
  await page.setViewportSize({ width: 1366, height: 860 });
  page.on('dialog', (d) => void d.accept());
  await page.goto('/');
  await page.getByLabel('Passphrase (at least 10 characters)').fill('screens passphrase 1');
  await page.getByLabel('Repeat the passphrase').fill('screens passphrase 1');
  await page.getByRole('button', { name: 'Create workspace' }).click();
  await page.getByRole('button', { name: 'Create sample engagement' }).click();
  await page.getByRole('link', { name: 'Imports' }).click();
  await page.getByRole('button', { name: 'Load sample data' }).click();
  await page.getByRole('button', { name: 'Continue in VendorShield' }).click();
  await page.getByRole('button', { name: 'Protect and save', exact: true }).click();
  await page.getByRole('button', { name: 'Run analysis' }).click();
  await page.getByRole('button', { name: /Vendor V105 ↔ employee E107 \(Accounts Payable\): same bank/ }).click();
  await expect(page.getByRole('img', { name: /highlighting/ })).toBeVisible();
  await page.screenshot({ path: join(dir, '1-findings.png') });
  await page.getByRole('img', { name: /Relationship graph/ }).scrollIntoViewIfNeeded();
  await page.screenshot({ path: join(dir, '2-graph.png') });
  await page.getByRole('link', { name: 'Imports' }).click();
  await page.getByText('Hand over to the auditor').scrollIntoViewIfNeeded();
  await page.screenshot({ path: join(dir, '3-handoff.png') });
  await page.getByRole('link', { name: 'AI Gateway' }).click();
  await page.getByRole('button', { name: 'Set up a local model (LM Studio)' }).click();
  await page.screenshot({ path: join(dir, '4-gateway.png') });
});
