/**
 * End-to-end persistence in a real browser (Edge), against the production build:
 *   1. set up → sample engagement → protect (with encrypted source copy) → analyse → reload →
 *      unlock → everything still there → lock → back up → restore into a second, empty profile;
 *   2. a full browser restart on a persistent profile directory.
 * Both assert that the page talks to nothing but its own origin.
 */
import { chromium, expect, type Page, test } from '@playwright/test';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const PASSPHRASE = 'e2e passphrase 2026';
const ORIGIN = 'http://127.0.0.1:4173';
const CONCLUSION = 'Second payment P0085 confirmed as a duplicate; recovery requested from the vendor.';

function watch(page: Page) {
  const offOrigin: string[] = [];
  const errors: string[] = [];
  page.on('request', (r) => {
    if (!r.url().startsWith(ORIGIN) && !r.url().startsWith('blob:') && !r.url().startsWith('data:')) offOrigin.push(r.url());
  });
  page.on('console', (m) => m.type() === 'error' && errors.push(m.text()));
  page.on('pageerror', (e) => errors.push(String(e)));
  // Source data in memory triggers the "leave site?" prompt; accept it so reload proceeds.
  page.on('dialog', (d) => void d.accept());
  return { offOrigin, errors };
}

async function createWorkspace(page: Page) {
  await page.goto('/');
  await expect(page.getByRole('heading', { name: 'Set up this browser profile' })).toBeVisible();
  await page.getByLabel('Passphrase (at least 10 characters)').fill(PASSPHRASE);
  await page.getByLabel('Repeat the passphrase').fill(PASSPHRASE);
  await page.getByRole('button', { name: 'Create workspace' }).click();
  await expect(page.getByRole('heading', { name: 'Overview' })).toBeVisible();
}

async function unlock(page: Page, passphrase = PASSPHRASE) {
  await expect(page.getByText('Workspace locked')).toBeVisible();
  await page.getByLabel('Passphrase', { exact: true }).fill(passphrase);
  await page.getByRole('button', { name: 'Unlock' }).click();
}

async function sampleProtectedAndAnalysed(page: Page, keepSource: boolean) {
  await page.getByRole('button', { name: 'Create sample engagement' }).click();
  await expect(page.getByLabel('Engagement', { exact: true })).toContainText('Mehta Industries');
  await page.getByRole('link', { name: 'Imports' }).click();
  await page.getByRole('button', { name: 'Load sample data' }).click();
  await page.getByRole('button', { name: 'Continue in VendorShield' }).click();
  if (keepSource) await page.getByRole('checkbox', { name: /keep an encrypted copy/ }).check();
  await page.getByRole('button', { name: 'Protect and save', exact: true }).click();
  await page.getByRole('button', { name: 'Run analysis' }).click();
  await expectSampleResults(page);
}

async function expectSampleResults(page: Page) {
  await expect(page.getByText('14 of 14 shown')).toBeVisible();
  await expect(page.getByText('2 critical · 10 high · 1 medium · 1 low')).toBeVisible();
  await expect(page.getByText('₹1,10,33,700')).toBeVisible();
  await expect(page.getByText('₹51,16,715')).toBeVisible();
}

test('persist across reload, lock, back up, and restore into a fresh profile', async ({ browser }, testInfo) => {
  const profileA = await browser.newContext({ acceptDownloads: true });
  const page = await profileA.newPage();
  const seen = watch(page);

  await createWorkspace(page);
  await sampleProtectedAndAnalysed(page, true);

  // ---- reload: memory is gone, the database is not
  await page.reload();
  await unlock(page, 'not the passphrase');
  await expect(page.getByText('That passphrase is not correct.')).toBeVisible();
  await unlock(page);
  await expect(page.getByLabel('Engagement', { exact: true })).toContainText('Mehta Industries');
  await page.getByRole('link', { name: 'VendorShield' }).click();
  await expectSampleResults(page);
  await expect(page.getByText('Not in memory.')).toBeVisible();

  // evidence comes from the stored snapshot
  await page.getByRole('button', { name: 'An invoice of V102 paid twice (P0084 and P0085)' }).click();
  await expect(page.getByRole('heading', { name: 'Payment evidence (2)' })).toBeVisible();
  await expect(page.getByRole('cell', { name: 'P0085', exact: true })).toBeVisible();

  // ---- review the finding: a settling decision needs a conclusion; then it is saved
  await page.getByLabel('Status').selectOption('confirmed-issue');
  await page.getByRole('button', { name: 'Save review' }).click();
  await expect(page.getByText(/needs a conclusion of at least 15 characters/)).toBeVisible();
  await page.getByLabel(/^Conclusion/).fill(CONCLUSION);
  await page.getByRole('button', { name: 'Save review' }).click();
  await expect(page.getByText(/Saved: revision 1/)).toBeVisible();

  // saved review survives a reload and appears in the exported workpaper
  await page.reload();
  await unlock(page);
  await page.getByRole('link', { name: 'Workpapers' }).click();
  await expect(page.getByText('1 of 14')).toBeVisible();
  await expect(page.getByRole('cell', { name: CONCLUSION })).toBeVisible();
  const [workpaper] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Export workpaper (HTML)' }).click()]);
  const workpaperPath = testInfo.outputPath('workpaper.html');
  await workpaper.saveAs(workpaperPath);
  const workpaperHtml = readFileSync(workpaperPath, 'utf8');
  expect(workpaperHtml).toContain(CONCLUSION);
  expect(workpaperHtml).toContain('Confirmed issue');
  expect(workpaperHtml.match(/<tr>/g)).toHaveLength(15);

  // the encrypted source copy is there and opens
  await page.getByRole('link', { name: 'Imports' }).click();
  await expect(page.getByText('Encrypted source copy kept')).toBeVisible();
  await page.getByRole('button', { name: 'Open it in this session' }).click();
  await expect(page.getByText('This is the same data as the saved snapshot.')).toBeVisible();

  // ---- manual lock closes the app
  await page.getByRole('button', { name: 'Lock' }).click();
  await expect(page.getByRole('link', { name: 'VendorShield' })).toHaveCount(0);
  await unlock(page);

  // ---- encrypted backup
  await page.getByRole('link', { name: 'Settings' }).click();
  await page.getByLabel('Workspace passphrase').fill(PASSPHRASE);
  await page.getByRole('checkbox', { name: /Include retained source data/ }).check();
  const [download] = await Promise.all([page.waitForEvent('download'), page.getByRole('button', { name: 'Create backup file' }).click()]);
  const backupPath = testInfo.outputPath('workspace.asbackup');
  await download.saveAs(backupPath);
  await expect(page.getByText(/Backup created/)).toBeVisible();
  await expect(page.getByText(/backed up today/)).toBeVisible();

  const file = readFileSync(backupPath, 'utf8');
  expect(JSON.parse(file)).toMatchObject({ format: 'auditshield-backup', formatVersion: 1, includesRetainedSource: true, counts: { engagements: 1, payments: 86, findings: 14, rawPayloads: 1 } });
  for (const secret of ['Mehta Industries', 'Rohit Shinde', 'DRSPS5532H', '60112233445566', PASSPHRASE]) expect(file).not.toContain(secret);

  expect(seen.offOrigin).toEqual([]);
  expect(seen.errors).toEqual([]);
  await profileA.close();

  // ---- a completely separate, empty profile
  const profileB = await browser.newContext();
  const pageB = await profileB.newPage();
  const seenB = watch(pageB);
  await pageB.goto('/');
  await expect(pageB.getByRole('heading', { name: 'Set up this browser profile' })).toBeVisible();
  await pageB.getByLabel('Backup file (.asbackup)').setInputFiles(backupPath);
  await expect(pageB.getByLabel('Backup contents')).toContainText('included (1)');

  await pageB.getByLabel('Backup passphrase').fill('wrong passphrase 123');
  await pageB.getByRole('button', { name: 'Restore backup' }).click();
  await expect(pageB.getByText(/passphrase is wrong or the backup file has been altered.*Nothing was changed/)).toBeVisible();
  await expect(pageB.getByRole('heading', { name: 'Set up this browser profile' })).toBeVisible();

  await pageB.getByLabel('Backup passphrase').fill(PASSPHRASE);
  await pageB.getByRole('button', { name: 'Restore backup' }).click();
  await expect(pageB.getByLabel('Engagement', { exact: true })).toContainText('Mehta Industries');
  await pageB.getByRole('link', { name: 'VendorShield' }).click();
  await expectSampleResults(pageB);
  await pageB.getByRole('link', { name: 'Workpapers' }).click();
  await expect(pageB.getByRole('cell', { name: CONCLUSION })).toBeVisible();
  await pageB.getByRole('link', { name: 'Activity' }).click();
  await expect(pageB.getByRole('cell', { name: 'Workspace restored from backup' })).toBeVisible();
  await expect(pageB.getByRole('cell', { name: 'Finding reviewed' })).toBeVisible();
  await expect(pageB.getByRole('cell', { name: 'Analysis run' })).toBeVisible();

  // the restored profile survives its own reload
  await pageB.reload();
  await unlock(pageB);
  await pageB.getByRole('link', { name: 'VendorShield' }).click();
  await expectSampleResults(pageB);
  expect(seenB.offOrigin).toEqual([]);
  expect(seenB.errors).toEqual([]);
  await profileB.close();
});

test('data survives a full browser restart on the same profile directory', async () => {
  const userDataDir = mkdtempSync(join(tmpdir(), 'auditshield-e2e-'));
  const launch = () => chromium.launchPersistentContext(userDataDir, { channel: 'msedge', baseURL: ORIGIN });

  const first = await launch();
  const page = first.pages()[0] ?? (await first.newPage());
  watch(page);
  await createWorkspace(page);
  await sampleProtectedAndAnalysed(page, false);
  await first.close(); // the browser process exits

  const second = await launch();
  const again = second.pages()[0] ?? (await second.newPage());
  const seen = watch(again);
  await again.goto('/');
  await unlock(again);
  await again.getByRole('link', { name: 'VendorShield' }).click();
  await expectSampleResults(again);
  // Source was not retained: after a restart it is simply not there.
  await again.getByRole('link', { name: 'Imports' }).click();
  await expect(again.getByText('No copy of the source data is stored.')).toBeVisible();
  expect(seen.offOrigin).toEqual([]);
  expect(seen.errors).toEqual([]);
  await second.close();
});
