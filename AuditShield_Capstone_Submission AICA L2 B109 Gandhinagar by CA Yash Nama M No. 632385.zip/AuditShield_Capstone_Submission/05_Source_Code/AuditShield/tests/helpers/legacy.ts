/**
 * Loaders for the frozen legacy reference in ./legacy.
 *
 * The legacy sources are never edited or transformed. They are executed in an isolated
 * node:vm context, the same way the built single-file HTML apps inline them, so these tests
 * describe what the shipped capstone actually does.
 */
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

export const LEGACY_ROOT = join(dirname(fileURLToPath(import.meta.url)), '..', '..', 'legacy');

export function legacyText(...segments: string[]): string {
  return readFileSync(join(LEGACY_ROOT, ...segments), 'utf8');
}

/** Structured-clone through JSON so values created inside the vm realm compare cleanly. */
export function plain<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}

/* ------------------------------------------------------------------ core modules */

export type LegacyRow = Record<string, unknown>;
export interface LegacyDataset {
  employees?: LegacyRow[];
  vendors?: LegacyRow[];
  directors?: LegacyRow[];
  payments?: LegacyRow[];
}
export type LegacySeverity = 'Critical' | 'High' | 'Medium' | 'Low';
export interface LegacyFlag {
  id: string;
  rule: string;
  severity: LegacySeverity;
  fraud: string;
  title: string;
  explain: string;
  entities: string[];
  amount: number;
  fields?: string[];
  payments?: string[];
}
export interface LegacySummary {
  employees: number;
  vendors: number;
  directors: number;
  payments: number;
  totalPaid: number;
  flags: number;
  critical: number;
  high: number;
  amountAtRisk: number;
  riskyVendors: number;
}
export interface LegacyAnalysis {
  flags: LegacyFlag[];
  vendorRisk: Record<string, number>;
  graph: {
    nodes: { id: string; kind: string; label: string; risk: number; flagged?: boolean; field?: string }[];
    edges: { a: string; b: string; field: string }[];
  };
  summary: LegacySummary;
}
export interface LegacyGV {
  sha256Hex(text: string): string;
  hmacHex(key: string, message: string): string;
  normalize(field: string, value: unknown): string;
  SENSITIVE: Record<'employees' | 'vendors' | 'directors' | 'payments', string[]>;
  MATCH_FIELDS: string[];
  protect(data: LegacyDataset, key: string): Record<keyof LegacyDataset, Record<string, string>[]>;
  analyze(
    protectedData: LegacyDataset,
    opts?: { approvalLimit?: number; nearLimitPct?: number; splitWindowDays?: number },
  ): LegacyAnalysis;
  sampleData(): {
    employees: Record<string, string>[];
    vendors: Record<string, string>[];
    directors: Record<string, string>[];
    payments: (Record<string, string> & { amount: number })[];
  };
  parseCSV(text: string): Record<string, string>[];
  toCSV(rows: LegacyRow[]): string;
  fmtINR(n: unknown): string;
}

export interface LegacyDetection {
  type: string;
  start: number;
  end: number;
  value: string;
  propagated?: boolean;
}
export interface LegacyVault {
  map: Record<string, string>;
  rev: Record<string, string>;
  count: Record<string, number>;
  tokenFor(type: string, value: string): string;
}
export interface LegacyEvalCounts {
  tp: number;
  fp: number;
  fn: number;
}
export interface LegacyAG {
  verhoeff: { valid(num: string): boolean; digit(num: string): number };
  gstinValid(gstin: string): boolean;
  luhn(num: string): boolean;
  TYPES: Record<string, { label: string; risk: string; color: string; pr: number }>;
  detect(text: string, opts?: { watchlist?: string[] }): LegacyDetection[];
  Vault: new () => LegacyVault;
  mask(
    text: string,
    vault: LegacyVault,
    opts?: { watchlist?: string[] },
  ): { masked: string; detections: LegacyDetection[]; spans: { type: string; token: string; value: string }[] };
  unmask(text: string, vault: LegacyVault): string;
  leakCheck(
    masked: string,
    vault: LegacyVault,
    opts?: { watchlist?: string[] },
  ): { leaks: { tok: string; val: string }[]; redetect: LegacyDetection[] };
  mockAI(maskedPrompt: string): string;
  SAMPLES: Record<string, string>;
  EVAL: [string, [string, string][]][];
  evaluate(): LegacyEvalCounts & {
    rows: { text: string; hit: string[]; miss: string[]; extra: string[] }[];
    per: Record<string, LegacyEvalCounts>;
    recall: number;
    precision: number;
  };
}

/** Executes legacy/<folder>/core.js unmodified and returns its CommonJS export. */
export function loadLegacyCore<T>(folder: 'ghost_vendor' | 'ai_gateway'): T {
  const filename = join(LEGACY_ROOT, folder, 'core.js');
  const sandbox = { module: { exports: {} as unknown }, TextEncoder, console };
  vm.runInNewContext(readFileSync(filename, 'utf8'), sandbox, { filename });
  return sandbox.module.exports as T;
}

/* ------------------------------------------------------------------ built HTML apps */

export interface FakeElement {
  id: string;
  value: string;
  innerHTML: string;
  textContent: string;
  checked: boolean;
  disabled: boolean;
  type: string;
  style: Record<string, string>;
  dataset: Record<string, string>;
  // Handlers are assigned by the legacy UI scripts.
  onclick?: (ev?: unknown) => unknown;
  onchange?: (ev?: unknown) => unknown;
  oninput?: (ev?: unknown) => unknown;
  [key: string]: unknown;
}
export interface FakeResponse {
  ok: boolean;
  statusText?: string;
  json(): Promise<unknown>;
}
export interface LegacyApp {
  els: Record<string, FakeElement>;
  alerts: string[];
  confirms: string[];
  downloads: { name: string; text: string }[];
  fetchCalls: { url: string; init: { method?: string; headers?: Record<string, string>; body?: string; signal?: unknown } }[];
  /** Mutable test controls. */
  control: {
    provider: 'mock' | 'api';
    confirmAnswer: boolean;
    fetchImpl: (url: string, init: unknown) => Promise<FakeResponse>;
  };
}

/**
 * Boots a built legacy single-file app (legacy/dist/*.html) against a minimal fake DOM.
 * This is the legacy tests/smoke.js harness made isolated and observable: element defaults are
 * read from the HTML `value="..."` attributes, and downloads, dialogs and fetch calls are recorded.
 * It is not a browser. Real-browser checks arrive with Playwright in later phases.
 */
export function bootLegacyApp(
  file: 'VendorShield_GhostVendorDetector.html' | 'CA_Safe_AI_Gateway.html',
): LegacyApp {
  const html = legacyText('dist', file);
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map((m) => m[1] ?? '');
  const els: Record<string, FakeElement> = {};
  const canvasStub = new Proxy<Record<string, unknown>>(
    {},
    {
      get: (t, p: string) => (p === 'measureText' ? () => ({ width: 50 }) : p in t ? t[p] : () => {}),
      set: (t, p: string, v) => ((t[p] = v), true),
    },
  );
  const make = (id: string): FakeElement => ({
    id,
    value: '',
    innerHTML: '',
    textContent: '',
    checked: false,
    disabled: false,
    type: 'text',
    style: {},
    dataset: {},
    classList: { toggle() {}, add() {}, remove() {}, contains: () => false },
    getContext: () => canvasStub,
    getBoundingClientRect: () => ({ left: 0, top: 0, width: 800, height: 560 }),
    click() {},
  });
  for (const m of html.matchAll(/<[a-z]+\b[^>]*\bid="([^"]+)"[^>]*>/gi)) {
    const el = make(m[1] ?? '');
    const value = /\bvalue="([^"]*)"/.exec(m[0]);
    if (value) el.value = value[1] ?? '';
    if (/\bdisabled\b/.test(m[0])) el.disabled = true;
    els[el.id] = el;
  }

  const app: LegacyApp = {
    els,
    alerts: [],
    confirms: [],
    downloads: [],
    fetchCalls: [],
    control: {
      provider: 'mock',
      confirmAnswer: true,
      fetchImpl: async () => ({
        ok: true,
        json: async () => ({ choices: [{ message: { content: 'stub reply' } }] }),
      }),
    },
  };

  const blobs = new Map<string, string>();
  const sandbox = {
    console,
    TextEncoder,
    window: { addEventListener() {}, devicePixelRatio: 1 },
    document: {
      getElementById: (id: string) => (els[id] ??= make(id)),
      querySelectorAll: () => [],
      querySelector: (selector: string) =>
        selector.includes('name=prov') ? { value: app.control.provider } : { value: '' },
      createElement: () => {
        const a = {
          href: '',
          download: '',
          click() {
            app.downloads.push({ name: a.download, text: blobs.get(a.href) ?? '' });
          },
        };
        return a;
      },
    },
    requestAnimationFrame: () => 1,
    performance: { now: () => Date.now() },
    alert: (message: unknown) => void app.alerts.push(String(message)),
    confirm: (message: unknown) => {
      app.confirms.push(String(message));
      return app.control.confirmAnswer;
    },
    Blob: function (this: { text: string }, parts: unknown[]) {
      this.text = parts.map(String).join('');
    },
    URL: {
      createObjectURL: (blob: { text: string }) => {
        const url = `blob:${blobs.size + 1}`;
        blobs.set(url, blob.text);
        return url;
      },
      revokeObjectURL() {},
    },
    setTimeout: (fn: () => void) => {
      fn();
      return 0;
    },
    fetch: (url: string, init: LegacyApp['fetchCalls'][number]['init']) => {
      app.fetchCalls.push({ url, init });
      return app.control.fetchImpl(url, init);
    },
  };
  const context = vm.createContext(sandbox);
  scripts.forEach((code, i) => vm.runInContext(code, context, { filename: `${file}#script${i}` }));
  return app;
}

export const stripTags = (html: string): string => html.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
