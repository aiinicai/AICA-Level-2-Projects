/**
 * Test "browser profiles": each call creates an independent in-memory IndexedDB (fake-indexeddb),
 * the equivalent of a separate browser profile or origin. Re-opening within one profile models a
 * page reload or browser restart: a new Dexie instance over the same stored data.
 */
import { IDBFactory, IDBKeyRange } from 'fake-indexeddb';
import { type AuditShieldDb, createDb, type DbOptions, openDb } from '../../src/data/db/schema';
import { createRepositories } from '../../src/data/repositories/repositories';
import type { Clock } from '../../src/services/workspace/useCases';

/** PBKDF2 cost for tests. Production uses KDF_V1.iterations; one test measures that separately. */
export const TEST_ITERATIONS = 2_000;
export const PASSPHRASE = 'correct horse battery staple';

export function newProfile() {
  const indexedDB = new IDBFactory();
  const opened: AuditShieldDb[] = [];
  return {
    indexedDB,
    /** Opens the database in this profile (a fresh connection each time). */
    async open(options: Pick<DbOptions, 'maxVersion' | 'beforeUpgradeV2'> = {}) {
      const db = createDb({ indexedDB, IDBKeyRange, ...options });
      const result = await openDb(db);
      opened.push(db);
      return { db, result, repos: createRepositories(db) };
    },
    closeAll() {
      for (const db of opened.splice(0)) db.close();
    },
  };
}

/** Deterministic IDs and a clock that advances one second per reading. */
export function testClock(start = '2026-11-16T09:00:00.000Z'): Clock & { advance(ms: number): void } {
  let n = 0;
  let t = Date.parse(start);
  return {
    id: () => `id-${String(++n).padStart(4, '0')}`,
    now: () => new Date((t += 1000)).toISOString(),
    advance: (ms) => {
      t += ms;
    },
  };
}

/** Every stored record of every store, serialised: what someone reading the database files would see. */
export async function dumpDatabase(db: AuditShieldDb): Promise<string> {
  const parts: string[] = [];
  for (const table of db.tables) {
    const rows = await table.toArray();
    parts.push(JSON.stringify(rows, (_k, v: unknown) => (v instanceof Uint8Array ? `bytes:${Buffer.from(v).toString('latin1')}` : v)));
  }
  return parts.join('\n');
}
