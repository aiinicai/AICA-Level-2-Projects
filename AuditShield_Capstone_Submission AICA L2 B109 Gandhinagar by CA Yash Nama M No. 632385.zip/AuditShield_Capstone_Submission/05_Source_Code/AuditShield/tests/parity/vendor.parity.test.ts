/**
 * PARITY — the TypeScript VendorShield port must reproduce the frozen legacy results on the
 * synthetic sample. Any difference here is either a porting bug or an intentional behaviour
 * change that has to be listed in IMPLEMENTATION_STATUS.md.
 */
import { createHmac } from 'node:crypto';
import { describe, expect, it } from 'vitest';
import { protectDataset } from '../../src/domain/vendor/protect';
import { analyse } from '../../src/domain/vendor/rules';
import { sampleRawDataset } from '../../src/domain/vendor/sample';
import { DEFAULT_RULE_CONFIG, MINIMAL_PROFILE, NAMED_PROFILE, type Finding } from '../../src/domain/vendor/types';
import { createTokeniser, generateEngagementKey, importEngagementKey } from '../../src/services/crypto/tokeniser';
import { type LegacyFlag, type LegacyGV, loadLegacyCore, plain } from '../helpers/legacy';

const GV = loadLegacyCore<LegacyGV>('ghost_vendor');
const legacyData = GV.sampleData();
const legacy = GV.analyze(GV.protect(legacyData, 'ClientSecret#2026'));

async function runNew(profile = NAMED_PROFILE) {
  const key = await generateEngagementKey();
  const outcome = await protectDataset(sampleRawDataset(), { tokenise: createTokeniser(key), keyId: key.keyId, profile });
  return { ...outcome, result: analyse(outcome.data) };
}

const legacyView = (f: LegacyFlag) => ({
  rule: f.rule,
  severity: f.severity,
  entities: f.entities,
  amountPaise: f.amount * 100,
  fields: f.fields ?? [],
  title: f.title,
});
const newView = (f: Finding) => ({
  rule: `${f.ruleId} ${f.ruleName}`,
  severity: f.severity,
  entities: f.entityRefs,
  amountPaise: f.amountPaise,
  fields: f.matchedFields,
  title: f.title,
});

describe('sample data parity', () => {
  it('the typed sample is the legacy sample, record for record', () => {
    const s = sampleRawDataset();
    expect(s.employees.map((e) => [e.id, e.name, e.department, e.bankAccount, e.pan, e.phone, e.address])).toEqual(
      plain(legacyData.employees).map((e) => [e['emp_id'], e['name'], e['department'], e['bank_account'], e['pan'], e['phone'], e['address']]),
    );
    expect(s.vendors.map((v) => [v.id, v.name, v.gstin, v.bankAccount, v.pan, v.phone, v.address, v.createdBy])).toEqual(
      plain(legacyData.vendors).map((v) => [v['vendor_id'], v['vendor_name'], v['gstin'], v['bank_account'], v['pan'], v['phone'], v['address'], v['created_by']]),
    );
    expect(s.directors.map((d) => [d.id, d.name, d.bankAccount, d.pan, d.phone, d.address])).toEqual(
      plain(legacyData.directors).map((d) => [d['din'], d['director_name'], d['bank_account'], d['pan'], d['phone'], d['address']]),
    );
    expect(s.payments.map((p) => [p.id, p.vendorId, p.invoiceNo, p.date, p.amountPaise, p.approvedBy])).toEqual(
      plain(legacyData.payments).map((p) => [p['payment_id'], p['vendor_id'], p['invoice_no'], p['date'], p.amount * 100, p['approved_by']]),
    );
  });
});

describe('rule engine parity on the sample (named profile, so titles are comparable)', () => {
  it('produces the same 14 findings in the same order', async () => {
    const { result } = await runNew();
    expect(result.findings.map(newView)).toEqual(plain(legacy.flags.map(legacyView)));
    expect(result.findings).toHaveLength(14);
  });

  it('payment-level findings cite the same payments as the legacy tool', async () => {
    const { result } = await runNew();
    const cited = (ruleId: string) => result.findings.filter((f) => f.ruleId === ruleId).map((f) => f.paymentIds);
    const legacyCited = (prefix: string) => plain(legacy.flags.filter((f) => f.rule.startsWith(prefix + ' ')).map((f) => f.payments));
    for (const rule of ['R6', 'R7', 'R8', 'R10']) expect(cited(rule), rule).toEqual(legacyCited(rule));
  });

  it('summary figures equal the legacy baseline', async () => {
    const { result } = await runNew();
    const s = result.summary;
    expect({
      employees: s.employees, vendors: s.vendors, directors: s.directors, payments: s.payments,
      totalPaid: s.totalPaidPaise / 100, flags: s.findings, critical: s.bySeverity.Critical, high: s.bySeverity.High,
      amountAtRisk: s.paymentsToVendorsUnderReviewPaise / 100, riskyVendors: s.vendorsUnderReview.length,
    }).toEqual(plain(legacy.summary));
    expect(s.totalPaidPaise).toBe(11_033_700_00);
    expect(s.paymentsToVendorsUnderReviewPaise).toBe(5_116_715_00);
    expect(s.bySeverity).toEqual({ Critical: 2, High: 10, Medium: 1, Low: 1 });
  });

  it('heuristic vendor priorities and graph size are unchanged', async () => {
    const { result } = await runNew();
    expect(result.vendorPriority).toEqual(plain(legacy.vendorRisk));
    expect(result.graph.nodes).toHaveLength(legacy.graph.nodes.length);
    expect(result.graph.edges).toHaveLength(legacy.graph.edges.length);
    expect(result.graph.nodes.filter((n) => n.flagged).map((n) => n.id).sort()).toEqual(
      legacy.graph.nodes.filter((n) => n.flagged).map((n) => n.id).sort(),
    );
  });

  it('raising the approval limit changes the split/near-limit findings exactly as in the legacy tool', async () => {
    const key = await generateEngagementKey();
    const { data } = await protectDataset(sampleRawDataset(), { tokenise: createTokeniser(key), keyId: key.keyId, profile: NAMED_PROFILE });
    for (const limit of [50_000, 150_000, 250_000]) {
      const mine = analyse(data, { ...DEFAULT_RULE_CONFIG, approvalLimitPaise: limit * 100 });
      const theirs = GV.analyze(GV.protect(legacyData, 'ClientSecret#2026'), { approvalLimit: limit });
      expect(mine.findings.map(newView), `limit ${limit}`).toEqual(plain(theirs.flags.map(legacyView)));
    }
  });

  it('findings do not depend on which random key was used', async () => {
    const [a, b] = await Promise.all([runNew(), runNew()]);
    expect(a.result.findings.map((f) => f.fingerprint)).toEqual(b.result.findings.map((f) => f.fingerprint));
    const tokenA = a.data.entities.find((e) => e.id === 'V101')?.attributes.pan;
    const tokenB = b.data.entities.find((e) => e.id === 'V101')?.attributes.pan;
    expect(tokenA).not.toBe(tokenB);
  });
});

describe('minimal profile: same evidence, fewer readable labels', () => {
  it('finds the same rules against the same payments, with director DINs replaced by local references', async () => {
    const named = await runNew(NAMED_PROFILE);
    const minimal = await runNew(MINIMAL_PROFILE);
    const shape = (f: Finding) => [f.ruleId, f.severity, f.amountPaise, f.paymentIds, f.matchedFields];
    expect(minimal.result.findings.map(shape)).toEqual(named.result.findings.map(shape));
    const r2 = minimal.result.findings.filter((f) => f.ruleId === 'R2').map((f) => f.entityRefs);
    expect(r2).toEqual([['vendor:V108', 'director:D-002'], ['vendor:V108', 'director:D-001']]);
  });
});

describe('token format', () => {
  it('is the full HMAC-SHA256 digest of a domain-separated message', async () => {
    const raw = new Uint8Array(32).fill(7);
    const tokenise = createTokeniser(await importEngagementKey('k_test', raw));
    const expected = createHmac('sha256', raw).update('auditshield/token/v2\npan\nAABCD1234E').digest('hex');
    expect(await tokenise('pan', 'AABCD1234E')).toBe(expected);
    expect(expected).toMatch(/^[0-9a-f]{64}$/);
  });

  it('separates fields: the same string under two fields gives different tokens', async () => {
    const tokenise = createTokeniser(await generateEngagementKey());
    expect(await tokenise('pan', '9822011104')).not.toBe(await tokenise('phone', '9822011104'));
  });

  it('refuses to tokenise an empty value', async () => {
    const tokenise = createTokeniser(await generateEngagementKey());
    await expect(tokenise('pan', '')).rejects.toThrow('empty');
  });
});
