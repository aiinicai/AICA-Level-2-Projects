/**
 * PARITY — the TypeScript detector must do at least as well as the frozen legacy detector on the
 * legacy evaluation set and sample prompts. Differences must be intentional and listed in
 * IMPLEMENTATION_STATUS.md.
 */
import { describe, expect, it } from 'vitest';
import { detect } from '../../src/domain/privacy/detect';
import { BASELINE_EVAL_SET, evaluateDetector, SAMPLE_PROMPTS } from '../../src/domain/privacy/evaluate';
import { offlineDemoReply } from '../../src/domain/privacy/offlineDemo';
import { maskText } from '../../src/domain/privacy/policy';
import { restore, SessionVault } from '../../src/domain/privacy/vault';
import { type LegacyAG, loadLegacyCore, plain } from '../helpers/legacy';

const AG = loadLegacyCore<LegacyAG>('ai_gateway');

describe('corpus parity', () => {
  it('the ported evaluation set and sample prompts are the legacy ones, verbatim', () => {
    expect(BASELINE_EVAL_SET.map((c) => [c.text, c.expected])).toEqual(plain(AG.EVAL));
    expect(SAMPLE_PROMPTS).toEqual(plain(AG.SAMPLES));
  });
});

describe('detector parity on the 18-sentence baseline set', () => {
  const report = evaluateDetector(BASELINE_EVAL_SET);
  const legacy = AG.evaluate();

  it('scores 21 TP, 1 FN, 0 FP — the same as the legacy detector', () => {
    expect({ tp: report.tp, fn: report.fn, fp: report.fp }).toEqual({ tp: 21, fn: 1, fp: 0 });
    expect({ tp: report.tp, fn: report.fn, fp: report.fp }).toEqual({ tp: legacy.tp, fn: legacy.fn, fp: legacy.fp });
    expect(report.labelled).toBe(22);
  });

  it('per-type counts are identical', () => {
    expect(report.perType).toEqual(plain(legacy.per));
  });

  it('sentence by sentence, hits, misses and extras are identical', () => {
    expect(report.rows).toEqual(plain(legacy.rows));
  });

  it('the remaining miss is still the lowercase untitled name, and it stays visible', () => {
    expect(report.rows.filter((r) => r.miss.length)).toEqual([
      { text: 'the director ramesh gupta approved it', hit: [], miss: ['PERSON|ramesh gupta'], extra: [] },
    ]);
  });
});

describe('detector parity on the three sample prompts', () => {
  it.each(Object.keys(SAMPLE_PROMPTS))('%s: same identifiers, same order', (name) => {
    const text = SAMPLE_PROMPTS[name] ?? '';
    expect(detect(text).map((d) => [d.type, d.value])).toEqual(plain(AG.detect(text).map((d) => [d.type, d.value])));
  });

  it.each(Object.keys(SAMPLE_PROMPTS))('%s: mask → offline reply → request-scoped restore', (name) => {
    const text = SAMPLE_PROMPTS[name] ?? '';
    const vault = new SessionVault('T3ST');
    const { masked, tokens, spans } = maskText(text, vault);
    for (const s of spans) expect(masked).not.toContain(s.value);
    // Restoring the masked prompt itself with its own tokens gives back the original text.
    expect(restore(masked, vault, new Set(tokens)).text).toBe(text);
    const reply = offlineDemoReply(masked);
    for (const e of vault.entries()) expect(reply).not.toContain(e.value);
    const restored = restore(reply, vault, new Set(tokens));
    expect(restored.unknownTokens).toEqual([]);
    expect(restored.restoredTokens.length).toBeGreaterThan(0);
  });
});
