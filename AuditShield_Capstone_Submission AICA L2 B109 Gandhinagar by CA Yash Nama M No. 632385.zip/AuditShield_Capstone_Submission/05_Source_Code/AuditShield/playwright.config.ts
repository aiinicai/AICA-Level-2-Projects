import { defineConfig } from '@playwright/test';

/**
 * Real-browser checks against the production build (`vite preview`, CSP applied).
 * Uses the Microsoft Edge already installed on Windows, so no browser download is needed.
 * Run with `npm run test:e2e` (builds first).
 */
export default defineConfig({
  testDir: 'tests/e2e',
  outputDir: 'test-results',
  timeout: 90_000,
  workers: 1,
  reporter: [['list']],
  use: { baseURL: 'http://127.0.0.1:4173', channel: 'msedge', trace: 'retain-on-failure' },
  webServer: { command: 'npm run preview', url: 'http://127.0.0.1:4173', reuseExistingServer: true, timeout: 60_000 },
});
