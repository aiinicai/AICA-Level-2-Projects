// Records or verifies SHA-256 digests of the frozen legacy reference.
//   node scripts/legacy-manifest.mjs            -> (re)write tests/fixtures/baseline/legacy-manifest.json
//   node scripts/legacy-manifest.mjs --verify   -> exit 1 if any legacy file changed, appeared or vanished
// The manifest was first written in Phase 0 from a fresh extraction of AuditShield_Project.zip.
// Rewriting it is only legitimate if the original archive itself is replaced.
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, readdirSync, statSync, writeFileSync } from 'node:fs';
import { dirname, join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = join(dirname(fileURLToPath(import.meta.url)), '..');
const legacy = join(root, 'legacy');
const manifestPath = join(root, 'tests', 'fixtures', 'baseline', 'legacy-manifest.json');

function walk(dir) {
  return readdirSync(dir)
    .sort()
    .flatMap((name) => {
      const p = join(dir, name);
      return statSync(p).isDirectory() ? walk(p) : [p];
    });
}

const current = Object.fromEntries(
  walk(legacy).map((p) => [
    relative(legacy, p).split('\\').join('/'),
    createHash('sha256').update(readFileSync(p)).digest('hex'),
  ]),
);

if (process.argv.includes('--verify')) {
  const recorded = JSON.parse(readFileSync(manifestPath, 'utf8')).files;
  const names = new Set([...Object.keys(recorded), ...Object.keys(current)]);
  const diffs = [...names].filter((n) => recorded[n] !== current[n]);
  if (diffs.length) {
    console.error('Legacy reference differs from the Phase 0 manifest:\n  ' + diffs.join('\n  '));
    process.exit(1);
  }
  console.log(`Legacy reference intact: ${names.size} files match the manifest.`);
} else {
  mkdirSync(dirname(manifestPath), { recursive: true });
  writeFileSync(
    manifestPath,
    JSON.stringify({ source: 'AuditShield_Project.zip', algorithm: 'SHA-256', files: current }, null, 2) + '\n',
  );
  console.log(`Wrote ${Object.keys(current).length} digests to ${relative(root, manifestPath)}`);
}
