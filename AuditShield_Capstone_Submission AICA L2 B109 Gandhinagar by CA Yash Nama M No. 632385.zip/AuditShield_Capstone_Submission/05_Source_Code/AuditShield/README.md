# AuditShield

Private, offline vendor-fraud analysis and AI masking for Chartered Accountants
(AICA Level 2 capstone).

- **VendorShield**: import client CSVs → validate → protect identifiers with keyed HMAC-SHA256
  tokens → run rules R1–R10 → findings with payment evidence and a relationship graph → review
  decisions → workpaper. A **protected package** hands the tokens to an auditor's separate
  workspace, which reproduces the analysis without source data or key.
- **AI Gateway**: detect and mask Indian identifiers and names → review the exact outgoing text →
  enforced send gate → offline GPT in **LM Studio** on this computer (or offline demo) → local,
  request-scoped restoration.
- Encrypted local workspace (AES-256-GCM), versioned database, lock, encrypted backup/restore,
  installable PWA that works offline. Nothing is sent to the internet.

## Run (no installation)

Double-click **`START_AUDITSHIELD.bat`**. It serves the prebuilt app in `dist` with Windows
PowerShell at http://127.0.0.1:4173 and opens the browser. Keep the window open; close it to stop.

Developers (Node.js 20+): `npm ci`, then `npm run dev` (http://127.0.0.1:5173) or `npm run build`
and `npm run preview`.

## Verify

```
npm test              # unit, parity, integration (299 tests)
npm run typecheck
npm run legacy:verify # original capstone unchanged
npm run test:e2e      # builds, then 6 real-browser tests in Microsoft Edge
```

## Layout

| Path | Contents |
| --- | --- |
| `src/domain` | Pure logic: normalisation, protection, rules, CSV import, detection, masking, outbound policy |
| `src/services` | Web Crypto, packages, backup, gateway request service, LM Studio adapter, workpaper export |
| `src/data` | Database schema, versions, repositories |
| `src/features` | Screens |
| `tests` | Baseline vs the original capstone, known-issue reproductions, unit, integration, Edge e2e |
| `legacy/` | The original capstone, unchanged |
| `DEMO_SCRIPT.md` | Video recording script |
| `IMPLEMENTATION_STATUS.md` | Engineering record: decisions, results, known issues |

## Limits

Findings are indicators, not conclusions; tokens are pseudonyms, not anonymisation; accuracy is
measured on small synthetic samples. Cloud AI providers are deliberately not connected.
