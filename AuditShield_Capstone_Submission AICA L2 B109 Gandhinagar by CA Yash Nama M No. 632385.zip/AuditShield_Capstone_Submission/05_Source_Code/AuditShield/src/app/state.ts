/**
 * Session state: the part of the application that is deliberately NOT stored.
 *
 * Since Phase 2, engagements, snapshots, runs, findings, settings and activity live in the local
 * database and are read through repositories and live queries. What remains here exists only in
 * memory, only while the workspace is unlocked, and is discarded on lock or reload:
 *  - source data loaded for preparation (client context) that has not been retained;
 *  - the gateway draft, watch-list, manual masks, reviewed scan and last answer.
 * The reducer owns the gateway invalidation rule: any change to what would be sent, or where,
 * voids the reviewed scan.
 */
import type { ReviewedScan } from '../domain/privacy/policy';
import type { RawDataset } from '../domain/vendor/types';
import type { DispatchOutcome } from '../services/gateway/requestService';
import { OFFLINE_DEMO_DESTINATION } from '../services/providers/offlineDemoProvider';

export interface LoadedSource {
  raw: RawDataset;
  label: string;
  sourceType: 'sample' | 'csv';
  /** SHA-256 of the source data; compared with the stored snapshot's digest. */
  digest: string;
}

export interface GatewayState {
  draft: string;
  watchlistText: string;
  manualTerms: string[];
  destinationId: string;
  scan: ReviewedScan | null;
  outcome: DispatchOutcome | null;
}

export interface SessionState {
  currentId: string | null;
  source: Record<string, LoadedSource>;
  gateway: Record<string, GatewayState>;
}

export const initialState: SessionState = { currentId: null, source: {}, gateway: {} };

const emptyGateway = (): GatewayState => ({
  draft: '', watchlistText: '', manualTerms: [], destinationId: OFFLINE_DEMO_DESTINATION.providerId, scan: null, outcome: null,
});

export type Action =
  | { type: 'session/reset' }
  | { type: 'engagement/select'; engagementId: string | null }
  | { type: 'engagement/removed'; engagementId: string }
  | { type: 'source/loaded'; engagementId: string; source: LoadedSource }
  | { type: 'source/cleared'; engagementId: string }
  | { type: 'gateway/edit'; engagementId: string; patch: Partial<Pick<GatewayState, 'draft' | 'watchlistText' | 'manualTerms' | 'destinationId'>> }
  | { type: 'gateway/scanned'; engagementId: string; scan: ReviewedScan }
  | { type: 'gateway/outcome'; engagementId: string; outcome: DispatchOutcome };

function withGateway(state: SessionState, id: string, update: (g: GatewayState) => GatewayState): SessionState['gateway'] {
  return { ...state.gateway, [id]: update(state.gateway[id] ?? emptyGateway()) };
}
const without = <T,>(record: Record<string, T>, key: string): Record<string, T> =>
  Object.fromEntries(Object.entries(record).filter(([k]) => k !== key));

export function reducer(state: SessionState, action: Action): SessionState {
  switch (action.type) {
    case 'session/reset':
      // Locking: drop every reference to unlocked data.
      return initialState;
    case 'engagement/select':
      return { ...state, currentId: action.engagementId };
    case 'engagement/removed':
      return {
        currentId: state.currentId === action.engagementId ? null : state.currentId,
        source: without(state.source, action.engagementId),
        gateway: without(state.gateway, action.engagementId),
      };
    case 'source/loaded':
      return { ...state, source: { ...state.source, [action.engagementId]: action.source } };
    case 'source/cleared':
      return { ...state, source: without(state.source, action.engagementId) };
    case 'gateway/edit':
      // Any change to what would be sent, or where, voids the reviewed scan and the last answer.
      return { ...state, gateway: withGateway(state, action.engagementId, (g) => ({ ...g, ...action.patch, scan: null, outcome: null })) };
    case 'gateway/scanned':
      return { ...state, gateway: withGateway(state, action.engagementId, (g) => ({ ...g, scan: action.scan, outcome: null })) };
    case 'gateway/outcome':
      return { ...state, gateway: withGateway(state, action.engagementId, (g) => ({ ...g, outcome: action.outcome })) };
  }
}

export const selectGateway = (state: SessionState, id: string): GatewayState => state.gateway[id] ?? emptyGateway();

/* ---- activity text for gateway events: metadata only, never prompt text, values or answers */

export function scanAuditDetail(scan: ReviewedScan): string {
  const counts: Record<string, number> = {};
  for (const s of scan.spans) counts[s.type] = (counts[s.type] ?? 0) + 1;
  const types = Object.entries(counts).map(([t, n]) => `${t}:${n}`).join(' ') || 'none';
  return `${scan.spans.length} items masked (${types}), ${scan.violations.length} unresolved checks`;
}

export function outcomeAuditDetail(outcome: DispatchOutcome, destinationLabel: string): string {
  const detail =
    outcome.status === 'answered' ? `sent ${outcome.charactersSent} masked characters, ${outcome.tokensSent.length} tokens; ${outcome.restoration.unknownTokens.length} unrecognised tokens in answer`
    : outcome.status === 'blocked' ? `blocked before any provider call: ${[...new Set(outcome.reasons.map((r) => r.code))].join(', ')}`
    : outcome.status === 'failed' ? `failed: ${outcome.code}`
    : 'cancelled by user';
  return `${destinationLabel}; ${detail}`;
}
