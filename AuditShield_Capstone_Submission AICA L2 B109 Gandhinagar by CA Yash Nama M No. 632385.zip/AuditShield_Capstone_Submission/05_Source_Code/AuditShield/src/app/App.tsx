import {
  Activity, BookOpen, Bot, ClipboardList, FileInput, HardDrive, Laptop, LayoutDashboard, Lock, Network, Settings, ShieldCheck, WifiOff,
} from 'lucide-react';
import { type ComponentType, useEffect, useState } from 'react';
import { Badge, Button, Select } from '../components/ui/primitives';
import { ActivityPage } from '../features/activity/ActivityPage';
import { GatewayPage } from '../features/gateway/GatewayPage';
import { ImportsPage } from '../features/imports/ImportsPage';
import { LearnPage } from '../features/learn/LearnPage';
import { OverviewPage } from '../features/overview/OverviewPage';
import { SettingsPage } from '../features/settings/SettingsPage';
import { VendorShieldPage } from '../features/vendorshield/VendorShieldPage';
import { DbErrorScreen, OpeningScreen, SetupScreen, UnlockScreen } from '../features/workspace/WorkspaceGate';
import { WorkpapersPage } from '../features/workpapers/WorkpapersPage';
import { cn } from '../lib/cn';
import { SETTING } from '../services/workspace/useCases';
import { useEngagements, useSetting, useStore } from './store';

export const ROUTES = ['overview', 'imports', 'vendorshield', 'gateway', 'workpapers', 'activity', 'settings', 'learn'] as const;
export type Route = (typeof ROUTES)[number];
export type Navigate = (route: Route) => void;

const NAV: { route: Route; label: string; icon: ComponentType<{ className?: string }>; group: 'work' | 'reference' }[] = [
  { route: 'overview', label: 'Overview', icon: LayoutDashboard, group: 'work' },
  { route: 'imports', label: 'Imports', icon: FileInput, group: 'work' },
  { route: 'vendorshield', label: 'VendorShield', icon: Network, group: 'work' },
  { route: 'gateway', label: 'AI Gateway', icon: Bot, group: 'work' },
  { route: 'workpapers', label: 'Workpapers', icon: ClipboardList, group: 'work' },
  { route: 'activity', label: 'Activity', icon: Activity, group: 'work' },
  { route: 'settings', label: 'Settings', icon: Settings, group: 'work' },
  { route: 'learn', label: 'Demo / Learn', icon: BookOpen, group: 'reference' },
];

const routeFromHash = (): Route => {
  const candidate = window.location.hash.replace(/^#\/?/, '');
  return (ROUTES as readonly string[]).includes(candidate) ? (candidate as Route) : 'overview';
};

function useHashRoute(): [Route, Navigate] {
  const [route, setRoute] = useState<Route>(routeFromHash);
  useEffect(() => {
    const onChange = () => setRoute(routeFromHash());
    window.addEventListener('hashchange', onChange);
    return () => window.removeEventListener('hashchange', onChange);
  }, []);
  return [route, (next) => { window.location.hash = `/${next}`; }];
}

/** Selecting an engagement is remembered across restarts. */
export function useSelectEngagement() {
  const { dispatch, repos, clock } = useStore();
  return (engagementId: string) => {
    dispatch({ type: 'engagement/select', engagementId });
    void repos.settings.set(SETTING.currentEngagement, engagementId, clock.now());
  };
}

const BACKUP_WARN_DAYS = 7;

function StorageBadge() {
  const lastBackup = useSetting<string | null>(SETTING.lastBackupAt, null);
  if (!lastBackup.ready) return null;
  const days = lastBackup.value ? Math.floor((Date.now() - Date.parse(lastBackup.value)) / 86_400_000) : null;
  const stale = days === null || days >= BACKUP_WARN_DAYS;
  return (
    <a href="#/settings" className="rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600">
      <Badge tone={stale ? 'warn' : 'ok'} title="Data is stored in this browser profile only. Open Settings for backup and storage status.">
        <HardDrive aria-hidden />
        {days === null ? 'Saved locally · no backup yet' : days === 0 ? 'Saved locally · backed up today' : `Saved locally · backup ${days} day${days === 1 ? '' : 's'} old`}
      </Badge>
    </a>
  );
}

function Shell() {
  const { state, session } = useStore();
  const [route, navigate] = useHashRoute();
  const engagements = useEngagements();
  const select = useSelectEngagement();
  const list = engagements.ready ? engagements.value : [];
  const current = list.find((e) => e.id === state.currentId) ?? null;

  // Source data and gateway drafts are memory-only by design; ask before a reload discards them.
  const volatile = Object.keys(state.source).length > 0 || Object.values(state.gateway).some((g) => g.draft.trim() !== '');
  useEffect(() => {
    if (!volatile) return;
    const warn = (e: BeforeUnloadEvent) => e.preventDefault();
    window.addEventListener('beforeunload', warn);
    return () => window.removeEventListener('beforeunload', warn);
  }, [volatile]);

  useEffect(() => {
    document.title = `${NAV.find((n) => n.route === route)?.label ?? 'AuditShield'} · AuditShield`;
  }, [route]);

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900 md:flex-row">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:z-10 focus:m-2 focus:rounded focus:bg-white focus:px-3 focus:py-2 focus:shadow">
        Skip to content
      </a>

      <nav aria-label="Main" className="shrink-0 border-b border-slate-200 bg-slate-900 text-slate-200 md:w-56 md:border-r md:border-b-0">
        <div className="flex items-center gap-2 px-4 py-4">
          <ShieldCheck className="size-5 text-indigo-300" aria-hidden />
          <span className="text-base font-semibold text-white">AuditShield</span>
        </div>
        <ul className="flex gap-1 overflow-x-auto px-2 pb-2 [scrollbar-color:var(--color-slate-600)_transparent] [scrollbar-width:thin] md:flex-col md:overflow-visible md:pb-4">
          {NAV.map(({ route: r, label, icon: Icon, group }) => (
            <li key={r} className={cn(group === 'reference' && 'md:mt-4 md:border-t md:border-slate-700 md:pt-4')}>
              <a
                href={`#/${r}`}
                aria-current={route === r ? 'page' : undefined}
                className={cn(
                  'flex items-center gap-2 rounded-md px-3 py-2 text-sm whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-300',
                  route === r ? 'bg-indigo-700 font-medium text-white' : 'text-slate-300 hover:bg-slate-800 hover:text-white',
                )}
              >
                <Icon className="size-4 shrink-0" aria-hidden />
                {label}
              </a>
            </li>
          ))}
        </ul>
      </nav>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex flex-wrap items-center gap-x-4 gap-y-2 border-b border-slate-200 bg-white px-4 py-3 md:px-6">
          <div className="flex min-w-0 flex-wrap items-center gap-2">
            <label htmlFor="engagement-switch" className="text-sm font-medium text-slate-600">Engagement</label>
            <Select
              id="engagement-switch"
              className="w-auto max-w-[min(16rem,60vw)]"
              value={current?.id ?? ''}
              disabled={list.length === 0}
              onChange={(e) => select(e.target.value)}
            >
              {current ? null : <option value="">{list.length === 0 ? 'None yet' : 'Choose…'}</option>}
              {list.map((e) => (
                <option key={e.id} value={e.id}>{e.name} · FY {e.financialYear}</option>
              ))}
            </Select>
            {current?.kind === 'sample' ? <Badge tone="info">Synthetic sample</Badge> : null}
          </div>
          <div className="ml-auto flex flex-wrap items-center gap-2">
            <StorageBadge />
            {current && state.gateway[current.id]?.destinationId === 'local-model' ? (
              <Badge tone="info" title="Approved, masked requests go to a model running on this computer. Nothing goes to the internet.">
                <Laptop aria-hidden /> AI: local model (this computer)
              </Badge>
            ) : (
              <Badge tone="neutral" title="The offline demo builds a canned reply in the browser. No request leaves this browser.">
                <WifiOff aria-hidden /> AI: offline demo
              </Badge>
            )}
            <Button variant="outline" size="sm" onClick={() => session.lock('manual')}><Lock aria-hidden /> Lock</Button>
          </div>
        </header>

        <main id="main" tabIndex={-1} className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 focus:outline-none md:px-6">
          {route === 'overview' && <OverviewPage navigate={navigate} />}
          {route === 'imports' && <ImportsPage navigate={navigate} />}
          {route === 'vendorshield' && <VendorShieldPage navigate={navigate} />}
          {route === 'gateway' && <GatewayPage navigate={navigate} />}
          {route === 'workpapers' && <WorkpapersPage navigate={navigate} />}
          {route === 'activity' && <ActivityPage />}
          {route === 'settings' && <SettingsPage navigate={navigate} />}
          {route === 'learn' && <LearnPage />}
        </main>
      </div>
    </div>
  );
}

export function App() {
  const { opened, workspace, unlocked } = useStore();
  if (!opened) return <OpeningScreen />;
  if (!opened.ok) return <DbErrorScreen result={opened} />;
  if (workspace === undefined) return <OpeningScreen />;
  if (workspace === null) return <SetupScreen />;
  // The whole shell is unmounted while locked, so no screen keeps showing unlocked data.
  return unlocked ? <Shell /> : <UnlockScreen />;
}
