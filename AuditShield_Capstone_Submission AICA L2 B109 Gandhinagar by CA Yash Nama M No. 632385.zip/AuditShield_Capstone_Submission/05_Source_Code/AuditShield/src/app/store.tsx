/**
 * Application wiring for React: database, repositories, lock state, in-memory session state and
 * the per-engagement runtime objects (HMAC key, gateway vault) that exist only while unlocked.
 */
import { useLiveQuery } from 'dexie-react-hooks';
import { createContext, type Dispatch, type ReactNode, useContext, useEffect, useMemo, useReducer, useState, useSyncExternalStore } from 'react';
import {
  type AnalysisRunRecord, type AuditShieldDb, createDb, type FindingRecord, type ImportRecord, openDb, type OpenResult, type WorkspaceRecord,
} from '../data/db/schema';
import { createRepositories, type EngagementView, type Repositories, type WorkpaperView } from '../data/repositories/repositories';
import { SessionVault } from '../domain/privacy/vault';
import { DEFAULT_RULE_CONFIG, type RuleConfig } from '../domain/vendor/types';
import { type EngagementKey, generateEngagementKey, importEngagementKey } from '../services/crypto/tokeniser';
import { GatewayRequestService, newVaultNamespace } from '../services/gateway/requestService';
import { createOfflineDemoProvider } from '../services/providers/offlineDemoProvider';
import type { ProviderAdapter } from '../services/providers/types';
import { WorkspaceSession } from '../services/workspace/session';
import {
  type Clock, currentRun, DEFAULT_AUTO_LOCK_MINUTES, getRuleConfig, purgeExpiredSource, SETTING, systemClock, type UnlockedWorkspace,
} from '../services/workspace/useCases';
import { type Action, initialState, reducer, type SessionState } from './state';

export interface Runtime {
  providers: readonly ProviderAdapter[];
  gateway: GatewayRequestService;
  /** The engagement's HMAC key for this session; created on first use unless one was restored. */
  hmacKey(engagementId: string): Promise<EngagementKey>;
  /** Uses a retained key so new tokens match an earlier snapshot. */
  restoreHmacKey(engagementId: string, keyId: string, bytes: Uint8Array<ArrayBuffer>): Promise<void>;
  vault(engagementId: string): SessionVault;
  /** Drops every key and vault (on lock). */
  reset(): void;
}

function createRuntime(): Runtime {
  const keys = new Map<string, EngagementKey>();
  const vaults = new Map<string, SessionVault>();
  const providers = [createOfflineDemoProvider()];
  return {
    providers,
    gateway: new GatewayRequestService(providers),
    async hmacKey(id) {
      let key = keys.get(id);
      if (!key) {
        key = await generateEngagementKey();
        keys.set(id, key);
      }
      return key;
    },
    async restoreHmacKey(id, keyId, bytes) {
      keys.set(id, await importEngagementKey(keyId, bytes));
    },
    vault(id) {
      let vault = vaults.get(id);
      if (!vault) {
        vault = new SessionVault(newVaultNamespace());
        vaults.set(id, vault);
      }
      return vault;
    },
    reset() {
      keys.clear();
      vaults.clear();
    },
  };
}

interface Services {
  db: AuditShieldDb;
  repos: Repositories;
  session: WorkspaceSession;
  runtime: Runtime;
  clock: Clock;
}

interface StoreValue extends Services {
  opened: OpenResult | null;
  /** undefined while loading, null when this profile has no workspace yet. */
  workspace: WorkspaceRecord | null | undefined;
  unlocked: UnlockedWorkspace | null;
  state: SessionState;
  dispatch: Dispatch<Action>;
}

const StoreContext = createContext<StoreValue | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const services = useMemo<Services>(() => {
    const db = createDb();
    return { db, repos: createRepositories(db), session: new WorkspaceSession(), runtime: createRuntime(), clock: systemClock };
  }, []);
  const { db, repos, session, runtime } = services;
  const [opened, setOpened] = useState<OpenResult | null>(null);
  const [state, dispatch] = useReducer(reducer, initialState);

  useEffect(() => {
    let cancelled = false;
    void openDb(db).then((result) => !cancelled && setOpened(result));
    return () => {
      cancelled = true;
    };
  }, [db]);

  const unlocked = useSyncExternalStore((onChange) => session.subscribe(onChange), () => session.current);
  const workspace = useLiveQuery(async () => (opened?.ok ? ((await repos.workspace.get()) ?? null) : undefined), [opened], undefined);

  // On lock: forget everything that was derived from unlocked data.
  useEffect(() => {
    if (unlocked) return;
    runtime.reset();
    dispatch({ type: 'session/reset' });
  }, [unlocked, runtime]);

  // On unlock: restore the last selected engagement and purge expired source copies.
  useEffect(() => {
    if (!unlocked) return;
    let cancelled = false;
    void (async () => {
      await purgeExpiredSource(repos);
      const last = await repos.settings.get<string | null>(SETTING.currentEngagement, null);
      if (!cancelled && last) dispatch({ type: 'engagement/select', engagementId: last });
    })();
    return () => {
      cancelled = true;
    };
  }, [unlocked, repos]);

  // Any interaction restarts the inactivity countdown.
  useEffect(() => {
    if (!unlocked) return;
    let last = 0;
    const touch = () => {
      const now = Date.now();
      if (now - last > 5_000) {
        last = now;
        session.touch();
      }
    };
    window.addEventListener('pointerdown', touch);
    window.addEventListener('keydown', touch);
    return () => {
      window.removeEventListener('pointerdown', touch);
      window.removeEventListener('keydown', touch);
    };
  }, [unlocked, session]);

  const value = useMemo<StoreValue>(() => ({ ...services, opened, workspace, unlocked, state, dispatch }), [services, opened, workspace, unlocked, state]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore(): StoreValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside StoreProvider');
  return ctx;
}

/** For screens that only render while unlocked. */
export function useUnlocked(): UnlockedWorkspace {
  const { unlocked } = useStore();
  if (!unlocked) throw new Error('Workspace is locked');
  return unlocked;
}

/* ---------------------------------------------------------------- data hooks (live queries) */

/** A live query result that distinguishes "still loading" from "loaded, nothing there". */
export type Loaded<T> = { ready: false } | { ready: true; value: T };

function useLive<T>(query: () => Promise<T>, deps: unknown[]): Loaded<T> {
  // The result carries the inputs it was computed for. While a query for new inputs is still
  // running, the previous result is treated as "loading", so one engagement's data is never
  // shown under another's heading.
  const key = JSON.stringify(deps);
  const result = useLiveQuery(async () => ({ key, value: await query() }), deps, null);
  // Stable identity between renders: callers use the result in effect dependencies.
  return useMemo<Loaded<T>>(() => (result && result.key === key ? { ready: true, value: result.value } : NOT_READY), [result, key]);
}
const NOT_READY = { ready: false } as const;

/** Engagements with their labels decrypted in memory. */
export function useEngagements(): Loaded<EngagementView[]> {
  const { repos } = useStore();
  const { workspace, dek } = useUnlocked();
  const records = useLive(() => repos.engagements.list(workspace.id), [workspace.id]);
  const [views, setViews] = useState<Loaded<EngagementView[]>>({ ready: false });
  useEffect(() => {
    if (!records.ready) return;
    let cancelled = false;
    void Promise.all(records.value.map((r) => repos.engagements.view(dek, r))).then((value) => !cancelled && setViews({ ready: true, value }));
    return () => {
      cancelled = true;
    };
  }, [records, repos, dek]);
  return views;
}

export function useCurrentEngagement(): Loaded<EngagementView | null> {
  const { state } = useStore();
  const engagements = useEngagements();
  if (!engagements.ready) return { ready: false };
  return { ready: true, value: engagements.value.find((e) => e.id === state.currentId) ?? null };
}

export interface EngagementData {
  snapshot: ImportRecord | null;
  ruleConfig: RuleConfig;
  /** The run of the current snapshot under the current thresholds, if one exists. */
  run: AnalysisRunRecord | null;
  hasRetainedSource: boolean;
}

/** Everything the screens need to know about an engagement's stored state, kept live. */
export function useEngagementData(engagementId: string): Loaded<EngagementData> {
  const { repos } = useStore();
  return useLive(async () => {
    const [snapshot, ruleConfig] = await Promise.all([repos.datasets.latestImport(engagementId), getRuleConfig(repos, engagementId)]);
    if (!snapshot) return { snapshot: null, ruleConfig, run: null, hasRetainedSource: false };
    const [run, retained] = await Promise.all([currentRun(repos, snapshot.id, ruleConfig), repos.datasets.retained(snapshot.id)]);
    return { snapshot, ruleConfig, run: run ?? null, hasRetainedSource: retained !== undefined };
  }, [engagementId]);
}

/** Saved reviews of this engagement's findings, decrypted in memory and keyed by finding fingerprint. */
export function useWorkpapers(engagementId: string): Loaded<ReadonlyMap<string, WorkpaperView>> {
  const { repos } = useStore();
  const { workspace, dek } = useUnlocked();
  const records = useLive(() => repos.workpapers.list(engagementId), [engagementId]);
  const [views, setViews] = useState<Loaded<ReadonlyMap<string, WorkpaperView>>>(NOT_READY);
  useEffect(() => {
    if (!records.ready) return setViews(NOT_READY);
    let cancelled = false;
    void Promise.all(records.value.map((r) => repos.workpapers.view(dek, workspace.id, r))).then(
      (list) => !cancelled && setViews({ ready: true, value: new Map(list.map((v) => [v.fingerprint, v])) }),
    );
    return () => {
      cancelled = true;
    };
  }, [records, repos, dek, workspace.id]);
  return views;
}

export function useFindings(runId: string | null): Loaded<FindingRecord[]> {
  const { repos } = useStore();
  return useLive(() => (runId ? repos.runs.findings(runId) : Promise.resolve([])), [runId]);
}

export function useSetting<T>(key: string, fallback: T): Loaded<T> {
  const { repos } = useStore();
  return useLive(() => repos.settings.get<T>(key, fallback), [key]);
}

export { DEFAULT_AUTO_LOCK_MINUTES, DEFAULT_RULE_CONFIG };
