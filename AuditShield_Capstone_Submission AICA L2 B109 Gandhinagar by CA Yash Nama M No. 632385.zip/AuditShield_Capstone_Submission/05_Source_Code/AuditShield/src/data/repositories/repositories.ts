/**
 * Persistence boundary. Screens and use-cases talk to `Repositories`; only this file knows the
 * storage engine. A different engine (for example SQLite in a desktop build) would implement the
 * same interface.
 *
 * Rules enforced here because IndexedDB has no foreign keys or constraints:
 *  - every multi-store change runs in one transaction: it is applied completely or not at all;
 *  - referential checks (engagement exists, import belongs to the engagement) happen inside that
 *    transaction;
 *  - encryption happens before the transaction starts (awaiting Web Crypto inside an IndexedDB
 *    transaction would let it auto-commit half-way);
 *  - snapshots, runs and findings are insert-only.
 */
import Dexie from 'dexie';
import { stableHash } from '../../domain/shared/hash';
import { ENGINE_VERSION } from '../../domain/vendor/rules';
import type {
  AnalysisResult, DataQualityIssue, MatchField, ProtectedDataset, ProtectedEntity, RawDataset, RuleConfig,
} from '../../domain/vendor/types';
import { type ReviewInput, reviewProblem } from '../../domain/vendor/review';
import { validateProtectedDataset, type ValidationError } from '../../domain/vendor/validate';
import { decryptBytes, decryptJson, encryptBytes, encryptJson, type KeyEnvelope, recordAad } from '../../services/crypto/envelope';
import {
  type AnalysisRunRecord, type AuditEventRecord, type AuditShieldDb, type EngagementRecord, type EntityAttributeRecord,
  type EntityRecord, type FindingRecord, type ImportRecord, type PaymentRecord, type WorkpaperRecord, type WorkspaceRecord,
} from '../db/schema';

export class ImportValidationError extends Error {
  constructor(readonly errors: ValidationError[]) {
    super(`The dataset has ${errors.length} validation error(s) and was not saved.`);
    this.name = 'ImportValidationError';
  }
}
export class IntegrityError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'IntegrityError';
  }
}

export interface WorkpaperView extends ReviewInput {
  fingerprint: string;
  revision: number;
  updatedAt: string;
}

export interface EngagementView {
  id: string;
  name: string;
  financialYear: string;
  kind: 'sample' | 'client';
  status: 'active' | 'archived';
  createdAt: string;
}

/** Caller-supplied identity and time, so writes are deterministic and testable. */
export interface Stamp {
  id: string;
  at: string;
}

export interface CommitImportInput {
  importId: string;
  engagementId: string;
  workspaceId: string;
  at: string;
  sourceType: ImportRecord['sourceType'];
  sourceLabel: string;
  sourceDigest: string;
  data: ProtectedDataset;
  issues: DataQualityIssue[];
  /** Present only when the user explicitly chose to keep an encrypted copy of the source and its key. */
  retain?: { raw: RawDataset; keyBytes: Uint8Array<ArrayBuffer>; expiresAt: string };
  auditId: string;
}

export interface SaveRunInput {
  runId: string;
  engagementId: string;
  importId: string;
  result: AnalysisResult;
  startedAt: string;
  finishedAt: string;
  auditId: string;
}

export const ruleSetIdFor = (config: RuleConfig): string =>
  `rs_${stableHash(JSON.stringify([ENGINE_VERSION, config.version, config.approvalLimitPaise, config.nearLimitBasisPoints, config.splitWindowDays, config.roundAmountPaise]))}`;

const range = (prefix: string) => [[prefix, Dexie.minKey], [prefix, Dexie.maxKey]] as const;

export function createRepositories(db: AuditShieldDb) {
  const audit = (id: string, at: string, engagementId: string, action: string, detail: string): AuditEventRecord => ({ id, at, engagementId, action, detail });

  return {
    workspace: {
      get: (): Promise<WorkspaceRecord | undefined> => db.workspace.toCollection().first(),
      async create(stamp: Stamp, envelope: KeyEnvelope, auditId: string): Promise<WorkspaceRecord> {
        const record: WorkspaceRecord = { id: stamp.id, createdAt: stamp.at, envelope };
        await db.transaction('rw', db.workspace, db.auditEvents, async () => {
          if (await db.workspace.count()) throw new IntegrityError('A workspace already exists in this browser profile.');
          await db.workspace.add(record);
          await db.auditEvents.add(audit(auditId, stamp.at, '', 'Workspace created', `key envelope v${envelope.version}, ${envelope.kdf.name} ${envelope.kdf.iterations} iterations`));
        });
        return record;
      },
    },

    engagements: {
      async create(dek: CryptoKey, workspaceId: string, stamp: Stamp, input: { name: string; financialYear: string; kind: EngagementRecord['kind'] }, auditId: string): Promise<EngagementRecord> {
        const label = await encryptJson(dek, recordAad(workspaceId, 'engagements', stamp.id, 'label'), input.name.trim());
        const record: EngagementRecord = {
          id: stamp.id, workspaceId, financialYear: input.financialYear.trim(), kind: input.kind, status: 'active', label, createdAt: stamp.at, updatedAt: stamp.at,
        };
        await db.transaction('rw', db.engagements, db.auditEvents, async () => {
          await db.engagements.add(record);
          await db.auditEvents.add(audit(auditId, stamp.at, record.id, 'Engagement created', `${record.kind} engagement, FY ${record.financialYear}`));
        });
        return record;
      },
      list: (workspaceId: string): Promise<EngagementRecord[]> =>
        db.engagements.where('[workspaceId+status]').between(...range(workspaceId)).sortBy('createdAt'),
      async view(dek: CryptoKey, record: EngagementRecord): Promise<EngagementView> {
        const name = await decryptJson<string>(dek, recordAad(record.workspaceId, 'engagements', record.id, 'label'), record.label);
        return { id: record.id, name, financialYear: record.financialYear, kind: record.kind, status: record.status, createdAt: record.createdAt };
      },
      /** Removes the engagement and every record that belongs to it, in one transaction. */
      async remove(engagementId: string, stamp: Stamp): Promise<void> {
        const scoped = [db.imports, db.entities, db.entityAttributes, db.payments, db.analysisRuns, db.findings, db.rawPayloads, db.engagementKeys, db.auditEvents, db.workpapers];
        await db.transaction('rw', [db.engagements, db.settings, ...scoped], async () => {
          for (const table of scoped) await table.where('engagementId').equals(engagementId).delete();
          await db.settings.delete(`ruleConfig:${engagementId}`);
          await db.engagements.delete(engagementId);
          await db.auditEvents.add(audit(stamp.id, stamp.at, '', 'Engagement deleted', 'engagement and all of its local records removed'));
        });
      },
    },

    datasets: {
      /** Validates, then writes one immutable snapshot atomically. Throws without writing on any problem. */
      async commitImport(dek: CryptoKey, input: CommitImportInput): Promise<ImportRecord> {
        const errors = validateProtectedDataset(input.data);
        if (errors.length) throw new ImportValidationError(errors);
        const { data, importId, engagementId, workspaceId, at } = input;

        const record: ImportRecord = {
          id: importId, engagementId, sourceType: input.sourceType,
          sourceLabel: await encryptJson(dek, recordAad(workspaceId, 'imports', importId, 'sourceLabel'), input.sourceLabel),
          sourceDigest: input.sourceDigest, importSchemaVersion: 1, scheme: data.scheme, profile: data.profile,
          rowCounts: {
            employees: data.entities.filter((e) => e.kind === 'employee').length,
            vendors: data.entities.filter((e) => e.kind === 'vendor').length,
            directors: data.entities.filter((e) => e.kind === 'director').length,
            payments: data.payments.length,
          },
          issues: input.issues, createdAt: at,
        };
        const entities: EntityRecord[] = [];
        const attributes: EntityAttributeRecord[] = [];
        data.entities.forEach((e, seq) => {
          const id = `${importId}|${e.kind}|${e.id}`;
          entities.push({ id, engagementId, importId, seq, kind: e.kind, sourceRecordId: e.id, label: e.label, ...(e.createdBy ? { createdBy: e.createdBy } : {}) });
          for (const [field, token] of Object.entries(e.attributes) as [MatchField, string][]) {
            attributes.push({
              id: `${id}|${field}`, engagementId, importId, entityId: id, field, token,
              normalisationVersion: data.scheme.normalisationVersion, keyId: data.scheme.keyId,
            });
          }
        });
        const payments: PaymentRecord[] = data.payments.map((p, seq) => ({
          id: `${importId}|${p.id}`, engagementId, importId, seq, sourcePaymentId: p.id, vendorId: p.vendorId,
          invoiceRef: p.invoiceRef, date: p.date, amountPaise: p.amountPaise, currency: 'INR', approverRef: p.approvedBy,
        }));
        const retained = input.retain
          ? {
              payload: await encryptJson(dek, recordAad(workspaceId, 'rawPayloads', importId, 'payload'), input.retain.raw),
              key: await encryptBytes(dek, recordAad(workspaceId, 'engagementKeys', data.scheme.keyId, 'key'), input.retain.keyBytes),
              expiresAt: input.retain.expiresAt,
            }
          : null;

        await db.transaction('rw', [db.engagements, db.imports, db.entities, db.entityAttributes, db.payments, db.rawPayloads, db.engagementKeys, db.auditEvents], async () => {
          if (!(await db.engagements.get(engagementId))) throw new IntegrityError('The engagement no longer exists.');
          await db.imports.add(record);
          await db.entities.bulkAdd(entities);
          await db.entityAttributes.bulkAdd(attributes);
          await db.payments.bulkAdd(payments);
          if (retained) {
            await db.rawPayloads.add({ id: importId, engagementId, payload: retained.payload, retentionExpiresAt: retained.expiresAt, createdAt: at });
            await db.engagementKeys.put({ id: data.scheme.keyId, engagementId, key: retained.key, createdAt: at });
          }
          await db.auditEvents.add(audit(input.auditId, at, engagementId, 'Snapshot committed',
            `${entities.length} entities, ${payments.length} payments, profile "${data.profile.id}", key ${data.scheme.keyId}, ${input.issues.length} data-quality warnings, source copy ${retained ? 'retained encrypted' : 'not retained'}`));
        });
        return record;
      },

      async latestImport(engagementId: string): Promise<ImportRecord | undefined> {
        return db.imports.where('[engagementId+createdAt]').between(...range(engagementId)).last();
      },
      importById: (importId: string): Promise<ImportRecord | undefined> => db.imports.get(importId),
      imports: (engagementId: string): Promise<ImportRecord[]> =>
        db.imports.where('[engagementId+createdAt]').between(...range(engagementId)).toArray(),

      /** Rebuilds the protected dataset of a snapshot exactly as it was committed. */
      async loadProtected(importId: string): Promise<ProtectedDataset> {
        return db.transaction('r', db.imports, db.entities, db.entityAttributes, db.payments, async () => {
          const record = await db.imports.get(importId);
          if (!record) throw new IntegrityError('Snapshot not found.');
          const [entities, attributes, payments] = await Promise.all([
            db.entities.where('[importId+kind]').between(...range(importId)).sortBy('seq'),
            db.entityAttributes.where('[importId+field+token]').between([importId, Dexie.minKey, Dexie.minKey], [importId, Dexie.maxKey, Dexie.maxKey]).toArray(),
            db.payments.where('[importId+vendorId+date]').between([importId, Dexie.minKey, Dexie.minKey], [importId, Dexie.maxKey, Dexie.maxKey]).sortBy('seq'),
          ]);
          const byEntity = new Map<string, ProtectedEntity['attributes']>();
          for (const a of attributes) byEntity.set(a.entityId, { ...byEntity.get(a.entityId), [a.field]: a.token });
          return {
            scheme: record.scheme,
            profile: record.profile,
            entities: entities.map((e) => ({
              kind: e.kind, id: e.sourceRecordId, label: e.label, attributes: byEntity.get(e.id) ?? {}, ...(e.createdBy ? { createdBy: e.createdBy } : {}),
            })),
            payments: payments.map((p) => ({ id: p.sourcePaymentId, vendorId: p.vendorId, invoiceRef: p.invoiceRef, date: p.date, amountPaise: p.amountPaise, approvedBy: p.approverRef })),
          };
        });
      },
      sourceLabel: (dek: CryptoKey, workspaceId: string, record: ImportRecord): Promise<string> =>
        decryptJson<string>(dek, recordAad(workspaceId, 'imports', record.id, 'sourceLabel'), record.sourceLabel),
      paymentsByIds: async (importId: string, sourcePaymentIds: readonly string[]): Promise<PaymentRecord[]> =>
        (await db.payments.bulkGet(sourcePaymentIds.map((id) => `${importId}|${id}`))).filter((p): p is PaymentRecord => p !== undefined),
      entities: (importId: string): Promise<EntityRecord[]> => db.entities.where('[importId+kind]').between(...range(importId)).toArray(),

      /* ---- optional encrypted retention of source data */
      retained: (importId: string) => db.rawPayloads.get(importId),
      async loadRetained(dek: CryptoKey, workspaceId: string, importId: string): Promise<{ raw: RawDataset; keyId: string; keyBytes: Uint8Array<ArrayBuffer> } | null> {
        const [payload, record] = await Promise.all([db.rawPayloads.get(importId), db.imports.get(importId)]);
        if (!payload || !record) return null;
        const key = await db.engagementKeys.get(record.scheme.keyId);
        if (!key) return null;
        return {
          raw: await decryptJson<RawDataset>(dek, recordAad(workspaceId, 'rawPayloads', importId, 'payload'), payload.payload),
          keyId: key.id,
          keyBytes: await decryptBytes(dek, recordAad(workspaceId, 'engagementKeys', key.id, 'key'), key.key),
        };
      },
      /** Deletes retained source copies (and keys no longer needed by any retained copy). */
      async deleteRetained(importIds: readonly string[], stamp: Stamp, engagementId: string, reason: string): Promise<number> {
        return db.transaction('rw', db.rawPayloads, db.engagementKeys, db.imports, db.auditEvents, async () => {
          const existing = (await db.rawPayloads.bulkGet([...importIds])).filter((r) => r !== undefined);
          if (existing.length === 0) return 0;
          await db.rawPayloads.bulkDelete(existing.map((r) => r.id));
          const stillRetained = new Set((await db.imports.bulkGet(await db.rawPayloads.toCollection().primaryKeys())).map((i) => i?.scheme.keyId));
          for (const record of await db.imports.bulkGet(existing.map((r) => r.id))) {
            if (record && !stillRetained.has(record.scheme.keyId)) await db.engagementKeys.delete(record.scheme.keyId);
          }
          await db.auditEvents.add(audit(stamp.id, stamp.at, engagementId, 'Retained source data deleted', `${existing.length} encrypted source cop${existing.length === 1 ? 'y' : 'ies'} removed (${reason})`));
          return existing.length;
        });
      },
      /** Import IDs whose retention period ended at or before `nowIso`. */
      expiredRetained: async (nowIso: string): Promise<{ id: string; engagementId: string }[]> =>
        (await db.rawPayloads.where('retentionExpiresAt').between('0', nowIso, true, true).toArray()).map((r) => ({ id: r.id, engagementId: r.engagementId })),
    },

    runs: {
      /** Stores a completed run with its findings and exact rule set, atomically. Runs are never updated. */
      async save(input: SaveRunInput): Promise<AnalysisRunRecord> {
        const { result, runId, engagementId, importId } = input;
        const ruleSetId = ruleSetIdFor(result.ruleConfig);
        const run: AnalysisRunRecord = {
          id: runId, engagementId, importId, ruleSetId, engineVersion: ENGINE_VERSION, status: 'completed',
          summary: result.summary, vendorPriority: result.vendorPriority, graph: result.graph, startedAt: input.startedAt, finishedAt: input.finishedAt,
        };
        const findings: FindingRecord[] = result.findings.map((f, seq) => ({
          ...f, id: `${runId}|${f.fingerprint}`, runId, engagementId, importId, seq, reviewStatus: 'open',
        }));
        await db.transaction('rw', db.imports, db.ruleSets, db.analysisRuns, db.findings, db.auditEvents, async () => {
          const snapshot = await db.imports.get(importId);
          if (!snapshot || snapshot.engagementId !== engagementId) throw new IntegrityError('The snapshot does not belong to this engagement.');
          if (!(await db.ruleSets.get(ruleSetId))) {
            await db.ruleSets.add({ id: ruleSetId, engineVersion: ENGINE_VERSION, config: result.ruleConfig, createdAt: input.finishedAt });
          }
          await db.analysisRuns.add(run);
          await db.findings.bulkAdd(findings);
          const s = result.summary;
          await db.auditEvents.add(audit(input.auditId, input.finishedAt, engagementId, 'Analysis run',
            `${s.findings} findings (${s.bySeverity.Critical} critical, ${s.bySeverity.High} high), rule set ${ruleSetId}, engine ${ENGINE_VERSION}`));
        });
        return run;
      },
      /** Most recent run of this snapshot under exactly this rule set, if any. */
      async latest(importId: string, ruleSetId: string): Promise<AnalysisRunRecord | undefined> {
        const runs = await db.analysisRuns.where('[importId+startedAt]').between(...range(importId)).toArray();
        return runs.filter((r) => r.ruleSetId === ruleSetId).at(-1);
      },
      forImport: (importId: string): Promise<AnalysisRunRecord[]> => db.analysisRuns.where('[importId+startedAt]').between(...range(importId)).toArray(),
      findings: (runId: string): Promise<FindingRecord[]> => db.findings.where('[runId+severity]').between(...range(runId)).sortBy('seq'),
      ruleSet: (id: string) => db.ruleSets.get(id),
    },

    workpapers: {
      /** Saves the review of one finding (insert or new revision) with its activity event, atomically. */
      async save(dek: CryptoKey, workspaceId: string, engagementId: string, fingerprint: string, input: ReviewInput, stamp: Stamp): Promise<WorkpaperRecord> {
        const problem = reviewProblem(input);
        if (problem) throw new IntegrityError(problem);
        const id = `${engagementId}|${fingerprint}`;
        const body = await encryptJson(dek, recordAad(workspaceId, 'workpapers', id, 'body'), { notes: input.notes, conclusion: input.conclusion });
        return db.transaction('rw', db.engagements, db.workpapers, db.auditEvents, async () => {
          if (!(await db.engagements.get(engagementId))) throw new IntegrityError('The engagement no longer exists.');
          const previous = await db.workpapers.get(id);
          const record: WorkpaperRecord = {
            id, engagementId, findingFingerprint: fingerprint, status: input.status, body, revision: (previous?.revision ?? 0) + 1, updatedAt: stamp.at,
          };
          await db.workpapers.put(record);
          await db.auditEvents.add(audit(stamp.id, stamp.at, engagementId, 'Finding reviewed',
            `finding ${fingerprint}: ${previous ? `${previous.status} → ` : ''}${input.status}, revision ${record.revision}`));
          return record;
        });
      },
      list: (engagementId: string): Promise<WorkpaperRecord[]> => db.workpapers.where('engagementId').equals(engagementId).toArray(),
      async view(dek: CryptoKey, workspaceId: string, record: WorkpaperRecord): Promise<WorkpaperView> {
        const body = await decryptJson<{ notes: string; conclusion: string }>(dek, recordAad(workspaceId, 'workpapers', record.id, 'body'), record.body);
        return { fingerprint: record.findingFingerprint, status: record.status, notes: body.notes, conclusion: body.conclusion, revision: record.revision, updatedAt: record.updatedAt };
      },
    },

    audit: {
      append: (stamp: Stamp, engagementId: string, action: string, detail: string) => db.auditEvents.add(audit(stamp.id, stamp.at, engagementId, action, detail)),
      list: (limit = 500): Promise<AuditEventRecord[]> => db.auditEvents.orderBy('at').reverse().limit(limit).toArray(),
    },

    settings: {
      async get<T>(key: string, fallback: T): Promise<T> {
        const record = await db.settings.get(key);
        return record === undefined ? fallback : (record.value as T);
      },
      set: (key: string, value: unknown, at: string) => db.settings.put({ key, value, updatedAt: at }),
    },
  };
}

export type Repositories = ReturnType<typeof createRepositories>;
