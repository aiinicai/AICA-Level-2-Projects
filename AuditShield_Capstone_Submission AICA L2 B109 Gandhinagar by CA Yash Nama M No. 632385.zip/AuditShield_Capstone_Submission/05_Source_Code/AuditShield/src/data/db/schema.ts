/**
 * IndexedDB schema (through Dexie), explicit versions and safe opening.
 *
 * What is stored, and how:
 *  - protected entities, attribute tokens, payments, runs, findings, rule sets, audit metadata and
 *    settings are stored as plain records so they can be indexed and queried;
 *  - engagement labels, import source labels, retained source data and retained HMAC keys are
 *    stored only as AES-GCM ciphertext under the workspace data key (EncryptedBox);
 *  - raw source data and HMAC keys are stored only when the user opts in at protection time.
 *  - gateway prompts, answers and vault values are not stored at all in this version.
 *
 * Every engagement-scoped record carries `engagementId`. Imports, their entities/attributes/
 * payments, rule sets, runs and findings are immutable: repositories offer no update for them.
 *
 * Version history
 *   1  workspace, engagements, imports, entities, entityAttributes, payments, ruleSets,
 *      analysisRuns, findings, rawPayloads, engagementKeys, auditEvents, settings
 *   2  findings gain `reviewStatus` (backfilled to "open") and a [runId+reviewStatus] index;
 *      new `workpapers` store. Groundwork for Phase 4 and the first real migration.
 */
import Dexie, { type Table } from 'dexie';
import type {
  AnalysisSummary, DataQualityIssue, EntityKind, ExportProfile, Finding, GraphEdge, GraphNode, MatchField, RuleConfig, TokenScheme,
} from '../../domain/vendor/types';
import type { ReviewStatus } from '../../domain/vendor/review';
import type { EncryptedBox, KeyEnvelope } from '../../services/crypto/envelope';

export const DB_NAME = 'auditshield';
export const SCHEMA_VERSION = 2;

export interface WorkspaceRecord {
  id: string;
  createdAt: string;
  envelope: KeyEnvelope;
}
export interface EngagementRecord {
  id: string;
  workspaceId: string;
  financialYear: string;
  kind: 'sample' | 'client';
  status: 'active' | 'archived';
  /** Encrypted client label. */
  label: EncryptedBox;
  createdAt: string;
  updatedAt: string;
}
export interface ImportRecord {
  id: string;
  engagementId: string;
  sourceType: 'sample' | 'csv' | 'package';
  /** Encrypted: file names and descriptions can identify a client. */
  sourceLabel: EncryptedBox;
  /** SHA-256 of the canonical source data, to recognise the same data again. */
  sourceDigest: string;
  importSchemaVersion: 1;
  scheme: TokenScheme;
  profile: ExportProfile;
  rowCounts: { employees: number; vendors: number; directors: number; payments: number };
  issues: DataQualityIssue[];
  createdAt: string;
}
export interface EntityRecord {
  /** `${importId}|${kind}|${sourceRecordId}` — unique per import by construction. */
  id: string;
  engagementId: string;
  importId: string;
  seq: number;
  kind: EntityKind;
  sourceRecordId: string;
  label: string;
  createdBy?: string;
}
export interface EntityAttributeRecord {
  /** `${entityId}|${field}` */
  id: string;
  engagementId: string;
  importId: string;
  entityId: string;
  field: MatchField;
  token: string;
  normalisationVersion: number;
  keyId: string;
}
export interface PaymentRecord {
  /** `${importId}|${sourcePaymentId}` — unique per import by construction. */
  id: string;
  engagementId: string;
  importId: string;
  seq: number;
  sourcePaymentId: string;
  vendorId: string;
  invoiceRef: string;
  /** ISO business date. */
  date: string;
  amountPaise: number;
  currency: 'INR';
  approverRef: string;
}
export interface RuleSetRecord {
  id: string;
  engineVersion: string;
  config: RuleConfig;
  createdAt: string;
}
export interface AnalysisRunRecord {
  id: string;
  engagementId: string;
  importId: string;
  ruleSetId: string;
  engineVersion: string;
  status: 'completed';
  summary: AnalysisSummary;
  vendorPriority: Record<string, number>;
  graph: { nodes: GraphNode[]; edges: GraphEdge[] };
  /** UTC instants. */
  startedAt: string;
  finishedAt: string;
}
export type { ReviewStatus };
export interface FindingRecord extends Finding {
  /** `${runId}|${fingerprint}` */
  id: string;
  runId: string;
  engagementId: string;
  importId: string;
  seq: number;
  /** Since schema version 2. */
  reviewStatus: ReviewStatus;
}
export interface RawPayloadRecord {
  /** Same as the import ID: at most one retained source per import. */
  id: string;
  engagementId: string;
  payload: EncryptedBox;
  /** UTC instant after which the copy is purged, or '' to keep until deleted. */
  retentionExpiresAt: string;
  createdAt: string;
}
export interface EngagementKeyRecord {
  /** keyId recorded in the import's token scheme. */
  id: string;
  engagementId: string;
  key: EncryptedBox;
  createdAt: string;
}
export interface AuditEventRecord {
  id: string;
  /** '' for workspace-level events. */
  engagementId: string;
  at: string;
  action: string;
  /** Metadata only: counts and record references, never identifiers, prompts or answers. */
  detail: string;
}
export interface SettingRecord {
  key: string;
  value: unknown;
  updatedAt: string;
}
/** The auditor's review of one finding. One record per engagement + finding fingerprint. */
export interface WorkpaperRecord {
  /** `${engagementId}|${findingFingerprint}` */
  id: string;
  engagementId: string;
  findingFingerprint: string;
  status: ReviewStatus;
  /** Encrypted `{ notes, conclusion }`: free text written by the auditor can name people. */
  body: EncryptedBox;
  /** Incremented on every save. */
  revision: number;
  updatedAt: string;
}

export class AuditShieldDb extends Dexie {
  workspace!: Table<WorkspaceRecord, string>;
  engagements!: Table<EngagementRecord, string>;
  imports!: Table<ImportRecord, string>;
  entities!: Table<EntityRecord, string>;
  entityAttributes!: Table<EntityAttributeRecord, string>;
  payments!: Table<PaymentRecord, string>;
  ruleSets!: Table<RuleSetRecord, string>;
  analysisRuns!: Table<AnalysisRunRecord, string>;
  findings!: Table<FindingRecord, string>;
  rawPayloads!: Table<RawPayloadRecord, string>;
  engagementKeys!: Table<EngagementKeyRecord, string>;
  auditEvents!: Table<AuditEventRecord, string>;
  settings!: Table<SettingRecord, string>;
  workpapers!: Table<WorkpaperRecord, string>;
  /** Set when an upgrade function threw during open; the version change was rolled back. */
  migrationFailed = false;
  /** Highest schema version this build of the app declares. */
  declaredVersion = SCHEMA_VERSION;
}

/** Stores holding engagement-scoped records, all indexed by `engagementId`. */
export const ENGAGEMENT_SCOPED = [
  'imports', 'entities', 'entityAttributes', 'payments', 'analysisRuns', 'findings', 'rawPayloads', 'engagementKeys', 'auditEvents', 'workpapers',
] as const;

const V1_STORES = {
  workspace: 'id',
  engagements: 'id, [workspaceId+status]',
  imports: 'id, [engagementId+createdAt], engagementId',
  entities: 'id, [importId+kind], engagementId',
  entityAttributes: 'id, entityId, [importId+field+token], engagementId',
  payments: 'id, [importId+vendorId+date], engagementId',
  ruleSets: 'id',
  analysisRuns: 'id, [importId+startedAt], engagementId',
  findings: 'id, [runId+severity], engagementId',
  rawPayloads: 'id, engagementId, retentionExpiresAt',
  engagementKeys: 'id, engagementId',
  auditEvents: 'id, [engagementId+at], at, engagementId',
  settings: 'key',
};
const V2_STORES = {
  findings: 'id, [runId+severity], [runId+reviewStatus], engagementId',
  workpapers: 'id, engagementId, [engagementId+findingFingerprint]',
};

export interface DbOptions {
  name?: string;
  /** Injected in tests (fake-indexeddb). Defaults to the browser's. */
  indexedDB?: IDBFactory;
  IDBKeyRange?: typeof IDBKeyRange;
  /** Tests only: build the database as an older release would have. */
  maxVersion?: 1 | 2;
  /** Tests only: runs at the start of the version 2 upgrade, to simulate a failing migration. */
  beforeUpgradeV2?: () => void;
}

export function createDb(options: DbOptions = {}): AuditShieldDb {
  const db = new AuditShieldDb(options.name ?? DB_NAME, {
    ...(options.indexedDB ? { indexedDB: options.indexedDB } : {}),
    ...(options.IDBKeyRange ? { IDBKeyRange: options.IDBKeyRange } : {}),
  });
  db.declaredVersion = options.maxVersion ?? SCHEMA_VERSION;
  db.version(1).stores(V1_STORES);
  if (db.declaredVersion >= 2) {
    db.version(2)
      .stores(V2_STORES)
      .upgrade(async (tx) => {
        // If anything here throws, IndexedDB aborts the whole version change: the database
        // stays at version 1 with its data untouched.
        try {
          options.beforeUpgradeV2?.();
          await tx.table<FindingRecord, string>('findings').toCollection().modify((f) => {
            f.reviewStatus = 'open';
          });
        } catch (error) {
          db.migrationFailed = true;
          throw error;
        }
      });
  }
  return db;
}

export type OpenFailure = 'unavailable' | 'newer-version' | 'migration-failed' | 'blocked' | 'quota';
export type OpenResult = { ok: true } | { ok: false; reason: OpenFailure; message: string };

const OPEN_MESSAGES: Record<OpenFailure, string> = {
  unavailable:
    'This browser is not providing local storage (IndexedDB) to the app. Private or guest windows and some privacy settings disable it. Open AuditShield in a normal window of the same browser profile.',
  'newer-version':
    'The local database was created by a newer version of AuditShield. This version will not open it, to avoid damaging it. Use the newer app version, or restore a backup into a fresh browser profile.',
  'migration-failed':
    'Updating the local database to this version failed and was rolled back. Your data is unchanged in the previous format. Go back to the previous app version and export a backup before trying again.',
  blocked: 'Another AuditShield tab is using an older version of the database. Close the other tabs and reload.',
  quota: 'The browser refused to store more data for this site (storage is full). Free disk space or export a backup and remove old engagements.',
};

export function describeDbError(error: unknown): { reason: OpenFailure; message: string } {
  const names: string[] = [];
  for (let e = error as { name?: string; inner?: unknown } | undefined, i = 0; e && i < 4; e = e.inner as typeof e, i++) {
    if (e.name) names.push(e.name);
  }
  const has = (...wanted: string[]) => names.some((n) => wanted.includes(n));
  const reason: OpenFailure =
    has('VersionError') ? 'newer-version'
    : has('QuotaExceededError') ? 'quota'
    : has('MissingAPIError', 'InvalidStateError', 'SecurityError', 'UnknownError') ? 'unavailable'
    : has('UpgradeError', 'AbortError') ? 'migration-failed'
    : 'unavailable';
  return { reason, message: OPEN_MESSAGES[reason] };
}

/** Opens the database, turning every failure into a reason the UI can explain. Never throws. */
export async function openDb(db: AuditShieldDb): Promise<OpenResult> {
  let blocked = false;
  db.on('blocked', () => {
    blocked = true;
  });
  try {
    await db.open();
    // Dexie 4 will open a database created by a later schema version instead of failing. An older
    // app must not work on newer data, so that case is refused here, before anything is written.
    // (The native IndexedDB version is the Dexie version times ten.)
    const installed = Math.round(db.backendDB().version / 10);
    if (installed > db.declaredVersion) {
      db.close();
      return { ok: false, reason: 'newer-version', message: OPEN_MESSAGES['newer-version'] };
    }
    return { ok: true };
  } catch (error) {
    if (blocked) return { ok: false, reason: 'blocked', message: OPEN_MESSAGES.blocked };
    if (db.migrationFailed) return { ok: false, reason: 'migration-failed', message: OPEN_MESSAGES['migration-failed'] };
    return { ok: false, ...describeDbError(error) };
  }
}
