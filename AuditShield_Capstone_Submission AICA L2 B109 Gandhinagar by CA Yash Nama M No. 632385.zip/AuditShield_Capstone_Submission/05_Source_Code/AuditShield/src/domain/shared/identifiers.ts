/**
 * Indian identifier structure and checksum helpers. Pure functions, no I/O.
 * "Valid" here means "passes the published structure/check-digit rule". It never means the
 * identifier exists or belongs to anyone.
 */

const VERHOEFF_D = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 0, 6, 7, 8, 9, 5], [2, 3, 4, 0, 1, 7, 8, 9, 5, 6],
  [3, 4, 0, 1, 2, 8, 9, 5, 6, 7], [4, 0, 1, 2, 3, 9, 5, 6, 7, 8], [5, 9, 8, 7, 6, 0, 4, 3, 2, 1],
  [6, 5, 9, 8, 7, 1, 0, 4, 3, 2], [7, 6, 5, 9, 8, 2, 1, 0, 4, 3], [8, 7, 6, 5, 9, 3, 2, 1, 0, 4],
  [9, 8, 7, 6, 5, 4, 3, 2, 1, 0],
] as const;
const VERHOEFF_P = [
  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 5, 7, 6, 2, 8, 3, 0, 9, 4], [5, 8, 0, 3, 7, 9, 6, 1, 4, 2],
  [8, 9, 1, 6, 0, 4, 3, 5, 2, 7], [9, 4, 5, 3, 1, 2, 6, 8, 7, 0], [4, 2, 8, 6, 5, 7, 3, 9, 0, 1],
  [2, 7, 9, 3, 8, 0, 6, 4, 1, 5], [7, 0, 4, 6, 9, 1, 3, 2, 5, 8],
] as const;

/** Verhoeff check over a digit string (Aadhaar uses it for its 12th digit). */
export function verhoeffValid(digits: string): boolean {
  if (!/^\d+$/.test(digits)) return false;
  let c = 0;
  const reversed = [...digits].reverse();
  for (let i = 0; i < reversed.length; i++) {
    c = VERHOEFF_D[c]?.[VERHOEFF_P[i % 8]?.[Number(reversed[i])] ?? 0] ?? 0;
  }
  return c === 0;
}

const GSTIN_CHARSET = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
export const GSTIN_STRUCTURE = /^\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]$/;

/** Check character for the first 14 characters of a GSTIN (upper-case). */
export function gstinCheckChar(first14: string): string {
  let sum = 0;
  for (let i = 0; i < 14; i++) {
    const v = GSTIN_CHARSET.indexOf(first14[i] ?? '');
    if (v < 0) return '';
    const prod = v * (i % 2 === 0 ? 1 : 2);
    sum += Math.floor(prod / 36) + (prod % 36);
  }
  return GSTIN_CHARSET[(36 - (sum % 36)) % 36] ?? '';
}

/** Structure and check character both pass. Input must already be upper-case without separators. */
export function isValidGstin(gstin: string): boolean {
  return GSTIN_STRUCTURE.test(gstin) && gstinCheckChar(gstin.slice(0, 14)) === gstin[14];
}

/** Fourth character encodes the holder type; only these letters are issued. */
export const PAN_STRUCTURE = /^[A-Z]{3}[ABCFGHLJPT][A-Z]\d{4}[A-Z]$/;
export const isValidPan = (pan: string): boolean => PAN_STRUCTURE.test(pan);

/** PAN embedded in characters 3–12 of a GSTIN, or null unless the GSTIN itself is valid. */
export function panFromGstin(gstin: string): string | null {
  return isValidGstin(gstin) ? gstin.slice(2, 12) : null;
}

/** Luhn check for payment-card numbers (13+ digits). Non-digits are ignored. */
export function luhnValid(value: string): boolean {
  const s = value.replace(/\D/g, '');
  let sum = 0;
  let alt = false;
  for (let i = s.length - 1; i >= 0; i--) {
    let n = Number(s[i]);
    if (alt) {
      n *= 2;
      if (n > 9) n -= 9;
    }
    sum += n;
    alt = !alt;
  }
  return s.length >= 13 && sum % 10 === 0;
}

/** Zero code points of the decimal digit blocks used by Indian scripts. */
const INDIC_ZEROES = [0x0966, 0x09e6, 0x0a66, 0x0ae6, 0x0b66, 0x0be6, 0x0c66, 0x0ce6, 0x0d66];

/** Converts Indian-script decimal digits to ASCII digits; other characters are untouched. */
export function asciiDigits(text: string): string {
  let out = '';
  for (const ch of text) {
    const cp = ch.codePointAt(0) ?? 0;
    const zero = INDIC_ZEROES.find((z) => cp >= z && cp <= z + 9);
    out += zero === undefined ? ch : String(cp - zero);
  }
  return out;
}
