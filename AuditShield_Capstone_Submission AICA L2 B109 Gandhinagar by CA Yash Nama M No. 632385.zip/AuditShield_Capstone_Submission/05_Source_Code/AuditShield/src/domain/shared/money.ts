/**
 * Money is carried as integer paise (1 INR = 100 paise) inside Number.MAX_SAFE_INTEGER.
 * Nothing in the domain layer does arithmetic on fractional rupees.
 */

export type ParseResult<T> = { ok: true; value: T } | { ok: false; error: string };

const PLAIN = /^-?\d+(\.\d{1,2})?$/;
/** Indian (1,25,000) or international (125,000) digit grouping, optional paise. */
const GROUPED = /^-?\d{1,3}(,\d{2,3})*,\d{3}(\.\d{1,2})?$/;

/**
 * Parses a rupee amount written as text into integer paise.
 * Rejects empty input, more than two decimals, exponent notation, stray characters and values
 * whose paise would exceed the safe integer range.
 */
export function parseRupeesToPaise(input: string | number): ParseResult<number> {
  const text = (typeof input === 'number' ? String(input) : input).trim();
  if (text === '') return { ok: false, error: 'Amount is empty' };
  if (!PLAIN.test(text) && !GROUPED.test(text)) {
    return { ok: false, error: `"${text}" is not a rupee amount with at most two decimals` };
  }
  const negative = text.startsWith('-');
  const [whole = '0', fraction = ''] = text.replace(/^-/, '').replace(/,/g, '').split('.');
  const paise = BigInt(whole) * 100n + BigInt(fraction.padEnd(2, '0'));
  if (paise > BigInt(Number.MAX_SAFE_INTEGER)) return { ok: false, error: 'Amount is too large to store safely' };
  return { ok: true, value: Number(negative ? -paise : paise) };
}

/** Adds paise values and throws rather than silently losing precision. */
export function sumPaise(values: Iterable<number>): number {
  let total = 0;
  for (const v of values) {
    if (!Number.isSafeInteger(v)) throw new RangeError('Paise value is not a safe integer');
    total += v;
    if (!Number.isSafeInteger(total)) throw new RangeError('Paise total exceeds the safe integer range');
  }
  return total;
}

/** ₹ with Indian digit grouping. Paise are shown only when non-zero. */
export function formatINR(paise: number): string {
  const negative = paise < 0;
  const abs = Math.abs(paise);
  const rupees = String(Math.floor(abs / 100));
  const fraction = abs % 100;
  const last3 = rupees.slice(-3);
  const rest = rupees.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return `${negative ? '-' : ''}₹${rest ? `${rest},` : ''}${last3}${fraction ? `.${String(fraction).padStart(2, '0')}` : ''}`;
}
