/** Business dates are ISO calendar dates (YYYY-MM-DD) with no time zone. */

const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;

/** True only for a real calendar date written exactly as YYYY-MM-DD. */
export function isIsoDate(value: string): boolean {
  const m = ISO_DATE.exec(value);
  if (!m) return false;
  const d = new Date(`${value}T00:00:00Z`);
  return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === value;
}

/** Days since the Unix epoch for an ISO date. Caller guarantees validity. */
export const dayNumber = (isoDate: string): number =>
  Math.floor(new Date(`${isoDate}T00:00:00Z`).getTime() / 86_400_000);

/** 0 = Sunday … 6 = Saturday. */
export const weekday = (isoDate: string): number => new Date(`${isoDate}T00:00:00Z`).getUTCDay();
