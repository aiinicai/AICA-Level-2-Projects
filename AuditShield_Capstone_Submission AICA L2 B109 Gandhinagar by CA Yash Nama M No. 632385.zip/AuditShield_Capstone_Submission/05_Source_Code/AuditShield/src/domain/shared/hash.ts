/**
 * FNV-1a 64-bit, hex encoded. A stable, synchronous identifier hash for fingerprints and cache
 * keys. It is NOT a cryptographic primitive and must never be used to protect data.
 */
export function stableHash(input: string): string {
  let h = 0xcbf29ce484222325n;
  for (const byte of new TextEncoder().encode(input)) {
    h ^= BigInt(byte);
    h = (h * 0x100000001b3n) & 0xffffffffffffffffn;
  }
  return h.toString(16).padStart(16, '0');
}
