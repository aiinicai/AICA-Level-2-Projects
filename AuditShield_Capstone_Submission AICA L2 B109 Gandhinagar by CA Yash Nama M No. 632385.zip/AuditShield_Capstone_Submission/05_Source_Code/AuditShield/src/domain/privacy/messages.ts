/** The exact chat messages that leave the gateway. Built in one place so one place can be checked. */

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export const SYSTEM_PROMPT =
  'You are assisting an audit and tax professional. Some details in the text have been replaced by codes in ' +
  'square brackets. Keep every code exactly as written, brackets included, and never guess what a code stands for.';

/**
 * System prompt, then any earlier masked turns, then the reviewed masked request.
 * Every element of the returned array is inspected by the outbound policy before dispatch.
 */
export function buildOutboundMessages(masked: string, history: readonly ChatMessage[] = []): ChatMessage[] {
  return [{ role: 'system', content: SYSTEM_PROMPT }, ...history.map((m) => ({ ...m })), { role: 'user', content: masked }];
}
