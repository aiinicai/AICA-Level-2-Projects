/**
 * Labelled evaluation of the detector: per-type true positives, false negatives, false positives.
 * A case counts a detection as correct only when both type and exact value match (case-insensitive).
 */
import { detect, type DetectOptions, type IdentifierType } from './detect';

export interface EvalCase {
  text: string;
  expected: readonly (readonly [IdentifierType, string])[];
}
export interface EvalCounts {
  tp: number;
  fp: number;
  fn: number;
}
export interface EvalRow {
  text: string;
  hit: string[];
  miss: string[];
  extra: string[];
}
export interface EvalReport extends EvalCounts {
  cases: number;
  labelled: number;
  recall: number;
  precision: number;
  perType: Partial<Record<IdentifierType, EvalCounts>>;
  rows: EvalRow[];
}

const keyOf = (type: string, value: string) => `${type}|${value.toLowerCase()}`;

export function evaluateDetector(cases: readonly EvalCase[], options: DetectOptions = {}): EvalReport {
  const perType: Partial<Record<IdentifierType, EvalCounts>> = {};
  const bump = (key: string, field: keyof EvalCounts) => {
    const type = key.split('|')[0] as IdentifierType;
    (perType[type] ??= { tp: 0, fp: 0, fn: 0 })[field]++;
  };
  let tp = 0;
  let fp = 0;
  let fn = 0;
  const rows = cases.map(({ text, expected }) => {
    const want = new Set(expected.map(([t, v]) => keyOf(t, v)));
    const got = new Set(detect(text, options).map((d) => keyOf(d.type, d.value)));
    const hit = [...want].filter((k) => got.has(k));
    const miss = [...want].filter((k) => !got.has(k));
    const extra = [...got].filter((k) => !want.has(k));
    hit.forEach((k) => bump(k, 'tp'));
    miss.forEach((k) => bump(k, 'fn'));
    extra.forEach((k) => bump(k, 'fp'));
    tp += hit.length;
    fn += miss.length;
    fp += extra.length;
    return { text, hit, miss, extra };
  });
  return {
    cases: cases.length,
    labelled: tp + fn,
    tp, fp, fn,
    recall: tp + fn ? tp / (tp + fn) : 1,
    precision: tp + fp ? tp / (tp + fp) : 1,
    perType,
    rows,
  };
}

/** The legacy 18-sentence built-in set, kept verbatim as the baseline corpus. Far too small to generalise from. */
export const BASELINE_EVAL_SET: readonly EvalCase[] = [
  { text: 'PAN of assessee is ABCPK1234D for AY 2026-27', expected: [['PAN', 'ABCPK1234D']] },
  { text: 'Pay Rs. 1,25,000 to M/s Ganesh Traders by 31 March', expected: [['ORG', 'M/s Ganesh Traders']] },
  { text: 'Contact Mr. Suresh Patil on 9876543210', expected: [['PERSON', 'Suresh Patil'], ['PHONE', '9876543210']] },
  { text: 'Mail invoice to accounts@deccansteel.co.in', expected: [['EMAIL', 'accounts@deccansteel.co.in']] },
  { text: 'Credit to A/c No. 123456789012 IFSC SBIN0001234', expected: [['BANK_AC', '123456789012'], ['IFSC', 'SBIN0001234']] },
  { text: 'Pay via UPI rakesh.m@okhdfcbank today', expected: [['UPI', 'rakesh.m@okhdfcbank']] },
  { text: 'GSTIN 27AAKCS4321M1Z1 filed GSTR-1 late', expected: [['GSTIN', '27AAKCS4321M1Z1']] },
  { text: 'Smt. Lata Joshi W/o Ramesh Joshi signed the form', expected: [['PERSON', 'Lata Joshi'], ['PERSON', 'Ramesh Joshi']] },
  { text: 'Invoice INV-2026-00981 dated 05-04-2026 for Rs 45,000', expected: [] },
  { text: 'Total turnover 4,82,35,000 for FY 2025-26', expected: [] },
  { text: 'Partner: Neha Agarwal of Agarwal & Associates', expected: [['PERSON', 'Neha Agarwal'], ['ORG', 'Agarwal & Associates']] },
  { text: 'Call 022-24567890 or +91-9988776655', expected: [['PHONE', '+91-9988776655']] },
  { text: 'Shree Balaji Enterprises supplied 120 MT steel', expected: [['ORG', 'Shree Balaji Enterprises']] },
  { text: 'Account number 50100234567812 belongs to the vendor', expected: [['BANK_AC', '50100234567812']] },
  { text: 'Section 194C TDS at 2% on Rs. 3,40,000', expected: [] },
  { text: 'Reply by Dr. Arvind Rao, PAN AAAPR9087L, phone 9123456780', expected: [['PERSON', 'Arvind Rao'], ['PAN', 'AAAPR9087L'], ['PHONE', '9123456780']] },
  { text: 'the director ramesh gupta approved it', expected: [['PERSON', 'ramesh gupta']] },
  { text: 'Payee: Kiran Bhatt, paid by card 5500 0000 0000 0004', expected: [['PERSON', 'Kiran Bhatt'], ['CARD', '5500 0000 0000 0004']] },
];

/** The three legacy sample prompts (fictional), kept verbatim for the demo and for parity tests. */
export const SAMPLE_PROMPTS: Record<string, string> = {
  'GST notice reply': `Draft a reply to the GST notice below for our client.

Client: Shubham Textiles Pvt Ltd, GSTIN 27AAKCS4321M1Z1, PAN AAKCS4321M
Authorised signatory: Mr. Rajesh Kulkarni (Director), mobile +91 98201 45678, email rajesh.k@shubhamtextiles.in

Notice ref ASMT-10 dated 12-08-2026 states that ITC of Rs. 4,82,350 claimed in GSTR-3B for FY 2025-26 exceeds GSTR-2B by Rs. 1,12,900.
The difference relates to invoices from Mahalaxmi Traders (GSTIN 27ABHFM7788K1ZD) which filed GSTR-1 late.
Payments to Mahalaxmi Traders were made from HDFC A/c No. 50200012345678, IFSC HDFC0001234.`,
  'Vendor ledger review': `Review this vendor payment extract and tell me what looks suspicious.

Vendor: Sai Enterprises, PAN AFZPS1234Q, Bank a/c 60112233445566, IFSC SBIN0004567, UPI saient@okaxis
Proprietor: Shri Rohit Shinde, mobile 9822011107
Note: Rohit Shinde is also our employee in Accounts Payable (Employee name: Rohit Shinde).
Payments: 12-06-2025 Rs. 98,500; 18-07-2025 Rs. 99,200; 03-09-2025 Rs. 97,800 (approval limit Rs. 1,00,000)
All payments approved by Mrs. Anita Deshpande.`,
  'Payroll / KYC query': `Employee name: Priya Nair
Aadhaar: 7341 5298 0167, PAN BQNPN6655K
Salary credited to ICICI account 001101556677, IFSC ICIC0000011
Reimbursement claim of Rs. 46,000 submitted by Ms. Priya Nair; card used 4111 1111 1111 1111.
Question: Is this reimbursement taxable as a perquisite and how should it be shown in Form 16?`,
};
