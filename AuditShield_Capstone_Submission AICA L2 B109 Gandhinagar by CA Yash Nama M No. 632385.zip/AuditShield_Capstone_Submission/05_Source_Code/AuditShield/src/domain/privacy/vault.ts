/**
 * Session vault: pseudonym token <-> original value, held in memory for one gateway session.
 *
 * Tokens look like `[PERSON_1_K7F3]`. The last part is a random per-session namespace, so:
 *  - text typed by a user such as "[PERSON_1]" cannot collide with a real token;
 *  - tokens from another session are never recognised here.
 * Restoration is request-scoped (see restore): holding a vault entry is not enough to reveal it.
 */
import { findVariants, IDENTIFIER_TYPES, type IdentifierType } from './detect';

export const NAMESPACE_PATTERN = /^[A-Z0-9]{4}$/;
const TYPE_ALTERNATION = Object.keys(IDENTIFIER_TYPES).join('|');

/** Anything that looks like a pseudonym token from any session or from the legacy tool. */
export const TOKEN_LIKE = new RegExp(`\\[?\\b(?:${TYPE_ALTERNATION})_\\d+(?:_[A-Z0-9]{4})?\\b\\]?`, 'g');

export interface VaultEntry {
  token: string;
  type: IdentifierType;
  value: string;
}

function normaliseForVault(type: IdentifierType, value: string): string {
  if (type === 'AADHAAR' || type === 'CARD' || type === 'BANK_AC') return value.replace(/\D/g, '');
  if (type === 'PHONE') return value.replace(/\D/g, '').slice(-10);
  if (type === 'PAN' || type === 'GSTIN' || type === 'IFSC') return value.toUpperCase();
  return value.toLowerCase().replace(/^m\/s\.?\s+/, '').replace(/\s+/g, ' ').trim();
}

export class SessionVault {
  readonly namespace: string;
  private readonly byKey = new Map<string, string>();
  private readonly byToken = new Map<string, VaultEntry>();
  private readonly counters = new Map<IdentifierType, number>();

  constructor(namespace: string) {
    if (!NAMESPACE_PATTERN.test(namespace)) throw new Error('Vault namespace must be 4 characters A–Z / 0–9');
    this.namespace = namespace;
  }

  /** Same type + same normalised value always yields the same token within the session. */
  tokenFor(type: IdentifierType, value: string): string {
    const key = `${type}|${normaliseForVault(type, value)}`;
    const existing = this.byKey.get(key);
    if (existing) return existing;
    const n = (this.counters.get(type) ?? 0) + 1;
    this.counters.set(type, n);
    const token = `[${type}_${n}_${this.namespace}]`;
    this.byKey.set(key, token);
    this.byToken.set(token, { token, type, value });
    return token;
  }

  get(token: string): VaultEntry | undefined {
    return this.byToken.get(token);
  }
  entries(): VaultEntry[] {
    return [...this.byToken.values()];
  }
  get size(): number {
    return this.byToken.size;
  }

  /** Matches exactly this session's tokens. */
  tokenPattern(): RegExp {
    return new RegExp(`\\[(?:${TYPE_ALTERNATION})_\\d+_${this.namespace}\\]`, 'g');
  }
  /** This session's tokens that occur in `text` and exist in the vault. */
  tokensIn(text: string): string[] {
    return [...new Set(text.match(this.tokenPattern()) ?? [])].filter((t) => this.byToken.has(t));
  }
  /** `text` with this session's tokens blanked out, for re-inspection of what remains readable. */
  withoutTokens(text: string): string {
    return text.replace(this.tokenPattern(), ' ');
  }
}

export type RestoredSegment =
  | { kind: 'text'; text: string }
  | { kind: 'restored'; token: string; value: string; type: IdentifierType }
  | { kind: 'unknown-token'; text: string };

export interface Restoration {
  text: string;
  segments: RestoredSegment[];
  restoredTokens: string[];
  /** Token-shaped text that was not authorised for this request. Left exactly as received. */
  unknownTokens: string[];
}

/**
 * Replaces tokens with their original values, but only tokens in `authorised` — the tokens that
 * were actually sent in this request. A model that invents `[PERSON_2_K7F3]`, drops the brackets,
 * or echoes a token from an earlier request gets nothing back; the text is kept and reported.
 */
export function restore(text: string, vault: SessionVault, authorised: ReadonlySet<string>): Restoration {
  const segments: RestoredSegment[] = [];
  const restored = new Set<string>();
  const unknown = new Set<string>();
  let out = '';
  let last = 0;
  for (const m of text.matchAll(TOKEN_LIKE)) {
    const literal = m[0];
    if (m.index > last) segments.push({ kind: 'text', text: text.slice(last, m.index) });
    out += text.slice(last, m.index);
    const entry = authorised.has(literal) ? vault.get(literal) : undefined;
    if (entry) {
      segments.push({ kind: 'restored', token: literal, value: entry.value, type: entry.type });
      out += entry.value;
      restored.add(literal);
    } else {
      segments.push({ kind: 'unknown-token', text: literal });
      out += literal;
      unknown.add(literal);
    }
    last = m.index + literal.length;
  }
  if (last < text.length) segments.push({ kind: 'text', text: text.slice(last) });
  out += text.slice(last);
  return { text: out, segments, restoredTokens: [...restored], unknownTokens: [...unknown] };
}

/** Vault entries whose original value (any case/spacing variant) is readable in `text`. */
export function visibleVaultValues(text: string, vault: SessionVault): VaultEntry[] {
  return vault.entries().filter((e) => e.value.trim().length >= 3 && findVariants(text, e.value, false).length > 0);
}
