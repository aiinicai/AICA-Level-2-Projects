/**
 * Detection of Indian identifiers and names in free text. Pure functions.
 *
 * Ported from the legacy `AG.detect` and held to its baseline by tests/parity. Deliberate
 * differences (BC-12, BC-14):
 *  - an identifier-shaped value is reported even when its checksum fails, because a mistyped
 *    Aadhaar, card or GSTIN is still sensitive. `validity` and `confidence` are separate facts;
 *  - a PAN-shaped value with an unissued fourth letter is reported as an invalid PAN;
 *  - once a name is known, every case/spacing variant of it is reported;
 *  - user-selected text ("manual" terms) is reported wherever it occurs, in any script.
 *
 * Pattern matching cannot find every name. Lowercase names, names without a title, and names in
 * regional scripts are missed unless a watch-list or manual mask covers them.
 */
import { isValidGstin, luhnValid, PAN_STRUCTURE, verhoeffValid } from '../shared/identifiers';

export type IdentifierType =
  | 'AADHAAR' | 'CARD' | 'GSTIN' | 'PAN' | 'BANK_AC' | 'IFSC' | 'UPI' | 'EMAIL' | 'PHONE'
  | 'ORG' | 'PERSON' | 'CUSTOM' | 'MANUAL';

export type Risk = 'Critical' | 'High' | 'Medium';
/** Higher priority wins when two detections overlap. */
export const IDENTIFIER_TYPES: Record<IdentifierType, { label: string; risk: Risk; priority: number }> = {
  MANUAL: { label: 'Manually masked text', risk: 'High', priority: 11 },
  CUSTOM: { label: 'Watch-list term', risk: 'High', priority: 10 },
  AADHAAR: { label: 'Aadhaar number', risk: 'Critical', priority: 9 },
  CARD: { label: 'Card number', risk: 'Critical', priority: 9 },
  GSTIN: { label: 'GSTIN', risk: 'High', priority: 8 },
  PAN: { label: 'PAN', risk: 'High', priority: 7 },
  BANK_AC: { label: 'Bank account no.', risk: 'Critical', priority: 6 },
  IFSC: { label: 'IFSC', risk: 'Medium', priority: 6 },
  UPI: { label: 'UPI ID', risk: 'High', priority: 6 },
  EMAIL: { label: 'Email', risk: 'Medium', priority: 5 },
  PHONE: { label: 'Phone', risk: 'Medium', priority: 5 },
  ORG: { label: 'Organisation / client', risk: 'High', priority: 4 },
  PERSON: { label: 'Person name', risk: 'High', priority: 3 },
};

/**
 * `valid` / `invalid`: the value passes / fails the structure or check-digit rule for its type.
 * `unverifiable`: the type has no such rule (names, phones, account numbers).
 */
export type Validity = 'valid' | 'invalid' | 'unverifiable';
/** How strongly the surrounding evidence suggests this really is an identifier of that type. */
export type Confidence = 'high' | 'medium' | 'low';
export type DetectionSource = 'pattern' | 'watchlist' | 'manual' | 'propagated';

export interface Detection {
  type: IdentifierType;
  start: number;
  end: number;
  value: string;
  source: DetectionSource;
  validity: Validity;
  confidence: Confidence;
}

export interface DetectOptions {
  /** Terms the firm always wants hidden. Matched as case-insensitive substrings. */
  watchlist?: readonly string[];
  /** Text the user selected for masking in this request. Matched as case-insensitive substrings. */
  manualTerms?: readonly string[];
  /** Values already pseudonymised in this session; every whole-word variant is reported again. */
  knownValues?: readonly { type: IdentifierType; value: string }[];
}

export const MIN_TERM_LENGTH = 2;

/** Trims, drops blanks and duplicates, and separates terms too short to match safely. */
export function cleanTerms(terms: readonly string[] = []): { accepted: string[]; rejected: string[] } {
  const accepted: string[] = [];
  const rejected: string[] = [];
  const seen = new Set<string>();
  for (const raw of terms) {
    const term = raw.trim();
    const key = term.toLowerCase();
    if (!term || seen.has(key)) continue;
    seen.add(key);
    (term.length >= MIN_TERM_LENGTH ? accepted : rejected).push(term);
  }
  return { accepted, rejected };
}

type Assessment = { validity: Validity; confidence: Confidence };
interface Rule {
  type: IdentifierType;
  re: RegExp;
  group?: number;
  /** Returns null to discard the match. */
  assess?: (value: string, text: string, start: number) => Assessment | null;
  fallback: Assessment;
}

const before = (text: string, start: number, chars: number) => text.slice(Math.max(0, start - chars), start);

const ORG_SUFFIX =
  '(?:Private\\s+Limited|Pvt\\.?\\s*Ltd\\.?|Limited|Ltd\\.?|LLP|Traders|Trading\\s+Co\\.?|Enterprises|Industries|Agencies|Associates|Corporation|& Co\\.?|& Sons|Solutions|Exports|Textiles|Steels?)';

const RULES: Rule[] = [
  {
    type: 'AADHAAR', re: /\b[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}\b/g, fallback: { validity: 'unverifiable', confidence: 'medium' },
    assess: (m, text, start) => {
      const valid = verhoeffValid(m.replace(/\D/g, ''));
      const keyword = /aadha+r|uid/i.test(before(text, start, 30));
      const grouped = /\d[ -]\d/.test(m);
      // An ungrouped 12-digit run that fails the checksum and has no keyword is left to the
      // generic account-number rule, which masks it as a bank account.
      if (!valid && !keyword && !grouped) return null;
      return {
        validity: valid ? 'valid' : 'invalid',
        confidence: valid && (keyword || grouped) ? 'high' : valid || keyword ? 'medium' : 'low',
      };
    },
  },
  {
    type: 'CARD', re: /\b(?:\d{4}[ -]?){3}\d{1,7}\b/g, fallback: { validity: 'unverifiable', confidence: 'medium' },
    assess: (m, text, start) => {
      const keyword = /card/i.test(before(text, start, 25));
      const grouped = /\d{4}[ -]\d{4}[ -]\d{4}/.test(m);
      if (!keyword && !grouped) return null;
      const valid = luhnValid(m);
      return { validity: valid ? 'valid' : 'invalid', confidence: valid ? 'high' : 'low' };
    },
  },
  {
    type: 'GSTIN', re: /\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b/gi, fallback: { validity: 'unverifiable', confidence: 'medium' },
    assess: (m) => (isValidGstin(m.toUpperCase()) ? { validity: 'valid', confidence: 'high' } : { validity: 'invalid', confidence: 'medium' }),
  },
  {
    type: 'PAN', re: /\b[A-Z]{5}\d{4}[A-Z]\b/gi, fallback: { validity: 'unverifiable', confidence: 'medium' },
    assess: (m) => (PAN_STRUCTURE.test(m.toUpperCase()) ? { validity: 'valid', confidence: 'high' } : { validity: 'invalid', confidence: 'medium' }),
  },
  { type: 'IFSC', re: /\b[A-Z]{4}0[A-Z0-9]{6}\b/gi, fallback: { validity: 'valid', confidence: 'high' } },
  {
    type: 'BANK_AC', group: 1, fallback: { validity: 'unverifiable', confidence: 'high' },
    re: /(?:a\/c|acct|account|ac)\.?\s*(?:no\.?|number|#)?\s*[:\-]?\s*(\d[\d -]{7,20}\d)/gi,
  },
  { type: 'BANK_AC', re: /\b\d{11,18}\b/g, fallback: { validity: 'unverifiable', confidence: 'medium' } },
  {
    type: 'UPI', fallback: { validity: 'unverifiable', confidence: 'high' },
    re: /\b[\w.\-]{2,}@(?:ok[a-z]+|ybl|ibl|axl|paytm|upi|apl|icici|sbi|hdfcbank|axisbank|kotak)\b(?!\.)/gi,
  },
  { type: 'EMAIL', re: /\b[\w.+\-]+@[\w\-]+(?:\.[\w\-]+)+\b/g, fallback: { validity: 'unverifiable', confidence: 'high' } },
  { type: 'PHONE', re: /(?:\+91[\s-]?|\b0)?\b[6-9]\d{4}[\s-]?\d{5}\b/g, fallback: { validity: 'unverifiable', confidence: 'medium' } },
  {
    type: 'ORG', fallback: { validity: 'unverifiable', confidence: 'medium' },
    re: new RegExp(`(?:M\\/s\\.?\\s+)?\\b(?:(?:[A-Z][A-Za-z0-9&\\.\\-]*|&)[ \\t]+){1,5}${ORG_SUFFIX}`, 'g'),
  },
  {
    type: 'PERSON', group: 1, fallback: { validity: 'unverifiable', confidence: 'high' },
    re: /\b(?:Mr|Mrs|Ms|Miss|Shri|Shree|Smt|Sh|Kumari|Dr|CA|Adv)\.?[ \t]+((?:[A-Z][a-z]+|[A-Z]\.)(?:[ \t]+(?:[A-Z][a-z]+|[A-Z]\.)){0,3})/g,
  },
  {
    type: 'PERSON', group: 1, fallback: { validity: 'unverifiable', confidence: 'high' },
    re: /\b(?:S\/o|D\/o|W\/o|C\/o)\.?[ \t]+((?:[A-Z][a-z]+)(?:[ \t]+[A-Z][a-z]+){0,3})/g,
  },
  {
    type: 'PERSON', group: 1, fallback: { validity: 'unverifiable', confidence: 'medium' },
    re: /\b(?:[Nn]ame|[Pp]roprietor|[Pp]artner|[Dd]irector|[Ee]mployee|[Pp]ayee|[Aa]ssessee|[Tt]axpayer)[ \t]*[:\-][ \t]*((?:(?:Mr|Mrs|Ms|Shri|Smt|Dr)\.?[ \t]+)?(?:[A-Z][a-z]+)(?:[ \t]+[A-Z][a-z]+){1,3})/g,
  },
];

const NOT_NAMES = new Set(['Assessment Year', 'Financial Year', 'Income Tax', 'Goods And', 'Section', 'Notice', 'Dear Sir']);
const escapeRegExp = (s: string) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/** Regex for a known value: case-insensitive, any whitespace run between its words. */
function variantPattern(value: string, wholeWord: boolean): RegExp {
  const body = value.trim().split(/\s+/).map(escapeRegExp).join('\\s+');
  // Unicode-aware boundaries: \b only understands ASCII word characters.
  return new RegExp(wholeWord ? `(?<![\\p{L}\\p{N}])${body}(?![\\p{L}\\p{N}])` : body, 'giu');
}

/** Every occurrence of a known value, as [start, end, matchedText]. Used by masking and leak checks. */
export function findVariants(text: string, value: string, wholeWord: boolean): [number, number, string][] {
  if (!value.trim()) return [];
  return [...text.matchAll(variantPattern(value, wholeWord))].map((m) => [m.index, m.index + m[0].length, m[0]]);
}

export function detect(text: string, options: DetectOptions = {}): Detection[] {
  const found: Detection[] = [];

  for (const term of cleanTerms(options.manualTerms).accepted) {
    for (const [start, end, value] of findVariants(text, term, false)) {
      found.push({ type: 'MANUAL', start, end, value, source: 'manual', validity: 'unverifiable', confidence: 'high' });
    }
  }
  for (const term of cleanTerms(options.watchlist).accepted) {
    for (const [start, end, value] of findVariants(text, term, false)) {
      found.push({ type: 'CUSTOM', start, end, value, source: 'watchlist', validity: 'unverifiable', confidence: 'high' });
    }
  }

  for (const known of options.knownValues ?? []) {
    if (known.value.trim().length < 3) continue;
    for (const [start, end, value] of findVariants(text, known.value, true)) {
      found.push({ type: known.type, start, end, value, source: 'propagated', validity: 'unverifiable', confidence: 'high' });
    }
  }

  for (const rule of RULES) {
    rule.re.lastIndex = 0;
    for (let m = rule.re.exec(text); m; m = rule.re.exec(text)) {
      let value = m[0];
      let start = m.index;
      if (rule.group) {
        value = m[rule.group] ?? '';
        start = m.index + m[0].lastIndexOf(value);
      }
      value = value.replace(/[\s.,]+$/, '');
      if (rule.type === 'PERSON') {
        const title = /^(?:Mr|Mrs|Ms|Shri|Smt|Dr)\.?[ \t]+/.exec(value);
        if (title) {
          value = value.slice(title[0].length);
          start += title[0].length;
        }
        if (NOT_NAMES.has(value)) continue;
      }
      const assessment = rule.assess ? rule.assess(value, text, start) : rule.fallback;
      if (!assessment) continue;
      found.push({ type: rule.type, start, end: start + value.length, value, source: 'pattern', ...assessment });
    }
  }

  // Propagate: once a name or organisation is known, hide every other mention of it too.
  const known = new Map<string, Detection>();
  for (const d of found) {
    if (d.type === 'PERSON' || d.type === 'ORG') known.set(d.value, known.get(d.value) ?? d);
  }
  for (const [value, origin] of known) {
    const core = value.replace(/^M\/s\.?\s+/i, '');
    for (const [start, end, matched] of findVariants(text, core, true)) {
      found.push({ ...origin, start, end, value: matched, source: 'propagated' });
    }
  }

  // Resolve overlaps: higher priority wins, then the longer match.
  const pr = (d: Detection) => IDENTIFIER_TYPES[d.type].priority;
  const len = (d: Detection) => d.end - d.start;
  found.sort((a, b) => a.start - b.start || pr(b) - pr(a) || len(b) - len(a));
  const kept: Detection[] = [];
  for (const d of found) {
    const clash = kept.findIndex((k) => d.start < k.end && k.start < d.end);
    if (clash === -1) {
      kept.push(d);
      continue;
    }
    const k = kept[clash] as Detection;
    if (pr(d) > pr(k) || (pr(d) === pr(k) && len(d) > len(k))) kept[clash] = d;
  }
  kept.sort((a, b) => a.start - b.start);
  return kept.filter((d, i) => !(i > 0 && d.start < (kept[i - 1] as Detection).end));
}
