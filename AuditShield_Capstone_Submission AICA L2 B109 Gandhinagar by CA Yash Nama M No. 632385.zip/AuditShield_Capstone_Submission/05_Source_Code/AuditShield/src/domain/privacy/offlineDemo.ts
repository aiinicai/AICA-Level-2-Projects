/**
 * Offline demo "AI": a deterministic template reply built only from the masked prompt.
 * It is not a model and makes no network call. Ported from the legacy `AG.mockAI` so the demo
 * works without internet; the wording now says plainly that it is a canned response.
 */
const tokensOf = (masked: string, type: string): string[] => [
  ...new Set(masked.match(new RegExp(`\\[${type}_\\d+(?:_[A-Z0-9]{4})?\\]`, 'g')) ?? []),
];

export function offlineDemoReply(masked: string): string {
  const orgs = [...tokensOf(masked, 'ORG'), ...tokensOf(masked, 'CUSTOM')];
  const people = tokensOf(masked, 'PERSON');
  const gstins = tokensOf(masked, 'GSTIN');
  const pans = tokensOf(masked, 'PAN');
  const accounts = tokensOf(masked, 'BANK_AC');
  const aadhaar = tokensOf(masked, 'AADHAAR');
  const amounts = [...new Set(masked.match(/(?:₹|Rs\.?|INR)\s?[\d,]+(?:\.\d+)?/g) ?? [])];

  const lines: string[] = ['Summary (offline demo response, generated locally from the masked text)'];
  if (orgs.length) lines.push(`- Entities involved: ${orgs.join(', ')}${gstins.length ? ` (GSTIN ${gstins.join(', ')})` : ''}.`);
  if (people.length) lines.push(`- Individuals referred to: ${people.join(', ')}${pans.length ? `; PAN references: ${pans.join(', ')}` : ''}.`);
  if (amounts.length) lines.push(`- Amounts mentioned: ${amounts.slice(0, 6).join(', ')}.`);
  lines.push('', 'Observations');
  if (/notice|143|148|demand|show cause|ASMT|DRC/i.test(masked)) {
    lines.push(`- This is a tax notice/demand. Prepare a point-wise reply for ${orgs[0] ?? 'the client'}, attach reconciliations, and track the response due date.`);
  }
  if (accounts.length) {
    lines.push(`- Bank account ${accounts[0]} appears in the data${accounts.length > 1 ? ` along with ${accounts.slice(1).join(', ')}` : ''}. Confirm it matches the vendor master and cancelled cheque on file.`);
  }
  if (accounts.length && people.length && orgs.length && /employee|staff/i.test(masked)) {
    lines.push(`- ${people[0]} appears linked to a payee account. Check for a conflict of interest / employee-vendor relationship.`);
  }
  if (aadhaar.length) {
    lines.push(`- Aadhaar ${aadhaar[0]} is present. Under data-minimisation principles, keep only the masked form in the working papers.`);
  }
  if (/round|split|below|limit/i.test(masked)) {
    lines.push('- Payments just below approval limits or split invoices should be tested against the delegation-of-authority matrix.');
  }
  lines.push(`- Reconcile the figures with the books of ${orgs[0] ?? 'the entity'} and GSTR-2B / Form 26AS as applicable.`);
  lines.push('', 'Suggested next steps');
  lines.push(`1. Obtain supporting documents from ${people[0] ?? 'the responsible person'}.`);
  lines.push(`2. Draft the reply / workpaper note for ${orgs[0] ?? 'the client'} and have the engagement partner review it.`);
  lines.push('3. Record conclusions in the audit file.');
  return lines.join('\n');
}
