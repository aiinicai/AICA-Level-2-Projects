/**
 * Masking, outbound policy and scan approval. Pure functions.
 *
 * A scan is valid for exactly one combination of text, watch-list, manual masks, policy version,
 * destination and vault session. `scanKey` captures that combination; any change produces a
 * different key and the earlier review no longer authorises a send.
 *
 * The outbound check is an inspection of the exact text about to leave. It can prove that known
 * values and recognisable patterns are absent. It cannot prove that no identifying information
 * remains, and nothing here says so.
 */
import { cleanTerms, detect, type Detection, type DetectOptions, IDENTIFIER_TYPES, type IdentifierType } from './detect';
import { type SessionVault, visibleVaultValues } from './vault';

export const POLICY_VERSION = 'outbound-policy-1';

/** What the outbound check covers, shown to the user beside its result. */
export const CHECK_SCOPE = [
  'Known values: every value already in this session’s vault, in any letter case or spacing.',
  'Patterns: Aadhaar, card, GSTIN, PAN, bank account, IFSC, UPI, email, phone, titled or labelled names, organisation suffixes.',
  'Your watch-list and manually masked text.',
  'Not covered: names without a title or label, lowercase names, names in regional scripts, addresses, and anything not matching the patterns above. Read the outgoing text before approving it.',
] as const;

export interface MaskSpan {
  type: IdentifierType;
  token: string;
  value: string;
  /** Position in the source text. */
  start: number;
  end: number;
  /** Position in the masked text. */
  maskedStart: number;
  maskedEnd: number;
  detection: Detection;
}

export interface MaskResult {
  masked: string;
  spans: MaskSpan[];
  /** Distinct tokens present in `masked`. */
  tokens: string[];
}

export function maskText(text: string, vault: SessionVault, options: DetectOptions = {}): MaskResult {
  const spans: MaskSpan[] = [];
  let masked = '';
  let last = 0;
  // Values pseudonymised earlier in the session are masked again wherever they reappear.
  const knownValues = vault.entries().map((e) => ({ type: e.type, value: e.value }));
  for (const d of detect(text, { ...options, knownValues })) {
    masked += text.slice(last, d.start);
    const token = vault.tokenFor(d.type, d.value);
    spans.push({
      type: d.type, token, value: d.value, start: d.start, end: d.end,
      maskedStart: masked.length, maskedEnd: masked.length + token.length, detection: d,
    });
    masked += token;
    last = d.end;
  }
  masked += text.slice(last);
  return { masked, spans, tokens: [...new Set(spans.map((s) => s.token))] };
}

export type ViolationCode =
  | 'reserved-token-in-source'
  | 'vault-value-visible'
  | 'identifier-detected'
  | 'watchlist-term-visible'
  | 'manual-term-visible'
  | 'empty-request';

export interface OutboundViolation {
  code: ViolationCode;
  /** Safe to log: never contains the offending value. */
  message: string;
  /** The offending text, for local display only. Never write this to activity logs. */
  sensitiveExcerpt?: string;
}

/** Source text must not already contain this session's token syntax: it could not be told apart from a real token. */
export function checkSource(text: string, vault: SessionVault): OutboundViolation[] {
  const literal = text.match(vault.tokenPattern());
  return literal
    ? [{
        code: 'reserved-token-in-source',
        message: 'The text contains a placeholder in this session’s token format. Remove it or rephrase it.',
        sensitiveExcerpt: literal[0],
      }]
    : [];
}

/**
 * Inspects every part of an outbound body (system prompt, history, user message).
 * Returns an empty array only when nothing in scope was found.
 */
export function checkOutbound(parts: readonly string[], vault: SessionVault, options: DetectOptions = {}): OutboundViolation[] {
  const violations: OutboundViolation[] = [];
  const body = parts.join('\n');
  if (body.trim() === '') return [{ code: 'empty-request', message: 'There is no text to send.' }];
  const readable = vault.withoutTokens(body);

  for (const entry of visibleVaultValues(readable, vault)) {
    violations.push({
      code: 'vault-value-visible',
      message: `A value already replaced by ${entry.token} is still readable elsewhere in the outgoing text.`,
      sensitiveExcerpt: entry.value,
    });
  }
  for (const d of detect(readable, options)) {
    const label = IDENTIFIER_TYPES[d.type].label;
    violations.push({
      code: d.type === 'CUSTOM' ? 'watchlist-term-visible' : d.type === 'MANUAL' ? 'manual-term-visible' : 'identifier-detected',
      message: `${label} is still readable in the outgoing text.`,
      sensitiveExcerpt: d.value,
    });
  }
  return violations;
}

/* ---------------------------------------------------------------- destination and approval */

export type DestinationKind = 'offline-demo' | 'local-model' | 'external';
export interface Destination {
  providerId: string;
  kind: DestinationKind;
  /** Shown to the user on the Send action. */
  label: string;
  /** Full request URL, or null when nothing leaves the browser. */
  endpoint: string | null;
  model: string | null;
}

export interface ScanInputs {
  text: string;
  watchlist: readonly string[];
  manualTerms: readonly string[];
  policyVersion: string;
  destination: Destination;
  /** Namespace of the vault session the tokens belong to. */
  vaultNamespace: string;
}

/** Canonical identity of a scan. Equal keys ⇔ the same reviewed combination of inputs. */
export function scanKey(inputs: ScanInputs): string {
  const terms = (list: readonly string[]) => cleanTerms(list).accepted.map((t) => t.toLowerCase()).sort();
  const d = inputs.destination;
  return JSON.stringify([
    inputs.text,
    terms(inputs.watchlist),
    terms(inputs.manualTerms),
    inputs.policyVersion,
    [d.providerId, d.kind, d.endpoint, d.model],
    inputs.vaultNamespace,
  ]);
}

export interface ReviewedScan {
  key: string;
  inputs: ScanInputs;
  masked: string;
  spans: MaskSpan[];
  tokens: string[];
  violations: OutboundViolation[];
  /** Watch-list or manual terms ignored because they are shorter than the minimum length. */
  rejectedTerms: string[];
}

/** Masks the text and inspects the result. The outcome is bound to `inputs` through `key`. */
export function reviewScan(inputs: ScanInputs, vault: SessionVault): ReviewedScan {
  if (inputs.vaultNamespace !== vault.namespace) throw new Error('Scan inputs refer to a different vault session');
  const options: DetectOptions = { watchlist: inputs.watchlist, manualTerms: inputs.manualTerms };
  const source = checkSource(inputs.text, vault);
  const result = maskText(inputs.text, vault, options);
  return {
    key: scanKey(inputs),
    inputs: structuredClone(inputs),
    masked: result.masked,
    spans: result.spans,
    tokens: result.tokens,
    violations: [...source, ...checkOutbound([result.masked], vault, options)],
    rejectedTerms: [...cleanTerms(inputs.watchlist).rejected, ...cleanTerms(inputs.manualTerms).rejected],
  };
}
