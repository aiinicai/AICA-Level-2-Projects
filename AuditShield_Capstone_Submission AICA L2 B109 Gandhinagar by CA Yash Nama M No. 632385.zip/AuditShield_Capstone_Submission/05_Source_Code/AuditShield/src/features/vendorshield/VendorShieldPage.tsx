import { useLiveQuery } from 'dexie-react-hooks';
import { ArrowDownUp, CircleAlert, Database, Lock, Play, Save, Search } from 'lucide-react';
import { type FormEvent, useMemo, useState } from 'react';
import type { Navigate } from '../../app/App';
import { type EngagementData, useEngagementData, useFindings, useSetting, useStore, useUnlocked, useWorkpapers } from '../../app/store';
import {
  Badge, Button, Card, CardBody, CardHeader, EmptyState, Input, Label, Notice, PageHeader, Select, SeverityBadge, Stat, Textarea,
} from '../../components/ui/primitives';
import type { AnalysisRunRecord, FindingRecord, ImportRecord } from '../../data/db/schema';
import { type EngagementView, ImportValidationError, type WorkpaperView } from '../../data/repositories/repositories';
import { formatINR } from '../../domain/shared/money';
import { MATERIAL_STATUSES, REVIEW_LABEL, REVIEW_STATUSES, type ReviewStatus, reviewProblem } from '../../domain/vendor/review';
import { type ExportProfile, type Finding, MINIMAL_PROFILE, NAMED_PROFILE, type Severity } from '../../domain/vendor/types';
import { cn, formatInstant } from '../../lib/cn';
import { describeDbError } from '../../data/db/schema';
import { analyseSnapshot, DEFAULT_RETENTION_DAYS, protectAndCommit, SETTING } from '../../services/workspace/useCases';
import { Loading, WithEngagement } from '../engagements/NeedEngagement';
import { RelationshipGraph } from './RelationshipGraph';

const PROFILES: Record<ExportProfile['id'], ExportProfile> = { minimal: MINIMAL_PROFILE, named: NAMED_PROFILE };
const SEVERITIES: Severity[] = ['Critical', 'High', 'Medium', 'Low'];
const SEVERITY_RANK: Record<Severity, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };

const BASIS_TEXT: Record<Finding['amountBasis'], string> = {
  'vendor-payments': 'All payments to the vendor(s) in this finding. Vendor-wide spend to review, not a loss.',
  'listed-payments': 'Total of the payments listed below.',
  'repeat-payment': 'Amount of the later payment of the repeated invoice.',
  none: 'No payment amount applies to this finding.',
};

function PrepareCard({ engagement, data }: { engagement: EngagementView; data: EngagementData }) {
  const { state, repos, runtime } = useStore();
  const unlocked = useUnlocked();
  const retentionDays = useSetting(SETTING.retentionDays, DEFAULT_RETENTION_DAYS);
  const [profileId, setProfileId] = useState<ExportProfile['id']>(data.snapshot?.profile.id ?? 'minimal');
  const [retain, setRetain] = useState(false);
  const [busy, setBusy] = useState<'protect' | 'analyse' | null>(null);
  const [error, setError] = useState<string | null>(null);
  const source = state.source[engagement.id];
  const { snapshot, ruleConfig, run } = data;
  const days = retentionDays.ready ? retentionDays.value : DEFAULT_RETENTION_DAYS;
  const alreadySaved = Boolean(source && snapshot && snapshot.sourceDigest === source.digest && snapshot.profile.id === profileId);

  const protect = async () => {
    if (!source) return;
    setBusy('protect');
    setError(null);
    try {
      await protectAndCommit(repos, unlocked, {
        engagementId: engagement.id, raw: source.raw, sourceType: source.sourceType, sourceLabel: source.label,
        profile: PROFILES[profileId], key: await runtime.hmacKey(engagement.id), retainDays: retain ? days : null,
      });
    } catch (e) {
      setError(
        e instanceof ImportValidationError
          ? `Not saved: the data has ${e.errors.length} problem(s). First: ${e.errors[0]?.message ?? ''}.`
          : `Not saved. ${describeDbError(e).reason === 'quota' ? 'Browser storage is full.' : 'The snapshot could not be written.'} Nothing was changed.`,
      );
    } finally {
      setBusy(null);
    }
  };
  const run_ = async () => {
    if (!snapshot) return;
    setBusy('analyse');
    setError(null);
    try {
      await analyseSnapshot(repos, { engagementId: engagement.id, importId: snapshot.id, ruleConfig });
    } catch {
      setError('Analysis failed on this snapshot. No results were saved.');
    } finally {
      setBusy(null);
    }
  };

  return (
    <Card>
      <CardHeader
        title="Prepare and analyse"
        description="Protection replaces identifiers with keyed tokens built from an allowlist of fields and saves the result as a snapshot. Analysis reads the saved snapshot only."
      />
      <CardBody className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div>
          <p className="flex items-center gap-2 text-sm font-medium text-slate-900"><Database className="size-4 text-slate-500" aria-hidden /> 1. Source data</p>
          {source ? (
            <>
              <p className="mt-1 text-sm text-slate-600">
                {source.raw.vendors.length} vendors, {source.raw.employees.length} employees, {source.raw.directors.length} directors, {source.raw.payments.length} payments, in memory.
              </p>
              <p className="mt-1 text-xs text-slate-500">{source.label}</p>
            </>
          ) : (
            <p className="mt-1 text-sm text-slate-600">
              {snapshot?.sourceType === 'package'
                ? 'Received as a protected package. This workspace has no source data and no matching key; analysis runs on the tokens only.'
                : `Not in memory. ${snapshot ? 'The saved snapshot can still be analysed. To protect data again, load it on the Imports page.' : 'Load data on the Imports page.'}`}
            </p>
          )}
        </div>

        <div>
          <p className="flex items-center gap-2 text-sm font-medium text-slate-900"><Lock className="size-4 text-slate-500" aria-hidden /> 2. Protect and save</p>
          <Label htmlFor="profile" className="mt-2">Readable labels in the protected dataset</Label>
          <Select id="profile" value={profileId} onChange={(e) => setProfileId(e.target.value as ExportProfile['id'])} disabled={!source}>
            <option value="minimal">Minimal: record IDs and departments only</option>
            <option value="named">Named: also vendor and director names, DINs, invoice numbers</option>
          </Select>
          <p className="mt-2 text-xs text-slate-600">
            {profileId === 'minimal'
              ? 'Vendor, employee and director names, DINs and invoice numbers are left out or tokenised.'
              : 'Vendor and director names, DINs and invoice numbers stay readable. Employee names never do.'}
          </p>
          <label className="mt-3 flex items-start gap-2 text-sm text-slate-800">
            <input type="checkbox" className="mt-1 size-4 accent-indigo-700" checked={retain} disabled={!source} onChange={(e) => setRetain(e.target.checked)} />
            <span>
              Also keep an encrypted copy of the source data and its matching key
              <span className="block text-xs text-slate-600">
                Off by default. Stored only as ciphertext under the workspace key{days > 0 ? `, deleted automatically after ${days} days` : ', until you delete it'}. Without it, the source exists only in this tab.
              </span>
            </span>
          </label>
          <Button className="mt-3" onClick={() => void protect()} disabled={!source || busy !== null} variant={snapshot ? 'outline' : 'primary'}>
            <Lock aria-hidden /> {busy === 'protect' ? 'Protecting…' : snapshot ? 'Protect and save new snapshot' : 'Protect and save'}
          </Button>
          {alreadySaved ? <p className="mt-2 text-xs text-slate-600">This data is already saved with this profile; saving again adds an identical snapshot.</p> : null}
        </div>

        <div>
          <p className="flex items-center gap-2 text-sm font-medium text-slate-900"><Play className="size-4 text-slate-500" aria-hidden /> 3. Analyse</p>
          <p className="mt-1 text-sm text-slate-600">
            Approval limit {formatINR(ruleConfig.approvalLimitPaise)}, split window {ruleConfig.splitWindowDays} days. Change thresholds in Settings.
          </p>
          <Button className="mt-3" onClick={() => void run_()} disabled={!snapshot || busy !== null} variant={run ? 'outline' : 'primary'}>
            <Play aria-hidden /> {busy === 'analyse' ? 'Analysing…' : run ? 'Run again' : 'Run analysis'}
          </Button>
          {!snapshot ? <p className="mt-2 text-xs text-slate-600">Protect and save the data first.</p> : null}
          {run ? <p className="mt-2 text-xs text-slate-600">Last run {formatInstant(run.finishedAt)}. Every run is kept.</p> : null}
        </div>
      </CardBody>
      {error ? <CardBody className="pt-0"><Notice tone="error" icon={<CircleAlert aria-hidden />}>{error}</Notice></CardBody> : null}
      <CardBody className="border-t border-slate-200 text-xs text-slate-600">
        {snapshot?.sourceType === 'package'
          ? 'Auditor workspace: this engagement was opened from a protected package. Nothing here can turn a token back into a PAN, account or phone number.'
          : 'Preparer workspace. To separate client and auditor, export a protected package from the Imports page and open it in the auditor’s own workspace (another browser profile or computer).'}
      </CardBody>
    </Card>
  );
}

type SortKey = 'severity' | 'amount' | 'rule';

const REVIEW_TONE: Record<ReviewStatus, 'neutral' | 'info' | 'warn' | 'critical' | 'ok'> = {
  open: 'neutral', investigating: 'info', 'needs-information': 'warn', 'confirmed-issue': 'critical', 'false-positive': 'ok', closed: 'ok',
};

function ReviewForm({ finding, review }: { finding: FindingRecord; review: WorkpaperView | undefined }) {
  const { repos, clock } = useStore();
  const { workspace, dek } = useUnlocked();
  const [status, setStatus] = useState<ReviewStatus>(review?.status ?? 'open');
  const [notes, setNotes] = useState(review?.notes ?? '');
  const [conclusion, setConclusion] = useState(review?.conclusion ?? '');
  const [state, setState] = useState<{ kind: 'idle' | 'saving' | 'saved' } | { kind: 'error'; message: string }>({ kind: 'idle' });
  const dirty = status !== (review?.status ?? 'open') || notes !== (review?.notes ?? '') || conclusion !== (review?.conclusion ?? '');

  const save = async (e: FormEvent) => {
    e.preventDefault();
    const input = { status, notes: notes.trim(), conclusion: conclusion.trim() };
    const problem = reviewProblem(input);
    if (problem) return setState({ kind: 'error', message: problem });
    setState({ kind: 'saving' });
    try {
      await repos.workpapers.save(dek, workspace.id, finding.engagementId, finding.fingerprint, input, { id: clock.id(), at: clock.now() });
      setState({ kind: 'saved' });
    } catch {
      setState({ kind: 'error', message: 'Not saved. Your text is still here; try again.' });
    }
  };

  return (
    <form onSubmit={(e) => void save(e)} className="grid grid-cols-1 gap-3 rounded-md border border-slate-200 bg-slate-50 p-3" noValidate>
      <h3 className="font-medium text-slate-900">Auditor review</h3>
      <div>
        <Label htmlFor="rv-status">Status</Label>
        <Select id="rv-status" value={status} onChange={(e) => { setStatus(e.target.value as ReviewStatus); setState({ kind: 'idle' }); }}>
          {REVIEW_STATUSES.map((s) => <option key={s} value={s}>{REVIEW_LABEL[s]}</option>)}
        </Select>
      </div>
      <div>
        <Label htmlFor="rv-notes">Working notes</Label>
        <Textarea id="rv-notes" rows={3} value={notes} onChange={(e) => { setNotes(e.target.value); setState({ kind: 'idle' }); }} placeholder="What was checked, what was requested, what is outstanding." />
      </div>
      <div>
        <Label htmlFor="rv-conclusion">Conclusion{MATERIAL_STATUSES.includes(status) ? ' (required for this status)' : ''}</Label>
        <Textarea id="rv-conclusion" rows={3} value={conclusion} onChange={(e) => { setConclusion(e.target.value); setState({ kind: 'idle' }); }} aria-describedby="rv-state" />
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Button type="submit" size="sm" disabled={state.kind === 'saving' || (!dirty && state.kind !== 'error')}><Save aria-hidden /> {state.kind === 'saving' ? 'Saving…' : 'Save review'}</Button>
        <p id="rv-state" role={state.kind === 'error' ? 'alert' : 'status'} className={cn('text-xs', state.kind === 'error' ? 'text-red-700' : 'text-slate-600')}>
          {state.kind === 'error' ? state.message
            : dirty ? 'Unsaved changes.'
            : review ? `Saved: revision ${review.revision}, ${formatInstant(review.updatedAt)}. Stored encrypted.`
            : 'No review saved yet.'}
        </p>
      </div>
    </form>
  );
}

function FindingsTable({ findings, reviews, selected, onSelect }: { findings: FindingRecord[]; reviews: ReadonlyMap<string, WorkpaperView>; selected: string | null; onSelect: (fingerprint: string) => void }) {
  const [severity, setSeverity] = useState<'all' | Severity>('all');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState<{ key: SortKey; dir: 1 | -1 }>({ key: 'severity', dir: 1 });

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const filtered = findings.filter(
      (f) => (severity === 'all' || f.severity === severity) && (!q || `${f.ruleId} ${f.ruleName} ${f.title}`.toLowerCase().includes(q)),
    );
    const compare: Record<SortKey, (a: FindingRecord, b: FindingRecord) => number> = {
      severity: (a, b) => SEVERITY_RANK[a.severity] - SEVERITY_RANK[b.severity] || b.amountPaise - a.amountPaise,
      amount: (a, b) => b.amountPaise - a.amountPaise,
      rule: (a, b) => Number(a.ruleId.slice(1)) - Number(b.ruleId.slice(1)),
    };
    return [...filtered].sort((a, b) => compare[sort.key](a, b) * sort.dir);
  }, [findings, severity, query, sort]);

  const header = (key: SortKey, label: string, align = 'text-left') => (
    <th scope="col" className={cn('px-3 py-2 font-medium', align)} aria-sort={sort.key === key ? (sort.dir === 1 ? 'ascending' : 'descending') : 'none'}>
      <button
        type="button"
        className="inline-flex items-center gap-1 rounded focus-visible:outline-2 focus-visible:outline-indigo-600"
        onClick={() => setSort((s) => ({ key, dir: s.key === key ? (s.dir === 1 ? -1 : 1) : 1 }))}
      >
        {label} <ArrowDownUp className="size-3 text-slate-400" aria-hidden />
      </button>
    </th>
  );

  return (
    <Card className="min-w-0">
      <CardHeader title="Findings" description={`${rows.length} of ${findings.length} shown. Select a row for evidence.`} />
      <CardBody className="flex flex-wrap items-end gap-3 border-b border-slate-200">
        <div className="w-40">
          <Label htmlFor="f-sev">Severity</Label>
          <Select id="f-sev" value={severity} onChange={(e) => setSeverity(e.target.value as 'all' | Severity)}>
            <option value="all">All</option>
            {SEVERITIES.map((s) => <option key={s} value={s}>{s}</option>)}
          </Select>
        </div>
        <div className="min-w-48 flex-1">
          <Label htmlFor="f-q">Search rule or finding</Label>
          <div className="relative">
            <Search className="pointer-events-none absolute top-2.5 left-3 size-4 text-slate-400" aria-hidden />
            <Input id="f-q" className="pl-9" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. split, R9, V105" />
          </div>
        </div>
      </CardBody>
      <div className="overflow-x-auto">
        <table className="w-full min-w-[640px] text-sm">
          <thead className="bg-slate-50 text-xs text-slate-600">
            <tr>
              {header('severity', 'Severity')}
              {header('rule', 'Rule')}
              <th scope="col" className="px-3 py-2 text-left font-medium">Finding</th>
              <th scope="col" className="px-3 py-2 text-right font-medium">Payments</th>
              {header('amount', 'Amount', 'text-right')}
              <th scope="col" className="px-3 py-2 text-left font-medium">Review</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-200">
            {rows.map((f) => (
              <tr key={f.fingerprint} className={cn('align-top', selected === f.fingerprint ? 'bg-indigo-50' : 'hover:bg-slate-50')}>
                <td className="px-3 py-2"><SeverityBadge severity={f.severity} /></td>
                <td className="px-3 py-2 whitespace-nowrap text-slate-700">{f.ruleId}</td>
                <td className="px-3 py-2">
                  <button
                    type="button"
                    className="rounded text-left font-medium text-indigo-900 hover:underline focus-visible:outline-2 focus-visible:outline-indigo-600"
                    aria-pressed={selected === f.fingerprint}
                    onClick={() => onSelect(f.fingerprint)}
                  >
                    {f.title}
                  </button>
                  <p className="text-xs text-slate-600">{f.ruleName}</p>
                </td>
                <td className="px-3 py-2 text-right tabular-nums">{f.paymentIds.length || '—'}</td>
                <td className="px-3 py-2 text-right whitespace-nowrap tabular-nums">{f.amountBasis === 'none' ? '—' : formatINR(f.amountPaise)}</td>
                <td className="px-3 py-2"><Badge tone={REVIEW_TONE[reviews.get(f.fingerprint)?.status ?? 'open']}>{REVIEW_LABEL[reviews.get(f.fingerprint)?.status ?? 'open']}</Badge></td>
              </tr>
            ))}
            {rows.length === 0 ? (
              <tr><td colSpan={6} className="px-3 py-8 text-center text-slate-600">{findings.length === 0 ? 'The rules found nothing in this snapshot.' : 'No findings match these filters.'}</td></tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function FindingDetails({ finding, review }: { finding: FindingRecord; review: WorkpaperView | undefined }) {
  const { repos } = useStore();
  // Evidence is read from the stored snapshot the run was computed on.
  const evidence = useLiveQuery(async () => {
    const [payments, entities] = await Promise.all([
      repos.datasets.paymentsByIds(finding.importId, finding.paymentIds),
      repos.datasets.entities(finding.importId),
    ]);
    return { payments, labels: new Map(entities.map((e) => [`${e.kind}:${e.sourceRecordId}`, e.label])) };
  }, [finding.id]);
  const payments = evidence?.payments ?? [];
  const labelOf = (ref: string) => evidence?.labels.get(ref) ?? ref.slice(ref.indexOf(':') + 1);

  return (
    <Card aria-live="polite">
      <CardHeader title={finding.title} description={<span className="flex flex-wrap items-center gap-2"><SeverityBadge severity={finding.severity} /> {finding.ruleId} · {finding.ruleName}</span>} />
      <CardBody className="grid grid-cols-1 gap-4 text-sm">
        <div>
          <h3 className="font-medium text-slate-900">Why this was flagged</h3>
          <p className="mt-1 text-slate-700">{finding.explanation}</p>
          <p className="mt-2 text-xs text-slate-600">Indicator type: {finding.fraudType}. A red flag needs investigation; it is not a conclusion.</p>
        </div>
        <div>
          <h3 className="font-medium text-slate-900">Entities</h3>
          <ul className="mt-1 flex flex-wrap gap-2">
            {finding.entityRefs.map((r) => <li key={r}><Badge>{r.slice(0, r.indexOf(':'))}: {labelOf(r)}</Badge></li>)}
          </ul>
          {finding.matchedFields.length ? (
            <p className="mt-2 text-slate-700">Matched on keyed tokens of: {finding.matchedFields.map((f) => f.replace('_', ' ')).join(', ')}. The underlying values are not in this dataset.</p>
          ) : null}
        </div>
        <div>
          <h3 className="font-medium text-slate-900">Amount: {finding.amountBasis === 'none' ? 'not applicable' : formatINR(finding.amountPaise)}</h3>
          <p className="mt-1 text-xs text-slate-600">{BASIS_TEXT[finding.amountBasis]}</p>
        </div>
        <div>
          <h3 className="font-medium text-slate-900">Payment evidence ({finding.paymentIds.length})</h3>
          {finding.paymentIds.length === 0 ? <p className="mt-1 text-slate-600">This finding is about master data; no payments are linked.</p> : (
            <div className="mt-2 max-h-72 overflow-auto rounded border border-slate-200">
              <table className="w-full min-w-[420px] text-xs">
                <thead className="sticky top-0 bg-slate-50 text-slate-600">
                  <tr>
                    <th scope="col" className="px-2 py-1.5 text-left font-medium">Payment</th>
                    <th scope="col" className="px-2 py-1.5 text-left font-medium">Date</th>
                    <th scope="col" className="px-2 py-1.5 text-left font-medium">Vendor</th>
                    <th scope="col" className="px-2 py-1.5 text-left font-medium">Approver</th>
                    <th scope="col" className="px-2 py-1.5 text-right font-medium">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {payments.map((p) => (
                    <tr key={p.id}>
                      <td className="px-2 py-1.5 font-mono">{p.sourcePaymentId}</td>
                      <td className="px-2 py-1.5 whitespace-nowrap">{p.date}</td>
                      <td className="px-2 py-1.5">{p.vendorId}</td>
                      <td className="px-2 py-1.5">{p.approverRef || '—'}</td>
                      <td className="px-2 py-1.5 text-right tabular-nums">{formatINR(p.amountPaise)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <ReviewForm key={`${finding.fingerprint}:${review?.revision ?? 0}`} finding={finding} review={review} />
        <p className="font-mono text-xs text-slate-500">Finding reference {finding.fingerprint}</p>
      </CardBody>
    </Card>
  );
}

function Relationships({ run, findings, selected, onSelect }: { run: AnalysisRunRecord; findings: FindingRecord[]; selected: FindingRecord | null; onSelect: (fingerprint: string) => void }) {
  const graph = run.graph;
  const [view, setView] = useState<'graph' | 'list'>('graph');
  const groups = useMemo(() => {
    const nodeOf = new Map(graph.nodes.map((n) => [n.id, n]));
    const byTarget = new Map<string, string[]>();
    const direct: string[] = [];
    for (const e of graph.edges) {
      const source = nodeOf.get(e.source);
      const target = nodeOf.get(e.target);
      if (!source || !target) continue;
      if (target.kind === 'attribute') byTarget.set(target.id, [...(byTarget.get(target.id) ?? []), `${source.kind} ${source.label}`]);
      else direct.push(`${source.kind} ${source.label} created vendor ${target.label} and approved its payments`);
    }
    return { shared: [...byTarget].map(([id, members]) => ({ id, label: nodeOf.get(id)?.label ?? id, members })), direct };
  }, [graph]);

  return (
    <Card>
      <CardHeader
        title="Relationships"
        description={selected ? `Highlighting: ${selected.title}` : 'Every shared attribute and creator-approver link behind the findings. Select a finding to highlight it.'}
        actions={
          <div role="group" aria-label="Relationship view" className="flex gap-1">
            <Button size="sm" variant={view === 'graph' ? 'primary' : 'outline'} aria-pressed={view === 'graph'} onClick={() => setView('graph')}>Graph</Button>
            <Button size="sm" variant={view === 'list' ? 'primary' : 'outline'} aria-pressed={view === 'list'} onClick={() => setView('list')}>List</Button>
          </div>
        }
      />
      <CardBody>
        {view === 'graph' ? <RelationshipGraph run={run} findings={findings} selected={selected} onSelect={onSelect} /> : groups.shared.length + groups.direct.length === 0 ? <p className="text-sm text-slate-600">No shared attributes were found.</p> : (
          <ul className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
            {groups.shared.map((g) => (
              <li key={g.id} className="rounded border border-slate-200 px-3 py-2">
                <span className="font-medium text-slate-900">{g.label[0]?.toUpperCase()}{g.label.slice(1)}</span>
                <span className="text-slate-700">: {g.members.join(' · ')}</span>
              </li>
            ))}
            {groups.direct.map((d) => <li key={d} className="rounded border border-slate-200 px-3 py-2 text-slate-700">{d}</li>)}
          </ul>
        )}
      </CardBody>
    </Card>
  );
}

function Results({ snapshot, run }: { snapshot: ImportRecord; run: AnalysisRunRecord }) {
  const findings = useFindings(run.id);
  const reviews = useWorkpapers(run.engagementId);
  const [selected, setSelected] = useState<string | null>(null);
  if (!findings.ready || !reviews.ready) return <Loading label="Loading findings…" />;
  const finding = findings.value.find((f) => f.fingerprint === selected) ?? null;
  const s = run.summary;

  return (
    <>
      <p className="text-sm text-slate-600">
        Results of the run finished {formatInstant(run.finishedAt)} on the snapshot saved {formatInstant(snapshot.createdAt)}, engine {run.engineVersion}.
      </p>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Findings" value={s.findings} hint={SEVERITIES.map((sev) => `${s.bySeverity[sev]} ${sev.toLowerCase()}`).join(' · ')} />
        <Stat label="Population" value={`${s.vendors} vendors`} hint={`${s.payments} payments, ${s.employees} employees, ${s.directors} directors`} />
        <Stat label="Total paid" value={formatINR(s.totalPaidPaise)} hint="All payments in the snapshot" />
        <Stat
          label="Payments to vendors under review"
          value={formatINR(s.paymentsToVendorsUnderReviewPaise)}
          hint={`All payments to ${s.vendorsUnderReview.length} vendors with a Critical/High finding, each counted once. Not a loss estimate.`}
        />
      </div>
      <div className="grid grid-cols-1 gap-4 xl:grid-cols-[minmax(0,3fr)_minmax(0,2fr)]">
        <FindingsTable findings={findings.value} reviews={reviews.value} selected={selected} onSelect={setSelected} />
        {finding ? <FindingDetails key={finding.id} finding={finding} review={reviews.value.get(finding.fingerprint)} /> : (
          <EmptyState icon={<Search aria-hidden />} title="No finding selected">Select a finding to see why it was flagged and the payments behind it.</EmptyState>
        )}
      </div>
      <Relationships run={run} findings={findings.value} selected={finding} onSelect={setSelected} />
      <p className="text-xs text-slate-600">
        Scores and severities are heuristic review priorities, not fraud probabilities. Finding amounts overlap and must not be added together.
        Export the reviewed findings from the Workpapers page.
      </p>
    </>
  );
}

function VendorShield({ engagement, navigate }: { engagement: EngagementView; navigate: Navigate }) {
  const { state } = useStore();
  const data = useEngagementData(engagement.id);
  if (!data.ready) return <Loading />;
  const { snapshot, run } = data.value;
  const source = state.source[engagement.id];

  if (!source && !snapshot) {
    return (
      <EmptyState icon={<Database aria-hidden />} title="No data in this engagement" action={<Button onClick={() => navigate('imports')}>Go to Imports</Button>}>
        Load data on the Imports page, then protect and analyse it here.
      </EmptyState>
    );
  }
  return (
    <div className="grid grid-cols-1 gap-4">
      <PrepareCard engagement={engagement} data={data.value} />

      {source && snapshot && snapshot.sourceDigest !== source.digest ? (
        <Notice tone="warn" icon={<CircleAlert aria-hidden />} title="The source data in memory is not what the saved snapshot was built from">
          Anything shown below belongs to the snapshot saved {formatInstant(snapshot.createdAt)}, not to the data now loaded. Protect and save the loaded data
          to analyse it.
        </Notice>
      ) : null}

      {snapshot && snapshot.issues.length > 0 ? (
        <Notice tone="warn" icon={<CircleAlert aria-hidden />} title={`${snapshot.issues.length} data-quality warnings recorded with this snapshot`}>
          <ul className="list-disc pl-5">
            {snapshot.issues.slice(0, 8).map((i) => <li key={`${i.table}-${i.recordId}-${i.field}-${i.code}`}>{i.table} {i.recordId}, {i.field}: {i.message}</li>)}
          </ul>
          {snapshot.issues.length > 8 ? <p className="mt-1">…and {snapshot.issues.length - 8} more.</p> : null}
        </Notice>
      ) : null}

      {snapshot && run ? <Results key={run.id} snapshot={snapshot} run={run} /> : null}
      {snapshot && !run ? (
        <Notice icon={<Play aria-hidden />} title="This snapshot has not been analysed with the current thresholds">
          Run the analysis above. Runs made with other thresholds or on earlier snapshots remain stored and are not shown as current.
        </Notice>
      ) : null}
    </div>
  );
}

export function VendorShieldPage({ navigate }: { navigate: Navigate }) {
  return (
    <WithEngagement
      navigate={navigate}
      purpose="analyse vendor data"
      header={<PageHeader title="VendorShield" description="Ghost-vendor, related-party and payment-pattern indicators from deterministic rules R1–R10, computed on protected data." />}
    >
      {(engagement) => <VendorShield key={engagement.id} engagement={engagement} navigate={navigate} />}
    </WithEngagement>
  );
}
