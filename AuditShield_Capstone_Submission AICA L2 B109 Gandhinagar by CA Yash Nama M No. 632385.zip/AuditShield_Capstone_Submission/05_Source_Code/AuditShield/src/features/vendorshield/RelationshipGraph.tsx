/**
 * Relationship graph: vendors, employees and directors joined through the attributes they share
 * (as keyed tokens) and through "created and approved" links. Selecting a finding highlights its
 * entities; clicking an entity selects the most severe finding that involves it. Shapes and
 * letters, not colour alone, tell the entity kinds apart; the list view stays available.
 * Layout is a small deterministic force simulation, computed once per run.
 */
import { useMemo } from 'react';
import type { AnalysisRunRecord, FindingRecord } from '../../data/db/schema';
import type { GraphNode } from '../../domain/vendor/types';

const W = 760;
const H = 440;
const MAX_NODES = 160;

interface Placed extends GraphNode {
  x: number;
  y: number;
}

function layout(graph: AnalysisRunRecord['graph']): Placed[] {
  const nodes: Placed[] = graph.nodes.map((n, i) => {
    const a = (i / Math.max(1, graph.nodes.length)) * Math.PI * 2;
    return { ...n, x: W / 2 + Math.cos(a) * W * 0.32, y: H / 2 + Math.sin(a) * H * 0.32 };
  });
  const index = new Map(nodes.map((n, i) => [n.id, i]));
  const edges = graph.edges.map((e) => [index.get(e.source), index.get(e.target)] as const).filter((e): e is readonly [number, number] => e[0] !== undefined && e[1] !== undefined);
  const k = 70;
  for (let step = 0; step < 300; step++) {
    const fx = new Float64Array(nodes.length);
    const fy = new Float64Array(nodes.length);
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i] as Placed;
        const b = nodes[j] as Placed;
        const dx = a.x - b.x || 0.01;
        const dy = a.y - b.y || 0.01;
        const d2 = Math.max(dx * dx + dy * dy, 25);
        const f = (k * k) / d2;
        const d = Math.sqrt(d2);
        fx[i]! += (dx / d) * f; fy[i]! += (dy / d) * f;
        fx[j]! -= (dx / d) * f; fy[j]! -= (dy / d) * f;
      }
    }
    for (const [s, t] of edges) {
      const a = nodes[s] as Placed;
      const b = nodes[t] as Placed;
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const d = Math.sqrt(dx * dx + dy * dy) || 1;
      const f = (d - k) * 0.08;
      fx[s]! += (dx / d) * f; fy[s]! += (dy / d) * f;
      fx[t]! -= (dx / d) * f; fy[t]! -= (dy / d) * f;
    }
    const cool = 1 - step / 300;
    nodes.forEach((n, i) => {
      fx[i]! += (W / 2 - n.x) * 0.01;
      fy[i]! += (H / 2 - n.y) * 0.01;
      n.x = Math.min(W - 40, Math.max(40, n.x + Math.max(-10, Math.min(10, fx[i]!)) * cool));
      n.y = Math.min(H - 28, Math.max(24, n.y + Math.max(-10, Math.min(10, fy[i]!)) * cool));
    });
  }
  return nodes;
}

const SHAPE_FILL: Record<GraphNode['kind'], string> = {
  vendor: 'var(--color-indigo-700)', employee: 'var(--color-slate-600)', director: 'var(--color-indigo-400)', attribute: 'var(--color-slate-100)',
};

export function RelationshipGraph({ run, findings, selected, onSelect }: {
  run: AnalysisRunRecord; findings: FindingRecord[]; selected: FindingRecord | null; onSelect: (fingerprint: string) => void;
}) {
  const placed = useMemo(() => (run.graph.nodes.length <= MAX_NODES ? layout(run.graph) : null), [run]);
  if (!placed) return <p className="text-sm text-slate-600">The graph has more than {MAX_NODES} nodes; use the list below.</p>;
  if (placed.length === 0) return <p className="text-sm text-slate-600">No shared attributes were found, so there is nothing to draw.</p>;

  const byId = new Map(placed.map((n) => [n.id, n]));
  const lit = new Set(selected?.entityRefs ?? []);
  if (selected) {
    // Light the attribute nodes that connect two highlighted entities.
    for (const e of run.graph.edges) {
      const target = byId.get(e.target);
      if (target?.kind === 'attribute' && lit.has(e.source) && run.graph.edges.some((o) => o.target === e.target && o.source !== e.source && lit.has(o.source))) lit.add(e.target);
    }
  }
  const dim = (id: string) => (selected && !lit.has(id) ? 0.2 : 1);
  const pickFor = (nodeId: string) => {
    const hit = findings.find((f) => f.entityRefs.includes(nodeId));
    if (hit) onSelect(hit.fingerprint);
  };

  return (
    <figure className="m-0">
      <svg viewBox={`0 0 ${W} ${H}`} className="h-auto w-full rounded-md border border-slate-200 bg-white" role="img"
        aria-label={`Relationship graph with ${placed.filter((n) => n.kind !== 'attribute').length} entities and ${placed.filter((n) => n.kind === 'attribute').length} shared attributes${selected ? `; highlighting ${selected.title}` : ''}`}>
        {run.graph.edges.map((e, i) => {
          const a = byId.get(e.source);
          const b = byId.get(e.target);
          if (!a || !b) return null;
          const on = selected && lit.has(e.source) && lit.has(e.target);
          return (
            <line key={i} x1={a.x} y1={a.y} x2={b.x} y2={b.y} strokeWidth={on ? 3 : 1.5}
              stroke={on ? 'var(--color-red-600)' : 'var(--color-slate-300)'} strokeDasharray={e.relation === 'created-and-approved' ? '6 4' : undefined}
              opacity={selected && !on ? 0.25 : 1} />
          );
        })}
        {placed.map((n) => {
          if (n.kind === 'attribute') {
            const text = n.label.replace(/^same /, '');
            const w = text.length * 6.4 + 16;
            return (
              <g key={n.id} opacity={dim(n.id)}>
                <rect x={n.x - w / 2} y={n.y - 10} width={w} height={20} rx={10} fill={SHAPE_FILL.attribute} stroke="var(--color-slate-400)" />
                <text x={n.x} y={n.y + 4} textAnchor="middle" fontSize={11} fill="var(--color-slate-700)">{text}</text>
              </g>
            );
          }
          const r = n.kind === 'vendor' ? 12 + n.reviewPriority / 12 : 11;
          const letter = n.kind === 'vendor' ? 'V' : n.kind === 'employee' ? 'E' : 'D';
          return (
            <g key={n.id} opacity={dim(n.id)} className="cursor-pointer" onClick={() => pickFor(n.id)}>
              <title>{`${n.kind} ${n.label}${n.kind === 'vendor' && n.reviewPriority ? ` · review priority ${n.reviewPriority}` : ''}`}</title>
              {n.kind === 'director'
                ? <rect x={n.x - r} y={n.y - r} width={r * 2} height={r * 2} rx={3} fill={SHAPE_FILL.director} />
                : <circle cx={n.x} cy={n.y} r={r} fill={SHAPE_FILL[n.kind]} />}
              {n.flagged ? <circle cx={n.x} cy={n.y} r={r + 4} fill="none" stroke="var(--color-red-600)" strokeWidth={2} /> : null}
              <text x={n.x} y={n.y + 4} textAnchor="middle" fontSize={11} fontWeight={700} fill="#fff">{letter}</text>
              <text x={n.x} y={n.y + r + 15} textAnchor="middle" fontSize={11} fill="var(--color-slate-900)">{n.label.length > 26 ? `${n.label.slice(0, 25)}…` : n.label}</text>
            </g>
          );
        })}
      </svg>
      <figcaption className="mt-2 flex flex-wrap gap-x-5 gap-y-1 text-xs text-slate-600">
        <span>● V vendor (larger = higher review priority)</span><span>● E employee</span><span>■ D director</span>
        <span>pill = shared attribute (matched by token)</span><span>dashed = created vendor and approved its payments</span><span>red ring = in a finding</span>
        <span>Click an entity to open its finding.</span>
      </figcaption>
    </figure>
  );
}
