import { ArrowRight, FlaskConical, Plus } from 'lucide-react';
import { type FormEvent, useState } from 'react';
import { type Navigate, type Route, useSelectEngagement } from '../../app/App';
import { selectGateway } from '../../app/state';
import { useEngagementData, useEngagements, useStore, useUnlocked } from '../../app/store';
import { Badge, Button, Card, CardBody, CardHeader, Input, Label, Notice, PageHeader, Stat } from '../../components/ui/primitives';
import type { EngagementView } from '../../data/repositories/repositories';
import { formatINR } from '../../domain/shared/money';
import { SAMPLE_COMPANY_NAME } from '../../domain/vendor/sample';
import { formatInstant } from '../../lib/cn';
import { Loading } from '../engagements/NeedEngagement';
import { OpenPackageCard } from '../packages/PackageCards';

const FY_PATTERN = /^\d{4}-\d{2}$/;

function CreateEngagement() {
  const { repos, clock } = useStore();
  const { workspace, dek } = useUnlocked();
  const select = useSelectEngagement();
  const [name, setName] = useState('');
  const [fy, setFy] = useState('2025-26');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const create = async (input: { name: string; financialYear: string; kind: 'sample' | 'client' }) => {
    setBusy(true);
    setError(null);
    try {
      const record = await repos.engagements.create(dek, workspace.id, { id: clock.id(), at: clock.now() }, input, clock.id());
      select(record.id);
      setName('');
    } catch {
      setError('The engagement could not be saved. Nothing was changed; try again.');
    } finally {
      setBusy(false);
    }
  };
  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (name.trim().length < 2) return setError('Enter an engagement label of at least 2 characters.');
    if (!FY_PATTERN.test(fy.trim())) return setError('Financial year must look like 2025-26.');
    void create({ name, financialYear: fy, kind: 'client' });
  };

  return (
    <Card>
      <CardHeader title="New engagement" description="A label and financial year. The label is stored encrypted and shown only while the workspace is unlocked." />
      <CardBody>
        <form onSubmit={submit} className="grid grid-cols-1 gap-4 sm:grid-cols-[1fr_10rem_auto] sm:items-end" noValidate>
          <div>
            <Label htmlFor="eng-name">Engagement label</Label>
            <Input id="eng-name" value={name} onChange={(e) => setName(e.target.value)} aria-invalid={error ? true : undefined} aria-describedby={error ? 'eng-error' : undefined} autoComplete="off" />
          </div>
          <div>
            <Label htmlFor="eng-fy">Financial year</Label>
            <Input id="eng-fy" value={fy} onChange={(e) => setFy(e.target.value)} inputMode="numeric" autoComplete="off" />
          </div>
          <Button type="submit" disabled={busy}><Plus aria-hidden /> Create engagement</Button>
        </form>
        {error ? <p id="eng-error" role="alert" className="mt-2 text-sm text-red-700">{error}</p> : null}
        <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-200 pt-4">
          <Button variant="outline" disabled={busy} onClick={() => void create({ name: SAMPLE_COMPANY_NAME, financialYear: '2025-26', kind: 'sample' })}>
            <FlaskConical aria-hidden /> Create sample engagement
          </Button>
          <p className="text-sm text-slate-600">Synthetic data only, kept apart from client engagements.</p>
        </div>
      </CardBody>
    </Card>
  );
}

function EngagementSummary({ engagement, navigate }: { engagement: EngagementView; navigate: Navigate }) {
  const { state } = useStore();
  const data = useEngagementData(engagement.id);
  const gateway = selectGateway(state, engagement.id);
  if (!data.ready) return <Loading />;
  const { snapshot, run } = data.value;
  const summary = run?.summary;
  const sourceLoaded = state.source[engagement.id] !== undefined;

  const next: { text: string; route: Route; label: string } =
    !snapshot && !sourceLoaded ? { text: 'No data has been loaded for this engagement.', route: 'imports', label: 'Go to Imports' }
    : !snapshot ? { text: 'Source data is loaded in memory but not yet protected and saved.', route: 'vendorshield', label: 'Protect data' }
    : !run ? { text: 'A protected snapshot is saved and has not been analysed with the current thresholds.', route: 'vendorshield', label: 'Run analysis' }
    : { text: `${summary?.findings ?? 0} findings are waiting for review.`, route: 'vendorshield', label: 'Open findings' };

  return (
    <>
      <Card>
        <CardBody className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-medium tracking-wide text-slate-500 uppercase">Next action</p>
            <p className="mt-1 text-sm text-slate-800">{next.text}</p>
          </div>
          <Button onClick={() => navigate(next.route)}>{next.label} <ArrowRight aria-hidden /></Button>
        </CardBody>
      </Card>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          label="Saved snapshot"
          value={snapshot ? `${snapshot.rowCounts.vendors} vendors` : 'None'}
          hint={snapshot ? `${snapshot.rowCounts.payments} payments · saved ${formatInstant(snapshot.createdAt)}` : 'Load and protect data to create one'}
        />
        <Stat
          label="Analysis run"
          value={run ? `${summary?.findings} findings` : 'Not run'}
          hint={run ? `${formatInstant(run.finishedAt)} · current thresholds` : snapshot ? 'No run for the current thresholds' : '—'}
        />
        <Stat label="Critical / High" value={summary ? `${summary.bySeverity.Critical} / ${summary.bySeverity.High}` : '—'} hint="Indicators to investigate, not conclusions" />
        <Stat
          label="Payments to vendors under review"
          value={summary ? formatINR(summary.paymentsToVendorsUnderReviewPaise) : '—'}
          hint={summary ? `All payments to ${summary.vendorsUnderReview.length} vendors with a Critical/High finding. Not a loss estimate.` : '—'}
        />
      </div>

      <Card>
        <CardHeader title="AI Gateway" description="Drafts and answers are kept in memory only and are cleared on lock or reload." actions={<Button variant="outline" size="sm" onClick={() => navigate('gateway')}>Open gateway</Button>} />
        <CardBody className="text-sm text-slate-700">
          {gateway.outcome?.status === 'answered' ? 'The last request in this session was answered by the offline demo provider.'
            : gateway.scan ? `A scan is ready for review: ${gateway.scan.spans.length} items masked, ${gateway.scan.violations.length} unresolved checks.`
            : gateway.draft ? 'There is an unscanned draft.' : 'No draft in this session.'}
        </CardBody>
      </Card>
    </>
  );
}

export function OverviewPage({ navigate }: { navigate: Navigate }) {
  const { state } = useStore();
  const engagements = useEngagements();
  const select = useSelectEngagement();
  if (!engagements.ready) return <Loading />;
  const current = engagements.value.find((e) => e.id === state.currentId) ?? null;

  return (
    <>
      <PageHeader
        title="Overview"
        description={current ? <>{current.name} · FY {current.financialYear} · created {formatInstant(current.createdAt)}</> : 'Vendor analysis and AI masking for an engagement, in one local workspace.'}
      />
      <div className="grid grid-cols-1 gap-4">
        {engagements.value.length === 0 ? (
          <Notice title="Where your data is">
            Everything is stored in this browser profile on this computer and nothing is sent anywhere. Protected snapshots, results, settings and
            activity are saved automatically. Source data is kept only if you choose that when protecting it, and then only encrypted. Make an encrypted
            backup in Settings: clearing this site’s data would otherwise lose the workspace.
          </Notice>
        ) : null}

        {current ? <EngagementSummary engagement={current} navigate={navigate} /> : null}

        {engagements.value.length > 0 ? (
          <Card>
            <CardHeader title="Engagements" description="Each engagement’s records are stored and queried separately." />
            <CardBody className="p-0">
              <ul className="divide-y divide-slate-200">
                {engagements.value.map((e) => (
                  <li key={e.id} className="flex flex-wrap items-center justify-between gap-3 px-5 py-3">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-medium text-slate-900">{e.name}</p>
                      <p className="text-xs text-slate-600">FY {e.financialYear} · created {formatInstant(e.createdAt)}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      {e.kind === 'sample' ? <Badge tone="info">Synthetic sample</Badge> : null}
                      {e.id === current?.id ? <Badge tone="ok">Current</Badge> : <Button variant="outline" size="sm" onClick={() => select(e.id)}>Switch</Button>}
                    </div>
                  </li>
                ))}
              </ul>
            </CardBody>
          </Card>
        ) : null}

        <CreateEngagement />
        <OpenPackageCard navigate={navigate} />
      </div>
    </>
  );
}
