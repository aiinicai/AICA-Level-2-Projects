import { Briefcase } from 'lucide-react';
import type { ReactNode } from 'react';
import type { Navigate } from '../../app/App';
import { useCurrentEngagement } from '../../app/store';
import { Button, EmptyState } from '../../components/ui/primitives';
import type { EngagementView } from '../../data/repositories/repositories';

/** Shown by engagement-scoped screens when no engagement is selected. */
export function NeedEngagement({ navigate, purpose }: { navigate: Navigate; purpose: string }) {
  return (
    <EmptyState
      icon={<Briefcase aria-hidden />}
      title="No engagement selected"
      action={<Button onClick={() => navigate('overview')}>Go to Overview</Button>}
    >
      Create or choose an engagement on the Overview page to {purpose}.
    </EmptyState>
  );
}

export function Loading({ label = 'Loading…' }: { label?: string }) {
  return <p role="status" className="py-8 text-center text-sm text-slate-600">{label}</p>;
}

/** Renders `children` for the current engagement, or the right loading / empty state. */
export function WithEngagement({ navigate, purpose, header, children }: {
  navigate: Navigate; purpose: string; header?: ReactNode; children: (engagement: EngagementView) => ReactNode;
}) {
  const current = useCurrentEngagement();
  return (
    <>
      {header}
      {!current.ready ? <Loading /> : current.value ? children(current.value) : <NeedEngagement navigate={navigate} purpose={purpose} />}
    </>
  );
}
