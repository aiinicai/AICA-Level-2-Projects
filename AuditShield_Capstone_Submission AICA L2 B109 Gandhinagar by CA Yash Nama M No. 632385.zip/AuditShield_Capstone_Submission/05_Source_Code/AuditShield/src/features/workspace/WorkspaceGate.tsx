/**
 * Screens shown before the application itself: database problems, first-time setup (create a
 * workspace or restore a backup into this empty profile) and unlock.
 */
import { CircleAlert, FolderUp, KeyRound, LockKeyhole, ShieldCheck } from 'lucide-react';
import { type FormEvent, type ReactNode, useState } from 'react';
import { useStore } from '../../app/store';
import { Button, Card, CardBody, CardHeader, Input, Label, Notice } from '../../components/ui/primitives';
import type { OpenResult } from '../../data/db/schema';
import { type BackupHeader, BackupError, readBackupHeader, restoreBackup } from '../../services/backup/backup';
import { MIN_PASSPHRASE_LENGTH, passphraseProblem, WrongPassphraseError } from '../../services/crypto/envelope';
import { DEFAULT_AUTO_LOCK_MINUTES, SETTING, setupWorkspace, unlockWorkspace } from '../../services/workspace/useCases';
import { formatInstant } from '../../lib/cn';

function Frame({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen items-start justify-center bg-slate-50 px-4 py-10 text-slate-900">
      <main className="w-full max-w-xl">
        <div className="mb-6 flex items-center gap-2">
          <ShieldCheck className="size-6 text-indigo-800" aria-hidden />
          <span className="text-lg font-semibold">AuditShield</span>
        </div>
        {children}
      </main>
    </div>
  );
}

export function OpeningScreen() {
  return <Frame><p role="status" className="text-sm text-slate-600">Opening local storage…</p></Frame>;
}

export function DbErrorScreen({ result }: { result: Extract<OpenResult, { ok: false }> }) {
  const titles: Record<typeof result.reason, string> = {
    unavailable: 'Local storage is not available',
    'newer-version': 'This data was saved by a newer AuditShield',
    'migration-failed': 'The database update did not complete',
    blocked: 'AuditShield is open in another tab',
    quota: 'Storage is full',
  };
  return (
    <Frame>
      <Notice tone="error" icon={<CircleAlert aria-hidden />} title={titles[result.reason]}>
        <p>{result.message}</p>
        <p className="mt-2">Nothing was deleted or overwritten. Reload the page after resolving the cause.</p>
      </Notice>
      <Button className="mt-4" variant="outline" onClick={() => window.location.reload()}>Reload</Button>
    </Frame>
  );
}

function PassphraseFields({ id, passphrase, confirm, onPassphrase, onConfirm, error }: {
  id: string; passphrase: string; confirm: string; onPassphrase: (v: string) => void; onConfirm: (v: string) => void; error: string | null;
}) {
  return (
    <>
      <div>
        <Label htmlFor={`${id}-pass`}>Passphrase (at least {MIN_PASSPHRASE_LENGTH} characters)</Label>
        <Input id={`${id}-pass`} type="password" value={passphrase} onChange={(e) => onPassphrase(e.target.value)} autoComplete="new-password" aria-invalid={error ? true : undefined} aria-describedby={error ? `${id}-error` : undefined} />
      </div>
      <div>
        <Label htmlFor={`${id}-confirm`}>Repeat the passphrase</Label>
        <Input id={`${id}-confirm`} type="password" value={confirm} onChange={(e) => onConfirm(e.target.value)} autoComplete="new-password" />
      </div>
      {error ? <p id={`${id}-error`} role="alert" className="text-sm text-red-700">{error}</p> : null}
    </>
  );
}

function CreateWorkspace() {
  const { repos, session } = useStore();
  const [passphrase, setPassphrase] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const problem = passphraseProblem(passphrase) ?? (passphrase !== confirm ? 'The two passphrases are not the same.' : null);
    if (problem) return setError(problem);
    setBusy(true);
    setError(null);
    try {
      session.unlock(await setupWorkspace(repos, passphrase), DEFAULT_AUTO_LOCK_MINUTES);
    } catch {
      setError('The workspace could not be created. Nothing was saved; try again.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader title="Create a workspace" description="A workspace is this browser profile’s local database. Engagement labels and any source data you choose to keep are encrypted with a key protected by this passphrase." />
      <CardBody>
        <form onSubmit={submit} className="grid grid-cols-1 gap-4" noValidate>
          <PassphraseFields id="create" passphrase={passphrase} confirm={confirm} onPassphrase={setPassphrase} onConfirm={setConfirm} error={error} />
          <Notice tone="warn">
            There is no passphrase recovery. If it is lost, the encrypted parts of the workspace cannot be read, by anyone. Keep an encrypted backup
            (Settings) somewhere other than this computer.
          </Notice>
          <div><Button type="submit" disabled={busy}><KeyRound aria-hidden /> {busy ? 'Creating…' : 'Create workspace'}</Button></div>
        </form>
      </CardBody>
    </Card>
  );
}

function RestoreWorkspace() {
  const { db, repos, session, clock } = useStore();
  const [file, setFile] = useState<{ name: string; bytes: Uint8Array; header: BackupHeader } | null>(null);
  const [passphrase, setPassphrase] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const choose = async (selected: File | undefined) => {
    setError(null);
    setFile(null);
    if (!selected) return;
    try {
      const bytes = new Uint8Array(await selected.arrayBuffer());
      setFile({ name: selected.name, bytes, header: readBackupHeader(bytes).header });
    } catch (e) {
      setError(e instanceof BackupError ? e.message : 'The file could not be read.');
    }
  };
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (!file) return setError('Choose a backup file first.');
    setBusy(true);
    setError(null);
    try {
      const { dek } = await restoreBackup(db, file.bytes, { passphrase, at: clock.now(), auditId: clock.id() });
      const workspace = await repos.workspace.get();
      if (!workspace) throw new Error('restore did not create a workspace');
      session.unlock({ workspace, dek }, await repos.settings.get(SETTING.autoLockMinutes, DEFAULT_AUTO_LOCK_MINUTES));
    } catch (e) {
      setError(e instanceof BackupError ? e.message : 'The restore failed. Nothing was changed.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader title="Restore from a backup" description="Only into an empty profile like this one, so a restore can never overwrite existing work. The backup’s passphrase becomes this workspace’s passphrase." />
      <CardBody>
        <form onSubmit={submit} className="grid grid-cols-1 gap-4" noValidate>
          <div>
            <Label htmlFor="restore-file">Backup file (.asbackup)</Label>
            <input id="restore-file" type="file" accept=".asbackup,application/json" className="block w-full text-sm file:mr-3 file:rounded-md file:border file:border-slate-300 file:bg-white file:px-3 file:py-1.5 file:text-sm file:font-medium" onChange={(e) => void choose(e.target.files?.[0])} />
          </div>
          {file ? (
            <dl className="grid grid-cols-2 gap-x-4 gap-y-1 rounded-md border border-slate-200 bg-slate-50 p-3 text-sm" aria-label="Backup contents">
              <dt className="text-slate-600">Created</dt><dd>{formatInstant(file.header.createdAt)}</dd>
              <dt className="text-slate-600">App / data version</dt><dd>{file.header.appVersion} / {file.header.schemaVersion}</dd>
              <dt className="text-slate-600">Engagements</dt><dd>{file.header.counts['engagements'] ?? 0}</dd>
              <dt className="text-slate-600">Snapshots / payments</dt><dd>{file.header.counts['imports'] ?? 0} / {file.header.counts['payments'] ?? 0}</dd>
              <dt className="text-slate-600">Runs / findings</dt><dd>{file.header.counts['analysisRuns'] ?? 0} / {file.header.counts['findings'] ?? 0}</dd>
              <dt className="text-slate-600">Retained source data</dt><dd>{file.header.includesRetainedSource ? `included (${file.header.counts['rawPayloads'] ?? 0})` : 'not included'}</dd>
            </dl>
          ) : null}
          <div>
            <Label htmlFor="restore-pass">Backup passphrase</Label>
            <Input id="restore-pass" type="password" value={passphrase} onChange={(e) => setPassphrase(e.target.value)} autoComplete="off" />
          </div>
          {error ? <p role="alert" className="text-sm text-red-700">{error}</p> : null}
          <div><Button type="submit" variant="outline" disabled={busy || !file || passphrase === ''}><FolderUp aria-hidden /> {busy ? 'Restoring…' : 'Restore backup'}</Button></div>
        </form>
      </CardBody>
    </Card>
  );
}

export function SetupScreen() {
  return (
    <Frame>
      <h1 className="text-xl font-semibold">Set up this browser profile</h1>
      <p className="mt-1 mb-6 text-sm text-slate-600">
        AuditShield stores its data in this browser profile on this computer and sends nothing anywhere. Clearing site data for this address, or using a
        different browser, profile or address, starts from empty; that is what backups are for.
      </p>
      <div className="grid grid-cols-1 gap-4">
        <CreateWorkspace />
        <RestoreWorkspace />
      </div>
    </Frame>
  );
}

export function UnlockScreen() {
  const { repos, session } = useStore();
  const [passphrase, setPassphrase] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const unlocked = await unlockWorkspace(repos, passphrase);
      session.unlock(unlocked, await repos.settings.get(SETTING.autoLockMinutes, DEFAULT_AUTO_LOCK_MINUTES));
    } catch (e) {
      setError(e instanceof WrongPassphraseError ? 'That passphrase is not correct.' : 'The workspace could not be unlocked.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Frame>
      <Card>
        <CardHeader
          title="Workspace locked"
          description={session.lastLockReason === 'inactivity' ? 'Locked after a period of inactivity. Unsaved gateway drafts and loaded source data were cleared.' : 'Enter the workspace passphrase to continue.'}
        />
        <CardBody>
          <form onSubmit={submit} className="grid grid-cols-1 gap-4" noValidate>
            <div>
              <Label htmlFor="unlock-pass">Passphrase</Label>
              <Input id="unlock-pass" type="password" value={passphrase} onChange={(e) => setPassphrase(e.target.value)} autoComplete="current-password" autoFocus aria-invalid={error ? true : undefined} aria-describedby={error ? 'unlock-error' : undefined} />
              {error ? <p id="unlock-error" role="alert" className="mt-1 text-sm text-red-700">{error}</p> : null}
            </div>
            <div><Button type="submit" disabled={busy || passphrase === ''}><LockKeyhole aria-hidden /> {busy ? 'Unlocking…' : 'Unlock'}</Button></div>
          </form>
        </CardBody>
      </Card>
    </Frame>
  );
}
