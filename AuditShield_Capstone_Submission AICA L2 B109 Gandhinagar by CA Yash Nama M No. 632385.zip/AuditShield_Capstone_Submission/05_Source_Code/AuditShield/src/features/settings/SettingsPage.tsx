import { CircleAlert, CircleCheck, Download, HardDrive, Save, Trash2 } from 'lucide-react';
import { type FormEvent, useEffect, useState } from 'react';
import type { Navigate } from '../../app/App';
import { useCurrentEngagement, useEngagementData, useSetting, useStore, useUnlocked } from '../../app/store';
import { Button, Card, CardBody, CardHeader, Input, Label, Notice, PageHeader, Select } from '../../components/ui/primitives';
import { SCHEMA_VERSION } from '../../data/db/schema';
import type { EngagementView } from '../../data/repositories/repositories';
import { POLICY_VERSION } from '../../domain/privacy/policy';
import { parseRupeesToPaise } from '../../domain/shared/money';
import { NORMALISATION_VERSION } from '../../domain/vendor/normalise';
import { ENGINE_VERSION } from '../../domain/vendor/rules';
import type { RuleConfig } from '../../domain/vendor/types';
import { formatInstant } from '../../lib/cn';
import { downloadBytes } from '../../lib/download';
import { APP_VERSION, exportBackup } from '../../services/backup/backup';
import { MIN_PASSPHRASE_LENGTH, openEnvelope, WrongPassphraseError } from '../../services/crypto/envelope';
import { TOKEN_ALGORITHM, TOKEN_VERSION } from '../../services/crypto/tokeniser';
import { DEFAULT_AUTO_LOCK_MINUTES, DEFAULT_RETENTION_DAYS, SETTING } from '../../services/workspace/useCases';
import { Loading } from '../engagements/NeedEngagement';

function validate(limit: string, window: string, nearPct: string): { ok: true; value: Omit<RuleConfig, 'version' | 'roundAmountPaise'> } | { ok: false; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  const paise = parseRupeesToPaise(limit);
  if (!paise.ok) errors['limit'] = paise.error;
  else if (paise.value < 100_00) errors['limit'] = 'Approval limit must be at least ₹100.';
  const days = Number(window);
  if (!/^\d+$/.test(window.trim()) || days < 0 || days > 31) errors['window'] = 'Split window must be a whole number of days from 0 to 31.';
  const pct = Number(nearPct);
  if (!/^\d+(\.\d{1,2})?$/.test(nearPct.trim()) || pct < 50 || pct >= 100) errors['near'] = 'Near-limit band must start between 50 and 99.99 percent.';
  if (Object.keys(errors).length || !paise.ok) return { ok: false, errors };
  return { ok: true, value: { approvalLimitPaise: paise.value, splitWindowDays: days, nearLimitBasisPoints: Math.round(pct * 100) } };
}

function RuleThresholds({ engagement, config }: { engagement: EngagementView; config: RuleConfig }) {
  const { repos, clock } = useStore();
  const [limit, setLimit] = useState(String(config.approvalLimitPaise / 100));
  const [window, setWindow] = useState(String(config.splitWindowDays));
  const [near, setNear] = useState(String(config.nearLimitBasisPoints / 100));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [saved, setSaved] = useState<'saved' | 'failed' | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setSaved(null);
    const result = validate(limit, window, near);
    if (!result.ok) return setErrors(result.errors);
    setErrors({});
    const v = result.value;
    // The version names the thresholds, so a run always records exactly what it used.
    const next: RuleConfig = { ...config, ...v, version: `rules-1.0.0/limit=${v.approvalLimitPaise}/window=${v.splitWindowDays}/near=${v.nearLimitBasisPoints}` };
    try {
      const at = clock.now();
      await repos.settings.set(SETTING.ruleConfig(engagement.id), next, at);
      await repos.audit.append({ id: clock.id(), at }, engagement.id, 'Rule thresholds changed', `configuration ${next.version}`);
      setSaved('saved');
    } catch {
      setSaved('failed');
    }
  };
  const field = (id: string, label: string, value: string, set: (v: string) => void, help: string) => (
    <div>
      <Label htmlFor={id}>{label}</Label>
      <Input id={id} value={value} onChange={(e) => { set(e.target.value); setSaved(null); }} inputMode="decimal" aria-invalid={errors[id] ? true : undefined} aria-describedby={`${id}-help`} autoComplete="off" />
      <p id={`${id}-help`} className={errors[id] ? 'mt-1 text-xs text-red-700' : 'mt-1 text-xs text-slate-600'} role={errors[id] ? 'alert' : undefined}>{errors[id] ?? help}</p>
    </div>
  );

  return (
    <Card>
      <CardHeader title="Rule thresholds" description={`Used by R7 (split payments) and R8 (just below the limit). Applies to “${engagement.name}”.`} />
      <CardBody>
        <form onSubmit={(e) => void submit(e)} className="grid grid-cols-1 gap-4 md:grid-cols-3" noValidate>
          {field('limit', 'Approval limit (₹)', limit, setLimit, 'Payments at or above this need senior approval.')}
          {field('window', 'Split window (days)', window, setWindow, 'Payments within this many days are grouped for R7.')}
          {field('near', 'Near-limit band starts at (%)', near, setNear, 'R8 looks at amounts from this percentage of the limit up to the limit.')}
          <div className="flex flex-wrap items-center gap-3 md:col-span-3">
            <Button type="submit"><Save aria-hidden /> Save thresholds</Button>
            {saved === 'saved' ? <span role="status" className="flex items-center gap-1 text-sm text-emerald-800"><CircleCheck className="size-4" aria-hidden /> Saved.</span> : null}
            {saved === 'failed' ? <span role="alert" className="text-sm text-red-700">Not saved; the previous thresholds are still in force.</span> : null}
            <span className="text-sm text-slate-600">Earlier runs stay stored with the thresholds they used. Run the analysis again to see results for new thresholds.</span>
          </div>
        </form>
      </CardBody>
    </Card>
  );
}

const formatBytes = (n: number) => (n >= 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`);

function StorageStatus() {
  const [status, setStatus] = useState<{ usage?: number; quota?: number; persisted: boolean | null } | null>(null);
  const [asked, setAsked] = useState(false);
  const refresh = async () => {
    const storage = navigator.storage;
    if (!storage?.estimate) return setStatus({ persisted: null });
    const [estimate, persisted] = await Promise.all([storage.estimate(), storage.persisted?.() ?? Promise.resolve(null)]);
    setStatus({ ...(estimate.usage !== undefined ? { usage: estimate.usage } : {}), ...(estimate.quota !== undefined ? { quota: estimate.quota } : {}), persisted });
  };
  useEffect(() => {
    void refresh();
  }, []);
  const request = async () => {
    await navigator.storage.persist?.();
    setAsked(true);
    await refresh();
  };

  return (
    <div>
      <h3 className="flex items-center gap-2 text-sm font-medium text-slate-900"><HardDrive className="size-4 text-slate-500" aria-hidden /> Browser storage</h3>
      {!status ? <p className="mt-1 text-sm text-slate-600">Checking…</p> : (
        <dl className="mt-2 grid grid-cols-1 gap-x-6 gap-y-1 text-sm sm:grid-cols-[14rem_1fr]">
          <dt className="text-slate-600">Used by this site</dt>
          <dd>{status.usage !== undefined ? formatBytes(status.usage) : 'not reported by this browser'}{status.quota ? ` of about ${formatBytes(status.quota)} available` : ''}</dd>
          <dt className="text-slate-600">Protected from automatic clearing</dt>
          <dd>
            {status.persisted === true ? 'Yes. The browser will not clear this data on its own when disk space runs low.'
              : status.persisted === false ? 'No. The browser may clear this site’s data if the disk becomes full.'
              : 'This browser does not report it.'}
          </dd>
        </dl>
      )}
      {status?.persisted === false ? (
        <div className="mt-2 flex flex-wrap items-center gap-3">
          <Button variant="outline" size="sm" onClick={() => void request()}>Ask the browser to keep this data</Button>
          {asked ? <span role="status" className="text-sm text-slate-600">The browser declined for now. It usually agrees once the app is installed or used regularly. Keep backups either way.</span> : null}
        </div>
      ) : null}
      <p className="mt-2 text-xs text-slate-600">
        Even when protected, you can still remove this data yourself by clearing site data. Data is tied to this address ({window.location.origin}) and this
        browser profile.
      </p>
    </div>
  );
}

function Backup() {
  const { db, repos, clock } = useStore();
  const { dek, workspace } = useUnlocked();
  const lastBackup = useSetting<string | null>(SETTING.lastBackupAt, null);
  const [passphrase, setPassphrase] = useState('');
  const [includeSource, setIncludeSource] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setMessage(null);
    setBusy(true);
    try {
      // The backup is encrypted with the workspace passphrase, which is checked here first.
      await openEnvelope(workspace.envelope, passphrase);
      const createdAt = clock.now();
      const { bytes, header } = await exportBackup(db, dek, { passphrase, includeRetainedSource: includeSource, createdAt });
      downloadBytes(`auditshield-${createdAt.slice(0, 10)}.asbackup`, bytes);
      await repos.settings.set(SETTING.lastBackupAt, createdAt, createdAt);
      await repos.audit.append({ id: clock.id(), at: createdAt }, '', 'Backup exported',
        `${header.counts['engagements'] ?? 0} engagements, ${header.counts['payments'] ?? 0} payments, ${header.counts['findings'] ?? 0} findings, retained source ${includeSource ? 'included' : 'not included'}, ${formatBytes(bytes.byteLength)}`);
      setPassphrase('');
      setMessage({ tone: 'ok', text: `Backup created (${formatBytes(bytes.byteLength)}). Check that the browser saved the file, then move it off this computer.` });
    } catch (err) {
      setMessage({ tone: 'error', text: err instanceof WrongPassphraseError ? 'That is not the workspace passphrase. No backup was created.' : 'The backup could not be created. Nothing was changed.' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <h3 className="flex items-center gap-2 text-sm font-medium text-slate-900"><Download className="size-4 text-slate-500" aria-hidden /> Encrypted backup</h3>
      <p className="mt-1 text-sm text-slate-600">
        One file with every engagement, snapshot, run, finding, setting and activity record, encrypted with the workspace passphrase.
        {lastBackup.ready ? (lastBackup.value ? ` Last backup: ${formatInstant(lastBackup.value)}.` : ' No backup has been made yet.') : ''}
      </p>
      <form onSubmit={(e) => void submit(e)} className="mt-3 grid grid-cols-1 gap-3 sm:max-w-md" noValidate>
        <div>
          <Label htmlFor="backup-pass">Workspace passphrase</Label>
          <Input id="backup-pass" type="password" value={passphrase} onChange={(e) => setPassphrase(e.target.value)} autoComplete="current-password" />
        </div>
        <label className="flex items-start gap-2 text-sm text-slate-800">
          <input type="checkbox" className="mt-1 size-4 accent-indigo-700" checked={includeSource} onChange={(e) => setIncludeSource(e.target.checked)} />
          <span>
            Include retained source data and matching keys
            <span className="block text-xs text-slate-600">Off by default. Only relevant if you chose to keep an encrypted source copy. The backup then contains real identifiers, encrypted.</span>
          </span>
        </label>
        <div><Button type="submit" disabled={busy || passphrase.length < MIN_PASSPHRASE_LENGTH}><Download aria-hidden /> {busy ? 'Creating backup…' : 'Create backup file'}</Button></div>
      </form>
      {message ? <p role={message.tone === 'error' ? 'alert' : 'status'} className={message.tone === 'error' ? 'mt-2 text-sm text-red-700' : 'mt-2 text-sm text-emerald-800'}>{message.text}</p> : null}
      <p className="mt-3 text-xs text-slate-600">
        To restore: open AuditShield in an empty browser profile (or after deleting all local data below) and choose “Restore from a backup” on the setup
        screen. A restore never overwrites an existing workspace, and a wrong passphrase or damaged file changes nothing. Anyone with the file and the
        passphrase can read it.
      </p>
    </div>
  );
}

function LockAndRetention() {
  const { repos, session, clock } = useStore();
  const autoLock = useSetting(SETTING.autoLockMinutes, DEFAULT_AUTO_LOCK_MINUTES);
  const retention = useSetting(SETTING.retentionDays, DEFAULT_RETENTION_DAYS);
  if (!autoLock.ready || !retention.ready) return <Loading />;
  const setAutoLock = async (minutes: number) => {
    await repos.settings.set(SETTING.autoLockMinutes, minutes, clock.now());
    session.setAutoLock(minutes);
  };
  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      <div>
        <Label htmlFor="auto-lock">Lock automatically after inactivity</Label>
        <Select id="auto-lock" value={String(autoLock.value)} onChange={(e) => void setAutoLock(Number(e.target.value))}>
          {[5, 15, 30, 60].map((m) => <option key={m} value={m}>{m} minutes</option>)}
          <option value="0">Never (lock manually)</option>
        </Select>
        <p className="mt-1 text-xs text-slate-600">Locking closes every screen and drops the keys, loaded source data and gateway drafts from memory.</p>
      </div>
      <div>
        <Label htmlFor="retention">Keep encrypted source copies for</Label>
        <Select id="retention" value={String(retention.value)} onChange={(e) => void repos.settings.set(SETTING.retentionDays, Number(e.target.value), clock.now())}>
          {[7, 30, 90, 365].map((d) => <option key={d} value={d}>{d} days</option>)}
          <option value="0">Until I delete them</option>
        </Select>
        <p className="mt-1 text-xs text-slate-600">Applies to copies made from now on, and only when you tick “keep an encrypted copy” while protecting data.</p>
      </div>
    </div>
  );
}

function DangerZone({ engagement }: { engagement: EngagementView | null }) {
  const { db, repos, dispatch, clock } = useStore();
  const [confirm, setConfirm] = useState<'engagement' | 'all' | null>(null);
  const [typed, setTyped] = useState('');
  const [error, setError] = useState<string | null>(null);

  const removeEngagement = async () => {
    if (!engagement) return;
    try {
      await repos.engagements.remove(engagement.id, { id: clock.id(), at: clock.now() });
      dispatch({ type: 'engagement/removed', engagementId: engagement.id });
      setConfirm(null);
    } catch {
      setError('The engagement could not be deleted. Nothing was changed.');
    }
  };
  const removeAll = async () => {
    await db.delete();
    window.location.reload();
  };

  return (
    <Card>
      <CardHeader title="Delete data" description="Removes records from this browser profile. It cannot be undone and does not affect backup files you already made. Browsers and disks may keep remnants; this is not forensic erasure." />
      <CardBody className="grid grid-cols-1 gap-4">
        {engagement ? (
          <div className="flex flex-wrap items-center gap-3">
            {confirm === 'engagement' ? (
              <>
                <span className="text-sm text-slate-800">Delete “{engagement.name}” with all its snapshots, runs and findings?</span>
                <Button variant="outline" size="sm" onClick={() => void removeEngagement()}><Trash2 aria-hidden /> Yes, delete engagement</Button>
                <Button variant="ghost" size="sm" onClick={() => setConfirm(null)}>Cancel</Button>
              </>
            ) : <Button variant="outline" size="sm" onClick={() => { setConfirm('engagement'); setError(null); }}><Trash2 aria-hidden /> Delete this engagement…</Button>}
          </div>
        ) : null}
        <div className="flex flex-wrap items-end gap-3">
          {confirm === 'all' ? (
            <>
              <div>
                <Label htmlFor="delete-all">Type DELETE to remove the whole workspace from this browser</Label>
                <Input id="delete-all" value={typed} onChange={(e) => setTyped(e.target.value)} autoComplete="off" className="w-48" />
              </div>
              <Button variant="outline" size="sm" disabled={typed !== 'DELETE'} onClick={() => void removeAll()}><Trash2 aria-hidden /> Delete everything</Button>
              <Button variant="ghost" size="sm" onClick={() => { setConfirm(null); setTyped(''); }}>Cancel</Button>
            </>
          ) : <Button variant="outline" size="sm" onClick={() => setConfirm('all')}><Trash2 aria-hidden /> Delete all local data…</Button>}
        </div>
        {error ? <p role="alert" className="text-sm text-red-700">{error}</p> : null}
      </CardBody>
    </Card>
  );
}

function EngagementSettings({ engagement }: { engagement: EngagementView }) {
  const data = useEngagementData(engagement.id);
  if (!data.ready) return <Loading />;
  return <RuleThresholds key={`${engagement.id}:${data.value.ruleConfig.version}`} engagement={engagement} config={data.value.ruleConfig} />;
}

export function SettingsPage(_props: { navigate: Navigate }) {
  const current = useCurrentEngagement();
  const { workspace } = useUnlocked();
  if (!current.ready) return <Loading />;

  return (
    <>
      <PageHeader title="Settings" description="Thresholds for the current engagement, and storage, locking, backup and deletion for the whole workspace." />
      <div className="grid grid-cols-1 gap-4">
        {current.value ? <EngagementSettings engagement={current.value} /> : (
          <Notice icon={<CircleAlert aria-hidden />}>Rule thresholds belong to an engagement. Choose one in the top bar to edit them.</Notice>
        )}

        <Card>
          <CardHeader title="Storage, locking and backup" description="Where the workspace lives and how to keep it safe." />
          <CardBody className="grid grid-cols-1 gap-6">
            <StorageStatus />
            <LockAndRetention />
            <Backup />
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="AI providers" />
          <CardBody className="text-sm text-slate-700">
            Only the offline demo provider is registered. It builds a canned reply in the browser and makes no network request. Local-model and external
            adapters, session-only API keys and destination restrictions are planned for a later release. No API key can be entered or stored in this build, and gateway
            prompts, answers and vault values are never written to storage.
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Versions" />
          <CardBody>
            <dl className="grid grid-cols-1 gap-x-6 gap-y-2 text-sm sm:grid-cols-[14rem_1fr]">
              {([
                ['App / database schema', `${APP_VERSION} / version ${SCHEMA_VERSION}`],
                ['Rule engine', ENGINE_VERSION],
                ['Normalisation scheme', `version ${NORMALISATION_VERSION}`],
                ['Token scheme', `${TOKEN_ALGORITHM}, version ${TOKEN_VERSION} (full 256-bit digest)`],
                ['Outbound policy', POLICY_VERSION],
                ['Storage encryption', `AES-256-GCM; key wrapped under ${workspace.envelope.kdf.name}-${workspace.envelope.kdf.hash}, ${workspace.envelope.kdf.iterations.toLocaleString('en-IN')} iterations (envelope v${workspace.envelope.version})`],
              ] as const).map(([k, v]) => (
                <div key={k} className="contents">
                  <dt className="text-slate-600">{k}</dt>
                  <dd className="font-mono text-[13px] break-all text-slate-900">{v}</dd>
                </div>
              ))}
            </dl>
          </CardBody>
        </Card>

        <DangerZone engagement={current.value} />
      </div>
    </>
  );
}
