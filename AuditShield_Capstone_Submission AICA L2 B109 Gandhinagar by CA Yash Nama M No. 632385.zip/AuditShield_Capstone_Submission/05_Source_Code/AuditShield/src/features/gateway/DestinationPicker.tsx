/**
 * Destination choice for the gateway: offline demo, local model (LM Studio / Ollama on this
 * computer), or external provider (not offered in this version). The three are visually distinct
 * and the chosen one is named on the Send button.
 */
import { Laptop, PlugZap, Save, Server, WifiOff } from 'lucide-react';
import { type FormEvent, useState } from 'react';
import { useStore } from '../../app/store';
import { Badge, Button, Card, CardBody, CardHeader, Input, Label, Select } from '../../components/ui/primitives';
import { cn } from '../../lib/cn';
import {
  DEFAULT_LOCAL_ENDPOINT, LOCAL_MODEL_PROVIDER_ID, type LocalModelConfig, listLocalModels, localEndpointProblem, ProviderError,
} from '../../services/providers/openAiCompatible';
import { OFFLINE_DEMO_DESTINATION } from '../../services/providers/offlineDemoProvider';
import { SETTING } from '../../services/workspace/useCases';

function LocalModelForm({ config }: { config: LocalModelConfig | null }) {
  const { repos, clock } = useStore();
  const [endpoint, setEndpoint] = useState(config?.endpoint ?? DEFAULT_LOCAL_ENDPOINT);
  const [model, setModel] = useState(config?.model ?? '');
  const [models, setModels] = useState<string[]>([]);
  const [message, setMessage] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);

  const check = async () => {
    setMessage(null);
    try {
      const ids = await listLocalModels(endpoint, undefined, AbortSignal.timeout(8000));
      setModels(ids);
      if (!model && ids[0]) setModel(ids[0]);
      setMessage({ tone: 'ok', text: ids.length ? `Connected. ${ids.length} model(s) available. No text was sent.` : 'Connected, but no model is loaded. Load one in LM Studio.' });
    } catch (e) {
      setMessage({ tone: 'error', text: e instanceof ProviderError ? e.message : 'The server did not respond in time.' });
    }
  };
  const save = async (e: FormEvent) => {
    e.preventDefault();
    const problem = localEndpointProblem(endpoint) ?? (model.trim() ? null : 'Enter or choose the model name.');
    if (problem) return setMessage({ tone: 'error', text: problem });
    await repos.settings.set(SETTING.localModel, { endpoint: endpoint.trim(), model: model.trim() }, clock.now());
    setMessage({ tone: 'ok', text: 'Saved. Select “Local model” above to use it.' });
  };

  return (
    <form onSubmit={(e) => void save(e)} className="mt-3 grid grid-cols-1 gap-3 rounded-md border border-slate-200 bg-slate-50 p-3 md:grid-cols-[2fr_1fr_auto_auto] md:items-end" noValidate>
      <div>
        <Label htmlFor="lm-endpoint">Local server address</Label>
        <Input id="lm-endpoint" value={endpoint} onChange={(e) => setEndpoint(e.target.value)} autoComplete="off" />
      </div>
      <div>
        <Label htmlFor="lm-model">Model</Label>
        {models.length ? (
          <Select id="lm-model" value={model} onChange={(e) => setModel(e.target.value)}>{models.map((m) => <option key={m} value={m}>{m}</option>)}</Select>
        ) : <Input id="lm-model" value={model} onChange={(e) => setModel(e.target.value)} placeholder="e.g. qwen2.5-7b-instruct" autoComplete="off" />}
      </div>
      <Button type="button" variant="outline" onClick={() => void check()}><PlugZap aria-hidden /> Check connection</Button>
      <Button type="submit"><Save aria-hidden /> Save</Button>
      <p className="text-xs text-slate-600 md:col-span-4">
        In LM Studio: load a model, open the Developer tab, start the server and turn on “Enable CORS”. Only addresses on this computer are accepted.
      </p>
      {message ? <p role={message.tone === 'error' ? 'alert' : 'status'} className={cn('text-sm md:col-span-4', message.tone === 'error' ? 'text-red-700' : 'text-emerald-800')}>{message.text}</p> : null}
    </form>
  );
}

export function DestinationPicker({ selected, config, onSelect }: { selected: string; config: LocalModelConfig | null; onSelect: (providerId: string) => void }) {
  const [configuring, setConfiguring] = useState(false);
  const option = (id: string, active: boolean, enabled: boolean) =>
    cn('rounded-md px-3 py-2 text-left', active ? 'border-2 border-indigo-700 bg-indigo-50' : 'border border-slate-300 bg-white',
      enabled ? 'hover:border-indigo-500 focus-visible:outline-2 focus-visible:outline-indigo-600' : 'cursor-not-allowed border-dashed opacity-80', id);

  return (
    <Card>
      <CardHeader title="Destination" description="Where an approved request goes. It is part of what you approve: changing it requires a new scan." />
      <CardBody>
        <div className="grid grid-cols-1 gap-3 md:grid-cols-3" role="radiogroup" aria-label="AI destination">
          <button type="button" role="radio" aria-checked={selected === OFFLINE_DEMO_DESTINATION.providerId} className={option('', selected === OFFLINE_DEMO_DESTINATION.providerId, true)} onClick={() => onSelect(OFFLINE_DEMO_DESTINATION.providerId)}>
            <span className="flex items-center gap-2 text-sm font-medium text-slate-900"><WifiOff className="size-4" aria-hidden /> Offline demo {selected === OFFLINE_DEMO_DESTINATION.providerId ? <Badge tone="ok">Selected</Badge> : null}</span>
            <span className="mt-1 block text-xs text-slate-700">A canned reply generated in this browser. It is not a model. Nothing is transmitted.</span>
          </button>
          <button type="button" role="radio" aria-checked={selected === LOCAL_MODEL_PROVIDER_ID} disabled={!config} className={option('', selected === LOCAL_MODEL_PROVIDER_ID, Boolean(config))} onClick={() => onSelect(LOCAL_MODEL_PROVIDER_ID)}>
            <span className="flex items-center gap-2 text-sm font-medium text-slate-900"><Laptop className="size-4" aria-hidden /> Local model {selected === LOCAL_MODEL_PROVIDER_ID ? <Badge tone="ok">Selected</Badge> : config ? <Badge tone="info">Ready</Badge> : <Badge>Not configured</Badge>}</span>
            <span className="mt-1 block text-xs text-slate-700">{config ? `${config.model} on this computer (${new URL(config.endpoint).host}). Masked text never leaves the machine.` : 'An offline GPT running in LM Studio or Ollama on this computer. Configure it below.'}</span>
          </button>
          <div className={option('', false, false)} aria-disabled="true">
            <span className="flex items-center gap-2 text-sm font-medium text-slate-700"><Server className="size-4" aria-hidden /> External provider <Badge>Not offered</Badge></span>
            <span className="mt-1 block text-xs text-slate-600">Cloud AI services are deliberately not connected in this version: masked text would leave the machine.</span>
          </div>
        </div>
        <Button className="mt-3" variant="ghost" size="sm" onClick={() => setConfiguring((c) => !c)}>
          <Laptop aria-hidden /> {configuring ? 'Hide local model settings' : config ? 'Change local model settings' : 'Set up a local model (LM Studio)'}
        </Button>
        {configuring ? <LocalModelForm config={config} /> : null}
      </CardBody>
    </Card>
  );
}
