import { Ban, CircleAlert, CircleCheck, EyeOff, Highlighter, ScanSearch, Send, X } from 'lucide-react';
import { Fragment, type ReactNode, useEffect, useRef, useState } from 'react';
import type { Navigate } from '../../app/App';
import { type GatewayState, outcomeAuditDetail, scanAuditDetail, selectGateway } from '../../app/state';
import { useSetting, useStore } from '../../app/store';
import {
  createLocalModelProvider, LOCAL_MODEL_PROVIDER_ID, type LocalModelConfig, localEndpointProblem, localModelDestination,
} from '../../services/providers/openAiCompatible';
import { SETTING } from '../../services/workspace/useCases';
import { DestinationPicker } from './DestinationPicker';
import { Badge, Button, Card, CardBody, CardHeader, Input, Label, Notice, PageHeader, Textarea } from '../../components/ui/primitives';
import { IDENTIFIER_TYPES, MIN_TERM_LENGTH } from '../../domain/privacy/detect';
import { SAMPLE_PROMPTS } from '../../domain/privacy/evaluate';
import { CHECK_SCOPE, POLICY_VERSION, type ReviewedScan, reviewScan, type ScanInputs } from '../../domain/privacy/policy';
import type { RestoredSegment } from '../../domain/privacy/vault';
import { cn } from '../../lib/cn';
import { OFFLINE_DEMO_DESTINATION } from '../../services/providers/offlineDemoProvider';
import { WithEngagement } from '../engagements/NeedEngagement';

const STAGES = ['Compose', 'Review masked request', 'Answer'] as const;
const REVEAL_SECONDS = 60;

function Stepper({ stage }: { stage: number }) {
  return (
    <ol className="mb-4 flex flex-wrap gap-2 text-sm" aria-label="Gateway steps">
      {STAGES.map((label, i) => (
        <li
          key={label}
          aria-current={i === stage ? 'step' : undefined}
          className={cn(
            'flex items-center gap-2 rounded-full border px-3 py-1',
            i === stage ? 'border-indigo-700 bg-indigo-50 font-medium text-indigo-900' : i < stage ? 'border-slate-300 bg-white text-slate-700' : 'border-slate-200 bg-white text-slate-400',
          )}
        >
          <span className="tabular-nums">{i + 1}</span> {label}
        </li>
      ))}
    </ol>
  );
}

/** Text with the given ranges wrapped by `render`. Ranges must be sorted and non-overlapping. */
function Marked({ text, ranges, render }: { text: string; ranges: { start: number; end: number; key: string }[]; render: (slice: string, key: string) => ReactNode }) {
  const out: ReactNode[] = [];
  let last = 0;
  ranges.forEach((r, i) => {
    out.push(<Fragment key={`t${i}`}>{text.slice(last, r.start)}</Fragment>);
    out.push(<Fragment key={`m${i}`}>{render(text.slice(r.start, r.end), r.key)}</Fragment>);
    last = r.end;
  });
  out.push(<Fragment key="tail">{text.slice(last)}</Fragment>);
  return <>{out}</>;
}

function ReviewPanels({ scan }: { scan: ReviewedScan }) {
  const pre = 'max-h-80 overflow-auto rounded-md border border-slate-200 bg-slate-50 p-3 text-sm leading-6 whitespace-pre-wrap break-words';
  return (
    <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
      <div>
        <h3 className="mb-1 text-sm font-medium text-slate-900">Your text (stays in this browser)</h3>
        <div className={pre}>
          <Marked
            text={scan.inputs.text}
            ranges={scan.spans.map((s) => ({ start: s.start, end: s.end, key: s.token }))}
            render={(slice, token) => <mark className="rounded bg-amber-100 px-0.5 text-amber-950" title={`Replaced by ${token}`}>{slice}</mark>}
          />
        </div>
      </div>
      <div>
        <h3 className="mb-1 text-sm font-medium text-slate-900">Outgoing text (exactly what would be sent)</h3>
        <div className={pre}>
          <Marked
            text={scan.masked}
            ranges={scan.spans.map((s) => ({ start: s.maskedStart, end: s.maskedEnd, key: s.token }))}
            render={(slice) => <span className="rounded border border-indigo-300 bg-indigo-50 px-0.5 font-mono text-[13px] text-indigo-900">{slice}</span>}
          />
        </div>
      </div>
    </div>
  );
}

function MaskedItems({ scan }: { scan: ReviewedScan }) {
  if (scan.spans.length === 0) return <p className="text-sm text-slate-700">Nothing was recognised and masked in this text.</p>;
  const unique = [...new Map(scan.spans.map((s) => [s.token, s])).values()];
  return (
    <div className="overflow-x-auto rounded border border-slate-200">
      <table className="w-full min-w-[520px] text-sm">
        <thead className="bg-slate-50 text-xs text-slate-600">
          <tr>
            <th scope="col" className="px-3 py-2 text-left font-medium">Type</th>
            <th scope="col" className="px-3 py-2 text-left font-medium">Code sent instead</th>
            <th scope="col" className="px-3 py-2 text-left font-medium">Found by</th>
            <th scope="col" className="px-3 py-2 text-left font-medium">Format check</th>
            <th scope="col" className="px-3 py-2 text-left font-medium">Confidence</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-100">
          {unique.map((s) => (
            <tr key={s.token}>
              <td className="px-3 py-1.5">{IDENTIFIER_TYPES[s.type].label}</td>
              <td className="px-3 py-1.5 font-mono text-[13px]">{s.token}</td>
              <td className="px-3 py-1.5">{s.detection.source}</td>
              <td className="px-3 py-1.5">
                {s.detection.validity === 'valid' ? 'passes' : s.detection.validity === 'invalid' ? 'fails (masked anyway)' : 'no check exists'}
              </td>
              <td className="px-3 py-1.5">{s.detection.confidence}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function Answer({ segments, reveal }: { segments: RestoredSegment[]; reveal: boolean }) {
  return (
    <div className="max-h-96 overflow-auto rounded-md border border-slate-200 bg-slate-50 p-3 text-sm leading-6 whitespace-pre-wrap break-words">
      {segments.map((s, i) =>
        s.kind === 'text' ? <Fragment key={i}>{s.text}</Fragment>
        : s.kind === 'restored' ? (
          reveal
            ? <mark key={i} className="rounded bg-emerald-100 px-0.5 text-emerald-950" title={`Restored from ${s.token}`}>{s.value}</mark>
            : <span key={i} className="rounded border border-indigo-300 bg-indigo-50 px-0.5 font-mono text-[13px] text-indigo-900">{s.token}</span>
        ) : (
          <span key={i} className="rounded border border-amber-400 bg-amber-50 px-0.5 font-mono text-[13px] text-amber-950" title="Not a code from this request; left as received">{s.text}</span>
        ),
      )}
    </div>
  );
}

const HEADER = (
  <PageHeader
    title="AI Gateway"
    description="Mask identifiers, review exactly what would leave, then send. Codes in the answer are turned back into values only on this screen. Drafts, answers and the code-to-value vault are kept in memory only."
  />
);

export function GatewayPage({ navigate }: { navigate: Navigate }) {
  return (
    <WithEngagement navigate={navigate} purpose="use the AI Gateway" header={HEADER}>
      {(engagement) => <Gateway key={engagement.id} engagementId={engagement.id} />}
    </WithEngagement>
  );
}

function Gateway({ engagementId }: { engagementId: string }) {
  const { state, dispatch, runtime, repos, clock } = useStore();
  const textarea = useRef<HTMLTextAreaElement>(null);
  const abort = useRef<AbortController | null>(null);
  const [sending, setSending] = useState(false);
  const [reveal, setReveal] = useState(false);
  const [extraTerm, setExtraTerm] = useState('');
  const [hint, setHint] = useState<string | null>(null);
  const localSetting = useSetting<LocalModelConfig | null>(SETTING.localModel, null);

  // Keep the request service's local adapter in step with the saved settings.
  const localKey = localSetting.ready ? JSON.stringify(localSetting.value) : '';
  useEffect(() => {
    if (!localSetting.ready) return;
    const cfg = localSetting.value;
    runtime.gateway.register(LOCAL_MODEL_PROVIDER_ID, cfg && !localEndpointProblem(cfg.endpoint) ? createLocalModelProvider(cfg) : null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [localKey, runtime]);

  // Revealed values go back to codes on their own after a short while.
  useEffect(() => {
    if (!reveal) return;
    const timer = setTimeout(() => setReveal(false), REVEAL_SECONDS * 1000);
    return () => clearTimeout(timer);
  }, [reveal]);

  const gw = selectGateway(state, engagementId);
  // Activity records are metadata only (counts, codes, outcome): never the prompt, values or answer.
  const record = (action: string, detail: string) =>
    void repos.audit.append({ id: clock.id(), at: clock.now() }, engagementId, action, detail).catch(() => undefined);
  const vault = runtime.vault(engagementId);
  const localConfig = localSetting.ready && localSetting.value && !localEndpointProblem(localSetting.value.endpoint) ? localSetting.value : null;
  const destination = gw.destinationId === LOCAL_MODEL_PROVIDER_ID && localConfig ? localModelDestination(localConfig) : OFFLINE_DEMO_DESTINATION;

  const inputsFor = (over: Partial<Pick<ScanInputs, 'text' | 'manualTerms'>> = {}): ScanInputs => ({
    text: gw.draft, watchlist: gw.watchlistText.split(','), manualTerms: gw.manualTerms,
    policyVersion: POLICY_VERSION, destination, vaultNamespace: vault.namespace, ...over,
  });
  const inputs = inputsFor();
  const scan = gw.scan;
  const outcome = gw.outcome;
  const reasons = scan ? runtime.gateway.evaluate(scan, inputs, vault) : [];
  const stage = outcome?.status === 'answered' ? 2 : scan ? 1 : 0;

  const edit = (patch: Partial<Pick<GatewayState, 'draft' | 'watchlistText' | 'manualTerms' | 'destinationId'>>) => {
    setReveal(false);
    setHint(null);
    dispatch({ type: 'gateway/edit', engagementId, patch });
  };
  const runScan = (over: Partial<Pick<ScanInputs, 'manualTerms'>> = {}) => {
    setReveal(false);
    const reviewed = reviewScan(inputsFor(over), vault);
    dispatch({ type: 'gateway/scanned', engagementId, scan: reviewed });
    record('Gateway scan', scanAuditDetail(reviewed));
  };

  const addManual = (term: string, rescan: boolean) => {
    const clean = term.trim();
    if (clean.length < MIN_TERM_LENGTH) return setHint(`Select or type at least ${MIN_TERM_LENGTH} characters to mask.`);
    if (gw.manualTerms.some((t) => t.toLowerCase() === clean.toLowerCase())) return setHint('That text is already masked.');
    const manualTerms = [...gw.manualTerms, clean];
    edit({ manualTerms });
    if (rescan) runScan({ manualTerms });
  };
  const maskSelection = () => {
    const el = textarea.current;
    if (!el) return;
    addManual(el.value.slice(el.selectionStart, el.selectionEnd), false);
  };

  const send = async () => {
    if (!scan) return;
    const controller = new AbortController();
    abort.current = controller;
    setSending(true);
    try {
      const result = await runtime.gateway.dispatch(scan, inputs, vault, { signal: controller.signal });
      dispatch({ type: 'gateway/outcome', engagementId, outcome: result });
      record(`Gateway request ${result.status}`, outcomeAuditDetail(result, destination.label));
    } finally {
      setSending(false);
      abort.current = null;
    }
  };

  return (
    <>
      <Stepper stage={stage} />

      <div className="grid grid-cols-1 gap-4">
        <DestinationPicker selected={gw.destinationId} config={localConfig} onSelect={(destinationId) => edit({ destinationId })} />

        <Card>
          <CardHeader
            title="1. Compose"
            description="Editing the text, watch-list or masks discards the current scan."
            actions={Object.keys(SAMPLE_PROMPTS).map((name) => (
              <Button key={name} variant="outline" size="sm" onClick={() => edit({ draft: SAMPLE_PROMPTS[name] ?? '' })}>{name}</Button>
            ))}
          />
          <CardBody className="grid grid-cols-1 gap-4">
            <div>
              <Label htmlFor="gw-draft">Text for the AI (fictional sample prompts are above)</Label>
              <Textarea id="gw-draft" ref={textarea} rows={9} value={gw.draft} onChange={(e) => edit({ draft: e.target.value })} placeholder="Paste or type the text you want help with." />
            </div>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
              <div>
                <Label htmlFor="gw-watch">Watch-list (comma-separated terms that must always be hidden)</Label>
                <Input id="gw-watch" value={gw.watchlistText} onChange={(e) => edit({ watchlistText: e.target.value })} placeholder="e.g. Shubham, Project Falcon" autoComplete="off" />
              </div>
              <div>
                <p className="mb-1 text-sm font-medium text-slate-700">Manually masked text</p>
                <div className="flex flex-wrap items-center gap-2">
                  <Button variant="outline" size="sm" onClick={maskSelection}><Highlighter aria-hidden /> Mask selected text</Button>
                  {gw.manualTerms.map((t) => (
                    <Badge key={t} tone="info">
                      {t}
                      <button type="button" aria-label={`Stop masking ${t}`} className="rounded-full hover:bg-indigo-200 focus-visible:outline-2 focus-visible:outline-indigo-600" onClick={() => edit({ manualTerms: gw.manualTerms.filter((x) => x !== t) })}>
                        <X aria-hidden />
                      </button>
                    </Badge>
                  ))}
                  {gw.manualTerms.length === 0 ? <span className="text-xs text-slate-600">Select text in the box above, then press the button.</span> : null}
                </div>
              </div>
            </div>
            {hint ? <p role="status" className="text-sm text-amber-800">{hint}</p> : null}
            <div className="flex flex-wrap items-center gap-3">
              <Button onClick={() => runScan()} disabled={gw.draft.trim() === ''}><ScanSearch aria-hidden /> {scan ? 'Scan again' : 'Scan and mask'}</Button>
              {gw.draft.trim() === '' ? <span className="text-sm text-slate-600">Enter some text to scan.</span> : null}
            </div>
          </CardBody>
        </Card>

        {scan ? (
          <Card>
            <CardHeader title="2. Review masked request" description={`${scan.spans.length} occurrences replaced by ${scan.tokens.length} codes. Read the outgoing text: pattern matching cannot find every name.`} />
            <CardBody className="grid grid-cols-1 gap-4">
              <ReviewPanels scan={scan} />
              <MaskedItems scan={scan} />

              <form
                className="flex flex-wrap items-end gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  addManual(extraTerm, true);
                  setExtraTerm('');
                }}
              >
                <div className="min-w-56 flex-1">
                  <Label htmlFor="gw-extra">Something still readable? Type it here to mask every occurrence</Label>
                  <Input id="gw-extra" value={extraTerm} onChange={(e) => setExtraTerm(e.target.value)} autoComplete="off" />
                </div>
                <Button type="submit" variant="outline"><EyeOff aria-hidden /> Mask and rescan</Button>
              </form>

              {scan.rejectedTerms.length ? (
                <Notice tone="warn" icon={<CircleAlert aria-hidden />}>
                  Ignored because they are shorter than {MIN_TERM_LENGTH} characters: {scan.rejectedTerms.map((t) => `“${t}”`).join(', ')}.
                </Notice>
              ) : null}

              {reasons.length === 0 ? (
                <Notice tone="ok" icon={<CircleCheck aria-hidden />} title="Automatic checks found nothing in scope">
                  <p>This is not a guarantee that no identifying detail remains. The checks cover:</p>
                  <ul className="mt-1 list-disc pl-5">{CHECK_SCOPE.map((line) => <li key={line}>{line}</li>)}</ul>
                </Notice>
              ) : (
                <Notice tone="error" icon={<Ban aria-hidden />} title="Sending is blocked">
                  <ul className="list-disc pl-5">
                    {reasons.map((r, i) => (
                      <li key={i}>
                        {r.message}
                        {r.code === 'policy-violation' && r.violation.sensitiveExcerpt ? <> Still readable: <span className="font-mono">{r.violation.sensitiveExcerpt}</span></> : null}
                      </li>
                    ))}
                  </ul>
                  <p className="mt-2">Mask the remaining text above, or edit the request. There is no way to send past a failed check.</p>
                </Notice>
              )}

              <div className="flex flex-wrap items-center gap-3 border-t border-slate-200 pt-4">
                <Button onClick={send} disabled={sending || reasons.length > 0}>
                  <Send aria-hidden /> {sending ? 'Waiting for reply…' : `Send to: ${destination.label}`}
                </Button>
                {sending ? <Button variant="outline" onClick={() => abort.current?.abort()}><X aria-hidden /> Cancel</Button> : null}
                <p className="text-sm text-slate-600">
                  {reasons.length > 0 ? 'Disabled: resolve the items listed above.' : `Destination: ${destination.label}.`}
                </p>
              </div>

              {outcome?.status === 'cancelled' ? <Notice tone="warn">Request cancelled. Your draft and scan are unchanged; nothing will be retried automatically.</Notice> : null}
              {outcome?.status === 'failed' ? <Notice tone="error" icon={<CircleAlert aria-hidden />}>{outcome.message}</Notice> : null}
              {outcome?.status === 'blocked' ? (
                <Notice tone="error" icon={<Ban aria-hidden />} title="The request service refused this request; no provider was called">
                  <ul className="list-disc pl-5">{outcome.reasons.map((r, i) => <li key={i}>{r.message}</li>)}</ul>
                </Notice>
              ) : null}
            </CardBody>
          </Card>
        ) : null}

        {outcome?.status === 'answered' ? (
          <Card>
            <CardHeader title="3. Answer" description={`From: ${destination.label}. ${outcome.charactersSent} masked characters and ${outcome.tokensSent.length} codes were sent.`} />
            <CardBody className="grid grid-cols-1 gap-3">
              <Answer segments={outcome.restoration.segments} reveal={reveal} />
              <label className="flex items-start gap-2 text-sm text-slate-800">
                <input type="checkbox" className="mt-1 size-4 accent-indigo-700" checked={reveal}
                  onChange={(e) => {
                    setReveal(e.target.checked);
                    if (e.target.checked && outcome.status === 'answered') {
                      record('Gateway values revealed on screen', `${outcome.restoration.restoredTokens.length} codes shown as values for up to ${REVEAL_SECONDS} seconds`);
                    }
                  }}
                />
                <span>
                  Show real values on this screen for {REVEAL_SECONDS} seconds
                  <span className="block text-xs text-slate-600">
                    A display toggle in an unlocked workspace, not an access control: anyone who can see this screen sees the values. Only codes sent in
                    this request are restored. Each use is noted in Activity (without the values).
                  </span>
                </span>
              </label>
              {outcome.restoration.unknownTokens.length ? (
                <Notice tone="warn" icon={<CircleAlert aria-hidden />} title="Codes in the answer that were not part of this request">
                  {outcome.restoration.unknownTokens.join(', ')} — left exactly as received and never restored.
                </Notice>
              ) : null}
            </CardBody>
          </Card>
        ) : null}
      </div>
    </>
  );
}
