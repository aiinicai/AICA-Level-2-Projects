/**
 * CSV import wizard: choose files → assign each to a dataset → map columns → validate → load into
 * memory. Loading never saves anything: the data is saved only as a protected snapshot when the
 * user protects it in VendorShield.
 */
import { CircleAlert, CircleCheck, FileDown, FileSpreadsheet, Upload } from 'lucide-react';
import { useState } from 'react';
import { useStore } from '../../app/store';
import { Badge, Button, Card, CardBody, CardHeader, Label, Notice, Select } from '../../components/ui/primitives';
import { buildDataset, DATASETS, type DatasetKind, errorsToCsv, FIELDS, type FileInput, type ImportResult, suggestDataset, suggestMapping } from '../../domain/vendor/csvImport';
import { downloadText } from '../../lib/download';
import { digestJson } from '../../services/crypto/tokeniser';
import { MAX_CSV_BYTES, parseCsv } from '../../services/imports/csv';

const DATASET_LABEL: Record<DatasetKind, string> = { employees: 'Employees', vendors: 'Vendor master', directors: 'Directors / KMP', payments: 'Payments' };

export function CsvImportCard({ engagementId, onLoaded }: { engagementId: string; onLoaded: () => void }) {
  const { dispatch } = useStore();
  const [files, setFiles] = useState<FileInput[]>([]);
  const [problems, setProblems] = useState<string[]>([]);
  const [result, setResult] = useState<ImportResult | null>(null);

  const choose = async (list: FileList | null) => {
    setResult(null);
    const next: FileInput[] = [];
    const notes: string[] = [];
    for (const file of Array.from(list ?? [])) {
      if (file.size > MAX_CSV_BYTES) {
        notes.push(`${file.name}: larger than 50 MB, skipped.`);
        continue;
      }
      const parsed = parseCsv(await file.text());
      notes.push(...parsed.problems.map((p) => `${file.name}: ${p}`));
      if (parsed.headers.length === 0) {
        notes.push(`${file.name}: no header row found, skipped.`);
        continue;
      }
      const dataset = suggestDataset(parsed.headers);
      next.push({ name: file.name, dataset, headers: parsed.headers, rows: parsed.rows, mapping: suggestMapping(dataset, parsed.headers) });
    }
    setFiles(next);
    setProblems(notes);
  };
  const update = (index: number, change: (f: FileInput) => FileInput) => {
    setResult(null);
    setFiles((all) => all.map((f, i) => (i === index ? change(f) : f)));
  };
  const validate = () => setResult(buildDataset(files));
  const load = async () => {
    if (!result || result.errors.length) return;
    dispatch({
      type: 'source/loaded', engagementId,
      source: { raw: result.raw, label: `CSV import: ${files.map((f) => f.name).join(', ')}`, sourceType: 'csv', digest: await digestJson(result.raw) },
    });
    onLoaded();
  };

  return (
    <Card>
      <CardHeader
        title="Import client CSV files"
        description="Employees, vendor master, directors and payments exported from the books (for example from Tally or Excel). Files are read in this browser only."
      />
      <CardBody className="grid grid-cols-1 gap-4">
        <div>
          <Label htmlFor="csv-files">CSV files (choose one or more)</Label>
          <input id="csv-files" type="file" multiple accept=".csv,text/csv" onChange={(e) => void choose(e.target.files)}
            className="block w-full text-sm file:mr-3 file:rounded-md file:border file:border-slate-300 file:bg-white file:px-3 file:py-1.5 file:text-sm file:font-medium" />
          <p className="mt-1 text-xs text-slate-600">The dataset of each file is suggested from its column names; check it below. File names are not used.</p>
        </div>
        {problems.length ? <Notice tone="warn" icon={<CircleAlert aria-hidden />}><ul className="list-disc pl-5">{problems.map((p) => <li key={p}>{p}</li>)}</ul></Notice> : null}

        {files.map((file, index) => {
          const mapped = new Set(Object.values(file.mapping));
          const unmapped = file.headers.filter((h) => !mapped.has(h));
          return (
            <section key={file.name} className="rounded-md border border-slate-200" aria-label={`Mapping for ${file.name}`}>
              <div className="flex flex-wrap items-end gap-3 border-b border-slate-200 bg-slate-50 px-4 py-3">
                <FileSpreadsheet className="size-5 text-slate-500" aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium text-slate-900">{file.name}</p>
                  <p className="text-xs text-slate-600">{file.rows.length} data rows · {file.headers.length} columns</p>
                </div>
                <div className="w-48">
                  <Label htmlFor={`ds-${index}`}>This file contains</Label>
                  <Select id={`ds-${index}`} value={file.dataset}
                    onChange={(e) => update(index, (f) => ({ ...f, dataset: e.target.value as DatasetKind, mapping: suggestMapping(e.target.value as DatasetKind, f.headers) }))}>
                    {DATASETS.map((d) => <option key={d} value={d}>{DATASET_LABEL[d]}</option>)}
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4">
                {FIELDS[file.dataset].map((spec) => (
                  <div key={spec.key}>
                    <Label htmlFor={`map-${index}-${spec.key}`}>{spec.label}{spec.required ? ' *' : ''}</Label>
                    <Select id={`map-${index}-${spec.key}`} value={file.mapping[spec.key] ?? ''}
                      onChange={(e) => update(index, (f) => {
                        const mapping = { ...f.mapping };
                        if (e.target.value) mapping[spec.key] = e.target.value;
                        else delete mapping[spec.key];
                        return { ...f, mapping };
                      })}>
                      <option value="">— not in this file —</option>
                      {file.headers.map((h) => <option key={h} value={h}>{h}</option>)}
                    </Select>
                  </div>
                ))}
              </div>
              <p className="border-t border-slate-200 px-4 py-2 text-xs text-slate-600">
                {unmapped.length ? <>Not imported (dropped): {unmapped.map((u) => <Badge key={u} className="mr-1">{u}</Badge>)}</> : 'Every column is mapped.'}
              </p>
            </section>
          );
        })}

        {files.length ? (
          <div className="flex flex-wrap items-center gap-3">
            <Button variant="outline" onClick={validate}><CircleCheck aria-hidden /> Validate</Button>
            {result && result.errors.length === 0 ? <Button onClick={() => void load()}><Upload aria-hidden /> Load into this engagement</Button> : null}
          </div>
        ) : null}

        {result && result.errors.length > 0 ? (
          <Notice tone="error" icon={<CircleAlert aria-hidden />} title={`${result.errors.length} problem(s) must be fixed before loading`}>
            <ul className="list-disc pl-5">
              {result.errors.slice(0, 15).map((e, i) => <li key={i}>{e.file ? `${e.file}` : 'Files'}{e.row ? `, row ${e.row}` : ''}{e.column ? `, ${e.column}` : ''}: {e.message}</li>)}
            </ul>
            {result.errors.length > 15 ? <p className="mt-1">…and {result.errors.length - 15} more in the error report.</p> : null}
            <Button className="mt-2" variant="outline" size="sm" onClick={() => downloadText('auditshield-import-errors.csv', errorsToCsv(result.errors), 'text/csv')}>
              <FileDown aria-hidden /> Download error report (CSV)
            </Button>
          </Notice>
        ) : null}
        {result && result.errors.length === 0 ? (
          <Notice tone="ok" icon={<CircleCheck aria-hidden />} title="Validation passed">
            {result.raw.vendors.length} vendors, {result.raw.employees.length} employees, {result.raw.directors.length} directors, {result.raw.payments.length} payments.
            Loading keeps the data in memory only; it is saved when you protect it in VendorShield.
          </Notice>
        ) : null}
      </CardBody>
    </Card>
  );
}
