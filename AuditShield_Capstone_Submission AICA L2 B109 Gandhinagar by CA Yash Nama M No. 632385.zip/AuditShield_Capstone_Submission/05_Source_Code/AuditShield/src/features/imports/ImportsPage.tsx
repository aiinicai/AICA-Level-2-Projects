import { CircleAlert, DatabaseBackup, FlaskConical, Info, Trash2 } from 'lucide-react';
import { useState } from 'react';
import type { Navigate } from '../../app/App';
import { useEngagementData, useStore, useUnlocked } from '../../app/store';
import { Badge, Button, Card, CardBody, CardHeader, Notice, PageHeader } from '../../components/ui/primitives';
import type { EngagementView } from '../../data/repositories/repositories';
import { formatINR, sumPaise } from '../../domain/shared/money';
import { SAMPLE_COMPANY_NAME, sampleRawDataset } from '../../domain/vendor/sample';
import { formatInstant } from '../../lib/cn';
import { digestJson } from '../../services/crypto/tokeniser';
import { describeProfile } from '../../services/packages/protectedPackage';
import { Loading, WithEngagement } from '../engagements/NeedEngagement';
import { ExportPackageSection } from '../packages/PackageCards';
import { CsvImportCard } from './CsvImportCard';

function Imports({ engagement, navigate }: { engagement: EngagementView; navigate: Navigate }) {
  const { state, dispatch, repos, runtime, clock } = useStore();
  const { workspace, dek } = useUnlocked();
  const data = useEngagementData(engagement.id);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const source = state.source[engagement.id];
  if (!data.ready) return <Loading />;
  const { snapshot, hasRetainedSource } = data.value;

  const loadSample = async () => {
    const raw = sampleRawDataset();
    dispatch({ type: 'source/loaded', engagementId: engagement.id, source: { raw, label: `Synthetic sample: ${SAMPLE_COMPANY_NAME}`, sourceType: 'sample', digest: await digestJson(raw) } });
  };
  const loadRetained = async () => {
    if (!snapshot) return;
    setError(null);
    try {
      const retained = await repos.datasets.loadRetained(dek, workspace.id, snapshot.id);
      if (!retained) return setError('The retained copy is no longer available.');
      await runtime.restoreHmacKey(engagement.id, retained.keyId, retained.keyBytes);
      const label = await repos.datasets.sourceLabel(dek, workspace.id, snapshot);
      dispatch({ type: 'source/loaded', engagementId: engagement.id, source: { raw: retained.raw, label, sourceType: snapshot.sourceType === 'csv' ? 'csv' : 'sample', digest: await digestJson(retained.raw) } });
      await repos.audit.append({ id: clock.id(), at: clock.now() }, engagement.id, 'Retained source data opened', 'decrypted into memory for this session');
    } catch {
      setError('The retained copy could not be decrypted.');
    }
  };
  const deleteRetained = async () => {
    if (!snapshot) return;
    await repos.datasets.deleteRetained([snapshot.id], { id: clock.id(), at: clock.now() }, engagement.id, 'requested by user');
    setConfirmDelete(false);
  };

  return (
    <div className="grid grid-cols-1 gap-4">
      {source ? (
        <Card>
          <CardHeader
            title="Source data in memory"
            description={source.label}
            actions={<>
              <Button variant="outline" onClick={() => dispatch({ type: 'source/cleared', engagementId: engagement.id })}>Clear from memory</Button>
              <Button onClick={() => navigate('vendorshield')}>Continue in VendorShield</Button>
            </>}
          />
          <CardBody>
            <dl className="grid grid-cols-2 gap-4 text-sm sm:grid-cols-5">
              {([
                ['Employees', source.raw.employees.length],
                ['Vendors', source.raw.vendors.length],
                ['Directors', source.raw.directors.length],
                ['Payments', source.raw.payments.length],
                ['Total paid', formatINR(sumPaise(source.raw.payments.map((p) => p.amountPaise)))],
              ] as const).map(([label, value]) => (
                <div key={label}>
                  <dt className="text-slate-600">{label}</dt>
                  <dd className="mt-0.5 text-base font-semibold text-slate-900 tabular-nums">{value}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 text-sm text-slate-600">
              {snapshot && snapshot.sourceDigest === source.digest
                ? 'This is the same data as the saved snapshot.'
                : 'Not saved. It exists only in this tab until you protect it; locking or reloading clears it.'}
            </p>
          </CardBody>
        </Card>
      ) : null}

      <Card>
        <CardHeader title="Saved snapshot" description="The protected dataset stored for this engagement. Snapshots are never changed; protecting data again adds a new one." />
        <CardBody>
          {!snapshot ? <p className="text-sm text-slate-600">Nothing has been saved yet. Load data, then protect it in VendorShield.</p> : (
            <>
              <dl className="grid grid-cols-2 gap-4 text-sm sm:grid-cols-4">
                <div><dt className="text-slate-600">Saved</dt><dd className="mt-0.5 font-medium text-slate-900">{formatInstant(snapshot.createdAt)}</dd></div>
                <div><dt className="text-slate-600">Records</dt><dd className="mt-0.5 font-medium text-slate-900 tabular-nums">{snapshot.rowCounts.vendors + snapshot.rowCounts.employees + snapshot.rowCounts.directors} entities · {snapshot.rowCounts.payments} payments</dd></div>
                <div><dt className="text-slate-600">Readable labels</dt><dd className="mt-0.5 font-medium text-slate-900">{snapshot.profile.id} profile</dd></div>
                <div><dt className="text-slate-600">Token scheme</dt><dd className="mt-0.5 font-medium text-slate-900">{snapshot.scheme.algorithm} v{snapshot.scheme.tokenVersion}, normalisation v{snapshot.scheme.normalisationVersion}</dd></div>
              </dl>
              <div className="mt-4 flex flex-wrap items-center gap-3 border-t border-slate-200 pt-4">
                {hasRetainedSource ? (
                  <>
                    <Badge tone="info"><DatabaseBackup aria-hidden /> Encrypted source copy kept</Badge>
                    {!source ? <Button variant="outline" size="sm" onClick={() => void loadRetained()}>Open it in this session</Button> : null}
                    {confirmDelete ? (
                      <>
                        <span className="text-sm text-slate-700">Delete the encrypted copy and its matching key? The snapshot and results stay.</span>
                        <Button variant="outline" size="sm" onClick={() => void deleteRetained()}><Trash2 aria-hidden /> Yes, delete</Button>
                        <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(false)}>Cancel</Button>
                      </>
                    ) : <Button variant="ghost" size="sm" onClick={() => setConfirmDelete(true)}><Trash2 aria-hidden /> Delete retained copy</Button>}
                  </>
                ) : snapshot.sourceType === 'package'
                  ? <p className="text-sm text-slate-700"><Badge tone="info">Received as a protected package</Badge> This workspace holds no source data and no matching key for it. Checksum {snapshot.sourceDigest.slice(0, 16)}…</p>
                  : <p className="text-sm text-slate-600">No copy of the source data is stored. Only the protected snapshot is.</p>}
              </div>
              {error ? <p role="alert" className="mt-2 text-sm text-red-700">{error}</p> : null}
              {snapshot.sourceType !== 'package' ? <ExportPackageSection engagement={engagement} snapshot={snapshot} disclosure={describeProfile(snapshot.profile)} /> : null}
            </>
          )}
        </CardBody>
      </Card>

      <Card>
        <CardHeader title="Synthetic sample" description={`${SAMPLE_COMPANY_NAME}: 10 employees, 12 vendors, 3 directors and 86 payments with planted patterns. Entirely fictional.`} />
        <CardBody>
          {engagement.kind === 'sample' ? (
            <Button variant={source || snapshot ? 'outline' : 'primary'} onClick={() => void loadSample()}>
              <FlaskConical aria-hidden /> {source ? 'Reload sample data' : 'Load sample data'}
            </Button>
          ) : (
            <Notice icon={<CircleAlert aria-hidden />}>
              Sample records are not loaded into a client engagement. Create a sample engagement on the Overview page to try the workflow.
            </Notice>
          )}
        </CardBody>
      </Card>

      <CsvImportCard engagementId={engagement.id} onLoaded={() => navigate('vendorshield')} />

      <Notice icon={<Info aria-hidden />} title="Received a protected package from a client?">
        Open it from the Overview page (“Open a protected package”). It becomes its own engagement, with no source data and no key.
      </Notice>
    </div>
  );
}

export function ImportsPage({ navigate }: { navigate: Navigate }) {
  return (
    <WithEngagement
      navigate={navigate}
      purpose="load data into it"
      header={<PageHeader title="Imports" description="Source data is held in memory while you prepare it. What is stored is the protected snapshot, plus an encrypted source copy only if you ask for one." />}
    >
      {(engagement) => <Imports key={engagement.id} engagement={engagement} navigate={navigate} />}
    </WithEngagement>
  );
}
