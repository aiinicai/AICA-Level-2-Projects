/**
 * Client → auditor handoff.
 *  - ExportPackageSection: in the preparer's workspace, turns the saved snapshot into a protected
 *    package file and states exactly what it contains.
 *  - OpenPackageCard: in the auditor's workspace (normally another browser profile or computer),
 *    validates a package, previews it and opens it as a new engagement. No source data or key
 *    arrives with it.
 */
import { FileCheck2, FileDown, FolderOpen, PackageOpen } from 'lucide-react';
import { type FormEvent, useState } from 'react';
import type { Navigate } from '../../app/App';
import { useSelectEngagement } from '../../app/App';
import { useStore, useUnlocked } from '../../app/store';
import { Button, Card, CardBody, CardHeader, Input, Label, Notice } from '../../components/ui/primitives';
import type { ImportRecord } from '../../data/db/schema';
import type { EngagementView } from '../../data/repositories/repositories';
import { formatInstant } from '../../lib/cn';
import { downloadText } from '../../lib/download';
import { type Disclosure, PACKAGE_EXTENSION, PackageError, type ReadPackage, readPackage } from '../../services/packages/protectedPackage';
import { exportPackage, openPackage } from '../../services/workspace/useCases';

export function DisclosureLists({ disclosure }: { disclosure: Disclosure }) {
  const block = (title: string, items: string[], tone: string) => (
    <div>
      <p className={`text-xs font-semibold tracking-wide uppercase ${tone}`}>{title}</p>
      <ul className="mt-1 list-disc pl-5 text-sm text-slate-700">{items.map((i) => <li key={i}>{i}</li>)}</ul>
    </div>
  );
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
      {block('Readable in the package', disclosure.readable, 'text-slate-700')}
      {block('Replaced by keyed tokens', disclosure.tokenised, 'text-indigo-800')}
      {block('Not included at all', disclosure.excluded, 'text-emerald-800')}
    </div>
  );
}

export function ExportPackageSection({ engagement, snapshot, disclosure }: { engagement: EngagementView; snapshot: ImportRecord; disclosure: Disclosure }) {
  const { repos } = useStore();
  const [state, setState] = useState<{ kind: 'idle' | 'busy' } | { kind: 'done'; id: string; dropped: number } | { kind: 'error'; message: string }>({ kind: 'idle' });

  const run = async () => {
    setState({ kind: 'busy' });
    try {
      const built = await exportPackage(repos, { engagementId: engagement.id, importId: snapshot.id, financialYear: engagement.financialYear });
      downloadText(`auditshield-package-${built.manifest.createdAt.slice(0, 10)}${PACKAGE_EXTENSION}`, built.text, 'application/json');
      setState({ kind: 'done', id: built.manifest.packageId, dropped: built.droppedIssues });
    } catch (e) {
      setState({ kind: 'error', message: e instanceof PackageError ? e.message : 'The package could not be created. Nothing was changed.' });
    }
  };

  return (
    <div className="mt-4 border-t border-slate-200 pt-4">
      <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900"><PackageOpen className="size-4 text-indigo-700" aria-hidden /> Hand over to the auditor</h3>
      <p className="mt-1 mb-3 text-sm text-slate-600">
        Creates a protected package from this saved snapshot (profile “{snapshot.profile.id}”). The auditor opens it in their own workspace and can run the
        same analysis without the source data and without the matching key, which stays here.
      </p>
      <DisclosureLists disclosure={disclosure} />
      <div className="mt-3 flex flex-wrap items-center gap-3">
        <Button onClick={() => void run()} disabled={state.kind === 'busy'}><FileDown aria-hidden /> {state.kind === 'busy' ? 'Creating…' : 'Export protected package'}</Button>
        {state.kind === 'done' ? (
          <span role="status" className="text-sm text-emerald-800">
            Package {state.id} created. It is readable JSON: open it in any text editor to check its contents. Send it over your usual confidential channel.
            {state.dropped ? ` ${state.dropped} warning(s) about records outside the package were left out.` : ''}
          </span>
        ) : null}
        {state.kind === 'error' ? <span role="alert" className="text-sm text-red-700">{state.message}</span> : null}
      </div>
    </div>
  );
}

export function OpenPackageCard({ navigate }: { navigate: Navigate }) {
  const { repos } = useStore();
  const unlocked = useUnlocked();
  const select = useSelectEngagement();
  const [file, setFile] = useState<{ name: string; bytes: Uint8Array; pkg: ReadPackage } | null>(null);
  const [label, setLabel] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const choose = async (selected: File | undefined) => {
    setError(null);
    setFile(null);
    if (!selected) return;
    try {
      const bytes = new Uint8Array(await selected.arrayBuffer());
      const pkg = await readPackage(bytes);
      setFile({ name: selected.name, bytes, pkg });
      setLabel(`Received package ${pkg.manifest.createdAt.slice(0, 10)}`);
    } catch (e) {
      setError(e instanceof PackageError ? e.message : 'The file could not be read.');
    }
  };
  const open = async (e: FormEvent) => {
    e.preventDefault();
    if (!file) return;
    setBusy(true);
    setError(null);
    try {
      const result = await openPackage(repos, unlocked, { bytes: file.bytes, label });
      select(result.engagementId);
      setFile(null);
      navigate('vendorshield');
    } catch (err) {
      setError(err instanceof PackageError || (err instanceof Error && err.name === 'IntegrityError') ? err.message : 'The package could not be opened. Nothing was saved.');
    } finally {
      setBusy(false);
    }
  };

  const m = file?.pkg.manifest;
  return (
    <Card>
      <CardHeader
        title="Open a protected package"
        description="Auditor side of the handoff. The package is checked (checksum, structure, declared profile, references) before anything is saved, and opens as a new engagement."
      />
      <CardBody>
        <form onSubmit={(e) => void open(e)} className="grid grid-cols-1 gap-4" noValidate>
          <div>
            <Label htmlFor="pkg-file">Protected package file ({PACKAGE_EXTENSION})</Label>
            <input id="pkg-file" type="file" accept={`${PACKAGE_EXTENSION},application/json`} onChange={(e) => void choose(e.target.files?.[0])}
              className="block w-full text-sm file:mr-3 file:rounded-md file:border file:border-slate-300 file:bg-white file:px-3 file:py-1.5 file:text-sm file:font-medium" />
          </div>
          {error ? <p role="alert" className="text-sm text-red-700">{error}</p> : null}
          {m && file ? (
            <>
              <Notice tone="ok" icon={<FileCheck2 aria-hidden />} title="Package verified">
                <dl className="grid grid-cols-1 gap-x-4 gap-y-1 sm:grid-cols-[12rem_1fr]" aria-label="Package contents">
                  <dt>Created</dt><dd>{formatInstant(m.createdAt)} · FY {m.financialYear}</dd>
                  <dt>Records</dt><dd>{m.counts.vendors} vendors, {m.counts.employees} employees, {m.counts.directors} directors, {m.counts.payments} payments</dd>
                  <dt>Label profile</dt><dd>{m.profile.id}</dd>
                  <dt>Tokens</dt><dd>{m.scheme.algorithm} v{m.scheme.tokenVersion}, key reference {m.scheme.keyId} (the key itself is not included)</dd>
                  <dt>Checksum</dt><dd className="font-mono text-xs break-all">{m.contentDigest.value}</dd>
                </dl>
              </Notice>
              <DisclosureLists disclosure={file.pkg.disclosure} />
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-[1fr_auto] sm:items-end">
                <div>
                  <Label htmlFor="pkg-label">Engagement label in this workspace</Label>
                  <Input id="pkg-label" value={label} onChange={(e) => setLabel(e.target.value)} autoComplete="off" />
                </div>
                <Button type="submit" disabled={busy}><FolderOpen aria-hidden /> {busy ? 'Opening…' : 'Open as new engagement'}</Button>
              </div>
            </>
          ) : null}
        </form>
      </CardBody>
    </Card>
  );
}
