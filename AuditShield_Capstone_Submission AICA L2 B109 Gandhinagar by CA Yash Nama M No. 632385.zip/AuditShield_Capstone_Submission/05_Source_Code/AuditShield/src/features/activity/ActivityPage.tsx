import { useLiveQuery } from 'dexie-react-hooks';
import { Activity } from 'lucide-react';
import { useEngagements, useStore } from '../../app/store';
import { Card, EmptyState, PageHeader } from '../../components/ui/primitives';
import { formatInstant } from '../../lib/cn';
import { Loading } from '../engagements/NeedEngagement';

export function ActivityPage() {
  const { repos } = useStore();
  const engagements = useEngagements();
  const events = useLiveQuery(() => repos.audit.list(), []);
  const nameOf = (id: string) =>
    id === '' ? 'Workspace' : engagements.ready ? (engagements.value.find((e) => e.id === id)?.name ?? '(deleted engagement)') : '…';

  return (
    <>
      <PageHeader
        title="Activity"
        description="What was done in this workspace, stored as metadata only: counts and record references, never identifiers, prompts or answers. A local log documents workflow; anyone with access to this browser profile could alter it, so it is not tamper-proof."
      />
      {!events ? <Loading /> : events.length === 0 ? (
        <EmptyState icon={<Activity aria-hidden />} title="No activity yet">Events appear here as you create engagements, save snapshots, run analyses and use the gateway.</EmptyState>
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <caption className="sr-only">Activity events, newest first</caption>
            <thead className="bg-slate-50 text-xs text-slate-600">
              <tr>
                <th scope="col" className="px-4 py-2 text-left font-medium">When</th>
                <th scope="col" className="px-4 py-2 text-left font-medium">Engagement</th>
                <th scope="col" className="px-4 py-2 text-left font-medium">Action</th>
                <th scope="col" className="px-4 py-2 text-left font-medium">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {events.map((e) => (
                <tr key={e.id} className="align-top">
                  <td className="px-4 py-2 whitespace-nowrap text-slate-600" title={e.at}>{formatInstant(e.at)}</td>
                  <td className="px-4 py-2 text-slate-700">{nameOf(e.engagementId)}</td>
                  <td className="px-4 py-2 font-medium text-slate-900">{e.action}</td>
                  <td className="px-4 py-2 text-slate-700">{e.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
    </>
  );
}
