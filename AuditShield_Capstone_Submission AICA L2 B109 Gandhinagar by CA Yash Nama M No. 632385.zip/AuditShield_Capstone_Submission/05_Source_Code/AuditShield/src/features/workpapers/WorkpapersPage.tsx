import { ClipboardList, FileDown } from 'lucide-react';
import { useState } from 'react';
import type { Navigate } from '../../app/App';
import { useEngagementData, useFindings, useStore, useWorkpapers } from '../../app/store';
import { Badge, Button, Card, CardBody, CardHeader, EmptyState, PageHeader, SeverityBadge, Stat } from '../../components/ui/primitives';
import type { EngagementView } from '../../data/repositories/repositories';
import { REVIEW_LABEL, REVIEW_STATUSES, type ReviewStatus } from '../../domain/vendor/review';
import { formatInstant } from '../../lib/cn';
import { downloadText } from '../../lib/download';
import { buildWorkpaperHtml } from '../../services/workpaper/exportHtml';
import { Loading, WithEngagement } from '../engagements/NeedEngagement';

function Workpapers({ engagement, navigate }: { engagement: EngagementView; navigate: Navigate }) {
  const { repos, clock } = useStore();
  const data = useEngagementData(engagement.id);
  const findings = useFindings(data.ready ? (data.value.run?.id ?? null) : null);
  const reviews = useWorkpapers(engagement.id);
  const [exported, setExported] = useState<string | null>(null);
  if (!data.ready || !findings.ready || !reviews.ready) return <Loading />;
  const { snapshot, run, ruleConfig } = data.value;

  if (!snapshot || !run) {
    return (
      <EmptyState icon={<ClipboardList aria-hidden />} title="No findings to review yet" action={<Button variant="outline" onClick={() => navigate('vendorshield')}>Open VendorShield</Button>}>
        Protect a dataset and run the analysis. Each finding can then be reviewed in VendorShield, and the reviewed findings exported from here.
      </EmptyState>
    );
  }

  const statusOf = (fingerprint: string): ReviewStatus => reviews.value.get(fingerprint)?.status ?? 'open';
  const counts = Object.fromEntries(REVIEW_STATUSES.map((s) => [s, findings.value.filter((f) => statusOf(f.fingerprint) === s).length])) as Record<ReviewStatus, number>;
  const reviewed = findings.value.length - counts.open;

  const exportHtml = async () => {
    const preparedAt = clock.now();
    const html = buildWorkpaperHtml({
      engagementName: engagement.name, financialYear: engagement.financialYear, preparedAt, snapshot, run, ruleConfig, findings: findings.value, reviews: reviews.value,
    });
    downloadText(`workpaper-vendor-indicators-${preparedAt.slice(0, 10)}.html`, html, 'text/html');
    await repos.audit.append({ id: clock.id(), at: preparedAt }, engagement.id, 'Workpaper exported', `${findings.value.length} findings, ${reviewed} reviewed, run ${run.id}`);
    setExported(preparedAt);
  };

  return (
    <div className="grid grid-cols-1 gap-4">
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Stat label="Findings in the current run" value={findings.value.length} hint={`Run finished ${formatInstant(run.finishedAt)}`} />
        <Stat label="Reviewed" value={`${reviewed} of ${findings.value.length}`} hint={`${counts.open} still open`} />
        <Stat label="Confirmed issues" value={counts['confirmed-issue']} hint="Decided by the auditor, with a written conclusion" />
        <Stat label="False positives / closed" value={`${counts['false-positive']} / ${counts.closed}`} hint={`${counts.investigating} investigating · ${counts['needs-information']} need information`} />
      </div>

      <Card>
        <CardHeader
          title="Workpaper"
          description="Every finding of the current run with its review. The export is a single HTML file with scope, thresholds, versions, evidence references and conclusions; open it in a browser to print or save as PDF."
          actions={<Button onClick={() => void exportHtml()}><FileDown aria-hidden /> Export workpaper (HTML)</Button>}
        />
        {exported ? (
          <CardBody className="border-b border-slate-200 text-sm text-emerald-800" role="status">
            Workpaper created {formatInstant(exported)}. It contains your notes and conclusions in readable form: store it with the audit file.
          </CardBody>
        ) : null}
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <caption className="sr-only">Findings and their review</caption>
            <thead className="bg-slate-50 text-xs text-slate-600">
              <tr>
                <th scope="col" className="px-4 py-2 text-left font-medium">Severity</th>
                <th scope="col" className="px-4 py-2 text-left font-medium">Finding</th>
                <th scope="col" className="px-4 py-2 text-left font-medium">Review</th>
                <th scope="col" className="px-4 py-2 text-left font-medium">Conclusion</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {findings.value.map((f) => {
                const r = reviews.value.get(f.fingerprint);
                return (
                  <tr key={f.fingerprint} className="align-top">
                    <td className="px-4 py-2"><SeverityBadge severity={f.severity} /></td>
                    <td className="px-4 py-2"><span className="font-medium text-slate-900">{f.title}</span><br /><span className="text-xs text-slate-600">{f.ruleId} · {f.ruleName}</span></td>
                    <td className="px-4 py-2 whitespace-nowrap">
                      <Badge tone={r && r.status !== 'open' ? 'info' : 'neutral'}>{REVIEW_LABEL[r?.status ?? 'open']}</Badge>
                      {r ? <span className="mt-1 block text-xs text-slate-600">rev. {r.revision} · {formatInstant(r.updatedAt)}</span> : null}
                    </td>
                    <td className="px-4 py-2 text-slate-700">{r?.conclusion || <span className="text-slate-500">—</span>}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <CardBody className="border-t border-slate-200 text-xs text-slate-600">
          Reviews are recorded against a finding’s evidence fingerprint, so a review carries over to a later run only when the evidence is the same.
          To add or change a review, select the finding in VendorShield.
        </CardBody>
      </Card>
    </div>
  );
}

export function WorkpapersPage({ navigate }: { navigate: Navigate }) {
  return (
    <WithEngagement
      navigate={navigate}
      purpose="keep workpapers for it"
      header={<PageHeader title="Workpapers" description="Review status, notes and conclusions for each finding, with a traceable export." />}
    >
      {(engagement) => <Workpapers key={engagement.id} engagement={engagement} navigate={navigate} />}
    </WithEngagement>
  );
}
