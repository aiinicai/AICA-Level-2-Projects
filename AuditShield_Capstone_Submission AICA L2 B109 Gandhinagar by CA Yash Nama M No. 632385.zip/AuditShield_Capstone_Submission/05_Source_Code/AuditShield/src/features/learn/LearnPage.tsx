import { FlaskConical } from 'lucide-react';
import { useState } from 'react';
import { Button, Card, CardBody, CardHeader, Notice, PageHeader, Stat } from '../../components/ui/primitives';
import { IDENTIFIER_TYPES, type IdentifierType } from '../../domain/privacy/detect';
import { BASELINE_EVAL_SET, type EvalReport, evaluateDetector } from '../../domain/privacy/evaluate';
import { RULE_NAMES } from '../../domain/vendor/rules';
import type { RuleId } from '../../domain/vendor/types';

const RULE_BASIS: Record<RuleId, string> = {
  R1: 'A vendor and an employee share a bank account, PAN or GSTIN token.',
  R2: 'A vendor shares any attribute token with a director.',
  R3: 'A vendor and an employee share only a phone or address token.',
  R4: 'Two vendor records share an attribute token.',
  R5: 'Two employee records share a bank account token.',
  R6: 'The same vendor and invoice reference is paid more than once. Instalments also match and need review.',
  R7: 'Several below-limit payments to one vendor inside the split window add up to the limit or more.',
  R8: 'Two or more payments to one vendor fall in the band just below the approval limit.',
  R9: 'The employee who created the vendor also approved payments to it.',
  R10: 'A round amount paid on a Saturday or Sunday.',
};

export function LearnPage() {
  const [report, setReport] = useState<EvalReport | null>(null);
  const pct = (n: number) => `${(n * 100).toFixed(1)}%`;

  return (
    <>
      <PageHeader
        title="Demo / Learn"
        description="Reference material and small demonstrations, kept apart from engagement work. Figures here describe tiny synthetic samples and are not accuracy guarantees."
      />
      <div className="grid grid-cols-1 gap-4">
        <Card>
          <CardHeader
            title="Masking detector on the built-in baseline set"
            description={`${BASELINE_EVAL_SET.length} fictional sentences with ${BASELINE_EVAL_SET.reduce((n, c) => n + c.expected.length, 0)} labelled identifiers. Runs in this browser.`}
            actions={<Button variant="outline" onClick={() => setReport(evaluateDetector(BASELINE_EVAL_SET))}><FlaskConical aria-hidden /> {report ? 'Run again' : 'Run evaluation'}</Button>}
          />
          <CardBody className="grid grid-cols-1 gap-4">
            {!report ? <p className="text-sm text-slate-600">Run the evaluation to see what the detector catches and misses on this set.</p> : (
              <>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-4">
                  <Stat label="Caught" value={`${report.tp} / ${report.labelled}`} hint={`Recall ${pct(report.recall)}`} />
                  <Stat label="Missed" value={report.fn} hint="Would have been sent in clear" />
                  <Stat label="False alarms" value={report.fp} hint={`Precision ${pct(report.precision)}`} />
                  <Stat label="Sentences" value={report.cases} hint="Too few to generalise from" />
                </div>
                <div className="overflow-x-auto rounded border border-slate-200">
                  <table className="w-full min-w-[420px] text-sm">
                    <caption className="sr-only">Results by identifier type</caption>
                    <thead className="bg-slate-50 text-xs text-slate-600">
                      <tr>
                        <th scope="col" className="px-3 py-2 text-left font-medium">Identifier type</th>
                        <th scope="col" className="px-3 py-2 text-right font-medium">Caught</th>
                        <th scope="col" className="px-3 py-2 text-right font-medium">Missed</th>
                        <th scope="col" className="px-3 py-2 text-right font-medium">False alarms</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {(Object.entries(report.perType) as [IdentifierType, { tp: number; fp: number; fn: number }][]).map(([type, c]) => (
                        <tr key={type}>
                          <td className="px-3 py-1.5">{IDENTIFIER_TYPES[type].label}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{c.tp}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{c.fn}</td>
                          <td className="px-3 py-1.5 text-right tabular-nums">{c.fp}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                {report.rows.filter((r) => r.miss.length || r.extra.length).map((r) => (
                  <Notice key={r.text} tone="warn" title="Remaining miss">
                    “{r.text}” — not detected: {r.miss.map((m) => m.split('|')[1]).join(', ') || 'none'}
                    {r.extra.length ? `; false alarm: ${r.extra.map((m) => m.split('|')[1]).join(', ')}` : ''}. A watch-list entry or a manual mask covers cases like this.
                  </Notice>
                ))}
              </>
            )}
            <p className="text-xs text-slate-600">
              A larger held-out corpus with lowercase names, regional scripts, OCR spacing and deliberate bypass attempts, reported per identifier type, is a
              planned next step.
            </p>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="What each VendorShield rule looks for" description="Deterministic rules. Each result is an indicator that needs investigation, not a conclusion." />
          <CardBody className="p-0">
            <table className="w-full text-sm">
              <caption className="sr-only">VendorShield rules</caption>
              <tbody className="divide-y divide-slate-200">
                {(Object.keys(RULE_NAMES) as RuleId[]).map((id) => (
                  <tr key={id} className="align-top">
                    <th scope="row" className="w-16 px-5 py-2 text-left font-medium text-slate-900">{id}</th>
                    <td className="px-2 py-2 font-medium text-slate-900">{RULE_NAMES[id]}</td>
                    <td className="px-5 py-2 text-slate-700">{RULE_BASIS[id]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="What keyed tokens do and do not protect" />
          <CardBody className="grid grid-cols-1 gap-2 text-sm text-slate-700">
            <p>
              Identifiers are normalised and replaced by HMAC-SHA256 tokens under a random key that stays with whoever prepared the data. Equal values give
              equal tokens, so matches can be found without the values. Without the key, guessing a phone number or PAN and checking it against a token is not
              possible in the way it is for a plain hash.
            </p>
            <p>
              Tokens are pseudonyms, not anonymisation. Whoever holds the key can test guesses, record IDs and any labels left readable still identify
              parties, and patterns of payments can identify a business. Treat a protected dataset as confidential.
            </p>
          </CardBody>
        </Card>
      </div>
    </>
  );
}
