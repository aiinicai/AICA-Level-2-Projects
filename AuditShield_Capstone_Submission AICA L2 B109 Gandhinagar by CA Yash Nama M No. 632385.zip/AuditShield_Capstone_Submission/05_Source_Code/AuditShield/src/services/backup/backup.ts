/**
 * Encrypted backup and restore of a whole workspace.
 *
 * File = small JSON header (readable: format, versions, date, record counts, KDF parameters) plus
 * one AES-GCM ciphertext of everything else. The key is derived from a passphrase with PBKDF2
 * under a fresh salt. The header is bound to the ciphertext as authenticated data, so changing a
 * version number or count makes decryption fail.
 *
 * Inside the ciphertext, fields that are encrypted at rest (engagement labels, source labels,
 * retained source data, retained HMAC keys) are carried in clear and re-encrypted under the new
 * workspace's own data key on restore. Retained source data and keys are included only when the
 * caller asks for them.
 *
 * Restore is all-or-nothing and only into an empty profile:
 *   read header â†’ refuse unknown/newer formats â†’ derive key â†’ decrypt (wrong passphrase or any
 *   tampering stops here) â†’ validate structure and references â†’ one transaction writes everything.
 * Nothing is written before the last step, and an existing workspace is never overwritten.
 *
 * A backup protects against losing the browser profile. Anyone with the file and the passphrase
 * can read it. The checksum-like authentication proves integrity under that passphrase; it does
 * not prove who made the file.
 */
import { z } from 'zod';
import {
  type AuditShieldDb, type EngagementKeyRecord, type EngagementRecord, type ImportRecord, type RawPayloadRecord, SCHEMA_VERSION,
  type WorkpaperRecord,
} from '../../data/db/schema';
import {
  createEnvelope, decryptBytes, decryptJson, deriveFileKey, encryptBytes, encryptJson, fromBase64, type KdfParams, KDF_V1,
  newKdfParams, recordAad, toBase64, WrongPassphraseError,
} from '../crypto/envelope';

export const BACKUP_FORMAT = 'auditshield-backup';
export const BACKUP_FORMAT_VERSION = 1;
export const APP_VERSION = '1.0.0';
const MAX_BACKUP_BYTES = 512 * 1024 * 1024;

const PLAIN_TABLES = ['entities', 'entityAttributes', 'payments', 'ruleSets', 'analysisRuns', 'findings', 'auditEvents', 'settings'] as const;
type PlainTable = (typeof PLAIN_TABLES)[number];

const headerSchema = z.strictObject({
  format: z.literal(BACKUP_FORMAT),
  formatVersion: z.number().int().positive(),
  appVersion: z.string().max(40),
  schemaVersion: z.number().int().positive(),
  createdAt: z.iso.datetime(),
  workspaceId: z.string().min(1).max(100),
  includesRetainedSource: z.boolean(),
  counts: z.record(z.string(), z.number().int().nonnegative()),
  kdf: z.strictObject({ name: z.literal('PBKDF2'), hash: z.literal('SHA-256'), iterations: z.number().int().min(1000).max(10_000_000), salt: z.string() }),
  cipher: z.strictObject({ name: z.literal('AES-GCM'), iv: z.string() }),
});
export type BackupHeader = z.infer<typeof headerSchema>;
const fileSchema = headerSchema.extend({ payload: z.string().min(1) });

const row = z.looseObject({});
const withId = z.looseObject({ id: z.string().min(1) });
const scoped = z.looseObject({ id: z.string().min(1), engagementId: z.string() });
const payloadSchema = z.strictObject({
  workspace: z.strictObject({ id: z.string().min(1), createdAt: z.string() }),
  engagements: z.array(z.looseObject({
    id: z.string().min(1), workspaceId: z.string(), financialYear: z.string(), kind: z.enum(['sample', 'client']),
    status: z.enum(['active', 'archived']), name: z.string(), createdAt: z.string(), updatedAt: z.string(),
  })),
  imports: z.array(z.looseObject({ id: z.string().min(1), engagementId: z.string(), sourceLabelText: z.string(), scheme: z.looseObject({ keyId: z.string() }) })),
  rawPayloads: z.array(z.looseObject({ id: z.string().min(1), engagementId: z.string(), raw: row, retentionExpiresAt: z.string(), createdAt: z.string() })),
  engagementKeys: z.array(z.looseObject({ id: z.string().min(1), engagementId: z.string(), keyBase64: z.string(), createdAt: z.string() })),
  entities: z.array(scoped.extend({ importId: z.string() })),
  entityAttributes: z.array(scoped.extend({ importId: z.string(), entityId: z.string() })),
  payments: z.array(scoped.extend({ importId: z.string(), amountPaise: z.number().int() })),
  ruleSets: z.array(withId),
  analysisRuns: z.array(scoped.extend({ importId: z.string(), ruleSetId: z.string() })),
  findings: z.array(scoped.extend({ runId: z.string() })),
  auditEvents: z.array(scoped),
  settings: z.array(z.looseObject({ key: z.string().min(1) })),
  workpapers: z.array(z.looseObject({
    id: z.string().min(1), engagementId: z.string(), findingFingerprint: z.string(), status: z.string(),
    notes: z.string(), conclusion: z.string(), revision: z.number().int(), updatedAt: z.string(),
  })),
});
type BackupPayload = z.infer<typeof payloadSchema>;

export class BackupError extends Error {
  constructor(
    readonly code: 'not-a-backup' | 'newer-format' | 'unsupported-schema' | 'wrong-passphrase-or-damaged' | 'invalid-content' | 'workspace-exists' | 'too-large',
    message: string,
  ) {
    super(message);
    this.name = 'BackupError';
  }
}

const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
/** Header fields in a fixed order: this exact byte string is authenticated with the ciphertext. */
const headerAad = (h: BackupHeader): Uint8Array<ArrayBuffer> =>
  encoder.encode(JSON.stringify([
    h.format, h.formatVersion, h.appVersion, h.schemaVersion, h.createdAt, h.workspaceId, h.includesRetainedSource,
    Object.entries(h.counts).sort(([a], [b]) => a.localeCompare(b)), h.kdf.name, h.kdf.hash, h.kdf.iterations, h.kdf.salt, h.cipher.name, h.cipher.iv,
  ]));

export interface ExportOptions {
  passphrase: string;
  /** Include encrypted-at-rest source copies and their HMAC keys. An explicit choice, never implied. */
  includeRetainedSource: boolean;
  createdAt: string;
  /** Tests only. */
  iterations?: number;
}

export async function exportBackup(db: AuditShieldDb, dek: CryptoKey, options: ExportOptions): Promise<{ bytes: Uint8Array<ArrayBuffer>; header: BackupHeader }> {
  // One read transaction: a consistent snapshot even if another tab is writing.
  const snapshot = await db.transaction('r', db.tables, async () => {
    const workspace = await db.workspace.toCollection().first();
    if (!workspace) throw new BackupError('invalid-content', 'There is no workspace to back up.');
    const plain = {} as Record<PlainTable, unknown[]>;
    for (const name of PLAIN_TABLES) plain[name] = await db.table(name).toArray();
    return {
      workspace, plain,
      engagements: await db.engagements.toArray(),
      imports: await db.imports.toArray(),
      workpapers: await db.workpapers.toArray(),
      rawPayloads: options.includeRetainedSource ? await db.rawPayloads.toArray() : [],
      engagementKeys: options.includeRetainedSource ? await db.engagementKeys.toArray() : [],
    };
  });
  const wid = snapshot.workspace.id;

  const payload: BackupPayload = {
    workspace: { id: wid, createdAt: snapshot.workspace.createdAt },
    engagements: await Promise.all(snapshot.engagements.map(async ({ label, ...rest }) => ({
      ...rest, name: await decryptJson<string>(dek, recordAad(wid, 'engagements', rest.id, 'label'), label),
    }))),
    imports: (await Promise.all(snapshot.imports.map(async ({ sourceLabel, ...rest }) => ({
      ...rest, sourceLabelText: await decryptJson<string>(dek, recordAad(wid, 'imports', rest.id, 'sourceLabel'), sourceLabel),
    })))) as unknown as BackupPayload['imports'],
    rawPayloads: await Promise.all(snapshot.rawPayloads.map(async ({ payload: box, ...rest }) => ({
      ...rest, raw: await decryptJson<Record<string, unknown>>(dek, recordAad(wid, 'rawPayloads', rest.id, 'payload'), box),
    }))),
    engagementKeys: await Promise.all(snapshot.engagementKeys.map(async ({ key, ...rest }) => ({
      ...rest, keyBase64: toBase64(await decryptBytes(dek, recordAad(wid, 'engagementKeys', rest.id, 'key'), key)),
    }))),
    workpapers: await Promise.all(snapshot.workpapers.map(async ({ body, ...rest }) => ({
      ...rest, ...(await decryptJson<{ notes: string; conclusion: string }>(dek, recordAad(wid, 'workpapers', rest.id, 'body'), body)),
    }))),
    ...(snapshot.plain as unknown as Pick<BackupPayload, PlainTable>),
  };

  const counts: Record<string, number> = {};
  for (const [name, value] of Object.entries(payload)) if (Array.isArray(value)) counts[name] = value.length;
  const kdf = newKdfParams(options.iterations ?? KDF_V1.iterations);
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const header: BackupHeader = {
    format: BACKUP_FORMAT, formatVersion: BACKUP_FORMAT_VERSION, appVersion: APP_VERSION, schemaVersion: SCHEMA_VERSION,
    createdAt: options.createdAt, workspaceId: wid, includesRetainedSource: options.includeRetainedSource, counts,
    kdf: { name: kdf.name, hash: kdf.hash, iterations: kdf.iterations, salt: toBase64(kdf.salt) },
    cipher: { name: 'AES-GCM', iv: toBase64(iv) },
  };
  const key = await deriveFileKey(options.passphrase, kdf);
  const ciphertext = new Uint8Array(await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: headerAad(header) }, key, encoder.encode(JSON.stringify(payload)),
  ));
  return { bytes: encoder.encode(JSON.stringify({ ...header, payload: toBase64(ciphertext) })), header };
}

/** Parses and checks the readable header without needing the passphrase (restore preview). */
export function readBackupHeader(bytes: Uint8Array): { header: BackupHeader; payload: string } {
  if (bytes.byteLength > MAX_BACKUP_BYTES) throw new BackupError('too-large', 'The file is larger than this version accepts for a backup.');
  let json: unknown;
  try {
    json = JSON.parse(decoder.decode(bytes));
  } catch {
    throw new BackupError('not-a-backup', 'This file is not an AuditShield backup.');
  }
  const format = (json as { format?: unknown; formatVersion?: unknown } | null)?.format;
  const version = (json as { formatVersion?: unknown } | null)?.formatVersion;
  if (format !== BACKUP_FORMAT) throw new BackupError('not-a-backup', 'This file is not an AuditShield backup.');
  if (typeof version === 'number' && version > BACKUP_FORMAT_VERSION) {
    throw new BackupError('newer-format', `This backup uses format version ${version}, which is newer than this app understands (${BACKUP_FORMAT_VERSION}). Use a newer AuditShield to restore it. Nothing was changed.`);
  }
  const parsed = fileSchema.safeParse(json);
  if (!parsed.success) throw new BackupError('not-a-backup', 'The backup file header is incomplete or malformed. Nothing was changed.');
  const { payload, ...header } = parsed.data;
  if (header.schemaVersion !== SCHEMA_VERSION) {
    throw new BackupError('unsupported-schema', header.schemaVersion > SCHEMA_VERSION
      ? `This backup holds database version ${header.schemaVersion}; this app supports version ${SCHEMA_VERSION}. Use a newer AuditShield. Nothing was changed.`
      : `This backup holds database version ${header.schemaVersion}, which this app version cannot upgrade on restore. Nothing was changed.`);
  }
  return { header, payload };
}

function checkReferences(p: BackupPayload, header: BackupHeader): string | null {
  for (const [name, expected] of Object.entries(header.counts)) {
    const actual = (p as Record<string, unknown>)[name];
    if (!Array.isArray(actual) || actual.length !== expected) return `record count for ${name} does not match the header`;
  }
  if (p.workspace.id !== header.workspaceId) return 'workspace identifier does not match the header';
  const engagements = new Set(p.engagements.map((e) => e.id));
  const imports = new Set(p.imports.map((i) => i.id));
  const runs = new Set(p.analysisRuns.map((r) => r.id));
  const entities = new Set(p.entities.map((e) => e.id));
  const ruleSets = new Set(p.ruleSets.map((r) => r.id));
  if (p.engagements.some((e) => e.workspaceId !== p.workspace.id)) return 'an engagement belongs to another workspace';
  const scopedTables = [p.imports, p.entities, p.entityAttributes, p.payments, p.analysisRuns, p.findings, p.rawPayloads, p.engagementKeys, p.workpapers];
  if (scopedTables.some((t) => t.some((r) => !engagements.has(r.engagementId)))) return 'a record refers to a missing engagement';
  if (p.auditEvents.some((e) => e.engagementId !== '' && !engagements.has(e.engagementId))) return 'an activity event refers to a missing engagement';
  if ([p.entities, p.entityAttributes, p.payments, p.analysisRuns].some((t) => t.some((r) => !imports.has(r.importId)))) return 'a record refers to a missing snapshot';
  if (p.rawPayloads.some((r) => !imports.has(r.id))) return 'a retained source copy refers to a missing snapshot';
  if (p.entityAttributes.some((a) => !entities.has(a.entityId))) return 'an attribute refers to a missing entity';
  if (p.analysisRuns.some((r) => !ruleSets.has(r.ruleSetId))) return 'a run refers to a missing rule set';
  if (p.findings.some((f) => !runs.has(f.runId))) return 'a finding refers to a missing run';
  for (const table of [p.engagements, p.imports, p.entities, p.entityAttributes, p.payments, p.ruleSets, p.analysisRuns, p.findings, p.auditEvents, p.workpapers]) {
    if (new Set(table.map((r) => r.id)).size !== table.length) return 'duplicate record identifiers';
  }
  return null;
}

export interface RestoreOptions {
  /** Decrypts the backup and becomes the passphrase of the restored workspace. */
  passphrase: string;
  at: string;
  auditId: string;
  /** Tests only: KDF cost of the new workspace envelope. */
  iterations?: number;
}

/** Restores into an empty profile. Returns the unlocked data key of the new workspace. */
export async function restoreBackup(db: AuditShieldDb, bytes: Uint8Array, options: RestoreOptions): Promise<{ dek: CryptoKey; header: BackupHeader }> {
  const { header, payload: payloadText } = readBackupHeader(bytes);
  if (await db.workspace.count()) {
    throw new BackupError('workspace-exists', 'This browser profile already has a workspace. A backup is only restored into an empty profile, so existing work is never overwritten.');
  }

  const kdf: KdfParams = { name: 'PBKDF2', hash: 'SHA-256', iterations: header.kdf.iterations, salt: fromBase64(header.kdf.salt) };
  let plain: BackupPayload;
  try {
    const key = await deriveFileKey(options.passphrase, kdf);
    const clear = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromBase64(header.cipher.iv), additionalData: headerAad(header) }, key, fromBase64(payloadText));
    plain = payloadSchema.parse(JSON.parse(decoder.decode(clear)));
  } catch (error) {
    if (error instanceof z.ZodError || error instanceof SyntaxError) {
      throw new BackupError('invalid-content', 'The backup decrypted but its contents are not valid. Nothing was changed.');
    }
    throw new BackupError('wrong-passphrase-or-damaged', 'The passphrase is wrong or the backup file has been altered or damaged. Nothing was changed.');
  }
  const problem = checkReferences(plain, header);
  if (problem) throw new BackupError('invalid-content', `The backup is inconsistent (${problem}). Nothing was changed.`);

  // Everything below is prepared in memory first; the database is touched once, at the end.
  const { envelope, dek } = await createEnvelope(options.passphrase, options.iterations ?? KDF_V1.iterations);
  const wid = plain.workspace.id;
  const engagements = await Promise.all(plain.engagements.map(async ({ name, ...rest }) => ({
    ...rest, label: await encryptJson(dek, recordAad(wid, 'engagements', rest.id, 'label'), name),
  }))) as unknown as EngagementRecord[];
  const imports = await Promise.all(plain.imports.map(async ({ sourceLabelText, ...rest }) => ({
    ...rest, sourceLabel: await encryptJson(dek, recordAad(wid, 'imports', rest.id, 'sourceLabel'), sourceLabelText),
  }))) as unknown as ImportRecord[];
  const rawPayloads = await Promise.all(plain.rawPayloads.map(async ({ raw, ...rest }) => ({
    ...rest, payload: await encryptJson(dek, recordAad(wid, 'rawPayloads', rest.id, 'payload'), raw),
  }))) as unknown as RawPayloadRecord[];
  const engagementKeys = await Promise.all(plain.engagementKeys.map(async ({ keyBase64, ...rest }) => ({
    ...rest, key: await encryptBytes(dek, recordAad(wid, 'engagementKeys', rest.id, 'key'), fromBase64(keyBase64)),
  }))) as unknown as EngagementKeyRecord[];
  const workpapers = await Promise.all(plain.workpapers.map(async ({ notes, conclusion, ...rest }) => ({
    ...rest, body: await encryptJson(dek, recordAad(wid, 'workpapers', rest.id, 'body'), { notes, conclusion }),
  }))) as unknown as WorkpaperRecord[];

  await db.transaction('rw', db.tables, async () => {
    if (await db.workspace.count()) throw new BackupError('workspace-exists', 'A workspace was created in this profile while the backup was being read. Nothing was changed.');
    await db.workspace.add({ id: wid, createdAt: plain.workspace.createdAt, envelope });
    await db.engagements.bulkAdd(engagements);
    await db.imports.bulkAdd(imports);
    await db.rawPayloads.bulkAdd(rawPayloads);
    await db.engagementKeys.bulkAdd(engagementKeys);
    await db.workpapers.bulkAdd(workpapers);
    for (const name of PLAIN_TABLES) await db.table(name).bulkAdd(plain[name]);
    await db.auditEvents.add({
      id: options.auditId, engagementId: '', at: options.at, action: 'Workspace restored from backup',
      detail: `backup of ${header.createdAt}, format ${header.formatVersion}, ${plain.engagements.length} engagements, retained source ${header.includesRetainedSource ? 'included' : 'not included'}`,
    });
  });
  return { dek, header };
}

export { WrongPassphraseError };
