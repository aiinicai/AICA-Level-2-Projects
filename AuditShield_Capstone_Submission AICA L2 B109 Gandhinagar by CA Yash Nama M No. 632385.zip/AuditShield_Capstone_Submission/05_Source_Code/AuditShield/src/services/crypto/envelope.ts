/**
 * Workspace encryption at rest, on Web Crypto primitives only.
 *
 *   passphrase --PBKDF2-SHA256(salt, iterations)--> key-encryption key (AES-GCM, wraps only)
 *   random 256-bit data key (DEK) --AES-GCM wrap--> stored `wrappedKey`
 *   sensitive record fields --AES-GCM(DEK, fresh 96-bit nonce, AAD = record identity)--> EncryptedBox
 *
 * - Only the wrapped DEK and public parameters are stored. The passphrase and DEK are never stored.
 * - After setup the DEK is held as a non-extractable CryptoKey: application code can use it but
 *   cannot read it.
 * - Every encryption draws a new random nonce. AAD binds a ciphertext to the workspace, store,
 *   record and field it belongs to, so a ciphertext copied elsewhere fails to decrypt.
 * - This key is unrelated to engagement HMAC keys (services/crypto/tokeniser.ts).
 *
 * Limits: this protects data at rest in a locked workspace. It does not protect against code
 * running in the unlocked page, and JavaScript cannot guarantee that key material is erased from
 * memory. There is no passphrase recovery.
 */

/** Versioned KDF parameters. Version 1: PBKDF2-HMAC-SHA256, 600,000 iterations, 16-byte salt. */
export const KDF_V1 = { name: 'PBKDF2', hash: 'SHA-256', iterations: 600_000 } as const;
export const MIN_PASSPHRASE_LENGTH = 10;

export interface KdfParams {
  name: 'PBKDF2';
  hash: 'SHA-256';
  iterations: number;
  salt: Uint8Array<ArrayBuffer>;
}

export interface KeyEnvelope {
  version: 1;
  kdf: KdfParams;
  wrap: { name: 'AES-GCM'; iv: Uint8Array<ArrayBuffer> };
  wrappedKey: Uint8Array<ArrayBuffer>;
}

export interface EncryptedBox {
  v: 1;
  iv: Uint8Array<ArrayBuffer>;
  ct: Uint8Array<ArrayBuffer>;
}

export class WrongPassphraseError extends Error {
  constructor() {
    super('The passphrase is not correct.');
    this.name = 'WrongPassphraseError';
  }
}
export class DecryptionError extends Error {
  constructor() {
    super('Stored data could not be decrypted. It may be damaged or belong to another workspace.');
    this.name = 'DecryptionError';
  }
}

const encoder = new TextEncoder();
const decoder = new TextDecoder('utf-8', { fatal: true });
const randomBytes = (n: number): Uint8Array<ArrayBuffer> => crypto.getRandomValues(new Uint8Array(n));

export function passphraseProblem(passphrase: string): string | null {
  if (passphrase.length < MIN_PASSPHRASE_LENGTH) return `Use at least ${MIN_PASSPHRASE_LENGTH} characters.`;
  if (/^(.)\1*$/.test(passphrase)) return 'Use more than one repeated character.';
  return null;
}

async function deriveKek(passphrase: string, kdf: KdfParams, usages: KeyUsage[]): Promise<CryptoKey> {
  // NFKC so the same passphrase typed on different keyboards/IMEs derives the same key.
  const material = await crypto.subtle.importKey('raw', encoder.encode(passphrase.normalize('NFKC')), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', hash: kdf.hash, salt: kdf.salt, iterations: kdf.iterations },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    usages,
  );
}

const DEK_USAGES: KeyUsage[] = ['encrypt', 'decrypt'];

/** Creates a new random data key and the envelope that stores it wrapped under the passphrase. */
export async function createEnvelope(passphrase: string, iterations: number = KDF_V1.iterations): Promise<{ envelope: KeyEnvelope; dek: CryptoKey }> {
  const kdf: KdfParams = { name: 'PBKDF2', hash: 'SHA-256', iterations, salt: randomBytes(16) };
  const kek = await deriveKek(passphrase, kdf, ['wrapKey']);
  // Extractable only for this one wrap; the handle is dropped and the key is re-imported locked.
  const extractable = await crypto.subtle.generateKey({ name: 'AES-GCM', length: 256 }, true, DEK_USAGES);
  const iv = randomBytes(12);
  const wrappedKey = new Uint8Array(await crypto.subtle.wrapKey('raw', extractable, kek, { name: 'AES-GCM', iv }));
  const envelope: KeyEnvelope = { version: 1, kdf, wrap: { name: 'AES-GCM', iv }, wrappedKey };
  return { envelope, dek: await openEnvelope(envelope, passphrase) };
}

/** Unwraps the data key. Throws WrongPassphraseError when authentication of the wrapped key fails. */
export async function openEnvelope(envelope: KeyEnvelope, passphrase: string): Promise<CryptoKey> {
  if (envelope.version !== 1) throw new Error(`Unsupported key envelope version ${String(envelope.version)}`);
  const kek = await deriveKek(passphrase, envelope.kdf, ['unwrapKey']);
  try {
    return await crypto.subtle.unwrapKey(
      'raw', envelope.wrappedKey, kek, { name: 'AES-GCM', iv: envelope.wrap.iv }, { name: 'AES-GCM', length: 256 }, false, DEK_USAGES,
    );
  } catch {
    throw new WrongPassphraseError();
  }
}

/** Authenticated additional data naming exactly where a ciphertext lives. */
export function recordAad(workspaceId: string, store: string, recordId: string, field: string): Uint8Array<ArrayBuffer> {
  return encoder.encode(['auditshield/aad/v1', workspaceId, store, recordId, field].join('\n'));
}

export async function encryptBytes(key: CryptoKey, aad: Uint8Array<ArrayBuffer>, plain: Uint8Array<ArrayBuffer>): Promise<EncryptedBox> {
  const iv = randomBytes(12);
  const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad }, key, plain));
  return { v: 1, iv, ct };
}

export async function decryptBytes(key: CryptoKey, aad: Uint8Array<ArrayBuffer>, box: EncryptedBox): Promise<Uint8Array<ArrayBuffer>> {
  if (box.v !== 1) throw new DecryptionError();
  try {
    return new Uint8Array(await crypto.subtle.decrypt({ name: 'AES-GCM', iv: box.iv, additionalData: aad }, key, box.ct));
  } catch {
    throw new DecryptionError();
  }
}

export const encryptJson = (key: CryptoKey, aad: Uint8Array<ArrayBuffer>, value: unknown): Promise<EncryptedBox> =>
  encryptBytes(key, aad, encoder.encode(JSON.stringify(value)));

export async function decryptJson<T>(key: CryptoKey, aad: Uint8Array<ArrayBuffer>, box: EncryptedBox): Promise<T> {
  return JSON.parse(decoder.decode(await decryptBytes(key, aad, box))) as T;
}

/** AES-GCM key from a passphrase, for whole-file encryption (backups). */
export async function deriveFileKey(passphrase: string, kdf: KdfParams): Promise<CryptoKey> {
  return deriveKek(passphrase, kdf, ['encrypt', 'decrypt']);
}
export const newKdfParams = (iterations: number = KDF_V1.iterations): KdfParams => ({
  name: 'PBKDF2', hash: 'SHA-256', iterations, salt: randomBytes(16),
});

/* ---- base64 for JSON file formats */
export function toBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}
export function fromBase64(text: string): Uint8Array<ArrayBuffer> {
  const binary = atob(text);
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}
