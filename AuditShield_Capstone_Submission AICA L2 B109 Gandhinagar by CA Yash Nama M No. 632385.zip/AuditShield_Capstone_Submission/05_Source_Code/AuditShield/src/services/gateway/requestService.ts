/**
 * The only path from the application to an AI provider.
 *
 * `dispatch` re-derives everything it needs to decide whether a request may leave:
 *  1. the reviewed scan must match the current text, watch-list, manual masks, policy version,
 *     destination and vault session exactly (otherwise: stale);
 *  2. the destination must be the one the registered adapter actually sends to;
 *  3. the complete outbound body (system prompt, history, masked message) is inspected again,
 *     immediately before the call.
 * If any check fails the provider is not called. There is no override parameter.
 * Restoration of the answer is limited to tokens that were present in the outbound body.
 */
import { buildOutboundMessages, type ChatMessage } from '../../domain/privacy/messages';
import {
  checkOutbound,
  checkSource,
  type OutboundViolation,
  type ReviewedScan,
  type ScanInputs,
  scanKey,
} from '../../domain/privacy/policy';
import { type Restoration, restore, type SessionVault } from '../../domain/privacy/vault';
import { ProviderError } from '../providers/openAiCompatible';
import type { ProviderAdapter } from '../providers/types';

export type BlockReason =
  | { code: 'stale-scan'; message: string }
  | { code: 'destination-not-allowed'; message: string }
  | { code: 'policy-violation'; message: string; violation: OutboundViolation };

export type DispatchOutcome =
  | { status: 'blocked'; reasons: BlockReason[] }
  | { status: 'answered'; answerMasked: string; restoration: Restoration; tokensSent: string[]; charactersSent: number }
  | { status: 'failed'; code: 'timeout' | 'provider-error' | 'invalid-response'; message: string }
  | { status: 'cancelled' };

export interface DispatchOptions {
  /** Earlier masked turns to include. They are inspected like everything else. */
  history?: readonly ChatMessage[];
  /** Lets the caller cancel. */
  signal?: AbortSignal;
  timeoutMs?: number;
}

export const DEFAULT_TIMEOUT_MS = 60_000;

const sameDestination = (a: ScanInputs['destination'], b: ScanInputs['destination']) =>
  a.providerId === b.providerId && a.kind === b.kind && a.endpoint === b.endpoint && a.model === b.model;

export class GatewayRequestService {
  private readonly providers = new Map<string, ProviderAdapter>();

  constructor(providers: readonly ProviderAdapter[]) {
    for (const p of providers) this.providers.set(p.destination.providerId, p);
  }

  /** Adds or replaces the adapter for a provider ID; `null` removes it. */
  register(providerId: string, adapter: ProviderAdapter | null): void {
    if (adapter) this.providers.set(providerId, adapter);
    else this.providers.delete(providerId);
  }
  has(providerId: string): boolean {
    return this.providers.has(providerId);
  }

  /** Every reason the request may not be sent right now. Empty array = allowed. */
  evaluate(scan: ReviewedScan, current: ScanInputs, vault: SessionVault, history: readonly ChatMessage[] = []): BlockReason[] {
    const reasons: BlockReason[] = [];
    if (scanKey(current) !== scan.key || current.vaultNamespace !== vault.namespace) {
      reasons.push({
        code: 'stale-scan',
        message: 'The text, watch-list, manual masks, policy or destination changed after this scan. Scan and review again.',
      });
    }
    const provider = this.providers.get(current.destination.providerId);
    if (!provider || !sameDestination(provider.destination, current.destination)) {
      reasons.push({
        code: 'destination-not-allowed',
        message: 'The selected destination is not a configured provider for this workspace.',
      });
    }
    const options = { watchlist: current.watchlist, manualTerms: current.manualTerms };
    const body = buildOutboundMessages(scan.masked, history).map((m) => m.content);
    for (const violation of [...checkSource(current.text, vault), ...checkOutbound(body, vault, options)]) {
      reasons.push({ code: 'policy-violation', message: violation.message, violation });
    }
    return reasons;
  }

  async dispatch(scan: ReviewedScan, current: ScanInputs, vault: SessionVault, options: DispatchOptions = {}): Promise<DispatchOutcome> {
    const history = options.history ?? [];
    const reasons = this.evaluate(scan, current, vault, history);
    if (reasons.length > 0) return { status: 'blocked', reasons };

    const provider = this.providers.get(current.destination.providerId) as ProviderAdapter;
    const messages = Object.freeze(buildOutboundMessages(scan.masked, history).map((m) => Object.freeze(m)));
    const outbound = messages.map((m) => m.content).join('\n');
    const authorised = new Set(vault.tokensIn(outbound));

    const controller = new AbortController();
    let timedOut = false;
    const timer = setTimeout(() => {
      timedOut = true;
      controller.abort();
    }, options.timeoutMs ?? DEFAULT_TIMEOUT_MS);
    const onCallerAbort = () => controller.abort();
    if (options.signal?.aborted) controller.abort();
    options.signal?.addEventListener('abort', onCallerAbort, { once: true });

    try {
      if (controller.signal.aborted) return { status: 'cancelled' };
      const answer = await provider.complete({ messages }, controller.signal);
      if (typeof answer !== 'string' || answer.trim() === '') {
        return { status: 'failed', code: 'invalid-response', message: 'The provider returned no text.' };
      }
      return {
        status: 'answered',
        answerMasked: answer,
        restoration: restore(answer, vault, authorised),
        tokensSent: [...authorised],
        charactersSent: outbound.length,
      };
    } catch (error) {
      if (timedOut) return { status: 'failed', code: 'timeout', message: 'The provider did not answer in time. Nothing was retried.' };
      if (controller.signal.aborted) return { status: 'cancelled' };
      // Adapter errors carry messages written by this app. Anything else may echo request
      // content, so only its type is shown.
      if (error instanceof ProviderError) {
        return { status: 'failed', code: error.code === 'invalid-response' ? 'invalid-response' : 'provider-error', message: `${error.message} Your draft is unchanged.` };
      }
      const name = error instanceof Error ? error.name : 'Error';
      return { status: 'failed', code: 'provider-error', message: `The provider call failed (${name}). Your draft is unchanged.` };
    } finally {
      clearTimeout(timer);
      options.signal?.removeEventListener('abort', onCallerAbort);
    }
  }
}

const NAMESPACE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

/** Random 4-character vault namespace (about one million possibilities) from the platform CSPRNG. */
export function newVaultNamespace(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(4)), (b) => NAMESPACE_ALPHABET[b % 32]).join('');
}
