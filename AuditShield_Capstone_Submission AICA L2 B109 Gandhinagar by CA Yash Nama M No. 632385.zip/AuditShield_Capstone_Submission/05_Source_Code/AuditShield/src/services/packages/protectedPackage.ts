/**
 * Protected package: the file a client (or the client-side preparer) hands to the auditor.
 *
 * Contents are exactly a stored protected snapshot: allowlisted entities with keyed tokens,
 * payments, and data-quality warnings that refer to records in the package. Never included:
 * source data, source file names, the engagement label, the HMAC key or any encryption key.
 *
 * The file is readable JSON on purpose, so anyone can open it and check what it contains. It is
 * pseudonymised, not anonymous: record IDs, amounts and dates are visible, so send it over the
 * firm's normal confidential channel.
 *
 * Import is strict: unknown fields anywhere are rejected (no unknown column can ride along), the
 * content must match its SHA-256 digest and counts, labels must match what the declared profile
 * allows, and the dataset must pass the same validation as a local snapshot. The digest detects
 * accidental damage; it does not prove who made the file, because anyone can recompute it.
 */
import { z } from 'zod';
import { NORMALISATION_VERSION } from '../../domain/vendor/normalise';
import {
  type DataQualityIssue, type EntityKind, type ExportProfile, MINIMAL_PROFILE, NAMED_PROFILE, type ProtectedDataset,
} from '../../domain/vendor/types';
import { validateProtectedDataset } from '../../domain/vendor/validate';
import { APP_VERSION } from '../backup/backup';
import { digestJson, TOKEN_ALGORITHM, TOKEN_VERSION } from '../crypto/tokeniser';

export const PACKAGE_FORMAT = 'auditshield-protected-package';
export const PACKAGE_FORMAT_VERSION = 1;
export const PACKAGE_EXTENSION = '.aspackage';
const MAX_PACKAGE_BYTES = 64 * 1024 * 1024;
const TOKEN = /^[0-9a-f]{64}$/;
const KNOWN_PROFILES: Record<ExportProfile['id'], ExportProfile> = { minimal: MINIMAL_PROFILE, named: NAMED_PROFILE };

/* ---------------------------------------------------------------- disclosure */

export interface Disclosure {
  readable: string[];
  tokenised: string[];
  excluded: string[];
}

/** Plain-language statement of what a profile leaves readable. Derived from the profile, never read from a file. */
export function describeProfile(p: ExportProfile): Disclosure {
  const readable = [
    'Record IDs of vendors, employees and payments',
    'Payment dates and amounts',
    'Who created each vendor and who approved each payment (employee IDs)',
  ];
  if (p.employeeDepartments) readable.push('Employee departments');
  if (p.vendorNames) readable.push('Vendor names');
  if (p.directorNames) readable.push('Director names');
  readable.push(p.directorIds ? 'Director DINs' : 'Director references D-001, D-002 … (not DINs)');
  if (p.invoiceNumbers === 'readable') readable.push('Invoice numbers');

  const tokenised = ['Bank account numbers', 'PANs, including PANs derived from valid GSTINs', 'GSTINs', 'Phone numbers', 'Addresses'];
  if (p.invoiceNumbers === 'tokenised') tokenised.push('Invoice numbers (equal numbers still match)');

  const excluded = [
    'Employee names',
    ...(p.vendorNames ? [] : ['Vendor names']),
    ...(p.directorNames ? [] : ['Director names']),
    ...(p.directorIds ? [] : ['Director DINs']),
    'Any column that is not on the allowlist',
    'Source files, file names and the engagement label',
    'The matching (HMAC) key and every encryption key',
  ];
  return { readable, tokenised, excluded };
}

/* ---------------------------------------------------------------- file schema */

const id = z.string().min(1).max(64);
const token = z.string().regex(TOKEN);
const attributes = z.strictObject({
  bank_account: token.optional(), pan: token.optional(), gstin: token.optional(), phone: token.optional(), address: token.optional(),
});
const entity = z.strictObject({
  kind: z.enum(['employee', 'vendor', 'director']), id, label: z.string().max(200), attributes, createdBy: id.optional(),
});
const payment = z.strictObject({
  id, vendorId: id, invoiceRef: z.string().max(200), date: z.string().max(10), amountPaise: z.number().int(), approvedBy: z.string().max(64),
});
const issue = z.strictObject({
  table: z.enum(['employees', 'vendors', 'directors', 'payments']),
  recordId: z.string().max(64),
  field: z.string().max(40),
  severity: z.enum(['error', 'warning']),
  code: z.enum(['placeholder-value', 'too-short', 'invalid-structure', 'invalid-checksum', 'not-normalisable']),
  message: z.string().max(300),
});
const profile = z.strictObject({
  id: z.enum(['minimal', 'named']), vendorNames: z.boolean(), directorNames: z.boolean(), directorIds: z.boolean(),
  employeeDepartments: z.boolean(), invoiceNumbers: z.enum(['readable', 'tokenised']),
});
const count = z.number().int().nonnegative();
const manifestSchema = z.strictObject({
  format: z.literal(PACKAGE_FORMAT),
  formatVersion: z.literal(PACKAGE_FORMAT_VERSION),
  packageId: z.string().min(1).max(100),
  createdAt: z.iso.datetime(),
  appVersion: z.string().max(40),
  financialYear: z.string().regex(/^\d{4}-\d{2}$/),
  importSchemaVersion: z.literal(1),
  scheme: z.strictObject({
    algorithm: z.literal(TOKEN_ALGORITHM), tokenVersion: z.literal(TOKEN_VERSION), normalisationVersion: z.literal(NORMALISATION_VERSION),
    keyId: z.string().regex(/^k_[0-9a-f]{16}$/),
  }),
  profile,
  disclosure: z.strictObject({ readable: z.array(z.string().max(200)).max(50), tokenised: z.array(z.string().max(200)).max(50), excluded: z.array(z.string().max(200)).max(50) }),
  counts: z.strictObject({ employees: count, vendors: count, directors: count, payments: count, issues: count }),
  contentDigest: z.strictObject({ algorithm: z.literal('SHA-256'), value: z.string().regex(/^[0-9a-f]{64}$/) }),
});
const fileSchema = z.strictObject({
  manifest: manifestSchema,
  content: z.strictObject({
    entities: z.array(entity).max(1_000_000),
    payments: z.array(payment).max(5_000_000),
    issues: z.array(issue).max(1_000_000),
  }),
});
export type PackageManifest = z.infer<typeof manifestSchema>;

export class PackageError extends Error {
  constructor(
    readonly code:
      | 'too-large' | 'not-a-package' | 'newer-format' | 'unsupported-scheme' | 'malformed' | 'digest-mismatch'
      | 'count-mismatch' | 'unsupported-profile' | 'inconsistent-profile' | 'invalid-data',
    message: string,
  ) {
    super(message);
    this.name = 'PackageError';
  }
}

/* ---------------------------------------------------------------- checks shared by export and import */

const TABLE_KIND: Record<DataQualityIssue['table'], EntityKind | 'payment'> = {
  employees: 'employee', vendors: 'vendor', directors: 'director', payments: 'payment',
};

function recordKeys(data: ProtectedDataset): Set<string> {
  return new Set([...data.entities.map((e) => `${e.kind}|${e.id}`), ...data.payments.map((p) => `payment|${p.id}`)]);
}
const issueKey = (i: DataQualityIssue) => `${TABLE_KIND[i.table]}|${i.recordId}`;

/** Does every label match what the profile says is readable? Returns the first mismatch. */
function profileProblem(data: ProtectedDataset): string | null {
  const p = data.profile;
  for (const e of data.entities) {
    if (e.kind === 'vendor' && !p.vendorNames && e.label !== e.id) return `vendor ${e.id} carries a name although vendor names are excluded`;
    if (e.kind === 'director' && !p.directorIds && !/^D-\d{3,}$/.test(e.id)) return 'a director is identified by something other than a package reference although DINs are excluded';
    if (e.kind === 'director' && !p.directorNames && e.label !== e.id) return `director ${e.id} carries a name although director names are excluded`;
    if (e.kind === 'employee' && e.label !== e.id && !(p.employeeDepartments && e.label.startsWith(`${e.id} (`))) {
      return `employee ${e.id} carries a label other than its ID and department`;
    }
  }
  if (p.invoiceNumbers === 'tokenised' && data.payments.some((x) => x.invoiceRef !== '' && !TOKEN.test(x.invoiceRef))) {
    return 'an invoice number is readable although invoice numbers are tokenised';
  }
  return null;
}

/* ---------------------------------------------------------------- export */

export interface BuildPackageInput {
  data: ProtectedDataset;
  issues: readonly DataQualityIssue[];
  financialYear: string;
  packageId: string;
  createdAt: string;
}

export async function buildPackage(input: BuildPackageInput): Promise<{ text: string; manifest: PackageManifest; droppedIssues: number }> {
  const { data } = input;
  const problem = profileProblem(data);
  if (problem) throw new PackageError('inconsistent-profile', `The snapshot does not match its own profile (${problem}). Protect the data again.`);
  // Only warnings about records that are in the package; anything else could name a hidden record.
  const keys = recordKeys(data);
  const issues = input.issues.filter((i) => keys.has(issueKey(i)));
  const content = {
    entities: data.entities.map((e) => ({ kind: e.kind, id: e.id, label: e.label, attributes: e.attributes, ...(e.createdBy ? { createdBy: e.createdBy } : {}) })),
    payments: data.payments.map((p) => ({ id: p.id, vendorId: p.vendorId, invoiceRef: p.invoiceRef, date: p.date, amountPaise: p.amountPaise, approvedBy: p.approvedBy })),
    issues: issues.map((i) => ({ table: i.table, recordId: i.recordId, field: i.field, severity: i.severity, code: i.code, message: i.message })),
  };
  const manifest: PackageManifest = {
    format: PACKAGE_FORMAT,
    formatVersion: PACKAGE_FORMAT_VERSION,
    packageId: input.packageId,
    createdAt: input.createdAt,
    appVersion: APP_VERSION,
    financialYear: input.financialYear,
    importSchemaVersion: 1,
    scheme: { algorithm: TOKEN_ALGORITHM, tokenVersion: TOKEN_VERSION, normalisationVersion: NORMALISATION_VERSION, keyId: data.scheme.keyId },
    profile: { ...data.profile },
    disclosure: describeProfile(data.profile),
    counts: {
      employees: content.entities.filter((e) => e.kind === 'employee').length,
      vendors: content.entities.filter((e) => e.kind === 'vendor').length,
      directors: content.entities.filter((e) => e.kind === 'director').length,
      payments: content.payments.length,
      issues: content.issues.length,
    },
    contentDigest: { algorithm: 'SHA-256', value: await digestJson(content) },
  };
  // Parse our own output before handing it out: an export that would fail import never leaves.
  const text = `${JSON.stringify({ manifest, content }, null, 2)}\n`;
  await readPackage(new TextEncoder().encode(text));
  return { text, manifest, droppedIssues: input.issues.length - issues.length };
}

/* ---------------------------------------------------------------- import */

export interface ReadPackage {
  manifest: PackageManifest;
  data: ProtectedDataset;
  issues: DataQualityIssue[];
  /** Recomputed from the validated profile, not taken from the file's text. */
  disclosure: Disclosure;
}

export async function readPackage(bytes: Uint8Array): Promise<ReadPackage> {
  if (bytes.byteLength > MAX_PACKAGE_BYTES) throw new PackageError('too-large', 'The file is larger than this version accepts for a package (64 MB).');
  let raw: unknown;
  try {
    raw = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
  } catch {
    throw new PackageError('not-a-package', 'This file is not an AuditShield protected package.');
  }
  const m = (raw as { manifest?: { format?: unknown; formatVersion?: unknown; scheme?: { tokenVersion?: unknown; normalisationVersion?: unknown } } } | null)?.manifest;
  if (m?.format !== PACKAGE_FORMAT) throw new PackageError('not-a-package', 'This file is not an AuditShield protected package.');
  if (typeof m.formatVersion === 'number' && m.formatVersion > PACKAGE_FORMAT_VERSION) {
    throw new PackageError('newer-format', `This package uses format version ${m.formatVersion}; this app understands version ${PACKAGE_FORMAT_VERSION}. Use a newer AuditShield.`);
  }
  if (m.scheme?.tokenVersion !== TOKEN_VERSION || m.scheme?.normalisationVersion !== NORMALISATION_VERSION) {
    throw new PackageError('unsupported-scheme', 'The package uses a token or normalisation scheme this app does not match against (for example a package from the original capstone tool). Ask for a package made with this version.');
  }

  const parsed = fileSchema.safeParse(raw);
  if (!parsed.success) {
    const first = parsed.error.issues[0];
    throw new PackageError('malformed', `The package structure is not valid at ${first?.path.join('.') || 'the top level'}: ${first?.message ?? 'unknown problem'}. Unknown or extra fields are not accepted.`);
  }
  const { manifest, content } = parsed.data;

  if ((await digestJson((raw as { content: unknown }).content)) !== manifest.contentDigest.value) {
    throw new PackageError('digest-mismatch', 'The package contents do not match their checksum. The file was altered or damaged after it was made.');
  }
  const known = KNOWN_PROFILES[manifest.profile.id];
  if (JSON.stringify(manifest.profile) !== JSON.stringify(known)) {
    throw new PackageError('unsupported-profile', 'The package declares a label profile this app does not know.');
  }

  const data: ProtectedDataset = {
    scheme: { algorithm: manifest.scheme.algorithm, tokenVersion: manifest.scheme.tokenVersion, normalisationVersion: manifest.scheme.normalisationVersion, keyId: manifest.scheme.keyId },
    profile: known,
    entities: content.entities,
    payments: content.payments,
  };
  const counted = {
    employees: data.entities.filter((e) => e.kind === 'employee').length,
    vendors: data.entities.filter((e) => e.kind === 'vendor').length,
    directors: data.entities.filter((e) => e.kind === 'director').length,
    payments: data.payments.length,
    issues: content.issues.length,
  };
  if (JSON.stringify(counted) !== JSON.stringify(manifest.counts)) {
    throw new PackageError('count-mismatch', 'The record counts in the package do not match its manifest.');
  }
  const problem = profileProblem(data);
  if (problem) throw new PackageError('inconsistent-profile', `The package contains more than its manifest declares: ${problem}.`);

  const errors = validateProtectedDataset(data);
  const keys = recordKeys(data);
  const orphanIssue = content.issues.find((i) => !keys.has(issueKey(i)));
  if (errors.length || orphanIssue) {
    const details = errors.slice(0, 3).map((e) => e.message);
    if (orphanIssue) details.push(`a data-quality warning refers to ${orphanIssue.table} ${orphanIssue.recordId}, which is not in the package`);
    throw new PackageError('invalid-data', `The package data is not valid (${errors.length + (orphanIssue ? 1 : 0)} problem(s)): ${details.join('; ')}.`);
  }
  return { manifest, data, issues: content.issues, disclosure: describeProfile(known) };
}
