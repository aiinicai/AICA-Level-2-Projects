import { offlineDemoReply } from '../../domain/privacy/offlineDemo';
import type { Destination } from '../../domain/privacy/policy';
import type { ProviderAdapter, ProviderRequest } from './types';

export const OFFLINE_DEMO_DESTINATION: Destination = {
  providerId: 'offline-demo',
  kind: 'offline-demo',
  label: 'Offline demo (canned reply, nothing leaves this browser)',
  endpoint: null,
  model: null,
};

/** Never touches the network. The short delay only makes the pending state visible. */
export function createOfflineDemoProvider(delayMs = 400): ProviderAdapter {
  return {
    destination: OFFLINE_DEMO_DESTINATION,
    complete(request: ProviderRequest, signal: AbortSignal): Promise<string> {
      return new Promise((resolve, reject) => {
        const abort = () => {
          clearTimeout(timer);
          reject(new DOMException('Request cancelled', 'AbortError'));
        };
        if (signal.aborted) return abort();
        const timer = setTimeout(() => {
          signal.removeEventListener('abort', abort);
          resolve(offlineDemoReply(request.messages.at(-1)?.content ?? ''));
        }, delayMs);
        signal.addEventListener('abort', abort, { once: true });
      });
    },
  };
}
