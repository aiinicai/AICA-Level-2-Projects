/**
 * Local model adapter: an OpenAI-compatible chat endpoint running on this computer, such as the
 * LM Studio local server (default http://127.0.0.1:1234/v1/chat/completions) or Ollama.
 *
 * Destination policy: only http(s) on localhost / 127.0.0.1 / [::1] is accepted, so this adapter
 * can never send to the internet. No API key is used or stored. The response is validated before
 * use, and every failure becomes a ProviderError whose message is written by this app (never
 * the provider's own text, which could echo the request).
 */
import { z } from 'zod';
import type { Destination } from '../../domain/privacy/policy';
import type { ProviderAdapter, ProviderRequest } from './types';

export const LOCAL_MODEL_PROVIDER_ID = 'local-model';
export const DEFAULT_LOCAL_ENDPOINT = 'http://127.0.0.1:1234/v1/chat/completions';
const LOCAL_HOSTS = new Set(['127.0.0.1', 'localhost', '[::1]']);

export interface LocalModelConfig {
  endpoint: string;
  model: string;
}

export class ProviderError extends Error {
  constructor(readonly code: 'unreachable' | 'auth' | 'rate-limit' | 'http' | 'invalid-response', message: string) {
    super(message);
    this.name = 'ProviderError';
  }
}

/** Returns why the endpoint is not allowed, or null. */
export function localEndpointProblem(endpoint: string): string | null {
  let url: URL;
  try {
    url = new URL(endpoint);
  } catch {
    return 'Enter a full address such as http://127.0.0.1:1234/v1/chat/completions.';
  }
  if (url.protocol !== 'http:' && url.protocol !== 'https:') return 'Only http or https addresses are allowed.';
  if (!LOCAL_HOSTS.has(url.hostname)) return 'A local model must run on this computer (localhost or 127.0.0.1). Internet addresses are not accepted here.';
  if (url.username || url.password || url.search || url.hash) return 'The address must not contain credentials, a query or a fragment.';
  if (!url.pathname.endsWith('/chat/completions')) return 'The address must end with /chat/completions (OpenAI-compatible chat endpoint).';
  return null;
}

export function localModelDestination(config: LocalModelConfig): Destination {
  const host = new URL(config.endpoint).host;
  return {
    providerId: LOCAL_MODEL_PROVIDER_ID, kind: 'local-model',
    label: `Local model ${config.model} at ${host} (this computer)`,
    endpoint: config.endpoint, model: config.model,
  };
}

const responseSchema = z.object({
  choices: z.array(z.object({ message: z.object({ content: z.string() }) })).min(1),
});
const modelsSchema = z.object({ data: z.array(z.object({ id: z.string().max(300) })) });

type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

async function call(fetchImpl: FetchLike, url: string, init: RequestInit): Promise<unknown> {
  let response: Response;
  try {
    response = await fetchImpl(url, init);
  } catch (error) {
    if (error instanceof DOMException && error.name === 'AbortError') throw error;
    throw new ProviderError('unreachable', 'The local model server did not respond. Start the server in LM Studio (Developer tab), enable CORS, and check the address.');
  }
  if (response.status === 401 || response.status === 403) throw new ProviderError('auth', 'The local server refused the request (authentication).');
  if (response.status === 429) throw new ProviderError('rate-limit', 'The local server is busy (too many requests). Wait and try again; nothing was resent automatically.');
  if (!response.ok) throw new ProviderError('http', `The local server answered with HTTP ${response.status}. Check that a model is loaded.`);
  try {
    return await response.json();
  } catch {
    throw new ProviderError('invalid-response', 'The local server returned something that is not valid JSON.');
  }
}

export function createLocalModelProvider(config: LocalModelConfig, fetchImpl: FetchLike = (i, init) => fetch(i, init)): ProviderAdapter {
  const problem = localEndpointProblem(config.endpoint);
  if (problem) throw new ProviderError('http', problem);
  return {
    destination: localModelDestination(config),
    async complete(request: ProviderRequest, signal: AbortSignal): Promise<string> {
      const body = JSON.stringify({ model: config.model, messages: request.messages, temperature: 0.2, stream: false });
      const json = await call(fetchImpl, config.endpoint, {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body, signal, credentials: 'omit', referrerPolicy: 'no-referrer', cache: 'no-store',
      });
      const parsed = responseSchema.safeParse(json);
      if (!parsed.success) throw new ProviderError('invalid-response', 'The local server’s answer did not have the expected chat-completion shape.');
      return parsed.data.choices[0]?.message.content ?? '';
    },
  };
}

/** Lists model IDs from the server's /models endpoint (sends no user data). */
export async function listLocalModels(endpoint: string, fetchImpl: FetchLike = (i, init) => fetch(i, init), signal?: AbortSignal): Promise<string[]> {
  const problem = localEndpointProblem(endpoint);
  if (problem) throw new ProviderError('http', problem);
  const url = endpoint.replace(/\/chat\/completions$/, '/models');
  const parsed = modelsSchema.safeParse(await call(fetchImpl, url, { method: 'GET', credentials: 'omit', cache: 'no-store', ...(signal ? { signal } : {}) }));
  if (!parsed.success) throw new ProviderError('invalid-response', 'The server’s model list did not have the expected shape.');
  return parsed.data.data.map((m) => m.id);
}
