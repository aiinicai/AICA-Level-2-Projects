/**
 * Provider adapter contract. An adapter receives an already approved, frozen, masked request and
 * nothing else: it has no access to raw text, the vault or UI state. Each wire protocol gets its
 * own adapter (Phase 5 adds local OpenAI-compatible and external adapters).
 */
import type { ChatMessage } from '../../domain/privacy/messages';
import type { Destination } from '../../domain/privacy/policy';

export interface ProviderRequest {
  readonly messages: readonly Readonly<ChatMessage>[];
}

export interface ProviderAdapter {
  /** Where this adapter sends data. Must equal the destination the user reviewed. */
  readonly destination: Destination;
  /** Resolves with the model's text. Must reject with an AbortError when `signal` aborts. */
  complete(request: ProviderRequest, signal: AbortSignal): Promise<string>;
}
