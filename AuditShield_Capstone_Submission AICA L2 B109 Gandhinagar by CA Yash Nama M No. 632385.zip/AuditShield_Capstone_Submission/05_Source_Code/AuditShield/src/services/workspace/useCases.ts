/**
 * Application use-cases: the sequences that combine domain functions, crypto and repositories.
 * No React here; screens call these and tests exercise them directly against a database.
 */
import type { AnalysisRunRecord, ImportRecord, WorkspaceRecord } from '../../data/db/schema';
import { IntegrityError, type Repositories, ruleSetIdFor } from '../../data/repositories/repositories';
import { buildPackage, readPackage } from '../packages/protectedPackage';
import { protectDataset } from '../../domain/vendor/protect';
import { analyse } from '../../domain/vendor/rules';
import { DEFAULT_RULE_CONFIG, type ExportProfile, type RawDataset, type RuleConfig } from '../../domain/vendor/types';
import { createEnvelope, KDF_V1, openEnvelope, passphraseProblem } from '../crypto/envelope';
import { createTokeniser, digestJson, type EngagementKey, exportEngagementKey } from '../crypto/tokeniser';

export interface Clock {
  id(): string;
  now(): string;
}
export const systemClock: Clock = { id: () => crypto.randomUUID(), now: () => new Date().toISOString() };

export const SETTING = {
  currentEngagement: 'currentEngagementId',
  autoLockMinutes: 'autoLockMinutes',
  retentionDays: 'rawRetentionDays',
  lastBackupAt: 'lastBackupAt',
  /** Local model server address and model name (not secret; no API key is ever stored). */
  localModel: 'localModel',
  ruleConfig: (engagementId: string) => `ruleConfig:${engagementId}`,
} as const;
export const DEFAULT_AUTO_LOCK_MINUTES = 15;
export const DEFAULT_RETENTION_DAYS = 30;

export interface UnlockedWorkspace {
  workspace: WorkspaceRecord;
  dek: CryptoKey;
}

export async function setupWorkspace(repos: Repositories, passphrase: string, clock: Clock = systemClock, iterations: number = KDF_V1.iterations): Promise<UnlockedWorkspace> {
  const problem = passphraseProblem(passphrase);
  if (problem) throw new Error(problem);
  const { envelope, dek } = await createEnvelope(passphrase, iterations);
  const workspace = await repos.workspace.create({ id: clock.id(), at: clock.now() }, envelope, clock.id());
  return { workspace, dek };
}

/** Throws WrongPassphraseError on a wrong passphrase; the stored data is not touched either way. */
export async function unlockWorkspace(repos: Repositories, passphrase: string): Promise<UnlockedWorkspace> {
  const workspace = await repos.workspace.get();
  if (!workspace) throw new Error('No workspace exists in this browser profile.');
  return { workspace, dek: await openEnvelope(workspace.envelope, passphrase) };
}

export async function getRuleConfig(repos: Repositories, engagementId: string): Promise<RuleConfig> {
  return repos.settings.get<RuleConfig>(SETTING.ruleConfig(engagementId), DEFAULT_RULE_CONFIG);
}

export interface ProtectAndCommitInput {
  engagementId: string;
  raw: RawDataset;
  sourceType: ImportRecord['sourceType'];
  sourceLabel: string;
  profile: ExportProfile;
  key: EngagementKey;
  /** null = do not keep the source (default). A number keeps an encrypted copy for that many days (0 = until deleted). */
  retainDays: number | null;
}

/** Protects source data and commits the result as an immutable snapshot, or throws having written nothing. */
export async function protectAndCommit(repos: Repositories, session: UnlockedWorkspace, input: ProtectAndCommitInput, clock: Clock = systemClock): Promise<ImportRecord> {
  const outcome = await protectDataset(input.raw, { tokenise: createTokeniser(input.key), keyId: input.key.keyId, profile: input.profile });
  const at = clock.now();
  const retain = input.retainDays === null ? undefined : {
    raw: input.raw,
    keyBytes: await exportEngagementKey(input.key),
    expiresAt: input.retainDays > 0 ? new Date(Date.parse(at) + input.retainDays * 86_400_000).toISOString() : '',
  };
  return repos.datasets.commitImport(session.dek, {
    importId: clock.id(), engagementId: input.engagementId, workspaceId: session.workspace.id, at,
    sourceType: input.sourceType, sourceLabel: input.sourceLabel, sourceDigest: await digestJson(input.raw),
    data: outcome.data, issues: outcome.issues, ...(retain ? { retain } : {}), auditId: clock.id(),
  });
}

/** Runs the rules on a stored snapshot (never on in-memory source data) and stores the run. */
export async function analyseSnapshot(repos: Repositories, input: { engagementId: string; importId: string; ruleConfig: RuleConfig }, clock: Clock = systemClock): Promise<AnalysisRunRecord> {
  const startedAt = clock.now();
  const data = await repos.datasets.loadProtected(input.importId);
  const result = analyse(data, input.ruleConfig);
  return repos.runs.save({ runId: clock.id(), engagementId: input.engagementId, importId: input.importId, result, startedAt, finishedAt: clock.now(), auditId: clock.id() });
}

/** The run to show as current: this snapshot under exactly the current thresholds. Older runs stay stored. */
export async function currentRun(repos: Repositories, importId: string, ruleConfig: RuleConfig): Promise<AnalysisRunRecord | undefined> {
  return repos.runs.latest(importId, ruleSetIdFor(ruleConfig));
}

/* ---------------------------------------------------------------- client → auditor handoff */

/** Builds a protected package from a stored snapshot (never from source data in memory). */
export async function exportPackage(repos: Repositories, input: { engagementId: string; importId: string; financialYear: string }, clock: Clock = systemClock) {
  const record = await repos.datasets.importById(input.importId);
  if (!record || record.engagementId !== input.engagementId) throw new IntegrityError('The snapshot does not belong to this engagement.');
  const data = await repos.datasets.loadProtected(record.id);
  const createdAt = clock.now();
  const built = await buildPackage({ data, issues: record.issues, financialYear: input.financialYear, packageId: `pkg_${clock.id()}`, createdAt });
  const c = built.manifest.counts;
  await repos.audit.append({ id: clock.id(), at: createdAt }, input.engagementId, 'Protected package exported',
    `${built.manifest.packageId}: ${c.vendors} vendors, ${c.employees} employees, ${c.directors} directors, ${c.payments} payments, profile "${built.manifest.profile.id}", key reference ${built.manifest.scheme.keyId}, digest ${built.manifest.contentDigest.value.slice(0, 16)}…`);
  return built;
}

/**
 * Opens a protected package as a new engagement in this workspace. Everything is validated before
 * anything is written; the workspace receives no source data and no key.
 */
export async function openPackage(repos: Repositories, session: UnlockedWorkspace, input: { bytes: Uint8Array; label: string }, clock: Clock = systemClock) {
  const pkg = await readPackage(input.bytes);
  const label = input.label.trim();
  if (label.length < 2) throw new IntegrityError('Enter an engagement label of at least 2 characters.');
  const engagement = await repos.engagements.create(session.dek, session.workspace.id, { id: clock.id(), at: clock.now() }, { name: label, financialYear: pkg.manifest.financialYear, kind: 'client' }, clock.id());
  try {
    const snapshot = await repos.datasets.commitImport(session.dek, {
      importId: clock.id(), engagementId: engagement.id, workspaceId: session.workspace.id, at: clock.now(), sourceType: 'package',
      sourceLabel: `Protected package ${pkg.manifest.packageId}, created ${pkg.manifest.createdAt}`,
      sourceDigest: pkg.manifest.contentDigest.value, data: pkg.data, issues: pkg.issues, auditId: clock.id(),
    });
    await repos.audit.append({ id: clock.id(), at: clock.now() }, engagement.id, 'Protected package opened',
      `${pkg.manifest.packageId} created ${pkg.manifest.createdAt}; checksum, structure, profile and references verified; no source data or key received`);
    return { engagementId: engagement.id, snapshot, manifest: pkg.manifest };
  } catch (error) {
    // Do not leave an empty engagement behind.
    await repos.engagements.remove(engagement.id, { id: clock.id(), at: clock.now() });
    throw error;
  }
}

/** Deletes retained source copies whose retention period has ended. Returns how many were removed. */
export async function purgeExpiredSource(repos: Repositories, clock: Clock = systemClock): Promise<number> {
  const now = clock.now();
  const expired = await repos.datasets.expiredRetained(now);
  let removed = 0;
  for (const engagementId of new Set(expired.map((e) => e.engagementId))) {
    const ids = expired.filter((e) => e.engagementId === engagementId).map((e) => e.id);
    removed += await repos.datasets.deleteRetained(ids, { id: clock.id(), at: now }, engagementId, 'retention period ended');
  }
  return removed;
}
