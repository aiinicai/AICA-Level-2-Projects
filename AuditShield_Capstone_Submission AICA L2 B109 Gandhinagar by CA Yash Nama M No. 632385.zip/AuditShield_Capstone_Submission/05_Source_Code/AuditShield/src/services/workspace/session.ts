/**
 * Lock state of the workspace. The unlocked data key exists only here, in memory.
 *
 * Locking drops the key reference and notifies listeners, which must drop everything derived
 * from unlocked data (decrypted labels, source data, HMAC keys, gateway vaults) and unmount the
 * screens showing it. JavaScript cannot guarantee the memory is wiped; locking removes the
 * application's references and closes the views.
 */
import type { UnlockedWorkspace } from './useCases';

export type LockReason = 'manual' | 'inactivity' | 'startup';

export interface SessionTimers {
  set(fn: () => void, ms: number): unknown;
  clear(handle: unknown): void;
}
const browserTimers: SessionTimers = { set: (fn, ms) => setTimeout(fn, ms), clear: (h) => clearTimeout(h as ReturnType<typeof setTimeout>) };

export class WorkspaceSession {
  private unlocked: UnlockedWorkspace | null = null;
  private listeners = new Set<() => void>();
  private timer: unknown = null;
  private autoLockMs = 0;
  lastLockReason: LockReason = 'startup';

  constructor(private readonly timers: SessionTimers = browserTimers) {}

  get current(): UnlockedWorkspace | null {
    return this.unlocked;
  }
  get isUnlocked(): boolean {
    return this.unlocked !== null;
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }
  private notify() {
    for (const l of this.listeners) l();
  }

  unlock(workspace: UnlockedWorkspace, autoLockMinutes: number): void {
    this.unlocked = workspace;
    this.setAutoLock(autoLockMinutes);
    this.notify();
  }

  lock(reason: LockReason = 'manual'): void {
    if (!this.unlocked) return;
    this.unlocked = null;
    this.lastLockReason = reason;
    this.timers.clear(this.timer);
    this.timer = null;
    this.notify();
  }

  /** 0 disables automatic locking. */
  setAutoLock(minutes: number): void {
    this.autoLockMs = Math.max(0, minutes) * 60_000;
    this.touch();
  }

  /** Call on user activity: restarts the inactivity countdown. */
  touch(): void {
    this.timers.clear(this.timer);
    this.timer = null;
    if (this.unlocked && this.autoLockMs > 0) this.timer = this.timers.set(() => this.lock('inactivity'), this.autoLockMs);
  }
}
