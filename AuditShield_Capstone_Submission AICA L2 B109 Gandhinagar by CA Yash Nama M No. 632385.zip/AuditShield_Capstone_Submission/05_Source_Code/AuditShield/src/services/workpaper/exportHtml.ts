/**
 * Workpaper export: one self-contained HTML file that can be printed or filed.
 * Every value is HTML-escaped. The file states its scope, thresholds, versions and the meaning of
 * each amount, and lists the evidence references behind every finding so it can be traced back.
 */
import type { AnalysisRunRecord, FindingRecord, ImportRecord } from '../../data/db/schema';
import type { WorkpaperView } from '../../data/repositories/repositories';
import { formatINR } from '../../domain/shared/money';
import { REVIEW_LABEL } from '../../domain/vendor/review';
import type { RuleConfig } from '../../domain/vendor/types';

export interface WorkpaperExportInput {
  engagementName: string;
  financialYear: string;
  preparedAt: string;
  snapshot: ImportRecord;
  run: AnalysisRunRecord;
  ruleConfig: RuleConfig;
  findings: FindingRecord[];
  reviews: ReadonlyMap<string, WorkpaperView>;
}

const esc = (value: unknown): string =>
  String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c] ?? c);

const BASIS: Record<FindingRecord['amountBasis'], string> = {
  'vendor-payments': 'all payments to the vendor(s) named',
  'listed-payments': 'the payments listed',
  'repeat-payment': 'the later payment of the repeated invoice',
  none: 'not applicable',
};

export function buildWorkpaperHtml(input: WorkpaperExportInput): string {
  const { run, snapshot, ruleConfig, findings, reviews } = input;
  const s = run.summary;
  const reviewed = findings.filter((f) => (reviews.get(f.fingerprint)?.status ?? 'open') !== 'open').length;
  const confirmed = findings.filter((f) => reviews.get(f.fingerprint)?.status === 'confirmed-issue');

  const rows = findings.map((f, i) => {
    const r = reviews.get(f.fingerprint);
    return `<tr>
<td>${i + 1}</td>
<td class="sev-${esc(f.severity)}">${esc(f.severity)}</td>
<td>${esc(f.ruleId)} ${esc(f.ruleName)}</td>
<td><strong>${esc(f.title)}</strong><br>${esc(f.explanation)}<br><span class="ref">Entities: ${esc(f.entityRefs.join(', '))}. Reference ${esc(f.fingerprint)}.</span></td>
<td class="num">${f.amountBasis === 'none' ? '—' : esc(formatINR(f.amountPaise))}<br><span class="ref">${esc(BASIS[f.amountBasis])}</span></td>
<td class="ref">${f.paymentIds.length ? esc(f.paymentIds.join(', ')) : '—'}</td>
<td>${esc(REVIEW_LABEL[r?.status ?? 'open'])}${r ? `<br><span class="ref">rev. ${r.revision}, ${esc(r.updatedAt)}</span>` : ''}</td>
<td>${r?.notes ? `<em>Notes:</em> ${esc(r.notes)}<br>` : ''}${r?.conclusion ? `<em>Conclusion:</em> ${esc(r.conclusion)}` : ''}</td>
</tr>`;
  }).join('\n');

  return `<!doctype html>
<html lang="en-IN"><head><meta charset="utf-8"><title>Workpaper — vendor and related-party indicators</title>
<style>
body{font-family:'Segoe UI',Arial,sans-serif;font-size:12px;color:#0f1b19;margin:28px;line-height:1.45}
h1{font-size:18px;margin:0 0 4px}h2{font-size:14px;margin:20px 0 6px}
table{border-collapse:collapse;width:100%}th,td{border:1px solid #c1cbc7;padding:5px 6px;vertical-align:top;text-align:left}
th{background:#154b45;color:#fff;font-weight:600}.num{text-align:right;white-space:nowrap}.ref{color:#485551;font-size:11px}
.sev-Critical{color:#b91c1c;font-weight:700}.sev-High{color:#c2410c;font-weight:700}.sev-Medium{color:#b45309}
dl{display:grid;grid-template-columns:240px 1fr;gap:2px 12px;margin:0}dt{color:#485551}dd{margin:0}
.note{border:1px solid #c1cbc7;background:#f6f8f6;padding:8px 10px;margin-top:14px}
</style></head><body>
<h1>Audit workpaper: vendor and related-party indicators</h1>
<p>${esc(input.engagementName)} · FY ${esc(input.financialYear)} · prepared ${esc(input.preparedAt)} (UTC) with AuditShield VendorShield.</p>

<h2>Scope and basis</h2>
<dl>
<dt>Population</dt><dd>${s.vendors} vendors, ${s.employees} employees, ${s.directors} directors, ${s.payments} payments totalling ${esc(formatINR(s.totalPaidPaise))}</dd>
<dt>Data analysed</dt><dd>Protected snapshot ${esc(snapshot.id)} saved ${esc(snapshot.createdAt)}; identifiers replaced by ${esc(snapshot.scheme.algorithm)} tokens (token v${snapshot.scheme.tokenVersion}, normalisation v${snapshot.scheme.normalisationVersion}, key reference ${esc(snapshot.scheme.keyId)}); label profile “${esc(snapshot.profile.id)}”</dd>
<dt>Analysis run</dt><dd>${esc(run.id)}, finished ${esc(run.finishedAt)}; engine ${esc(run.engineVersion)}; rule set ${esc(run.ruleSetId)}</dd>
<dt>Thresholds</dt><dd>Approval limit ${esc(formatINR(ruleConfig.approvalLimitPaise))}; split window ${ruleConfig.splitWindowDays} days; near-limit band from ${ruleConfig.nearLimitBasisPoints / 100}% of the limit; configuration ${esc(ruleConfig.version)}</dd>
<dt>Data-quality warnings at protection</dt><dd>${snapshot.issues.length}</dd>
</dl>

<h2>Summary</h2>
<dl>
<dt>Findings</dt><dd>${s.findings}: ${s.bySeverity.Critical} critical, ${s.bySeverity.High} high, ${s.bySeverity.Medium} medium, ${s.bySeverity.Low} low</dd>
<dt>Reviewed / still open</dt><dd>${reviewed} / ${findings.length - reviewed}</dd>
<dt>Confirmed issues</dt><dd>${confirmed.length}${confirmed.length ? `: ${esc(confirmed.map((f) => `${f.ruleId} (${f.fingerprint})`).join('; '))}` : ''}</dd>
<dt>Payments to vendors under review</dt><dd>${esc(formatINR(s.paymentsToVendorsUnderReviewPaise))}: every payment to the ${s.vendorsUnderReview.length} vendors having a Critical or High finding, each counted once. This is spend to examine, not an estimate of loss.</dd>
</dl>

<h2>Findings and auditor response</h2>
<table>
<thead><tr><th>#</th><th>Severity</th><th>Rule</th><th>Finding and explanation</th><th>Amount (basis)</th><th>Payment evidence</th><th>Review status</th><th>Notes and conclusion</th></tr></thead>
<tbody>
${rows}
</tbody></table>

<div class="note">
Findings are indicators produced by deterministic rules; they are not conclusions. Severities and scores are review priorities, not fraud probabilities.
Amounts of different findings overlap and must not be added together. Matching was performed on keyed tokens: the analysis did not use the underlying
bank, PAN, GSTIN, phone or address values. Follow up as required by SA 240 (fraud) and SA 550 (related parties).
</div>
</body></html>
`;
}
