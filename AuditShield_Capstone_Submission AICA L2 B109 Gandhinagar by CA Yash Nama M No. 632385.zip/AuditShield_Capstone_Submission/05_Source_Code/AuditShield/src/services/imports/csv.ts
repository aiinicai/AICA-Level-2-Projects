/** CSV text → header list and string rows (Papa Parse; no type guessing, so leading zeros survive). */
import Papa from 'papaparse';

export interface ParsedCsv {
  headers: string[];
  rows: Record<string, string>[];
  problems: string[];
}

export const MAX_CSV_BYTES = 50 * 1024 * 1024;

export function parseCsv(text: string): ParsedCsv {
  const result = Papa.parse<Record<string, string>>(text.replace(/^﻿/, ''), {
    header: true,
    skipEmptyLines: 'greedy',
    dynamicTyping: false,
    transformHeader: (h) => h.trim(),
  });
  const headers = (result.meta.fields ?? []).filter((h) => h !== '');
  const problems = result.errors.slice(0, 20).map((e) => `Row ${typeof e.row === 'number' ? e.row + 2 : '?'}: ${e.message}`);
  if (new Set(headers).size !== headers.length) problems.push('The header row repeats a column name.');
  return { headers, rows: result.data, problems };
}
