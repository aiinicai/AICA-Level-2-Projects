/** Hands a locally generated file to the browser's download handling. Nothing is uploaded. */
export function downloadBytes(name: string, bytes: Uint8Array<ArrayBuffer>, type = 'application/octet-stream'): void {
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const a = document.createElement('a');
  a.href = url;
  a.download = name;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10_000);
}

export const downloadText = (name: string, text: string, type: string): void => downloadBytes(name, new TextEncoder().encode(text), type);
