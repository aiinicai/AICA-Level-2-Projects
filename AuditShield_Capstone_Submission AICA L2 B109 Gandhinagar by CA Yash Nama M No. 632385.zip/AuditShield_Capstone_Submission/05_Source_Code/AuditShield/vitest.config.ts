import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    // The frozen legacy reference is loaded through node:vm by tests/helpers; it is never
    // transformed or collected as test code.
    exclude: ['legacy/**', 'node_modules/**'],
  },
});
