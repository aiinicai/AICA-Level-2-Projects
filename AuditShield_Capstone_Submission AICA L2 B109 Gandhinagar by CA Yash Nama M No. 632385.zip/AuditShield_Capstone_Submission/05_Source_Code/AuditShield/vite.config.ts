import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import { defineConfig, type Plugin } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

/**
 * Production Content-Security-Policy. Scripts, styles and data come only from the app's own
 * origin. Network connections are allowed only to this origin and to servers on this computer
 * (the local-model adapter for LM Studio / Ollama). Nothing can be sent to the internet.
 * Not applied in development, where Vite's hot-reload client needs inline scripts and a socket.
 */
const PRODUCTION_CSP = [
  "default-src 'self'",
  "script-src 'self'",
  "style-src 'self'",
  "img-src 'self' data:",
  "font-src 'self'",
  "connect-src 'self' http://127.0.0.1:* http://localhost:* https://127.0.0.1:* https://localhost:*",
  "worker-src 'self'",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'none'",
  "form-action 'none'",
].join('; ');

const productionCsp = (): Plugin => ({
  name: 'auditshield-production-csp',
  apply: 'build',
  transformIndexHtml: () => [
    { tag: 'meta', attrs: { 'http-equiv': 'Content-Security-Policy', content: PRODUCTION_CSP }, injectTo: 'head-prepend' },
  ],
});

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    productionCsp(),
    // Installable, offline-capable app. The service worker caches the application files only:
    // there is no runtime caching, so prompts, answers, data and downloads are never cached.
    // registerType 'prompt' without a prompt UI means a new version activates only after every
    // AuditShield tab has been closed, so an update never interrupts work in progress.
    VitePWA({
      registerType: 'prompt',
      injectRegister: 'script',
      includeAssets: ['icon.svg'],
      manifest: {
        name: 'AuditShield',
        short_name: 'AuditShield',
        description: 'Private, offline vendor-fraud analysis and AI masking for CA audit work.',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        background_color: '#f6f8f6',
        theme_color: '#154b45',
        icons: [
          { src: 'icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png' },
          { src: 'icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'maskable' },
        ],
      },
      workbox: {
        globPatterns: ['**/*.{js,css,html,svg,png,webmanifest}'],
        navigateFallback: 'index.html',
        runtimeCaching: [],
        maximumFileSizeToCacheInBytes: 4 * 1024 * 1024,
      },
    }),
  ],
  // Fixed origin: browser storage is tied to scheme + host + port, so the port must not drift.
  server: { host: '127.0.0.1', port: 5173, strictPort: true },
  preview: { host: '127.0.0.1', port: 4173, strictPort: true },
  build: { target: 'es2022', sourcemap: false, chunkSizeWarningLimit: 900 },
});
