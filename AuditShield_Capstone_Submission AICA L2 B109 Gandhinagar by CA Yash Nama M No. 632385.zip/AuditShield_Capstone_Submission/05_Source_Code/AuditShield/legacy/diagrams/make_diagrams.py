import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import pathlib

OUT = pathlib.Path(__file__).parent
plt.rcParams["font.family"] = "DejaVu Sans"


def box(ax, x, y, w, h, title, body="", fc="#ffffff", ec="#334155", tc="#0f172a", ts=11, bs=9, lw=1.6, bold=True):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.018",
                                fc=fc, ec=ec, lw=lw, zorder=2))
    if body:
        ax.text(x + w / 2, y + h - 0.035, title, ha="center", va="top", fontsize=ts,
                fontweight="bold" if bold else "normal", color=tc, zorder=3, wrap=True)
        ax.text(x + w / 2, y + h - 0.085, body, ha="center", va="top", fontsize=bs, color="#1e293b",
                zorder=3, linespacing=1.35)
    else:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=ts,
                fontweight="bold" if bold else "normal", color=tc, zorder=3, linespacing=1.3)


def arrow(ax, x1, y1, x2, y2, color="#334155", lw=2, style="-|>", ls="-"):
    ax.add_patch(FancyArrowPatch((x1, y1), (x2, y2), arrowstyle=style, mutation_scale=16,
                                 color=color, lw=lw, linestyle=ls, zorder=1))


def lane(ax, y, h, label, color, fc):
    ax.add_patch(FancyBboxPatch((0.01, y), 0.98, h, boxstyle="round,pad=0.005,rounding_size=0.015",
                                fc=fc, ec=color, lw=2, zorder=0))
    ax.text(0.02, y + h - 0.012, label, ha="left", va="top", fontsize=13, fontweight="bold", color=color)


def new_fig(title, subtitle):
    fig = plt.figure(figsize=(16, 9), dpi=150)
    ax = fig.add_axes([0, 0, 1, 1]); ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    ax.text(0.5, 0.975, title, ha="center", va="top", fontsize=20, fontweight="bold", color="#0f172a")
    ax.text(0.5, 0.935, subtitle, ha="center", va="top", fontsize=11.5, color="#475569")
    return fig, ax


# ---------------------------------------------------------------- VendorShield
fig, ax = new_fig("VendorShield: Privacy-Preserving Ghost Vendor & Related-Party Detector",
                  "How the problem happens today, and how the program solves it without the auditor seeing personal data")

# PROBLEM LANE
lane(ax, 0.60, 0.30, "THE PROBLEM TODAY", "#b91c1c", "#fef2f2")
py, ph, pw = 0.635, 0.20, 0.172
steps = [
    ("1. Fake vendor created", "Accounts employee adds\n'Sai Traders' to the vendor\nmaster using HIS OWN\nbank account and PAN"),
    ("2. Money flows out", "6 invoices of ₹97,800-₹99,750,\nall just under the ₹1,00,000\napproval limit. He approves\nthem himself."),
    ("3. Auditor wants to check", "Needs to compare vendor\nbank/PAN with employee\nbank/PAN (HR + payroll data)"),
    ("4. Privacy wall", "Client: 'Employee PAN, bank &\naddress are personal data.\nWe can't hand them over'\n(DPDP Act / confidentiality)"),
    ("5. Fraud is missed", "Only a sample is checked\nmanually. ₹5.9 lakh leaks\nout and nobody connects\nthe dots"),
]
xs = [0.03 + i * 0.193 for i in range(5)]
for i, (t, b) in enumerate(steps):
    box(ax, xs[i], py, pw, ph, t, b, fc="#ffffff", ec="#dc2626", tc="#b91c1c", bs=9.2)
    if i < 4:
        arrow(ax, xs[i] + pw + 0.003, py + ph / 2, xs[i + 1] - 0.003, py + ph / 2, color="#dc2626")

# SOLUTION LANE
lane(ax, 0.03, 0.55, "OUR SOLUTION: THE PROGRAM (runs in a web browser, offline)", "#1d4ed8", "#eff6ff")
# client zone and auditor zone
ax.add_patch(FancyBboxPatch((0.025, 0.07), 0.445, 0.45, boxstyle="round,pad=0.005,rounding_size=0.012",
                            fc="#f0fdf4", ec="#16a34a", lw=1.5, ls="--", zorder=0.5))
ax.text(0.2475, 0.505, "AT THE CLIENT'S OFFICE  (raw data never leaves)", ha="center", fontsize=11, fontweight="bold", color="#15803d")
ax.add_patch(FancyBboxPatch((0.53, 0.07), 0.445, 0.45, boxstyle="round,pad=0.005,rounding_size=0.012",
                            fc="#fff7ed", ec="#ea580c", lw=1.5, ls="--", zorder=0.5))
ax.text(0.7525, 0.505, "AT THE AUDITOR'S OFFICE  (sees only codes)", ha="center", fontsize=11, fontweight="bold", color="#c2410c")

bw, bh, by = 0.13, 0.20, 0.27
box(ax, 0.035, by, bw, bh, "A. Load data",
    "Employees\nVendors\nDirectors / KMP\nPayments\n(CSV from Tally / ERP)", ec="#16a34a")
box(ax, 0.185, by, bw, bh, "B. Clean (fuzzy)",
    "'Flat No.12, M.G. Rd.'\n= 'flat 12 MG Road'\nphone: last 10 digits\nGSTIN -> PAN inside", ec="#16a34a")
box(ax, 0.335, by, bw, bh, "C. Lock with key",
    "HMAC-SHA256 with the\nclient's SECRET key\n60112233445566\n-> H:3f9a1c...", ec="#16a34a")
arrow(ax, 0.165, by + bh / 2, 0.185, by + bh / 2, color="#16a34a")
arrow(ax, 0.315, by + bh / 2, 0.335, by + bh / 2, color="#16a34a")

# boundary
ax.plot([0.5, 0.5], [0.08, 0.50], color="#475569", lw=2.5, ls=(0, (6, 4)))
ax.text(0.5, 0.235, "only codes\ncross this line", ha="center", va="center", fontsize=9.5, color="#334155",
        bbox=dict(boxstyle="round", fc="white", ec="#475569"))
arrow(ax, 0.465, by + bh / 2, 0.545, by + bh / 2, color="#334155", lw=2.5)

box(ax, 0.545, by, bw, bh, "D. Match codes",
    "Same code = same value\nvendor <-> employee\nvendor <-> director\nvendor <-> vendor", ec="#ea580c")
box(ax, 0.695, by, bw, bh, "E. 10 fraud rules",
    "shared bank/PAN, split\npayments, near-limit,\nduplicates, self-approval,\nweekend round sums", ec="#ea580c")
box(ax, 0.845, by, 0.125, bh, "F. Output",
    "Risk graph\nRed flags in plain\nEnglish + ₹ at risk\nAudit workpaper", ec="#ea580c")
arrow(ax, 0.675, by + bh / 2, 0.695, by + bh / 2, color="#ea580c")
arrow(ax, 0.825, by + bh / 2, 0.845, by + bh / 2, color="#ea580c")

# example strip
box(ax, 0.035, 0.085, 0.43, 0.15, "Why matching still works:",
    "Vendor 'Sai Traders' bank a/c 60112233445566  ->  H:3f9a1c0b...\n"
    "Employee E107 bank a/c 60112233445566        ->  H:3f9a1c0b...\n"
    "Same input + same key = same code, so the auditor sees a MATCH\nwithout ever seeing the number.",
    fc="#ffffff", ec="#94a3b8", tc="#15803d", ts=10, bs=9)
box(ax, 0.545, 0.085, 0.425, 0.15, "Result on the sample company (planted cases):",
    "CRITICAL: Sai Traders = employee E107 (same bank, PAN, phone, address)\n"
    "HIGH: Om Enterprises shares phone + address with a director (related party)\n"
    "HIGH: 3 split payments ₹1.63 lakh | duplicate invoice | ghost employee\n"
    "14 red flags, all planted cases caught, 0 false alarms on this sample",
    fc="#ffffff", ec="#94a3b8", tc="#c2410c", ts=10, bs=9)
fig.savefig(OUT / "diagram_vendorshield.png", bbox_inches="tight", facecolor="white")
plt.close(fig)

# ---------------------------------------------------------------- AI Gateway
fig, ax = new_fig("CA-Safe AI Gateway: Use AI on Client Work Without Leaking Client Identities",
                  "How the problem happens today, and how the program solves it")
lane(ax, 0.60, 0.30, "THE PROBLEM TODAY", "#b91c1c", "#fef2f2")
steps = [
    ("1. Deadline pressure", "Article assistant needs a\nGST notice reply or a\nledger review quickly"),
    ("2. Copy-paste into AI", "Pastes client name, PAN,\nGSTIN, Aadhaar, bank a/c\nand phone into a public\nAI chatbot"),
    ("3. Data leaves the firm", "Identifiers now sit on an\noutside server. The firm\nhas no record of what\nwas sent"),
    ("4. Real risk", "Breach of client\nconfidentiality (ICAI Code\nof Ethics), DPDP Act\nexposure, KYC misuse"),
    ("5. Firms react", "Either ban AI (lose\nproductivity) or ignore it\n(shadow AI). Neither\nworks"),
]
for i, (t, b) in enumerate(steps):
    box(ax, xs[i], py, pw, ph, t, b, fc="#ffffff", ec="#dc2626", tc="#b91c1c", bs=9.2)
    if i < 4:
        arrow(ax, xs[i] + pw + 0.003, py + ph / 2, xs[i + 1] - 0.003, py + ph / 2, color="#dc2626")

lane(ax, 0.03, 0.55, "OUR SOLUTION: THE PROGRAM (a privacy layer between the CA and any AI)", "#4338ca", "#eef2ff")
ax.add_patch(FancyBboxPatch((0.025, 0.07), 0.60, 0.45, boxstyle="round,pad=0.005,rounding_size=0.012",
                            fc="#f0fdf4", ec="#16a34a", lw=1.5, ls="--", zorder=0.5))
ax.text(0.325, 0.505, "ON THE CA FIRM'S COMPUTER (browser)", ha="center", fontsize=11, fontweight="bold", color="#15803d")
ax.add_patch(FancyBboxPatch((0.66, 0.24), 0.315, 0.27, boxstyle="round,pad=0.005,rounding_size=0.012",
                            fc="#fff7ed", ec="#ea580c", lw=1.5, ls="--", zorder=0.5))
ax.text(0.8175, 0.495, "OUTSIDE AI SERVER", ha="center", fontsize=11, fontweight="bold", color="#c2410c")

by2, bh2 = 0.29, 0.18
box(ax, 0.035, by2, 0.13, bh2, "1. CA types",
    "'Vendor Sai Enterprises,\nPAN AFZPS1234Q,\na/c 6011...5566,\nShri Rohit Shinde'", ec="#16a34a", bs=8.8)
box(ax, 0.185, by2, 0.13, bh2, "2. Detect",
    "12 detectors: PAN, GSTIN,\nAadhaar, bank a/c, IFSC,\nUPI, card, phone, email,\nnames, firms + checksums", ec="#16a34a", bs=8.8)
box(ax, 0.335, by2, 0.13, bh2, "3. Replace",
    "Rohit Shinde -> [PERSON_1]\nAFZPS1234Q -> [PAN_1]\nsame person = same code\namounts & dates kept", ec="#16a34a", bs=8.8)
box(ax, 0.485, by2, 0.13, bh2, "4. Leak test",
    "Re-scan outgoing text\n+ search every real\nvalue. 0 found ->\nallowed to send", ec="#16a34a", bs=8.8)
for x in (0.165, 0.315, 0.465):
    arrow(ax, x, by2 + bh2 / 2, x + 0.02, by2 + bh2 / 2, color="#16a34a")
box(ax, 0.685, 0.30, 0.27, 0.16, "5. AI sees only codes",
    "'[ORG_1], PAN [PAN_1],\na/c [BANK_AC_1], [PERSON_1]...\nRs. 98,500; 99,200; 97,800'\nAI analyses & replies using codes", ec="#ea580c", bs=9)
arrow(ax, 0.615, by2 + bh2 / 2 + 0.03, 0.685, 0.41, color="#334155", lw=2.5)
ax.text(0.65, 0.435, "masked", ha="center", fontsize=9, color="#334155")

box(ax, 0.335, 0.09, 0.28, 0.15, "6. Restore locally",
    "AI reply: '[PERSON_1] may be linked to the payee'\n-> 'Rohit Shinde may be linked to the payee'\nCA gets a full, useful answer", ec="#16a34a", bs=9)
arrow(ax, 0.82, 0.30, 0.62, 0.17, color="#334155", lw=2.5)
ax.text(0.75, 0.22, "reply with codes", ha="center", fontsize=9, color="#334155")
box(ax, 0.035, 0.09, 0.28, 0.15, "Vault + audit log (stay local)",
    "[PAN_1] <-> AFZPS1234Q   [PERSON_1] <-> Rohit Shinde\nLog: time, AI used, 8 identifiers masked,\nleak test PASS  (proof for peer review)", ec="#16a34a", tc="#15803d", bs=9)
arrow(ax, 0.315, 0.165, 0.335, 0.165, color="#16a34a", style="<|-|>")
box(ax, 0.66, 0.09, 0.315, 0.12, "Works with",
    "Offline demo AI (built in) | OpenAI-compatible API\nLocal model (e.g. Ollama) for zero data leaving",
    fc="#ffffff", ec="#94a3b8", tc="#4338ca", bs=9)
fig.savefig(OUT / "diagram_ai_gateway.png", bbox_inches="tight", facecolor="white")
plt.close(fig)
print("diagrams saved")
