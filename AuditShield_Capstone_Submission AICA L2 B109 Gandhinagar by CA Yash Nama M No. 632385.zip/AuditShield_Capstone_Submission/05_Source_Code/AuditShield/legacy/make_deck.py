from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
import pathlib

ROOT = pathlib.Path(__file__).parent
prs = Presentation(); prs.slide_width = Inches(13.333); prs.slide_height = Inches(7.5)
BL = prs.slide_layouts[6]
NAVY, BLUE, RED, GREEN, GREY, WHITE = (RGBColor.from_string(c) for c in ["13294B", "2563EB", "DC2626", "16A34A", "475569", "FFFFFF"])


def rect(s, x, y, w, h, fill, line=None, shape=MSO_SHAPE.RECTANGLE):
    r = s.shapes.add_shape(shape, x, y, w, h); r.fill.solid(); r.fill.fore_color.rgb = fill
    if line: r.line.color.rgb = line
    else: r.line.fill.background()
    r.shadow.inherit = False
    return r


def text(s, x, y, w, h, t, size=18, bold=False, color=NAVY, align=PP_ALIGN.LEFT, anchor=MSO_ANCHOR.TOP):
    tb = s.shapes.add_textbox(x, y, w, h); tf = tb.text_frame; tf.word_wrap = True; tf.vertical_anchor = anchor
    lines = t if isinstance(t, list) else [t]
    for i, ln in enumerate(lines):
        p = tf.paragraphs[0] if i == 0 else tf.add_paragraph(); p.alignment = align
        parts = ln.split("**")
        for j, part in enumerate(parts):
            if not part: continue
            r = p.add_run(); r.text = part; r.font.size = Pt(size); r.font.bold = bold or j % 2 == 1; r.font.color.rgb = color
        p.space_after = Pt(6)
    return tb


def slide(title, kicker=None):
    s = prs.slides.add_slide(BL)
    rect(s, 0, 0, prs.slide_width, Inches(1.05), NAVY)
    text(s, Inches(0.5), Inches(0.18), Inches(12.3), Inches(0.75), title, 30, True, WHITE, anchor=MSO_ANCHOR.MIDDLE)
    if kicker: text(s, Inches(0.5), Inches(1.15), Inches(12.3), Inches(0.5), kicker, 16, False, GREY)
    return s


def card(s, x, y, w, h, head, body, col):
    rect(s, x, y, w, h, RGBColor.from_string("F8FAFC"), col, MSO_SHAPE.ROUNDED_RECTANGLE).adjustments[0] = 0.06
    rect(s, x, y, Inches(0.12), h, col)
    text(s, x + Inches(0.3), y + Inches(0.15), w - Inches(0.45), Inches(0.5), head, 19, True, col)
    text(s, x + Inches(0.3), y + Inches(0.7), w - Inches(0.45), h - Inches(0.8), body, 15, False, RGBColor.from_string("1E293B"))


# 1 Title
s = prs.slides.add_slide(BL)
rect(s, 0, 0, prs.slide_width, prs.slide_height, NAVY)
text(s, Inches(0.8), Inches(2.0), Inches(11.7), Inches(1.2), "AuditShield", 60, True, WHITE)
text(s, Inches(0.8), Inches(3.2), Inches(11.7), Inches(1), "Privacy-first audit + AI tools for Chartered Accountant firms", 28, False, RGBColor.from_string("CBD5E1"))
text(s, Inches(0.8), Inches(4.4), Inches(11.7), Inches(1),
     ["VendorShield: find ghost vendors without seeing personal data", "CA-Safe AI Gateway: use AI without leaking client identities"], 20, False, RGBColor.from_string("FBBF24"))
text(s, Inches(0.8), Inches(6.4), Inches(11.7), Inches(0.5), "[Team name] · [Members] · [College / Event]", 16, False, RGBColor.from_string("94A3B8"))

# 2 Problem
s = slide("Two problems every CA firm faces", "Both are about data that is needed for the work, but must not be exposed")
card(s, Inches(0.5), Inches(1.8), Inches(6), Inches(5.2), "1. The ghost vendor",
     ["An Accounts Payable employee creates supplier 'Sai Traders' with **his own bank account**.",
      "6 invoices of ₹97,800-₹99,750: each just under the ₹1 lakh approval limit.",
      "To catch it, the auditor must compare vendor and employee PAN / bank / address.",
      "**But that is personal data the company hesitates to share.**"], RED)
card(s, Inches(6.85), Inches(1.8), Inches(6), Inches(5.2), "2. The 9 pm AI shortcut",
     ["An article assistant pastes a GST notice into an AI chatbot to draft a reply.",
      "It contains client name, GSTIN, PAN, director's mobile and bank account.",
      "That data now sits on an outside server, with no record kept.",
      "**Firms either ban AI or ignore the risk. Neither works.**"], RED)

# 3 Why hard
s = slide("Why this is hard", "The core tension")
text(s, Inches(0.8), Inches(2.0), Inches(11.7), Inches(4.5),
     ["Fraud checks and AI both work better with **more data**.",
      "Professional confidentiality (ICAI Code of Ethics) and India's **DPDP Act 2023** push for **less data**.",
      "Today's choice: share everything (risky) or check only a sample (fraud missed).",
      "", "**Our idea: let the computer compare and reason on CODES, while real identities stay where they belong.**"], 24, False, NAVY)

# 4 VendorShield diagram
s = slide("VendorShield: match without seeing")
s.shapes.add_picture(str(ROOT / "diagrams" / "diagram_vendorshield.png"), Inches(1.25), Inches(1.2), height=Inches(6.15))

# 5 Coverage
s = slide("Fraud patterns VendorShield detects", "Sample result: 14 flags, every planted fraud caught, 0 false alarms (synthetic data)")
rows = [("R1", "Ghost vendor: vendor bank/PAN = employee's", "Critical"), ("R2", "Undisclosed related party: vendor ↔ director", "High"),
        ("R3", "Conflict of interest: vendor phone/address = employee's", "High"), ("R4", "Shell / duplicate vendors: same PAN/bank/GSTIN", "High"),
        ("R5", "Ghost employee: two employees, one bank account", "High"), ("R6", "Duplicate payment: same invoice paid twice", "High"),
        ("R7", "Invoice splitting to dodge approval limit", "High"), ("R8", "Repeated amounts just below the limit", "Medium"),
        ("R9", "Same person creates vendor and approves payment", "High"), ("R10", "Round amounts paid on weekends (SA 240)", "Low")]
tbl = s.shapes.add_table(len(rows) + 1, 3, Inches(0.8), Inches(1.8), Inches(11.7), Inches(5.2)).table
tbl.columns[0].width = Inches(1.2); tbl.columns[1].width = Inches(8.5); tbl.columns[2].width = Inches(2.0)
for i, h in enumerate(["Rule", "Fraud pattern", "Severity"]):
    c = tbl.cell(0, i); c.text = h; c.fill.solid(); c.fill.fore_color.rgb = NAVY
    c.text_frame.paragraphs[0].runs[0].font.color.rgb = WHITE; c.text_frame.paragraphs[0].runs[0].font.size = Pt(15)
sevcol = {"Critical": RED, "High": RGBColor.from_string("EA580C"), "Medium": RGBColor.from_string("D97706"), "Low": GREY}
for r, row in enumerate(rows, 1):
    for i, v in enumerate(row):
        c = tbl.cell(r, i); c.text = v; run = c.text_frame.paragraphs[0].runs[0]; run.font.size = Pt(14)
        c.fill.solid(); c.fill.fore_color.rgb = RGBColor.from_string("F8FAFC" if r % 2 else "FFFFFF")
        if i == 2: run.font.color.rgb = sevcol[v]; run.font.bold = True

# 6 demo
for name, steps in [("LIVE DEMO 1: VendorShield", ["Load sample company → Protect with secret key", "Show: auditor's file has 0 of 120 sensitive values",
                                                   "Run analysis → Sai Traders = employee E107", "Related party, split payments, near-limit amounts",
                                                   "Privacy proof: crack a plain hash live, then show why the key stops it"]),
                    ]:
    s = slide(name)
    text(s, Inches(0.8), Inches(1.6), Inches(11.7), Inches(5), ["→  " + x for x in steps], 26, False, NAVY)

# 7 Gateway diagram
s = slide("CA-Safe AI Gateway: AI sees the problem, not the people")
s.shapes.add_picture(str(ROOT / "diagrams" / "diagram_ai_gateway.png"), Inches(1.25), Inches(1.2), height=Inches(6.15))

# 8 demo 2 + accuracy
s = slide("LIVE DEMO 2: AI Gateway + measured accuracy")
text(s, Inches(0.8), Inches(1.5), Inches(6.5), Inches(5.5),
     ["→  GST notice: 11 identifiers found", "→  AI receives only codes; leak test = 0", "→  Answer comes back with real names restored",
      "→  Aadhaar & card caught with checksum math", "→  Vault + audit log stay on the computer"], 24, False, NAVY)
for i, (big, small, col) in enumerate([("95%", "recall: 21 of 22 identifiers caught", GREEN), ("100%", "precision: 0 false alarms", GREEN),
                                       ("1 miss", "lowercase name with no title: our roadmap", RED)]):
    y = Inches(1.6 + i * 1.8)
    text(s, Inches(7.8), y, Inches(5), Inches(0.9), big, 48, True, col)
    text(s, Inches(7.8), y + Inches(0.95), Inches(5), Inches(0.6), small, 16, False, GREY)
text(s, Inches(7.8), Inches(6.85), Inches(5.2), Inches(0.5), "On 18 hand-labelled test sentences written by our team", 12, False, GREY)

# 9 Tech & honesty
s = slide("How it's built, and what it can't do yet")
card(s, Inches(0.5), Inches(1.4), Inches(6), Inches(5.7), "Tech",
     ["Single HTML files: HTML + CSS + JavaScript, **no libraries, works offline**", "HMAC-SHA256 (verified against Node crypto)",
      "Fuzzy address/phone normalisation; GSTIN → PAN", "Force-directed relationship graph on canvas",
      "12 India-specific detectors + Verhoeff, GSTIN, Luhn checksums", "Automatic leak tests in both tools"], BLUE)
card(s, Inches(6.85), Inches(1.4), Inches(6), Inches(5.7), "Honest limits → roadmap",
     ["Red flags are indicators, not proof (SA 240 / SA 550 follow-up)", "Exact matching misses typos → privacy-preserving fuzzy matching",
      "Rule-based today → ML anomaly scoring", "Name detection misses untitled lowercase names → NER model",
      "Tested on synthetic data only → pilot with a CA firm", "Pseudonymised data is still personal data"], RED)

# 10 close
s = prs.slides.add_slide(BL)
rect(s, 0, 0, prs.slide_width, prs.slide_height, NAVY)
text(s, Inches(0.8), Inches(2.4), Inches(11.7), Inches(1.5), "Auditors get the evidence.\nClients keep their privacy.", 44, True, WHITE)
text(s, Inches(0.8), Inches(4.6), Inches(11.7), Inches(1), "Thank you · Questions?", 28, False, RGBColor.from_string("FBBF24"))

prs.save(ROOT.parent / "AuditShield_Pitch_Deck.pptx")
print("deck saved", len(prs.slides), "slides")
