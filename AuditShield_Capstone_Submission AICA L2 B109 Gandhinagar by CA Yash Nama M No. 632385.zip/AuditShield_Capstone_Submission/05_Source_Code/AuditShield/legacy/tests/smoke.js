// minimal fake DOM to execute UI scripts and click buttons
const fs = require('fs');
const file = process.argv[2];
const html = fs.readFileSync(file, 'utf8');
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
const ids = [...html.matchAll(/id="([^"]+)"/g)].map(m => m[1]);
const els = {};
function mk(id) {
  const ctxStub = new Proxy({}, { get: (t, p) => p === 'measureText' ? () => ({ width: 50 }) : (p in t ? t[p] : () => {}), set: (t, p, v) => (t[p] = v, true) });
  return { id, value: '', innerHTML: '', textContent: '', checked: false, disabled: false, type: 'text', style: {}, dataset: {},
    classList: { toggle(){}, add(){}, remove(){}, contains(){ return false; } },
    getContext: () => ctxStub, getBoundingClientRect: () => ({ left: 0, top: 0, width: 800, height: 560 }), click(){} };
}
ids.forEach(id => els[id] = mk(id));
if (els.key) els.key.value = 'Client@Secret#2026';
if (els.bfPhone) els.bfPhone.value = '9822563107';
if (els.limit) els.limit.value = '100000';
if (els.apiUrl) { els.apiModel.value = 'x'; }
global.window = { addEventListener(){}, devicePixelRatio: 1 };
global.document = {
  getElementById: id => els[id] || (els[id] = mk(id)),
  querySelectorAll: sel => sel === 'nav button' ? [] : [],
  querySelector: sel => ({ value: 'mock' }),
  createElement: () => ({ click(){} })
};
global.requestAnimationFrame = () => 1; global.performance = { now: () => Date.now() };
global.alert = m => console.log('ALERT', m); global.confirm = () => true;
global.URL = { createObjectURL: () => 'blob:', revokeObjectURL(){} }; global.Blob = function(){};
global.setTimeout = (f) => f();
const vm = require('vm');
scripts.forEach(s => vm.runInThisContext(s));
(async () => {
  if (els.loadSample) {
    els.loadSample.onclick(); console.log('load:', els.loadMsg.textContent);
    els.protect.onclick(); console.log('leak:', els.leakCheck.innerHTML.replace(/<[^>]+>/g, ''));
    els.runBtn.onclick(); console.log('kpis ok:', els.kpis.innerHTML.length > 100, 'flags html:', (els.flags.innerHTML.match(/class="flag /g)||[]).length);
    els.dlReport.onclick(); console.log('report ok');
    els.bfRun.onclick(); console.log('bf:', els.bfOut.innerHTML.replace(/<[^>]+>/g, '').slice(0, 160));
  } else {
    els.scanBtn.onclick(); console.log('chips:', els.chips.innerHTML.replace(/<[^>]+>/g, ' ').trim());
    console.log('leak:', els.leak.innerHTML.replace(/<[^>]+>/g, '').trim().slice(0, 80));
    await els.sendBtn.onclick(); console.log('final:', els.final.innerHTML.replace(/<[^>]+>/g, '').slice(0, 200));
    els.reveal.onchange(); console.log('vault rows:', (els.vault.innerHTML.match(/<tr>/g)||[]).length - 1, 'log rows:', (els.log.innerHTML.match(/<tr>/g)||[]).length - 1);
    els.evalBtn.onclick(); console.log('eval:', els.evalOut.innerHTML.replace(/<[^>]+>/g, ' ').replace(/\s+/g,' ').slice(0, 120));
  }
})();
