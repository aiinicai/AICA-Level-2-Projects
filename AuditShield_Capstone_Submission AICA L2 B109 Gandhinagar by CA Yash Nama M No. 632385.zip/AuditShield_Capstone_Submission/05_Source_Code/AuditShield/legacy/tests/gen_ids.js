const AG = require('../ai_gateway/core.js');
['27AAKCS4321M1Z','27ABHFM7788K1Z','27AABCD1234E1Z'].forEach(g=>console.log(g+AG.gstinCheck(g)));
let base='73415298016'; console.log('aadhaar', base+AG.verhoeff.digit(base), AG.verhoeff.valid(base+AG.verhoeff.digit(base)));
