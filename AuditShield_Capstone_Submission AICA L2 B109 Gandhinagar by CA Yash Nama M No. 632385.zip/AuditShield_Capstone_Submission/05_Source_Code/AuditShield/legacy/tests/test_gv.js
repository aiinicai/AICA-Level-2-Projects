const GV = require('../ghost_vendor/core.js');
const crypto = require('crypto');
// crypto correctness
for (const s of ['', 'abc', 'x'.repeat(200), 'ಪುಣೆ ₹']) {
  const a = GV.sha256Hex(s), b = crypto.createHash('sha256').update(s).digest('hex');
  if (a !== b) throw new Error('sha mismatch ' + s);
  const k = 'k'.repeat(70);
  if (GV.hmacHex('secretkey1', s) !== crypto.createHmac('sha256','secretkey1').update(s).digest('hex')) throw new Error('hmac');
  if (GV.hmacHex(k, s) !== crypto.createHmac('sha256',k).update(s).digest('hex')) throw new Error('hmac long');
}
console.log('crypto OK');
console.log(GV.normalize('address','Flat No. 12, Ganesh Society, M.G. Rd., Pune'), '|', GV.normalize('address','Flat 12 Ganesh Society MG Road Pune'));
const d = GV.sampleData();
const p = GV.protect(d, 'ClientSecret#2026');
console.log('raw leak check:', JSON.stringify(p).includes('60112233445566'), JSON.stringify(p).includes('DRSPS5532H'), JSON.stringify(p).includes('Rohit'));
const r = GV.analyze(p);
console.log(r.summary);
r.flags.forEach(f => console.log(f.severity.padEnd(8), f.rule.padEnd(36), f.title));
console.log('nodes', r.graph.nodes.length, 'edges', r.graph.edges.length);
// different key -> different tokens but same findings
const r2 = GV.analyze(GV.protect(d, 'AnotherKey#999'));
console.log('same flags with other key:', r2.flags.length === r.flags.length);
const csv = GV.toCSV(d.vendors); const back = GV.parseCSV(csv);
console.log('csv roundtrip:', JSON.stringify(back) === JSON.stringify(d.vendors));
