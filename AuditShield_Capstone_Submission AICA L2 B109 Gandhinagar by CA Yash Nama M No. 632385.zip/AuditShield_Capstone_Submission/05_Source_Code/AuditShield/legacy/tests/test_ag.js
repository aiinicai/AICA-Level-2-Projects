const AG = require('../ai_gateway/core.js');
for (const [name, text] of Object.entries(AG.SAMPLES)) {
  const v = new AG.Vault();
  const r = AG.mask(text, v, {});
  console.log('=== ' + name + ' ===');
  console.log(r.masked);
  console.log('detections:', r.detections.map(d => d.type + '=' + d.value).join(' | '));
  const lc = AG.leakCheck(r.masked, v, {});
  console.log('leaks:', lc.leaks.length, 'redetect:', lc.redetect.map(d=>d.type+'='+d.value));
  const ai = AG.mockAI(r.masked);
  const back = AG.unmask(ai, v);
  console.log('--- AI (masked) ---\n' + ai + '\n--- restored ---\n' + back.split('\n').slice(0,4).join('\n'));
}
const e = AG.evaluate();
console.log('EVAL recall', e.recall.toFixed(2), 'precision', e.precision.toFixed(2), e.per);
e.rows.filter(r => r.miss.length || r.extra.length).forEach(r => console.log('  ', r.text, 'MISS', r.miss, 'EXTRA', r.extra));
