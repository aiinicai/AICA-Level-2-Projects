import pathlib
root = pathlib.Path(__file__).parent
for folder, out in [('ghost_vendor', 'VendorShield_GhostVendorDetector.html'), ('ai_gateway', 'CA_Safe_AI_Gateway.html')]:
    d = root / folder
    html = (d / 'template.html').read_text()
    core = (d / 'core.js').read_text().replace("if (typeof module !== 'undefined') module.exports", "if (typeof module !== 'undefined' && module.exports) module.exports")
    html = html.replace('/*__CORE__*/', core).replace('/*__UI__*/', (d / 'ui.js').read_text())
    assert '</script' not in core.lower() and '</script' not in (d / 'ui.js').read_text().lower()
    (root / 'dist').mkdir(exist_ok=True)
    (root / 'dist' / out).write_text(html)
    print('built', out, len(html)//1024, 'KB')
