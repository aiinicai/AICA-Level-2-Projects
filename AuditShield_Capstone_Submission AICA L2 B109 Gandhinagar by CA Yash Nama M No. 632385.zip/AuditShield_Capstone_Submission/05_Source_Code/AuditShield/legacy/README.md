# AuditShield capstone: VendorShield + CA-Safe AI Gateway

## Run the demo (no installation)
Open the files in `dist/` by double-clicking them. They open in Chrome, Edge or Firefox and work offline.
- `dist/VendorShield_GhostVendorDetector.html`: privacy-preserving ghost vendor / related-party detector
- `dist/CA_Safe_AI_Gateway.html`: masks client identifiers before text goes to an AI

## Folder map
- `ghost_vendor/core.js`: hashing, normalisation, fraud rules, sample data
- `ghost_vendor/ui.js`, `template.html`: screens
- `ai_gateway/core.js`: detectors, checksums, vault, leak test, offline demo AI, evaluation set
- `ai_gateway/ui.js`, `template.html`: screens
- `sample_data/`: the sample company as CSV (upload these in VendorShield, or edit them)
- `diagrams/`: diagram images + the script that draws them
- `tests/`: Node tests

## After editing code
    python build.py          # rebuilds dist/*.html
    node tests/test_gv.js    # VendorShield logic tests
    node tests/test_ag.js    # Gateway logic tests

All data is synthetic. Never demo with real client data.
