from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import pathlib

ROOT = pathlib.Path(__file__).parent
doc = Document()
sec = doc.sections[0]
sec.left_margin = sec.right_margin = Cm(2); sec.top_margin = sec.bottom_margin = Cm(1.8)
st = doc.styles["Normal"]; st.font.name = "Calibri"; st.font.size = Pt(11)
st.element.rPr.rFonts.set(qn("w:eastAsia"), "Calibri")
for lvl, size, col in [(1, 18, "13294B"), (2, 14, "1D4ED8"), (3, 12, "334155")]:
    h = doc.styles[f"Heading {lvl}"]; h.font.size = Pt(size); h.font.color.rgb = RGBColor.from_string(col); h.font.name = "Calibri"


def shade(cell, hexcol):
    tcPr = cell._tc.get_or_add_tcPr(); s = OxmlElement("w:shd")
    s.set(qn("w:val"), "clear"); s.set(qn("w:color"), "auto"); s.set(qn("w:fill"), hexcol); tcPr.append(s)


def P(text="", bold=False, italic=False, size=None, color=None, align=None, space_after=6):
    p = doc.add_paragraph()
    add_runs(p, text, bold, italic, size, color)
    p.paragraph_format.space_after = Pt(space_after)
    if align: p.alignment = align
    return p


def add_runs(p, text, bold=False, italic=False, size=None, color=None):
    # **bold** markup support
    parts = text.split("**")
    for i, part in enumerate(parts):
        if not part: continue
        r = p.add_run(part); r.bold = bold or (i % 2 == 1); r.italic = italic
        if size: r.font.size = Pt(size)
        if color: r.font.color.rgb = RGBColor.from_string(color)


def B(text, level=0, style="List Bullet"):
    p = doc.add_paragraph(style=style if level == 0 else style + " 2")
    add_runs(p, text); p.paragraph_format.space_after = Pt(2)
    return p


def N(text):
    return B(text, style="List Number")


def table(headers, rows, widths=None, head_fill="13294B", font=9.5):
    t = doc.add_table(rows=1, cols=len(headers)); t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        c = t.rows[0].cells[i]; c.text = ""; r = c.paragraphs[0].add_run(h); r.bold = True
        r.font.size = Pt(font); r.font.color.rgb = RGBColor(255, 255, 255); shade(c, head_fill)
    for ri, row in enumerate(rows):
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""; add_runs(cells[i].paragraphs[0], str(v), size=font)
            if ri % 2: shade(cells[i], "F1F5F9")
    if widths:
        for row in t.rows:
            for i, w in enumerate(widths): row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)
    return t


def callout(text, fill="EFF6FF", border="2563EB"):
    t = doc.add_table(rows=1, cols=1); c = t.rows[0].cells[0]; shade(c, fill); c.text = ""
    add_runs(c.paragraphs[0], text, size=10.5)
    doc.add_paragraph().paragraph_format.space_after = Pt(2)


def say(text):
    callout("🎤 SAY: " + text, fill="FFF7ED")


# ============================================================ COVER
P("Capstone / Hackathon Project Pack", bold=True, size=26, color="13294B", align=WD_ALIGN_PARAGRAPH.CENTER, space_after=4)
P("Audit + AI + Privacy for Chartered Accountants", size=15, color="475569", align=WD_ALIGN_PARAGRAPH.CENTER, space_after=18)
table(["Project", "One-line idea", "File to open"], [
    ["1. VendorShield", "Find ghost vendors, related parties and payment fraud **without the auditor seeing anyone's PAN, bank account, phone or address**.",
     "VendorShield_GhostVendorDetector.html"],
    ["2. CA-Safe AI Gateway", "Let CA staff use ChatGPT-style AI on client work **while client identities are automatically hidden** before they leave the computer.",
     "CA_Safe_AI_Gateway.html"],
], widths=[3.5, 9.5, 4.5], font=10)
callout("**Both apps are already built and tested.** Download the zip, unzip it, and double-click the HTML file. It opens in Chrome or Edge. "
        "No installation, no internet, no server, no login. This is deliberate: on demo day nothing can break because of Wi-Fi or an expired API key.",
        fill="F0FDF4")

doc.add_heading("Your plan for today", level=2)
table(["Time", "What to do", "Done when…"], [
    ["Hour 1", "Open both apps. Click through every tab with the sample data. Read sections 1.1–1.3 and 2.1–2.3 of this guide.",
     "You can explain each app in 2 sentences without looking."],
    ["Hour 2", "Make the slides (outline in Section 3; use the two diagram images). Put your team name on the apps' title if you want "
               "(edit the <h1> line in the HTML with Notepad).", "8–10 slides ready."],
    ["Hour 3", "Rehearse the click-by-click demo scripts (1.6 and 2.6) **three times** with a timer. Record one run on your phone or with a screen recorder as a backup.",
     "Demo fits the time limit and you have a backup video."],
    ["Hour 4", "Practise the judge Q&A (1.8 and 2.8). Each team member owns some questions.", "Every likely question has an owner."],
], widths=[2, 10.5, 5])

# ============================================================ PROJECT 1
doc.add_page_break()
doc.add_heading("1. VendorShield: Privacy-Preserving Ghost Vendor & Related-Party Detector", level=1)
doc.add_heading("1.1 The problem, in simple language", level=2)
P("Imagine an employee in the Accounts Payable team of a company. He creates a new supplier called **'Sai Traders'** in the "
  "accounting system. But the bank account he enters for 'Sai Traders' is **his own**. He then books fake invoices of ₹98,500, ₹99,200 and ₹97,800. "
  "Each one is just below the ₹1,00,000 limit that needs his manager's approval. Money quietly flows from the company into his pocket.")
P("This is called a **ghost vendor** (a supplier that doesn't really exist). A similar trick is a **related-party vendor**: a supplier secretly "
  "owned by a director's family, which the law requires to be disclosed and approved.")
P("**How would an auditor catch it?** By comparing the vendor's bank account, PAN, phone and address with every employee's and director's details. "
  "If they match, something is wrong. **The catch:** employee PAN, bank account, phone and home address are personal data. "
  "Companies are increasingly unwilling to hand the whole HR and payroll file to outsiders, especially with India's DPDP Act 2023 and confidentiality duties. "
  "So the check is often done only on a small sample, or not at all.")
callout("**In one line:** auditors need to compare personal details to catch fraud, but privacy rules make it hard to share those details. "
        "VendorShield lets them compare **without seeing** the details.", fill="FEF2F2")

doc.add_heading("1.2 What the program is", level=2)
P("VendorShield is a **web application that runs completely inside the browser** (a single HTML file with JavaScript). It has two sides:")
B("**Client side (at the company):** loads the employee list, vendor list, director list and payment list, then converts every sensitive value "
  "into a secret code using a key that only the company knows.")
B("**Auditor side (at the CA firm):** receives only the coded file, finds matches and suspicious payment patterns, and shows a relationship graph, "
  "a list of red flags explained in plain English, and a downloadable audit workpaper.")
P("**Platform:** any laptop with Chrome, Edge or Firefox (Windows, Mac or Linux). Works offline. For the semester version it can become a hosted web app "
  "(e.g. Python FastAPI backend + the same front end) or a Tally/ERP add-on. Today, the browser version is enough and is the safest to demo.")

doc.add_heading("1.3 How it solves the problem (the 6 steps)", level=2)
doc.add_picture(str(ROOT / "diagrams" / "diagram_vendorshield.png"), width=Cm(17.5))
N("**Load data:** 4 CSV files exported from Tally/ERP: employees, vendors, directors, payments (or click 'Load sample company data').")
N("**Clean the data (fuzzy matching):** the same address can be written many ways: 'Flat No. 12, M.G. Rd., Pune' and 'Flat 12 MG Road Pune'. "
  "The program removes punctuation and filler words and expands abbreviations, so both become '12 ganesh society mg road pune'. Phones keep the last 10 digits. "
  "A GSTIN contains the PAN inside it, so the PAN is extracted from it too.")
N("**Lock with a secret key (HMAC-SHA256):** each cleaned value is turned into a code like H:3f9a1c0b…. "
  "The same value with the same key always gives the same code, so matching still works. Without the key, nobody can reverse it.")
N("**Match codes:** if a vendor's bank-account code equals an employee's bank-account code, they have the same bank account. The auditor knows they match, "
  "but never sees the actual account number.")
N("**Apply 10 fraud rules + risk score:** shared details, split payments, near-limit amounts, duplicate invoices, self-approval and weekend round sums (table 1.4).")
N("**Show results:** a relationship graph (who is connected to whom), red flags ranked Critical → Low with ₹ amounts, and a workpaper you can download.")
callout("**Why a secret key and not normal hashing?** A 10-digit mobile number has only about 4 billion possibilities. Anyone can hash all of them and look up the answer. "
        "The app's tab ④ proves this live: it cracks a plain SHA-256 phone hash in seconds in the browser. With HMAC the attacker would need the client's key, "
        "which never leaves the client. **This is your strongest technical point. Make sure every team member can explain it.**", fill="F0FDF4")

doc.add_heading("1.4 All fraud types it covers", level=2)
table(["#", "Fraud / risk", "Simple meaning", "How the program spots it", "In the sample demo"], [
    ["R1", "Ghost / fictitious vendor", "An employee is secretly the supplier", "Vendor bank a/c or PAN (or GSTIN) = an employee's", "Sai Traders = employee E107 (Critical)"],
    ["R2", "Undisclosed related party (AS 18 / Ind AS 24, Sec 188, SA 550)", "Supplier belongs to a director or their family", "Vendor shares bank/PAN/phone/address with a director", "Om Enterprises = director's phone + address"],
    ["R3", "Conflict of interest / kickbacks", "Employee's relative or friend gets business", "Vendor phone or address = an employee's", "Kumar Hardware = Stores employee's phone"],
    ["R4", "Shell vendors / duplicate vendor master", "One person runs many 'companies'; or the same vendor is entered twice", "Different vendor names, same PAN/bank/GSTIN/phone/address", "Sai Traders & Shri Sai Trading Co share a PAN"],
    ["R5", "Ghost employee (payroll fraud)", "Fake employee whose salary goes to a real person", "Two employees paid into one bank account", "E109 & E110 same account"],
    ["R6", "Duplicate payment", "Same invoice paid twice", "Same vendor + same invoice number", "Invoice SP-2207 paid twice"],
    ["R7", "Invoice splitting", "One big bill broken into small ones to avoid approval", "Several payments within N days, each below limit, total above it", "3 payments = ₹1.63 lakh in 2 days"],
    ["R8", "Approval-limit manipulation", "Amounts kept just under the limit", "Repeated amounts at 90–99.9% of the limit", "6 payments of ₹97,800–₹99,750"],
    ["R9", "Segregation-of-duties breach", "Same person creates the vendor and approves its payment", "created_by = approved_by", "E107 created & approved Sai Traders"],
    ["R10", "Management override indicator (SA 240)", "Unusual timing / round sums", "Round amounts paid on Saturday/Sunday", "₹1,50,000 on a Sunday"],
    ["Roadmap", "Vendor bank-change fraud (payment redirection)", "Fraudster changes a real vendor's bank details before a big payment", "Needs vendor-master change history", "-"],
    ["Roadmap", "Benford's law anomalies", "Invented numbers have an unnatural digit pattern", "First-digit test per vendor/approver", "-"],
    ["Roadmap", "Circular trading / round-tripping", "Money goes out and comes back via the same party", "Needs customer receipts data", "-"],
    ["Roadmap", "Bid rigging", "Fake competing quotes", "Losing bidders share details with the winner", "-"],
], widths=[1.3, 3.4, 3.6, 4.6, 4.6], font=8.5)
P("**Result on the sample company:** 14 red flags. Every planted fraud was caught, and there were no false alarms **on this sample**. "
  "Be honest that the sample was made by us; real data will produce some false alarms (e.g. two vendors legitimately sharing an office).", size=10)

doc.add_heading("1.5 What it cannot catch (say this before judges ask)", level=2)
B("A fraudster who uses details **completely unconnected** to anyone in the master files (e.g. a friend's bank account that isn't on file).")
B("Cash bribes, verbal collusion, or anything that leaves no data trail.")
B("A red flag is **not proof**. A shared address can be a shared office building. Every flag needs auditor follow-up under SA 240 and SA 550.")
B("Today's version is rule-based plus graph analytics. Machine learning (anomaly scoring, smarter name matching) is the roadmap.")

doc.add_heading("1.6 Live demo script (≈3 minutes, click by click)", level=2)
table(["Step", "Click", "Say"], [
    ["1", "Tab ① → 'Load sample company data'", "\"This is a fictional company: 10 employees, 12 vendors, 3 directors and 86 payments. The yellow cells are personal data the company does not want to share.\""],
    ["2", "Point at the key box → click '🔒 Protect & share with auditor'", "\"The company enters a secret key that only it knows. Every PAN, GSTIN, bank account, phone and address becomes a code.\""],
    ["3", "Tab ② appears. Point at the green leak test.", "\"This is everything the auditor receives. Our automatic test searched this file for all 120 original values and found zero.\""],
    ["4", "Tab ③ → '▶ Run fraud analysis'", "\"Now the auditor analyses only codes.\" Read the KPI cards: 14 red flags, 2 critical, amount at risk."],
    ["5", "Click the first CRITICAL flag (Sai Traders ↔ E107)", "\"Sai Traders shares the same bank account, PAN, phone and address as employee E107 in Accounts Payable. We found it without ever seeing the account number.\" The graph highlights the link."],
    ["6", "Click the R2 flag (Om Enterprises ↔ director)", "\"This supplier shares a phone and address with a director's family. That's a related party that must be disclosed.\""],
    ["7", "Click R7 split payment, then R8", "\"Three bills in two days, each under the limit, total ₹1.63 lakh. And six payments sit just under ₹1 lakh.\""],
    ["8", "'Download audit workpaper'", "\"The auditor gets a ready workpaper with an empty column for their conclusion.\""],
    ["9", "Tab ④ → '⚡ Attack it'", "\"Why a secret key? Watch: plain hashing of a phone number is cracked live in a few seconds. With our key the attack can't even start.\""],
], widths=[1.2, 5.3, 11], font=9)
callout("**90-second version:** steps 1, 2, 4, 5, 9 only.  **Backup:** record a screen video of the full run today, in case the projector laptop has problems.", fill="FFF7ED")

doc.add_heading("1.7 How to pitch it to judges (structure)", level=2)
N("**Hook (15 s):** \"What if the person paying the bills is also the supplier?\" Tell the Sai Traders story.")
N("**Problem (30 s):** the check is easy in theory but needs personal data the company can't freely share. Use the red lane of the diagram.")
N("**Solution (30 s):** 'match without seeing'. Show the blue lane of the diagram.")
N("**Live demo (2–3 min):** script 1.6.")
N("**Why it is technically sound (30 s):** keyed hashing vs plain hashing (tab ④), fuzzy cleaning, graph + 10 rules, automatic leak test.")
N("**Honest limits + roadmap (20 s):** section 1.5 and 1.9.")
N("**Close (10 s):** \"Auditors get the evidence. Employees keep their privacy. Fraud has nowhere to hide.\"")

doc.add_heading("1.8 Judge questions and good answers", level=2)
table(["Likely question", "Answer"], [
    ["Where is the AI?", "Today it is explainable analytics: fuzzy normalisation, graph analysis and weighted risk scoring. Auditors must be able to explain every flag (SA 240), so we started explainable. "
     "Roadmap: ML anomaly scoring on payments and learned name/address matching. Our second project, the AI Gateway, covers safe use of generative AI."],
    ["Can't the auditor reverse the codes?", "Not without the key. HMAC-SHA256 needs the secret key to make any guess. Tab ④ shows plain hashing being cracked and why keyed hashing stops it."],
    ["Who holds the key?", "Only the client. A new random key per engagement, so codes can't be linked across years or clients. To investigate a flag, the auditor asks the client to reveal only that one record."],
    ["What about spelling differences?", "We clean before hashing (abbreviations, punctuation, filler words). Exact hashing can't catch typos like 'Ganseh'. Roadmap: privacy-preserving fuzzy matching (e.g. Bloom-filter encoding)."],
    ["Did you test it on real data?", "No. We used synthetic data on purpose, to avoid any confidentiality breach. All planted frauds were caught with 0 false alarms on that sample. Next step: pilot with a CA firm on anonymised data."],
    ["Isn't this what IDEA/ACL already do?", "Those tools need the raw data. Our difference is doing the matching on protected data, in a free browser tool a small CA firm can use."],
    ["Is hashed data 'anonymous' under the law?", "No. It is pseudonymised: the client can still link codes back, so it is still personal data. We reduce exposure (data minimisation); we don't claim it removes legal obligations."],
], widths=[5, 12.5], font=9)

doc.add_heading("1.9 Future scope (semester version)", level=2)
for t in ["Direct import from Tally/ERP exports; vendor-master change history (bank-change fraud).",
          "Privacy-preserving fuzzy matching for typos; ML anomaly scores on payments.",
          "Client 'reveal on request' workflow with an audit trail; hosted multi-user version.",
          "Evaluation on a larger synthetic benchmark with precision/recall, plus a pilot with a practising CA firm."]:
    B(t)

# ============================================================ PROJECT 2
doc.add_page_break()
doc.add_heading("2. CA-Safe AI Gateway: Use AI Without Leaking Client Data", level=1)
doc.add_heading("2.1 The problem, in simple language", level=2)
P("It's 9 pm and an article assistant has to draft a reply to a GST notice by tomorrow. The fastest way is to paste the notice into an AI chatbot. "
  "But the notice contains the **client's name, GSTIN, PAN, the director's mobile number and the company's bank account**. Once pasted, that data sits on "
  "a server outside the firm. The firm doesn't control it and has no record that it happened.")
P("CAs have a professional duty to keep client information confidential (ICAI Code of Ethics), and India's DPDP Act 2023 adds legal duties for personal data. "
  "So firms are stuck: **ban AI** and lose productivity, or **ignore the problem** and hope nothing leaks.")
callout("**In one line:** staff want AI's speed, but every prompt can leak client identities. The gateway lets them use AI while the identities stay inside the firm.", fill="FEF2F2")

doc.add_heading("2.2 What the program is", level=2)
P("A **privacy layer that sits between the CA and any AI model**. The CA types normally. Before anything is sent, the gateway finds every identifier, "
  "replaces it with a code like [PERSON_1] or [PAN_1], checks that nothing slipped through, and sends only the masked text. When the AI replies using those codes, "
  "the gateway puts the real names back **on the CA's own computer**.")
P("**Platform:** a single HTML file that runs in Chrome/Edge/Firefox. Detection, the vault (code ↔ real value table) and the audit log all stay in the browser. "
  "It has a built-in **offline demo AI** so the live demo never depends on the internet, and it can connect to a real AI through any OpenAI-compatible API, "
  "including a local model like Ollama. Semester version: a browser extension that works inside ChatGPT/Gemini directly, or an office-wide proxy.")

doc.add_heading("2.3 How it solves the problem (the 6 steps)", level=2)
doc.add_picture(str(ROOT / "diagrams" / "diagram_ai_gateway.png"), width=Cm(17.5))
N("**CA types the question** with the client data, as usual.")
N("**Detect:** 12 detectors find Indian identifiers. PAN, GSTIN, Aadhaar, bank account, IFSC, UPI ID, card number, phone, email, person names, firm names and a client watch-list. "
  "**Checksums** cut false alarms: Aadhaar uses the Verhoeff check digit, GSTIN has its own check character, and cards use the Luhn check. So a random 12-digit number isn't mistaken for an Aadhaar.")
N("**Replace with consistent codes:** 'Rohit Shinde' becomes [PERSON_1] **every time** it appears, so the AI can still reason ('PERSON_1 is both proprietor and employee'). Amounts and dates are kept, so the analysis still works.")
N("**Leak test:** the outgoing text is scanned again and searched for every real value in the vault. Only if 0 are found does it go out.")
N("**AI answers using the codes.** It never sees the real values.")
N("**Restore locally:** codes in the reply are swapped back to real names on the CA's computer. Every request is written to an **audit log** (time, AI used, how many identifiers were masked, leak-test result).")

doc.add_heading("2.4 Risks and frauds it helps prevent", level=2)
P("Be precise with judges: the gateway **does not detect fraud**. It **prevents data leaks**, and leaked identity data is the raw material for many frauds.", italic=True)
table(["Risk / fraud", "How leaked data is misused", "How the gateway prevents it"], [
    ["Client confidentiality breach (ICAI Code of Ethics)", "Client's financial details sit on an outside server", "Only codes leave; the real values stay in the local vault"],
    ["Personal-data exposure (DPDP Act 2023)", "Individuals' PAN, Aadhaar, phone, address processed by a third party", "Data minimisation: identifiers removed before sharing; log as evidence"],
    ["Identity theft / KYC fraud", "Name + PAN + Aadhaar + phone are enough for fake loans or SIM swaps", "Aadhaar, PAN and phone are always masked; Aadhaar treated as Critical"],
    ["Fake GST registration / GSTIN misuse", "Leaked GSTIN + PAN + signatory details used to impersonate a business", "GSTIN, PAN and signatory names masked"],
    ["Payment redirection / business-email-compromise scams", "Fraudster learns vendor names + bank details, then emails 'new bank details'", "Vendor names, bank accounts, IFSC and UPI IDs masked"],
    ["Card fraud", "Card numbers in reimbursement data", "Luhn-validated card detector"],
    ["Phishing / impersonation of clients or partners", "Names, emails and phones used for targeted phishing", "Emails, phones and names masked"],
    ["Shadow AI / insider misuse", "Nobody knows what staff sent to AI tools", "Audit log of every request; exportable for peer review / quality control"],
    ["Prompt-data reuse by AI providers", "Depending on settings, prompts may be retained or reviewed by the provider", "Even if retained, prompts contain no identities"],
], widths=[4.3, 6.4, 6.8], font=9)
P("**Measured accuracy (built-in test, tab ③):** 21 of 22 hand-labelled identifiers caught (95% recall), 0 false alarms (100% precision) on 18 test sentences. "
  "The miss is a lowercase name with no title ('ramesh gupta'). That honest miss is a good talking point. "
  "These test sentences were written by us, so treat this as a sanity check, not proof.", size=10)

doc.add_heading("2.5 What it cannot do (say this before judges ask)", level=2)
B("Names with no title or keyword, lowercase names, or names in regional scripts can be missed. The client watch-list and an NER model (roadmap) close the gap.")
B("Indirect identification: 'the only steel company in Bhosari with ₹480 crore turnover' can still point to a client. Future: generalise amounts and locations.")
B("Pseudonymised data is **still personal data** legally. The gateway reduces risk; it doesn't replace the firm's policies or client consent.")
B("Scanned PDFs/images need OCR first (roadmap).")

doc.add_heading("2.6 Live demo script (≈3 minutes, click by click)", level=2)
table(["Step", "Click", "Say"], [
    ["1", "Sample 'GST notice reply'", "\"An article assistant wants AI to draft a GST notice reply. Look at what's inside: client name, GSTIN, PAN, director's mobile, bank account.\""],
    ["2", "'🔍 Scan & mask'", "\"Every identifier is highlighted by type. The big numbers below show what would have gone to an outside server without us.\""],
    ["3", "Point at box ③ and the green leak test", "\"This is ALL the AI receives: codes, plus amounts and dates so the analysis still works. Leak test: zero.\""],
    ["4", "'📤 Send masked text to AI'", "\"The AI answers using codes…\" (open 'Show raw AI reply') \"…and here, on our computer, real names are restored.\""],
    ["5", "Sample 'Vendor ledger review' → Scan → Send", "\"Note: Rohit Shinde appears three times and gets ONE code, so the AI can still notice he is both proprietor and employee.\""],
    ["6", "Sample 'Payroll / KYC query' → Scan", "\"Aadhaar and card numbers are caught using checksum validation, the same math the government and card networks use.\""],
    ["7", "Tab ② Vault & Audit Log", "\"The vault never leaves this computer. The log is proof for quality review of what went to AI.\""],
    ["8", "Tab ③ → Run test", "\"We measured it: 95% recall, 0 false alarms. Here is the one we miss, a lowercase name, and how we'll fix it.\""],
], widths=[1.2, 5.3, 11], font=9)
callout("**90-second version:** steps 1–4 and 8.  If the event has internet and you have an API key, you can switch tab ④ to a real AI. "
        "But **keep the offline demo AI as the default on stage**.", fill="FFF7ED")

doc.add_heading("2.7 How to pitch it to judges (structure)", level=2)
N("**Hook:** \"Show of hands: who has pasted something into ChatGPT that they probably shouldn't have?\"")
N("**Problem:** the 9 pm GST notice story; the choice between banning AI and ignoring the problem.")
N("**Solution:** 'AI sees the problem, not the people'. Show the diagram.")
N("**Demo:** script 2.6.")
N("**Technical depth:** India-specific detectors with checksums, consistent pseudonyms, double leak test, local vault, audit log.")
N("**Honest limits + roadmap.**")
N("**Close:** \"Firms don't have to choose between AI and confidentiality.\"")

doc.add_heading("2.8 Judge questions and good answers", level=2)
table(["Likely question", "Answer"], [
    ["Isn't this just regex / Microsoft Presidio?", "Generic tools don't know Indian identifiers or CA workflows. We added checksum-validated Aadhaar/GSTIN/card detection, consistent pseudonyms for reasoning, a leak re-test, a local vault, an audit log and a measured accuracy test."],
    ["Does masking reduce AI answer quality?", "Very little for audit/tax tasks: the AI needs relationships, amounts and dates, not real names. Consistent codes keep relationships intact. Future work: measure answer quality with and without masking."],
    ["What if detection misses something?", "That's why we measure recall and show misses openly. Safeguards: client watch-list, leak re-test, and a confirmation prompt if anything looks unmasked. Roadmap: NER model for names."],
    ["Why not just use a local AI model?", "Local models are a great option and our gateway supports them. But many firms will still use cloud AI for quality; the gateway makes both safe, and the audit log helps either way."],
    ["Where does the vault live?", "Only in the browser tab's memory. Close the tab or click 'Clear vault' and it's gone. Semester version: encrypted local storage per engagement."],
    ["Is this DPDP compliant?", "It supports data minimisation and creates evidence, but compliance depends on the firm's overall processes. We don't claim it alone makes a firm compliant."],
], widths=[5, 12.5], font=9)

doc.add_heading("2.9 Future scope", level=2)
for t in ["Browser extension that masks text directly inside ChatGPT / Gemini / Claude web apps.",
          "NER model for names in any case or regional script; OCR for scanned notices and invoices.",
          "Policy engine: per-client rules (e.g. 'never send anything about Client X'), role-based reveal.",
          "Office-wide proxy with central audit log for the firm's quality-control reviews."]:
    B(t)

# ============================================================ PRESENTING
doc.add_page_break()
doc.add_heading("3. Presenting: one project or both?", level=1)
P("**If you can present only one:** choose **VendorShield**. Its 'match without seeing' idea and the live hash-cracking demo are memorable, and it is clearly an audit tool.")
P("**If you have 5+ minutes, present both as one suite: 'AuditShield: privacy-first tools for CA firms'.** They complement each other:")
B("VendorShield covers **audit analytics on private data** (Audit + Privacy).")
B("The Gateway covers **safe use of generative AI** (AI + Privacy). Together they answer the 'where is the AI?' question for VendorShield.")
doc.add_heading("Slide outline (10 slides)", level=2)
table(["#", "Slide", "Content"], [
    ["1", "Title", "Team name, 'AuditShield: privacy-first audit + AI tools for CA firms'"],
    ["2", "The problem", "Two stories: Sai Traders ghost vendor; 9 pm GST notice pasted into AI"],
    ["3", "Why it's hard", "Fraud checks and AI both need data that privacy rules protect"],
    ["4", "VendorShield: how it works", "diagram_vendorshield.png"],
    ["5", "Fraud coverage", "Table 1.4 (R1–R10), result on the sample: 14 flags, 0 false alarms"],
    ["6", "LIVE DEMO 1", "Switch to browser"],
    ["7", "AI Gateway: how it works", "diagram_ai_gateway.png"],
    ["8", "LIVE DEMO 2 + accuracy", "Switch to browser; 95% recall / 100% precision on our test set"],
    ["9", "Tech & honesty", "Stack: HTML/CSS/JavaScript, no libraries, HMAC-SHA256, checksums, force-directed graph. Limits + roadmap"],
    ["10", "Close", "\"Auditors get the evidence. Clients keep their privacy.\" Thank you + Q&A"],
], widths=[1, 4, 12.5], font=9.5)

doc.add_heading("4. Technical notes (for viva / code questions)", level=1)
table(["Item", "VendorShield", "CA-Safe AI Gateway"], [
    ["Built with", "HTML + CSS + plain JavaScript; no external libraries", "HTML + CSS + plain JavaScript; no external libraries"],
    ["Core algorithm", "SHA-256 + HMAC (verified against Node's crypto library), text normalisation, attribute index → entity pairs, 10 rules, weighted risk score (Critical 40, High 25, Medium 12, Low 5; max 100)",
     "Regex detectors + Verhoeff (Aadhaar), GSTIN mod-36 check, Luhn (cards); overlap resolution by priority; name propagation; token vault; double leak test"],
    ["Graph / UI", "Force-directed graph drawn on HTML canvas; click a flag to highlight", "Colour-coded highlights, side-by-side 'typed vs sent vs restored'"],
    ["Data", "Synthetic company with 6 planted fraud scenarios; or upload your own 4 CSVs", "3 synthetic sample prompts; 18 labelled test sentences"],
    ["Source files", "ghost_vendor/core.js (logic), ui.js (screen), template.html", "ai_gateway/core.js, ui.js, template.html"],
    ["Rebuild after editing", "python build.py  → regenerates the HTML files in dist/", "same"],
    ["Tests", "node tests/test_gv.js", "node tests/test_ag.js"],
], widths=[3, 7.3, 7.2], font=9)
callout("**Everything is synthetic.** All names, PANs, GSTINs, Aadhaar and bank numbers in the samples are made up (some generated with valid checksums for realism). "
        "Never demo with real client data.", fill="FEF2F2")

doc.save(ROOT.parent / "Capstone_Guide_VendorShield_and_AI_Gateway.docx")
print("guide saved")
