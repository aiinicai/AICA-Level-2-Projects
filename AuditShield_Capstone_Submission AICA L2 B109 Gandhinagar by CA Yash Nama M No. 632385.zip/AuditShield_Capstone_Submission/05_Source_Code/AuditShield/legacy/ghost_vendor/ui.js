/* VendorShield UI */
(function () {
  const $ = id => document.getElementById(id);
  const esc = s => String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let RAW = null, PROT = null, RESULT = null;

  // ---------- tabs
  document.querySelectorAll('nav button').forEach(b => b.onclick = () => showTab(b.dataset.tab));
  function showTab(t) {
    document.querySelectorAll('nav button').forEach(b => b.classList.toggle('active', b.dataset.tab === t));
    document.querySelectorAll('.tab').forEach(s => s.classList.toggle('active', s.id === t));
    if (t === 't3' && RESULT) setTimeout(() => graph.resize(), 30);
  }

  // ---------- tables
  function table(rows, sensCols, mode) {
    if (!rows || !rows.length) return '<div style="padding:8px;color:#64748b">No rows</div>';
    const cols = Object.keys(rows[0]);
    let h = '<table><tr>' + cols.map(c => '<th>' + esc(c) + '</th>').join('') + '</tr>';
    rows.forEach(r => {
      h += '<tr>' + cols.map(c => {
        const s = sensCols.includes(c);
        let v = r[c];
        if (c === 'amount') v = GV.fmtINR(v);
        return '<td class="' + (s ? mode : '') + '">' + esc(v) + '</td>';
      }).join('') + '</tr>';
    });
    return h + '</table>';
  }
  function renderRaw() {
    $('rawCard').style.display = 'block';
    $('rawEmp').innerHTML = table(RAW.employees, GV.SENSITIVE.employees, 'sens');
    $('rawVen').innerHTML = table(RAW.vendors, GV.SENSITIVE.vendors, 'sens');
    $('rawDir').innerHTML = table(RAW.directors, GV.SENSITIVE.directors, 'sens');
    $('rawPay').innerHTML = table(RAW.payments, [], '');
  }

  // ---------- load data
  $('loadSample').onclick = () => {
    RAW = GV.sampleData();
    $('loadMsg').textContent = `Loaded fictional "Mehta Industries Pvt Ltd": ${RAW.employees.length} employees, ${RAW.vendors.length} vendors, ${RAW.directors.length} directors, ${RAW.payments.length} payments.`;
    renderRaw();
  };
  $('upload').onchange = async (ev) => {
    const data = { employees: [], vendors: [], directors: [], payments: [] };
    const got = [];
    for (const f of ev.target.files) {
      const name = f.name.toLowerCase();
      const k = ['employees', 'vendors', 'directors', 'payments'].find(t => name.includes(t.slice(0, -1)));
      if (!k) continue;
      data[k] = GV.parseCSV(await f.text()); got.push(k + ' (' + data[k].length + ')');
    }
    if (!got.length) { alert('No recognised files. Name them employees.csv, vendors.csv, directors.csv, payments.csv'); return; }
    RAW = data; $('loadMsg').textContent = 'Loaded: ' + got.join(', '); renderRaw();
  };
  function download(name, text, type) {
    const a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob([text], { type: type || 'text/csv' }));
    a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }
  $('dlSample').onclick = () => {
    const d = GV.sampleData();
    ['employees', 'vendors', 'directors', 'payments'].forEach((t, i) => setTimeout(() => download(t + '.csv', GV.toCSV(d[t])), i * 400));
  };
  $('showKey').onchange = e => $('key').type = e.target.checked ? 'text' : 'password';

  // ---------- protect
  $('protect').onclick = () => {
    try { PROT = GV.protect(RAW, $('key').value); } catch (e) { alert(e.message); return; }
    RESULT = null;
    $('pEmp').innerHTML = table(PROT.employees, GV.SENSITIVE.employees, 'hash');
    $('pVen').innerHTML = table(PROT.vendors, GV.SENSITIVE.vendors, 'hash');
    $('pDir').innerHTML = table(PROT.directors, GV.SENSITIVE.directors, 'hash');
    $('pPay').innerHTML = table(PROT.payments, [], '');
    // leak check: search the protected file for every raw sensitive value
    const blob = JSON.stringify(PROT); let total = 0, leaked = 0;
    for (const t of ['employees', 'vendors', 'directors'])
      (RAW[t] || []).forEach(r => GV.SENSITIVE[t].forEach(f => { if (r[f]) { total++; if (blob.includes(String(r[f]))) leaked++; } }));
    $('leakCheck').innerHTML = `<div class="${leaked ? 'warn' : 'ok'}" style="margin:0">Automatic leak test: searched the shared file for all ${total} original sensitive values → <b>${leaked} found</b>.</div>`;
    $('nav2').disabled = false; $('nav3').disabled = false;
    showTab('t2');
  };
  $('dlProtected').onclick = () => download('protected_for_auditor.json', JSON.stringify(PROT, null, 2), 'application/json');
  $('goAnalyze').onclick = () => showTab('t3');

  // ---------- analyse
  $('runBtn').onclick = () => {
    if (!PROT) { alert('Protect the data first (tab 1).'); return; }
    RESULT = GV.analyze(PROT, { approvalLimit: Number($('limit').value) || 100000 });
    const s = RESULT.summary;
    $('kpis').innerHTML = [
      ['', s.vendors + ' / ' + s.payments, 'Vendors / payments scanned'],
      ['', GV.fmtINR(s.totalPaid), 'Total paid'],
      ['red', s.critical, 'Critical flags'],
      ['orange', s.flags, 'Total red flags'],
      ['red', GV.fmtINR(s.amountAtRisk), `Paid to ${s.riskyVendors} high-risk vendors`]
    ].map(k => `<div class="kpi ${k[0]}"><div class="v">${k[1]}</div><div class="l">${k[2]}</div></div>`).join('');
    $('flags').innerHTML = RESULT.flags.map((f, i) => `
      <div class="flag ${f.severity}" data-i="${i}">
        <div><span class="sev ${f.severity}">${f.severity}</span><span class="r">${esc(f.rule)} · ${esc(f.fraud)}</span></div>
        <div class="t">${esc(f.title)}</div>
        <div class="e">${esc(f.explain)}<br><span class="r">Next step: obtain vendor KYC, check approval trail and supporting documents; discuss with management / those charged with governance.</span></div>
      </div>`).join('') || '<div class="ok">No red flags found.</div>';
    document.querySelectorAll('.flag').forEach(el => el.onclick = () => {
      const was = el.classList.contains('sel');
      document.querySelectorAll('.flag').forEach(x => x.classList.remove('sel'));
      if (!was) { el.classList.add('sel'); graph.highlight(RESULT.flags[+el.dataset.i].entities); } else graph.highlight(null);
    });
    $('analysisArea').style.display = 'grid';
    $('dlReport').disabled = false;
    graph.load(RESULT.graph);
  };

  // ---------- workpaper export
  $('dlReport').onclick = () => {
    const s = RESULT.summary, now = new Date().toLocaleString();
    let h = `<html><head><meta charset="utf-8"><title>VendorShield workpaper</title><style>body{font-family:Arial;margin:30px;font-size:13px}
      table{border-collapse:collapse;width:100%}td,th{border:1px solid #ccc;padding:6px;vertical-align:top;text-align:left}th{background:#13294b;color:#fff}
      .Critical{color:#dc2626;font-weight:bold}.High{color:#ea580c;font-weight:bold}.Medium{color:#d97706}</style></head><body>
      <h1>Audit Workpaper: Vendor & Related-Party Red Flags</h1>
      <p>Prepared with VendorShield on ${esc(now)}. Analysis performed on client-protected (keyed-hash) data; no raw PAN, bank, phone or address was received by the auditor.</p>
      <p>Population: ${s.vendors} vendors, ${s.employees} employees, ${s.directors} directors, ${s.payments} payments totalling ${GV.fmtINR(s.totalPaid)}.
      Approval limit used: ${GV.fmtINR($('limit').value)}.</p>
      <table><tr><th>#</th><th>Severity</th><th>Rule</th><th>Finding</th><th>Explanation</th><th>Amount</th><th>Auditor response / conclusion</th></tr>`;
    RESULT.flags.forEach((f, i) => h += `<tr><td>${i + 1}</td><td class="${f.severity}">${f.severity}</td><td>${esc(f.rule)}</td><td>${esc(f.title)}</td>
      <td>${esc(f.explain)}</td><td>${GV.fmtINR(f.amount)}</td><td></td></tr>`);
    h += '</table><p><i>Red flags are indicators, not conclusions. Follow up as per SA 240 (fraud) and SA 550 (related parties).</i></p></body></html>';
    download('VendorShield_workpaper.html', h, 'text/html');
  };

  // ---------- force-directed graph on canvas
  const graph = (function () {
    const cv = $('graph'), ctx = cv.getContext('2d');
    let nodes = [], edges = [], hl = null, drag = null, raf = null, ticks = 0, W = 0, H = 0;
    const COL = { vendor: '#ea580c', employee: '#2563eb', director: '#7c3aed', attr: '#94a3b8' };
    function resize() {
      const r = cv.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
      W = r.width; H = r.height; cv.width = W * dpr; cv.height = H * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); draw();
    }
    function load(g) {
      const map = {};
      nodes = g.nodes.map((n, i) => {
        const a = (i / g.nodes.length) * Math.PI * 2;
        const o = Object.assign({}, n, { x: 0, y: 0, vx: 0, vy: 0, a }); map[n.id] = o; return o;
      });
      edges = g.edges.filter(e => map[e.a] && map[e.b]).map(e => ({ s: map[e.a], t: map[e.b], field: e.field }));
      hl = null; resize();
      nodes.forEach(n => { n.x = W / 2 + Math.cos(n.a) * W * 0.3 + Math.random() * 10; n.y = H / 2 + Math.sin(n.a) * H * 0.3 + Math.random() * 10; });
      ticks = 0; if (!raf) loop();
    }
    function step() {
      const k = 95;
      for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i], b = nodes[j]; let dx = a.x - b.x, dy = a.y - b.y; let d2 = dx * dx + dy * dy || 1;
        const f = (k * k) / d2 * 0.9, d = Math.sqrt(d2); dx /= d; dy /= d;
        a.vx += dx * f; a.vy += dy * f; b.vx -= dx * f; b.vy -= dy * f;
      }
      edges.forEach(e => {
        let dx = e.t.x - e.s.x, dy = e.t.y - e.s.y; const d = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (d - k * 0.9) * 0.04; dx /= d; dy /= d;
        e.s.vx += dx * f; e.s.vy += dy * f; e.t.vx -= dx * f; e.t.vy -= dy * f;
      });
      nodes.forEach(n => {
        n.vx += (W / 2 - n.x) * 0.004; n.vy += (H / 2 - n.y) * 0.004;
        if (n === drag) { n.vx = n.vy = 0; return; }
        n.vx *= 0.82; n.vy *= 0.82;
        n.x = Math.max(40, Math.min(W - 40, n.x + Math.max(-12, Math.min(12, n.vx))));
        n.y = Math.max(30, Math.min(H - 30, n.y + Math.max(-12, Math.min(12, n.vy))));
      });
    }
    function draw() {
      ctx.clearRect(0, 0, W, H);
      const on = n => !hl || hl.has(n.id);
      edges.forEach(e => {
        const act = hl && hl.has(e.s.id) && hl.has(e.t.id);
        ctx.strokeStyle = act ? '#dc2626' : (hl ? '#e2e8f0' : '#94a3b8'); ctx.lineWidth = act ? 3 : 1.5;
        if (e.field === 'created+approved') ctx.setLineDash([6, 4]); else ctx.setLineDash([]);
        ctx.beginPath(); ctx.moveTo(e.s.x, e.s.y); ctx.lineTo(e.t.x, e.t.y); ctx.stroke();
        if (e.field === 'created+approved' && (!hl || act)) {
          ctx.fillStyle = '#475569'; ctx.font = '10px Segoe UI'; ctx.fillText('created & approved', (e.s.x + e.t.x) / 2 + 4, (e.s.y + e.t.y) / 2 - 4);
        }
      });
      ctx.setLineDash([]);
      nodes.forEach(n => {
        ctx.globalAlpha = on(n) ? 1 : 0.18;
        if (n.kind === 'attr') {
          ctx.fillStyle = '#e2e8f0'; ctx.strokeStyle = '#64748b'; ctx.lineWidth = 1; ctx.font = '11px Segoe UI';
          const tw = ctx.measureText('🔗 ' + n.label.replace('same ', '')).width + 14;
          ctx.beginPath(); ctx.roundRect ? ctx.roundRect(n.x - tw / 2, n.y - 10, tw, 20, 9) : ctx.rect(n.x - tw / 2, n.y - 10, tw, 20);
          ctx.fill(); ctx.stroke(); ctx.fillStyle = '#334155'; ctx.textAlign = 'center'; ctx.fillText('🔗 ' + n.label.replace('same ', ''), n.x, n.y + 4);
        } else {
          const r = n.kind === 'vendor' ? 13 + (n.risk || 0) / 10 : 12;
          ctx.beginPath(); ctx.arc(n.x, n.y, r, 0, Math.PI * 2); ctx.fillStyle = COL[n.kind]; ctx.fill();
          if (n.flagged) { ctx.lineWidth = 3.5; ctx.strokeStyle = '#dc2626'; ctx.stroke(); }
          ctx.fillStyle = '#fff'; ctx.font = 'bold 11px Segoe UI'; ctx.textAlign = 'center';
          ctx.fillText(n.kind === 'vendor' ? 'V' : n.kind === 'employee' ? 'E' : 'D', n.x, n.y + 4);
          ctx.fillStyle = '#0f172a'; ctx.font = (n.kind === 'vendor' ? 'bold ' : '') + '12px Segoe UI';
          ctx.fillText(n.label + (n.kind === 'vendor' && n.risk ? '  [risk ' + n.risk + ']' : ''), n.x, n.y + r + 14);
        }
        ctx.globalAlpha = 1;
      });
    }
    function loop() { if (ticks < 400 || drag) { step(); ticks++; } draw(); raf = requestAnimationFrame(loop); }
    function pos(e) { const r = cv.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
    cv.onmousedown = e => { const p = pos(e); drag = nodes.find(n => (n.x - p.x) ** 2 + (n.y - p.y) ** 2 < 400) || null; };
    cv.onmousemove = e => { if (drag) { const p = pos(e); drag.x = p.x; drag.y = p.y; ticks = Math.min(ticks, 300); } };
    window.addEventListener('mouseup', () => drag = null);
    window.addEventListener('resize', () => nodes.length && resize());
    return {
      load, resize,
      highlight(ents) {
        if (!ents) { hl = null; return; }
        hl = new Set(ents);
        // also light up shared-detail nodes connecting highlighted entities
        edges.forEach(e => { if (e.t.kind === 'attr' && hl.has(e.s.id)) {
          const others = edges.filter(x => x.t === e.t && x.s !== e.s && hl.has(x.s.id));
          if (others.length) hl.add(e.t.id); } });
      }
    };
  })();

  // ---------- brute force demo
  function refreshBF() {
    const ph = $('bfPhone').value.replace(/\D/g, '');
    $('bfPrefix').textContent = ph.slice(0, 4);
    $('bfPlain').textContent = 'SHA-256("' + ph + '") = ' + GV.sha256Hex(ph);
    $('bfKeyed').textContent = 'HMAC(key, "' + ph + '") = ' + GV.hmacHex($('key').value || 'Client@Secret#2026', 'phone|' + ph);
  }
  $('bfPhone').oninput = refreshBF; refreshBF();
  $('bfRun').onclick = () => {
    const ph = $('bfPhone').value.replace(/\D/g, '');
    if (ph.length !== 10) { alert('Enter a 10-digit number'); return; }
    const target = GV.sha256Hex(ph), prefix = ph.slice(0, 4);
    let i = 0, found = null; const t0 = performance.now(); $('bfRun').disabled = true; $('bfOut').innerHTML = '';
    (function chunk() {
      const end = Math.min(i + 25000, 1000000);
      for (; i < end; i++) { const c = prefix + String(i).padStart(6, '0'); if (GV.sha256Hex(c) === target) { found = c; break; } }
      $('bfBar').style.width = (i / 10000) + '%';
      if (found || i >= 1000000) {
        const sec = (performance.now() - t0) / 1000, rate = (i + 1) / sec;
        const allIndia = 4e9 / rate;
        $('bfOut').innerHTML = found
          ? `<b style="color:#dc2626">CRACKED in ${sec.toFixed(2)} s:</b> the hash belongs to <b>${found}</b> (${(i + 1).toLocaleString('en-IN')} guesses).<br>
             At this speed (${Math.round(rate).toLocaleString('en-IN')} guesses/sec in a browser) ALL Indian mobile numbers take about
             ${(allIndia / 3600).toFixed(1)} hours. A gaming GPU does it in seconds.`
          : 'Not found in this range.';
        $('bfRun').disabled = false; return;
      }
      setTimeout(chunk, 0);
    })();
  };

  // ---------- coverage table
  const COV = [
    ['Ghost / fictitious vendor (employee is secretly the vendor)', 'R1', 'Vendor bank a/c or PAN = an employee\'s', 'Critical'],
    ['Employee conflict of interest / kickbacks via relative\'s firm', 'R3', 'Vendor phone or address = an employee\'s', 'High'],
    ['Undisclosed related-party transactions (AS 18 / Ind AS 24, Sec 188, SA 550)', 'R2', 'Vendor shares bank/PAN/phone/address with a director or KMP', 'High-Critical'],
    ['Shell companies / multiple fake vendors run by one person', 'R4', 'Different vendor names, same PAN / bank / phone / address', 'High'],
    ['Duplicate vendor master records (leading to double payment)', 'R4', 'Same as above, from master data hygiene angle', 'Medium-High'],
    ['Ghost employee / payroll fraud', 'R5', 'Two employees paid into one bank account', 'High'],
    ['Duplicate invoice / double payment', 'R6', 'Same vendor + same invoice number paid twice', 'High'],
    ['Invoice splitting to bypass approval authority', 'R7', 'Several payments to one vendor within N days, each < limit, total ≥ limit', 'High'],
    ['Approval-limit manipulation', 'R8', 'Repeated amounts at 90–99.9% of the approval limit', 'Medium'],
    ['Segregation-of-duties breach (create vendor + approve payment)', 'R9', 'Vendor created_by = payment approved_by', 'High'],
    ['Management override / unusual timing (SA 240 indicators)', 'R10', 'Round-amount payments on Saturday/Sunday', 'Low'],
    ['Vendor bank-account change fraud (BEC / payment redirection)', 'Roadmap', 'Needs vendor-master change history: bank changed shortly before a big payment', '—'],
    ['Benford\'s law anomalies in vendor payments', 'Roadmap', 'First-digit distribution test per vendor/approver', '—'],
    ['Circular trading / round-tripping', 'Roadmap', 'Needs receipts (customers) too: same party appears as customer and vendor', '—'],
    ['Bid rigging / cartel vendors', 'Roadmap', 'Needs quotations data: losing bidders share details with winner', '—']
  ];
  $('coverage').innerHTML = '<table><tr><th>Fraud / risk</th><th>Rule</th><th>How the tool spots it</th><th>Severity</th></tr>' +
    COV.map(r => `<tr><td style="white-space:normal">${esc(r[0])}</td><td><b>${r[1]}</b></td><td style="white-space:normal">${esc(r[2])}</td><td>${r[3]}</td></tr>`).join('') + '</table>';
})();
