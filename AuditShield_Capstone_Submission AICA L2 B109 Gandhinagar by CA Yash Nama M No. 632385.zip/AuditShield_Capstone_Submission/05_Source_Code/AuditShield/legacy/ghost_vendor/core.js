/* ============================================================
   GHOST VENDOR & RELATED-PARTY GRAPH  —  core logic
   Works in the browser (inlined into the HTML) and in Node (tests).
   No external libraries. All data is synthetic.
   ============================================================ */

/* ---------- 1. SHA-256 + HMAC (pure JS, synchronous) ---------- */
const GV = {};
(function () {
  const K = new Uint32Array([
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
  const W = new Uint32Array(64);

  function utf8(str) { return new TextEncoder().encode(str); }

  function sha256Bytes(msg) {           // msg: Uint8Array -> Uint8Array(32)
    const l = msg.length, bitLen = l * 8;
    const n = (((l + 9) + 63) >> 6) << 6;
    const buf = new Uint8Array(n);
    buf.set(msg); buf[l] = 0x80;
    const dv = new DataView(buf.buffer);
    dv.setUint32(n - 4, bitLen >>> 0);
    dv.setUint32(n - 8, Math.floor(bitLen / 0x100000000));
    let h0=0x6a09e667,h1=0xbb67ae85,h2=0x3c6ef372,h3=0xa54ff53a,h4=0x510e527f,h5=0x9b05688c,h6=0x1f83d9ab,h7=0x5be0cd19;
    for (let off = 0; off < n; off += 64) {
      for (let i = 0; i < 16; i++) W[i] = dv.getUint32(off + i * 4);
      for (let i = 16; i < 64; i++) {
        const w15 = W[i-15], w2 = W[i-2];
        const s0 = ((w15>>>7)|(w15<<25)) ^ ((w15>>>18)|(w15<<14)) ^ (w15>>>3);
        const s1 = ((w2>>>17)|(w2<<15)) ^ ((w2>>>19)|(w2<<13)) ^ (w2>>>10);
        W[i] = (W[i-16] + s0 + W[i-7] + s1) | 0;
      }
      let a=h0,b=h1,c=h2,d=h3,e=h4,f=h5,g=h6,h=h7;
      for (let i = 0; i < 64; i++) {
        const S1 = ((e>>>6)|(e<<26)) ^ ((e>>>11)|(e<<21)) ^ ((e>>>25)|(e<<7));
        const ch = (e & f) ^ (~e & g);
        const t1 = (h + S1 + ch + K[i] + W[i]) | 0;
        const S0 = ((a>>>2)|(a<<30)) ^ ((a>>>13)|(a<<19)) ^ ((a>>>22)|(a<<10));
        const mj = (a & b) ^ (a & c) ^ (b & c);
        const t2 = (S0 + mj) | 0;
        h=g; g=f; f=e; e=(d + t1)|0; d=c; c=b; b=a; a=(t1 + t2)|0;
      }
      h0=(h0+a)|0; h1=(h1+b)|0; h2=(h2+c)|0; h3=(h3+d)|0; h4=(h4+e)|0; h5=(h5+f)|0; h6=(h6+g)|0; h7=(h7+h)|0;
    }
    const out = new Uint8Array(32), odv = new DataView(out.buffer);
    [h0,h1,h2,h3,h4,h5,h6,h7].forEach((v, i) => odv.setUint32(i * 4, v >>> 0));
    return out;
  }
  function hex(bytes) { let s = ''; for (const b of bytes) s += b.toString(16).padStart(2, '0'); return s; }
  function sha256Hex(str) { return hex(sha256Bytes(utf8(str))); }
  function hmacHex(key, msg) {
    let k = utf8(key);
    if (k.length > 64) k = sha256Bytes(k);
    const kp = new Uint8Array(64); kp.set(k);
    const ipad = new Uint8Array(64), opad = new Uint8Array(64);
    for (let i = 0; i < 64; i++) { ipad[i] = kp[i] ^ 0x36; opad[i] = kp[i] ^ 0x5c; }
    const m = utf8(msg);
    const inner = new Uint8Array(64 + m.length); inner.set(ipad); inner.set(m, 64);
    const ih = sha256Bytes(inner);
    const outer = new Uint8Array(96); outer.set(opad); outer.set(ih, 64);
    return hex(sha256Bytes(outer));
  }
  GV.sha256Hex = sha256Hex; GV.hmacHex = hmacHex;
})();

/* ---------- 2. Normalisation ("fuzzy" cleaning before hashing) ----------
   Hashes only match if the input is identical, so we clean values first:
   "Flat No. 12, M.G. Rd., Pune" and "flat 12 MG Road pune" become the same. */
GV.ABBREV = { rd:'road', st:'street', ngr:'nagar', apt:'apartment', apts:'apartment', bldg:'building',
  soc:'society', opp:'opposite', nr:'near', mkt:'market', chs:'society', marg:'road', lane:'lane', ln:'lane', pk:'park', indl:'industrial', ind:'industrial', est:'estate', co:'company', pvt:'private', ltd:'limited' };
GV.STOP = new Set(['no','number','flat','house','plot','shop','the','of','at','post','dist','district','taluka','near']);

GV.normalize = function (field, value) {
  if (value === undefined || value === null) return '';
  let v = String(value).trim();
  if (!v) return '';
  switch (field) {
    case 'bank_account': return v.replace(/\D/g, '').replace(/^0+/, '');
    case 'phone': { const d = v.replace(/\D/g, ''); return d.length >= 10 ? d.slice(-10) : d; }
    case 'pan': return v.toUpperCase().replace(/[^A-Z0-9]/g, '');
    case 'gstin': return v.toUpperCase().replace(/[^A-Z0-9]/g, '');
    case 'address': {
      v = v.toLowerCase().replace(/\./g, '').replace(/[^a-z0-9]+/g, ' ');
      const words = v.split(' ').filter(Boolean).map(w => GV.ABBREV[w] || w).filter(w => !GV.STOP.has(w));
      return words.join(' ');
    }
    default: return v.toLowerCase().replace(/\s+/g, ' ');
  }
};

/* Which columns are sensitive (hashed) per table */
GV.SENSITIVE = {
  employees: ['name', 'bank_account', 'pan', 'phone', 'address'],
  vendors:   ['gstin', 'bank_account', 'pan', 'phone', 'address'],
  directors: ['bank_account', 'pan', 'phone', 'address'],
  payments:  []
};
GV.MATCH_FIELDS = ['bank_account', 'pan', 'gstin', 'phone', 'address'];

/* ---------- 3. CLIENT SIDE: protect data with a secret key ---------- */
GV.protect = function (data, key) {
  if (!key || key.length < 8) throw new Error('Secret key must be at least 8 characters');
  const out = {};
  for (const table of Object.keys(GV.SENSITIVE)) {
    out[table] = (data[table] || []).map(row => {
      const r = { ...row };
      // A GSTIN contains the PAN (characters 3-12). Derive the PAN if missing, so a
      // proprietor's GSTIN can still be matched with an employee's PAN.
      if (table === 'vendors' && !r.pan && r.gstin && r.gstin.length >= 12) r.pan = r.gstin.slice(2, 12);
      for (const f of GV.SENSITIVE[table]) {
        if (!(f in r)) continue;
        const n = GV.normalize(f, r[f]);
        // field name is mixed into the hash so a PAN can never collide with a phone
        r[f] = n ? 'H:' + GV.hmacHex(key, f + '|' + n).slice(0, 16) : '';
      }
      return r;
    });
  }
  return out;
};

/* ---------- 4. AUDITOR SIDE: analyse protected data only ---------- */
GV.FIELD_LABEL = { bank_account: 'bank account', pan: 'PAN', gstin: 'GSTIN', phone: 'phone number', address: 'address' };
GV.fmtINR = function (n) {
  n = Math.round(Number(n) || 0);
  const s = String(Math.abs(n)); let last3 = s.slice(-3), rest = s.slice(0, -3);
  if (rest) last3 = ',' + last3;
  rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
  return (n < 0 ? '-' : '') + '₹' + rest + last3;
};

GV.analyze = function (p, opts) {
  opts = Object.assign({ approvalLimit: 100000, nearLimitPct: 0.9, splitWindowDays: 3 }, opts || {});
  const flags = [];
  const emps = p.employees || [], vens = p.vendors || [], dirs = p.directors || [], pays = p.payments || [];
  const entities = [];
  emps.forEach(e => entities.push({ kind: 'employee', id: e.emp_id, label: e.emp_id + (e.department ? ' (' + e.department + ')' : ''), row: e }));
  vens.forEach(v => entities.push({ kind: 'vendor', id: v.vendor_id, label: v.vendor_name || v.vendor_id, row: v }));
  dirs.forEach(d => entities.push({ kind: 'director', id: d.din, label: (d.director_name || d.din), row: d }));
  const byId = {}; entities.forEach(e => byId[e.kind + ':' + e.id] = e);

  // payments per vendor
  const paid = {}; const payList = {};
  pays.forEach(x => {
    const a = Number(x.amount) || 0;
    paid[x.vendor_id] = (paid[x.vendor_id] || 0) + a;
    (payList[x.vendor_id] = payList[x.vendor_id] || []).push(x);
  });

  // --- index of hashed attribute -> entities that have it
  const index = {};
  entities.forEach(en => {
    GV.MATCH_FIELDS.forEach(f => {
      const h = en.row[f];
      if (!h) return;
      const k = f + '#' + h;
      (index[k] = index[k] || []).push(en);
    });
  });

  const graphNodes = {}, graphEdges = [];
  const addNode = (en) => { graphNodes[en.kind + ':' + en.id] = { id: en.kind + ':' + en.id, kind: en.kind, label: en.label, risk: 0 }; };
  let fid = 0;
  const flag = (o) => { o.id = 'F' + (++fid); flags.push(o); return o; };

  // --- Rules on shared attributes
  for (const k of Object.keys(index)) {
    const group = index[k];
    if (group.length < 2) continue;
    const field = k.split('#')[0];
    const label = GV.FIELD_LABEL[field];
    const attrId = 'attr:' + k;
    graphNodes[attrId] = { id: attrId, kind: 'attr', label: 'same ' + label, risk: 0, field };
    group.forEach(en => { addNode(en); graphEdges.push({ a: en.kind + ':' + en.id, b: attrId, field }); });

  }

  // --- combine all shared attributes per pair of entities (one flag per pair)
  const pairs = {};
  for (const k of Object.keys(index)) {
    const group = index[k]; if (group.length < 2) continue;
    const field = k.split('#')[0];
    for (let i = 0; i < group.length; i++) for (let j = i + 1; j < group.length; j++) {
      let a = group[i], b = group[j];
      const order = { vendor: 0, employee: 1, director: 2 };
      if (order[a.kind] > order[b.kind]) [a, b] = [b, a];
      const key = a.kind + ':' + a.id + '|' + b.kind + ':' + b.id;
      (pairs[key] = pairs[key] || { a, b, fields: [] }).fields.push(field);
    }
  }
  const fieldText = fs => { const l = fs.map(f => GV.FIELD_LABEL[f]); return l.length > 1 ? l.slice(0, -1).join(', ') + ' and ' + l[l.length - 1] : l[0]; };
  Object.values(pairs).forEach(({ a, b, fields }) => {
    const strong = fields.includes('bank_account') || fields.includes('pan') || fields.includes('gstin');
    const ft = fieldText(fields);
    const ents = [a.kind + ':' + a.id, b.kind + ':' + b.id];
    const amt = a.kind === 'vendor' ? (paid[a.id] || 0) + (b.kind === 'vendor' ? (paid[b.id] || 0) : 0) : 0;
    if (a.kind === 'vendor' && b.kind === 'employee') {
      flag({
        rule: strong ? 'R1 Employee-as-Vendor / Ghost Vendor' : 'R3 Possible Conflict of Interest',
        severity: strong ? 'Critical' : 'High',
        fraud: strong ? 'Ghost vendor / fictitious vendor' : 'Undisclosed conflict of interest (kickback risk)',
        title: `Vendor ${a.label} ↔ employee ${b.label}: same ${ft}`,
        explain: `The vendor and the employee have the same ${ft}. This was matched through protected hashes, so the auditor never saw the actual values. ` +
          (strong ? 'Money paid to this vendor may be reaching the employee. This is the classic ghost-vendor pattern.'
                  : 'This may be a relative or a business run by the employee. Ask for a conflict-of-interest declaration.') +
          ` Total paid to vendor: ${GV.fmtINR(paid[a.id] || 0)}.`,
        entities: ents, amount: paid[a.id] || 0, fields });
    } else if (a.kind === 'vendor' && b.kind === 'director') {
      flag({
        rule: 'R2 Undisclosed Related Party', severity: strong ? 'Critical' : 'High',
        fraud: 'Related-party transaction not disclosed (AS 18 / Ind AS 24, Sec 188)',
        title: `Vendor ${a.label} ↔ director ${b.label}: same ${ft}`,
        explain: `A vendor and a director share the same ${ft}. If the vendor is a director's relative or firm, the transactions ` +
          `may need board/shareholder approval and must be disclosed as related-party transactions. Total paid: ${GV.fmtINR(paid[a.id] || 0)}. ` +
          'Compare with the related-party list given by management. If this vendor is missing from it, that is a red flag.',
        entities: ents, amount: paid[a.id] || 0, fields });
    } else if (a.kind === 'vendor' && b.kind === 'vendor') {
      flag({
        rule: 'R4 Duplicate / Shell Vendors', severity: strong ? 'High' : 'Medium',
        fraud: 'Duplicate vendor master entries / shell companies',
        title: `Vendors ${a.label} and ${b.label}: same ${ft}`,
        explain: `Two vendor names but the same ${ft}. Either the vendor master has duplicates (risk of double payment) ` +
          `or one person is running several shell vendors to stay below limits. Combined payments: ${GV.fmtINR(amt)}.`,
        entities: ents, amount: amt, fields });
    } else if (a.kind === 'employee' && b.kind === 'employee' && fields.includes('bank_account')) {
      flag({
        rule: 'R5 Ghost Employee (Payroll)', severity: 'High', fraud: 'Ghost employee / payroll fraud',
        title: `Employees ${a.label} and ${b.label}: salary to the same bank account`,
        explain: 'Two employee records pointing to one bank account is a common sign of a fake (ghost) employee on payroll. ' +
          'Verify physical existence, attendance and joining documents.',
        entities: ents, amount: 0, fields });
    }
  });

  // --- Payment rules
  const lim = opts.approvalLimit;
  const vendName = id => (byId['vendor:' + id] || {}).label || id;
  // R6 duplicate payments
  const seen = {};
  pays.forEach(x => {
    const k1 = x.vendor_id + '|' + String(x.invoice_no || '').trim().toUpperCase();
    if (x.invoice_no && seen[k1]) {
      const prev = seen[k1];
      flag({ rule: 'R6 Duplicate Payment', severity: 'High', fraud: 'Duplicate invoice / double payment',
        title: `Invoice ${x.invoice_no} of ${vendName(x.vendor_id)} paid twice (${prev.payment_id} and ${x.payment_id})`,
        explain: `Same vendor and same invoice number paid on ${prev.date} and again on ${x.date}. ` +
          `Amount at risk: ${GV.fmtINR(x.amount)}. Check whether the second payment was recovered or adjusted.`,
        entities: ['vendor:' + x.vendor_id], amount: Number(x.amount), payments: [prev.payment_id, x.payment_id] });
    } else seen[k1] = x;
  });
  // R7 split payments & R8 just-below-limit
  Object.keys(payList).forEach(vid => {
    const list = payList[vid].slice().sort((a, b) => a.date.localeCompare(b.date));
    const day = d => Math.floor(new Date(d + 'T00:00:00Z').getTime() / 86400000);
    const used = new Set();
    for (let i = 0; i < list.length; i++) {
      if (used.has(i) || Number(list[i].amount) >= lim) continue;
      const grp = [i];
      for (let j = i + 1; j < list.length; j++) {
        if (day(list[j].date) - day(list[i].date) > opts.splitWindowDays) break;
        if (Number(list[j].amount) < lim) grp.push(j);
      }
      const total = grp.reduce((s, g) => s + Number(list[g].amount), 0);
      if (grp.length >= 2 && total >= lim) {
        grp.forEach(g => used.add(g));
        flag({ rule: 'R7 Split Payment', severity: 'High', fraud: 'Invoice splitting to avoid approval limit',
          title: `${grp.length} payments to ${vendName(vid)} within ${opts.splitWindowDays} days total ${GV.fmtINR(total)} (limit ${GV.fmtINR(lim)})`,
          explain: `Each payment is below the ${GV.fmtINR(lim)} approval limit, but together they exceed it. ` +
            `Payments: ${grp.map(g => list[g].payment_id + ' ' + GV.fmtINR(list[g].amount) + ' on ' + list[g].date).join('; ')}. ` +
            'This pattern is used to avoid senior approval.',
          entities: ['vendor:' + vid], amount: total, payments: grp.map(g => list[g].payment_id) });
      }
    }
    const near = list.filter(x => Number(x.amount) >= lim * opts.nearLimitPct && Number(x.amount) < lim);
    if (near.length >= 2) {
      const t = near.reduce((s, x) => s + Number(x.amount), 0);
      flag({ rule: 'R8 Just-Below-Limit Pattern', severity: 'Medium', fraud: 'Approval-limit manipulation',
        title: `${near.length} payments to ${vendName(vid)} are just below the approval limit`,
        explain: `Amounts between ${GV.fmtINR(lim * opts.nearLimitPct)} and ${GV.fmtINR(lim - 1)}: ` +
          near.map(x => GV.fmtINR(x.amount)).join(', ') + '. Repeated near-limit amounts are unlikely by chance.',
        entities: ['vendor:' + vid], amount: t, payments: near.map(x => x.payment_id) });
    }
  });
  // R9 Segregation of duties: same person created vendor and approved its payments
  vens.forEach(v => {
    if (!v.created_by) return;
    const own = (payList[v.vendor_id] || []).filter(x => x.approved_by && x.approved_by === v.created_by);
    if (own.length) {
      const t = own.reduce((s, x) => s + Number(x.amount), 0);
      flag({ rule: 'R9 Segregation-of-Duties Breach', severity: 'High', fraud: 'Same person creates vendor and approves payment',
        title: `${v.created_by} created vendor ${v.vendor_name} AND approved ${own.length} of its payments`,
        explain: `One person controlling both vendor creation and payment approval can create a fake vendor and pay it. ` +
          `Approved by creator: ${GV.fmtINR(t)}.`,
        entities: ['vendor:' + v.vendor_id, 'employee:' + v.created_by], amount: t });
      const en = byId['employee:' + v.created_by];
      if (en) { addNode(en); addNode(byId['vendor:' + v.vendor_id]);
        graphEdges.push({ a: 'employee:' + v.created_by, b: 'vendor:' + v.vendor_id, field: 'created+approved' }); }
    }
  });
  // R10 Round-amount payments on weekends
  pays.forEach(x => {
    const d = new Date(x.date + 'T00:00:00Z').getUTCDay();
    const a = Number(x.amount);
    if ((d === 0 || d === 6) && a >= 10000 && a % 10000 === 0) {
      flag({ rule: 'R10 Weekend Round-Amount Payment', severity: 'Low', fraud: 'Unusual timing / management override indicator',
        title: `${x.payment_id}: ${GV.fmtINR(a)} to ${vendName(x.vendor_id)} on a ${d === 0 ? 'Sunday' : 'Saturday'}`,
        explain: 'Round amounts paid on non-working days are a standard SA 240 journal-entry testing filter. Verify supporting documents.',
        entities: ['vendor:' + x.vendor_id], amount: a, payments: [x.payment_id] });
    }
  });

  // --- risk score per vendor (simple weighted sum, 0-100)
  const W = { Critical: 40, High: 25, Medium: 12, Low: 5 };
  const vendorRisk = {};
  flags.forEach(f => f.entities.forEach(e => {
    if (e.startsWith('vendor:')) vendorRisk[e] = Math.min(100, (vendorRisk[e] || 0) + W[f.severity]);
  }));
  Object.keys(vendorRisk).forEach(k => { if (graphNodes[k]) graphNodes[k].risk = vendorRisk[k]; });
  flags.forEach(f => f.entities.forEach(e => { if (graphNodes[e]) graphNodes[e].flagged = true; }));

  const sevOrder = { Critical: 0, High: 1, Medium: 2, Low: 3 };
  flags.sort((a, b) => sevOrder[a.severity] - sevOrder[b.severity] || b.amount - a.amount);

  const atRisk = {}; // amount at risk = total paid to vendors with Critical/High flags (no double counting)
  flags.filter(f => f.severity === 'Critical' || f.severity === 'High')
       .forEach(f => f.entities.filter(e => e.startsWith('vendor:')).forEach(e => atRisk[e] = paid[e.slice(7)] || 0));
  return {
    flags, vendorRisk,
    graph: { nodes: Object.values(graphNodes), edges: graphEdges },
    summary: {
      employees: emps.length, vendors: vens.length, directors: dirs.length, payments: pays.length,
      totalPaid: pays.reduce((s, x) => s + Number(x.amount || 0), 0),
      flags: flags.length,
      critical: flags.filter(f => f.severity === 'Critical').length,
      high: flags.filter(f => f.severity === 'High').length,
      amountAtRisk: Object.values(atRisk).reduce((s, a) => s + a, 0),
      riskyVendors: Object.keys(atRisk).length
    }
  };
};

/* ---------- 5. Synthetic sample data (fictional company, planted frauds) ---------- */
GV.sampleData = function () {
  let seed = 42; const rnd = () => (seed = (seed * 1103515245 + 12345) % 2147483648) / 2147483648;
  const employees = [
    ['E101','Anita Deshpande','Finance','50100234567812','ABDPD4521K','9822011101','Flat 4, Shanti Apartments, Karve Road, Pune'],
    ['E102','Vikram Joshi','Purchase','50100234567813','AHJPJ7734M','9822011102','12 Model Colony, Pune'],
    ['E103','Sneha Kulkarni','Purchase','30987654321001','BCKPK1209Q','9822011103','B-7 Sahakar Nagar, Pune'],
    ['E104','Rahul Patil','Stores','30987654321002','CQPPP6612L','9822011104','22 Kothrud Depot Road, Pune'],
    ['E105','Meera Iyer','HR','50100234567815','AMIPI3398R','9822011105','5 Aundh Road, Pune'],
    ['E106','Sanjay Gupta','Admin','30987654321004','BKGPG8821C','9822011106','Plot 9, Baner, Pune'],
    ['E107','Rohit Shinde','Accounts Payable','60112233445566','DRSPS5532H','9822011107','Flat No. 12, Ganesh Society, M.G. Rd., Pune'],
    ['E108','Kavita Rao','Sales','50100234567818','ARKPR4410D','9822011108','18 Viman Nagar, Pune'],
    ['E109','Amit Verma','Production','71234500998877','AQVPV2208E','9822011109','3 Hadapsar Industrial Estate, Pune'],
    ['E110','Ajay Verma','Production','71234500998877','BQVPV9921F','9822011110','3 Hadapsar Indl. Estate, Pune']
  ].map(r => ({ emp_id: r[0], name: r[1], department: r[2], bank_account: r[3], pan: r[4], phone: r[5], address: r[6] }));

  const directors = [
    ['DIN01234567','Mr. Prakash Mehta','80001122334455','AAMPM1111A','9890012345','Bungalow 1, Koregaon Park, Pune'],
    ['DIN07654321','Mrs. Sunita Mehta','80001122334466','AAMPM2222B','9890054321','Bungalow 1, Koregaon Park, Pune'],
    ['DIN05556667','Mr. Nikhil Bhosale','80001122334477','ABBPB3333C','9890077788','7 Law College Road, Pune']
  ].map(r => ({ din: r[0], director_name: r[1], bank_account: r[2], pan: r[3], phone: r[4], address: r[5] }));

  const vendors = [
    ['V101','Deccan Steel Pvt Ltd','27AABCD1234E1Z8','11122233344401','AABCD1234E','2026000001','MIDC Bhosari, Pune','E102'],
    ['V102','Sahyadri Packaging','27AAFFS5678K1Z2','11122233344402','AAFFS5678K','2026000002','Chakan Industrial Area, Pune','E103'],
    ['V103','Western Logistics','27AACCW9012L1Z9','11122233344403','AACCW9012L','2026000003','Wagholi, Pune','E102'],
    ['V104','PowerTech Electricals','27AADCP3456M1Z1','11122233344404','AADCP3456M','2026000004','Pimpri, Pune','E103'],
    ['V105','Sai Traders','','60112233445566','DRSPS5532H','9822011107','Flat 12 Ganesh Society MG Road Pune','E107'],
    ['V106','Pune Office Supplies','27AAGFP7890N1Z4','11122233344406','AAGFP7890N','2026000006','Shivajinagar, Pune','E106'],
    ['V107','Krishna Canteen Services','27AAHFK2345P1Z8','11122233344407','AAHFK2345P','2026000007','Hinjewadi, Pune','E105'],
    ['V108','Om Enterprises','27AAIFO6789Q1Z3','90909090909090','AAIFO6789Q','9890054321','Bungalow No. 1, Koregaon Pk., Pune','E102'],
    ['V109','Quick Fix Maintenance','27AAJFQ1122R1Z6','11122233344409','AAJFQ1122R','2026000009','Kondhwa, Pune','E103'],
    ['V110','Shri Sai Trading Co','','60112233445599','DRSPS5532H','2026000010','Katraj, Pune','E107'],
    ['V111','Kumar Hardware & Tools','27AAKFK3344S1Z0','11122233344411','AAKFK3344S','+91 98220 11104','Bhosari, Pune','E103'],
    ['V112','GreenLeaf Housekeeping','27AALFG5566T1Z7','11122233344412','AALFG5566T','2026000012','Wakad, Pune','E105']
  ].map(r => ({ vendor_id: r[0], vendor_name: r[1], gstin: r[2], bank_account: r[3], pan: r[4], phone: r[5], address: r[6], created_by: r[7] }));

  const approvers = ['E101', 'E101', 'E108'];
  const payments = []; let pid = 1;
  const P = (vendor_id, invoice_no, date, amount, approved_by) =>
    payments.push({ payment_id: 'P' + String(pid++).padStart(4, '0'), vendor_id, invoice_no, date, amount, approved_by });
  // normal payments (Apr 2025 - Mar 2026), avoid weekends for normal activity
  const legit = ['V101','V102','V103','V104','V106','V107','V109','V111','V112','V108'];
  for (let i = 0; i < 70; i++) {
    const v = legit[Math.floor(rnd() * legit.length)];
    let dt = new Date(Date.UTC(2025, 3, 1) + Math.floor(rnd() * 360) * 86400000);
    while (dt.getUTCDay() === 0 || dt.getUTCDay() === 6) dt = new Date(dt.getTime() + 86400000);
    let amt = Math.round((5000 + rnd() * 240000) / 10) * 10 + 7;
    if (amt >= 90000 && amt < 100000) amt += 15000; // keep near-limit pattern only in planted cases
    P(v, 'INV-' + v.slice(1) + '-' + (100 + i), dt.toISOString().slice(0, 10), amt, approvers[Math.floor(rnd() * 3)].replace('E108','E101'));
  }
  // PLANTED 1: ghost vendor Sai Traders, created and approved by E107, just below limit
  [['2025-06-12', 98500], ['2025-07-18', 99200], ['2025-09-03', 97800], ['2025-11-21', 99750], ['2026-01-14', 98900], ['2026-02-27', 99400]]
    .forEach((x, i) => P('V105', 'ST/' + (21 + i), x[0], x[1], 'E107'));
  // PLANTED 2: shell vendor sharing PAN with Sai Traders
  P('V110', 'SSTC-7', '2025-08-08', 64000, 'E107'); P('V110', 'SSTC-9', '2025-12-10', 71500, 'E101');
  // PLANTED 3: related party (director's address & phone) - large payments
  P('V108', 'OM-501', '2025-05-15', 345000, 'E102'); P('V108', 'OM-517', '2025-10-06', 412000, 'E102');
  // PLANTED 4: split payment to Quick Fix on consecutive days
  P('V109', 'QF-881', '2025-08-19', 60000, 'E101'); P('V109', 'QF-882', '2025-08-19', 55000, 'E101'); P('V109', 'QF-883', '2025-08-20', 48000, 'E101');
  // PLANTED 5: duplicate payment of same invoice
  P('V102', 'SP-2207', '2025-09-10', 132450, 'E101'); P('V102', 'SP-2207', '2025-10-02', 132450, 'E101');
  // PLANTED 6: weekend round amount
  P('V106', 'POS-55', '2025-12-28', 150000, 'E101');
  return { employees, vendors, directors, payments };
};

/* ---------- 6. CSV helpers ---------- */
GV.parseCSV = function (text) {
  const rows = []; let row = [], cur = '', q = false;
  text = text.replace(/^\uFEFF/, '');
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; } else cur += c; }
    else if (c === '"') q = true;
    else if (c === ',') { row.push(cur); cur = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cur); rows.push(row); row = []; cur = ''; }
    else cur += c;
  }
  if (cur.length || row.length) { row.push(cur); rows.push(row); }
  const clean = rows.filter(r => r.some(x => x.trim() !== ''));
  if (!clean.length) return [];
  const head = clean[0].map(h => h.trim().toLowerCase().replace(/\s+/g, '_'));
  return clean.slice(1).map(r => { const o = {}; head.forEach((h, i) => o[h] = (r[i] || '').trim()); return o; });
};
GV.toCSV = function (rows) {
  if (!rows.length) return '';
  const cols = Object.keys(rows[0]);
  const esc = v => { v = v === undefined || v === null ? '' : String(v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
  return [cols.join(',')].concat(rows.map(r => cols.map(c => esc(r[c])).join(','))).join('\n');
};

if (typeof module !== 'undefined') module.exports = GV;
