/* CA-Safe AI Gateway UI */
(function () {
  const $ = id => document.getElementById(id);
  const esc = s => String(s === undefined || s === null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  let vault = new AG.Vault(), last = null; const LOG = [];

  document.querySelectorAll('nav button').forEach(b => b.onclick = () => {
    document.querySelectorAll('nav button').forEach(x => x.classList.toggle('active', x === b));
    document.querySelectorAll('.tab').forEach(s => s.classList.toggle('active', s.id === b.dataset.tab));
    if (b.dataset.tab === 't2') renderVault();
  });

  // samples
  $('samples').innerHTML = Object.keys(AG.SAMPLES).map((k, i) => `<button class="btn grey small" data-s="${esc(k)}">${esc(k)}</button>`).join(' ');
  document.querySelectorAll('[data-s]').forEach(b => b.onclick = () => { $('input').value = AG.SAMPLES[b.dataset.s]; reset(); });
  $('input').value = AG.SAMPLES['Vendor ledger review'];
  $('input').oninput = reset;
  function reset() { $('sendBtn').disabled = true; last = null; }
  const provider = () => document.querySelector('input[name=prov]:checked').value;
  function updMode() { $('mode').textContent = provider() === 'mock' ? 'AI: offline demo (change in tab ④)' : 'AI: ' + $('apiModel').value; }
  document.querySelectorAll('input[name=prov]').forEach(r => r.onchange = updMode); updMode();

  const opts = () => ({ watchlist: $('watch').value.split(',').filter(Boolean) });

  // scan
  $('scanBtn').onclick = () => {
    const text = $('input').value;
    const r = AG.mask(text, vault, opts());
    last = { text, ...r };
    // highlighted original
    let h = '', p = 0;
    r.spans.forEach(s => {
      const T = AG.TYPES[s.type];
      h += esc(text.slice(p, s.inStart)) + `<span class="hit" style="background:${T.color}" title="${T.label} → ${s.token}">${esc(text.slice(s.inStart, s.inEnd))}</span>`;
      p = s.inEnd;
    });
    $('highlighted').innerHTML = h + esc(text.slice(p));
    // masked with coloured tokens
    let m = '', q = 0;
    r.spans.forEach(s => {
      const T = AG.TYPES[s.type];
      m += esc(r.masked.slice(q, s.outStart)) + `<span class="tok" style="color:${T.color};border-color:${T.color};background:${T.color}14">${esc(s.token)}</span>`;
      q = s.outEnd;
    });
    $('masked').innerHTML = m + esc(r.masked.slice(q));
    // chips
    const counts = {}; r.spans.forEach(s => counts[s.type] = (counts[s.type] || 0) + 1);
    $('chips').innerHTML = Object.entries(counts).map(([t, c]) => `<span style="background:${AG.TYPES[t].color}">${AG.TYPES[t].label}: ${c}</span>`).join('') ||
      '<span style="background:#16a34a">No identifiers found</span>';
    // leak check
    const lc = AG.leakCheck(r.masked, vault, opts());
    last.leak = lc;
    $('leak').innerHTML = (lc.leaks.length || lc.redetect.length)
      ? `<div class="warn">⚠ Possible leak: ${lc.leaks.length + lc.redetect.length} item(s) still visible. Add them to the watch-list before sending.</div>`
      : `<div class="ok">✅ Leak test passed: re-scanned the outgoing text and searched for all ${Object.keys(vault.rev).length} vault values → <b>0 found</b>.
         Amounts, dates and wording are kept so the AI can still do the analysis.</div>`;
    $('sendBtn').disabled = false;
    $('final').innerHTML = '<span style="color:#94a3b8">Now click "Send masked text to AI".</span>'; $('aiRaw').textContent = '';
    const crit = r.spans.filter(s => AG.TYPES[s.type].risk === 'Critical').length;
    $('impact').style.display = 'block';
    $('impact').innerHTML = `<div class="row" style="gap:40px">
      <div><div class="big" style="color:#dc2626">${r.spans.length}</div>identifiers would have gone to an external AI server without the gateway</div>
      <div><div class="big" style="color:#dc2626">${crit}</div>of them critical (Aadhaar, bank account, card)</div>
      <div><div class="big" style="color:#16a34a">0</div>identifiers sent with the gateway</div>
      <div><div class="big">${new Set(r.spans.map(s => s.token)).size}</div>unique pseudonyms (same person = same code)</div></div>`;
  };

  // send
  $('sendBtn').onclick = async () => {
    if (!last) return;
    if (last.leak && (last.leak.leaks.length || last.leak.redetect.length) && !confirm('Leak warning: send anyway?')) return;
    $('sendBtn').disabled = true; $('final').textContent = '⏳ Waiting for AI…';
    const sys = 'You are an assistant for a Chartered Accountant firm. Identifiers are replaced with codes like [PERSON_1], [ORG_2], [PAN_1]. ' +
      'Keep these codes exactly as written in your answer; never guess the real values.';
    let reply;
    try {
      if (provider() === 'mock') { await new Promise(r => setTimeout(r, 900)); reply = AG.mockAI(last.masked); }
      else {
        const res = await fetch($('apiUrl').value, { method: 'POST',
          headers: Object.assign({ 'Content-Type': 'application/json' }, $('apiKey').value ? { Authorization: 'Bearer ' + $('apiKey').value } : {}),
          body: JSON.stringify({ model: $('apiModel').value, messages: [{ role: 'system', content: sys }, { role: 'user', content: last.masked }], temperature: 0.2 }) });
        const j = await res.json();
        if (!res.ok) throw new Error((j.error && j.error.message) || res.statusText);
        reply = j.choices[0].message.content;
      }
    } catch (e) { $('final').innerHTML = `<span style="color:#dc2626">AI call failed: ${esc(e.message)}. Switch to Offline demo AI in tab ④.</span>`; $('sendBtn').disabled = false; return; }
    $('aiRaw').textContent = reply;
    // restore + highlight
    const html = esc(reply).replace(/\[?\b(AADHAAR|CARD|GSTIN|PAN|BANK_AC|IFSC|UPI|EMAIL|PHONE|ORG|PERSON|CUSTOM)_(\d+)\b\]?/g, (m, t, n) => {
      const tok = '[' + t + '_' + n + ']'; const v = vault.rev[tok];
      return v !== undefined ? `<span class="restored" title="${tok}">${esc(v)}</span>` : m;
    });
    $('final').innerHTML = html;
    const counts = {}; last.spans.forEach(s => counts[s.type] = (counts[s.type] || 0) + 1);
    LOG.unshift({ time: new Date().toLocaleString(), provider: provider() === 'mock' ? 'offline-demo' : $('apiModel').value,
      chars_sent: last.masked.length, identifiers_masked: last.spans.length,
      types: Object.entries(counts).map(([t, c]) => t + ':' + c).join(' '),
      leak_test: (last.leak.leaks.length + last.leak.redetect.length) ? 'WARN' : 'PASS',
      preview: last.masked.slice(0, 90).replace(/\n/g, ' ') + '…' });
    $('sendBtn').disabled = false;
  };

  // vault + log
  function renderVault() {
    const rows = Object.entries(vault.rev);
    const show = $('reveal').checked;
    const maskV = v => v.length <= 4 ? '••••' : '•'.repeat(Math.min(10, v.length - 4)) + v.slice(-4);
    $('vault').innerHTML = rows.length ? '<table><tr><th>Code sent to AI</th><th>Type</th><th>Real value (local only)</th></tr>' +
      rows.map(([t, v]) => { const ty = t.slice(1, t.lastIndexOf('_')); return `<tr><td><b>${esc(t)}</b></td><td>${AG.TYPES[ty] ? AG.TYPES[ty].label : ty}</td><td class="mono">${esc(show ? v : maskV(v))}</td></tr>`; }).join('') + '</table>'
      : '<i>Vault is empty.</i>';
    $('log').innerHTML = LOG.length ? '<table><tr><th>Time</th><th>AI</th><th>Identifiers masked</th><th>Types</th><th>Leak test</th><th>What was sent (preview)</th></tr>' +
      LOG.map(l => `<tr><td>${esc(l.time)}</td><td>${esc(l.provider)}</td><td>${l.identifiers_masked}</td><td>${esc(l.types)}</td><td>${l.leak_test}</td><td class="mono" style="font-size:11px">${esc(l.preview)}</td></tr>`).join('') + '</table>'
      : '<i>No requests sent yet.</i>';
  }
  $('reveal').onchange = renderVault;
  $('clearVault').onclick = () => { if (confirm('Clear all pseudonyms?')) { vault = new AG.Vault(); renderVault(); reset(); } };
  $('dlLog').onclick = () => {
    if (!LOG.length) return alert('Log is empty');
    const cols = Object.keys(LOG[0]);
    const csv = [cols.join(',')].concat(LOG.map(l => cols.map(c => '"' + String(l[c]).replace(/"/g, '""') + '"').join(','))).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' })); a.download = 'ai_gateway_audit_log.csv'; a.click();
  };

  // evaluation
  $('evalBtn').onclick = () => {
    const e = AG.evaluate();
    let h = `<div class="row" style="gap:40px"><div><div class="big">${(e.recall * 100).toFixed(0)}%</div>Recall (caught)</div>
      <div><div class="big">${(e.precision * 100).toFixed(0)}%</div>Precision (correct flags)</div>
      <div><div class="big">${e.tp}/${e.tp + e.fn}</div>identifiers caught</div><div><div class="big">${e.fp}</div>false alarms</div></div>`;
    h += '<table style="margin-top:10px"><tr><th>Test sentence</th><th>Caught</th><th>Missed (leak!)</th><th>False alarm</th></tr>' +
      e.rows.map(r => `<tr><td>${esc(r.text)}</td><td style="color:#16a34a">${esc(r.hit.join(', '))}</td><td style="color:#dc2626">${esc(r.miss.join(', '))}</td><td style="color:#d97706">${esc(r.extra.join(', '))}</td></tr>`).join('') + '</table>';
    h += '<div class="note">Honest limit: names written without a title or keyword, in lowercase, or in regional scripts can be missed. ' +
      'The client watch-list and an NER model (roadmap) close this gap.</div>';
    $('evalOut').innerHTML = h;
  };
})();
