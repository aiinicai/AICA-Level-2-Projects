/* ============================================================
   CONFIDENTIAL AI GATEWAY for CA firms  —  core logic
   Detect Indian identifiers -> replace with consistent pseudonyms ->
   send only masked text to AI -> restore real values locally.
   Works in browser and Node. No external libraries.
   ============================================================ */
const AG = {};

/* ---------- checksum validators (reduce false positives) ---------- */
AG.verhoeff = (function () {
  const d = [[0,1,2,3,4,5,6,7,8,9],[1,2,3,4,0,6,7,8,9,5],[2,3,4,0,1,7,8,9,5,6],[3,4,0,1,2,8,9,5,6,7],[4,0,1,2,3,9,5,6,7,8],
             [5,9,8,7,6,0,4,3,2,1],[6,5,9,8,7,1,0,4,3,2],[7,6,5,9,8,2,1,0,4,3],[8,7,6,5,9,3,2,1,0,4],[9,8,7,6,5,4,3,2,1,0]];
  const p = [[0,1,2,3,4,5,6,7,8,9],[1,5,7,6,2,8,3,0,9,4],[5,8,0,3,7,9,6,1,4,2],[8,9,1,6,0,4,3,5,2,7],[9,4,5,3,1,2,6,8,7,0],
             [4,2,8,6,5,7,3,9,0,1],[2,7,9,3,8,0,6,4,1,5],[7,0,4,6,9,1,3,2,5,8]];
  const inv = [0,4,3,2,1,5,6,7,8,9];
  return {
    valid(num) { let c = 0; const a = String(num).split('').reverse().map(Number); for (let i = 0; i < a.length; i++) c = d[c][p[i % 8][a[i]]]; return c === 0; },
    digit(num) { let c = 0; const a = String(num).split('').reverse().map(Number); for (let i = 0; i < a.length; i++) c = d[c][p[(i + 1) % 8][a[i]]]; return inv[c]; }
  };
})();
AG.gstinCheck = function (g14) {
  const cs = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'; let sum = 0;
  for (let i = 0; i < 14; i++) { const v = cs.indexOf(g14[i]); const prod = v * (i % 2 === 0 ? 1 : 2); sum += Math.floor(prod / 36) + (prod % 36); }
  return cs[(36 - (sum % 36)) % 36];
};
AG.gstinValid = g => g.length === 15 && AG.gstinCheck(g.slice(0, 14)) === g[14];
AG.luhn = function (num) {
  const s = num.replace(/\D/g, ''); let sum = 0, alt = false;
  for (let i = s.length - 1; i >= 0; i--) { let n = +s[i]; if (alt) { n *= 2; if (n > 9) n -= 9; } sum += n; alt = !alt; }
  return s.length >= 13 && sum % 10 === 0;
};

/* ---------- detectors ---------- */
// priority: higher wins when two detections overlap
AG.TYPES = {
  AADHAAR: { label: 'Aadhaar number', risk: 'Critical', color: '#dc2626', pr: 9 },
  CARD:    { label: 'Card number', risk: 'Critical', color: '#b91c1c', pr: 9 },
  GSTIN:   { label: 'GSTIN', risk: 'High', color: '#ea580c', pr: 8 },
  PAN:     { label: 'PAN', risk: 'High', color: '#d97706', pr: 7 },
  BANK_AC: { label: 'Bank account no.', risk: 'Critical', color: '#be123c', pr: 6 },
  IFSC:    { label: 'IFSC', risk: 'Medium', color: '#0891b2', pr: 6 },
  UPI:     { label: 'UPI ID', risk: 'High', color: '#9333ea', pr: 6 },
  EMAIL:   { label: 'Email', risk: 'Medium', color: '#2563eb', pr: 5 },
  PHONE:   { label: 'Phone', risk: 'Medium', color: '#0d9488', pr: 5 },
  ORG:     { label: 'Organisation / client', risk: 'High', color: '#4f46e5', pr: 4 },
  PERSON:  { label: 'Person name', risk: 'High', color: '#7c3aed', pr: 3 },
  CUSTOM:  { label: 'Client watch-list term', risk: 'High', color: '#475569', pr: 10 }
};

const ORG_SUFFIX = '(?:Private\\s+Limited|Pvt\\.?\\s*Ltd\\.?|Limited|Ltd\\.?|LLP|Traders|Trading\\s+Co\\.?|Enterprises|Industries|Agencies|Associates|Corporation|& Co\\.?|& Sons|Solutions|Exports|Textiles|Steels?)';
AG.RULES = [
  { type: 'AADHAAR', re: /\b[2-9]\d{3}[ -]?\d{4}[ -]?\d{4}\b/g,
    check: (m, text, idx) => AG.verhoeff.valid(m.replace(/\D/g, '')) || /aadha+r|uid/i.test(text.slice(Math.max(0, idx - 30), idx)) },
  { type: 'CARD', re: /\b(?:\d{4}[ -]?){3}\d{1,7}\b/g, check: (m, text, idx) => AG.luhn(m) && (/card/i.test(text.slice(Math.max(0, idx - 25), idx)) || /\d{4}[ -]\d{4}[ -]\d{4}/.test(m)) },
  { type: 'GSTIN', re: /\b\d{2}[A-Z]{5}\d{4}[A-Z][1-9A-Z]Z[0-9A-Z]\b/gi },
  { type: 'PAN', re: /\b[A-Z]{3}[ABCFGHLJPT][A-Z]\d{4}[A-Z]\b/gi },
  { type: 'IFSC', re: /\b[A-Z]{4}0[A-Z0-9]{6}\b/gi },
  { type: 'BANK_AC', re: /(?:a\/c|acct|account|ac)\.?\s*(?:no\.?|number|#)?\s*[:\-]?\s*(\d[\d -]{7,20}\d)/gi, group: 1 },
  { type: 'BANK_AC', re: /\b\d{11,18}\b/g },
  { type: 'UPI', re: /\b[\w.\-]{2,}@(?:ok[a-z]+|ybl|ibl|axl|paytm|upi|apl|icici|sbi|hdfcbank|axisbank|kotak)\b(?!\.)/gi },
  { type: 'EMAIL', re: /\b[\w.+\-]+@[\w\-]+(?:\.[\w\-]+)+\b/g },
  { type: 'PHONE', re: /(?:\+91[\s-]?|\b0)?\b[6-9]\d{4}[\s-]?\d{5}\b/g },
  { type: 'ORG', re: new RegExp('(?:M\\/s\\.?\\s+)?\\b(?:(?:[A-Z][A-Za-z0-9&\\.\\-]*|&)[ \\t]+){1,5}' + ORG_SUFFIX, 'g') },
  { type: 'PERSON', re: /\b(?:Mr|Mrs|Ms|Miss|Shri|Shree|Smt|Sh|Kumari|Dr|CA|Adv)\.?[ \t]+((?:[A-Z][a-z]+|[A-Z]\.)(?:[ \t]+(?:[A-Z][a-z]+|[A-Z]\.)){0,3})/g, group: 1 },
  { type: 'PERSON', re: /\b(?:S\/o|D\/o|W\/o|C\/o)\.?[ \t]+((?:[A-Z][a-z]+)(?:[ \t]+[A-Z][a-z]+){0,3})/g, group: 1 },
  { type: 'PERSON', re: /\b(?:[Nn]ame|[Pp]roprietor|[Pp]artner|[Dd]irector|[Ee]mployee|[Pp]ayee|[Aa]ssessee|[Tt]axpayer)[ \t]*[:\-][ \t]*((?:(?:Mr|Mrs|Ms|Shri|Smt|Dr)\.?[ \t]+)?(?:[A-Z][a-z]+)(?:[ \t]+[A-Z][a-z]+){1,3})/g, group: 1 }
];
const STOP_NAMES = new Set(['Assessment Year', 'Financial Year', 'Income Tax', 'Goods And', 'Section', 'Notice', 'Dear Sir']);

AG.detect = function (text, opts) {
  opts = opts || {};
  const found = [];
  // custom watch-list (client names the firm always wants hidden)
  (opts.watchlist || []).map(w => w.trim()).filter(w => w.length > 2).forEach(w => {
    const re = new RegExp(w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi'); let m;
    while ((m = re.exec(text))) found.push({ type: 'CUSTOM', start: m.index, end: m.index + m[0].length, value: m[0] });
  });
  for (const r of AG.RULES) {
    r.re.lastIndex = 0; let m;
    while ((m = r.re.exec(text))) {
      let val = m[0], start = m.index;
      if (r.group) { val = m[r.group]; start = m.index + m[0].lastIndexOf(val); }
      val = val.replace(/[\s.,]+$/, '');
      if (r.type === 'PERSON') {
        const t = val.match(/^(?:Mr|Mrs|Ms|Shri|Smt|Dr)\.?[ \t]+/);
        if (t) { val = val.slice(t[0].length); start += t[0].length; }
        if (STOP_NAMES.has(val)) continue;
      }
      if (r.check && !r.check(val, text, start)) continue;
      found.push({ type: r.type, start, end: start + val.length, value: val });
    }
  }
  // propagate: once a name/org is detected, hide every other mention of it too
  const names = [...new Set(found.filter(f => f.type === 'PERSON' || f.type === 'ORG' || f.type === 'CUSTOM').map(f => f.value))];
  names.forEach(n => {
    const core = n.replace(/^M\/s\.?\s+/i, '');
    const re = new RegExp('\\b' + core.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b', 'g'); let m;
    const t = (found.find(f => f.value === n) || {}).type;
    while ((m = re.exec(text))) found.push({ type: t, start: m.index, end: m.index + m[0].length, value: m[0], propagated: true });
  });
  // resolve overlaps: keep higher priority, then longer
  found.sort((a, b) => a.start - b.start || (AG.TYPES[b.type].pr - AG.TYPES[a.type].pr) || (b.end - b.start) - (a.end - a.start));
  const out = [];
  for (const f of found) {
    const clash = out.findIndex(o => f.start < o.end && o.start < f.end);
    if (clash === -1) { out.push(f); continue; }
    const o = out[clash];
    const better = AG.TYPES[f.type].pr > AG.TYPES[o.type].pr || (AG.TYPES[f.type].pr === AG.TYPES[o.type].pr && (f.end - f.start) > (o.end - o.start));
    if (better) out[clash] = f;
  }
  // re-check for new overlaps after replacement
  out.sort((a, b) => a.start - b.start);
  return out.filter((f, i) => !(i > 0 && f.start < out[i - 1].end));
};

/* ---------- pseudonymisation vault ---------- */
AG.Vault = function () { this.map = {}; this.rev = {}; this.count = {}; };
AG.Vault.prototype.norm = function (type, v) {
  if (['AADHAAR', 'CARD', 'BANK_AC', 'PHONE'].includes(type)) { const d = v.replace(/\D/g, ''); return type === 'PHONE' ? d.slice(-10) : d; }
  if (['PAN', 'GSTIN', 'IFSC'].includes(type)) return v.toUpperCase();
  return v.toLowerCase().replace(/^m\/s\.?\s+/, '').replace(/\s+/g, ' ').trim();
};
AG.Vault.prototype.tokenFor = function (type, value) {
  const k = type + '|' + this.norm(type, value);
  if (!this.map[k]) {
    this.count[type] = (this.count[type] || 0) + 1;
    const tok = '[' + type + '_' + this.count[type] + ']';
    this.map[k] = tok; this.rev[tok] = value;
  }
  return this.map[k];
};

AG.mask = function (text, vault, opts) {
  const dets = AG.detect(text, opts);
  let out = '', last = 0;
  const spans = [];
  dets.forEach(d => {
    out += text.slice(last, d.start);
    const tok = vault.tokenFor(d.type, d.value);
    spans.push({ type: d.type, token: tok, value: d.value, outStart: out.length, outEnd: out.length + tok.length, inStart: d.start, inEnd: d.end });
    out += tok; last = d.end;
  });
  out += text.slice(last);
  return { masked: out, detections: dets, spans };
};

AG.unmask = function (text, vault) {
  return text.replace(/\[?\b(AADHAAR|CARD|GSTIN|PAN|BANK_AC|IFSC|UPI|EMAIL|PHONE|ORG|PERSON|CUSTOM)_(\d+)\b\]?/g, (m, t, n) => {
    const tok = '[' + t + '_' + n + ']'; return vault.rev[tok] !== undefined ? vault.rev[tok] : m;
  });
};

/* leak check: is any original value still visible in the masked text? */
AG.leakCheck = function (masked, vault, opts) {
  const leaks = [];
  Object.entries(vault.rev).forEach(([tok, val]) => {
    if (val.length >= 4 && masked.toLowerCase().includes(val.toLowerCase())) leaks.push({ tok, val });
  });
  const redetect = AG.detect(masked.replace(/\[[A-Z_]+_\d+\]/g, ' '), opts);
  return { leaks, redetect };
};

/* ---------- offline demo "AI" (so the live demo never depends on internet) ---------- */
AG.mockAI = function (maskedPrompt) {
  const toks = t => [...new Set((maskedPrompt.match(new RegExp('\\[' + t + '_\\d+\\]', 'g')) || []))];
  const orgs = toks('ORG').concat(toks('CUSTOM')), ppl = toks('PERSON'), gst = toks('GSTIN'), pan = toks('PAN'), ac = toks('BANK_AC'), aad = toks('AADHAAR');
  const amts = [...new Set(maskedPrompt.match(/(?:₹|Rs\.?|INR)\s?[\d,]+(?:\.\d+)?/g) || [])];
  const L = [];
  L.push('**Summary (prepared by AI on masked data)**');
  if (orgs.length) L.push(`- Entities involved: ${orgs.join(', ')}${gst.length ? ' (GSTIN ' + gst.join(', ') + ')' : ''}.`);
  if (ppl.length) L.push(`- Individuals referred to: ${ppl.join(', ')}${pan.length ? '; PAN references: ' + pan.join(', ') : ''}.`);
  if (amts.length) L.push(`- Amounts mentioned: ${amts.slice(0, 6).join(', ')}.`);
  L.push('');
  L.push('**Observations**');
  if (/notice|143|148|demand|show cause|ASMT|DRC/i.test(maskedPrompt))
    L.push(`- This is a tax notice/demand. Prepare a point-wise reply for ${orgs[0] || 'the client'}, attach reconciliations, and track the response due date.`);
  if (ac.length) L.push(`- Bank account ${ac[0]} appears in the data${ac.length > 1 ? ' along with ' + ac.slice(1).join(', ') : ''}. Confirm it matches the vendor master and cancelled cheque on file.`);
  if (ac.length && ppl.length && orgs.length && /employee|staff/i.test(maskedPrompt))
    L.push(`- ⚠ ${ppl[0]} appears linked to a payee account. Check for a conflict of interest / employee-vendor relationship.`);
  if (aad.length) L.push(`- Aadhaar ${aad[0]} is present. Under data-minimisation principles, store only the masked form (last 4 digits) in the working papers.`);
  if (/round|split|below|limit/i.test(maskedPrompt)) L.push('- Payments just below approval limits or split invoices should be tested against the delegation-of-authority matrix.');
  L.push(`- Reconcile the figures with the books of ${orgs[0] || 'the entity'} and GSTR-2B / Form 26AS as applicable.`);
  L.push('');
  L.push('**Suggested next steps**');
  L.push(`1. Obtain supporting documents from ${ppl[0] || 'the responsible person'}.`);
  L.push(`2. Draft the reply / workpaper note for ${orgs[0] || 'the client'} and have the engagement partner review it.`);
  L.push('3. Record conclusions in the audit file.');
  return L.join('\n');
};

/* ---------- sample prompts (all fictional; IDs generated with valid checksums) ---------- */
AG.SAMPLES = {
  'GST notice reply': `Draft a reply to the GST notice below for our client.

Client: Shubham Textiles Pvt Ltd, GSTIN 27AAKCS4321M1Z1, PAN AAKCS4321M
Authorised signatory: Mr. Rajesh Kulkarni (Director), mobile +91 98201 45678, email rajesh.k@shubhamtextiles.in

Notice ref ASMT-10 dated 12-08-2026 states that ITC of Rs. 4,82,350 claimed in GSTR-3B for FY 2025-26 exceeds GSTR-2B by Rs. 1,12,900.
The difference relates to invoices from Mahalaxmi Traders (GSTIN 27ABHFM7788K1ZD) which filed GSTR-1 late.
Payments to Mahalaxmi Traders were made from HDFC A/c No. 50200012345678, IFSC HDFC0001234.`,
  'Vendor ledger review': `Review this vendor payment extract and tell me what looks suspicious.

Vendor: Sai Enterprises, PAN AFZPS1234Q, Bank a/c 60112233445566, IFSC SBIN0004567, UPI saient@okaxis
Proprietor: Shri Rohit Shinde, mobile 9822011107
Note: Rohit Shinde is also our employee in Accounts Payable (Employee name: Rohit Shinde).
Payments: 12-06-2025 Rs. 98,500; 18-07-2025 Rs. 99,200; 03-09-2025 Rs. 97,800 (approval limit Rs. 1,00,000)
All payments approved by Mrs. Anita Deshpande.`,
  'Payroll / KYC query': `Employee name: Priya Nair
Aadhaar: 7341 5298 0167, PAN BQNPN6655K
Salary credited to ICICI account 001101556677, IFSC ICIC0000011
Reimbursement claim of Rs. 46,000 submitted by Ms. Priya Nair; card used 4111 1111 1111 1111.
Question: Is this reimbursement taxable as a perquisite and how should it be shown in Form 16?`
};

/* labelled evaluation set: [text, [[TYPE, value], ...]] */
AG.EVAL = [
  ['PAN of assessee is ABCPK1234D for AY 2026-27', [['PAN', 'ABCPK1234D']]],
  ['Pay Rs. 1,25,000 to M/s Ganesh Traders by 31 March', [['ORG', 'M/s Ganesh Traders']]],
  ['Contact Mr. Suresh Patil on 9876543210', [['PERSON', 'Suresh Patil'], ['PHONE', '9876543210']]],
  ['Mail invoice to accounts@deccansteel.co.in', [['EMAIL', 'accounts@deccansteel.co.in']]],
  ['Credit to A/c No. 123456789012 IFSC SBIN0001234', [['BANK_AC', '123456789012'], ['IFSC', 'SBIN0001234']]],
  ['Pay via UPI rakesh.m@okhdfcbank today', [['UPI', 'rakesh.m@okhdfcbank']]],
  ['GSTIN 27AAKCS4321M1Z1 filed GSTR-1 late', [['GSTIN', '27AAKCS4321M1Z1']]],
  ['Smt. Lata Joshi W/o Ramesh Joshi signed the form', [['PERSON', 'Lata Joshi'], ['PERSON', 'Ramesh Joshi']]],
  ['Invoice INV-2026-00981 dated 05-04-2026 for Rs 45,000', []],
  ['Total turnover 4,82,35,000 for FY 2025-26', []],
  ['Partner: Neha Agarwal of Agarwal & Associates', [['PERSON', 'Neha Agarwal'], ['ORG', 'Agarwal & Associates']]],
  ['Call 022-24567890 or +91-9988776655', [['PHONE', '+91-9988776655']]],
  ['Shree Balaji Enterprises supplied 120 MT steel', [['ORG', 'Shree Balaji Enterprises']]],
  ['Account number 50100234567812 belongs to the vendor', [['BANK_AC', '50100234567812']]],
  ['Section 194C TDS at 2% on Rs. 3,40,000', []],
  ['Reply by Dr. Arvind Rao, PAN AAAPR9087L, phone 9123456780', [['PERSON', 'Arvind Rao'], ['PAN', 'AAAPR9087L'], ['PHONE', '9123456780']]],
  ['the director ramesh gupta approved it', [['PERSON', 'ramesh gupta']]],
  ['Payee: Kiran Bhatt, paid by card 5500 0000 0000 0004', [['PERSON', 'Kiran Bhatt'], ['CARD', '5500 0000 0000 0004']]]
];

AG.evaluate = function () {
  const per = {}; let tp = 0, fp = 0, fn = 0;
  const rows = AG.EVAL.map(([text, exp]) => {
    const det = AG.detect(text).map(d => [d.type, d.value]);
    const key = x => x[0] + '|' + x[1].toLowerCase();
    const E = new Set(exp.map(key)), D = new Set(det.map(key));
    const hit = [...E].filter(k => D.has(k)), miss = [...E].filter(k => !D.has(k)), extra = [...D].filter(k => !E.has(k));
    hit.forEach(k => { const t = k.split('|')[0]; (per[t] = per[t] || { tp: 0, fp: 0, fn: 0 }).tp++; });
    miss.forEach(k => { const t = k.split('|')[0]; (per[t] = per[t] || { tp: 0, fp: 0, fn: 0 }).fn++; });
    extra.forEach(k => { const t = k.split('|')[0]; (per[t] = per[t] || { tp: 0, fp: 0, fn: 0 }).fp++; });
    tp += hit.length; fn += miss.length; fp += extra.length;
    return { text, hit, miss, extra };
  });
  return { rows, per, tp, fp, fn, recall: tp / ((tp + fn) || 1), precision: tp / ((tp + fp) || 1) };
};

if (typeof module !== 'undefined') module.exports = AG;
