# AuditShield upgrade — implementation status

Last updated: 2026-11-16 (Phases 0, 1 and 2 complete; part of Phase 4 pulled forward for a demo; Phase 3 not started).
Presentation guide and click-by-click demo script: `DEMO_SCRIPT.md`.

> **Release 1.0.0 (2026-11-16, capstone submission).** Added after the sections below: CSV import
> wizard (dataset assignment, column mapping, row-level validation, error CSV, unknown columns
> dropped); protected package export and auditor-side import (strict schema, checksum, declared
> profile enforced, references validated; tested between two independent profiles and two browser
> contexts); director-DIN leak in data-quality warnings fixed; LM Studio / Ollama local-model
> adapter (localhost-only destination policy, response validation, timeout, cancellation, safe
> errors; network-level tests prove blocked requests make zero calls); SVG relationship graph synced
> with finding selection; installable PWA (app files only cached, starts offline); no-install
> PowerShell launcher. Results: `npm test` 299 passed, 19 todo; `npm run test:e2e` 6 passed in Edge.
> Still not done: cloud providers (deliberately), legacy 16-hex package import, large-dataset
> benchmarks, formal accessibility audit, R6 instalment grouping.
Governing documents, one level up: `../AuditShield_Upgrade_Plan.md`, `../CLAUDE_UPGRADE_PROMPT.md`.

## How to resume

1. Work only inside this directory (`auditshield/`). The original files one level up
   (`AuditShield_Project.zip`, `AuditShield_Project/`, the two top-level HTML apps, deck, guide) are
   never modified. The only file added outside this directory is `../.claude/launch.json`
   (dev/preview server definitions for the Claude desktop browser pane).
2. `npm ci` then `npm test`, `npm run typecheck`, `npm run legacy:verify`, `npm run build`,
   `npm run test:e2e`. All five must pass before and after any change. The end-to-end tests drive
   the Microsoft Edge already installed on this machine (`channel: 'msedge'`); no browser download.
3. Run the app: `npm run dev` → http://127.0.0.1:5173 (fixed port, `strictPort`), or
   `npm run build` then `npm run preview` → http://127.0.0.1:4173 (production build with CSP).
   It cannot be opened by double-clicking `index.html`.
4. Read "Phase status" for where things stand and "Next bounded task" (end of file) for what to do next.
5. Git is not installed on this machine, so there is no branch. This directory *is* the upgrade
   workspace, and `package-lock.json` is the committed lockfile. A `.gitignore` is ready.

## Environment

| Item | Value |
| --- | --- |
| OS | Windows 11 Home Single Language 10.0.26200 |
| Node / npm | 26.13.0 / 11.20.0 |
| Python | 3.15.2 (only needed for the legacy `build.py`) |
| Git | not installed |
| Dev dependencies | vitest 5.1.0, typescript 7.0.2, @types/node 26.6.6, vite 8.3.8, @vitejs/plugin-react 6.3.0, tailwindcss 4.3.5, @tailwindcss/vite 4.3.5, @types/react 19.3.0, @types/react-dom 19.3.0 |
| Runtime dependencies | react 19.3.1, react-dom 19.3.1, lucide-react 1.73.0, clsx 2.1.1, tailwind-merge 3.7.0, class-variance-authority 0.7.1; added in Phase 2: dexie 4.4.7, dexie-react-hooks 4.4.0, zod 4.6.7 |
| Added to dev dependencies in Phase 2 | fake-indexeddb 6.2.8, @playwright/test 1.65.1 |
| Reference machine | Intel Core Ultra 7 256V, 15.7 GB RAM |
| Not installed yet (by design, added in their phase) | Papa Parse, React Hook Form (3), TanStack Table/Virtual, Cytoscape.js (4), vite-plugin-pwa (6) |

All versions are exact pins, current stable on 2026-11-15, peer ranges checked; `npm install` reported 0 vulnerabilities.

## Decisions

| # | Decision | Status |
| --- | --- | --- |
| D1 | Platform: browser app, React + TypeScript + Vite, Dexie over IndexedDB. One database engine. The Tauri + SQLite path is taken only if an installed Windows app with an ordinary SQLite file is explicitly required, and that must be said before Phase 2 starts. | **Confirmed by the user on 2026-11-16** ("Start Phase 2" on the browser + Dexie path) |
| D5 | A workspace always has a passphrase. One code path: engagement labels are always encrypted, and optional retention always has a key to use. There is no passphrase recovery. | Done (Phase 2) |
| D6 | Gateway prompts, answers and vault values are never written to storage in this version. They live in memory and are cleared on lock or reload. Optional encrypted retention of gateway content is deferred to Phase 5 with the provider work. | Done (Phase 2) |
| D7 | A backup is restored only into an empty profile. An existing workspace is never overwritten or merged. | Done (Phase 2) |
| D8 | Retaining source data (and the matching HMAC key) is a per-snapshot opt-in, off by default, stored only as ciphertext, with a retention period (default 30 days). Including it in a backup is a second explicit opt-in. | Done (Phase 2) |
| D2 | `legacy/` is a fresh extraction of `AuditShield_Project.zip`, frozen. `tests/fixtures/baseline/legacy-manifest.json` holds SHA-256 digests of all 23 files and a test fails if any byte changes. Legacy code is executed through `node:vm`, never edited or transformed. | Done |
| D3 | Known defects are captured as passing "characterisation" tests against the frozen legacy code (`tests/known-issues`). The required new behaviour is listed beside each as `it.todo('TARGET [Phase N] …')` and becomes a real test against the new modules in that phase. | Done |
| D4 | Readable fields in the protected package (critical requirement 3). Proposed default "Minimal" profile: source record IDs (vendor/employee/payment IDs) readable; vendor, employee and director names excluded; DIN replaced by a package-local director reference; department readable; invoice numbers tokenised (R6 only needs equality); `created_by` / `approved_by` kept as employee IDs. Optional "Named" profile adds vendor and director names by explicit opt-in shown in the package preview. | **Proposed — confirm before Phase 3** |

## Phase status

| Phase | Scope | Status |
| --- | --- | --- |
| 0 | Reproduce baseline, assert it, reproduce known issues, record behaviour changes | **Complete** |
| 1 | Typed foundation, domain ports, shared shell | **Complete** (limits listed in the Phase 1 report) |
| 2 | Repositories, DB versions, encryption, backup/restore | **Complete** (limits listed in the Phase 2 report) |
| 3 | Validated imports, protected package, auditor workflow | Not started |
| 4 | Findings triage, graph/list, review decisions, workpapers | **Partly done early** (review decisions, workpaper export; see "Demo readiness work"). Graph, saved filters, metric definitions, R6 grouping still open |
| 5 | Gateway review, enforced outbound policy, provider adapters | Not started |
| 6 | Workers, large fixtures, accessibility, offline install, docs | Not started |

---

## Phase 0 report

### What was inspected

- Every source member of the archive: `ghost_vendor/{core.js,ui.js,template.html}`,
  `ai_gateway/{core.js,ui.js,template.html}`, `tests/*`, `build.py`, `sample_data/*`, `README.md`.
- `AuditShield_Project/` (already extracted next to the zip) has the same 23 files and sizes as the zip.
- The two top-level HTML apps have the same SHA-256 as `dist/*.html` in the archive.
- `dist/*.html` are exactly `template.html` with `core.js` and `ui.js` inlined (asserted in
  `tests/baseline/legacy-integrity.test.ts`).

### What changed

New files only; nothing existing was edited.

```
auditshield/
  legacy/                               frozen copy of the archive (23 files)
  scripts/legacy-manifest.mjs           write / verify legacy digests
  tests/helpers/legacy.ts               vm loader for legacy core + observable fake-DOM harness for dist/*.html
  tests/fixtures/baseline/legacy-manifest.json
  tests/baseline/                       asserted baseline (4 files)
  tests/known-issues/                   reproduced defects + TARGET todos (3 files)
  package.json, package-lock.json, tsconfig.json, vitest.config.ts
  IMPLEMENTATION_STATUS.md
```

### Commands and results (2026-11-15)

| Command | Result |
| --- | --- |
| `node tests/test_gv.js`, `node tests/test_ag.js`, `node tests/smoke.js dist/<each>.html` in the original project | All exit 0; printed output matches the baseline below |
| `npm test` (`vitest run`) | 7 files, **121 passed, 47 todo, 0 failed** |
| `npm run typecheck` (`tsc --noEmit`) | exit 0 |
| `npm run legacy:verify` | "Legacy reference intact: 23 files match the manifest." |

No production build exists yet; there is no application code before Phase 1.

### Baseline, now asserted

VendorShield, synthetic sample (`tests/baseline/vendorshield.baseline.test.ts`):

| Measure | Value |
| --- | --- |
| Employees / vendors / directors / payments | 10 / 12 / 3 / 86 |
| Findings | 14: 2 Critical, 10 High, 1 Medium, 1 Low |
| Per rule | R1 2, R2 2, R3 1, R4 1, R5 1, R6 1, R7 1, R8 1, R9 3, R10 1 |
| Total paid | INR 11,033,700 |
| Legacy "amount at risk" | INR 5,116,715 = all payments to the 6 vendors with any Critical/High finding (V102, V105, V108, V109, V110, V111) |
| Sum of per-finding amounts | INR 7,233,492 (overlapping; not a meaningful total) |
| Payment-level evidence | 12 distinct payments, INR 1,171,450 (R6, R7, R8, R10 only) |
| Graph | 20 nodes, 23 edges |
| Heuristic vendor scores | V105 100, V110 90, V108 75, V111 25, V102 25, V109 25, V106 5 |

All 14 findings are pinned with rule, severity, entities, amount, matched fields, payment IDs and
title. They are identical under a different key and when loaded from `sample_data/*.csv`.

Gateway (`tests/baseline/gateway.baseline.test.ts`): 18 sentences, 22 labelled identifiers,
**21 TP, 1 FN, 0 FP** (recall 95.45%, precision 100%). Per type: PERSON 6/7, ORG 3/3, PHONE 3/3,
PAN 2/2, BANK_AC 2/2, EMAIL, IFSC, UPI, GSTIN, CARD 1/1 each. The miss is
`the director ramesh gupta approved it`. The three sample prompts are pinned detection by detection.

These are results on tiny synthetic samples. They are not accuracy guarantees.

### Known-issue register

Line numbers refer to files under `legacy/`. Every row is reproduced by a passing test in
`tests/known-issues/` unless marked "documented only".

| ID | Pri | Evidence | Reproduced behaviour | Fix phase |
| --- | --- | --- | --- | --- |
| KI-G01 | P0 | `ai_gateway/ui.js:57,69–71` | Send is enabled after any scan; on a leak warning one `confirm()` OK transmits the leaking text. No service-level gate. | 5 |
| KI-V01 | P0 | `ghost_vendor/core.js:108–124` | `protect` spreads the whole input row. `extra_notes` survives unchanged; the payments table is copied wholesale (`SENSITIVE.payments = []`). | 3 |
| KI-V02 | P0 | `ghost_vendor/core.js:99–104` | Director names, DINs, vendor names, departments and invoice references are readable in the "protected" file. The "0 leaks" counter only searches the declared sensitive columns. | 3 |
| KI-G03 | P0 | `ai_gateway/core.js:154–160` | Leak check = vault-value search + the same detector again. Lowercase names, Devanagari names and unlisted client names pass with both lists empty. | 5 |
| KI-G08 | P0 | `ai_gateway/ui.js:53–56` | UI prints "Leak test passed … 0 found" while an undetected name is in the outgoing text. | 5 |
| KI-G05 | P0 | `ai_gateway/core.js:117–131,147–151` | Restoration is global and tokens are sequential (`[PERSON_2]`). An answer to an unrelated request reveals other vault entries; bare `PERSON_1` is restored; literal `[PERSON_1]` typed by the user collides with a real token. | 5 |
| KI-G10 | P0 | `ai_gateway/ui.js:104–115` | "Reveal real values (partner/manager only)" is an unguarded checkbox. The session log keeps a 90-character preview of sent text. | 2, 5 |
| KI-V10 | P1 | `ghost_vendor/ui.js:39–55,83,87–89` | Loading new data leaves `PROT`/`RESULT` in place: Analyse and Download still use the previous dataset. Files are assigned to datasets by filename. Client and auditor share one page; there is no package import. A default key ships in `template.html:108`. | 3 |
| KI-G02 | P1 | `ai_gateway/ui.js:17–18,23` | Only the prompt textarea resets the scan. Changing the watch-list, endpoint, model or provider after scanning still sends the old scan. | 5 |
| KI-V03 | P1 | `ghost_vendor/core.js:85` | Leading zeros stripped: `00123456789` ≡ `123456789`, producing a false Critical R1. All-zero accounts become empty. | 1, 3 |
| KI-V04 | P1 | `ghost_vendor/core.js:90` | Non-Latin text deleted: `पुणे` → `""`; two different Devanagari addresses with house number 12 match falsely; identical pure-script addresses never match; `Café` → `caf`. | 1 |
| KI-V05 | P1 | `ghost_vendor/core.js:109,121` | Tokens are HMAC truncated to 64 bits with no version metadata. The key is a typed password (any 8 characters) used directly. | 1, 2, 3 |
| KI-V06 | P1 | `ghost_vendor/core.js:116` | PAN derived from any GSTIN-length string without validation, and sliced before normalising, so a spaced genuine GSTIN derives the wrong PAN. | 1, 3 |
| KI-V07 | P1 | `ghost_vendor/core.js:152,260,339` | No validation: `"1,25,000"` makes the total `NaN`; duplicate payment IDs and orphan vendors are accepted; a missing date throws. Amounts are floating-point rupees. | 1, 3 |
| KI-G04 | P1 | `ai_gateway/core.js:52–54` | Aadhaar-shaped numbers failing Verhoeff (9 of 10 last digits) and card-shaped numbers failing Luhn are sent in clear. Detections carry no validity/confidence. | 1 |
| KI-G06 | P1 | `ai_gateway/core.js:97` | Name propagation is case-sensitive; a later lowercase mention stays visible. | 1 |
| KI-G09 | P1 | `ai_gateway/ui.js:79–86` | Any URL accepted (including plain http), no timeout or AbortSignal, response shape unvalidated, HTTP status lost when the error body is not JSON. One request shape for every provider. | 5 |
| KI-V08 | P2 | `ghost_vendor/core.js:246–257` | R6 flags any repeated vendor + invoice as "paid twice"; three instalments give two findings. | 4 |
| KI-V09 | P2 | `ghost_vendor/core.js:199–240,292–306,331–333` | Finding amounts overlap (V105: paid INR 593,550, findings total INR 2,509,700). R1–R5 and R9 list no payment IDs. Finding IDs are positional. | 1, 4 |
| KI-G07 | P2 | `ai_gateway/core.js:74–77` | Watch-list terms under 3 characters are ignored silently; terms match inside other words. | 5 |
| KI-X01 | P2 | `ai_gateway/ui.js:117–122` | Audit-log CSV export does not neutralise formula-leading cells. Documented only. | 4, 5 |
| KI-X02 | P2 | both `ui.js` | All state is in page memory; a refresh loses everything. Documented only (nothing to assert). | 2 |

Additional fact found while probing: 8 of the 10 GSTINs in the synthetic vendor sample fail the
GSTIN check digit (only V101 and V104 are valid). Sample vendors all carry an explicit PAN, so
findings are unaffected, but validation will warn on these rows and the sample fixture should
either be corrected or kept deliberately as a data-quality demonstration.

### Intentional future behaviour changes

Recorded now so later differences from the legacy baseline are explainable. "Sample effect" is the
expected effect on the 14-finding baseline and will be asserted when the change lands.

| ID | Change | Sample effect | Phase |
| --- | --- | --- | --- |
| BC-01 | Bank accounts keep leading zeros (normalisation v2) | None; no sample account starts with 0 | 1 |
| BC-02 | Unicode-preserving address normalisation, versioned | None expected on the ASCII sample | 1 |
| BC-03 | Full HMAC-SHA256 tokens with algorithm/key/normalisation versions; random engagement key | Token strings change; matches unchanged | 1–3 |
| BC-04 | PAN derived only from a normalised, structurally valid, checksum-valid GSTIN | None; no sample vendor relies on derivation | 1 |
| BC-05 | Protected output built from allowlists; unknown columns excluded; readable labels by explicit profile (D4) | Protected file loses names/DIN/unknown columns | 3 |
| BC-06 | Money as integer paise; invalid amounts rejected at import | Displayed values unchanged | 1, 3 |
| BC-07 | "Amount at risk" renamed to payments to vendors with high/critical findings (under review); new payment-level figure deduplicated by payment ID; nothing labelled as loss without a confirmed decision | Same INR 5,116,715 under an accurate label; plus INR 1,171,450 payment-level figure | 4 |
| BC-08 | Stable finding fingerprints replace `F1…F14` | IDs change | 1 |
| BC-09 | R6 groups repeated vendor + invoice as one candidate with all payments | Still one R6 finding on the sample | 4 |
| BC-10 | Failed outbound checks block the request in the service; no override | Gateway samples still send | 5 |
| BC-11 | Scan approval bound to text + watch-list + policy + destination digest | n/a | 5 |
| BC-12 | Identifier-shaped values masked even when checksums fail; confidence and validity reported separately | 21/1/0 on the 18-sentence set must be re-measured; any new false positives reported | 1, 5 |
| BC-13 | Session-namespaced tokens; request-scoped restoration | Token text changes | 5 |
| BC-14 | Case- and spacing-insensitive masking of values already in the request vault | n/a | 1 |
| BC-15 | Invalid input blocks the import instead of producing `NaN` or a crash | n/a | 3 |

### Not tested in Phase 0

- No real browser was used. UI reproductions run the legacy handlers against a fake DOM that
  records state, downloads, dialogs and `fetch` calls. Rendering, layout, focus and accessibility
  of the legacy apps were not examined.
- No network request was made. `fetch` is a recording stub.
- `legacy/build.py`, `make_deck.py`, `make_guide.py` and `diagrams/make_diagrams.py` were not run.
  The build output is checked instead by reconstructing `dist/*.html` from the sources.
- The brute-force demo in VendorShield was not exercised by the new suite (it ran in the original
  smoke script).
- Larger corpora and 10k/100k payment fixtures do not exist yet (Phases 5–6).

---

## Phase 1 report

### What was built

```
src/
  domain/shared/     identifiers (Verhoeff, GSTIN, PAN, Luhn, Indic digits), money (integer paise), dates, hash
  domain/vendor/     types, normalise (v2), protect (allowlist + export profiles), rules (R1–R10 port), sample
  domain/privacy/    detect, vault (namespaced tokens, request-scoped restore), policy (mask, outbound check,
                     scan key), messages, offlineDemo, evaluate (+ baseline set and sample prompts)
  services/crypto/   tokeniser: random non-extractable 256-bit HMAC key, full HMAC-SHA256 tokens (Web Crypto)
  services/gateway/  requestService: the only path to a provider; enforces the send gate
  services/providers/ adapter contract + offline demo adapter
  app/               state.ts (pure reducer with invalidation rules), store.tsx, App.tsx (shell, hash routes)
  components/ui/     shadcn-style primitives (button, card, badge, inputs, notice, empty state, stat)
  features/          overview, imports, vendorshield, gateway, workpapers, activity, settings, learn
tests/parity/        new modules vs frozen legacy on the sample and the baseline evaluation set
tests/unit/          new behaviour: vendor domain, gateway domain + request service, app reducer
index.html, vite.config.ts (production CSP), src/index.css
```

Domain modules import nothing from React, the DOM or storage. Network access exists only behind
`ProviderAdapter`; the single registered adapter makes no network call.

### Commands and results (2026-11-15)

| Command | Result |
| --- | --- |
| `npm test` | 12 files, **217 passed, 20 todo, 0 failed** (121 legacy baseline/known-issue + 96 new) |
| `npm run typecheck` | exit 0 |
| `npm run legacy:verify` | 23 files match the manifest |
| `npm run build` | exit 0; `dist/index.html` 0.84 kB, CSS 23.45 kB, JS 363.56 kB (114.68 kB gzip) |

Real-browser run of the production build (`npm run preview`, Claude desktop browser pane, Chromium):
create sample engagement → Imports: load sample → VendorShield: protect → analyse → select a finding →
AI Gateway: sample prompt → scan → send → answer; then a text containing a reserved token → blocked.
Observed: 14 findings (2 critical, 10 high, 1 medium, 1 low), total paid ₹1,10,33,700, payments to
vendors under review ₹51,16,715, 8 GSTIN warnings; gateway masked 10 occurrences into 8 codes; **zero
network requests recorded**; no console messages under the production CSP (`connect-src 'none'`);
editing the draft cleared the scan; the blocked state disabled Send. At 375 px the page had no
horizontal scroll on VendorShield, Gateway and Settings after a layout fix found by this run.
This was a manual drive of the pane, not an automated Playwright suite.

### Parity with the legacy baseline

- VendorShield: the typed sample equals the legacy sample record for record; the new engine yields
  the same 14 findings in the same order with the same entities, amounts, matched fields, titles and
  cited payments, the same summary figures, vendor priorities, graph size and flagged nodes, also at
  approval limits of ₹50,000, ₹1,50,000 and ₹2,50,000. Every attribute in the ASCII sample
  normalises to the same string under v1 and v2.
- Gateway: on the 18-sentence set the new detector scores **21 TP, 1 FN, 0 FP**, identical per type
  and sentence by sentence; the three sample prompts give identical detections. The remaining miss
  (lowercase untitled name) is unchanged and visible in Demo / Learn.

### Known-issue status after Phase 1

"Fixed (domain)" means the new modules have the required behaviour under test. The legacy apps are
unchanged, so the legacy reproductions still pass.

| ID | Status |
| --- | --- |
| KI-G01 send-anyway | Fixed (service): failed checks block in `GatewayRequestService`; no override exists; spy adapter proves zero calls. Network interception with real adapters: Phase 5. |
| KI-G02 stale scan | Fixed (domain, service, reducer): scan key covers text, watch-list, manual masks, policy, destination, vault session. |
| KI-G03 / G08 leak-check scope | Partly: honest scope text, manual masking, re-masking of known values. Lowercase/regional names still undetected by patterns; corpus report: Phase 5–6. |
| KI-G04 checksum drop | Fixed: masked regardless of checksum; `validity` and `confidence` separate. |
| KI-G05 global restoration | Fixed: namespaced tokens, request-scoped restoration, unknown tokens surfaced. |
| KI-G06 case-sensitive propagation | Fixed. |
| KI-G07 watch-list | Short terms (< 2 characters) are reported back. Substring matching kept on purpose (over-masking is the safe side). |
| KI-G09 provider call | Timeout, cancellation, generic errors and destination equality exist in the service. Real adapters, host policy, response schema validation: Phase 5. |
| KI-G10 reveal checkbox | Relabelled as a display toggle. Workspace unlock, timed reveal, audit event: Phase 2. |
| KI-V01 unknown columns | Fixed (domain): allowlist construction. Import-wizard handling of unmapped columns: Phase 3. |
| KI-V02 readable labels | Fixed (domain): explicit `minimal` / `named` profiles (decision D4 still to confirm). Package preview: Phase 3. |
| KI-V03 leading zeros | Fixed. |
| KI-V04 Unicode addresses | Fixed. |
| KI-V05 token strength | Fixed for new data. Legacy-package import path: Phase 3. Key backup/wrapping: Phase 2. |
| KI-V06 PAN from GSTIN | Fixed. |
| KI-V07 validation | Money/date primitives fixed. Import-time validation and atomic commit: Phase 3. |
| KI-V08 R6 instalments | Open (Phase 4). Legacy behaviour kept for parity. |
| KI-V09 evidence, overlap, IDs | Evidence and fingerprints fixed. Deduplicated payment-level metric and its definition: Phase 4. |
| KI-V10 stale state | Fixed in the reducer (revision-checked). Immutable snapshots and package handoff: Phase 3. |
| KI-X01 CSV formula cells | Open (no CSV export exists yet). |
| KI-X02 no persistence | Open (Phase 2). The UI says so on every screen. |

### Behaviour changes introduced in Phase 1 (additions to the table above)

| ID | Change | Sample effect |
| --- | --- | --- |
| BC-16 | An address that normalises to numbers only ("Flat No. 12") is unusable and gets no token | None |
| BC-17 | Phone: 12 digits starting 91 or 11 digits starting 0 are reduced to 10; other lengths kept whole; fewer than 7 digits or one repeated digit is unusable | None (same strings as legacy on the sample) |
| BC-18 | A PAN-shaped value with an unissued fourth letter is detected as an invalid PAN | None on the baseline set |
| BC-19 | R6 explanation says "Second payment" instead of "Amount at risk" | Wording only |
| BC-20 | Graph attribute nodes are numbered, so tokens never appear in graph data | None (20 nodes / 23 edges) |
| BC-21 | Relationship findings list the payments behind their amount (R1–R4: all payments to the vendor(s); R9: creator-approved payments) | New evidence; amounts unchanged |
| BC-22 | Minimal profile shows vendor IDs instead of names and `D-00n` instead of DINs in finding titles; invoice numbers are tokenised | Titles differ under `minimal`; identical under `named` |

### Limits of Phase 1 (not done, by design or by time)

- **No persistence.** State is in memory; refresh loses it. The app warns before unload.
- **Only the synthetic sample can be loaded.** No CSV import, no package export/import, so client
  preparation and auditor analysis are not yet separate workspaces. The screen says so.
- **Workpapers screen is an explanatory empty state.** Nothing can be recorded there.
- **No interactive graph**; relationships are shown as a list (kept later as the accessible alternative).
- **Only the offline demo provider exists.** Local/external modes are shown as "Not configured".
- **UI primitives are hand-written in the shadcn/ui style** (Tailwind + class-variance-authority).
  The shadcn CLI and Radix components have not been added; `components.json` does not exist yet.
- **Rule analysis runs on the main thread** (86 payments). Workers and benchmarks: Phase 6.
- **Accessibility was not audited.** Semantics, labels, focus rings, `aria-sort`, `aria-current` and a
  skip link are in place, but no screen-reader or automated a11y check was run. Keyboard-only use was
  not exercised end to end.
- **No Playwright suite yet.**
- React components have no unit tests; UI behaviour was verified through the reducer tests and the
  browser run above.

(The Phase 1 limits "no persistence" and "no Playwright suite" are resolved by Phase 2 below.)

---

## Phase 2 report

### What was built

```
src/data/db/schema.ts               Dexie database, 14 stores, schema versions 1 and 2, safe open with explained failures
src/data/repositories/repositories.ts  the persistence boundary: workspace, engagements, datasets (snapshots +
                                    optional retained source), runs, audit, settings
src/domain/vendor/validate.ts       structural validation of a protected dataset before commit
src/services/crypto/envelope.ts     passphrase → PBKDF2 → key-encryption key → wrapped random data key; AES-GCM boxes with AAD
src/services/crypto/tokeniser.ts    + export of the HMAC key (only for encrypted retention), SHA-256 source digest
src/services/backup/backup.ts       encrypted backup file format, export, header preview, validated atomic restore
src/services/workspace/useCases.ts  setup, unlock, protect-and-commit, analyse-snapshot, current run, retention purge
src/services/workspace/session.ts   lock state, in-memory data key, inactivity auto-lock
src/app/state.ts, store.tsx         reducer reduced to memory-only session state; live-query hooks over the database
src/features/workspace/             setup (create or restore), unlock and database-error screens
tests/integration/                  crypto, persistence, migration, backup (fake-indexeddb, one "profile" per test)
tests/e2e/                          Playwright in Edge against the production build
playwright.config.ts
```

Every screen now reads stored data through repositories and live queries. The reducer holds only
what is deliberately not stored: loaded source data and the gateway session.

### What is stored, and how

| Data | Stored | Form |
| --- | --- | --- |
| Protected entities, attribute tokens, payments (per immutable snapshot) | Always, once protected | Plain records, indexed |
| Rule sets, analysis runs, findings | Always, insert-only | Plain records |
| Activity events | Always | Metadata text only |
| Settings (thresholds, auto-lock, retention, last backup, current engagement) | Always | Plain records |
| Engagement labels, snapshot source labels | Always | AES-256-GCM ciphertext |
| Source data and its HMAC key | Only if ticked when protecting; purged after the retention period | AES-256-GCM ciphertext |
| Workspace data key | Always | Wrapped under a PBKDF2-derived key; passphrase never stored |
| Gateway prompts, answers, vault values | Never | — |

Encryption: PBKDF2-HMAC-SHA256, 600,000 iterations, 16-byte random salt, versioned envelope (v1);
random 256-bit data key, non-extractable once unwrapped; AES-GCM with a fresh random 96-bit nonce per
encryption and authenticated data naming workspace, store, record and field. Engagement HMAC keys
are separate keys and are never used for encryption. Measured KDF cost on the reference machine:
129–162 ms per derivation in Node 26 (five runs); not separately timed inside the browser.

### Commands and results (2026-11-16)

| Command | Result |
| --- | --- |
| `npm test` | 16 files, **261 passed, 19 todo, 0 failed** (43 of them new integration tests) |
| `npm run typecheck` | exit 0 |
| `npm run legacy:verify` | 23 files match the manifest |
| `npm run build` | exit 0; JS 608 kB (189 kB gzip) after adding Dexie and Zod; Vite warns the single chunk is over 500 kB |
| `npm run test:e2e` | **3 passed** in Microsoft Edge against `vite preview` (production build, CSP on) |

### What the tests prove

Integration (real repositories and Dexie on fake-indexeddb; "restart" = close all connections and reopen):

- **Restart**: engagement (label decrypts), snapshot, run, 14 findings, settings and activity are all
  there after reopening and unlocking; a reloaded snapshot analyses to the same findings.
- **At rest**: with defaults, a dump of every store contains none of the 224 source values, the
  engagement label, the source file label or the passphrase. With retention on, still none in clear,
  and the retained source and key decrypt after restart and reproduce the stored tokens.
- **Atomic imports**: a dataset with a duplicate payment ID, an impossible date and an orphan vendor is
  rejected with all three errors and no store changes. A forced collision on the 50th payment insert
  rolls back the import, entities and attributes already written. A missing engagement or a run
  against another engagement's snapshot is refused.
- **Runs**: changing thresholds stops the old run being presented as current; both runs and both rule
  sets stay stored; a new snapshot has no run until analysed.
- **Isolation**: two engagements with the same source IDs (V105, P0001) do not collide; deleting one
  removes all of its records in every store and none of the other's.
- **Retention**: a 30-day copy survives day 29 and is purged with its key on day 31, with an activity
  event; "until deleted" never expires and can be deleted on request.
- **Migration**: a version 1 database with real data upgrades to version 2 (new field backfilled, new
  store and index usable, nothing lost). A migration that throws is rolled back, reported as
  `migration-failed`, and the version 1 data is byte-for-byte unchanged and still upgradable later.
  A database newer than the app is refused unmodified. A browser that denies IndexedDB gets an
  explanation.
- **Backup/restore**: restore into a separate empty profile reproduces every table count, the
  engagement label, snapshot, run, findings, thresholds, settings and retained source, and unlocks
  after its own restart; the restored snapshot re-analyses to the stored result. The file shows only
  versions, date, counts and KDF parameters in clear. Wrong passphrase, one altered ciphertext
  character, truncation, any altered header field, a newer format or schema version, a non-backup
  file, an internally inconsistent backup and a non-empty target each fail with nothing written.
- **Locking**: inactivity timer locks, activity restarts it, locking drops the key and notifies.

End to end in Edge (production build):

1. Create workspace → sample engagement → load → protect with encrypted source copy → analyse →
   **reload** → wrong passphrase refused → unlock → same 14 findings and figures, evidence read from
   the stored snapshot, retained source opens → **Lock** closes the app → **backup** downloads → the
   file has no identifiers in clear → **second, empty browser context**: wrong passphrase changes
   nothing, right passphrase restores → findings and activity present → survives its own reload.
2. **Full browser restart** on a persistent profile directory: data is there after the browser
   process exits and starts again; unretained source is, correctly, gone.
3. Gateway after the storage change: answer, timed reveal, activity event; a dump of every IndexedDB
   store contains no prompt text, vault value, engagement label or passphrase; lock clears the draft.

All three assert zero requests to any other origin, and the first two assert zero console errors.

### Defects found by this phase's own tests

- Dexie 4 opens a database created by a later schema version instead of failing. An older app would
  have worked on newer data. `openDb` now compares versions and refuses, without writing.
- The live-query hook returned a new object on every render, causing an infinite re-render loop that
  froze the page (caught by the first Playwright run, invisible to the unit tests).
- A missing favicon produced a console error on every load; an inline icon was added.

### Known-issue status changes

| ID | Change in Phase 2 |
| --- | --- |
| KI-X02 no persistence | Fixed. |
| KI-V10 stale state | Stronger: results are bound to an immutable snapshot and an exact rule set in the database; a differing in-memory source is flagged against the stored digest. Package handoff still Phase 3. |
| KI-V05 key handling | HMAC key is random, per engagement, in memory; stored only on opt-in and only encrypted. |
| KI-V07 validation | Structural validation now blocks the commit. Column mapping and row-level error reports: Phase 3. |
| KI-G10 reveal | Reveal exists only in an unlocked workspace, reverts after 60 seconds, and writes a metadata event. Still a display control, labelled as such. |

### Limits of Phase 2

- **No passphrase change and no recovery.** Changing it means: back up, delete local data, restore.
- **Restore accepts only backups of the current schema version (2).** Upgrading an older backup during
  restore is not implemented (no older backups exist yet).
- **Backups are built in memory as one JSON document**; not suitable for very large workspaces. Size
  limits and streaming belong with the Phase 6 benchmarks.
- **Quota exhaustion is mapped to a message but was not provoked in a test.** Persistence refusal
  (`navigator.storage.persist()` returning false) shows a message; observed "not persisted" in the
  pane, not automated.
- **Only one tab is assumed.** A second tab works on the same database but has its own lock state and
  memory; cross-tab locking is not implemented.
- **The 60-second reveal timeout and the inactivity lock in a real browser are not covered by automated
  tests** (the lock timer is unit-tested with injected timers).
- **Still only the synthetic sample can be loaded**, and workpapers cannot be recorded (Phases 3, 4).
- **KDF is PBKDF2**, the strongest password KDF Web Crypto offers; a memory-hard KDF would need a
  third-party implementation and a review, so it was not added.
- No accessibility audit yet; the new screens follow the same labelled-form pattern as Phase 1.

---

## Demo readiness work (2026-11-16, after Phase 2)

Requested by the user ahead of a presentation, with limited usage budget: make one module
presentable end to end, replace the theme, and write a presentation guide. Phase 3 was not started.

### What changed

- **Theme "ledger and seal"**: deep assurance teal brand and green-tinted ink neutrals on a paper
  background, defined once in `src/index.css` by redefining the `indigo-*` (brand) and `slate-*`
  (neutral) scales that components already use. Severity and success colours are unchanged and
  remain reserved for risk and outcomes. Follow-up worth doing: rename the utility classes to
  semantic names (`brand-*`, `ink-*`) so the code no longer says "indigo".
- **Finding review (from Phase 4)**: `src/domain/vendor/review.ts` (six statuses; a settling
  decision needs a conclusion of at least 15 characters), `repos.workpapers` (one record per
  engagement + finding fingerprint, revision counter, notes and conclusion AES-GCM encrypted,
  activity event in the same transaction), review form in the finding details panel, review column
  in the findings table. `WorkpaperRecord` gained unindexed fields; no schema version change.
- **Workpapers page and export**: counts by status, table of findings with conclusions, and
  `src/services/workpaper/exportHtml.ts`, a self-contained HTML workpaper with scope, thresholds,
  engine/rule-set/token versions, evidence references, statuses, notes and conclusions, everything
  HTML-escaped.
- **Backup**: reviews are carried in the backup and re-encrypted under the new workspace key on restore.
- Wording: internal "Phase N" references removed from screens. `DEMO_SCRIPT.md` added.

### Commands and results

| Command | Result |
| --- | --- |
| `npm test` | 17 files, **266 passed, 19 todo, 0 failed** |
| `npm run typecheck`, `npm run legacy:verify` | pass |
| `npm run test:e2e` | **3 passed** in Edge. The persistence test now covers the whole chain: protect → analyse → select finding → review (missing conclusion refused, then saved) → reload → Workpapers shows it → export workpaper (downloaded file contains the conclusion and 14 finding rows) → backup → restore in a fresh context → the review and its activity event are there |

New integration tests (`tests/integration/workpapers.test.ts`): review rules; invalid review and
missing engagement refused; revisions and activity text; notes not readable in a database dump;
survive restart; survive backup and restore under a new key; export content and HTML escaping.

### Not done / not tested

- The new theme was checked by eye on the setup screen and the AI Gateway page only. Contrast
  ratios quoted in `src/index.css` were calculated, not measured with a tool on rendered screens.
- No relationship graph, no saved filters or column controls, no CSV export of findings.
- Reviews carry across runs by fingerprint by design, but no test yet runs a second analysis and
  checks the carry-over.
- The export is HTML only (print to PDF from the browser).

### Next bounded task

Phase 3, step 1 (after confirming D4, the readable-label default): protected package format v1 with
a Zod schema and manifest (package and schema versions, normalisation and token versions, key
reference, row counts, digest), export from a stored snapshot, and import into a workspace as a
`package` snapshot with a contents preview. Exit check: in Playwright, client context exports a
package; a second empty context imports it, analyses it and shows the 14 findings, and a dump of
that context's database and the package file contain no source values and no key. Step 2: CSV
import wizard (Papa Parse; file-to-dataset assignment, column mapping, validation with row-level
errors and a downloadable error CSV, unknown columns dropped by default). Step 3: legacy 16-hex
package import through a separate, labelled path.
