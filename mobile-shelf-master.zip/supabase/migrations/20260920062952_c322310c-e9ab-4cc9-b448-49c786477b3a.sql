CREATE TYPE public.app_role AS ENUM ('admin', 'store_executive', 'manager', 'owner');
CREATE TYPE public.requisition_status AS ENUM ('draft', 'submitted', 'manager_approved', 'owner_approval_pending', 'approved', 'rejected', 'sent_back');
CREATE TYPE public.transaction_type AS ENUM ('receipt', 'sale', 'transfer', 'adjustment');

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  full_name text NOT NULL,
  phone text,
  avatar_url text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

CREATE POLICY "profiles_read_own_or_admin" ON public.profiles FOR SELECT TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "profiles_insert_own_or_admin" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "profiles_update_own_or_admin" ON public.profiles FOR UPDATE TO authenticated USING (id = auth.uid() OR public.has_role(auth.uid(), 'admin')) WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "profiles_delete_admin" ON public.profiles FOR DELETE TO authenticated USING (public.has_role(auth.uid(), 'admin'));
CREATE POLICY "roles_read_own_or_admin" ON public.user_roles FOR SELECT TO authenticated USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'admin'));
CREATE POLICY "roles_admin_manage" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL UNIQUE, status boolean NOT NULL DEFAULT true,
  created_by uuid, modified_by uuid, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories_read" ON public.categories FOR SELECT TO authenticated USING (true);
CREATE POLICY "categories_admin_manage" ON public.categories FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.suppliers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), supplier_name text NOT NULL, gst_number text, address text, contact_person text, email text, mobile_no text, status boolean NOT NULL DEFAULT true,
  created_by uuid, modified_by uuid, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.suppliers TO authenticated;
GRANT ALL ON public.suppliers TO service_role;
ALTER TABLE public.suppliers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "suppliers_read" ON public.suppliers FOR SELECT TO authenticated USING (true);
CREATE POLICY "suppliers_admin_manage" ON public.suppliers FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.warehouses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), name text NOT NULL UNIQUE, status boolean NOT NULL DEFAULT true,
  created_by uuid, modified_by uuid, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.warehouses TO authenticated;
GRANT ALL ON public.warehouses TO service_role;
ALTER TABLE public.warehouses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "warehouses_read" ON public.warehouses FOR SELECT TO authenticated USING (true);
CREATE POLICY "warehouses_admin_manage" ON public.warehouses FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), item_code text NOT NULL UNIQUE, item_name text NOT NULL, brand text NOT NULL, model text, imei_tracking_required boolean NOT NULL DEFAULT false,
  category_id uuid REFERENCES public.categories(id), unit text NOT NULL DEFAULT 'Unit', purchase_price numeric(12,2) NOT NULL DEFAULT 0, selling_price numeric(12,2) NOT NULL DEFAULT 0, reorder_level integer NOT NULL DEFAULT 0, status boolean NOT NULL DEFAULT true,
  created_by uuid, modified_by uuid, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (purchase_price >= 0 AND selling_price >= 0 AND reorder_level >= 0)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.items TO authenticated;
GRANT ALL ON public.items TO service_role;
ALTER TABLE public.items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "items_read" ON public.items FOR SELECT TO authenticated USING (true);
CREATE POLICY "items_admin_manage" ON public.items FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TABLE public.inventory_balances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), item_id uuid NOT NULL REFERENCES public.items(id) ON DELETE CASCADE, warehouse_id uuid NOT NULL REFERENCES public.warehouses(id) ON DELETE CASCADE, quantity integer NOT NULL DEFAULT 0,
  updated_at timestamptz NOT NULL DEFAULT now(), UNIQUE(item_id, warehouse_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.inventory_balances TO authenticated;
GRANT ALL ON public.inventory_balances TO service_role;
ALTER TABLE public.inventory_balances ENABLE ROW LEVEL SECURITY;
CREATE POLICY "inventory_read" ON public.inventory_balances FOR SELECT TO authenticated USING (true);
CREATE POLICY "inventory_operate" ON public.inventory_balances FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'store_executive')) WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'store_executive'));

CREATE TABLE public.stock_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), transaction_type public.transaction_type NOT NULL, item_id uuid NOT NULL REFERENCES public.items(id), source_warehouse_id uuid REFERENCES public.warehouses(id), destination_warehouse_id uuid REFERENCES public.warehouses(id), supplier_id uuid REFERENCES public.suppliers(id),
  invoice_number text, invoice_date date, customer_name text, quantity integer NOT NULL, unit_rate numeric(12,2) NOT NULL DEFAULT 0, gst_percent numeric(5,2) NOT NULL DEFAULT 0, serial_imei text, reason text, approval_status text NOT NULL DEFAULT 'approved',
  created_by uuid NOT NULL, approved_by uuid, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now(), CHECK (quantity > 0)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.stock_transactions TO authenticated;
GRANT ALL ON public.stock_transactions TO service_role;
ALTER TABLE public.stock_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "transactions_read" ON public.stock_transactions FOR SELECT TO authenticated USING (true);
CREATE POLICY "transactions_create" ON public.stock_transactions FOR INSERT TO authenticated WITH CHECK (created_by = auth.uid() AND (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'store_executive')));
CREATE POLICY "transactions_approve" ON public.stock_transactions FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'owner')) WITH CHECK (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'owner'));

CREATE TABLE public.requisitions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), requisition_number text NOT NULL UNIQUE, requested_by uuid NOT NULL, warehouse_id uuid REFERENCES public.warehouses(id), status public.requisition_status NOT NULL DEFAULT 'draft', total_value numeric(14,2) NOT NULL DEFAULT 0, notes text,
  manager_id uuid, manager_note text, owner_id uuid, owner_note text, submitted_at timestamptz, approved_at timestamptz, created_at timestamptz NOT NULL DEFAULT now(), updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.requisitions TO authenticated;
GRANT ALL ON public.requisitions TO service_role;
ALTER TABLE public.requisitions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "requisitions_read" ON public.requisitions FOR SELECT TO authenticated USING (requested_by = auth.uid() OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'owner'));
CREATE POLICY "requisitions_create" ON public.requisitions FOR INSERT TO authenticated WITH CHECK (requested_by = auth.uid());
CREATE POLICY "requisitions_update" ON public.requisitions FOR UPDATE TO authenticated USING (requested_by = auth.uid() OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'owner')) WITH CHECK (requested_by = auth.uid() OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'owner'));
CREATE POLICY "requisitions_delete_draft" ON public.requisitions FOR DELETE TO authenticated USING (requested_by = auth.uid() AND status = 'draft');

CREATE TABLE public.requisition_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), requisition_id uuid NOT NULL REFERENCES public.requisitions(id) ON DELETE CASCADE, item_id uuid NOT NULL REFERENCES public.items(id), quantity integer NOT NULL, estimated_rate numeric(12,2) NOT NULL DEFAULT 0, created_at timestamptz NOT NULL DEFAULT now(), CHECK (quantity > 0)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.requisition_items TO authenticated;
GRANT ALL ON public.requisition_items TO service_role;
ALTER TABLE public.requisition_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "requisition_items_read" ON public.requisition_items FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.requisitions r WHERE r.id = requisition_id AND (r.requested_by = auth.uid() OR public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'owner'))));
CREATE POLICY "requisition_items_manage" ON public.requisition_items FOR ALL TO authenticated USING (EXISTS (SELECT 1 FROM public.requisitions r WHERE r.id = requisition_id AND r.requested_by = auth.uid() AND r.status IN ('draft','sent_back'))) WITH CHECK (EXISTS (SELECT 1 FROM public.requisitions r WHERE r.id = requisition_id AND r.requested_by = auth.uid() AND r.status IN ('draft','sent_back')));

CREATE TABLE public.activity_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(), user_id uuid NOT NULL, action text NOT NULL, entity_type text NOT NULL, entity_id uuid, details jsonb NOT NULL DEFAULT '{}'::jsonb, created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT ON public.activity_logs TO authenticated;
GRANT ALL ON public.activity_logs TO service_role;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "logs_create" ON public.activity_logs FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "logs_read_admin_owner" ON public.activity_logs FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin') OR public.has_role(auth.uid(), 'owner'));

CREATE OR REPLACE FUNCTION public.touch_updated_at() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;
CREATE TRIGGER touch_profiles BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_categories BEFORE UPDATE ON public.categories FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_suppliers BEFORE UPDATE ON public.suppliers FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_warehouses BEFORE UPDATE ON public.warehouses FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_items BEFORE UPDATE ON public.items FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_stock_transactions BEFORE UPDATE ON public.stock_transactions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
CREATE TRIGGER touch_requisitions BEFORE UPDATE ON public.requisitions FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

CREATE OR REPLACE FUNCTION public.recalculate_requisition_total() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target_id uuid;
BEGIN
  target_id := COALESCE(NEW.requisition_id, OLD.requisition_id);
  UPDATE public.requisitions SET total_value = COALESCE((SELECT SUM(quantity * estimated_rate) FROM public.requisition_items WHERE requisition_id = target_id), 0) WHERE id = target_id;
  RETURN COALESCE(NEW, OLD);
END; $$;
CREATE TRIGGER recalculate_requisition_total AFTER INSERT OR UPDATE OR DELETE ON public.requisition_items FOR EACH ROW EXECUTE FUNCTION public.recalculate_requisition_total();

CREATE INDEX idx_items_search ON public.items (item_name, brand, model);
CREATE INDEX idx_stock_imei ON public.stock_transactions (serial_imei);
CREATE INDEX idx_stock_invoice ON public.stock_transactions (invoice_number);
CREATE INDEX idx_requisitions_status ON public.requisitions (status);

INSERT INTO public.categories (name) VALUES ('Mobile Phone'), ('Tablet'), ('Smart Watch'), ('Accessories'), ('Earbuds'), ('Charger'), ('Power Bank');
INSERT INTO public.warehouses (name) VALUES ('Main Store'), ('Display Store'), ('Godown');