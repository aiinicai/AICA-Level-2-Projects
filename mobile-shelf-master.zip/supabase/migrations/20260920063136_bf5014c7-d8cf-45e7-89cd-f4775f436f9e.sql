CREATE OR REPLACE FUNCTION public.apply_stock_transaction() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.approval_status <> 'approved' OR (TG_OP = 'UPDATE' AND OLD.approval_status = 'approved') THEN
    RETURN NEW;
  END IF;

  IF NEW.transaction_type = 'receipt' THEN
    IF NEW.destination_warehouse_id IS NULL THEN RAISE EXCEPTION 'Destination warehouse is required'; END IF;
    INSERT INTO public.inventory_balances (item_id, warehouse_id, quantity)
    VALUES (NEW.item_id, NEW.destination_warehouse_id, NEW.quantity)
    ON CONFLICT (item_id, warehouse_id) DO UPDATE SET quantity = public.inventory_balances.quantity + EXCLUDED.quantity, updated_at = now();
  ELSIF NEW.transaction_type IN ('sale', 'adjustment') THEN
    IF NEW.source_warehouse_id IS NULL THEN RAISE EXCEPTION 'Source warehouse is required'; END IF;
    UPDATE public.inventory_balances SET quantity = quantity - NEW.quantity, updated_at = now()
    WHERE item_id = NEW.item_id AND warehouse_id = NEW.source_warehouse_id AND quantity >= NEW.quantity;
    IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient stock'; END IF;
  ELSIF NEW.transaction_type = 'transfer' THEN
    IF NEW.source_warehouse_id IS NULL OR NEW.destination_warehouse_id IS NULL OR NEW.source_warehouse_id = NEW.destination_warehouse_id THEN
      RAISE EXCEPTION 'Different source and destination warehouses are required';
    END IF;
    UPDATE public.inventory_balances SET quantity = quantity - NEW.quantity, updated_at = now()
    WHERE item_id = NEW.item_id AND warehouse_id = NEW.source_warehouse_id AND quantity >= NEW.quantity;
    IF NOT FOUND THEN RAISE EXCEPTION 'Insufficient stock'; END IF;
    INSERT INTO public.inventory_balances (item_id, warehouse_id, quantity)
    VALUES (NEW.item_id, NEW.destination_warehouse_id, NEW.quantity)
    ON CONFLICT (item_id, warehouse_id) DO UPDATE SET quantity = public.inventory_balances.quantity + EXCLUDED.quantity, updated_at = now();
  END IF;
  RETURN NEW;
END; $$;
REVOKE ALL ON FUNCTION public.apply_stock_transaction() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.apply_stock_transaction() TO service_role;
CREATE TRIGGER apply_stock_on_insert AFTER INSERT ON public.stock_transactions FOR EACH ROW EXECUTE FUNCTION public.apply_stock_transaction();
CREATE TRIGGER apply_stock_on_approval AFTER UPDATE OF approval_status ON public.stock_transactions FOR EACH ROW EXECUTE FUNCTION public.apply_stock_transaction();