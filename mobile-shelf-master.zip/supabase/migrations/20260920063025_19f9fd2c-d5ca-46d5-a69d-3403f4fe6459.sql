CREATE SCHEMA IF NOT EXISTS private;
REVOKE ALL ON SCHEMA private FROM PUBLIC;
GRANT USAGE ON SCHEMA private TO authenticated, service_role;

CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;
REVOKE ALL ON FUNCTION private.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated, service_role;

ALTER POLICY "profiles_read_own_or_admin" ON public.profiles USING (id = auth.uid() OR private.has_role(auth.uid(), 'admin'));
ALTER POLICY "profiles_insert_own_or_admin" ON public.profiles WITH CHECK (id = auth.uid() OR private.has_role(auth.uid(), 'admin'));
ALTER POLICY "profiles_update_own_or_admin" ON public.profiles USING (id = auth.uid() OR private.has_role(auth.uid(), 'admin')) WITH CHECK (id = auth.uid() OR private.has_role(auth.uid(), 'admin'));
ALTER POLICY "profiles_delete_admin" ON public.profiles USING (private.has_role(auth.uid(), 'admin'));
ALTER POLICY "roles_read_own_or_admin" ON public.user_roles USING (user_id = auth.uid() OR private.has_role(auth.uid(), 'admin'));
ALTER POLICY "roles_admin_manage" ON public.user_roles USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));
ALTER POLICY "categories_admin_manage" ON public.categories USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));
ALTER POLICY "suppliers_admin_manage" ON public.suppliers USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));
ALTER POLICY "warehouses_admin_manage" ON public.warehouses USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));
ALTER POLICY "items_admin_manage" ON public.items USING (private.has_role(auth.uid(), 'admin')) WITH CHECK (private.has_role(auth.uid(), 'admin'));
ALTER POLICY "inventory_operate" ON public.inventory_balances USING (private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'store_executive')) WITH CHECK (private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'store_executive'));
ALTER POLICY "transactions_create" ON public.stock_transactions WITH CHECK (created_by = auth.uid() AND (private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'store_executive')));
ALTER POLICY "transactions_approve" ON public.stock_transactions USING (private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'manager') OR private.has_role(auth.uid(), 'owner')) WITH CHECK (private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'manager') OR private.has_role(auth.uid(), 'owner'));
ALTER POLICY "requisitions_read" ON public.requisitions USING (requested_by = auth.uid() OR private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'manager') OR private.has_role(auth.uid(), 'owner'));
ALTER POLICY "requisitions_update" ON public.requisitions USING (requested_by = auth.uid() OR private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'manager') OR private.has_role(auth.uid(), 'owner')) WITH CHECK (requested_by = auth.uid() OR private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'manager') OR private.has_role(auth.uid(), 'owner'));
ALTER POLICY "requisition_items_read" ON public.requisition_items USING (EXISTS (SELECT 1 FROM public.requisitions r WHERE r.id = requisition_id AND (r.requested_by = auth.uid() OR private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'manager') OR private.has_role(auth.uid(), 'owner'))));
ALTER POLICY "logs_read_admin_owner" ON public.activity_logs USING (private.has_role(auth.uid(), 'admin') OR private.has_role(auth.uid(), 'owner'));

REVOKE ALL ON FUNCTION public.recalculate_requisition_total() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.recalculate_requisition_total() TO service_role;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon, authenticated;
DROP FUNCTION public.has_role(uuid, public.app_role);