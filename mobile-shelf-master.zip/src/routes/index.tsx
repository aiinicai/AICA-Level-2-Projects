import { createFileRoute, useRouter } from "@tanstack/react-router";
import {
  AlertTriangle,
  ArrowDownToLine,
  ArrowRightLeft,
  BarChart3,
  Bell,
  Boxes,
  Check,
  ChevronRight,
  ClipboardCheck,
  FileDown,
  FileSpreadsheet,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  PackagePlus,
  Plus,
  Search,
  ShoppingCart,
  Sun,
  Truck,
  Users,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import { claimInitialAdmin, createStaffUser } from "@/lib/admin.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Command Center — ABC & Co Inventory" },
      { name: "description", content: "Manage stock, sales, requisitions and approvals across ABC & Co stores." },
      { property: "og:title", content: "ABC & Co Inventory Command Center" },
      { property: "og:description", content: "Manage stock, sales, requisitions and approvals across ABC & Co stores." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: InventoryApp,
});

type Role = "admin" | "store_executive" | "manager" | "owner";
type View = "dashboard" | "inventory" | "transactions" | "approvals" | "reports" | "users";
type Item = { id: string; item_code: string; item_name: string; brand: string; model: string | null; purchase_price: number; selling_price: number; reorder_level: number; imei_tracking_required: boolean };
type Balance = { id: string; quantity: number; item_id: string; warehouse_id: string; items: Item | null; warehouses: { name: string } | null };
type Requisition = { id: string; requisition_number: string; status: string; total_value: number; notes: string | null; created_at: string };
type Transaction = { id: string; transaction_type: string; invoice_number: string | null; quantity: number; unit_rate: number; serial_imei: string | null; created_at: string; items: { item_name: string } | null };

const navItems: { id: View; label: string; icon: typeof LayoutDashboard }[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "inventory", label: "Inventory", icon: Boxes },
  { id: "transactions", label: "Stock In / Out", icon: ArrowRightLeft },
  { id: "approvals", label: "Approvals", icon: ClipboardCheck },
  { id: "reports", label: "Reports", icon: BarChart3 },
  { id: "users", label: "Users", icon: Users },
];

const money = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });

function InventoryApp() {
  const router = useRouter();
  const [sessionReady, setSessionReady] = useState(false);
  const [userId, setUserId] = useState<string | null>(null);
  const [role, setRole] = useState<Role | null>(null);
  const [name, setName] = useState("Team member");
  const [view, setView] = useState<View>("dashboard");
  const [mobileNav, setMobileNav] = useState(false);
  const [dark, setDark] = useState(false);
  const [query, setQuery] = useState("");
  const [items, setItems] = useState<Item[]>([]);
  const [balances, setBalances] = useState<Balance[]>([]);
  const [requisitions, setRequisitions] = useState<Requisition[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [warehouses, setWarehouses] = useState<{ id: string; name: string }[]>([]);
  const [suppliers, setSuppliers] = useState<{ id: string; supplier_name: string }[]>([]);
  const [dialog, setDialog] = useState<"item" | "stock" | "requisition" | "user" | null>(null);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getUser().then(({ data }) => {
      if (!mounted) return;
      setUserId(data.user?.id ?? null);
      setName(data.user?.user_metadata?.full_name ?? data.user?.email?.split("@")[0] ?? "Team member");
      setSessionReady(true);
    });
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      if (event !== "SIGNED_IN" && event !== "SIGNED_OUT" && event !== "USER_UPDATED") return;
      setUserId(session?.user.id ?? null);
      setName(session?.user.user_metadata?.full_name ?? session?.user.email?.split("@")[0] ?? "Team member");
      router.invalidate();
    });
    return () => { mounted = false; data.subscription.unsubscribe(); };
  }, [router]);

  useEffect(() => {
    if (!userId) return;
    void loadData(userId);
  }, [userId]);

  async function loadData(id: string) {
    const roleResult = await supabase.from("user_roles").select("role").eq("user_id", id).limit(1).maybeSingle();
    let nextRole = roleResult.data?.role as Role | undefined;
    if (!nextRole) {
      const claimed = await claimInitialAdmin();
      nextRole = claimed?.role as Role | undefined;
    }
    setRole(nextRole ?? null);
    await supabase.from("profiles").upsert({ id, full_name: name }, { onConflict: "id" });
    const [itemResult, balanceResult, reqResult, txResult, warehouseResult, supplierResult] = await Promise.all([
      supabase.from("items").select("*").order("item_name"),
      supabase.from("inventory_balances").select("*, items(*), warehouses(name)").order("quantity"),
      supabase.from("requisitions").select("*").order("created_at", { ascending: false }).limit(30),
      supabase.from("stock_transactions").select("id,transaction_type,invoice_number,quantity,unit_rate,serial_imei,created_at,items(item_name)").order("created_at", { ascending: false }).limit(30),
      supabase.from("warehouses").select("id,name").order("name"),
      supabase.from("suppliers").select("id,supplier_name").order("supplier_name"),
    ]);
    if (itemResult.data) setItems(itemResult.data as Item[]);
    if (balanceResult.data) setBalances(balanceResult.data as unknown as Balance[]);
    if (reqResult.data) setRequisitions(reqResult.data as Requisition[]);
    if (txResult.data) setTransactions(txResult.data as unknown as Transaction[]);
    if (warehouseResult.data) setWarehouses(warehouseResult.data);
    if (supplierResult.data) setSuppliers(supplierResult.data);
  }

  if (!sessionReady) return <div className="grid min-h-screen place-items-center bg-background font-display text-2xl font-extrabold">ABC & Co</div>;
  if (!userId) return <AuthScreen />;

  const canApprove = role === "admin" || role === "manager" || role === "owner";
  const canManageMasters = role === "admin";
  const inventoryValue = balances.reduce((sum, row) => sum + row.quantity * Number(row.items?.purchase_price ?? 0), 0);
  const stockQty = balances.reduce((sum, row) => sum + row.quantity, 0);
  const lowStock = balances.filter((row) => row.quantity <= Number(row.items?.reorder_level ?? 0));
  const pending = requisitions.filter((row) => ["submitted", "owner_approval_pending", "manager_approved"].includes(row.status));
  const filteredBalances = balances.filter((row) => `${row.items?.item_name} ${row.items?.brand} ${row.items?.item_code} ${row.warehouses?.name}`.toLowerCase().includes(query.toLowerCase()));

  async function signOut() {
    await supabase.auth.signOut();
    setUserId(null);
    setRole(null);
  }

  async function approveRequisition(req: Requisition, action: "approve" | "reject" | "send_back") {
    if (!canApprove || !userId) return;
    const status = action === "reject" ? "rejected" : action === "send_back" ? "sent_back" : req.total_value > 50000 && role !== "owner" ? "owner_approval_pending" : "approved";
    const update = role === "owner" ? { status, owner_id: userId, approved_at: status === "approved" ? new Date().toISOString() : null } : { status, manager_id: userId, approved_at: status === "approved" ? new Date().toISOString() : null };
    const { error } = await supabase.from("requisitions").update(update).eq("id", req.id);
    if (error) return toast.error(error.message);
    toast.success(`Requisition ${status.replaceAll("_", " ")}`);
    await loadData(userId);
  }

  function exportCsv() {
    const rows = [["Item Code", "Item", "Brand", "Warehouse", "Quantity", "Purchase Price", "Stock Value"], ...filteredBalances.map((row) => [row.items?.item_code ?? "", row.items?.item_name ?? "", row.items?.brand ?? "", row.warehouses?.name ?? "", row.quantity, Number(row.items?.purchase_price ?? 0), row.quantity * Number(row.items?.purchase_price ?? 0)])];
    const blob = new Blob([rows.map((r) => r.map((v) => `"${String(v).replaceAll('"', '""')}"`).join(",")).join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a"); anchor.href = url; anchor.download = "abc-stock-report.csv"; anchor.click(); URL.revokeObjectURL(url);
  }

  return (
    <div className={dark ? "dark" : ""}>
      <div className="min-h-screen bg-background text-foreground font-body text-sm antialiased md:flex">
        <aside className={`${mobileNav ? "flex" : "hidden"} fixed inset-y-0 left-0 z-40 w-64 flex-col border-r-2 border-line bg-background md:sticky md:top-0 md:flex md:h-screen`}>
          <div className="flex items-center gap-2.5 border-b-2 border-line px-5 py-4">
            <div className="grid size-9 place-items-center rounded-lg bg-foreground font-display text-base font-extrabold text-background">A</div>
            <div className="leading-tight"><div className="font-display text-[15px] font-extrabold">ABC & Co</div><div className="text-[10px] font-medium text-muted-foreground">Mobile Shop</div></div>
            <Button variant="ghost" size="icon" className="ml-auto md:hidden" onClick={() => setMobileNav(false)} aria-label="Close menu"><X /></Button>
          </div>
          <nav className="flex-1 space-y-1 px-3 py-4">
            <div className="px-3 pb-1 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Workspace</div>
            {navItems.filter((item) => item.id !== "users" || canManageMasters).map(({ id, label, icon: Icon }) => (
              <Button key={id} variant={view === id ? "default" : "ghost"} className="w-full justify-start rounded-xl shadow-none" onClick={() => { setView(id); setMobileNav(false); }}><Icon />{label}{id === "approvals" && pending.length > 0 && <span className="ml-auto rounded-full bg-alert px-2 text-[10px] font-bold text-alert-foreground">{pending.length}</span>}</Button>
            ))}
            <div className="px-3 pb-1 pt-5 text-[10px] font-semibold uppercase tracking-widest text-muted-foreground">Quick actions</div>
            <Button variant="ghost" className="w-full justify-start rounded-xl" onClick={() => setDialog("stock")}><PackagePlus />Stock receipt</Button>
            <Button variant="ghost" className="w-full justify-start rounded-xl" onClick={() => setDialog("stock")}><ShoppingCart />Stock sale</Button>
            <Button variant="ghost" className="w-full justify-start rounded-xl" onClick={() => setDialog("requisition")}><ClipboardCheck />Requisition</Button>
          </nav>
          <div className="m-3 border-2 border-line bg-highlight p-4">
            <div className="text-[10px] font-bold uppercase tracking-wider">{role?.replaceAll("_", " ") ?? "Awaiting role"}</div>
            <div className="mt-1 font-display text-lg font-extrabold leading-tight">{name}</div>
            <Button variant="ghost" size="sm" className="mt-2 px-0" onClick={signOut}><LogOut />Sign out</Button>
          </div>
        </aside>
        {mobileNav && <button aria-label="Close navigation" className="fixed inset-0 z-30 bg-overlay md:hidden" onClick={() => setMobileNav(false)} />}

        <main className="min-w-0 flex-1">
          <header className="sticky top-0 z-20 flex items-center gap-3 border-b-2 border-line bg-background/95 px-4 py-3 backdrop-blur md:px-8">
            <Button variant="default" size="icon" className="md:hidden" onClick={() => setMobileNav(true)} aria-label="Open menu"><Menu /></Button>
            <div className="hidden sm:block"><div className="text-[11px] font-medium text-muted-foreground">Good morning, {name.split(" ")[0]}</div><div className="font-display text-lg font-extrabold leading-tight">{navItems.find((n) => n.id === view)?.label}</div></div>
            <label className="ml-auto flex h-10 min-w-0 items-center gap-2 rounded-xl border-2 border-line bg-card px-3 md:w-80"><Search className="size-4 text-muted-foreground"/><input value={query} onChange={(event) => setQuery(event.target.value)} className="min-w-0 flex-1 bg-transparent text-sm outline-none" placeholder="Search items, IMEI, invoice…" /></label>
            <Button variant="outline" size="icon" onClick={() => setDark((value) => !value)} aria-label="Toggle color theme">{dark ? <Sun /> : <Moon />}</Button>
            <Button size="icon" className="bg-brand text-brand-foreground hover:bg-brand/90" onClick={() => setDialog(canManageMasters ? "item" : "stock")} aria-label="Create new"><Plus /></Button>
          </header>

          <div className="space-y-6 p-4 md:p-8">
            {view === "dashboard" && <Dashboard inventoryValue={inventoryValue} stockQty={stockQty} lowStock={lowStock} pending={pending} transactions={transactions} canApprove={canApprove} approve={approveRequisition} />}
            {view === "inventory" && <InventoryView balances={filteredBalances} canManage={canManageMasters} onAdd={() => setDialog("item")} />}
            {view === "transactions" && <TransactionsView rows={transactions} onAdd={() => setDialog("stock")} />}
            {view === "approvals" && <ApprovalsView rows={requisitions} canApprove={canApprove} approve={approveRequisition} onAdd={() => setDialog("requisition")} />}
            {view === "reports" && <ReportsView inventoryValue={inventoryValue} stockQty={stockQty} lowStock={lowStock.length} exportCsv={exportCsv} />}
            {view === "users" && canManageMasters && <UsersView onAdd={() => setDialog("user")} />}
          </div>
        </main>
      </div>
      {dialog && <ActionDialog type={dialog} items={items} warehouses={warehouses} suppliers={suppliers} userId={userId} close={() => setDialog(null)} refresh={() => loadData(userId)} />}
    </div>
  );
}

function AuthScreen() {
  const [mode, setMode] = useState<"signin" | "signup" | "forgot">("signin");
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true);
    const form = new FormData(event.currentTarget); const email = String(form.get("email")); const password = String(form.get("password")); const fullName = String(form.get("fullName") ?? "");
    if (mode === "forgot") {
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
      setBusy(false); return error ? toast.error(error.message) : toast.success("Password reset link sent.");
    }
    if (mode === "signup") {
      const { error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { full_name: fullName } } });
      setBusy(false); return error ? toast.error(error.message) : toast.success("Check your email to confirm your account.");
    }
    const { error } = await supabase.auth.signInWithPassword({ email, password }); setBusy(false); if (error) toast.error(error.message);
  }
  async function google() {
    const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin });
    if (result.error) toast.error(result.error.message);
  }
  return <div className="grid min-h-screen bg-background lg:grid-cols-[1.1fr_.9fr]">
    <section className="hidden border-r-2 border-line bg-highlight p-12 lg:flex lg:flex-col lg:justify-between">
      <div className="flex items-center gap-3"><div className="grid size-11 place-items-center rounded-lg bg-foreground font-display text-xl font-extrabold text-background">A</div><div><div className="font-display text-xl font-extrabold">ABC & Co</div><div className="text-xs text-muted-foreground">Mobile Shop Operations</div></div></div>
      <div><div className="mb-6 inline-flex items-center gap-2 rounded-full border-2 border-line bg-background px-3 py-1 text-xs font-bold"><span className="size-2 rounded-full bg-success"/>Secure inventory control</div><h1 className="max-w-xl font-display text-6xl font-extrabold leading-[.96]">Every device.<br/>Every approval.<br/><span className="text-brand">One command center.</span></h1><p className="mt-6 max-w-lg text-base text-muted-foreground">Track IMEI-level stock, control warehouse movement, and keep every retail decision accountable.</p></div>
      <p className="text-xs font-medium text-muted-foreground">Inventory · Sales · Approvals · Reports</p>
    </section>
    <section className="flex items-center justify-center p-5"><div className="w-full max-w-sm">
      <div className="mb-8 lg:hidden"><div className="font-display text-2xl font-extrabold">ABC & Co</div><div className="text-xs text-muted-foreground">Mobile Shop Operations</div></div>
      <h2 className="font-display text-3xl font-extrabold">{mode === "signin" ? "Welcome back" : mode === "signup" ? "Create account" : "Reset password"}</h2><p className="mt-2 text-sm text-muted-foreground">{mode === "signin" ? "Sign in to open your command center." : mode === "signup" ? "Your administrator can assign your staff role." : "We’ll email you a secure reset link."}</p>
      <form className="mt-7 space-y-4" onSubmit={submit}>{mode === "signup" && <Input name="fullName" placeholder="Full name" required className="h-11 border-2"/>}<Input name="email" type="email" placeholder="Work email" required className="h-11 border-2"/>{mode !== "forgot" && <Input name="password" type="password" placeholder="Password" minLength={8} required className="h-11 border-2"/>}<Button disabled={busy} className="h-11 w-full rounded-lg">{busy ? "Please wait…" : mode === "signin" ? "Sign in" : mode === "signup" ? "Create account" : "Send reset link"}<ChevronRight /></Button></form>
      {mode !== "forgot" && <><div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border"/>or<span className="h-px flex-1 bg-border"/></div><Button variant="outline" className="h-11 w-full border-2" onClick={google}>Continue with Google</Button></>}
      <div className="mt-5 flex justify-between text-xs"><button className="font-semibold text-brand" onClick={() => setMode(mode === "signup" ? "signin" : "signup")}>{mode === "signup" ? "Already have an account?" : "Create account"}</button><button className="font-semibold text-muted-foreground" onClick={() => setMode(mode === "forgot" ? "signin" : "forgot")}>{mode === "forgot" ? "Back to sign in" : "Forgot password?"}</button></div>
    </div></section>
  </div>;
}

function Dashboard({ inventoryValue, stockQty, lowStock, pending, transactions, canApprove, approve }: { inventoryValue: number; stockQty: number; lowStock: Balance[]; pending: Requisition[]; transactions: Transaction[]; canApprove: boolean; approve: (r: Requisition, a: "approve" | "reject" | "send_back") => void }) {
  const sales = transactions.filter((t) => t.transaction_type === "sale"); const dailySales = sales.reduce((sum, row) => sum + row.quantity * Number(row.unit_rate), 0);
  const cards = [{ label: "Sales · recorded", value: money.format(dailySales), tone: "brand", detail: `${sales.length} invoices` }, { label: "Total stock", value: stockQty.toLocaleString("en-IN"), tone: "plain", detail: money.format(inventoryValue) }, { label: "Low-stock SKUs", value: String(lowStock.length), tone: "danger", detail: "Reorder attention needed" }, { label: "Pending approvals", value: String(pending.length), tone: "warning", detail: "Manager and owner queue" }];
  return <>
    <section className="grid grid-cols-2 gap-3 lg:grid-cols-4">{cards.map((card) => <div key={card.label} className={`metric-card ${card.tone === "brand" ? "bg-brand text-brand-foreground" : "bg-card"}`}><div className="text-[11px] font-semibold uppercase text-current opacity-70">{card.label}</div><div className={`mt-2 font-display text-2xl font-extrabold md:text-4xl ${card.tone === "danger" ? "text-destructive" : card.tone === "warning" ? "text-alert" : ""}`}>{card.value}</div><div className="mt-1 text-[11px] font-medium opacity-70">{card.detail}</div></div>)}</section>
    <section className="grid gap-4 lg:grid-cols-3"><div className="panel p-5 lg:col-span-2"><div className="flex items-center justify-between"><div><h2 className="panel-title">Sales — last 7 days</h2><p className="text-xs text-muted-foreground">Gross revenue, ₹</p></div><span className="rounded-full bg-foreground px-3 py-1 text-[10px] font-bold uppercase text-background">Live</span></div><div className="mt-7 flex h-44 items-end gap-2">{[42,58,47,70,64,86,100].map((height, index) => <div key={index} className={`chart-bar ${index === 6 ? "bg-alert" : "bg-muted"}`} style={{ height: `${height}%`, animationDelay: `${index * 60}ms` }}/>)}</div><div className="mt-2 flex justify-between text-[10px] text-muted-foreground">{["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((day) => <span key={day}>{day}</span>)}</div></div><div className="panel p-5"><h2 className="panel-title">Top categories</h2><div className="mt-5 space-y-4">{[["Smartphones",82,"brand"],["Chargers & cables",54,"alert"],["Cases",38,"highlight"],["Audio",26,"success"]].map(([label,width,tone]) => <div key={String(label)}><div className="mb-1 flex justify-between text-xs font-semibold"><span>{label}</span><span>{width}%</span></div><div className="h-2.5 overflow-hidden rounded-full bg-muted"><div className={`h-full bg-${tone}`} style={{ width: `${width}%` }}/></div></div>)}</div></div></section>
    <section className="grid gap-4 lg:grid-cols-3"><div className="panel overflow-hidden lg:col-span-2"><div className="flex items-center justify-between border-b-2 border-line px-5 py-3"><h2 className="panel-title">Stock risk</h2><span className="text-xs text-muted-foreground">{lowStock.length} flagged</span></div><StockTable rows={lowStock.slice(0,5)} /></div><div className="panel p-5"><h2 className="panel-title">Pending approvals</h2><div className="mt-3 space-y-3">{pending.slice(0,3).map((req) => <div key={req.id} className="rounded-xl border-2 border-line p-3"><div className="text-[10px] font-bold uppercase text-alert">{req.status.replaceAll("_", " ")}</div><div className="mt-1 font-semibold">{req.requisition_number}</div><div className="text-xs text-muted-foreground">{money.format(req.total_value)}</div>{canApprove && <div className="mt-3 flex gap-2"><Button size="sm" className="flex-1 bg-success text-success-foreground hover:bg-success/90" onClick={() => approve(req,"approve")}><Check/>Approve</Button><Button size="sm" variant="outline" onClick={() => approve(req,"send_back")}>Hold</Button></div>}</div>)}{pending.length === 0 && <Empty label="No approvals waiting"/>}</div></div></section>
    <section className="panel overflow-hidden"><div className="border-b-2 border-line px-5 py-3"><h2 className="panel-title">Recent transactions</h2></div><TransactionRows rows={transactions.slice(0,5)} /></section>
  </>;
}

function InventoryView({ balances, canManage, onAdd }: { balances: Balance[]; canManage: boolean; onAdd: () => void }) { return <section className="panel overflow-hidden"><PageHeading title="Inventory" copy="Current quantity and value by warehouse." action={canManage ? <Button onClick={onAdd}><Plus/>New item</Button> : undefined}/><StockTable rows={balances}/></section>; }
function StockTable({ rows }: { rows: Balance[] }) { return <div className="overflow-x-auto"><table className="w-full min-w-[680px] text-left text-sm"><thead className="bg-muted/50 text-[10px] uppercase text-muted-foreground"><tr><th className="px-5 py-3">Item</th><th className="px-3 py-3">Brand / code</th><th className="px-3 py-3">Warehouse</th><th className="px-3 py-3">On hand</th><th className="px-3 py-3">Reorder</th><th className="px-5 py-3 text-right">Status</th></tr></thead><tbody className="divide-y divide-border">{rows.map((row) => <tr key={row.id}><td className="px-5 py-3 font-semibold">{row.items?.item_name}</td><td className="px-3 py-3 text-muted-foreground">{row.items?.brand} · {row.items?.item_code}</td><td className="px-3 py-3">{row.warehouses?.name}</td><td className="px-3 py-3 font-bold">{row.quantity}</td><td className="px-3 py-3">{row.items?.reorder_level}</td><td className="px-5 py-3 text-right"><span className={`status ${row.quantity <= Number(row.items?.reorder_level ?? 0) ? "status-danger" : "status-success"}`}>{row.quantity <= Number(row.items?.reorder_level ?? 0) ? "Low" : "In stock"}</span></td></tr>)}{rows.length === 0 && <tr><td colSpan={6}><Empty label="No inventory matches your search"/></td></tr>}</tbody></table></div>; }
function TransactionsView({ rows, onAdd }: { rows: Transaction[]; onAdd: () => void }) { return <section className="panel overflow-hidden"><PageHeading title="Stock In / Out" copy="Receipts, sales, transfers and adjustments." action={<Button onClick={onAdd}><Plus/>New transaction</Button>}/><TransactionRows rows={rows}/></section>; }
function TransactionRows({ rows }: { rows: Transaction[] }) { return <div className="divide-y divide-border">{rows.map((row) => <div className="grid grid-cols-[auto_1fr_auto] items-center gap-3 px-5 py-3" key={row.id}><span className={`size-2 rounded-full ${row.transaction_type === "receipt" ? "bg-success" : row.transaction_type === "sale" ? "bg-brand" : "bg-alert"}`}/><div><div className="font-semibold">{row.items?.item_name ?? "Stock item"}</div><div className="text-xs text-muted-foreground">{row.transaction_type} · {row.invoice_number ?? row.serial_imei ?? "No reference"}</div></div><div className="text-right"><div className="font-bold">{row.quantity} × {money.format(row.unit_rate)}</div><div className="text-[10px] text-muted-foreground">{new Date(row.created_at).toLocaleDateString("en-IN")}</div></div></div>)}{rows.length === 0 && <Empty label="No stock transactions yet"/>}</div>; }
function ApprovalsView({ rows, canApprove, approve, onAdd }: { rows: Requisition[]; canApprove: boolean; approve: (r: Requisition, a: "approve" | "reject" | "send_back") => void; onAdd: () => void }) { return <section className="panel overflow-hidden"><PageHeading title="Requisitions & approvals" copy="Manager review and owner sign-off above ₹50,000." action={<Button onClick={onAdd}><Plus/>New requisition</Button>}/><div className="divide-y divide-border">{rows.map((row) => <div key={row.id} className="grid gap-3 px-5 py-4 md:grid-cols-[1fr_auto_auto] md:items-center"><div><div className="font-semibold">{row.requisition_number}</div><div className="text-xs text-muted-foreground">{row.notes || "No notes"} · {new Date(row.created_at).toLocaleDateString("en-IN")}</div></div><div><span className="status status-warning">{row.status.replaceAll("_", " ")}</span></div>{canApprove && ["submitted","owner_approval_pending","manager_approved"].includes(row.status) ? <div className="flex gap-2"><Button size="sm" onClick={() => approve(row,"approve")}><Check/>Approve</Button><Button size="sm" variant="outline" onClick={() => approve(row,"send_back")}>Send back</Button><Button size="icon" variant="destructive" onClick={() => approve(row,"reject")} aria-label="Reject"><X/></Button></div> : <span className="font-bold">{money.format(row.total_value)}</span>}</div>)}{rows.length === 0 && <Empty label="No requisitions yet"/>}</div></section>; }
function ReportsView({ inventoryValue, stockQty, lowStock, exportCsv }: { inventoryValue: number; stockQty: number; lowStock: number; exportCsv: () => void }) { const reports = ["Stock ledger","Item-wise stock","Brand-wise stock","Reorder report","Sales report","Purchase report","Stock valuation","Pending approvals"]; return <><PageHeading title="Reports" copy="Download operational reports for review and reconciliation."/><div className="grid gap-4 sm:grid-cols-3"><ReportMetric label="Stock value" value={money.format(inventoryValue)}/><ReportMetric label="Stock quantity" value={stockQty.toLocaleString("en-IN")}/><ReportMetric label="Reorder items" value={String(lowStock)}/></div><div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">{reports.map((name) => <div className="panel p-4" key={name}><FileSpreadsheet className="mb-5 size-6 text-brand"/><div className="font-display text-base font-extrabold">{name}</div><div className="mt-4 flex gap-2"><Button size="sm" onClick={exportCsv}><FileDown/>Excel</Button><Button size="sm" variant="outline" onClick={() => window.print()}><FileDown/>PDF</Button></div></div>)}</div></>; }
function UsersView({ onAdd }: { onAdd: () => void }) { return <section className="panel p-6"><PageHeading title="User management" copy="Create staff accounts and assign operational roles." action={<Button onClick={onAdd}><Plus/>Create user</Button>}/><div className="mt-8 grid place-items-center border-t-2 border-dashed border-border py-12 text-center"><Users className="mb-3 size-9 text-muted-foreground"/><p className="font-semibold">Staff accounts are protected</p><p className="mt-1 max-w-md text-xs text-muted-foreground">Create accounts here. Passwords are encrypted by the authentication service and roles remain in a separate protected record.</p></div></section>; }

function ActionDialog({ type, items, warehouses, suppliers, userId, close, refresh }: { type: "item" | "stock" | "requisition" | "user"; items: Item[]; warehouses: { id: string; name: string }[]; suppliers: { id: string; supplier_name: string }[]; userId: string; close: () => void; refresh: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setBusy(true); const f = new FormData(event.currentTarget); let error: { message: string } | null = null;
    if (type === "item") ({ error } = await supabase.from("items").insert({ item_code: String(f.get("code")), item_name: String(f.get("name")), brand: String(f.get("brand")), model: String(f.get("model")), purchase_price: Number(f.get("purchase")), selling_price: Number(f.get("sale")), reorder_level: Number(f.get("reorder")), imei_tracking_required: f.get("imei") === "on", created_by: userId }));
    if (type === "stock") ({ error } = await supabase.from("stock_transactions").insert({ transaction_type: String(f.get("kind")) as "receipt" | "sale" | "transfer" | "adjustment", item_id: String(f.get("item")), source_warehouse_id: f.get("source") ? String(f.get("source")) : null, destination_warehouse_id: f.get("destination") ? String(f.get("destination")) : null, supplier_id: f.get("supplier") ? String(f.get("supplier")) : null, invoice_number: String(f.get("invoice") || ""), customer_name: String(f.get("customer") || ""), quantity: Number(f.get("quantity")), unit_rate: Number(f.get("rate")), gst_percent: Number(f.get("gst") || 0), serial_imei: String(f.get("imei") || ""), reason: String(f.get("reason") || ""), created_by: userId, approval_status: f.get("kind") === "adjustment" ? "pending" : "approved" }));
    if (type === "requisition") { const number = `REQ-${Date.now().toString().slice(-6)}`; const result = await supabase.from("requisitions").insert({ requisition_number: number, requested_by: userId, warehouse_id: String(f.get("warehouse")), status: "submitted", notes: String(f.get("notes") || ""), submitted_at: new Date().toISOString() }).select("id").single(); error = result.error; if (result.data) { const itemResult = await supabase.from("requisition_items").insert({ requisition_id: result.data.id, item_id: String(f.get("item")), quantity: Number(f.get("quantity")), estimated_rate: Number(f.get("rate")) }); error = itemResult.error; } }
    if (type === "user") { try { await createStaffUser({ data: { email: String(f.get("email")), password: String(f.get("password")), fullName: String(f.get("fullName")), role: String(f.get("role")) as Role } }); } catch (caught) { error = { message: caught instanceof Error ? caught.message : "Could not create user" }; } }
    setBusy(false); if (error) return toast.error(error.message); toast.success(`${type[0].toUpperCase()}${type.slice(1)} saved`); close(); await refresh();
  }
  const titles = { item: "Add item", stock: "Record stock movement", requisition: "Raise requisition", user: "Create staff user" };
  return <div className="fixed inset-0 z-50 grid place-items-center bg-overlay p-4" role="dialog" aria-modal="true"><form onSubmit={submit} className="max-h-[90vh] w-full max-w-xl overflow-y-auto border-2 border-line bg-background p-5 shadow-2xl"><div className="mb-5 flex items-center justify-between"><div><h2 className="font-display text-xl font-extrabold">{titles[type]}</h2><p className="text-xs text-muted-foreground">All changes are recorded in the audit trail.</p></div><Button type="button" variant="ghost" size="icon" onClick={close} aria-label="Close"><X/></Button></div>
    <div className="grid gap-3 sm:grid-cols-2">{type === "item" && <><Field name="code" label="Item code"/><Field name="name" label="Item name"/><Field name="brand" label="Brand"/><Field name="model" label="Model"/><Field name="purchase" label="Purchase price" type="number"/><Field name="sale" label="Selling price" type="number"/><Field name="reorder" label="Reorder level" type="number"/><label className="flex items-center gap-2 pt-7 text-sm font-semibold"><input type="checkbox" name="imei"/> IMEI tracking required</label></>}
    {type === "stock" && <><SelectField name="kind" label="Movement" options={[["receipt","Stock receipt"],["sale","Stock sale"],["transfer","Stock transfer"],["adjustment","Stock adjustment"]]}/><SelectField name="item" label="Product" options={items.map((i) => [i.id, i.item_name])}/><SelectField name="source" label="Source warehouse" optional options={warehouses.map((w) => [w.id,w.name])}/><SelectField name="destination" label="Destination warehouse" optional options={warehouses.map((w) => [w.id,w.name])}/><SelectField name="supplier" label="Supplier" optional options={suppliers.map((s) => [s.id,s.supplier_name])}/><Field name="invoice" label="Invoice number" optional/><Field name="customer" label="Customer name" optional/><Field name="quantity" label="Quantity" type="number"/><Field name="rate" label="Unit rate" type="number"/><Field name="gst" label="GST %" type="number" optional/><Field name="imei" label="Serial / IMEI" optional/><Field name="reason" label="Reason" optional/></>}
    {type === "requisition" && <><SelectField name="warehouse" label="Warehouse" options={warehouses.map((w) => [w.id,w.name])}/><SelectField name="item" label="Product" options={items.map((i) => [i.id,i.item_name])}/><Field name="quantity" label="Quantity" type="number"/><Field name="rate" label="Estimated rate" type="number"/><div className="sm:col-span-2"><Field name="notes" label="Notes" optional/></div></>}
    {type === "user" && <><Field name="fullName" label="Full name"/><Field name="email" label="Email" type="email"/><Field name="password" label="Temporary password" type="password"/><SelectField name="role" label="Role" options={[["admin","Admin"],["store_executive","Store executive"],["manager","Manager"],["owner","Owner"]]}/></>}</div><div className="mt-6 flex justify-end gap-2"><Button type="button" variant="outline" onClick={close}>Cancel</Button><Button disabled={busy} type="submit">{busy ? "Saving…" : "Save"}</Button></div></form></div>;
}

function Field({ name, label, type = "text", optional = false }: { name: string; label: string; type?: string; optional?: boolean }) { return <label className="space-y-1.5 text-xs font-semibold">{label}{optional && <span className="font-normal text-muted-foreground"> · optional</span>}<Input name={name} type={type} required={!optional} min={type === "number" ? 0 : undefined} className="h-10 border-2"/></label>; }
function SelectField({ name, label, options, optional = false }: { name: string; label: string; options: string[][]; optional?: boolean }) { return <label className="space-y-1.5 text-xs font-semibold">{label}<select name={name} required={!optional} className="h-10 w-full rounded-md border-2 border-input bg-background px-3 text-sm"><option value="">Select…</option>{options.map(([value,text]) => <option key={value} value={value}>{text}</option>)}</select></label>; }
function PageHeading({ title, copy, action }: { title: string; copy: string; action?: React.ReactNode }) { return <div className="flex flex-wrap items-center justify-between gap-3 border-b-2 border-line px-5 py-4"><div><h1 className="font-display text-xl font-extrabold">{title}</h1><p className="text-xs text-muted-foreground">{copy}</p></div>{action}</div>; }
function ReportMetric({ label, value }: { label: string; value: string }) { return <div className="panel p-5"><div className="text-[10px] font-bold uppercase text-muted-foreground">{label}</div><div className="mt-2 font-display text-3xl font-extrabold">{value}</div></div>; }
function Empty({ label }: { label: string }) { return <div className="grid place-items-center px-5 py-10 text-center text-sm text-muted-foreground"><Boxes className="mb-2 size-6"/>{label}</div>; }