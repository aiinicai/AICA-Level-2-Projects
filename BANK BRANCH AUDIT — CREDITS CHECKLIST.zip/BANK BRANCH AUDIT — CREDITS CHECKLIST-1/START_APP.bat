@echo off
title Bank Branch Audit - Credits Checklist
echo ========================================================
echo   BANK BRANCH AUDIT - CREDITS CHECKLIST ^& IRAC ENGINE
echo ========================================================
echo.
echo Starting Web Application...
echo Opening in browser at http://localhost:5173
echo.
echo Press Ctrl+C in this window anytime to stop the server.
echo.

cd /d "%~dp0"
npx vite --port 5173 --host --open
pause
