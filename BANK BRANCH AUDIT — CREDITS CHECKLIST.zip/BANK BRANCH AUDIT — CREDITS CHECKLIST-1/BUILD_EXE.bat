@echo off
title Bank Branch Audit - Windows EXE Builder
echo ========================================================
echo   BANK BRANCH AUDIT - CREDITS CHECKLIST ^& IRAC ENGINE
echo            WINDOWS .EXE APPLICATION BUILDER
echo ========================================================
echo.
echo [1/3] Checking Node.js environment...
where node >nul 2>nul
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Node.js is not installed or not in PATH!
    echo Please install Node.js from https://nodejs.org/ to build the .exe.
    pause
    exit /b 1
)

cd /d "%~dp0"

echo [2/3] Building frontend assets...
call npm run build
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Frontend build failed!
    pause
    exit /b 1
)

echo.
echo [3/3] Packaging Windows Standalone Executable (.exe)...
call npm run electron:build
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Packaging failed!
    pause
    exit /b 1
)

echo.
echo ========================================================
echo   BUILD COMPLETED SUCCESSFULLY!
echo ========================================================
echo.
echo The standalone installer and portable .exe are available in:
echo   release\
echo.
pause
