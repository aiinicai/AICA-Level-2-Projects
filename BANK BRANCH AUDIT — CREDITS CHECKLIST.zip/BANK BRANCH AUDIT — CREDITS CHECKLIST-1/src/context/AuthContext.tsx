import React, { createContext, useContext, useState } from 'react';
import { UserAccount, UserRole, CreditFacility } from '../types/audit';
import { StorageService } from '../services/storageService';

interface AuthContextType {
  currentUser: UserAccount;
  allUsers: UserAccount[];
  switchUser: (userId: string) => void;
  updateUserList: (users: UserAccount[]) => void;
  updateCurrentUser: (user: Partial<UserAccount>) => void;
  
  // Granular Role & Authorization Flags
  isAdmin: boolean;
  isStaff: boolean;
  isReadOnly: boolean;
  canEnterData: boolean;
  canModifyFacility: (facility: CreditFacility) => { allowed: boolean; reason?: string };
  canDeleteFacility: (facility?: CreditFacility) => boolean;
  canLockUnlock: boolean;
  canManageTeam: boolean;
  canEditMetadata: boolean;
  canReview: boolean;
  canEdit: boolean; // Backwards compatible general edit check
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [allUsers, setAllUsers] = useState<UserAccount[]>(() => StorageService.getUsers());
  const [currentUser, setCurrentUserState] = useState<UserAccount>(() => StorageService.getActiveUser());

  const switchUser = (userId: string) => {
    const user = allUsers.find(u => u.id === userId);
    if (user) {
      setCurrentUserState(user);
      StorageService.setActiveUser(user);
    }
  };

  const updateUserList = (users: UserAccount[]) => {
    setAllUsers(users);
    StorageService.saveUsers(users);
    // If active user was updated, update active user state
    const updatedActive = users.find(u => u.id === currentUser.id);
    if (updatedActive) {
      setCurrentUserState(updatedActive);
      StorageService.setActiveUser(updatedActive);
    } else if (users.length > 0) {
      setCurrentUserState(users[0]);
      StorageService.setActiveUser(users[0]);
    }
  };

  const updateCurrentUser = (partial: Partial<UserAccount>) => {
    const updated = { ...currentUser, ...partial };
    setCurrentUserState(updated);
    StorageService.setActiveUser(updated);
    const users = allUsers.map(u => (u.id === currentUser.id ? updated : u));
    setAllUsers(users);
    StorageService.saveUsers(users);
  };

  // Role Checks
  const isAdmin = currentUser.role === 'admin' || currentUser.role === 'reviewer' || currentUser.isAdmin === true;
  const isStaff = currentUser.role === 'staff' || currentUser.role === 'auditor';
  const isReadOnly = currentUser.role === 'read-only';

  const canEnterData = !isReadOnly;
  const canLockUnlock = isAdmin;
  const canManageTeam = isAdmin;
  const canEditMetadata = isAdmin;
  const canReview = isAdmin;
  const canEdit = !isReadOnly;

  // Deletion: ONLY Admin can delete saved records. Staff can NEVER delete saved audit facilities.
  const canDeleteFacility = (facility?: CreditFacility): boolean => {
    if (isAdmin) return true;
    return false;
  };

  // Modification:
  // - While creating/drafting (!facility.isSubmitted && !facility.isLocked): allowed for Staff & Admin.
  // - Once saved/locked: Admin can edit directly. Staff can only edit if Admin has authorized or with mandatory revision reason.
  const canModifyFacility = (facility: CreditFacility): { allowed: boolean; reason?: string } => {
    if (isReadOnly) {
      return { allowed: false, reason: 'Read-only account cannot modify records.' };
    }
    if (isAdmin) {
      return { allowed: true };
    }
    // If record is saved/locked and user is staff:
    if (facility.isLocked || facility.isSubmitted) {
      if (facility.isAuthorizedForEdit) {
        return { allowed: true };
      }
      return { 
        allowed: false, 
        reason: 'This credit facility is saved & locked. Only CA Admin is authorized to modify or unlock saved audit records.' 
      };
    }
    return { allowed: true };
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers,
        switchUser,
        updateUserList,
        updateCurrentUser,
        isAdmin,
        isStaff,
        isReadOnly,
        canEnterData,
        canModifyFacility,
        canDeleteFacility,
        canLockUnlock,
        canManageTeam,
        canEditMetadata,
        canReview,
        canEdit,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
