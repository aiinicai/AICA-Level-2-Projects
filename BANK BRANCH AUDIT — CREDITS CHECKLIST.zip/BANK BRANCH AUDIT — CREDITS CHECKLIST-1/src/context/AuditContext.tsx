import React, { createContext, useContext, useState, useMemo, useCallback, useEffect } from 'react';
import { 
  CreditFacility, 
  EditHistoryEntry, 
  FacilityType, 
  IRACCategory, 
  DPStatusBadgeType, 
  RBIProvisionRates,
  AttachmentItem 
} from '../types/audit';
import { StorageService, AuditMetadata } from '../services/storageService';
import { useAuth } from './AuthContext';
import { evaluateDPStatusBadge, checkBankingNormsOverride } from '../services/dpEngine';

export interface AuditAlertItem {
  id: string;
  facilityId: string;
  borrowerName: string;
  accountNumber: string;
  type: 'EXPIRING_INSURANCE' | 'RENEWAL_DUE' | 'STALE_STOCK_STATEMENT' | 'OVERDRAWN_LIMIT' | 'OVERDRAWN_DP' | 'RELATED_PARTY_SEC20' | 'PENDING_DOCUMENTATION';
  severity: 'critical' | 'warning' | 'info';
  title: string;
  description: string;
  dueDateOrExpiry?: string;
  daysRemainingOrOverdue?: number;
}

export interface FilterState {
  searchQuery: string;
  facilityType: FacilityType | 'ALL';
  iracCategory: IRACCategory | 'ALL';
  dpBadge: DPStatusBadgeType | 'ALL';
  reviewStatus: 'ALL' | 'REVIEWED' | 'PENDING';
  relatedPartyOnly: boolean;
  normsOverriddenOnly: boolean;
  showArchived: boolean;
  sortBy: 'borrowerName' | 'accountNumber' | 'totalSanctionedLimit' | 'outstandingBalance' | 'nextRenewalDueDate' | 'updatedAt';
  sortOrder: 'asc' | 'desc';
}

interface AuditContextType {
  facilities: CreditFacility[];
  filteredFacilities: CreditFacility[];
  activeFacility: CreditFacility | null;
  setActiveFacility: (facility: CreditFacility | null) => void;
  filters: FilterState;
  setFilters: React.Dispatch<React.SetStateAction<FilterState>>;
  resetFilters: () => void;
  
  // CRUD Actions
  saveFacility: (facility: CreditFacility, changeReason?: string) => void;
  archiveFacility: (id: string) => void;
  restoreFacility: (id: string) => void;
  deleteFacilityPermanent: (id: string) => boolean;
  lockFacility: (id: string) => void;
  unlockFacility: (id: string, reason: string) => void;
  toggleReviewStatus: (facilityId: string, comments?: string) => void;
  
  // Backup & Restore
  exportBackupJSON: () => string;
  restoreBackupJSON: (jsonStr: string) => { success: boolean; message: string; count: number };
  
  // History & Attachments
  getHistoryForFacility: (facilityId: string) => EditHistoryEntry[];
  allHistory: EditHistoryEntry[];
  attachments: AttachmentItem[];
  addAttachment: (attachment: AttachmentItem) => void;
  removeAttachment: (id: string) => void;
  
  // Rates & Metadata
  rbiRates: RBIProvisionRates;
  updateRBIRates: (rates: RBIProvisionRates) => void;
  auditMetadata: AuditMetadata;
  updateAuditMetadata: (meta: AuditMetadata) => void;
  
  // Alerts & KPIs
  alerts: AuditAlertItem[];
  kpiStats: {
    totalFacilitiesCount: number;
    totalSanctionedSum: number;
    totalOutstandingSum: number;
    totalProvisionSum: number;
    npaCount: number;
    npaOutstandingSum: number;
    staleStockCount: number;
    overdrawnCount: number;
    expiringInsuranceCount: number;
    renewalsDueCount: number;
    pendingReviewCount: number;
  };
  
  // Drafts
  draft: Partial<CreditFacility> | null;
  saveDraft: (data: Partial<CreditFacility>) => void;
  clearDraft: () => void;
  resetAllData: (asOfDate?: string) => void;
}

const DEFAULT_FILTERS: FilterState = {
  searchQuery: '',
  facilityType: 'ALL',
  iracCategory: 'ALL',
  dpBadge: 'ALL',
  reviewStatus: 'ALL',
  relatedPartyOnly: false,
  normsOverriddenOnly: false,
  showArchived: false,
  sortBy: 'updatedAt',
  sortOrder: 'desc',
};

const AuditContext = createContext<AuditContextType | undefined>(undefined);

export const AuditProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser } = useAuth();
  const [facilities, setFacilities] = useState<CreditFacility[]>(() => StorageService.getFacilities());
  const [activeFacility, setActiveFacility] = useState<CreditFacility | null>(null);
  const [filters, setFilters] = useState<FilterState>(DEFAULT_FILTERS);
  const [allHistory, setAllHistory] = useState<EditHistoryEntry[]>(() => StorageService.getEditHistory());
  const [attachments, setAttachments] = useState<AttachmentItem[]>(() => StorageService.getAttachments());
  const [rbiRates, setRbiRates] = useState<RBIProvisionRates>(() => StorageService.getRBIRates());
  const [auditMetadata, setAuditMetadata] = useState<AuditMetadata>(() => StorageService.getAuditMetadata());
  const [draft, setDraft] = useState<Partial<CreditFacility> | null>(() => StorageService.getDraft()?.data || null);

  const resetFilters = useCallback(() => {
    setFilters(DEFAULT_FILTERS);
  }, []);

  const saveFacility = useCallback((facility: CreditFacility, changeReason?: string) => {
    // Run norms check to ensure state consistency
    const norms = checkBankingNormsOverride(facility);
    const enrichedFacility: CreditFacility = {
      ...facility,
      isNormOverridden: norms.isOverridden || facility.isNormOverridden,
    };

    const result = StorageService.saveFacility(enrichedFacility, currentUser, changeReason);
    setFacilities(StorageService.getFacilities());
    setAllHistory(StorageService.getEditHistory());
    if (activeFacility?.id === enrichedFacility.id) {
      setActiveFacility(result.facility);
    }
  }, [currentUser, activeFacility]);

  const archiveFacility = useCallback((id: string) => {
    StorageService.softDeleteFacility(id, currentUser);
    setFacilities(StorageService.getFacilities());
    setAllHistory(StorageService.getEditHistory());
    if (activeFacility?.id === id) {
      setActiveFacility(null);
    }
  }, [currentUser, activeFacility]);

  const restoreFacility = useCallback((id: string) => {
    StorageService.restoreFacility(id, currentUser);
    setFacilities(StorageService.getFacilities());
    setAllHistory(StorageService.getEditHistory());
  }, [currentUser]);

  const deleteFacilityPermanent = useCallback((id: string) => {
    const success = StorageService.deleteFacilityPermanent(id, currentUser);
    if (success) {
      setFacilities(StorageService.getFacilities());
      setAllHistory(StorageService.getEditHistory());
      if (activeFacility?.id === id) {
        setActiveFacility(null);
      }
    }
    return success;
  }, [currentUser, activeFacility]);

  const lockFacility = useCallback((id: string) => {
    StorageService.lockFacility(id, currentUser);
    setFacilities(StorageService.getFacilities());
    setAllHistory(StorageService.getEditHistory());
  }, [currentUser]);

  const unlockFacility = useCallback((id: string, reason: string) => {
    StorageService.unlockFacility(id, currentUser, reason);
    setFacilities(StorageService.getFacilities());
    setAllHistory(StorageService.getEditHistory());
  }, [currentUser]);

  const exportBackupJSON = useCallback(() => {
    return StorageService.exportBackupJSON();
  }, []);

  const restoreBackupJSON = useCallback((jsonStr: string) => {
    const res = StorageService.restoreBackupJSON(jsonStr);
    if (res.success) {
      setFacilities(StorageService.getFacilities());
      setAllHistory(StorageService.getEditHistory());
      setAttachments(StorageService.getAttachments());
      setRbiRates(StorageService.getRBIRates());
      setAuditMetadata(StorageService.getAuditMetadata());
      setActiveFacility(null);
    }
    return res;
  }, []);

  const toggleReviewStatus = useCallback((facilityId: string, comments?: string) => {
    const target = facilities.find(f => f.id === facilityId);
    if (!target) return;

    const newStatus = !target.isReviewed;
    const updated: CreditFacility = {
      ...target,
      isReviewed: newStatus,
      reviewedBy: newStatus ? currentUser.name : undefined,
      reviewedAt: newStatus ? new Date().toISOString() : undefined,
      reviewerComments: comments || target.reviewerComments,
    };

    saveFacility(updated, newStatus ? 'Marked as reviewed by Engagement Reviewer' : 'Reopened review status');
  }, [facilities, currentUser, saveFacility]);

  const getHistoryForFacility = useCallback((facilityId: string) => {
    return allHistory.filter(h => h.facilityId === facilityId);
  }, [allHistory]);

  const addAttachment = useCallback((attachment: AttachmentItem) => {
    StorageService.saveAttachment(attachment);
    setAttachments(StorageService.getAttachments());
  }, []);

  const removeAttachment = useCallback((id: string) => {
    StorageService.deleteAttachment(id);
    setAttachments(StorageService.getAttachments());
  }, []);

  const updateRBIRates = useCallback((rates: RBIProvisionRates) => {
    StorageService.saveRBIRates(rates);
    setRbiRates(rates);
  }, []);

  const updateAuditMetadata = useCallback((meta: AuditMetadata) => {
    StorageService.saveAuditMetadata(meta);
    setAuditMetadata(meta);
  }, []);

  const handleSaveDraft = useCallback((data: Partial<CreditFacility>) => {
    StorageService.saveDraft(data);
    setDraft(data);
  }, []);

  const handleClearDraft = useCallback(() => {
    StorageService.clearDraft();
    setDraft(null);
  }, []);

  const resetAllData = useCallback((asOfDate?: string) => {
    StorageService.resetToSeed(asOfDate);
    setFacilities(StorageService.getFacilities());
    setAllHistory(StorageService.getEditHistory());
    setAttachments(StorageService.getAttachments());
    setRbiRates(StorageService.getRBIRates());
    setAuditMetadata(StorageService.getAuditMetadata());
    setActiveFacility(null);
    setDraft(null);
    resetFilters();
  }, [resetFilters]);

  // Compute Active Alerts
  const alerts = useMemo<AuditAlertItem[]>(() => {
    const list: AuditAlertItem[] = [];
    const auditTime = new Date(auditMetadata.auditAsOfDate || Date.now()).getTime();

    facilities.filter(f => !f.isArchived).forEach(fac => {
      // 1. Insurance Expiry Check (< 30 days or expired)
      if (fac.insuranceExpiryDate) {
        const insTime = new Date(fac.insuranceExpiryDate).getTime();
        if (!isNaN(insTime)) {
          const daysToExpiry = Math.ceil((insTime - auditTime) / (1000 * 60 * 60 * 24));
          if (daysToExpiry <= 0) {
            list.push({
              id: `alt_ins_${fac.id}`,
              facilityId: fac.id,
              borrowerName: fac.borrowerName,
              accountNumber: fac.accountNumber,
              type: 'EXPIRING_INSURANCE',
              severity: 'critical',
              title: 'Insurance Policy Lapsed / Expired',
              description: `Insurance expired on ${fac.insuranceExpiryDate} (${Math.abs(daysToExpiry)} days ago). Credit exposure is unprotected.`,
              dueDateOrExpiry: fac.insuranceExpiryDate,
              daysRemainingOrOverdue: daysToExpiry,
            });
          } else if (daysToExpiry <= 30) {
            list.push({
              id: `alt_ins_${fac.id}`,
              facilityId: fac.id,
              borrowerName: fac.borrowerName,
              accountNumber: fac.accountNumber,
              type: 'EXPIRING_INSURANCE',
              severity: 'warning',
              title: 'Insurance Expiring Soon',
              description: `Policy expires in ${daysToExpiry} days (${fac.insuranceExpiryDate}). Renewal premium endorsement pending.`,
              dueDateOrExpiry: fac.insuranceExpiryDate,
              daysRemainingOrOverdue: daysToExpiry,
            });
          }
        }
      }

      // 2. Renewal Due Check (< 30 days or overdue)
      if (fac.nextRenewalDueDate) {
        const renTime = new Date(fac.nextRenewalDueDate).getTime();
        if (!isNaN(renTime)) {
          const daysToRenewal = Math.ceil((renTime - auditTime) / (1000 * 60 * 60 * 24));
          if (daysToRenewal <= 0) {
            list.push({
              id: `alt_ren_${fac.id}`,
              facilityId: fac.id,
              borrowerName: fac.borrowerName,
              accountNumber: fac.accountNumber,
              type: 'RENEWAL_DUE',
              severity: 'critical',
              title: 'Facility Review / Renewal Overdue',
              description: `Annual renewal was due on ${fac.nextRenewalDueDate} (${Math.abs(daysToRenewal)} days overdue). Needs immediate regularisation.`,
              dueDateOrExpiry: fac.nextRenewalDueDate,
              daysRemainingOrOverdue: daysToRenewal,
            });
          } else if (daysToRenewal <= 30) {
            list.push({
              id: `alt_ren_${fac.id}`,
              facilityId: fac.id,
              borrowerName: fac.borrowerName,
              accountNumber: fac.accountNumber,
              type: 'RENEWAL_DUE',
              severity: 'warning',
              title: 'Facility Renewal Due in <30 Days',
              description: `Due for renewal on ${fac.nextRenewalDueDate} (${daysToRenewal} days left). Review proposal under process.`,
              dueDateOrExpiry: fac.nextRenewalDueDate,
              daysRemainingOrOverdue: daysToRenewal,
            });
          }
        }
      }

      // 3. Stale Stock Statement Check
      const dp = fac.currentDPWorking;
      if (fac.facilityType === 'Cash Credit (CC)' || fac.facilityType === 'Overdraft (OD)') {
        if (!dp || !dp.statementDate) {
          list.push({
            id: `alt_stale_${fac.id}`,
            facilityId: fac.id,
            borrowerName: fac.borrowerName,
            accountNumber: fac.accountNumber,
            type: 'STALE_STOCK_STATEMENT',
            severity: 'critical',
            title: 'Missing Stock Statement',
            description: 'No stock statement on record to ascertain Drawing Power.',
          });
        } else {
          const stmtTime = new Date(dp.statementDate).getTime();
          const daysOld = Math.floor((auditTime - stmtTime) / (1000 * 60 * 60 * 24));
          if (daysOld > 90) {
            list.push({
              id: `alt_stale_${fac.id}`,
              facilityId: fac.id,
              borrowerName: fac.borrowerName,
              accountNumber: fac.accountNumber,
              type: 'STALE_STOCK_STATEMENT',
              severity: 'critical',
              title: 'Stale Stock Statement (>90 Days)',
              description: `Latest stock statement is dated ${dp.statementDate} (${daysOld} days old). RBI norms require regular monthly statements.`,
              dueDateOrExpiry: dp.statementDate,
              daysRemainingOrOverdue: daysOld,
            });
          }
        }
      }

      // 4. Overdrawn Limits
      if (fac.outstandingBalance > fac.totalSanctionedLimit) {
        const excess = fac.outstandingBalance - fac.totalSanctionedLimit;
        list.push({
          id: `alt_ovl_${fac.id}`,
          facilityId: fac.id,
          borrowerName: fac.borrowerName,
          accountNumber: fac.accountNumber,
          type: 'OVERDRAWN_LIMIT',
          severity: 'critical',
          title: 'Outstanding Exceeds Sanctioned Limit',
          description: `Outstanding (₹${fac.outstandingBalance.toLocaleString('en-IN')}) exceeds limit (₹${fac.totalSanctionedLimit.toLocaleString('en-IN')}) by ₹${excess.toLocaleString('en-IN')}.`,
        });
      } else if (dp && fac.outstandingBalance > dp.computedDP) {
        const excessDP = fac.outstandingBalance - dp.computedDP;
        list.push({
          id: `alt_ovdp_${fac.id}`,
          facilityId: fac.id,
          borrowerName: fac.borrowerName,
          accountNumber: fac.accountNumber,
          type: 'OVERDRAWN_DP',
          severity: 'warning',
          title: 'Outstanding Exceeds Drawing Power',
          description: `Outstanding exceeds DP by ₹${excessDP.toLocaleString('en-IN')} (DP: ₹${dp.computedDP.toLocaleString('en-IN')}).`,
        });
      }

      // 5. Section 20 Related Party Flag
      if (fac.isRelatedParty) {
        list.push({
          id: `alt_sec20_${fac.id}`,
          facilityId: fac.id,
          borrowerName: fac.borrowerName,
          accountNumber: fac.accountNumber,
          type: 'RELATED_PARTY_SEC20',
          severity: 'info',
          title: 'Section 20 BRA 1949 — Related Party Facility',
          description: `Director/relative related facility: ${fac.relatedPartyDetails || 'Board approval verified.'}`,
        });
      }

      // 6. Incomplete / Expired Checklist Documentation
      const pendingDocs = fac.checklist.filter(c => c.status === 'Obtained but Expired / Due' || c.status === 'Not Obtained / Pending');
      if (pendingDocs.length > 0) {
        list.push({
          id: `alt_doc_${fac.id}`,
          facilityId: fac.id,
          borrowerName: fac.borrowerName,
          accountNumber: fac.accountNumber,
          type: 'PENDING_DOCUMENTATION',
          severity: 'warning',
          title: `${pendingDocs.length} Pending / Expired Document(s)`,
          description: `Critical items pending: ${pendingDocs.map(d => d.title).slice(0, 2).join(', ')}${pendingDocs.length > 2 ? ` (+${pendingDocs.length - 2} more)` : ''}`,
        });
      }
    });

    return list;
  }, [facilities, auditMetadata]);

  // Compute KPI Statistics
  const kpiStats = useMemo(() => {
    const active = facilities.filter(f => !f.isArchived);
    let totalSanctionedSum = 0;
    let totalOutstandingSum = 0;
    let totalProvisionSum = 0;
    let npaCount = 0;
    let npaOutstandingSum = 0;
    let staleStockCount = 0;
    let overdrawnCount = 0;
    let expiringInsuranceCount = 0;
    let renewalsDueCount = 0;
    let pendingReviewCount = 0;

    const auditTime = new Date(auditMetadata.auditAsOfDate || Date.now()).getTime();

    active.forEach(fac => {
      totalSanctionedSum += fac.totalSanctionedLimit || 0;
      totalOutstandingSum += fac.outstandingBalance || 0;

      const irac = fac.currentIRAC;
      if (irac) {
        totalProvisionSum += irac.totalProvisionAmount || 0;
        if (irac.computedCategory !== 'Standard') {
          npaCount += 1;
          npaOutstandingSum += fac.outstandingBalance || 0;
        }
      }

      const dp = fac.currentDPWorking;
      if (fac.facilityType === 'Cash Credit (CC)' || fac.facilityType === 'Overdraft (OD)') {
        if (!dp || !dp.statementDate) {
          staleStockCount += 1;
        } else {
          const stmtTime = new Date(dp.statementDate).getTime();
          if ((auditTime - stmtTime) / (1000 * 60 * 60 * 24) > 90) {
            staleStockCount += 1;
          }
        }
      }

      if (fac.outstandingBalance > fac.totalSanctionedLimit || (dp && fac.outstandingBalance > dp.computedDP)) {
        overdrawnCount += 1;
      }

      if (fac.insuranceExpiryDate) {
        const insTime = new Date(fac.insuranceExpiryDate).getTime();
        if ((insTime - auditTime) / (1000 * 60 * 60 * 24) <= 30) {
          expiringInsuranceCount += 1;
        }
      }

      if (fac.nextRenewalDueDate) {
        const renTime = new Date(fac.nextRenewalDueDate).getTime();
        if ((renTime - auditTime) / (1000 * 60 * 60 * 24) <= 30) {
          renewalsDueCount += 1;
        }
      }

      if (!fac.isReviewed) {
        pendingReviewCount += 1;
      }
    });

    return {
      totalFacilitiesCount: active.length,
      totalSanctionedSum,
      totalOutstandingSum,
      totalProvisionSum,
      npaCount,
      npaOutstandingSum,
      staleStockCount,
      overdrawnCount,
      expiringInsuranceCount,
      renewalsDueCount,
      pendingReviewCount,
    };
  }, [facilities, auditMetadata]);

  // Filtered & Sorted Facilities
  const filteredFacilities = useMemo(() => {
    let result = facilities.filter(f => {
      // Archive filter
      if (!filters.showArchived && f.isArchived) return false;
      if (filters.showArchived && !f.isArchived) return false;

      // Facility Type filter
      if (filters.facilityType !== 'ALL' && f.facilityType !== filters.facilityType) return false;

      // IRAC Category filter
      if (filters.iracCategory !== 'ALL' && f.currentIRAC?.computedCategory !== filters.iracCategory) return false;

      // DP Badge filter
      if (filters.dpBadge !== 'ALL') {
        const badgeObj = evaluateDPStatusBadge(f, auditMetadata.auditAsOfDate);
        if (badgeObj.badge !== filters.dpBadge) return false;
      }

      // Review Status filter
      if (filters.reviewStatus === 'REVIEWED' && !f.isReviewed) return false;
      if (filters.reviewStatus === 'PENDING' && f.isReviewed) return false;

      // Related Party filter
      if (filters.relatedPartyOnly && !f.isRelatedParty) return false;

      // Norms Overridden filter
      if (filters.normsOverriddenOnly && !f.isNormOverridden) return false;

      // Global Search Query
      if (filters.searchQuery.trim()) {
        const query = filters.searchQuery.toLowerCase().trim();
        const matchesBorrower = f.borrowerName.toLowerCase().includes(query);
        const matchesAccount = f.accountNumber.toLowerCase().includes(query);
        const matchesBranch = f.branch.toLowerCase().includes(query);
        const matchesGuarantors = f.guarantors?.toLowerCase().includes(query);
        const matchesNotes = f.additionalNotes?.toLowerCase().includes(query);
        const matchesObs = f.auditorObservations?.toLowerCase().includes(query);
        const matchesSector = f.industrySector?.toLowerCase().includes(query);

        if (!matchesBorrower && !matchesAccount && !matchesBranch && !matchesGuarantors && !matchesNotes && !matchesObs && !matchesSector) {
          return false;
        }
      }

      return true;
    });

    // Sort
    result.sort((a, b) => {
      let comparison = 0;
      switch (filters.sortBy) {
        case 'borrowerName':
          comparison = a.borrowerName.localeCompare(b.borrowerName);
          break;
        case 'accountNumber':
          comparison = a.accountNumber.localeCompare(b.accountNumber);
          break;
        case 'totalSanctionedLimit':
          comparison = (a.totalSanctionedLimit || 0) - (b.totalSanctionedLimit || 0);
          break;
        case 'outstandingBalance':
          comparison = (a.outstandingBalance || 0) - (b.outstandingBalance || 0);
          break;
        case 'nextRenewalDueDate':
          comparison = (a.nextRenewalDueDate || '').localeCompare(b.nextRenewalDueDate || '');
          break;
        case 'updatedAt':
        default:
          comparison = (a.updatedAt || '').localeCompare(b.updatedAt || '');
          break;
      }
      return filters.sortOrder === 'asc' ? comparison : -comparison;
    });

    return result;
  }, [facilities, filters, auditMetadata]);

  return (
    <AuditContext.Provider
      value={{
        facilities,
        filteredFacilities,
        activeFacility,
        setActiveFacility,
        filters,
        setFilters,
        resetFilters,
        saveFacility,
        archiveFacility,
        restoreFacility,
        deleteFacilityPermanent,
        lockFacility,
        unlockFacility,
        toggleReviewStatus,
        exportBackupJSON,
        restoreBackupJSON,
        getHistoryForFacility,
        allHistory,
        attachments,
        addAttachment,
        removeAttachment,
        rbiRates,
        updateRBIRates,
        auditMetadata,
        updateAuditMetadata,
        alerts,
        kpiStats,
        draft,
        saveDraft: handleSaveDraft,
        clearDraft: handleClearDraft,
        resetAllData,
      }}
    >
      {children}
    </AuditContext.Provider>
  );
};

export const useAudit = () => {
  const context = useContext(AuditContext);
  if (!context) throw new Error('useAudit must be used within an AuditProvider');
  return context;
};
