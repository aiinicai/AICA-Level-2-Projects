import React from 'react';
import { ThemeProvider } from './context/ThemeContext';
import { AuthProvider } from './context/AuthContext';
import { AuditProvider } from './context/AuditContext';
import { AppShell } from './components/layout/AppShell';

export function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <AuditProvider>
          <AppShell />
        </AuditProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}

export default App;
