import { CreditFacility, ChecklistItem, UserAccount, FacilityType, ConstitutionType, SectorType } from '../types/audit';
import { computeDrawingPower } from '../services/dpEngine';
import { computeIRACClassification, DEFAULT_RBI_RATES } from '../services/iracEngine';

export const INITIAL_USERS: UserAccount[] = [
  {
    id: 'usr_ca_lead',
    name: 'CA. Rajesh Sharma',
    email: 'rajesh.sharma@ca-audit.in',
    role: 'admin',
    membershipNumber: '054321',
    designation: 'Senior Partner & CA Engagement Leader',
    phone: '+91 98201 54321',
    firmName: 'R. Sharma & Associates, Chartered Accountants',
    branchAssigned: 'Nariman Point Corporate Branch (0142)',
    isAdmin: true,
  },
  {
    id: 'usr_ca_senior',
    name: 'CA. Priya Iyer',
    email: 'priya.iyer@ca-audit.in',
    role: 'admin',
    membershipNumber: '128940',
    designation: 'Audit Partner & Reviewer',
    phone: '+91 98450 12894',
    firmName: 'R. Sharma & Associates, Chartered Accountants',
    branchAssigned: 'Nariman Point Corporate Branch (0142)',
    isAdmin: true,
  },
  {
    id: 'usr_ca_assistant',
    name: 'Rohan Deshmukh',
    email: 'rohan.deshmukh@ca-audit.in',
    role: 'staff',
    membershipNumber: 'CA-ART-8821',
    designation: 'Audit Staff / Senior Article Assistant',
    phone: '+91 97654 32109',
    firmName: 'R. Sharma & Associates, Chartered Accountants',
    branchAssigned: 'Nariman Point Corporate Branch (0142)',
    isAdmin: false,
  },
  {
    id: 'usr_bank_officer',
    name: 'Amitabh Sen',
    email: 'amitabh.sen@bank.co.in',
    role: 'read-only',
    designation: 'Chief Manager - Credit & Advances (Inspection)',
    phone: '+91 98111 22334',
    firmName: 'Nationalized Commercial Bank of India',
    branchAssigned: 'Nariman Point Corporate Branch (0142)',
    isAdmin: false,
  }
];

export const STANDARD_CHECKLIST_TEMPLATE: Omit<ChecklistItem, 'id'>[] = [
  {
    title: 'Sanction Letter & Acceptance by Borrower',
    category: 'Legal',
    status: 'Obtained & Valid',
    expiryDate: '2027-03-31',
    documentRef: 'SANCT/2025-26/0491',
    remarks: 'Duly countersigned by all partners/directors.'
  },
  {
    title: 'Demand Promissory Note (DPN) & Loan Agreement',
    category: 'Legal',
    status: 'Obtained & Valid',
    expiryDate: '2028-03-31',
    documentRef: 'DPN/00918',
    remarks: 'Stamped adequately as per State Stamp Act.'
  },
  {
    title: 'Hypothecation Agreement for Stocks & Book Debts',
    category: 'Security',
    status: 'Obtained & Valid',
    expiryDate: '2027-03-31',
    documentRef: 'HYPO/2024/09',
    remarks: 'Valid charge created on all current assets.'
  },
  {
    title: 'ROC Charge Registration (Form CHG-1) / CERSAI',
    category: 'Charge',
    status: 'Obtained & Valid',
    expiryDate: '2029-06-30',
    documentRef: 'CHG1/SRN/X982173',
    remarks: 'Certificate of registration of charge received from RoC.'
  },
  {
    title: 'Comprehensive Fire & Burglary Insurance Policy',
    category: 'Insurance',
    status: 'Obtained & Valid',
    expiryDate: '2026-11-30',
    documentRef: 'POL-GIC-9812903',
    remarks: 'Bank clause endorsed; sum insured adequate.'
  },
  {
    title: 'Latest Certified Stock & Book Debt Statement',
    category: 'Financial',
    status: 'Obtained & Valid',
    expiryDate: '2026-09-30',
    documentRef: 'STMT/AUG26',
    remarks: 'Submitted within 15 days of month end.'
  },
  {
    title: 'Audited Financial Statements & Tax Audit Report',
    category: 'Financial',
    status: 'Obtained & Valid',
    expiryDate: '2026-10-31',
    documentRef: 'BAL-FY25-SIGNED',
    remarks: 'Audited by independent statutory auditor; clean opinion.'
  },
  {
    title: 'Title Deeds Search & Non-Encumbrance Certificate (NEC)',
    category: 'Legal',
    status: 'Obtained & Valid',
    expiryDate: '2027-03-31',
    documentRef: 'NEC-ADV-ADV901',
    remarks: 'Search for 30 years clear title by Bank Empanelled Advocate.'
  },
  {
    title: 'Personal Guarantee Deeds of Promoters / Directors',
    category: 'Security',
    status: 'Obtained & Valid',
    expiryDate: '2028-03-31',
    documentRef: 'PGD/2024/11',
    remarks: 'Net worth statements verified with IT returns.'
  }
];

// 300 Indian Enterprise base names
const INDIAN_BUSINESS_NAMES: string[] = [
  "Apex Precision Engineering Pvt. Ltd.",
  "Saffron Textiles & Fabrics LLP",
  "Zenith Logistics & Cold Chain Infrastructure",
  "Vardhman Agro Commodities",
  "Blue Horizon Hospitality & Resorts Pvt. Ltd.",
  "Sterling Metallurgical Industries Ltd.",
  "M/s. Somnath Financial Services",
  "Trans-India Infra Projects Ltd.",
  "Kaveri Cotton Ginning Mills",
  "Pinnacle Pharmaceuticals India Pvt. Ltd.",
  "Maharaja Spices & Export House",
  "Aditya Solar & Clean Energy Ltd.",
  "Bharat Heavy Steel Fabricators",
  "Ganesh Polyplast Industries",
  "Shree Ram Rolling Mills LLP",
  "Titan Precision Auto Components",
  "Godavari Sugar & Allied Industries",
  "Navkar Paper & Packaging Products",
  "Sunrise Realtech & Infrastructure LLP",
  "Omkar Granites & Marbles Pvt. Ltd.",
  "Krishna Dairy Products & Agro Foods",
  "Sudarshan Chemical Synthetics Ltd.",
  "Balaji Cotton & Yarn Spinners",
  "Laxmi Flour & Grain Processing",
  "Kalyan Ceramic Tiles & Sanitaryware",
  "Navjivan Diagnostic & Healthcare",
  "Arihant Diamond & Jewellery Works",
  "Hindustan Transformer & Electricals",
  "Vardhaman Foundry & Castings",
  "Maruti Leather Goods & Tannery",
  "Falcon Cold Storage & Logistics",
  "Ridhi Sidhi Timber & Wood Craft",
  "Shreeji Polychem & Resins LLP",
  "Ambica Cotton Pressing Factory",
  "Saraswati Educational & Research Trust",
  "National Rubber & Conveyor Belts",
  "Pooja Print & Pack Industries",
  "Tirupati Balaji Cement Products",
  "Universal Wire & Cables Ltd.",
  "Radhe Krishna Edible Oils",
  "Kuber Financial Consultants LLP",
  "Kisan Agro Seeds & Fertilizers",
  "Siddhi Vinayak Steels Pvt. Ltd.",
  "Everest Pharmaceuticals & Labs",
  "Deepak Rice Mills & Agri Export",
  "Jindal Aluminum Extrusions",
  "Surat Dyeing & Printing Works",
  "Shree Ganesh Auto Forge",
  "Galaxy Inox Tubes & Pipes Ltd.",
  "Kohinoor Tea Estates & Blenders",
  "Devika Construction & Developers",
  "Narmada Pipes & Sanitary Fitting",
  "Matrix Telecom & Fiber Solutions",
  "Vikas Agro Chemicals & Bio-tech",
  "Choudhary Transport Corporation",
  "Rajdhani Masala & Food Products",
  "Swastik Plastic Molding Works",
  "Classic Garments & Apparels LLP",
  "Bhiwandi Warehousing & Freight",
  "Alok Knits & Weaving Mills",
  "Manikchand Tobacco & FMCG Corp",
  "Metro City Housing & Infra Ltd.",
  "Kandla Port Stevedoring Services",
  "Jindal Pre-Cast Concrete Solutions",
  "Mahaveer Cotton & Ginning Press",
  "Siddharth Glass & Mirror Works",
  "Surabhi Dairy & Frozen Foods",
  "Orient Electrical Appliances",
  "Prabhat Oil & Solvent Extraction",
  "Shivam Auto Spares & Ancillaries",
  "Dhanlaxmi Jewellers & Bullion",
  "Karnavati Engineering Works",
  "Bhagwati Tea Packaging Co.",
  "Standard Fasteners & Bolts",
  "Mayur Leather Tannery & Footwear",
  "Pioneer Solar Systems Pvt. Ltd.",
  "Kalyani Iron & Scrap Recyclers",
  "Shree Sai Baba Sugar Mills",
  "Gujarat Petrochem Distributorship",
  "Vikas Bio-Pharma Laboratories",
  "Shubham Yarn & Textile Traders",
  "Ratan Commercial Logistics LLP",
  "Rajputana Minerals & Chemicals",
  "Gaurav Paper Cones & Tubes",
  "Vanguard Security & Facility Care",
  "Chirag Electronic Components",
  "Shree Ganesh Cold Storage",
  "Anand Milk Collection & Processing",
  "Surat Art Silk Weaving Mills",
  "Konkan Marine Fisheries & Export",
  "Shree Vallabh Chemical Synthetics",
  "Indus Power Generators & Motors",
  "Nandi Cattle Feed & Agro",
  "Pooja Polyesters & Filament",
  "Riddhi Siddhi Real Estate Developers",
  "Goyal Iron Foundry & Casting",
  "Sagar Water Purifiers & Pipes",
  "Arihant Medical Supplies LLP",
  "Royal Auto Gears & Bearings",
  "Vaishno Devi Flour & Rice Mills",
  "Gitanjali Gems & Gold Ornaments",
  "Shree Balaji Transporters",
  "Mehsana Agro Tech & Farm Implements",
  "Diamond Dye Chem Industries",
  "Kasturi Cotton Ginning & Pressing",
  "Pankaj Plastic & Polymer Sheets",
  "Himalaya Ayurvedic Herbals",
  "Surat Diamond Cutting & Polishing",
  "Shree Tirupati Cement & Asbestos",
  "Krishna Engineering & Boiler Works",
  "Vardhman Thread & Spools LLP",
  "Sterling Wire Mesh & Fencing",
  "Pritam Hospitality & Banquets",
  "Siddhi Vinayak Edible Oils",
  "Alaknanda Paper & Stationery",
  "Jay Jalaram Agri Commodities",
  "Adarsh Hospital & Maternity Care",
  "Kesar Sweets & Confectionery",
  "Balaji Auto Components Pvt Ltd",
  "Navrang Prints & Textile Processing",
  "Mahalaxmi Dyes & Auxiliaries",
  "Raman Polychem & Coatings",
  "Shree Durga Rice Mills",
  "Zenith Transformers & Electric",
  "Marwar Granites & Sandstone",
  "Bikaner Sweets & Namkeen Factory",
  "Godavari Biorefineries & Alcohol",
  "Suraj Precision Steel Tubes",
  "Paras Agro Food Products",
  "Kalyan Jewellers Franchise Partner",
  "Shree Ganesh Logistics & CFS",
  "Amardeep Dyeing Mills LLP",
  "Gautam Auto Spares & Gears",
  "Lalita Textile Weaving Factory",
  "National Fasteners & Spring Works",
  "Narmada Agro Bio-Fertilizers",
  "Shree Ram Polychem & Plastic",
  "Vishwakarma Wood Industries",
  "Pavitra Organic Farm Fresh",
  "Dhanwantari Pharma Formulations",
  "Apex Industrial Safety Equipments",
  "Satyam Ceramic Wall Tiles",
  "Bhavani Iron & Steel Traders",
  "Kuber Cotton Pressing Mills",
  "Shri Hari Bio Fuels & Ethanol",
  "Rishabh Gems & Diamonds",
  "Chaitanya Educational Society",
  "Radha Krishna Flour Mills",
  "Sujata Knitting & Hosiery Works",
  "Vanguard Heavy Earthmovers",
  "Manasvi Chemical Industries",
  "Om Agro Seeds & Fertilizers",
  "Shree Mahavir Auto Body Builders",
  "Jalgaon Banana Ripening & Export",
  "Kisan Seva Cold Storage LLP",
  "Supreme Polyesters & Fibers",
  "Harshdeep Paper Mills Pvt Ltd",
  "Gauri Shankar Tea & Spices",
  "Siddheshwar Sugar Factory",
  "Raj Auto Spares & Lubricants",
  "Shreeji Cotton Ginning Mill",
  "Devbhoomi Agro Produce",
  "Kanak Jewellers & Goldsmiths",
  "Pooja Engineering & Welding",
  "Surat Jacquard Silk Mills",
  "Tulsi Organic Dairy Products",
  "Ravi Solar Power & Energy",
  "Shree Krishna Logistics & Warehousing",
  "Adarsh Cement Products",
  "Vipul Chemicals & Dyes",
  "Maruti Wire Drawing Works",
  "Ganesh Textile Weaving House",
  "Bhavna Plastic Molding",
  "Kalyani Agro Cold Storage",
  "Shree Ram Paper Box Factory",
  "Sardar Vallabhbhai Cotton Press",
  "Dhanlaxmi Cotton & Ginning",
  "Mahalaxmi Roller Flour Mills",
  "Indo-Asian Medical Devices",
  "Tirupati Steels & TMT Bars",
  "Sai Krupa Polybags & Sacks",
  "Ambica Agro Seeds & Crop Science",
  "Paramount Electronics & PCBs",
  "Shree Ganesh Minerals & Quartz",
  "Vardhman Auto Components LLP",
  "Radhika Synthetic Mills",
  "Kaveri Rice & Pulse Processing",
  "Navratan Gems & Jewellery",
  "Jindal Fasteners & Rivets",
  "Shreeji Transport Carriers",
  "Siddharth Metal Works & Utensils",
  "Pioneer Polychem Pvt Ltd",
  "Alankar Gold & Silversmiths",
  "Vikas Cold Storage & Warehousing",
  "Swastik Flour Mills & Gram Flour",
  "Kisan Agro Equipment & Tractors",
  "Royal Cotton Spinners LLP",
  "Shree Ramakrishna Agro Foods",
  "Manish Poly Extrusions",
  "Goyal Steels & Re-Rollers",
  "Surat Embroidery & Laces",
  "Hindustan Bearing Corporation",
  "Shree Balaji Ceramic Ware",
  "Kailash Paper & Boards",
  "Narmada Agro Cold Chain",
  "Paras Jewellers & Bullion",
  "Sunder Deep Engineering Works",
  "Arihant Synthetic Yarn",
  "Krishna Wire Products",
  "Pooja Textile Printing Press",
  "Shree Sai Hospital & Research",
  "Mehsana Cotton & Agro",
  "Ratan Real Estate Developers",
  "Deepak Leather & Tannery",
  "Balaji Metal & Alloys",
  "Laxmi Polychem & Resins",
  "Sudarshan Auto Ancillaries",
  "Falcon Pharma Formulations",
  "Godavari Flour Mills",
  "Navkar Poly Sacks",
  "Omkar Metal Crafts",
  "Sunrise Agro Commodities",
  "Titan Steel Alloys",
  "Shreeji Cold Storage & Logistics",
  "Ganesh Cotton Ginning Mill",
  "Bharat Agri Biotech",
  "Aditya Auto Forge",
  "Maharaja Flour Mills",
  "Pinnacle Ceramic Works",
  "Kaveri Sugar & Ethanol",
  "Trans-India Logistics Hub",
  "M/s. Somnath Agro Foods",
  "Sterling Plastic Molding",
  "Blue Horizon Warehouses",
  "Vardhman Chemical Labs",
  "Zenith Bio-Energy Solutions",
  "Saffron Knitwear & Hosiery",
  "Apex Solar Power Park",
  "Kalyan Polychem Industries",
  "Devika Real Estate Consortium",
  "Kohinoor Spices & Condiments",
  "Galaxy Steel Re-Rollers",
  "Shree Ganesh Textile Park",
  "Surat Synthetic Yarn Spinners",
  "Jindal Precast Walls & Poles",
  "Deepak Bio-Fertilizers",
  "Everest Heavy Fabrications",
  "Siddhi Vinayak Transporters",
  "Kuber Gold Bullion Merchants",
  "Radhe Krishna Cotton Press",
  "Universal Transformer Works",
  "Tirupati Plastic Industries",
  "Pooja Cotton Ginning",
  "National Paper Bag Makers",
  "Saraswati Educational Academy",
  "Ambica Cold Chain & Storage",
  "Shreeji Pre-Cast Structures",
  "Ridhi Sidhi Ceramic Tiles",
  "Falcon Freight & Cargo Services",
  "Maruti Auto Forge & Parts",
  "Vardhaman Steel Billets",
  "Hindustan Sugar & Refineries",
  "Arihant Grain Processing Mills",
  "Navjivan Bio-Pharma Labs",
  "Kalyan Timber & Ply Industries",
  "Laxmi Cotton Weaving Factory",
  "Balaji Electronic Appliances",
  "Sudarshan Stone Crushers",
  "Krishna Pre-Engineered Buildings",
  "Omkar Agro Chemicals",
  "Sunrise Yarn & Threads",
  "Navkar Granite Polishing Works",
  "Godavari Cold Chain Systems",
  "Titan Auto Parts & Axles",
  "Shree Ram Cotton Corporation",
  "Ganesh Synthetic Dyeing",
  "Bharat Heavy Valves & Fittings",
  "Aditya Polyplast Polymers",
  "Maharaja Agro Cold Storage",
  "Pinnacle Steel Foundry",
  "Kaveri Ceramic Products",
  "Trans-India Warehousing Network",
  "M/s. Somnath Paper Mills",
  "Sterling Cotton Pressing",
  "Blue Horizon Properties",
  "Vardhman Agro Farm Implements",
  "Zenith Metal Formings",
  "Saffron Glass & Glazings",
  "Apex Synthetic Filaments",
  "Kalyan Food Products & Snacks",
  "Devika Infra Buildcon LLP",
  "Kohinoor Cotton Spinners",
  "Galaxy Rice Mills & Export",
  "Shree Ganesh Dairy Processing",
  "Surat Digital Textile Printers",
  "Jindal Heavy Machine Tools",
  "Deepak Agro Chemical Formulations",
  "Everest Bio Fuels & Biomass",
  "Siddhi Vinayak Foundry Works",
  "Kuber Ceramic sanitaryware",
  "Radhe Krishna Wire Drawing",
  "Universal Cotton Ginning Press",
  "Tirupati Edible Oils & Ghee",
  "Pooja Agro Cold Storage",
  "National Steel Tubing Co",
  "Saraswati Auto Ancillaries",
  "Ambica Synthetic Fiber Mills",
  "Shreeji Chemical Solvents",
  "Ridhi Sidhi Cold Chain",
  "Falcon Pre-Cast Concrete"
];

const SECTORS: SectorType[] = [
  'Micro & Small Enterprises (MSE)',
  'Micro & Small Enterprises (MSE)',
  'Medium Enterprises',
  'Agriculture & Allied',
  'Large Corporates / Infrastructure',
  'Commercial Real Estate (CRE)',
  'Commercial Real Estate - Residential Housing (CRE-RH)',
  'Services / Trading',
  'Retail / Housing Loan',
  'NBFC'
];

const FACILITIES: FacilityType[] = [
  'Cash Credit (CC)',
  'Cash Credit (CC)',
  'Cash Credit (CC)',
  'Term Loan (TL)',
  'Term Loan (TL)',
  'Overdraft (OD)',
  'Bank Guarantee (BG)',
  'Letter of Credit (LC)',
  'Demand Loan (DL)',
  'Bill Discounting'
];

const CONSTITUTIONS: ConstitutionType[] = [
  'Private Limited Company',
  'Private Limited Company',
  'Partnership Firm',
  'Partnership Firm',
  'Individual / Proprietorship',
  'LLP',
  'Public Limited Company',
  'Trust / Society',
  'HUF'
];

export function generate300Facilities(asOfDate: string = '2026-09-03'): CreditFacility[] {
  const branchName = 'Nariman Point Corporate Branch (0142)';
  const baseAuditTime = new Date(asOfDate).getTime();
  const list: CreditFacility[] = [];

  for (let i = 0; i < 300; i++) {
    const id = `fac_${String(i + 1).padStart(3, '0')}`;
    const borrowerName = INDIAN_BUSINESS_NAMES[i] || `M/s. Enterprise & Trading Co. ${i + 1}`;
    
    // Facility Type selection
    const facilityType = FACILITIES[i % FACILITIES.length];
    const constitution = CONSTITUTIONS[i % CONSTITUTIONS.length];
    const sector = SECTORS[i % SECTORS.length];

    // Account Number format
    const prefix = facilityType === 'Cash Credit (CC)' ? 'CC' 
      : facilityType === 'Term Loan (TL)' ? 'TL' 
      : facilityType === 'Overdraft (OD)' ? 'OD'
      : facilityType === 'Bank Guarantee (BG)' ? 'BG'
      : facilityType === 'Letter of Credit (LC)' ? 'LC'
      : facilityType === 'Demand Loan (DL)' ? 'DL' : 'BD';
    const accNum = `0142-${prefix}-${String(100000 + i + 1)}`;

    // Sanction Limits
    // Base limits from 20 Lakhs to 25 Crores
    const multiplier = ((i % 15) + 1) * 1000000; // 10L to 1.5 Cr base multiplier
    const sanctionedFund = facilityType === 'Bank Guarantee (BG)' || facilityType === 'Letter of Credit (LC)'
      ? 0
      : (i % 7 === 0 ? 50000000 : (i % 3 === 0 ? 25000000 : 10000000)) + multiplier;
    
    const sanctionedNFB = facilityType === 'Bank Guarantee (BG)' || facilityType === 'Letter of Credit (LC)'
      ? (15000000 + multiplier)
      : (i % 4 === 0 ? 5000000 : 0);

    const totalLimit = (sanctionedFund || sanctionedNFB);

    // Outstanding Balance logic
    // Few overdrawn limits (indices % 23 === 0)
    let outstanding = 0;
    if (sanctionedFund > 0) {
      if (i % 23 === 0) {
        outstanding = Math.round(sanctionedFund * 1.08); // Overdrawn limit by 8%
      } else {
        outstanding = Math.round(sanctionedFund * (0.65 + ((i % 25) * 0.01))); // 65% - 90%
      }
    } else {
      outstanding = Math.round(sanctionedNFB * 0.85);
    }

    // Security Realizable values
    const realizablePrimary = Math.round(totalLimit * (0.8 + ((i % 30) * 0.02)));
    const realizableCollateral = i % 2 === 0 ? Math.round(totalLimit * 0.45) : Math.round(totalLimit * 0.2);

    // Margins
    const isMarginBreached = i % 19 === 0;
    const stipulatedMargin = isMarginBreached ? 15 : 25;
    const bankNormMargin = 25;

    // Related party (Section 20 BRA 1949)
    const isRelatedParty = i % 37 === 0 || i === 6; // ~8 accounts
    const relatedPartyDetails = isRelatedParty
      ? `Promoter/Partner is related to Director on Bank Board. Governed under Section 20 of Banking Regulation Act 1949. Approved by Board Resolution BD/2025/${100 + i}.`
      : undefined;

    // Norms Overridden
    const isNormOverridden = isMarginBreached || isRelatedParty || (realizablePrimary + realizableCollateral < totalLimit);
    const overrideRemarks = isNormOverridden
      ? `Concession sanctioned per Competent Authority delegation ref: CR-SANCT/2025/${200 + i}.`
      : undefined;
    const overrideApprovingAuthority = isNormOverridden ? 'Board Credit Committee' : undefined;

    // Dates
    const sanctionYear = 2024 + (i % 2);
    const sanctionMonth = String((i % 12) + 1).padStart(2, '0');
    const sanctionDate = `${sanctionYear}-${sanctionMonth}-15`;

    // Renewal Due Date: Some due in < 30 days, some overdue, some normal
    let nextRenewalDueDate = '2027-04-30';
    if (i % 17 === 0) {
      nextRenewalDueDate = '2026-09-18'; // Due in ~15 days (Alert!)
    } else if (i % 29 === 0) {
      nextRenewalDueDate = '2026-07-31'; // Overdue! (Alert!)
    } else if (i % 5 === 0) {
      nextRenewalDueDate = '2026-10-15';
    } else {
      nextRenewalDueDate = `2027-${String((i % 11) + 1).padStart(2, '0')}-28`;
    }

    // Insurance Expiry: Some expiring in < 30 days
    let insuranceExpiryDate = '2027-06-30';
    if (i % 13 === 0) {
      insuranceExpiryDate = '2026-09-22'; // Expiring in <30 days (Alert!)
    } else if (i % 31 === 0) {
      insuranceExpiryDate = '2026-08-15'; // Expired! (Alert!)
    } else {
      insuranceExpiryDate = `2027-${String(((i + 3) % 12) + 1).padStart(2, '0')}-30`;
    }

    // NPA & IRAC conditions
    let isNPA = false;
    let npaDate = undefined;
    let isLossFlagged = false;

    if (i % 47 === 0 || i === 8) {
      isNPA = true;
      isLossFlagged = true;
      npaDate = '2022-03-31';
    } else if (i % 39 === 0 || i === 5) {
      isNPA = true;
      npaDate = '2024-06-30'; // ~26 months -> Doubtful 2 (D2)
    } else if (i % 27 === 0) {
      isNPA = true;
      npaDate = '2025-04-15'; // ~16 months -> Doubtful 1 (D1)
    } else if (i % 19 === 0 || i === 4) {
      isNPA = true;
      npaDate = '2025-12-31'; // ~8 months -> Sub-Standard
    }

    // IRAC Computation
    const iracRes = computeIRACClassification({
      isNPA,
      npaDate,
      isLossFlagged,
      outstandingBalance: outstanding,
      realizableSecurityPrimary: realizablePrimary,
      realizableSecurityCollateral: realizableCollateral,
      sector: sector,
      asOfDate: asOfDate,
      customRates: DEFAULT_RBI_RATES
    });

    const iracWorking = {
      id: `irac_${id}`,
      facilityId: id,
      asOfDate: asOfDate,
      isNPA,
      npaDate,
      monthsElapsedSinceNPA: iracRes.monthsElapsedSinceNPA,
      computedCategory: iracRes.category,
      isLossManuallyFlagged: isLossFlagged,
      outstandingBalance: outstanding,
      realizableSecurityPrimary: realizablePrimary,
      realizableSecurityCollateral: realizableCollateral,
      totalRealizableSecurity: iracRes.totalRealizableSecurity,
      securedPortion: iracRes.securedPortion,
      unsecuredPortion: iracRes.unsecuredPortion,
      provisionRateSecuredPercent: iracRes.rateSecured,
      provisionRateUnsecuredPercent: iracRes.rateUnsecured,
      provisionAmountSecured: iracRes.provisionSecured,
      provisionAmountUnsecured: iracRes.provisionUnsecured,
      totalProvisionAmount: iracRes.totalProvision,
      effectiveProvisionPercent: iracRes.effectiveRatePercent,
      remarks: `Provision computed under RBI master circular as on ${asOfDate}`,
      updatedAt: '2026-08-28T10:00:00Z'
    };

    // DP Working setup for CC/OD
    let dpWorking = undefined;
    if (facilityType === 'Cash Credit (CC)' || facilityType === 'Overdraft (OD)') {
      let isStaleStmt = (i % 21 === 0);
      let stmtDate = isStaleStmt ? '2026-04-10' : '2026-08-15'; // 146 days old vs fresh
      let isOverdrawnDP = (i % 11 === 0);

      let stockVal = Math.round(outstanding * (isOverdrawnDP ? 0.7 : 1.3));
      let credVal = Math.round(stockVal * 0.25);
      let debtsTotal = Math.round(outstanding * (isOverdrawnDP ? 0.4 : 0.8));
      let debtsOverdue = Math.round(debtsTotal * (isOverdrawnDP ? 0.5 : 0.15));

      const dpRes = computeDrawingPower({
        stockValue: stockVal,
        creditorsForStock: credVal,
        marginPercentOnStock: stipulatedMargin,
        bookDebtsTotal: debtsTotal,
        bookDebtsOverdue: debtsOverdue,
        permissibleDebtAgeMonths: 90,
        marginPercentOnDebtors: 40,
        statementDate: stmtDate,
        auditDate: asOfDate
      });

      dpWorking = {
        id: `dp_${id}`,
        facilityId: id,
        statementDate: stmtDate,
        stockValue: stockVal,
        creditorsForStock: credVal,
        unpaidStock: credVal,
        marginPercentOnStock: stipulatedMargin,
        netPaidStock: dpRes.netPaidStock,
        bookDebtsTotal: debtsTotal,
        bookDebtsOverdue: debtsOverdue,
        bookDebtsEligible: dpRes.eligibleDebtors,
        permissibleDebtAgeMonths: 90,
        marginPercentOnDebtors: 40,
        netEligibleDebtors: dpRes.netEligibleDebtors,
        computedDP: dpRes.computedDP,
        isStale: dpRes.isStale,
        remarks: dpRes.isStale ? 'Stock statement is stale (>90 days overdue).' : 'Calculated in accordance with sanctioned terms.',
        updatedAt: '2026-08-28T10:00:00Z'
      };
    }

    const isReviewed = i % 3 === 0;

    list.push({
      id,
      accountNumber: accNum,
      borrowerName,
      branch: branchName,
      facilityType,
      constitution,
      industrySector: sector,
      sanctionDate,
      sanctioningAuthority: i % 2 === 0 ? 'Credit Sanction Committee' : 'Zonal Head (Scale V)',
      lastRenewalDate: '2025-10-10',
      nextRenewalDueDate,
      interestRate: Number((8.75 + ((i % 15) * 0.25)).toFixed(2)),
      sanctionedLimitFundBased: sanctionedFund,
      sanctionedLimitNonFundBased: sanctionedNFB,
      totalSanctionedLimit: totalLimit,
      outstandingBalance: outstanding,
      primarySecurity: 'First hypothecation charge on current assets, inventory, raw materials and trade receivables.',
      collateralSecurity: realizableCollateral > 0 ? `Registered mortgage on Commercial/Industrial property Unit ${100 + i}.` : 'Nil / Personal Guarantee only.',
      realizableValuePrimary: realizablePrimary,
      realizableValueCollateral: realizableCollateral,
      guarantors: `Promoter Director ${String.fromCharCode(65 + (i % 26))}. Sharma & Key Partners`,
      stipulatedMarginPercent: stipulatedMargin,
      bankNormMarginPercent: bankNormMargin,
      isRelatedParty,
      relatedPartyDetails,
      insuranceDetails: `National/New India General Insurance Policy No. POL-${880000 + i}`,
      insuranceExpiryDate,
      insuranceAmount: Math.round(totalLimit * 1.15),
      isNormOverridden,
      overrideRemarks,
      overrideApprovingAuthority,
      checklist: STANDARD_CHECKLIST_TEMPLATE.map((chk, cIdx) => ({
        ...chk,
        id: `chk_${id}_${cIdx}`,
        status: (i % 9 === 0 && cIdx === 4) ? 'Obtained but Expired / Due' : 'Obtained & Valid'
      })),
      currentDPWorking: dpWorking,
      currentIRAC: iracWorking,
      additionalNotes: isRelatedParty ? 'Section 20 compliance verified against Board minutes.' : 'Borrower operations verified with bank ledger and GST returns.',
      auditorObservations: isNPA
        ? `Account is non-performing. Required provision computed per RBI IRAC guidelines as of ${asOfDate}.`
        : (outstanding > totalLimit ? 'Outstanding balance is exceeding the sanctioned limit. Needs regularisation.' : 'Turnover in the account is proportionate to scale of business. Documentation verified.'),
      isReviewed,
      reviewedBy: isReviewed ? 'CA. Rajesh Sharma' : undefined,
      reviewedAt: isReviewed ? '2026-08-30T14:00:00Z' : undefined,
      isSubmitted: true,
      isLocked: true,
      lockedBy: 'CA. Rajesh Sharma (Lead Partner)',
      lockedAt: '2026-08-30T14:00:00Z',
      isArchived: false,
      createdBy: 'usr_ca_senior',
      createdAt: '2026-08-15T09:00:00Z',
      updatedBy: 'usr_ca_senior',
      updatedAt: '2026-08-30T14:00:00Z',
    });
  }

  return list;
}

export function initializeSeedFacilities(): CreditFacility[] {
  return generate300Facilities('2026-09-03');
}
