import React, { useState } from 'react';
import { UserAccount, UserRole } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { Select } from '../common/Select';
import { useAuth } from '../../context/AuthContext';
import { useAudit } from '../../context/AuditContext';
import { 
  Users, 
  UserPlus, 
  Edit, 
  Trash2, 
  Check, 
  Shield, 
  Save, 
  X,
  UserCheck,
  Building2,
  Lock,
  Unlock,
  ShieldCheck,
  AlertCircle
} from 'lucide-react';
import clsx from 'clsx';

interface TeamManagementModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ROLE_OPTIONS: { value: UserRole; label: string }[] = [
  { value: 'admin', label: '🛡️ CA Admin / Partner (Full Authorisation & Delete Rights)' },
  { value: 'staff', label: '✍️ Audit Staff / Assistant (Data Entry & Drafts; Cannot Delete Saved)' },
  { value: 'read-only', label: '👁️ Read-Only / Bank Official (Inspection & View Only)' },
];

export const TeamManagementModal: React.FC<TeamManagementModalProps> = ({ isOpen, onClose }) => {
  const { allUsers, currentUser, switchUser, updateUserList, isAdmin } = useAuth();
  const { auditMetadata } = useAudit();

  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // Form State
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<UserRole>('staff');
  const [membershipNumber, setMembershipNumber] = useState('');
  const [designation, setDesignation] = useState('');
  const [phone, setPhone] = useState('');

  const handleStartEdit = (user: UserAccount) => {
    setIsAddingNew(false);
    setEditingUserId(user.id);
    setName(user.name);
    setEmail(user.email);
    setRole(user.role === 'reviewer' ? 'admin' : (user.role === 'auditor' ? 'staff' : user.role));
    setMembershipNumber(user.membershipNumber || '');
    setDesignation(user.designation || '');
    setPhone(user.phone || '');
  };

  const handleStartAdd = () => {
    setIsAddingNew(true);
    setEditingUserId(null);
    setName('');
    setEmail('');
    setRole('staff');
    setMembershipNumber('');
    setDesignation('Audit Assistant / Article Trainee');
    setPhone('');
  };

  const handleCancelForm = () => {
    setEditingUserId(null);
    setIsAddingNew(false);
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    if (isAddingNew) {
      const newUser: UserAccount = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substr(2, 4)}`,
        name: name.trim(),
        email: email.trim() || `${name.toLowerCase().replace(/[^a-z0-9]/g, '.')}@ca-audit.in`,
        role,
        membershipNumber: membershipNumber.trim() || undefined,
        designation: designation.trim() || undefined,
        phone: phone.trim() || undefined,
        firmName: auditMetadata.firmName,
        branchAssigned: `${auditMetadata.branchName} (${auditMetadata.branchCode})`,
        isAdmin: role === 'admin',
      };
      updateUserList([...allUsers, newUser]);
      setIsAddingNew(false);
    } else if (editingUserId) {
      const updated = allUsers.map(u => {
        if (u.id === editingUserId) {
          return {
            ...u,
            name: name.trim(),
            email: email.trim(),
            role,
            membershipNumber: membershipNumber.trim() || undefined,
            designation: designation.trim() || undefined,
            phone: phone.trim() || undefined,
            isAdmin: role === 'admin',
          };
        }
        return u;
      });
      updateUserList(updated);
      setEditingUserId(null);
    }
  };

  const handleDeleteUser = (userId: string) => {
    if (allUsers.length <= 1) {
      alert('You must retain at least one user account in the audit team.');
      return;
    }
    if (window.confirm('Remove this CA/staff member from the audit engagement team?')) {
      const filtered = allUsers.filter(u => u.id !== userId);
      updateUserList(filtered);
      if (currentUser.id === userId) {
        switchUser(filtered[0].id);
      }
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Audit Team, CA & Staff Profile Management"
      subtitle="Assign CA Admin vs Staff roles, set data entry and deletion authorisations, and edit profiles"
      maxWidth="4xl"
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      <div className="space-y-6">
        {/* Top Summary Banner */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-4 bg-blue-50/70 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900 text-xs text-blue-950 dark:text-blue-200">
          <div>
            <span className="font-bold text-sm text-blue-900 dark:text-blue-100 block">
              Auditing CA Firm: {auditMetadata.firmName}
            </span>
            <p className="mt-0.5 text-blue-700 dark:text-blue-300">
              Assigned to Branch: {auditMetadata.branchName} ({auditMetadata.branchCode})
            </p>
          </div>
          {!isAddingNew && !editingUserId && (
            <Button
              variant="primary"
              size="sm"
              icon={<UserPlus className="w-4 h-4" />}
              onClick={handleStartAdd}
            >
              Add CA / Staff Member
            </Button>
          )}
        </div>

        {/* Role Permissions Matrix Card */}
        <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 text-xs space-y-2">
          <h5 className="font-bold text-slate-900 dark:text-slate-100 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            Role-Based Authorization & Security Rules
          </h5>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <div className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="font-bold text-purple-700 dark:text-purple-300 block mb-1">
                🛡️ CA Admin / Partner
              </span>
              <ul className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px] list-disc list-inside">
                <li>Full Data Entry & Modification rights</li>
                <li>Can modify saved & locked facilities anytime</li>
                <li><strong>Exclusive authorization to DELETE saved records</strong></li>
                <li>Can lock/unlock records and manage team roles</li>
              </ul>
            </div>
            <div className="p-2.5 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-800">
              <span className="font-bold text-blue-700 dark:text-blue-300 block mb-1">
                ✍️ Audit Staff / Assistant
              </span>
              <ul className="space-y-1 text-slate-600 dark:text-slate-400 text-[11px] list-disc list-inside">
                <li>Can add new credit facilities & edit while entering/drafting</li>
                <li>Once saved into register, records are protected</li>
                <li><strong>CANNOT delete saved records</strong></li>
                <li>Modifying saved records requires Admin authorization & justification</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Add / Edit Form Drawer */}
        {(isAddingNew || editingUserId) && (
          <form
            onSubmit={handleSaveUser}
            className="p-5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-4 animate-in fade-in duration-150"
          >
            <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-3">
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
                <Edit className="w-4 h-4 text-blue-600" />
                {isAddingNew ? 'Add New CA / Staff Member' : 'Edit CA / Staff Member Profile'}
              </h4>
              <button
                type="button"
                onClick={handleCancelForm}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Full Name (with Prefix e.g. CA. Rajesh Sharma)"
                required
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="e.g. CA. Rajesh Sharma"
              />
              <Input
                label="Email Address"
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="rajesh.sharma@ca-firm.in"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Select
                label="Role & Authorization Level"
                value={role}
                onChange={e => setRole(e.target.value as UserRole)}
                options={ROLE_OPTIONS}
              />
              <Input
                label="Designation in Audit Team"
                value={designation}
                onChange={e => setDesignation(e.target.value)}
                placeholder="e.g. Engagement Partner / Audit Senior"
              />
              <Input
                label="ICAI Membership No. (if CA)"
                value={membershipNumber}
                onChange={e => setMembershipNumber(e.target.value)}
                placeholder="e.g. 054321"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Contact Phone / Mobile"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="+91 98201 54321"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <Button type="button" variant="secondary" size="sm" onClick={handleCancelForm}>
                Cancel
              </Button>
              <Button type="submit" variant="primary" size="sm" icon={<Save className="w-4 h-4" />}>
                Save Profile
              </Button>
            </div>
          </form>
        )}

        {/* User Accounts List */}
        <div className="space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Active Engagement Team Members ({allUsers.length})
          </h4>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
            {allUsers.map(user => {
              const isActive = currentUser.id === user.id;
              const isUserAdmin = user.role === 'admin' || user.role === 'reviewer' || user.isAdmin;

              return (
                <div
                  key={user.id}
                  className={clsx(
                    'p-4 bg-white dark:bg-slate-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 transition-colors',
                    isActive && 'bg-blue-50/40 dark:bg-blue-950/20'
                  )}
                >
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center font-bold text-sm shrink-0 shadow-xs">
                      {user.name.replace('CA.', '').trim().charAt(0)}
                    </div>
                    <div className="min-w-0 space-y-0.5">
                      <div className="flex items-center gap-2">
                        <h5 className="font-bold text-sm text-slate-900 dark:text-slate-100 truncate">
                          {user.name}
                        </h5>
                        {isActive && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                            Active Session
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        {user.designation || (isUserAdmin ? 'CA Partner / Admin' : 'Staff Auditor')} &bull; {user.email} {user.phone ? `&bull; ${user.phone}` : ''}
                      </p>
                      {user.membershipNumber && (
                        <p className="text-[11px] font-mono font-medium text-blue-600 dark:text-blue-400">
                          ICAI M. No: {user.membershipNumber}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions & Role Badge */}
                  <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                    <span
                      className={clsx(
                        'px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider',
                        isUserAdmin
                          ? 'bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border border-purple-200 dark:border-purple-800'
                          : user.role === 'staff' || user.role === 'auditor'
                          ? 'bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-800'
                          : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      )}
                    >
                      {isUserAdmin ? '🛡️ CA Admin' : (user.role === 'staff' || user.role === 'auditor' ? '✍️ Staff' : '👁️ Read-Only')}
                    </span>

                    {!isActive && (
                      <Button
                        variant="outline"
                        size="sm"
                        icon={<UserCheck className="w-3.5 h-3.5" />}
                        onClick={() => switchUser(user.id)}
                        title="Switch active user to this profile"
                      >
                        Switch
                      </Button>
                    )}

                    <Button
                      variant="ghost"
                      size="sm"
                      icon={<Edit className="w-3.5 h-3.5 text-blue-600" />}
                      onClick={() => handleStartEdit(user)}
                      title="Edit CA / Staff details"
                    />

                    {allUsers.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<Trash2 className="w-3.5 h-3.5 text-rose-500" />}
                        onClick={() => handleDeleteUser(user.id)}
                        title="Delete staff member"
                      />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </Modal>
  );
};
