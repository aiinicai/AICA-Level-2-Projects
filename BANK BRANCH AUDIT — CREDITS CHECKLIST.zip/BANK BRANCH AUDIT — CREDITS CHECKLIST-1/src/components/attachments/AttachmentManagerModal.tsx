import React, { useState } from 'react';
import { CreditFacility, AttachmentItem } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Select } from '../common/Select';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { Upload, File, Trash2, Download, Paperclip, FileText, CheckCircle2 } from 'lucide-react';

interface AttachmentManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  facility: CreditFacility | null;
}

const CATEGORIES: { value: AttachmentItem['category']; label: string }[] = [
  { value: 'Stock Statement', label: 'Stock / Debtors Statement' },
  { value: 'Sanction Letter', label: 'Sanction Letter / Loan Agreement' },
  { value: 'Search Report', label: 'Title Search / NEC / CERSAI' },
  { value: 'Valuation Report', label: 'Property Valuation Report' },
  { value: 'Insurance Policy', label: 'Insurance Policy & Premium Receipt' },
  { value: 'Other', label: 'Other Correspondence / Audited Financials' },
];

export const AttachmentManagerModal: React.FC<AttachmentManagerModalProps> = ({
  isOpen,
  onClose,
  facility,
}) => {
  if (!facility) return null;

  const { attachments, addAttachment, removeAttachment } = useAudit();
  const { currentUser, canEdit } = useAuth();
  const [category, setCategory] = useState<AttachmentItem['category']>('Stock Statement');
  const [uploading, setUploading] = useState(false);

  const facilityAttachments = attachments.filter(a => a.facilityId === facility.id);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    const reader = new FileReader();
    reader.onload = () => {
      const item: AttachmentItem = {
        id: `att_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        facilityId: facility.id,
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream',
        category,
        uploadedAt: new Date().toISOString(),
        uploadedBy: currentUser.name,
        dataUrl: reader.result as string,
      };
      addAttachment(item);
      setUploading(false);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  const handleDownload = (item: AttachmentItem) => {
    if (!item.dataUrl) return;
    const a = document.createElement('a');
    a.href = item.dataUrl;
    a.download = item.name;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Document Attachments: ${facility.borrowerName}`}
      subtitle={`Account: ${facility.accountNumber} | Stock statements, sanction letters & legal reports`}
      maxWidth="3xl"
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      <div className="space-y-6">
        {/* Upload Box */}
        {canEdit && (
          <div className="p-4 rounded-xl border border-dashed border-blue-300 dark:border-blue-800 bg-blue-50/50 dark:bg-blue-950/30 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 dark:text-blue-300 flex items-center gap-1.5">
              <Upload className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              Upload New Credit Attachment (Supabase / Local Vault)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 items-end">
              <div className="sm:col-span-2">
                <Select
                  label="Document Category"
                  value={category}
                  onChange={e => setCategory(e.target.value as AttachmentItem['category'])}
                  options={CATEGORIES}
                />
              </div>

              <div>
                <label className="cursor-pointer flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-sm font-semibold shadow-xs transition-colors">
                  <Paperclip className="w-4 h-4" />
                  <span>{uploading ? 'Processing...' : 'Browse & Upload'}</span>
                  <input
                    type="file"
                    className="hidden"
                    onChange={handleFileUpload}
                    disabled={uploading}
                  />
                </label>
              </div>
            </div>
          </div>
        )}

        {/* Existing Attachments List */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Attached Documents ({facilityAttachments.length})
            </h4>
          </div>

          {facilityAttachments.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs border border-slate-200 dark:border-slate-800 rounded-xl bg-slate-50/50 dark:bg-slate-900/40">
              <FileText className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-700 mb-1" />
              <p>No document attachments uploaded for this account yet.</p>
            </div>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden">
              {facilityAttachments.map(item => (
                <div
                  key={item.id}
                  className="p-3 bg-white dark:bg-slate-900 flex items-center justify-between gap-3 text-xs hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 shrink-0">
                      <File className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-slate-900 dark:text-slate-100 truncate">
                        {item.name}
                      </p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400">
                        {item.category} &bull; {(item.size / 1024).toFixed(1)} KB &bull; Uploaded by {item.uploadedBy} on {new Date(item.uploadedAt).toLocaleDateString()}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      icon={<Download className="w-3.5 h-3.5" />}
                      onClick={() => handleDownload(item)}
                      title="Download file"
                    />
                    {canEdit && (
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<Trash2 className="w-3.5 h-3.5 text-rose-500" />}
                        onClick={() => removeAttachment(item.id)}
                        title="Delete file"
                      />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Modal>
  );
};
