import React from 'react';
import { ShieldAlert, Info } from 'lucide-react';
import { NormOverrideCheck } from '../../services/dpEngine';

interface NormsOverrideWarningProps {
  check: NormOverrideCheck;
  overrideRemarks?: string;
  overrideApprovingAuthority?: string;
  onRemarksChange?: (remarks: string) => void;
  onAuthorityChange?: (authority: string) => void;
  isEditable?: boolean;
}

export const NormsOverrideWarning: React.FC<NormsOverrideWarningProps> = ({
  check,
  overrideRemarks = '',
  overrideApprovingAuthority = '',
  onRemarksChange,
  onAuthorityChange,
  isEditable = false,
}) => {
  if (!check.isOverridden && !check.reasons.length) return null;

  return (
    <div className="rounded-xl border border-rose-300 dark:border-rose-800 bg-rose-50/70 dark:bg-rose-950/40 p-4 space-y-3">
      <div className="flex items-start gap-3">
        <div className="p-2 bg-rose-100 dark:bg-rose-900/60 rounded-lg text-rose-600 dark:text-rose-400 shrink-0">
          <ShieldAlert className="w-5 h-5" />
        </div>
        <div className="space-y-1 flex-1">
          <div className="flex items-center gap-2">
            <h5 className="text-sm font-bold text-rose-900 dark:text-rose-200">
              Sanctioned Overriding Banking Norms
            </h5>
            <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-rose-200 text-rose-800 dark:bg-rose-900 dark:text-rose-300">
              High Risk
            </span>
          </div>
          <p className="text-xs text-rose-700 dark:text-rose-300">
            One or more statutory or prudential credit norms have been relaxed or breached for this facility.
          </p>

          {check.reasons.length > 0 && (
            <ul className="mt-2 space-y-1 text-xs text-rose-800 dark:text-rose-300 list-disc list-inside bg-white/50 dark:bg-slate-900/50 p-2.5 rounded-lg border border-rose-200 dark:border-rose-900/50">
              {check.reasons.map((reason, idx) => (
                <li key={idx} className="leading-relaxed font-medium">
                  {reason}
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      {isEditable ? (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-rose-200 dark:border-rose-900/50">
          <div>
            <label className="block text-xs font-semibold text-rose-900 dark:text-rose-200 mb-1">
              Sanctioning / Approving Authority <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Board of Directors / MD & CEO"
              value={overrideApprovingAuthority}
              onChange={e => onAuthorityChange?.(e.target.value)}
              className="w-full text-xs rounded-lg border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-900 p-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-rose-500"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-rose-900 dark:text-rose-200 mb-1">
              Mandatory Justification / Resolution Ref <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Approved vide Board Resolution BD/2025/89"
              value={overrideRemarks}
              onChange={e => onRemarksChange?.(e.target.value)}
              className="w-full text-xs rounded-lg border border-rose-300 dark:border-rose-700 bg-white dark:bg-slate-900 p-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-rose-500"
            />
          </div>
        </div>
      ) : (
        overrideRemarks && (
          <div className="p-2.5 rounded-lg bg-white/60 dark:bg-slate-900/60 border border-rose-200 dark:border-rose-900/50 text-xs">
            <span className="font-semibold text-rose-900 dark:text-rose-200">
              Authority / Justification on Record ({overrideApprovingAuthority || 'Competent Authority'}):
            </span>{' '}
            <span className="text-slate-700 dark:text-slate-300">{overrideRemarks}</span>
          </div>
        )
      )}
    </div>
  );
};
