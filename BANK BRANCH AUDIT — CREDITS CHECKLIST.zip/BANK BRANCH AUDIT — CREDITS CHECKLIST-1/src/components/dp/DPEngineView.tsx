import React, { useState } from 'react';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { CreditFacility } from '../../types/audit';
import { DPBadge } from './DPBadge';
import { DPWorksheetModal } from './DPWorksheetModal';
import { Button } from '../common/Button';
import { Calculator, AlertTriangle, Clock, CheckCircle2, AlertOctagon } from 'lucide-react';
import clsx from 'clsx';

export const DPEngineView: React.FC = () => {
  const { facilities, saveFacility } = useAudit();
  const { isReadOnly } = useAuth();
  const [selectedFac, setSelectedFac] = useState<CreditFacility | null>(null);

  const wcFacilities = facilities.filter(f => !f.isArchived && (f.facilityType === 'Cash Credit (CC)' || f.facilityType === 'Overdraft (OD)'));

  const handleSaveDP = (updatedDP: any) => {
    if (!selectedFac) return;
    const updated: CreditFacility = {
      ...selectedFac,
      currentDPWorking: updatedDP,
    };
    saveFacility(updated, 'Recalculated Drawing Power from DP Engine View');
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
            <Calculator className="w-6 h-6 text-blue-600" />
            Drawing Power (DP) & Sanction Limit Engine
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Automated stock & book debts net value formulas, margin norm checks, and 4-tier risk status monitoring
          </p>
        </div>
      </div>

      {/* Formula Explanatory Card */}
      <div className="p-4 rounded-xl bg-blue-50/70 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 grid grid-cols-1 md:grid-cols-2 gap-3 text-xs text-blue-950 dark:text-blue-200">
        <div>
          <strong className="font-bold text-blue-900 dark:text-blue-100">1. Net Value of Paid Stock:</strong>
          <p className="font-mono mt-0.5 text-[11px]">(Stock − Creditors for stock) × (1 − Margin% on stock)</p>
        </div>
        <div>
          <strong className="font-bold text-blue-900 dark:text-blue-100">2. Net Value of Eligible Book Debts:</strong>
          <p className="font-mono mt-0.5 text-[11px]">(Book debts within permissible age) × (1 − Margin% on debtors)</p>
        </div>
      </div>

      {/* Facilities DP Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Borrower / Account</th>
                <th className="py-3 px-4">Statement Date</th>
                <th className="py-3 px-4 text-right">Net Paid Stock</th>
                <th className="py-3 px-4 text-right">Eligible Debts</th>
                <th className="py-3 px-4 text-right">Computed DP</th>
                <th className="py-3 px-4 text-right">Outstanding</th>
                <th className="py-3 px-4">DP Status</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {wcFacilities.map(fac => {
                const dp = fac.currentDPWorking;
                return (
                  <tr key={fac.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-slate-100">
                        {fac.borrowerName}
                      </div>
                      <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                        {fac.accountNumber} ({fac.facilityType})
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono">
                      {dp?.statementDate || <span className="text-rose-500 font-bold">Missing</span>}
                    </td>
                    <td className="py-3 px-4 text-right font-mono">
                      ₹{((dp?.netPaidStock || 0) / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4 text-right font-mono">
                      ₹{((dp?.netEligibleDebtors || 0) / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-blue-700 dark:text-blue-400">
                      ₹{((dp?.computedDP || 0) / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-slate-100">
                      ₹{(fac.outstandingBalance / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4">
                      <DPBadge facility={fac} />
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Button
                        variant="outline"
                        size="sm"
                        icon={<Calculator className="w-3.5 h-3.5" />}
                        onClick={() => setSelectedFac(fac)}
                      >
                        Worksheet
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selectedFac && (
        <DPWorksheetModal
          isOpen={Boolean(selectedFac)}
          onClose={() => setSelectedFac(null)}
          facility={selectedFac}
          onSave={handleSaveDP}
          isReadOnly={isReadOnly}
        />
      )}
    </div>
  );
};
