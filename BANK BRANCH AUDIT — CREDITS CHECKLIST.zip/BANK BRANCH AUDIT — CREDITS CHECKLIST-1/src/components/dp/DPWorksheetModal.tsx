import React, { useState, useEffect } from 'react';
import { CreditFacility, DPWorking } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { computeDrawingPower, evaluateDPStatusBadge } from '../../services/dpEngine';
import { Calculator, AlertCircle, Save, Calendar, CheckCircle2 } from 'lucide-react';
import clsx from 'clsx';

interface DPWorksheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  facility: CreditFacility | null;
  onSave: (dp: DPWorking) => void;
  isReadOnly?: boolean;
}

export const DPWorksheetModal: React.FC<DPWorksheetModalProps> = ({
  isOpen,
  onClose,
  facility,
  onSave,
  isReadOnly = false,
}) => {
  if (!facility) return null;

  const current = facility.currentDPWorking;

  const [statementDate, setStatementDate] = useState(current?.statementDate || new Date().toISOString().split('T')[0]);
  const [stockValue, setStockValue] = useState<number>(current?.stockValue || 0);
  const [creditorsForStock, setCreditorsForStock] = useState<number>(current?.creditorsForStock || 0);
  const [marginPercentOnStock, setMarginPercentOnStock] = useState<number>(current?.marginPercentOnStock || facility.stipulatedMarginPercent || 25);

  const [bookDebtsTotal, setBookDebtsTotal] = useState<number>(current?.bookDebtsTotal || 0);
  const [bookDebtsOverdue, setBookDebtsOverdue] = useState<number>(current?.bookDebtsOverdue || 0);
  const [permissibleDebtAgeMonths, setPermissibleDebtAgeMonths] = useState<number>(current?.permissibleDebtAgeMonths || 90);
  const [marginPercentOnDebtors, setMarginPercentOnDebtors] = useState<number>(current?.marginPercentOnDebtors || 40);
  const [remarks, setRemarks] = useState(current?.remarks || '');

  useEffect(() => {
    if (facility && facility.currentDPWorking) {
      const dp = facility.currentDPWorking;
      setStatementDate(dp.statementDate);
      setStockValue(dp.stockValue);
      setCreditorsForStock(dp.creditorsForStock);
      setMarginPercentOnStock(dp.marginPercentOnStock);
      setBookDebtsTotal(dp.bookDebtsTotal);
      setBookDebtsOverdue(dp.bookDebtsOverdue);
      setPermissibleDebtAgeMonths(dp.permissibleDebtAgeMonths);
      setMarginPercentOnDebtors(dp.marginPercentOnDebtors);
      setRemarks(dp.remarks || '');
    }
  }, [facility]);

  // Live calculation
  const computed = computeDrawingPower({
    stockValue,
    creditorsForStock,
    marginPercentOnStock,
    bookDebtsTotal,
    bookDebtsOverdue,
    permissibleDebtAgeMonths,
    marginPercentOnDebtors,
    statementDate,
  });

  // Simulated temporary facility to evaluate status badge
  const previewFacility: CreditFacility = {
    ...facility,
    currentDPWorking: {
      id: current?.id || `dp_${facility.id}`,
      facilityId: facility.id,
      statementDate,
      stockValue,
      creditorsForStock,
      unpaidStock: creditorsForStock,
      marginPercentOnStock,
      netPaidStock: computed.netPaidStock,
      bookDebtsTotal,
      bookDebtsOverdue,
      bookDebtsEligible: computed.eligibleDebtors,
      permissibleDebtAgeMonths,
      marginPercentOnDebtors,
      netEligibleDebtors: computed.netEligibleDebtors,
      computedDP: computed.computedDP,
      isStale: computed.isStale,
      remarks,
      updatedAt: new Date().toISOString(),
    }
  };

  const status = evaluateDPStatusBadge(previewFacility);

  const handleSave = () => {
    if (isReadOnly) return;
    const working: DPWorking = {
      id: current?.id || `dp_${facility.id}`,
      facilityId: facility.id,
      statementDate,
      stockValue,
      creditorsForStock,
      unpaidStock: creditorsForStock,
      marginPercentOnStock,
      netPaidStock: computed.netPaidStock,
      bookDebtsTotal,
      bookDebtsOverdue,
      bookDebtsEligible: computed.eligibleDebtors,
      permissibleDebtAgeMonths,
      marginPercentOnDebtors,
      netEligibleDebtors: computed.netEligibleDebtors,
      computedDP: computed.computedDP,
      isStale: computed.isStale,
      remarks,
      updatedAt: new Date().toISOString(),
    };
    onSave(working);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Drawing Power (DP) Calculation Worksheet"
      subtitle={`Account: ${facility.accountNumber} — ${facility.borrowerName}`}
      maxWidth="4xl"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          {!isReadOnly && (
            <Button variant="primary" icon={<Save className="w-4 h-4" />} onClick={handleSave}>
              Save DP Working
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-6">
        {/* Status and Limits Banner */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs">
          <div>
            <span className="text-slate-500 dark:text-slate-400 block font-medium">Sanctioned Limit:</span>
            <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
              ₹{facility.totalSanctionedLimit.toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 block font-medium">Outstanding Balance:</span>
            <span className="text-sm font-bold text-slate-900 dark:text-slate-100">
              ₹{facility.outstandingBalance.toLocaleString('en-IN')}
            </span>
          </div>
          <div>
            <span className="text-slate-500 dark:text-slate-400 block font-medium">Current Status Assessment:</span>
            <span className={clsx('inline-block mt-0.5 font-bold', status.colorClass)}>
              {status.label}
            </span>
          </div>
        </div>

        {/* Statement Date & Stale Indicator */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-end bg-blue-50/50 dark:bg-blue-950/30 p-4 rounded-xl border border-blue-100 dark:border-blue-900/50">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Stock & Debtors Statement Date <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <input
                type="date"
                disabled={isReadOnly}
                value={statementDate}
                onChange={e => setStatementDate(e.target.value)}
                className="w-full text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-slate-900 dark:text-slate-100"
              />
            </div>
          </div>
          <div className="text-xs space-y-1">
            <span className="font-semibold text-slate-700 dark:text-slate-300">Statement Age:</span>
            <div className="flex items-center gap-2">
              <span className={clsx('font-bold', computed.isStale ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600 dark:text-emerald-400')}>
                {computed.daysSinceStatement} Days Elapsed
              </span>
              {computed.isStale && (
                <span className="px-2 py-0.5 bg-rose-100 dark:bg-rose-900/60 text-rose-700 dark:text-rose-300 text-[10px] font-bold rounded">
                  STALE (&gt;90 DAYS)
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Section A: Stock Valuation & Margin */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 flex items-center justify-center text-xs">
                A
              </span>
              Stock / Inventory Valuation & Net Paid Stock
            </h4>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Formula: (Stock − Creditors) × (1 − Margin%)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Input
              label="Gross Value of Stock (₹)"
              type="number"
              disabled={isReadOnly}
              currencyPrefix
              value={stockValue || ''}
              onChange={e => setStockValue(Number(e.target.value))}
              placeholder="0"
            />
            <Input
              label="Less: Creditors for Stock (₹)"
              type="number"
              disabled={isReadOnly}
              currencyPrefix
              value={creditorsForStock || ''}
              onChange={e => setCreditorsForStock(Number(e.target.value))}
              placeholder="0"
              helperText="Unpaid stock purchases"
            />
            <Input
              label="Stipulated Margin on Stock (%)"
              type="number"
              disabled={isReadOnly}
              value={marginPercentOnStock || ''}
              onChange={e => setMarginPercentOnStock(Number(e.target.value))}
              placeholder="25"
              helperText={`Bank norm: ${facility.bankNormMarginPercent}%`}
            />
          </div>

          {/* Paid stock result sub-box */}
          <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs">
            <span className="text-slate-600 dark:text-slate-400">
              Paid Stock: <strong className="text-slate-900 dark:text-slate-100">₹{computed.paidStock.toLocaleString('en-IN')}</strong> (Margin deducted: {marginPercentOnStock}%)
            </span>
            <span className="font-bold text-sm text-blue-700 dark:text-blue-400">
              Net Paid Stock: ₹{computed.netPaidStock.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Section B: Book Debts / Receivables Valuation & Margin */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 flex items-center justify-center text-xs">
                B
              </span>
              Book Debts / Receivables & Eligible Debts
            </h4>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Formula: (Eligible Debts within {permissibleDebtAgeMonths}d) × (1 − Margin%)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <Input
              label="Total Book Debts (₹)"
              type="number"
              disabled={isReadOnly}
              currencyPrefix
              value={bookDebtsTotal || ''}
              onChange={e => setBookDebtsTotal(Number(e.target.value))}
              placeholder="0"
            />
            <Input
              label={`Overdue / Aged Debts (>${permissibleDebtAgeMonths}d) (₹)`}
              type="number"
              disabled={isReadOnly}
              currencyPrefix
              value={bookDebtsOverdue || ''}
              onChange={e => setBookDebtsOverdue(Number(e.target.value))}
              placeholder="0"
              helperText="Ineligible receivables"
            />
            <Input
              label="Permissible Age (Days)"
              type="number"
              disabled={isReadOnly}
              value={permissibleDebtAgeMonths || ''}
              onChange={e => setPermissibleDebtAgeMonths(Number(e.target.value))}
              placeholder="90"
            />
            <Input
              label="Margin on Debtors (%)"
              type="number"
              disabled={isReadOnly}
              value={marginPercentOnDebtors || ''}
              onChange={e => setMarginPercentOnDebtors(Number(e.target.value))}
              placeholder="40"
            />
          </div>

          {/* Eligible Debts result sub-box */}
          <div className="flex items-center justify-between p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs">
            <span className="text-slate-600 dark:text-slate-400">
              Eligible Debts: <strong className="text-slate-900 dark:text-slate-100">₹{computed.eligibleDebtors.toLocaleString('en-IN')}</strong> (Margin deducted: {marginPercentOnDebtors}%)
            </span>
            <span className="font-bold text-sm text-blue-700 dark:text-blue-400">
              Net Eligible Debts: ₹{computed.netEligibleDebtors.toLocaleString('en-IN')}
            </span>
          </div>
        </div>

        {/* Final Computation Summary Box */}
        <div className="p-5 rounded-xl bg-gradient-to-br from-blue-900 to-indigo-950 text-white space-y-4 shadow-md">
          <div className="flex items-center justify-between border-b border-blue-800/80 pb-3">
            <div>
              <span className="text-xs uppercase tracking-wider text-blue-300 font-semibold">Total Drawing Power</span>
              <h3 className="text-2xl font-black text-white">
                ₹{computed.computedDP.toLocaleString('en-IN')}
              </h3>
            </div>
            <div className="text-right">
              <span className="text-xs text-blue-300 block">Sanctioned Limit: ₹{facility.totalSanctionedLimit.toLocaleString('en-IN')}</span>
              <span className="text-xs text-blue-300 block">Outstanding: ₹{facility.outstandingBalance.toLocaleString('en-IN')}</span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
            <div className="bg-white/10 p-3 rounded-lg backdrop-blur-xs">
              <span className="text-blue-200 block">Net Paid Stock (A):</span>
              <span className="font-bold text-sm">₹{computed.netPaidStock.toLocaleString('en-IN')}</span>
            </div>
            <div className="bg-white/10 p-3 rounded-lg backdrop-blur-xs">
              <span className="text-blue-200 block">Net Eligible Debts (B):</span>
              <span className="font-bold text-sm">₹{computed.netEligibleDebtors.toLocaleString('en-IN')}</span>
            </div>
            <div className="bg-white/10 p-3 rounded-lg backdrop-blur-xs">
              <span className="text-blue-200 block">Variance (DP vs O/S):</span>
              <span className={clsx('font-bold text-sm', computed.computedDP >= facility.outstandingBalance ? 'text-emerald-300' : 'text-rose-300')}>
                {computed.computedDP >= facility.outstandingBalance ? '+' : ''}
                ₹{(computed.computedDP - facility.outstandingBalance).toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>

        {/* Auditor Remarks on DP */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Auditor DP Observations & Notes
          </label>
          <textarea
            rows={2}
            disabled={isReadOnly}
            value={remarks}
            onChange={e => setRemarks(e.target.value)}
            placeholder="e.g. Stock verified with CA stock audit certificate; book debts aged > 90 days excluded."
            className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
      </div>
    </Modal>
  );
};
