import React from 'react';
import { CreditFacility } from '../../types/audit';
import { evaluateDPStatusBadge } from '../../services/dpEngine';
import { CheckCircle2, AlertTriangle, AlertOctagon, Clock, ShieldAlert } from 'lucide-react';
import clsx from 'clsx';

interface DPBadgeProps {
  facility: CreditFacility;
  auditDate?: string;
  showDetail?: boolean;
}

export const DPBadge: React.FC<DPBadgeProps> = ({ facility, auditDate, showDetail = false }) => {
  const status = evaluateDPStatusBadge(facility, auditDate);

  const getIcon = () => {
    switch (status.badge) {
      case 'WITHIN_DP_AND_LIMIT':
        return <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400 shrink-0" />;
      case 'EXCEEDS_DP_WITHIN_LIMIT':
        return <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400 shrink-0" />;
      case 'EXCEEDS_SANCTION_LIMIT':
        return <AlertOctagon className="w-3.5 h-3.5 text-red-600 dark:text-red-400 shrink-0" />;
      case 'STALE_OR_MISSING_STOCK_STATEMENT':
        return <Clock className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400 shrink-0" />;
    }
  };

  return (
    <div className="inline-flex flex-col items-start gap-1">
      <span
        title={status.description}
        className={clsx(
          'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border shadow-xs transition-colors cursor-help',
          status.bgClass,
          status.colorClass,
          status.borderClass
        )}
      >
        {getIcon()}
        <span>{status.label}</span>
      </span>
      {showDetail && (
        <span className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-1">
          {status.description}
        </span>
      )}
    </div>
  );
};
