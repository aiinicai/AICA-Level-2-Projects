import React from 'react';
import { useAudit } from '../../context/AuditContext';
import { 
  Building2, 
  CreditCard, 
  TrendingDown, 
  AlertTriangle, 
  Clock, 
  ShieldAlert, 
  CheckCircle2, 
  FileWarning 
} from 'lucide-react';

export const KPIStats: React.FC = () => {
  const { kpiStats } = useAudit();

  const cards = [
    {
      title: 'Total Audited Advances',
      value: `₹${(kpiStats.totalOutstandingSum / 10000000).toFixed(2)} Cr`,
      subtitle: `${kpiStats.totalFacilitiesCount} Accounts (Limit: ₹${(kpiStats.totalSanctionedSum / 10000000).toFixed(2)} Cr)`,
      icon: <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      bg: 'bg-blue-50/70 dark:bg-blue-950/40 border-blue-200 dark:border-blue-900',
    },
    {
      title: 'RBI Provision Required',
      value: `₹${(kpiStats.totalProvisionSum / 100000).toFixed(2)} Lakhs`,
      subtitle: `${kpiStats.npaCount} NPAs (₹${(kpiStats.npaOutstandingSum / 10000000).toFixed(2)} Cr Stress)`,
      icon: <ShieldAlert className="w-5 h-5 text-rose-600 dark:text-rose-400" />,
      bg: 'bg-rose-50/70 dark:bg-rose-950/40 border-rose-200 dark:border-rose-900',
    },
    {
      title: 'Overdrawn / DP Irregularity',
      value: `${kpiStats.overdrawnCount} Accounts`,
      subtitle: `${kpiStats.staleStockCount} Stale Stock Statements (>90d)`,
      icon: <AlertTriangle className="w-5 h-5 text-amber-600 dark:text-amber-400" />,
      bg: 'bg-amber-50/70 dark:bg-amber-950/40 border-amber-200 dark:border-amber-900',
    },
    {
      title: 'Actionable Alerts (<30d)',
      value: `${kpiStats.renewalsDueCount + kpiStats.expiringInsuranceCount} Items`,
      subtitle: `${kpiStats.renewalsDueCount} Renewals, ${kpiStats.expiringInsuranceCount} Ins. Expiry`,
      icon: <Clock className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />,
      bg: 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-900',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
      {cards.map((c, i) => (
        <div
          key={i}
          className={`p-4 rounded-xl border ${c.bg} shadow-xs space-y-2 transition-all hover:shadow-sm`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
              {c.title}
            </span>
            <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 shadow-2xs">
              {c.icon}
            </div>
          </div>
          <div>
            <h3 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight">
              {c.value}
            </h3>
            <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
              {c.subtitle}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};
