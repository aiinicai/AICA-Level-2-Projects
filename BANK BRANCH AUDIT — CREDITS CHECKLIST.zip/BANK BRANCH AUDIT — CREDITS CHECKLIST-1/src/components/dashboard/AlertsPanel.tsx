import React from 'react';
import { useAudit, AuditAlertItem } from '../../context/AuditContext';
import { 
  AlertTriangle, 
  ShieldAlert, 
  Clock, 
  Flame, 
  FileWarning, 
  Building2, 
  ArrowRight,
  CheckCircle2,
  Users
} from 'lucide-react';
import clsx from 'clsx';

interface AlertsPanelProps {
  onSelectFacility?: (facilityId: string) => void;
}

export const AlertsPanel: React.FC<AlertsPanelProps> = ({ onSelectFacility }) => {
  const { alerts, setFilters } = useAudit();

  const getAlertIcon = (type: AuditAlertItem['type']) => {
    switch (type) {
      case 'EXPIRING_INSURANCE':
        return <Flame className="w-4 h-4 text-rose-600 dark:text-rose-400" />;
      case 'RENEWAL_DUE':
        return <Clock className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'STALE_STOCK_STATEMENT':
        return <FileWarning className="w-4 h-4 text-orange-600 dark:text-orange-400" />;
      case 'OVERDRAWN_LIMIT':
        return <AlertTriangle className="w-4 h-4 text-red-600 dark:text-red-400" />;
      case 'OVERDRAWN_DP':
        return <AlertTriangle className="w-4 h-4 text-amber-600 dark:text-amber-400" />;
      case 'RELATED_PARTY_SEC20':
        return <Users className="w-4 h-4 text-purple-600 dark:text-purple-400" />;
      case 'PENDING_DOCUMENTATION':
        return <ShieldAlert className="w-4 h-4 text-blue-600 dark:text-blue-400" />;
    }
  };

  const getSeverityStyle = (severity: AuditAlertItem['severity']) => {
    switch (severity) {
      case 'critical':
        return 'border-red-200 bg-red-50/60 dark:border-red-900/60 dark:bg-red-950/30 text-red-950 dark:text-red-200';
      case 'warning':
        return 'border-amber-200 bg-amber-50/60 dark:border-amber-900/60 dark:bg-amber-950/30 text-amber-950 dark:text-amber-200';
      case 'info':
        return 'border-purple-200 bg-purple-50/60 dark:border-purple-900/60 dark:bg-purple-950/30 text-purple-950 dark:text-purple-200';
    }
  };

  const handleAlertClick = (item: AuditAlertItem) => {
    setFilters(prev => ({
      ...prev,
      searchQuery: item.accountNumber,
      showArchived: false,
    }));
    onSelectFacility?.(item.facilityId);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse" />
            Active CA Audit Risk Alerts & Compliance Triggers ({alerts.length})
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real-time compliance triggers requiring statutory reporting or regularization
          </p>
        </div>
      </div>

      {alerts.length === 0 ? (
        <div className="text-center py-6 text-slate-400 text-xs flex items-center justify-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>All audited accounts are within healthy compliance limits. No immediate alerts.</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 max-h-[380px] overflow-y-auto pr-1">
          {alerts.map(item => (
            <div
              key={item.id}
              onClick={() => handleAlertClick(item)}
              className={clsx(
                'p-3 rounded-xl border transition-all cursor-pointer hover:shadow-xs flex items-start gap-3 text-xs',
                getSeverityStyle(item.severity)
              )}
            >
              <div className="p-2 rounded-lg bg-white/80 dark:bg-slate-900/80 shrink-0 mt-0.5 shadow-2xs">
                {getAlertIcon(item.type)}
              </div>
              <div className="space-y-1 min-w-0 flex-1">
                <div className="flex items-center justify-between gap-1">
                  <h5 className="font-bold text-slate-900 dark:text-slate-100 truncate">
                    {item.borrowerName}
                  </h5>
                  <span className="font-mono text-[10px] text-slate-500 shrink-0">
                    {item.accountNumber}
                  </span>
                </div>
                <p className="font-semibold text-[11px] leading-tight text-slate-800 dark:text-slate-200">
                  {item.title}
                </p>
                <p className="text-[11px] text-slate-600 dark:text-slate-400 leading-snug line-clamp-2">
                  {item.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
