import React from 'react';
import { KPIStats } from './KPIStats';
import { IRACChart } from './IRACChart';
import { AlertsPanel } from './AlertsPanel';
import { Button } from '../common/Button';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { 
  Building2, 
  FileSpreadsheet, 
  Settings, 
  ShieldCheck, 
  Calendar,
  Users,
  Edit,
  MapPin,
  Sparkles 
} from 'lucide-react';

interface DashboardViewProps {
  onNavigateToRegister: () => void;
  onOpenSettings: () => void;
  onOpenEngagementSettings?: () => void;
  onOpenTeamManagement?: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigateToRegister,
  onOpenSettings,
  onOpenEngagementSettings,
  onOpenTeamManagement,
}) => {
  const { auditMetadata, facilities } = useAudit();
  const { currentUser } = useAuth();

  return (
    <div className="space-y-6">
      {/* Top Banner with Audit Metadata */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-blue-900 via-indigo-900 to-slate-900 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
          <div className="space-y-2 max-w-2xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-blue-500/30 text-blue-200 border border-blue-400/40">
                FY {auditMetadata.auditYear} Statutory / Concurrent Advances Audit
              </span>
              <button
                onClick={onOpenEngagementSettings}
                className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
                title="Click to edit As-on Reporting Date"
              >
                <Calendar className="w-3 h-3 text-blue-300" />
                <span>As on: <strong>{auditMetadata.auditAsOfDate}</strong></span>
                <Edit className="w-3 h-3 text-blue-300" />
              </button>
            </div>

            <div>
              <h2 className="text-2xl font-black tracking-tight text-white flex items-center gap-2">
                {auditMetadata.bankName}
              </h2>
              <p className="text-xs text-blue-200 mt-0.5 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-emerald-400 shrink-0" />
                <span>Branch: <strong>{auditMetadata.branchName} ({auditMetadata.branchCode})</strong> {auditMetadata.branchAddress ? `— ${auditMetadata.branchAddress}` : ''}</span>
              </p>
            </div>

            <div className="pt-1 text-xs text-blue-200 border-t border-white/10 flex flex-wrap items-center gap-y-1 gap-x-4">
              <span>Conducting Firm: <strong>{auditMetadata.firmName}</strong> (FRN: {auditMetadata.firmFRN})</span>
              <span>Lead Partner: <strong>{auditMetadata.leadAuditor}</strong> {auditMetadata.membershipNumber ? `(M. No. ${auditMetadata.membershipNumber})` : ''}</span>
            </div>
          </div>

          {/* Quick Action Shortcuts */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <Button
              variant="outline"
              size="sm"
              icon={<Building2 className="w-4 h-4 text-emerald-300" />}
              onClick={onOpenEngagementSettings}
              className="text-white border-white/30 hover:bg-white/10"
            >
              Edit Bank & Firm
            </Button>
            <Button
              variant="outline"
              size="sm"
              icon={<Users className="w-4 h-4 text-blue-300" />}
              onClick={onOpenTeamManagement}
              className="text-white border-white/30 hover:bg-white/10"
            >
              Team & Staff
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={<FileSpreadsheet className="w-4 h-4" />}
              onClick={onNavigateToRegister}
              className="bg-blue-500 hover:bg-blue-600 text-white shadow-sm"
            >
              Credit Register ({facilities.length})
            </Button>
          </div>
        </div>
      </div>

      {/* KPI Stats */}
      <KPIStats />

      {/* IRAC Asset Chart & Distribution */}
      <IRACChart />

      {/* Alerts Panel */}
      <AlertsPanel onSelectFacility={() => onNavigateToRegister()} />
    </div>
  );
};
