import React from 'react';
import { useAudit } from '../../context/AuditContext';
import { IRACCategory } from '../../types/audit';
import { getIRACBadgeTheme } from '../../services/iracEngine';

export const IRACChart: React.FC = () => {
  const { facilities } = useAudit();
  const active = facilities.filter(f => !f.isArchived);

  const categories: IRACCategory[] = [
    'Standard',
    'Sub-Standard',
    'Doubtful 1 (D1)',
    'Doubtful 2 (D2)',
    'Doubtful 3 (D3)',
    'Loss'
  ];

  const totalOutstanding = active.reduce((sum, f) => sum + (f.outstandingBalance || 0), 0) || 1;

  const stats = categories.map(cat => {
    const list = active.filter(f => f.currentIRAC?.computedCategory === cat);
    const count = list.length;
    const value = list.reduce((sum, f) => sum + (f.outstandingBalance || 0), 0);
    const provision = list.reduce((sum, f) => sum + (f.currentIRAC?.totalProvisionAmount || 0), 0);
    const percentOfPortfolio = ((value / totalOutstanding) * 100);
    const theme = getIRACBadgeTheme(cat);

    return {
      category: cat,
      count,
      value,
      provision,
      percentOfPortfolio,
      theme,
    };
  });

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-xs space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            IRAC Asset Classification & Provision Distribution
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Portfolio quality breakdown per RBI Prudential Guidelines
          </p>
        </div>
        <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
          Total Exposure: <strong>₹{(totalOutstanding / 10000000).toFixed(2)} Cr</strong>
        </span>
      </div>

      {/* Visual Stacked Progress Bar */}
      <div className="w-full h-3 rounded-full bg-slate-100 dark:bg-slate-800 flex overflow-hidden">
        {stats.map((s, idx) => (
          s.percentOfPortfolio > 0 && (
            <div
              key={idx}
              style={{ width: `${s.percentOfPortfolio}%` }}
              title={`${s.category}: ${s.percentOfPortfolio.toFixed(1)}% (₹${(s.value / 100000).toFixed(1)} L)`}
              className={`${s.theme.dot} transition-all duration-300 hover:opacity-80`}
            />
          )
        ))}
      </div>

      {/* Category Breakdown Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-1">
        {stats.map((s, idx) => (
          <div
            key={idx}
            className={`p-3 rounded-xl border ${s.theme.border} ${s.theme.bg} space-y-1`}
          >
            <div className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${s.theme.dot}`} />
              <span className={`text-[11px] font-bold truncate ${s.theme.color}`}>
                {s.category}
              </span>
            </div>
            <div className="text-sm font-black text-slate-900 dark:text-slate-100">
              {s.count} <span className="text-[10px] font-normal text-slate-400">({s.percentOfPortfolio.toFixed(0)}%)</span>
            </div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
              ₹{(s.value / 100000).toFixed(1)} L O/S
            </div>
            {s.provision > 0 && (
              <div className="text-[10px] font-bold text-rose-600 dark:text-rose-400 font-mono">
                ₹{(s.provision / 100000).toFixed(1)} L Prov.
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
