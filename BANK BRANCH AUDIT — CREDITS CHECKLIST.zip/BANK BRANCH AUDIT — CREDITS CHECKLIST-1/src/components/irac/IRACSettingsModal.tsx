import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { RBIProvisionRates } from '../../types/audit';
import { DEFAULT_RBI_RATES } from '../../services/iracEngine';
import { useAudit } from '../../context/AuditContext';
import { Settings, RefreshCw, Save, CheckCircle2 } from 'lucide-react';

interface IRACSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const IRACSettingsModal: React.FC<IRACSettingsModalProps> = ({ isOpen, onClose }) => {
  const { rbiRates, updateRBIRates, saveFacility, facilities } = useAudit();
  const [rates, setRates] = useState<RBIProvisionRates>(rbiRates);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleChange = (key: keyof RBIProvisionRates, value: number) => {
    setRates(prev => ({
      ...prev,
      [key]: Math.max(0, value),
    }));
  };

  const handleResetToDefaults = () => {
    setRates(DEFAULT_RBI_RATES);
  };

  const handleSave = () => {
    updateRBIRates(rates);
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 800);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="RBI IRAC Provisioning Master Rates Matrix"
      subtitle="Prudential Norms on Income Recognition, Asset Classification and Provisioning pertaining to Advances"
      maxWidth="3xl"
      footer={
        <>
          <Button
            variant="outline"
            icon={<RefreshCw className="w-4 h-4" />}
            onClick={handleResetToDefaults}
          >
            Reset to RBI Defaults
          </Button>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            icon={savedSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
            onClick={handleSave}
          >
            {savedSuccess ? 'Saved & Applied!' : 'Save Rate Matrix'}
          </Button>
        </>
      }
    >
      <div className="space-y-5">
        <div className="p-3.5 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900 text-xs text-blue-900 dark:text-blue-300">
          <p className="font-semibold">RBI Master Circular Compliance Note:</p>
          <p className="mt-0.5">
            Rates configured here immediately drive all automatic provisioning workings across the audit portfolio. Changes persist across auditor sessions.
          </p>
        </div>

        {/* Section 1: Standard Assets by Sector */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            1. Standard Asset Provisioning Rates (% of Outstanding)
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <Input
              label="Direct Agriculture & Allied (%)"
              type="number"
              step="0.05"
              value={rates.standardDirectAgri}
              onChange={e => handleChange('standardDirectAgri', parseFloat(e.target.value))}
            />
            <Input
              label="Micro & Small Enterprises (MSE) (%)"
              type="number"
              step="0.05"
              value={rates.standardMSE}
              onChange={e => handleChange('standardMSE', parseFloat(e.target.value))}
            />
            <Input
              label="General / Other Advances (%)"
              type="number"
              step="0.05"
              value={rates.standardGeneralOther}
              onChange={e => handleChange('standardGeneralOther', parseFloat(e.target.value))}
            />
            <Input
              label="Commercial Real Estate (CRE) (%)"
              type="number"
              step="0.05"
              value={rates.standardCRE}
              onChange={e => handleChange('standardCRE', parseFloat(e.target.value))}
            />
            <Input
              label="CRE - Residential Housing (%)"
              type="number"
              step="0.05"
              value={rates.standardCRERH}
              onChange={e => handleChange('standardCRERH', parseFloat(e.target.value))}
            />
          </div>
        </div>

        {/* Section 2: Non-Performing Assets Rates */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            2. Non-Performing Asset (NPA) Provisioning Matrix
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Sub-Standard */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
              <h5 className="text-xs font-bold text-amber-700 dark:text-amber-400">
                Sub-Standard (&le; 12 Months)
              </h5>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  label="Secured (%)"
                  type="number"
                  value={rates.subStandardSecured}
                  onChange={e => handleChange('subStandardSecured', parseFloat(e.target.value))}
                />
                <Input
                  label="Unsecured (%)"
                  type="number"
                  value={rates.subStandardUnsecured}
                  onChange={e => handleChange('subStandardUnsecured', parseFloat(e.target.value))}
                />
              </div>
            </div>

            {/* Doubtful 1 */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
              <h5 className="text-xs font-bold text-orange-700 dark:text-orange-400">
                Doubtful 1 (D1) (&gt;12 to 24 Months)
              </h5>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  label="Secured (%)"
                  type="number"
                  value={rates.doubtful1Secured}
                  onChange={e => handleChange('doubtful1Secured', parseFloat(e.target.value))}
                />
                <Input
                  label="Unsecured (%)"
                  type="number"
                  value={rates.doubtful1Unsecured}
                  onChange={e => handleChange('doubtful1Unsecured', parseFloat(e.target.value))}
                />
              </div>
            </div>

            {/* Doubtful 2 */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
              <h5 className="text-xs font-bold text-rose-700 dark:text-rose-400">
                Doubtful 2 (D2) (&gt;24 to 48 Months)
              </h5>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  label="Secured (%)"
                  type="number"
                  value={rates.doubtful2Secured}
                  onChange={e => handleChange('doubtful2Secured', parseFloat(e.target.value))}
                />
                <Input
                  label="Unsecured (%)"
                  type="number"
                  value={rates.doubtful2Unsecured}
                  onChange={e => handleChange('doubtful2Unsecured', parseFloat(e.target.value))}
                />
              </div>
            </div>

            {/* Doubtful 3 & Loss */}
            <div className="p-3 bg-slate-50 dark:bg-slate-900/60 rounded-lg border border-slate-200 dark:border-slate-800 space-y-2">
              <h5 className="text-xs font-bold text-red-700 dark:text-red-400">
                Doubtful 3 (&gt;48m) & Loss Assets
              </h5>
              <div className="grid grid-cols-2 gap-2">
                <Input
                  label="D3 Total (%)"
                  type="number"
                  value={rates.doubtful3Secured}
                  onChange={e => {
                    handleChange('doubtful3Secured', parseFloat(e.target.value));
                    handleChange('doubtful3Unsecured', parseFloat(e.target.value));
                  }}
                />
                <Input
                  label="Loss Asset (%)"
                  type="number"
                  value={rates.loss}
                  onChange={e => handleChange('loss', parseFloat(e.target.value))}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
