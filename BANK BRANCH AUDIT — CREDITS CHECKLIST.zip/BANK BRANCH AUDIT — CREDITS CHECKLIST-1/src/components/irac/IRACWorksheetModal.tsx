import React, { useState, useEffect } from 'react';
import { CreditFacility, IRACClassification, IRACCategory } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { Select } from '../common/Select';
import { IRACStepMath } from './IRACStepMath';
import { computeIRACClassification } from '../../services/iracEngine';
import { useAudit } from '../../context/AuditContext';
import { Save, AlertTriangle, ShieldCheck } from 'lucide-react';
import clsx from 'clsx';

interface IRACWorksheetModalProps {
  isOpen: boolean;
  onClose: () => void;
  facility: CreditFacility | null;
  onSave: (irac: IRACClassification) => void;
  isReadOnly?: boolean;
}

export const IRACWorksheetModal: React.FC<IRACWorksheetModalProps> = ({
  isOpen,
  onClose,
  facility,
  onSave,
  isReadOnly = false,
}) => {
  if (!facility) return null;

  const { rbiRates, auditMetadata } = useAudit();
  const current = facility.currentIRAC;

  const [asOfDate, setAsOfDate] = useState(current?.asOfDate || auditMetadata.auditAsOfDate || new Date().toISOString().split('T')[0]);
  const [isNPA, setIsNPA] = useState(Boolean(current?.isNPA));
  const [npaDate, setNpaDate] = useState(current?.npaDate || '');
  const [isLossFlagged, setIsLossFlagged] = useState(Boolean(current?.isLossManuallyFlagged));

  const [realizablePrimary, setRealizablePrimary] = useState<number>(facility.realizableValuePrimary || 0);
  const [realizableCollateral, setRealizableCollateral] = useState<number>(facility.realizableValueCollateral || 0);
  const [remarks, setRemarks] = useState(current?.remarks || '');

  useEffect(() => {
    if (facility && facility.currentIRAC) {
      const ir = facility.currentIRAC;
      setAsOfDate(ir.asOfDate);
      setIsNPA(ir.isNPA);
      setNpaDate(ir.npaDate || '');
      setIsLossFlagged(Boolean(ir.isLossManuallyFlagged));
      setRealizablePrimary(facility.realizableValuePrimary || 0);
      setRealizableCollateral(facility.realizableValueCollateral || 0);
      setRemarks(ir.remarks || '');
    }
  }, [facility]);

  // Compute live IRAC
  const computed = computeIRACClassification({
    isNPA,
    npaDate: isNPA ? npaDate : undefined,
    isLossFlagged,
    outstandingBalance: facility.outstandingBalance,
    realizableSecurityPrimary: realizablePrimary,
    realizableSecurityCollateral: realizableCollateral,
    sector: facility.industrySector,
    asOfDate,
    customRates: rbiRates,
  });

  const handleSave = () => {
    if (isReadOnly) return;
    const working: IRACClassification = {
      id: current?.id || `irac_${facility.id}`,
      facilityId: facility.id,
      asOfDate,
      isNPA,
      npaDate: isNPA ? npaDate : undefined,
      monthsElapsedSinceNPA: computed.monthsElapsedSinceNPA,
      computedCategory: computed.category,
      isLossManuallyFlagged: isLossFlagged,
      outstandingBalance: facility.outstandingBalance,
      realizableSecurityPrimary: realizablePrimary,
      realizableSecurityCollateral: realizableCollateral,
      totalRealizableSecurity: computed.totalRealizableSecurity,
      securedPortion: computed.securedPortion,
      unsecuredPortion: computed.unsecuredPortion,
      provisionRateSecuredPercent: computed.rateSecured,
      provisionRateUnsecuredPercent: computed.rateUnsecured,
      provisionAmountSecured: computed.provisionSecured,
      provisionAmountUnsecured: computed.provisionUnsecured,
      totalProvisionAmount: computed.totalProvision,
      effectiveProvisionPercent: computed.effectiveRatePercent,
      remarks,
      updatedAt: new Date().toISOString(),
    };
    onSave(working);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="IRAC Asset Classification & Provisioning Engine"
      subtitle={`Account: ${facility.accountNumber} — ${facility.borrowerName} (${facility.industrySector})`}
      maxWidth="4xl"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          {!isReadOnly && (
            <Button variant="primary" icon={<Save className="w-4 h-4" />} onClick={handleSave}>
              Save IRAC Classification
            </Button>
          )}
        </>
      }
    >
      <div className="space-y-6">
        {/* Top Summary / Outcome Card */}
        <div className="p-5 rounded-xl bg-gradient-to-r from-slate-900 to-blue-950 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-md">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider text-blue-300 font-semibold">
                Computed IRAC Category
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-500/30 border border-blue-400/40 text-blue-200">
                {computed.category}
              </span>
            </div>
            <h3 className="text-2xl font-black mt-1 text-white">
              ₹{computed.totalProvision.toLocaleString('en-IN')}
            </h3>
            <span className="text-xs text-blue-200 font-medium">
              Total Provision Required ({computed.effectiveRatePercent}% effective rate on ₹{facility.outstandingBalance.toLocaleString('en-IN')} O/S)
            </span>
          </div>

          <div className="bg-white/10 p-3 rounded-lg backdrop-blur-xs text-xs space-y-1 sm:text-right">
            <div>
              <span className="text-blue-200">Secured Portion Provision:</span>{' '}
              <strong>₹{computed.provisionSecured.toLocaleString('en-IN')}</strong> ({computed.rateSecured}%)
            </div>
            <div>
              <span className="text-blue-200">Unsecured Portion Provision:</span>{' '}
              <strong>₹{computed.provisionUnsecured.toLocaleString('en-IN')}</strong> ({computed.rateUnsecured}%)
            </div>
          </div>
        </div>

        {/* Input Parameters: NPA Flag & Date, As-of Date */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/40 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Classification Parameters & Overdue Assessment
            </h4>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              As-of Reporting Date: <strong>{asOfDate}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
                Asset Status
              </label>
              <div className="flex items-center gap-4 pt-1">
                <label className="flex items-center gap-2 text-xs text-slate-800 dark:text-slate-200 cursor-pointer">
                  <input
                    type="radio"
                    name="npaStatus"
                    checked={!isNPA}
                    disabled={isReadOnly}
                    onChange={() => {
                      setIsNPA(false);
                      setIsLossFlagged(false);
                    }}
                    className="text-blue-600 focus:ring-blue-500"
                  />
                  <span>Standard / Performing</span>
                </label>
                <label className="flex items-center gap-2 text-xs text-rose-700 dark:text-rose-400 font-semibold cursor-pointer">
                  <input
                    type="radio"
                    name="npaStatus"
                    checked={isNPA}
                    disabled={isReadOnly}
                    onChange={() => setIsNPA(true)}
                    className="text-rose-600 focus:ring-rose-500"
                  />
                  <span>Non-Performing (NPA)</span>
                </label>
              </div>
            </div>

            {isNPA && (
              <div>
                <label className="block text-xs font-semibold text-rose-700 dark:text-rose-400 mb-1">
                  NPA Date <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  disabled={isReadOnly}
                  value={npaDate}
                  onChange={e => setNpaDate(e.target.value)}
                  className="w-full text-xs rounded-lg border border-rose-300 dark:border-rose-800 bg-white dark:bg-slate-900 p-2 text-slate-900 dark:text-slate-100"
                />
                {isNPA && npaDate && (
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                    {computed.monthsElapsedSinceNPA} months elapsed ({computed.daysElapsedSinceNPA} days)
                  </p>
                )}
              </div>
            )}

            <div className="flex items-center pt-5">
              <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  disabled={isReadOnly}
                  checked={isLossFlagged}
                  onChange={e => setIsLossFlagged(e.target.checked)}
                  className="rounded text-purple-600 focus:ring-purple-500"
                />
                <span className="font-semibold text-purple-700 dark:text-purple-400">
                  Manually Flag as Loss Asset (100% Provision)
                </span>
              </label>
            </div>
          </div>
        </div>

        {/* Realizable Security Valuation & Splitting */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Security Valuation & Exposure Allocation
            </h4>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Total Outstanding: <strong>₹{facility.outstandingBalance.toLocaleString('en-IN')}</strong>
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Realizable Value of Primary Security (₹)"
              type="number"
              disabled={isReadOnly}
              currencyPrefix
              value={realizablePrimary || ''}
              onChange={e => setRealizablePrimary(Number(e.target.value))}
              placeholder="0"
              helperText="Current assets, stocks, machinery"
            />
            <Input
              label="Realizable Value of Collateral Security (₹)"
              type="number"
              disabled={isReadOnly}
              currencyPrefix
              value={realizableCollateral || ''}
              onChange={e => setRealizableCollateral(Number(e.target.value))}
              placeholder="0"
              helperText="Mortgaged immovable properties"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs">
            <div>
              <span className="text-slate-500 dark:text-slate-400 block">Total Realizable Security:</span>
              <span className="font-bold text-slate-900 dark:text-slate-100 text-sm">
                ₹{computed.totalRealizableSecurity.toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-slate-500 dark:text-slate-400 block">Secured Exposure:</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                ₹{computed.securedPortion.toLocaleString('en-IN')}
              </span>
            </div>
            <div>
              <span className="text-slate-500 dark:text-slate-400 block">Unsecured / Shortfall:</span>
              <span className={clsx('font-bold text-sm', computed.unsecuredPortion > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-900 dark:text-slate-100')}>
                ₹{computed.unsecuredPortion.toLocaleString('en-IN')}
              </span>
            </div>
          </div>
        </div>

        {/* Step-by-Step Mathematical Working Trace */}
        <IRACStepMath steps={computed.stepTrace} />

        {/* Auditor IRAC Remarks */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Auditor Notes & Justification on Classification
          </label>
          <textarea
            rows={2}
            disabled={isReadOnly}
            value={remarks}
            onChange={e => setRemarks(e.target.value)}
            placeholder="e.g. Valuation report dated 15-Jan-2026 considered for collateral valuation. Account verified as Sub-Standard."
            className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-500"
          />
        </div>
      </div>
    </Modal>
  );
};
