import React, { useState } from 'react';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { CreditFacility } from '../../types/audit';
import { IRACBadge } from './IRACBadge';
import { IRACWorksheetModal } from './IRACWorksheetModal';
import { Button } from '../common/Button';
import { ShieldAlert, Settings, Calculator, ShieldCheck } from 'lucide-react';

interface IRACEngineViewProps {
  onOpenSettings: () => void;
}

export const IRACEngineView: React.FC<IRACEngineViewProps> = ({ onOpenSettings }) => {
  const { facilities, saveFacility, kpiStats } = useAudit();
  const { isReadOnly } = useAuth();
  const [selectedFac, setSelectedFac] = useState<CreditFacility | null>(null);

  const active = facilities.filter(f => !f.isArchived);

  const handleSaveIRAC = (updatedIRAC: any) => {
    if (!selectedFac) return;
    const updated: CreditFacility = {
      ...selectedFac,
      currentIRAC: updatedIRAC,
    };
    saveFacility(updated, `Updated IRAC classification to ${updatedIRAC.computedCategory}`);
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
            <ShieldAlert className="w-6 h-6 text-amber-600" />
            IRAC Asset Classification & Provisioning Engine
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Prudential norms on income recognition, asset classification, and step-by-step provisioning calculations
          </p>
        </div>

        <Button
          variant="outline"
          size="sm"
          icon={<Settings className="w-4 h-4" />}
          onClick={onOpenSettings}
        >
          Edit RBI Rate Matrix
        </Button>
      </div>

      {/* Summary KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-xl bg-slate-900 text-white space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">Total Provision Required</span>
          <h3 className="text-xl font-black text-rose-400">
            ₹{(kpiStats.totalProvisionSum / 100000).toFixed(2)} Lakhs
          </h3>
        </div>
        <div className="p-4 rounded-xl bg-slate-900 text-white space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">NPA Exposure Stress</span>
          <h3 className="text-xl font-black text-amber-400">
            ₹{(kpiStats.npaOutstandingSum / 10000000).toFixed(2)} Cr ({kpiStats.npaCount} Accounts)
          </h3>
        </div>
        <div className="p-4 rounded-xl bg-slate-900 text-white space-y-1">
          <span className="text-[11px] text-slate-400 font-semibold uppercase">Performing / Standard Portfolio</span>
          <h3 className="text-xl font-black text-emerald-400">
            ₹{((kpiStats.totalOutstandingSum - kpiStats.npaOutstandingSum) / 10000000).toFixed(2)} Cr
          </h3>
        </div>
      </div>

      {/* IRAC Register Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Borrower / Account</th>
                <th className="py-3 px-4">IRAC Category</th>
                <th className="py-3 px-4 text-right">Outstanding (O/S)</th>
                <th className="py-3 px-4 text-right">Realizable Security</th>
                <th className="py-3 px-4 text-right">Secured Portion</th>
                <th className="py-3 px-4 text-right">Unsecured Portion</th>
                <th className="py-3 px-4 text-right">RBI Provision</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {active.map(fac => {
                const irac = fac.currentIRAC;
                return (
                  <tr key={fac.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-slate-100">
                        {fac.borrowerName}
                      </div>
                      <div className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                        {fac.accountNumber} &bull; {fac.industrySector}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <IRACBadge
                        category={irac?.computedCategory || 'Standard'}
                        isNPA={irac?.isNPA}
                        npaDate={irac?.npaDate}
                      />
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-slate-100">
                      ₹{(fac.outstandingBalance / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-slate-600 dark:text-slate-400">
                      ₹{((irac?.totalRealizableSecurity || 0) / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-emerald-600 dark:text-emerald-400">
                      ₹{((irac?.securedPortion || 0) / 100000).toFixed(2)} L ({irac?.provisionRateSecuredPercent || 0}%)
                    </td>
                    <td className="py-3 px-4 text-right font-mono text-rose-600 dark:text-rose-400">
                      ₹{((irac?.unsecuredPortion || 0) / 100000).toFixed(2)} L ({irac?.provisionRateUnsecuredPercent || 0}%)
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold text-rose-700 dark:text-rose-400">
                      ₹{((irac?.totalProvisionAmount || 0) / 100000).toFixed(2)} L
                    </td>
                    <td className="py-3 px-4 text-center">
                      <Button
                        variant="outline"
                        size="sm"
                        icon={<ShieldAlert className="w-3.5 h-3.5" />}
                        onClick={() => setSelectedFac(fac)}
                      >
                        Math Trace
                      </Button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {selectedFac && (
        <IRACWorksheetModal
          isOpen={Boolean(selectedFac)}
          onClose={() => setSelectedFac(null)}
          facility={selectedFac}
          onSave={handleSaveIRAC}
          isReadOnly={isReadOnly}
        />
      )}
    </div>
  );
};
