import React from 'react';
import { IRACCategory } from '../../types/audit';
import { getIRACBadgeTheme } from '../../services/iracEngine';
import clsx from 'clsx';

interface IRACBadgeProps {
  category: IRACCategory;
  isNPA?: boolean;
  npaDate?: string;
  className?: string;
}

export const IRACBadge: React.FC<IRACBadgeProps> = ({
  category,
  isNPA,
  npaDate,
  className = '',
}) => {
  const theme = getIRACBadgeTheme(category);

  return (
    <div className={clsx('inline-flex items-center gap-1.5', className)}>
      <span
        className={clsx(
          'inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold border shadow-xs transition-colors',
          theme.bg,
          theme.color,
          theme.border
        )}
      >
        <span className={clsx('w-1.5 h-1.5 rounded-full shrink-0', theme.dot)} />
        <span>{category}</span>
      </span>
      {isNPA && npaDate && (
        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">
          (NPA: {npaDate})
        </span>
      )}
    </div>
  );
};
