import React from 'react';
import { IRACStepDetail } from '../../services/iracEngine';
import { Calculator, Check, ArrowRight } from 'lucide-react';

interface IRACStepMathProps {
  steps: IRACStepDetail[];
}

export const IRACStepMath: React.FC<IRACStepMathProps> = ({ steps }) => {
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h5 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
          <Calculator className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
          RBI Statutory Step-by-Step Provisioning Working
        </h5>
        <span className="text-[11px] text-slate-400">Auto-calculated per Master Circular</span>
      </div>

      <div className="grid grid-cols-1 gap-2.5">
        {steps.map(step => (
          <div
            key={step.stepNumber}
            className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900/60 space-y-1.5 text-xs"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
                <span className="w-4 h-4 rounded-full bg-blue-600 text-white flex items-center justify-center text-[10px] font-bold">
                  {step.stepNumber}
                </span>
                {step.title}
              </span>
              <span className="font-mono text-[11px] font-semibold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2 py-0.5 rounded border border-blue-200 dark:border-blue-900">
                {step.result}
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-slate-600 dark:text-slate-400 text-[11px] pt-1">
              <div>
                <span className="text-slate-400 font-mono block">Rule / Formula:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">{step.formula}</span>
              </div>
              <div>
                <span className="text-slate-400 font-mono block">Evaluation:</span>
                <span className="font-mono text-slate-700 dark:text-slate-300">{step.computation}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
