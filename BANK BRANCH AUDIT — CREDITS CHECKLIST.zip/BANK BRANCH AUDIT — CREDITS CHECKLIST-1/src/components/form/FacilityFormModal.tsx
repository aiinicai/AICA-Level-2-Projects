import React, { useState, useEffect } from 'react';
import { 
  CreditFacility, 
  FacilityType, 
  ConstitutionType, 
  SectorType, 
  ChecklistItem,
  DocumentationStatus 
} from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { Select } from '../common/Select';
import { Badge } from '../common/Badge';
import { Tabs } from '../common/Tabs';
import { AutosaveIndicator } from './AutosaveIndicator';
import { NormsOverrideWarning } from '../dp/NormsOverrideWarning';
import { STANDARD_CHECKLIST_TEMPLATE } from '../../data/seedData';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { checkBankingNormsOverride } from '../../services/dpEngine';
import clsx from 'clsx';
import { 
  Building2, 
  CreditCard, 
  Shield, 
  FileCheck, 
  FileText, 
  CheckSquare, 
  Save, 
  History,
  AlertTriangle,
  RotateCcw,
  Lock,
  Unlock,
  Trash2,
  ShieldCheck,
  Info
} from 'lucide-react';

interface FacilityFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  facilityToEdit?: CreditFacility | null;
}

const FACILITY_TYPES: { value: FacilityType; label: string }[] = [
  { value: 'Cash Credit (CC)', label: 'Cash Credit (CC)' },
  { value: 'Overdraft (OD)', label: 'Overdraft (OD)' },
  { value: 'Term Loan (TL)', label: 'Term Loan (TL)' },
  { value: 'Demand Loan (DL)', label: 'Demand Loan (DL)' },
  { value: 'Bill Discounting', label: 'Bill Discounting' },
  { value: 'Bank Guarantee (BG)', label: 'Bank Guarantee (BG)' },
  { value: 'Letter of Credit (LC)', label: 'Letter of Credit (LC)' },
];

const CONSTITUTION_TYPES: { value: ConstitutionType; label: string }[] = [
  { value: 'Individual / Proprietorship', label: 'Individual / Proprietorship' },
  { value: 'Partnership Firm', label: 'Partnership Firm' },
  { value: 'LLP', label: 'LLP' },
  { value: 'Private Limited Company', label: 'Private Limited Company' },
  { value: 'Public Limited Company', label: 'Public Limited Company' },
  { value: 'Trust / Society', label: 'Trust / Society' },
  { value: 'HUF', label: 'HUF' },
];

const SECTOR_TYPES: { value: SectorType; label: string }[] = [
  { value: 'Agriculture & Allied', label: 'Agriculture & Allied' },
  { value: 'Micro & Small Enterprises (MSE)', label: 'Micro & Small Enterprises (MSE)' },
  { value: 'Medium Enterprises', label: 'Medium Enterprises' },
  { value: 'Large Corporates / Infrastructure', label: 'Large Corporates / Infrastructure' },
  { value: 'Commercial Real Estate (CRE)', label: 'Commercial Real Estate (CRE)' },
  { value: 'Commercial Real Estate - Residential Housing (CRE-RH)', label: 'CRE - Residential Housing (CRE-RH)' },
  { value: 'Retail / Housing Loan', label: 'Retail / Housing Loan' },
  { value: 'Services / Trading', label: 'Services / Trading' },
  { value: 'NBFC', label: 'NBFC' },
];

const DOC_STATUSES: { value: DocumentationStatus; label: string }[] = [
  { value: 'Obtained & Valid', label: 'Obtained & Valid' },
  { value: 'Obtained but Expired / Due', label: 'Obtained but Expired / Due' },
  { value: 'Obtained - Incomplete/Defective', label: 'Obtained - Incomplete/Defective' },
  { value: 'Not Obtained / Pending', label: 'Not Obtained / Pending' },
  { value: 'Not Applicable', label: 'Not Applicable' },
];

export const FacilityFormModal: React.FC<FacilityFormModalProps> = ({
  isOpen,
  onClose,
  facilityToEdit,
}) => {
  const { saveFacility, auditMetadata, draft, saveDraft, clearDraft, archiveFacility } = useAudit();
  const { currentUser, isAdmin, isStaff, canDeleteFacility } = useAuth();
  const [activeTab, setActiveTab] = useState('borrower');
  const [lastAutosave, setLastAutosave] = useState<string | null>(null);
  const [changeReason, setChangeReason] = useState('');
  const [isRecordLocked, setIsRecordLocked] = useState(true);

  // Form State
  const [accountNumber, setAccountNumber] = useState('');
  const [borrowerName, setBorrowerName] = useState('');
  const [branch, setBranch] = useState(auditMetadata.branchName);
  const [facilityType, setFacilityType] = useState<FacilityType>('Cash Credit (CC)');
  const [constitution, setConstitution] = useState<ConstitutionType>('Private Limited Company');
  const [industrySector, setIndustrySector] = useState<SectorType>('Micro & Small Enterprises (MSE)');

  const [sanctionDate, setSanctionDate] = useState('');
  const [sanctioningAuthority, setSanctioningAuthority] = useState('');
  const [lastRenewalDate, setLastRenewalDate] = useState('');
  const [nextRenewalDueDate, setNextRenewalDueDate] = useState('');
  const [interestRate, setInterestRate] = useState<number>(9.5);
  const [sanctionedLimitFundBased, setSanctionedLimitFundBased] = useState<number>(0);
  const [sanctionedLimitNonFundBased, setSanctionedLimitNonFundBased] = useState<number>(0);
  const [outstandingBalance, setOutstandingBalance] = useState<number>(0);

  const [primarySecurity, setPrimarySecurity] = useState('');
  const [collateralSecurity, setCollateralSecurity] = useState('');
  const [realizableValuePrimary, setRealizableValuePrimary] = useState<number>(0);
  const [realizableValueCollateral, setRealizableValueCollateral] = useState<number>(0);
  const [guarantors, setGuarantors] = useState('');
  const [stipulatedMarginPercent, setStipulatedMarginPercent] = useState<number>(25);
  const [bankNormMarginPercent, setBankNormMarginPercent] = useState<number>(25);

  const [isRelatedParty, setIsRelatedParty] = useState(false);
  const [relatedPartyDetails, setRelatedPartyDetails] = useState('');
  const [insuranceDetails, setInsuranceDetails] = useState('');
  const [insuranceExpiryDate, setInsuranceExpiryDate] = useState('');
  const [insuranceAmount, setInsuranceAmount] = useState<number>(0);

  const [isNormOverridden, setIsNormOverridden] = useState(false);
  const [overrideRemarks, setOverrideRemarks] = useState('');
  const [overrideApprovingAuthority, setOverrideApprovingAuthority] = useState('');

  const [checklist, setChecklist] = useState<ChecklistItem[]>([]);
  const [additionalNotes, setAdditionalNotes] = useState('');
  const [auditorObservations, setAuditorObservations] = useState('');

  // Initial load
  useEffect(() => {
    if (facilityToEdit) {
      setAccountNumber(facilityToEdit.accountNumber);
      setBorrowerName(facilityToEdit.borrowerName);
      setBranch(facilityToEdit.branch);
      setFacilityType(facilityToEdit.facilityType);
      setConstitution(facilityToEdit.constitution);
      setIndustrySector(facilityToEdit.industrySector);

      setSanctionDate(facilityToEdit.sanctionDate);
      setSanctioningAuthority(facilityToEdit.sanctioningAuthority);
      setLastRenewalDate(facilityToEdit.lastRenewalDate);
      setNextRenewalDueDate(facilityToEdit.nextRenewalDueDate);
      setInterestRate(facilityToEdit.interestRate);
      setSanctionedLimitFundBased(facilityToEdit.sanctionedLimitFundBased);
      setSanctionedLimitNonFundBased(facilityToEdit.sanctionedLimitNonFundBased);
      setOutstandingBalance(facilityToEdit.outstandingBalance);

      setPrimarySecurity(facilityToEdit.primarySecurity);
      setCollateralSecurity(facilityToEdit.collateralSecurity);
      setRealizableValuePrimary(facilityToEdit.realizableValuePrimary);
      setRealizableValueCollateral(facilityToEdit.realizableValueCollateral);
      setGuarantors(facilityToEdit.guarantors);
      setStipulatedMarginPercent(facilityToEdit.stipulatedMarginPercent);
      setBankNormMarginPercent(facilityToEdit.bankNormMarginPercent || 25);

      setIsRelatedParty(facilityToEdit.isRelatedParty);
      setRelatedPartyDetails(facilityToEdit.relatedPartyDetails || '');
      setInsuranceDetails(facilityToEdit.insuranceDetails);
      setInsuranceExpiryDate(facilityToEdit.insuranceExpiryDate);
      setInsuranceAmount(facilityToEdit.insuranceAmount);

      setIsNormOverridden(facilityToEdit.isNormOverridden);
      setOverrideRemarks(facilityToEdit.overrideRemarks || '');
      setOverrideApprovingAuthority(facilityToEdit.overrideApprovingAuthority || '');

      setChecklist(facilityToEdit.checklist || []);
      setAdditionalNotes(facilityToEdit.additionalNotes || '');
      setAuditorObservations(facilityToEdit.auditorObservations || '');
      setChangeReason('');
      setIsRecordLocked(facilityToEdit.isLocked !== false);
    } else {
      // New record defaults
      const randNum = Math.floor(100000 + Math.random() * 900000);
      setAccountNumber(`${auditMetadata.branchCode}-CC-${randNum}`);
      setBorrowerName('');
      setBranch(`${auditMetadata.branchName} (${auditMetadata.branchCode})`);
      setFacilityType('Cash Credit (CC)');
      setConstitution('Private Limited Company');
      setIndustrySector('Micro & Small Enterprises (MSE)');
      setSanctionDate(new Date().toISOString().split('T')[0]);
      setSanctioningAuthority('Branch Sanction Committee');
      setLastRenewalDate('');
      setNextRenewalDueDate('');
      setInterestRate(9.5);
      setSanctionedLimitFundBased(10000000);
      setSanctionedLimitNonFundBased(0);
      setOutstandingBalance(8500000);
      setPrimarySecurity('Hypothecation of raw materials, finished goods and book debts.');
      setCollateralSecurity('');
      setRealizableValuePrimary(12000000);
      setRealizableValueCollateral(0);
      setGuarantors('');
      setStipulatedMarginPercent(25);
      setBankNormMarginPercent(25);
      setIsRelatedParty(false);
      setRelatedPartyDetails('');
      setInsuranceDetails('Comprehensive Fire & Burglary Policy');
      setInsuranceExpiryDate('');
      setInsuranceAmount(12000000);
      setIsNormOverridden(false);
      setOverrideRemarks('');
      setOverrideApprovingAuthority('');
      setChecklist(STANDARD_CHECKLIST_TEMPLATE.map((c, i) => ({ ...c, id: `chk_${Date.now()}_${i}` })));
      setAdditionalNotes('');
      setAuditorObservations('');
      setChangeReason('');
      setIsRecordLocked(true);
    }
  }, [facilityToEdit, auditMetadata, isOpen]);

  // Autosave effect (for new records or unsaved edits)
  useEffect(() => {
    if (!isOpen) return;
    const timer = setTimeout(() => {
      saveDraft({
        borrowerName,
        accountNumber,
        sanctionedLimitFundBased,
        outstandingBalance,
        additionalNotes,
        auditorObservations,
      });
      setLastAutosave(new Date().toISOString());
    }, 1500);

    return () => clearTimeout(timer);
  }, [borrowerName, accountNumber, sanctionedLimitFundBased, outstandingBalance, additionalNotes, auditorObservations, isOpen, saveDraft]);

  const totalSanctionedLimit = (Number(sanctionedLimitFundBased) || 0) + (Number(sanctionedLimitNonFundBased) || 0);

  // Check norms violation in real-time
  const normsCheck = checkBankingNormsOverride({
    stipulatedMarginPercent,
    bankNormMarginPercent,
    isRelatedParty,
    realizableValuePrimary,
    realizableValueCollateral,
    totalSanctionedLimit,
    isNormOverridden,
  });

  const handleChecklistStatusChange = (id: string, newStatus: DocumentationStatus) => {
    setChecklist(prev =>
      prev.map(item => (item.id === id ? { ...item, status: newStatus } : item))
    );
  };

  const handleChecklistFieldChange = (id: string, field: keyof ChecklistItem, value: string) => {
    setChecklist(prev =>
      prev.map(item => (item.id === id ? { ...item, [field]: value } : item))
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!borrowerName.trim()) {
      setActiveTab('borrower');
      alert('Please enter Borrower Name');
      return;
    }

    if (!accountNumber.trim()) {
      setActiveTab('borrower');
      alert('Please enter unique Account Number');
      return;
    }

    if (normsCheck.requiresRemarks && (!overrideRemarks.trim() || !overrideApprovingAuthority.trim())) {
      setActiveTab('compliance');
      alert('Banking norms breach detected. Please provide Mandatory Justification & Approving Authority in the Compliance & Norms tab.');
      return;
    }

    if (facilityToEdit && isStaff && !changeReason.trim()) {
      setActiveTab('notes');
      alert('Mandatory Justification Required:\nPlease provide a reason for modifying this saved audit record in the "CA Notes & Observations" tab.');
      return;
    }

    const facility: CreditFacility = {
      id: facilityToEdit?.id || `fac_${Date.now()}`,
      accountNumber,
      borrowerName,
      branch,
      facilityType,
      constitution,
      industrySector,
      sanctionDate,
      sanctioningAuthority,
      lastRenewalDate,
      nextRenewalDueDate,
      interestRate,
      sanctionedLimitFundBased,
      sanctionedLimitNonFundBased,
      totalSanctionedLimit,
      outstandingBalance,
      primarySecurity,
      collateralSecurity,
      realizableValuePrimary,
      realizableValueCollateral,
      guarantors,
      stipulatedMarginPercent,
      bankNormMarginPercent,
      isRelatedParty,
      relatedPartyDetails,
      insuranceDetails,
      insuranceExpiryDate,
      insuranceAmount,
      isNormOverridden: normsCheck.isOverridden,
      overrideRemarks,
      overrideApprovingAuthority,
      checklist,
      currentDPWorking: facilityToEdit?.currentDPWorking,
      currentIRAC: facilityToEdit?.currentIRAC,
      additionalNotes,
      auditorObservations,
      isReviewed: facilityToEdit?.isReviewed || false,
      reviewedBy: facilityToEdit?.reviewedBy,
      reviewedAt: facilityToEdit?.reviewedAt,
      isSubmitted: true,
      isLocked: isRecordLocked,
      lockedBy: isRecordLocked ? (facilityToEdit?.lockedBy || currentUser.name) : undefined,
      lockedAt: isRecordLocked ? (facilityToEdit?.lockedAt || new Date().toISOString()) : undefined,
      revisionReason: changeReason,
      isArchived: facilityToEdit?.isArchived || false,
      createdBy: facilityToEdit?.createdBy || currentUser.id,
      createdAt: facilityToEdit?.createdAt || new Date().toISOString(),
      updatedBy: currentUser.id,
      updatedAt: new Date().toISOString(),
    };

    saveFacility(facility, changeReason || (facilityToEdit ? 'Updated credit facility parameters' : 'Created & committed new credit facility'));
    clearDraft();
    onClose();
  };

  const handleDeleteFacility = () => {
    if (!facilityToEdit) return;
    if (window.confirm(`CA ADMIN CONFIRMATION:\nAre you sure you want to delete/archive account ${facilityToEdit.accountNumber} (${facilityToEdit.borrowerName})?`)) {
      archiveFacility(facilityToEdit.id);
      onClose();
    }
  };

  const tabs = [
    { id: 'borrower', label: '1. Borrower & Account', icon: <Building2 className="w-4 h-4" /> },
    { id: 'sanction', label: '2. Limits & Sanction', icon: <CreditCard className="w-4 h-4" /> },
    { id: 'securities', label: '3. Securities & Margin', icon: <Shield className="w-4 h-4" /> },
    {
      id: 'compliance',
      label: '4. Compliance & Norms',
      icon: <FileCheck className="w-4 h-4" />,
      badge: normsCheck.isOverridden ? (
        <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
      ) : undefined,
    },
    { id: 'checklist', label: '5. Documentation Checklist', icon: <CheckSquare className="w-4 h-4" /> },
    { id: 'notes', label: '6. CA Notes & Observations', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={facilityToEdit ? `Credit Facility Audit Record: ${facilityToEdit.borrowerName}` : 'New Credit Facility Audit Entry'}
      subtitle={`Branch: ${branch} | Active User: ${currentUser.name} (${currentUser.role.toUpperCase()})`}
      maxWidth="5xl"
      footer={
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 w-full">
          <AutosaveIndicator lastSavedAt={lastAutosave} />
          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            {facilityToEdit && canDeleteFacility(facilityToEdit) && (
              <Button 
                variant="ghost" 
                size="sm"
                icon={<Trash2 className="w-4 h-4 text-rose-500" />}
                onClick={handleDeleteFacility}
                className="text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40"
              >
                Delete Record
              </Button>
            )}
            <Button variant="secondary" onClick={onClose}>
              Cancel
            </Button>
            <Button
              variant="primary"
              icon={<Save className="w-4 h-4" />}
              onClick={handleSubmit}
            >
              {facilityToEdit ? (isRecordLocked ? 'Save & Protect Record' : 'Save Unlocked Revision') : 'Save & Commit to Register'}
            </Button>
          </div>
        </div>
      }
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Top Authorization Banner */}
        {facilityToEdit ? (
          <div className={clsx(
            'p-3.5 rounded-xl border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs',
            isAdmin 
              ? 'bg-purple-50/70 border-purple-200 dark:bg-purple-950/30 dark:border-purple-900 text-purple-950 dark:text-purple-200'
              : 'bg-blue-50/70 border-blue-200 dark:bg-blue-950/30 dark:border-blue-900 text-blue-950 dark:text-blue-200'
          )}>
            <div className="flex items-center gap-2">
              <ShieldCheck className={clsx('w-5 h-5 shrink-0', isAdmin ? 'text-purple-600' : 'text-blue-600')} />
              <div>
                <span className="font-bold block">
                  {isAdmin 
                    ? `🛡️ CA Admin Mode (${currentUser.name}) — Full Authorization` 
                    : `✍️ Staff Auditor Mode (${currentUser.name}) — Saved Audit Facility`}
                </span>
                <span className="text-[11px] opacity-80">
                  {isAdmin 
                    ? 'You can modify any parameters or toggle the record lock.' 
                    : 'Changes will be logged in the immutable audit history under your name.'}
                </span>
              </div>
            </div>

            {isAdmin && (
              <label className="flex items-center gap-2 cursor-pointer bg-white dark:bg-slate-900 px-3 py-1.5 rounded-lg border border-purple-200 dark:border-purple-800 shadow-xs">
                <input
                  type="checkbox"
                  checked={isRecordLocked}
                  onChange={e => setIsRecordLocked(e.target.checked)}
                  className="rounded text-purple-600 focus:ring-purple-500"
                />
                <span className="font-semibold text-slate-800 dark:text-slate-200 text-[11px] flex items-center gap-1">
                  {isRecordLocked ? <Lock className="w-3 h-3 text-purple-600" /> : <Unlock className="w-3 h-3 text-amber-500" />}
                  {isRecordLocked ? 'Locked (Protected)' : 'Unlocked for Edit'}
                </span>
              </label>
            )}
          </div>
        ) : (
          <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 rounded-xl flex items-center gap-2.5 text-xs text-emerald-900 dark:text-emerald-200">
            <Info className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>New Credit Facility Entry:</strong> Enter borrower loan details below. Once saved, this record is permanently preserved in the audit database.
            </span>
          </div>
        )}

        {/* Tabs Bar */}
        <Tabs tabs={tabs} activeTab={activeTab} onChange={setActiveTab} />

        {/* Tab 1: Borrower & Core Info */}
        {activeTab === 'borrower' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Borrower Name"
                required
                value={borrowerName}
                onChange={e => setBorrowerName(e.target.value)}
                placeholder="e.g. Acme Precision Tools Pvt. Ltd."
              />
              <Input
                label="Account Number (Unique)"
                required
                value={accountNumber}
                onChange={e => setAccountNumber(e.target.value)}
                placeholder="e.g. 0142-CC-901829"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Select
                label="Facility Type"
                value={facilityType}
                onChange={e => setFacilityType(e.target.value as FacilityType)}
                options={FACILITY_TYPES}
              />
              <Select
                label="Constitution"
                value={constitution}
                onChange={e => setConstitution(e.target.value as ConstitutionType)}
                options={CONSTITUTION_TYPES}
              />
              <Select
                label="Industry / Sector"
                value={industrySector}
                onChange={e => setIndustrySector(e.target.value as SectorType)}
                options={SECTOR_TYPES}
              />
            </div>

            <Input
              label="Branch Name / Code"
              value={branch}
              onChange={e => setBranch(e.target.value)}
            />
          </div>
        )}

        {/* Tab 2: Sanction & Renewal */}
        {activeTab === 'sanction' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Sanction Date"
                type="date"
                value={sanctionDate}
                onChange={e => setSanctionDate(e.target.value)}
              />
              <Input
                label="Sanctioning Authority"
                value={sanctioningAuthority}
                onChange={e => setSanctioningAuthority(e.target.value)}
                placeholder="e.g. Zonal Credit Committee / Circle Office"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input
                label="Last Renewal Date"
                type="date"
                value={lastRenewalDate}
                onChange={e => setLastRenewalDate(e.target.value)}
              />
              <Input
                label="Next Renewal Due Date"
                type="date"
                value={nextRenewalDueDate}
                onChange={e => setNextRenewalDueDate(e.target.value)}
              />
              <Input
                label="Interest Rate (% p.a.)"
                type="number"
                step="0.05"
                value={interestRate || ''}
                onChange={e => setInterestRate(parseFloat(e.target.value))}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800">
              <Input
                label="Sanctioned Limit - Fund Based (₹)"
                type="number"
                currencyPrefix
                value={sanctionedLimitFundBased || ''}
                onChange={e => setSanctionedLimitFundBased(Number(e.target.value))}
              />
              <Input
                label="Sanctioned Limit - Non-Fund Based (₹)"
                type="number"
                currencyPrefix
                value={sanctionedLimitNonFundBased || ''}
                onChange={e => setSanctionedLimitNonFundBased(Number(e.target.value))}
              />
              <Input
                label="Current Outstanding Balance (₹)"
                type="number"
                required
                currencyPrefix
                value={outstandingBalance || ''}
                onChange={e => setOutstandingBalance(Number(e.target.value))}
              />
            </div>

            <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-lg text-xs flex justify-between items-center text-blue-900 dark:text-blue-200">
              <span>Total Sanctioned Limit: <strong>₹{totalSanctionedLimit.toLocaleString('en-IN')}</strong></span>
              <span>Exposure Ratio: <strong>{totalSanctionedLimit > 0 ? ((outstandingBalance / totalSanctionedLimit) * 100).toFixed(1) : 0}%</strong></span>
            </div>
          </div>
        )}

        {/* Tab 3: Securities & Margin */}
        {activeTab === 'securities' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Primary Security Description
              </label>
              <textarea
                rows={2}
                value={primarySecurity}
                onChange={e => setPrimarySecurity(e.target.value)}
                placeholder="e.g. Hypothecation of entire stocks of raw materials, stock-in-process, finished goods and book debts."
                className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Collateral Security Description
              </label>
              <textarea
                rows={2}
                value={collateralSecurity}
                onChange={e => setCollateralSecurity(e.target.value)}
                placeholder="e.g. Registered EM of Commercial Property situated at Plot 45, MIDC Industrial Area."
                className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Realizable Value of Primary Security (₹)"
                type="number"
                currencyPrefix
                value={realizableValuePrimary || ''}
                onChange={e => setRealizableValuePrimary(Number(e.target.value))}
              />
              <Input
                label="Realizable Value of Collateral Security (₹)"
                type="number"
                currencyPrefix
                value={realizableValueCollateral || ''}
                onChange={e => setRealizableValueCollateral(Number(e.target.value))}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Input
                label="Guarantor(s) Details & Net Worth"
                value={guarantors}
                onChange={e => setGuarantors(e.target.value)}
                placeholder="e.g. Ramesh Kumar (Director, Net worth: ₹4.5 Cr)"
              />
              <Input
                label="Stipulated Margin (%)"
                type="number"
                value={stipulatedMarginPercent || ''}
                onChange={e => setStipulatedMarginPercent(Number(e.target.value))}
              />
              <Input
                label="Bank Stated Norm Margin (%)"
                type="number"
                value={bankNormMarginPercent || ''}
                onChange={e => setBankNormMarginPercent(Number(e.target.value))}
              />
            </div>
          </div>
        )}

        {/* Tab 4: Compliance & Banking Norms */}
        {activeTab === 'compliance' && (
          <div className="space-y-5 animate-in fade-in duration-150">
            {/* Section 20 BRA 1949 */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    Section 20 of Banking Regulation Act 1949 (Related Party Facility)
                  </h4>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Restrictions on loans and advances to Directors of the banking company or firms/entities in which they have substantial interest.
                  </p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isRelatedParty}
                    onChange={e => setIsRelatedParty(e.target.checked)}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-slate-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-rose-600"></div>
                </label>
              </div>

              {isRelatedParty && (
                <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-lg space-y-2 border border-rose-200 dark:border-rose-900">
                  <Input
                    label="Director / Related Party Connection Details & Board Resolution"
                    required
                    value={relatedPartyDetails}
                    onChange={e => setRelatedPartyDetails(e.target.value)}
                    placeholder="e.g. Partner is brother of Bank Director. Approved vide Board Resolution No. BD/2025/89."
                  />
                </div>
              )}
            </div>

            {/* Insurance Policy */}
            <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-3">
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Insurance Coverage & Policy Expiry
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <Input
                  label="Insurance Details / Policy Number"
                  value={insuranceDetails}
                  onChange={e => setInsuranceDetails(e.target.value)}
                  placeholder="e.g. New India Assurance Fire & Burglary Pol #881923"
                />
                <Input
                  label="Insurance Expiry Date"
                  type="date"
                  value={insuranceExpiryDate}
                  onChange={e => setInsuranceExpiryDate(e.target.value)}
                />
                <Input
                  label="Sum Insured (₹)"
                  type="number"
                  currencyPrefix
                  value={insuranceAmount || ''}
                  onChange={e => setInsuranceAmount(Number(e.target.value))}
                />
              </div>
            </div>

            {/* Norms Override Warning & Validation */}
            <NormsOverrideWarning
              check={normsCheck}
              overrideRemarks={overrideRemarks}
              overrideApprovingAuthority={overrideApprovingAuthority}
              onRemarksChange={setOverrideRemarks}
              onAuthorityChange={setOverrideApprovingAuthority}
              isEditable={true}
            />
          </div>
        )}

        {/* Tab 5: Documentation Checklist */}
        {activeTab === 'checklist' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Statutory Credit Documentation & Security Charge Checklist
              </h4>
              <span className="text-xs text-slate-500 dark:text-slate-400">
                {checklist.filter(c => c.status === 'Obtained & Valid').length} of {checklist.length} Valid
              </span>
            </div>

            <div className="border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold">
                  <tr>
                    <th className="p-3 w-10">Sr.</th>
                    <th className="p-3">Document / Requirement</th>
                    <th className="p-3 w-48">Status</th>
                    <th className="p-3 w-36">Expiry Date</th>
                    <th className="p-3">Ref / Remarks</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {checklist.map((item, idx) => (
                    <tr key={item.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                      <td className="p-3 text-slate-400 font-mono text-center">{idx + 1}</td>
                      <td className="p-3 font-medium text-slate-900 dark:text-slate-100">
                        {item.title}
                        <span className="block text-[10px] text-slate-400">{item.category}</span>
                      </td>
                      <td className="p-3">
                        <select
                          value={item.status}
                          onChange={e => handleChecklistStatusChange(item.id, e.target.value as DocumentationStatus)}
                          className="w-full text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-1.5"
                        >
                          {DOC_STATUSES.map(s => (
                            <option key={s.value} value={s.value}>
                              {s.label}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="p-3">
                        <input
                          type="date"
                          value={item.expiryDate || ''}
                          onChange={e => handleChecklistFieldChange(item.id, 'expiryDate', e.target.value)}
                          className="w-full text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-1.5"
                        />
                      </td>
                      <td className="p-3">
                        <input
                          type="text"
                          value={item.documentRef || ''}
                          onChange={e => handleChecklistFieldChange(item.id, 'documentRef', e.target.value)}
                          placeholder="Doc reference / remarks"
                          className="w-full text-xs rounded-md border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-1.5"
                        />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* Tab 6: CA Notes & Observations */}
        {activeTab === 'notes' && (
          <div className="space-y-4 animate-in fade-in duration-150">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Auditor's Statutory Observations & Audit Memorandum
              </label>
              <textarea
                rows={4}
                value={auditorObservations}
                onChange={e => setAuditorObservations(e.target.value)}
                placeholder="Detailed statutory audit observations regarding account turnover, drawing power irregularities, documentation lapses, or asset classification."
                className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-slate-900 dark:text-slate-100"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Additional Notes (Free Text / Branch Explanations)
              </label>
              <textarea
                rows={3}
                value={additionalNotes}
                onChange={e => setAdditionalNotes(e.target.value)}
                placeholder="Branch response, management representations, or follow-up action required."
                className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-3 text-slate-900 dark:text-slate-100"
              />
            </div>

            {facilityToEdit && (
              <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
                <Input
                  label="Reason for this Revision / Change (Recorded in Edit History)"
                  value={changeReason}
                  onChange={e => setChangeReason(e.target.value)}
                  placeholder="e.g. Updated stock statement valuation per August 2026 submission"
                />
              </div>
            )}
          </div>
        )}
      </form>
    </Modal>
  );
};
