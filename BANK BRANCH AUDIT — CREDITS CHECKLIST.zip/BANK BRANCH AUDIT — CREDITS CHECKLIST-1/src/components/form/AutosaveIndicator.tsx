import React from 'react';
import { Cloud, Check, Clock } from 'lucide-react';

interface AutosaveIndicatorProps {
  lastSavedAt: string | null;
  isSaving?: boolean;
}

export const AutosaveIndicator: React.FC<AutosaveIndicatorProps> = ({ lastSavedAt, isSaving = false }) => {
  if (isSaving) {
    return (
      <div className="flex items-center gap-1.5 text-xs text-blue-600 dark:text-blue-400">
        <Clock className="w-3.5 h-3.5 animate-spin" />
        <span>Autosaving draft...</span>
      </div>
    );
  }

  if (lastSavedAt) {
    return (
      <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
        <Check className="w-3.5 h-3.5 text-emerald-500" />
        <span>Draft saved locally ({new Date(lastSavedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })})</span>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-1.5 text-xs text-slate-400">
      <Cloud className="w-3.5 h-3.5" />
      <span>Autosave active</span>
    </div>
  );
};
