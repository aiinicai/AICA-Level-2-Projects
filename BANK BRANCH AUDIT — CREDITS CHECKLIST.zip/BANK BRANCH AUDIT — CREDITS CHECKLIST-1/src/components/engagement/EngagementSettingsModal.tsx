import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Input } from '../common/Input';
import { useAudit } from '../../context/AuditContext';
import { AuditMetadata } from '../../services/storageService';
import { 
  Building2, 
  Calendar, 
  ShieldCheck, 
  Save, 
  CheckCircle2, 
  RefreshCw,
  MapPin,
  FileSpreadsheet
} from 'lucide-react';

interface EngagementSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EngagementSettingsModal: React.FC<EngagementSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { auditMetadata, updateAuditMetadata, resetAllData } = useAudit();
  const [meta, setMeta] = useState<AuditMetadata>(auditMetadata);
  const [recalculatePortfolio, setRecalculatePortfolio] = useState(true);
  const [savedSuccess, setSavedSuccess] = useState(false);

  const handleChange = (key: keyof AuditMetadata, value: string) => {
    setMeta(prev => ({
      ...prev,
      [key]: value,
    }));
  };

  const handleSave = () => {
    updateAuditMetadata(meta);
    if (recalculatePortfolio && meta.auditAsOfDate !== auditMetadata.auditAsOfDate) {
      // Re-seed portfolio calculations aligned to the new As-on date
      resetAllData(meta.auditAsOfDate);
    }
    setSavedSuccess(true);
    setTimeout(() => {
      setSavedSuccess(false);
      onClose();
    }, 700);
  };

  const PRESET_DATES = [
    { label: '31-Mar-2026 (Statutory FY End)', value: '2026-03-31' },
    { label: '30-Jun-2026 (Q1 Concurrent Audit)', value: '2026-06-30' },
    { label: '03-Sep-2026 (Current Reporting Date)', value: '2026-09-03' },
    { label: '30-Sep-2026 (Half-Yearly Review)', value: '2026-09-30' },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Audit Engagement, Bank & Firm Configuration"
      subtitle="Configure audited bank branch, conducting CA firm, and Advance Audit reporting As-on date"
      maxWidth="4xl"
      footer={
        <>
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant="primary"
            icon={savedSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-300" /> : <Save className="w-4 h-4" />}
            onClick={handleSave}
          >
            {savedSuccess ? 'Saved & Applied Everywhere!' : 'Save Configuration'}
          </Button>
        </>
      }
    >
      <div className="space-y-6">
        {/* Section 1: Advance Audit As-on Date & Audit Year */}
        <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900 bg-blue-50/50 dark:bg-blue-950/30 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-bold uppercase tracking-wider text-blue-900 dark:text-blue-300 flex items-center gap-1.5">
              <Calendar className="w-4 h-4 text-blue-600 dark:text-blue-400" />
              1. Advance Audit Reporting Date & Period
            </h4>
            <span className="text-[11px] text-blue-700 dark:text-blue-300 font-medium">
              Controls DP stale calculations & IRAC aging
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Advance Audit "As-On Date" <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                required
                value={meta.auditAsOfDate}
                onChange={e => handleChange('auditAsOfDate', e.target.value)}
                className="w-full text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-slate-900 dark:text-slate-100 font-semibold"
              />
            </div>

            <Input
              label="Audit Financial Year"
              value={meta.auditYear}
              onChange={e => handleChange('auditYear', e.target.value)}
              placeholder="e.g. 2026-27"
            />
          </div>

          {/* Quick Date Presets */}
          <div className="pt-2 flex flex-wrap items-center gap-2 text-xs">
            <span className="text-slate-500 dark:text-slate-400 text-[11px] font-medium">Quick Date Presets:</span>
            {PRESET_DATES.map(p => (
              <button
                key={p.value}
                type="button"
                onClick={() => handleChange('auditAsOfDate', p.value)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold border transition-colors ${
                  meta.auditAsOfDate === p.value
                    ? 'bg-blue-600 text-white border-blue-600'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-300 dark:border-slate-700 hover:bg-slate-100'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          <label className="flex items-center gap-2 pt-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
            <input
              type="checkbox"
              checked={recalculatePortfolio}
              onChange={e => setRecalculatePortfolio(e.target.checked)}
              className="rounded text-blue-600 focus:ring-blue-500"
            />
            <span className="font-semibold text-blue-900 dark:text-blue-300">
              Automatically re-evaluate all 300 accounts against this As-on date (IRAC aging, provisioning & stale statement days)
            </span>
          </label>
        </div>

        {/* Section 2: Bank & Branch Being Audited */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <Building2 className="w-4 h-4 text-emerald-600" />
            2. Bank & Audited Branch Profile
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Name of the Bank"
              required
              value={meta.bankName}
              onChange={e => handleChange('bankName', e.target.value)}
              placeholder="e.g. Nationalized Commercial Bank of India"
            />
            <Input
              label="Bank Head / Corporate Office Address"
              value={meta.bankAddress || ''}
              onChange={e => handleChange('bankAddress', e.target.value)}
              placeholder="e.g. Corporate Centre, Madame Cama Road, Nariman Point, Mumbai - 400021"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <Input
                label="Branch Name"
                required
                value={meta.branchName}
                onChange={e => handleChange('branchName', e.target.value)}
                placeholder="e.g. Nariman Point Corporate Branch"
              />
            </div>
            <Input
              label="Branch Sol ID / Code"
              required
              value={meta.branchCode}
              onChange={e => handleChange('branchCode', e.target.value)}
              placeholder="e.g. 0142"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Branch Physical Address & Location
            </label>
            <textarea
              rows={2}
              value={meta.branchAddress || ''}
              onChange={e => handleChange('branchAddress', e.target.value)}
              placeholder="e.g. Ground & 1st Floor, Express Towers, Nariman Point, Mumbai - 400021"
              className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>

        {/* Section 3: Audit Conducting Chartered Accountant Firm */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-4">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-purple-600" />
            3. Audit Conducting CA Firm Profile & Signatory
          </h4>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Name of CA Firm"
              required
              value={meta.firmName}
              onChange={e => handleChange('firmName', e.target.value)}
              placeholder="e.g. R. Sharma & Associates, Chartered Accountants"
            />
            <Input
              label="Firm Registration Number (FRN)"
              required
              value={meta.firmFRN}
              onChange={e => handleChange('firmFRN', e.target.value)}
              placeholder="e.g. 109823W"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input
              label="Lead Auditor / Engagement Partner Name"
              required
              value={meta.leadAuditor}
              onChange={e => handleChange('leadAuditor', e.target.value)}
              placeholder="e.g. CA. Rajesh Sharma"
            />
            <Input
              label="ICAI Membership Number"
              value={meta.membershipNumber || ''}
              onChange={e => handleChange('membershipNumber', e.target.value)}
              placeholder="e.g. 054321"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              CA Firm Head / Branch Office Address
            </label>
            <textarea
              rows={2}
              value={meta.firmAddress || ''}
              onChange={e => handleChange('firmAddress', e.target.value)}
              placeholder="e.g. Suite 402, Commerce House, Fort, Mumbai - 400001"
              className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:ring-1 focus:ring-blue-500"
            />
          </div>
        </div>
      </div>
    </Modal>
  );
};
