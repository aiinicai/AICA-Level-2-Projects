import React from 'react';
import { 
  LayoutDashboard, 
  FileSpreadsheet, 
  Calculator, 
  ShieldAlert, 
  FileText, 
  Settings, 
  ShieldCheck,
  Building2,
  Users,
  Calendar,
  History
} from 'lucide-react';
import clsx from 'clsx';
import { useAudit } from '../../context/AuditContext';

export type NavTab = 'dashboard' | 'register' | 'dp' | 'irac' | 'reports' | 'settings';

interface SidebarProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
  onOpenEngagementSettings?: () => void;
  onOpenTeamManagement?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeTab, 
  onTabChange,
  onOpenEngagementSettings,
  onOpenTeamManagement
}) => {
  const { alerts, facilities, auditMetadata } = useAudit();
  const activeCount = facilities.filter(f => !f.isArchived).length;

  const navItems: { id: NavTab; label: string; icon: React.ReactNode; badge?: React.ReactNode }[] = [
    {
      id: 'dashboard',
      label: 'Executive Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'register',
      label: 'Credit Audit Register',
      icon: <FileSpreadsheet className="w-4 h-4" />,
      badge: <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300">{activeCount}</span>,
    },
    {
      id: 'dp',
      label: 'Drawing Power Engine',
      icon: <Calculator className="w-4 h-4" />,
    },
    {
      id: 'irac',
      label: 'IRAC & Provisioning',
      icon: <ShieldAlert className="w-4 h-4" />,
    },
    {
      id: 'reports',
      label: 'Reports & Exports',
      icon: <FileText className="w-4 h-4" />,
    },
    {
      id: 'settings',
      label: 'RBI Master Rates',
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col shrink-0 border-r border-slate-800 hidden md:flex">
      {/* Brand Header */}
      <div className="h-16 px-5 flex items-center gap-3 border-b border-slate-800">
        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center font-black text-white shadow-md">
          CA
        </div>
        <div>
          <h2 className="text-sm font-black tracking-tight text-white leading-tight">
            CREDIT AUDIT
          </h2>
          <p className="text-[10px] text-blue-300 font-semibold tracking-wider uppercase">
            Bank Branch System
          </p>
        </div>
      </div>

      {/* Main Navigation List */}
      <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
        {navItems.map(item => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={clsx(
                'w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-colors cursor-pointer',
                isActive
                  ? 'bg-blue-600 text-white shadow-sm'
                  : 'text-slate-300 hover:text-white hover:bg-slate-800/80'
              )}
            >
              <div className="flex items-center gap-2.5">
                <span className={isActive ? 'text-white' : 'text-slate-400'}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </div>
              {item.badge}
            </button>
          );
        })}

        {/* Quick Engagement Shortcuts */}
        <div className="pt-3 mt-3 border-t border-slate-800/80 space-y-1">
          <span className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 block mb-1.5">
            Engagement Configuration
          </span>

          <button
            onClick={onOpenEngagementSettings}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer text-left"
          >
            <Building2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate">Bank, Branch & As-on</span>
          </button>

          <button
            onClick={onOpenTeamManagement}
            className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/80 transition-colors cursor-pointer text-left"
          >
            <Users className="w-4 h-4 text-blue-400 shrink-0" />
            <span className="truncate">CA & Staff Profiles</span>
          </button>
        </div>
      </nav>

      {/* Alerts Indicator Footer */}
      {alerts.length > 0 && (
        <div className="p-3 border-t border-slate-800">
          <div
            onClick={() => onTabChange('dashboard')}
            className="p-3 rounded-xl bg-rose-950/40 border border-rose-800/60 text-rose-200 text-xs flex items-center justify-between cursor-pointer hover:bg-rose-900/40 transition-colors"
          >
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              <span className="font-bold">{alerts.length} Active Risk Alert(s)</span>
            </div>
          </div>
        </div>
      )}

      {/* Bottom CA Compliance Footer */}
      <div className="p-4 border-t border-slate-800/80 text-[10px] text-slate-500">
        <p className="font-semibold text-slate-400 truncate">{auditMetadata.firmName}</p>
        <p>FRN: {auditMetadata.firmFRN} &bull; As on {auditMetadata.auditAsOfDate}</p>
      </div>
    </aside>
  );
};
