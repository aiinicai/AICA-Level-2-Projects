import React, { useRef } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { useAudit } from '../../context/AuditContext';
import { Button } from '../common/Button';
import { 
  Sun, 
  Moon, 
  User, 
  Building2, 
  ShieldCheck, 
  RotateCcw, 
  Settings,
  Calendar,
  Users,
  Edit,
  Download,
  Upload,
  Database,
  Shield
} from 'lucide-react';
import clsx from 'clsx';

interface HeaderProps {
  onOpenSettings: () => void;
  onOpenEngagementSettings: () => void;
  onOpenTeamManagement: () => void;
}

export const Header: React.FC<HeaderProps> = ({ 
  onOpenSettings,
  onOpenEngagementSettings,
  onOpenTeamManagement 
}) => {
  const { currentUser, allUsers, switchUser, isAdmin, isStaff } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const { auditMetadata, resetAllData, exportBackupJSON, restoreBackupJSON, facilities } = useAudit();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleExportBackup = () => {
    const jsonStr = exportBackupJSON();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const dateStr = new Date().toISOString().split('T')[0];
    a.download = `BankAudit_${auditMetadata.branchCode}_${auditMetadata.auditAsOfDate}_Backup_${dateStr}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        const res = restoreBackupJSON(content);
        if (res.success) {
          alert(`Backup restored successfully!\n${res.count} credit facilities loaded.`);
        } else {
          alert(`Failed to restore backup: ${res.message}`);
        }
      }
    };
    reader.readAsText(file);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between gap-4 sticky top-0 z-30 shadow-xs">
      {/* Left: Bank & Branch Info (Clickable to Edit) */}
      <div 
        onClick={onOpenEngagementSettings}
        className="flex items-center gap-3 min-w-0 cursor-pointer group p-1.5 -ml-1.5 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800/60 transition-colors"
        title="Click to edit Bank, Branch, Conducting CA Firm & As-on Date"
      >
        <div className="p-2 rounded-xl bg-blue-600 text-white shadow-xs shrink-0 group-hover:bg-blue-700 transition-colors">
          <Building2 className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <h1 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate group-hover:text-blue-600 transition-colors">
              {auditMetadata.branchName}
            </h1>
            <Edit className="w-3 h-3 text-slate-400 group-hover:text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
            {auditMetadata.bankName} &bull; Code: {auditMetadata.branchCode}
          </p>
        </div>
      </div>

      {/* Middle: As-On Date Badge */}
      <div 
        onClick={onOpenEngagementSettings}
        className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300 cursor-pointer hover:border-blue-400 transition-colors"
        title="Click to change Advance Audit As-On Reporting Date"
      >
        <Calendar className="w-3.5 h-3.5 text-blue-600 dark:text-blue-400" />
        <span>As on: <strong>{auditMetadata.auditAsOfDate}</strong> (FY {auditMetadata.auditYear})</span>
        <Edit className="w-3 h-3 text-slate-400" />
      </div>

      {/* Right: Controls, Team Manager & User Switcher */}
      <div className="flex items-center gap-2">
        {/* Backup / Export JSON Button */}
        <Button
          variant="outline"
          size="sm"
          icon={<Download className="w-3.5 h-3.5 text-indigo-600" />}
          onClick={handleExportBackup}
          title="Download complete offline .json backup of all 300 accounts and audit notes"
          className="hidden md:inline-flex text-xs"
        >
          Export Backup
        </Button>

        {/* Restore Backup File Input */}
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept=".json" 
          className="hidden" 
        />
        <Button
          variant="outline"
          size="sm"
          icon={<Upload className="w-3.5 h-3.5 text-slate-600 dark:text-slate-300" />}
          onClick={() => fileInputRef.current?.click()}
          title="Restore audit data from offline .json backup"
          className="hidden xl:inline-flex text-xs"
        >
          Restore JSON
        </Button>

        {/* Engagement & Bank Config Button */}
        <Button
          variant="outline"
          size="sm"
          icon={<Building2 className="w-3.5 h-3.5 text-emerald-600" />}
          onClick={onOpenEngagementSettings}
          title="Edit Bank, Branch, Firm & As-on Date"
          className="hidden sm:inline-flex text-xs"
        >
          Bank & Firm
        </Button>

        {/* Team / Staff Management Button */}
        <Button
          variant="outline"
          size="sm"
          icon={<Users className="w-3.5 h-3.5 text-blue-600" />}
          onClick={onOpenTeamManagement}
          title="Edit CA & Staff Names, Roles & Profiles"
          className="hidden sm:inline-flex text-xs"
        >
          CA & Staff Team
        </Button>

        {/* Reset 300 Master Records (Admin Only) */}
        {isAdmin && (
          <Button
            variant="ghost"
            size="sm"
            icon={<RotateCcw className="w-3.5 h-3.5 text-slate-500" />}
            onClick={() => {
              if (window.confirm(`CA ADMIN CONFIRMATION:\nRe-generate clean 300 sample credit facilities aligned to reporting date ${auditMetadata.auditAsOfDate}?`)) {
                resetAllData(auditMetadata.auditAsOfDate);
              }
            }}
            title="CA Admin: Re-generate clean 300 sample accounts"
            className="hidden 2xl:inline-flex text-xs"
          >
            Reset 300 Records
          </Button>
        )}

        {/* RBI Settings */}
        <Button
          variant="ghost"
          size="sm"
          icon={<Settings className="w-4 h-4 text-slate-600 dark:text-slate-300" />}
          onClick={onOpenSettings}
          title="RBI Rate Master Matrix"
        />

        {/* Theme Toggle */}
        <Button
          variant="ghost"
          size="sm"
          icon={theme === 'dark' ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-slate-600" />}
          onClick={toggleTheme}
          title={theme === 'dark' ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        />

        {/* Role & User Profile Switcher */}
        <div className="flex items-center gap-2 pl-2 border-l border-slate-200 dark:border-slate-800">
          <div 
            onClick={onOpenTeamManagement}
            className="text-right hidden xl:block cursor-pointer hover:opacity-80"
            title="Click to edit CA/Staff profile"
          >
            <span className="text-xs font-bold text-slate-900 dark:text-slate-100 block truncate max-w-[130px]">
              {currentUser.name}
            </span>
            <span className={clsx(
              "text-[10px] uppercase font-bold block",
              isAdmin ? "text-purple-600 dark:text-purple-400" : "text-blue-600 dark:text-blue-400"
            )}>
              {isAdmin ? '🛡️ CA Admin' : (isStaff ? '✍️ Staff' : '👁️ Read-Only')}
            </span>
          </div>

          <select
            value={currentUser.id}
            onChange={e => switchUser(e.target.value)}
            className="text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 py-1.5 px-2 text-slate-800 dark:text-slate-200 cursor-pointer font-medium"
            title="Switch Active Auditor Profile"
          >
            {allUsers.map(u => {
              const uIsAdmin = u.role === 'admin' || u.role === 'reviewer' || u.isAdmin;
              return (
                <option key={u.id} value={u.id}>
                  {u.name} ({uIsAdmin ? 'CA Admin' : (u.role === 'staff' || u.role === 'auditor' ? 'Staff' : 'Read-Only')})
                </option>
              );
            })}
          </select>
        </div>
      </div>
    </header>
  );
};
