import React, { useState } from 'react';
import { Sidebar, NavTab } from './Sidebar';
import { Header } from './Header';
import { MobileNav } from './MobileNav';
import { DashboardView } from '../dashboard/DashboardView';
import { CreditRegister } from '../register/CreditRegister';
import { DPEngineView } from '../dp/DPEngineView';
import { IRACEngineView } from '../irac/IRACEngineView';
import { ReportsView } from '../reports/ReportsView';
import { IRACSettingsModal } from '../irac/IRACSettingsModal';
import { EngagementSettingsModal } from '../engagement/EngagementSettingsModal';
import { TeamManagementModal } from '../team/TeamManagementModal';

export const AppShell: React.FC = () => {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [engagementModalOpen, setEngagementModalOpen] = useState(false);
  const [teamModalOpen, setTeamModalOpen] = useState(false);

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            onNavigateToRegister={() => setActiveTab('register')}
            onOpenSettings={() => setSettingsOpen(true)}
            onOpenEngagementSettings={() => setEngagementModalOpen(true)}
            onOpenTeamManagement={() => setTeamModalOpen(true)}
          />
        );
      case 'register':
        return <CreditRegister />;
      case 'dp':
        return <DPEngineView />;
      case 'irac':
        return <IRACEngineView onOpenSettings={() => setSettingsOpen(true)} />;
      case 'reports':
        return <ReportsView />;
      case 'settings':
        return (
          <div className="space-y-4">
            <IRACEngineView onOpenSettings={() => setSettingsOpen(true)} />
          </div>
        );
      default:
        return (
          <DashboardView
            onNavigateToRegister={() => setActiveTab('register')}
            onOpenSettings={() => setSettingsOpen(true)}
            onOpenEngagementSettings={() => setEngagementModalOpen(true)}
            onOpenTeamManagement={() => setTeamModalOpen(true)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-100 dark:bg-slate-950 font-sans text-slate-900 dark:text-slate-100">
      {/* Desktop Sidebar */}
      <Sidebar 
        activeTab={activeTab} 
        onTabChange={setActiveTab}
        onOpenEngagementSettings={() => setEngagementModalOpen(true)}
        onOpenTeamManagement={() => setTeamModalOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 pb-16 md:pb-0">
        {/* Top Header */}
        <Header 
          onOpenSettings={() => setSettingsOpen(true)} 
          onOpenEngagementSettings={() => setEngagementModalOpen(true)}
          onOpenTeamManagement={() => setTeamModalOpen(true)}
        />

        {/* Dynamic Main Body */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto overflow-y-auto">
          {renderContent()}
        </main>
      </div>

      {/* Mobile Bottom Navigation */}
      <MobileNav activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Global RBI Rate Matrix Modal */}
      {settingsOpen && (
        <IRACSettingsModal
          isOpen={settingsOpen}
          onClose={() => setSettingsOpen(false)}
        />
      )}

      {/* Engagement, Bank & Firm Details Modal */}
      {engagementModalOpen && (
        <EngagementSettingsModal
          isOpen={engagementModalOpen}
          onClose={() => setEngagementModalOpen(false)}
        />
      )}

      {/* CA & Staff Team Profiles Modal */}
      {teamModalOpen && (
        <TeamManagementModal
          isOpen={teamModalOpen}
          onClose={() => setTeamModalOpen(false)}
        />
      )}
    </div>
  );
};
