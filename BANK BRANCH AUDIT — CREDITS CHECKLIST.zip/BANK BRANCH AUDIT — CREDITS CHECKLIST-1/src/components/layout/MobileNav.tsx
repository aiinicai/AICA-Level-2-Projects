import React from 'react';
import { NavTab } from './Sidebar';
import { 
  LayoutDashboard, 
  FileSpreadsheet, 
  Calculator, 
  ShieldAlert, 
  FileText 
} from 'lucide-react';
import clsx from 'clsx';
import { useAudit } from '../../context/AuditContext';

interface MobileNavProps {
  activeTab: NavTab;
  onTabChange: (tab: NavTab) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ activeTab, onTabChange }) => {
  const { alerts } = useAudit();

  const items: { id: NavTab; label: string; icon: React.ReactNode; alertBadge?: boolean }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: <LayoutDashboard className="w-5 h-5" />, alertBadge: alerts.length > 0 },
    { id: 'register', label: 'Register', icon: <FileSpreadsheet className="w-5 h-5" /> },
    { id: 'dp', label: 'DP Engine', icon: <Calculator className="w-5 h-5" /> },
    { id: 'irac', label: 'IRAC', icon: <ShieldAlert className="w-5 h-5" /> },
    { id: 'reports', label: 'Reports', icon: <FileText className="w-5 h-5" /> },
  ];

  return (
    <nav className="fixed bottom-0 inset-x-0 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800 z-40 md:hidden flex items-center justify-around px-2 py-1.5 shadow-lg">
      {items.map(item => {
        const isActive = activeTab === item.id;
        return (
          <button
            key={item.id}
            onClick={() => onTabChange(item.id)}
            className={clsx(
              'flex flex-col items-center justify-center p-1.5 rounded-lg text-[10px] font-medium transition-colors relative',
              isActive
                ? 'text-blue-600 dark:text-blue-400 font-bold'
                : 'text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-200'
            )}
          >
            <span className="relative">
              {item.icon}
              {item.alertBadge && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              )}
            </span>
            <span className="mt-0.5">{item.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
