import React from 'react';
import { EditHistoryEntry, CreditFacility } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { History, User, Clock, ArrowRight } from 'lucide-react';

interface EditHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  facility: CreditFacility | null;
  historyEntries: EditHistoryEntry[];
}

export const EditHistoryModal: React.FC<EditHistoryModalProps> = ({
  isOpen,
  onClose,
  facility,
  historyEntries,
}) => {
  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={facility ? `Audit Trail & Edit History: ${facility.borrowerName}` : 'Audit Trail & Edit History'}
      subtitle={facility ? `Account: ${facility.accountNumber} | Granular field-level changelog` : 'Complete system edit changelog'}
      maxWidth="3xl"
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      <div className="space-y-4">
        {historyEntries.length === 0 ? (
          <div className="text-center py-12 text-slate-500 dark:text-slate-400 text-xs">
            <History className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700 mb-2" />
            <p>No field edits recorded yet for this facility.</p>
          </div>
        ) : (
          <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 space-y-6 py-2">
            {historyEntries.map(entry => (
              <div key={entry.id} className="relative pl-6">
                {/* Timeline node */}
                <div className="absolute -left-[9px] top-1 w-4 h-4 rounded-full bg-blue-600 border-2 border-white dark:border-slate-900" />

                <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 dark:border-slate-700/60 pb-2">
                    <div className="flex items-center gap-1.5 font-semibold text-slate-900 dark:text-slate-100">
                      <User className="w-3.5 h-3.5 text-blue-600" />
                      <span>{entry.changedByName || entry.changedBy}</span>
                    </div>
                    <div className="flex items-center gap-1.5 text-slate-400 text-[11px]">
                      <Clock className="w-3 h-3" />
                      <span>{new Date(entry.changedAt).toLocaleString()}</span>
                    </div>
                  </div>

                  <div className="space-y-1">
                    <div className="font-mono text-xs font-bold text-blue-700 dark:text-blue-400">
                      Field: <span className="text-slate-900 dark:text-slate-100">{entry.field}</span>
                    </div>

                    {entry.oldValue || entry.newValue ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono text-[11px]">
                        <div className="p-2 bg-rose-50 dark:bg-rose-950/40 rounded border border-rose-200 dark:border-rose-900/50 text-rose-800 dark:text-rose-300">
                          <span className="block text-[10px] uppercase font-bold text-rose-500">Previous Value:</span>
                          <span className="break-all">{entry.oldValue || '(empty)'}</span>
                        </div>
                        <div className="p-2 bg-emerald-50 dark:bg-emerald-950/40 rounded border border-emerald-200 dark:border-emerald-900/50 text-emerald-800 dark:text-emerald-300">
                          <span className="block text-[10px] uppercase font-bold text-emerald-500">New Value:</span>
                          <span className="break-all">{entry.newValue || '(empty)'}</span>
                        </div>
                      </div>
                    ) : null}

                    {entry.reason && (
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 italic pt-1">
                        Reason: {entry.reason}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Modal>
  );
};
