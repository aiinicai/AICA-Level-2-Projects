import React from 'react';
import { CreditFacility } from '../../types/audit';
import { DPBadge } from '../dp/DPBadge';
import { IRACBadge } from '../irac/IRACBadge';
import { Button } from '../common/Button';
import { useAuth } from '../../context/AuthContext';
import { useAudit } from '../../context/AuditContext';
import { 
  Edit, 
  Calculator, 
  FileText, 
  Paperclip, 
  History, 
  Trash2, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  ShieldAlert,
  Building2,
  Lock,
  Unlock
} from 'lucide-react';
import clsx from 'clsx';

interface CreditCardViewProps {
  facilities: CreditFacility[];
  onEdit: (facility: CreditFacility) => void;
  onOpenDP: (facility: CreditFacility) => void;
  onOpenIRAC: (facility: CreditFacility) => void;
  onOpenReport: (facility: CreditFacility) => void;
  onOpenAttachments: (facility: CreditFacility) => void;
  onOpenHistory: (facility: CreditFacility) => void;
  onArchive: (id: string) => void;
  onRestore: (id: string) => void;
  onToggleReview: (id: string) => void;
}

export const CreditCardView: React.FC<CreditCardViewProps> = ({
  facilities,
  onEdit,
  onOpenDP,
  onOpenIRAC,
  onOpenReport,
  onOpenAttachments,
  onOpenHistory,
  onArchive,
  onRestore,
  onToggleReview,
}) => {
  const { canEdit, canReview, isAdmin, canDeleteFacility } = useAuth();
  const { lockFacility, unlockFacility } = useAudit();

  if (facilities.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center space-y-2">
        <Building2 className="w-10 h-10 mx-auto text-slate-300 dark:text-slate-700" />
        <p className="text-xs text-slate-500">No facilities match your filters.</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-3 md:hidden">
      {facilities.map(fac => {
        const dp = fac.currentDPWorking;
        const irac = fac.currentIRAC;
        const isLocked = fac.isLocked !== false;

        return (
          <div
            key={fac.id}
            className={clsx(
              'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-xs space-y-3',
              fac.isArchived && 'opacity-60 bg-slate-50 dark:bg-slate-950'
            )}
          >
            {/* Header: Borrower & Account */}
            <div className="flex items-start justify-between gap-2">
              <div>
                <h4 className="font-bold text-sm text-slate-900 dark:text-slate-100">
                  {fac.borrowerName}
                </h4>
                <p className="font-mono text-[11px] text-slate-500 dark:text-slate-400">
                  {fac.accountNumber} &bull; {fac.facilityType}
                </p>
              </div>
              <div className="flex items-center gap-1">
                {isLocked ? (
                  <span className="p-1 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400" title="Saved & Protected">
                    <Lock className="w-3.5 h-3.5" />
                  </span>
                ) : (
                  <span className="p-1 rounded bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400" title="Draft / Unlocked">
                    <Unlock className="w-3.5 h-3.5" />
                  </span>
                )}
                <button
                  disabled={!canReview}
                  onClick={() => onToggleReview(fac.id)}
                  className={clsx(
                    'px-2 py-0.5 rounded-full text-[10px] font-bold shrink-0',
                    fac.isReviewed
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  )}
                >
                  {fac.isReviewed ? 'Reviewed' : 'Pending'}
                </button>
              </div>
            </div>

            {/* Tags: Section 20 / Norms */}
            <div className="flex flex-wrap gap-1.5">
              {fac.isRelatedParty && (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300">
                  Sec. 20 Related Party
                </span>
              )}
              {fac.isNormOverridden && (
                <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300">
                  Norms Breached
                </span>
              )}
            </div>

            {/* Numbers: Outstanding & Limit */}
            <div className="grid grid-cols-2 gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-xs">
              <div>
                <span className="text-slate-400 block text-[10px]">Outstanding:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">
                  ₹{(fac.outstandingBalance / 100000).toFixed(2)} L
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">Sanctioned Limit:</span>
                <span className="font-bold text-slate-900 dark:text-slate-100">
                  ₹{(fac.totalSanctionedLimit / 100000).toFixed(2)} L
                </span>
              </div>
            </div>

            {/* Health Badges: DP & IRAC */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <DPBadge facility={fac} />
              <IRACBadge category={irac?.computedCategory || 'Standard'} />
            </div>

            {/* Mobile Actions Grid */}
            <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-1">
              <div className="flex items-center gap-1">
                {canEdit && !fac.isArchived && (
                  <Button
                    variant="outline"
                    size="sm"
                    icon={<Edit className="w-3.5 h-3.5" />}
                    onClick={() => onEdit(fac)}
                  >
                    Edit
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  icon={<Calculator className="w-3.5 h-3.5 text-emerald-600" />}
                  onClick={() => onOpenDP(fac)}
                >
                  DP
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  icon={<ShieldAlert className="w-3.5 h-3.5 text-amber-600" />}
                  onClick={() => onOpenIRAC(fac)}
                >
                  IRAC
                </Button>
              </div>

              <div className="flex items-center gap-1">
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<FileText className="w-4 h-4 text-indigo-600" />}
                  onClick={() => onOpenReport(fac)}
                  title="Reports"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<Paperclip className="w-4 h-4 text-slate-500" />}
                  onClick={() => onOpenAttachments(fac)}
                  title="Attachments"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  icon={<History className="w-4 h-4 text-slate-500" />}
                  onClick={() => onOpenHistory(fac)}
                  title="History"
                />
                {canDeleteFacility(fac) && (
                  fac.isArchived ? (
                    <Button
                      variant="ghost"
                      size="sm"
                      icon={<RotateCcw className="w-4 h-4 text-emerald-600" />}
                      onClick={() => onRestore(fac.id)}
                      title="Restore"
                    />
                  ) : (
                    <Button
                      variant="ghost"
                      size="sm"
                      icon={<Trash2 className="w-4 h-4 text-rose-500" />}
                      onClick={() => {
                        if (window.confirm(`CA ADMIN: Archive account ${fac.accountNumber}?`)) {
                          onArchive(fac.id);
                        }
                      }}
                      title="Archive"
                    />
                  )
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
};
