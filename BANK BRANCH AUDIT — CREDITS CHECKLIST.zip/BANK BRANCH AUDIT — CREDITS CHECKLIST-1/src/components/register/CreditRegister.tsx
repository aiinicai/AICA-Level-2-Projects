import React, { useState, useMemo } from 'react';
import { CreditFacility } from '../../types/audit';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { FiltersBar } from './FiltersBar';
import { CreditTable } from './CreditTable';
import { CreditCardView } from './CreditCardView';
import { FacilityFormModal } from '../form/FacilityFormModal';
import { DPWorksheetModal } from '../dp/DPWorksheetModal';
import { IRACWorksheetModal } from '../irac/IRACWorksheetModal';
import { ReportGenerationModal } from '../reports/ReportGenerationModal';
import { BulkReportModal } from '../reports/BulkReportModal';
import { AttachmentManagerModal } from '../attachments/AttachmentManagerModal';
import { EditHistoryModal } from '../history/EditHistoryModal';
import { Button } from '../common/Button';
import { 
  Plus, 
  Download, 
  ChevronLeft, 
  ChevronRight, 
  ChevronsLeft, 
  ChevronsRight,
  SlidersHorizontal 
} from 'lucide-react';

export const CreditRegister: React.FC = () => {
  const { 
    filteredFacilities, 
    saveFacility, 
    archiveFacility, 
    restoreFacility, 
    toggleReviewStatus, 
    getHistoryForFacility,
    facilities 
  } = useAudit();
  const { canEdit, isReadOnly } = useAuth();

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState<number>(25);

  // Modal States
  const [formOpen, setFormOpen] = useState(false);
  const [selectedForEdit, setSelectedForEdit] = useState<CreditFacility | null>(null);

  const [dpModalOpen, setDpModalOpen] = useState(false);
  const [selectedForDP, setSelectedForDP] = useState<CreditFacility | null>(null);

  const [iracModalOpen, setIracModalOpen] = useState(false);
  const [selectedForIRAC, setSelectedForIRAC] = useState<CreditFacility | null>(null);

  const [reportModalOpen, setReportModalOpen] = useState(false);
  const [selectedForReport, setSelectedForReport] = useState<CreditFacility | null>(null);

  const [bulkReportOpen, setBulkReportOpen] = useState(false);

  const [attachModalOpen, setAttachModalOpen] = useState(false);
  const [selectedForAttach, setSelectedForAttach] = useState<CreditFacility | null>(null);

  const [historyModalOpen, setHistoryModalOpen] = useState(false);
  const [selectedForHistory, setSelectedForHistory] = useState<CreditFacility | null>(null);

  // Pagination computations
  const totalEntries = filteredFacilities.length;
  const totalPages = Math.max(1, Math.ceil(totalEntries / pageSize));

  // Reset to page 1 if filter makes current page out of range
  const safePage = Math.min(currentPage, totalPages);

  const paginatedFacilities = useMemo(() => {
    if (pageSize >= 1000) return filteredFacilities;
    const start = (safePage - 1) * pageSize;
    return filteredFacilities.slice(start, start + pageSize);
  }, [filteredFacilities, safePage, pageSize]);

  const startEntry = totalEntries === 0 ? 0 : (safePage - 1) * pageSize + 1;
  const endEntry = Math.min(safePage * pageSize, totalEntries);

  // Handlers
  const handleOpenCreate = () => {
    setSelectedForEdit(null);
    setFormOpen(true);
  };

  const handleOpenEdit = (fac: CreditFacility) => {
    setSelectedForEdit(fac);
    setFormOpen(true);
  };

  const handleOpenDP = (fac: CreditFacility) => {
    setSelectedForDP(fac);
    setDpModalOpen(true);
  };

  const handleSaveDP = (updatedDP: any) => {
    if (!selectedForDP) return;
    const updated: CreditFacility = {
      ...selectedForDP,
      currentDPWorking: updatedDP,
    };
    saveFacility(updated, 'Recalculated Drawing Power (DP) parameters');
  };

  const handleOpenIRAC = (fac: CreditFacility) => {
    setSelectedForIRAC(fac);
    setIracModalOpen(true);
  };

  const handleSaveIRAC = (updatedIRAC: any) => {
    if (!selectedForIRAC) return;
    const updated: CreditFacility = {
      ...selectedForIRAC,
      currentIRAC: updatedIRAC,
    };
    saveFacility(updated, `Updated IRAC classification to ${updatedIRAC.computedCategory}`);
  };

  const handleOpenReport = (fac: CreditFacility) => {
    setSelectedForReport(fac);
    setReportModalOpen(true);
  };

  const handleOpenAttachments = (fac: CreditFacility) => {
    setSelectedForAttach(fac);
    setAttachModalOpen(true);
  };

  const handleOpenHistory = (fac: CreditFacility) => {
    setSelectedForHistory(fac);
    setHistoryModalOpen(true);
  };

  return (
    <div className="space-y-4">
      {/* Top Action Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
            Credit Audit Register
            <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-blue-100 text-blue-800 dark:bg-blue-950 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
              {facilities.length} Total Accounts
            </span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Statutory & Concurrent Credit Audit portfolio verification, Drawing Power & IRAC review
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant="outline"
            size="sm"
            icon={<Download className="w-4 h-4" />}
            onClick={() => setBulkReportOpen(true)}
          >
            Bulk Export ({filteredFacilities.length})
          </Button>

          {canEdit && (
            <Button
              variant="primary"
              size="sm"
              icon={<Plus className="w-4 h-4" />}
              onClick={handleOpenCreate}
            >
              Add Credit Facility
            </Button>
          )}
        </div>
      </div>

      {/* Filters & Global Search */}
      <FiltersBar />

      {/* Pagination Top Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 shadow-xs text-xs">
        <div className="text-slate-600 dark:text-slate-400">
          Showing <strong className="text-slate-900 dark:text-slate-100">{startEntry}</strong> to{' '}
          <strong className="text-slate-900 dark:text-slate-100">{endEntry}</strong> of{' '}
          <strong className="text-slate-900 dark:text-slate-100">{totalEntries}</strong> entries
          {totalEntries < facilities.length && ` (filtered from ${facilities.length} total)`}
        </div>

        <div className="flex items-center gap-3">
          {/* Page Size Selector */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-500 text-[11px]">Per page:</span>
            <select
              value={pageSize}
              onChange={e => {
                setPageSize(Number(e.target.value));
                setCurrentPage(1);
              }}
              className="text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 py-1 px-2 text-slate-800 dark:text-slate-200 cursor-pointer"
            >
              <option value={15}>15</option>
              <option value={25}>25</option>
              <option value={50}>50</option>
              <option value={100}>100</option>
              <option value={1000}>All ({totalEntries})</option>
            </select>
          </div>

          {/* Page Navigation Buttons */}
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="sm"
              disabled={safePage <= 1}
              onClick={() => setCurrentPage(1)}
              icon={<ChevronsLeft className="w-3.5 h-3.5" />}
              title="First page"
              className="px-2"
            />
            <Button
              variant="outline"
              size="sm"
              disabled={safePage <= 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
              icon={<ChevronLeft className="w-3.5 h-3.5" />}
              className="px-2"
            >
              Prev
            </Button>

            <span className="px-2 font-semibold text-slate-700 dark:text-slate-300">
              Page {safePage} of {totalPages}
            </span>

            <Button
              variant="outline"
              size="sm"
              disabled={safePage >= totalPages}
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
              icon={<ChevronRight className="w-3.5 h-3.5" />}
              iconPosition="right"
              className="px-2"
            >
              Next
            </Button>
            <Button
              variant="ghost"
              size="sm"
              disabled={safePage >= totalPages}
              onClick={() => setCurrentPage(totalPages)}
              icon={<ChevronsRight className="w-3.5 h-3.5" />}
              title="Last page"
              className="px-2"
            />
          </div>
        </div>
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block">
        <CreditTable
          facilities={paginatedFacilities}
          onEdit={handleOpenEdit}
          onOpenDP={handleOpenDP}
          onOpenIRAC={handleOpenIRAC}
          onOpenReport={handleOpenReport}
          onOpenAttachments={handleOpenAttachments}
          onOpenHistory={handleOpenHistory}
          onArchive={archiveFacility}
          onRestore={restoreFacility}
          onToggleReview={toggleReviewStatus}
        />
      </div>

      {/* Mobile Card List View */}
      <div className="block md:hidden">
        <CreditCardView
          facilities={paginatedFacilities}
          onEdit={handleOpenEdit}
          onOpenDP={handleOpenDP}
          onOpenIRAC={handleOpenIRAC}
          onOpenReport={handleOpenReport}
          onOpenAttachments={handleOpenAttachments}
          onOpenHistory={handleOpenHistory}
          onArchive={archiveFacility}
          onRestore={restoreFacility}
          onToggleReview={toggleReviewStatus}
        />
      </div>

      {/* Bottom Pagination Bar */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 shadow-xs text-xs">
          <span className="text-slate-500">
            Showing page {safePage} of {totalPages} ({totalEntries} accounts)
          </span>
          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="sm"
              disabled={safePage <= 1}
              onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              disabled={safePage >= totalPages}
              onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
            >
              Next
            </Button>
          </div>
        </div>
      )}

      {/* Modals */}
      {formOpen && (
        <FacilityFormModal
          isOpen={formOpen}
          onClose={() => setFormOpen(false)}
          facilityToEdit={selectedForEdit}
        />
      )}

      {dpModalOpen && (
        <DPWorksheetModal
          isOpen={dpModalOpen}
          onClose={() => setDpModalOpen(false)}
          facility={selectedForDP}
          onSave={handleSaveDP}
          isReadOnly={isReadOnly}
        />
      )}

      {iracModalOpen && (
        <IRACWorksheetModal
          isOpen={iracModalOpen}
          onClose={() => setIracModalOpen(false)}
          facility={selectedForIRAC}
          onSave={handleSaveIRAC}
          isReadOnly={isReadOnly}
        />
      )}

      {reportModalOpen && (
        <ReportGenerationModal
          isOpen={reportModalOpen}
          onClose={() => setReportModalOpen(false)}
          facility={selectedForReport}
        />
      )}

      {bulkReportOpen && (
        <BulkReportModal
          isOpen={bulkReportOpen}
          onClose={() => setBulkReportOpen(false)}
          facilities={filteredFacilities}
        />
      )}

      {attachModalOpen && (
        <AttachmentManagerModal
          isOpen={attachModalOpen}
          onClose={() => setAttachModalOpen(false)}
          facility={selectedForAttach}
        />
      )}

      {historyModalOpen && (
        <EditHistoryModal
          isOpen={historyModalOpen}
          onClose={() => setHistoryModalOpen(false)}
          facility={selectedForHistory}
          historyEntries={selectedForHistory ? getHistoryForFacility(selectedForHistory.id) : []}
        />
      )}
    </div>
  );
};
