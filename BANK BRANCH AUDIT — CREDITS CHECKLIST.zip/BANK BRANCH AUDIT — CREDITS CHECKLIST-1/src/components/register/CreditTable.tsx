import React from 'react';
import { CreditFacility } from '../../types/audit';
import { DPBadge } from '../dp/DPBadge';
import { IRACBadge } from '../irac/IRACBadge';
import { Badge } from '../common/Badge';
import { Button } from '../common/Button';
import { useAuth } from '../../context/AuthContext';
import { useAudit } from '../../context/AuditContext';
import { 
  Edit, 
  Calculator, 
  FileText, 
  Paperclip, 
  History, 
  Trash2, 
  RotateCcw, 
  CheckCircle2, 
  Clock, 
  ShieldAlert,
  Building2,
  ChevronRight,
  Sparkles,
  Lock,
  Unlock,
  ShieldCheck
} from 'lucide-react';
import clsx from 'clsx';

interface CreditTableProps {
  facilities: CreditFacility[];
  onEdit: (facility: CreditFacility) => void;
  onOpenDP: (facility: CreditFacility) => void;
  onOpenIRAC: (facility: CreditFacility) => void;
  onOpenReport: (facility: CreditFacility) => void;
  onOpenAttachments: (facility: CreditFacility) => void;
  onOpenHistory: (facility: CreditFacility) => void;
  onArchive: (id: string) => void;
  onRestore: (id: string) => void;
  onToggleReview: (id: string) => void;
}

export const CreditTable: React.FC<CreditTableProps> = ({
  facilities,
  onEdit,
  onOpenDP,
  onOpenIRAC,
  onOpenReport,
  onOpenAttachments,
  onOpenHistory,
  onArchive,
  onRestore,
  onToggleReview,
}) => {
  const { canEdit, canReview, isAdmin, canDeleteFacility } = useAuth();
  const { lockFacility, unlockFacility } = useAudit();

  if (facilities.length === 0) {
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-12 text-center space-y-3">
        <Building2 className="w-12 h-12 mx-auto text-slate-300 dark:text-slate-700" />
        <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
          No credit facilities match the active filter criteria
        </h4>
        <p className="text-xs text-slate-400">
          Try adjusting your search keywords, filter selections, or clear all filters.
        </p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs border-collapse">
          <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
            <tr>
              <th className="py-3 px-4">Borrower & Account Details</th>
              <th className="py-3 px-4">Facility Type & Sector</th>
              <th className="py-3 px-4 text-right">Limit / Outstanding</th>
              <th className="py-3 px-4">Drawing Power (DP)</th>
              <th className="py-3 px-4">IRAC Asset Class</th>
              <th className="py-3 px-4 text-right">RBI Provision</th>
              <th className="py-3 px-4 text-center">Security & Lock</th>
              <th className="py-3 px-4 text-center">Review</th>
              <th className="py-3 px-4 text-center">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {facilities.map(fac => {
              const dp = fac.currentDPWorking;
              const irac = fac.currentIRAC;
              const isLocked = fac.isLocked !== false;

              return (
                <tr
                  key={fac.id}
                  className={clsx(
                    'hover:bg-blue-50/40 dark:hover:bg-slate-800/50 transition-colors',
                    fac.isArchived && 'opacity-60 bg-slate-50 dark:bg-slate-950'
                  )}
                >
                  {/* Column 1: Borrower & Account */}
                  <td className="py-3 px-4 max-w-[220px]">
                    <div className="space-y-0.5">
                      <span className="font-bold text-slate-900 dark:text-slate-100 text-sm block truncate" title={fac.borrowerName}>
                        {fac.borrowerName}
                      </span>
                      <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 block">
                        {fac.accountNumber}
                      </span>
                      <div className="flex items-center gap-1.5 pt-1">
                        {fac.isRelatedParty && (
                          <span
                            title={`Section 20 BRA 1949: ${fac.relatedPartyDetails}`}
                            className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-purple-100 text-purple-800 dark:bg-purple-950 dark:text-purple-300 border border-purple-200 dark:border-purple-800"
                          >
                            Sec. 20 Related
                          </span>
                        )}
                        {fac.isNormOverridden && (
                          <span
                            title={`Norms Overridden: ${fac.overrideRemarks}`}
                            className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950 dark:text-rose-300 border border-rose-200 dark:border-rose-800"
                          >
                            Norms Breached
                          </span>
                        )}
                      </div>
                    </div>
                  </td>

                  {/* Column 2: Facility & Sector */}
                  <td className="py-3 px-4">
                    <div className="space-y-0.5">
                      <span className="font-semibold text-slate-800 dark:text-slate-200 block">
                        {fac.facilityType}
                      </span>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 block truncate max-w-[150px]" title={fac.industrySector}>
                        {fac.industrySector}
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        Renewal: {fac.nextRenewalDueDate || 'N/A'}
                      </span>
                    </div>
                  </td>

                  {/* Column 3: Limit / Outstanding */}
                  <td className="py-3 px-4 text-right">
                    <div className="space-y-0.5">
                      <div className="text-slate-900 dark:text-slate-100 font-bold">
                        ₹{(fac.outstandingBalance / 100000).toLocaleString('en-IN', { maximumFractionDigits: 2 })} L
                      </div>
                      <div className="text-[11px] text-slate-500 dark:text-slate-400">
                        Limit: ₹{(fac.totalSanctionedLimit / 100000).toLocaleString('en-IN', { maximumFractionDigits: 2 })} L
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {fac.interestRate}% p.a.
                      </div>
                    </div>
                  </td>

                  {/* Column 4: Drawing Power */}
                  <td className="py-3 px-4">
                    <div className="space-y-1">
                      <DPBadge facility={fac} />
                      {dp && (
                        <div className="text-[11px] font-mono text-slate-600 dark:text-slate-400">
                          DP: ₹{(dp.computedDP / 100000).toFixed(2)} L
                        </div>
                      )}
                    </div>
                  </td>

                  {/* Column 5: IRAC Category */}
                  <td className="py-3 px-4">
                    <div className="space-y-1">
                      <IRACBadge
                        category={irac?.computedCategory || 'Standard'}
                        isNPA={irac?.isNPA}
                        npaDate={irac?.npaDate}
                      />
                    </div>
                  </td>

                  {/* Column 6: Provision Amount */}
                  <td className="py-3 px-4 text-right">
                    <div className="space-y-0.5">
                      <div className="font-bold text-rose-700 dark:text-rose-400">
                        ₹{((irac?.totalProvisionAmount || 0) / 100000).toLocaleString('en-IN', { maximumFractionDigits: 2 })} L
                      </div>
                      <div className="text-[10px] text-slate-400">
                        ({irac?.effectiveProvisionPercent || 0}% eff.)
                      </div>
                    </div>
                  </td>

                  {/* Column 7: Security & Record Lock Status */}
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1">
                      {isLocked ? (
                        <span 
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 border border-slate-200 dark:border-slate-700"
                          title="Saved & Locked audit record (Delete protected)"
                        >
                          <Lock className="w-3 h-3 text-slate-500" />
                          <span>Saved</span>
                        </span>
                      ) : (
                        <span 
                          className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-200 dark:border-amber-800"
                          title="Draft / Revision mode unlocked"
                        >
                          <Unlock className="w-3 h-3 text-amber-500" />
                          <span>Draft</span>
                        </span>
                      )}

                      {/* Admin Quick Lock/Unlock Toggle */}
                      {isAdmin && (
                        <button
                          type="button"
                          onClick={() => {
                            if (isLocked) {
                              const reason = window.prompt('Enter reason for unlocking facility for revision:', 'CA Admin authorized revision');
                              if (reason) unlockFacility(fac.id, reason);
                            } else {
                              lockFacility(fac.id);
                            }
                          }}
                          className="p-1 rounded text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                          title={isLocked ? "Admin: Click to unlock for staff revision" : "Admin: Click to lock and protect record"}
                        >
                          {isLocked ? <Unlock className="w-3 h-3" /> : <Lock className="w-3 h-3" />}
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Column 8: Review Status */}
                  <td className="py-3 px-4 text-center">
                    <button
                      disabled={!canReview}
                      onClick={() => onToggleReview(fac.id)}
                      className={clsx(
                        'inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition-colors',
                        fac.isReviewed
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                          : 'bg-slate-100 text-slate-600 border border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700',
                        canReview ? 'cursor-pointer hover:opacity-80' : 'cursor-default'
                      )}
                      title={fac.isReviewed ? `Reviewed by ${fac.reviewedBy || 'Partner'}` : 'Pending partner review'}
                    >
                      {fac.isReviewed ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Reviewed</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3.5 h-3.5 text-slate-400" />
                          <span>Pending</span>
                        </>
                      )}
                    </button>
                  </td>

                  {/* Column 9: Action Buttons */}
                  <td className="py-3 px-4 text-center">
                    <div className="flex items-center justify-center gap-1">
                      {/* Edit Button */}
                      {canEdit && !fac.isArchived && (
                        <Button
                          variant="ghost"
                          size="sm"
                          icon={<Edit className="w-3.5 h-3.5 text-blue-600" />}
                          onClick={() => onEdit(fac)}
                          title={isLocked && !isAdmin ? "Modify saved record (requires revision justification)" : "Edit facility parameters"}
                        />
                      )}

                      {/* DP Worksheet Button */}
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<Calculator className="w-3.5 h-3.5 text-emerald-600" />}
                        onClick={() => onOpenDP(fac)}
                        title="Open Drawing Power worksheet"
                      />

                      {/* IRAC Worksheet Button */}
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<ShieldAlert className="w-3.5 h-3.5 text-amber-600" />}
                        onClick={() => onOpenIRAC(fac)}
                        title="Open IRAC Provisioning calculation"
                      />

                      {/* Report Generation Button */}
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<FileText className="w-3.5 h-3.5 text-indigo-600" />}
                        onClick={() => onOpenReport(fac)}
                        title="Generate Word (.docx) and PDF report"
                      />

                      {/* Attachments */}
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<Paperclip className="w-3.5 h-3.5 text-slate-500" />}
                        onClick={() => onOpenAttachments(fac)}
                        title="Manage document attachments"
                      />

                      {/* History */}
                      <Button
                        variant="ghost"
                        size="sm"
                        icon={<History className="w-3.5 h-3.5 text-slate-500" />}
                        onClick={() => onOpenHistory(fac)}
                        title="View field-level edit history"
                      />

                      {/* Archive / Delete - STRICT RBAC: Staff CANNOT delete saved records */}
                      {canDeleteFacility(fac) ? (
                        fac.isArchived ? (
                          <Button
                            variant="ghost"
                            size="sm"
                            icon={<RotateCcw className="w-3.5 h-3.5 text-emerald-600" />}
                            onClick={() => onRestore(fac.id)}
                            title="Restore from archive"
                          />
                        ) : (
                          <Button
                            variant="ghost"
                            size="sm"
                            icon={<Trash2 className="w-3.5 h-3.5 text-rose-500" />}
                            onClick={() => {
                              if (window.confirm(`CA ADMIN CONFIRMATION:\nAre you sure you want to delete/archive account ${fac.accountNumber} (${fac.borrowerName})?`)) {
                                onArchive(fac.id);
                              }
                            }}
                            title="CA Admin: Soft delete / Archive account"
                          />
                        )
                      ) : (
                        <span 
                          className="p-1.5 text-slate-300 dark:text-slate-600 cursor-not-allowed"
                          title="🔒 Deletion prohibited for Staff. Only CA Admin is authorized to delete saved records."
                        >
                          <Lock className="w-3.5 h-3.5" />
                        </span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
