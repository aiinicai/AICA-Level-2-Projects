import React from 'react';
import { useAudit, FilterState } from '../../context/AuditContext';
import { FacilityType, IRACCategory, DPStatusBadgeType } from '../../types/audit';
import { Button } from '../common/Button';
import { 
  Search, 
  Filter, 
  RotateCcw, 
  ShieldAlert, 
  Users, 
  Archive, 
  SlidersHorizontal,
  ChevronDown,
  X
} from 'lucide-react';
import clsx from 'clsx';

const FACILITY_OPTIONS: { value: FacilityType | 'ALL'; label: string }[] = [
  { value: 'ALL', label: 'All Facility Types' },
  { value: 'Cash Credit (CC)', label: 'Cash Credit (CC)' },
  { value: 'Overdraft (OD)', label: 'Overdraft (OD)' },
  { value: 'Term Loan (TL)', label: 'Term Loan (TL)' },
  { value: 'Demand Loan (DL)', label: 'Demand Loan (DL)' },
  { value: 'Bill Discounting', label: 'Bill Discounting' },
  { value: 'Bank Guarantee (BG)', label: 'Bank Guarantee (BG)' },
  { value: 'Letter of Credit (LC)', label: 'Letter of Credit (LC)' },
];

const IRAC_OPTIONS: { value: IRACCategory | 'ALL'; label: string }[] = [
  { value: 'ALL', label: 'All IRAC Categories' },
  { value: 'Standard', label: 'Standard (Performing)' },
  { value: 'Sub-Standard', label: 'Sub-Standard (NPA ≤ 12m)' },
  { value: 'Doubtful 1 (D1)', label: 'Doubtful 1 (D1)' },
  { value: 'Doubtful 2 (D2)', label: 'Doubtful 2 (D2)' },
  { value: 'Doubtful 3 (D3)', label: 'Doubtful 3 (D3)' },
  { value: 'Loss', label: 'Loss Asset' },
];

const DP_BADGE_OPTIONS: { value: DPStatusBadgeType | 'ALL'; label: string }[] = [
  { value: 'ALL', label: 'All DP Health Statuses' },
  { value: 'WITHIN_DP_AND_LIMIT', label: 'Within DP & Limit (Green)' },
  { value: 'EXCEEDS_DP_WITHIN_LIMIT', label: 'Exceeds DP within Limit (Amber)' },
  { value: 'EXCEEDS_SANCTION_LIMIT', label: 'Exceeds Limit (Red)' },
  { value: 'STALE_OR_MISSING_STOCK_STATEMENT', label: 'Stale / Missing Statement (Grey)' },
];

export const FiltersBar: React.FC = () => {
  const { filters, setFilters, resetFilters, filteredFacilities, facilities } = useAudit();
  const [showAdvanced, setShowAdvanced] = React.useState(false);

  const activeFilterCount = [
    filters.facilityType !== 'ALL',
    filters.iracCategory !== 'ALL',
    filters.dpBadge !== 'ALL',
    filters.reviewStatus !== 'ALL',
    filters.relatedPartyOnly,
    filters.normsOverriddenOnly,
    filters.showArchived,
  ].filter(Boolean).length;

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xs p-3.5 space-y-3">
      {/* Top Search & Main Quick Filters */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        {/* Global Search Bar */}
        <div className="relative flex-1">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            placeholder="Search by Borrower Name, Account Number, Branch, or Sector..."
            value={filters.searchQuery}
            onChange={e => setFilters(prev => ({ ...prev, searchQuery: e.target.value }))}
            className="w-full text-xs sm:text-sm rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 pl-9 pr-8 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
          {filters.searchQuery && (
            <button
              onClick={() => setFilters(prev => ({ ...prev, searchQuery: '' }))}
              className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {/* Quick Filter Buttons & Advanced Toggle */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar shrink-0">
          <select
            value={filters.facilityType}
            onChange={e => setFilters(prev => ({ ...prev, facilityType: e.target.value as any }))}
            className="text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 py-2 px-2.5 text-slate-800 dark:text-slate-200"
          >
            {FACILITY_OPTIONS.map(opt => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>

          <select
            value={filters.iracCategory}
            onChange={e => setFilters(prev => ({ ...prev, iracCategory: e.target.value as any }))}
            className="text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 py-2 px-2.5 text-slate-800 dark:text-slate-200"
          >
            {IRAC_OPTIONS.map(opt => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>

          <Button
            variant={showAdvanced ? 'secondary' : 'outline'}
            size="sm"
            icon={<SlidersHorizontal className="w-3.5 h-3.5" />}
            onClick={() => setShowAdvanced(prev => !prev)}
            className="relative whitespace-nowrap"
          >
            <span>Filters</span>
            {activeFilterCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center">
                {activeFilterCount}
              </span>
            )}
          </Button>

          {activeFilterCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              icon={<RotateCcw className="w-3.5 h-3.5" />}
              onClick={resetFilters}
              title="Reset all filters"
            />
          )}
        </div>
      </div>

      {/* Advanced Filters Drawer / Panel */}
      {showAdvanced && (
        <div className="pt-3 border-t border-slate-100 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs animate-in fade-in duration-150">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Drawing Power (DP) Status
            </label>
            <select
              value={filters.dpBadge}
              onChange={e => setFilters(prev => ({ ...prev, dpBadge: e.target.value as any }))}
              className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-slate-800 dark:text-slate-200"
            >
              {DP_BADGE_OPTIONS.map(opt => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Engagement Review Status
            </label>
            <select
              value={filters.reviewStatus}
              onChange={e => setFilters(prev => ({ ...prev, reviewStatus: e.target.value as any }))}
              className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-slate-800 dark:text-slate-200"
            >
              <option value="ALL">All Accounts (Reviewed & Pending)</option>
              <option value="REVIEWED">Reviewed by Partner</option>
              <option value="PENDING">Pending Review</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 dark:text-slate-400 mb-1">
              Sort By
            </label>
            <div className="flex gap-1.5">
              <select
                value={filters.sortBy}
                onChange={e => setFilters(prev => ({ ...prev, sortBy: e.target.value as any }))}
                className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 p-2 text-slate-800 dark:text-slate-200"
              >
                <option value="updatedAt">Last Updated</option>
                <option value="borrowerName">Borrower Name</option>
                <option value="accountNumber">Account Number</option>
                <option value="totalSanctionedLimit">Sanctioned Limit</option>
                <option value="outstandingBalance">Outstanding Balance</option>
                <option value="nextRenewalDueDate">Renewal Due Date</option>
              </select>
              <button
                onClick={() => setFilters(prev => ({ ...prev, sortOrder: prev.sortOrder === 'asc' ? 'desc' : 'asc' }))}
                className="px-2.5 py-1.5 border border-slate-300 dark:border-slate-700 rounded-lg text-slate-700 dark:text-slate-300 bg-slate-50 dark:bg-slate-800 font-mono text-xs font-bold"
              >
                {filters.sortOrder === 'asc' ? '↑' : '↓'}
              </button>
            </div>
          </div>

          <div className="flex flex-col justify-end space-y-1.5">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.relatedPartyOnly}
                onChange={e => setFilters(prev => ({ ...prev, relatedPartyOnly: e.target.checked }))}
                className="rounded text-blue-600 focus:ring-blue-500"
              />
              <span className="text-slate-700 dark:text-slate-300 font-medium">
                Section 20 Related Parties Only
              </span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.normsOverriddenOnly}
                onChange={e => setFilters(prev => ({ ...prev, normsOverriddenOnly: e.target.checked }))}
                className="rounded text-rose-600 focus:ring-rose-500"
              />
              <span className="text-rose-700 dark:text-rose-400 font-medium">
                Norms Breaches / Overrides Only
              </span>
            </label>

            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.showArchived}
                onChange={e => setFilters(prev => ({ ...prev, showArchived: e.target.checked }))}
                className="rounded text-slate-600 focus:ring-slate-500"
              />
              <span className="text-slate-500 dark:text-slate-400 font-medium">
                Show Archived (Soft-Deleted) Records
              </span>
            </label>
          </div>
        </div>
      )}

      {/* Results Count & Current Filter Tags */}
      <div className="flex items-center justify-between text-[11px] text-slate-500 dark:text-slate-400 pt-1">
        <span>
          Showing <strong>{filteredFacilities.length}</strong> of <strong>{facilities.length}</strong> facilities
        </span>
        {filters.showArchived && (
          <span className="px-2 py-0.5 bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300 rounded font-semibold">
            Archived Records View
          </span>
        )}
      </div>
    </div>
  );
};
