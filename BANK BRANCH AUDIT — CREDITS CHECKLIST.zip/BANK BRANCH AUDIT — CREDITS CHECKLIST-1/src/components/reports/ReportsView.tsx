import React, { useState } from 'react';
import { useAudit } from '../../context/AuditContext';
import { CreditFacility } from '../../types/audit';
import { ReportGenerationModal } from './ReportGenerationModal';
import { BulkReportModal } from './BulkReportModal';
import { Button } from '../common/Button';
import { FileText, FileSpreadsheet, Download, ShieldCheck, Printer } from 'lucide-react';

export const ReportsView: React.FC = () => {
  const { facilities } = useAudit();
  const [selectedFac, setSelectedFac] = useState<CreditFacility | null>(null);
  const [bulkModalOpen, setBulkModalOpen] = useState(false);

  const active = facilities.filter(f => !f.isArchived);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-slate-900 dark:text-slate-100 tracking-tight flex items-center gap-2">
            <FileText className="w-6 h-6 text-indigo-600" />
            Statutory Audit Reports & Portfolio Exports
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Generate printable Word (.docx), PDF memos with CA signature blocks, and Excel/CSV registers
          </p>
        </div>

        <Button
          variant="primary"
          size="sm"
          icon={<Download className="w-4 h-4" />}
          onClick={() => setBulkModalOpen(true)}
        >
          Bulk Portfolio Export
        </Button>
      </div>

      {/* Facilities Export Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-xs">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
            Individual Account CA Audit Memos ({active.length} Facilities)
          </h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-3 px-4">Borrower Name</th>
                <th className="py-3 px-4">Account Number</th>
                <th className="py-3 px-4">Facility Type</th>
                <th className="py-3 px-4 text-right">Outstanding Balance</th>
                <th className="py-3 px-4">IRAC Category</th>
                <th className="py-3 px-4 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {active.map(fac => (
                <tr key={fac.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50">
                  <td className="py-3 px-4 font-bold text-slate-900 dark:text-slate-100">
                    {fac.borrowerName}
                  </td>
                  <td className="py-3 px-4 font-mono text-slate-500 dark:text-slate-400">
                    {fac.accountNumber}
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    {fac.facilityType}
                  </td>
                  <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-slate-100">
                    ₹{(fac.outstandingBalance / 100000).toFixed(2)} L
                  </td>
                  <td className="py-3 px-4 font-semibold text-slate-800 dark:text-slate-200">
                    {fac.currentIRAC?.computedCategory || 'Standard'}
                  </td>
                  <td className="py-3 px-4 text-center">
                    <Button
                      variant="outline"
                      size="sm"
                      icon={<FileText className="w-3.5 h-3.5 text-indigo-600" />}
                      onClick={() => setSelectedFac(fac)}
                    >
                      Generate Report (.docx / .pdf)
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedFac && (
        <ReportGenerationModal
          isOpen={Boolean(selectedFac)}
          onClose={() => setSelectedFac(null)}
          facility={selectedFac}
        />
      )}

      {bulkModalOpen && (
        <BulkReportModal
          isOpen={bulkModalOpen}
          onClose={() => setBulkModalOpen(false)}
          facilities={active}
        />
      )}
    </div>
  );
};
