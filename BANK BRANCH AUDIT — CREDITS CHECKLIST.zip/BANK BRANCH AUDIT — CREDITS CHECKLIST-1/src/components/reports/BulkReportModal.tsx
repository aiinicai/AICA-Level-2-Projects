import React, { useState } from 'react';
import { CreditFacility } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { generateBulkFacilitiesPDF } from '../../services/pdfReportService';
import { exportFacilitiesToExcel, exportFacilitiesToCSV } from '../../services/exportService';
import { FileSpreadsheet, FileText, Download, CheckSquare } from 'lucide-react';

interface BulkReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  facilities: CreditFacility[];
}

export const BulkReportModal: React.FC<BulkReportModalProps> = ({
  isOpen,
  onClose,
  facilities,
}) => {
  const { auditMetadata } = useAudit();
  const { currentUser } = useAuth();
  const [downloading, setDownloading] = useState(false);

  const activeFacilities = facilities.filter(f => !f.isArchived);

  const handleExportPDF = () => {
    setDownloading(true);
    try {
      const doc = generateBulkFacilitiesPDF(activeFacilities, auditMetadata, currentUser);
      doc.save(`Credit_Audit_Register_Summary_${auditMetadata.branchCode}.pdf`);
    } finally {
      setDownloading(false);
    }
  };

  const handleExportExcel = () => {
    setDownloading(true);
    try {
      exportFacilitiesToExcel(activeFacilities, `Credit_Audit_Register_${auditMetadata.branchCode}.xlsx`);
    } finally {
      setDownloading(false);
    }
  };

  const handleExportCSV = () => {
    setDownloading(true);
    try {
      exportFacilitiesToCSV(activeFacilities, `Credit_Audit_Register_${auditMetadata.branchCode}.csv`);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Bulk Export & Audit Register Generation"
      subtitle={`Export current filtered portfolio (${activeFacilities.length} Credit Accounts)`}
      maxWidth="2xl"
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      <div className="space-y-4">
        <p className="text-xs text-slate-600 dark:text-slate-400">
          Choose a format to export the complete credit register, including all drawing power calculations, IRAC classifications, provisioning numbers, and statutory compliance flags.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {/* Excel Export */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-2 hover:border-emerald-500 transition-colors">
            <div className="p-3 w-fit mx-auto rounded-lg bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">
              Excel (.xlsx)
            </h5>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Full dataset with all 35+ fields formatted.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="w-full text-xs"
              onClick={handleExportExcel}
              icon={<Download className="w-3.5 h-3.5" />}
            >
              Export Excel
            </Button>
          </div>

          {/* PDF Export */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-2 hover:border-red-500 transition-colors">
            <div className="p-3 w-fit mx-auto rounded-lg bg-red-100 dark:bg-red-900/60 text-red-700 dark:text-red-300">
              <FileText className="w-6 h-6" />
            </div>
            <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">
              Combined PDF
            </h5>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Landscape portfolio summary table.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="w-full text-xs"
              onClick={handleExportPDF}
              icon={<Download className="w-3.5 h-3.5" />}
            >
              Export PDF
            </Button>
          </div>

          {/* CSV Export */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-center space-y-2 hover:border-blue-500 transition-colors">
            <div className="p-3 w-fit mx-auto rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <h5 className="text-xs font-bold text-slate-900 dark:text-slate-100">
              CSV Register
            </h5>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Lightweight standard comma-separated text.
            </p>
            <Button
              variant="outline"
              size="sm"
              className="w-full text-xs"
              onClick={handleExportCSV}
              icon={<Download className="w-3.5 h-3.5" />}
            >
              Export CSV
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
