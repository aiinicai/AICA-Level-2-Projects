import React, { useState } from 'react';
import { CreditFacility } from '../../types/audit';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { useAudit } from '../../context/AuditContext';
import { useAuth } from '../../context/AuthContext';
import { generateFacilityWordDocument } from '../../services/docxReportService';
import { generateFacilityPDF } from '../../services/pdfReportService';
import { FileText, Download, CheckCircle2, FileCode, CheckSquare, Shield } from 'lucide-react';

interface ReportGenerationModalProps {
  isOpen: boolean;
  onClose: () => void;
  facility: CreditFacility | null;
}

export const ReportGenerationModal: React.FC<ReportGenerationModalProps> = ({
  isOpen,
  onClose,
  facility,
}) => {
  if (!facility) return null;

  const { auditMetadata } = useAudit();
  const { currentUser } = useAuth();
  const [generatingWord, setGeneratingWord] = useState(false);
  const [generatingPDF, setGeneratingPDF] = useState(false);

  const handleDownloadWord = async () => {
    try {
      setGeneratingWord(true);
      const blob = await generateFacilityWordDocument(facility, auditMetadata, currentUser);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `Credit_Audit_Memo_${facility.accountNumber.replace(/[^a-zA-Z0-9]/g, '_')}.docx`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('Word export error:', e);
      alert('Error generating Word document');
    } finally {
      setGeneratingWord(false);
    }
  };

  const handleDownloadPDF = () => {
    try {
      setGeneratingPDF(true);
      const doc = generateFacilityPDF(facility, auditMetadata, currentUser);
      doc.save(`Credit_Audit_Memo_${facility.accountNumber.replace(/[^a-zA-Z0-9]/g, '_')}.pdf`);
    } catch (e) {
      console.error('PDF export error:', e);
      alert('Error generating PDF document');
    } finally {
      setGeneratingPDF(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Generate Statutory CA Credit Audit Report"
      subtitle={`Account: ${facility.accountNumber} — ${facility.borrowerName}`}
      maxWidth="2xl"
      footer={
        <Button variant="secondary" onClick={onClose}>
          Close
        </Button>
      }
    >
      <div className="space-y-5">
        <div className="p-4 bg-blue-50/70 dark:bg-blue-950/40 rounded-xl border border-blue-200 dark:border-blue-900 text-xs text-blue-950 dark:text-blue-200 space-y-2">
          <div className="flex items-center gap-2 font-bold text-sm text-blue-900 dark:text-blue-100">
            <Shield className="w-4 h-4 text-blue-600" />
            Statutory Bank Audit Checklist Certificate & Memorandum
          </div>
          <p>
            Generates a comprehensive audit certificate including the Borrower Profile, Drawing Power mathematical evaluation, IRAC Asset Classification & Provisioning trace, 9-point Security/Documentation checklist, CA observations, and dual signature blocks.
          </p>
        </div>

        {/* Export Options Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Word Option */}
          <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-blue-500 dark:hover:border-blue-500 transition-all space-y-3">
            <div className="p-3 w-fit rounded-lg bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300">
              <FileCode className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Microsoft Word (.docx)
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Editable formal CA memorandum with table styling, firm headers, and dual signature block.
              </p>
            </div>
            <Button
              variant="primary"
              className="w-full"
              loading={generatingWord}
              icon={<Download className="w-4 h-4" />}
              onClick={handleDownloadWord}
            >
              Download .docx Report
            </Button>
          </div>

          {/* PDF Option */}
          <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-red-500 dark:hover:border-red-500 transition-all space-y-3">
            <div className="p-3 w-fit rounded-lg bg-red-100 dark:bg-red-900/60 text-red-700 dark:text-red-300">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                Printable PDF (.pdf)
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                High-resolution ready-to-print PDF with navy CA header, structured tables, and verification sign-offs.
              </p>
            </div>
            <Button
              variant="danger"
              className="w-full bg-red-600 hover:bg-red-700"
              loading={generatingPDF}
              icon={<Download className="w-4 h-4" />}
              onClick={handleDownloadPDF}
            >
              Download PDF Report
            </Button>
          </div>
        </div>

        {/* Report Content Preview Summary */}
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 space-y-2 text-xs">
          <span className="font-bold text-slate-700 dark:text-slate-300 uppercase tracking-wider text-[10px]">
            Report Sections Included:
          </span>
          <div className="grid grid-cols-2 gap-2 text-slate-600 dark:text-slate-400">
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Borrower & Facility Parameters</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Drawing Power Calculations</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>IRAC Classification & Provision</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>9-Point Checklist Matrix</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Auditor Observations & Notes</span>
            </div>
            <div className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              <span>Dual CA Signature Blocks</span>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};
