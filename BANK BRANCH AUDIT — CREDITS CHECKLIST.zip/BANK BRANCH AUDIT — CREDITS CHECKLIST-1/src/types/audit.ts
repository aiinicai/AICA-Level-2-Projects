export type UserRole = 'admin' | 'staff' | 'reviewer' | 'auditor' | 'read-only';

export interface UserAccount {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  membershipNumber?: string; // CA Membership No.
  designation?: string; // e.g. Partner, Senior Audit Associate, Article Assistant
  phone?: string;
  firmName: string;
  branchAssigned: string;
  avatarUrl?: string;
  isAdmin?: boolean;
}

export type FacilityType = 
  | 'Cash Credit (CC)'
  | 'Overdraft (OD)'
  | 'Term Loan (TL)'
  | 'Demand Loan (DL)'
  | 'Bill Discounting'
  | 'Bank Guarantee (BG)'
  | 'Letter of Credit (LC)';

export type ConstitutionType = 
  | 'Individual / Proprietorship'
  | 'Partnership Firm'
  | 'LLP'
  | 'Private Limited Company'
  | 'Public Limited Company'
  | 'Trust / Society'
  | 'HUF';

export type SectorType = 
  | 'Agriculture & Allied'
  | 'Micro & Small Enterprises (MSE)'
  | 'Medium Enterprises'
  | 'Large Corporates / Infrastructure'
  | 'Commercial Real Estate (CRE)'
  | 'Commercial Real Estate - Residential Housing (CRE-RH)'
  | 'Retail / Housing Loan'
  | 'Services / Trading'
  | 'NBFC';

export type DocumentationStatus = 
  | 'Obtained & Valid'
  | 'Obtained but Expired / Due'
  | 'Obtained - Incomplete/Defective'
  | 'Not Obtained / Pending'
  | 'Not Applicable';

export interface ChecklistItem {
  id: string;
  title: string;
  category: 'Security' | 'Charge' | 'Financial' | 'Statutory' | 'Legal' | 'Insurance';
  status: DocumentationStatus;
  expiryDate?: string;
  documentRef?: string;
  remarks?: string;
}

export interface DPWorking {
  id: string;
  facilityId: string;
  statementDate: string; // YYYY-MM-DD
  stockValue: number;
  creditorsForStock: number;
  unpaidStock: number; // calculated
  marginPercentOnStock: number; // e.g. 25
  netPaidStock: number; // calculated

  bookDebtsTotal: number;
  bookDebtsOverdue: number; // beyond permissible age
  bookDebtsEligible: number; // calculated
  permissibleDebtAgeMonths: number; // e.g. 90 or 180 days (expressed in days or months, standard 90 days)
  marginPercentOnDebtors: number; // e.g. 40
  netEligibleDebtors: number; // calculated

  computedDP: number; // netPaidStock + netEligibleDebtors
  isStale: boolean; // > 90 days from audit date
  remarks?: string;
  updatedAt: string;
}

export type IRACCategory = 
  | 'Standard'
  | 'Sub-Standard'
  | 'Doubtful 1 (D1)'
  | 'Doubtful 2 (D2)'
  | 'Doubtful 3 (D3)'
  | 'Loss';

export interface IRACClassification {
  id: string;
  facilityId: string;
  asOfDate: string; // audit reporting date
  isNPA: boolean;
  npaDate?: string; // YYYY-MM-DD
  monthsElapsedSinceNPA: number;
  computedCategory: IRACCategory;
  isLossManuallyFlagged: boolean;
  
  // Provisioning breakdown
  outstandingBalance: number;
  realizableSecurityPrimary: number;
  realizableSecurityCollateral: number;
  totalRealizableSecurity: number;
  securedPortion: number;
  unsecuredPortion: number;
  
  provisionRateSecuredPercent: number;
  provisionRateUnsecuredPercent: number;
  provisionAmountSecured: number;
  provisionAmountUnsecured: number;
  totalProvisionAmount: number;
  effectiveProvisionPercent: number;
  
  remarks?: string;
  updatedAt: string;
}

export interface AttachmentItem {
  id: string;
  facilityId: string;
  name: string;
  size: number;
  type: string;
  category: 'Stock Statement' | 'Sanction Letter' | 'Search Report' | 'Valuation Report' | 'Insurance Policy' | 'Other';
  uploadedAt: string;
  uploadedBy: string;
  dataUrl?: string; // base64 or storage url
}

export interface EditHistoryEntry {
  id: string;
  facilityId: string;
  field: string;
  oldValue: string;
  newValue: string;
  changedBy: string;
  changedByName: string;
  changedAt: string;
  reason?: string;
}

export interface CreditFacility {
  id: string;
  accountNumber: string; // unique
  borrowerName: string;
  branch: string;
  facilityType: FacilityType;
  constitution: ConstitutionType;
  industrySector: SectorType;
  
  // Sanction & Limits
  sanctionDate: string;
  sanctioningAuthority: string;
  lastRenewalDate: string;
  nextRenewalDueDate: string;
  interestRate: number; // % p.a.
  sanctionedLimitFundBased: number;
  sanctionedLimitNonFundBased: number;
  totalSanctionedLimit: number;
  outstandingBalance: number;
  
  // Securities & Guarantee
  primarySecurity: string;
  collateralSecurity: string;
  realizableValuePrimary: number;
  realizableValueCollateral: number;
  guarantors: string;
  stipulatedMarginPercent: number;
  bankNormMarginPercent: number; // reference norm (e.g. 25%)
  
  // Statutory / Compliance
  isRelatedParty: boolean; // Section 20, Banking Regulation Act 1949
  relatedPartyDetails?: string;
  insuranceDetails: string;
  insuranceExpiryDate: string;
  insuranceAmount: number;
  
  // Norms Override & Approval
  isNormOverridden: boolean;
  overrideRemarks?: string;
  overrideApprovingAuthority?: string;
  
  // Documentation Checklist
  checklist: ChecklistItem[];
  
  // DP & IRAC active state
  currentDPWorking?: DPWorking;
  currentIRAC?: IRACClassification;
  
  // CA Audit Observations & Notes
  additionalNotes: string;
  auditorObservations: string;
  reviewerComments?: string;
  isReviewed: boolean;
  reviewedBy?: string;
  reviewedAt?: string;
  
  // Submission & Lock State (Admin / Staff Role Access)
  isSubmitted?: boolean; // True once saved into credit register
  isLocked?: boolean; // True when locked against unauthorized deletion/modification
  lockedBy?: string;
  lockedAt?: string;
  isAuthorizedForEdit?: boolean; // Admin authorized modification
  revisionReason?: string; // Reason entered when modifying saved record

  // Metadata & Soft Delete
  isArchived: boolean;
  archivedAt?: string;
  archivedBy?: string;
  createdBy: string;
  createdAt: string;
  updatedBy: string;
  updatedAt: string;
}

export interface RBIProvisionRates {
  standardDirectAgri: number; // 0.25%
  standardCRE: number; // 1.00%
  standardCRERH: number; // 0.75%
  standardMSE: number; // 0.25%
  standardGeneralOther: number; // 0.40%
  
  subStandardSecured: number; // 15%
  subStandardUnsecured: number; // 25% (or 20% for infrastructure)
  
  doubtful1Secured: number; // 25%
  doubtful1Unsecured: number; // 100%
  
  doubtful2Secured: number; // 40%
  doubtful2Unsecured: number; // 100%
  
  doubtful3Secured: number; // 100%
  doubtful3Unsecured: number; // 100%
  
  loss: number; // 100%
}

export type DPStatusBadgeType = 
  | 'WITHIN_DP_AND_LIMIT' // Green
  | 'EXCEEDS_DP_WITHIN_LIMIT' // Amber
  | 'EXCEEDS_SANCTION_LIMIT' // Red
  | 'STALE_OR_MISSING_STOCK_STATEMENT'; // Grey / Slate
