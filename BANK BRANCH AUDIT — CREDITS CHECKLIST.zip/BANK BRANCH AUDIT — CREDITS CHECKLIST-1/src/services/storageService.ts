import { 
  CreditFacility, 
  EditHistoryEntry, 
  AttachmentItem, 
  RBIProvisionRates, 
  UserAccount, 
  DPWorking, 
  IRACClassification 
} from '../types/audit';
import { initializeSeedFacilities, generate300Facilities, INITIAL_USERS } from '../data/seedData';
import { DEFAULT_RBI_RATES } from './iracEngine';

const STORAGE_KEYS = {
  FACILITIES: 'bank_audit_credit_facilities_v2',
  IS_INITIALIZED: 'bank_audit_initialized_v2',
  EDIT_HISTORY: 'bank_audit_edit_history_v2',
  ATTACHMENTS: 'bank_audit_attachments_v2',
  RATES: 'bank_audit_rbi_rates_v2',
  ACTIVE_USER: 'bank_audit_active_user_v2',
  USERS: 'bank_audit_users_v2',
  THEME: 'bank_audit_theme_v2',
  DRAFT_FACILITY: 'bank_audit_facility_draft_v2',
  AUDIT_METADATA: 'bank_audit_metadata_v2',
};

// IndexedDB Helper for permanent zero-loss browser storage
const IDB_NAME = 'BankAuditCreditsDB';
const IDB_VERSION = 1;
const IDB_STORE = 'audit_store';

function openIndexedDB(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      resolve(null);
      return;
    }
    try {
      const request = indexedDB.open(IDB_NAME, IDB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains(IDB_STORE)) {
          db.createObjectStore(IDB_STORE, { keyPath: 'key' });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

async function idbSet(key: string, value: any): Promise<void> {
  try {
    const db = await openIndexedDB();
    if (!db) return;
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put({ key, value });
  } catch (e) {
    console.warn('IndexedDB write warning:', e);
  }
}

export interface AuditMetadata {
  bankName: string;
  bankAddress: string;
  branchName: string;
  branchCode: string;
  branchAddress: string;
  auditYear: string;
  auditAsOfDate: string; // e.g. 2026-09-03
  leadAuditor: string;
  membershipNumber: string;
  firmName: string;
  firmFRN: string;
  firmAddress: string;
}

export const DEFAULT_AUDIT_METADATA: AuditMetadata = {
  bankName: 'Nationalized Commercial Bank of India',
  bankAddress: 'Corporate Centre, Nariman Point, Mumbai - 400021',
  branchName: 'Nariman Point Corporate Branch',
  branchCode: '0142',
  branchAddress: 'Ground & 1st Floor, Express Towers, Nariman Point, Mumbai - 400021',
  auditYear: '2026-27',
  auditAsOfDate: '2026-09-03',
  leadAuditor: 'CA. Rajesh Sharma',
  membershipNumber: '054321',
  firmName: 'R. Sharma & Associates, Chartered Accountants',
  firmFRN: '109823W',
  firmAddress: 'Suite 402, Commerce House, Fort, Mumbai - 400001',
};

export class StorageService {
  // Facilities - Guaranteed Permanent Persistence
  static getFacilities(): CreditFacility[] {
    try {
      const isInitialized = localStorage.getItem(STORAGE_KEYS.IS_INITIALIZED);
      const data = localStorage.getItem(STORAGE_KEYS.FACILITIES);
      
      // If initialized and data exists, NEVER reset or overwrite
      if (isInitialized && data) {
        return JSON.parse(data);
      }

      // Check legacy key if migrating
      const legacyData = localStorage.getItem('bank_audit_credit_facilities_v1');
      if (legacyData) {
        try {
          const parsedLegacy = JSON.parse(legacyData);
          if (Array.isArray(parsedLegacy) && parsedLegacy.length > 0) {
            this.saveFacilities(parsedLegacy);
            localStorage.setItem(STORAGE_KEYS.IS_INITIALIZED, 'true');
            return parsedLegacy;
          }
        } catch {}
      }

      // First-time initialize with 300 records
      const seeded = generate300Facilities(DEFAULT_AUDIT_METADATA.auditAsOfDate);
      this.saveFacilities(seeded);
      localStorage.setItem(STORAGE_KEYS.IS_INITIALIZED, 'true');
      return seeded;
    } catch (e) {
      console.error('Error reading facilities:', e);
      return generate300Facilities(DEFAULT_AUDIT_METADATA.auditAsOfDate);
    }
  }

  static saveFacilities(facilities: CreditFacility[]): void {
    try {
      localStorage.setItem(STORAGE_KEYS.FACILITIES, JSON.stringify(facilities));
      localStorage.setItem(STORAGE_KEYS.IS_INITIALIZED, 'true');
      idbSet(STORAGE_KEYS.FACILITIES, facilities);
    } catch (e) {
      console.error('Error saving facilities to localStorage:', e);
    }
  }

  static getFacilityById(id: string): CreditFacility | undefined {
    return this.getFacilities().find(f => f.id === id);
  }

  static saveFacility(
    facility: CreditFacility,
    currentUser: UserAccount,
    changeReason?: string
  ): { facility: CreditFacility; historyEntries: EditHistoryEntry[] } {
    const facilities = this.getFacilities();
    const existingIndex = facilities.findIndex(f => f.id === facility.id);
    const newHistoryEntries: EditHistoryEntry[] = [];
    const timestamp = new Date().toISOString();

    if (existingIndex >= 0) {
      const oldFac = facilities[existingIndex];
      const keysToTrack: (keyof CreditFacility)[] = [
        'borrowerName',
        'accountNumber',
        'facilityType',
        'constitution',
        'industrySector',
        'sanctionDate',
        'sanctioningAuthority',
        'lastRenewalDate',
        'nextRenewalDueDate',
        'interestRate',
        'sanctionedLimitFundBased',
        'sanctionedLimitNonFundBased',
        'totalSanctionedLimit',
        'outstandingBalance',
        'primarySecurity',
        'collateralSecurity',
        'realizableValuePrimary',
        'realizableValueCollateral',
        'stipulatedMarginPercent',
        'isRelatedParty',
        'relatedPartyDetails',
        'insuranceDetails',
        'insuranceExpiryDate',
        'insuranceAmount',
        'isNormOverridden',
        'overrideRemarks',
        'additionalNotes',
        'auditorObservations',
        'isReviewed',
        'isLocked',
        'isSubmitted'
      ];

      keysToTrack.forEach(key => {
        const oldVal = oldFac[key];
        const newVal = facility[key];
        if (JSON.stringify(oldVal) !== JSON.stringify(newVal)) {
          const entry: EditHistoryEntry = {
            id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
            facilityId: facility.id,
            field: String(key),
            oldValue: String(oldVal ?? ''),
            newValue: String(newVal ?? ''),
            changedBy: currentUser.id,
            changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
            changedAt: timestamp,
            reason: changeReason || facility.revisionReason || 'Manual field update',
          };
          newHistoryEntries.push(entry);
        }
      });

      const updatedRecord: CreditFacility = {
        ...facility,
        isSubmitted: true,
        isLocked: facility.isLocked !== undefined ? facility.isLocked : true,
        updatedBy: currentUser.id,
        updatedAt: timestamp,
      };

      facilities[existingIndex] = updatedRecord;
      this.saveFacilities(facilities);
      this.appendEditHistory(newHistoryEntries);
      return { facility: updatedRecord, historyEntries: newHistoryEntries };
    } else {
      const newRecord: CreditFacility = {
        ...facility,
        isSubmitted: true,
        isLocked: true,
        lockedBy: currentUser.name,
        lockedAt: timestamp,
        createdBy: currentUser.id,
        createdAt: timestamp,
        updatedBy: currentUser.id,
        updatedAt: timestamp,
      };

      const createEntry: EditHistoryEntry = {
        id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
        facilityId: newRecord.id,
        field: 'RECORD_CREATED',
        oldValue: '',
        newValue: `Created & Finalized ${newRecord.facilityType} record for ${newRecord.borrowerName} (Limit ₹${(newRecord.totalSanctionedLimit/100000).toFixed(2)}L)`,
        changedBy: currentUser.id,
        changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
        changedAt: timestamp,
        reason: 'New credit facility entered and committed to audit register',
      };
      newHistoryEntries.push(createEntry);

      facilities.unshift(newRecord);
      this.saveFacilities(facilities);
      this.appendEditHistory(newHistoryEntries);
      return { facility: newRecord, historyEntries: newHistoryEntries };
    }
  }

  // Record Locking / Unlocking
  static lockFacility(id: string, currentUser: UserAccount): boolean {
    const facilities = this.getFacilities();
    const target = facilities.find(f => f.id === id);
    if (!target) return false;

    target.isLocked = true;
    target.lockedBy = currentUser.name;
    target.lockedAt = new Date().toISOString();
    target.updatedAt = new Date().toISOString();
    target.updatedBy = currentUser.id;

    this.saveFacilities(facilities);

    const historyEntry: EditHistoryEntry = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      facilityId: id,
      field: 'RECORD_LOCKED',
      oldValue: 'Unlocked / Editable',
      newValue: 'Locked (Saved & Protected)',
      changedBy: currentUser.id,
      changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
      changedAt: new Date().toISOString(),
      reason: 'Audit record locked against modification',
    };
    this.appendEditHistory([historyEntry]);
    return true;
  }

  static unlockFacility(id: string, currentUser: UserAccount, reason: string): boolean {
    const facilities = this.getFacilities();
    const target = facilities.find(f => f.id === id);
    if (!target) return false;

    target.isLocked = false;
    target.isAuthorizedForEdit = true;
    target.updatedAt = new Date().toISOString();
    target.updatedBy = currentUser.id;

    this.saveFacilities(facilities);

    const historyEntry: EditHistoryEntry = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      facilityId: id,
      field: 'RECORD_UNLOCKED',
      oldValue: 'Locked',
      newValue: 'Unlocked for Revision',
      changedBy: currentUser.id,
      changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
      changedAt: new Date().toISOString(),
      reason: reason || 'Admin authorized record modification',
    };
    this.appendEditHistory([historyEntry]);
    return true;
  }

  // Deletion - Admin Only
  static softDeleteFacility(id: string, currentUser: UserAccount): boolean {
    const facilities = this.getFacilities();
    const target = facilities.find(f => f.id === id);
    if (!target) return false;

    target.isArchived = true;
    target.archivedAt = new Date().toISOString();
    target.archivedBy = currentUser.name;
    target.updatedAt = new Date().toISOString();
    target.updatedBy = currentUser.id;

    this.saveFacilities(facilities);

    const historyEntry: EditHistoryEntry = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      facilityId: id,
      field: 'RECORD_ARCHIVED',
      oldValue: 'Active',
      newValue: 'Archived (Soft Deleted)',
      changedBy: currentUser.id,
      changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
      changedAt: new Date().toISOString(),
      reason: 'Archived from active register by authorized CA Admin',
    };
    this.appendEditHistory([historyEntry]);
    return true;
  }

  static restoreFacility(id: string, currentUser: UserAccount): boolean {
    const facilities = this.getFacilities();
    const target = facilities.find(f => f.id === id);
    if (!target) return false;

    target.isArchived = false;
    target.archivedAt = undefined;
    target.archivedBy = undefined;
    target.updatedAt = new Date().toISOString();
    target.updatedBy = currentUser.id;

    this.saveFacilities(facilities);

    const historyEntry: EditHistoryEntry = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      facilityId: id,
      field: 'RECORD_RESTORED',
      oldValue: 'Archived',
      newValue: 'Active',
      changedBy: currentUser.id,
      changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
      changedAt: new Date().toISOString(),
      reason: 'Restored from archive by CA Admin',
    };
    this.appendEditHistory([historyEntry]);
    return true;
  }

  static deleteFacilityPermanent(id: string, currentUser: UserAccount): boolean {
    const facilities = this.getFacilities();
    const filtered = facilities.filter(f => f.id !== id);
    if (filtered.length === facilities.length) return false;

    this.saveFacilities(filtered);

    const historyEntry: EditHistoryEntry = {
      id: 'hist_' + Date.now() + '_' + Math.random().toString(36).substr(2, 5),
      facilityId: id,
      field: 'RECORD_PERMANENTLY_DELETED',
      oldValue: 'Archived / Active',
      newValue: 'DELETED',
      changedBy: currentUser.id,
      changedByName: `${currentUser.name} (${currentUser.role.toUpperCase()})`,
      changedAt: new Date().toISOString(),
      reason: 'Permanently removed from database by CA Admin',
    };
    this.appendEditHistory([historyEntry]);
    return true;
  }

  // Edit History
  static getEditHistory(facilityId?: string): EditHistoryEntry[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.EDIT_HISTORY);
      const all: EditHistoryEntry[] = data ? JSON.parse(data) : [];
      if (facilityId) {
        return all.filter(h => h.facilityId === facilityId);
      }
      return all;
    } catch (e) {
      console.error('Error reading history:', e);
      return [];
    }
  }

  static appendEditHistory(entries: EditHistoryEntry[]): void {
    if (!entries.length) return;
    const all = this.getEditHistory();
    const updated = [...entries, ...all];
    localStorage.setItem(STORAGE_KEYS.EDIT_HISTORY, JSON.stringify(updated));
    idbSet(STORAGE_KEYS.EDIT_HISTORY, updated);
  }

  // Attachments
  static getAttachments(facilityId?: string): AttachmentItem[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ATTACHMENTS);
      const all: AttachmentItem[] = data ? JSON.parse(data) : [];
      if (facilityId) {
        return all.filter(a => a.facilityId === facilityId);
      }
      return all;
    } catch (e) {
      console.error('Error reading attachments:', e);
      return [];
    }
  }

  static saveAttachment(attachment: AttachmentItem): void {
    const all = this.getAttachments();
    all.unshift(attachment);
    localStorage.setItem(STORAGE_KEYS.ATTACHMENTS, JSON.stringify(all));
    idbSet(STORAGE_KEYS.ATTACHMENTS, all);
  }

  static deleteAttachment(id: string): void {
    const all = this.getAttachments().filter(a => a.id !== id);
    localStorage.setItem(STORAGE_KEYS.ATTACHMENTS, JSON.stringify(all));
    idbSet(STORAGE_KEYS.ATTACHMENTS, all);
  }

  // RBI Rates
  static getRBIRates(): RBIProvisionRates {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.RATES);
      return data ? JSON.parse(data) : DEFAULT_RBI_RATES;
    } catch (e) {
      return DEFAULT_RBI_RATES;
    }
  }

  static saveRBIRates(rates: RBIProvisionRates): void {
    localStorage.setItem(STORAGE_KEYS.RATES, JSON.stringify(rates));
    idbSet(STORAGE_KEYS.RATES, rates);
  }

  // Users & Staff Management
  static getUsers(): UserAccount[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.USERS);
      if (data) {
        return JSON.parse(data);
      }
      // Check legacy
      const legacyUsers = localStorage.getItem('bank_audit_users_v1');
      if (legacyUsers) {
        try {
          const parsed = JSON.parse(legacyUsers);
          if (Array.isArray(parsed) && parsed.length > 0) {
            this.saveUsers(parsed);
            return parsed;
          }
        } catch {}
      }
      this.saveUsers(INITIAL_USERS);
      return INITIAL_USERS;
    } catch (e) {
      return INITIAL_USERS;
    }
  }

  static saveUsers(users: UserAccount[]): void {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
    idbSet(STORAGE_KEYS.USERS, users);
  }

  static getActiveUser(): UserAccount {
    try {
      const users = this.getUsers();
      const data = localStorage.getItem(STORAGE_KEYS.ACTIVE_USER);
      if (data) {
        const parsed = JSON.parse(data);
        const match = users.find(u => u.id === parsed.id);
        if (match) return match;
      }
      const initial = users[0] || INITIAL_USERS[0];
      this.setActiveUser(initial);
      return initial;
    } catch (e) {
      return INITIAL_USERS[0];
    }
  }

  static setActiveUser(user: UserAccount): void {
    localStorage.setItem(STORAGE_KEYS.ACTIVE_USER, JSON.stringify(user));
  }

  // Drafts for Autosave
  static saveDraft(draft: Partial<CreditFacility>): void {
    localStorage.setItem(STORAGE_KEYS.DRAFT_FACILITY, JSON.stringify({
      data: draft,
      savedAt: new Date().toISOString()
    }));
  }

  static getDraft(): { data: Partial<CreditFacility>; savedAt: string } | null {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.DRAFT_FACILITY);
      return data ? JSON.parse(data) : null;
    } catch (e) {
      return null;
    }
  }

  static clearDraft(): void {
    localStorage.removeItem(STORAGE_KEYS.DRAFT_FACILITY);
  }

  // Audit Metadata (Bank, Branch, Firm & As-on Date)
  static getAuditMetadata(): AuditMetadata {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.AUDIT_METADATA);
      if (data) {
        return { ...DEFAULT_AUDIT_METADATA, ...JSON.parse(data) };
      }
      const legacyMeta = localStorage.getItem('bank_audit_metadata_v1');
      if (legacyMeta) {
        try {
          const parsed = JSON.parse(legacyMeta);
          return { ...DEFAULT_AUDIT_METADATA, ...parsed };
        } catch {}
      }
      return DEFAULT_AUDIT_METADATA;
    } catch (e) {
      return DEFAULT_AUDIT_METADATA;
    }
  }

  static saveAuditMetadata(meta: AuditMetadata): void {
    localStorage.setItem(STORAGE_KEYS.AUDIT_METADATA, JSON.stringify(meta));
    idbSet(STORAGE_KEYS.AUDIT_METADATA, meta);
  }

  // Export Full Offline Backup (.json)
  static exportBackupJSON(): string {
    const backup = {
      exportTimestamp: new Date().toISOString(),
      version: '2.0.0',
      auditMetadata: this.getAuditMetadata(),
      facilities: this.getFacilities(),
      editHistory: this.getEditHistory(),
      attachments: this.getAttachments(),
      users: this.getUsers(),
      rbiRates: this.getRBIRates(),
    };
    return JSON.stringify(backup, null, 2);
  }

  // Restore Full Offline Backup (.json)
  static restoreBackupJSON(jsonString: string): { success: boolean; message: string; count: number } {
    try {
      const parsed = JSON.parse(jsonString);
      if (!parsed.facilities || !Array.isArray(parsed.facilities)) {
        return { success: false, message: 'Invalid backup file: missing facilities array', count: 0 };
      }

      this.saveFacilities(parsed.facilities);
      if (parsed.auditMetadata) this.saveAuditMetadata(parsed.auditMetadata);
      if (parsed.editHistory && Array.isArray(parsed.editHistory)) {
        localStorage.setItem(STORAGE_KEYS.EDIT_HISTORY, JSON.stringify(parsed.editHistory));
        idbSet(STORAGE_KEYS.EDIT_HISTORY, parsed.editHistory);
      }
      if (parsed.attachments && Array.isArray(parsed.attachments)) {
        localStorage.setItem(STORAGE_KEYS.ATTACHMENTS, JSON.stringify(parsed.attachments));
        idbSet(STORAGE_KEYS.ATTACHMENTS, parsed.attachments);
      }
      if (parsed.users && Array.isArray(parsed.users)) {
        this.saveUsers(parsed.users);
      }
      if (parsed.rbiRates) {
        this.saveRBIRates(parsed.rbiRates);
      }

      localStorage.setItem(STORAGE_KEYS.IS_INITIALIZED, 'true');
      return { success: true, message: 'Backup restored successfully', count: parsed.facilities.length };
    } catch (e: any) {
      return { success: false, message: e.message || 'Error parsing backup JSON', count: 0 };
    }
  }

  // Reset / Re-seed 300 Facilities Data (Admin Only)
  static resetToSeed(asOfDate?: string): void {
    const targetDate = asOfDate || '2026-09-03';
    localStorage.removeItem(STORAGE_KEYS.FACILITIES);
    localStorage.removeItem(STORAGE_KEYS.EDIT_HISTORY);
    localStorage.removeItem(STORAGE_KEYS.ATTACHMENTS);
    localStorage.removeItem(STORAGE_KEYS.RATES);
    localStorage.removeItem(STORAGE_KEYS.DRAFT_FACILITY);
    
    const seeded = generate300Facilities(targetDate);
    this.saveFacilities(seeded);
    this.saveUsers(INITIAL_USERS);
    this.setActiveUser(INITIAL_USERS[0]);
    this.saveRBIRates(DEFAULT_RBI_RATES);
    
    const meta = this.getAuditMetadata();
    meta.auditAsOfDate = targetDate;
    this.saveAuditMetadata(meta);
  }
}
