import { CreditFacility, DPStatusBadgeType, DPWorking } from '../types/audit';

export interface DPComputeInput {
  stockValue: number;
  creditorsForStock: number;
  marginPercentOnStock: number;
  bookDebtsTotal: number;
  bookDebtsOverdue: number;
  permissibleDebtAgeMonths: number;
  marginPercentOnDebtors: number;
  statementDate: string;
  auditDate?: string;
}

export interface DPComputeResult {
  paidStock: number; // Stock - Creditors
  netPaidStock: number; // paidStock * (1 - marginStock%)
  eligibleDebtors: number; // totalDebts - overdueDebts
  netEligibleDebtors: number; // eligibleDebtors * (1 - marginDebtors%)
  computedDP: number; // netPaidStock + netEligibleDebtors
  isStale: boolean; // statementDate older than 90 days
  daysSinceStatement: number;
}

export function computeDrawingPower(input: DPComputeInput): DPComputeResult {
  const stock = Math.max(0, Number(input.stockValue) || 0);
  const creditors = Math.max(0, Number(input.creditorsForStock) || 0);
  const stockMargin = Math.min(100, Math.max(0, Number(input.marginPercentOnStock) || 0));

  const paidStock = Math.max(0, stock - creditors);
  const netPaidStock = Math.round(paidStock * (1 - stockMargin / 100));

  const debtsTotal = Math.max(0, Number(input.bookDebtsTotal) || 0);
  const debtsOverdue = Math.min(debtsTotal, Math.max(0, Number(input.bookDebtsOverdue) || 0));
  const debtorsMargin = Math.min(100, Math.max(0, Number(input.marginPercentOnDebtors) || 0));

  const eligibleDebtors = Math.max(0, debtsTotal - debtsOverdue);
  const netEligibleDebtors = Math.round(eligibleDebtors * (1 - debtorsMargin / 100));

  const computedDP = netPaidStock + netEligibleDebtors;

  // Stale check (90 days)
  let daysSinceStatement = 0;
  let isStale = false;
  if (input.statementDate) {
    const stmtTime = new Date(input.statementDate).getTime();
    const refTime = input.auditDate ? new Date(input.auditDate).getTime() : Date.now();
    if (!isNaN(stmtTime)) {
      daysSinceStatement = Math.max(0, Math.floor((refTime - stmtTime) / (1000 * 60 * 60 * 24)));
      isStale = daysSinceStatement > 90;
    } else {
      isStale = true;
    }
  } else {
    isStale = true;
  }

  return {
    paidStock,
    netPaidStock,
    eligibleDebtors,
    netEligibleDebtors,
    computedDP,
    isStale,
    daysSinceStatement
  };
}

export function evaluateDPStatusBadge(
  facility: CreditFacility,
  auditDate?: string
): {
  badge: DPStatusBadgeType;
  label: string;
  colorClass: string;
  bgClass: string;
  borderClass: string;
  description: string;
} {
  const isWorkingCapital = facility.facilityType === 'Cash Credit (CC)' || facility.facilityType === 'Overdraft (OD)';

  if (!isWorkingCapital) {
    // For non-WC facilities (e.g. Term Loans, BGs)
    if (facility.outstandingBalance > facility.totalSanctionedLimit) {
      return {
        badge: 'EXCEEDS_SANCTION_LIMIT',
        label: 'Exceeds Sanctioned Limit',
        colorClass: 'text-red-700 dark:text-red-400',
        bgClass: 'bg-red-50 dark:bg-red-950/50',
        borderClass: 'border-red-300 dark:border-red-800',
        description: `Outstanding ₹${facility.outstandingBalance.toLocaleString('en-IN')} exceeds Limit ₹${facility.totalSanctionedLimit.toLocaleString('en-IN')}`
      };
    }
    return {
      badge: 'WITHIN_DP_AND_LIMIT',
      label: 'Within Limit (TL/NFB)',
      colorClass: 'text-emerald-700 dark:text-emerald-400',
      bgClass: 'bg-emerald-50 dark:bg-emerald-950/50',
      borderClass: 'border-emerald-300 dark:border-emerald-800',
      description: 'Term/Non-fund based facility within sanctioned limit.'
    };
  }

  const dp = facility.currentDPWorking;
  if (!dp || !dp.statementDate) {
    return {
      badge: 'STALE_OR_MISSING_STOCK_STATEMENT',
      label: 'Missing Stock Statement',
      colorClass: 'text-slate-700 dark:text-slate-300',
      bgClass: 'bg-slate-100 dark:bg-slate-800',
      borderClass: 'border-slate-300 dark:border-slate-700',
      description: 'No current stock statement on record to compute DP.'
    };
  }

  const refTime = auditDate ? new Date(auditDate).getTime() : Date.now();
  const stmtTime = new Date(dp.statementDate).getTime();
  const daysDiff = isNaN(stmtTime) ? 999 : Math.floor((refTime - stmtTime) / (1000 * 60 * 60 * 24));

  if (daysDiff > 90) {
    return {
      badge: 'STALE_OR_MISSING_STOCK_STATEMENT',
      label: `Stale Statement (${daysDiff} days old)`,
      colorClass: 'text-amber-800 dark:text-amber-300',
      bgClass: 'bg-amber-50 dark:bg-amber-950/50',
      borderClass: 'border-amber-300 dark:border-amber-800',
      description: `Stock statement dated ${dp.statementDate} is >90 days old (overdue for review).`
    };
  }

  if (facility.outstandingBalance > facility.totalSanctionedLimit) {
    return {
      badge: 'EXCEEDS_SANCTION_LIMIT',
      label: 'Exceeds Sanctioned Limit',
      colorClass: 'text-red-700 dark:text-red-400',
      bgClass: 'bg-red-50 dark:bg-red-950/50',
      borderClass: 'border-red-300 dark:border-red-800',
      description: `Outstanding (₹${facility.outstandingBalance.toLocaleString('en-IN')}) exceeds Sanctioned Limit (₹${facility.totalSanctionedLimit.toLocaleString('en-IN')})`
    };
  }

  if (facility.outstandingBalance > dp.computedDP) {
    const excess = facility.outstandingBalance - dp.computedDP;
    return {
      badge: 'EXCEEDS_DP_WITHIN_LIMIT',
      label: 'Exceeds DP (Within Limit)',
      colorClass: 'text-amber-700 dark:text-amber-400',
      bgClass: 'bg-amber-50 dark:bg-amber-950/50',
      borderClass: 'border-amber-300 dark:border-amber-800',
      description: `Irregularity: Outstanding exceeds DP by ₹${excess.toLocaleString('en-IN')} (DP: ₹${dp.computedDP.toLocaleString('en-IN')})`
    };
  }

  return {
    badge: 'WITHIN_DP_AND_LIMIT',
    label: 'Within DP & Limit',
    colorClass: 'text-emerald-700 dark:text-emerald-400',
    bgClass: 'bg-emerald-50 dark:bg-emerald-950/50',
    borderClass: 'border-emerald-300 dark:border-emerald-800',
    description: `Healthy: Outstanding within DP (₹${dp.computedDP.toLocaleString('en-IN')}) and Limit (₹${facility.totalSanctionedLimit.toLocaleString('en-IN')})`
  };
}

export interface NormOverrideCheck {
  isOverridden: boolean;
  reasons: string[];
  requiresRemarks: boolean;
}

export function checkBankingNormsOverride(facility: Partial<CreditFacility>): NormOverrideCheck {
  const reasons: string[] = [];

  // 1. Margin stipulated below bank's stated norm
  const stipulated = Number(facility.stipulatedMarginPercent) || 0;
  const bankNorm = Number(facility.bankNormMarginPercent) || 25; // default benchmark 25%
  if (stipulated < bankNorm && stipulated > 0) {
    reasons.push(`Stipulated margin (${stipulated}%) is below bank norm (${bankNorm}%).`);
  }

  // 2. Section 20 of Banking Regulation Act 1949: Credit to Directors / Related Parties
  if (facility.isRelatedParty) {
    reasons.push('Related party facility to Director/Relative under Section 20 of Banking Regulation Act 1949.');
  }

  // 3. Security cover inadequacy vs Sanctioned Limit
  const totalSecurity = (Number(facility.realizableValuePrimary) || 0) + (Number(facility.realizableValueCollateral) || 0);
  const sanctioned = Number(facility.totalSanctionedLimit) || 0;
  if (sanctioned > 0 && totalSecurity < sanctioned * 0.85) {
    const coverage = Math.round((totalSecurity / sanctioned) * 100);
    reasons.push(`Security cover appears inadequate: Realizable security (₹${totalSecurity.toLocaleString('en-IN')}) covers only ${coverage}% of sanctioned limit (₹${sanctioned.toLocaleString('en-IN')}).`);
  }

  return {
    isOverridden: reasons.length > 0 || Boolean(facility.isNormOverridden),
    reasons,
    requiresRemarks: reasons.length > 0
  };
}
