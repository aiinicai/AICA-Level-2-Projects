import * as XLSX from 'xlsx';
import { CreditFacility } from '../types/audit';
import { evaluateDPStatusBadge } from './dpEngine';

export function exportFacilitiesToExcel(facilities: CreditFacility[], filename = 'Credit_Audit_Register.xlsx') {
  const rows = facilities.map((fac, idx) => {
    const dpStatus = evaluateDPStatusBadge(fac);
    const dp = fac.currentDPWorking;
    const irac = fac.currentIRAC;

    return {
      'Sr No.': idx + 1,
      'Account Number': fac.accountNumber,
      'Borrower Name': fac.borrowerName,
      'Branch': fac.branch,
      'Facility Type': fac.facilityType,
      'Constitution': fac.constitution,
      'Sector / Industry': fac.industrySector,
      'Sanction Date': fac.sanctionDate,
      'Sanctioning Authority': fac.sanctioningAuthority,
      'Last Renewal Date': fac.lastRenewalDate,
      'Next Renewal Due Date': fac.nextRenewalDueDate,
      'Interest Rate (% p.a.)': fac.interestRate,
      'Sanctioned Limit (Fund Based) (₹)': fac.sanctionedLimitFundBased,
      'Sanctioned Limit (Non-Fund) (₹)': fac.sanctionedLimitNonFundBased,
      'Total Sanctioned Limit (₹)': fac.totalSanctionedLimit,
      'Outstanding Balance (₹)': fac.outstandingBalance,
      'Drawing Power (₹)': dp?.computedDP ?? 'N/A',
      'DP Status': dpStatus.label,
      'Stock Statement Date': dp?.statementDate ?? 'N/A',
      'IRAC Asset Classification': irac?.computedCategory ?? 'Standard',
      'NPA Date': irac?.npaDate ?? 'N/A',
      'Realizable Security Primary (₹)': fac.realizableValuePrimary,
      'Realizable Security Collateral (₹)': fac.realizableValueCollateral,
      'Total Realizable Security (₹)': (fac.realizableValuePrimary || 0) + (fac.realizableValueCollateral || 0),
      'Secured Portion (₹)': irac?.securedPortion ?? 0,
      'Unsecured Portion (₹)': irac?.unsecuredPortion ?? 0,
      'Total Provision Required (₹)': irac?.totalProvisionAmount ?? 0,
      'Effective Provision Rate (%)': irac?.effectiveProvisionPercent ?? 0,
      'Related Party Flag (Sec. 20 BRA)': fac.isRelatedParty ? 'YES' : 'NO',
      'Related Party Details': fac.relatedPartyDetails || '',
      'Norms Overridden Flag': fac.isNormOverridden ? 'YES' : 'NO',
      'Norms Override Remarks': fac.overrideRemarks || '',
      'Insurance Expiry Date': fac.insuranceExpiryDate,
      'Insurance Sum Insured (₹)': fac.insuranceAmount,
      'Auditor Observations': fac.auditorObservations,
      'Additional Notes': fac.additionalNotes,
      'Review Status': fac.isReviewed ? 'Reviewed' : 'Pending Review',
      'Reviewed By': fac.reviewedBy || '',
      'Record Created At': fac.createdAt,
      'Last Updated At': fac.updatedAt,
    };
  });

  const worksheet = XLSX.utils.json_to_sheet(rows);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, 'Credit Register');

  // Auto column widths
  const maxProps = Object.keys(rows[0] || {});
  worksheet['!cols'] = maxProps.map(key => ({ wch: Math.max(key.length, 14) }));

  XLSX.writeFile(workbook, filename);
}

export function exportFacilitiesToCSV(facilities: CreditFacility[], filename = 'Credit_Audit_Register.csv') {
  const rows = facilities.map((fac, idx) => {
    const dpStatus = evaluateDPStatusBadge(fac);
    const irac = fac.currentIRAC;

    return {
      'Sr_No': idx + 1,
      'Account_Number': `"${fac.accountNumber}"`,
      'Borrower_Name': `"${fac.borrowerName.replace(/"/g, '""')}"`,
      'Facility_Type': `"${fac.facilityType}"`,
      'Sector': `"${fac.industrySector}"`,
      'Sanctioned_Limit_INR': fac.totalSanctionedLimit,
      'Outstanding_Balance_INR': fac.outstandingBalance,
      'Drawing_Power_INR': fac.currentDPWorking?.computedDP ?? 0,
      'DP_Status': `"${dpStatus.label}"`,
      'IRAC_Category': `"${irac?.computedCategory ?? 'Standard'}"`,
      'Provision_Required_INR': irac?.totalProvisionAmount ?? 0,
      'Related_Party_Sec20': fac.isRelatedParty ? 'YES' : 'NO',
      'Next_Renewal_Due': fac.nextRenewalDueDate,
      'Insurance_Expiry': fac.insuranceExpiryDate,
      'Review_Status': fac.isReviewed ? 'Reviewed' : 'Pending',
    };
  });

  if (!rows.length) return;

  const headers = Object.keys(rows[0]).join(',');
  const csvContent = [
    headers,
    ...rows.map(row => Object.values(row).join(','))
  ].join('\n');

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
