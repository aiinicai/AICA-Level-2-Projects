import { 
  CreditFacility, 
  IRACCategory, 
  IRACClassification, 
  RBIProvisionRates, 
  SectorType 
} from '../types/audit';

export const DEFAULT_RBI_RATES: RBIProvisionRates = {
  standardDirectAgri: 0.25,
  standardCRE: 1.00,
  standardCRERH: 0.75,
  standardMSE: 0.25,
  standardGeneralOther: 0.40,
  subStandardSecured: 15.0,
  subStandardUnsecured: 25.0,
  doubtful1Secured: 25.0,
  doubtful1Unsecured: 100.0,
  doubtful2Secured: 40.0,
  doubtful2Unsecured: 100.0,
  doubtful3Secured: 100.0,
  doubtful3Unsecured: 100.0,
  loss: 100.0,
};

export interface IRACComputeInput {
  isNPA: boolean;
  npaDate?: string;
  isLossFlagged?: boolean;
  outstandingBalance: number;
  realizableSecurityPrimary: number;
  realizableSecurityCollateral: number;
  sector: SectorType;
  asOfDate?: string; // default today
  customRates?: RBIProvisionRates;
}

export interface IRACStepDetail {
  stepNumber: number;
  title: string;
  formula: string;
  computation: string;
  result: string;
}

export interface IRACComputeResult {
  category: IRACCategory;
  monthsElapsedSinceNPA: number;
  daysElapsedSinceNPA: number;
  totalRealizableSecurity: number;
  securedPortion: number;
  unsecuredPortion: number;
  rateSecured: number;
  rateUnsecured: number;
  provisionSecured: number;
  provisionUnsecured: number;
  totalProvision: number;
  effectiveRatePercent: number;
  stepTrace: IRACStepDetail[];
}

export function computeIRACClassification(input: IRACComputeInput): IRACComputeResult {
  const rates = input.customRates || DEFAULT_RBI_RATES;
  const outstanding = Math.max(0, Number(input.outstandingBalance) || 0);
  const primarySec = Math.max(0, Number(input.realizableSecurityPrimary) || 0);
  const collateralSec = Math.max(0, Number(input.realizableSecurityCollateral) || 0);
  const totalSecurity = primarySec + collateralSec;

  const securedPortion = Math.min(outstanding, totalSecurity);
  const unsecuredPortion = Math.max(0, outstanding - totalSecurity);

  const asOfTime = input.asOfDate ? new Date(input.asOfDate).getTime() : Date.now();
  let daysElapsed = 0;
  let monthsElapsed = 0;

  let category: IRACCategory = 'Standard';

  if (input.isLossFlagged) {
    category = 'Loss';
  } else if (input.isNPA && input.npaDate) {
    const npaTime = new Date(input.npaDate).getTime();
    if (!isNaN(npaTime) && asOfTime >= npaTime) {
      daysElapsed = Math.floor((asOfTime - npaTime) / (1000 * 60 * 60 * 24));
      monthsElapsed = Number((daysElapsed / 30.4375).toFixed(1)); // average month length
      
      if (monthsElapsed <= 12) {
        category = 'Sub-Standard';
      } else if (monthsElapsed <= 24) {
        category = 'Doubtful 1 (D1)';
      } else if (monthsElapsed <= 48) {
        category = 'Doubtful 2 (D2)';
      } else {
        category = 'Doubtful 3 (D3)';
      }
    } else {
      category = 'Sub-Standard'; // fallback if NPA marked without past date
    }
  } else {
    category = 'Standard';
  }

  // Determine standard rate based on sector
  let standardRate = rates.standardGeneralOther;
  if (input.sector === 'Agriculture & Allied') {
    standardRate = rates.standardDirectAgri;
  } else if (input.sector === 'Micro & Small Enterprises (MSE)') {
    standardRate = rates.standardMSE;
  } else if (input.sector === 'Commercial Real Estate (CRE)') {
    standardRate = rates.standardCRE;
  } else if (input.sector === 'Commercial Real Estate - Residential Housing (CRE-RH)') {
    standardRate = rates.standardCRERH;
  }

  let rateSecured = 0;
  let rateUnsecured = 0;
  let provisionSecured = 0;
  let provisionUnsecured = 0;

  switch (category) {
    case 'Standard':
      rateSecured = standardRate;
      rateUnsecured = standardRate;
      provisionSecured = Math.round((outstanding * standardRate) / 100);
      provisionUnsecured = 0;
      break;

    case 'Sub-Standard':
      rateSecured = rates.subStandardSecured;
      rateUnsecured = rates.subStandardUnsecured;
      provisionSecured = Math.round((securedPortion * rates.subStandardSecured) / 100);
      provisionUnsecured = Math.round((unsecuredPortion * rates.subStandardUnsecured) / 100);
      break;

    case 'Doubtful 1 (D1)':
      rateSecured = rates.doubtful1Secured;
      rateUnsecured = rates.doubtful1Unsecured;
      provisionSecured = Math.round((securedPortion * rates.doubtful1Secured) / 100);
      provisionUnsecured = Math.round((unsecuredPortion * rates.doubtful1Unsecured) / 100);
      break;

    case 'Doubtful 2 (D2)':
      rateSecured = rates.doubtful2Secured;
      rateUnsecured = rates.doubtful2Unsecured;
      provisionSecured = Math.round((securedPortion * rates.doubtful2Secured) / 100);
      provisionUnsecured = Math.round((unsecuredPortion * rates.doubtful2Unsecured) / 100);
      break;

    case 'Doubtful 3 (D3)':
      rateSecured = rates.doubtful3Secured;
      rateUnsecured = rates.doubtful3Unsecured;
      provisionSecured = Math.round((securedPortion * rates.doubtful3Secured) / 100);
      provisionUnsecured = Math.round((unsecuredPortion * rates.doubtful3Unsecured) / 100);
      break;

    case 'Loss':
      rateSecured = rates.loss;
      rateUnsecured = rates.loss;
      provisionSecured = Math.round((outstanding * rates.loss) / 100);
      provisionUnsecured = 0;
      break;
  }

  const totalProvision = category === 'Standard' || category === 'Loss'
    ? provisionSecured
    : (provisionSecured + provisionUnsecured);

  const effectiveRatePercent = outstanding > 0
    ? Number(((totalProvision / outstanding) * 100).toFixed(2))
    : 0;

  // Step-by-step mathematical working trace for auditor verification & report annexure
  const stepTrace: IRACStepDetail[] = [
    {
      stepNumber: 1,
      title: 'Classification Rule Evaluation',
      formula: input.isNPA ? 'Months since NPA = (Audit Date - NPA Date) / 30.4' : 'Standard asset not overdue beyond 90 days',
      computation: input.isNPA 
        ? `${daysElapsed} days elapsed (${monthsElapsed} months since ${input.npaDate || 'NPA'})` 
        : `Regular servicing of dues in sector "${input.sector}"`,
      result: `Asset Category: ${category}`
    },
    {
      stepNumber: 2,
      title: 'Security Valuation & Exposure Splitting',
      formula: 'Secured = Min(Outstanding, Total Security); Unsecured = Outstanding - Secured',
      computation: `Total Realizable Sec = ₹${primarySec.toLocaleString('en-IN')} (Primary) + ₹${collateralSec.toLocaleString('en-IN')} (Collateral) = ₹${totalSecurity.toLocaleString('en-IN')}`,
      result: `Secured: ₹${securedPortion.toLocaleString('en-IN')} | Unsecured: ₹${unsecuredPortion.toLocaleString('en-IN')}`
    },
    {
      stepNumber: 3,
      title: 'RBI Provisioning Rate Application',
      formula: category === 'Standard' 
        ? `Standard sector rate (${standardRate}%)`
        : category === 'Loss' 
        ? 'Loss asset flat 100%' 
        : `Secured (${rateSecured}%) + Unsecured (${rateUnsecured}%)`,
      computation: category === 'Standard' || category === 'Loss'
        ? `₹${outstanding.toLocaleString('en-IN')} × ${rateSecured}%`
        : `(₹${securedPortion.toLocaleString('en-IN')} × ${rateSecured}%) + (₹${unsecuredPortion.toLocaleString('en-IN')} × ${rateUnsecured}%)`,
      result: `Total Provision: ₹${totalProvision.toLocaleString('en-IN')} (${effectiveRatePercent}% effective)`
    }
  ];

  return {
    category,
    monthsElapsedSinceNPA: monthsElapsed,
    daysElapsedSinceNPA: daysElapsed,
    totalRealizableSecurity: totalSecurity,
    securedPortion,
    unsecuredPortion,
    rateSecured,
    rateUnsecured,
    provisionSecured,
    provisionUnsecured,
    totalProvision,
    effectiveRatePercent,
    stepTrace
  };
}

export function getIRACBadgeTheme(category: IRACCategory): {
  color: string;
  bg: string;
  border: string;
  dot: string;
} {
  switch (category) {
    case 'Standard':
      return {
        color: 'text-emerald-700 dark:text-emerald-300',
        bg: 'bg-emerald-50 dark:bg-emerald-950/60',
        border: 'border-emerald-200 dark:border-emerald-800',
        dot: 'bg-emerald-500'
      };
    case 'Sub-Standard':
      return {
        color: 'text-amber-700 dark:text-amber-300',
        bg: 'bg-amber-50 dark:bg-amber-950/60',
        border: 'border-amber-200 dark:border-amber-800',
        dot: 'bg-amber-500'
      };
    case 'Doubtful 1 (D1)':
      return {
        color: 'text-orange-700 dark:text-orange-300',
        bg: 'bg-orange-50 dark:bg-orange-950/60',
        border: 'border-orange-200 dark:border-orange-800',
        dot: 'bg-orange-500'
      };
    case 'Doubtful 2 (D2)':
      return {
        color: 'text-rose-700 dark:text-rose-300',
        bg: 'bg-rose-50 dark:bg-rose-950/60',
        border: 'border-rose-200 dark:border-rose-800',
        dot: 'bg-rose-500'
      };
    case 'Doubtful 3 (D3)':
      return {
        color: 'text-red-800 dark:text-red-300',
        bg: 'bg-red-50 dark:bg-red-950/60',
        border: 'border-red-300 dark:border-red-800',
        dot: 'bg-red-600'
      };
    case 'Loss':
      return {
        color: 'text-purple-800 dark:text-purple-300',
        bg: 'bg-purple-50 dark:bg-purple-950/60',
        border: 'border-purple-300 dark:border-purple-800',
        dot: 'bg-purple-600'
      };
  }
}
