import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { CreditFacility, UserAccount } from '../types/audit';
import { AuditMetadata } from './storageService';
import { evaluateDPStatusBadge } from './dpEngine';

export function generateFacilityPDF(
  facility: CreditFacility,
  metadata: AuditMetadata,
  currentUser: UserAccount
): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const dpStatus = evaluateDPStatusBadge(facility, metadata.auditAsOfDate);
  const dp = facility.currentDPWorking;
  const irac = facility.currentIRAC;

  // Header Banner
  doc.setFillColor(30, 58, 138); // Navy 900
  doc.rect(0, 0, 210, 26, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(metadata.firmName.toUpperCase(), 14, 8);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`FRN: ${metadata.firmFRN} | Address: ${metadata.firmAddress || 'Chartered Accountants'}`, 14, 13);
  doc.text(`Bank: ${metadata.bankName} | Branch: ${metadata.branchName} (${metadata.branchCode})`, 14, 18);
  doc.text(`Branch Address: ${metadata.branchAddress || 'Branch Premises'} | Audit As-on Date: ${metadata.auditAsOfDate}`, 14, 23);

  let currentY = 34;

  // Facility Title
  doc.setTextColor(17, 24, 39);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`CREDIT FACILITY AUDIT MEMORANDUM: ${facility.borrowerName.toUpperCase()}`, 14, currentY);
  currentY += 5;

  doc.setFontSize(9);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(75, 85, 99);
  doc.text(`Account No: ${facility.accountNumber} | Facility: ${facility.facilityType} | Sector: ${facility.industrySector}`, 14, currentY);
  currentY += 5;

  // Table 1: Sanction & Limit Matrix
  autoTable(doc, {
    startY: currentY,
    head: [['Facility Parameters', 'Sanctioned & Operational Terms']],
    body: [
      ['Sanction Date & Authority', `${facility.sanctionDate} | ${facility.sanctioningAuthority}`],
      ['Renewal Status', `Last: ${facility.lastRenewalDate || 'N/A'} | Next Due: ${facility.nextRenewalDueDate || 'N/A'}`],
      ['Interest Rate / Pricing', `${facility.interestRate}% p.a.`],
      ['Sanctioned Limit (Fund / Non-Fund)', `Fund: Rs. ${facility.sanctionedLimitFundBased.toLocaleString('en-IN')} | NFB: Rs. ${facility.sanctionedLimitNonFundBased.toLocaleString('en-IN')} (Total: Rs. ${facility.totalSanctionedLimit.toLocaleString('en-IN')})`],
      ['Outstanding Balance', `Rs. ${facility.outstandingBalance.toLocaleString('en-IN')}`],
      ['Primary & Collateral Security', `Primary: ${facility.primarySecurity}\nCollateral: ${facility.collateralSecurity}`],
      ['Realizable Security Valuation', `Primary: Rs. ${(facility.realizableValuePrimary || 0).toLocaleString('en-IN')} | Collateral: Rs. ${(facility.realizableValueCollateral || 0).toLocaleString('en-IN')}`],
      ['Guarantor(s) & Net Worth', facility.guarantors || 'None stated'],
      ['Section 20 BRA 1949 (Related Party)', facility.isRelatedParty ? `YES - ${facility.relatedPartyDetails}` : 'NO (Independent)'],
      ['Insurance Policy & Expiry', `${facility.insuranceDetails} (Exp: ${facility.insuranceExpiryDate || 'N/A'}, Cover: Rs. ${(facility.insuranceAmount || 0).toLocaleString('en-IN')})`]
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 138], textColor: 255, fontStyle: 'bold', fontSize: 8.5 },
    bodyStyles: { fontSize: 8, cellPadding: 2 },
    columnStyles: { 0: { cellWidth: 55, fontStyle: 'bold' }, 1: { cellWidth: 125 } },
    margin: { left: 14, right: 14 },
  });

  currentY = (doc as any).lastAutoTable.finalY + 6;

  // Table 2: Drawing Power & IRAC Summary side-by-side or stacked
  autoTable(doc, {
    startY: currentY,
    head: [['Drawing Power (DP) Working', 'IRAC Asset Classification & Provisioning']],
    body: [
      [
        `Statement Date: ${dp?.statementDate || 'N/A'}\n` +
        `Paid Stock Value: Rs. ${(dp?.netPaidStock || 0).toLocaleString('en-IN')} (Margin: ${dp?.marginPercentOnStock || facility.stipulatedMarginPercent}%)\n` +
        `Eligible Debtors: Rs. ${(dp?.netEligibleDebtors || 0).toLocaleString('en-IN')} (Margin: ${dp?.marginPercentOnDebtors || 40}%)\n` +
        `Computed DP: Rs. ${(dp?.computedDP || 0).toLocaleString('en-IN')}\n` +
        `DP Status: ${dpStatus.label}`,
        `Asset Category: ${irac?.computedCategory || 'Standard'} ${irac?.isNPA ? `(NPA: ${irac.npaDate})` : ''}\n` +
        `Total Security: Rs. ${(irac?.totalRealizableSecurity || 0).toLocaleString('en-IN')}\n` +
        `Secured: Rs. ${(irac?.securedPortion || 0).toLocaleString('en-IN')} @ ${irac?.provisionRateSecuredPercent || 0}%\n` +
        `Unsecured: Rs. ${(irac?.unsecuredPortion || 0).toLocaleString('en-IN')} @ ${irac?.provisionRateUnsecuredPercent || 0}%\n` +
        `Total Provision: Rs. ${(irac?.totalProvisionAmount || 0).toLocaleString('en-IN')} (${irac?.effectiveProvisionPercent || 0}%)`
      ]
    ],
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 138], textColor: 255, fontStyle: 'bold', fontSize: 8.5 },
    bodyStyles: { fontSize: 8, cellPadding: 3 },
    columnStyles: { 0: { cellWidth: 90 }, 1: { cellWidth: 90 } },
    margin: { left: 14, right: 14 },
  });

  currentY = (doc as any).lastAutoTable.finalY + 6;

  // Table 3: Documentation Checklist Table
  autoTable(doc, {
    startY: currentY,
    head: [['Sr.', 'Documentation Checklist Item', 'Category', 'Status', 'Expiry / Ref']],
    body: facility.checklist.map((chk, idx) => [
      String(idx + 1),
      chk.title,
      chk.category,
      chk.status,
      `${chk.expiryDate || 'N/A'}${chk.documentRef ? ` (${chk.documentRef})` : ''}`
    ]),
    theme: 'striped',
    headStyles: { fillColor: [51, 65, 85], textColor: 255, fontStyle: 'bold', fontSize: 8 },
    bodyStyles: { fontSize: 7.5, cellPadding: 1.5 },
    columnStyles: {
      0: { cellWidth: 10, halign: 'center' },
      1: { cellWidth: 70 },
      2: { cellWidth: 25 },
      3: { cellWidth: 40 },
      4: { cellWidth: 35 }
    },
    margin: { left: 14, right: 14 },
  });

  currentY = (doc as any).lastAutoTable.finalY + 6;

  // Check if new page is needed for observations & signatures
  if (currentY > 230) {
    doc.addPage();
    currentY = 20;
  }

  // Auditor Observations Box
  doc.setFontSize(9);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(30, 58, 138);
  doc.text("AUDITOR'S OBSERVATIONS & STATUTORY FINDINGS:", 14, currentY);
  currentY += 4;

  doc.setFontSize(8);
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(31, 41, 55);
  const obsLines = doc.splitTextToSize(facility.auditorObservations || 'No major adverse remarks.', 180);
  doc.text(obsLines, 14, currentY);
  currentY += obsLines.length * 4 + 4;

  if (facility.additionalNotes) {
    doc.setFont('helvetica', 'bold');
    doc.text("Additional Branch Notes:", 14, currentY);
    currentY += 4;
    doc.setFont('helvetica', 'italic');
    const noteLines = doc.splitTextToSize(facility.additionalNotes, 180);
    doc.text(noteLines, 14, currentY);
    currentY += noteLines.length * 4 + 6;
  }

  // Signatures
  if (currentY > 245) {
    doc.addPage();
    currentY = 25;
  }

  doc.setDrawColor(200, 200, 200);
  doc.line(14, currentY + 12, 85, currentY + 12);
  doc.line(115, currentY + 12, 195, currentY + 12);

  doc.setFontSize(8);
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(50, 50, 50);
  doc.text("VERIFIED BY AUDIT SENIOR:", 14, currentY + 17);
  doc.text("REVIEWED BY ENGAGEMENT PARTNER:", 115, currentY + 17);

  doc.setFont('helvetica', 'normal');
  doc.text(currentUser.name, 14, currentY + 21);
  doc.text(`Date: ${metadata.auditAsOfDate}`, 14, currentY + 25);

  doc.text(metadata.leadAuditor, 115, currentY + 21);
  doc.text(metadata.firmName, 115, currentY + 25);

  return doc;
}

export function generateBulkFacilitiesPDF(
  facilities: CreditFacility[],
  metadata: AuditMetadata,
  currentUser: UserAccount
): jsPDF {
  const doc = new jsPDF({
    orientation: 'landscape',
    unit: 'mm',
    format: 'a4',
  });

  // Header Banner
  doc.setFillColor(30, 58, 138);
  doc.rect(0, 0, 297, 24, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFontSize(12);
  doc.setFont('helvetica', 'bold');
  doc.text(`${metadata.firmName.toUpperCase()} (FRN: ${metadata.firmFRN}) — CREDIT AUDIT REGISTER & ADVANCES PORTFOLIO`, 14, 8);

  doc.setFontSize(7.5);
  doc.setFont('helvetica', 'normal');
  doc.text(`Bank: ${metadata.bankName} | Branch: ${metadata.branchName} (${metadata.branchCode}) | Location: ${metadata.branchAddress || 'Branch Premises'}`, 14, 14);
  doc.text(`Lead Auditor: ${metadata.leadAuditor} | Audit Reporting As-on Date: ${metadata.auditAsOfDate} (FY ${metadata.auditYear}) | Portfolio: ${facilities.length} Accounts`, 14, 19);

  const tableData = facilities.map((fac, idx) => {
    const dpStatus = evaluateDPStatusBadge(fac, metadata.auditAsOfDate);
    const irac = fac.currentIRAC;
    return [
      String(idx + 1),
      fac.accountNumber,
      fac.borrowerName,
      fac.facilityType,
      `Rs. ${(fac.totalSanctionedLimit / 100000).toFixed(2)} L`,
      `Rs. ${(fac.outstandingBalance / 100000).toFixed(2)} L`,
      fac.currentDPWorking ? `Rs. ${(fac.currentDPWorking.computedDP / 100000).toFixed(2)} L` : 'N/A',
      dpStatus.label,
      irac?.computedCategory || 'Standard',
      `Rs. ${((irac?.totalProvisionAmount || 0) / 100000).toFixed(2)} L`,
      fac.nextRenewalDueDate || 'N/A',
      fac.isReviewed ? 'Reviewed' : 'Pending'
    ];
  });

  autoTable(doc, {
    startY: 26,
    head: [['Sr', 'Account No', 'Borrower Name', 'Facility', 'Limit (L)', 'O/S (L)', 'DP (L)', 'DP Health', 'IRAC Category', 'Provision (L)', 'Renewal Due', 'Review']],
    body: tableData,
    theme: 'grid',
    headStyles: { fillColor: [30, 58, 138], textColor: 255, fontStyle: 'bold', fontSize: 7.5 },
    bodyStyles: { fontSize: 7, cellPadding: 1.5 },
    margin: { left: 10, right: 10 },
  });

  return doc;
}
