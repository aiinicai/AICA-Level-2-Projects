import { 
  Document, 
  Packer, 
  Paragraph, 
  Table, 
  TableCell, 
  TableRow, 
  TextRun, 
  WidthType, 
  AlignmentType, 
  BorderStyle, 
  HeadingLevel,
  ShadingType
} from 'docx';
import { CreditFacility, UserAccount } from '../types/audit';
import { AuditMetadata } from './storageService';
import { evaluateDPStatusBadge } from './dpEngine';

export async function generateFacilityWordDocument(
  facility: CreditFacility,
  metadata: AuditMetadata,
  currentUser: UserAccount
): Promise<Blob> {
  const dpStatus = evaluateDPStatusBadge(facility, metadata.auditAsOfDate);
  const dp = facility.currentDPWorking;
  const irac = facility.currentIRAC;

  // Colors
  const PRIMARY_HEX = "1E3A8A"; // Navy 900
  const LIGHT_GRAY_HEX = "F3F4F6";
  const BORDER_HEX = "D1D5DB";

  const tableBorder = {
    top: { style: BorderStyle.SINGLE, size: 1, color: BORDER_HEX },
    bottom: { style: BorderStyle.SINGLE, size: 1, color: BORDER_HEX },
    left: { style: BorderStyle.SINGLE, size: 1, color: BORDER_HEX },
    right: { style: BorderStyle.SINGLE, size: 1, color: BORDER_HEX },
  };

  const createCell = (text: string, isBold: boolean = false, widthPct: number = 50, isHeader: boolean = false): TableCell => {
    return new TableCell({
      width: { size: widthPct, type: WidthType.PERCENTAGE },
      shading: isHeader ? { fill: PRIMARY_HEX, type: ShadingType.CLEAR } : undefined,
      borders: tableBorder,
      children: [
        new Paragraph({
          children: [
            new TextRun({
              text,
              bold: isBold,
              color: isHeader ? "FFFFFF" : "000000",
              size: 19, // 9.5pt
              font: "Arial",
            }),
          ],
        }),
      ],
    });
  };

  // Section 1: Core Facility Info Rows
  const summaryRows = [
    new TableRow({
      children: [createCell("Borrower Name", true, 25), createCell(facility.borrowerName, false, 75)],
    }),
    new TableRow({
      children: [createCell("Account Number", true, 25), createCell(facility.accountNumber, false, 75)],
    }),
    new TableRow({
      children: [createCell("Facility Type & Constitution", true, 25), createCell(`${facility.facilityType} | ${facility.constitution}`, false, 75)],
    }),
    new TableRow({
      children: [createCell("Industry / Sector", true, 25), createCell(facility.industrySector, false, 75)],
    }),
    new TableRow({
      children: [createCell("Sanction Date & Authority", true, 25), createCell(`${facility.sanctionDate} | ${facility.sanctioningAuthority}`, false, 75)],
    }),
    new TableRow({
      children: [createCell("Renewal Status", true, 25), createCell(`Last: ${facility.lastRenewalDate || 'N/A'} | Next Due: ${facility.nextRenewalDueDate || 'N/A'}`, false, 75)],
    }),
    new TableRow({
      children: [createCell("Interest Rate", true, 25), createCell(`${facility.interestRate}% p.a.`, false, 75)],
    }),
    new TableRow({
      children: [createCell("Sanctioned Limit (Fund / NFB)", true, 25), createCell(`Fund: ₹${facility.sanctionedLimitFundBased.toLocaleString('en-IN')} | Non-Fund: ₹${facility.sanctionedLimitNonFundBased.toLocaleString('en-IN')} (Total: ₹${facility.totalSanctionedLimit.toLocaleString('en-IN')})`, false, 75)],
    }),
    new TableRow({
      children: [createCell("Outstanding Balance", true, 25), createCell(`₹${facility.outstandingBalance.toLocaleString('en-IN')}`, true, 75)],
    }),
    new TableRow({
      children: [createCell("Related Party (Sec. 20 BRA)", true, 25), createCell(facility.isRelatedParty ? `YES - ${facility.relatedPartyDetails || 'Disclosed'}` : 'NO', false, 75)],
    }),
  ];

  // Section 2: DP Rows
  const dpRows = [
    new TableRow({
      children: [createCell("Stock Statement Date", true, 30), createCell(dp?.statementDate || 'N/A', false, 70)],
    }),
    new TableRow({
      children: [createCell("Gross Stock Value", true, 30), createCell(`₹${(dp?.stockValue || 0).toLocaleString('en-IN')}`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Less: Creditors for Stock", true, 30), createCell(`₹${(dp?.creditorsForStock || 0).toLocaleString('en-IN')}`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Margin on Stock", true, 30), createCell(`${dp?.marginPercentOnStock || facility.stipulatedMarginPercent}%`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Net Paid Stock Value", true, 30), createCell(`₹${(dp?.netPaidStock || 0).toLocaleString('en-IN')}`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Eligible Book Debts (<90d)", true, 30), createCell(`₹${(dp?.bookDebtsEligible || 0).toLocaleString('en-IN')} (Total: ₹${(dp?.bookDebtsTotal || 0).toLocaleString('en-IN')}, Overdue: ₹${(dp?.bookDebtsOverdue || 0).toLocaleString('en-IN')})`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Margin on Debtors", true, 30), createCell(`${dp?.marginPercentOnDebtors || 40}%`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Net Eligible Book Debts", true, 30), createCell(`₹${(dp?.netEligibleDebtors || 0).toLocaleString('en-IN')}`, false, 70)],
    }),
    new TableRow({
      children: [createCell("COMPUTED DRAWING POWER", true, 30), createCell(`₹${(dp?.computedDP || 0).toLocaleString('en-IN')}`, true, 70)],
    }),
    new TableRow({
      children: [createCell("DP Status Assessment", true, 30), createCell(`${dpStatus.label} - ${dpStatus.description}`, true, 70)],
    }),
  ];

  // Section 3: IRAC Rows
  const iracRows = [
    new TableRow({
      children: [createCell("IRAC Category", true, 30), createCell(`${irac?.computedCategory || 'Standard'} ${irac?.isNPA ? `(NPA Date: ${irac.npaDate})` : '(Performing)'}`, true, 70)],
    }),
    new TableRow({
      children: [createCell("Total Realizable Security", true, 30), createCell(`₹${(irac?.totalRealizableSecurity || 0).toLocaleString('en-IN')} (Primary: ₹${(facility.realizableValuePrimary || 0).toLocaleString('en-IN')}, Collateral: ₹${(facility.realizableValueCollateral || 0).toLocaleString('en-IN')})`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Secured Portion vs Rate", true, 30), createCell(`₹${(irac?.securedPortion || 0).toLocaleString('en-IN')} @ ${irac?.provisionRateSecuredPercent || 0}% = ₹${(irac?.provisionAmountSecured || 0).toLocaleString('en-IN')}`, false, 70)],
    }),
    new TableRow({
      children: [createCell("Unsecured Portion vs Rate", true, 30), createCell(`₹${(irac?.unsecuredPortion || 0).toLocaleString('en-IN')} @ ${irac?.provisionRateUnsecuredPercent || 0}% = ₹${(irac?.provisionAmountUnsecured || 0).toLocaleString('en-IN')}`, false, 70)],
    }),
    new TableRow({
      children: [createCell("TOTAL PROVISION REQUIRED", true, 30), createCell(`₹${(irac?.totalProvisionAmount || 0).toLocaleString('en-IN')} (${irac?.effectiveProvisionPercent || 0}% effective)`, true, 70)],
    }),
  ];

  // Checklist table
  const checklistHeader = new TableRow({
    children: [
      createCell("Sr.", true, 8, true),
      createCell("Documentation / Security Requirement", true, 42, true),
      createCell("Status", true, 25, true),
      createCell("Expiry / Ref", true, 25, true),
    ],
  });

  const checklistRows = facility.checklist.map((chk, idx) => {
    return new TableRow({
      children: [
        createCell(String(idx + 1), false, 8),
        createCell(chk.title, false, 42),
        createCell(chk.status, chk.status !== 'Obtained & Valid', 25),
        createCell(`${chk.expiryDate || 'N/A'}${chk.documentRef ? ` (${chk.documentRef})` : ''}`, false, 25),
      ],
    });
  });

  const doc = new Document({
    sections: [
      {
        properties: {},
        children: [
          // Header
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: metadata.firmName.toUpperCase(),
                bold: true,
                size: 26,
                color: PRIMARY_HEX,
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `Firm Registration No: ${metadata.firmFRN} | Address: ${metadata.firmAddress || 'Chartered Accountants'}`,
                size: 17,
                italics: true,
                color: "555555",
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `CREDIT AUDIT CHECKLIST & ADVANCE VERIFICATION MEMO — FY ${metadata.auditYear}`,
                bold: true,
                size: 22,
                color: "111827",
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `Bank: ${metadata.bankName} | Branch: ${metadata.branchName} (${metadata.branchCode})`,
                size: 18,
                bold: true,
              }),
            ],
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `Branch Address: ${metadata.branchAddress || 'Branch Premises'} | Audit As on: ${metadata.auditAsOfDate}`,
                size: 16,
                color: "444444",
              }),
            ],
          }),
          new Paragraph({ text: "" }),

          // Section 1 Heading
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [
              new TextRun({
                text: "1. BORROWER & CREDIT FACILITY PROFILE",
                bold: true,
                size: 20,
                color: PRIMARY_HEX,
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: summaryRows,
          }),
          new Paragraph({ text: "" }),

          // Section 2 Heading: DP
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [
              new TextRun({
                text: "2. DRAWING POWER (DP) & NORMS EVALUATION",
                bold: true,
                size: 20,
                color: PRIMARY_HEX,
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: dpRows,
          }),
          ...(facility.isNormOverridden ? [
            new Paragraph({
              children: [
                new TextRun({
                  text: `⚠️ SANCTIONED OVERRIDING BANKING NORMS: ${facility.overrideRemarks || 'Approval verified on record'} (Approving Authority: ${facility.overrideApprovingAuthority || 'Competent Authority'})`,
                  bold: true,
                  color: "B91C1C",
                  size: 18,
                }),
              ],
            }),
          ] : []),
          new Paragraph({ text: "" }),

          // Section 3 Heading: IRAC
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [
              new TextRun({
                text: "3. IRAC ASSET CLASSIFICATION & PROVISIONING",
                bold: true,
                size: 20,
                color: PRIMARY_HEX,
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: iracRows,
          }),
          new Paragraph({ text: "" }),

          // Section 4 Heading: Checklist
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [
              new TextRun({
                text: "4. DOCUMENTATION, SECURITY & CHARGE VERIFICATION CHECKLIST",
                bold: true,
                size: 20,
                color: PRIMARY_HEX,
              }),
            ],
          }),
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [checklistHeader, ...checklistRows],
          }),
          new Paragraph({ text: "" }),

          // Section 5: Auditor Observations & Additional Notes
          new Paragraph({
            heading: HeadingLevel.HEADING_2,
            children: [
              new TextRun({
                text: "5. AUDITOR'S OBSERVATIONS & CRITICAL FINDINGS",
                bold: true,
                size: 20,
                color: PRIMARY_HEX,
              }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: facility.auditorObservations || 'No major adverse deviations observed during credit verification.',
                size: 19,
              }),
            ],
          }),
          new Paragraph({ text: "" }),

          new Paragraph({
            heading: HeadingLevel.HEADING_3,
            children: [
              new TextRun({
                text: "Additional Notes / Branch Remarks:",
                bold: true,
                size: 19,
              }),
            ],
          }),
          new Paragraph({
            children: [
              new TextRun({
                text: facility.additionalNotes || 'N/A',
                italics: true,
                size: 18,
              }),
            ],
          }),
          new Paragraph({ text: "" }),
          new Paragraph({ text: "" }),

          // Dual Signature Block
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  new TableCell({
                    width: { size: 50, type: WidthType.PERCENTAGE },
                    borders: {
                      top: { style: BorderStyle.NONE },
                      bottom: { style: BorderStyle.NONE },
                      left: { style: BorderStyle.NONE },
                      right: { style: BorderStyle.NONE },
                    },
                    children: [
                      new Paragraph({ children: [new TextRun({ text: "_______________________________", bold: true })] }),
                      new Paragraph({ children: [new TextRun({ text: "AUDIT SENIOR / VERIFIED BY:", bold: true, size: 18 })] }),
                      new Paragraph({ children: [new TextRun({ text: currentUser.name, size: 18 })] }),
                      new Paragraph({ children: [new TextRun({ text: `Date: ${metadata.auditAsOfDate}`, size: 18 })] }),
                    ],
                  }),
                  new TableCell({
                    width: { size: 50, type: WidthType.PERCENTAGE },
                    borders: {
                      top: { style: BorderStyle.NONE },
                      bottom: { style: BorderStyle.NONE },
                      left: { style: BorderStyle.NONE },
                      right: { style: BorderStyle.NONE },
                    },
                    children: [
                      new Paragraph({ children: [new TextRun({ text: "_______________________________", bold: true })] }),
                      new Paragraph({ children: [new TextRun({ text: "ENGAGEMENT PARTNER / REVIEWER:", bold: true, size: 18 })] }),
                      new Paragraph({ children: [new TextRun({ text: metadata.leadAuditor, size: 18 })] }),
                      new Paragraph({ children: [new TextRun({ text: `${metadata.firmName}`, size: 18 })] }),
                    ],
                  }),
                ],
              }),
            ],
          }),
        ],
      },
    ],
  });

  return await Packer.toBlob(doc);
}
