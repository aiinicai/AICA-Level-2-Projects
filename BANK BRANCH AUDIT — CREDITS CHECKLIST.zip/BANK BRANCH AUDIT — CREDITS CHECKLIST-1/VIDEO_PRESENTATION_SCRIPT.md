# Video Presentation & Demonstration Script
## Capstone Project Submission: Bank Branch Audit — Credits Checklist & IRAC Engine

> [!TIP]
> **How to use this script**: 
> 1. Open your application in full screen (either the `.exe` desktop app or web browser at `http://localhost:5173`).
> 2. Start your screen recording software (e.g., OBS Studio, Windows Game Bar `Win + Alt + R`, Zoom, or Loom).
> 3. Follow the **[SHOW ON SCREEN]** cues for what to display while reading the **"Spoken Script"** sections out loud.

---

### ⏱️ Quick Video Overview & Timeline (Total Duration: ~5 - 7 Minutes)

| Segment | Topic | Estimated Time |
| :--- | :--- | :--- |
| **Part 1** | Project Introduction & Core Problem Solved | 0:00 – 0:45 |
| **Part 2** | Tech Stack & System Architecture | 0:45 – 1:30 |
| **Part 3** | Main Dashboard & Risk Alerts Tour | 1:30 – 2:30 |
| **Part 4** | Credit Register & 6-Tab Facility Manager | 2:30 – 3:30 |
| **Part 5** | Deep-Dive: Drawing Power (DP) & RBI IRAC Math Engines | 3:30 – 5:00 |
| **Part 6** | Audit Trail, Attachments & Report Generation (PDF/DOCX) | 5:00 – 6:15 |
| **Part 7** | Conclusion & Closing Summary | 6:15 – 6:45 |

---

### 🎬 Part 1: Project Introduction & Purpose (0:00 – 0:45)

**[SHOW ON SCREEN]**: *Application launch screen showing the main Dashboard view with KPI cards, IRAC pie chart, and live alerts panel.*

**[SPOKEN SCRIPT]**:
> "Hello everyone, welcome to the demonstration of my Capstone Project: **Bank Branch Audit — Credits Checklist & IRAC Engine**.
> 
> In commercial banking audits, Statutory Branch Auditors and Concurrent Auditors face a significant challenge: manually calculating Drawing Power against fluctuating stock statements, categorizing non-performing loan assets according to complex Reserve Bank of India (RBI) IRAC guidelines, verifying dozens of security compliance documents, and compiling long audit reports under tight deadlines.
> 
> To solve this, I built a specialized, 100% offline desktop and web application that automates Drawing Power estimations, dynamic RBI asset classification and provisioning, statutory banking compliance scanning, audit trail tracking, and dual PDF and Word report generation."

---

### 🎬 Part 2: Tech Stack & System Architecture (0:45 – 1:30)

**[SHOW ON SCREEN]**: *Briefly display the project folder structure or README.md, showing `BUILD_EXE.bat` and the `release/` folder containing the executable files, then return to the app.*

**[SPOKEN SCRIPT]**:
> "Let me brief you on how this application was engineered and packaged.
> 
> On the **Frontend**, the app is built using **React 19**, **TypeScript**, and **Vite** for ultra-fast UI rendering, structured data typing, and component modularity. The user interface is styled with **Tailwind CSS**, featuring full support for both Light and Dark themes.
> 
> For **Desktop Deployment**, I integrated **Electron** and **electron-builder**. This packages the entire React application into a standalone Windows executable (`.exe`). It runs 100% offline directly on an auditor's laptop without needing Node.js, internet connectivity, or external database setups.
> 
> For **Reporting and Data Engine Capabilities**, I integrated the **`docx`** JavaScript library for editable Microsoft Word audit reports, **`jsPDF`** with `jspdf-autotable` for printable PDF certificates, and **`SheetJS / XLSX`** for raw spreadsheet data exports."

---

### 🎬 Part 3: Dashboard & Live Risk Alerts Tour (1:30 – 2:30)

**[SHOW ON SCREEN]**: *Hover over the top header bar, click the 'Audit Settings' icon to open Engagement Settings, then close it and interact with the Dashboard KPI cards and Quick Alerts Panel.*

**[SPOKEN SCRIPT]**:
> "Now let's tour the application interface.
> 
> In the top navigation header, auditors can set the **Audit Engagement Metadata** — including the Bank Name, SOL Branch Code, Financial Year cut-off date, Chartered Accountant Firm name, FRN, and Signing Partner Membership Number.
> 
> Below that, the **Dashboard** gives the Lead Auditor an instant bird's-eye view of the branch's loan portfolio:
> - The **KPI Cards** display total borrower accounts, aggregate fund-based and non-fund-based sanctioned limits, and total outstanding balances.
> - The **IRAC Exposure Panel & Chart** visualizes portfolio quality — breaking down advances into Standard, Sub-Standard, Doubtful (D1, D2, D3), and Loss accounts, alongside total required RBI rupee provisions.
> - On the right, the **Quick Risk Alerts Panel** automatically flags high-risk accounts requiring immediate auditor intervention — such as accounts with Stale Stock Statements older than 90 days, outstandings exceeding Drawing Power or Sanctioned Limits, expired insurance policies, and critical documentation deficiencies. Clicking any alert instantly filters the audit register."

---

### 🎬 Part 4: Credit Register & 6-Tab Facility Manager (2:30 – 3:30)

**[SHOW ON SCREEN]**: *Navigate to the Credit Register view. Demonstrate filtering by facility type (CC/OD/TL) and IRAC status. Click '+ Add Credit Facility' or open an existing account to show the 6 form tabs.*

**[SPOKEN SCRIPT]**:
> "Moving to the **Credit Register**, this is the primary audit repository where all borrower credit facilities are managed. It supports multi-criteria filtering by account number, branch code, facility type like Cash Credit or Term Loans, IRAC category, and Drawing Power status.
> 
> When we open or add a borrower facility, the **Facility Manager** organizes data across six specialized tabs:
> 1. **General & Borrower Details**: Captures Account Number, Borrower Name, Branch, Constitution type (like Private Limited or Partnership), Industry Sector, Sanction Date, and Renewal Due Dates.
> 2. **Limits & Balances**: Captures Fund-Based and Non-Fund-Based limits, outstanding balance, and interest rates.
> 3. **Security & Margins**: Captures Primary and Collateral security descriptions, realizable market values, guarantor details, stipulated margins, and bank reference norms.
> 4. **Compliance & Banking Norms**: Scans for compliance with Section 20 of the Banking Regulation Act 1949 regarding director/related-party advances, insurance policy details, and banking norm overrides.
> 5. **Documentation Checklist**: A comprehensive verification matrix covering 6 categories — Security, Charge creation, Financials, Statutory, Legal, and Insurance documents.
> 6. **Auditor Observations**: Captures detailed CA observations, audit notes, and reviewer sign-offs."

---

### 🎬 Part 5: Drawing Power & RBI IRAC Math Engines (3:30 – 5:00)

**[SHOW ON SCREEN]**: *Click on the 'DP Worksheet' button for a Cash Credit account to show the DP modal math. Then click on the 'IRAC Worksheet' button to highlight the RBI classification step-by-step mathematical trace.*

**[SPOKEN SCRIPT]**:
> "Now let me highlight the core mathematical algorithms powered by the app.
> 
> First is the **Drawing Power Engine**. For working capital facilities like Cash Credit and Overdrafts, the engine computes:
> $$\text{Net Paid Stock} = (\text{Stock Value} - \text{Creditors}) \times (1 - \text{Stock Margin \%})$$
> $$\text{Net Eligible Debtors} = (\text{Total Debtors} - \text{Overdue Debtors}) \times (1 - \text{Debtors Margin \%})$$
> $$\text{Total Computed DP} = \text{Net Paid Stock} + \text{Net Eligible Debtors}$$
> 
> If a stock statement is older than 90 days from the audit cut-off date, the engine automatically flags a **Stale Statement Warning**, marking the DP as unverified as per RBI norms.
> 
> Second is the **RBI IRAC Engine**. The engine takes the NPA date, auto-calculates months elapsed, and categorizes the asset:
> - Up to 12 months as **Sub-Standard** (15% secured / 25% unsecured provision).
> - 12 to 24 months as **Doubtful 1** (25% secured / 100% unsecured provision).
> - 24 to 48 months as **Doubtful 2** (40% secured / 100% unsecured provision).
> - Beyond 48 months as **Doubtful 3** (100% provision).
> 
> The engine splits the outstanding balance into Secured and Unsecured portions based on primary and collateral security valuation, applies sector-specific rates (such as 0.25% for Agriculture/MSE or 1.00% for Commercial Real Estate), and generates a transparent, step-by-step mathematical audit trace for auditor verification."

---

### 🎬 Part 6: Audit Trail, Attachments & Report Generation (5:00 – 6:15)

**[SHOW ON SCREEN]**: *Show the Attachment Manager modal uploading or displaying a document. Open the Edit History modal to show change logs. Finally, open the Report Generation Modal and generate a Word (.docx) or PDF audit report.*

**[SPOKEN SCRIPT]**:
> "To ensure complete regulatory integrity, the system includes two key features:
> 1. **Attachment Repository**: Auditors can attach digital working papers — like stock statements, sanction letters, and valuation reports — directly to loan accounts with timestamp and user attribution.
> 2. **Audit Trail & Locking**: Every parameter change is logged in an immutable Edit History log showing the old value, new value, auditor identity, timestamp, and revision reason. Lead Auditors can lock completed accounts against unauthorized modifications.
> 
> Finally, for **Reporting**:
> With one click on **'Generate Report'**, the application compiles professional single-borrower certificates or branch-wide credit audit reports.
> We can download fully editable **Word documents (`.docx`)** for long-form audit reports (LFAR), print-ready **PDF documents**, or raw **Excel workbooks (`.xlsx`)**, complete with formal signature blocks for both the CA Firm and Bank Branch Management."

---

### 🎬 Part 7: Conclusion & Closing Summary (6:15 – 6:45)

**[SHOW ON SCREEN]**: *Return to the main Dashboard view or show the generated Word / PDF report on screen.*

**[SPOKEN SCRIPT]**:
> "In conclusion, the **Bank Branch Audit — Credits Checklist & IRAC Engine** bridges the gap between banking credit regulations and software automation. It saves hundreds of audit hours, eliminates mathematical errors in DP and provision calculations, ensures strict statutory compliance, and provides dual PDF and Word reports.
> 
> The application is fully built, tested, packaged into an executable desktop installer, and ready for deployment.
> 
> Thank you so much for your time!"

---

> [!NOTE]
> **Tips for a Great Recording**:
> - Speak at a steady, clear pace.
> - Keep your mouse movements smooth when navigating between tabs and modals.
> - Ensure your screen resolution is set to 1080p (`1920x1080`) for optimal clarity.
