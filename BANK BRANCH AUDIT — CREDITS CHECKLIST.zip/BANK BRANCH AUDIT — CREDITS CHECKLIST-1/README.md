# Bank Branch Audit — Credits Checklist & IRAC Engine

A desktop and web audit application for Statutory and Internal Bank Branch Credit Audits, IRAC asset classification, borrower loan account assessment, and reporting.

---
video link: https://drive.google.com/file/d/1KmlusraVrg2FVXjKR9-2AZJdlKQ4et5U/view?usp=sharing
## 🚀 Standalone Windows Application (.exe)

This application is packaged as a standalone Windows desktop executable that runs **100% offline** without needing Node.js or an internet connection.

### Built Executables (in `release/` folder)

| File | Description |
| :--- | :--- |
| **`Bank Branch Audit - Credits Checklist Setup 1.0.0.exe`** | **Windows Installer (NSIS)** — Installs to Windows, creates Desktop shortcut & Start Menu entry. |
| **`Bank Branch Audit - Credits Checklist 1.0.0.exe`** | **Portable Standalone Executable** — Run directly anywhere without installing (e.g., from USB drive). |
| **`release\win-unpacked\`** | Unpacked portable application folder for direct launch. |

---

## 🛠️ How to Rebuild the Windows .exe

### Option 1: 1-Click Batch Script
Double-click **`BUILD_EXE.bat`** in the project root directory.

### Option 2: Command Line
```bash
npm run electron:build
```

---

## 💻 Development & Web Mode

- **Run in Electron Desktop Dev Mode**:
  ```bash
  npm run electron:dev
  ```
- **Run Web Dev Server**:
  ```bash
  npm run dev
  ```
- **Build Web Assets**:
  ```bash
  npm run build
  ```

