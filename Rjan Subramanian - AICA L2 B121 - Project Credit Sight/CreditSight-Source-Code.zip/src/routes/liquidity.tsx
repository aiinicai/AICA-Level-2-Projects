import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Bar, CartesianGrid, ComposedChart, Line, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Download, TrendingUp, CalendarClock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Kpi, RiskChip, Table, exportCsv } from "@/components/app";
import { customers, divisions, forecastAsOf, fmt, fmtM, receivables } from "@/lib/demo-data";
import { addDays, forecastWeeks, predictPayments, type Scenario } from "@/lib/liquidity";
import { head } from "@/lib/head";

export const Route = createFileRoute("/liquidity")({
  head: head("Predictive Liquidity Forecast", "CreditSight cash collection forecast based on invoice due dates, promises to pay, payment behaviour and customer risk."),
  component: Liquidity,
});

const dateLabel = (date: string) => new Date(`${date}T00:00:00Z`).toLocaleDateString("en-GB", { day: "2-digit", month: "short", timeZone: "UTC" });

function Liquidity() {
  const [days, setDays] = useState(90);
  const [scenario, setScenario] = useState<Scenario>("Base");
  const [division, setDivision] = useState("All divisions");
  const [reliability, setReliability] = useState(90);
  const [delay, setDelay] = useState(0);
  const [view, setView] = useState<"All payments" | "Promises only">("All payments");
  const accounts = customers.filter((c) => division === "All divisions" || c.division === division);
  const ids = new Set(accounts.map((c) => c.id));
  const invoices = receivables.filter((i) => ids.has(i.customerId));
  const payments = predictPayments(invoices, accounts, { asOf: forecastAsOf, days, scenario, promiseReliability: reliability, extraDelay: delay });
  const end = addDays(forecastAsOf, days);
  const within = payments.filter((p) => p.date >= forecastAsOf && p.date < end);
  const weeks = forecastWeeks(payments, invoices, forecastAsOf, days);
  const expected = within.reduce((s, p) => s + p.expected, 0);
  const promised = within.filter((p) => p.source === "Promise").reduce((s, p) => s + p.expected, 0);
  const first30 = within.filter((p) => p.date < addDays(forecastAsOf, 30)).reduce((s, p) => s + p.expected, 0);
  const overdue = invoices.filter((i) => i.dueDate < forecastAsOf).reduce((s, i) => s + i.amount, 0);
  const missed = invoices.filter((i) => i.promise && i.promise.date < forecastAsOf);
  const rows = within.filter((p) => view === "All payments" || p.source === "Promise");
  const accountMap = new Map(accounts.map((c) => [c.id, c]));
  const download = () => exportCsv("creditsight-liquidity-forecast.csv", ["Week", "Start", "End", "Due-date expected AED", "Promise expected AED", "Total expected AED", "Cumulative AED", "Scenario", "Promise reliability %", "Extra delay days"], weeks.map((w) => [w.week, w.start, w.end, Math.round(w.due), Math.round(w.promised), Math.round(w.expected), Math.round(w.cumulative), scenario, reliability, delay]));

  return <div className="space-y-6">
    <header className="flex flex-wrap items-start justify-between gap-4">
      <div>
        <div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase text-accent"><TrendingUp className="h-4 w-4" /> Treasury outlook</div>
        <h1 className="text-2xl font-semibold">Predictive Liquidity Forecast</h1>
        <p className="mt-1 text-sm text-muted-foreground">Demo snapshot · 25 October 2026 · AED equivalent · Receivables inflows only</p>
      </div>
      <div className="flex flex-wrap gap-2"><Button variant="outline" asChild><Link to="/stress-test">CFO stress test</Link></Button><Button variant="outline" onClick={download}><Download /> Export forecast</Button></div>
    </header>

    <section aria-label="Forecast settings" className="flex flex-wrap items-end gap-5 border-y py-4">
      <label className="space-y-1 text-xs text-muted-foreground"><span className="block">Forecast horizon</span>
        <select aria-label="Forecast horizon" value={days} onChange={(e) => setDays(Number(e.target.value))} className="h-9 rounded-md border bg-background px-3 text-sm text-foreground"><option value={30}>30 days</option><option value={60}>60 days</option><option value={90}>90 days</option></select>
      </label>
      <label className="min-w-0 space-y-1 text-xs text-muted-foreground"><span className="block">Division</span>
        <select aria-label="Division" value={division} onChange={(e) => setDivision(e.target.value)} className="h-9 w-full max-w-64 rounded-md border bg-background px-3 text-sm text-foreground"><option>All divisions</option>{divisions.map((d) => <option key={d}>{d}</option>)}</select>
      </label>
      <fieldset><legend className="mb-1 text-xs text-muted-foreground">Scenario</legend><div className="flex flex-wrap gap-1">{(["Conservative", "Base", "Optimistic"] as const).map((s) => <Button key={s} variant={scenario === s ? "default" : "outline"} size="sm" aria-pressed={scenario === s} onClick={() => setScenario(s)}>{s}</Button>)}</div></fieldset>
      <label className="w-40 text-xs text-muted-foreground"><span className="mb-2 block">Promise reliability <span className="float-right font-mono text-foreground">{reliability}%</span></span><input aria-label="Promise reliability" type="range" min={0} max={100} step={5} value={reliability} onChange={(e) => setReliability(Number(e.target.value))} className="w-full accent-accent" /></label>
      <label className="text-xs text-muted-foreground"><span className="mb-1 block">Extra payment delay</span><select aria-label="Extra payment delay" value={delay} onChange={(e) => setDelay(Number(e.target.value))} className="h-9 rounded-md border bg-background px-3 text-sm text-foreground">{[0, 7, 14, 30].map((d) => <option key={d} value={d}>{d} days</option>)}</select></label>
    </section>

    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      <Kpi label={`${days}-day expected receipts`} value={fmtM(expected)} note={`${dateLabel(forecastAsOf)} – ${dateLabel(addDays(end, -1))}`} />
      <Kpi label="Next 30 days" value={fmtM(first30)} note="Risk-weighted cash inflows" />
      <Kpi label="Promise-backed receipts" value={fmtM(promised)} note={`${within.filter((p) => p.source === "Promise").length} future payment commitments`} />
      <Kpi label="Overdue receivables" value={fmtM(overdue)} tone="bad" note={`${missed.length} missed promises · ${fmtM(missed.reduce((s, i) => s + (i.promise?.amount ?? 0), 0))}`} />
    </div>

    <section aria-label="Weekly forecast">
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3"><div><h2 className="font-semibold">Cash inflow outlook</h2><p className="text-xs text-muted-foreground">Weekly receipts · AED millions</p></div><div className="flex flex-wrap gap-4 text-xs text-muted-foreground"><span className="flex items-center gap-2"><span className="h-2 w-2 bg-chart-1" />Due-date based</span><span className="flex items-center gap-2"><span className="h-2 w-2 bg-chart-2" />Promise-backed</span><span className="flex items-center gap-2"><span className="h-0.5 w-4 bg-chart-3" />Cumulative</span></div></div>
      <div className="h-80 min-w-0">
        <ResponsiveContainer width="100%" height="100%"><ComposedChart data={weeks.map((w) => ({ ...w, due: w.due / 1e6, promised: w.promised / 1e6, cumulative: w.cumulative / 1e6 }))} margin={{ top: 10, right: 0, left: 0, bottom: 5 }}>
          <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} /><XAxis dataKey="week" fontSize={12} /><YAxis fontSize={11} width={42} /><YAxis yAxisId="total" orientation="right" fontSize={11} width={45} />
          <Tooltip contentStyle={{ background: "var(--card)", borderColor: "var(--border)", color: "var(--foreground)" }} formatter={(v: number) => `${v.toFixed(2)}M AED`} labelFormatter={(_, payload) => { const w = payload[0]?.payload; return w ? `${dateLabel(w.start)} – ${dateLabel(w.end)}` : ""; }} />
          <Bar dataKey="due" name="Due-date expected" stackId="cash" fill="var(--chart-1)" maxBarSize={44} isAnimationActive={false} /><Bar dataKey="promised" name="Promise expected" stackId="cash" fill="var(--chart-2)" maxBarSize={44} radius={[3, 3, 0, 0]} isAnimationActive={false} /><Line yAxisId="total" dataKey="cumulative" name="Cumulative expected" stroke="var(--chart-3)" strokeWidth={3} dot={false} isAnimationActive={false} />
        </ComposedChart></ResponsiveContainer>
      </div>
    </section>

    <section className="border-t pt-5">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3"><h2 className="flex items-center gap-2 font-semibold"><CalendarClock className="h-4 w-4 text-accent" /> Expected payment schedule <span className="text-xs font-normal text-muted-foreground">{rows.length} payment portions</span></h2><div className="flex gap-1">{(["All payments", "Promises only"] as const).map((v) => <Button key={v} variant={view === v ? "secondary" : "ghost"} size="sm" aria-pressed={view === v} onClick={() => setView(v)}>{v}</Button>)}</div></div>
      {rows.length === 0 ? <p className="border-y py-10 text-center text-sm text-muted-foreground">No payments expected within this forecast window.</p> : <Table head={["Expected date", "Customer / invoice", "Basis", "Payment amount", "Probability", "Expected receipt", "Risk"]} right={[3, 4, 5]} rows={rows.map((p) => {
        const c = accountMap.get(p.customerId);
        return [dateLabel(p.date), <div><Link to="/customers/$id" params={{ id: p.customerId }} className="font-medium text-accent">{c?.name ?? p.customerId}</Link><div className="text-xs text-muted-foreground">{p.invoiceId}</div></div>, <span className={p.source === "Promise" ? "font-medium text-accent" : "text-muted-foreground"}>{p.source}</span>, fmt(p.amount), `${Math.round(p.probability * 100)}%`, fmt(p.expected), c ? <RiskChip r={c.rating} /> : "—"];
      })} />}
    </section>

    <details className="border-t py-3 text-xs text-muted-foreground"><summary className="cursor-pointer font-medium text-foreground">Forecast assumptions & coverage</summary><div className="mt-3 max-w-3xl space-y-2 leading-relaxed">
      <p>Illustrative invoice due dates and payment promises are generated from the demo portfolio. Collection notes are not parsed or linked. This is a rules-based estimate, not a trained predictive model.</p>
      <p>Unpromised balances use due date plus historical days beyond terms (DBT). Overdue balances use the snapshot date plus at least seven days. Valid promises replace only their committed portion; missed promises fall back to the overdue estimate.</p>
      <p>Base collection probabilities: Low 96%, Medium 85%, High 65%, Critical 40%. Promise reliability multiplies these probabilities. Optimistic adds 8 percentage points and halves DBT; Conservative subtracts 15 points and multiplies DBT by 1.5. Probabilities are capped at 100%. Extra delay applies to both payment sources.</p>
      <p>Opening cash, cash outflows, new sales and uncollected residual balances are excluded. This forecast estimates receipts, not a net cash balance. All amounts are AED equivalent.</p>
    </div></details>
  </div>;
}