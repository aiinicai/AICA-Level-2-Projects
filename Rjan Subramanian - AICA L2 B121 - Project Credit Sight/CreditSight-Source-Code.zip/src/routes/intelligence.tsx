import { createFileRoute } from "@tanstack/react-router";
import { PageHeader, Panel, RiskChip } from "@/components/app";
import { countries, customers, fmtM, ratingOf, sectors } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/intelligence")({
  head: head("Sector & Country Intelligence", "Concentration and risk by sector and country."),
  component: Intel,
});

function Block({ title, items }: { title: string; items: { name: string; risk: number; key: "sector" | "country" }[] }) {
  return (
    <Panel title={title}>
      <table className="w-full text-sm">
        <thead className="text-xs text-muted-foreground"><tr><th className="text-left">Name</th><th className="text-right">Customers</th><th className="text-right">Exposure</th><th className="text-right">Risk index</th><th /></tr></thead>
        <tbody>{items.map((it) => { const cs = customers.filter((c) => c[it.key] === it.name); return (
          <tr key={it.name} className="border-t"><td className="py-2">{it.name}</td><td className="num">{cs.length}</td><td className="num">{fmtM(cs.reduce((a, c) => a + c.exposure, 0))}</td><td className="num">{it.risk}</td><td className="pl-3"><RiskChip r={ratingOf(100 - it.risk)} /></td></tr>); })}</tbody>
      </table>
    </Panel>
  );
}

function Intel() {
  return (
    <>
      <PageHeader title="Sector & Country Intelligence" sub="Risk index 0 (safe) – 100 (severe) feeds the scorecard" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Block title="Sectors" items={sectors.map((s) => ({ ...s, key: "sector" }))} />
        <Block title="Countries" items={countries.map((c) => ({ name: c.name, risk: c.risk, key: "country" }))} />
      </div>
    </>
  );
}
