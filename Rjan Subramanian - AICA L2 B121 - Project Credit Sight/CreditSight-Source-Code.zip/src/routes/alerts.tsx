import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Kpi, PageHeader, RiskChip, Table } from "@/components/app";
import { alerts } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/alerts")({
  head: head("Monitoring & Alerts", "Early-warning alerts for limit breaches, deterioration and overdue balances."),
  component: Alerts,
});

function Alerts() {
  const [type, setType] = useState("");
  const list = alerts.filter((a) => !type || a.type === type);
  const types = [...new Set(alerts.map((a) => a.type))];
  return (
    <>
      <PageHeader title="Monitoring & Alerts" sub="Rules: exposure > limit · utilisation > 90% · score drop > 12 pts · 90+ overdue with DBT > 40" />
      <div className="mb-4 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {types.map((t) => <button key={t} onClick={() => setType(type === t ? "" : t)} className="text-left"><Kpi label={t} value={String(alerts.filter((a) => a.type === t).length)} note={type === t ? "Filtered" : "Click to filter"} /></button>)}
      </div>
      <Table head={["Date", "Customer", "Alert", "Trigger", "Severity", "Status", "Owner"]}
        rows={list.map((a) => [a.date, <Link to="/customers/$id" params={{ id: a.customer.id }} className="hover:text-accent">{a.customer.name}</Link>, a.type, a.detail, <RiskChip r={a.severity} />, a.status, a.owner])} />
    </>
  );
}
