import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, Download, FileText, Table2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { exportCsv, PageHeader } from "@/components/app";
import { forecastAsOf } from "@/lib/demo-data";
import { downloadPortfolioReport, portfolioReports, type PortfolioReport } from "@/lib/portfolio-reports";
import { head } from "@/lib/head";

export const Route = createFileRoute("/reports")({
  head: head("Management Reports", "CreditSight print-ready portfolio reports, aging, watchlist, alerts, credit utilisation and scenario board packs."),
  component: Reports,
});

function Reports() {
  const [busy, setBusy] = useState<string | null>(null);
  const [error, setError] = useState("");
  const download = async (report: PortfolioReport) => {
    setBusy(report.id); setError("");
    try { await downloadPortfolioReport(report); }
    catch { setError("The report could not be prepared. Please try again."); }
    finally { setBusy(null); }
  };
  return (
    <>
      <PageHeader title="Management reports" sub={`Synthetic case study · Snapshot ${forecastAsOf} · AED equivalent`} />
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4 border-y py-6"><div className="flex items-start gap-3"><FileText className="mt-1 h-6 w-6 shrink-0 text-accent" /><div><h2 className="text-lg font-semibold">The board briefing</h2><p className="mt-1 max-w-lg text-sm text-muted-foreground">Executive assessment · Cash trajectory · Reconciliation · ECL basis · Evidence appendix</p></div></div><Button asChild><Link to="/stress-test">Prepare board pack<ArrowRight /></Link></Button></div>
      {error && <p role="alert" className="mb-4 text-destructive">{error}</p>}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {portfolioReports.map((r, i) => (
          <div key={r.id} className="flex flex-col rounded-lg border bg-card p-5">
            <div className="mb-5 flex items-center justify-between text-muted-foreground"><FileText className="h-5 w-5 text-accent" /><span className="font-mono text-xs">{String(i + 1).padStart(2, "0")}</span></div>
            <h2 className="font-semibold">{r.title}</h2><p className="mt-1 text-sm text-muted-foreground">{r.description}</p><p className="mt-3 text-xs text-muted-foreground">{r.rows.length} records · AED equivalent</p>
            <div className="mt-auto flex flex-wrap gap-2 pt-5"><Button size="sm" aria-label={`Download ${r.title} PDF`} disabled={busy !== null} onClick={() => download(r)}><Download />{busy === r.id ? "Preparing…" : "PDF"}</Button><Button variant="outline" size="sm" aria-label={`Download ${r.title} CSV`} onClick={() => exportCsv(`CreditSight-${r.id}-${forecastAsOf}.csv`, r.headers, r.rows)}><Table2 />CSV</Button></div>
          </div>
        ))}
      </div>
    </>
  );
}
