import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { Activity, Download, RotateCcw, FileSearch, ArrowRight } from "lucide-react";
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Kpi, RiskChip, Table } from "@/components/app";
import { customers, forecastAsOf, fmt, fmtM, receivables } from "@/lib/demo-data";
import { addDays, type ForecastOptions } from "@/lib/liquidity";
import { runStressTest, scenarioPresets, type StressOptions } from "@/lib/stress-test";
import { downloadBoardPack } from "@/lib/board-pack";
import { head } from "@/lib/head";

export const Route = createFileRoute("/stress-test")({
  head: head("CFO Stress-Test Cockpit", "CreditSight explainable liquidity stress scenarios, invoice evidence and downloadable management board pack."),
  component: StressTest,
});
const initial: StressOptions = { delayDays: 0, brokenPromises: 0, defaultCustomerId: "", openingCash: 5e6, weeklyOutflows: 8e6, minimumCash: 2e6 };
const topCustomers = [...customers].sort((a, b) => b.exposure - a.exposure);

function StressTest() {
  const [stress, setStress] = useState(initial);
  const [preset, setPreset] = useState("base");
  const [days, setDays] = useState(90);
  const [selected, setSelected] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const options: ForecastOptions = { asOf: forecastAsOf, days, scenario: "Base", promiseReliability: 90, extraDelay: 0 };
  const result = runStressTest(receivables, customers, options, stress);
  const defaultName = customers.find((c) => c.id === stress.defaultCustomerId)?.name ?? "None";
  const selectedInvoice = receivables.find((i) => i.id === selected);
  const customer = customers.find((c) => c.id === selectedInvoice?.customerId);
  const evidence = selectedInvoice ? result.stressed.filter((p) => p.invoiceId === selectedInvoice.id) : [];
  const end = addDays(forecastAsOf, days);
  const setNumber = (key: keyof StressOptions, value: string, max = 1e10) => setStress((s) => ({ ...s, [key]: Math.min(max, Math.max(0, Number(value) || 0)) }));
  const exportPack = async () => {
    setBusy(true); setError("");
    try { await downloadBoardPack(result, options, stress, defaultName); }
    catch { setError("The board pack could not be downloaded. Please try again."); }
    finally { setBusy(false); }
  };
  return <div className="space-y-6">
    <header className="flex flex-wrap items-start justify-between gap-4">
      <div><div className="mb-2 flex items-center gap-2 text-xs font-medium uppercase text-accent"><Activity className="h-4 w-4" /> Management decision lab</div><h1 className="text-2xl font-semibold">CFO Stress-Test Cockpit</h1><p className="mt-1 text-sm text-muted-foreground">Synthetic case study · 25 October 2026 · AED equivalent</p></div>
      <Button onClick={exportPack} disabled={busy}><Download />{busy ? "Preparing report…" : "Download board pack"}</Button>
    </header>
    {error && <p role="alert" className="text-destructive">{error}</p>}
    <section aria-label="Ready-made scenarios" className="border-y py-3">
      <div className="mb-2 flex items-center justify-between"><span className="text-xs font-medium uppercase text-muted-foreground">Ready-made scenarios</span><Button variant="ghost" size="sm" onClick={() => { setStress(initial); setPreset("base"); }}><RotateCcw />Reset</Button></div>
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
        {scenarioPresets.map((p) => (
          <button key={p.id} aria-pressed={preset === p.id} onClick={() => { setStress(p.apply(initial, topCustomers[0]?.id ?? "")); setPreset(p.id); }}
            className={"rounded-lg border bg-card p-3 text-left transition hover:border-accent " + (preset === p.id ? "border-accent ring-1 ring-accent" : "")}>
            <div className="text-sm font-semibold">{p.label}</div>
            <div className="mt-1 text-xs text-muted-foreground">{p.description}</div>
          </button>
        ))}
      </div>
    </section>
    <section aria-label="Stress assumptions" className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
      <label className="text-xs text-muted-foreground">Additional delay: <span className="font-mono text-foreground">{stress.delayDays} days</span><input aria-label="Stress delay" type="range" min={0} max={60} step={1} value={stress.delayDays} onChange={(e) => setNumber("delayDays", e.target.value, 60)} className="mt-3 block w-full accent-accent" /></label>
      <label className="text-xs text-muted-foreground">Broken promises: <span className="font-mono text-foreground">{stress.brokenPromises}%</span><input aria-label="Broken promises" type="range" min={0} max={100} step={5} value={stress.brokenPromises} onChange={(e) => setNumber("brokenPromises", e.target.value, 100)} className="mt-3 block w-full accent-accent" /></label>
      <label className="min-w-0 text-xs text-muted-foreground">Customer default<select aria-label="Customer default" value={stress.defaultCustomerId} onChange={(e) => setStress((s) => ({ ...s, defaultCustomerId: e.target.value }))} className="mt-2 h-9 w-full rounded-md border bg-background px-2 text-sm text-foreground"><option value="">None</option>{topCustomers.map((c) => <option key={c.id} value={c.id}>{c.name} · {c.id}</option>)}</select></label>
      <label className="text-xs text-muted-foreground">Horizon<select aria-label="Stress horizon" value={days} onChange={(e) => setDays(Number(e.target.value))} className="mt-2 block h-9 w-full rounded-md border bg-background px-2 text-sm text-foreground">{[30, 60, 90].map((d) => <option key={d} value={d}>{d} days</option>)}</select></label>
      {([['openingCash', 'Opening cash (AED)'], ['weeklyOutflows', 'Weekly outflows (AED)'], ['minimumCash', 'Minimum cash floor (AED)']] as const).map(([key, label]) => <label key={key} className="text-xs text-muted-foreground">{label}<input aria-label={label} type="number" min={0} max={1e10} step={100000} value={stress[key]} onChange={(e) => setNumber(key, e.target.value)} className="mt-2 h-9 w-full rounded-md border bg-background px-3 font-mono text-sm text-foreground" /></label>)}
      <div className="self-end text-xs leading-relaxed text-muted-foreground">Base scenario · 90% promise reliability<br />Cash assumptions are illustrative inputs.</div>
    </section>
    <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4"><Kpi label="Baseline receipts" value={fmtM(result.baseReceipts)} note={`${days}-day forecast`} /><Kpi label="Stressed receipts" value={fmtM(result.stressReceipts)} note={`${fmtM(result.baseReceipts - result.stressReceipts)} at risk`} /><Kpi label="Peak funding gap" value={fmtM(result.peakGap)} {...(result.peakGap > 0 ? { tone: "bad" as const } : {})} note={result.firstBreach ? `First weekly breach: ${result.firstBreach.start}` : "No weekly cash-floor breach"} /><Kpi label="Stressed closing cash" value={fmtM(result.closingCash)} {...(result.closingCash < 0 ? { tone: "bad" as const } : {})} note={`Minimum floor ${fmtM(stress.minimumCash)}`} /></div>
    <section className="border-y py-5"><div className="mb-4 flex flex-wrap items-center justify-between gap-3"><h2 className="font-semibold">Weekly closing cash · AED M</h2><div className="flex gap-4 text-xs"><span className="text-accent">Baseline</span><span className="text-destructive">Stressed</span><span className="text-muted-foreground">Dashed: minimum cash</span></div></div><div className="h-72 min-w-0 overflow-hidden"><ResponsiveContainer width="100%" height="100%"><LineChart data={result.stressWeeks.map((w, i) => ({ week: w.week, baseline: (result.baseWeeks[i]?.cash ?? 0) / 1e6, stressed: w.cash / 1e6 }))}><CartesianGrid stroke="var(--border)" strokeDasharray="3 3" vertical={false} /><XAxis dataKey="week" fontSize={12} /><YAxis width={45} fontSize={12} /><Tooltip formatter={(v: number) => `${v.toFixed(2)}M AED`} contentStyle={{ background: "var(--card)", borderColor: "var(--border)" }} /><ReferenceLine y={stress.minimumCash / 1e6} stroke="var(--muted-foreground)" strokeDasharray="5 5" /><Line dataKey="baseline" name="Baseline cash" stroke="var(--accent)" strokeWidth={2} dot={false} isAnimationActive={false} /><Line dataKey="stressed" name="Stressed cash" stroke="var(--destructive)" strokeWidth={3} dot={false} isAnimationActive={false} /></LineChart></ResponsiveContainer></div></section>
    <section><h2 className="mb-3 font-semibold">Management action priorities</h2>{result.priorities.length === 0 ? <p className="py-4 text-sm text-muted-foreground">No incremental receipts at risk. Select a stress assumption to compare against baseline.</p> : <Table head={["Customer", "Risk", "Receipts at risk", "Recommended action"]} right={[2]} rows={result.priorities.slice(0, 8).map((p) => [<Link to="/customers/$id" params={{ id: p.customer.id }} className="font-medium text-accent">{p.customer.name}</Link>, <RiskChip r={p.customer.rating} />, fmt(p.atRisk), p.customer.id === stress.defaultCustomerId ? "Credit review & funding contingency" : "Reconfirm promises & chase affected invoices"])} />}</section>
    <section><h2 className="mb-3 font-semibold">Invoice evidence & reconciliation</h2><Table head={["Invoice", "Basis", "Baseline date", "Stressed date", "Expected receipt", "Evidence"]} right={[4]} rows={result.stressed.map((p, i) => [p.invoiceId, p.source, result.baseline[i]?.date ?? "—", <span>{p.date}{p.date >= end && <span className="block text-xs text-muted-foreground">Beyond horizon</span>}</span>, fmt(p.expected), <Button variant="ghost" size="sm" aria-label={`Inspect ${p.invoiceId} ${p.source}`} onClick={() => setSelected(p.invoiceId)}><FileSearch />Inspect</Button>])} /></section>
    <details className="border-t py-3 text-xs leading-relaxed text-muted-foreground"><summary className="cursor-pointer font-medium text-foreground">Methodology & limitations</summary><div className="mt-3 space-y-2"><p>Rules-based estimates, not a trained AI model. Invoice due dates, DBT, customer risk and valid payment promises determine baseline receipts. Partial promises replace only their committed portion.</p><p>Broken promises reduce only promise-backed expected receipts with no recovery assumed during this horizon. Selected default means zero collections from that customer, not an ECL posting. Delay moves all dates; receipts beyond the horizon are excluded, not written off.</p><p>Weekly cash equals opening cash plus expected receipts minus operating outflows. Final-week outflows are prorated. Cash-floor breaches use weekly closing balances, not intraday cash. New sales, financing and actual collection accuracy are excluded. Mitigation assumes better collections and lower weekly outflows; it is not a guaranteed outcome.</p><Link to="/liquidity" className="inline-block text-accent">Detailed baseline assumptions →</Link></div></details>
    <Dialog open={selected !== null} onOpenChange={(open) => { if (!open) setSelected(null); }}><DialogContent className="max-h-[85vh] w-[calc(100%-2rem)] max-w-2xl overflow-y-auto"><DialogTitle>Invoice evidence · {selected}</DialogTitle><DialogDescription>{customer?.name} · Synthetic outstanding receivable</DialogDescription>{selectedInvoice && <div className="space-y-4 text-sm"><dl className="grid grid-cols-2 gap-3"><div><dt className="text-xs text-muted-foreground">Outstanding balance</dt><dd className="font-mono">{fmt(selectedInvoice.amount)}</dd></div><div><dt className="text-xs text-muted-foreground">Contractual due date</dt><dd>{selectedInvoice.dueDate}</dd></div><div><dt className="text-xs text-muted-foreground">Historical DBT / risk</dt><dd>{customer?.dbt} days · {customer?.rating}</dd></div><div><dt className="text-xs text-muted-foreground">Payment promise</dt><dd>{selectedInvoice.promise ? `${selectedInvoice.promise.date} · ${fmt(selectedInvoice.promise.amount)}` : "No promise recorded"}</dd></div></dl>{evidence.map((p) => <div key={p.source} className="border-t pt-3"><div className="font-medium">{p.source} · {p.date}</div><p className="mt-1 font-mono text-xs">{fmt(p.amount)} × {(p.probability * 100).toFixed(1)}% = {fmt(p.expected)}</p><p className="mt-1 text-xs text-muted-foreground">{p.source === "Promise" ? `Customer probability × 90% reliability × ${100 - stress.brokenPromises}% surviving promises.` : "Due date / overdue estimate plus historical DBT."} Additional delay: {stress.delayDays} days.{customer?.id === stress.defaultCustomerId ? " Selected customer default: probability set to 0%." : ""}</p></div>)}<p className="border-t pt-3 font-medium">Allocated principal: {fmt(evidence.reduce((s, p) => s + p.amount, 0))} / {fmt(selectedInvoice.amount)} outstanding.</p></div>}</DialogContent></Dialog>
  </div>;
}