import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel } from "@/components/app";
import { head } from "@/lib/head";

export const Route = createFileRoute("/import")({
  head: head("Data Import", "Upload CSV files with column mapping and validation."),
  component: Import,
});

const fields = ["customer_name", "invoice_number", "invoice_date", "due_date", "amount", "currency"];

function Import() {
  const [rows, setRows] = useState<string[][]>([]);
  const [map, setMap] = useState<Record<string, number>>({});
  const onFile = async (f?: File) => {
    if (!f) return;
    const r = (await f.text()).split(/\r?\n/).filter(Boolean).map((l) => l.split(",").map((x) => x.replace(/^"|"$/g, "").trim()));
    setRows(r);
    const m: Record<string, number> = {};
    fields.forEach((fl) => { const i = r[0]!.findIndex((h) => h.toLowerCase().replace(/\W/g, "").includes(fl.replace("_", "").slice(0, 6))); if (i >= 0) m[fl] = i; });
    setMap(m);
  };
  const body = rows.slice(1);
  const bad = body.filter((r) => map["amount"] === undefined || isNaN(+(r[map["amount"]] ?? "")));
  return (
    <>
      <PageHeader title="Data Import" sub="Demo: upload a CSV to see mapping and validation. Nothing is saved." />
      <Panel title="1 · Upload">
        <input type="file" accept=".csv" onChange={(e) => onFile(e.target.files?.[0])} className="text-sm" />
      </Panel>
      {rows.length > 0 && (
        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <Panel title="2 · Column mapping">
            {fields.map((f) => (
              <label key={f} className="flex items-center justify-between py-1 text-sm">{f}
                <select value={map[f] ?? ""} onChange={(e) => setMap({ ...map, [f]: +e.target.value })} className="rounded border bg-background px-2 py-1">
                  <option value="">— skip —</option>{rows[0]!.map((h, i) => <option key={i} value={i}>{h}</option>)}
                </select>
              </label>
            ))}
          </Panel>
          <Panel title="3 · Validation" className="lg:col-span-2">
            <div className="mb-3 flex gap-6 text-sm"><span>Rows: <b>{body.length}</b></span><span>Accepted: <b>{body.length - bad.length}</b></span><span className="text-destructive">Rejected (bad amount): <b>{bad.length}</b></span></div>
            <div className="overflow-auto"><table className="text-xs"><tbody>{rows.slice(0, 21).map((r, i) => <tr key={i} className={i ? "border-t" : "font-semibold"}>{r.map((c, j) => <td key={j} className="px-2 py-1">{c}</td>)}</tr>)}</tbody></table></div>
          </Panel>
        </div>
      )}
    </>
  );
}
