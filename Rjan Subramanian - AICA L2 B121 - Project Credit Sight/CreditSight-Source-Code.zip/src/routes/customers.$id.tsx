import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Kpi, PageHeader, Panel, RiskChip } from "@/components/app";
import { alerts, buckets, customers, fmt } from "@/lib/demo-data";

export const Route = createFileRoute("/customers/$id")({
  loader: ({ params }) => { const c = customers.find((x) => x.id === params.id); if (!c) throw notFound(); return c; },
  head: ({ loaderData }) => ({ meta: [
    { title: `${loaderData?.name ?? "Customer"} · CreditSight` },
    { name: "description", content: "Customer 360: exposure, aging, risk score breakdown and alerts." },
    { property: "og:title", content: `${loaderData?.name ?? "Customer"} · CreditSight` },
    { property: "og:description", content: "Customer 360 credit profile." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary" },
  ] }),
  component: Customer360,
});

function Customer360() {
  const c = Route.useLoaderData();
  const months = ["Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct"];
  const weakest = [...c.factors].sort((a, b) => a.points / a.weight - b.points / b.weight).slice(0, 2);
  return (
    <>
      <Link to="/customers" className="text-sm text-muted-foreground hover:text-accent">← Customers</Link>
      <PageHeader title={c.name} sub={`${c.id} · ${c.license} · ${c.country} · ${c.sector} · ${c.division} · ${c.terms}-day terms`}>
        <div className="flex items-center gap-2"><RiskChip r={c.rating} /><span className="rounded border px-2 py-0.5 text-xs">{c.status}</span></div>
      </PageHeader>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Kpi label="Credit limit" value={fmt(c.limit)} />
        <Kpi label="Exposure" value={fmt(c.exposure)} note={`${Math.round((c.exposure / c.limit) * 100)}% utilised`} {...(c.exposure > c.limit ? { tone: "bad" as const } : {})} />
        <Kpi label="Overdue" value={fmt(c.overdue)} {...(c.overdue ? { tone: "bad" as const } : {})} />
        <Kpi label="Avg days beyond terms" value={`${c.dbt}`} />
        <Kpi label="Risk score" value={`${c.score} / 100`} />
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Panel title="Score breakdown (how the score is built)">
          <table className="w-full text-sm">
            <thead className="text-xs text-muted-foreground"><tr><th className="text-left">Factor</th><th className="text-left">Input</th><th className="text-right">Points / weight</th></tr></thead>
            <tbody>{c.factors.map((f) => (
              <tr key={f.name} className="border-t"><td className="py-1.5">{f.name}</td><td>{f.value}</td><td className="num">{f.points} / {f.weight}</td></tr>
            ))}<tr className="border-t font-semibold"><td className="py-1.5">Total</td><td /><td className="num">{c.score} / 100</td></tr></tbody>
          </table>
          <p className="mt-3 text-xs text-muted-foreground">To improve: strengthen {weakest.map((w) => w.name.toLowerCase()).join(" and ")}.</p>
        </Panel>
        <Panel title="Aging">
          {buckets.map((b, i) => (
            <div key={b} className="flex items-center gap-3 py-1.5 text-sm">
              <span className="w-16">{b}</span>
              <div className="h-2 flex-1 rounded bg-muted"><div className={i ? "h-2 rounded bg-destructive" : "h-2 rounded bg-accent"} style={{ width: `${(c.aging[i]! / c.exposure) * 100}%` }} /></div>
              <span className="num w-36">{fmt(c.aging[i]!)}</span>
            </div>
          ))}
          <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
            <div>Current ratio <div className="font-mono text-sm">{c.currentRatio}</div></div>
            <div>Debt / equity <div className="font-mono text-sm">{c.debtEquity}</div></div>
            <div>EBITDA margin <div className="font-mono text-sm">{c.ebitdaMargin}%</div></div>
          </div>
        </Panel>
        <Panel title="Score trend (12 months)">
          <ResponsiveContainer width="100%" height={180}>
            <LineChart data={c.trend.map((v, i) => ({ m: months[i], v }))}><XAxis dataKey="m" fontSize={12} /><YAxis fontSize={12} domain={[0, 100]} /><Tooltip />
              <Line dataKey="v" stroke="var(--primary)" strokeWidth={2} dot={false} /></LineChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Alerts">
          {alerts.filter((a) => a.customer.id === c.id).map((a) => (
            <div key={a.id} className="flex justify-between border-b py-2 text-sm last:border-0"><span>{a.type} – {a.detail}</span><RiskChip r={a.severity} /></div>
          ))}
          {!alerts.some((a) => a.customer.id === c.id) && <p className="text-sm text-muted-foreground">No open alerts.</p>}
        </Panel>
      </div>
    </>
  );
}
