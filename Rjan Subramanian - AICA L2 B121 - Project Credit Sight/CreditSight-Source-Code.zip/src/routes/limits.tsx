import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel, RiskChip, Table } from "@/components/app";
import { customers, fmt } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/limits")({
  head: head("Credit Limits", "Limit calculator with net-worth, DSO-adjusted and score-based methods."),
  component: Limits,
});

const tier = (s: number) => (s >= 75 ? 1 : s >= 55 ? 0.6 : s >= 35 ? 0.3 : 0.1);

function Limits() {
  const [id, setId] = useState(customers[0]!.id);
  const c = customers.find((x) => x.id === id)!;
  const nw = c.netWorth * 0.1;
  const dso = (c.revenue / 12) * (c.terms / 30) * 1.2 * 0.15;
  const sb = c.revenue * 0.05 * tier(c.score);
  const rec = Math.round(Math.min(nw, dso, sb) / 50000) * 50000;
  const [log, setLog] = useState<string[]>([]);
  return (
    <>
      <PageHeader title="Credit Limits" sub="Recommended limit = lowest of three methods (conservative blend)" />
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="Limit calculator">
          <select value={id} onChange={(e) => setId(e.target.value)} className="mb-4 w-full rounded-md border bg-background px-3 py-2 text-sm">
            {customers.map((x) => <option key={x.id} value={x.id}>{x.name} ({x.id})</option>)}
          </select>
          {[["10% of net worth", nw, `Net worth ${fmt(c.netWorth)}`], ["DSO-adjusted exposure", dso, `Monthly sales × ${c.terms}/30 × 1.2 safety × 15% share`], ["Score-based tier", sb, `Score ${c.score} → ${tier(c.score) * 100}% of 5% revenue`]].map(([n, v, d]) => (
            <div key={n as string} className="flex justify-between border-b py-2 text-sm"><div>{n}<div className="text-xs text-muted-foreground">{d}</div></div><span className="num">{fmt(v as number)}</span></div>
          ))}
          <div className="mt-3 flex items-center justify-between"><span className="font-semibold">Recommended</span><span className="num text-lg font-semibold">{fmt(rec)}</span></div>
          <div className="mt-1 text-sm text-muted-foreground">Current approved: {fmt(c.limit)}</div>
          <button onClick={() => setLog([`${new Date().toLocaleString()} · Credit Manager · ${c.name}: ${fmt(c.limit)} → ${fmt(rec)} · reason: calculator recommendation`, ...log])}
            className="mt-4 rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground">Approve recommended limit</button>
        </Panel>
        <Panel title="Audit log">
          {log.length ? log.map((l) => <div key={l} className="border-b py-2 font-mono text-xs">{l}</div>) : <p className="text-sm text-muted-foreground">No changes this session.</p>}
        </Panel>
      </div>
      <h2 className="mb-2 mt-6 font-semibold">Utilisation</h2>
      <Table head={["Customer", "Limit", "Exposure", "Utilisation", "Rating"]} right={[1, 2, 3]}
        rows={[...customers].sort((a, b) => b.exposure / b.limit - a.exposure / a.limit).map((x) => [x.name, fmt(x.limit), fmt(x.exposure),
          <span className={x.exposure > x.limit ? "text-destructive" : ""}>{Math.round((x.exposure / x.limit) * 100)}%</span>, <RiskChip r={x.rating} />])} />
    </>
  );
}
