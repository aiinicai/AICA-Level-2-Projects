import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PageHeader, Panel, RiskChip } from "@/components/app";
import { countries, ratingOf, sectors } from "@/lib/demo-data";
import { scoreCredit, v13Countries, v13Sectors, type ScoreInput, type Sector } from "@/lib/credit-score";
import { head } from "@/lib/head";

export const Route = createFileRoute("/onboarding")({
  head: head("Onboarding & Scoring", "Transparent weighted scorecard for new credit applications."),
  component: Onboarding,
});

const inputCls = "mt-1 w-full rounded-md border bg-background px-3 py-2";

function ModelSwitch({ model, setModel }: { model: "v1.2" | "v1.3"; setModel: (m: "v1.2" | "v1.3") => void }) {
  return (
    <div className="mb-4 inline-flex rounded-md border p-1 text-sm">
      {(["v1.2", "v1.3"] as const).map((m) => (
        <button key={m} onClick={() => setModel(m)}
          className={`rounded px-4 py-1.5 font-medium transition-colors ${model === m ? "bg-accent text-accent-foreground" : "text-muted-foreground hover:text-foreground"}`}>
          Scorecard {m}
        </button>
      ))}
    </div>
  );
}

function Onboarding() {
  const [model, setModel] = useState<"v1.2" | "v1.3">("v1.3");
  return (
    <>
      <PageHeader title="Onboarding & Scoring" sub={`New application · scorecard model ${model} · every factor shown`} />
      <ModelSwitch model={model} setModel={setModel} />
      {model === "v1.2" ? <V12 /> : <V13 />}
      <DataSources />
    </>
  );
}

const sources = [
  { name: "Al Etihad Credit Bureau (AECB)", tag: "Paid · bureau",
    note: "Official UAE credit bureau; most authoritative source for business credit reports and scores. Access via membership/subscription, typically for regulated lenders." },
  { name: "Dun & Bradstreet / Creditsafe", tag: "Paid · provider",
    note: "Commercial business-information providers covering UAE companies with scores and financials; paid plans, sometimes with trial access and APIs." },
  { name: "UAE licence verification portals", tag: "Free · KYC",
    note: "Official portals (e.g. Dubai's economic department) confirm legal name, licence status and legal form — useful for KYC and the Legal name field, but no credit score." },
];

function DataSources() {
  return (
    <Panel title="External data sources (production)">
      <p className="mb-3 text-sm text-muted-foreground">
        This demo scores from manually entered inputs. In production, no free source returns a UAE company credit score by API, so the design assumes one of these feeds:
      </p>
      <div className="grid gap-3 md:grid-cols-3">
        {sources.map((s) => (
          <div key={s.name} className="rounded-md border p-3">
            <div className="mb-1 flex items-center justify-between gap-2">
              <span className="text-sm font-medium">{s.name}</span>
              <span className="shrink-0 rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">{s.tag}</span>
            </div>
            <p className="text-xs text-muted-foreground">{s.note}</p>
          </div>
        ))}
      </div>
    </Panel>
  );
}

function V12() {
  const [v, setV] = useState({ cr: 1.3, de: 1.1, eb: 9, dbt: 10, yrs: 6, sector: "Logistics", country: "UAE", adverse: false });
  const s = sectors.find((x) => x.name === v.sector)!; const c = countries.find((x) => x.name === v.country)!;
  const f = [
    ["Liquidity (current ratio)", 15, Math.min(15, v.cr * 8)], ["Leverage (debt/equity)", 15, Math.max(0, 15 - v.de * 5)],
    ["Profitability (EBITDA %)", 10, Math.min(10, v.eb / 1.5)], ["Payment history (DBT)", 25, Math.max(0, 25 - v.dbt * 0.4)],
    ["Years trading", 10, Math.min(10, v.yrs / 1.5)], ["Sector risk", 10, 10 - s.risk / 10], ["Country risk", 10, 10 - c.risk / 10], ["Adverse flags", 5, v.adverse ? 0 : 5],
  ] as [string, number, number][];
  const score = Math.round(f.reduce((a, x) => a + x[2], 0));
  const num = (k: keyof typeof v, label: string, step = 0.1) => (
    <label className="block text-sm">{label}
      <input type="number" step={step} value={v[k] as number} onChange={(e) => setV({ ...v, [k]: +e.target.value })} className={`${inputCls} font-mono`} />
    </label>
  );
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Panel title="Application inputs">
        <div className="grid grid-cols-2 gap-3">
          <label className="col-span-2 block text-sm">Legal name<input defaultValue="Horizon Fleet Services LLC" className={inputCls} /></label>
          {num("cr", "Current ratio")}{num("de", "Debt / equity")}{num("eb", "EBITDA margin %", 0.5)}{num("dbt", "Days beyond terms (12m)", 1)}{num("yrs", "Years trading", 1)}
          <label className="block text-sm">Sector<select value={v.sector} onChange={(e) => setV({ ...v, sector: e.target.value })} className={inputCls}>{sectors.map((x) => <option key={x.name}>{x.name}</option>)}</select></label>
          <label className="block text-sm">Country<select value={v.country} onChange={(e) => setV({ ...v, country: e.target.value })} className={inputCls}>{countries.map((x) => <option key={x.name}>{x.name}</option>)}</select></label>
          <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={v.adverse} onChange={(e) => setV({ ...v, adverse: e.target.checked })} /> Litigation / ownership change</label>
        </div>
        <div className="mt-4 rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">Drop trade license, financials, bank reference, KYC here (demo only)</div>
      </Panel>
      <Panel title="Result">
        <div className="mb-4 flex items-center gap-4"><div className="font-mono text-5xl font-semibold">{score}</div><RiskChip r={ratingOf(score)} /></div>
        {f.map(([n, w, p]) => (
          <div key={n} className="flex items-center gap-3 py-1 text-sm">
            <span className="w-52">{n}</span>
            <div className="h-2 flex-1 rounded bg-muted"><div className="h-2 rounded bg-accent" style={{ width: `${(p / w) * 100}%` }} /></div>
            <span className="num w-20">{p.toFixed(1)} / {w}</span>
          </div>
        ))}
        <p className="mt-4 text-xs text-muted-foreground">Bands: 75+ Low · 55–74 Medium · 35–54 High · below 35 Critical.</p>
      </Panel>
    </div>
  );
}

function V13() {
  const [v, setV] = useState({
    cr: 1.3, de: 1.1, eb: 9, dbt: 10, yrs: 6,
    sector: "Logistics" as Sector, country: "AE", adverse: false,
    equity: "", cheques: "",
  });
  const input: ScoreInput = useMemo(() => ({
    currentRatio: v.cr, debtToEquity: v.de, ebitdaMarginPct: v.eb,
    daysBeyondTerms12m: v.dbt, yearsTrading: v.yrs,
    sector: v.sector, country: v.country, litigationOrOwnershipChange: v.adverse,
    ...(v.equity !== "" ? { equity: +v.equity } : {}),
    ...(v.cheques !== "" ? { bouncedCheques12m: +v.cheques } : {}),
  }), [v]);
  const result = useMemo(() => scoreCredit(input), [input]);
  const r = result;
  const num = (k: "cr" | "de" | "eb" | "dbt" | "yrs", label: string, step = 0.1) => (
    <label className="block text-sm">{label}
      <input type="number" step={step} value={v[k]} onChange={(e) => setV({ ...v, [k]: +e.target.value })} className={`${inputCls} font-mono`} />
    </label>
  );
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Panel title="Application inputs">
        <div className="grid grid-cols-2 gap-3">
          <label className="col-span-2 block text-sm">Legal name<input defaultValue="Horizon Fleet Services LLC" className={inputCls} /></label>
          {num("cr", "Current ratio")}{num("de", "Debt / equity")}{num("eb", "EBITDA margin %", 0.5)}{num("dbt", "Days beyond terms (12m)", 1)}{num("yrs", "Years trading", 1)}
          <label className="block text-sm">Sector<select value={v.sector} onChange={(e) => setV({ ...v, sector: e.target.value as Sector })} className={inputCls}>{v13Sectors.map((x) => <option key={x}>{x}</option>)}</select></label>
          <label className="block text-sm">Country<select value={v.country} onChange={(e) => setV({ ...v, country: e.target.value })} className={inputCls}>{v13Countries.map((x) => <option key={x.code} value={x.code}>{x.name}</option>)}</select></label>
          <label className="block text-sm">Equity (optional, AED)<input type="number" value={v.equity} placeholder="Leave blank if unknown" onChange={(e) => setV({ ...v, equity: e.target.value })} className={`${inputCls} font-mono`} /></label>
          <label className="block text-sm">Bounced cheques, 12m (optional)<input type="number" value={v.cheques} placeholder="Leave blank if unknown" onChange={(e) => setV({ ...v, cheques: e.target.value })} className={`${inputCls} font-mono`} /></label>
          <label className="col-span-2 flex items-center gap-2 text-sm"><input type="checkbox" checked={v.adverse} onChange={(e) => setV({ ...v, adverse: e.target.checked })} /> Litigation / ownership change</label>
        </div>
        <div className="mt-4 rounded-md border border-dashed p-4 text-center text-sm text-muted-foreground">Drop trade license, financials, bank reference, KYC here (demo only)</div>
      </Panel>
      <Panel title="Result">
        <div className="mb-1 flex items-center gap-4">
          <div className="font-mono text-5xl font-semibold">{r.score}</div>
          <RiskChip r={r.band as "Low" | "Medium" | "High" | "Critical"} />
          <span className="ml-auto rounded-full border px-3 py-1 text-xs text-muted-foreground">
            {Math.round(result.confidence * 100)}% data coverage
          </span>
        </div>
        <p className="mb-4 rounded-md border bg-muted/40 px-3 py-2 text-sm"><span className="font-medium">Recommended action:</span> {r.action}</p>
        {r.overrides.length > 0 && (
          <div className="mb-4 rounded-md border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm">
            <div className="mb-1 font-medium">Knock-out overrides applied</div>
            <ul className="list-inside list-disc text-muted-foreground">{r.overrides.map((o) => <li key={o}>{o}</li>)}</ul>
          </div>
        )}
        {r.factors.map((f) => (
          <div key={f.key} className="flex items-center gap-3 py-1 text-sm">
            <span className="w-52">{f.label}</span>
            <div className="h-2 flex-1 rounded bg-muted">
              {f.points !== null && <div className="h-2 rounded bg-accent" style={{ width: `${(f.points / f.max) * 100}%` }} />}
            </div>
            <span className="num w-28 text-right">{f.points === null ? "n/a" : `${f.points.toFixed(1)} / ${f.max}`}</span>
          </div>
        ))}
        <p className="mt-4 text-xs text-muted-foreground">
          v1.3 uses interpolated scoring curves; missing inputs are excluded and the score is rescaled over the data provided
          {r.rawScore !== r.score ? ` · raw score ${r.rawScore} before overrides` : ""}. Bands: 75+ Low · 55–74 Medium · 35–54 High · below 35 Critical.
        </p>
      </Panel>
    </div>
  );
}
