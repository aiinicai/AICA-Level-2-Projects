import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Cell, Pie, PieChart } from "recharts";
import { Kpi, Panel, RiskChip } from "@/components/app";
import { PortfolioWelcome } from "@/components/portfolio-welcome";
import { alerts, buckets, customers, divisions, eclRates, fmt, fmtM, monthly, totals } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/dashboard")({
  head: head("Credit & Receivables Overview", "CreditSight portfolio intelligence: credit exposure, receivables aging, customer risk and early-warning alerts in one clear view."),
  component: Dashboard,
});

const bucketColors = ["var(--chart-2)", "var(--chart-1)", "var(--chart-3)", "var(--chart-4)", "var(--chart-5)"];
const riskColors = ["var(--risk-low)", "var(--risk-medium)", "var(--risk-high)", "var(--risk-critical)"];

function Dashboard() {
  const ecl = totals.aging.reduce((a, v, i) => a + v * (eclRates[i] ?? 0), 0);
  const mix = (["Low", "Medium", "High", "Critical"] as const).map((r) => ({ r, n: customers.filter((c) => c.rating === r).length }));
  const top = [...customers].sort((a, b) => b.exposure - a.exposure).slice(0, 8);
  return (
    <>
      <PortfolioWelcome />
      <Link to="/stress-test" className="mb-5 flex items-center justify-between gap-3 border-y py-3 text-sm font-medium text-accent"><span>CFO decision lab · Stress scenarios & management board pack</span><span aria-hidden="true">→</span></Link>
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-5">
        <Kpi label="Total exposure" value={fmtM(totals.exposure)} note={`${customers.length} customers`} />
        <Kpi label="Approved limits" value={fmtM(totals.limit)} note={`${Math.round((totals.exposure / totals.limit) * 100)}% utilised`} />
        <Kpi label="Overdue" value={fmtM(totals.overdue)} tone="bad" note={`${Math.round((totals.overdue / totals.exposure) * 100)}% of exposure`} />
        <Kpi label="DSO" value={`${monthly.at(-1)?.dso ?? 0} days`} note="Days sales outstanding" />
        <Kpi label="ECL provision" value={fmtM(ecl)} note="Simplified matrix" />
      </div>
      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel title="Aging profile (AED M)" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={buckets.map((b, i) => ({ b, v: +((totals.aging[i] ?? 0) / 1e6).toFixed(1) }))}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="b" fontSize={12} /><YAxis fontSize={12} /><Tooltip />
              <Bar dataKey="v" name="Balance (AED M)" radius={[4, 4, 0, 0]} maxBarSize={70} isAnimationActive={false}>{buckets.map((_, i) => <Cell key={i} fill={bucketColors[i]} />)}</Bar>
            </BarChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Risk mix">
          <div className="relative mx-auto h-36 max-w-60">
            <ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={mix} dataKey="n" nameKey="r" innerRadius={48} outerRadius={65} paddingAngle={3} stroke="none" isAnimationActive={false}>{mix.map((m, i) => <Cell key={m.r} fill={riskColors[i]} />)}</Pie><Tooltip /></PieChart></ResponsiveContainer>
            <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center"><span className="font-mono text-2xl font-semibold">{customers.length}</span><span className="text-xs text-muted-foreground">customers</span></div>
          </div>
          <div className="grid grid-cols-2 gap-x-4 gap-y-2">
            {mix.map((m) => (
              <div key={m.r} className="flex items-center gap-3">
                <div className="w-20"><RiskChip r={m.r} /></div>
                <div className="w-8 text-right font-mono">{m.n}</div>
              </div>
            ))}
          </div>
        </Panel>
        <Panel title="DSO trend (days)" className="lg:col-span-2">
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthly}><CartesianGrid strokeDasharray="3 3" stroke="var(--border)" /><XAxis dataKey="month" fontSize={12} /><YAxis fontSize={12} domain={["auto", "auto"]} /><Tooltip />
              <Line dataKey="dso" stroke="var(--accent)" strokeWidth={2} dot={false} isAnimationActive={false} /></LineChart>
          </ResponsiveContainer>
        </Panel>
        <Panel title="Exposure by division">
          {divisions.map((d) => { const v = customers.filter((c) => c.division === d).reduce((a, c) => a + c.exposure, 0); return (
            <div key={d} className="flex justify-between border-b py-2 text-sm last:border-0"><span>{d}</span><span className="num">{fmtM(v)}</span></div>); })}
        </Panel>
        <Panel title="Top exposures" className="lg:col-span-2">
          {top.map((c) => (
            <Link key={c.id} to="/customers/$id" params={{ id: c.id }} className="flex items-center justify-between border-b py-2 text-sm last:border-0 hover:text-accent">
              <span>{c.name} <span className="text-muted-foreground">· {c.country}</span></span>
              <span className="flex items-center gap-3"><span className="num">{fmt(c.exposure)}</span><RiskChip r={c.rating} /></span>
            </Link>
          ))}
        </Panel>
        <Panel title={`Open alerts (${alerts.length})`}>
          {alerts.slice(0, 7).map((a) => (
            <div key={a.id} className="flex items-center justify-between border-b py-2 text-sm last:border-0">
              <span className="truncate">{a.type} · <span className="text-muted-foreground">{a.customer.name}</span></span><RiskChip r={a.severity} />
            </div>
          ))}
        </Panel>
      </div>
    </>
  );
}
