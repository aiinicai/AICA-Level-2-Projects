import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { createThread, readThreads, writeThreads } from "@/lib/chat-history";
import { head } from "@/lib/head";

export const Route = createFileRoute("/chat/")({
  head: head(
    "Portfolio Assistant",
    "Ask CreditSight about portfolio risk, customers and cash flow.",
  ),
  component: ChatStart,
});
function ChatStart() {
  const navigate = useNavigate();
  const [error, setError] = useState("");
  useEffect(() => {
    try {
      let threads = readThreads();
      if (!threads.length) {
        threads = [createThread()];
        writeThreads(threads);
      }
      const first = threads[0];
      if (first)
        void navigate({ to: "/chat/$threadId", params: { threadId: first.id }, replace: true });
    } catch {
      setError("Browser storage is unavailable. Enable it to save conversations.");
    }
  }, [navigate]);
  return (
    <p role="status" className="text-muted-foreground">
      {error || "Opening conversation…"}
    </p>
  );
}
