import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { handlePortfolioChat } = await import("@/lib/portfolio-chat.server");
        return handlePortfolioChat(request);
      },
    },
  },
});
