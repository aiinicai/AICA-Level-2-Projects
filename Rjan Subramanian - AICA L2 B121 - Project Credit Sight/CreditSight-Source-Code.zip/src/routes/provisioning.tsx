import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Kpi, PageHeader, Table } from "@/components/app";
import { buckets, eclRates, fmt, totals } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/provisioning")({
  head: head("Provisioning (ECL)", "IFRS 9 simplified provision matrix by aging bucket."),
  component: Provisioning,
});

function Provisioning() {
  const [rates, setRates] = useState(eclRates.map((r) => r * 100));
  const [fl, setFl] = useState(10);
  const ecl = totals.aging.map((v, i) => v * (rates[i]! / 100) * (1 + fl / 100));
  const sum = ecl.reduce((a, b) => a + b, 0);
  return (
    <>
      <PageHeader title="Provisioning (ECL)" sub="IFRS 9 simplified approach · loss rates editable · forward-looking overlay" />
      <div className="mb-4 grid grid-cols-3 gap-4">
        <Kpi label="Gross receivables" value={fmt(totals.exposure)} />
        <Kpi label="ECL provision" value={fmt(sum)} tone="bad" />
        <Kpi label="Coverage" value={`${((sum / totals.exposure) * 100).toFixed(2)}%`} />
      </div>
      <label className="mb-4 flex items-center gap-3 text-sm">Forward-looking overlay
        <input type="range" min={0} max={50} value={fl} onChange={(e) => setFl(+e.target.value)} /> <span className="font-mono">+{fl}%</span>
      </label>
      <Table head={["Bucket", "Balance", "Loss rate %", "ECL"]} right={[1, 2, 3]}
        rows={buckets.map((b, i) => [b, fmt(totals.aging[i]!),
          <input type="number" step={0.1} value={rates[i]} onChange={(e) => setRates(rates.map((r, j) => (j === i ? +e.target.value : r)))} className="w-20 rounded border bg-background px-2 py-1 text-right" />,
          fmt(ecl[i]!)])} />
    </>
  );
}
