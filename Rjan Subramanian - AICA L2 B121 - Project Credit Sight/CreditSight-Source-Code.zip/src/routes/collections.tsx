import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { PageHeader, Panel, RiskChip, Table } from "@/components/app";
import { customers, fmt } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/collections")({
  head: head("Collections", "Overdue worklist with collection actions and promises to pay."),
  component: Collections,
});

function Collections() {
  const work = customers.filter((c) => c.overdue > 0).sort((a, b) => b.overdue - a.overdue);
  const [sel, setSel] = useState(work[0]?.id);
  const [actions, setActions] = useState<{ c: string; t: string }[]>([
    { c: work[0]?.name ?? "", t: "Call · promised AED 250,000 by 31 Oct" }, { c: work[1]?.name ?? "", t: "Email reminder sent, statement attached" },
  ]);
  const [note, setNote] = useState("");
  return (
    <>
      <PageHeader title="Collections" sub={`${work.length} accounts with overdue balances, prioritised by amount`} />
      <div className="grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Table head={["Customer", "Overdue", "90+", "DBT", "Rating", ""]} right={[1, 2, 3]}
            rows={work.map((c) => [c.name, <span className="text-destructive">{fmt(c.overdue)}</span>, fmt(c.aging[4]!), c.dbt, <RiskChip r={c.rating} />,
              <button onClick={() => setSel(c.id)} className="text-xs text-accent">Log action</button>])} />
        </div>
        <Panel title="Log action">
          <div className="mb-2 text-sm font-medium">{customers.find((c) => c.id === sel)?.name}</div>
          <textarea value={note} onChange={(e) => setNote(e.target.value)} placeholder="Call outcome, promise to pay amount and date…" className="h-24 w-full rounded-md border bg-background p-2 text-sm" />
          <button onClick={() => { if (note) { setActions([{ c: customers.find((c) => c.id === sel)!.name, t: note }, ...actions]); setNote(""); } }}
            className="mt-2 rounded-md bg-primary px-4 py-2 text-sm text-primary-foreground">Save</button>
          <div className="mt-4 space-y-2">{actions.map((a, i) => <div key={i} className="border-b pb-2 text-sm"><div className="font-medium">{a.c}</div><div className="text-muted-foreground">{a.t}</div></div>)}</div>
        </Panel>
      </div>
    </>
  );
}
