import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Activity, Bell, ClipboardCheck, Globe2, HandCoins, ShieldCheck, ShoppingCart, TrendingUp, UserPlus, Users } from "lucide-react";
import { Cell, Pie, PieChart, Area, AreaChart, ResponsiveContainer } from "recharts";
import { Button } from "@/components/ui/button";
import { alerts, countries, customers, divisions, fmtM, monthly, totals } from "@/lib/demo-data";
import { head } from "@/lib/head";
import logo from "@/assets/logo.png";
import skyline from "@/assets/creditsight-skyline.jpg";

export const Route = createFileRoute("/")({
  head: head("CreditSight — Explainable Credit Risk & Liquidity Intelligence", "See credit exposure, overdue risk, liquidity forecasts and CFO stress tests at a glance with CreditSight."),
  component: Cover,
});

const riskColors = ["var(--risk-low)", "var(--risk-medium)", "var(--risk-high)", "var(--risk-critical)"];

function Cover() {
  const util = Math.round((totals.exposure / totals.limit) * 100);
  const overduePct = Math.round((totals.overdue / totals.exposure) * 100);
  const mix = (["Low", "Medium", "High", "Critical"] as const).map((r) => ({ r, n: customers.filter((c) => c.rating === r).length }));
  const dso = monthly.at(-1)?.dso ?? 0;
  const modules = [
    { icon: Users, t: "Customer 360", d: "Scorecards, limits and aging per customer" },
    { icon: TrendingUp, t: "Liquidity forecast", d: "Receipts from due dates & promises to pay" },
    { icon: Activity, t: "CFO stress test", d: "Delays, defaults and funding gaps" },
    { icon: Bell, t: "Early warnings", d: `${alerts.length} live alerts across the portfolio` },
  ];
  return (
    <main className="relative min-h-screen overflow-hidden bg-background text-foreground">
      <img src={skyline} alt="" className="absolute inset-0 h-full w-full object-cover opacity-30" />
      <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/90 to-background" />
      <div className="relative mx-auto flex min-h-screen max-w-6xl flex-col px-5 py-6 md:px-8">
        <header className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3"><img src={logo} alt="CreditSight logo" width={48} height={48} className="size-12 shrink-0 rounded-md border border-border bg-brand-surface p-1" /><span className="font-display text-3xl font-semibold text-foreground">CreditSight</span></div>
          <span className="rounded border border-border bg-card px-2 py-1 text-xs text-cover-copy">DEMO PORTFOLIO · AED</span>
        </header>

        <section className="mt-12 grid items-center gap-10 lg:mt-20 lg:grid-cols-2">
          <div>
            <p className="flex items-center gap-3 text-xl font-semibold leading-snug text-welcome-accent"><ShieldCheck className="size-6 shrink-0" /><span>Credit & receivables intelligence</span></p>
            <h1 className="mt-3 text-4xl font-semibold leading-tight md:text-6xl">See risk before it becomes a cash gap.</h1>
            <p className="mt-4 max-w-lg text-lg font-semibold leading-relaxed text-cover-copy md:text-xl">Explainable credit scoring, predictive liquidity and CFO stress testing — one cockpit for finance teams across {countries.length} countries.</p>
            <p className="mt-7 text-lg font-semibold text-welcome-accent md:text-xl">Ready to explore? Step inside your live portfolio.</p>
            <div className="mt-4 flex flex-wrap gap-3">
              <Button asChild size="lg" className="px-7 py-6 text-lg font-semibold"><Link to="/dashboard">Enter dashboard <ArrowRight className="size-5" /></Link></Button>
              <Button asChild size="lg" variant="outline" className="px-7 py-6 text-lg font-semibold"><Link to="/stress-test">Run a stress test</Link></Button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Stat label="Total exposure" value={fmtM(totals.exposure)} sub={`${customers.length} customers · ${divisions.length} divisions`} />
            <Ring label="Limit utilised" pct={util} />
            <Ring label="Overdue share" pct={overduePct} bad />
            <div className="rounded-xl border bg-card p-4">
              <p className="text-xs text-muted-foreground">Risk mix</p>
              <div className="h-24"><ResponsiveContainer><PieChart><Pie data={mix} dataKey="n" innerRadius={26} outerRadius={42} stroke="none" isAnimationActive={false}>{mix.map((_, i) => <Cell key={i} fill={riskColors[i]} />)}</Pie></PieChart></ResponsiveContainer></div>
              <p className="text-center text-xs text-muted-foreground">{mix.map((m) => `${m.r[0]} ${m.n}`).join(" · ")}</p>
            </div>
            <div className="col-span-2 rounded-xl border bg-card p-4">
              <div className="flex items-baseline justify-between"><p className="text-xs text-muted-foreground">DSO trend · 12 months</p><p className="font-mono text-lg">{dso} days</p></div>
              <div className="h-20"><ResponsiveContainer><AreaChart data={monthly}><Area dataKey="dso" stroke="var(--accent)" fill="var(--accent)" fillOpacity={0.2} isAnimationActive={false} /></AreaChart></ResponsiveContainer></div>
            </div>
          </div>
        </section>

        <FlowStrip />

        <section className="mt-12 grid gap-3 pb-8 sm:grid-cols-2 lg:mt-auto lg:grid-cols-4">
          {modules.map((m) => (
            <div key={m.t} className="rounded-xl border bg-card p-4"><m.icon className="size-5 text-accent" /><p className="mt-2 font-medium">{m.t}</p><p className="text-sm text-muted-foreground">{m.d}</p></div>
          ))}
        </section>
        <p className="flex items-center gap-1 pb-2 text-xs text-muted-foreground"><Globe2 className="size-3" /> Prototype using synthetic data — not financial advice.</p>
      </div>
    </main>
  );
}

const flowSteps = [
  { icon: UserPlus, t: "Customer", d: "Onboard & verify" },
  { icon: ClipboardCheck, t: "Credit", d: "Score & set limits" },
  { icon: ShoppingCart, t: "Sales", d: "Invoice on terms" },
  { icon: TrendingUp, t: "Liquidity forecast", d: "Cash position ahead" },
  { icon: HandCoins, t: "Collection", d: "Receipts & promises" },
];

function FlowStrip() {
  return (
    <section className="mt-12 rounded-xl border bg-card p-5">
      <p className="text-xs uppercase tracking-wide text-muted-foreground">Order to cash, end to end</p>
      <div className="relative mt-5">
        <div className="absolute left-[8%] right-[8%] top-6 hidden h-px bg-border md:block" />
        <div className="cs-flow-dot absolute top-6 hidden size-2 -translate-y-1/2 rounded-full bg-accent md:block" />
        <div className="grid gap-4 md:grid-cols-5">
          {flowSteps.map((s, i) => (
            <div key={s.t} className="cs-flow-step relative flex items-center gap-3 md:flex-col md:text-center" style={{ animationDelay: `${0.15 + i * 0.18}s` }}>
              <div className="cs-flow-node z-10 flex size-12 shrink-0 items-center justify-center rounded-full border bg-background" style={{ animationDelay: `${1.0 + i * 0.95}s` }}><s.icon className="cs-flow-icon size-5 text-accent" style={{ animationDelay: `${1.0 + i * 0.95}s` }} /></div>
              <div><p className="cs-flow-label text-sm font-medium" style={{ animationDelay: `${1.0 + i * 0.95}s` }}>{i + 1}. {s.t}</p><p className="text-xs text-muted-foreground">{s.d}</p></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function Stat({ label, value, sub }: { label: string; value: string; sub: string }) {
  return <div className="rounded-xl border bg-card p-4"><p className="text-xs text-muted-foreground">{label}</p><p className="mt-2 font-mono text-2xl font-semibold">{value}</p><p className="mt-1 text-xs text-muted-foreground">{sub}</p></div>;
}

function Ring({ label, pct, bad }: { label: string; pct: number; bad?: boolean }) {
  const c = 2 * Math.PI * 30;
  return (
    <div className="flex items-center gap-3 rounded-xl border bg-card p-4">
      <svg viewBox="0 0 72 72" className="size-16 shrink-0 -rotate-90"><circle cx="36" cy="36" r="30" fill="none" stroke="var(--border)" strokeWidth="7" /><circle cx="36" cy="36" r="30" fill="none" stroke={bad ? "var(--risk-high)" : "var(--accent)"} strokeWidth="7" strokeLinecap="round" strokeDasharray={`${(pct / 100) * c} ${c}`} /></svg>
      <div><p className="font-mono text-xl font-semibold">{pct}%</p><p className="text-xs text-muted-foreground">{label}</p></div>
    </div>
  );
}
