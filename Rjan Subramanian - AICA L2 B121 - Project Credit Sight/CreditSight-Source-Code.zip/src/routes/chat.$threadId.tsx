import { createFileRoute } from "@tanstack/react-router";
import { PortfolioChat } from "@/components/portfolio-chat";
import { head } from "@/lib/head";
export const Route = createFileRoute("/chat/$threadId")({
  head: head(
    "Portfolio Conversation",
    "Personalized CreditSight conversations about customers, credit exposure and liquidity.",
  ),
  component: ChatPage,
});
function ChatPage() {
  const { threadId } = Route.useParams();
  return <PortfolioChat key={threadId} threadId={threadId} />;
}
