import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { exportCsv, PageHeader, RiskChip, Table } from "@/components/app";
import { customers, divisions, fmt } from "@/lib/demo-data";
import { head } from "@/lib/head";

export const Route = createFileRoute("/customers/")({
  head: head("Customers", "Search and filter all credit customers by division, country and risk rating."),
  component: Customers,
});

type Key = "name" | "exposure" | "overdue" | "score" | "dbt";

function Customers() {
  const [q, setQ] = useState(""); const [div, setDiv] = useState(""); const [rating, setRating] = useState("");
  const [sort, setSort] = useState<Key>("exposure");
  const list = useMemo(() => customers
    .filter((c) => (c.name + c.license + c.country).toLowerCase().includes(q.toLowerCase()) && (!div || c.division === div) && (!rating || c.rating === rating))
    .sort((a, b) => sort === "name" ? a.name.localeCompare(b.name) : (b[sort] as number) - (a[sort] as number)), [q, div, rating, sort]);
  const sel = "rounded-md border bg-card px-3 py-2 text-sm";
  return (
    <>
      <PageHeader title="Customers" sub={`${list.length} of ${customers.length} customers`}>
        <button className={sel} onClick={() => exportCsv("customers.csv", ["ID", "Name", "Country", "Division", "Limit", "Exposure", "Overdue", "Score", "Rating"],
          list.map((c) => [c.id, c.name, c.country, c.division, c.limit, c.exposure, c.overdue, c.score, c.rating]))}>Export CSV</button>
      </PageHeader>
      <div className="mb-4 flex flex-wrap gap-2">
        <input className={sel + " w-72"} placeholder="Search name, license, country…" value={q} onChange={(e) => setQ(e.target.value)} />
        <select className={sel} value={div} onChange={(e) => setDiv(e.target.value)}><option value="">All divisions</option>{divisions.map((d) => <option key={d}>{d}</option>)}</select>
        <select className={sel} value={rating} onChange={(e) => setRating(e.target.value)}><option value="">All ratings</option>{["Low", "Medium", "High", "Critical"].map((d) => <option key={d}>{d}</option>)}</select>
        <select className={sel} value={sort} onChange={(e) => setSort(e.target.value as Key)}>
          <option value="exposure">Sort: exposure</option><option value="overdue">Sort: overdue</option><option value="score">Sort: score</option><option value="dbt">Sort: days late</option><option value="name">Sort: name</option>
        </select>
      </div>
      <Table head={["Customer", "Country", "Division", "Sector", "Limit", "Exposure", "Overdue", "DBT", "Score", "Rating", "Status"]} right={[4, 5, 6, 7, 8]}
        rows={list.map((c) => [
          <Link to="/customers/$id" params={{ id: c.id }} className="font-medium hover:text-accent">{c.name}<div className="text-xs text-muted-foreground">{c.id} · {c.license}</div></Link>,
          c.country, c.division, c.sector, fmt(c.limit), fmt(c.exposure),
          <span className={c.overdue > 0 ? "text-destructive" : ""}>{fmt(c.overdue)}</span>, c.dbt, c.score, <RiskChip r={c.rating} />, c.status,
        ])} />
    </>
  );
}
