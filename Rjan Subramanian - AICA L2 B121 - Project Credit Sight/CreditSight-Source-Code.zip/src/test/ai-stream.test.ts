import { describe, expect, it } from "vitest";
import { withLovableAiGatewayRunIdHeader } from "@/lib/ai/run-id";
import { isRequestAbort } from "@/lib/request-abort";

describe("AI stream cancellation", () => {
  it("recognises cross-realm cancellation without hiding other failures", () => {
    expect(isRequestAbort({ name: "AbortError" })).toBe(true);
    expect(isRequestAbort(new Error("aborted"))).toBe(true);
    expect(isRequestAbort(new Error("Provider unavailable"))).toBe(false);
  });
  it("handles a failed first read while waiting for gateway headers", async () => {
    const abort = new DOMException("This operation was aborted", "AbortError");
    const source = new ReadableStream({ start: (controller) => controller.error(abort) });
    let release: (value: string | undefined) => void = () => {};
    const ready = new Promise<string | undefined>((resolve) => {
      release = resolve;
    });
    const pending = withLovableAiGatewayRunIdHeader(new Response(source), {
      getRunId: () => undefined,
      waitForRunId: () => ready,
    });
    await new Promise((resolve) => setTimeout(resolve, 10));
    release(undefined);
    const response = await pending;
    await expect(response.text()).resolves.toBe("");
  });
});
