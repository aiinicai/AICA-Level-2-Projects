import { describe, expect, it } from "vitest";
import { cashPath, stressPayments } from "../lib/stress-test";
import type { Payment } from "../lib/liquidity";

const payment: Payment = { invoiceId: "I1", customerId: "C1", source: "Promise", date: "2026-10-26", amount: 1000, probability: 0.8, expected: 800 };
const stress = { delayDays: 0, brokenPromises: 0, defaultCustomerId: "", openingCash: 100, weeklyOutflows: 700, minimumCash: 200 };
describe("CFO stress-test accounting", () => {
  it("reduces promised receipts by the broken-promise share without duplicating balances", () => {
    const result = stressPayments([payment], { ...stress, brokenPromises: 50 });
    expect(result).toHaveLength(1);
    expect(result[0]?.amount).toBe(1000);
    expect(result[0]?.expected).toBe(400);
  });
  it("leaves due-date portions unaffected by broken promises", () => {
    expect(stressPayments([{ ...payment, source: "Due date" }], { ...stress, brokenPromises: 100 })[0]?.expected).toBe(800);
  });
  it("defaults only the selected customer", () => {
    const result = stressPayments([payment, { ...payment, customerId: "C2" }], { ...stress, defaultCustomerId: "C1" });
    expect(result.map((p) => p.expected)).toEqual([0, 800]);
  });
  it("moves delayed receipts outside a seven-day horizon", () => {
    const payments = stressPayments([payment], { ...stress, delayDays: 7 });
    const path = cashPath(payments, [], { asOf: "2026-10-25", days: 7, scenario: "Base", promiseReliability: 100, extraDelay: 0 }, stress);
    expect(path[0]?.expected).toBe(0);
    expect(path[0]?.cash).toBe(-600);
    expect(path[0]?.gap).toBe(800);
  });
  it("prorates outflows for a partial final week", () => {
    const path = cashPath([], [], { asOf: "2026-10-25", days: 10, scenario: "Base", promiseReliability: 100, extraDelay: 0 }, stress);
    expect(path.map((w) => w.outflow)).toEqual([700, 300]);
    expect(path.at(-1)?.cash).toBe(-900);
  });
});
import { scenarioPresets } from "@/lib/stress-test";
describe("scenario presets", () => {
  const base = { delayDays: 0, brokenPromises: 0, defaultCustomerId: "", openingCash: 5e6, weeklyOutflows: 8e6, minimumCash: 2e6 };
  const get = (id: string) => scenarioPresets.find((p) => p.id === id)!.apply(base, "C1");
  it("largest customer default targets the top customer", () => expect(get("default").defaultCustomerId).toBe("C1"));
  it("liquidity crunch raises outflows by 25%", () => expect(get("crunch").weeklyOutflows).toBe(10e6));
  it("regional slowdown delays 30 days with 40% broken promises", () => { expect(get("recession").delayDays).toBe(30); expect(get("recession").brokenPromises).toBe(40); });
});
