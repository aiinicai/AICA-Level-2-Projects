import { describe, expect, it } from "vitest";
import { scoreCredit } from "@/lib/credit-score";

const strong = {
  currentRatio: 2.0, debtToEquity: 0.5, ebitdaMarginPct: 20,
  daysBeyondTerms12m: 0, yearsTrading: 10, sector: "Utilities" as const,
  country: "AE", litigationOrOwnershipChange: false,
};

describe("scorecard v1.3", () => {
  it("gives a perfect profile 99 points with full confidence", () => {
    // AE country risk earns 9/10, so the maximum achievable is 99
    const r = scoreCredit(strong);
    expect(r.score).toBe(99);
    expect(r.band).toBe("Low");
    expect(r.confidence).toBe(1);
    expect(r.overrides).toEqual([]);
  });

  it("interpolates liquidity points between curve breakpoints", () => {
    // current ratio 1.1 sits halfway between (1.0, 5) and (1.2, 8) → 6.5
    const r = scoreCredit({ ...strong, currentRatio: 1.1 });
    const liq = r.factors.find((f) => f.key === "liquidity")!;
    expect(liq.points).toBe(6.5);
  });

  it("rescales over provided factors and reports confidence when data is missing", () => {
    // Only payment history (25) + flags (5) provided → confidence 0.30
    const r = scoreCredit({ daysBeyondTerms12m: 0, litigationOrOwnershipChange: false });
    expect(r.confidence).toBeCloseTo(0.3, 5);
    expect(r.score).toBe(100); // 30/30 earned rescales to 100
    expect(r.factors.filter((f) => f.points === null)).toHaveLength(6);
  });

  it("caps at Critical (34) on negative equity", () => {
    const r = scoreCredit({ ...strong, equity: -1 });
    expect(r.score).toBe(34);
    expect(r.band).toBe("Critical");
    expect(r.overrides).toContain("Negative equity → capped at Critical");
  });

  it("caps at Critical (34) on 3+ bounced cheques", () => {
    const r = scoreCredit({ ...strong, bouncedCheques12m: 3 });
    expect(r.score).toBe(34);
    expect(r.overrides).toContain("3+ bounced cheques in 12m → capped at Critical");
  });

  it("caps at High (54) on 90+ days beyond terms", () => {
    const r = scoreCredit({ ...strong, daysBeyondTerms12m: 90 });
    expect(r.score).toBe(54);
    expect(r.band).toBe("High");
  });

  it("caps at High (54) on litigation combined with DBT over 60", () => {
    const r = scoreCredit({ ...strong, litigationOrOwnershipChange: true, daysBeyondTerms12m: 61 });
    expect(r.score).toBe(54);
    expect(r.overrides).toContain("Litigation/ownership change with DBT > 60 → capped at High");
  });

  it("applies the country default for unlisted countries", () => {
    const r = scoreCredit({ ...strong, country: "EG" });
    const c = r.factors.find((f) => f.key === "country")!;
    expect(c.points).toBe(5);
  });
});
