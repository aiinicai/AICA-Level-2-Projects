import { beforeEach, describe, expect, it } from "vitest";
import { createThread, readThreads, updateThread, writeThreads } from "@/lib/chat-history";
import type { UIMessage } from "ai";

describe("browser conversations", () => {
  beforeEach(() => localStorage.clear());
  it("keeps conversations separate after saving and reading", () => {
    const messages: UIMessage[] = [{ id: "m1", role: "user", parts: [{ type: "text", text: "Review liquidity" }] }];
    writeThreads(updateThread([createThread("first"), createThread("second")], "first", messages));
    const threads = readThreads();
    expect(threads[0]?.messages).toEqual(messages);
    expect(threads[1]?.messages).toEqual([]);
    expect(threads[0]?.title).toBe("Review liquidity");
  });
});