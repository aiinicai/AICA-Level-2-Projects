import { describe, expect, it } from "vitest";
import { forecastWeeks, predictPayments, type ForecastOptions } from "../lib/liquidity";
import { customers, receivables, type Receivable } from "../lib/demo-data";

const options: ForecastOptions = { asOf: "2026-10-25", days: 30, scenario: "Base", promiseReliability: 100, extraDelay: 0 };
const accounts = [{ id: "C1", dbt: 4, rating: "Low" as const }];
const invoice: Receivable = { id: "I1", customerId: "C1", amount: 1000, dueDate: "2026-10-28" };
describe("Liquidity forecast", () => {
  it("forecasts payment from due date plus payment delay", () => {
    const [payment] = predictPayments([invoice], accounts, options);
    expect(payment?.date).toBe("2026-11-01");
    expect(payment?.expected).toBe(960);
  });
  it("uses promise date for the promised portion without double counting", () => {
    const payments = predictPayments([{ ...invoice, promise: { date: "2026-11-10", amount: 400 } }], accounts, options);
    expect(payments.find((p) => p.source === "Promise")?.date).toBe("2026-11-10");
    expect(payments.find((p) => p.source === "Due date")?.amount).toBe(600);
    expect(payments.reduce((s, p) => s + p.amount, 0)).toBe(1000);
  });
  it("does not count missed promises as future commitments", () => {
    const payments = predictPayments([{ ...invoice, promise: { date: "2026-10-24", amount: 1000 } }], accounts, options);
    expect(payments).toHaveLength(1);
    expect(payments[0]?.source).toBe("Due date");
  });
  it("applies promise reliability to the promised portion", () => {
    const payments = predictPayments([{ ...invoice, promise: { date: "2026-11-10", amount: 1000 } }], accounts, { ...options, promiseReliability: 50 });
    expect(payments[0]?.expected).toBe(480);
  });
  it("counts payments on weekly boundaries once and excludes beyond horizon", () => {
    const payments = predictPayments([{ ...invoice, dueDate: "2026-10-28" }, { ...invoice, id: "I2", dueDate: "2026-11-25" }], accounts, options);
    const weeks = forecastWeeks(payments, [invoice], options.asOf, 14);
    expect(weeks[0]?.expected).toBe(0);
    expect(weeks[1]?.expected).toBe(960);
    expect(weeks.at(-1)?.cumulative).toBe(960);
  });
  it("reconciles invoice balances to the portfolio", () => {
    for (const customer of customers) {
      expect(receivables.filter((i) => i.customerId === customer.id).reduce((s, i) => s + i.amount, 0)).toBe(customer.exposure);
    }
  });
});