import type { UIMessage } from "ai";

export type PortfolioThread = {
  id: string;
  title: string;
  updatedAt: string;
  messages: UIMessage[];
};
export const CHAT_STORAGE_KEY = "cs-portfolio-conversations";

export function readThreads(): PortfolioThread[] {
  if (typeof window === "undefined") return [];
  const raw = localStorage.getItem(CHAT_STORAGE_KEY);
  if (!raw) return [];
  const parsed: unknown = JSON.parse(raw);
  if (!Array.isArray(parsed)) throw new Error("Saved conversations could not be read.");
  return parsed.filter(
    (t): t is PortfolioThread =>
      typeof t?.id === "string" && typeof t?.title === "string" && Array.isArray(t?.messages),
  );
}

export function writeThreads(threads: PortfolioThread[]) {
  localStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(threads));
}

export function createThread(id: string = crypto.randomUUID()): PortfolioThread {
  return { id, title: "New conversation", updatedAt: new Date().toISOString(), messages: [] };
}

export function updateThread(threads: PortfolioThread[], id: string, messages: UIMessage[]) {
  const first = messages.find((m) => m.role === "user")?.parts.find((p) => p.type === "text");
  return threads.map((t) =>
    t.id === id
      ? {
          ...t,
          messages,
          title: first?.type === "text" ? first.text.slice(0, 65) : t.title,
          updatedAt: new Date().toISOString(),
        }
      : t,
  );
}
