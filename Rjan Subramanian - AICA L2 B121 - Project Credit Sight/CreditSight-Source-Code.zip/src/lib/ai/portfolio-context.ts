import {
  customers,
  alerts,
  totals,
  forecastAsOf,
  receivables,
  buckets,
  eclRates,
} from "../demo-data";
import { runStressTest, scenarioPresets } from "../stress-test";

export function portfolioContext() {
  const options = {
    asOf: forecastAsOf,
    days: 90,
    scenario: "Base" as const,
    promiseReliability: 90,
    extraDelay: 0,
  };
  const initial = {
    delayDays: 0,
    brokenPromises: 0,
    defaultCustomerId: "",
    openingCash: 5e6,
    weeklyOutflows: 8e6,
    minimumCash: 2e6,
  };
  const largest = [...customers].sort((a, b) => b.exposure - a.exposure)[0];
  const scenarios = scenarioPresets.map((preset) => {
    const assumptions = preset.apply(initial, largest?.id ?? "");
    const r = runStressTest(receivables, customers, options, assumptions);
    return {
      name: preset.label,
      assumptions,
      baselineReceipts: r.baseReceipts,
      stressedReceipts: r.stressReceipts,
      closingCash: r.closingCash,
      peakCashFloorGap: r.peakGap,
      firstBreach: r.firstBreach?.week ?? null,
      priorities: r.priorities
        .slice(0, 5)
        .map((p) => ({ customer: p.customer.name, atRisk: p.atRisk })),
    };
  });
  return JSON.stringify({
    asOf: forecastAsOf,
    currency: "AED",
    source: "Deterministic synthetic demonstration data, not live financial records",
    totals,
    customers,
    alerts: alerts.map((a) => ({
      id: a.id,
      customer: a.customer.name,
      type: a.type,
      severity: a.severity,
      detail: a.detail,
      status: a.status,
    })),
    agingBuckets: buckets,
    illustrativeEclRates: eclRates,
    forecastOptions: options,
    scenarios,
  });
}
