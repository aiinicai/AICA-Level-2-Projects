import { alerts, buckets, customers, forecastAsOf, totals } from "./demo-data";
import { createReport, money, millions, saveReport } from "./report-pdf";

export const portfolioReports = [
  { id: "aging", title: "Aging summary", description: "Portfolio receivables by overdue age", headers: ["Aging bucket", "Balance (AED)", "Portfolio share (%)"], right: [1, 2], rows: buckets.map((b, i) => [b, totals.aging[i] ?? 0, Number(((totals.aging[i] ?? 0) / totals.exposure * 100).toFixed(2))]) },
  { id: "aging-detail", title: "Customer aging detail", description: "Customer-level receivables and aging balances", headers: ["Customer", ...buckets.map((b) => `${b} (AED)`)], right: [1, 2, 3, 4, 5], rows: customers.map((c) => [c.name, ...c.aging]) },
  { id: "watchlist", title: "Credit watchlist", description: "High and Critical risk customers", headers: ["Customer", "Score", "Risk", "Exposure (AED)"], right: [1, 3], rows: customers.filter((c) => c.score < 55).map((c) => [c.name, c.score, c.rating, c.exposure]) },
  { id: "alerts", title: "Alert register", description: "Open risk alerts and accountable owners", headers: ["Date", "Customer", "Type", "Severity", "Owner"], right: [], rows: alerts.map((a) => [a.date, a.customer.name, a.type, a.severity, a.owner]) },
  { id: "utilisation", title: "Limit utilisation", description: "Credit capacity, exposure and utilisation", headers: ["Customer", "Limit (AED)", "Exposure (AED)", "Used (%)"], right: [1, 2, 3], rows: customers.map((c) => [c.name, c.limit, c.exposure, Number((c.exposure / c.limit * 100).toFixed(1))]) },
];
export type PortfolioReport = typeof portfolioReports[number];
export async function downloadPortfolioReport(report: PortfolioReport) {
  const r = await createReport(report.title, forecastAsOf, report.description);
  r.metrics([{ label: "Gross receivables", value: millions(totals.exposure), note: "AED equivalent" }, { label: "Overdue balance", value: millions(totals.overdue), note: `${(totals.overdue / totals.exposure * 100).toFixed(1)}% of portfolio` }, { label: "Report records", value: String(report.rows.length), note: "Synthetic portfolio" }], 50);
  let y = 94;
  if (report.id === "aging") { r.text("RECEIVABLES DISTRIBUTION / AED M", 16, y, 10, true); r.bars(buckets.map((label, i) => ({ label, value: totals.aging[i] ?? 0 })), y + 9); y = 179; }
  else y = r.paragraph(report.id === "watchlist" ? "Focus credit review on the highest-risk accounts. Risk scores and balances are illustrative; this register is not an approved credit decision." : "Source: deterministic CreditSight demonstration portfolio. Balances are expressed in AED equivalent; this report is not connected to a live ledger.", y, 178, 9) + 4;
  r.table(report.headers, report.rows.map((row) => row.map((v, i) => typeof v === "number" ? (report.headers[i]?.includes("AED") ? money(v) : String(v)) : v)), y, report.right);
  r.finish(); saveReport(r.pdf, `CreditSight-${report.id}-${forecastAsOf}.pdf`);
}