// credit-score.ts — scorecard v1.3 (weights match v1.2; breakpoints are placeholders to calibrate)

export type Sector =
  | "Utilities" | "Healthcare" | "Logistics" | "Manufacturing"
  | "Retail" | "Construction" | "Hospitality" | "Other";

export const v13Sectors: Sector[] = [
  "Utilities", "Healthcare", "Logistics", "Manufacturing",
  "Retail", "Construction", "Hospitality", "Other",
];

export const v13Countries = [
  { code: "AE", name: "UAE" },
  { code: "SA", name: "Saudi Arabia" },
  { code: "QA", name: "Qatar" },
  { code: "KW", name: "Kuwait" },
  { code: "BH", name: "Bahrain" },
  { code: "OM", name: "Oman" },
  { code: "IN", name: "India" },
];

export interface ScoreInput {
  legalName?: string;
  currentRatio?: number;
  debtToEquity?: number;
  ebitdaMarginPct?: number;
  daysBeyondTerms12m?: number;
  yearsTrading?: number;
  sector?: Sector;
  country?: string;                 // ISO-2, e.g. "AE"
  litigationOrOwnershipChange?: boolean;
  equity?: number;                  // optional, for knock-out
  bouncedCheques12m?: number;       // optional, for knock-out
}

type Curve = [number, number][];    // [input, points], input ascending

const CURVES: Record<"liquidity" | "leverage" | "profitability" | "paymentHistory" | "yearsTrading", { label: string; max: number; curve: Curve; unit: string }> = {
  liquidity:     { label: "Liquidity (current ratio)", max: 15, unit: "x",
                   curve: [[0.8, 2], [1.0, 5], [1.2, 8], [1.5, 11], [2.0, 15]] },
  leverage:      { label: "Leverage (debt/equity)",    max: 15, unit: "x",
                   curve: [[0.5, 15], [1.0, 12], [1.5, 9], [2.5, 5], [4.0, 2], [6.0, 0]] },
  profitability: { label: "Profitability (EBITDA %)",  max: 10, unit: "%",
                   curve: [[0, 1], [5, 3], [10, 6], [15, 8], [20, 10]] },
  paymentHistory:{ label: "Payment history (DBT 12m)", max: 25, unit: " days",
                   curve: [[0, 25], [5, 22], [15, 17], [30, 11], [60, 5], [90, 0]] },
  yearsTrading:  { label: "Years trading",             max: 10, unit: " yrs",
                   curve: [[0, 0], [1, 1], [3, 4], [5, 6], [7, 8], [10, 10]] },
};

const SECTOR_POINTS: Record<Sector, number> = {
  Utilities: 10, Healthcare: 9, Logistics: 6, Manufacturing: 6,
  Retail: 4, Construction: 4, Hospitality: 3, Other: 5,
};
const COUNTRY_POINTS: Record<string, number> = { AE: 9, SA: 8, QA: 8, KW: 8, BH: 7, OM: 7, IN: 6 };
const COUNTRY_DEFAULT = 5;
const FLAG_MAX = 5, FLAG_PENALTY = 2.5;

const BANDS = [
  { min: 75, band: "Low",      action: "Standard terms within policy limit; annual review." },
  { min: 55, band: "Medium",   action: "Reduce limit; 30-day terms; quarterly review." },
  { min: 35, band: "High",     action: "Secured or credit-insured only; 15-day terms; monthly review." },
  { min: 0,  band: "Critical", action: "Credit hold or cash in advance; escalate to Credit Committee." },
] as const;

const interpolate = (x: number, c: Curve): number => {
  if (x <= c[0]![0]) return c[0]![1];
  for (let i = 1; i < c.length; i++) {
    const [x1, y1] = c[i - 1]!, [x2, y2] = c[i]!;
    if (x <= x2) return y1 + ((x - x1) / (x2 - x1)) * (y2 - y1);
  }
  return c[c.length - 1]![1];
};

export interface FactorResult {
  key: string; label: string; points: number | null; max: number; reason: string;
}

export interface ScoreResult {
  score: number;               // 0–100, rounded
  rawScore: number;            // before overrides
  band: string;
  action: string;
  confidence: number;          // share of the 100 points backed by real inputs (0–1)
  factors: FactorResult[];
  overrides: string[];         // knock-outs that capped the score
}

export function scoreCredit(i: ScoreInput): ScoreResult {
  const factors: FactorResult[] = [];
  const add = (key: string, label: string, max: number, val: number | undefined,
               pts: (v: number) => number, fmt: (v: number) => string) => {
    if (val === undefined || Number.isNaN(val)) {
      factors.push({ key, label, points: null, max, reason: "Not provided" });
    } else {
      const p = Math.round(pts(val) * 10) / 10;
      factors.push({ key, label, points: p, max, reason: `${fmt(val)} → ${p}/${max}` });
    }
  };

  const c = CURVES;
  add("liquidity", c.liquidity.label, c.liquidity.max, i.currentRatio,
      v => interpolate(v, c.liquidity.curve), v => `${v.toFixed(2)}x`);
  add("leverage", c.leverage.label, c.leverage.max, i.debtToEquity,
      v => interpolate(v, c.leverage.curve), v => `${v.toFixed(2)}x`);
  add("profitability", c.profitability.label, c.profitability.max, i.ebitdaMarginPct,
      v => interpolate(v, c.profitability.curve), v => `${v.toFixed(1)}%`);
  add("paymentHistory", c.paymentHistory.label, c.paymentHistory.max, i.daysBeyondTerms12m,
      v => interpolate(v, c.paymentHistory.curve), v => `${v} days`);
  add("yearsTrading", c.yearsTrading.label, c.yearsTrading.max, i.yearsTrading,
      v => interpolate(v, c.yearsTrading.curve), v => `${v} yrs`);
  add("sector", "Sector risk", 10, i.sector ? 1 : undefined,
      () => (i.sector ? SECTOR_POINTS[i.sector] : 0), () => i.sector ?? "");
  add("country", "Country risk", 10, i.country ? 1 : undefined,
      () => COUNTRY_POINTS[i.country!] ?? COUNTRY_DEFAULT, () => i.country ?? "");
  add("flags", "Adverse flags", FLAG_MAX,
      i.litigationOrOwnershipChange === undefined ? undefined : 1,
      () => (i.litigationOrOwnershipChange ? Math.max(0, FLAG_MAX - FLAG_PENALTY) : FLAG_MAX),
      () => (i.litigationOrOwnershipChange ? "Flag raised" : "None"));

  // Missing data: rescale over the points that were provided
  const provided = factors.filter(f => f.points !== null);
  const earned = provided.reduce((s, f) => s + (f.points as number), 0);
  const possible = provided.reduce((s, f) => s + f.max, 0);
  const confidence = possible / 100;
  const rawScore = possible ? (earned / possible) * 100 : 0;

  // Knock-out overrides: caps, not penalties
  const overrides: string[] = [];
  let cap = 100;
  const capWith = (limit: number, why: string) => {
    if (rawScore > limit || cap > limit) { cap = Math.min(cap, limit); overrides.push(why); }
  };
  if (i.equity !== undefined && i.equity < 0) capWith(34, "Negative equity → capped at Critical");
  if (i.bouncedCheques12m !== undefined && i.bouncedCheques12m >= 3)
    capWith(34, "3+ bounced cheques in 12m → capped at Critical");
  if ((i.daysBeyondTerms12m ?? 0) >= 90) capWith(54, "90+ days beyond terms → capped at High");
  if (i.litigationOrOwnershipChange && (i.daysBeyondTerms12m ?? 0) > 60)
    capWith(54, "Litigation/ownership change with DBT > 60 → capped at High");

  const score = Math.round(Math.min(rawScore, cap));
  const b = BANDS.find(x => score >= x.min)!;
  return { score, rawScore: Math.round(rawScore), band: b.band, action: b.action,
           confidence, factors, overrides };
}
