// Use structural checks: DOMExceptions can cross runtime/realm boundaries.
export function isRequestAbort(error: unknown): boolean {
  if (!error || typeof error !== "object") return false;
  const value = error as { name?: unknown; code?: unknown; message?: unknown; cause?: unknown };
  return (
    value.name === "AbortError" ||
    value.code === "ECONNRESET" ||
    value.message === "aborted" ||
    (value.cause !== error && value.cause !== undefined && isRequestAbort(value.cause))
  );
}
