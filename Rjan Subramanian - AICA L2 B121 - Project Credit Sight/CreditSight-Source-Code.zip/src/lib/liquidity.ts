import type { Customer, Receivable } from "./demo-data";

export type Scenario = "Base" | "Optimistic" | "Conservative";
export type ForecastOptions = { asOf: string; days: number; scenario: Scenario; promiseReliability: number; extraDelay: number };
export type Payment = { invoiceId: string; customerId: string; source: "Promise" | "Due date"; date: string; amount: number; probability: number; expected: number };
export const addDays = (date: string, days: number) => {
  const d = new Date(`${date}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
};
export const daysBetween = (a: string, b: string) => Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86400000);

export function predictPayments(invoices: Receivable[], accounts: Pick<Customer, "id" | "dbt" | "rating">[], options: ForecastOptions): Payment[] {
  const accountMap = new Map(accounts.map((c) => [c.id, c]));
  const riskProbability = { Low: 0.96, Medium: 0.85, High: 0.65, Critical: 0.4 };
  const result: Payment[] = [];
  for (const invoice of invoices) {
    const customer = accountMap.get(invoice.customerId);
    if (!customer) continue;
    const probability = Math.min(1, Math.max(0, riskProbability[customer.rating] + (options.scenario === "Optimistic" ? 0.08 : options.scenario === "Conservative" ? -0.15 : 0)));
    const delay = Math.max(0, Math.round(customer.dbt * (options.scenario === "Optimistic" ? 0.5 : options.scenario === "Conservative" ? 1.5 : 1)) + options.extraDelay);
    const overdue = invoice.dueDate < options.asOf;
    const dueDate = addDays(overdue ? options.asOf : invoice.dueDate, overdue ? Math.max(7, delay) : delay);
    // A missed promise is not treated as a future commitment. Partial promises only replace their own portion.
    const promise = invoice.promise && invoice.promise.date >= options.asOf ? invoice.promise : undefined;
    const promised = promise ? Math.min(invoice.amount, Math.max(0, promise.amount)) : 0;
    const add = (source: Payment["source"], date: string, amount: number, chance: number) => {
      if (amount > 0) result.push({ invoiceId: invoice.id, customerId: invoice.customerId, source, date, amount, probability: chance, expected: amount * chance });
    };
    if (promise) add("Promise", addDays(promise.date, options.extraDelay), promised, probability * Math.min(100, Math.max(0, options.promiseReliability)) / 100);
    add("Due date", dueDate, invoice.amount - promised, probability);
  }
  return result.sort((a, b) => a.date.localeCompare(b.date));
}

export function forecastWeeks(payments: Payment[], invoices: Receivable[], asOf: string, days: number) {
  let cumulative = 0;
  return Array.from({ length: Math.ceil(days / 7) }, (_, i) => {
    const start = addDays(asOf, i * 7);
    const end = addDays(asOf, Math.min(days, (i + 1) * 7));
    const inWeek = payments.filter((p) => p.date >= start && p.date < end);
    const promised = inWeek.filter((p) => p.source === "Promise").reduce((sum, p) => sum + p.expected, 0);
    const due = inWeek.filter((p) => p.source === "Due date").reduce((sum, p) => sum + p.expected, 0);
    const contractual = invoices.filter((p) => p.dueDate >= start && p.dueDate < end).reduce((sum, p) => sum + p.amount, 0);
    cumulative += promised + due;
    return { week: `W${i + 1}`, start, end: addDays(end, -1), promised, due, expected: due + promised, contractual, cumulative };
  });
}