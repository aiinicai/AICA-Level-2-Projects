import type { jsPDF } from "jspdf";
import type { RowInput, UserOptions } from "jspdf-autotable";

type RGB = [number, number, number];
export const money = (n: number) => new Intl.NumberFormat("en-GB", { maximumFractionDigits: 0 }).format(n);
export const millions = (n: number) => `${(n / 1e6).toFixed(2)}M`;
const clean = (s: string) => s.replace(/[–—]/g, "-").replace(/·/g, " | ").replace(/×/g, "x").replace(/→/g, "> ");

// Resolve the semantic print palette independently of the selected screen theme.
function color(token: string): RGB {
  const canvas = document.createElement("canvas"); canvas.width = 1; canvas.height = 1;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Report palette unavailable");
  ctx.fillStyle = getComputedStyle(document.documentElement).getPropertyValue(token).trim();
  ctx.fillRect(0, 0, 1, 1);
  const p = ctx.getImageData(0, 0, 1, 1).data;
  return [p[0] ?? 0, p[1] ?? 0, p[2] ?? 0];
}

export async function createReport(title: string, snapshot: string, subtitle: string) {
  const [{ jsPDF }, { autoTable }] = await Promise.all([import("jspdf"), import("jspdf-autotable")]);
  const pdf = new jsPDF({ unit: "mm", format: "a4", compress: true });
  pdf.setProperties({ title: `CreditSight | ${title}`, subject: "Synthetic case study | AED equivalent", author: "CreditSight", creator: "CreditSight management reporting" });
  const c = { ink: color("--report-ink"), accent: color("--report-accent"), muted: color("--report-muted"), paper: color("--report-paper"), rule: color("--report-rule"), wash: color("--report-wash"), alert: color("--report-alert") };
  const text = (value: string, x: number, y: number, size = 10, bold = false, tone: keyof typeof c = "ink", align: "left" | "right" = "left") => {
    pdf.setFont("helvetica", bold ? "bold" : "normal"); pdf.setFontSize(size); pdf.setTextColor(...c[tone]); pdf.text(clean(value), x, y, { align });
  };
  const rule = (y: number) => { pdf.setDrawColor(...c.rule); pdf.setLineWidth(0.25); pdf.line(16, y, 194, y); };
  const frame = () => {
    pdf.setFillColor(...c.accent); pdf.rect(0, 0, 210, 2, "F");
    text("CreditSight", 16, 13, 14, true); text("FINANCE INTELLIGENCE / SYNTHETIC CASE STUDY", 194, 12, 7, false, "muted", "right"); rule(18);
  };
  frame();
  const section = (label: string, y = 32, description?: string) => { text(label, 16, y, 21, true); if (description) text(description, 16, y + 8, 9, false, "muted"); };
  const page = (label: string, description?: string) => { pdf.addPage(); frame(); section(label, 32, description); };
  const paragraph = (value: string, y: number, width = 178, size = 10, x = 16): number => {
    pdf.setFont("helvetica", "normal"); pdf.setFontSize(size);
    const lines: string[] = pdf.splitTextToSize(clean(value), width);
    text(lines.join("\n"), x, y, size); return y + lines.length * size * 0.43 + 4;
  };
  const metrics = (items: { label: string; value: string; note?: string; alert?: boolean }[], y: number) => {
    const width = 178 / items.length;
    items.forEach((item, i) => {
      const x = 16 + i * width; pdf.setFillColor(...c.wash); pdf.rect(x, y, width - 3, 31, "F");
      text(item.label.toUpperCase(), x + 3, y + 7, 7, false, "muted"); text(item.value, x + 3, y + 18, 18, true, item.alert ? "alert" : "ink");
      if (item.note) text(item.note, x + 3, y + 26, 7, false, "muted");
    });
  };
  const table = (headers: string[], rows: RowInput[], y: number, right: number[] = [], extra: Partial<UserOptions> = {}) => {
    autoTable(pdf, { startY: y, head: [headers], body: rows.length ? rows : [[{ content: "No records under the current selection.", colSpan: headers.length }]],
      margin: { left: 16, right: 16, top: 25, bottom: 21 }, theme: "plain",
      styles: { font: "helvetica", fontSize: 8, cellPadding: 2.7, textColor: c.ink, lineColor: c.rule, lineWidth: { bottom: 0.15 }, overflow: "linebreak" },
      headStyles: { fillColor: c.ink, textColor: c.paper, fontStyle: "bold", fontSize: 7.5 }, alternateRowStyles: { fillColor: c.wash },
      columnStyles: Object.fromEntries(right.map((i) => [i, { halign: "right" }])), rowPageBreak: "avoid", showHead: "everyPage",
      didDrawPage: frame, ...extra });
  };
  const bars = (items: { label: string; value: number }[], y: number) => {
    const max = Math.max(1, ...items.map((i) => i.value));
    items.forEach((item, i) => { const yy = y + i * 13; text(item.label, 16, yy + 4, 9); pdf.setFillColor(...c.wash); pdf.rect(64, yy, 94, 6, "F"); pdf.setFillColor(...c.accent); pdf.rect(64, yy, 94 * item.value / max, 6, "F"); text(millions(item.value), 194, yy + 4.5, 9, true, "ink", "right"); });
  };
  const finish = () => {
    const total = pdf.getNumberOfPages();
    for (let i = 1; i <= total; i++) { pdf.setPage(i); rule(279); text(`Snapshot ${snapshot} | AED equivalent | Prototype - not financial advice`, 16, 285, 7, false, "muted"); text(`${i} / ${total}`, 194, 285, 8, true, "muted", "right"); }
  };
  section(title, 33, subtitle);
  return { pdf, c, text, rule, page, paragraph, metrics, table, bars, finish };
}

export function saveReport(pdf: jsPDF, name: string) {
  const blob = pdf.output("blob"); const url = URL.createObjectURL(blob);
  const link = document.createElement("a"); link.href = url; link.download = name; document.body.appendChild(link); link.click(); link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 30_000);
}