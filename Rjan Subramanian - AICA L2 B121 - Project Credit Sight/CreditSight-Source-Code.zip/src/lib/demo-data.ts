// Deterministic demo dataset for the CreditSight clickable demo (no backend).
let seed = 42;
const rnd = () => ((seed = (seed * 16807) % 2147483647) - 1) / 2147483646;
const pick = <T,>(a: T[]) => a[Math.floor(rnd() * a.length)]!;

export type Rating = "Low" | "Medium" | "High" | "Critical";
export const divisions = ["Automotive Retail", "Fleet and Leasing", "Parts and Service", "Financial Services"];
export const countries = [
  { name: "UAE", risk: 10, ccy: "AED", fx: 1 },
  { name: "KSA", risk: 15, ccy: "SAR", fx: 0.979 },
  { name: "Oman", risk: 25, ccy: "OMR", fx: 9.54 },
  { name: "Kuwait", risk: 20, ccy: "KWD", fx: 11.95 },
  { name: "Qatar", risk: 15, ccy: "QAR", fx: 1.009 },
  { name: "Bahrain", risk: 35, ccy: "BHD", fx: 9.74 },
  { name: "Egypt", risk: 70, ccy: "EGP", fx: 0.075 },
];
export const sectors = [
  { name: "Construction", risk: 65 }, { name: "Logistics", risk: 40 }, { name: "Government", risk: 10 },
  { name: "Car Rental", risk: 50 }, { name: "Oil and Gas", risk: 30 }, { name: "Retail", risk: 45 },
  { name: "Hospitality", risk: 55 }, { name: "Healthcare", risk: 25 },
];
const prefixes = ["Al Noor", "Gulf", "Emirates", "Desert Star", "Falcon", "Oasis", "Pearl", "Horizon", "Crescent", "Dune", "Marina", "Sahara", "Najm", "Al Waha", "Bluewave"];
const suffixes = ["Trading LLC", "Contracting", "Logistics FZE", "Rent a Car", "Holdings", "Services WLL", "Group", "Transport"];

export function ratingOf(score: number): Rating {
  return score >= 75 ? "Low" : score >= 55 ? "Medium" : score >= 35 ? "High" : "Critical";
}

export type Customer = {
  id: string; name: string; license: string; country: string; ccy: string; sector: string;
  division: string; terms: number; limit: number; exposure: number; overdue: number;
  aging: number[]; // current, 1-30, 31-60, 61-90, 90+ (AED)
  dbt: number; score: number; rating: Rating; years: number; currentRatio: number;
  debtEquity: number; ebitdaMargin: number; revenue: number; netWorth: number;
  status: "Active" | "On Hold" | "Watchlist"; trend: number[];
  factors: { name: string; weight: number; value: string; points: number }[];
};

export const customers: Customer[] = Array.from({ length: 60 }, (_, i) => {
  const c = pick(countries); const s = pick(sectors);
  const behaviour = rnd(); // <0.6 good, <0.85 late, rest deteriorating
  const currentRatio = +(0.6 + rnd() * 1.8).toFixed(2);
  const debtEquity = +(0.2 + rnd() * 2.8).toFixed(2);
  const ebitdaMargin = +(2 + rnd() * 18).toFixed(1);
  const years = 1 + Math.floor(rnd() * 30);
  const dbt = behaviour < 0.6 ? Math.floor(rnd() * 8) : behaviour < 0.85 ? 10 + Math.floor(rnd() * 30) : 30 + Math.floor(rnd() * 60);
  const f = [
    { name: "Liquidity (current ratio)", weight: 15, value: currentRatio.toString(), points: Math.min(15, currentRatio * 8) },
    { name: "Leverage (debt/equity)", weight: 15, value: debtEquity.toString(), points: Math.max(0, 15 - debtEquity * 5) },
    { name: "Profitability (EBITDA %)", weight: 10, value: ebitdaMargin + "%", points: Math.min(10, ebitdaMargin / 1.5) },
    { name: "Payment history (DBT)", weight: 25, value: dbt + " days", points: Math.max(0, 25 - dbt * 0.4) },
    { name: "Years trading", weight: 10, value: years + " yrs", points: Math.min(10, years / 1.5) },
    { name: "Sector risk", weight: 10, value: s.name, points: 10 - s.risk / 10 },
    { name: "Country risk", weight: 10, value: c.name, points: 10 - c.risk / 10 },
    { name: "Adverse flags", weight: 5, value: behaviour > 0.93 ? "Litigation" : "None", points: behaviour > 0.93 ? 0 : 5 },
  ].map((x) => ({ ...x, points: +x.points.toFixed(1) }));
  const score = Math.round(f.reduce((a, b) => a + b.points, 0));
  const limit = Math.round((0.5 + rnd() * 9.5) * 1e6 / 50000) * 50000;
  const exposure = Math.round(limit * (0.3 + rnd() * (behaviour > 0.85 ? 0.95 : 0.7)));
  const late = Math.min(0.9, dbt / 80);
  const w = [1 - late, late * 0.45, late * 0.25, late * 0.15, late * 0.15];
  const aging = w.map((x) => Math.round(exposure * x));
  const trend = Array.from({ length: 12 }, (_, m) => Math.round(score + (behaviour > 0.85 ? (11 - m) * 2 : (rnd() - 0.5) * 6)));
  return {
    id: `C${String(1001 + i)}`, name: `${pick(prefixes)} ${pick(suffixes)}`, license: `TL-${100000 + Math.floor(rnd() * 900000)}`,
    country: c.name, ccy: c.ccy, sector: s.name, division: divisions[i % 4]!, terms: pick([30, 45, 60, 90]),
    limit, exposure, overdue: aging.slice(1).reduce((a, b) => a + b, 0), aging, dbt, score, rating: ratingOf(score), years,
    currentRatio, debtEquity, ebitdaMargin, revenue: Math.round(limit * (8 + rnd() * 20)), netWorth: Math.round(limit * (2 + rnd() * 6)),
    status: exposure > limit ? "On Hold" : score < 45 ? "Watchlist" : "Active", trend, factors: f,
  };
});

export const buckets = ["Current", "1-30", "31-60", "61-90", "90+"];
export const eclRates = [0.005, 0.02, 0.06, 0.15, 0.45];

export type Alert = { id: string; customer: Customer; type: string; severity: Rating; detail: string; status: string; owner: string; date: string };
export const alerts: Alert[] = customers.flatMap((c, i) => {
  const out: Alert[] = [];
  const d = `2026-10-${String(1 + (i % 23)).padStart(2, "0")}`;
  if (c.exposure > c.limit) out.push({ id: `A${i}a`, customer: c, type: "Limit breach", severity: "Critical", detail: `Exposure ${fmt(c.exposure)} vs limit ${fmt(c.limit)}`, status: "Open", owner: "R. Menon", date: d });
  else if (c.exposure > c.limit * 0.9) out.push({ id: `A${i}b`, customer: c, type: "Utilisation > 90%", severity: "High", detail: `${Math.round((c.exposure / c.limit) * 100)}% of limit used`, status: "Open", owner: "S. Khan", date: d });
  if (c.trend[0]! - c.trend[11]! > 12) out.push({ id: `A${i}c`, customer: c, type: "Score deterioration", severity: "High", detail: `Score fell ${c.trend[0]! - c.trend[11]!} pts in 12 months`, status: "Investigating", owner: "R. Menon", date: d });
  if (c.aging[4]! > 0 && c.dbt > 40) out.push({ id: `A${i}d`, customer: c, type: "90+ overdue", severity: "Critical", detail: `${fmt(c.aging[4]!)} beyond 90 days`, status: "Open", owner: "A. Haddad", date: d });
  return out;
});

export function fmt(n: number, ccy = "AED") {
  const s = Math.abs(n).toLocaleString("en-US", { maximumFractionDigits: 0 });
  return `${n < 0 ? "-" : ""}${ccy} ${s}`;
}
export function fmtM(n: number) {
  return `AED ${(n / 1e6).toFixed(1)}M`;
}
export const totals = {
  exposure: customers.reduce((a, c) => a + c.exposure, 0),
  limit: customers.reduce((a, c) => a + c.limit, 0),
  overdue: customers.reduce((a, c) => a + c.overdue, 0),
  aging: buckets.map((_, b) => customers.reduce((a, c) => a + c.aging[b]!, 0)),
};
export const monthly = ["Nov", "Dec", "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct"].map((m, i) => ({
  month: m, dso: Math.round(48 + Math.sin(i / 2) * 5 + i * 0.6), overdue: Math.round((totals.overdue * (0.7 + i * 0.03)) / 1e6 * 10) / 10,
}));

export const forecastAsOf = "2026-10-25";
export type Receivable = {
  id: string; customerId: string; amount: number; dueDate: string;
  promise?: { date: string; amount: number };
};
const demoDate = (days: number) => {
  const date = new Date(`${forecastAsOf}T00:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
};
// Each customer's invoices reconcile exactly to exposure; all amounts are AED equivalent.
export const receivables: Receivable[] = customers.flatMap((c, i) => {
  const overdue = Math.min(c.exposure, c.overdue);
  const current = c.exposure - overdue;
  const first = Math.round(current * 0.55);
  return [
    { id: `INV-${c.id}-01`, customerId: c.id, amount: first, dueDate: demoDate(3 + i % 28) },
    { id: `INV-${c.id}-02`, customerId: c.id, amount: current - first, dueDate: demoDate(32 + i % 59) },
    { id: `INV-${c.id}-03`, customerId: c.id, amount: overdue, dueDate: demoDate(-Math.max(1, c.dbt)),
      ...(i % 3 === 0 && overdue > 0 ? { promise: { date: demoDate(i % 9 === 0 ? -3 : 5 + i % 21), amount: Math.round(overdue * 0.65) } } : {}) },
  ].filter((invoice) => invoice.amount > 0);
});
