import type { Customer, Receivable } from "./demo-data";
import { addDays, forecastWeeks, predictPayments, type ForecastOptions, type Payment } from "./liquidity";

export type StressOptions = {
  delayDays: number; brokenPromises: number; defaultCustomerId: string;
  openingCash: number; weeklyOutflows: number; minimumCash: number;
};

// Stress changes probabilities and timing, never creates a second invoice allocation.
export function stressPayments(payments: Payment[], stress: StressOptions): Payment[] {
  const failure = Math.min(100, Math.max(0, stress.brokenPromises)) / 100;
  return payments.map((p) => {
    const probability = p.customerId === stress.defaultCustomerId ? 0 : p.probability * (p.source === "Promise" ? 1 - failure : 1);
    return { ...p, date: addDays(p.date, Math.max(0, stress.delayDays)), probability, expected: p.amount * probability };
  });
}

export function cashPath(payments: Payment[], invoices: Receivable[], options: ForecastOptions, stress: StressOptions) {
  let cash = Math.max(0, stress.openingCash);
  return forecastWeeks(payments, invoices, options.asOf, options.days).map((w, i) => {
    const periodDays = Math.min(7, options.days - i * 7);
    const outflow = Math.max(0, stress.weeklyOutflows) * periodDays / 7;
    cash += w.expected - outflow;
    return { ...w, outflow, cash, gap: Math.max(0, stress.minimumCash - cash) };
  });
}

export function runStressTest(invoices: Receivable[], accounts: Customer[], options: ForecastOptions, stress: StressOptions) {
  const baseline = predictPayments(invoices, accounts, options);
  const stressed = stressPayments(baseline, stress);
  const baseWeeks = cashPath(baseline, invoices, options, stress);
  const stressWeeks = cashPath(stressed, invoices, options, stress);
  const end = addDays(options.asOf, options.days);
  const inHorizon = (p: Payment) => p.date >= options.asOf && p.date < end;
  const baseReceipts = baseline.filter(inHorizon).reduce((s, p) => s + p.expected, 0);
  const stressReceipts = stressed.filter(inHorizon).reduce((s, p) => s + p.expected, 0);
  const priorities = accounts.map((c) => {
    const base = baseline.filter((p) => p.customerId === c.id && inHorizon(p)).reduce((s, p) => s + p.expected, 0);
    const current = stressed.filter((p) => p.customerId === c.id && inHorizon(p)).reduce((s, p) => s + p.expected, 0);
    return { customer: c, base, stressed: current, atRisk: Math.max(0, base - current) };
  }).filter((c) => c.atRisk > 0).sort((a, b) => b.atRisk - a.atRisk);
  return { baseline, stressed, baseWeeks, stressWeeks, baseReceipts, stressReceipts, priorities,
    peakGap: Math.max(0, ...stressWeeks.map((w) => w.gap)),
    firstBreach: stressWeeks.find((w) => w.gap > 0),
    closingCash: stressWeeks.at(-1)?.cash ?? stress.openingCash };
}
export type ScenarioPreset = { id: string; label: string; description: string; apply: (base: StressOptions, topCustomerId: string) => StressOptions };

/** Ready-made cash flow scenarios for one-click exploration (illustrative assumptions). */
export const scenarioPresets: ScenarioPreset[] = [
  { id: "base", label: "Base case", description: "Payments arrive as forecast", apply: (b) => ({ ...b, delayDays: 0, brokenPromises: 0, defaultCustomerId: "" }) },
  { id: "recession", label: "Regional slowdown", description: "Customers pay 30 days late, 40% of promises broken", apply: (b) => ({ ...b, delayDays: 30, brokenPromises: 40, defaultCustomerId: "" }) },
  { id: "default", label: "Largest customer defaults", description: "Biggest exposure stops paying; 14-day delays elsewhere", apply: (b, top) => ({ ...b, delayDays: 14, brokenPromises: 20, defaultCustomerId: top }) },
  { id: "crunch", label: "Liquidity crunch", description: "21-day delays, 60% promises broken, outflows up 25%", apply: (b) => ({ ...b, delayDays: 21, brokenPromises: 60, defaultCustomerId: "", weeklyOutflows: b.weeklyOutflows * 1.25 }) },
  { id: "push", label: "Collections push", description: "On-time payments, promises kept, outflows cut 25%", apply: (b) => ({ ...b, delayDays: 0, brokenPromises: 0, defaultCustomerId: "", weeklyOutflows: b.weeklyOutflows * 0.75 }) },
];
