import { buckets, eclRates, totals, customers } from "./demo-data";
import { addDays, type ForecastOptions } from "./liquidity";
import type { runStressTest, StressOptions } from "./stress-test";
import { createReport, money, millions, saveReport } from "./report-pdf";

export async function downloadBoardPack(result: ReturnType<typeof runStressTest>, options: ForecastOptions, stress: StressOptions, defaultName: string) {
  const r = await createReport("Liquidity & credit risk", options.asOf, `BOARD BRIEFING | ${options.days}-day scenario | Management review`);
  const { pdf, c } = r;
  r.metrics([
    { label: "Baseline receipts", value: millions(result.baseReceipts), note: "AED / within horizon" },
    { label: "Stressed receipts", value: millions(result.stressReceipts), note: `${millions(result.baseReceipts - result.stressReceipts)} at risk` },
    { label: "Peak funding gap", value: millions(result.peakGap), note: "Against minimum cash floor", alert: result.peakGap > 0 },
  ], 51);
  r.text("01 / EXECUTIVE ASSESSMENT", 16, 98, 10, true, "accent");
  let y = r.paragraph(result.firstBreach ? `The scenario breaches the minimum cash floor in the week starting ${result.firstBreach.start}. Peak funding need is AED ${money(result.peakGap)}; closing cash is AED ${money(result.closingCash)}. Review funding capacity and payment timing before the first breach.` : `No weekly cash-floor breach occurs in this scenario. Closing cash is AED ${money(result.closingCash)} against a floor of AED ${money(stress.minimumCash)}. Maintain collection monitoring; weekly balances do not rule out intraday shortfalls.`, 108);
  r.text("SCENARIO AT A GLANCE", 16, y + 4, 10, true);
  y = r.paragraph(`${stress.delayDays}-day additional delay | ${stress.brokenPromises}% broken promises | Default: ${defaultName}. Opening cash AED ${money(stress.openingCash)}; operating outflows AED ${money(stress.weeklyOutflows)} per week.`, y + 13, 178, 9);
  r.text("02 / MANAGEMENT PRIORITIES", 16, y + 6, 10, true, "accent");
  r.table(["Customer", "At-risk receipts (AED)", "Proposed response"], result.priorities.slice(0, 5).map((p) => [p.customer.name, money(p.atRisk), p.customer.id === stress.defaultCustomerId ? "Credit review and funding contingency" : "Reconfirm promises; chase affected invoices"]), y + 13, [1]);

  r.page("Cash trajectory", "Baseline versus stressed weekly closing cash | AED millions");
  // Vector chart: crisp at any print resolution, derived from the same weekly results as the app.
  const left = 30, top = 61, width = 158, height = 97;
  const values = [stress.minimumCash, ...result.baseWeeks.map((w) => w.cash), ...result.stressWeeks.map((w) => w.cash)];
  const low = Math.min(0, ...values), high = Math.max(1e6, ...values), pad = (high - low) * 0.08;
  const min = low - pad, max = high + pad;
  const yy = (v: number) => top + height - (v - min) / (max - min) * height;
  const xx = (i: number) => left + i * width / Math.max(1, result.stressWeeks.length - 1);
  for (let i = 0; i <= 4; i++) { const value = min + (max - min) * i / 4; pdf.setDrawColor(...c.rule); pdf.line(left, yy(value), left + width, yy(value)); r.text((value / 1e6).toFixed(1), left - 3, yy(value) + 1, 8, false, "muted", "right"); }
  pdf.setDrawColor(...c.muted); pdf.setLineDashPattern([2, 2], 0); pdf.line(left, yy(stress.minimumCash), left + width, yy(stress.minimumCash)); pdf.setLineDashPattern([], 0);
  const draw = (weeks: typeof result.stressWeeks, tone: "accent" | "alert") => { pdf.setDrawColor(...c[tone]); pdf.setLineWidth(0.8); weeks.forEach((w, i) => { const prev = weeks[i - 1]; if (prev) pdf.line(xx(i - 1), yy(prev.cash), xx(i), yy(w.cash)); }); };
  draw(result.baseWeeks, "accent"); draw(result.stressWeeks, "alert");
  result.stressWeeks.forEach((w, i) => { if (i % 2 === 0 || i === result.stressWeeks.length - 1) r.text(w.week, xx(i) - 3, top + height + 7, 8, false, "muted"); });
  r.text("Baseline", 30, 179, 9, true, "accent"); r.text("Stressed", 66, 179, 9, true, "alert"); r.text("Dashed: minimum cash floor", 103, 179, 9, false, "muted");
  r.metrics([{ label: "Opening cash", value: millions(stress.openingCash), note: "AED" }, { label: "Stressed closing cash", value: millions(result.closingCash), note: "AED / end of horizon", alert: result.closingCash < stress.minimumCash }, { label: "First floor breach", value: result.firstBreach?.week ?? "None", note: result.firstBreach?.start ?? "No weekly breach" }], 194);
  r.paragraph("Reading the chart: delays can move receipts outside the forecast horizon. Such receipts are excluded from period cash, not written off. This is a weekly closing-cash view, not a daily treasury forecast.", 240, 178, 9);

  r.page("Cash reconciliation", "Weekly bridge from opening cash to scenario closing cash | AED");
  r.table(["Week / start", "Base receipts", "Stress receipts", "Outflows", "Closing cash", "Floor gap"], result.stressWeeks.map((w, i) => [`${w.week}\n${w.start}`, money(result.baseWeeks[i]?.expected ?? 0), money(w.expected), money(w.outflow), money(w.cash), money(w.gap)]), 51, [1, 2, 3, 4, 5], { styles: { fontSize: 7.5, cellPadding: 2.5, textColor: c.ink, lineColor: c.rule, lineWidth: { bottom: 0.15 } } });
  const outflow = result.stressWeeks.reduce((sum, w) => sum + w.outflow, 0);
  r.page("Scenario basis & ECL", "Assumptions, portfolio aging and illustrative provision | AED");
  r.text("03 / FORECAST ASSUMPTIONS", 16, 52, 10, true, "accent");
  y = r.paragraph(`Baseline ${options.scenario}; promise reliability ${options.promiseReliability}%; extra baseline delay ${options.extraDelay} days. Stress: ${stress.delayDays} additional days; ${stress.brokenPromises}% broken promises; default ${defaultName}. Horizon [${options.asOf}, ${addDays(options.asOf, options.days)}) excludes the end date.`, 62, 178, 9);
  r.text("CASH BRIDGE / AED", 16, y + 5, 10, true);
  y = r.paragraph(`${money(stress.openingCash)} opening + ${money(result.stressReceipts)} receipts - ${money(outflow)} outflows = ${money(result.closingCash)} closing. Final-week outflows are prorated. Cash inputs are illustrative, not ledger balances.`, y + 15, 178, 9);
  r.text("04 / ILLUSTRATIVE ECL MATRIX", 16, y + 6, 10, true, "accent");
  const ecl = totals.aging.reduce((sum, v, i) => sum + v * (eclRates[i] ?? 0), 0);
  r.table(["Aging", "Balance (AED)", "Loss rate", "Provision (AED)"], [...buckets.map((b, i) => [b, money(totals.aging[i] ?? 0), `${((eclRates[i] ?? 0) * 100).toFixed(1)}%`, money((totals.aging[i] ?? 0) * (eclRates[i] ?? 0))]), ["Total", money(totals.exposure), "", money(ecl)]], y + 14, [1, 2, 3]);
  r.paragraph("ECL is separate from liquidity stress. This unadjusted demo matrix does not use the editable Provisioning page overlay. It supports discussion of IFRS 9 / Ind AS 109; it does not establish compliance or an approved impairment charge.", 242, 178, 9);

  r.page("Methodology & limitations", "Transparent model basis | Synthetic case study, not proven business outcomes");
  const notes = [
    ["01 / Collection probabilities", "Rules-based estimates, not a trained AI model. Low 96%, Medium 85%, High 65%, Critical 40%. Optimistic adds 8 percentage points and halves DBT; Conservative subtracts 15 points and scales DBT by 1.5. Probabilities are capped at 100%."],
    ["02 / Due dates and promises", "Due-date portions use historical days beyond terms (DBT). Overdue estimates use the snapshot plus at least seven days. Valid future promises replace only their committed portion and multiply probability by promise reliability. Missed promises revert to an overdue estimate; invoice principal is never allocated twice."],
    ["03 / Stress interpretation", "Additional delay shifts all forecast dates. Broken promises reduce only promise-backed expected receipts, with no recovery assumed in the horizon. Selected default means zero collections within the horizon, not a booked impairment. Management actions are proposals, not approved commitments."],
    ["04 / Scope and exclusions", "Cash equals opening cash plus risk-weighted receipts less operating outflows. Weekly closes do not detect intraday gaps. New sales, financing, tax schedules, actual collections backtesting and validated forecast accuracy are excluded. All accounts, rates and scenario inputs are illustrative."],
    ["05 / Evidence and precision", "The appendix lists every payment allocation, including dates beyond the horizon, with its outstanding portion, probability and expected receipt. Displayed AED values are rounded to whole units; calculations retain precision, so rounded rows may differ marginally from totals. Portfolio data is synthetic and does not represent real customers."],
  ];
  y = 56;
  notes.forEach(([label, body]) => { if (!label || !body) return; r.text(label, 16, y, 11, true, "accent"); y = r.paragraph(body, y + 9, 178, 10) + 9; });

  r.page("Invoice evidence appendix", "All allocations | Principal x probability = expected receipt | AED");
  r.table(["Invoice / account", "Basis", "Date", "Principal", "Probability", "Expected", "Horizon"], result.stressed.map((p) => [`${p.invoiceId}\n${customers.find((cu) => cu.id === p.customerId)?.name ?? p.customerId}`, p.source, p.date, money(p.amount), `${(p.probability * 100).toFixed(1)}%`, money(p.expected), p.date >= options.asOf && p.date < addDays(options.asOf, options.days) ? "Included" : "Excluded"]), 51, [3, 4, 5], { columnStyles: { 0: { cellWidth: 42 }, 3: { halign: "right" }, 4: { halign: "right" }, 5: { halign: "right" } } });
  r.finish(); saveReport(pdf, `CreditSight-Board-Pack-${options.asOf}.pdf`);
}
