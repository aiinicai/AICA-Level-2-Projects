import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MessageSquare, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Conversation,
  ConversationContent,
  ConversationScrollButton,
} from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import {
  PromptInput,
  PromptInputTextarea,
  PromptInputFooter,
  PromptInputSubmit,
} from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Reasoning, ReasoningTrigger, ReasoningContent } from "@/components/ai-elements/reasoning";
import {
  createThread,
  readThreads,
  updateThread,
  writeThreads,
  type PortfolioThread,
} from "@/lib/chat-history";
import logo from "@/assets/logo.png";

export function PortfolioChat({ threadId }: { threadId: string }) {
  const [threads, setThreads] = useState<PortfolioThread[] | null>(null);
  const [storageError, setStorageError] = useState("");
  const navigate = useNavigate();
  useEffect(() => {
    try {
      const saved = readThreads();
      if (!saved.some((t) => t.id === threadId)) {
        saved.push(createThread(threadId));
        writeThreads(saved);
      }
      setThreads(saved);
    } catch {
      setStorageError("Conversations cannot be saved because browser storage is unavailable.");
    }
  }, [threadId]);
  const persist = useCallback(
    (messages: UIMessage[]) => {
      setThreads((previous) => {
        if (!previous) return previous;
        const next = updateThread(previous, threadId, messages);
        try {
          writeThreads(next);
        } catch {
          setStorageError("Your latest messages could not be saved in this browser.");
        }
        return next;
      });
    },
    [threadId],
  );
  const newConversation = () => {
    if (!threads) return;
    const thread = createThread();
    try {
      writeThreads([thread, ...threads]);
      void navigate({ to: "/chat/$threadId", params: { threadId: thread.id } });
    } catch {
      setStorageError("Unable to save a new conversation.");
    }
  };
  const remove = (id: string) => {
    if (!threads || !window.confirm("Delete this conversation from this browser?")) return;
    let next = threads.filter((t) => t.id !== id);
    if (!next.length) next = [createThread()];
    try {
      writeThreads(next);
      setThreads(next);
      const first = next[0];
      if (id === threadId && first)
        void navigate({ to: "/chat/$threadId", params: { threadId: first.id } });
    } catch {
      setStorageError("Unable to delete the conversation.");
    }
  };
  const active = threads?.find((t) => t.id === threadId);
  return (
    <div>
      <header className="mb-5 flex items-center gap-3">
        <img src={logo} alt="CreditSight" className="size-12 rounded-md bg-brand-surface p-1" />
        <div>
          <h1 className="font-display text-2xl font-semibold">Portfolio assistant</h1>
          <p className="text-sm text-muted-foreground">
            Synthetic portfolio · 25 October 2026 · AI-powered
          </p>
        </div>
      </header>
      {storageError && (
        <p role="alert" className="mb-3 text-sm text-destructive">
          {storageError}
        </p>
      )}
      <div className="grid min-w-0 gap-5 lg:grid-cols-[230px_minmax(0,1fr)]">
        <aside className="min-w-0 border-b pb-4 lg:border-b-0 lg:border-r lg:pr-4">
          <Button onClick={newConversation} className="mb-3 w-full" disabled={!threads}>
            <Plus />
            New conversation
          </Button>
          <div
            className="max-h-48 space-y-1 overflow-y-auto lg:max-h-[620px]"
            aria-label="Conversations"
          >
            {threads?.map((t) => (
              <div key={t.id} className="flex items-center gap-1">
                <Button
                  asChild
                  variant={t.id === threadId ? "secondary" : "ghost"}
                  className="min-w-0 flex-1 justify-start"
                >
                  <Link to="/chat/$threadId" params={{ threadId: t.id }}>
                    <MessageSquare className="shrink-0" />
                    <span className="truncate">{t.title}</span>
                  </Link>
                </Button>
                <Button
                  variant="ghost"
                  size="icon-sm"
                  aria-label={`Delete ${t.title}`}
                  title="Delete conversation"
                  onClick={() => remove(t.id)}
                >
                  <Trash2 />
                </Button>
              </div>
            ))}
          </div>
        </aside>
        {active ? (
          <ChatWindow key={threadId} thread={active} persist={persist} />
        ) : (
          <p role="status">Opening conversation…</p>
        )}
      </div>
    </div>
  );
}

function ChatWindow({
  thread,
  persist,
}: {
  thread: PortfolioThread;
  persist: (messages: UIMessage[]) => void;
}) {
  const input = useRef<HTMLTextAreaElement>(null);
  const [text, setText] = useState("");
  const transport = useMemo(
    () => new DefaultChatTransport({ api: "/api/chat", body: { conversationId: thread.id } }),
    [thread.id],
  );
  const { messages, sendMessage, status, stop, error } = useChat({
    id: thread.id,
    messages: thread.messages,
    transport,
    onFinish: () => input.current?.focus(),
  });
  const busy = status === "submitted" || status === "streaming";
  useEffect(() => {
    persist(messages);
  }, [messages, persist]);
  useEffect(() => {
    if (!busy) input.current?.focus();
  }, [busy]);
  const send = (value: string) => {
    if (busy || !value.trim()) return;
    void sendMessage({ text: value.trim() });
    setText("");
    input.current?.focus();
  };
  return (
    <section className="flex h-[740px] min-w-0 max-h-[calc(100dvh-190px)] flex-col lg:min-h-[500px]">
      <Conversation className="min-h-0 flex-1">
        <ConversationContent className="px-1 py-4">
          {!messages.length && (
            <div className="flex flex-col items-center gap-5 py-12 text-center">
              <img
                src={logo}
                alt="CreditSight assistant"
                className="size-20 rounded-md bg-brand-surface p-2"
              />
              <h2 className="font-display text-xl font-semibold">What would you like to know?</h2>
              <div className="flex max-w-xl flex-wrap justify-center gap-2">
                {[
                  "Which customers need collections attention?",
                  "Explain our liquidity crunch scenario",
                  "I’m a CFO. What are my top portfolio risks?",
                ].map((q) => (
                  <Button
                    key={q}
                    variant="outline"
                    className="h-auto max-w-full whitespace-normal text-left"
                    onClick={() => send(q)}
                  >
                    {q}
                  </Button>
                ))}
              </div>
            </div>
          )}
          {messages.map((m) => (
            <Message key={m.id} from={m.role}>
              <MessageContent
                className={
                  m.role === "user"
                    ? "group-[.is-user]:bg-primary group-[.is-user]:text-primary-foreground"
                    : "w-full"
                }
              >
                {m.parts.map((p, i) =>
                  p.type === "text" ? (
                    <MessageResponse key={i}>{p.text}</MessageResponse>
                  ) : p.type === "reasoning" && p.text ? (
                    <Reasoning
                      key={i}
                      defaultOpen={false}
                      isStreaming={busy && m.id === messages.at(-1)?.id}
                    >
                      <ReasoningTrigger />
                      <ReasoningContent>{p.text}</ReasoningContent>
                    </Reasoning>
                  ) : null,
                )}
              </MessageContent>
            </Message>
          ))}
          {busy && !messages.at(-1)?.parts.some((p) => p.type === "text" && p.text) && (
            <div role="status">
              <Shimmer>Reviewing the portfolio…</Shimmer>
            </div>
          )}
        </ConversationContent>
        <ConversationScrollButton />
      </Conversation>
      {error && (
        <p role="alert" className="mb-3 break-words text-sm text-destructive">
          {error.message}
        </p>
      )}
      <PromptInput onSubmit={({ text: value }) => send(value)} className="mt-3">
        <PromptInputTextarea
          ref={input}
          aria-label="Ask about the portfolio"
          placeholder="Ask about a customer, credit risk or cash flow…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="min-h-20 text-base"
        />
        <PromptInputFooter className="justify-end">
          <PromptInputSubmit
            status={status}
            onStop={() => {
              void stop();
              input.current?.focus();
            }}
            disabled={!busy && !text.trim()}
            title={busy ? "Stop answer" : "Send message"}
          />
        </PromptInputFooter>
      </PromptInput>
      <p className="mt-2 text-xs text-muted-foreground">
        Illustrative answers, not financial advice. Conversations saved only in this browser.
      </p>
    </section>
  );
}
