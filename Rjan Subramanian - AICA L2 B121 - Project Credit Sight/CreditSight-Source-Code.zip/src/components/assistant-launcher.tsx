import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { MessageSquare } from "lucide-react";
export function AssistantLauncher() {
  return (
    <Button asChild className="fixed bottom-5 right-5 z-40 shadow-lg">
      <Link to="/chat">
        <MessageSquare />
        Ask CreditSight
      </Link>
    </Button>
  );
}
