import { Link } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import {
  LayoutDashboard, Users, ClipboardCheck, Gauge, Bell, PhoneCall, Landmark, Globe2, FileBarChart, Upload, MessageSquare, TrendingUp, Activity, Moon, Sun, Home, ArrowLeft,
} from "lucide-react";
import { type Rating } from "@/lib/demo-data";
import { cn } from "@/lib/utils";
import logo from "@/assets/logo.png";

const nav = [
  { to: "/", label: "Cover page", icon: Home },
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/customers", label: "Customers", icon: Users },
  { to: "/onboarding", label: "Onboarding & Scoring", icon: ClipboardCheck },
  { to: "/limits", label: "Credit Limits", icon: Gauge },
  { to: "/alerts", label: "Monitoring & Alerts", icon: Bell },
  { to: "/collections", label: "Collections", icon: PhoneCall },
  { to: "/liquidity", label: "Liquidity Forecast", icon: TrendingUp },
  { to: "/stress-test", label: "CFO Stress Test", icon: Activity },
  { to: "/provisioning", label: "Provisioning (ECL)", icon: Landmark },
  { to: "/intelligence", label: "Sector & Country", icon: Globe2 },
  { to: "/reports", label: "Reports", icon: FileBarChart },
  { to: "/import", label: "Data Import", icon: Upload },
  { to: "/chat", label: "Portfolio Assistant", icon: MessageSquare },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen">
      <aside className="sticky top-0 hidden h-screen w-60 shrink-0 flex-col bg-sidebar text-sidebar-foreground md:flex">
        <Link to="/" aria-label="CreditSight cover page" className="flex items-center gap-3 px-5 py-5">
          <img src={logo} alt="CreditSight logo" width={40} height={40} className="h-10 w-10 rounded-md bg-white/95 p-1" />
          <div>
            <div className="text-lg font-semibold tracking-tight text-sidebar-accent-foreground">
              Credit<span className="text-sidebar-primary">Sight</span>
            </div>
            <div className="text-[11px] uppercase tracking-wider opacity-60">Credit & AR Risk · Demo</div>
          </div>
        </Link>
        <nav className="flex-1 space-y-0.5 overflow-y-auto px-2">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" || n.to === "/dashboard" }}
              className="flex items-center gap-3 rounded-md px-3 py-2 text-sm hover:bg-sidebar-accent"
              activeProps={{ className: "bg-sidebar-accent text-sidebar-accent-foreground border-l-2 border-sidebar-primary" }}>
              <n.icon className="h-4 w-4" />{n.label}
            </Link>
          ))}
        </nav>
        <div className="space-y-2 border-t border-sidebar-border px-5 py-3 text-xs">
          <ThemeSwitch />
          <div className="opacity-70">Viewing as: Credit Manager</div>
        </div>
      </aside>
      <main className="min-w-0 flex-1">
        <div className="mx-auto max-w-[1400px] p-6">
          <Link to="/" className="mb-4 inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground">
            <ArrowLeft className="size-4" aria-hidden="true" />Back to cover page
          </Link>
          {children}
        </div>
      </main>
    </div>
  );
}

export function ThemeSwitch() {
  const [glass, setGlass] = useState(true);
  useEffect(() => { setGlass(document.documentElement.classList.contains("glass")); }, []);
  const toggle = () => {
    const next = !glass;
    setGlass(next);
    document.documentElement.classList.toggle("glass", next);
    try { localStorage.setItem("cs-theme", next ? "glass" : "light"); } catch { /* storage unavailable */ }
  };
  return (
    <button onClick={toggle} aria-label="Switch theme"
      className="flex w-full items-center gap-2 rounded-md border border-sidebar-border px-3 py-2 hover:bg-sidebar-accent">
      {glass ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
      {glass ? "Switch to light theme" : "Switch to Cyber-Glass"}
    </button>
  );
}

const chip: Record<Rating, string> = {
  Low: "bg-risk-low/15 text-risk-low border-risk-low/30",
  Medium: "bg-risk-medium/15 text-risk-medium border-risk-medium/40",
  High: "bg-risk-high/15 text-risk-high border-risk-high/30",
  Critical: "bg-risk-critical/15 text-risk-critical border-risk-critical/30",
};
export function RiskChip({ r }: { r: Rating }) {
  return <span className={cn("inline-block rounded border px-2 py-0.5 text-xs font-medium", chip[r])}>{r}</span>;
}

export function PageHeader({ title, sub, children }: { title: string; sub?: string; children?: ReactNode }) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
        {sub && <p className="mt-1 text-sm text-muted-foreground">{sub}</p>}
      </div>
      {children}
    </div>
  );
}

export function Kpi({ label, value, note, tone }: { label: string; value: string; note?: string; tone?: "bad" }) {
  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={cn("mt-1 font-mono text-2xl font-semibold", tone === "bad" && "text-destructive")}>{value}</div>
      {note && <div className="mt-1 text-xs text-muted-foreground">{note}</div>}
    </div>
  );
}

export function Panel({ title, children, className }: { title: string; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-lg border bg-card", className)}>
      <h2 className="border-b px-4 py-3 text-sm font-semibold">{title}</h2>
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Table({ head, rows, right = [] }: { head: string[]; rows: ReactNode[][]; right?: number[] }) {
  return (
    <div className="max-h-[600px] overflow-auto rounded-lg border bg-card">
      <table className="w-full text-sm">
        <thead className="sticky top-0 bg-muted text-xs uppercase text-muted-foreground">
          <tr>{head.map((h, i) => <th key={h} className={cn("px-3 py-2 font-medium", right.includes(i) ? "text-right" : "text-left")}>{h}</th>)}</tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i} className="border-t hover:bg-muted/50">
              {r.map((c, j) => <td key={j} className={cn("px-3 py-2", right.includes(j) && "num")}>{c}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function exportCsv(name: string, head: string[], rows: (string | number)[][]) {
  const csv = [head, ...rows].map((r) => r.map((v) => `"${v}"`).join(",")).join("\n");
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
  a.download = name; a.click();
}
