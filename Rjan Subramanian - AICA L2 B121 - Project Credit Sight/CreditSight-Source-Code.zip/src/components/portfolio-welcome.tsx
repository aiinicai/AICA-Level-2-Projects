import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Bell, Building2, Globe2, ShieldCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { alerts, countries, customers, divisions } from "@/lib/demo-data";
import skyline from "@/assets/creditsight-skyline.jpg";

export function PortfolioWelcome() {
  return (
    <>
      <header className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-sm text-muted-foreground"><ShieldCheck className="size-4 text-accent" /> Credit & receivables intelligence</div>
        <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="rounded border border-border bg-card px-2 py-1">DEMO PORTFOLIO</span><span>24 Oct 2026 · AED</span></div>
      </header>
      <section className="portfolio-welcome relative isolate overflow-hidden">
        <img src={skyline} alt="Dubai’s waterfront business skyline" width={1920} height={640} className="absolute inset-0 -z-20 size-full object-cover object-right" />
        <div className="welcome-scrim absolute inset-0 -z-10" />
        <div className="max-w-xl px-6 py-8 sm:px-9 sm:py-10">
          <div className="mb-4 flex items-center gap-2 text-xs font-semibold uppercase text-primary"><span className="h-px w-7 bg-accent" /> Your portfolio. In perspective.</div>
          <h1 className="text-4xl font-semibold text-primary sm:text-5xl">Credit<span className="text-welcome-accent">Sight</span></h1>
          <p className="mt-3 max-w-sm text-base leading-relaxed text-primary">A clearer view of credit risk.<br />A stronger grip on receivables.</p>
          <div className="mt-6 flex flex-wrap gap-3">
            <Button asChild><Link to="/customers">View customers <ArrowUpRight /></Link></Button>
            <Button asChild variant="outline" className="bg-card/80"><Link to="/reports">Portfolio reports <ArrowUpRight /></Link></Button>
          </div>
        </div>
        <div className="welcome-facts flex flex-wrap gap-x-7 gap-y-3 border-t px-6 py-4 sm:px-9">
          <span className="flex items-center gap-2 text-xs text-primary"><Building2 className="size-4 text-welcome-accent" /><strong>{customers.length}</strong> customers</span>
          <span className="flex items-center gap-2 text-xs text-primary"><Globe2 className="size-4 text-welcome-accent" /><strong>{countries.length}</strong> countries</span>
          <span className="flex items-center gap-2 text-xs text-primary"><ShieldCheck className="size-4 text-welcome-accent" /><strong>{divisions.length}</strong> divisions</span>
        </div>
      </section>
      <div className="my-6 flex flex-wrap items-end justify-between gap-3">
        <div><p className="mb-1 text-xs font-medium uppercase text-accent">Portfolio overview</p><h2 className="text-xl font-semibold">The numbers that matter</h2></div>
        <Button asChild variant="ghost" size="sm" className="text-destructive"><Link to="/alerts"><Bell /> {alerts.length} alerts to review <ArrowUpRight /></Link></Button>
      </div>
    </>
  );
}