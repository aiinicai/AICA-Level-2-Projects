<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Demo mode: all data comes from the deterministic generator in src/lib/demo-data.ts (synthetic portfolio); Cloud powers AI only until a real-data migration is explicitly requested.
- "/" is a standalone cover page (no AppShell) with infographics from demo-data; the working dashboard lives at /dashboard with PortfolioWelcome.
- Keep invoice and promise demo records in the deterministic demo generator; liquidity calculations live in a pure, tested forecasting module so payment portions are never counted twice.
- CFO stress calculations live in a pure module layered on the existing payment allocations; board packs export the current scenario in the browser so reports and displayed figures reconcile without a backend.
- Two themes: light tokens on :root, Cyber-Glass tokens and glass effects scoped under html.glass; the choice is saved in localStorage "cs-theme" and applied by an inline head script so the page never flashes the wrong theme.
- PDF exports use the shared report-pdf print palette resolved from global semantic tokens and auto-paginated vector tables; portfolio PDF and CSV exports share report definitions to keep figures aligned.

- Portfolio assistant uses server-only AI Gateway Responses calls grounded in the deterministic portfolio; chat UI uses AI Elements and route-derived thread IDs with browser-only UIMessage history.
- Request cancellations close AI relays safely and return HTTP 499 at request boundaries; only actual failures reach error reporting, so Stop never produces an application crash.
