@echo off
setlocal
title Real Estate Manager
REM Runs RealEstateManager_Standalone.py from the folder this .bat file is in.
cd /d "%~dp0"

set "APPFILE=RealEstateManager_Standalone.py"
if not exist "%APPFILE%" (
  echo ERROR: %APPFILE% must be in the same folder as this .bat file.
  pause
  exit /b 1
)

REM --- find Python: py launcher first, then python on PATH ---
set "PY="
where py >nul 2>nul && py -3 -c "import sys" >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && python -c "import sys" >nul 2>nul && set "PY=python"
)

if not defined PY (
  echo Python was not found on this computer.
  echo.
  choice /c YN /m "Install Python 3.12 now using winget (internet required)"
  if errorlevel 2 goto nopython
  winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
  if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PY=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
  if not defined PY (
    where py >nul 2>nul && set "PY=py -3"
  )
  if not defined PY goto nopython
)

echo Using: %PY%
echo Starting Real Estate Manager... (close this window to stop the server)
echo.
%PY% "%APPFILE%"
echo.
echo The server has stopped.
pause
exit /b 0

:nopython
echo.
echo Please install Python 3.10 or newer from https://www.python.org/downloads/
echo (tick "Add python.exe to PATH" during setup) and run this file again.
pause
exit /b 1
