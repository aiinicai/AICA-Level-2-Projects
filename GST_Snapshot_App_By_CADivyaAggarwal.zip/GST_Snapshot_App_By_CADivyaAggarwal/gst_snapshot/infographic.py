"""
Data prep for the "Infographic Comparison" tab -- month-on-month trend
data, composition breakdowns, headline ratios, and a GSTR-1 vs GSTR-3B
reconciliation check. Pure data functions (no Tkinter/matplotlib here) so
they're easy to unit-test independently of the GUI.

All figures are derived from the same months[] structures the Comparison
tab and the Excel export already use (via summary.py's _t/_t3b lookups),
so the three views can never disagree with each other.
"""
from summary import _t, _t3b

MONTH_LABEL = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def _period_sort_key(period):
    import re
    m = re.match(r"^([A-Za-z]{3})-(\d{4})", period.strip())
    if m and m.group(1).capitalize() in MONTH_LABEL:
        return (0, int(m.group(2)), MONTH_LABEL.index(m.group(1).capitalize()))
    return (1, period)


def _pct_change(prev, cur):
    if not prev:
        return None
    return (cur - prev) / abs(prev) * 100


def gstr1_dashboard(months):
    """months: same list _build_gstr1_data() produces (each has 'period', 'tables')."""
    periods = [m["period"] for m in months]

    taxable_value = [_t(m, "total_liability", "value") for m in months]
    tax_liability = [_t(m, "total_liability", "igst") + _t(m, "total_liability", "cgst")
                      + _t(m, "total_liability", "sgst") for m in months]
    credit_notes = [abs(_t(m, "9B_cdnr", "value") + _t(m, "9B_cdnur", "value")) for m in months]
    documents = [_t(m, "13", "docs") for m in months]
    invoice_counts = [_t(m, "4A", "n") + _t(m, "4B", "n") + _t(m, "7", "n") for m in months]

    mom_growth = [None] + [_pct_change(taxable_value[i - 1], taxable_value[i])
                            for i in range(1, len(months))]
    credit_note_ratio = [(credit_notes[i] / taxable_value[i] * 100) if taxable_value[i] else None
                          for i in range(len(months))]
    avg_invoice_value = [(taxable_value[i] / invoice_counts[i]) if invoice_counts[i] else None
                          for i in range(len(months))]

    mix_labels, mix_values = [], []
    if months:
        last = months[-1]
        candidates = [
            ("B2B", _t(last, "4A", "value") + _t(last, "4B", "value")),
            ("B2CL", _t(last, "5A", "value")),
            ("B2CS", _t(last, "7", "value")),
            ("Exports / SEZ / Deemed Exp.",
             _t(last, "6A", "value") + _t(last, "6B", "value") + _t(last, "6C", "value")),
            ("Nil / Exempt / Non-GST", _t(last, "8", "total")),
        ]
        mix_labels = [c[0] for c in candidates if c[1] and c[1] > 0]
        mix_values = [c[1] for c in candidates if c[1] and c[1] > 0]

    return {
        "periods": periods, "taxable_value": taxable_value, "tax_liability": tax_liability,
        "credit_notes": credit_notes, "documents": documents, "mom_growth": mom_growth,
        "credit_note_ratio": credit_note_ratio, "avg_invoice_value": avg_invoice_value,
        "mix_labels": mix_labels, "mix_values": mix_values,
    }


def gstr3b_dashboard(months):
    """months: same list _build_gstr3b_data() produces (each has 'label', flat table keys)."""
    periods = [m["label"] for m in months]
    heads = ("6_1a_igst", "6_1a_cgst", "6_1a_sgst", "6_1a_cess",
             "6_1b_igst", "6_1b_cgst", "6_1b_sgst", "6_1b_cess")

    def outward_tax(m):
        return sum(_t3b(m, "3_1a", f) for f in ("igst", "cgst", "sgst", "cess"))

    def itc_available(m):
        return sum(_t3b(m, "4c", f) for f in ("igst", "cgst", "sgst", "cess"))

    def cash_paid(m):
        return sum(_t3b(m, h, "cash") for h in heads)

    def itc_used(m):
        return sum(_t3b(m, h, f) for h in heads for f in ("itc_igst", "itc_cgst", "itc_sgst", "itc_cess"))

    def total_payable(m):
        return sum(_t3b(m, h, "total_payable") for h in heads)

    def interest_latefee(m):
        return sum(_t3b(m, h, "interest_cash") + _t3b(m, h, "late_fee_cash") for h in heads)

    taxable_value = [_t3b(m, "3_1a", "taxable_value") for m in months]
    output_tax = [outward_tax(m) for m in months]
    itc_avail = [itc_available(m) for m in months]
    cash = [cash_paid(m) for m in months]
    itc_use = [itc_used(m) for m in months]
    payable = [total_payable(m) for m in months]
    intlate = [interest_latefee(m) for m in months]

    mom_growth = [None] + [_pct_change(taxable_value[i - 1], taxable_value[i])
                            for i in range(1, len(months))]
    itc_ratio = [(itc_use[i] / payable[i] * 100) if payable[i] else None for i in range(len(months))]
    cash_ratio = [(cash[i] / payable[i] * 100) if payable[i] else None for i in range(len(months))]

    mix_labels, mix_values = [], []
    if months and (itc_use[-1] or cash[-1]):
        mix_labels = ["Paid via ITC", "Paid in Cash"]
        mix_values = [itc_use[-1], cash[-1]]

    return {
        "periods": periods, "taxable_value": taxable_value, "output_tax": output_tax,
        "itc_available": itc_avail, "cash_paid": cash, "interest_latefee": intlate,
        "mom_growth": mom_growth, "itc_utilisation_ratio": itc_ratio, "cash_ratio": cash_ratio,
        "mix_labels": mix_labels, "mix_values": mix_values,
    }


def reconcile_gstr1_vs_gstr3b(gstr1_months, gstr3b_months, tolerance_pct=1.0):
    """
    Matches periods present in BOTH uploaded sets and compares GSTR-1's
    declared outward taxable value / tax against GSTR-3B's Table 3.1(a)+
    3.1(b) outward taxable value / tax for the same period -- the standard
    first-pass scrutiny check. Periods only in one return are reported
    separately, not silently skipped.
    """
    g1 = {m["period"]: (
        _t(m, "total_liability", "value"),
        _t(m, "total_liability", "igst") + _t(m, "total_liability", "cgst") + _t(m, "total_liability", "sgst"))
        for m in gstr1_months}
    g3 = {m["label"]: (
        _t3b(m, "3_1a", "taxable_value") + _t3b(m, "3_1b", "taxable_value"),
        sum(_t3b(m, "3_1a", f) for f in ("igst", "cgst", "sgst")))
        for m in gstr3b_months}

    common = sorted(set(g1) & set(g3), key=_period_sort_key)
    only_g1 = sorted(set(g1) - set(g3), key=_period_sort_key)
    only_g3 = sorted(set(g3) - set(g1), key=_period_sort_key)

    rows = []
    for p in common:
        v1, t1 = g1[p]
        v3, t3 = g3[p]
        value_diff = v1 - v3
        tax_diff = t1 - t3
        base = max(abs(v1), abs(v3), 1)
        matched = abs(value_diff) / base * 100 <= tolerance_pct
        rows.append({"period": p, "gstr1_value": v1, "gstr3b_value": v3, "value_diff": value_diff,
                     "gstr1_tax": t1, "gstr3b_tax": t3, "tax_diff": tax_diff, "matched": matched})
    return {"rows": rows, "only_gstr1": only_g1, "only_gstr3b": only_g3}


# ---------------------------------------------------------------------
# Chart building (matplotlib) -- shared by the live Tkinter dashboard and
# the PDF export, so what gets printed is exactly what's on screen.
# ---------------------------------------------------------------------
NAVY = "#0A2647"
TEAL = "#144272"
ACCENT = "#2C74B3"
GOLD = "#F2A93B"
GREEN = "#1E8E3E"
RED = "#B23B3B"


def build_main_figure(dash, form_name, figsize=(12.5, 8.5), dpi=96):
    """The 2x2 trend/mix/growth chart grid. Returns a matplotlib Figure."""
    from matplotlib.figure import Figure
    periods = dash["periods"]
    fig = Figure(figsize=figsize, dpi=dpi)
    fig.patch.set_facecolor("white")
    ax1, ax2, ax3, ax4 = fig.subplots(2, 2).flatten()
    palette = [ACCENT, GOLD, TEAL, GREEN, RED]

    if form_name == "GSTR-1":
        ax1.bar(periods, dash["taxable_value"], color=ACCENT, label="Taxable Value (₹)")
        ax1b = ax1.twinx()
        ax1b.plot(periods, dash["tax_liability"], color=RED, marker="o",
                  linewidth=2, label="Tax Liability (₹)")
        ax1.set_title("Taxable Value & Tax Liability", fontsize=10, fontweight="bold")
        ax1.tick_params(axis="x", labelrotation=30)
        lines1, labels1 = ax1.get_legend_handles_labels()
        lines1b, labels1b = ax1b.get_legend_handles_labels()
        ax1.legend(lines1 + lines1b, labels1 + labels1b, fontsize=7, loc="upper right")

        ax2.bar(periods, dash["credit_notes"], color=GOLD)
        ax2.set_title("Credit/Debit Notes (Sales Returns)", fontsize=10, fontweight="bold")
        ax2.tick_params(axis="x", labelrotation=30)
        for i, v in enumerate(dash["credit_note_ratio"]):
            if v is not None:
                ax2.annotate(f"{v:.0f}%", (i, dash["credit_notes"][i]),
                             textcoords="offset points", xytext=(0, 4), fontsize=7, ha="center")

        if dash["mix_values"]:
            ax3.pie(dash["mix_values"], labels=dash["mix_labels"], autopct="%1.0f%%",
                    colors=palette, textprops={"fontsize": 8})
        else:
            ax3.text(0.5, 0.5, "No sales value\nin latest period", ha="center", va="center", fontsize=9)
            ax3.axis("off")
        ax3.set_title(f"Sales Mix — {periods[-1]}", fontsize=10, fontweight="bold")

        colors4 = [GREEN if (v or 0) >= 0 else RED for v in dash["mom_growth"]]
        ax4.bar(periods, [v or 0 for v in dash["mom_growth"]], color=colors4)
        ax4.set_title("Month-on-Month Growth %", fontsize=10, fontweight="bold")
        ax4.tick_params(axis="x", labelrotation=30)
        ax4.axhline(0, color="#999", linewidth=0.8)
    else:
        ax1.plot(periods, dash["output_tax"], marker="o", color=ACCENT, label="Output Tax")
        ax1.plot(periods, dash["itc_available"], marker="o", color=TEAL, label="Net ITC Available")
        ax1.plot(periods, dash["cash_paid"], marker="o", color=RED, label="Cash Paid")
        ax1.set_title("Output Tax vs ITC vs Cash Paid", fontsize=10, fontweight="bold")
        ax1.tick_params(axis="x", labelrotation=30)
        ax1.legend(fontsize=7, loc="upper right")

        il_colors = [RED if v else GREEN for v in dash["interest_latefee"]]
        ax2.bar(periods, dash["interest_latefee"], color=il_colors)
        ax2.set_title("Interest + Late Fee Paid (compliance health)", fontsize=10, fontweight="bold")
        ax2.tick_params(axis="x", labelrotation=30)

        if dash["mix_values"]:
            ax3.pie(dash["mix_values"], labels=dash["mix_labels"], autopct="%1.0f%%",
                    colors=[TEAL, RED], textprops={"fontsize": 8})
        else:
            ax3.text(0.5, 0.5, "No tax paid\nin latest period", ha="center", va="center", fontsize=9)
            ax3.axis("off")
        ax3.set_title(f"Tax Payment Mix — {periods[-1]}", fontsize=10, fontweight="bold")

        colors4 = [GREEN if (v or 0) >= 0 else RED for v in dash["mom_growth"]]
        ax4.bar(periods, [v or 0 for v in dash["mom_growth"]], color=colors4)
        ax4.set_title("Month-on-Month Growth % (Outward Value)", fontsize=10, fontweight="bold")
        ax4.tick_params(axis="x", labelrotation=30)
        ax4.axhline(0, color="#999", linewidth=0.8)

    for ax in (ax1, ax2, ax3, ax4):
        ax.tick_params(labelsize=8)
    fig.tight_layout(pad=2.0)
    return fig


def build_recon_figure(rec, figsize=(12.5, 6.5), dpi=96):
    """
    GSTR-1 vs GSTR-3B side-by-side comparison: a grouped bar chart of
    declared outward value per period, plus the reconciliation table
    rendered underneath. Returns a matplotlib Figure, or None if there
    are no overlapping periods to compare.
    """
    if not rec["rows"]:
        return None
    from matplotlib.figure import Figure
    import numpy as np

    rows = rec["rows"]
    periods = [r["period"] for r in rows]
    g1_vals = [r["gstr1_value"] for r in rows]
    g3_vals = [r["gstr3b_value"] for r in rows]

    fig = Figure(figsize=figsize, dpi=dpi)
    fig.patch.set_facecolor("white")
    ax_chart = fig.add_axes([0.08, 0.42, 0.88, 0.50])
    x = np.arange(len(periods))
    w = 0.35
    ax_chart.bar(x - w / 2, g1_vals, w, color=ACCENT, label="GSTR-1 Declared Value")
    ax_chart.bar(x + w / 2, g3_vals, w, color=TEAL, label="GSTR-3B Declared Value")
    ax_chart.set_xticks(x)
    ax_chart.set_xticklabels(periods, rotation=20, fontsize=8)
    ax_chart.set_title("GSTR-1 vs GSTR-3B — Declared Outward Value by Period",
                        fontsize=11, fontweight="bold")
    ax_chart.legend(fontsize=8, loc="upper right")
    ax_chart.tick_params(labelsize=8)

    ax_table = fig.add_axes([0.02, 0.02, 0.96, 0.32])
    ax_table.axis("off")
    col_labels = ["Period", "GSTR-1 Value", "GSTR-3B Value", "Value Diff", "Tax Diff", "Status"]
    cell_text = []
    row_colors = []
    for r in rows:
        status = "Matched" if r["matched"] else "MISMATCH"
        cell_text.append([r["period"], f"{r['gstr1_value']:,.2f}", f"{r['gstr3b_value']:,.2f}",
                          f"{r['value_diff']:,.2f}", f"{r['tax_diff']:,.2f}", status])
        row_colors.append("#FCE4E4" if not r["matched"] else "white")
    tbl = ax_table.table(cellText=cell_text, colLabels=col_labels, loc="center", cellLoc="center")
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(8)
    tbl.scale(1, 1.6)
    for j in range(len(col_labels)):
        tbl[0, j].set_facecolor(NAVY)
        tbl[0, j].set_text_props(color="white", fontweight="bold")
    for i, color in enumerate(row_colors, start=1):
        for j in range(len(col_labels)):
            tbl[i, j].set_facecolor(color)

    extra_bits = []
    if rec["only_gstr1"]:
        extra_bits.append("In GSTR-1 only: " + ", ".join(rec["only_gstr1"]))
    if rec["only_gstr3b"]:
        extra_bits.append("In GSTR-3B only: " + ", ".join(rec["only_gstr3b"]))
    if extra_bits:
        fig.text(0.02, 0.005, "   |   ".join(extra_bits), fontsize=7, style="italic", color="#667085")

    return fig


def export_dashboard_pdf(out_path, form_name, entity, dash, rec=None):
    """
    Writes the full Infographic Comparison dashboard to a PDF: a title/KPI
    page with the main 2x2 chart grid, plus (if both returns are loaded
    for overlapping periods) a second page with the GSTR-1 vs GSTR-3B
    comparison chart and reconciliation table.
    """
    from matplotlib.backends.backend_pdf import PdfPages
    from matplotlib.figure import Figure
    from datetime import datetime

    with PdfPages(out_path) as pdf:
        fig = Figure(figsize=(11.69, 8.27), dpi=150)  # A4 landscape
        fig.patch.set_facecolor("white")
        fig.text(0.03, 0.965, "GST SNAPSHOT", fontsize=20, fontweight="bold", color=NAVY)
        fig.text(0.03, 0.935, f"{form_name} — Infographic Comparison", fontsize=13, color=TEAL)
        entity_bits = [b for b in (entity.get("legal_name"),
                                    f"GSTIN: {entity['gstin']}" if entity.get("gstin") else None) if b]
        if entity_bits:
            fig.text(0.03, 0.910, "   |   ".join(entity_bits), fontsize=9, color="#444")
        fig.text(0.97, 0.965, f"Generated {datetime.now():%d-%b-%Y %H:%M}",
                  fontsize=8, ha="right", color="#888")

        kpi_line = _kpi_summary_line(dash, form_name)
        fig.text(0.03, 0.875, kpi_line, fontsize=9, color=NAVY, fontweight="bold")

        chart_fig = build_main_figure(dash, form_name, figsize=(11.2, 6.9), dpi=150)
        _blit_figure_onto(fig, chart_fig, rect=[0.02, 0.02, 0.96, 0.83])
        pdf.savefig(fig)

        if rec is not None and rec["rows"]:
            rfig = build_recon_figure(rec, figsize=(11.69, 8.27), dpi=150)
            if rfig is not None:
                rfig.suptitle(f"{form_name} — GSTR-1 vs GSTR-3B Reconciliation",
                               fontsize=14, fontweight="bold", color=NAVY, y=0.98)
                pdf.savefig(rfig)


def _kpi_summary_line(dash, form_name):
    def pct(v):
        return "N/A" if v is None else f"{v:+.1f}%"

    if form_name == "GSTR-1":
        cnr = dash["credit_note_ratio"][-1] if dash["credit_note_ratio"] else None
        aiv = dash["avg_invoice_value"][-1] if dash["avg_invoice_value"] else None
        docs = dash["documents"][-1] if dash["documents"] else None
        return (f"MoM Growth (Taxable Value): {pct(dash['mom_growth'][-1])}   |   "
                f"Credit Note Ratio: {'N/A' if cnr is None else f'{cnr:.1f}%'}   |   "
                f"Avg. Invoice Value: {'N/A' if aiv is None else f'₹{aiv:,.0f}'}   |   "
                f"Documents Issued: {'N/A' if docs is None else f'{docs:,.0f}'}")
    itc_r = dash["itc_utilisation_ratio"][-1] if dash["itc_utilisation_ratio"] else None
    cash_r = dash["cash_ratio"][-1] if dash["cash_ratio"] else None
    il = dash["interest_latefee"][-1] if dash["interest_latefee"] else 0
    return (f"MoM Growth (Outward Value): {pct(dash['mom_growth'][-1])}   |   "
            f"ITC Utilisation Ratio: {'N/A' if itc_r is None else f'{itc_r:.1f}%'}   |   "
            f"Cash Payment Ratio: {'N/A' if cash_r is None else f'{cash_r:.1f}%'}   |   "
            f"Interest/Late Fee: {'None' if not il else f'₹{il:,.0f}'}")


def _blit_figure_onto(target_fig, source_fig, rect):
    """Copies a rendered chart figure onto a region of the PDF page figure
    as a raster image (keeps text on the page itself as real vector text,
    avoids re-deriving chart geometry for a different page size)."""
    import io
    from PIL import Image
    buf = io.BytesIO()
    source_fig.savefig(buf, format="png", dpi=source_fig.dpi, bbox_inches="tight",
                        facecolor="white")
    buf.seek(0)
    img = Image.open(buf)
    ax = target_fig.add_axes(rect)
    ax.imshow(img)
    ax.axis("off")
