"""
Extraction for GSTR-1 / GSTR-3B PDFs.

Built and verified against real GST-portal-generated PDFs (the standard
"FORM GSTR-1" / "Form GSTR-3B" system-rendered layout). It is still a
text-pattern extractor, not an official parser -- every value it produces
is meant to be reviewed in the grid before a workbook is generated.
"""
import re

DECIMAL_TOKEN_RE = re.compile(r"^\(?-?[\d,]+\.\d{1,2}\)?$")
GSTIN_RE = re.compile(r"\b\d{2}[A-Z]{5}\d{4}[A-Z]\d[A-Z\d]Z[A-Z\d]\b")
ARN_RE = re.compile(r"\b[A-Z]{2}\d{10,12}[A-Z0-9]?\b")
DATE_RE = re.compile(r"\b\d{2}[/-]\d{2}[/-]\d{4}\b")


def parse_number(tok):
    """Convert a PDF-extracted numeric token to a float. '-' or blank -> 0."""
    tok = tok.strip()
    if tok in ("", "-", "–", "—"):
        return 0.0
    neg = tok.startswith("(") and tok.endswith(")")
    tok = tok.strip("()").replace(",", "")
    try:
        val = float(tok)
    except ValueError:
        return None
    return -val if neg else val


def read_pdf_text(path):
    """Return full extracted text of a PDF, page-joined. Requires pdfplumber."""
    import pdfplumber
    text = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            t = page.extract_text() or ""
            text.append(t)
    return "\n".join(text)


def find_meta(text):
    """Best-effort GSTIN / ARN / date grab from anywhere in the document."""
    meta = {}
    m = GSTIN_RE.search(text)
    if m:
        meta["gstin"] = m.group(0)
    arns = ARN_RE.findall(text)
    if arns:
        meta["arn"] = arns[0]
    dates = DATE_RE.findall(text)
    if dates:
        meta["date"] = dates[0]
    return meta


MONTH_LABEL = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
MONTH_NAMES = ["january", "february", "march", "april", "may", "june", "july",
               "august", "september", "october", "november", "december"]
FY_RE = re.compile(r"\b(?:Financial year|Year)\s+(20\d{2})-(\d{2})\b", re.IGNORECASE)
TAXPERIOD_MONTH_RE = re.compile(
    r"\b(?:Tax period|Period)\s+(" + "|".join(MONTH_NAMES) + r")\b", re.IGNORECASE)
PERIOD_MMYYYY_RE = re.compile(r"\b(0[1-9]|1[0-2])[/-](20\d{2})\b")
QUARTER_RE = re.compile(r"\bQ[1-4]\b[^\n]{0,20}(20\d{2}-\d{2}|20\d{2})", re.IGNORECASE)


def detect_period(text, fallback_name):
    """
    Best-effort tax-period label so a batch upload doesn't need a prompt per
    file. The real GST-portal PDFs print the financial year and the tax
    period as two SEPARATE lines with no year next to the month name
    ("Financial year 2025-26" / "Tax period January"), so the two are
    matched independently and combined -- Jan/Feb/Mar belong to the second
    calendar year of the FY, Apr-Dec to the first.
    """
    fy = FY_RE.search(text[:1500])
    mo = TAXPERIOD_MONTH_RE.search(text[:1500])
    if fy and mo:
        fy_start = int(fy.group(1))
        month_name = mo.group(1).lower()
        month_idx = MONTH_NAMES.index(month_name)  # 0=Jan ... 11=Dec
        year = fy_start + 1 if month_idx <= 2 else fy_start  # Jan/Feb/Mar -> next cal. year
        return f"{MONTH_LABEL[month_idx]}-{year}"

    # Fallbacks for layouts that don't match the pattern above.
    m = PERIOD_MMYYYY_RE.search(text[:2000])
    if m:
        mm, yyyy = int(m.group(1)), m.group(2)
        return f"{MONTH_LABEL[mm - 1]}-{yyyy}"
    qm = QUARTER_RE.search(text[:2000])
    if qm:
        return qm.group(0).strip()
    return fallback_name


def trailing_numeric_tokens(line):
    """
    Walk a line's whitespace-split tokens backward from the end, collecting
    tokens that are either a decimal figure or a lone '-' placeholder, and
    stop at the first token that is neither. This reliably isolates a data
    row's numeric columns from its label text -- including prose that
    itself contains hyphens (" - ") or bare digits with no decimal point
    (invoice counts, section numbers like "17(5)") -- because those never
    appear at the very end of the line, and a lone '-' immediately after a
    label word (not another number) correctly stops the scan rather than
    being misread as a data column.

    Also tolerates a short (<=3 char) stray leading letter fused onto a
    number -- an observed PDF artifact where a diagonal "FILED" watermark
    overlaps a table cell and pdfplumber merges one of its letters into the
    adjacent digit token (e.g. "L50000.00").
    """
    toks = line.split()
    out = []
    for t in reversed(toks):
        if t in ("-", "–", "—"):
            out.append(t)
            continue
        if DECIMAL_TOKEN_RE.match(t):
            out.append(t)
            continue
        m = re.match(r"^[A-Za-z]{1,3}(\(?-?[\d,]+\.\d{1,2}\)?)$", t)
        if m:
            out.append(m.group(1))
            continue
        break
    out.reverse()
    return [parse_number(t) for t in out]


COUNT_RE = re.compile(r"(?<!\d)(\d+)\s+[A-Za-z]")


def leading_count(line):
    """First bare integer (not part of a decimal) followed by a word --
    the invoice/note/document count GST-portal PDFs print before the
    document-type label on a table's Total row."""
    m = COUNT_RE.search(line)
    return float(m.group(1)) if m else None


def _find_line(lines, contains, start=0):
    for i in range(start, len(lines)):
        if contains in lines[i]:
            return i
    return None


def _find_line_ci(lines, contains, start=0):
    low = contains.lower()
    for i in range(start, len(lines)):
        if low in lines[i].lower():
            return i
    return None


def _next_data_line(lines, start, prefixes, max_ahead=6):
    """From `start`, find the next line beginning with one of `prefixes`
    (checked against the line with leading whitespace stripped)."""
    for i in range(start, min(start + max_ahead, len(lines))):
        stripped = lines[i].strip()
        if any(stripped.startswith(p) for p in prefixes):
            return i
    return None


# ---------------------------------------------------------------------
# GSTR-1
# ---------------------------------------------------------------------

# (json_key, subfields, header anchor substring, has_leading_count)
_GSTR1_SIMPLE_TABLES = [
    ("4A", ["n", "value", "igst", "cgst", "sgst"], "4A - Taxable outward supplies made to registered persons (other than reverse ch", True),
    ("4B", ["n", "value", "igst", "cgst", "sgst"], "4B - Taxable outward supplies made to registered persons attracting tax on reverse", True),
    ("5A", ["n", "value", "igst"], "5 - Taxable outward inter-state supplies made to unregistered persons", True),
    ("6A", ["n", "value", "igst"], "6A", True),
    ("6B", ["n", "value", "igst"], "6B - Supplies made to SEZ", True),
    ("6C", ["n", "value", "igst", "cgst", "sgst"], "6C - Deemed Exports", True),
    ("7", ["n", "value", "igst", "cgst", "sgst"], "7- Taxable supplies (Net of debit and credit notes)", True),
    ("9B_cdnr", ["n", "value", "igst", "cgst", "sgst"], "9B - Credit/Debit Notes (Registered)", True),
    ("9B_cdnur", ["n", "value", "igst"], "9B - Credit/Debit Notes (Unregistered)", True),
    ("12", ["n", "value", "igst", "cgst", "sgst"], "12 - HSN-wise summary", True),
]


def extract_gstr1(text):
    lines = text.split("\n")
    out = {}

    for key, subfields, anchor, has_count in _GSTR1_SIMPLE_TABLES:
        i = _find_line(lines, anchor)
        if i is None:
            out[key] = {sf: None for sf in subfields}
            continue
        j = _next_data_line(lines, i, ["Total", "Amended amount"])
        if j is None:
            out[key] = {sf: None for sf in subfields}
            continue
        nums = trailing_numeric_tokens(lines[j])
        vals = list(nums)
        if has_count:
            cnt = leading_count(lines[j])
            vals = [cnt] + vals
        vals = (vals + [None] * len(subfields))[:len(subfields)]
        out[key] = dict(zip(subfields, vals))

    # Table 8 -- four separate one-number lines
    i8 = _find_line(lines, "8 - Nil rated, exempted and non GST")
    tot = nil = exe = non = None
    if i8 is not None:
        for i in range(i8, min(i8 + 6, len(lines))):
            s = lines[i].strip()
            n = trailing_numeric_tokens(s)
            if s.startswith("Total") and n:
                tot = n[-1]
            elif s.startswith("- Nil") and n:
                nil = n[-1]
            elif s.startswith("- Exempted") and n:
                exe = n[-1]
            elif s.startswith("- Non-GST") and n:
                non = n[-1]
    out["8"] = {"total": tot, "nil": nil, "exempted": exe, "non_gst": non}

    # 9A -- five amendment sub-blocks (B2B Regular, B2B Reverse Charge,
    # B2CL, Exports, SEZ, Deemed Exports), each with its own "Net
    # differential amount" line. Schema wants one summed figure per field;
    # sub-blocks without CGST/SGST columns (B2CL/Exports/SEZ are inter-
    # state only) contribute 0 to those fields.
    _9A_ANCHORS = [
        "9A - Amendment to taxable outward supplies made to registered person in returns of earlier tax periods in table 4 - B2B Regular",
        "9A - Amendment to taxable outward supplies made to registered person in returns of earlier tax periods in table 4 - B2B Reverse charge",
        "9A - Amendment to Inter-State supplies made to unregistered person",
        "9A - Amendment to Export supplies",
        "9A - Amendment to supplies made to SEZ units",
        "9A - Amendment to Deemed Exports",
    ]
    totals = [0.0, 0.0, 0.0, 0.0]  # value, igst, cgst, sgst
    any_found = False
    for anchor in _9A_ANCHORS:
        i = _find_line(lines, anchor)
        if i is None:
            continue
        j = _find_line(lines, "Net differential amount (Amended - Original)", i)
        if j is None or j > i + 4:
            continue
        vals = trailing_numeric_tokens(lines[j])
        vals = (vals + [0.0] * 4)[:4]
        for k in range(4):
            totals[k] += vals[k] if vals[k] is not None else 0.0
        any_found = True
    out["9A"] = (dict(zip(["value", "igst", "cgst", "sgst"], totals)) if any_found
                 else {sf: None for sf in ["value", "igst", "cgst", "sgst"]})

    # 9C -- amended CDNR/CDNUR net differential
    i9c = _find_line(lines, "9C - Amended Credit/Debit Notes (Registered)")
    if i9c is not None:
        j = _find_line(lines, "Net Differential amount (Net Amended Debit notes", i9c)
        vals = (trailing_numeric_tokens(lines[j]) if j is not None else [])
    else:
        vals = []
    vals = (vals + [None] * 4)[:4]
    out["9C"] = dict(zip(["value", "igst", "cgst", "sgst"], vals))

    # 10 -- amendment to B2CS, net differential
    i10 = _find_line(lines, "10 - Amendment to taxable outward supplies made to unregistered person")
    if i10 is not None:
        j = _find_line(lines, "Net differential amount (Amended - Original)", i10)
        vals = (trailing_numeric_tokens(lines[j]) if j is not None else [])
    else:
        vals = []
    vals = (vals + [None] * 4)[:4]
    out["10"] = dict(zip(["value", "igst", "cgst", "sgst"], vals))

    # 11A / 11B -- base advances tables (before the later amendment sections)
    i11a = _find_line(lines, "11A(1), 11A(2) - Advances received")
    j = _next_data_line(lines, i11a, ["Total"]) if i11a is not None else None
    vals = trailing_numeric_tokens(lines[j]) if j is not None else []
    vals = (vals + [None] * 4)[:4]
    out["11A"] = dict(zip(["value", "igst", "cgst", "sgst"], vals))

    i11b = _find_line(lines, "11B(1), 11B(2) - Advance amount received")
    j = _next_data_line(lines, i11b, ["Total"]) if i11b is not None else None
    vals = trailing_numeric_tokens(lines[j]) if j is not None else []
    vals = (vals + [None] * 4)[:4]
    out["11B"] = dict(zip(["value", "igst", "cgst", "sgst"], vals))

    # 13 -- documents issued
    i13 = _find_line(lines, "Net issued documents")
    if i13 is not None:
        cnt = leading_count(lines[i13])
        out["13"] = {"docs": cnt}
    else:
        out["13"] = {"docs": None}

    # Total liability
    itl = _find_line(lines, "Total Liability (Outward supplies other than Reverse charge)")
    vals = trailing_numeric_tokens(lines[itl]) if itl is not None else []
    vals = (vals + [None] * 4)[:4]
    out["total_liability"] = dict(zip(["value", "igst", "cgst", "sgst"], vals))

    return out


def extract_gstr1_meta(text):
    lines = text.split("\n")
    meta = {}
    for i, ln in enumerate(lines):
        if ln.strip().startswith("1 GSTIN"):
            m = GSTIN_RE.search(ln)
            if m:
                meta["gstin"] = m.group(0)
        if "Legal name of the registered person" in ln:
            meta["legal_name"] = ln.split("Legal name of the registered person", 1)[1].strip()
        if "Trade name if any" in ln:
            meta["trade_name"] = ln.split("Trade name if any", 1)[1].strip()
        if "(c) ARN" in ln:
            m = ARN_RE.search(ln)
            if m:
                meta["arn"] = m.group(0)
        if "(d) ARN date" in ln:
            m = DATE_RE.search(ln)
            if m:
                meta["arn_date"] = m.group(0)
    fy = FY_RE.search(text[:1500])
    if fy:
        meta["financial_year"] = f"{fy.group(1)}-{fy.group(2)}"
    return meta


# ---------------------------------------------------------------------
# GSTR-3B
# ---------------------------------------------------------------------

def _row(lines, anchor, n, start=0):
    i = _find_line(lines, anchor, start)
    if i is None:
        return [None] * n, None
    vals = trailing_numeric_tokens(lines[i])
    vals = (vals + [None] * n)[:n]
    return vals, i


def extract_gstr3b(text):
    lines = text.split("\n")
    out = {}

    v, _ = _row(lines, "Outward taxable supplies (other than zero rated", 5)
    out["3_1a"] = dict(zip(["taxable_value", "igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "Outward taxable supplies (zero rated)", 2)
    out["3_1b"] = dict(zip(["taxable_value", "igst"], v))
    v, _ = _row(lines, "Other outward supplies (nil rated, exempted)", 1)
    out["3_1c"] = dict(zip(["taxable_value"], v))
    v, _ = _row(lines, "Inward supplies (liable to reverse charge)", 5)
    out["3_1d"] = dict(zip(["taxable_value", "igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "Non-GST outward supplies", 1)
    out["3_1e"] = dict(zip(["taxable_value"], v))

    v, _ = _row(lines, "electronic commerce operator pays tax u/s 9(5)", 5)
    out["3_1_1i"] = dict(zip(["taxable_value", "igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "made by registered person through electronic commerce", 5)
    out["3_1_1ii"] = dict(zip(["taxable_value", "igst", "cgst", "sgst", "cess"], v))

    v, _ = _row(lines, "Supplies made to Unregistered Persons", 2)
    out["3_2_unregistered"] = dict(zip(["taxable_value", "igst"], v))
    v, _ = _row(lines, "Supplies made to Composition Taxable", 2)
    out["3_2_composition"] = dict(zip(["taxable_value", "igst"], v))
    v, _ = _row(lines, "Supplies made to UIN holders", 2)
    out["3_2_uin"] = dict(zip(["taxable_value", "igst"], v))

    v, _ = _row(lines, "(1) Import of goods", 4)
    out["4a1"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "(2) Import of services", 4)
    out["4a2"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "Inward supplies liable to reverse charge (other than 1 & 2", 4)
    out["4a3"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "Inward supplies from ISD", 4)
    out["4a4"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "All other ITC", 4)
    out["4a5"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "As per rules 38", 4)
    out["4b1"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, i_4b2 = _row(lines, "(2) Others", 4)
    out["4b2"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "Net ITC available (A-B)", 4)
    out["4c"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    v, _ = _row(lines, "ITC reclaimed which was reversed under Table 4(B)(2)", 1)
    if v[0] is None:
        v, _ = _row(lines, "As per section 17(5)", 1)  # pre-Aug'22 label
    out["4d1"] = {"igst": v[0]}
    v, _ = _row(lines, "Ineligible ITC under section 16(4)", 1)
    if v[0] is None:
        v, _ = _row(lines, "(2) Others", 1, start=(i_4b2 + 1 if i_4b2 is not None else 0))
    out["4d2"] = {"igst": v[0]}

    i5 = _find_line(lines, "From a supplier under composition scheme")
    if i5 is not None:
        v = trailing_numeric_tokens(lines[i5])
        v = (v + [None, None])[:2]
    else:
        v = [None, None]
    out["5_exempt_inter"] = {"value": v[0]}
    out["5_exempt_intra"] = {"value": v[1]}
    i5b = _find_line(lines, "Non GST supply")
    if i5b is not None:
        v = trailing_numeric_tokens(lines[i5b])
        v = (v + [None, None])[:2]
    else:
        v = [None, None]
    out["5_nongst_inter"] = {"value": v[0]}
    out["5_nongst_intra"] = {"value": v[1]}

    v, _ = _row(lines, "Interest Paid", 4)
    out["5_1_interest"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))
    i_interest = _find_line(lines, "Interest Paid")
    v, _ = _row(lines, "Late fee", 4, start=(i_interest + 1 if i_interest is not None else 0))
    out["5_1_latefee"] = dict(zip(["igst", "cgst", "sgst", "cess"], v))

    # 6.1 -- see extract_gstr3b_61() below. Text-line extraction can't
    # reliably reconstruct this table (rows wrap mid-number across lines),
    # so it's populated separately using pdfplumber's structured table
    # reader. Left as None here; the caller merges in extract_gstr3b_61().
    subfields8 = ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess",
                  "cash", "interest_cash", "late_fee_cash"]
    for sec in ("6_1a", "6_1b"):
        for head in ("igst", "cgst", "sgst", "cess"):
            out[f"{sec}_{head}"] = {sf: None for sf in subfields8}

    return out


_STRAY_LETTER_RE = re.compile(r"^[A-Za-z]{1,3}(\(?-?[\d,]+\.\d{1,2}\)?)$")


def _clean_cell(tok):
    tok = (tok or "").replace("\n", "").strip()
    m = _STRAY_LETTER_RE.match(tok)
    if m:
        tok = m.group(1)
    return parse_number(tok)


def extract_gstr3b_61(path):
    """
    GSTR-3B Table 6.1 (Payment of Tax), read via pdfplumber's structured
    table extraction rather than line text -- each cell comes back already
    isolated by column, which sidesteps the mid-number line-wrap that makes
    plain text extraction unreliable for this table. Uses the real 10-data-
    column layout (Tax payable, Adjustment of negative liability, Net Tax
    Payable, then the 4 ITC-utilisation columns, Cash, Interest, Late fee)
    and keeps the 8 our schema tracks, skipping Adjustment/Net Tax Payable.
    """
    subfields8 = ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess",
                  "cash", "interest_cash", "late_fee_cash"]
    out = {}
    for sec in ("6_1a", "6_1b"):
        for head in ("igst", "cgst", "sgst", "cess"):
            out[f"{sec}_{head}"] = {sf: None for sf in subfields8}

    import pdfplumber
    head_map = {"integratedtax": "igst", "centraltax": "cgst",
                "state/uttax": "sgst", "cess": "cess"}
    table = None
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            for t in page.extract_tables():
                flat = " ".join(str(c) for row in t[:2] for c in row if c)
                if "Descripti" in flat:
                    table = t
                    break
            if table:
                break
    if not table:
        return out

    section = None
    for row in table:
        label = (row[0] or "").replace("\n", "").strip()
        low = label.lower()
        if low.startswith("(a)"):
            section = "6_1a"
            continue
        if low.startswith("(b)"):
            section = "6_1b"
            continue
        key = head_map.get(low)
        if key is None or section is None or len(row) < 11:
            continue
        cells = [_clean_cell(c) for c in row[1:11]]
        # cells: [total_payable, adjustment(skip), net_payable(skip),
        #         itc_igst, itc_cgst, itc_sgst, itc_cess, cash, interest, latefee]
        vals = [cells[0], cells[3], cells[4], cells[5], cells[6], cells[7], cells[8], cells[9]]
        out[f"{section}_{key}"] = dict(zip(subfields8, vals))
    return out


def extract_gstr3b_meta(text):
    lines = text.split("\n")
    meta = {}
    for ln in lines:
        if ln.strip().startswith("GSTIN of the supplier"):
            m = GSTIN_RE.search(ln)
            if m:
                meta["gstin"] = m.group(0)
        if "Legal name of the registered person" in ln:
            meta["legal_name"] = ln.split("Legal name of the registered person", 1)[1].strip()
        if "Trade name, if any" in ln:
            meta["trade_name"] = ln.split("Trade name, if any", 1)[1].strip()
        if "2(c). ARN" in ln:
            m = ARN_RE.search(ln)
            if m:
                meta["arn"] = m.group(0)
        if "2(d). Date of ARN" in ln:
            m = DATE_RE.search(ln)
            if m:
                meta["date_of_arn"] = m.group(0)
    fy = FY_RE.search(text[:1500])
    if fy:
        meta["financial_year"] = f"{fy.group(1)}-{fy.group(2)}"
    has_311 = "3.1.1" in text[:4000]
    meta["format_label"] = "Post-Aug'22" if has_311 else "Pre-Aug'22 (no 3.1.1)"
    return meta
