GST SNAPSHOT — by Tax Without Tears
====================================
Offline GSTR-1 / GSTR-3B multi-period consolidator (AICA Level 2 capstone build)

WHAT THIS IS
------------
A desktop app that turns a stack of GSTR-1 or GSTR-3B PDFs into the same
formatted, multi-period Excel summary that the consolidate-gstr1-pdfs /
consolidate-gstr3b-pdfs Claude skills produce — but running fully on your
own machine, no internet or AI needed at runtime.

SETUP (one time, needs internet)
---------------------------------
1. Install Python 3.10 or newer from python.org if not already installed.
   Tick "Add python.exe to PATH" during setup.
2. Double-click run_gst_snapshot.bat. It installs two small libraries
   (openpyxl, pdfplumber) the first time, then opens the app.
   From then on the app runs fully offline — nothing is uploaded anywhere.

HOW TO USE
----------
1. Pick the GSTR-1 or GSTR-3B tab.
2. Fill in the entity details (GSTIN, legal name, etc.) once.
3. Click "⬆ Upload GSTR-1/3B PDF(s)" and select as many PDFs as you like
   in one go — one file per return period. Period labels are detected
   automatically from each PDF (falls back to the filename if it can't
   find one) — no prompt per file.
   Prefer to type figures yourself for a period? Use "+ Add Blank Period".
4. The app switches to the Comparison tab automatically — headline
   figures for every uploaded period, side by side, with a
   % Chg (First→Last) column.
5. Open "Infographic Comparison" for a visual dashboard: month-on-month
   trend charts, a sales/tax-payment composition pie chart for the latest
   period, headline ratio cards (credit note ratio, ITC utilisation,
   cash payment ratio, etc.), and — if both GSTR-1 and GSTR-3B are loaded
   for overlapping periods — a GSTR-1 vs GSTR-3B comparison chart plus a
   reconciliation table checking their declared outward value/tax match.
   Click "📄 Export Infographic to PDF" at any time to save this whole
   dashboard (KPIs, charts, and reconciliation) as a standalone PDF for
   sharing with a client or partner.
6. Open "Detailed Grid" and REVIEW every extracted figure before you
   trust it — this is the important step, read on below.
7. Click "Export to Excel" and choose where to save the workbook. The
   output includes the same formatted tabs the two Claude skills produce,
   plus a "0. Comparison" sheet mirroring the in-app comparison. (The
   Infographic tab is an on-screen dashboard only — it isn't exported to
   the workbook.)

⚠ READ THIS BEFORE YOU TRUST A SINGLE NUMBER IN THE AUTO-FILL
----------------------------------------------------------------
Auto-fill has been rewritten and tested against real filed GSTR-1 and
GSTR-3B PDFs (not just synthetic text), and now matches the source PDFs
exactly on every field it fills in — including GSTR-3B's Table 6.1
(Payment of Tax), which needed a structured cell-by-cell table read
(pdfplumber's extract_tables()) rather than plain text, since that
table's numbers wrap across lines in a way plain text can't reconstruct.

Still worth knowing:
  - Table 6.1 relies on the current GST-portal PDF layout (10 data
    columns, including "Adjustment of negative liability" and "Net Tax
    Payable" columns added after this schema was originally written). If
    a filing from an older portal layout doesn't match, that table's
    columns for that period will come back blank rather than guessed.
  - GSTR-1 Table 9A (amendments) sums all five amendment sub-blocks
    (B2B Regular, B2B Reverse Charge, B2CL, Exports, SEZ, Deemed
    Exports) into the one combined figure the schema expects.

Every other table — GSTR-1's 4 through 13, GSTR-3B's 3.1, 3.1.1, 3.2, 4
(ITC), 5, and 5.1 — has been verified figure-for-figure against real
filings, including negative credit-note values and cross-utilised ITC.
Still review the grid before exporting; a heuristic text parser can be
fooled by a PDF layout it hasn't seen yet.

FILES IN THIS FOLDER
---------------------
app.py              - the GUI (run this, or via the .bat)
extract.py           - best-effort PDF text extraction
fields.py            - table/field definitions + auto-fill trigger phrases
summary.py            - headline comparison metrics (Comparison tab + Excel sheet)
infographic.py         - trend/ratio/mix data prep for the Infographic Comparison tab
gstr1_workbook.py     - Excel builder for GSTR-1 (from the Claude skill)
gstr3b_workbook.py    - Excel builder for GSTR-3B (from the Claude skill)
logo.png              - Tax Without Tears branding
run_gst_snapshot.bat  - Windows one-click launcher

Formulas in the generated workbook (FY Total column) are stored as live
Excel SUM formulas with no cached value — they calculate automatically the
first time you open the file in Excel (this is normal Excel behaviour, not
a bug — if a formula cell briefly shows 0, press Ctrl+Alt+F9 to force a
recalculation).
