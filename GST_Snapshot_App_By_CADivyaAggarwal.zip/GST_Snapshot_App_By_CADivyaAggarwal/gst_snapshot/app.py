#!/usr/bin/env python3
"""
GST Snapshot — by Tax Without Tears
Offline GSTR-1 / GSTR-3B multi-period consolidator.

Run:  python app.py   (or double-click run_gst_snapshot.bat on Windows)

Workflow per return type:
  1. "Upload GSTR-1/3B PDF(s)" -- pick as many PDFs as you like at once,
     one per return period. Period labels are auto-detected (best-effort
     -- see extract.py); no per-file prompt.
  2. The Comparison tab opens automatically, showing headline figures
     side by side across every uploaded period.
  3. Open "Detailed Grid" to review/correct every extracted figure --
     auto-fill is heuristic, not verified. Nothing is final until you do.
  4. "Export to Excel" produces the same formatted workbook the
     consolidate-gstr1-pdfs / consolidate-gstr3b-pdfs skills produce,
     with an extra "0. Comparison" sheet mirroring the in-app view.
"""
import os
import re
import sys
import traceback
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import fields as F
import extract
import summary
import infographic
import gstr1_workbook
import gstr3b_workbook
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

NAVY = "#0A2647"
TEAL = "#144272"
ACCENT = "#2C74B3"
GOLD = "#F2A93B"
LIGHT = "#EAF3FB"
WHITE = "#FFFFFF"
GREEN = "#1E8E3E"

FONT_HEAD = ("Segoe UI", 20, "bold")
FONT_SUB = ("Segoe UI", 10)
FONT_SECTION = ("Segoe UI", 9, "bold")
FONT_LABEL = ("Segoe UI", 9)
FONT_BTN = ("Segoe UI", 10, "bold")


def _round_rect_points(x1, y1, x2, y2, r):
    return [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
            x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]


def _build_logo_card(logo_path, target_h=64, pad=14, radius=14,
                      shadow_blur=6, shadow_offset=(3, 4)):
    """
    Composite the logo onto a white rounded card with a soft drop shadow,
    entirely in PIL, so it reads clearly against the navy header instead
    of blending into it. Returns an RGBA PIL Image, or None if PIL isn't
    available (caller falls back to a flat canvas-drawn version).
    """
    from PIL import Image, ImageDraw, ImageFilter
    logo = Image.open(logo_path).convert("RGBA")
    scale = target_h / logo.height
    logo = logo.resize((max(1, round(logo.width * scale)), target_h), Image.LANCZOS)

    plate_w, plate_h = logo.width + pad * 2, logo.height + pad * 2
    margin = shadow_blur * 2 + max(shadow_offset)
    cw, ch = plate_w + margin * 2, plate_h + margin * 2

    card = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))

    shadow = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    sx0, sy0 = margin + shadow_offset[0], margin + shadow_offset[1]
    ImageDraw.Draw(shadow).rounded_rectangle(
        [sx0, sy0, sx0 + plate_w, sy0 + plate_h], radius=radius, fill=(0, 0, 0, 130))
    shadow = shadow.filter(ImageFilter.GaussianBlur(shadow_blur))
    card = Image.alpha_composite(card, shadow)

    plate = Image.new("RGBA", (cw, ch), (0, 0, 0, 0))
    px0, py0 = margin, margin
    ImageDraw.Draw(plate).rounded_rectangle(
        [px0, py0, px0 + plate_w, py0 + plate_h], radius=radius,
        fill=(255, 255, 255, 255), outline=(214, 221, 230, 255), width=1)
    card = Image.alpha_composite(card, plate)

    lx, ly = px0 + (plate_w - logo.width) // 2, py0 + (plate_h - logo.height) // 2
    card.alpha_composite(logo, (lx, ly))
    return card


def _fmt_num(val):
    """Fixed-point display for auto-filled numbers -- never scientific
    notation (Python's :g switches to it above ~1e6, which silently loses
    precision on real GST figures once typed into an Entry as text)."""
    s = f"{val:.2f}"
    if "." in s:
        s = s.rstrip("0").rstrip(".")
    return s


class ScrollableGrid(ttk.Frame):
    """A scrollable (both directions) frame that holds the entry grid."""

    def __init__(self, parent):
        super().__init__(parent)
        self.canvas = tk.Canvas(self, bg=WHITE, highlightthickness=0)
        vbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        hbar = ttk.Scrollbar(self, orient="horizontal", command=self.canvas.xview)
        self.inner = tk.Frame(self.canvas, bg=WHITE)
        self.inner.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")),
        )
        self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.canvas.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)

        self.canvas.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(0, weight=1)

        self.canvas.bind("<MouseWheel>", self._on_wheel)
        self.canvas.bind("<Enter>", lambda e: self.canvas.focus_set())

    def _on_wheel(self, event):
        self.canvas.yview_scroll(int(-event.delta / 120), "units")


def _build_excel_label_map(build_module, form_name):
    """
    Pull the section titles and field labels straight from the same
    workbook-builder module used for the .xlsx export, so the Detailed
    Grid reads word-for-word the same as the Excel output rather than a
    re-approximation of it. Returns {table_key: (section_title, {subfield: (label, is_int)})}.
    """
    m = {}
    if form_name == "GSTR-1":
        for key, title, rows in build_module.TABLE_DEFS:
            m[key] = (title, {field: (label, fmt is build_module.INT)
                               for label, field, fmt in rows})
        m["13"] = ("TABLE 13 — Documents Issued",
                   {"docs": ("Net Documents Issued", True)})
        m["total_liability"] = (
            "TOTAL LIABILITY (Outward Supplies other than Reverse Charge)",
            {"value": ("Total Taxable Value (₹)", False), "igst": ("Total IGST (₹)", False),
             "cgst": ("Total CGST (₹)", False), "sgst": ("Total SGST (₹)", False)})
    else:
        for title, subfields, key, labels in build_module.SECTION_ROWS:
            m[key] = (title, {sf: (lbl, False) for sf, lbl in zip(subfields, labels)})
    return m


def _excel_style_display(val, is_int=False):
    """Render a number the way the Excel workbook does: comma-grouped,
    parentheses for negatives, a bare dash for zero -- so an auto-filled
    Detailed Grid cell reads the same as the exported .xlsx. parse_number()
    already round-trips '-' and '(1,234.56)' correctly on export."""
    if val is None:
        return ""
    if val == 0:
        return "-"
    s = f"{abs(val):,.0f}" if is_int else f"{abs(val):,.2f}"
    return f"({s})" if val < 0 else s


class ReturnTab(ttk.Frame):
    """One tab: GSTR-1 or GSTR-3B consolidator, entirely self-contained."""

    def __init__(self, parent, form_name, table_defs, meta_text_rows,
                 entity_fields, build_module, out_prefix, status_cb):
        super().__init__(parent, padding=10)
        self.form_name = form_name
        self.table_defs = table_defs
        self.meta_text_rows = meta_text_rows  # [(key, label)]
        self.entity_fields = entity_fields    # [(key, label)]
        self.build_module = build_module
        self.out_prefix = out_prefix
        self.status_cb = status_cb

        self.periods = []            # ordered list of period labels (kept chronological)
        self.period_widgets = {}     # period -> [(row_idx, widget), ...] for regrid/removal
        self.entity_entries = {}     # key -> Entry
        self.cells = {}              # (row_key, period) -> Entry
        self._insertion_seq = {}     # period -> upload order (tiebreak for unparseable labels)
        self.excel_labels = _build_excel_label_map(build_module, form_name)

        self._build_toolbar()
        self._build_entity_form()
        self._build_grid_area()

    # -- UI construction ---------------------------------------------
    def _build_toolbar(self):
        bar = tk.Frame(self, bg=LIGHT)
        bar.pack(fill="x", pady=(0, 8))
        tk.Label(bar, text=f"{self.form_name} Consolidator", font=("Segoe UI", 13, "bold"),
                 bg=LIGHT, fg=NAVY).pack(side="left", padx=(4, 16), pady=6)

        def mkbtn(text, cmd, bg=ACCENT, fg="white"):
            b = tk.Button(bar, text=text, command=cmd, font=FONT_BTN, bg=bg, fg=fg,
                           activebackground=TEAL, activeforeground="white",
                           relief="flat", padx=12, pady=6, cursor="hand2")
            b.pack(side="left", padx=4, pady=6)
            return b

        mkbtn(f"⬆ Upload {self.form_name} PDF(s)", self.upload_pdfs, bg=GOLD, fg=NAVY)
        mkbtn("+ Add Blank Period", self.add_blank_period, bg=TEAL)
        mkbtn("Remove Last Period", self.remove_last_period, bg="#B23B3B")
        mkbtn("Export to Excel", self.generate, bg=GREEN)

    def _build_entity_form(self):
        frm = tk.LabelFrame(self, text="Entity details (applies to whole workbook)",
                             font=FONT_SECTION, bg=WHITE, fg=NAVY, padx=8, pady=6)
        frm.pack(fill="x", pady=(0, 8))
        for i, (key, label) in enumerate(self.entity_fields):
            tk.Label(frm, text=label, font=FONT_LABEL, bg=WHITE).grid(
                row=0, column=2 * i, sticky="w", padx=(4, 4))
            e = tk.Entry(frm, width=20, font=FONT_LABEL)
            e.grid(row=0, column=2 * i + 1, sticky="w", padx=(0, 12))
            self.entity_entries[key] = e

    def _build_grid_area(self):
        self.inner_nb = ttk.Notebook(self)
        self.inner_nb.pack(fill="both", expand=True)
        self.inner_nb.bind("<<NotebookTabChanged>>", self._on_inner_tab_changed)

        cmp_frame = tk.Frame(self.inner_nb, bg=WHITE)
        self.inner_nb.add(cmp_frame, text="  📊 Comparison  ")
        self._build_comparison_view(cmp_frame)

        info_frame = tk.Frame(self.inner_nb, bg=WHITE)
        self.inner_nb.add(info_frame, text="  📈 Infographic Comparison  ")
        self._build_infographic_view(info_frame)

        grid_frame = tk.Frame(self.inner_nb, bg=WHITE)
        self.inner_nb.add(grid_frame, text="  📝 Detailed Grid (edit here)  ")
        self.grid_holder = ScrollableGrid(grid_frame)
        self.grid_holder.pack(fill="both", expand=True)
        self.inner = self.grid_holder.inner
        self._draw_row_labels()

    def _build_comparison_view(self, parent):
        tk.Label(parent, text="Auto-refreshes from the Detailed Grid whenever you open this tab.",
                 font=("Segoe UI", 8, "italic"), bg=WHITE, fg="#666").pack(anchor="w", padx=6, pady=(4, 0))
        style = ttk.Style()
        style.configure("Cmp.Treeview", font=("Segoe UI", 9, "bold"), rowheight=26)
        style.configure("Cmp.Treeview.Heading", font=("Segoe UI", 10, "bold"),
                         background=NAVY, foreground="white")
        wrap = tk.Frame(parent, bg=WHITE)
        wrap.pack(fill="both", expand=True, padx=6, pady=6)
        self.cmp_tree = ttk.Treeview(wrap, style="Cmp.Treeview", show="tree headings")
        vbar = ttk.Scrollbar(wrap, orient="vertical", command=self.cmp_tree.yview)
        hbar = ttk.Scrollbar(wrap, orient="horizontal", command=self.cmp_tree.xview)
        self.cmp_tree.configure(yscrollcommand=vbar.set, xscrollcommand=hbar.set)
        self.cmp_tree.grid(row=0, column=0, sticky="nsew")
        vbar.grid(row=0, column=1, sticky="ns")
        hbar.grid(row=1, column=0, sticky="ew")
        wrap.grid_rowconfigure(0, weight=1)
        wrap.grid_columnconfigure(0, weight=1)
        self.cmp_tree.tag_configure("odd", background=LIGHT, foreground=NAVY)
        self.cmp_tree.tag_configure("even", background=WHITE, foreground=NAVY)

    def _on_inner_tab_changed(self, event):
        tab_text = self.inner_nb.tab(self.inner_nb.select(), "text")
        if "Comparison" in tab_text and "Infographic" not in tab_text:
            self.refresh_comparison()
        elif "Infographic" in tab_text:
            self.refresh_infographic()

    def refresh_comparison(self):
        tree = self.cmp_tree
        tree.delete(*tree.get_children())
        tree["columns"] = tuple(self.periods) + (("% Chg (First→Last)",) if len(self.periods) >= 2 else ())
        tree.heading("#0", text="Metric")
        tree.column("#0", width=260, anchor="w")
        for p in self.periods:
            tree.heading(p, text=p)
            tree.column(p, width=120, anchor="e")
        if len(self.periods) >= 2:
            tree.heading("% Chg (First→Last)", text="% Chg (First→Last)")
            tree.column("% Chg (First→Last)", width=140, anchor="e")

        if not self.periods:
            tree.insert("", "end", text="Add a period (upload a PDF or add blank) to see a comparison.")
            return

        try:
            if self.form_name == "GSTR-1":
                data = self._build_gstr1_data()
                rows = summary.gstr1_summary(data["months"])
            else:
                data = self._build_gstr3b_data()
                rows = summary.gstr3b_summary(data["months"])
        except Exception:
            tree.insert("", "end", text="Could not compute comparison — check the Detailed Grid for non-numeric entries.")
            return

        for i, (label, vals) in enumerate(rows):
            row_vals = [f"{vals.get(p, 0):,.2f}" for p in self.periods]
            if len(self.periods) >= 2:
                first, last = vals.get(self.periods[0], 0), vals.get(self.periods[-1], 0)
                if first:
                    chg = f"{(last - first) / abs(first) * 100:+.1f}%"
                elif last:
                    chg = "new"
                else:
                    chg = "-"
                row_vals.append(chg)
            tree.insert("", "end", text=label, values=row_vals,
                         tags=("odd" if i % 2 else "even",))

    # -- Infographic Comparison ----------------------------------------
    def _build_infographic_view(self, parent):
        bar = tk.Frame(parent, bg=WHITE)
        bar.pack(fill="x", padx=6, pady=(4, 0))
        tk.Label(bar, text="Auto-refreshes from the Detailed Grid whenever you open this tab.",
                 font=("Segoe UI", 8, "italic"), bg=WHITE, fg="#666").pack(side="left")
        tk.Button(bar, text="📄 Export Infographic to PDF", command=self.export_infographic_pdf,
                  font=FONT_BTN, bg=GREEN, fg="white", activebackground=TEAL,
                  activeforeground="white", relief="flat", padx=10, pady=4,
                  cursor="hand2").pack(side="right")
        holder = ScrollableGrid(parent)
        holder.pack(fill="both", expand=True, padx=4, pady=4)
        self.info_holder = holder
        self.info_content = tk.Frame(holder.inner, bg=WHITE)
        self.info_content.pack(fill="both", expand=True)
        self._info_canvas_widget = None  # matplotlib FigureCanvasTkAgg, tracked for cleanup
        self._last_recon = None

    def _clear_infographic(self):
        for w in self.info_content.winfo_children():
            w.destroy()
        self._info_canvas_widget = None

    def _stat_card(self, parent, title, value_text, accent):
        card = tk.Frame(parent, bg="white", highlightbackground="#D6DDE6",
                         highlightthickness=1, bd=0)
        tk.Frame(card, bg=accent, height=4).pack(fill="x")
        tk.Label(card, text=title, font=("Segoe UI", 8, "bold"), bg="white",
                 fg="#667085", wraplength=150, justify="left").pack(
            anchor="w", padx=10, pady=(8, 2))
        tk.Label(card, text=value_text, font=("Segoe UI", 16, "bold"), bg="white",
                 fg=NAVY).pack(anchor="w", padx=10, pady=(0, 10))
        return card

    @staticmethod
    def _pct_text(val):
        return "N/A" if val is None else f"{val:+.1f}%"

    def refresh_infographic(self):
        self._clear_infographic()
        if not self.periods:
            tk.Label(self.info_content, text="Add a period (upload a PDF or add blank) to see the infographic.",
                      font=FONT_LABEL, bg=WHITE, fg="#666").pack(anchor="w", padx=10, pady=20)
            return

        try:
            if self.form_name == "GSTR-1":
                data = self._build_gstr1_data()
                dash = infographic.gstr1_dashboard(data["months"])
            else:
                data = self._build_gstr3b_data()
                dash = infographic.gstr3b_dashboard(data["months"])
        except Exception:
            tk.Label(self.info_content, text="Could not build the infographic — check the "
                      "Detailed Grid for non-numeric entries.", font=FONT_LABEL, bg=WHITE,
                      fg="#B23B3B").pack(anchor="w", padx=10, pady=20)
            return

        self._render_kpi_cards(dash)
        self._render_charts(dash)
        self._render_reconciliation()

    def export_infographic_pdf(self):
        if not self.periods:
            messagebox.showwarning("No periods", "Add at least one period before exporting the infographic.")
            return
        try:
            from matplotlib.backends.backend_pdf import PdfPages  # noqa: F401 -- availability check
        except ImportError:
            messagebox.showerror(
                "matplotlib not installed",
                "The PDF export needs the 'matplotlib' package.\n\nRun:  pip install matplotlib\n\n"
                "(run_gst_snapshot.bat installs this automatically on Windows.)")
            return

        try:
            if self.form_name == "GSTR-1":
                data = self._build_gstr1_data()
                dash = infographic.gstr1_dashboard(data["months"])
            else:
                data = self._build_gstr3b_data()
                dash = infographic.gstr3b_dashboard(data["months"])
        except Exception:
            messagebox.showerror("Data error", traceback.format_exc())
            return

        # Reconciliation is optional (needs the sibling tab loaded too);
        # reuse whatever's already been computed for the on-screen view.
        rec = self._last_recon
        if rec is None:
            sib = getattr(self, "sibling", None)
            if sib is not None and sib.periods:
                try:
                    if self.form_name == "GSTR-1":
                        g1_months, g3_months = data["months"], sib._build_gstr3b_data()["months"]
                    else:
                        g1_months, g3_months = sib._build_gstr1_data()["months"], data["months"]
                    rec = infographic.reconcile_gstr1_vs_gstr3b(g1_months, g3_months)
                except Exception:
                    rec = None

        entity = self._entity_dict()
        default_name = f"{self.out_prefix}_Infographic.pdf"
        out_path = filedialog.asksaveasfilename(
            title="Save infographic as", defaultextension=".pdf",
            initialfile=default_name, filetypes=[("PDF document", "*.pdf")])
        if not out_path:
            return

        try:
            infographic.export_dashboard_pdf(out_path, self.form_name, entity, dash, rec)
        except Exception:
            messagebox.showerror("PDF export failed", traceback.format_exc())
            return

        self.status_cb(f"Infographic saved: {out_path}")
        if messagebox.askyesno("Done", f"Infographic PDF saved:\n{out_path}\n\nOpen the containing folder?"):
            folder = os.path.dirname(os.path.abspath(out_path))
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform == "darwin":
                os.system(f'open "{folder}"')
            else:
                os.system(f'xdg-open "{folder}"')

    def _render_kpi_cards(self, dash):
        row = tk.Frame(self.info_content, bg=WHITE)
        row.pack(fill="x", padx=6, pady=(6, 4))

        if self.form_name == "GSTR-1":
            cnr = dash["credit_note_ratio"][-1] if dash["credit_note_ratio"] else None
            aiv = dash["avg_invoice_value"][-1] if dash["avg_invoice_value"] else None
            docs = dash["documents"][-1] if dash["documents"] else None
            cards = [
                ("MoM Growth — Taxable Value", self._pct_text(dash["mom_growth"][-1]), ACCENT),
                ("Credit Note Ratio (latest period)",
                 "N/A" if cnr is None else f"{cnr:.1f}%", GOLD),
                ("Avg. Invoice Value (latest)",
                 "N/A" if aiv is None else f"₹{aiv:,.0f}", TEAL),
                ("Documents Issued (latest)", "N/A" if docs is None else f"{docs:,.0f}", GREEN),
            ]
        else:
            itc_r = dash["itc_utilisation_ratio"][-1] if dash["itc_utilisation_ratio"] else None
            cash_r = dash["cash_ratio"][-1] if dash["cash_ratio"] else None
            il = dash["interest_latefee"][-1] if dash["interest_latefee"] else 0
            cards = [
                ("MoM Growth — Outward Value", self._pct_text(dash["mom_growth"][-1]), ACCENT),
                ("ITC Utilisation Ratio (latest)",
                 "N/A" if itc_r is None else f"{itc_r:.1f}%", TEAL),
                ("Cash Payment Ratio (latest)",
                 "N/A" if cash_r is None else f"{cash_r:.1f}%", GOLD),
                ("Interest / Late Fee (latest)",
                 "None" if not il else f"₹{il:,.0f}", GREEN if not il else "#B23B3B"),
            ]
        for title, value, color in cards:
            self._stat_card(row, title, value, color).pack(side="left", padx=6, fill="y")

    def _render_charts(self, dash):
        try:
            from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
        except ImportError:
            tk.Label(self.info_content, text=(
                "Charts need the 'matplotlib' package.\n\nRun:  pip install matplotlib\n\n"
                "(run_gst_snapshot.bat installs this automatically on Windows.)"),
                font=FONT_LABEL, bg=WHITE, fg="#B23B3B", justify="left").pack(
                anchor="w", padx=10, pady=20)
            return

        fig = infographic.build_main_figure(dash, self.form_name)
        canvas = FigureCanvasTkAgg(fig, master=self.info_content)
        canvas.draw()
        widget = canvas.get_tk_widget()
        widget.pack(fill="both", expand=True, padx=6, pady=6)
        self._info_canvas_widget = canvas

    def _render_reconciliation(self):
        self._last_recon = None
        sib = getattr(self, "sibling", None)
        if sib is None or not sib.periods:
            return
        try:
            if self.form_name == "GSTR-1":
                g1_months = self._build_gstr1_data()["months"]
                g3_months = sib._build_gstr3b_data()["months"]
            else:
                g1_months = sib._build_gstr1_data()["months"]
                g3_months = self._build_gstr3b_data()["months"]
            rec = infographic.reconcile_gstr1_vs_gstr3b(g1_months, g3_months)
        except Exception:
            return
        self._last_recon = rec

        box = tk.LabelFrame(self.info_content, text="GSTR-1 vs GSTR-3B Reconciliation (outward value/tax)",
                             font=FONT_SECTION, bg=WHITE, fg=NAVY, padx=8, pady=8)
        box.pack(fill="both", expand=True, padx=6, pady=(0, 10))

        if not rec["rows"]:
            tk.Label(box, text="No overlapping periods between the two returns yet.",
                     font=FONT_LABEL, bg=WHITE).pack(anchor="w")
        else:
            try:
                from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
                rfig = infographic.build_recon_figure(rec, figsize=(12.5, 6.5))
                rcanvas = FigureCanvasTkAgg(rfig, master=box)
                rcanvas.draw()
                rcanvas.get_tk_widget().pack(fill="both", expand=True)
                self._info_recon_canvas = rcanvas
            except ImportError:
                self._render_reconciliation_table_fallback(box, rec)
        extra = []
        if rec["only_gstr1"]:
            extra.append("In GSTR-1 only: " + ", ".join(rec["only_gstr1"]))
        if rec["only_gstr3b"]:
            extra.append("In GSTR-3B only: " + ", ".join(rec["only_gstr3b"]))
        if extra:
            tk.Label(box, text="  |  ".join(extra), font=("Segoe UI", 8, "italic"),
                     bg=WHITE, fg="#667085").pack(anchor="w", pady=(6, 0))

    def _render_reconciliation_table_fallback(self, box, rec):
        """Plain Treeview table, used only if matplotlib isn't installed
        (the chart+table combo above needs it; the KPI cards don't)."""
        cols = ("Period", "GSTR-1 Value", "GSTR-3B Value", "Value Diff", "Tax Diff", "Status")
        tree = ttk.Treeview(box, columns=cols, show="headings", height=len(rec["rows"]))
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=130, anchor="center")
        tree.column("Period", width=90)
        for r in rec["rows"]:
            status = "✓ Matched" if r["matched"] else "⚠ Mismatch"
            tree.insert("", "end", values=(
                r["period"], f"{r['gstr1_value']:,.2f}", f"{r['gstr3b_value']:,.2f}",
                f"{r['value_diff']:,.2f}", f"{r['tax_diff']:,.2f}", status),
                tags=("bad",) if not r["matched"] else ())
        tree.tag_configure("bad", background="#FCE4E4")
        tree.pack(fill="x")

    def _row_defs(self):
        """Flattened row list: (row_key, display_label, is_section_header).
        Section titles and field labels are pulled from excel_labels (the
        same strings the .xlsx export uses) wherever available, so the
        Detailed Grid reads the same as the Excel output; only genuinely
        GUI-only rows (Filing Meta) use their own fields.py labels."""
        rows = [("__section_meta__", "Filing Meta", True)]
        for key, label in self.meta_text_rows:
            rows.append((key, "   " + label.upper(), False))
        for key, label, subfields, _triggers in self.table_defs:
            title, field_map = self.excel_labels.get(key, (label, {}))
            rows.append((f"__section_{key}__", title, True))
            for sf in subfields:
                sub_label, _is_int = field_map.get(sf, (sf.replace("_", " ").upper(), False))
                rows.append((f"{key}.{sf}", "   " + sub_label, False))
        return rows

    LABEL_COL_CHARS = 46
    LABEL_WRAP_PX = 340

    def _draw_row_labels(self):
        """All label cells are placed directly in the single shared grid
        (self.inner) -- see _add_period_column for why this matters. The
        Excel-derived section titles run long (e.g. "TABLE 4A — B2B Regular
        Supplies (Taxable outward supplies to registered persons)"), so
        these wrap within a fixed pixel width instead of being clipped."""
        self.row_defs = self._row_defs()
        tk.Label(self.inner, text="Particulars", font=FONT_SECTION, bg=NAVY, fg="white",
                 width=self.LABEL_COL_CHARS, anchor="w", padx=6, pady=4
                 ).grid(row=0, column=0, sticky="nsew")
        for r, (key, label, is_section) in enumerate(self.row_defs, start=1):
            bg = TEAL if is_section else (LIGHT if r % 2 == 0 else WHITE)
            fg = "white" if is_section else "black"
            font = FONT_SECTION if is_section else FONT_LABEL
            tk.Label(self.inner, text=label, font=font, bg=bg, fg=fg,
                     width=self.LABEL_COL_CHARS, anchor="w", padx=6, pady=4,
                     justify="left", wraplength=self.LABEL_WRAP_PX
                     ).grid(row=r, column=0, sticky="nsew")

    def _period_sort_key(self, period):
        """Chronological sort key for 'Mon-YYYY' labels; unparseable labels
        (custom text, quarters, etc.) sort after all parseable ones, in the
        order they were added."""
        m = re.match(r"^([A-Za-z]{3})-(\d{4})", period.strip())
        if m:
            mon = m.group(1).capitalize()
            months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                      "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
            if mon in months:
                return (0, int(m.group(2)), months.index(mon))
        return (1, self._insertion_seq.get(period, 0), 0)

    def _add_period_column(self, period):
        """
        Every cell for this period is placed directly into the SAME shared
        grid as the label column (self.inner), rather than into a separate
        per-column Frame. This is deliberate: Tkinter's grid geometry
        manager only guarantees matching row heights for widgets that share
        one grid -- widgets in sibling Frames each get their own
        independent row-sizing pass, which is what caused the row drift /
        misalignment between the label column and the data columns
        (worse the further down the sheet, and worse mid-scroll).
        """
        self._insertion_seq[period] = len(self._insertion_seq)
        self.periods.append(period)
        self.periods.sort(key=self._period_sort_key)

        widgets = []
        header = tk.Label(self.inner, text=period, font=FONT_SECTION, bg=NAVY, fg="white",
                           width=19, anchor="center", pady=4)
        widgets.append((0, header))
        for r, (key, label, is_section) in enumerate(self.row_defs, start=1):
            if is_section:
                w = tk.Label(self.inner, bg=TEAL, width=19, height=1)
                widgets.append((r, w))
                continue
            bg = LIGHT if r % 2 == 0 else WHITE
            e = tk.Entry(self.inner, width=19, font=FONT_LABEL, justify="right",
                         relief="solid", bd=1, bg=bg)
            widgets.append((r, e))
            self.cells[(key, period)] = e
        self.period_widgets[period] = widgets

        self._regrid_period_columns()
        self.inner.update_idletasks()
        self.grid_holder.canvas.configure(scrollregion=self.grid_holder.canvas.bbox("all"))

    def _regrid_period_columns(self):
        """Re-lay-out every period's cells left-to-right in self.periods'
        (chronological) order -- called after any add/remove."""
        for idx, period in enumerate(self.periods, start=1):
            for row_idx, widget in self.period_widgets[period]:
                widget.grid(row=row_idx, column=idx, sticky="nsew", padx=(1, 0),
                            ipady=(2 if isinstance(widget, tk.Entry) else 0))

    def add_blank_period(self):
        label = simpledialog.askstring("Period label", "Enter period label (e.g. Apr-2024):",
                                        parent=self)
        if not label:
            return
        if label in self.periods:
            messagebox.showwarning("Duplicate", "That period label is already in the grid.")
            return
        self._add_period_column(label)
        self.inner_nb.select(1)
        self.status_cb(f"Added blank period '{label}'. Fill in figures on this grid, then Export to Excel.")

    def upload_pdfs(self):
        """Multi-select upload. Period label is auto-detected per file (from
        the PDF's own tax-period field, falling back to the filename) so a
        batch of files loads in one go with no per-file prompt."""
        paths = filedialog.askopenfilenames(
            title=f"Select {self.form_name} PDF(s) — one file per return period",
            filetypes=[("PDF files", "*.pdf")])
        if not paths:
            return

        try:
            import pdfplumber  # noqa: F401 -- fail fast with one clear dialog
        except ImportError:
            messagebox.showerror(
                "pdfplumber not installed",
                "Auto-extraction needs the 'pdfplumber' package.\n\nRun:  pip install pdfplumber\n\n"
                "(run_gst_snapshot.bat installs this automatically on Windows.)")
            return

        added, failed = [], []
        for path in paths:
            fname = os.path.basename(path)
            self.status_cb(f"Reading {fname} ...")
            self.update_idletasks()
            try:
                text = extract.read_pdf_text(path)
                label = extract.detect_period(text, os.path.splitext(fname)[0])
                base_label, n = label, 2
                while label in self.periods:
                    label = f"{base_label} ({n})"
                    n += 1
                if self.form_name == "GSTR-1":
                    meta = extract.extract_gstr1_meta(text)
                    data = extract.extract_gstr1(text)
                else:
                    meta = extract.extract_gstr3b_meta(text)
                    data = extract.extract_gstr3b(text)
                    try:
                        data.update(extract.extract_gstr3b_61(path))
                    except Exception:
                        pass  # Table 6.1 stays blank if the structured table read fails
            except Exception as exc:
                failed.append(f"{fname}: {exc}")
                continue

            self._add_period_column(label)

            for k in ("gstin", "legal_name", "trade_name"):
                if meta.get(k) and k in self.entity_entries and not self.entity_entries[k].get():
                    self.entity_entries[k].insert(0, meta[k])
            if meta.get("financial_year"):
                for k in ("financial_year", "period_label"):
                    if k in self.entity_entries and not self.entity_entries[k].get():
                        self.entity_entries[k].insert(0, meta["financial_year"] if k == "financial_year"
                                                       else f"FY {meta['financial_year']}")
            if meta.get("arn"):
                for key, _lbl in self.meta_text_rows:
                    if "arn" in key.lower() and "date" not in key.lower():
                        self.cells[(key, label)].insert(0, meta["arn"])
                        break
            arn_date = meta.get("arn_date") or meta.get("date_of_arn")
            if arn_date:
                for key, _lbl in self.meta_text_rows:
                    if "date" in key.lower():
                        self.cells[(key, label)].insert(0, arn_date)
                        break
            if meta.get("format_label"):
                for key, _lbl in self.meta_text_rows:
                    if "format" in key.lower():
                        self.cells[(key, label)].insert(0, meta["format_label"])
                        break

            for tkey, _tlabel, subfields, _trig in self.table_defs:
                _title, field_map = self.excel_labels.get(tkey, ("", {}))
                for sf in subfields:
                    val = data.get(tkey, {}).get(sf)
                    if val is not None:
                        is_int = field_map.get(sf, (None, False))[1]
                        self.cells[(f"{tkey}.{sf}", label)].insert(
                            0, _excel_style_display(val, is_int))
            added.append(label)

        self.inner_nb.select(0)  # jump straight to the Comparison view, auto-refreshed on select
        msg = f"Uploaded {len(added)} period(s): {', '.join(added)}." if added else "No periods added."
        if failed:
            msg += f"  {len(failed)} file(s) failed: {'; '.join(failed)}"
        msg += "  Auto-fill is heuristic — open Detailed Grid to correct any figure before exporting."
        self.status_cb(msg)

    def remove_last_period(self):
        if not self.periods:
            return
        period = self.periods.pop()
        for _row_idx, widget in self.period_widgets.pop(period):
            widget.destroy()
        for (key, p) in list(self.cells.keys()):
            if p == period:
                del self.cells[(key, p)]
        self.status_cb(f"Removed period '{period}'.")

    # -- Data collection / export -------------------------------------
    def _cell_value(self, row_key, period):
        entry = self.cells.get((row_key, period))
        if entry is None:
            return None
        txt = entry.get().strip()
        if txt == "":
            return None
        val = extract.parse_number(txt)
        return val if val is not None else txt  # keep text as-is if not numeric (e.g. ARN)

    def generate(self):
        if not self.periods:
            messagebox.showwarning("No periods", "Add at least one period before generating.")
            return

        blanks = []
        for tkey, _label, subfields, _trig in self.table_defs:
            for period in self.periods:
                for sf in subfields:
                    if self._cell_value(f"{tkey}.{sf}", period) is None:
                        blanks.append(f"{period} / {tkey}.{sf}")
        if blanks:
            proceed = messagebox.askyesno(
                "Blank cells found",
                f"{len(blanks)} figure(s) are blank and will be treated as 0 (nil).\n\n"
                "Continue and generate anyway?")
            if not proceed:
                return

        try:
            if self.form_name == "GSTR-1":
                data = self._build_gstr1_data()
            else:
                data = self._build_gstr3b_data()
        except Exception:
            messagebox.showerror("Data error", traceback.format_exc())
            return

        default_name = f"{self.out_prefix}_Summary.xlsx"
        out_path = filedialog.asksaveasfilename(
            title="Save workbook as", defaultextension=".xlsx",
            initialfile=default_name, filetypes=[("Excel workbook", "*.xlsx")])
        if not out_path:
            return

        try:
            self.build_module.build(data, out_path)
            periods = data["periods"] if self.form_name == "GSTR-1" else [m["label"] for m in data["months"]]
            rows = (summary.gstr1_summary(data["months"]) if self.form_name == "GSTR-1"
                    else summary.gstr3b_summary(data["months"]))
            self._append_comparison_sheet(out_path, rows, periods)
        except Exception:
            messagebox.showerror("Workbook generation failed", traceback.format_exc())
            return

        self.status_cb(f"Saved: {out_path}")
        if messagebox.askyesno("Done", f"Workbook saved:\n{out_path}\n\nOpen the containing folder?"):
            folder = os.path.dirname(os.path.abspath(out_path))
            if sys.platform.startswith("win"):
                os.startfile(folder)
            elif sys.platform == "darwin":
                os.system(f'open "{folder}"')
            else:
                os.system(f'xdg-open "{folder}"')

    def _append_comparison_sheet(self, out_path, rows, periods):
        """Inserts a '0. Comparison' sheet at the front of the just-built
        workbook, mirroring what's shown on the in-app Comparison tab."""
        wb = openpyxl.load_workbook(out_path)
        ws = wb.create_sheet("0. Comparison", 0)
        navy_fill = PatternFill("solid", fgColor="1F3864")
        band_fill = PatternFill("solid", fgColor="D9E2F3")
        thin = Side(style="thin", color="B7B7B7")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        header_font = Font(name="Arial", size=10, bold=True, color="FFFFFF")
        label_font = Font(name="Arial", size=10)
        num_font = Font(name="Arial", size=10)
        fmt = '#,##0.00;(#,##0.00);"-"'

        last_col = 1 + len(periods) + 1
        ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
        title = f"{self.form_name} — HEADLINE COMPARISON ACROSS PERIODS"
        c = ws.cell(row=1, column=1, value=title)
        c.font = Font(name="Arial", size=13, bold=True, color="FFFFFF")
        c.fill = navy_fill
        c.alignment = Alignment(horizontal="center", vertical="center")
        ws.row_dimensions[1].height = 22

        ws.cell(row=3, column=1, value="Metric").font = header_font
        ws.cell(row=3, column=1).fill = navy_fill
        for i, p in enumerate(periods):
            cell = ws.cell(row=3, column=2 + i, value=p)
            cell.font = header_font
            cell.fill = navy_fill
            cell.alignment = Alignment(horizontal="center")
        chg_col = 2 + len(periods)
        if len(periods) >= 2:
            cell = ws.cell(row=3, column=chg_col, value="% Chg (First→Last)")
            cell.font = header_font
            cell.fill = navy_fill
            cell.alignment = Alignment(horizontal="center")

        for r, (label, vals) in enumerate(rows, start=4):
            band = band_fill if r % 2 == 0 else None
            lc = ws.cell(row=r, column=1, value=label)
            lc.font = label_font
            lc.border = border
            if band:
                lc.fill = band
            for i, p in enumerate(periods):
                v = vals.get(p, 0)
                dc = ws.cell(row=r, column=2 + i, value=v)
                dc.font = num_font
                dc.number_format = fmt
                dc.border = border
                dc.alignment = Alignment(horizontal="right")
                if band:
                    dc.fill = band
            if len(periods) >= 2:
                first, last = vals.get(periods[0], 0), vals.get(periods[-1], 0)
                chg = f"{(last - first) / abs(first) * 100:+.1f}%" if first else ("new" if last else "-")
                cc = ws.cell(row=r, column=chg_col, value=chg)
                cc.font = num_font
                cc.border = border
                cc.alignment = Alignment(horizontal="right")
                if band:
                    cc.fill = band

        ws.column_dimensions["A"].width = 34
        for i in range(len(periods) + 1):
            ws.column_dimensions[openpyxl.utils.get_column_letter(2 + i)].width = 16
        ws.freeze_panes = "B4"
        wb.save(out_path)

    def _entity_dict(self):
        return {k: self.entity_entries[k].get().strip() for k, _l in self.entity_fields}

    def _build_gstr1_data(self):
        entity = self._entity_dict()
        entity_out = {
            "gstin": entity.get("gstin", ""),
            "legal_name": entity.get("legal_name", ""),
            "trade_name": entity.get("trade_name", ""),
            "financial_year": entity.get("financial_year", ""),
        }
        months = []
        for period in self.periods:
            tables = {}
            for tkey, _label, subfields, _trig in self.table_defs:
                allblank = all(self._cell_value(f"{tkey}.{sf}", period) is None for sf in subfields)
                if allblank:
                    tables[tkey] = {sf: 0 for sf in subfields}
                else:
                    tables[tkey] = {sf: (self._cell_value(f"{tkey}.{sf}", period) or 0)
                                    for sf in subfields}
            months.append({
                "period": period,
                "arn": self._cell_value("__arn__", period) or "",
                "arn_date": self._cell_value("__arn_date__", period) or "",
                "tables": tables,
            })
        return {"entity": entity_out, "periods": list(self.periods), "months": months}

    def _build_gstr3b_data(self):
        entity = self._entity_dict()
        entity_out = {
            "gstin": entity.get("gstin", ""),
            "legal_name": entity.get("legal_name", ""),
            "trade_name": entity.get("trade_name", ""),
            "period_label": entity.get("period_label", ""),
        }
        months = []
        for period in self.periods:
            m = {
                "label": period,
                "arn": self._cell_value("__arn__", period) or "",
                "date_of_arn": self._cell_value("__arn_date__", period) or "",
                "format_label": self._cell_value("__format_label__", period) or "Post-Aug'22",
            }
            is_pre = "pre" in str(m["format_label"]).lower()
            for tkey, _label, subfields, _trig in self.table_defs:
                allblank = all(self._cell_value(f"{tkey}.{sf}", period) is None for sf in subfields)
                if tkey in ("3_1_1i", "3_1_1ii") and is_pre:
                    m[tkey] = None
                elif allblank:
                    m[tkey] = {sf: 0 for sf in subfields}
                else:
                    m[tkey] = {sf: (self._cell_value(f"{tkey}.{sf}", period) or 0) for sf in subfields}
            months.append(m)
        return {"entity": entity_out, "months": months}


class GSTSnapshotApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GST Snapshot — by Tax Without Tears")
        self.geometry("1280x760")
        self.configure(bg=WHITE)
        self._set_window_icon()
        self._build_header()
        self._build_tabs()
        self._build_status_bar()

    def _set_window_icon(self):
        """Title-bar/taskbar icon. Left unset, Tk shows its own generic
        default icon (a small feather) instead of our logo -- easy to
        mistake for a second, blurrier copy of the brand mark."""
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logo.png")
        if not os.path.exists(logo_path):
            return
        try:
            from PIL import Image, ImageTk
            im = Image.open(logo_path).convert("RGBA")
            icons = []
            for size in (16, 32, 48):
                scale = size / max(im.size)
                resized = im.resize((max(1, round(im.width * scale)),
                                      max(1, round(im.height * scale))), Image.LANCZOS)
                canvas = Image.new("RGBA", (size, size), (0, 0, 0, 0))
                canvas.paste(resized, ((size - resized.width) // 2, (size - resized.height) // 2), resized)
                icons.append(ImageTk.PhotoImage(canvas))
            self._icon_imgs = icons  # keep a reference, Tk drops unreferenced PhotoImages
            self.iconphoto(True, *icons)
        except Exception:
            pass

    def _build_header(self):
        HEADER_H = 140
        header = tk.Canvas(self, height=HEADER_H, highlightthickness=0)
        header.pack(fill="x")

        def draw_gradient(event=None):
            header.delete("grad")
            w = header.winfo_width() or 1280
            h = HEADER_H
            steps = 60
            for i in range(steps):
                t = i / steps
                r = int(int(NAVY[1:3], 16) * (1 - t) + int(TEAL[1:3], 16) * t)
                g = int(int(NAVY[3:5], 16) * (1 - t) + int(TEAL[3:5], 16) * t)
                b = int(int(NAVY[5:7], 16) * (1 - t) + int(TEAL[5:7], 16) * t)
                color = f"#{r:02x}{g:02x}{b:02x}"
                x0 = int(w * i / steps)
                x1 = int(w * (i + 1) / steps)
                header.create_rectangle(x0, 0, x1, h, fill=color, outline=color, tags="grad")
            header.tag_lower("grad")

        header.bind("<Configure>", draw_gradient)

        logo_cy = HEADER_H // 2  # vertical center for the logo card
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logo.png")
        text_x = 24
        if os.path.exists(logo_path):
            try:
                from PIL import ImageTk
                # The card (logo + white plate + blurred shadow) is taller
                # than the plain logo -- at the old 92px header height this
                # shadow was being clipped by the canvas edge, which is what
                # made the whole thing read as fuzzy/"not clear". Header is
                # now tall enough to show the full card with room to spare.
                card = _build_logo_card(logo_path)
                img = ImageTk.PhotoImage(card)
                self._logo_img = img
                header.create_image(6, logo_cy, image=img, anchor="w")
                text_x = 6 + img.width() + 10
            except Exception:
                # No PIL: draw a flat (unblurred) white card on the canvas
                # itself, then place the logo on top of it.
                try:
                    img = tk.PhotoImage(file=logo_path)
                    factor = max(1, img.height() // 60)
                    if factor > 1:
                        img = img.subsample(factor, factor)
                    self._logo_img = img
                    pad = 12
                    x0, y0 = 14, logo_cy - img.height() // 2 - pad
                    x1, y1 = x0 + img.width() + pad * 2, y0 + img.height() + pad * 2
                    header.create_polygon(_round_rect_points(x0 + 3, y0 + 4, x1 + 3, y1 + 4, 12),
                                           smooth=True, fill="#06172B", outline="")
                    header.create_polygon(_round_rect_points(x0, y0, x1, y1, 12),
                                           smooth=True, fill="white", outline="#D6DDE6")
                    header.create_image(x0 + pad, logo_cy, image=img, anchor="w")
                    text_x = x1 + 16
                except Exception:
                    text_x = 24

        header.create_text(text_x, logo_cy - 20, text="GST SNAPSHOT", anchor="w",
                            font=FONT_HEAD, fill="white")
        header.create_text(text_x, logo_cy + 12, text="By Tax Without Tears", anchor="w",
                            font=("Segoe UI", 12, "italic"), fill=GOLD)
        header.create_text(1260, HEADER_H - 22, text="Offline GSTR-1 / GSTR-3B Consolidator",
                            anchor="e", font=("Segoe UI", 9), fill="#CFE3F5")

    def _build_tabs(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background=WHITE, borderwidth=0)
        style.configure("TNotebook.Tab", font=("Segoe UI", 11, "bold"), padding=[16, 8],
                         background=LIGHT, foreground=NAVY)
        style.map("TNotebook.Tab", background=[("selected", ACCENT)],
                   foreground=[("selected", "white")])

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        tab1 = ReturnTab(nb, "GSTR-1", F.GSTR1_TABLES,
                          [("__arn__", "ARN"), ("__arn_date__", "ARN Date")],
                          [("gstin", "GSTIN"), ("legal_name", "Legal Name"),
                           ("trade_name", "Trade Name"), ("financial_year", "Financial Year")],
                          gstr1_workbook, "GSTR1", self.set_status)
        tab2 = ReturnTab(nb, "GSTR-3B", F.GSTR3B_TABLES,
                          [("__arn__", "ARN"), ("__arn_date__", "Date of ARN"),
                           ("__format_label__", "Format (type Pre-Aug'22 or Post-Aug'22)")],
                          [("gstin", "GSTIN"), ("legal_name", "Legal Name"),
                           ("trade_name", "Trade Name"), ("period_label", "FY / Period Label")],
                          gstr3b_workbook, "GSTR3B", self.set_status)
        nb.add(tab1, text="  GSTR-1  ")
        nb.add(tab2, text="  GSTR-3B  ")
        tab1.sibling = tab2  # cross-reference for the GSTR-1 vs GSTR-3B reconciliation check
        tab2.sibling = tab1

    def _build_status_bar(self):
        self.status = tk.Label(self, text=(
            "Ready. Upload one or more PDFs to auto-fill periods, or add a blank period to "
            "enter figures manually. Always review the Detailed Grid before exporting."),
            anchor="w", bg=NAVY, fg="white", font=("Segoe UI", 9), padx=10, pady=6)
        self.status.pack(fill="x", side="bottom")

    def set_status(self, text):
        self.status.config(text=text)


def main():
    # Windows renders Tk windows at 96 DPI internally, then lets Windows'
    # DPI-virtualization layer bitmap-stretch the whole window to match the
    # display's actual scaling (125%/150%/etc.) -- that's what makes an
    # un-aware Tk app look softly blurred on a modern high-DPI laptop, even
    # though nothing in the app itself is a low-res image. Declaring the
    # process DPI-aware makes Windows render it natively instead. Tried
    # most-capable API first: Per-Monitor-V2 (handles the app being
    # dragged between monitors with different scaling), then Per-Monitor,
    # then System-Aware, then the old unconditional API. No-op (and
    # harmless) on non-Windows platforms.
    if sys.platform.startswith("win"):
        import ctypes
        DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2 = ctypes.c_void_p(-4)
        try:
            ctypes.windll.user32.SetProcessDpiAwarenessContext(
                DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2)
        except Exception:
            try:
                ctypes.windll.shcore.SetProcessDpiAwareness(2)  # PER_MONITOR_DPI_AWARE
            except Exception:
                try:
                    ctypes.windll.shcore.SetProcessDpiAwareness(1)  # SYSTEM_DPI_AWARE
                except Exception:
                    try:
                        ctypes.windll.user32.SetProcessDPIAware()
                    except Exception:
                        pass

    app = GSTSnapshotApp()
    app.mainloop()


if __name__ == "__main__":
    main()
