@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   GST SNAPSHOT - by Tax Without Tears
echo ============================================
echo.

where python >nul 2>nul
if %errorlevel% neq 0 (
    echo Python was not found on this computer.
    echo Please install Python 3.10+ from https://www.python.org/downloads/
    echo ^(tick "Add python.exe to PATH" during setup^), then run this file again.
    pause
    exit /b 1
)

echo Checking required packages ^(openpyxl, pdfplumber^)...
python -c "import openpyxl" 2>nul
if %errorlevel% neq 0 (
    echo Installing openpyxl ...
    python -m pip install --quiet openpyxl
)
python -c "import pdfplumber" 2>nul
if %errorlevel% neq 0 (
    echo Installing pdfplumber ^(needed for PDF auto-fill^)...
    python -m pip install --quiet pdfplumber
)
python -c "import PIL" 2>nul
if %errorlevel% neq 0 (
    echo Installing Pillow ^(sharper logo rendering^)...
    python -m pip install --quiet Pillow
)
python -c "import matplotlib" 2>nul
if %errorlevel% neq 0 (
    echo Installing matplotlib ^(needed for the Infographic Comparison charts^)...
    python -m pip install --quiet matplotlib
)

echo.
echo Starting GST Snapshot ...
python app.py

if %errorlevel% neq 0 (
    echo.
    echo GST Snapshot closed with an error - see above.
    pause
)
