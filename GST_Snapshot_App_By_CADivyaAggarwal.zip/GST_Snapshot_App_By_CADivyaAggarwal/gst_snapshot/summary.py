"""
Headline comparison metrics shown on the dashboard (and appended as an
extra sheet in the exported workbook). Computed straight from the same
months[] structure used to build the full workbook, so the comparison
always matches whatever is in the detailed grid.
"""


def _t(month, key, field):
    """GSTR-1 lookup: tables nested under month['tables'][key]."""
    t = month.get("tables", {}).get(key) or {}
    v = t.get(field)
    return v or 0


def _t3b(month, key, field):
    """GSTR-3B lookup: tables are flat top-level keys on the month dict."""
    t = month.get(key) or {}
    v = t.get(field)
    return v or 0


def gstr1_summary(months):
    """Returns [(metric_label, {period: value}), ...]"""
    rows = [
        ("B2B Taxable Value (4A+4B)", lambda m: _t(m, "4A", "value") + _t(m, "4B", "value")),
        ("B2CL Value (5A)", lambda m: _t(m, "5A", "value")),
        ("B2CS Value (7)", lambda m: _t(m, "7", "value")),
        ("Exports Value (6A+6B)", lambda m: _t(m, "6A", "value") + _t(m, "6B", "value")),
        ("Nil / Exempt / Non-GST (8)", lambda m: _t(m, "8", "total")),
        ("Credit/Debit Notes Net (9B)",
         lambda m: _t(m, "9B_cdnr", "value") + _t(m, "9B_cdnur", "value")),
        ("Total Taxable Value", lambda m: _t(m, "total_liability", "value")),
        ("Total IGST", lambda m: _t(m, "total_liability", "igst")),
        ("Total CGST", lambda m: _t(m, "total_liability", "cgst")),
        ("Total SGST", lambda m: _t(m, "total_liability", "sgst")),
        ("Documents Issued (13)", lambda m: _t(m, "13", "docs")),
    ]
    out = []
    for label, fn in rows:
        out.append((label, {m["period"]: fn(m) for m in months}))
    return out


def gstr3b_summary(months):
    def outward_tax(m):
        return sum(_t3b(m, "3_1a", f) for f in ("igst", "cgst", "sgst", "cess"))

    def itc_available(m):
        return sum(_t3b(m, "4c", f) for f in ("igst", "cgst", "sgst", "cess"))

    def cash_paid(m):
        total = 0
        for head in ("6_1a_igst", "6_1a_cgst", "6_1a_sgst", "6_1a_cess",
                     "6_1b_igst", "6_1b_cgst", "6_1b_sgst", "6_1b_cess"):
            total += _t3b(m, head, "cash")
        return total

    def interest_latefee(m):
        total = 0
        for head in ("6_1a_igst", "6_1a_cgst", "6_1a_sgst", "6_1a_cess",
                     "6_1b_igst", "6_1b_cgst", "6_1b_sgst", "6_1b_cess"):
            total += _t3b(m, head, "interest_cash") + _t3b(m, head, "late_fee_cash")
        return total

    rows = [
        ("Outward Taxable Value (3.1a)", lambda m: _t3b(m, "3_1a", "taxable_value")),
        ("Zero-Rated Value (3.1b)", lambda m: _t3b(m, "3_1b", "taxable_value")),
        ("Nil/Exempt Outward (3.1c)", lambda m: _t3b(m, "3_1c", "taxable_value")),
        ("Total Output Tax (3.1a)", outward_tax),
        ("Net ITC Available (4C)", itc_available),
        ("Tax Paid in Cash (6.1)", cash_paid),
        ("Interest + Late Fee Paid", interest_latefee),
    ]
    out = []
    for label, fn in rows:
        out.append((label, {m["label"]: fn(m) for m in months}))
    return out
