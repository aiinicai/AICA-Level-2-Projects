#!/usr/bin/env python3
"""
Build a vertical, multi-month GSTR-3B consolidation workbook (3.1, 3.1.1, 3.2, 4, 5)
from a JSON data file. See references/schema.md for the exact JSON structure and
references/field_mapping.md for how each field maps to the printed GSTR-3B PDF.

Usage:
    python build_workbook.py --data data.json --out Summary.xlsx
"""
import argparse
import json
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, Protection
from openpyxl.utils import get_column_letter

NA = "N/A"
FONT_NAME = "Arial"
NAVY = "1F3864"
SECTION_BLUE = "4472C4"
INFO_BLUE = "DCE6F1"
TOTAL_ORANGE = "FCE4D6"
WHITE = "FFFFFF"
NUMFMT = '#,##0.00;(#,##0.00);"-"'

SECTION_ROWS = [
    # (section_title, subrow_label, json_key_path, fields)
    ("3.1(a) Outward taxable supplies (other than zero/nil/exempt)", ["taxable_value", "igst", "cgst", "sgst", "cess"], "3_1a",
     ["Taxable Value", "Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("3.1(b) Outward taxable supplies (zero rated)", ["taxable_value", "igst"], "3_1b",
     ["Taxable Value", "Integrated Tax"]),
    ("3.1(c) Other outward supplies (nil rated, exempted)", ["taxable_value"], "3_1c",
     ["Taxable Value"]),
    ("3.1(d) Inward supplies liable to reverse charge", ["taxable_value", "igst", "cgst", "sgst", "cess"], "3_1d",
     ["Taxable Value", "Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("3.1(e) Non-GST outward supplies", ["taxable_value"], "3_1e",
     ["Taxable Value"]),
    ("3.1.1(i) Supplies where ECO pays tax u/s 9(5)", ["taxable_value", "igst", "cgst", "sgst", "cess"], "3_1_1i",
     ["Taxable Value", "Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("3.1.1(ii) Supplies through ECO, ECO liable u/s 9(5)", ["taxable_value", "igst", "cgst", "sgst", "cess"], "3_1_1ii",
     ["Taxable Value", "Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("3.2 Inter-state supplies to Unregistered Persons", ["taxable_value", "igst"], "3_2_unregistered",
     ["Taxable Value", "Integrated Tax"]),
    ("3.2 Inter-state supplies to Composition Taxable Persons", ["taxable_value", "igst"], "3_2_composition",
     ["Taxable Value", "Integrated Tax"]),
    ("3.2 Inter-state supplies to UIN holders", ["taxable_value", "igst"], "3_2_uin",
     ["Taxable Value", "Integrated Tax"]),
    ("4A(1) ITC \u2013 Import of goods", ["igst", "cgst", "sgst", "cess"], "4a1",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4A(2) ITC \u2013 Import of services", ["igst", "cgst", "sgst", "cess"], "4a2",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4A(3) ITC \u2013 Inward supplies liable to RCM (other than 1 & 2)", ["igst", "cgst", "sgst", "cess"], "4a3",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4A(4) ITC \u2013 Inward supplies from ISD", ["igst", "cgst", "sgst", "cess"], "4a4",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4A(5) ITC \u2013 All other ITC", ["igst", "cgst", "sgst", "cess"], "4a5",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4B(1) ITC Reversed \u2013 Rule 38/42/43 & Sec 17(5)", ["igst", "cgst", "sgst", "cess"], "4b1",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4B(2) ITC Reversed \u2013 Others", ["igst", "cgst", "sgst", "cess"], "4b2",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4C Net ITC Available (A \u2212 B)", ["igst", "cgst", "sgst", "cess"], "4c",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("4D(1) Ineligible ITC u/s17(5) [pre-Aug'22] / ITC reclaimed after earlier reversal [post-Aug'22]", ["igst"], "4d1",
     ["Integrated Tax"]),
    ("4D(2) Ineligible ITC \u2013 Others [pre-Aug'22] / Ineligible ITC u/s16(4) & PoS restricted [post-Aug'22]", ["igst"], "4d2",
     ["Integrated Tax"]),
    ("5 Exempt/Nil/Composition inward supplies \u2013 Inter-State", ["value"], "5_exempt_inter",
     ["Value"]),
    ("5 Exempt/Nil/Composition inward supplies \u2013 Intra-State", ["value"], "5_exempt_intra",
     ["Value"]),
    ("5 Non-GST inward supplies \u2013 Inter-State", ["value"], "5_nongst_inter",
     ["Value"]),
    ("5 Non-GST inward supplies \u2013 Intra-State", ["value"], "5_nongst_intra",
     ["Value"]),
    ("5.1 Interest paid (for previous tax period)", ["igst", "cgst", "sgst", "cess"], "5_1_interest",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("5.1 Late fee paid (for previous tax period)", ["igst", "cgst", "sgst", "cess"], "5_1_latefee",
     ["Integrated Tax", "Central Tax", "State/UT Tax", "Cess"]),
    ("6.1(A) Other than RC \u2013 Integrated Tax", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1a_igst",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(A) Other than RC \u2013 Central Tax", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1a_cgst",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(A) Other than RC \u2013 State/UT Tax", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1a_sgst",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(A) Other than RC \u2013 Cess", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1a_cess",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(B) Reverse Charge \u2013 Integrated Tax", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1b_igst",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(B) Reverse Charge \u2013 Central Tax", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1b_cgst",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(B) Reverse Charge \u2013 State/UT Tax", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1b_sgst",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
    ("6.1(B) Reverse Charge \u2013 Cess", ["total_payable", "itc_igst", "itc_cgst", "itc_sgst", "itc_cess", "cash", "interest_cash", "late_fee_cash"], "6_1b_cess",
     ["Total Tax Payable", "ITC Utilised \u2013 IGST", "ITC Utilised \u2013 CGST", "ITC Utilised \u2013 SGST", "ITC Utilised \u2013 Cess", "Paid in Cash", "Interest Paid in Cash", "Late Fee Paid in Cash"]),
]


def build(data, out_path):
    entity = data["entity"]
    months = data["months"]
    n = len(months)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "GSTR-3B Summary"

    title_font = Font(name=FONT_NAME, size=14, bold=True, color=WHITE)
    section_font = Font(name=FONT_NAME, size=10, bold=True, color=WHITE)
    label_font = Font(name=FONT_NAME, size=10)
    subheader_font = Font(name=FONT_NAME, size=10, bold=True)
    data_font = Font(name=FONT_NAME, size=10)
    header_fill = PatternFill("solid", fgColor=NAVY)
    section_fill = PatternFill("solid", fgColor=SECTION_BLUE)
    info_fill = PatternFill("solid", fgColor=INFO_BLUE)
    total_fill = PatternFill("solid", fgColor=TOTAL_ORANGE)
    thin = Side(style="thin", color="B7B7B7")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    ncols = 1 + n + 1
    last_col = ncols

    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
    title = f"GSTR-3B SUMMARY \u2013 {entity.get('legal_name','')} (GSTIN: {entity.get('gstin','')})"
    if entity.get("period_label"):
        title += f" \u2013 {entity['period_label']}"
    c = ws.cell(row=1, column=1, value=title)
    c.font = title_font
    c.fill = header_fill
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 24

    r = 3
    info_rows = [
        ("GSTIN", [entity.get("gstin", "")] * n),
        ("Legal Name", [entity.get("legal_name", "")] * n),
        ("Trade Name", [entity.get("trade_name", "")] * n),
        ("ARN", [m.get("arn", "") for m in months]),
        ("Date of ARN / Filing", [m.get("date_of_arn", "") for m in months]),
        ("Return Format", [m.get("format_label", "") for m in months]),
    ]
    for label, vals in info_rows:
        ws.cell(row=r, column=1, value=label).font = subheader_font
        ws.cell(row=r, column=1).fill = info_fill
        ws.cell(row=r, column=1).border = border
        for i, v in enumerate(vals):
            cell = ws.cell(row=r, column=2 + i, value=v)
            cell.font = data_font
            cell.fill = info_fill
            cell.alignment = Alignment(horizontal="center")
            cell.border = border
        r += 1
    r += 1

    ws.cell(row=r, column=1, value="Particulars").font = section_font
    ws.cell(row=r, column=1).fill = section_fill
    for i, m in enumerate(months):
        cell = ws.cell(row=r, column=2 + i, value=m["label"])
        cell.font = section_font
        cell.fill = section_fill
        cell.alignment = Alignment(horizontal="center")
    tcell = ws.cell(row=r, column=last_col, value="TOTAL")
    tcell.font = section_font
    tcell.fill = PatternFill("solid", fgColor="C00000")
    tcell.alignment = Alignment(horizontal="center", wrap_text=True)
    header_row = r
    r += 1

    month_start_col, month_end_col = 2, 1 + n

    for section_title, fields, key, field_labels in SECTION_ROWS:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=last_col)
        sc = ws.cell(row=r, column=1, value=section_title)
        sc.font = section_font
        sc.fill = section_fill
        sc.alignment = Alignment(horizontal="left", indent=1)
        r += 1
        for field, flabel in zip(fields, field_labels):
            lbl = ws.cell(row=r, column=1, value="   " + flabel)
            lbl.font = label_font
            lbl.border = border
            for i, m in enumerate(months):
                block = m.get(key)
                cell = ws.cell(row=r, column=2 + i)
                cell.border = border
                cell.font = data_font
                if block is None:
                    cell.value = NA
                    cell.alignment = Alignment(horizontal="center")
                else:
                    v = block.get(field, 0) if isinstance(block, dict) else block
                    if v == NA:
                        cell.value = NA
                        cell.alignment = Alignment(horizontal="center")
                    else:
                        cell.value = v
                        cell.number_format = NUMFMT
                        cell.alignment = Alignment(horizontal="right")
            start_letter = get_column_letter(month_start_col)
            end_letter = get_column_letter(month_end_col)
            tcell = ws.cell(row=r, column=last_col, value=f"=SUM({start_letter}{r}:{end_letter}{r})")
            tcell.number_format = NUMFMT
            tcell.font = Font(name=FONT_NAME, size=10, bold=True)
            tcell.fill = total_fill
            tcell.border = border
            tcell.alignment = Alignment(horizontal="right")
            r += 1

    ws.column_dimensions["A"].width = 66
    for i in range(n):
        ws.column_dimensions[get_column_letter(2 + i)].width = 14
    ws.column_dimensions[get_column_letter(last_col)].width = 16
    ws.freeze_panes = f"B{header_row + 1}"

    ws.protection.sheet = False
    for row_cells in ws.iter_rows():
        for cell in row_cells:
            cell.protection = Protection(locked=False)

    wb.save(out_path)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="Path to JSON data file (see references/schema.md)")
    ap.add_argument("--out", required=True, help="Output .xlsx path")
    args = ap.parse_args()
    with open(args.data) as f:
        data = json.load(f)
    build(data, args.out)
    print(f"saved {args.out}")
