#!/usr/bin/env python3
"""
Build a vertical GSTR-1 consolidation workbook from a data.json file
(see references/schema.md).

Usage:
    python build_workbook.py --data data.json --out GSTR1_Summary.xlsx

Tab 1 ("1. Tables With Data") shows every GSTR-1 table that carried a
non-zero figure in at least one uploaded period, periods as columns,
line items as rows, with a formula-driven FY Total column.

Tab 2 ("2. Tables With No Data") lists every GSTR-1 table that was nil
across EVERY uploaded period, by table number and description, so a
reviewer can see it was checked and found nil rather than simply
missing from the workbook.
"""
import argparse
import json
import openpyxl
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side, Protection
from openpyxl.utils import get_column_letter

NUM = '#,##0.00;(#,##0.00);"-"'
INT = '#,##0;(#,##0);"-"'

NAVY = "1F3864"
BLUE_HDR = "4472C4"
LIGHTBLUE = "D9E2F3"
GREY = "F2F2F2"
AMBER = "FFF2CC"
ORANGE = "FCE4D6"

TITLE_FONT = Font(name="Arial", size=14, bold=True, color="FFFFFF")
HEADER_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
SECTION_FONT = Font(name="Arial", size=10, bold=True, color="FFFFFF")
LABEL_FONT = Font(name="Arial", size=10, bold=False)
LABEL_BOLD = Font(name="Arial", size=10, bold=True)
DATA_FONT = Font(name="Arial", size=10)
TOTAL_FONT = Font(name="Arial", size=10, bold=True)
THIN = Side(style="thin", color="B7B7B7")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# (table_key, section_title, [(row_label, field, number_format), ...])
TABLE_DEFS = [
    ("4A", "TABLE 4A — B2B Regular Supplies (Taxable outward supplies to registered persons)",
        [("No. of Invoices", "n", INT), ("Taxable Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM), ("Central Tax / CGST (₹)", "cgst", NUM),
         ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("4B", "TABLE 4B — B2B Reverse Charge Supplies",
        [("No. of Invoices", "n", INT), ("Taxable Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM), ("Central Tax / CGST (₹)", "cgst", NUM),
         ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("5A", "TABLE 5A — B2CL (Inter-state supplies to unregistered persons, invoice > ₹2.5 lakh)",
        [("No. of Invoices", "n", INT), ("Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM)]),
    ("6A", "TABLE 6A — Exports (EXPWP / EXPWOP)",
        [("No. of Invoices", "n", INT), ("Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM)]),
    ("6B", "TABLE 6B — Supplies to SEZ Unit or SEZ Developer (SEZWP / SEZWOP)",
        [("No. of Invoices", "n", INT), ("Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM)]),
    ("6C", "TABLE 6C — Deemed Exports (DE)",
        [("No. of Invoices", "n", INT), ("Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM), ("Central Tax / CGST (₹)", "cgst", NUM),
         ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("7", "TABLE 7 — B2CS (Taxable supplies to unregistered persons, net of debit/credit notes)",
        [("No. of Records", "n", INT), ("Net Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM), ("Central Tax / CGST (₹)", "cgst", NUM),
         ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("8", "TABLE 8 — Nil Rated, Exempted and Non-GST Outward Supplies",
        [("Total (₹)", "total", NUM), ("Nil Rated (₹)", "nil", NUM),
         ("Exempted (₹)", "exempted", NUM), ("Non-GST (₹)", "non_gst", NUM)]),
    ("9A", "TABLE 9A — Amendments to 4/5A/6A/6B/6C of Earlier Tax Periods (net differential, all sub-tables)",
        [("Net Differential Value (₹)", "value", NUM), ("Integrated Tax / IGST (₹)", "igst", NUM),
         ("Central Tax / CGST (₹)", "cgst", NUM), ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("9B_cdnr", "TABLE 9B — Credit/Debit Notes (Registered) — CDNR, Net (Debit Notes − Credit Notes)",
        [("No. of Notes", "n", INT), ("Net Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM), ("Central Tax / CGST (₹)", "cgst", NUM),
         ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("9B_cdnur", "TABLE 9B — Credit/Debit Notes (Unregistered) — CDNUR",
        [("No. of Notes", "n", INT), ("Net Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM)]),
    ("9C", "TABLE 9C — Amended Credit/Debit Notes (CDNRA / CDNURA), net differential",
        [("Net Differential Value (₹)", "value", NUM), ("Integrated Tax / IGST (₹)", "igst", NUM),
         ("Central Tax / CGST (₹)", "cgst", NUM), ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("10", "TABLE 10 — Amendment to B2CS of Earlier Tax Periods",
        [("Net Differential Value (₹)", "value", NUM), ("Integrated Tax / IGST (₹)", "igst", NUM),
         ("Central Tax / CGST (₹)", "cgst", NUM), ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("11A", "TABLE 11A — Advances Received (invoice not yet issued)",
        [("Value (₹)", "value", NUM), ("Integrated Tax / IGST (₹)", "igst", NUM),
         ("Central Tax / CGST (₹)", "cgst", NUM), ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("11B", "TABLE 11B — Advances Adjusted Against Current-Period Supplies",
        [("Value (₹)", "value", NUM), ("Integrated Tax / IGST (₹)", "igst", NUM),
         ("Central Tax / CGST (₹)", "cgst", NUM), ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
    ("12", "TABLE 12 — HSN-wise Summary of Outward Supplies",
        [("No. of HSN Records", "n", INT), ("Value (₹)", "value", NUM),
         ("Integrated Tax / IGST (₹)", "igst", NUM), ("Central Tax / CGST (₹)", "cgst", NUM),
         ("State/UT Tax / SGST (₹)", "sgst", NUM)]),
]

TABLE_DESCRIPTIONS = {k: title.split("—", 1)[1].strip() if "—" in title else title
                       for k, title, _ in TABLE_DEFS}

ALWAYS_SHOW = {"13", "total_liability"}  # never classified as nil, always in Tab 1


def set_cell(ws, row, col, value, font=DATA_FONT, fill=None, align="right", fmt=None, bordered=True):
    c = ws.cell(row=row, column=col, value=value)
    c.font = font
    c.alignment = Alignment(horizontal=align, vertical="center")
    if fill:
        c.fill = PatternFill("solid", fgColor=fill)
    if fmt:
        c.number_format = fmt
    if bordered:
        c.border = BORDER
    return c


def table_has_data(months, key):
    """True if any numeric field under this table key is non-zero/non-null in any period."""
    for m in months:
        t = m["tables"].get(key)
        if not t:
            continue
        for v in t.values():
            if v not in (None, 0, 0.0):
                return True
    return False


def build(data, out_path):
    entity = data["entity"]
    periods = data["periods"]
    months = data["months"]
    month_by_period = {m["period"]: m for m in months}

    populated = [k for k, _, _ in TABLE_DEFS if k in ALWAYS_SHOW or table_has_data(months, k)]
    nil_tables = [k for k, _, _ in TABLE_DEFS if k not in populated]

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "1. Tables With Data"

    last_col = len(periods) + 2  # label col + periods + FY Total

    title = (f"GSTR-1 CONSOLIDATED SUMMARY — {entity.get('legal_name','')} "
              f"(GSTIN: {entity.get('gstin','')}) — FY {entity.get('financial_year','')}")
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=last_col)
    set_cell(ws, 1, 1, title, font=TITLE_FONT, fill=NAVY, align="center", bordered=False)
    ws.row_dimensions[1].height = 24

    row = 3
    set_cell(ws, row, 1, "Particulars", font=HEADER_FONT, fill=NAVY, align="left")
    for i, p in enumerate(periods):
        set_cell(ws, row, 2 + i, p, font=HEADER_FONT, fill=NAVY, align="center")
    set_cell(ws, row, last_col, "FY Total", font=HEADER_FONT, fill=NAVY, align="center")
    ws.row_dimensions[row].height = 18
    row += 1

    # Filing meta
    for label, field in (("ARN", "arn"), ("ARN Date", "arn_date")):
        set_cell(ws, row, 1, label, font=LABEL_FONT, align="left", fill=GREY)
        for i, p in enumerate(periods):
            set_cell(ws, row, 2 + i, month_by_period[p].get(field, ""), font=DATA_FONT, align="center")
        set_cell(ws, row, last_col, "", align="center")
        row += 1
    row += 1

    def section_header(row, text):
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=last_col)
        set_cell(ws, row, 1, text, font=SECTION_FONT, fill=BLUE_HDR, align="left", bordered=False)
        ws.row_dimensions[row].height = 16
        return row + 1

    def data_row(row, label, key, field, fmt, bold=False):
        f = LABEL_BOLD if bold else LABEL_FONT
        set_cell(ws, row, 1, label, font=f, align="left")
        for i, p in enumerate(periods):
            t = month_by_period[p]["tables"].get(key) or {}
            val = t.get(field)
            set_cell(ws, row, 2 + i, val if val is not None else "N/A",
                     font=(TOTAL_FONT if bold else DATA_FONT), fmt=fmt)
        col_first, col_last = get_column_letter(2), get_column_letter(2 + len(periods) - 1)
        c = ws.cell(row=row, column=last_col, value=f"=SUM({col_first}{row}:{col_last}{row})")
        c.font = TOTAL_FONT
        c.number_format = fmt
        c.alignment = Alignment(horizontal="right", vertical="center")
        c.fill = PatternFill("solid", fgColor=LIGHTBLUE)
        c.border = BORDER
        return row + 1

    for key, title_text, rows in TABLE_DEFS:
        if key not in populated:
            continue
        row = section_header(row, title_text)
        for label, field, fmt in rows:
            row = data_row(row, label, key, field, fmt)
        row += 1

    # Table 13 — documents issued (special: single field, always shown)
    row = section_header(row, "TABLE 13 — Documents Issued")
    row = data_row(row, "Net Documents Issued", "13", "docs", INT)
    row += 1

    # Total liability
    row = section_header(row, "TOTAL LIABILITY (Outward Supplies other than Reverse Charge)")
    row = data_row(row, "Total Taxable Value (₹)", "total_liability", "value", NUM, bold=True)
    tl_igst_row = row
    row = data_row(row, "Total IGST (₹)", "total_liability", "igst", NUM, bold=True)
    tl_cgst_row = row
    row = data_row(row, "Total CGST (₹)", "total_liability", "cgst", NUM, bold=True)
    tl_sgst_row = row
    row = data_row(row, "Total SGST (₹)", "total_liability", "sgst", NUM, bold=True)
    row += 1

    # Grand total tax row (formula referencing the three rows above)
    row = section_header(row, "GRAND TOTAL GST LIABILITY")
    set_cell(ws, row, 1, "Total Tax Payable (IGST+CGST+SGST) (₹)", font=LABEL_BOLD, align="left")
    for i in range(len(periods)):
        col_l = get_column_letter(2 + i)
        c = ws.cell(row=row, column=2 + i,
                     value=f"={col_l}{tl_igst_row}+{col_l}{tl_cgst_row}+{col_l}{tl_sgst_row}")
        c.font = TOTAL_FONT
        c.number_format = NUM
        c.alignment = Alignment(horizontal="right", vertical="center")
        c.fill = PatternFill("solid", fgColor=ORANGE)
        c.border = BORDER
    col_first, col_last = get_column_letter(2), get_column_letter(2 + len(periods) - 1)
    c = ws.cell(row=row, column=last_col, value=f"=SUM({col_first}{row}:{col_last}{row})")
    c.font = TOTAL_FONT
    c.number_format = NUM
    c.alignment = Alignment(horizontal="right", vertical="center")
    c.fill = PatternFill("solid", fgColor=ORANGE)
    c.border = BORDER
    row += 2

    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=last_col)
    note = ws.cell(row=row, column=1,
        value="Note: Source — GSTR-1 (outward supply returns) only, ARNs as filed for each period. GSTR-1 does "
              "not carry purchase / ITC / cash-ledger data — that resides in GSTR-3B. See Tab 2 for the complete "
              "list of GSTR-1 tables that returned NIL across every uploaded period. Figures are as filed; not "
              "re-verified against books.")
    note.font = Font(name="Arial", size=9, italic=True, color="808080")
    note.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 30

    ws.column_dimensions["A"].width = 38
    for i in range(len(periods)):
        ws.column_dimensions[get_column_letter(2 + i)].width = 14
    ws.column_dimensions[get_column_letter(last_col)].width = 16
    ws.freeze_panes = "B6"

    # ---------------- Tab 2: nil tables ----------------
    ws2 = wb.create_sheet("2. Tables With No Data")
    ws2.merge_cells(start_row=1, start_column=1, end_row=1, end_column=3)
    set_cell(ws2, 1, 1,
             f"GSTR-1 TABLES WITH NO DATA — {entity.get('legal_name','')} "
             f"(GSTIN: {entity.get('gstin','')}) — FY {entity.get('financial_year','')}",
             font=TITLE_FONT, fill=NAVY, align="center", bordered=False)
    ws2.row_dimensions[1].height = 24

    r = 3
    set_cell(ws2, r, 1, "Table No.", font=HEADER_FONT, fill=NAVY, align="center")
    set_cell(ws2, r, 2, "Table Description", font=HEADER_FONT, fill=NAVY, align="left")
    set_cell(ws2, r, 3, "Status", font=HEADER_FONT, fill=NAVY, align="center")
    ws2.row_dimensions[r].height = 18
    r += 1

    period_range = f"{periods[0]} to {periods[-1]}" if len(periods) > 1 else periods[0]
    for key in nil_tables:
        desc = TABLE_DESCRIPTIONS.get(key, key)
        set_cell(ws2, r, 1, key, font=DATA_FONT, align="center", fill=AMBER)
        set_cell(ws2, r, 2, desc, font=DATA_FONT, align="left")
        set_cell(ws2, r, 3, f"NIL — all {len(periods)} periods ({period_range})", font=DATA_FONT, align="center")
        ws2.row_dimensions[r].height = 28
        r += 1

    r += 1
    ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
    note2 = ws2.cell(row=r, column=1,
        value="These tables carried Nil/0.00 figures across every uploaded GSTR-1 return. Listed here for "
              "completeness and audit trail, so a reviewer can confirm each table was checked and found nil, "
              "rather than simply absent from the summary.")
    note2.font = Font(name="Arial", size=9, italic=True, color="808080")
    note2.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    ws2.row_dimensions[r].height = 40

    ws2.column_dimensions["A"].width = 16
    ws2.column_dimensions["B"].width = 85
    ws2.column_dimensions["C"].width = 32
    for row_cells in ws2.iter_rows():
        for cell in row_cells:
            cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal=cell.alignment.horizontal)

    # Unlock everything, no protection, on both sheets — standing requirement
    for wsx in (ws, ws2):
        wsx.protection.sheet = False
        for r_ in wsx.iter_rows():
            for cell in r_:
                cell.protection = Protection(locked=False)

    wb.save(out_path)
    print(f"saved: {out_path}")
    print(f"tables with data: {populated}")
    print(f"tables with no data: {nil_tables}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    with open(args.data) as f:
        data = json.load(f)
    build(data, args.out)
