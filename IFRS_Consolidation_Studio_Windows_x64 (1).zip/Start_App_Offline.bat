@echo off
setlocal
title IFRS Consolidation Studio
cd /d "%~dp0"

echo =====================================================================
echo             Starting IFRS Consolidation Studio Desktop
echo =====================================================================
echo.

where node >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    echo Starting offline local server engine...
    start /min "" node standalone_server.cjs
    timeout /t 2 /nobreak >nul
    start "" http://localhost:3000
) else (
    echo Node.js not detected in system path.
    echo Launching client directly in default browser with full local IndexedDB storage...
    if exist "dist\index.html" (
        start "" "dist\index.html"
    ) else if exist "index.html" (
        start "" "index.html"
    ) else (
        echo Error: Could not locate index.html.
        pause
    )
)
