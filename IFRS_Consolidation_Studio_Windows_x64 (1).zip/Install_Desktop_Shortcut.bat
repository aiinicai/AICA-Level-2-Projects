@echo off
setlocal enabledelayedexpansion
title IFRS Consolidation Studio - Desktop Installer

echo =====================================================================
echo       IFRS Consolidation Studio - Windows Desktop Setup
echo       Enterprise IFRS Multi-Entity Group Financial Reporting
echo =====================================================================
echo.

set APP_DIR=%~dp0
set TARGET_SCRIPT=%APP_DIR%Start_App_Offline.bat
set ICON_FILE=%APP_DIR%public\favicon.ico
if not exist "%ICON_FILE%" set ICON_FILE=%APP_DIR%dist\favicon.ico

echo [1/3] Registering Application Directory: "%APP_DIR%"
echo [2/3] Checking Node.js Runtime Environment...
where node >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [INFO] Node.js is not found in system PATH.
    echo Direct standalone HTML mode is available.
    echo To use full local background server, install Node.js from https://nodejs.org
    echo.
) else (
    echo [OK] Node.js is available.
)

echo [3/3] Creating Windows Desktop and Start Menu Shortcuts...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$WScriptShell = New-Object -ComObject WScript.Shell; " ^
  "$DesktopPath = [System.Environment]::GetFolderPath('Desktop'); " ^
  "$Shortcut = $WScriptShell.CreateShortcut(\"$DesktopPath\IFRS Consolidation Studio.lnk\"); " ^
  "$Shortcut.TargetPath = \"%TARGET_SCRIPT%\"; " ^
  "$Shortcut.WorkingDirectory = \"%APP_DIR%\"; " ^
  "$Shortcut.Description = 'IFRS Consolidation Studio - Multi-Entity Financial Reporting Platform'; " ^
  "if (Test-Path \"%ICON_FILE%\") { $Shortcut.IconLocation = \"%ICON_FILE%\"; }; " ^
  "$Shortcut.Save(); " ^
  "$StartMenuPath = [System.Environment]::GetFolderPath('StartMenu'); " ^
  "$ProgramsPath = Join-Path $StartMenuPath 'Programs'; " ^
  "$StartShortcut = $WScriptShell.CreateShortcut(\"$ProgramsPath\IFRS Consolidation Studio.lnk\"); " ^
  "$StartShortcut.TargetPath = \"%TARGET_SCRIPT%\"; " ^
  "$StartShortcut.WorkingDirectory = \"%APP_DIR%\"; " ^
  "$StartShortcut.Description = 'IFRS Consolidation Studio'; " ^
  "if (Test-Path \"%ICON_FILE%\") { $StartShortcut.IconLocation = \"%ICON_FILE%\"; }; " ^
  "$StartShortcut.Save(); " ^
  "Write-Host '[SUCCESS] Desktop & Start Menu Shortcuts created successfully!' -ForegroundColor Green;"

echo.
echo =====================================================================
echo  Installation Complete!
echo  You can now launch the app from:
echo   - Your Windows Desktop ("IFRS Consolidation Studio")
echo   - Start Menu Programs
echo   - Or by running IFRS_Consolidation_Studio.exe in this folder.
echo =====================================================================
echo.
pause
