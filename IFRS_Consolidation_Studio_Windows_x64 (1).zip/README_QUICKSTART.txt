================================================================================
          IFRS CONSOLIDATION STUDIO - ENTERPRISE DESKTOP DISTRIBUTION
================================================================================

PRODUCT:       IFRS Consolidation Studio
EDITION:       Windows x64 Enterprise Edition (Desktop & Offline Ready)
COMPLIANCE:    IFRS 10, IAS 21, IAS 28, IFRS 3, IAS 7 / IFRS 18, IAS 24
DATA PRIVACY:  100% Client-Side / Local Storage (IndexedDB via Dexie)

--------------------------------------------------------------------------------
QUICK INSTALLATION & EXECUTION INSTRUCTIONS:
--------------------------------------------------------------------------------

OPTION 1: One-Click Desktop Executable (.exe)
---------------------------------------------
1. Double-click "IFRS_Consolidation_Studio.exe".
2. The application will immediately launch in your default web browser or standalone
   desktop window at http://localhost:3000.
3. All accounting data, trial balances, and consolidation journals are stored
   securely in your local machine's encrypted IndexedDB storage.

OPTION 2: Windows Desktop & Start Menu Installer (Setup)
--------------------------------------------------------
1. Double-click "IFRS_Consolidation_Studio_Setup.exe" (or "Install_Desktop_Shortcut.bat").
2. This creates:
   - A dedicated desktop shortcut: "IFRS Consolidation Studio"
   - A Windows Start Menu entry under Programs
3. You can launch it anytime directly from your Windows Desktop or Start Menu.

OPTION 3: Progressive Web App (PWA) Native Desktop Installation
---------------------------------------------------------------
1. In the application header bar, click the "Install Desktop App (.exe)" button.
2. Click "Install as Native Windows App".
3. Google Chrome or Microsoft Edge will install IFRS Consolidation Studio as a
   standalone desktop app with its own taskbar icon and window frame (no browser bar).

--------------------------------------------------------------------------------
KEY FEATURES & IFRS METHODOLOGY:
--------------------------------------------------------------------------------
* Foreign Currency Translation (IAS 21):
  - Assets and Liabilities translated at Closing FX Rates
  - P&L Items translated at Average FX Rates
  - Equity translated at Historical FX Rates
  - Foreign Currency Translation Reserve (FCTR/CTA) reconciled in OCI

* Intercompany Eliminations (IFRS 10):
  - Automated counterparty matching with configurable tolerance
  - Unrealized intercompany inventory profit elimination
  - Intercompany balance netting & dividend elimination

* Non-Controlling Interests (IFRS 10 & IFRS 3):
  - Proportionate share of net identifiable assets vs. Fair value (full goodwill)
  - Full roll-forward of NCI equity & P&L allocation

* Double-Entry Manual Adjustment Journal Engine:
  - Full debit/credit balance enforcement (Sum Dr = Sum Cr)
  - Audit trail tracking preparer, approver, IFRS category, and rationale

* Multi-Format Financial Statements & Executive Dashboard:
  - Consolidated Statement of Financial Position (Balance Sheet)
  - Consolidated Statement of Profit or Loss and OCI
  - Consolidated Statement of Cash Flows (Indirect Method)
  - Consolidated Statement of Changes in Equity (SOCIE)
  - Professional Multi-Tab Excel Export (.xlsx), Boardroom PDF, and PPT Reports

--------------------------------------------------------------------------------
SUPPORT & SYSTEM REQUIREMENTS:
--------------------------------------------------------------------------------
- Operating System: Windows 10, Windows 11, or Windows Server (64-bit)
- RAM: 4 GB minimum (8 GB recommended for groups with 50+ entities)
- Browser: Microsoft Edge, Google Chrome, Mozilla Firefox, or Brave
- Contact: Finance Systems Architecture & Group Financial Reporting Team
================================================================================
