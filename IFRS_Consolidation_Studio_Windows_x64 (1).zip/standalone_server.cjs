/**
 * IFRS Consolidation Studio - Offline Local Desktop Server
 * Single-file, zero-dependency Node.js HTTP server.
 * Serves the consolidated IFRS application on localhost:3000
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const PORT = process.env.PORT || 3000;
const DIST_DIR = path.resolve(__dirname, 'dist');

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.json': 'application/json',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
  '.ttf': 'font/ttf',
  '.wasm': 'application/wasm'
};

const server = http.createServer((req, res) => {
  // CORS & PWA headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');

  const cleanUrl = req.url.split('?')[0];

  // API Health Endpoint for local offline diagnostics
  if (cleanUrl === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    return res.end(JSON.stringify({
      status: 'ok',
      mode: 'desktop-offline',
      engine: 'IFRS Consolidation Engine v2.4 (Deterministic Decimal.js)',
      storage: 'Dexie / IndexedDB Local Storage',
      timestamp: new Date().toISOString()
    }));
  }

  let filePath = path.join(DIST_DIR, cleanUrl === '/' ? 'index.html' : cleanUrl);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // SPA Fallback to index.html for client-side routing
      filePath = path.join(DIST_DIR, 'index.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        return res.end('Error loading ' + cleanUrl);
      }
      res.writeHead(200, { 'Content-Type': contentType });
      res.end(content);
    });
  });
});

server.listen(PORT, '127.0.0.1', () => {
  const url = `http://localhost:${PORT}`;
  console.log('========================================================');
  console.log('  IFRS Consolidation Studio - Enterprise Desktop Engine  ');
  console.log('========================================================');
  console.log(`  Local Address: ${url}`);
  console.log('  Mode:          100% Offline / Local Desktop');
  console.log('  Database:      IndexedDB Local Encryption & Storage');
  console.log('========================================================');
  console.log('Opening your default browser...');

  // Auto-launch the default Windows browser or PWA window
  const startCmd = process.platform === 'win32' ? `start "" "${url}"` : `xdg-open "${url}"`;
  exec(startCmd, (err) => {
    if (err) console.log(`Please open ${url} in your browser.`);
  });
});
