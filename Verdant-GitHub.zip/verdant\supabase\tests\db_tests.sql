-- =====================================================================
-- Verdant database test suite.
-- Runs against a database where 001_verdant_schema.sql has been applied.
-- Every block raises an exception (and psql stops) on the first failure.
-- Locally it runs with an emulated auth schema; on Supabase it can be run
-- inside a transaction that is rolled back (see README → "Verifying").
-- =====================================================================
\set ON_ERROR_STOP 1
\set QUIET 1

-- Two test users
insert into auth.users (id, email) values
  ('00000000-0000-0000-0000-00000000000a', 'alice@test.local'),
  ('00000000-0000-0000-0000-00000000000b', 'bob@test.local')
on conflict do nothing;

create or replace function pg_temp.as_user(u uuid) returns void language plpgsql as $$
begin
  perform set_config('request.jwt.claims', json_build_object('sub', u, 'role', 'authenticated')::text, false);
end $$;

-- ---------------- T1 bootstrap seeds once ----------------
set role authenticated;
select from pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
do $$ declare r jsonb; begin
  r := public.diet_bootstrap(true);
  assert (r->>'created')::boolean and (r->>'seeded')::int = 10, 'T1a bootstrap should seed 10 meals: '||r;
  r := public.diet_bootstrap(true);
  assert not (r->>'created')::boolean and (r->>'seeded')::int = 0, 'T1b second bootstrap must be a no-op';
  assert (select count(*) from public.diet_meals) = 10, 'T1c alice sees 10 meals';
  raise notice 'PASS T1 bootstrap seeds sample meals exactly once';
end $$;

-- ---------------- T2 meal CRUD ----------------
do $$ declare mid uuid; begin
  insert into public.diet_meals (name, category, calories, protein, carbs, fat)
  values ('Test Upma', 'Breakfast', 310.5, 8, 50, 9) returning id into mid;
  assert (select user_id from public.diet_meals where id = mid) = auth.uid(), 'T2a user_id defaults to auth.uid()';
  update public.diet_meals set calories = 320, name = 'Test Upma v2' where id = mid;
  assert (select calories from public.diet_meals where id = mid) = 320, 'T2b update';
  assert (select updated_at > created_at or updated_at = created_at from public.diet_meals where id = mid), 'T2c updated_at';
  delete from public.diet_meals where id = mid;
  assert not exists (select 1 from public.diet_meals where id = mid), 'T2d delete';
  begin
    insert into public.diet_meals (name, category) values ('  ', 'Lunch');
    raise exception 'T2e blank name accepted';
  exception when check_violation then null; end;
  begin
    insert into public.diet_meals (name, category) values ('X', 'Brunch');
    raise exception 'T2f bad category accepted';
  exception when check_violation then null; end;
  begin
    insert into public.diet_meals (name, category, calories) values ('X', 'Lunch', -5);
    raise exception 'T2g negative calories accepted';
  exception when check_violation then null; end;
  raise notice 'PASS T2 meal create/read/update/delete + validation';
end $$;

-- ---------------- T3 day + entries ----------------
do $$ declare did uuid; mid uuid; begin
  select id into mid from public.diet_meals where name = 'Vegetable Poha';
  insert into public.diet_days (day, calorie_target) values ('2026-11-19', 1800) returning id into did;
  insert into public.diet_entries (day_id, meal_type, slot, meal_id) values (did, 'breakfast', 0, mid);
  -- upsert the same slot (what the app does when a different meal is picked)
  insert into public.diet_entries (day_id, meal_type, slot, meal_id, completed, portion)
  values (did, 'breakfast', 0, mid, true, '1.5 bowl')
  on conflict (day_id, meal_type, slot) do update set completed = excluded.completed, portion = excluded.portion;
  assert (select completed and portion = '1.5 bowl' from public.diet_entries where day_id = did and slot = 0), 'T3a upsert';
  begin
    insert into public.diet_entries (day_id, meal_type, slot, meal_id) values (did, 'breakfast', 3, mid);
    raise exception 'T3b slot 3 accepted';
  exception when check_violation then null; end;
  begin
    insert into public.diet_days (day) values ('2026-11-19');
    raise exception 'T3c duplicate day accepted';
  exception when unique_violation then null; end;
  -- a referenced meal cannot be hard-deleted; app archives instead
  begin
    set constraints public.diet_entries_meal_fk immediate;  -- PostgREST requests hit this at commit
    delete from public.diet_meals where id = mid;
    raise exception 'T3d referenced meal deleted';
  exception when foreign_key_violation then null; end;
  update public.diet_meals set archived_at = now() where id = mid;
  update public.diet_meals set archived_at = null where id = mid;
  raise notice 'PASS T3 days/entries, slot limits, unique day, referenced-meal protection';
end $$;

-- ---------------- T4 RLS isolation ----------------
select from pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
do $$ declare n int; a_day uuid := (select id from public.diet_days limit 1); begin
  perform public.diet_bootstrap(false);
  assert (select count(*) from public.diet_meals) = 0, 'T4a bob must not see alice meals';
  assert (select count(*) from public.diet_days) = 0, 'T4b bob must not see alice days';
  assert (select count(*) from public.diet_entries) = 0, 'T4c bob must not see alice entries';
  assert (select count(*) from public.diet_settings) = 1, 'T4d bob sees only his settings';
  update public.diet_meals set name = 'hacked'; get diagnostics n = row_count;
  assert n = 0, 'T4e bob updated alice rows';
  delete from public.diet_days; get diagnostics n = row_count;
  assert n = 0, 'T4f bob deleted alice rows';
  begin
    insert into public.diet_meals (user_id, name, category) values ('00000000-0000-0000-0000-00000000000a', 'spoof', 'Lunch');
    raise exception 'T4g bob inserted a row owned by alice';
  exception when insufficient_privilege then null; end;
  raise notice 'PASS T4 RLS: no cross-user read/update/delete/insert';
end $$;

-- Bob tries to attach an entry to Alice's day and meal (ids known to him somehow)
reset role;
select set_config('test.alice_day',  (select id::text from public.diet_days  where user_id = '00000000-0000-0000-0000-00000000000a' limit 1), false) \g /dev/null
select set_config('test.alice_meal', (select id::text from public.diet_meals where user_id = '00000000-0000-0000-0000-00000000000a' limit 1), false) \g /dev/null
set role authenticated;
select from pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
do $$ declare bob_day uuid; begin
  set constraints all immediate;  -- deferred FK is checked at commit in real requests
  begin
    insert into public.diet_entries (day_id, meal_type, slot, meal_id) values (current_setting('test.alice_day')::uuid, 'lunch', 1, current_setting('test.alice_meal')::uuid);
    raise exception 'T4h bob linked an entry to alice day';
  exception when foreign_key_violation or insufficient_privilege then null; end;
  insert into public.diet_days (day) values ('2026-11-19') returning id into bob_day;  -- same date, separate user: allowed
  begin
    insert into public.diet_entries (day_id, meal_type, slot, meal_id) values (bob_day, 'lunch', 0, current_setting('test.alice_meal')::uuid);
    raise exception 'T4i bob referenced alice meal';
  exception when foreign_key_violation then null; end;
  raise notice 'PASS T4 composite FKs block cross-user references';
end $$;

-- ---------------- T5 anonymous access ----------------
reset role;
set role anon;
select set_config('request.jwt.claims', '', false);
do $$ begin
  begin perform 1 from public.diet_meals; raise exception 'T5a anon read meals';
  exception when insufficient_privilege then null; end;
  begin perform public.diet_bootstrap(true); raise exception 'T5b anon ran rpc';
  exception when insufficient_privilege then null; end;
  raise notice 'PASS T5 anon has no table or RPC access';
end $$;
reset role;

-- ---------------- T6 legacy import (merge) ----------------
set role authenticated;
select from pg_temp.as_user('00000000-0000-0000-0000-00000000000b');
do $$ declare r jsonb; p jsonb := '{
  "version":1,
  "meals":[
    {"id":"m-poha","name":"Vegetable Poha","category":"Breakfast","calories":300,"protein":7,"carbs":48,"fat":9},
    {"id":"m-dal","name":"Dal Tadka & Roti","category":"Lunch","calories":"520","protein":"20","carbs":75,"fat":14},
    {"id":"m-bad","name":"","category":"Lunch"},
    {"id":"m-odd","name":"Odd Cat","category":"Brunch","calories":""}
  ],
  "dietHistory":[
    {"date":"2026-11-01","breakfast":[{"mealId":"m-poha","completed":true,"portion":"1 bowl"}],"lunch":[{},{"mealId":"m-dal","completed":false}],"dinner":[{"mealId":"gone-123","completed":true}],"notes":"day one","calorieTarget":1800},
    {"date":"2026-11-02","breakfast":[{"mealId":"m-poha"},{"mealId":"m-poha"},{"mealId":"m-poha"},{"mealId":"m-dal"}],"lunch":[],"dinner":[],"notes":"","calorieTarget":null},
    {"date":"2026-11-19","breakfast":[{"mealId":"m-poha"}],"lunch":[],"dinner":[],"notes":"merged note","calorieTarget":"1500"},
    {"date":"bad-date","breakfast":[]},
    {"date":"2026-11-03","breakfast":[{"mealId":"missing-Masala Dosa","completed":true}],"lunch":[],"dinner":[],"notes":""}
  ]}'::jsonb;
begin
  r := public.diet_import_backup(p, 'merge');
  assert (r->>'meals_added')::int = 3,       'T6a meals_added: '||r;
  assert (r->>'placeholder_meals')::int = 2, 'T6b placeholders: '||r;
  assert (r->>'days_added')::int = 3 and (r->>'days_merged')::int = 1 and (r->>'days_invalid')::int = 1, 'T6c days: '||r;
  assert (r->>'entries_no_free_slot')::int = 1, 'T6d 4th breakfast option has no slot: '||r;
  assert (select slot from public.diet_entries e join public.diet_days d on d.id = e.day_id
           where d.day = '2026-11-01' and e.meal_type = 'lunch') = 1, 'T6e slot position preserved';
  assert (select name from public.diet_meals where legacy_id = 'gone-123') = 'Deleted meal', 'T6f deleted placeholder';
  assert (select archived_at is not null from public.diet_meals where legacy_id = 'gone-123'), 'T6g placeholder archived';
  assert (select name from public.diet_meals where legacy_id = 'missing-Masala Dosa') = 'Masala Dosa', 'T6h xlsx placeholder name';
  assert (select category from public.diet_meals where legacy_id = 'm-odd') = 'Other', 'T6i bad category → Other';
  assert (select calories from public.diet_meals where legacy_id = 'm-dal') = 520, 'T6j string number parsed';
  assert (select notes = 'merged note' and calorie_target = 1500 from public.diet_days where day = '2026-11-19'), 'T6k merge fills empty notes/target';
  assert (select completed from public.diet_entries e join public.diet_days d on d.id=e.day_id where d.day='2026-11-01' and meal_type='breakfast'), 'T6l completed flag';
  -- idempotency: importing the same file again adds nothing
  r := public.diet_import_backup(p, 'merge');
  assert (r->>'meals_added')::int = 0 and (r->>'entries_added')::int = 0 and (r->>'placeholder_meals')::int = 0, 'T6m re-import idempotent: '||r;
  raise notice 'PASS T6 legacy JSON import: merge, placeholders, slots, validation, idempotency';
end $$;

-- ---------------- T7 invalid payload rolls back ----------------
do $$ declare before int := (select count(*) from public.diet_meals); begin
  begin perform public.diet_import_backup('{"meals":{}}'::jsonb, 'merge'); raise exception 'T7a bad payload accepted';
  exception when invalid_parameter_value then null; end;
  begin perform public.diet_import_backup('{"meals":[],"dietHistory":[]}'::jsonb, 'wipe'); raise exception 'T7b bad mode accepted';
  exception when raise_exception then null; end;
  assert (select count(*) from public.diet_meals) = before, 'T7c nothing changed';
  raise notice 'PASS T7 invalid imports rejected without side effects';
end $$;

-- ---------------- T8 replace import ----------------
do $$ declare r jsonb; begin
  r := public.diet_import_backup('{"meals":[{"id":"x1","name":"Only Meal","category":"Any","calories":100,"archived":false}],
        "dietHistory":[{"date":"2026-10-10","breakfast":[{"mealId":"x1"}],"lunch":[],"dinner":[]}],
        "settings":{"calorieTolerance":50},"metadata":{"lastBackup":"2026-10-11T08:00:00.000Z"}}'::jsonb, 'replace');
  assert (select count(*) from public.diet_meals) = 1, 'T8a replace leaves only imported meals';
  assert (select count(*) from public.diet_days) = 1, 'T8b replace leaves only imported days';
  assert (select calorie_tolerance = 50 and last_backup_at is not null from public.diet_settings), 'T8c settings restored';
  raise notice 'PASS T8 replace import';
end $$;

-- ---------------- T9 clear all ----------------
do $$ declare r jsonb; begin
  r := public.diet_clear_all();
  assert (select count(*) from public.diet_days) = 0 and (select count(*) from public.diet_entries) = 0, 'T9a history cleared';
  assert (select count(*) from public.diet_meals) = 10, 'T9b samples restored';
  assert (select calorie_tolerance = 0 and last_backup_at is null from public.diet_settings), 'T9c settings reset';
  raise notice 'PASS T9 clear-all (atomic) restores samples';
end $$;

-- Alice's data untouched by Bob's replace/clear
select from pg_temp.as_user('00000000-0000-0000-0000-00000000000a');
do $$ begin
  assert (select count(*) from public.diet_meals) = 10 and (select count(*) from public.diet_entries) = 1, 'T9d alice unaffected';
  raise notice 'PASS T9 other users unaffected by clear/replace';
end $$;

-- ---------------- T10 account deletion cascades ----------------
reset role;
do $$ begin
  delete from auth.users where id = '00000000-0000-0000-0000-00000000000a';
  assert not exists (select 1 from public.diet_meals where user_id = '00000000-0000-0000-0000-00000000000a'), 'T10a meals cascade';
  assert not exists (select 1 from public.diet_days  where user_id = '00000000-0000-0000-0000-00000000000a'), 'T10b days cascade';
  assert not exists (select 1 from public.diet_settings where user_id = '00000000-0000-0000-0000-00000000000a'), 'T10c settings cascade';
  raise notice 'PASS T10 deleting an auth user removes all of their data';
end $$;
