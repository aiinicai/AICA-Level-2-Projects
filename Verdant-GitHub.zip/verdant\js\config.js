/* Verdant — Supabase connection settings.
 * Paste your project's values here (Supabase dashboard → Project Settings → API).
 *   SUPABASE_URL      e.g. https://abcdefghijkl.supabase.co
 *   SUPABASE_ANON_KEY the "anon public" key or a "sb_publishable_…" key
 * These two values are designed to be public: Row Level Security protects the data.
 * NEVER put the service_role / secret key in this file or anywhere in the frontend.
 */
window.VERDANT_CONFIG = {
  SUPABASE_URL: "https://dqsobtsmfxhkckslmtfg.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_EJ8obqBDYcvJ0LEP1JpGtQ_ZKKtKDrO",
  // Android app only (optional): web address that email links (confirm / reset password) should open.
  // Leave empty to use the "Site URL" configured in Supabase → Authentication → URL Configuration.
  AUTH_REDIRECT_URL: "",
};
