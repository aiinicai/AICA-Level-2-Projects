# Verdant — Android app

This folder wraps the web app in `../verdant` as an Android app with [Capacitor](https://capacitorjs.com).
The web code is not duplicated by hand: `npm run copy-web` copies `../verdant` into `www/` on every build.

## Rebuild the APK (Windows PowerShell)

```powershell
$env:JAVA_HOME = (Get-ChildItem "$env:USERPROFILE\.verdant-build\jdk-x" -Directory | Select -First 1).FullName
$env:ANDROID_HOME = "$env:USERPROFILE\.verdant-build\android-sdk"
npm run build:apk
```

Output: `android/app/build/outputs/apk/release/app-release.apk`

Before building, fill in `../verdant/js/config.js` (Supabase URL + anon key), or the app opens on the
"Connect your database" screen.

## Signing key — keep it safe

`android/verdant-release.jks` + `android/keystore.properties` sign the APK. Back both up privately.
Updates to an installed app must be signed with the same key; lose it and users must uninstall first.
Never commit or share them (they are in `.gitignore`).

## App-specific behaviour

- Backup / Excel export: saved to the phone's Documents folder and offered through the Android share sheet.
- Email links (confirm sign-up, reset password) open in the phone browser. Set `AUTH_REDIRECT_URL` in
  `config.js` to a hosted copy of the web app, or turn off "Confirm email" in Supabase → Authentication.
- To bump the version for an update, raise `versionCode` / `versionName` in `android/app/build.gradle`.
