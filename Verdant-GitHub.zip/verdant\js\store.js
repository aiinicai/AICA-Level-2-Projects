/* Verdant — Supabase data layer.
 * Supabase is the single source of truth. This module keeps an in-memory copy of
 * the signed-in user's rows (loaded from the database) purely for rendering;
 * every change is written to the database first and the copy is updated from the
 * row the database returns. Nothing is persisted to localStorage except the
 * Supabase auth session (handled by supabase-js).
 */
(function () {
  "use strict";
  const { MEAL_TYPES } = window.Calc;
  const PAGE = 1000; // PostgREST default max rows per request
  const MEAL_COLS = "id,name,category,description,ingredients,calories,protein,carbs,fat,serving,tags,prep,legacy_id,archived_at,created_at,updated_at";
  const DAY_COLS = "id,day,calorie_target,notes,updated_at";
  const ENTRY_COLS = "id,day_id,meal_type,slot,meal_id,completed,portion";

  class StoreError extends Error {
    constructor(message, cause) { super(message); this.cause = cause; this.code = cause && cause.code; }
  }

  function friendly(err, action) {
    if (!err) return new StoreError(`Could not ${action}.`);
    if (err instanceof StoreError) return err;
    const msg = String(err.message || err);
    if (err.name === "TypeError" || /Failed to fetch|NetworkError|Load failed/i.test(msg))
      return new StoreError(`Could not ${action}: the server could not be reached. Check your connection — this change was not saved.`, err);
    if (err.code === "23514") return new StoreError(`Could not ${action}: a value is outside the allowed range.`, err);
    if (err.code === "23505") return new StoreError(`Could not ${action}: this record already exists.`, err);
    if (err.code === "42501" || /row-level security/i.test(msg)) return new StoreError(`Could not ${action}: permission denied. Please sign in again.`, err);
    if (err.code === "PGRST301" || /JWT/i.test(msg)) return new StoreError(`Your session has expired. Please sign in again.`, err);
    if (err.code === "42P01" || err.code === "PGRST205" || /relation .* does not exist|Could not find the table/i.test(msg))
      return new StoreError(`The database tables were not found. Run supabase/migrations/001_verdant_schema.sql in your Supabase project (see README).`, err);
    return new StoreError(`Could not ${action}: ${msg}`, err);
  }

  const Store = {
    client: null,
    user: null,
    meals: [],
    mealsById: new Map(),
    days: new Map(),        // 'YYYY-MM-DD' → { id, day, calorie_target, notes, entries:{breakfast:[…3],…} }
    settings: { calorie_tolerance: 0, last_backup_at: null },
    loadedAt: 0,
    _queue: Promise.resolve(),
    onStatus: () => {},     // (state: 'saving'|'saved'|'error'|'loading', message?)

    init(url, key) {
      this.client = window.supabase.createClient(url, key, {
        auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
      });
      return this.client;
    },

    // Serialise writes so rapid edits (typing notes, ticking boxes) land in order.
    pending: 0,             // writes queued or in flight (used to warn before closing the tab)
    _write(action, fn) {
      this.pending++;
      const run = async () => {
        this.onStatus("saving");
        try { const r = await fn(); this.onStatus(this.pending > 1 ? "saving" : "saved"); return r; }
        catch (e) { const fe = friendly(e, action); this.onStatus("error", fe.message); throw fe; }
        finally { this.pending--; }
      };
      const p = this._queue.then(run, run);
      this._queue = p.catch(() => {});
      return p;
    },
    _check({ data, error }) { if (error) throw error; return data; },

    async _fetchAll(table, cols, order) {
      const out = [];
      for (let from = 0; ; from += PAGE) {
        const rows = this._check(await this.client.from(table).select(cols).order(order).order("id").range(from, from + PAGE - 1));
        out.push(...rows);
        if (rows.length < PAGE) break;
      }
      return out;
    },

    // ---------- load ----------
    async bootstrap(seedSamples) {
      try { return this._check(await this.client.rpc("diet_bootstrap", { p_seed: !!seedSamples })); }
      catch (e) { throw friendly(e, "set up your account"); }
    },

    async loadAll() {
      this.onStatus("loading");
      try {
        const [meals, days, entries, settings] = await Promise.all([
          this._fetchAll("diet_meals", MEAL_COLS, "name"),
          this._fetchAll("diet_days", DAY_COLS, "day"),
          this._fetchAll("diet_entries", ENTRY_COLS, "day_id"),
          this.client.from("diet_settings").select("calorie_tolerance,last_backup_at").maybeSingle().then((r) => this._check(r)),
        ]);
        this._setMeals(meals);
        this._setDays(days, entries);
        this.settings = { calorie_tolerance: Number(settings?.calorie_tolerance) || 0, last_backup_at: settings?.last_backup_at || null };
        this.loadedAt = Date.now();
        this.onStatus("saved");
      } catch (e) { const fe = friendly(e, "load your data"); this.onStatus("error", fe.message); throw fe; }
    },

    _normMeal(m) { return { ...m, calories: num(m.calories), protein: num(m.protein), carbs: num(m.carbs), fat: num(m.fat) }; },
    _setMeals(rows) {
      this.meals = rows.map((m) => this._normMeal(m)).sort((a, b) => a.name.localeCompare(b.name));
      this.mealsById = new Map(this.meals.map((m) => [m.id, m]));
    },
    _blankDay(date) { return { id: null, day: date, calorie_target: null, notes: "", entries: { breakfast: [null, null, null], lunch: [null, null, null], dinner: [null, null, null] } }; },
    _setDays(dayRows, entryRows) {
      const byId = new Map();
      this.days = new Map();
      for (const r of dayRows) {
        const d = { ...this._blankDay(r.day), id: r.id, calorie_target: num(r.calorie_target), notes: r.notes || "" };
        this.days.set(r.day, d); byId.set(r.id, d);
      }
      for (const e of entryRows) { const d = byId.get(e.day_id); if (d) d.entries[e.meal_type][e.slot] = e; }
    },
    getDay(date) { return this.days.get(date) || null; },
    viewDay(date) { return this.days.get(date) || this._blankDay(date); },

    // ---------- meals ----------
    saveMeal(fields, id) {
      return this._write(id ? "update the meal" : "add the meal", async () => {
        const payload = { ...fields };
        const q = id
          ? this.client.from("diet_meals").update(payload).eq("id", id).select(MEAL_COLS).single()
          : this.client.from("diet_meals").insert({ ...payload, user_id: this.user.id }).select(MEAL_COLS).single();
        const row = this._normMeal(this._check(await q));
        this._setMeals([...this.meals.filter((m) => m.id !== row.id), row]);
        return row;
      });
    },
    isMealReferenced(id) {
      for (const d of this.days.values()) for (const t of MEAL_TYPES) if (d.entries[t].some((e) => e && e.meal_id === id)) return true;
      return false;
    },
    // Hard-delete when unused; archive when history references it (history keeps name & nutrition).
    deleteMeal(id) {
      return this._write("delete the meal", async () => {
        if (!this.isMealReferenced(id)) {
          const { error } = await this.client.from("diet_meals").delete().eq("id", id);
          if (!error) { this._setMeals(this.meals.filter((m) => m.id !== id)); return "deleted"; }
          if (error.code !== "23503") throw error; // referenced from another device → archive instead
        }
        const row = this._normMeal(this._check(await this.client.from("diet_meals").update({ archived_at: new Date().toISOString() }).eq("id", id).select(MEAL_COLS).single()));
        this._setMeals([...this.meals.filter((m) => m.id !== id), row]);
        return "archived";
      });
    },
    restoreMeal(id) { return this.saveMeal({ archived_at: null }, id); },
    addSampleMeals() {
      return this._write("add the sample meals", async () => {
        const n = this._check(await this.client.rpc("diet_add_sample_meals"));
        this._setMeals(await this._fetchAll("diet_meals", MEAL_COLS, "name"));
        return n;
      });
    },

    // ---------- days & entries ----------
    async _ensureDayRow(date, extra) {
      const row = this._check(await this.client.from("diet_days")
        .upsert({ user_id: this.user.id, day: date, ...(extra || {}) }, { onConflict: "user_id,day" })
        .select(DAY_COLS).single());
      let d = this.days.get(date);
      if (!d) { d = this._blankDay(date); this.days.set(date, d); }
      d.id = row.id; d.calorie_target = num(row.calorie_target); d.notes = row.notes || "";
      return d;
    },
    setDayFields(date, fields) { return this._write("save the day", () => this._ensureDayRow(date, fields)); },
    setEntry(date, type, slot, fields) {
      return this._write("save the meal option", async () => {
        let d = this.days.get(date);
        if (!d || !d.id) d = await this._ensureDayRow(date);
        const cur = d.entries[type][slot];
        const payload = { user_id: this.user.id, day_id: d.id, meal_type: type, slot,
          meal_id: fields.meal_id ?? cur?.meal_id, completed: fields.completed ?? cur?.completed ?? false, portion: fields.portion ?? cur?.portion ?? "" };
        if (!payload.meal_id) throw new StoreError("Select a meal for this option first.");
        const row = this._check(await this.client.from("diet_entries").upsert(payload, { onConflict: "day_id,meal_type,slot" }).select(ENTRY_COLS).single());
        d.entries[type][slot] = row;
        return row;
      });
    },
    clearEntry(date, type, slot) {
      return this._write("clear the meal option", async () => {
        const d = this.days.get(date), cur = d && d.entries[type][slot];
        if (!cur) return;
        this._check(await this.client.from("diet_entries").delete().eq("id", cur.id));
        d.entries[type][slot] = null;
      });
    },
    clearDay(date) {
      return this._write("clear the day", async () => {
        const d = this.days.get(date);
        if (!d || !d.id) return;
        this._check(await this.client.from("diet_days").delete().eq("id", d.id)); // entries cascade
        this.days.delete(date);
      });
    },

    // ---------- settings / bulk ----------
    updateSettings(patch) {
      return this._write("save settings", async () => {
        const row = this._check(await this.client.from("diet_settings").upsert({ user_id: this.user.id, ...patch }, { onConflict: "user_id" })
          .select("calorie_tolerance,last_backup_at").single());
        this.settings = { calorie_tolerance: Number(row.calorie_tolerance) || 0, last_backup_at: row.last_backup_at };
      });
    },
    importBackup(payload, mode) {
      return this._write("import the backup", async () => {
        const res = this._check(await this.client.rpc("diet_import_backup", { p_payload: payload, p_mode: mode }));
        await this.loadAll();
        return res;
      });
    },
    clearAll() {
      return this._write("clear your data", async () => {
        const res = this._check(await this.client.rpc("diet_clear_all"));
        await this.loadAll();
        return res;
      });
    },

    // Same JSON shape as the original app's "Save History" backup (version 1),
    // so files remain interchangeable. Archived meals are included so history resolves.
    toBackup() {
      const dayList = [...this.days.values()].sort((a, b) => a.day.localeCompare(b.day));
      const slotArr = (arr) => {
        const out = arr.map((e) => (e ? { mealId: e.meal_id, completed: !!e.completed, portion: e.portion || "" } : {}));
        while (out.length && !out[out.length - 1].mealId) out.pop();
        return out;
      };
      return {
        version: 1,
        app: "Verdant",
        meals: this.meals.map((m) => ({ id: m.id, name: m.name, category: m.category, description: m.description, ingredients: m.ingredients,
          calories: m.calories, protein: m.protein, carbs: m.carbs, fat: m.fat, serving: m.serving, tags: m.tags, prep: m.prep, archived: !!m.archived_at })),
        dietHistory: dayList.map((d) => ({ date: d.day, breakfast: slotArr(d.entries.breakfast), lunch: slotArr(d.entries.lunch), dinner: slotArr(d.entries.dinner),
          notes: d.notes || "", calorieTarget: d.calorie_target })),
        settings: { calorieTolerance: this.settings.calorie_tolerance },
        metadata: { lastBackup: this.settings.last_backup_at, backupCreatedAt: new Date().toISOString(), account: this.user && this.user.email },
      };
    },
  };

  function num(v) { return v === null || v === undefined || v === "" ? null : Number(v); }

  window.Store = Store;
  window.StoreError = StoreError;
})();
