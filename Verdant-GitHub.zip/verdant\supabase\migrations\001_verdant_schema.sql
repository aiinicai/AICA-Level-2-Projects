-- =====================================================================
-- Verdant — Diet Planner · Supabase schema, RLS and RPCs
-- Migration 001. Safe to run once in the Supabase SQL editor.
-- All objects are prefixed "diet_" so they can live alongside other apps
-- in the same project without colliding (e.g. an existing "profiles").
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Tables
-- ---------------------------------------------------------------------

-- Per-user settings (one row per user). Created by diet_bootstrap().
create table public.diet_settings (
  user_id            uuid primary key default auth.uid()
                     references auth.users(id) on delete cascade,
  calorie_tolerance  numeric(7,1) not null default 0
                     check (calorie_tolerance >= 0 and calorie_tolerance <= 2000),
  last_backup_at     timestamptz,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

-- Reusable meal library. Meals used in history are archived, never hard-deleted,
-- so historic records keep their name and nutrition values.
create table public.diet_meals (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null default auth.uid()
               references auth.users(id) on delete cascade,
  name         text not null check (char_length(btrim(name)) between 1 and 200),
  category     text not null default 'Other'
               check (category in ('Breakfast','Lunch','Dinner','Snack','Other','Any')),
  description  text not null default '' check (char_length(description) <= 2000),
  ingredients  text not null default '' check (char_length(ingredients) <= 4000),
  calories     numeric(8,1) check (calories >= 0 and calories <= 20000),
  protein      numeric(7,1) check (protein  >= 0 and protein  <= 2000),
  carbs        numeric(7,1) check (carbs    >= 0 and carbs    <= 2000),
  fat          numeric(7,1) check (fat      >= 0 and fat      <= 2000),
  serving      text not null default '' check (char_length(serving) <= 200),
  tags         text not null default '' check (char_length(tags) <= 500),
  prep         text not null default '' check (char_length(prep) <= 4000),
  legacy_id    text,              -- id from the offline app / backups, for de-duplication
  archived_at  timestamptz,       -- set instead of deleting when history references the meal
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint diet_meals_id_user_key unique (id, user_id),
  constraint diet_meals_user_legacy_key unique (user_id, legacy_id)
);
create index diet_meals_user_active_idx on public.diet_meals (user_id, name) where archived_at is null;

-- One row per user per calendar day.
create table public.diet_days (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null default auth.uid()
                  references auth.users(id) on delete cascade,
  day             date not null,
  calorie_target  numeric(8,1) check (calorie_target > 0 and calorie_target <= 20000),
  notes           text not null default '' check (char_length(notes) <= 5000),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  constraint diet_days_user_day_key unique (user_id, day),
  constraint diet_days_id_user_key unique (id, user_id)
);

-- Up to three meal options per meal type per day.
create table public.diet_entries (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null default auth.uid()
              references auth.users(id) on delete cascade,
  day_id      uuid not null,
  meal_type   text not null check (meal_type in ('breakfast','lunch','dinner')),
  slot        smallint not null check (slot between 0 and 2),
  meal_id     uuid not null,
  completed   boolean not null default false,
  portion     text not null default '' check (char_length(portion) <= 100),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint diet_entries_slot_key unique (day_id, meal_type, slot),
  -- Composite FKs guarantee an entry can only point at the SAME user's day and meal.
  constraint diet_entries_day_fk  foreign key (day_id, user_id)
             references public.diet_days (id, user_id) on delete cascade,
  constraint diet_entries_meal_fk foreign key (meal_id, user_id)
             references public.diet_meals (id, user_id) on delete no action
             deferrable initially deferred   -- lets account deletion cascade in any order
);
create index diet_entries_user_idx on public.diet_entries (user_id);
create index diet_entries_meal_idx on public.diet_entries (meal_id);

-- ---------------------------------------------------------------------
-- 2. updated_at maintenance
-- ---------------------------------------------------------------------
create function public.diet_touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end $$;

create trigger diet_settings_touch before update on public.diet_settings for each row execute function public.diet_touch_updated_at();
create trigger diet_meals_touch    before update on public.diet_meals    for each row execute function public.diet_touch_updated_at();
create trigger diet_days_touch     before update on public.diet_days     for each row execute function public.diet_touch_updated_at();
create trigger diet_entries_touch  before update on public.diet_entries  for each row execute function public.diet_touch_updated_at();

-- ---------------------------------------------------------------------
-- 3. Row Level Security — every row is visible/editable only by its owner
-- ---------------------------------------------------------------------
alter table public.diet_settings enable row level security;
alter table public.diet_meals    enable row level security;
alter table public.diet_days     enable row level security;
alter table public.diet_entries  enable row level security;

do $$
declare t text;
begin
  foreach t in array array['diet_settings','diet_meals','diet_days','diet_entries'] loop
    execute format('create policy %I on public.%I for select to authenticated using (user_id = (select auth.uid()))', t||'_select_own', t);
    execute format('create policy %I on public.%I for insert to authenticated with check (user_id = (select auth.uid()))', t||'_insert_own', t);
    execute format('create policy %I on public.%I for update to authenticated using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()))', t||'_update_own', t);
    execute format('create policy %I on public.%I for delete to authenticated using (user_id = (select auth.uid()))', t||'_delete_own', t);
    -- Anonymous visitors get nothing, even before RLS is evaluated.
    execute format('revoke all on public.%I from anon', t);
    execute format('grant select, insert, update, delete on public.%I to authenticated', t);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 4. Helper functions (all SECURITY INVOKER: they run under the caller's RLS)
-- ---------------------------------------------------------------------

-- Lenient number parser for imported JSON values ("300", 300, "", null).
create function public.diet_to_num(v jsonb) returns numeric
language plpgsql immutable set search_path = '' as $$
declare n numeric;
begin
  if v is null or jsonb_typeof(v) = 'null' then return null; end if;
  if jsonb_typeof(v) = 'number' then n := (v #>> '{}')::numeric;
  elsif jsonb_typeof(v) = 'string' and btrim(v #>> '{}') ~ '^-?[0-9]+(\.[0-9]+)?$' then n := btrim(v #>> '{}')::numeric;
  else return null; end if;
  if n < 0 then return null; end if;
  return round(n, 1);
end $$;

-- Adds the standard sample meals to the caller's library.
create function public.diet_add_sample_meals() returns integer
language plpgsql security invoker set search_path = '' as $$
declare uid uuid := auth.uid(); n integer;
begin
  if uid is null then raise exception 'Not authenticated' using errcode = '28000'; end if;
  insert into public.diet_meals (user_id, name, category, description, ingredients, calories, protein, carbs, fat, serving, tags, prep)
  select uid, s.* from (values
    ('Vegetable Poha','Breakfast','Light poha with vegetables and peanuts.','Poha, onion, peas, carrot, peanuts, lemon, coriander',300,7,48,9,'1 bowl','quick,vegetarian','Rinse poha; sauté vegetables and tempering; mix and cook briefly.'),
    ('Moong Dal Chilla','Breakfast','Protein-rich savoury lentil pancakes.','Soaked moong dal, onion, tomato, coriander, spices',280,16,36,7,'2 chillas','high-protein,vegetarian','Blend soaked dal, add vegetables and cook on a hot tawa.'),
    ('Greek Yogurt & Fruit','Breakfast','Yogurt with seasonal fruit and seeds.','Greek yogurt, fruit, chia/flax seeds',260,18,30,7,'1 bowl','quick,high-protein','Combine yogurt, chopped fruit and seeds.'),
    ('Dal Tadka & Roti','Lunch','Dal with whole-wheat rotis and salad.','Toor/moong dal, whole-wheat flour, vegetables, spices',520,20,75,14,'1 bowl + 2 rotis','vegetarian,balanced','Cook dal; temper separately; serve with rotis and salad.'),
    ('Rajma Rice','Lunch','Kidney beans with rice and fresh salad.','Rajma, rice, onion, tomato, spices',560,18,88,11,'1 bowl','vegetarian,filling','Soak and pressure-cook rajma; simmer in tomato-onion masala.'),
    ('Grilled Chicken Bowl','Lunch','Chicken with vegetables and a modest grain portion.','Chicken breast, vegetables, rice/quinoa, herbs',540,43,52,16,'1 bowl','high-protein','Grill seasoned chicken and serve over cooked grain and vegetables.'),
    ('Paneer Bhurji & Roti','Dinner','Paneer scramble with vegetables and roti.','Paneer, onion, tomato, capsicum, spices, roti',510,25,48,22,'1 bowl + 2 rotis','vegetarian,high-protein','Sauté vegetables, crumble paneer and cook with spices.'),
    ('Vegetable Khichdi','Dinner','Comforting rice and lentil khichdi with vegetables.','Rice, moong dal, mixed vegetables, spices',430,15,65,10,'1 large bowl','vegetarian,light','Pressure-cook rice, dal and vegetables with spices.'),
    ('Egg & Vegetable Omelette','Dinner','Egg omelette with mixed vegetables.','Eggs, onion, tomato, capsicum, spinach',330,22,10,21,'2 eggs','high-protein,quick','Whisk eggs, add vegetables and cook until set.'),
    ('Roasted Chana','Snack','Simple crunchy roasted chickpeas.','Roasted chickpeas, spices',180,9,28,4,'40 g','snack,protein','Serve roasted chana with preferred spices.')
  ) as s(name, category, description, ingredients, calories, protein, carbs, fat, serving, tags, prep);
  get diagnostics n = row_count;
  return n;
end $$;

-- First-run setup: creates the settings row once and (optionally) seeds sample meals.
-- Idempotent: a second call (e.g. from another device) does nothing.
create function public.diet_bootstrap(p_seed boolean default true) returns jsonb
language plpgsql security invoker set search_path = '' as $$
declare uid uuid := auth.uid(); created boolean := false; seeded integer := 0;
begin
  if uid is null then raise exception 'Not authenticated' using errcode = '28000'; end if;
  insert into public.diet_settings (user_id) values (uid) on conflict (user_id) do nothing;
  created := found;
  if created and p_seed then seeded := public.diet_add_sample_meals(); end if;
  return jsonb_build_object('created', created, 'seeded', seeded);
end $$;

-- Deletes all of the caller's diet data and restores the sample meals (matches
-- the original "Clear All Data" behaviour). Runs as a single transaction.
create function public.diet_clear_all() returns jsonb
language plpgsql security invoker set search_path = '' as $$
declare uid uuid := auth.uid(); d integer; m integer; s integer;
begin
  if uid is null then raise exception 'Not authenticated' using errcode = '28000'; end if;
  delete from public.diet_entries where user_id = uid;
  delete from public.diet_days    where user_id = uid; get diagnostics d = row_count;
  delete from public.diet_meals   where user_id = uid; get diagnostics m = row_count;
  insert into public.diet_settings (user_id) values (uid)
    on conflict (user_id) do update set calorie_tolerance = 0, last_backup_at = null;
  s := public.diet_add_sample_meals();
  return jsonb_build_object('days_deleted', d, 'meals_deleted', m, 'samples_added', s);
end $$;

-- Imports a backup in the original app's JSON shape:
--   { meals:[{id,name,category,...,archived?}], dietHistory:[{date,breakfast:[{mealId,completed,portion}],lunch,dinner,notes,calorieTarget}], settings?, metadata? }
-- p_mode = 'merge'   → keep existing data; add meals whose id is unknown; fill empty slots / empty notes / empty target
-- p_mode = 'replace' → delete the caller's data first, then load the backup
-- Entries that point at an unknown meal become an archived placeholder meal
-- ("Deleted meal", or the name from an XLSX import), so no record is discarded.
-- Entirely transactional: any error rolls the whole import back.
create function public.diet_import_backup(p_payload jsonb, p_mode text default 'merge') returns jsonb
language plpgsql security invoker set search_path = '' as $$
declare
  uid uuid := auth.uid();
  m jsonb; r jsonb; e jsonb; ord bigint; mt text;
  v_old text; v_new uuid; id_map jsonb := '{}'::jsonb; nm text; cat text;
  v_day date; v_day_id uuid; day_existed boolean; v_target numeric; v_notes text;
  v_meal uuid; v_completed boolean; v_portion text; pref smallint; free_slot smallint;
  meals_added int := 0; meals_matched int := 0; placeholders int := 0;
  days_added int := 0; days_merged int := 0; days_invalid int := 0;
  entries_added int := 0; entries_duplicate int := 0; entries_no_slot int := 0;
  tol numeric;
begin
  if uid is null then raise exception 'Not authenticated' using errcode = '28000'; end if;
  if p_mode not in ('merge','replace') then raise exception 'Invalid import mode: %', p_mode; end if;
  if jsonb_typeof(p_payload) <> 'object'
     or jsonb_typeof(p_payload->'meals') <> 'array'
     or jsonb_typeof(p_payload->'dietHistory') <> 'array' then
    raise exception 'Invalid backup structure: expected "meals" and "dietHistory" arrays' using errcode = '22023';
  end if;

  insert into public.diet_settings (user_id) values (uid) on conflict (user_id) do nothing;

  if p_mode = 'replace' then
    delete from public.diet_entries where user_id = uid;
    delete from public.diet_days    where user_id = uid;
    delete from public.diet_meals   where user_id = uid;
    tol := public.diet_to_num(p_payload->'settings'->'calorieTolerance');
    update public.diet_settings
       set calorie_tolerance = coalesce(tol, 0),
           last_backup_at = case when (p_payload->'metadata'->>'lastBackup') ~ '^\d{4}-\d{2}-\d{2}T'
                                 then (p_payload->'metadata'->>'lastBackup')::timestamptz end
     where user_id = uid;
  end if;

  -- Meals -------------------------------------------------------------
  for m in select value from jsonb_array_elements(p_payload->'meals') loop
    v_old := nullif(m->>'id', '');
    nm := btrim(coalesce(m->>'name', ''));
    continue when v_old is null or nm = '';
    continue when id_map ? v_old;

    select dm.id into v_new from public.diet_meals dm
     where dm.user_id = uid and (dm.id::text = v_old or dm.legacy_id = v_old) limit 1;
    if found then
      meals_matched := meals_matched + 1;
    else
      cat := coalesce(m->>'category', 'Other');
      if cat not in ('Breakfast','Lunch','Dinner','Snack','Other','Any') then cat := 'Other'; end if;
      insert into public.diet_meals (user_id, name, category, description, ingredients, calories, protein, carbs, fat,
                                     serving, tags, prep, legacy_id, archived_at)
      values (uid, left(nm, 200), cat,
              left(coalesce(m->>'description',''), 2000), left(coalesce(m->>'ingredients',''), 4000),
              least(public.diet_to_num(m->'calories'), 20000), least(public.diet_to_num(m->'protein'), 2000),
              least(public.diet_to_num(m->'carbs'), 2000),     least(public.diet_to_num(m->'fat'), 2000),
              left(coalesce(m->>'serving',''), 200), left(coalesce(m->>'tags',''), 500), left(coalesce(m->>'prep',''), 4000),
              v_old,
              case when m->'archived' = 'true'::jsonb then now() end)
      returning id into v_new;
      meals_added := meals_added + 1;
    end if;
    id_map := id_map || jsonb_build_object(v_old, v_new);
  end loop;

  -- Diet history ------------------------------------------------------
  for r in select value from jsonb_array_elements(p_payload->'dietHistory') loop
    begin
      v_day := (r->>'date')::date;
    exception when others then v_day := null; end;
    if v_day is null or (r->>'date') !~ '^\d{4}-\d{2}-\d{2}$' then days_invalid := days_invalid + 1; continue; end if;

    v_target := public.diet_to_num(r->'calorieTarget');
    if v_target is not null and (v_target <= 0 or v_target > 20000) then v_target := null; end if;
    v_notes := left(coalesce(r->>'notes', ''), 5000);

    select id into v_day_id from public.diet_days where user_id = uid and day = v_day;
    day_existed := found;
    if day_existed then
      update public.diet_days
         set notes = case when notes = '' then v_notes else notes end,
             calorie_target = coalesce(calorie_target, v_target)
       where id = v_day_id;
      days_merged := days_merged + 1;
    else
      insert into public.diet_days (user_id, day, calorie_target, notes)
      values (uid, v_day, v_target, v_notes) returning id into v_day_id;
      days_added := days_added + 1;
    end if;

    foreach mt in array array['breakfast','lunch','dinner'] loop
      continue when jsonb_typeof(r->mt) is distinct from 'array';
      for e, ord in select value, ordinality from jsonb_array_elements(r->mt) with ordinality loop
        v_old := nullif(e->>'mealId', '');
        continue when v_old is null;

        -- resolve the meal (map → existing → archived placeholder)
        v_meal := (id_map->>v_old)::uuid;
        if v_meal is null then
          select dm.id into v_meal from public.diet_meals dm
           where dm.user_id = uid and (dm.id::text = v_old or dm.legacy_id = v_old) limit 1;
          if not found then
            insert into public.diet_meals (user_id, name, category, archived_at, legacy_id)
            values (uid,
                    case when v_old like 'missing-%' and length(v_old) > 8 then left(substr(v_old, 9), 200) else 'Deleted meal' end,
                    'Other', now(), v_old)
            returning id into v_meal;
            placeholders := placeholders + 1;
          end if;
          id_map := id_map || jsonb_build_object(v_old, v_meal);
        end if;

        v_completed := case jsonb_typeof(e->'completed')
                         when 'boolean' then (e->>'completed')::boolean
                         when 'string'  then lower(e->>'completed') in ('true','1','yes')
                         else false end;
        v_portion := left(coalesce(e->>'portion', ''), 100);

        -- merging into an existing day: skip an identical entry already present
        if day_existed and exists (select 1 from public.diet_entries de
              where de.day_id = v_day_id and de.meal_type = mt and de.meal_id = v_meal
                and de.completed = v_completed and de.portion = v_portion) then
          entries_duplicate := entries_duplicate + 1;
          continue;
        end if;

        -- keep the original position if free, otherwise take the first free slot
        pref := case when ord <= 3 then (ord - 1)::smallint end;
        if pref is not null and not exists (select 1 from public.diet_entries de
              where de.day_id = v_day_id and de.meal_type = mt and de.slot = pref) then
          free_slot := pref;
        else
          select s into free_slot from generate_series(0, 2) s
           where not exists (select 1 from public.diet_entries de
                              where de.day_id = v_day_id and de.meal_type = mt and de.slot = s)
           order by s limit 1;
        end if;
        if free_slot is null then entries_no_slot := entries_no_slot + 1; continue; end if;

        insert into public.diet_entries (user_id, day_id, meal_type, slot, meal_id, completed, portion)
        values (uid, v_day_id, mt, free_slot, v_meal, v_completed, v_portion);
        entries_added := entries_added + 1;
      end loop;
    end loop;
  end loop;

  return jsonb_build_object(
    'mode', p_mode,
    'meals_added', meals_added, 'meals_matched', meals_matched, 'placeholder_meals', placeholders,
    'days_added', days_added, 'days_merged', days_merged, 'days_invalid', days_invalid,
    'entries_added', entries_added, 'entries_duplicate', entries_duplicate, 'entries_no_free_slot', entries_no_slot);
end $$;

-- Function privileges: signed-in users only.
revoke all on function public.diet_to_num(jsonb)               from public, anon;
revoke all on function public.diet_add_sample_meals()          from public, anon;
revoke all on function public.diet_bootstrap(boolean)          from public, anon;
revoke all on function public.diet_clear_all()                 from public, anon;
revoke all on function public.diet_import_backup(jsonb, text)  from public, anon;
revoke all on function public.diet_touch_updated_at()          from public, anon;
grant execute on function public.diet_to_num(jsonb)              to authenticated;
grant execute on function public.diet_add_sample_meals()         to authenticated;
grant execute on function public.diet_bootstrap(boolean)         to authenticated;
grant execute on function public.diet_clear_all()                to authenticated;
grant execute on function public.diet_import_backup(jsonb, text) to authenticated;
