// Unit tests for js/calc.js — run with: node tests/calc.test.js
const assert = require("assert");
const C = require("../js/calc.js");
let n = 0; const t = (name, fn) => { fn(); n++; console.log("PASS", name); };
const meals = new Map([["a",{calories:300,protein:7,carbs:48,fat:9}],["b",{calories:520.5,protein:20,carbs:75,fat:14}],["c",{calories:null}],["z",{calories:0.1}],["y",{calories:0.2}]]);
const day = (target, ents) => { const d={calorie_target:target,notes:"",entries:{breakfast:[null,null,null],lunch:[null,null,null],dinner:[null,null,null]}}; ents.forEach(([t,s,m,c])=>d.entries[t][s]={meal_id:m,completed:!!c,portion:""}); return d; };

t("local date helpers do not shift across UTC", () => {
  process.env.TZ = "Asia/Kolkata";
  assert.equal(C.isoLocal(new Date(2026, 10, 19, 0, 30)), "2026-11-19");
  assert.equal(C.addDays("2026-11-19", 1), "2026-11-20");
  assert.equal(C.addDays("2026-12-31", 1), "2027-01-01");
  assert.equal(C.addDays("2026-03-01", -1), "2026-02-28");
  assert.ok(C.isValidISO("2024-02-29") && !C.isValidISO("2026-02-29") && !C.isValidISO("2026-1-1"));
});
t("planned totals sum every selected option; completed-only filter", () => {
  const d = day(1000, [["breakfast",0,"a",true],["lunch",1,"b"],["dinner",0,"c"]]);
  assert.deepEqual(C.totals(d, meals), {calories:820.5,protein:27,carbs:123,fat:23});
  assert.equal(C.totals(d, meals, {completedOnly:true}).calories, 300);
  assert.equal(C.totals(d, meals, {type:"lunch"}).calories, 520.5);
  assert.equal(C.countMeals(d), 3); assert.equal(C.countCompleted(d), 1);
});
t("float sums are rounded (0.1+0.2)", () => assert.equal(C.actualCalories(day(null,[["breakfast",0,"z"],["breakfast",1,"y"]]), meals), 0.3));
t("status: exact match rule and optional tolerance", () => {
  assert.equal(C.calorieStatus(day(300,[["breakfast",0,"a"]]), meals, 0).status, "Achieved");
  assert.equal(C.calorieStatus(day(301,[["breakfast",0,"a"]]), meals, 0).status, "Under-achieved");
  assert.equal(C.calorieStatus(day(299,[["breakfast",0,"a"]]), meals, 0).status, "Over-achieved");
  assert.equal(C.calorieStatus(day(350,[["breakfast",0,"a"]]), meals, 50).status, "Achieved");
  assert.equal(C.calorieStatus(day(351,[["breakfast",0,"a"]]), meals, 50).status, "Under-achieved");
  assert.equal(C.calorieStatus(day(301,[["breakfast",0,"a"]]), meals, 0).variance, -1);
  assert.equal(C.calorieStatus(day(null,[["breakfast",0,"a"]]), meals).status, "—");
  assert.equal(C.calorieStatus(null, meals).status, "—");
});
t("credits: streak ends today, 1 credit per 10 days, remaining shows 10 at zero", () => {
  const days = new Map(); const today = "2026-11-19";
  assert.deepEqual([C.creditStats(days, meals, 0, today).streak, C.creditStats(days, meals, 0, today).remaining], [0, 10]);
  for (let i = 0; i < 23; i++) days.set(C.addDays(today, -i), day(300, [["breakfast",0,"a"]]));
  let c = C.creditStats(days, meals, 0, today);
  assert.deepEqual([c.streak, c.credits, c.remaining, c.progressPct], [23, 2, 7, 30]);
  assert.equal(c.milestones[1].endDate, C.addDays(today, -3));
  days.set(C.addDays(today, -5), day(301, [["breakfast",0,"a"]]));
  c = C.creditStats(days, meals, 0, today); assert.deepEqual([c.streak, c.credits], [5, 0]);
  const d10 = new Map(); for (let i = 0; i < 10; i++) d10.set(C.addDays(today, -i), day(300, [["breakfast",0,"a"]]));
  c = C.creditStats(d10, meals, 0, today); assert.deepEqual([c.credits, c.remaining, c.progressPct], [1, 10, 0]);
});
t("periods: Monday-start week and full month", () => {
  assert.deepEqual(C.periodDates("week", "2026-11-19"), ["2026-11-16","2026-11-17","2026-11-18","2026-11-19","2026-11-20","2026-11-21","2026-11-22"]);
  assert.equal(C.periodDates("month", "2024-02-10").length, 29);
  assert.deepEqual(C.periodDates("day", "2026-11-19"), ["2026-11-19"]);
});
t("overall stats and tracked days", () => {
  const m = new Map([["2026-11-01", day(null,[["breakfast",0,"a",true],["lunch",0,"b"]])], ["2026-11-02", {...day(null,[]), notes:"note"}], ["2026-11-03", day(1800,[])]]);
  assert.deepEqual(C.overallStats(m), {daysTracked:2, planned:2, completed:1, consistency:50});
});
t("macro energy split sums to 100", () => { const e = C.macroEnergy({protein:20,carbs:75,fat:14}); assert.equal(e.protein+e.carbs+e.fat, 100); assert.equal(e.kcal, 506); });
t("slot meal filter keeps category + Any/Snack/Other, excludes archived", () => {
  const list = [{name:"x",category:"Breakfast"},{name:"y",category:"Lunch"},{name:"s",category:"Snack"},{name:"o",category:"Any"},{name:"q",category:"Breakfast",archived_at:"x"}];
  assert.deepEqual(C.mealsForType("breakfast", list).map(m=>m.name), ["x","s","o"]);
});
console.log(`\n${n} calc test groups passed`);
