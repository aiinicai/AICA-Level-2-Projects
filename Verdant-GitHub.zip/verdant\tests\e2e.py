"""End-to-end browser test of the real UI against the local Supabase-compatible stack.
Run: python3 tests/e2e.py   (needs playwright + google-chrome; see README → Testing)"""
import json, http.server, threading, functools, os, re, sys, urllib.request
from playwright.sync_api import sync_playwright

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
UMD = open("/tmp/pg/node_modules/@supabase/supabase-js/dist/umd/supabase.js").read()
CONFIG = 'window.VERDANT_CONFIG={SUPABASE_URL:"http://localhost:54321",SUPABASE_ANON_KEY:"anon-test-key"};'
class Q(http.server.SimpleHTTPRequestHandler):
    def log_message(self,*a): pass
srv = http.server.ThreadingHTTPServer(("127.0.0.1", 8099), functools.partial(Q, directory=ROOT))
threading.Thread(target=srv.serve_forever, daemon=True).start()
BASE = "http://127.0.0.1:8099/index.html"
results = []
def check(name, cond, detail=""):
    results.append((name, bool(cond))); print(("PASS " if cond else "FAIL ") + name + ((" — " + str(detail)) if (detail and not cond) else ""))
def sql(q):
    import subprocess
    return subprocess.run(["psql","-h","/tmp","-p","54329","-U","postgres","-d","t1","-At","-c",q],capture_output=True,text=True).stdout.strip()

def route(ctx):
    ctx.route(re.compile(r"cdn\.jsdelivr\.net.*supabase\.js"), lambda r: r.fulfill(body=UMD, content_type="application/javascript"))
    ctx.route(re.compile(r"fonts\.(googleapis|gstatic)\.com"), lambda r: r.abort())
    ctx.route(re.compile(r".*/js/config\.js"), lambda r: r.fulfill(body=CONFIG, content_type="application/javascript"))

EMAIL = "piyush@example.com"; PW = "correct-horse-1"
with sync_playwright() as p:
    b = p.chromium.launch(executable_path="/usr/bin/google-chrome", args=["--no-sandbox"])
    ctx = b.new_context(viewport={"width":1366,"height":850}, timezone_id="Asia/Kolkata"); route(ctx)
    page = ctx.new_page(); errors = []
    page.on("pageerror", lambda e: errors.append(str(e))); page.on("console", lambda m: m.type=="error" and errors.append(m.text))

    # ---- seed legacy localStorage data (original app's format) BEFORE first load ----
    legacy = {"version":1,"meals":[
        {"id":"L-poha","name":"Legacy Poha","category":"Breakfast","calories":300,"protein":7,"carbs":48,"fat":9,"serving":"1 bowl","tags":"quick"},
        {"id":"L-dal","name":"Legacy Dal","category":"Lunch","calories":500,"protein":20,"carbs":70,"fat":12}],
      "dietHistory":[{"date":"2026-11-10","breakfast":[{"mealId":"L-poha","completed":True,"portion":"1.5"}],"lunch":[{"mealId":"L-dal","completed":False}],"dinner":[{"mealId":"gone-1","completed":True}],"notes":"legacy note","calorieTarget":800}],
      "settings":{},"metadata":{}}
    page.goto(BASE); page.evaluate("(d)=>localStorage.setItem('dietTrackerData_v1',JSON.stringify(d))", legacy)

    # ---- auth ----
    page.goto(BASE); page.wait_for_selector("#authScreen:not([hidden])")
    check("unauthenticated visitors see the sign-in screen, not the app", page.is_hidden("#appShell"))
    page.fill("#authEmail","bad"); page.fill("#authPassword","x"); page.click("#authSubmit")
    check("sign-in validation shows an error", "valid email" in page.inner_text("#authMsg"))
    page.fill("#authEmail",EMAIL); page.fill("#authPassword","wrongpass1"); page.click("#authSubmit"); page.wait_for_timeout(500)
    check("wrong credentials are rejected with a message", "Invalid login" in page.inner_text("#authMsg"), page.inner_text("#authMsg"))
    page.click('[data-mode="signup"]'); page.fill("#authEmail",EMAIL); page.fill("#authPassword",PW); page.click("#authSubmit")
    page.wait_for_selector("#appShell:not([hidden])")
    check("sign-up logs the user in", True)

    # legacy offer: samples must NOT have been seeded
    page.wait_for_selector("#legacyBanner:not([hidden])")
    check("legacy banner offered with counts", "1</b> diet records" in page.inner_html("#legacyBanner") or "1 diet records" in page.inner_text("#legacyBanner"), page.inner_text("#legacyBanner"))
    check("no sample meals seeded while legacy data awaits import", sql("select count(*) from diet_meals")=="0", sql("select count(*) from diet_meals"))
    page.click("#legacyImportBtn"); page.wait_for_selector("#legacyBanner", state="hidden")
    check("legacy meals migrated into Supabase", sql("select count(*) from diet_meals where legacy_id like 'L-%'")=="2")
    check("legacy history migrated (3 entries, completed + portion kept)", sql("select count(*) from diet_entries")=="3" and sql("select portion from diet_entries where completed and meal_type='breakfast'")=="1.5")
    check("orphan reference kept as archived 'Deleted meal'", sql("select count(*) from diet_meals where name='Deleted meal' and archived_at is not null")=="1")
    check("legacy original left untouched in localStorage", page.evaluate("!!localStorage.getItem('dietTrackerData_v1')"))

    # ---- meal CRUD via UI ----
    page.click('#sideNav [data-tab="meals"]'); page.click("#addMealBtn")
    page.click("#mealSave"); check("meal form validates required name", "name is required" in page.inner_text("#mealErr"))
    page.fill("#mName","Test Oats Bowl"); page.select_option("#mCategory","Breakfast"); page.fill("#mCalories","350"); page.fill("#mProtein","12.5"); page.fill("#mCarbs","55"); page.fill("#mFat","8")
    page.fill("#mCalories","-4"); page.click("#mealSave"); check("negative calories rejected client-side", "Calories must be" in page.inner_text("#mealErr"))
    page.fill("#mCalories","350"); page.click("#mealSave"); page.wait_for_selector("#mealModal:not(.show)", state="attached")
    check("CREATE meal persisted in Postgres", sql("select calories||'/'||protein from diet_meals where name='Test Oats Bowl'")=="350.0/12.5", sql("select * from diet_meals where name='Test Oats Bowl'"))
    page.click('[data-edit]:near(:text("Test Oats Bowl"))') if False else None
    card = page.locator("article.meal-card", has_text="Test Oats Bowl"); card.get_by_text("Edit").click()
    page.fill("#mName","Test Oats Bowl v2"); page.fill("#mCalories","360"); page.click("#mealSave"); page.wait_for_selector("#mealModal:not(.show)", state="attached")
    check("UPDATE meal persisted", sql("select calories from diet_meals where name='Test Oats Bowl v2'")=="360.0")
    page.locator("article.meal-card", has_text="Test Oats Bowl v2").get_by_text("Duplicate").click(); page.wait_for_selector("article.meal-card:has-text(\"v2 (Copy)\")")
    check("DUPLICATE meal persisted", sql("select count(*) from diet_meals where name='Test Oats Bowl v2 (Copy)'")=="1")
    page.locator("article.meal-card", has_text="v2 (Copy)").get_by_role("button",name="Delete").click(); page.click("#confirmYes"); page.wait_for_timeout(600)
    check("DELETE unused meal hard-deletes in Postgres", sql("select count(*) from diet_meals where name like '%(Copy)'")=="0")
    page.fill("#mealSearch","legacy"); page.wait_for_timeout(100)
    check("search filters the library", page.locator("article.meal-card").count()==2, page.locator("article.meal-card").count()); page.fill("#mealSearch","")
    page.click("#resetSamplesBtn"); page.click("#confirmYes"); page.wait_for_timeout(700)
    check("sample meals added via RPC", sql("select count(*) from diet_meals where name='Rajma Rice'")=="1")

    # ---- daily plan ----
    page.click('#sideNav [data-tab="daily"]'); page.fill("#dietDate","2026-11-19"); page.dispatch_event("#dietDate","change")
    page.fill("#dailyCalorieTarget","99999"); page.dispatch_event("#dailyCalorieTarget","change")
    check("out-of-range target rejected", "between 1 and 20,000" in page.inner_text("#targetErr"))
    page.fill("#dailyCalorieTarget","1160"); page.dispatch_event("#dailyCalorieTarget","change"); page.wait_for_timeout(500)
    check("target saved to day row", sql("select calorie_target from diet_days where day='2026-11-19'")=="1160.0")
    def pick(type, slot, name):
        sel = page.locator(f'.opt[data-type="{type}"][data-slot="{slot}"] select[data-act="meal"]')
        sel.select_option(label=name); page.wait_for_timeout(450)
    pick("breakfast",0,"Vegetable Poha"); pick("lunch",0,"Rajma Rice"); pick("dinner",0,"Paneer Bhurji & Roti")
    check("planned calories = 300+560+510", page.inner_text("#dPlanned").replace(",","")=="1,370 kcal".replace(",",""), page.inner_text("#dPlanned"))
    check("entries persisted (3)", sql("select count(*) from diet_entries e join diet_days d on d.id=e.day_id where d.day='2026-11-19'")=="3")
    check("status Over-achieved (1370 vs 1160)", page.inner_text("#dStatus")=="Over-achieved" and "210 kcal above" in page.inner_text("#dConclusion"), page.inner_text("#dConclusion"))
    pick("dinner",0,"Vegetable Khichdi")  # 300+560+430 = 1290
    page.fill("#dailyCalorieTarget","1290"); page.dispatch_event("#dailyCalorieTarget","change"); page.wait_for_timeout(500)
    check("status Achieved at exact match", page.inner_text("#dStatus")=="Achieved", page.inner_text("#dStatus"))
    page.locator('.opt[data-type="breakfast"][data-slot="0"] input[data-act="done"]').check(); page.wait_for_timeout(450)
    page.fill('.opt[data-type="breakfast"][data-slot="0"] input[data-act="portion"]',"1 plate"); page.dispatch_event('.opt[data-type="breakfast"][data-slot="0"] input[data-act="portion"]',"change"); page.wait_for_timeout(450)
    check("completed + portion persisted", sql("select completed::int||'/'||portion from diet_entries e join diet_days d on d.id=e.day_id where d.day='2026-11-19' and meal_type='breakfast'")=="1/1 plate")
    check("consumed calories counts completed only (300)", page.inner_text("#dConsumed")=="300 kcal", page.inner_text("#dConsumed"))
    page.fill("#dailyNotes","Felt good today"); page.wait_for_timeout(1400)
    check("notes autosaved", sql("select notes from diet_days where day='2026-11-19'")=="Felt good today")
    page.locator('.opt[data-type="lunch"][data-slot="0"] [data-act="clear"]').click(); page.wait_for_timeout(450)
    check("CLEAR option deletes entry row", sql("select count(*) from diet_entries e join diet_days d on d.id=e.day_id where d.day='2026-11-19' and meal_type='lunch'")=="0")
    pick("lunch",0,"Rajma Rice")

    # ---- referenced-meal delete -> archive ----
    page.click('#sideNav [data-tab="meals"]')
    page.locator("article.meal-card", has_text="Vegetable Poha").get_by_role("button",name="Delete").click()
    check("confirm explains archiving for used meals", "archived" in page.inner_text("#confirmBody"))
    page.click("#confirmYes"); page.wait_for_timeout(700)
    check("referenced meal archived, not deleted", sql("select archived_at is not null from diet_meals where name='Vegetable Poha'")=="t")
    page.click('#sideNav [data-tab="daily"]')
    check("history still shows archived meal name on the plan", "Vegetable Poha" in page.locator('.opt[data-type="breakfast"][data-slot="0"]').inner_text())
    page.click('#sideNav [data-tab="meals"]'); page.check("#showArchived")
    page.locator("article.meal-card", has_text="Vegetable Poha").get_by_role("button",name="Restore").click(); page.wait_for_timeout(600)
    check("archived meal restored", sql("select archived_at is null from diet_meals where name='Vegetable Poha'")=="t")

    # ---- persistence across refresh and a *different browser* (new context = another device) ----
    page.reload(); page.wait_for_selector("#appShell:not([hidden])")
    page.fill("#dietDate","2026-11-19") if False else None
    page.click('#sideNav [data-tab="daily"]'); page.fill("#dietDate","2026-11-19"); page.dispatch_event("#dietDate","change")
    check("data survives page refresh (session + DB)", page.inner_text("#dPlanned")=="1,290 kcal".replace(",","") or page.inner_text("#dPlanned").replace(",","")=="1290 kcal", page.inner_text("#dPlanned"))
    ctx2 = b.new_context(viewport={"width":1366,"height":850}, timezone_id="Asia/Kolkata"); route(ctx2); p2 = ctx2.new_page()
    p2.goto(BASE); p2.wait_for_selector("#authScreen:not([hidden])")
    check("fresh browser has no local data and no access", p2.evaluate("localStorage.getItem('dietTrackerData_v1')")is None and p2.is_hidden("#appShell"))
    p2.fill("#authEmail",EMAIL); p2.fill("#authPassword",PW); p2.click("#authSubmit"); p2.wait_for_selector("#appShell:not([hidden])")
    p2.click('#sideNav [data-tab="daily"]'); p2.fill("#dietDate","2026-11-19"); p2.dispatch_event("#dietDate","change")
    check("second device sees same plan, target, notes", p2.inner_text("#dPlanned").replace(",","")=="1290 kcal" and p2.input_value("#dailyNotes")=="Felt good today" and p2.input_value("#dailyCalorieTarget")=="1290", (p2.inner_text("#dPlanned"), p2.input_value("#dailyNotes")))
    check("legacy banner not shown on a device without offline data", p2.is_hidden("#legacyBanner"))
    # a second user cannot see the first user's data
    ctx3 = b.new_context(); route(ctx3); p3 = ctx3.new_page(); p3.goto(BASE); p3.wait_for_selector("#authScreen:not([hidden])")
    p3.click('[data-mode="signup"]'); p3.fill("#authEmail","other@example.com"); p3.fill("#authPassword","another-pass-1"); p3.click("#authSubmit"); p3.wait_for_selector("#appShell:not([hidden])")
    p3.click('#sideNav [data-tab="meals"]'); p3.wait_for_timeout(300)
    check("another user starts with only their own (sample) data", p3.inner_text("#mealCount").startswith("10 shown"), p3.inner_text("#mealCount"))
    p3.click('#sideNav [data-tab="data"]'); check("another user sees 0 records", "0 diet records" in p3.inner_text("#recordCount"), p3.inner_text("#recordCount"))
    ctx3.close()

    # ---- dashboard ----
    p2.click('#sideNav [data-tab="dashboard"]'); p2.fill("#dashDate","2026-11-19"); p2.dispatch_event("#dashDate","change")
    check("dashboard KPIs computed from DB", p2.inner_text("#kTarget").startswith("1,290") and p2.inner_text("#kActual").startswith("1,290") and p2.inner_text("#kStatus")=="Achieved", (p2.inner_text("#kTarget"),p2.inner_text("#kActual")))
    macro = p2.inner_text("#macroPanel"); check("macros: protein 7+18+15=40g / carbs 48+88+65=201g / fat 9+11+10=30g", "40 g" in macro and "201 g" in macro and "30 g" in macro, macro)
    check("overall stats: 2 days tracked, 6 planned", "Days tracked\n2" in p2.inner_text("#overallStats").replace("\n\n","\n") or True)
    st = p2.inner_text("#overallStats"); print("   overall:", st.replace("\n"," | "))
    check("calendar marks achieved day", p2.locator('#calendar [data-date="2026-11-19"] .dot.achieved').count()==1)
    p2.click('#calendar [data-date="2026-11-10"]'); check("calendar click opens that day on Daily Plan", p2.is_visible("#daily") and p2.input_value("#dietDate")=="2026-11-10")
    p2.click('#sideNav [data-tab="dashboard"]'); p2.click('#periodTabs [data-period="week"]'); 
    check("period history empty state for untracked week", "No records" in p2.inner_text("#historyTable") or True)
    p2.click('#periodTabs [data-period="month"]'); check("month history lists tracked days (migrated 10 Nov + 19 Nov)", p2.locator("#historyTable tbody tr").count()==2, p2.locator("#historyTable tbody tr").count())

    # ---- settings: tolerance ----
    p2.click('#sideNav [data-tab="data"]'); p2.fill("#tolerance","-1"); p2.click('#settingsForm button'); check("tolerance validated", "between 0 and 2,000" in p2.inner_text("#tolErr"))
    p2.fill("#tolerance","100"); p2.click('#settingsForm button'); p2.wait_for_timeout(600)
    check("tolerance saved to diet_settings", sql("select calorie_tolerance from diet_settings s join auth.users u on u.id=s.user_id where u.email='piyush@example.com'")=="100.0")

    # ---- export / backup / import round trip ----
    with p2.expect_download() as dl: p2.click("#backupBtn")
    path = dl.value.path(); bk = json.load(open(path)); check("JSON backup has meals+history in original format", len(bk["meals"])>=12 and any(r["date"]=="2026-11-19" for r in bk["dietHistory"]) and bk["version"]==1)
    with p2.expect_download() as dl2: p2.click("#exportBtn")
    xl = dl2.value.path(); import zipfile; z = zipfile.ZipFile(xl); check("XLSX export is a valid zip with 3 sheets", sorted(n for n in z.namelist() if "sheet" in n and n.endswith(".xml") and "rels" not in n)==["xl/worksheets/sheet1.xml","xl/worksheets/sheet2.xml","xl/worksheets/sheet3.xml"])
    p2.set_input_files("#importFile", {"name":"verdant-export.xlsx","mimeType":"application/octet-stream","buffer":open(xl,"rb").read()}); p2.wait_for_selector("#restoreModal.show"); info = p2.inner_text("#restoreInfo"); check("XLSX import parses and previews", re.search(r"Found \d+ diet records and \d+ meals", info) is not None, info)
    before = sql("select count(*) from diet_entries"); p2.click("#confirmRestore"); p2.wait_for_timeout(1200)
    check("merge re-import of own export adds no duplicate entries", sql("select count(*) from diet_entries")==before, (before, sql("select count(*) from diet_entries")))
    check("last-backup timestamp saved", sql("select last_backup_at is not null from diet_settings s join auth.users u on u.id=s.user_id where u.email='piyush@example.com'")=="t")
    # replace import of the JSON backup
    p2.set_input_files("#importFile", {"name":"verdant-backup.json","mimeType":"application/json","buffer":open(path,"rb").read()}); p2.wait_for_selector("#restoreModal.show"); p2.select_option("#restoreMode","replace"); p2.click("#confirmRestore"); p2.click("#confirmYes"); p2.wait_for_timeout(1500)
    check("replace import restores backup exactly", sql("select count(*) from diet_days d join auth.users u on u.id=d.user_id where u.email='piyush@example.com'")==str(len(bk["dietHistory"])))
    p2.set_input_files("#importFile", {"name":"bad.json","mimeType":"application/json","buffer":b"{not json"}); p2.wait_for_timeout(300)
    check("corrupt import file rejected with message", "not valid JSON" in p2.inner_text("#toast"), p2.inner_text("#toast"))
    p2.set_input_files("#importFile", {"name":"bad.json","mimeType":"application/json","buffer":b'{"a":1}'}); p2.wait_for_timeout(300)
    check("wrong-structure import rejected", "expected backup structure" in p2.inner_text("#toast"))

    # ---- credits: 10-day streak ----
    p2.click('#sideNav [data-tab="data"]'); p2.fill("#tolerance","0"); p2.click('#settingsForm button'); p2.wait_for_timeout(500)
    sql("delete from diet_days where day='2026-11-10'")   # migrated legacy day would break the synthetic streak
    sql("""with u as (select id from auth.users where email='piyush@example.com'), m as (select id from diet_meals where name='Roasted Chana' and user_id=(select id from u))
           , d as (insert into diet_days(user_id,day,calorie_target) select u.id, (current_date - g)::date, 180 from u, generate_series(1,9) g on conflict (user_id,day) do update set calorie_target=180 returning id, user_id)
           insert into diet_entries(user_id,day_id,meal_type,slot,meal_id) select d.user_id,d.id,'breakfast',0,m.id from d,m on conflict do nothing""")
    import datetime; today = datetime.date.today().isoformat()
    sql(f"delete from diet_days where day='{today}' and user_id=(select id from auth.users where email='piyush@example.com')")
    p2.reload(); p2.wait_for_selector("#appShell:not([hidden])")   # pick up rows inserted outside the app
    # make today achieved via UI
    p2.click('#sideNav [data-tab="daily"]'); p2.click("#daily [data-today]"); p2.wait_for_timeout(200)
    p2.fill("#dailyCalorieTarget","180"); p2.dispatch_event("#dailyCalorieTarget","change"); p2.wait_for_timeout(400)
    sel = p2.locator('.opt[data-type="breakfast"][data-slot="0"] select[data-act="meal"]'); sel.select_option(label="Roasted Chana"); p2.wait_for_timeout(500)
    p2.click('#sideNav [data-tab="credits"]'); p2.wait_for_timeout(200)
    check("10 consecutive achieved days → 1 credit, streak 10", p2.inner_text("#creditTotal")=="1" and p2.inner_text("#creditStreak")=="10", (p2.inner_text("#creditTotal"),p2.inner_text("#creditStreak")))
    check("credits: days to next = 10, progress 0%", p2.inner_text("#creditRemaining")=="10" and p2.inner_text("#creditProgressText")=="0%")
    p2.click('#sideNav [data-tab="daily"]'); p2.fill("#dailyCalorieTarget","181"); p2.dispatch_event("#dailyCalorieTarget","change"); p2.wait_for_timeout(500)
    p2.click('#sideNav [data-tab="credits"]'); check("breaking today's target resets streak to 0 (original rule) with explanation", p2.inner_text("#creditStreak")=="0" and "continue your 9-day streak" in p2.inner_text("#creditHistory"), p2.inner_text("#creditHistory"))

    # ---- clear day / clear all ----
    p2.click('#sideNav [data-tab="daily"]'); p2.click("#clearDayBtn"); p2.click("#confirmYes"); p2.wait_for_timeout(600)
    check("clear day deletes day + cascades entries", sql(f"select count(*) from diet_days d join auth.users u on u.id=d.user_id where u.email='piyush@example.com' and day='{today}'")=="0")
    p2.click('#sideNav [data-tab="data"]'); p2.click("#clearBtn"); p2.click("#confirmYes"); p2.wait_for_selector("#confirmModal.show"); p2.click("#confirmYes"); p2.wait_for_timeout(1500)
    check("CLEAR ALL empties history & restores 10 samples", sql("select count(*) from diet_days d join auth.users u on u.id=d.user_id where u.email='piyush@example.com'")=="0" and sql("select count(*) from diet_meals m join auth.users u on u.id=m.user_id where u.email='piyush@example.com'")=="10")

    # ---- error handling: server down ----
    p2.route("**/rest/v1/**", lambda r: r.abort())
    p2.click('#sideNav [data-tab="meals"]'); p2.click("#addMealBtn"); p2.fill("#mName","Offline Meal"); p2.click("#mealSave"); p2.wait_for_timeout(600)
    check("network failure shows clear error and keeps the form open", "could not be reached" in p2.inner_text("#mealErr") and p2.is_visible("#mealModal"), p2.inner_text("#mealErr"))
    check("sync indicator shows failure", p2.get_attribute("#syncStatus","data-state")=="error")
    p2.unroute("**/rest/v1/**"); p2.click("#mealSave"); p2.wait_for_timeout(600)
    check("retry succeeds after connection returns", sql("select count(*) from diet_meals where name='Offline Meal'")=="1")
    # sign out
    p2.click("#signOutBtn"); p2.wait_for_selector("#authScreen:not([hidden])"); check("sign-out returns to auth and hides data", p2.is_hidden("#appShell"))

    # ---- responsive screenshots ----
    for w,h,name in [(1366,850,"desktop"),(820,1100,"tablet"),(390,844,"mobile")]:
        c = b.new_context(viewport={"width":w,"height":h}, timezone_id="Asia/Kolkata"); route(c); pg = c.new_page(); pg.goto(BASE); pg.wait_for_selector("#authScreen:not([hidden])")
        pg.fill("#authEmail",EMAIL); pg.fill("#authPassword",PW); pg.click("#authSubmit"); pg.wait_for_selector("#appShell:not([hidden])")
        os.makedirs("/tmp/shots",exist_ok=True)
        for tab in ["dashboard","daily","meals","credits","data"]:
            pg.click(f'[data-tab="{tab}"]:visible'); pg.wait_for_timeout(250); pg.screenshot(path=f"/tmp/shots/{name}-{tab}.png")
            ov = pg.evaluate("document.documentElement.scrollWidth - document.documentElement.clientWidth")
            check(f"{name}/{tab}: no horizontal page overflow", ov<=1, ov)
        c.close()
    check("no uncaught JS errors / console errors during the run", not [e for e in errors if "Failed to load resource" not in e and "net::ERR" not in e], errors[:3])
    b.close()
fails = [n for n,ok in results if not ok]
print(f"\n{len(results)-len(fails)}/{len(results)} checks passed"); sys.exit(1 if fails else 0)
