package com.verdant.dietplanner;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
