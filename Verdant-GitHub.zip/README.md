# Verdant: Meal Planning & Nutrition Tracker

Verdant is a web and Android app for planning daily meals and tracking calories and macronutrients.
Users build a reusable meal library, plan breakfast, lunch and dinner, and mark meals as completed.
A dashboard compares each day against a calorie target and shows progress on a calendar.
Users earn a cheat-meal credit for every 10-day streak of meeting their target.

**Download the Android app:** [`release/Verdant-v1.0.1.apk`](release/Verdant-v1.0.1.apk) (Android 6.0+)

![Dashboard](verdant/docs/screenshots/desktop-dashboard.png)

## Features

- **Daily planner:** up to 3 options each for breakfast, lunch and dinner, with completed tick, portion and notes
- **Meal library:** calories, protein, carbs, fat, serving, ingredients and prep notes; search, filter and archive
- **Dashboard:** target vs planned vs consumed calories, macro breakdown, Achieved / Under / Over status
- **History:** colour-coded calendar plus day, week and month tables
- **Credits:** one cheat-meal credit per 10 consecutive achieved days
- **Data:** JSON backup and restore (merge / replace), Excel export, cross-device sync

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | HTML, CSS, vanilla JavaScript (responsive) |
| Backend | Supabase (PostgreSQL, Auth, Row-Level Security) |
| Android | Capacitor 7, signed release APK |

## Project structure

```
verdant/                  Web app (index.html, css/, js/)
  supabase/migrations/    Database schema, RLS policies and functions
  supabase/tests/         Database tests
  tests/                  Unit and end-to-end tests
  docs/screenshots/       Screenshots
android-app/              Capacitor wrapper that builds the Android APK
release/                  Ready-to-install APK
```

## Setup

1. Create a Supabase project, then run `verdant/supabase/migrations/001_verdant_schema.sql` in the SQL Editor.
2. Put the **Project URL** and **anon / publishable key** in `verdant/js/config.js`.
3. **Web:** open `verdant/index.html` through any static web server.
4. **Android:** follow [`android-app/README.md`](android-app/README.md) (`npm install`, then `npm run build:apk`).

## Installing the APK

1. Copy `release/Verdant-v1.0.1.apk` to your phone and tap it.
2. Allow **Install unknown apps** for that source when asked.
3. Tap **Install**, open Verdant and create an account.

## Security

- Row-Level Security: each user can read and change only their own rows, and anonymous access is blocked.
- Database functions run as `SECURITY INVOKER` with a fixed `search_path`.
- All user text is HTML-escaped before display to prevent script injection.
- Only the public publishable key is used, and the app refuses to start with a secret / service-role key.
- Android: HTTPS only, minimal permissions, and app data excluded from device backups.

> The Supabase URL and publishable key in `config.js` are public by design; data is protected by RLS.
> Never commit a `service_role` / secret key or the APK signing keystore.
