/* Verdant — dependency-free XLSX export and import of the app's own export.
 * Ported from the original app. Fixes: the parser is now awaited correctly
 * (the original never awaited it, so XLSX restore always failed), and
 * portions written as "Meal (portion)" are read back instead of dropped.
 * New columns are appended at the end so older exports still import.
 */
(function () {
  "use strict";
  const { MEAL_TYPES, countMeals, countCompleted, totals, calorieStatus } = window.Calc;
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const xmlEsc = (s) => esc(s).replace(/\n/g, "&#10;");
  function col(n) { let s = ""; n++; while (n) { const r = (n - 1) % 26; s = String.fromCharCode(65 + r) + s; n = Math.floor((n - 1) / 26); } return s; }
  function sheetXML(rows) {
    return `<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>${rows.map((r, i) =>
      `<row r="${i + 1}">${r.map((v, j) => {
        const ref = `${col(j)}${i + 1}`;
        return typeof v === "number" && Number.isFinite(v) ? `<c r="${ref}"><v>${v}</v></c>` : `<c r="${ref}" t="inlineStr"><is><t>${xmlEsc(v)}</t></is></c>`;
      }).join("")}</row>`).join("")}</sheetData></worksheet>`;
  }

  function build(store) {
    const byId = store.mealsById, tol = store.settings.calorie_tolerance;
    const name = (id) => (byId.get(id) || {}).name || "Deleted meal";
    const hist = [["Date", "Breakfast", "Lunch", "Dinner", "Meals Planned", "Meals Completed", "Completion %", "Target Calories", "Actual Calories", "Calorie Status", "Notes", "Protein (g)", "Carbohydrates (g)", "Fat (g)", "Completed Calories"]];
    [...store.days.values()].sort((a, b) => a.day.localeCompare(b.day)).forEach((d) => {
      const p = countMeals(d), c = countCompleted(d), t = totals(d, byId), done = totals(d, byId, { completedOnly: true });
      hist.push([d.day, ...MEAL_TYPES.map((k) => d.entries[k].filter(Boolean).map((e) => name(e.meal_id) + (e.portion ? ` (${e.portion})` : "") + (e.completed ? " ✓" : "")).join(" | ")),
        p, c, p ? Math.round((c / p) * 100) + "%" : "0%", d.calorie_target ?? "", t.calories, calorieStatus(d, byId, tol).status, d.notes || "", t.protein, t.carbs, t.fat, done.calories]);
    });
    const meals = [["ID", "Meal Name", "Category", "Description", "Ingredients", "Calories", "Protein (g)", "Carbohydrates (g)", "Fat (g)", "Serving Size", "Preparation Notes", "Tags", "Archived"]];
    store.meals.forEach((m) => meals.push([m.id, m.name, m.category, m.description || "", m.ingredients || "", m.calories ?? "", m.protein ?? "", m.carbs ?? "", m.fat ?? "", m.serving || "", m.prep || "", m.tags || "", m.archived_at ? "Yes" : ""]));
    const all = [...store.days.values()];
    const summary = [["Metric", "Value"], ["Diet records", all.length], ["Meals in database", store.meals.filter((m) => !m.archived_at).length],
      ["Archived meals", store.meals.filter((m) => m.archived_at).length], ["Days with meal data", all.filter((d) => countMeals(d) > 0).length],
      ["Total meals planned", all.reduce((n, d) => n + countMeals(d), 0)], ["Total meals completed", all.reduce((n, d) => n + countCompleted(d), 0)],
      ["Calorie tolerance (kcal)", tol], ["Exported", new Date().toLocaleString()]];
    const ct = "application/vnd.openxmlformats-officedocument.spreadsheetml";
    const files = {
      "[Content_Types].xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="${ct}.sheet.main+xml"/>${[1, 2, 3].map((i) => `<Override PartName="/xl/worksheets/sheet${i}.xml" ContentType="${ct}.worksheet+xml"/>`).join("")}</Types>`,
      "_rels/.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`,
      "xl/workbook.xml": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Diet History" sheetId="1" r:id="rId1"/><sheet name="Meal Database" sheetId="2" r:id="rId2"/><sheet name="Daily Summary" sheetId="3" r:id="rId3"/></sheets></workbook>`,
      "xl/_rels/workbook.xml.rels": `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${[1, 2, 3].map((i) => `<Relationship Id="rId${i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i}.xml"/>`).join("")}</Relationships>`,
      "xl/worksheets/sheet1.xml": sheetXML(hist), "xl/worksheets/sheet2.xml": sheetXML(meals), "xl/worksheets/sheet3.xml": sheetXML(summary),
    };
    return zipStore(files);
  }

  function crc32(bytes) {
    let t = crc32.t;
    if (!t) { t = crc32.t = []; for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } }
    let c = 0xffffffff; for (const b of bytes) c = t[(c ^ b) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0;
  }
  const u16 = (n) => new Uint8Array([n & 255, (n >>> 8) & 255]);
  const u32 = (n) => new Uint8Array([n & 255, (n >>> 8) & 255, (n >>> 16) & 255, (n >>> 24) & 255]);
  function cat(a) { const out = new Uint8Array(a.reduce((n, x) => n + x.length, 0)); let p = 0; a.forEach((x) => { out.set(x, p); p += x.length; }); return out; }
  function zipStore(files) {
    const enc = new TextEncoder(), locals = [], centrals = []; let offset = 0;
    for (const [name, text] of Object.entries(files)) {
      const nb = enc.encode(name), db = enc.encode(text), crc = crc32(db);
      const lh = cat([new Uint8Array([80, 75, 3, 4]), u16(20), u16(0x0800), u16(0), u16(0), u16(0), u32(crc), u32(db.length), u32(db.length), u16(nb.length), u16(0), nb, db]);
      locals.push(lh);
      centrals.push(cat([new Uint8Array([80, 75, 1, 2]), u16(20), u16(20), u16(0x0800), u16(0), u16(0), u16(0), u32(crc), u32(db.length), u32(db.length), u16(nb.length), u16(0), u16(0), u16(0), u16(0), u32(0), u32(offset), nb]));
      offset += lh.length;
    }
    const cd = cat(centrals), body = cat(locals);
    return cat([body, cd, cat([new Uint8Array([80, 75, 5, 6]), u16(0), u16(0), u16(centrals.length), u16(centrals.length), u32(cd.length), u32(body.length), u16(0)])]);
  }

  // Parses an uncompressed XLSX written by this app (or the original app) into the
  // version-1 backup JSON shape accepted by diet_import_backup().
  async function parse(buf) {
    const bytes = new Uint8Array(buf), dec = new TextDecoder(), entries = {};
    const r16 = (i) => bytes[i] | (bytes[i + 1] << 8), r32 = (i) => (bytes[i] | (bytes[i + 1] << 8) | (bytes[i + 2] << 16) | (bytes[i + 3] << 24)) >>> 0;
    let p = 0;
    while (p < bytes.length - 4 && r32(p) === 0x04034b50) {
      const method = r16(p + 8), cs = r32(p + 18), nl = r16(p + 26), xl = r16(p + 28), name = dec.decode(bytes.slice(p + 30, p + 30 + nl)), st = p + 30 + nl + xl;
      if (method !== 0) throw new Error("This XLSX is compressed (it was re-saved in Excel). Import an XLSX exported by this app, or use a JSON backup.");
      entries[name] = dec.decode(bytes.slice(st, st + cs)); p = st + cs;
    }
    if (!entries["xl/worksheets/sheet1.xml"] || !entries["xl/worksheets/sheet2.xml"]) throw new Error("This is not an export from this app.");
    const unesc = (s) => { const ta = document.createElement("textarea"); ta.innerHTML = s; return ta.value; };
    const rows = (name) => {
      const out = [];
      for (const rm of entries[name].matchAll(/<row[^>]*>([\s\S]*?)<\/row>/g)) {
        const cells = [];
        for (const cm of rm[1].matchAll(/<c([^>]*)>([\s\S]*?)<\/c>/g)) {
          const ref = (cm[1].match(/r="([A-Z]+)\d+"/) || [])[1];
          const idx = ref ? ref.split("").reduce((n, ch) => n * 26 + ch.charCodeAt(0) - 64, 0) - 1 : cells.length;
          const tm = cm[2].match(/<t[^>]*>([\s\S]*?)<\/t>/) || cm[2].match(/<v>([\s\S]*?)<\/v>/);
          cells[idx] = tm ? unesc(tm[1]) : "";
        }
        out.push(Array.from(cells, (c) => c ?? ""));
      }
      return out;
    };
    const h = rows("xl/worksheets/sheet1.xml"), m = rows("xl/worksheets/sheet2.xml");
    const numOrNull = (v) => (v === "" || v == null ? null : Number(v));
    const meals = m.slice(1).filter((r) => r[0] && r[1]).map((r) => ({ id: r[0], name: r[1], category: r[2] || "Other", description: r[3] || "", ingredients: r[4] || "",
      calories: numOrNull(r[5]), protein: numOrNull(r[6]), carbs: numOrNull(r[7]), fat: numOrNull(r[8]), serving: r[9] || "", prep: r[10] || "", tags: r[11] || "", archived: r[12] === "Yes" }));
    const byName = new Map(); meals.forEach((x) => { if (!byName.has(x.name) || !x.archived) byName.set(x.name, x.id); });
    const dietHistory = [];
    h.slice(1).forEach((r) => {
      if (!r[0]) return;
      const rec = { date: r[0], breakfast: [], lunch: [], dinner: [], notes: r[10] || "", calorieTarget: numOrNull(r[7]) };
      MEAL_TYPES.forEach((k, i) => {
        (r[i + 1] || "").split(" | ").filter(Boolean).forEach((label) => {
          const completed = / ✓$/.test(label);
          let clean = label.replace(/ ✓$/, ""), portion = "";
          const pm = clean.match(/^(.*) \(([^()]*)\)$/);
          if (pm && !byName.has(clean)) { clean = pm[1]; portion = pm[2]; }
          rec[k].push({ mealId: byName.get(clean) || "missing-" + clean, completed, portion });
        });
      });
      dietHistory.push(rec);
    });
    return { version: 1, meals, dietHistory, settings: {}, metadata: { importedAt: new Date().toISOString() } };
  }

  window.Xlsx = { build, parse };
})();
