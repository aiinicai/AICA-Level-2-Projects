#!/usr/bin/env bash
# Resets the local test database + mock auth, then runs the browser suite.
set -e
pkill -f mock-supabase.js 2>/dev/null || true
psql -h /tmp -p 54329 -U postgres -d t1 -qc "truncate auth.users cascade"
(cd "$(dirname "$0")/.." && nohup node tests/mock-supabase.js >/tmp/mock.log 2>&1 &)
sleep 1.5
python3 "$(dirname "$0")/e2e.py"
