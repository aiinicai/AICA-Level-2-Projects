# Verdant — Meal Planning & Nutrition

Verdant is the redesigned, Supabase‑powered version of your offline *Diet Tracker & Planner*.
It keeps the original features and calculation rules, but every record now lives in a **Supabase
PostgreSQL database** behind **sign‑in and Row Level Security**, so your data persists across
refreshes, browsers and devices.

It is still a plain HTML/CSS/JavaScript app (no build step, no framework). The only runtime
dependency is the official `@supabase/supabase-js` client, loaded from a CDN.

```
verdant/
├── index.html                      App shell, all screens and dialogs
├── css/styles.css                  Design system (forest / sage / off-white / charcoal)
├── js/
│   ├── config.js                   ← YOU EDIT THIS: Supabase URL + anon key
│   ├── calc.js                     Pure calculation rules (calories, status, credits, periods)
│   ├── store.js                    Supabase data layer (all reads/writes, error handling)
│   ├── xlsx.js                     Excel export / import (dependency-free)
│   └── app.js                      UI controller, auth, offline-data migration
├── supabase/
│   ├── migrations/001_verdant_schema.sql   Tables, constraints, indexes, RLS, RPCs
│   └── tests/db_tests.sql                  Database test suite (12 groups)
├── tests/                          Unit, E2E and local-stack harness (see TESTING_REPORT.md)
└── docs/screenshots/
```

---

## 1. Connect to your Supabase project (≈10 minutes)

These steps need **your** Supabase login. I could not do them for you.

### Step 1 — Run the migration
1. Open your project at <https://supabase.com/dashboard> → **SQL Editor** → **New query**.
2. Paste the entire contents of `supabase/migrations/001_verdant_schema.sql` and click **Run**.
3. Expected result: *Success. No rows returned.* Then **Table Editor** shows four new tables:
   `diet_settings`, `diet_meals`, `diet_days`, `diet_entries`.

All objects are prefixed `diet_`, so the migration is safe to add to a project that already holds
other tables. It makes **no changes** to existing tables. Run it **once**; re-running it will fail
with "already exists" (it does not use `if not exists`, so you never silently get a stale schema).

### Step 2 — Copy your API values
**Project Settings → API** (or **Connect**):
- **Project URL** — `https://<ref>.supabase.co`
- **anon / public key** (long `eyJ…` string) **or** a **publishable key** (`sb_publishable_…`)

> ⚠️ Use only the **anon/publishable** key. **Never** paste the `service_role` or `sb_secret_…`
> key anywhere in this app. It bypasses all security. If one is pasted into `config.js`, the app
> refuses to start and tells you to rotate it.

### Step 3 — Edit `js/config.js`
```js
window.VERDANT_CONFIG = {
  SUPABASE_URL: "https://abcdefghijkl.supabase.co",
  SUPABASE_ANON_KEY: "eyJ...your anon key...",
};
```
The anon key is *designed* to be public; RLS (below) is what protects your data.

### Step 4 — Configure authentication
**Authentication → Providers → Email** must be enabled (it is by default).

| Setting | Where | Recommendation |
|---|---|---|
| Confirm email | Auth → Providers → Email | **On** for production. If on, new users get a confirmation email before they can sign in. For quick personal testing you may turn it off. |
| Site URL | Auth → URL Configuration | The address you serve the app from (e.g. `http://localhost:8080` or your hosting URL). |
| Redirect URLs | Auth → URL Configuration | Add the same address (and `http://localhost:8080` while developing) so confirmation and password‑reset links return to the app. |
| Built‑in email limits | Auth → Rate limits | Supabase's default mailer is rate‑limited; add your own SMTP for real use. |

### Step 5 — Serve and open the app
`supabase-js` needs `http(s)://`, so opening `index.html` by double‑click (`file://`) will not work
for email links. Use any static server:

```bash
cd verdant
python3 -m http.server 8080        # then open http://localhost:8080
# or:  npx serve .
```

To publish it, upload the folder to any static host (Netlify, Vercel, Cloudflare Pages, GitHub
Pages, S3…). Add that URL to Supabase **Redirect URLs**.

### Step 6 — Create your account and migrate old data
1. Choose **Create account**, sign up, confirm the email if required, sign in.
2. **If you used the original offline app in the same browser**, Verdant detects its saved data
   (`localStorage` key `dietTrackerData_v1`) and shows an **Import my data** banner. Click it:
   your meals and diet history are copied into your account. The browser copy is **left untouched**.
   If you dismiss the banner, the option stays under **Data & Settings**.
3. If your old data is on another computer/browser: in the old app click **Save History** to get a
   JSON file, then in Verdant go to **Data & Settings → Import / Restore** and choose it.
   (The old app's own `.xlsx` export is also accepted if it is the uncompressed one the app wrote.)

First sign‑in on an account with no offline data seeds the 10 sample meals once.

---

## 2. How the data is stored

| Table | Holds | Key points |
|---|---|---|
| `diet_settings` | one row per user | calorie tolerance, last backup time |
| `diet_meals` | the meal library | name/category/nutrition validated by `CHECK`s; `archived_at` instead of deleting meals that history uses |
| `diet_days` | one row per user per date | calorie target, notes; `UNIQUE(user_id, day)` |
| `diet_entries` | up to 3 options × breakfast/lunch/dinner per day | `UNIQUE(day_id, meal_type, slot)`, `slot 0‑2`, completed flag, portion |

Relationships: `diet_entries → diet_days` (cascade) and `diet_entries → diet_meals`. Both use
**composite foreign keys including `user_id`**, so a row can never point at another user's day or
meal even if its UUID were known. Deleting an auth user cascades through everything.

**Totals are never stored.** Calories, macros, daily status, streaks and credits are calculated on
the fly from the selected meals' nutrition, so they can't drift out of sync with the data.

**Security**
- RLS is enabled on all four tables; four policies each (select / insert / update / delete) limited
  to `user_id = auth.uid()`. `anon` has no table or function privileges at all.
- All functions are `SECURITY INVOKER` (they run under the caller's RLS) with a fixed
  `search_path`. No `SECURITY DEFINER`, no service key anywhere.
- Multi‑row operations (bootstrap, import, clear‑all) are Postgres functions, so each is **one
  transaction**: a failed import changes nothing.

---

## 3. What changed from the original app

**Preserved:** Dashboard with calendar and Month/Week/Day history; Daily Diet with 3 options per
meal, completed ticks, portions, notes and calorie target; Meal Library with search/filter/add/edit/
duplicate/delete; Credits (1 cheat‑meal credit per 10 straight achieved days); JSON backup, Excel
export, Import/Restore with Merge/Replace; Clear All; the "Planned calories" rule (every selected
option counts) and exact‑match "Achieved" rule.

**Added:** sign‑in, Supabase persistence + multi‑device sync, macro bars & energy split, consumed
(completed‑only) calories, per‑day status colours on the calendar, 30‑day streak strip, sync status
indicator, optional calorie tolerance (default 0 = original behaviour), archived meals.

**Bugs fixed in the original logic** (behaviour you may notice):
1. **Dates were off by one in IST** — the original used `toISOString()` (UTC), so around midnight
   and in time zones ahead of UTC a day could land on the wrong date. All dates are now local.
2. **Excel import never worked** — the parser was `async` but not awaited. Fixed; portions are now
   also read back.
3. **Deleting a meal left history pointing at "Deleted meal"** and lost its nutrition (so a past
   day's calories silently changed). Meals used in history are now *archived*; history keeps its values.
4. **"Days to next credit"** showed 0 at the start of a streak; it now shows 10.
5. Floating‑point sums (0.1 + 0.2) are rounded to 1 decimal.

**Rule kept as‑is, worth knowing:** the credits streak counts back from **today**. If today isn't
achieved yet the streak shows 0 until it is. Verdant now says so on the Credits page rather than
silently dropping you to zero.

---

## 4. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| "Connect your database" screen | `js/config.js` is empty. Fill both values and reload. |
| "database tables were not found" | Step 1 not run (or run in a different project). |
| Sign‑up works but you can't sign in | Email confirmation is on: click the link in the email. |
| Confirmation link opens the wrong page | Add your app URL to **Redirect URLs** (Step 4). |
| "permission denied … sign in again" | Session expired. Sign in again. |
| Red "Not saved" badge | Network/server error; hover for details. The change was **not** saved. Retry the action. |
| "Invalid API key" | Wrong/typo'd key, or key from another project. |
| Edits don't appear on another device | The app refreshes when the tab regains focus (if >30 s since last load); otherwise reload. |

---

## 5. Running the tests
See `TESTING_REPORT.md`. In short:
`node tests/calc.test.js` (no setup), `psql -f supabase/tests/db_tests.sql` (needs a database with
the migration; the local harness in `tests/` emulates Supabase's `auth` schema), and
`tests/run-e2e.sh` (Chrome + Playwright against a local PostgREST).
