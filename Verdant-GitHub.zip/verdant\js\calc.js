/* Verdant — pure calculation helpers (no DOM, no network).
 * Mirrors the original app's business rules:
 *   • "Actual/Planned calories" = sum of calories of every meal option selected for the day
 *   • Status: Achieved / Under-achieved / Over-achieved vs the day's target
 *     (exact match as before; an optional tolerance in Settings defaults to 0)
 *   • Credits: 1 cheat-meal credit per 10 consecutive achieved days ending today
 * All dates are LOCAL calendar dates in YYYY-MM-DD form.
 */
(function (root) {
  "use strict";
  const MEAL_TYPES = ["breakfast", "lunch", "dinner"];
  const CATEGORIES = ["Breakfast", "Lunch", "Dinner", "Snack", "Other", "Any"];
  const r1 = (x) => Math.round((Number(x) || 0) * 10) / 10;
  const pad = (n) => String(n).padStart(2, "0");

  // ---- local-date helpers (the original used toISOString(), which is UTC and
  //      shifted dates by one day in time zones ahead of UTC such as IST) ----
  function isoLocal(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
  function parseISO(s) { const [y, m, d] = String(s).split("-").map(Number); return new Date(y, m - 1, d); }
  function addDays(s, n) { const d = parseISO(s); d.setDate(d.getDate() + n); return isoLocal(d); }
  function todayISO() { return isoLocal(new Date()); }
  function isValidISO(s) { if (!/^\d{4}-\d{2}-\d{2}$/.test(String(s))) return false; return isoLocal(parseISO(s)) === s; }

  // ---- per-day helpers. day = { calorie_target, notes, entries:{breakfast:[e|null,…],…} } ----
  function entriesOf(day, type) {
    if (!day || !day.entries) return [];
    const types = type ? [type] : MEAL_TYPES;
    return types.flatMap((t) => (day.entries[t] || []).filter((e) => e && e.meal_id));
  }
  const countMeals = (day) => entriesOf(day).length;
  const countCompleted = (day) => entriesOf(day).filter((e) => e.completed).length;
  const isTracked = (day) => !!day && (countMeals(day) > 0 || !!(day.notes && day.notes.trim()));

  function totals(day, mealsById, opts) {
    const onlyCompleted = !!(opts && opts.completedOnly);
    const type = opts && opts.type;
    const t = { calories: 0, protein: 0, carbs: 0, fat: 0 };
    for (const e of entriesOf(day, type)) {
      if (onlyCompleted && !e.completed) continue;
      const m = mealsById.get(e.meal_id);
      if (!m) continue;
      t.calories += Number(m.calories) || 0;
      t.protein += Number(m.protein) || 0;
      t.carbs += Number(m.carbs) || 0;
      t.fat += Number(m.fat) || 0;
    }
    return { calories: r1(t.calories), protein: r1(t.protein), carbs: r1(t.carbs), fat: r1(t.fat) };
  }
  const actualCalories = (day, mealsById) => totals(day, mealsById).calories;

  function calorieStatus(day, mealsById, tolerance) {
    const tol = Math.max(0, Number(tolerance) || 0);
    const target = Number(day && day.calorie_target);
    const actual = actualCalories(day, mealsById);
    if (!Number.isFinite(target) || target <= 0) return { status: "—", variance: null, target: null, actual };
    const variance = r1(actual - target);
    const status = Math.abs(variance) <= tol ? "Achieved" : variance < 0 ? "Under-achieved" : "Over-achieved";
    return { status, variance, target, actual };
  }
  const achieved = (day, mealsById, tol) => calorieStatus(day, mealsById, tol).status === "Achieved";

  // Energy split of macros (protein & carbs 4 kcal/g, fat 9 kcal/g)
  function macroEnergy(t) {
    const p = (Number(t.protein) || 0) * 4, c = (Number(t.carbs) || 0) * 4, f = (Number(t.fat) || 0) * 9;
    const sum = p + c + f;
    if (!sum) return { protein: 0, carbs: 0, fat: 0, kcal: 0 };
    const pp = Math.round((p / sum) * 100), cp = Math.round((c / sum) * 100);
    return { protein: pp, carbs: cp, fat: Math.max(0, 100 - pp - cp), kcal: Math.round(sum) };
  }

  // ---- credits ----
  function creditStats(daysByDate, mealsById, tolerance, today) {
    let streak = 0, d = today || todayISO();
    while (achieved(daysByDate.get(d), mealsById, tolerance)) { streak++; d = addDays(d, -1); }
    const credits = Math.floor(streak / 10);
    const intoCycle = streak % 10;
    const milestones = [];
    for (let i = 10; i <= streak; i += 10) milestones.push({ days: i, endDate: addDays(today || todayISO(), -(streak - i)) });
    return {
      streak, credits,
      remaining: 10 - intoCycle,           // original showed 0 here when the streak was 0
      progressPct: intoCycle * 10,
      streakStart: streak ? addDays(today || todayISO(), -(streak - 1)) : null,
      milestones,
    };
  }

  // ---- periods / overall ----
  function periodDates(period, anchor) {
    if (period === "day") return [anchor];
    const d = parseISO(anchor);
    if (period === "week") {
      const start = addDays(anchor, -((d.getDay() + 6) % 7));
      return Array.from({ length: 7 }, (_, i) => addDays(start, i));
    }
    const y = d.getFullYear(), m = d.getMonth(), n = new Date(y, m + 1, 0).getDate();
    return Array.from({ length: n }, (_, i) => `${y}-${pad(m + 1)}-${pad(i + 1)}`);
  }

  function overallStats(daysByDate) {
    let tracked = 0, planned = 0, completed = 0;
    for (const day of daysByDate.values()) {
      if (isTracked(day)) tracked++;
      planned += countMeals(day);
      completed += countCompleted(day);
    }
    return { daysTracked: tracked, planned, completed, consistency: planned ? Math.round((completed / planned) * 100) : 0 };
  }

  // Meals offered in a slot: same category, or Any / Snack / Other (unchanged rule)
  function mealsForType(type, meals) {
    const cat = type[0].toUpperCase() + type.slice(1);
    return meals.filter((m) => !m.archived_at && (m.category === cat || m.category === "Any" || m.category === "Snack" || m.category === "Other"));
  }

  const api = { MEAL_TYPES, CATEGORIES, r1, isoLocal, parseISO, addDays, todayISO, isValidISO, entriesOf, countMeals,
    countCompleted, isTracked, totals, actualCalories, calorieStatus, achieved, macroEnergy, creditStats, periodDates,
    overallStats, mealsForType };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  root.Calc = api;
})(typeof window !== "undefined" ? window : globalThis);
