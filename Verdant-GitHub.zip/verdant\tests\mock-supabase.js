// LOCAL TEST HARNESS ONLY. Emulates the parts of Supabase Auth (GoTrue) that the app uses and
// proxies /rest/v1/* to PostgREST, so the real frontend + real supabase-js can run offline.
// Usage: PG=... node tests/mock-supabase.js   (needs jsonwebtoken, pg; installed in /tmp/pg)
const http = require("http"), crypto = require("crypto"), path = require("path");
const mod = (n) => require(path.join(process.env.NODE_PATH_EXTRA || "/tmp/pg/node_modules", n));
const jwt = mod("jsonwebtoken"), { Client } = mod("pg");
const SECRET = "test-secret-test-secret-test-secret-0123456789", PORT = +process.env.PORT || 54321, REST = "http://localhost:3001";
const db = new Client({ host: "/tmp", port: 54329, user: "postgres", database: "t1" });
const users = new Map(); // email -> {id,email,password}
const mint = (u) => {
  const now = Math.floor(Date.now() / 1000), exp = now + 3600;
  const access_token = jwt.sign({ aud: "authenticated", role: "authenticated", sub: u.id, email: u.email, exp, iat: now }, SECRET);
  return { access_token, token_type: "bearer", expires_in: 3600, expires_at: exp, refresh_token: "r-" + u.id,
    user: { id: u.id, aud: "authenticated", role: "authenticated", email: u.email, app_metadata: {}, user_metadata: {}, created_at: new Date().toISOString() } };
};
const send = (res, code, body, extra) => { res.writeHead(code, { "content-type": "application/json", "access-control-allow-origin": "*", "access-control-allow-headers": "*", "access-control-allow-methods": "*", "access-control-expose-headers": "*", ...(extra || {}) }); res.end(JSON.stringify(body)); };
http.createServer(async (req, res) => {
  if (req.method === "OPTIONS") return send(res, 204, {});
  const url = new URL(req.url, "http://x");
  const chunks = []; for await (const c of req) chunks.push(c); const raw = Buffer.concat(chunks);
  if (url.pathname.startsWith("/rest/v1/")) {
    const headers = { ...req.headers }; delete headers.host; delete headers["content-length"];
    delete headers.apikey; // supabase's gateway consumes apikey; PostgREST only needs the bearer
    if (headers.authorization && !/Bearer ey/.test(headers.authorization)) delete headers.authorization;
    const r = await fetch(REST + url.pathname.replace("/rest/v1", "") + url.search, { method: req.method, headers, body: ["GET", "HEAD"].includes(req.method) ? undefined : raw });
    const buf = Buffer.from(await r.arrayBuffer()); const h = Object.fromEntries(r.headers); delete h["content-encoding"]; delete h["transfer-encoding"];
    res.writeHead(r.status, { ...h, "access-control-allow-origin": "*", "access-control-expose-headers": "*" }); return res.end(buf);
  }
  const body = raw.length ? JSON.parse(raw) : {};
  if (url.pathname === "/auth/v1/signup") {
    const email = body.email.toLowerCase(); if (users.has(email)) return send(res, 422, { code: 422, error_code: "user_already_exists", msg: "User already registered" });
    const u = { id: crypto.randomUUID(), email, password: body.password }; users.set(email, u);
    await db.query("insert into auth.users(id,email) values($1,$2)", [u.id, email]);
    return send(res, 200, mint(u));
  }
  if (url.pathname === "/auth/v1/token") {
    if (url.searchParams.get("grant_type") === "refresh_token") { const u = [...users.values()].find((x) => "r-" + x.id === body.refresh_token); return u ? send(res, 200, mint(u)) : send(res, 400, { error_description: "Invalid refresh token" }); }
    const u = users.get(String(body.email).toLowerCase());
    if (!u || u.password !== body.password) return send(res, 400, { code: 400, error_code: "invalid_credentials", msg: "Invalid login credentials" });
    return send(res, 200, mint(u));
  }
  if (url.pathname === "/auth/v1/user") { const t = (req.headers.authorization || "").slice(7); try { const p = jwt.verify(t, SECRET); return send(res, 200, mint(users.get(p.email)).user); } catch { return send(res, 401, { msg: "invalid" }); } }
  if (url.pathname === "/auth/v1/logout") return send(res, 204, {});
  send(res, 404, { msg: "not found " + url.pathname });
}).listen(PORT, async () => { await db.connect(); console.log("mock supabase on", PORT); });
