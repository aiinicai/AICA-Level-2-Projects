/* Verdant — UI controller. All data operations go through window.Store (Supabase). */
(function () {
  "use strict";
  const C = window.Calc, S = window.Store;
  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const LEGACY_KEY = "dietTrackerData_v1";
  const TYPE_LABEL = { breakfast: "Breakfast", lunch: "Lunch", dinner: "Dinner" };
  const PAGE_TITLE = { dashboard: "Dashboard", daily: "Daily Plan", meals: "Meal Library", credits: "Credits", data: "Data & Settings", help: "How to Use" };

  const state = { tab: "dashboard", date: C.todayISO(), cal: monthOf(C.todayISO()), period: "month", pendingImport: null, authMode: "signin", entering: false, inApp: false, legacy: null };
  function monthOf(iso) { const d = C.parseISO(iso); return new Date(d.getFullYear(), d.getMonth(), 1); }

  // ---------- formatting ----------
  const nf = new Intl.NumberFormat(undefined, { maximumFractionDigits: 1 });
  const kcal = (n) => `${nf.format(Number(n) || 0)} kcal`;
  const grams = (n) => (n == null ? "—" : `${nf.format(n)} g`);
  const fmtDate = (iso) => C.parseISO(iso).toLocaleDateString(undefined, { day: "2-digit", month: "short", year: "numeric" });
  const fmtLong = (iso) => C.parseISO(iso).toLocaleDateString(undefined, { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  const statusCls = (s) => (s === "Achieved" ? "achieved" : s === "Under-achieved" ? "under" : s === "Over-achieved" ? "over" : "");
  const tol = () => S.settings.calorie_tolerance;
  const varianceText = (cs) => cs.variance == null ? "set a target to compare"
    : cs.status === "Achieved" ? (cs.variance === 0 ? "target matched exactly" : `within ±${nf.format(tol())} kcal (${cs.variance > 0 ? "+" : ""}${nf.format(cs.variance)})`)
    : `${nf.format(Math.abs(cs.variance))} kcal ${cs.variance < 0 ? "below" : "above"} target`;

  // ---------- toast / modal / confirm ----------
  function toast(msg, kind) {
    const t = $("toast"); t.textContent = msg; t.className = "toast show" + (kind === "error" ? " error" : "");
    clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove("show"), kind === "error" ? 6500 : 3200);
  }
  function openModal(id) { $(id).classList.add("show"); const f = $(id).querySelector("input:not([type=hidden]),select,button.primary"); if (f) setTimeout(() => f.focus(), 30); }
  function closeModal(id) { $(id).classList.remove("show"); if (id === "restoreModal") state.pendingImport = null; }
  document.addEventListener("click", (e) => {
    const c = e.target.closest("[data-close]"); if (c) closeModal(c.closest(".modal").id);
    if (e.target.classList && e.target.classList.contains("modal") && e.target.id !== "pwModal" && e.target.id !== "confirmModal") closeModal(e.target.id);
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") document.querySelectorAll(".modal.show").forEach((m) => { if (m.id === "confirmModal") $("confirmNo").click(); else if (m.id !== "pwModal") closeModal(m.id); }); });
  function confirmDialog({ title, body, ok = "Confirm", danger = false }) {
    return new Promise((resolve) => {
      $("confirmTitle").textContent = title; $("confirmBody").innerHTML = body;
      const yes = $("confirmYes"); yes.textContent = ok; yes.className = "btn " + (danger ? "danger" : "primary");
      const done = (v) => { $("confirmModal").classList.remove("show"); yes.onclick = $("confirmNo").onclick = null; resolve(v); };
      yes.onclick = () => done(true); $("confirmNo").onclick = () => done(false);
      $("confirmModal").classList.add("show"); setTimeout(() => $("confirmNo").focus(), 30);
    });
  }
  async function busy(btn, fn) { if (btn) btn.classList.add("busy"); try { return await fn(); } finally { if (btn) btn.classList.remove("busy"); } }
  // Inside the Android app (Capacitor) a blob <a download> does nothing, so the file is
  // written to the app's Documents folder and handed to the Android share sheet instead.
  const nativeApp = () => !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  async function nativeSave(blob, name) {
    const { Filesystem, Share } = window.Capacitor.Plugins;
    const b64 = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(",")[1]); r.onerror = rej; r.readAsDataURL(blob); });
    let uri;
    try { ({ uri } = await Filesystem.writeFile({ path: name, data: b64, directory: "DOCUMENTS", recursive: true })); }
    catch { ({ uri } = await Filesystem.writeFile({ path: name, data: b64, directory: "CACHE", recursive: true })); }
    try { await Share.share({ title: name, files: [uri], dialogTitle: "Save or share " + name }); }
    catch (e) { if (!/cancel/i.test(e && e.message || "")) toast("Saved to Documents/" + name); }
  }
  function download(blob, name) {
    if (nativeApp()) { nativeSave(blob, name).catch((e) => toast("Could not save file: " + (e && e.message || e))); return; }
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = name; document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000); }
  function stamp() { const d = new Date(), p = (n) => String(n).padStart(2, "0"); return `${C.isoLocal(d)}-${p(d.getHours())}${p(d.getMinutes())}`; }

  // ---------- screens ----------
  function screen(name) {
    $("bootScreen").hidden = name !== "boot"; $("setupScreen").hidden = name !== "setup";
    $("authScreen").hidden = name !== "auth"; $("appShell").hidden = name !== "app";
  }
  S.onStatus = (st, msg) => {
    const el = $("syncStatus"); el.dataset.state = st; el.title = msg || "";
    $("syncText").textContent = st === "saving" ? "Saving…" : st === "loading" ? "Syncing…" : st === "error" ? "Not saved" : "All changes saved";
  };

  // ---------- boot ----------
  async function boot() {
    const cfg = window.VERDANT_CONFIG || {};
    if (!window.supabase || !window.supabase.createClient) { setupError("The Supabase client library could not be loaded. Check your internet connection and reload."); return; }
    if (!cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) { screen("setup"); return; }
    if (isSecretKey(cfg.SUPABASE_ANON_KEY)) { setupError("js/config.js contains a service-role / secret key. Remove it immediately, rotate it in Supabase, and use the anon (publishable) key instead."); return; }
    try { S.init(cfg.SUPABASE_URL.trim().replace(/\/+$/, ""), cfg.SUPABASE_ANON_KEY.trim()); }
    catch (e) { setupError("Invalid Supabase configuration: " + e.message); return; }
    S.client.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY") { openModal("pwModal"); return; }
      if (event === "SIGNED_OUT") { leaveApp(); return; }
      if ((event === "SIGNED_IN" || event === "INITIAL_SESSION") && session) setTimeout(() => enterApp(session.user), 0);
      if (event === "INITIAL_SESSION" && !session) showAuth();
    });
  }
  function isSecretKey(k) {
    if (/^sb_secret_/.test(k)) return true;
    try { const p = JSON.parse(atob(k.split(".")[1].replace(/-/g, "+").replace(/_/g, "/"))); return p.role === "service_role"; } catch { return false; }
  }
  function setupError(msg) { screen("setup"); const p = $("setupScreen").querySelector(".auth-card > p"); p.innerHTML = `<span style="color:var(--clay)">${esc(msg)}</span>`; }

  async function enterApp(user) {
    if (state.entering || (state.inApp && S.user && S.user.id === user.id)) return;
    state.entering = true; S.user = user; screen("boot");
    try {
      state.legacy = readLegacy();
      await S.bootstrap(!state.legacy);  // skip sample meals when offline data is about to be imported
      await S.loadAll();
      state.inApp = true;
      $("userEmail").textContent = user.email || ""; $("acctEmail").textContent = user.email || "";
      screen("app"); renderAll(); showTab(state.tab); offerLegacy();
    } catch (e) {
      state.inApp = false; showAuth(e.message);
    } finally { state.entering = false; }
  }
  function leaveApp() {
    state.inApp = false; S.user = null; S.meals = []; S.mealsById = new Map(); S.days = new Map();
    showAuth();
  }

  // ---------- auth ----------
  function showAuth(err) { screen("auth"); setAuthMode(state.authMode === "reset" ? "signin" : state.authMode); authMsg(err || "", !err); }
  function authMsg(t, ok) { const m = $("authMsg"); m.textContent = t; m.className = "form-msg" + (ok ? " ok" : ""); }
  function setAuthMode(mode) {
    state.authMode = mode;
    document.querySelectorAll("#authTabs .seg-btn").forEach((b) => b.classList.toggle("active", b.dataset.mode === mode));
    $("authTabs").hidden = mode === "reset"; $("passField").hidden = mode === "reset";
    $("authTitle").textContent = mode === "signup" ? "Create your account" : mode === "reset" ? "Reset password" : "Sign in";
    $("authSub").textContent = mode === "reset" ? "We'll email you a link to set a new password." : "Your meal plans, synced securely across devices.";
    $("authSubmit").textContent = mode === "signup" ? "Create account" : mode === "reset" ? "Send reset link" : "Sign in";
    $("forgotBtn").textContent = mode === "reset" ? "Back to sign in" : "Forgot password?";
    $("authPassword").autocomplete = mode === "signup" ? "new-password" : "current-password";
    authMsg("");
  }
  document.querySelectorAll("#authTabs .seg-btn").forEach((b) => (b.onclick = () => setAuthMode(b.dataset.mode)));
  $("forgotBtn").onclick = () => setAuthMode(state.authMode === "reset" ? "signin" : "reset");
  $("authForm").onsubmit = async (e) => {
    e.preventDefault();
    const email = $("authEmail").value.trim(), pw = $("authPassword").value, mode = state.authMode;
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return authMsg("Enter a valid email address.");
    if (mode !== "reset" && pw.length < 8) return authMsg("Password must be at least 8 characters.");
    // In the Android app location.href is https://localhost/, which a phone browser cannot open,
    // so email links fall back to AUTH_REDIRECT_URL (or the Supabase "Site URL" when unset).
    const redirectTo = nativeApp() ? ((window.VERDANT_CONFIG || {}).AUTH_REDIRECT_URL || undefined) : location.href.split("#")[0];
    await busy($("authSubmit"), async () => {
      try {
        if (mode === "signin") {
          const { error } = await S.client.auth.signInWithPassword({ email, password: pw });
          if (error) throw error;
        } else if (mode === "signup") {
          const { data, error } = await S.client.auth.signUp({ email, password: pw, options: { emailRedirectTo: redirectTo } });
          if (error) throw error;
          if (!data.session) { setAuthMode("signin"); authMsg("Account created. Check your email to confirm it, then sign in.", true); }
        } else {
          const { error } = await S.client.auth.resetPasswordForEmail(email, { redirectTo });
          if (error) throw error;
          authMsg("If an account exists for that email, a reset link is on its way.", true);
        }
      } catch (err) {
        authMsg(/Failed to fetch|NetworkError/i.test(err.message) ? "Cannot reach Supabase. Check the URL in js/config.js and your connection." : err.message);
      }
    });
  };
  $("pwForm").onsubmit = async (e) => {
    e.preventDefault();
    const pw = $("newPw").value;
    if (pw.length < 8) { $("pwMsg").textContent = "Password must be at least 8 characters."; return; }
    const { error } = await S.client.auth.updateUser({ password: pw });
    if (error) { $("pwMsg").textContent = error.message; return; }
    closeModal("pwModal"); toast("Password updated.");
  };
  $("signOutBtn").onclick = async () => {
    if (S.pending && !(await confirmDialog({ title: "Changes still saving", body: "Some changes are still being saved. Sign out anyway?", ok: "Sign out" }))) return;
    await S.client.auth.signOut();
  };

  // ---------- navigation ----------
  function showTab(id) {
    flushNotes();
    state.tab = id;
    document.querySelectorAll("[data-tab]").forEach((b) => b.classList.toggle("active", b.dataset.tab === id));
    document.querySelectorAll(".page").forEach((p) => p.classList.toggle("active", p.id === id));
    $("pageTitle").textContent = PAGE_TITLE[id];
    window.scrollTo(0, 0);
  }
  document.querySelectorAll("[data-tab]").forEach((b) => (b.onclick = () => showTab(b.dataset.tab)));
  function setDate(iso) {
    if (!C.isValidISO(iso)) return;
    flushNotes();
    state.date = iso; state.cal = monthOf(iso);
    renderDashboard(); renderDaily();
  }
  document.addEventListener("click", (e) => {
    const s = e.target.closest("[data-shift]"); if (s) setDate(C.addDays(state.date, Number(s.dataset.shift)));
    if (e.target.closest("[data-today]")) setDate(C.todayISO());
  });
  ["dashDate", "dietDate"].forEach((id) => ($(id).onchange = (e) => setDate(e.target.value || C.todayISO())));

  // Refresh from the database when the tab regains focus (picks up edits from other devices).
  document.addEventListener("visibilitychange", async () => {
    if (document.visibilityState !== "visible" || !state.inApp || S.pending || noteTimer) return;
    if (document.querySelector(".modal.show")) return;
    if (Date.now() - S.loadedAt < 30000) return;
    try { await S.loadAll(); renderAll(); } catch (e) { toast(e.message, "error"); }
  });
  window.addEventListener("beforeunload", (e) => { if (S.pending || noteTimer) { flushNotes(); e.preventDefault(); e.returnValue = ""; } });

  function renderAll() {
    $("headerDate").textContent = new Date().toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" });
    renderDashboard(); renderDaily(); renderMeals(); renderCredits(); renderData();
  }
  const refreshDayViews = () => { renderDashboard(); renderDaily(); renderCredits(); };

  // ---------- dashboard ----------
  function renderDashboard() {
    const day = S.viewDay(state.date), byId = S.mealsById;
    const cs = C.calorieStatus(day, byId, tol()), t = C.totals(day, byId), done = C.totals(day, byId, { completedOnly: true });
    const planned = C.countMeals(day), completed = C.countCompleted(day);
    $("dashDate").value = state.date;
    $("kTarget").innerHTML = cs.target ? `${nf.format(cs.target)}<small>kcal</small>` : "—";
    $("kTargetSub").textContent = fmtLong(state.date);
    $("kActual").innerHTML = `${nf.format(cs.actual)}<small>kcal</small>`;
    const bar = $("kActualBar"); bar.style.width = cs.target ? Math.min(100, (cs.actual / cs.target) * 100) + "%" : "0%"; bar.className = statusCls(cs.status);
    $("kActualSub").textContent = cs.target ? `${Math.round((cs.actual / cs.target) * 100)}% of target · ${planned} option${planned === 1 ? "" : "s"} selected` : `${planned} option${planned === 1 ? "" : "s"} selected`;
    const st = $("kStatus"); st.textContent = cs.status; st.className = "status " + statusCls(cs.status);
    $("kVariance").textContent = varianceText(cs);
    $("kConsumed").innerHTML = `${nf.format(done.calories)}<small>kcal</small>`;
    $("kConsumedSub").textContent = planned ? `${completed} of ${planned} options completed` : "options marked completed";

    // macros
    const e = C.macroEnergy(t);
    if (!t.protein && !t.carbs && !t.fat) {
      $("macroPanel").innerHTML = `<div class="empty"><b>No macronutrient data for this day</b>Select meals that have protein, carbohydrate and fat values.</div>`;
    } else {
      const row = (k, label, color) => `<div class="macro-row"><span class="macro-name"><i style="background:${color}"></i>${label}</span><div class="meter" style="margin:0"><span style="width:${e[k]}%;background:${color}"></span></div><span class="macro-val">${grams(t[k])} <small>${e[k]}%</small></span></div>`;
      $("macroPanel").innerHTML = row("protein", "Protein", "var(--c-protein)") + row("carbs", "Carbohydrates", "var(--c-carbs)") + row("fat", "Fat", "var(--c-fat)") +
        `<div class="split" aria-hidden="true"><span style="width:${e.protein}%;background:var(--c-protein)"></span><span style="width:${e.carbs}%;background:var(--c-carbs)"></span><span style="width:${e.fat}%;background:var(--c-fat)"></span></div>
         <div class="split-legend"><span>Share of macro energy (4/4/9 kcal per g): ${nf.format(e.kcal)} kcal</span><span>Consumed: ${grams(done.protein)} P · ${grams(done.carbs)} C · ${grams(done.fat)} F</span></div>`;
    }
    const o = C.overallStats(S.days);
    $("overallStats").innerHTML = [["Days tracked", o.daysTracked], ["Meals planned", o.planned], ["Meals completed", o.completed], ["Consistency", o.consistency + "%"]]
      .map(([k, v]) => `<div><dt>${k}</dt><dd>${v}</dd></div>`).join("");
    renderCalendar(); renderHistory();
  }

  function renderCalendar() {
    const y = state.cal.getFullYear(), m = state.cal.getMonth(), today = C.todayISO();
    $("monthTitle").textContent = state.cal.toLocaleDateString(undefined, { month: "long", year: "numeric" });
    const start = (new Date(y, m, 1).getDay() + 6) % 7;
    let h = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((x) => `<div class="dow">${x}</div>`).join("");
    for (let i = 0; i < 42; i++) {
      const d = new Date(y, m, i - start + 1), iso = C.isoLocal(d), day = S.getDay(iso);
      const cs = C.calorieStatus(day, S.mealsById, tol()), p = C.countMeals(day);
      const dot = statusCls(cs.status) || (p ? "planned" : "");
      const label = `${fmtLong(iso)}${p ? ` — ${p} meal option${p > 1 ? "s" : ""}` : ""}${cs.status !== "—" ? `, ${cs.status}` : ""}`;
      h += `<button class="day${d.getMonth() !== m ? " other" : ""}${iso === today ? " today" : ""}${iso === state.date ? " selected" : ""}" data-date="${iso}" title="${esc(label)}" aria-label="${esc(label)}"><span>${d.getDate()}</span><span class="dot ${dot}"></span></button>`;
    }
    $("calendar").innerHTML = h;
  }
  $("calendar").onclick = (e) => { const b = e.target.closest("[data-date]"); if (b) { setDate(b.dataset.date); showTab("daily"); } };
  $("prevMonth").onclick = () => { state.cal = new Date(state.cal.getFullYear(), state.cal.getMonth() - 1, 1); renderCalendar(); };
  $("nextMonth").onclick = () => { state.cal = new Date(state.cal.getFullYear(), state.cal.getMonth() + 1, 1); renderCalendar(); };

  function mealName(id) { return (S.mealsById.get(id) || {}).name || "Deleted meal"; }
  function renderHistory() {
    const rows = C.periodDates(state.period, state.date).map((d) => ({ d, r: S.getDay(d) })).filter((x) => C.isTracked(x.r));
    if (!rows.length) { $("historyTable").innerHTML = `<div class="empty"><b>No records for this ${state.period}</b>Plan meals on the Daily Plan to see them here.</div>`; return; }
    const cell = (r, k) => r.entries[k].filter(Boolean).map((e) => esc(mealName(e.meal_id)) + (e.completed ? ' <span class="done" title="Completed">✓</span>' : "")).join("<br>") || '<span class="muted">—</span>';
    let h = `<div class="tablewrap"><table class="table"><thead><tr><th>Date</th><th>Breakfast</th><th>Lunch</th><th>Dinner</th><th class="n">Done</th><th class="n">Target</th><th class="n">Planned</th><th>Status</th><th>Notes</th></tr></thead><tbody>`;
    rows.forEach(({ d, r }) => {
      const p = C.countMeals(r), c = C.countCompleted(r), cs = C.calorieStatus(r, S.mealsById, tol());
      h += `<tr data-date="${d}"><td class="nowrap"><b>${fmtDate(d)}</b></td><td class="meals-cell">${cell(r, "breakfast")}</td><td class="meals-cell">${cell(r, "lunch")}</td><td class="meals-cell">${cell(r, "dinner")}</td>
        <td class="n"><span class="pill ${p === c ? "" : "amber"}">${c}/${p}</span></td><td class="n">${cs.target ? nf.format(cs.target) : "—"}</td><td class="n">${nf.format(cs.actual)}</td>
        <td><span class="status ${statusCls(cs.status)}">${cs.status}</span></td><td class="note-cell" title="${esc(r.notes)}">${esc(r.notes || "—")}</td></tr>`;
    });
    $("historyTable").innerHTML = h + "</tbody></table></div>";
  }
  $("historyTable").onclick = (e) => { const tr = e.target.closest("tr[data-date]"); if (tr) { setDate(tr.dataset.date); showTab("daily"); } };
  document.querySelectorAll("#periodTabs .seg-btn").forEach((b) => (b.onclick = () => {
    state.period = b.dataset.period; document.querySelectorAll("#periodTabs .seg-btn").forEach((x) => x.classList.toggle("active", x === b)); renderHistory();
  }));

  // ---------- daily ----------
  function renderDaily() {
    const day = S.viewDay(state.date), byId = S.mealsById, cs = C.calorieStatus(day, byId, tol());
    const t = C.totals(day, byId), done = C.totals(day, byId, { completedOnly: true });
    $("dietDate").value = state.date;
    $("dailyHeading").textContent = fmtLong(state.date);
    const ti = $("dailyCalorieTarget");
    if (document.activeElement !== ti) { ti.value = day.calorie_target ?? ""; ti.removeAttribute("aria-invalid"); $("targetErr").textContent = ""; }
    $("dPlanned").textContent = kcal(t.calories); $("dConsumed").textContent = kcal(done.calories);
    const st = $("dStatus"); st.textContent = cs.status; st.className = "status " + statusCls(cs.status);
    const bar = $("dBar"); bar.style.width = cs.target ? Math.min(100, (cs.actual / cs.target) * 100) + "%" : "0%"; bar.className = statusCls(cs.status);
    $("dConclusion").textContent = cs.variance == null ? "Enter a daily target to evaluate calorie achievement." : cs.status === "Achieved" ? `Target achieved — ${varianceText(cs)}.` : `${cs.status}: ${varianceText(cs)}.`;
    $("dMacros").textContent = `Planned macros: ${grams(t.protein)} protein · ${grams(t.carbs)} carbs · ${grams(t.fat)} fat`;
    C.MEAL_TYPES.forEach((type) => { renderOptions(type, day); const s = C.totals(day, byId, { type }); $("sum-" + type).textContent = C.countMeals({ entries: { [type]: day.entries[type] } }) ? kcal(s.calories) : ""; });
    if (document.activeElement !== $("dailyNotes") && !noteTimer) $("dailyNotes").value = day.notes || "";
  }

  function renderOptions(type, day) {
    const list = C.mealsForType(type, S.meals);
    $(type + "Options").innerHTML = [0, 1, 2].map((slot) => {
      const e = day.entries[type][slot], m = e && S.mealsById.get(e.meal_id);
      let opts = `<option value="">Select a meal…</option>` + list.map((x) => `<option value="${x.id}"${e && x.id === e.meal_id ? " selected" : ""}>${esc(x.name)}</option>`).join("");
      if (e && !list.some((x) => x.id === e.meal_id)) opts += `<option value="${esc(e.meal_id)}" selected>${esc(m ? m.name : "Deleted meal")} ${m && m.archived_at ? "(archived)" : "(saved reference)"}</option>`;
      const meta = m ? [m.calories != null ? `<b>${kcal(m.calories)}</b>` : "", m.protein != null ? `${grams(m.protein)} protein` : "", m.serving ? esc(m.serving) : ""].filter(Boolean).join(" · ") || "No nutrition data" : "Choose from your meal library";
      const dis = e ? "" : " disabled";
      return `<div class="opt${e ? " filled" : ""}${e && e.completed ? " completed" : ""}" data-type="${type}" data-slot="${slot}">
        <div class="opt-label">Option ${slot + 1}</div>
        <select data-act="meal" aria-label="${TYPE_LABEL[type]} option ${slot + 1}">${opts}</select>
        <div class="opt-meta">${meta}</div>
        <div class="opt-actions"><label class="check"><input type="checkbox" data-act="done"${e && e.completed ? " checked" : ""}${dis}> Completed</label>
          <input class="portion" data-act="portion" maxlength="100" value="${esc(e ? e.portion : "")}" placeholder="Portion"${dis} aria-label="Portion">
          <button class="btn small" data-act="clear"${dis}>Clear</button></div></div>`;
    }).join("");
  }

  async function optionAction(el) {
    const opt = el.closest(".opt"); if (!opt) return;
    const type = opt.dataset.type, slot = Number(opt.dataset.slot), date = state.date, act = el.dataset.act;
    opt.setAttribute("aria-busy", "true");
    try {
      if (act === "meal") el.value ? await S.setEntry(date, type, slot, { meal_id: el.value, completed: false }) : await S.clearEntry(date, type, slot);
      else if (act === "done") await S.setEntry(date, type, slot, { completed: el.checked });
      else if (act === "portion") await S.setEntry(date, type, slot, { portion: el.value.trim().slice(0, 100) });
      else if (act === "clear") await S.clearEntry(date, type, slot);
    } catch (e) { toast(e.message, "error"); }
    refreshDayViews();
  }
  const mealsGrid = document.querySelector(".meals-grid");
  mealsGrid.addEventListener("change", (e) => { if (e.target.dataset.act) optionAction(e.target); });
  mealsGrid.addEventListener("click", (e) => { const b = e.target.closest('[data-act="clear"]'); if (b) optionAction(b); });

  $("dailyCalorieTarget").onchange = async (e) => {
    const el = e.target, raw = el.value.trim(), date = state.date;
    let v = raw === "" ? null : Number(raw);
    if (v !== null && (!Number.isFinite(v) || v < 0 || v > 20000)) { el.setAttribute("aria-invalid", "true"); $("targetErr").textContent = "Enter a number between 1 and 20,000, or leave blank."; return; }
    if (v === 0) v = null; // the original treated 0 as "no target"
    el.removeAttribute("aria-invalid"); $("targetErr").textContent = "";
    if ((S.getDay(date)?.calorie_target ?? null) === v) return;
    try { await S.setDayFields(date, { calorie_target: v === null ? null : Math.round(v * 10) / 10 }); } catch (err) { toast(err.message, "error"); }
    el.blur(); refreshDayViews();
  };

  let noteTimer = null, noteDate = null;
  $("dailyNotes").oninput = () => { noteDate = state.date; clearTimeout(noteTimer); noteTimer = setTimeout(flushNotes, 700); };
  $("dailyNotes").onblur = () => flushNotes();
  function flushNotes() {
    if (!noteTimer) return;
    clearTimeout(noteTimer); noteTimer = null;
    const date = noteDate, val = $("dailyNotes").value.slice(0, 5000);
    if ((S.getDay(date)?.notes || "") === val) return;
    S.setDayFields(date, { notes: val }).then(() => { renderDashboard(); }).catch((e) => toast(e.message, "error"));
  }
  $("clearDayBtn").onclick = async () => {
    const date = state.date, day = S.getDay(date);
    if (!day) { toast("There is nothing saved for this day."); return; }
    if (!(await confirmDialog({ title: "Clear this day?", body: `All meal options, the calorie target and notes for <b>${esc(fmtLong(date))}</b> will be permanently deleted.`, ok: "Clear day", danger: true }))) return;
    try { noteTimer && clearTimeout(noteTimer); noteTimer = null; await S.clearDay(date); toast("Day cleared."); } catch (e) { toast(e.message, "error"); }
    $("dailyNotes").value = ""; refreshDayViews();
  };

  // ---------- credits ----------
  function renderCredits() {
    const today = C.todayISO(), c = C.creditStats(S.days, S.mealsById, tol(), today);
    $("creditTotal").textContent = c.credits; $("creditStreak").textContent = c.streak;
    $("creditStreakSub").textContent = c.streak ? `since ${fmtDate(c.streakStart)}` : "consecutive achieved days";
    $("creditRemaining").textContent = c.remaining; $("creditProgressText").textContent = c.progressPct + "%"; $("creditProgress").style.width = c.progressPct + "%";
    let strip = "";
    for (let i = 29; i >= 0; i--) { const d = C.addDays(today, -i), on = C.achieved(S.getDay(d), S.mealsById, tol()); strip += `<i class="${on ? "on" : ""}${i === 0 ? " today" : ""}" title="${esc(fmtDate(d))}${on ? " — achieved" : ""}"></i>`; }
    $("streakStrip").innerHTML = strip;
    let h = "";
    if (c.credits) h += `<div class="notice">${c.credits} cheat-meal credit${c.credits > 1 ? "s" : ""} unlocked from your current ${c.streak}-day achieved streak.<br>${c.milestones.map((m, i) => `Credit ${i + 1}: day ${m.days}, reached ${esc(fmtDate(m.endDate))}`).join(" · ")}</div>`;
    else h += `<div class="empty"><b>No credits unlocked yet</b>Achieve your calorie target for 10 straight days to unlock your first cheat meal.</div>`;
    if (!C.achieved(S.getDay(today), S.mealsById, tol())) {
      const y = C.creditStats(S.days, S.mealsById, tol(), C.addDays(today, -1));
      if (y.streak) h += `<div class="notice warn" style="margin-top:10px">Today's target isn't achieved yet, so the streak counts from today and shows 0. Achieve today's target to continue your ${y.streak}-day streak.</div>`;
    }
    $("creditHistory").innerHTML = h;
  }

  // ---------- meal library ----------
  function renderMeals() {
    const q = $("mealSearch").value.trim().toLowerCase(), cat = $("categoryFilter").value, arch = $("showArchived").checked;
    const list = S.meals.filter((m) => (arch || !m.archived_at) && (!cat || m.category === cat) &&
      (!q || [m.name, m.description, m.ingredients, m.tags].join(" ").toLowerCase().includes(q)));
    const active = S.meals.filter((m) => !m.archived_at).length, archived = S.meals.length - active;
    $("mealCount").textContent = `${list.length} shown · ${active} active${archived ? ` · ${archived} archived` : ""}`;
    if (!list.length) { $("mealList").innerHTML = `<div class="card empty" style="grid-column:1/-1"><b>No meals found</b>${S.meals.length ? "Change the search or filters." : "Add a meal or load the sample meals."}</div>`; return; }
    const v = (x) => (x == null ? "—" : nf.format(x));
    $("mealList").innerHTML = list.map((m) => `<article class="card meal-card${m.archived_at ? " archived" : ""}">
      <div class="meal-top"><h4>${esc(m.name)}</h4><span style="display:flex;gap:4px">${m.archived_at ? '<span class="pill amber">Archived</span>' : ""}<span class="pill">${esc(m.category)}</span></span></div>
      ${m.description ? `<p class="meal-desc">${esc(m.description)}</p>` : ""}
      <div class="nutri"><div><b>${v(m.calories)}</b><span>kcal</span></div><div><b>${v(m.protein)}</b><span>Protein g</span></div><div><b>${v(m.carbs)}</b><span>Carbs g</span></div><div><b>${v(m.fat)}</b><span>Fat g</span></div></div>
      <dl class="meal-dl"><dt>Serving</dt><dd>${esc(m.serving || "—")}</dd><dt>Ingredients</dt><dd>${esc(m.ingredients || "—")}</dd><dt>Tags</dt><dd>${esc(m.tags || "—")}</dd>${m.prep ? `<dt>Prep</dt><dd>${esc(m.prep)}</dd>` : ""}</dl>
      <div class="meal-actions"><button class="btn small" data-edit="${m.id}">Edit</button><button class="btn small" data-dup="${m.id}">Duplicate</button>
      ${m.archived_at ? `<button class="btn small" data-restore="${m.id}">Restore</button>` : `<button class="btn small danger-ghost" data-del="${m.id}">Delete</button>`}</div></article>`).join("");
  }
  ["mealSearch", "categoryFilter", "showArchived"].forEach((id) => $(id).addEventListener(id === "mealSearch" ? "input" : "change", renderMeals));
  $("mealList").onclick = async (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.edit) return openMealModal(b.dataset.edit);
    if (b.dataset.dup) {
      const m = S.mealsById.get(b.dataset.dup); if (!m) return;
      await busy(b, async () => { try { await S.saveMeal({ ...mealFields(m), name: (m.name + " (Copy)").slice(0, 200) }); toast("Meal duplicated."); } catch (err) { toast(err.message, "error"); } });
      renderMeals(); renderDaily(); return;
    }
    if (b.dataset.restore) { await busy(b, async () => { try { await S.restoreMeal(b.dataset.restore); toast("Meal restored to the library."); } catch (err) { toast(err.message, "error"); } }); renderMeals(); renderDaily(); return; }
    if (b.dataset.del) {
      const m = S.mealsById.get(b.dataset.del); if (!m) return;
      const used = S.isMealReferenced(m.id);
      const ok = await confirmDialog({ title: `Delete “${m.name}”?`, danger: true, ok: used ? "Archive meal" : "Delete meal",
        body: used ? "This meal is used in your diet history, so it will be <b>archived</b>: past days keep its name and nutrition, and it no longer appears in the planner. You can restore it later." : "This meal will be permanently deleted from your library." });
      if (!ok) return;
      await busy(b, async () => { try { const r = await S.deleteMeal(m.id); toast(r === "archived" ? "Meal archived; history preserved." : "Meal deleted."); } catch (err) { toast(err.message, "error"); } });
      renderMeals(); refreshDayViews();
    }
  };
  function mealFields(m) { return { name: m.name, category: m.category, description: m.description || "", ingredients: m.ingredients || "", calories: m.calories, protein: m.protein, carbs: m.carbs, fat: m.fat, serving: m.serving || "", tags: m.tags || "", prep: m.prep || "" }; }
  const MF = { Name: "name", Category: "category", Description: "description", Ingredients: "ingredients", Calories: "calories", Protein: "protein", Carbs: "carbs", Fat: "fat", Serving: "serving", Tags: "tags", Prep: "prep" };
  function openMealModal(id) {
    $("mealForm").reset(); $("mealErr").textContent = ""; $("mealId").value = id || "";
    document.querySelectorAll("#mealForm [aria-invalid]").forEach((x) => x.removeAttribute("aria-invalid"));
    $("mealModalTitle").textContent = id ? "Edit meal" : "Add meal";
    if (id) { const m = S.mealsById.get(id); if (!m) return; Object.entries(MF).forEach(([k, f]) => ($("m" + k).value = m[f] ?? "")); }
    openModal("mealModal");
  }
  $("addMealBtn").onclick = () => openMealModal();
  $("mealForm").onsubmit = async (e) => {
    e.preventDefault();
    const id = $("mealId").value || null, err = [], f = {};
    document.querySelectorAll("#mealForm [aria-invalid]").forEach((x) => x.removeAttribute("aria-invalid"));
    f.name = $("mName").value.trim(); if (!f.name) { err.push("Meal name is required."); $("mName").setAttribute("aria-invalid", "true"); }
    f.category = $("mCategory").value;
    ["description", "ingredients", "serving", "tags", "prep"].forEach((k) => (f[k] = $("m" + k[0].toUpperCase() + k.slice(1)).value.trim()));
    [["Calories", 20000], ["Protein", 2000], ["Carbs", 2000], ["Fat", 2000]].forEach(([k, max]) => {
      const el = $("m" + k), raw = el.value.trim();
      if (raw === "") { f[MF[k]] = null; return; }
      const n = Number(raw);
      if (!Number.isFinite(n) || n < 0 || n > max) { err.push(`${k} must be between 0 and ${max.toLocaleString()}.`); el.setAttribute("aria-invalid", "true"); }
      else f[MF[k]] = Math.round(n * 10) / 10;
    });
    if (err.length) { $("mealErr").textContent = err.join(" "); return; }
    await busy($("mealSave"), async () => {
      try { await S.saveMeal(f, id); closeModal("mealModal"); toast(id ? "Meal updated." : "Meal added."); renderMeals(); refreshDayViews(); }
      catch (ex) { $("mealErr").textContent = ex.message; }
    });
  };
  $("resetSamplesBtn").onclick = async (e) => {
    if (!(await confirmDialog({ title: "Add sample meals?", body: "Adds a fresh set of 10 sample meals. Existing meals are not changed.", ok: "Add samples" }))) return;
    await busy(e.currentTarget, async () => { try { const n = await S.addSampleMeals(); toast(`${n} sample meals added.`); } catch (err) { toast(err.message, "error"); } });
    renderMeals(); renderDaily();
  };

  // ---------- data & settings ----------
  function renderData() {
    const active = S.meals.filter((m) => !m.archived_at).length;
    $("recordCount").textContent = `${S.days.size} diet records · ${active} meals`;
    $("lastBackup").textContent = S.settings.last_backup_at ? new Date(S.settings.last_backup_at).toLocaleString() : "Never";
    if (document.activeElement !== $("tolerance")) $("tolerance").value = S.settings.calorie_tolerance;
    const lg = state.legacy;
    $("legacyCard").innerHTML = lg ? `<div class="notice" style="margin-top:12px">This browser still holds data from the original offline app: <b>${lg.dietHistory.length}</b> diet records and <b>${lg.meals.length}</b> meals.${legacyDone() ? " It has already been imported into this account." : ""}<div style="margin-top:10px"><button class="btn small" id="legacyImportBtn2">${legacyDone() ? "Import again (duplicates are skipped)" : "Import into my account"}</button></div></div>` : "";
    const b2 = $("legacyImportBtn2"); if (b2) b2.onclick = (e) => importLegacy(e.currentTarget);
  }
  $("settingsForm").onsubmit = async (e) => {
    e.preventDefault();
    const raw = $("tolerance").value.trim(), n = raw === "" ? 0 : Number(raw);
    if (!Number.isFinite(n) || n < 0 || n > 2000) { $("tolerance").setAttribute("aria-invalid", "true"); $("tolErr").textContent = "Enter a whole number between 0 and 2,000."; return; }
    $("tolerance").removeAttribute("aria-invalid"); $("tolErr").textContent = "";
    try { await S.updateSettings({ calorie_tolerance: Math.round(n) }); toast("Calculation settings saved."); } catch (err) { toast(err.message, "error"); }
    renderAll();
  };
  $("backupBtn").onclick = async (e) => {
    await busy(e.currentTarget, async () => {
      const data = S.toBackup();
      download(new Blob([JSON.stringify(data, null, 2)], { type: "application/json" }), `verdant-backup-${stamp()}.json`);
      try { await S.updateSettings({ last_backup_at: new Date().toISOString() }); } catch (err) { toast("Backup downloaded, but the backup date could not be saved: " + err.message, "error"); return; }
      toast("Backup downloaded."); renderData();
    });
  };
  $("exportBtn").onclick = () => {
    try { download(new Blob([window.Xlsx.build(S)], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }), `verdant-export-${C.todayISO()}.xlsx`); toast("Excel workbook downloaded."); }
    catch (e) { toast("Excel export failed: " + e.message, "error"); }
  };
  $("restoreBtn").onclick = () => $("importFile").click();
  $("importFile").onchange = async (e) => {
    const f = e.target.files[0]; e.target.value = ""; if (!f) return;
    try {
      let obj;
      if (/\.json$/i.test(f.name)) { try { obj = JSON.parse(await f.text()); } catch { throw new Error("The file is not valid JSON."); } }
      else if (/\.xlsx$/i.test(f.name)) obj = await window.Xlsx.parse(await f.arrayBuffer());
      else throw new Error("Choose a JSON backup or an XLSX exported by this app.");
      validateBackup(obj);
      state.pendingImport = obj;
      $("restoreInfo").innerHTML = `<p><b>${esc(f.name)}</b></p><p>Found <b>${obj.dietHistory.length}</b> diet records and <b>${obj.meals.length}</b> meals.</p><p class="muted small"><b>Merge</b> keeps your data and adds what's new (empty notes, targets and meal slots are filled). <b>Replace</b> deletes your current data first. Nothing changes until you confirm.</p>`;
      $("restoreMode").value = "merge"; openModal("restoreModal");
    } catch (err) { toast("Import failed: " + err.message, "error"); }
  };
  function validateBackup(o) { if (!o || typeof o !== "object" || !Array.isArray(o.meals) || !Array.isArray(o.dietHistory)) throw new Error("This file does not have the expected backup structure."); }
  function importSummary(r) {
    let s = `Imported ${r.meals_added} meal${r.meals_added === 1 ? "" : "s"}, ${r.days_added} new day${r.days_added === 1 ? "" : "s"}${r.days_merged ? `, merged ${r.days_merged} existing` : ""}, ${r.entries_added} meal option${r.entries_added === 1 ? "" : "s"}.`;
    if (r.placeholder_meals) s += ` ${r.placeholder_meals} reference${r.placeholder_meals > 1 ? "s" : ""} to deleted meals kept as archived meals.`;
    if (r.entries_no_free_slot) s += ` ${r.entries_no_free_slot} option${r.entries_no_free_slot > 1 ? "s" : ""} skipped because all three slots were full.`;
    if (r.days_invalid) s += ` ${r.days_invalid} record${r.days_invalid > 1 ? "s" : ""} with an invalid date skipped.`;
    return s;
  }
  $("confirmRestore").onclick = async (e) => {
    const obj = state.pendingImport, mode = $("restoreMode").value; if (!obj) return;
    if (mode === "replace" && !(await confirmDialog({ title: "Replace all data?", danger: true, ok: "Replace data", body: "All diet history and meals in your account will be deleted and replaced with the imported file. This cannot be undone unless you have a backup." }))) return;
    await busy(e.currentTarget, async () => {
      try { const r = await S.importBackup(obj, mode); closeModal("restoreModal"); renderAll(); toast(importSummary(r)); }
      catch (err) { toast(err.message, "error"); }
    });
  };
  $("clearBtn").onclick = async (e) => {
    if (!(await confirmDialog({ title: "Clear all data?", danger: true, ok: "Continue", body: "This permanently deletes all diet history and meals in your account and restores the sample meals. Download a backup first if needed." }))) return;
    if (!(await confirmDialog({ title: "Final confirmation", danger: true, ok: "Delete everything", body: "Permanently clear all application data from the database?" }))) return;
    await busy(e.currentTarget, async () => { try { await S.clearAll(); renderAll(); toast("All data cleared and sample meals restored."); } catch (err) { toast(err.message, "error"); } });
  };

  // ---------- migration of the original app's browser data ----------
  function readLegacy() {
    try {
      const o = JSON.parse(localStorage.getItem(LEGACY_KEY) || "null");
      if (!o || !Array.isArray(o.meals) || !Array.isArray(o.dietHistory)) return null;
      if (!o.dietHistory.length && !o.meals.length) return null;
      return o;
    } catch { return null; }
  }
  const legacyFlag = (k) => `verdant_legacy_${k}:${S.user && S.user.id}`;
  const legacyDone = () => { try { return !!localStorage.getItem(legacyFlag("imported")); } catch { return false; } };
  function offerLegacy() {
    const lg = state.legacy, b = $("legacyBanner");
    let dismissed = false; try { dismissed = !!localStorage.getItem(legacyFlag("dismissed")); } catch {}
    if (!lg || legacyDone() || dismissed) { b.hidden = true; return; }
    b.innerHTML = `<p>We found <b>${lg.dietHistory.length}</b> diet records and <b>${lg.meals.length}</b> meals saved in this browser by the original offline app. Import them into your account? Your browser copy is left untouched.</p><div class="actions"><button class="btn small" id="legacyLater">Not now</button><button class="btn primary small" id="legacyImportBtn">Import my data</button></div>`;
    b.hidden = false;
    $("legacyImportBtn").onclick = (e) => importLegacy(e.currentTarget);
    $("legacyLater").onclick = () => { try { localStorage.setItem(legacyFlag("dismissed"), new Date().toISOString()); } catch {} b.hidden = true; toast("You can import it later from Data & Settings."); };
  }
  async function importLegacy(btn) {
    const lg = state.legacy; if (!lg) return;
    await busy(btn, async () => {
      try {
        const r = await S.importBackup(lg, "merge");
        try { localStorage.setItem(legacyFlag("imported"), new Date().toISOString()); } catch {}
        $("legacyBanner").hidden = true; renderAll(); toast(importSummary(r));
      } catch (err) { toast(err.message, "error"); }
    });
  }

  // ---------- start ----------
  screen("boot");
  boot();
  window.__verdant = { state, renderAll }; // debugging aid
})();
