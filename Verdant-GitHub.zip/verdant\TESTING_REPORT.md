# Verdant — Testing Report

**Date:** 19 Nov 2026 · **Result:** 12 database groups, 9 calculation groups and 80 browser checks — all pass.

## What was and was not tested against

| Layer | Tested against | Real or emulated |
|---|---|---|
| Database schema, constraints, RLS, RPCs | **PostgreSQL 17** (same major version as Supabase) | Real Postgres. `auth.users`, `auth.uid()` and the `anon`/`authenticated` roles were **emulated** with a small shim (`tests/local-auth-shim.sql`) |
| REST API | **PostgREST 12.2** — the same server Supabase uses | Real |
| Client library | **`@supabase/supabase-js` 2.119.1** driving the real UI | Real |
| Auth (sign‑up, sign‑in, JWT) | A **mock** auth server issuing JWTs signed with the shared secret that PostgREST verifies | **Emulated** |
| UI | Headless Google Chrome via Playwright, time zone **Asia/Kolkata** | Real browser |

### ⚠️ Not verified — please check on your own project
I did **not** run the migration on, or sign in to, your hosted Supabase project; that needs your
credentials. Therefore these remain **unverified** until you do Steps 1–6 of the README:
- Supabase's real GoTrue behaviour: email confirmation, password‑reset emails, redirect URLs.
- Supabase's hosted API gateway and CDN loading of `supabase-js` (tests served a local copy).
- Supabase's own security advisor (run **Advisors → Security** after migrating; expected: no findings
  for the `diet_*` tables).

After migrating, a 2‑minute smoke test on the real project: sign up → add a meal → refresh the page
→ open the app in a private window, sign in → confirm the meal is there. In the Table Editor the row
should appear in `diet_meals` with your user id.

## 1. Database tests (`supabase/tests/db_tests.sql`) — PASS

| # | Verified |
|---|---|
| T1 | `diet_bootstrap` seeds 10 sample meals once; second call is a no‑op |
| T2 | **Create / read / update / delete** a meal; `user_id` defaults to caller; blank name, bad category and negative calories rejected by `CHECK` |
| T3 | Day + entries; upsert of an existing slot; slot 3 rejected; duplicate day rejected; a meal used by history cannot be hard‑deleted |
| T4 | **RLS isolation**: second user sees 0 of the first user's meals/days/entries; cannot update, delete, or insert rows as another user; composite FKs reject entries pointing at another user's day or meal |
| T5 | `anon` role has no table access and cannot call any RPC |
| T6 | Legacy JSON import (merge): meals added, strings parsed as numbers, bad category → `Other`, blank‑name meal skipped, invalid date skipped, orphan `mealId` → archived placeholder, `missing-<name>` placeholder uses the name, 4th option reported as "no free slot", slot position preserved, merge fills empty note/target, **re‑import is idempotent** |
| T7 | Invalid payload / mode rejected with no side effects |
| T8 | Replace import leaves only imported data; tolerance and last‑backup restored |
| T9 | Clear‑all deletes history and restores samples atomically; **other users untouched** |
| T10 | Deleting an auth user cascades to all their rows |

A real defect was found and fixed by T10 during development (account deletion was blocked by the
meal reference; the foreign key is now deferrable and entries cascade from the user).
Also confirmed with auto‑commit statements (as PostgREST issues them) that deleting a referenced
meal and referencing another user's meal both fail with FK errors.

## 2. Calculation unit tests (`tests/calc.test.js`) — 9 groups PASS
Run with `TZ=Asia/Kolkata`: local‑date arithmetic across month/year/leap boundaries; planned vs
completed totals; float rounding; Achieved/Under/Over with and without tolerance; credits (23‑day
streak → 2 credits, 7 remaining, 30%; broken streak; exact 10); Monday‑start weeks; overall stats;
macro energy split sums to 100%; slot meal filter.

## 3. Browser end‑to‑end (`tests/e2e.py`) — 80/80 PASS
Every database effect below was confirmed by **querying Postgres directly**, not by trusting the UI.

- **Auth:** unauthenticated visitors never see the app; validation messages; wrong password rejected; sign‑up; sign‑out; session survives refresh.
- **Meals:** create, edit, duplicate, delete (hard delete when unused, **archive** when used), restore, search filter, sample meals, form validation (required name, negative values).
- **Daily plan:** target saved (and out‑of‑range rejected); choosing meals writes `diet_entries`; planned total 300+560+510 = 1,370 kcal; Over/Achieved status; completed + portion persisted; consumed = completed‑only; notes autosave; clear option; clear day.
- **Persistence:** reload keeps everything; a **second, separate browser** signing in sees the same plan, target and notes; a **second user** sees only their own data.
- **Dashboard:** KPIs from DB rows; macros 40 g / 201 g / 30 g match hand calculation; calendar status dots; calendar click opens that day; period history.
- **Settings & data:** tolerance validated and saved; JSON backup downloads in the original format; Excel export is a valid 3‑sheet workbook; Excel re‑import parses; merge adds no duplicates; replace restores exactly; corrupt/wrong‑structure files rejected with a message.
- **Credits:** 10 consecutive achieved days → 1 credit, 0% progress, 10 remaining; breaking today resets the streak and the page explains why.
- **Migration:** original app's `localStorage` data detected, samples **not** seeded, 2 meals + 3 entries + archived orphan imported with completed flags and portions intact, browser copy left untouched.
- **Failure handling:** with the API blocked, saving shows "could not be reached", keeps the form open and turns the sync badge red; retry succeeds once connectivity returns.
- **Responsive:** desktop (1366), tablet (820), mobile (390) × 5 screens — no horizontal overflow. Screenshots in `docs/screenshots/`.
- **Console:** no uncaught JS errors during the whole run.

## 4. Known limitations
- **Excel import** only reads the uncompressed workbook the app itself writes (as in the original). A file re‑saved by Excel is compressed and is rejected with an explanatory message; use the JSON backup instead.
- **Two devices editing the same field at the same moment:** last write wins. The app refreshes when a tab regains focus (after 30 s), but there is no live push.
- **Existing offline‑app data is only migrated from the browser/profile where it is saved.** Data on other browsers needs a JSON backup from the old app.
- Fonts load from Google Fonts; offline, the app falls back to the system font.
- A 4th meal option from an old backup (the original UI never produced one) cannot fit the 3‑slot model and is reported, not silently dropped.
