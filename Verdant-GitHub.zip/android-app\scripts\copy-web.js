// Copies the web app (../verdant) into www/ for Capacitor, leaving out tests/docs,
// and swaps the CDN copy of supabase-js for a local one so the app starts without the CDN.
const fs = require("fs");
const path = require("path");

const src = path.resolve(__dirname, "..", "..", "verdant");
const out = path.resolve(__dirname, "..", "www");

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const item of ["index.html", "css", "js"]) {
  fs.cpSync(path.join(src, item), path.join(out, item), { recursive: true });
}

const supa = path.resolve(__dirname, "..", "node_modules", "@supabase", "supabase-js", "dist", "umd", "supabase.js");
fs.copyFileSync(supa, path.join(out, "js", "supabase.js"));

const indexPath = path.join(out, "index.html");
let html = fs.readFileSync(indexPath, "utf8");
const cdn = /<script src="https:\/\/cdn\.jsdelivr\.net\/npm\/@supabase\/supabase-js@[^"]+"[^>]*><\/script>/;
if (!cdn.test(html)) throw new Error("supabase-js CDN <script> tag not found in index.html");
html = html.replace(cdn, '<script src="js/supabase.js"></script>');
fs.writeFileSync(indexPath, html);

const cfg = fs.readFileSync(path.join(out, "js", "config.js"), "utf8");
if (/SUPABASE_URL:\s*""/.test(cfg)) console.warn("WARNING: js/config.js has no SUPABASE_URL - the app will show the setup screen.");
console.log("Web app copied to", out);
