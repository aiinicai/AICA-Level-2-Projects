"""
parsers.py  -  Reads bank statements from many banks and file formats.

Supported inputs
    * PDF  (normal or password-protected; tables with or without borders)
    * Excel (.xlsx / .xls, including .xls files that are really HTML)
    * CSV / TXT

How it copes with different banks
    1. Finds the bank name from the top of the statement (name or IFSC code).
    2. Finds the header row anywhere in the first rows (banks put account
       details above the table).
    3. Recognises column names used by Indian banks, e.g.
         "Txn Date" / "Tran Date" / "Value Dt" / "Transaction Date"
         "Narration" / "Description" / "Particulars" / "Transaction Remarks"
         "Withdrawal Amt." / "Debit" / "DR" / "Withdrawal (Dr)"
         "Deposit Amt." / "Credit" / "CR" / "Deposit (Cr)"
         "Closing Balance" / "Balance (INR)" / "BAL"
         single "Amount" column with a separate "Dr/Cr" column, or "1,234.00 Cr"
    4. Joins narrations that wrap onto several lines.
    5. Checks every row against the running balance and reports the result.
    6. If anything cannot be recognised, the app lets the user map columns.
"""
from __future__ import annotations

import csv
import io
import re
from dataclasses import dataclass, field

import pandas as pd


class PasswordRequired(Exception):
    """PDF is locked and no password (or a wrong one) was given."""


class StatementError(Exception):
    """File could not be read as a bank statement."""


# ---------------------------------------------------------------------------
# Bank detection
# ---------------------------------------------------------------------------
BANKS = [  # (display name, IFSC prefix, name patterns)
    ("State Bank of India", "SBIN", ["STATE BANK OF INDIA", "SBI "]),
    ("HDFC Bank", "HDFC", ["HDFC BANK"]),
    ("ICICI Bank", "ICIC", ["ICICI BANK"]),
    ("Axis Bank", "UTIB", ["AXIS BANK"]),
    ("Kotak Mahindra Bank", "KKBK", ["KOTAK MAHINDRA", "KOTAK BANK"]),
    ("Punjab National Bank", "PUNB", ["PUNJAB NATIONAL BANK"]),
    ("Bank of Baroda", "BARB", ["BANK OF BARODA"]),
    ("Canara Bank", "CNRB", ["CANARA BANK"]),
    ("Union Bank of India", "UBIN", ["UNION BANK OF INDIA"]),
    ("Central Bank of India", "CBIN", ["CENTRAL BANK OF INDIA"]),
    ("Bank of India", "BKID", ["BANK OF INDIA"]),
    ("Indian Bank", "IDIB", ["INDIAN BANK"]),
    ("Indian Overseas Bank", "IOBA", ["INDIAN OVERSEAS BANK"]),
    ("UCO Bank", "UCBA", ["UCO BANK"]),
    ("Bank of Maharashtra", "MAHB", ["BANK OF MAHARASHTRA"]),
    ("IndusInd Bank", "INDB", ["INDUSIND BANK"]),
    ("Yes Bank", "YESB", ["YES BANK"]),
    ("IDFC FIRST Bank", "IDFB", ["IDFC FIRST", "IDFC BANK"]),
    ("IDBI Bank", "IBKL", ["IDBI BANK"]),
    ("Federal Bank", "FDRL", ["FEDERAL BANK"]),
    ("South Indian Bank", "SIBL", ["SOUTH INDIAN BANK"]),
    ("Karur Vysya Bank", "KVBL", ["KARUR VYSYA"]),
    ("City Union Bank", "CIUB", ["CITY UNION BANK"]),
    ("Karnataka Bank", "KARB", ["KARNATAKA BANK"]),
    ("Tamilnad Mercantile Bank", "TMBL", ["TAMILNAD MERCANTILE"]),
    ("RBL Bank", "RATN", ["RBL BANK", "RATNAKAR BANK"]),
    ("AU Small Finance Bank", "AUBL", ["AU SMALL FINANCE"]),
    ("Bandhan Bank", "BDBL", ["BANDHAN BANK"]),
    ("Equitas Small Finance Bank", "ESFB", ["EQUITAS"]),
    ("Ujjivan Small Finance Bank", "UJVN", ["UJJIVAN"]),
    ("Jammu & Kashmir Bank", "JAKA", ["JAMMU & KASHMIR BANK", "J&K BANK"]),
    ("Saraswat Bank", "SRCB", ["SARASWAT"]),
    ("DBS Bank", "DBSS", ["DBS BANK"]),
    ("Standard Chartered", "SCBL", ["STANDARD CHARTERED"]),
    ("HSBC", "HSBC", ["HSBC"]),
    ("Citibank", "CITI", ["CITIBANK"]),
    ("India Post Payments Bank", "IPOS", ["INDIA POST PAYMENTS"]),
    ("Airtel Payments Bank", "AIRP", ["AIRTEL PAYMENTS"]),
    ("Paytm Payments Bank", "PYTM", ["PAYTM PAYMENTS"]),
]
IFSC_RX = re.compile(r"\b([A-Z]{4})0[A-Z0-9]{6}\b")


ACCT_RX = re.compile(r"(?:A/?C|ACCOUNT|ACCT)\.?\s*(?:NO|NUMBER|NUM)?\.?\s*[:\-.]?\s*([X*\d][X*\d\- ]{5,22}\d)", re.I)


def detect_account_no(text: str) -> str:
    """Return the last 4 digits of the account number shown at the top, or ''."""
    m = ACCT_RX.search(str(text))
    if not m:
        return ""
    digits = re.sub(r"\D", "", m.group(1))
    return digits[-4:] if len(digits) >= 4 else ""


def detect_bank(text: str) -> str:
    """Look for an IFSC code first, then the bank's name. Only the top of the
    statement should be passed in (narrations mention other banks)."""
    t = str(text).upper()
    for m in IFSC_RX.finditer(t):
        for name, prefix, _ in BANKS:
            if m.group(1) == prefix:
                return name
    # longest name first so "STATE BANK OF INDIA" wins over "BANK OF INDIA"
    pats = sorted(((p, name) for name, _, ps in BANKS for p in ps), key=lambda x: -len(x[0]))
    for p, name in pats:
        if p in t:
            return name
    return "Not identified"


# ---------------------------------------------------------------------------
# Column recognition
# ---------------------------------------------------------------------------
ROLES = ["date", "narration", "debit", "credit", "amount", "drcr", "balance", "ref"]
ROLE_LABELS = {"date": "Date", "narration": "Narration", "debit": "Debit / Withdrawal",
               "credit": "Credit / Deposit", "amount": "Amount (single column)",
               "drcr": "Dr/Cr indicator", "balance": "Balance", "ref": "Cheque / Ref No"}


def _norm(h) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9]+", " ", str(h).lower())).strip()


def _role_of(header) -> str | None:
    n = _norm(header)
    if not n or n in ("nan", "none"):
        return None
    tok = set(n.split())
    if tok & {"dr", "debit"} and tok & {"cr", "credit"}:
        return "drcr"                                 # "Dr / Cr", "Debit/Credit"
    if n in ("type", "txn type", "transaction type", "cr dr", "dr cr"):
        return "drcr"
    if "date" in tok or n in ("dt", "txn dt", "tran dt", "value dt", "trans dt", "post dt"):
        return "date"
    if tok & {"narration", "description", "particulars", "remarks", "details", "naration"}:
        return "narration"
    if tok & {"withdrawal", "withdrawals", "withdrawl", "debit", "debits", "dr"} or n in ("paid out", "money out"):
        return "debit"
    if tok & {"deposit", "deposits", "credit", "credits", "cr"} or n in ("paid in", "money in", "receipts"):
        return "credit"
    if tok & {"balance", "bal", "balances"}:
        return "balance"
    if tok & {"amount", "amt", "amount inr", "transaction amount"}:
        return "amount"
    if tok & {"chq", "cheque", "ref", "reference", "instrument", "chqno", "utr"}:
        return "ref"
    return None


def guess_mapping(columns) -> dict:
    """Map each role to the best column. Transaction date beats value date."""
    found: dict[str, list] = {}
    for c in columns:
        r = _role_of(c)
        if r:
            found.setdefault(r, []).append(c)
    mapping = {}
    for role, cols in found.items():
        if role == "date":
            cols = sorted(cols, key=lambda c: ("value" in _norm(c), "post" in _norm(c)))
        mapping[role] = cols[0]
    return mapping


def _header_score(cells) -> int:
    roles = {_role_of(c) for c in cells} - {None}
    has_amount = bool(roles & {"debit", "credit", "amount"})
    if "date" not in roles or not has_amount:
        return 0
    return len(roles) + ("narration" in roles) + ("balance" in roles)


def find_header_row(rows: list[list], max_scan: int = 80) -> int | None:
    best, best_i = 0, None
    for i, row in enumerate(rows[:max_scan]):
        s = _header_score(row)
        if s > best and s >= 4:
            best, best_i = s, i
            if s >= 7:
                break
    return best_i


# ---------------------------------------------------------------------------
# Value cleaning
# ---------------------------------------------------------------------------
AMT_RX = re.compile(r"^\(?-?\s*(?:rs\.?|inr|₹)?\s*[\d,]*\d(?:\.\d+)?\)?\s*(cr|dr|c|d)?\.?$", re.I)


def parse_amount(v) -> tuple[float, str | None]:
    """'1,23,456.50 Cr' -> (123456.5, 'CR'). Empty / '-' -> (0, None)."""
    if v is None:
        return 0.0, None
    if isinstance(v, (int, float)):
        return (0.0, None) if pd.isna(v) else (float(v), None)
    s = str(v).strip().replace("\n", " ")
    if s in ("", "-", "--", "nan", "None", "NaN", "0", "0.00"):
        return 0.0, None
    s = s.replace("₹", "").replace("INR", "").replace("Rs.", "").replace("Rs", "").strip()
    suffix = None
    m = re.search(r"\b(CR|DR|Cr|Dr|cr|dr)\.?$", s)
    if m:
        suffix = m.group(1).upper()
        s = s[:m.start()].strip()
    neg = s.startswith("(") and s.endswith(")") or s.startswith("-") or s.endswith("-")
    s = re.sub(r"[^\d.]", "", s)
    if not s or s == ".":
        return 0.0, suffix
    try:
        val = float(s)
    except ValueError:
        return 0.0, suffix
    return (-val if neg else val), suffix


def is_amount(s: str) -> bool:
    s = str(s).strip()
    return bool(s) and bool(re.search(r"\d", s)) and bool(AMT_RX.match(s.replace(" ", "")))


DATE_RX = re.compile(
    r"^(\d{1,2}[/\-. ](?:\d{1,2}|[A-Za-z]{3,9})[/\-. ,]*\d{2,4}|\d{4}-\d{2}-\d{2})(?:\s+\d{1,2}:\d{2}(?::\d{2})?)?$")


def parse_dates(series: pd.Series) -> pd.Series:
    if pd.api.types.is_datetime64_any_dtype(series):
        return series
    s = series.astype(str).str.replace("\n", " ").str.strip()
    s = s.where(s.str.contains(r"\d"), None)
    return pd.to_datetime(s, dayfirst=True, errors="coerce", format="mixed")


# ---------------------------------------------------------------------------
# Result container
# ---------------------------------------------------------------------------
@dataclass
class ParseResult:
    df: pd.DataFrame                    # Date, Narration, Ref, Debit, Credit, Balance
    raw: pd.DataFrame                   # table as read (for manual column mapping)
    bank: str = "Not identified"
    file_type: str = ""
    method: str = ""
    mapping: dict = field(default_factory=dict)
    pages: int = 0
    account_no: str = ""                # last 4 digits, if printed on the statement
    balance_check: str = ""
    rows_checked: int = 0
    rows_ok: int = 0
    notes: list = field(default_factory=list)


# ---------------------------------------------------------------------------
# Raw table -> standard transactions
# ---------------------------------------------------------------------------
def standardise(raw: pd.DataFrame, mapping: dict | None = None) -> tuple[pd.DataFrame, dict, list]:
    notes = []
    mapping = {k: v for k, v in (mapping or guess_mapping(raw.columns)).items() if v in raw.columns}
    if "date" not in mapping:
        raise StatementError("Could not find the Date column.")
    if not ({"debit", "credit"} & mapping.keys() or "amount" in mapping):
        raise StatementError("Could not find Debit/Credit or Amount columns.")

    get = lambda role: raw[mapping[role]] if role in mapping else pd.Series([None] * len(raw), index=raw.index)
    dates = parse_dates(get("date"))
    narr = get("narration").fillna("").astype(str).str.replace(r"\s+", " ", regex=True).str.strip()
    narr = narr.replace({"nan": "", "None": ""})
    ref = get("ref").fillna("").astype(str).str.replace(r"\.0$", "", regex=True).replace({"nan": "", "None": ""})

    debit, credit = [], []
    for i in raw.index:
        d = c = 0.0
        if "debit" in mapping or "credit" in mapping:
            d, sd = parse_amount(raw.at[i, mapping["debit"]]) if "debit" in mapping else (0.0, None)
            c, sc = parse_amount(raw.at[i, mapping["credit"]]) if "credit" in mapping else (0.0, None)
            d, c = abs(d), abs(c)
        if d == 0 and c == 0 and "amount" in mapping:
            a, suf = parse_amount(raw.at[i, mapping["amount"]])
            ind = str(raw.at[i, mapping["drcr"]]).strip().upper() if "drcr" in mapping else ""
            if ind.startswith("D") or suf in ("DR", "D"):
                d = abs(a)
            elif ind.startswith("C") or suf in ("CR", "C"):
                c = abs(a)
            elif a < 0:
                d = -a
            else:
                c = a
        debit.append(d)
        credit.append(c)

    bal = []
    for v in get("balance"):
        b, suf = parse_amount(v)
        bal.append(-abs(b) if suf == "DR" else b)

    t = pd.DataFrame({"Date": dates, "Narration": narr, "Ref": ref,
                      "Debit": debit, "Credit": credit, "Balance": bal}, index=raw.index)

    # Opening balance row (no amount, has balance)
    opening = None
    ob = t[t["Narration"].str.upper().str.contains(r"OPENING BALANCE|BROUGHT FORWARD|^B/F|BAL B/F", regex=True)]
    if len(ob):
        opening = ob["Balance"].iloc[0]

    # Merge wrapped narration lines into the transaction above them
    keep = []
    last = None
    for i, r in t.iterrows():
        is_txn = pd.notna(r["Date"]) and (r["Debit"] or r["Credit"])
        if is_txn:
            keep.append(i)
            last = i
        elif last is not None and pd.isna(r["Date"]) and not (r["Debit"] or r["Credit"]) and r["Narration"] \
                and not re.search(r"(?i)page \d|total|closing balance|statement|opening balance", r["Narration"]):
            t.at[last, "Narration"] = (t.at[last, "Narration"] + " " + r["Narration"]).strip()
            if r["Ref"] and not t.at[last, "Ref"]:
                t.at[last, "Ref"] = r["Ref"]
    t = t.loc[keep].reset_index(drop=True)
    if t.empty:
        raise StatementError("No transactions found. Check the column mapping.")
    t["Narration"] = t["Narration"].replace("", "(no narration)")
    t.attrs["opening"] = opening
    if "balance" not in mapping:
        notes.append("No balance column found; balances were rebuilt from the transactions.")
    return t, mapping, notes


def balance_check(t: pd.DataFrame) -> tuple[pd.DataFrame, int, int, str]:
    """Verify every row against the running balance. Detects newest-first
    statements and reverses them. Returns (df oldest-first, checked, ok, text)."""
    if (t["Balance"] == 0).all():
        opening = t.attrs.get("opening") or 0.0
        t = t.sort_values("Date", kind="stable").reset_index(drop=True)
        t["Balance"] = opening + (t["Credit"] - t["Debit"]).cumsum()
        t["Balance OK"] = True
        return t, 0, 0, "No balance column - balances rebuilt from transactions"

    def ok_count(d):
        b = d["Balance"].values
        moves = (d["Credit"] - d["Debit"]).values
        return sum(abs(b[i - 1] + moves[i] - b[i]) < 0.05 for i in range(1, len(d)))

    fwd = ok_count(t)
    rev_df = t.iloc[::-1].reset_index(drop=True)
    rev = ok_count(rev_df)
    if rev > fwd:
        t, fwd = rev_df, rev
    b, moves = t["Balance"].values, (t["Credit"] - t["Debit"]).values
    t["Balance OK"] = [True] + [bool(abs(b[i - 1] + moves[i] - b[i]) < 0.05) for i in range(1, len(t))]
    n, ok = len(t), int(t["Balance OK"].sum())
    text = (f"Balance check passed: all {n} rows reconcile with the running balance" if ok == n
            else f"Balance check: {ok} of {n} rows reconcile ({ok / n * 100:.0f}%) - review highlighted rows")
    t = t.sort_values("Date", kind="stable").reset_index(drop=True)
    return t, n, ok, text


# ---------------------------------------------------------------------------
# File readers
# ---------------------------------------------------------------------------
def _rows_to_raw(rows: list[list], header_i: int) -> pd.DataFrame:
    header = [str(h).replace("\n", " ").strip() if h is not None else "" for h in rows[header_i]]
    seen = {}
    cols = []
    for h in header:  # make names unique
        h = h or "Column"
        seen[h] = seen.get(h, 0) + 1
        cols.append(h if seen[h] == 1 else f"{h} ({seen[h]})")
    width = len(cols)
    body = []
    for r in rows[header_i + 1:]:
        r = list(r)[:width] + [None] * max(0, width - len(r))
        if [str(x).strip() for x in r] == [str(x).strip() for x in rows[header_i]]:
            continue  # repeated header on a new page
        if all(x is None or str(x).strip() in ("", "nan", "None") for x in r):
            continue
        body.append([str(x).replace("\n", " ").strip() if isinstance(x, str) else x for x in r])
    return pd.DataFrame(body, columns=cols)


def _read_tabular(data: bytes, name: str) -> tuple[list[list], str]:
    """Return rows (list of lists) and file type for Excel/CSV/HTML-xls."""
    low = name.lower()
    if low.endswith((".xlsx", ".xlsm")):
        sheets = pd.read_excel(io.BytesIO(data), header=None, sheet_name=None)
        sheet = max(sheets.values(), key=len)
        return sheet.where(pd.notna(sheet), None).values.tolist(), "Excel (.xlsx)"
    if low.endswith(".xls"):
        try:
            sheets = pd.read_excel(io.BytesIO(data), header=None, sheet_name=None, engine="xlrd")
            sheet = max(sheets.values(), key=len)
            return sheet.where(pd.notna(sheet), None).values.tolist(), "Excel (.xls)"
        except Exception:
            tables = pd.read_html(io.BytesIO(data), header=None)   # many banks' ".xls" is HTML
            sheet = max(tables, key=len)
            return sheet.where(pd.notna(sheet), None).values.tolist(), "Excel (.xls, HTML type)"
    text = data.decode("utf-8-sig", errors="replace")
    try:
        dialect = csv.Sniffer().sniff(text[:5000], delimiters=",;\t|")
    except csv.Error:
        dialect = csv.excel
    return [r for r in csv.reader(io.StringIO(text), dialect)], "CSV / text"


def _from_rows(rows, file_type, top_text_extra="", header_row: int | None = None) -> ParseResult:
    hi = header_row - 1 if header_row else find_header_row(rows)
    if hi is None:
        err = StatementError("Could not find a header row with Date and Amount columns.")
        err.preview = pd.DataFrame(rows[:25])   # shown in the app so the user can pick the row
        raise err
    raw = _rows_to_raw(rows, hi)
    top = top_text_extra + " " + " ".join(str(x) for r in rows[:hi] for x in r if x is not None)
    return ParseResult(df=pd.DataFrame(), raw=raw, bank=detect_bank(top), file_type=file_type,
                       method=f"Header found on row {hi + 1}",
                       account_no=detect_account_no(" ".join(str(x) for r in rows[:hi] for x in r if x is not None)))


# ----- PDF ----------------------------------------------------------------
def _open_pdf(data: bytes, password: str | None):
    import pdfplumber
    from pdfminer.pdfdocument import PDFPasswordIncorrect
    locked, ok = pdf_password_status(data, password)
    if locked and not password:
        raise PasswordRequired("This PDF is password-protected.")
    if locked and not ok:
        raise PasswordRequired("The password is incorrect.")
    try:
        pdf = pdfplumber.open(io.BytesIO(data), password=password or "")
        _ = pdf.pages[0].chars
        return pdf
    except PDFPasswordIncorrect:
        raise PasswordRequired("This PDF is password-protected." if not password
                               else "The password is incorrect. Please try again.")
    except Exception as e:  # pdfminer raises different errors for some encryptions
        if "password" in str(e).lower() or "encrypt" in str(e).lower():
            raise PasswordRequired("This PDF is password-protected.")
        raise StatementError(f"Could not open PDF: {e}")


def pdf_password_status(data: bytes, password: str | None) -> tuple[bool, bool]:
    """(needs a password?, does the given password open it?)"""
    try:
        from pypdf import PdfReader
        r = PdfReader(io.BytesIO(data))
        if not r.is_encrypted or r.decrypt("") != 0:
            return False, True
        return True, bool(password) and r.decrypt(password) != 0
    except Exception:
        return False, True


def is_pdf_locked(data: bytes) -> bool:
    return pdf_password_status(data, None)[0]


def _pdf_tables(pdf) -> list[list]:
    rows = []
    for page in pdf.pages:
        for tb in page.extract_tables():
            rows.extend(tb)
    return rows


DATE_START = re.compile(
    r"^(\d{1,2}[/\-.](\d{1,2}|[A-Za-z]{3})[/\-.]\d{2,4})$|^\d{4}-\d{2}-\d{2}$")
MONTHS = {"jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "sept", "oct", "nov", "dec"}


def _lines(page, tol=3):
    words = page.extract_words(keep_blank_chars=False, x_tolerance=1.5, y_tolerance=2)
    words.sort(key=lambda w: (round(w["top"]), w["x0"]))
    lines, cur, top = [], [], None
    for w in words:
        if top is None or abs(w["top"] - top) <= tol:
            cur.append(w)
            top = w["top"] if top is None else top
        else:
            lines.append(sorted(cur, key=lambda w: w["x0"]))
            cur, top = [w], w["top"]
    if cur:
        lines.append(sorted(cur, key=lambda w: w["x0"]))
    return lines


def _leading_date(words):
    """Return (date_text, n_words_used) if the line starts with a date."""
    if not words:
        return None, 0
    w0 = words[0]["text"]
    if DATE_START.match(w0):
        return w0, 1
    if len(words) >= 3 and re.fullmatch(r"\d{1,2}", w0) and words[1]["text"].lower().strip(",") in MONTHS \
            and re.fullmatch(r"\d{2,4}", words[2]["text"]):
        return " ".join(w["text"] for w in words[:3]), 3
    return None, 0


def _header_columns(words) -> dict | None:
    """If this line is a column-header line, return x-centres of the amount
    columns, e.g. {'debit': 410, 'credit': 480, 'balance': 560}."""
    roles = [_role_of(w["text"]) for w in words]
    rs = set(roles)
    if not ("date" in rs and "balance" in rs and rs & {"debit", "credit", "amount"}):
        return None
    cols, i = {}, 0
    while i < len(words):
        r = roles[i]
        if r in ("debit", "credit", "balance", "amount", "drcr"):
            x0, x1, j = words[i]["x0"], words[i]["x1"], i + 1
            # extend label over following words like "Amt." / "(INR)"
            while j < len(words) and roles[j] in (None, "amount") and words[j]["x0"] - x1 < 12:
                x1, j = words[j]["x1"], j + 1
            if r not in cols:
                cols[r] = (x0 + x1) / 2
            i = j
        else:
            i += 1
    if "debit" in cols or "credit" in cols:
        cols.pop("amount", None)
    cols.pop("drcr", None)
    # horizontal span of the narration column (up to the next column's label)
    starts = [(w["x0"], r) for w, r in zip(words, roles) if r]
    narr = [x for x, r in starts if r == "narration"]
    span = None
    if narr:
        later = [x for x, r in starts if x > narr[0] + 1 and r != "narration"]
        span = (narr[0] - 4, (min(later) - 4) if later else 1e9)
    cols["_narr"] = span
    return cols


def _pdf_text_layout(pdf) -> tuple[pd.DataFrame, str]:
    """For statements without table borders: read word positions line by line."""
    cols = None
    span = None
    txns, opening = [], None
    header_text = ""
    for page in pdf.pages:
        for words in _lines(page):
            text = " ".join(w["text"] for w in words)
            hc = _header_columns(words)
            if hc:
                if cols is None:
                    span = hc.pop("_narr")
                    cols = hc
                continue
            in_span = (lambda w: span[0] <= w["x0"] < span[1]) if span else (lambda w: True)
            if cols is None and not txns:
                header_text += " " + text
            if re.search(r"(?i)opening balance|balance b/?f|brought forward", text):
                amts = [w for w in words if is_amount(w["text"]) and "." in w["text"]]
                if amts:
                    opening = parse_amount(amts[-1]["text"])[0]
                continue
            d, used = _leading_date(words)
            rest = words[used:]
            if d:
                d2, used2 = _leading_date(rest)   # value-date column
                if d2:
                    rest = rest[used2:]
                amt_words, narr_words = [], []
                for w in rest:
                    if is_amount(w["text"]) and "." in w["text"]:
                        amt_words.append(w)
                    elif w["text"].upper().strip(".") in ("CR", "DR") and amt_words:
                        amt_words[-1] = {**amt_words[-1], "text": amt_words[-1]["text"] + w["text"].upper().strip(".")}
                    elif not amt_words and in_span(w) and not (span is None and DATE_START.match(w["text"])):
                        narr_words.append(w)
                if not amt_words:
                    continue
                txns.append({"Date": d, "Narration": " ".join(w["text"] for w in narr_words),
                             "Debit": 0.0, "Credit": 0.0, "Balance": None, "_amts": amt_words})
            elif txns and not any(is_amount(w["text"]) and "." in w["text"] for w in words) \
                    and not re.search(r"(?i)page \d|statement|generated|total|closing balance|computer", text):
                extra = " ".join(w["text"] for w in words if in_span(w))
                if extra:
                    txns[-1]["Narration"] += " " + extra

    if not txns:
        raise StatementError("No transactions found in the PDF text.")

    # Assign each amount to Debit / Credit / Balance by its position under the
    # header; if there is no header, use the running balance to decide.
    prev = opening
    for t in txns:
        amts = t.pop("_amts")
        if cols and "balance" in cols and len(cols) >= 2:
            for w in amts:
                x = (w["x0"] + w["x1"]) / 2
                role = min(cols, key=lambda r: abs(cols[r] - x))
                val, suf = parse_amount(w["text"])
                if role == "balance":
                    t["Balance"] = -abs(val) if suf == "DR" else val
                elif role == "debit":
                    t["Debit"] = abs(val)
                elif role == "credit":
                    t["Credit"] = abs(val)
                elif suf in ("DR", "CR"):
                    t["Debit" if suf == "DR" else "Credit"] = abs(val)
                elif prev is not None and t["Balance"] is not None:
                    t["Credit" if t["Balance"] >= prev else "Debit"] = abs(val)
                else:
                    t["_amount"] = abs(val)
            if "_amount" in t:   # single amount column without Dr/Cr marker
                a = t.pop("_amount")
                t["Credit" if prev is not None and (t["Balance"] or 0) >= prev else "Debit"] = a
        else:
            vals = [parse_amount(w["text"]) for w in amts]
            bal, bsuf = vals[-1]
            t["Balance"] = -abs(bal) if bsuf == "DR" else bal
            if len(vals) >= 2:
                amt, suf = vals[-2]
                if suf in ("DR", "CR"):
                    t["Debit" if suf == "DR" else "Credit"] = abs(amt)
                elif prev is not None:
                    t["Credit" if t["Balance"] >= prev else "Debit"] = abs(amt)
                else:
                    t["Debit"] = abs(amt)
        prev = t["Balance"] if t["Balance"] is not None else prev

    raw = pd.DataFrame(txns)[["Date", "Narration", "Debit", "Credit", "Balance"]]
    if opening is not None:
        raw = pd.concat([pd.DataFrame([{"Date": None, "Narration": "OPENING BALANCE", "Debit": None,
                                        "Credit": None, "Balance": opening}]), raw], ignore_index=True)
    return raw, header_text


def _read_pdf(data: bytes, password: str | None) -> ParseResult:
    pdf = _open_pdf(data, password)
    try:
        if not any(p.chars for p in pdf.pages[:3]):
            raise StatementError("This PDF is a scanned image (no readable text). "
                                 "Please download the statement from net banking as a PDF/Excel, "
                                 "or use an OCR tool first.")
        first_text = pdf.pages[0].extract_text() or ""
        pages = len(pdf.pages)

        # 1) Tables with ruling lines
        rows = _pdf_tables(pdf)
        hi = find_header_row(rows) if rows else None
        if hi is not None:
            raw = _rows_to_raw(rows, hi)
            first_cell = str(rows[hi][0] or "").split("\n")[0]
            idx = first_text.find(first_cell) if first_cell else -1
            top = first_text[:idx] if idx > 0 else first_text[:1500]
            res = ParseResult(df=pd.DataFrame(), raw=raw, bank=detect_bank(top), file_type="PDF",
                              method="PDF table (ruled lines)", pages=pages, account_no=detect_account_no(top))
            try:
                standardise(raw)
                return res
            except StatementError:
                pass  # fall through to text layout

        # 2) Text layout (no borders)
        raw, header_text = _pdf_text_layout(pdf)
        top = header_text or first_text[:1500]
        return ParseResult(df=pd.DataFrame(), raw=raw, bank=detect_bank(top), account_no=detect_account_no(top),
                           file_type="PDF", method="PDF text layout (no table borders)", pages=pages)
    finally:
        pdf.close()


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------
def read_raw(data: bytes, name: str, password: str | None = None,
             header_row: int | None = None) -> ParseResult:
    """Read the file into a raw table (columns as in the statement)."""
    if name.lower().endswith(".pdf") or data[:5] == b"%PDF-":
        return _read_pdf(data, password)
    try:
        rows, ftype = _read_tabular(data, name)
    except Exception as e:
        raise StatementError(f"Could not read the file: {e}")
    return _from_rows(rows, ftype, top_text_extra=name, header_row=header_row)


def read_statement(data: bytes, name: str, password: str | None = None,
                   mapping: dict | None = None, res: ParseResult | None = None) -> ParseResult:
    res = res or read_raw(data, name, password)
    df, used, notes = standardise(res.raw, mapping)
    df, n, ok, text = balance_check(df)
    res.df, res.mapping, res.notes = df, used, notes
    res.rows_checked, res.rows_ok, res.balance_check = n, ok, text
    return res
