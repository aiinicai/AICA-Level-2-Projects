"""
analyzer.py  -  The analysis engine.

    load_statement()  read any bank statement (via parsers.py) and categorise
                      every transaction (via the keyword database)
    find_red_flags()  compliance checks
    summary(), income_summary(), deduction_hints(), ...  numbers for the screens
    client_query_letter(), to_excel()                    outputs
"""
from __future__ import annotations

import io
import re
from dataclasses import dataclass

import pandas as pd

import keywords_db as kdb
import parsers


def rs(x: float) -> str:
    """Indian number format: 1234567 -> Rs 12,34,567"""
    v = f"{abs(x):.0f}"
    if len(v) > 3:
        head = re.sub(r"(\d)(?=(\d\d)+$)", r"\1,", v[:-3])
        v = head + "," + v[-3:]
    return ("-" if x < 0 else "") + "Rs " + v


# ---------------------------------------------------------------------------
# 1. LOADING
# ---------------------------------------------------------------------------
def load_statement(file, password: str | None = None, mapping: dict | None = None,
                   keywords: pd.DataFrame | None = None, header_row: int | None = None,
                   name: str | None = None):
    """Read a statement (path, bytes or uploaded file) and return (df, ParseResult)."""
    if isinstance(file, str):
        name, data = name or file, open(file, "rb").read()
    elif isinstance(file, bytes):
        data = file
    else:
        name = getattr(file, "name", "statement")
        data = file.getvalue() if hasattr(file, "getvalue") else file.read()
    raw = parsers.read_raw(data, name or "statement", password, header_row)
    try:
        res = parsers.read_statement(data, name or "statement", password, mapping, res=raw)
    except parsers.StatementError as e:
        e.raw = raw.raw          # lets the app offer manual column mapping
        raise
    df = categorise(res.df, keywords)
    return df, res


# ---------------------------------------------------------------------------
# 2. CATEGORISATION  - mode from the narration, category from the keyword DB
# ---------------------------------------------------------------------------
def _has(text: str, kw: str) -> bool:
    """Keyword must start a word, so 'ATM' does not match 'TREATMENT'."""
    return re.search(r"(?<![A-Z])" + re.escape(kw), text) is not None


def detect_mode(narr: str) -> str:
    n = str(narr).upper()
    if _has(n, "CASH") or _has(n, "CDM") or _has(n, "CSH"):
        return "Cash"
    if _has(n, "ATM") or _has(n, "ATW") or _has(n, "NWD"):
        return "ATM"
    for m in ("UPI", "NEFT", "RTGS", "IMPS", "NACH", "ACH", "ECS", "CHQ", "CLG", "POS", "INB", "MB"):
        if _has(n, m):
            return {"NACH": "ACH", "ECS": "ACH", "CLG": "CHQ", "INB": "Net Banking", "MB": "Mobile Banking"}.get(m, m)
    return "Other"


def categorise(df: pd.DataFrame, keywords: pd.DataFrame | None = None) -> pd.DataFrame:
    df = df.copy()
    cat = kdb.Categoriser(keywords)
    df["Month"] = df["Date"].dt.strftime("%Y-%m")
    df["Mode"] = df["Narration"].apply(detect_mode)
    cats, kws = [], []
    for narr, cr, mode in zip(df["Narration"], df["Credit"], df["Mode"]):
        is_credit = cr > 0
        if mode == "Cash":
            c, k = ("Cash Deposit" if is_credit else "Cash Withdrawal"), "(cash in narration)"
        elif mode == "ATM" and not is_credit:
            c, k = "Cash Withdrawal", "(ATM)"
        else:
            c, k = cat.match(narr, is_credit)
            if c is None:
                c, k = ("Unidentified Credit" if is_credit else "Uncategorised Debit"), ""
        cats.append(c)
        kws.append(k)
    df["Category"] = cats
    df["Matched Keyword"] = kws
    return df


def uncategorised(df: pd.DataFrame) -> pd.DataFrame:
    """Narrations no keyword matched - grouped, biggest first, to help add keywords."""
    u = df[df["Category"].isin(["Unidentified Credit", "Uncategorised Debit"])].copy()
    if u.empty:
        return pd.DataFrame(columns=["Narration", "Side", "Count", "Amount"])
    u["Side"] = u["Credit"].gt(0).map({True: "Credit", False: "Debit"})
    u["Amount"] = u["Credit"] + u["Debit"]
    g = u.groupby(["Narration", "Side"]).agg(Count=("Amount", "size"), Amount=("Amount", "sum")).reset_index()
    return g.sort_values("Amount", ascending=False).reset_index(drop=True)


# ---------------------------------------------------------------------------
# 2b. COUNTERPARTIES - who the money came from / went to
# ---------------------------------------------------------------------------
NOISE_WORDS = {
    "NEFT", "RTGS", "IMPS", "UPI", "ACH", "NACH", "ECS", "CR", "DR", "POS", "TRF", "TRANSFER", "TFR",
    "INB", "MB", "BY", "TO", "FROM", "P2A", "P2M", "CMS", "CHQ", "CLG", "INWARD", "OUTWARD", "REF", "TXN",
    "IB", "FT", "NETBANKING", "MOB", "BIL", "BILLPAY", "ONL", "OF", "AC", "THE", "DIV", "SETTLEMENT",
    "PAYMENT", "PAYMENTS", "FUND", "FUNDS", "INST", "IMPSP2A", "NEFTCR", "NEFTDR", "OWN",
}
CAT_PARTY = {
    "Interest Income": "BANK (interest)", "Interest Paid": "BANK (interest)", "Bank Charges": "BANK (charges)",
    "Cheque Bounce Charges": "BANK (charges)", "TDS Deducted": "GOVT (tax)", "Taxes Paid": "GOVT (tax)",
    "Tax Refund": "GOVT (tax)", "Own Account Transfer": "OWN ACCOUNTS",
}
IFSC_LIKE = re.compile(r"^[A-Z]{4}0[A-Z0-9]{6}$")


def counterparty(narration: str, mode: str = "", category: str = "") -> str:
    """Best guess of the party name in a narration, e.g.
    'NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY APR' -> 'ACME TECHNOLOGIES PVT LTD'
    'UPI/123456789012/RAMESH KUMAR/ramesh@ybl'    -> 'RAMESH KUMAR'"""
    if category in CAT_PARTY:
        return CAT_PARTY[category]
    if mode == "Cash" or category in ("Cash Deposit", "Cash Withdrawal"):
        return "CASH"
    if mode == "ATM":
        return "CASH"
    n = str(narration).upper().replace("M/S", "MS ").replace("A/C", "AC")
    for seg in re.split(r"\s*[-/|:*\\]\s*|\s{2,}", n):
        words = [w.strip(".,()") for w in seg.split()]
        words = [w for w in words if w and w not in NOISE_WORDS and "@" not in w
                 and not re.search(r"\d{3,}", w) and not IFSC_LIKE.match(w)]
        name = " ".join(words).strip()
        if len(name) >= 3:
            return name[:40]
    return "OTHER"


def add_counterparties(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["Counterparty"] = [counterparty(n, m, c) for n, m, c in zip(df["Narration"], df["Mode"], df["Category"])]
    return df


GENERIC_PARTIES = {"CASH", "BANK (interest)", "BANK (charges)", "GOVT (tax)", "OWN ACCOUNTS", "SELF", "OTHER"}


def counterparty_summary(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby("Counterparty").agg(
        Received=("Credit", "sum"), Receipts=("Credit", lambda s: int((s > 0).sum())),
        Paid=("Debit", "sum"), Payments=("Debit", lambda s: int((s > 0).sum())),
        First=("Date", "min"), Last=("Date", "max"),
    ).reset_index()
    if "Account" in df:
        acc = df.groupby("Counterparty")["Account"].agg(lambda s: ", ".join(sorted(set(s))))
        g["Accounts"] = g["Counterparty"].map(acc)
    g["Net"] = g["Received"] - g["Paid"]
    g["Two-way"] = (g["Received"] > 0) & (g["Paid"] > 0) & ~g["Counterparty"].isin(GENERIC_PARTIES)
    g["Total"] = g["Received"] + g["Paid"]
    return g.sort_values("Total", ascending=False).drop(columns="Total").reset_index(drop=True)


# ---------------------------------------------------------------------------
# 2c. SEVERAL ACCOUNTS - combine, match transfers between own accounts
# ---------------------------------------------------------------------------
TRANSFER_HINT = re.compile(r"(?<![A-Z])(SELF|OWN|TRANSFER|TRF|TFR|SWEEP|FUND TRANSFER)", re.I)


def account_label(res, file_name: str, taken: set) -> str:
    short = {"State Bank of India": "SBI", "Punjab National Bank": "PNB", "Bank of Baroda": "BoB",
             "Kotak Mahindra Bank": "Kotak", "Union Bank of India": "Union Bank", "Bank of India": "BoI"}
    bank = "" if res.bank == "Not identified" else short.get(res.bank, res.bank.replace(" Bank", ""))
    if bank and res.account_no:
        label = f"{bank} ..{res.account_no}"
    elif res.account_no:
        label = f"A/c ..{res.account_no}"
    elif bank:
        label = bank
    else:
        label = re.sub(r"\.[^.]+$", "", file_name)[:25]
    base, i = label, 2
    while label in taken:
        label, i = f"{base} ({i})", i + 1
    taken.add(label)
    return label


def combine(frames: list[tuple[str, pd.DataFrame]]) -> pd.DataFrame:
    parts = []
    for label, d in frames:
        d = d.copy()
        d.insert(0, "Account", label)
        parts.append(d)
    out = pd.concat(parts, ignore_index=True)
    out["Transfer ID"] = ""
    return out.sort_values(["Date"], kind="stable").reset_index(drop=True)


def match_own_transfers(df: pd.DataFrame, max_days: int = 3, min_amount: float = 25_000) -> pd.DataFrame:
    """Pair a debit in one of the client's accounts with a credit of the same amount
    in another of his accounts within `max_days`. Pairs are accepted if either
    narration looks like a self transfer, or the amount is at least `min_amount`."""
    df = df.copy()
    if "Account" not in df or df["Account"].nunique() < 2:
        return df
    debits = df[df["Debit"] > 0].sort_values("Date")
    credits = df[df["Credit"] > 0]
    used, n = set(), 0
    for i, d in debits.iterrows():
        c = credits[(credits["Account"] != d["Account"]) & ((credits["Credit"] - d["Debit"]).abs() < 0.5)
                    & ((credits["Date"] - d["Date"]).dt.days.abs() <= max_days) & ~credits.index.isin(used)]
        if c.empty:
            continue
        j = (c["Date"] - d["Date"]).abs().idxmin()
        hint = TRANSFER_HINT.search(d["Narration"]) or TRANSFER_HINT.search(df.at[j, "Narration"])
        if not hint and d["Debit"] < min_amount:
            continue
        used.add(j)
        n += 1
        for k in (i, j):
            df.at[k, "Category"] = "Own Account Transfer"
            df.at[k, "Matched Keyword"] = "(matched transfer)"
            df.at[k, "Transfer ID"] = f"T{n}"
    return df


def own_transfers(df: pd.DataFrame) -> pd.DataFrame:
    if "Transfer ID" not in df:
        return pd.DataFrame()
    t = df[df["Transfer ID"] != ""]
    if t.empty:
        return pd.DataFrame()
    out = t[t["Debit"] > 0][["Transfer ID", "Date", "Account", "Narration", "Debit"]].rename(
        columns={"Date": "Paid on", "Account": "From account", "Narration": "Narration (from)", "Debit": "Amount"})
    to = t[t["Credit"] > 0][["Transfer ID", "Date", "Account", "Narration"]].rename(
        columns={"Date": "Received on", "Account": "To account", "Narration": "Narration (to)"})
    return out.merge(to, on="Transfer ID")


def account_summary(df: pd.DataFrame, results: dict) -> pd.DataFrame:
    rows = []
    for acc, d in df.groupby("Account", sort=False):
        r = results.get(acc)
        first = d.iloc[0]
        rows.append({
            "Account": acc, "Bank": r.bank if r else "", "File": getattr(r, "file_name", ""),
            "From": d["Date"].min(), "To": d["Date"].max(), "Transactions": len(d),
            "Opening balance": first["Balance"] - first["Credit"] + first["Debit"],
            "Credits": d["Credit"].sum(), "Debits": d["Debit"].sum(), "Closing balance": d["Balance"].iloc[-1],
            "Balance check": f"{r.rows_ok}/{r.rows_checked}" if r else "",
        })
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# 2d. MANUAL CATEGORY CHANGES
# ---------------------------------------------------------------------------
def txn_key(row) -> str:
    """Stable id of a transaction, used to remember manual category changes."""
    return "|".join([str(row.get("Account", "")), f"{row['Date']:%Y-%m-%d}", str(row["Narration"])[:80],
                     f"{row['Debit']:.2f}", f"{row['Credit']:.2f}", f"{row['Balance']:.2f}"])


def apply_overrides(df: pd.DataFrame, overrides: dict) -> pd.DataFrame:
    df = df.copy()
    df["Key"] = [txn_key(r) for _, r in df.iterrows()]
    if overrides:
        hit = df["Key"].isin(overrides.keys())
        df.loc[hit, "Category"] = df.loc[hit, "Key"].map(overrides)
        df.loc[hit, "Matched Keyword"] = "(changed manually)"
    return df


def suggest_keyword(narration: str) -> str:
    cp = counterparty(narration)
    return "" if cp == "OTHER" else cp


# ---------------------------------------------------------------------------
# 3. RED-FLAG / COMPLIANCE CHECKS
# ---------------------------------------------------------------------------
@dataclass
class Thresholds:
    """All limits are editable in the app sidebar. They are REVIEW TRIGGERS,
    not legal conclusions - always verify against the law in force."""
    single_cash_deposit: float = 50_000        # PAN quoting limit for cash deposit
    cash_receipt_limit: float = 2_00_000       # cash receipt limit per transaction
    aggregate_cash_deposit: float = 10_00_000  # bank SFT reporting (savings a/c, per FY)
    structuring_band_low: float = 40_000       # deposits just below the PAN limit
    high_value_txn: float = 5_00_000           # large single debit / credit
    unexplained_credit: float = 1_00_000       # credit from unidentified party


def find_red_flags(df: pd.DataFrame, t: Thresholds | None = None) -> pd.DataFrame:
    t = t or Thresholds()
    flags = []
    multi = "Account" in df and df["Account"].nunique() > 1

    def add(row, severity, flag, why, action):
        flags.append({
            "Date": row["Date"].strftime("%d-%m-%Y"),
            **({"Account": row["Account"]} if "Account" in row and multi else {}),
            "Narration": row["Narration"],
            "Amount": row["Credit"] if row["Credit"] > 0 else row["Debit"],
            "Severity": severity, "Flag": flag,
            "Why it matters": why, "Suggested action": action,
        })

    cash_dep = df[(df["Category"] == "Cash Deposit") & (df["Credit"] > 0)]

    for _, r in df.iterrows():
        amt_cr, amt_dr, cat = r["Credit"], r["Debit"], r["Category"]

        if cat == "Cash Deposit" and amt_cr >= t.cash_receipt_limit:
            add(r, "High", "Large cash deposit",
                f"Cash of {rs(amt_cr)} is at/above the {rs(t.cash_receipt_limit)} cash-receipt limit.",
                "Obtain source of cash with evidence; check cash-receipt restrictions.")
        elif cat == "Cash Deposit" and amt_cr >= t.single_cash_deposit:
            add(r, "Medium", "Cash deposit above PAN limit",
                f"Single cash deposit of {rs(amt_cr)} requires PAN quoting.",
                "Confirm source of cash; keep supporting records.")

        if cat == "Unidentified Credit" and amt_cr >= t.unexplained_credit:
            add(r, "High", "Unexplained credit",
                "Credit from an unidentified party may be questioned as unexplained income.",
                "Ask client for party name, nature and documentary proof.")

        if cat == "Loan Received":
            add(r, "Medium", "Loan / deposit received",
                "Loans must be accepted through banking channels and be explainable.",
                "Obtain loan confirmation, lender PAN and agreement.")

        if cat == "Cheque Bounce Charges":
            add(r, "Low", "Cheque bounced",
                "Indicates liquidity issues; may relate to a dishonoured cheque dispute.",
                "Ask client which cheque bounced and why.")

        if max(amt_cr, amt_dr) >= t.high_value_txn and cat not in ("Cash Deposit",):
            add(r, "Medium", "High-value transaction",
                f"Transaction of {rs(max(amt_cr, amt_dr))} may appear in the client's AIS/SFT.",
                "Match with AIS; collect supporting documents.")

        if cat == "Cash Withdrawal" and amt_dr >= 1_00_000:
            add(r, "Low", "Large cash withdrawal",
                "Large cash withdrawals should be explained (purpose / end use).",
                "Ask client the purpose of withdrawal.")

    # Possible structuring: several deposits just below PAN limit within 7 days
    band = cash_dep[(cash_dep["Credit"] >= t.structuring_band_low) &
                    (cash_dep["Credit"] < t.single_cash_deposit)].sort_values("Date")
    if len(band) >= 2:
        for i in range(len(band) - 1):
            window = band[(band["Date"] >= band.iloc[i]["Date"]) &
                          (band["Date"] <= band.iloc[i]["Date"] + pd.Timedelta(days=7))]
            if len(window) >= 2:
                r = window.iloc[0]
                flags.append({
                    "Date": r["Date"].strftime("%d-%m-%Y"),
                    "Narration": f"{len(window)} cash deposits between "
                                 f"{rs(t.structuring_band_low)}-{rs(t.single_cash_deposit)[3:]} within 7 days",
                    "Amount": window["Credit"].sum(), "Severity": "High",
                    "Flag": "Possible split cash deposits",
                    "Why it matters": "Repeated deposits just below the PAN limit can look like "
                                      "deliberate splitting to avoid reporting.",
                    "Suggested action": "Discuss with client; document the genuine reason.",
                })
                break

    total_cash = cash_dep["Credit"].sum()
    if total_cash >= t.aggregate_cash_deposit:
        flags.append({
            "Date": "Full period", "Narration": "Aggregate cash deposits",
            "Amount": total_cash, "Severity": "High",
            "Flag": "Cash deposits above reporting limit",
            "Why it matters": f"Total cash deposits {rs(total_cash)} exceed "
                              f"{rs(t.aggregate_cash_deposit)}; bank is likely to report this "
                              "(SFT) and it will appear in AIS.",
            "Suggested action": "Prepare cash-flow explanation before filing the return.",
        })

    out = pd.DataFrame(flags)
    if not out.empty and "Account" in out:
        out["Account"] = out["Account"].fillna("All accounts")
    if not out.empty:
        order = {"High": 0, "Medium": 1, "Low": 2}
        out = out.sort_values("Severity", key=lambda s: s.map(order)).reset_index(drop=True)
    return out


# ---------------------------------------------------------------------------
# 4. SUMMARIES (used by the dashboard, tax view and Excel export)
# ---------------------------------------------------------------------------
INCOME_CATS = ["Salary Income", "Pension Income", "Rent Received", "Professional / Business Receipts",
               "Interest Income", "Dividend Income"]
DEDUCTION_HINTS = {
    "Insurance Premium": "Life insurance / mediclaim premium - possible deduction (old regime)",
    "Children Tuition Fees": "Tuition fees - possible deduction (old regime)",
    "Home Loan EMI": "Home loan - principal & interest may be deductible (get lender certificate)",
    "Investments (Shares/MF/PPF/FD)": "Check PPF / ELSS / NPS / tax-saver FD (old regime); track capital gains",
    "Loan EMI (Other)": "Business vehicle loan? Interest may be a business expense - get loan statement",
    "TDS Deducted": "Claim TDS credit - match with Form 26AS / AIS",
    "Taxes Paid": "Advance tax / GST paid - verify challans",
}


def summary(df: pd.DataFrame) -> dict:
    groups = df.groupby("Account", sort=False) if "Account" in df else [("", df)]
    opening = closing = 0.0
    for _, d in groups:
        first = d.iloc[0]
        opening += float(first["Balance"] - first["Credit"] + first["Debit"])
        closing += float(d["Balance"].iloc[-1])
    own = df["Transfer ID"] != "" if "Transfer ID" in df else pd.Series(False, index=df.index)
    return {
        "period": f"{df['Date'].min():%d-%b-%Y} to {df['Date'].max():%d-%b-%Y}",
        "accounts": int(df["Account"].nunique()) if "Account" in df else 1,
        "transactions": int(len(df)),
        "opening_balance": opening,
        "total_credits": float(df["Credit"].sum()),
        "total_debits": float(df["Debit"].sum()),
        "closing_balance": closing,
        "cash_deposits": float(df.loc[df["Category"] == "Cash Deposit", "Credit"].sum()),
        "cash_withdrawals": float(df.loc[df["Category"] == "Cash Withdrawal", "Debit"].sum()),
        "own_transfers": float(df.loc[own, "Debit"].sum()),
    }


def category_totals(df: pd.DataFrame) -> pd.DataFrame:
    g = df.groupby("Category").agg(Credits=("Credit", "sum"), Debits=("Debit", "sum"),
                                   Count=("Narration", "count")).reset_index()
    g["Net"] = g["Credits"] - g["Debits"]
    return g.sort_values("Net", key=abs, ascending=False).reset_index(drop=True)


def monthly(df: pd.DataFrame) -> pd.DataFrame:
    return df.groupby("Month").agg(Credits=("Credit", "sum"),
                                   Debits=("Debit", "sum")).reset_index()


def income_summary(df: pd.DataFrame) -> pd.DataFrame:
    """Income heads a CA needs for the ITR."""
    # also picks up your own categories whose name contains "Income" or "Receipts"
    is_income = df["Category"].isin(INCOME_CATS) | df["Category"].str.contains(r"income|receipts", case=False)
    d = df[is_income & (df["Credit"] > 0)]
    return d.groupby("Category")["Credit"].agg(["sum", "count"]).rename(
        columns={"sum": "Amount", "count": "Entries"}).reset_index()


def deduction_hints(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for cat, hint in DEDUCTION_HINTS.items():
        amt = df.loc[df["Category"] == cat, "Debit"].sum()
        if amt > 0:
            rows.append({"Category": cat, "Amount": amt, "What to check": hint})
    return pd.DataFrame(rows)


def search(df: pd.DataFrame, keyword: str = "", min_amount: float = 0,
           txn_type: str = "any", category: str = "") -> pd.DataFrame:
    d = df.copy()
    if keyword:
        d = d[d["Narration"].str.contains(keyword, case=False, regex=False)]
    if category:
        d = d[d["Category"].str.contains(category, case=False, regex=False)]
    if txn_type == "credit":
        d = d[d["Credit"] > 0]
    elif txn_type == "debit":
        d = d[d["Debit"] > 0]
    if min_amount:
        d = d[(d["Credit"] >= min_amount) | (d["Debit"] >= min_amount)]
    return d


def client_query_letter(flags: pd.DataFrame, client_name: str = "Client") -> str:
    """Drafts the list of queries a CA office would send to the client."""
    if flags.empty:
        return f"Dear {client_name},\n\nWe have reviewed your bank statement and have no queries at this stage.\n\nRegards"
    lines = [f"Dear {client_name},", "",
             "While reviewing your bank statement for the purpose of filing your return, "
             "we need clarification on the following entries:", ""]
    for i, r in flags.iterrows():
        amt = rs(r["Amount"])
        acc = f"[{r['Account']}] " if "Account" in flags and r.get("Account") not in (None, "All accounts") else ""
        lines.append(f"{i + 1}. {acc}{r['Date']} - {r['Narration']} ({amt}): {r['Suggested action']}")
    lines += ["", "Kindly share the details and supporting documents at the earliest.",
              "", "Regards,", "For [CA Firm Name]"]
    return "\n".join(lines)


def to_excel(df: pd.DataFrame, flags: pd.DataFrame, info: dict | None = None,
             accounts: pd.DataFrame | None = None) -> bytes:
    """One-click Excel working paper for the file."""
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="openpyxl") as xw:
        s = {**(info or {}), **summary(df)}
        pd.DataFrame(list(s.items()), columns=["Item", "Value"]).to_excel(xw, sheet_name="Summary", index=False)
        if accounts is not None and not accounts.empty:
            a = accounts.copy()
            for c in ("From", "To"):
                a[c] = a[c].dt.strftime("%d-%m-%Y")
            a.to_excel(xw, sheet_name="Accounts", index=False)
        out = df.drop(columns=[c for c in ("Key", "Month") if c in df]).copy()
        out["Date"] = out["Date"].dt.strftime("%d-%m-%Y")
        out.to_excel(xw, sheet_name="Transactions", index=False)
        if "Counterparty" in df:
            cps = counterparty_summary(df)
            for c in ("First", "Last"):
                cps[c] = cps[c].dt.strftime("%d-%m-%Y")
            cps.to_excel(xw, sheet_name="Counterparties", index=False)
        ot = own_transfers(df)
        if not ot.empty:
            for c in ("Paid on", "Received on"):
                ot[c] = ot[c].dt.strftime("%d-%m-%Y")
            ot.to_excel(xw, sheet_name="Own Transfers", index=False)
        category_totals(df).to_excel(xw, sheet_name="Category Totals", index=False)
        income_summary(df).to_excel(xw, sheet_name="Income Heads", index=False)
        deduction_hints(df).to_excel(xw, sheet_name="Deduction Hints", index=False)
        monthly(df).to_excel(xw, sheet_name="Monthly", index=False)
        (flags if not flags.empty else pd.DataFrame({"Info": ["No red flags"]})).to_excel(
            xw, sheet_name="Red Flags", index=False)
        for ws in xw.book.worksheets:
            for col in ws.columns:
                width = max(len(str(c.value or "")) for c in col) + 2
                ws.column_dimensions[col[0].column_letter].width = min(width, 60)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# 6. FULL PIPELINE for one or more statements of the same client
# ---------------------------------------------------------------------------
def build_view(loaded: list, overrides: dict | None = None, match_transfers: bool = True,
               max_days: int = 3, min_amount: float = 25_000):
    """loaded: list of (file_name, categorised df, ParseResult).
    Returns (combined df, {account label: ParseResult})."""
    taken, frames, results = set(), [], {}
    for name, d, r in loaded:
        label = account_label(r, name, taken)
        r.file_name = name
        results[label] = r
        frames.append((label, d))
    df = combine(frames)
    if match_transfers:
        df = match_own_transfers(df, max_days, min_amount)
    df = apply_overrides(df, overrides or {})
    df = add_counterparties(df)
    return df, results
