"""
Creates specimen statements in different bank LAYOUTS to test and demonstrate
the multi-bank reader. All data is fictitious and every file is marked
"SPECIMEN - FICTITIOUS DATA".

  samples/Sample_A_SBI_layout_ruled_table.pdf     ruled table, wrapped descriptions, 2 pages
  samples/Sample_B_HDFC_layout_LOCKED.pdf         no table borders, password AICA2026
  samples/Sample_C_Kotak_layout_DrCr.xlsx         account details above table, single
                                                  Amount + Dr/Cr column, newest first
  samples/Sample_D_Suresh_Iyer_second_account_SBI.pdf   second account of Sample 1's client,
                                                  for the multi-account / own-transfer demo
"""
import csv
import io
import os
import random
from datetime import date, timedelta

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from pypdf import PdfReader, PdfWriter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfgen import canvas
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "samples")
os.makedirs(OUT, exist_ok=True)
SPECIMEN = "SPECIMEN STATEMENT - FICTITIOUS DATA FOR SOFTWARE DEMONSTRATION - NOT A REAL BANK RECORD"


def inr(x):
    s = f"{abs(x):.2f}"
    whole, dec = s.split(".")
    if len(whole) > 3:
        head = whole[:-3]
        head = ",".join([head[max(0, i - 2):i] for i in range(len(head), 0, -2)][::-1])
        whole = head + "," + whole[-3:]
    return whole + "." + dec


# ---------------------------------------------------------------- Sample A
def _ruled_pdf(path, title, info_lines, rows):
    doc = SimpleDocTemplate(path, pagesize=A4, leftMargin=12 * mm, rightMargin=12 * mm,
                            topMargin=12 * mm, bottomMargin=12 * mm)
    small = ParagraphStyle("s", fontName="Helvetica", fontSize=7.5, leading=9)
    head = ParagraphStyle("h", fontName="Helvetica-Bold", fontSize=11, leading=14)
    story = [
        Paragraph(SPECIMEN, ParagraphStyle("w", fontName="Helvetica-Bold", fontSize=8, textColor=colors.red)),
        Spacer(1, 4), Paragraph(title, head), Paragraph("<br/>".join(info_lines), small), Spacer(1, 6),
    ]
    data = [["Txn Date", "Value\nDate", "Description", "Ref No./Cheque\nNo.", "Debit", "Credit", "Balance"]]
    for r in rows:
        d = date(*map(int, r["Date"].split("-")[::-1])).strftime("%d %b %Y")
        narr = r["Narration"].replace("-", " - ")
        data.append([d, d, Paragraph(narr, small), r["Ref No"],
                     inr(float(r["Debit"])) if r["Debit"] else "",
                     inr(float(r["Credit"])) if r["Credit"] else "", inr(float(r["Balance"]))])
    t = Table(data, colWidths=[20 * mm, 20 * mm, 62 * mm, 24 * mm, 20 * mm, 20 * mm, 22 * mm], repeatRows=1)
    t.setStyle(TableStyle([
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#DCE6F2")),
        ("FONT", (0, 0), (-1, 0), "Helvetica-Bold", 7.5),
        ("FONT", (0, 1), (-1, -1), "Helvetica", 7.5),
        ("ALIGN", (4, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    story.append(t)
    doc.build(story)
    return path


def sample_a():
    lines = open(os.path.join(HERE, "sample_statement.csv")).read().splitlines()
    start = next(i for i, l in enumerate(lines) if l.startswith("Date,"))
    rows = list(csv.DictReader(lines[start:]))
    return _ruled_pdf(os.path.join(OUT, "Sample_A_SBI_layout_ruled_table.pdf"),
                      "Account Statement (layout modelled on State Bank of India)",
                      ["Account Name : MR. SURESH IYER (FICTITIOUS)", "Account Number : XXXXXXXX1234",
                       "Branch : DEMO BRANCH, CHENNAI", "Statement period : 01 Apr 2026 to 18 Sep 2026"], rows)


# ---------------------------------------------------------------- Sample D
def sample_d():
    """Suresh Iyer's SECOND account. Two entries mirror his first account
    (sample_statement.csv) so the app can match own-account transfers:
      10-06-2026  first a/c pays 2,00,000 'SELF-TRANSFER TO SBI A/C'  -> credit here
      13-07-2026  first a/c receives 2,50,000 'IMPS CR-UNKNOWN-...'   -> debit here"""
    ev = []
    for m in range(4, 10):
        ev.append((date(2026, m, 5), f"NEFT CR-ANIL MEHTA-RENT FLAT 2B {date(2026, m, 1):%b}".upper(), 0, 18000))
        ev.append((date(2026, m, 22), "UPI/MAHANAGAR GAS/GAS BILL", 1150 + m * 20, 0))
    ev += [
        (date(2026, 4, 15), "NEFT DR-SBI LIFE-PREMIUM POLICY 4471", 25000, 0),
        (date(2026, 5, 2), "NEFT DR-RAMESH KUMAR-SECURITY DEPOSIT REFUND", 50000, 0),
        (date(2026, 6, 10), "NEFT CR-SURESH IYER-OWN A/C FUND TRANSFER", 0, 200000),
        (date(2026, 6, 30), "INT CREDIT-SB INTEREST", 0, 1420),
        (date(2026, 7, 13), "IMPS DR-SELF-9876543210", 250000, 0),
        (date(2026, 8, 1), "TRF-FIXED DEPOSIT BOOKED A/C 8812", 100000, 0),
        (date(2026, 8, 20), "CASH DEPOSIT-SBI BRANCH ADYAR", 0, 30000),
        (date(2026, 9, 12), "UPI/RAMESH KUMAR/MAINTENANCE SHARE", 0, 6000),
        (date(2026, 9, 30), "INT CREDIT-SB INTEREST", 0, 1655),
    ]
    ev.sort(key=lambda e: e[0])
    bal, rows = 260000.0, []
    for i, (d, narr, dr, cr) in enumerate(ev, 1):
        bal += cr - dr
        rows.append({"Date": d.strftime("%d-%m-%Y"), "Narration": narr, "Ref No": f"SBI{550000 + i}",
                     "Debit": dr or "", "Credit": cr or "", "Balance": round(bal, 2)})
    return _ruled_pdf(os.path.join(OUT, "Sample_D_Suresh_Iyer_second_account_SBI.pdf"),
                      "Account Statement (layout modelled on State Bank of India)",
                      ["Account Name : MR. SURESH IYER (FICTITIOUS)", "Account Number : XXXXXXXX7788",
                       "Branch : DEMO BRANCH, ADYAR", "Statement period : 01 Apr 2026 to 30 Sep 2026"], rows)


# ---------------------------------------------------------------- Sample B
def sample_b():
    wb = load_workbook(os.path.join(HERE, "samples", "Sample_Statement_2_Dr_Kavita_Rao.xlsx"))
    ws = wb.active
    rows = [r for r in ws.iter_rows(min_row=2, values_only=True)]
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=landscape(A4))
    W, H = landscape(A4)
    X = {"date": 30, "narr": 95, "ref": 365, "vdt": 455, "wd": 600, "dep": 690, "bal": 800}

    def header(page):
        y = H - 30
        c.setFont("Helvetica-Bold", 8)
        c.setFillColor(colors.red)
        c.drawString(30, y, SPECIMEN)
        c.setFillColor(colors.black)
        if page == 1:
            c.setFont("Helvetica-Bold", 12)
            c.drawString(30, y - 20, "Statement of Account (layout modelled on HDFC Bank)")
            c.setFont("Helvetica", 8)
            for i, line in enumerate(["DR. KAVITA RAO (FICTITIOUS)", "Account No : XXXXXXXX5678",
                                      "Statement From : 01/04/2025  To : 31/03/2026",
                                      "Opening Balance : 4,50,000.00"]):
                c.drawString(30, y - 36 - i * 11, line)
            y -= 90
        else:
            y -= 18
        c.setFont("Helvetica-Bold", 8)
        c.drawString(X["date"], y, "Date")
        c.drawString(X["narr"], y, "Narration")
        c.drawString(X["ref"], y, "Chq./Ref.No.")
        c.drawString(X["vdt"], y, "Value Dt")
        c.drawRightString(X["wd"], y, "Withdrawal Amt.")
        c.drawRightString(X["dep"], y, "Deposit Amt.")
        c.drawRightString(X["bal"], y, "Closing Balance")
        c.line(28, y - 4, W - 28, y - 4)
        return y - 16

    page = 1
    y = header(page)
    c.setFont("Helvetica", 8)
    for n, (td, vd, narr, chq, wd, dep, bal) in enumerate(rows):
        lines = [narr[i:i + 44] for i in range(0, len(narr), 44)]
        if y - 11 * len(lines) < 40:
            c.setFont("Helvetica", 7)
            c.drawString(30, 25, f"Page {page}")
            c.showPage()
            page += 1
            y = header(page)
        c.setFont("Helvetica", 8)
        c.drawString(X["date"], y, td.strftime("%d/%m/%y"))
        c.drawString(X["narr"], y, lines[0])
        c.drawString(X["ref"], y, str(chq) if chq else f"{4000000000 + n * 7919:016d}"[-16:])
        c.drawString(X["vdt"], y, vd.strftime("%d/%m/%y"))
        if wd:
            c.drawRightString(X["wd"], y, inr(wd))
        if dep:
            c.drawRightString(X["dep"], y, inr(dep))
        c.drawRightString(X["bal"], y, inr(bal))
        for extra in lines[1:]:
            y -= 10
            c.drawString(X["narr"], y, extra)
        y -= 14
    c.setFont("Helvetica", 7)
    c.drawString(30, 25, f"Page {page}")
    c.save()

    reader = PdfReader(io.BytesIO(buf.getvalue()))
    writer = PdfWriter()
    for p in reader.pages:
        writer.add_page(p)
    writer.encrypt(user_password="AICA2026", owner_password="owner-AICA2026", algorithm="AES-256")
    path = os.path.join(OUT, "Sample_B_HDFC_layout_LOCKED.pdf")
    with open(path, "wb") as f:
        writer.write(f)
    return path


# ---------------------------------------------------------------- Sample C
def sample_c():
    random.seed(11)
    tx = []
    d0 = date(2026, 1, 1)
    bal = 220000.0
    events = []
    for m in range(3):
        base = date(2026, 1 + m, 1)
        events += [
            (base + timedelta(days=1), "NEFT-SHREE BALAJI ENTERPRISES-SALES RECEIPT", random.randrange(150000, 260000, 100), "Cr"),
            (base + timedelta(days=3), "NEFT-RAJ STEEL DISTRIBUTOR-PURCHASE", random.randrange(90000, 160000, 100), "Dr"),
            (base + timedelta(days=5), "CASH DEPOSIT-SELF-SHOP COLLECTION", random.randrange(30000, 48000, 500), "Cr"),
            (base + timedelta(days=7), "RTGS-AMBIKA HARDWARE-SALES RECEIPT", random.randrange(80000, 140000, 100), "Cr"),
            (base + timedelta(days=9), "IMPS-SHOP RENT-JAN" if m == 0 else "IMPS-SHOP RENT", 30000, "Dr"),
            (base + timedelta(days=10), "UPI-STAFF SALARY-RAVI", 15000, "Dr"),
            (base + timedelta(days=19), "GST PAYMENT-CBIC-GSTR3B", random.randrange(12000, 22000, 10), "Dr"),
            (base + timedelta(days=21), "UPI-SWIGGY-FOOD", random.randrange(300, 900, 10), "Dr"),
            (base + timedelta(days=24), "NEFT-KUMAR TRANSPORT-FREIGHT", random.randrange(8000, 15000, 50), "Dr"),
            (base + timedelta(days=26), "POS-HP PETROL PUMP-FUEL", random.randrange(2500, 4500, 10), "Dr"),
        ]
    events += [
        (date(2026, 2, 14), "NEFT-UNKNOWN PARTY-9988776655", 275000, "Cr"),
        (date(2026, 3, 5), "CASH WITHDRAWAL-SELF", 150000, "Dr"),
        (date(2026, 3, 20), "SMS CHGS-QTR", 17.70, "Dr"),
        (date(2026, 3, 31), "INT CR-SB INTEREST", 1245.00, "Cr"),
    ]
    events.sort(key=lambda e: e[0])
    for d, narr, amt, side in events:
        bal += amt if side == "Cr" else -amt
        tx.append((d, narr, amt, side, round(bal, 2)))

    wb = Workbook()
    ws = wb.active
    ws.title = "Account Statement"
    top = [
        [SPECIMEN],
        ["Account Statement (layout modelled on Kotak Mahindra Bank)"],
        [],
        ["Account Name", "M/S GANESH TRADERS (FICTITIOUS)"],
        ["Account No.", "XXXXXXXX9012"],
        ["Period", "01-01-2026 to 31-03-2026"],
        ["Currency", "INR"],
        [],
        ["Sl. No.", "Transaction Date", "Value Date", "Description", "Chq / Ref No.",
         "Amount", "Dr / Cr", "Balance", "Dr / Cr"],
    ]
    for r in top:
        ws.append(r)
    ws["A1"].font = Font(bold=True, color="C00000")
    for c in ws[9]:
        c.font = Font(bold=True)
        c.fill = PatternFill("solid", fgColor="DDEBF7")
    for i, (d, narr, amt, side, b) in enumerate(reversed(tx), 1):   # newest first, like many downloads
        ws.append([i, d.strftime("%d-%m-%Y"), d.strftime("%d-%m-%Y"), narr,
                   f"REF{700000 + i}", f"{amt:,.2f}", side.upper(), f"{b:,.2f}", "CR"])
    for col, w in zip("ABCDEFGHI", (8, 16, 12, 46, 14, 14, 8, 16, 8)):
        ws.column_dimensions[col].width = w
    path = os.path.join(OUT, "Sample_C_Kotak_layout_DrCr.xlsx")
    wb.save(path)
    return path


if __name__ == "__main__":
    for f in (sample_a(), sample_b(), sample_c(), sample_d()):
        print("Wrote", os.path.relpath(f, HERE))
    print("Password for Sample B: AICA2026")
