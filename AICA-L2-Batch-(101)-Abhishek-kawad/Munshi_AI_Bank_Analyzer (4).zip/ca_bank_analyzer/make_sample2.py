"""Generates a second demo statement: Sample_Statement_2_Dr_Kavita_Rao.xlsx

Profile : Dr. Kavita Rao, self-employed doctor running a clinic (fictitious)
Period  : Full FY 2025-26 (01-Apr-2025 to 31-Mar-2026)
Format  : Excel, with column names like a real bank export
          (Txn Date, Value Date, Particulars, Chq No, Withdrawal Amt,
           Deposit Amt, Closing Balance) - shows that the app auto-detects
           columns that differ from sample 1.
All names, banks and numbers are fictitious.
"""
import random
from datetime import date

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

random.seed(2026)
txns = []  # (date, particulars, chq, withdrawal, deposit)


def add(d, text, dr=0.0, cr=0.0, chq=""):
    txns.append((d, text, chq, round(dr, 2), round(cr, 2)))


def r(lo, hi, step=10):
    return random.randrange(lo, hi, step)


months = [(2025, m) for m in range(4, 13)] + [(2026, m) for m in range(1, 4)]
cash_big = {(2025, 7): 260000, (2025, 12): 310000, (2026, 3): 180000}

for i, (y, m) in enumerate(months):
    mon = date(y, m, 1).strftime("%b").upper()
    # --- Receipts from the practice
    add(date(y, m, 1), f"POS SETTLEMENT-HDFC MERCHANT-CLINIC CARD COLLECTION {mon}", cr=r(160000, 240000) + 0.5)
    add(date(y, m, 10), f"NEFT CR-APOLLO SPECIALITY HOSPITAL-CONSULTATION FEES {mon}", cr=r(120000, 150000, 500))
    add(date(y, m, 18), f"UPI SETTLEMENT-PHONEPE BUSINESS-CLINIC COLLECTION {mon}", cr=r(40000, 70000) + 0.75)
    cash = cash_big.get((y, m), r(25000, 38000, 500))
    add(date(y, m, 7), "CASH DEPOSIT-BRANCH JAYANAGAR-CLINIC COUNTER", cr=cash)

    # --- Practice expenses
    add(date(y, m, 3), "NEFT DR-SHANTI ESTATES-CLINIC RENT", dr=45000)
    add(date(y, m, 5), "NEFT DR-STAFF SALARY-NURSE PRIYA S", dr=22000)
    add(date(y, m, 5), "NEFT DR-STAFF SALARY-RECEPTIONIST ANIL K", dr=18000)
    add(date(y, m, 12), "NEFT DR-SRI SAI SURGICAL DISTRIBUTORS-SUPPLIES", dr=r(35000, 60000) + 0.4)
    add(date(y, m, 15), "UPI/BESCOM/ELECTRICITY BILL", dr=r(4000, 6500))
    add(date(y, m, 16), "UPI/AIRTEL/BROADBAND BILL", dr=1179)

    # --- Personal
    add(date(y, m, 20), "NEFT DR-HDFC CREDIT CARD-BILL PAYMENT", dr=r(30000, 80000) + 0.2)
    add(date(y, m, 22), "ACH DR-ICICI PRU MF SIP", dr=10000)
    add(date(y, m, 28), "UPI/BIGBASKET/GROCERY", dr=r(4000, 7000) + 0.6)
    if (y, m) >= (2025, 9):
        add(date(y, m, 25), "ACH DR-HDFC BANK-VEHICLE LOAN EMI", dr=28500)

# --- One-off events (these create the red flags / tax items for the demo)
add(date(2025, 4, 20), "NEFT DR-LIC OF INDIA-PREMIUM POLICY 7712", dr=48000)
add(date(2025, 5, 14), "TRF-PPF A/C DEPOSIT", dr=150000)
add(date(2025, 6, 9), "CASH DEPOSIT-CDM KORAMANGALA", cr=45000)
add(date(2025, 6, 10), "CASH DEPOSIT-CDM KORAMANGALA", cr=45000)
add(date(2025, 6, 11), "CASH DEPOSIT-CDM KORAMANGALA", cr=45000)
for d, amt in ((date(2025, 6, 13), 75000), (date(2025, 9, 13), 150000),
               (date(2025, 12, 13), 150000), (date(2026, 3, 13), 125000)):
    add(d, "NEFT DR-ADVANCE TAX-CHALLAN 280", dr=amt)
add(date(2025, 7, 22), "IMPS CR-RAJESH RAO-LOAN RECEIVED", cr=500000)
add(date(2025, 8, 6), "DIV-HDFC BANK LTD-FINAL DIVIDEND", cr=3800)
add(date(2025, 8, 18), "RTGS DR-KUN HYUNDAI MOTORS-VEHICLE PURCHASE MARGIN", dr=350000)
add(date(2025, 10, 3), "NEFT CR-M/S GLOBAL ENTERPRISES", cr=350000)
add(date(2025, 10, 18), "CASH WDL-SELF CHQ 118204", dr=300000, chq="118204")
add(date(2025, 11, 12), "UPI/STAR HEALTH/MEDICLAIM PREMIUM", dr=32400)
add(date(2025, 11, 21), "CHQ RETURN CHARGES-INSUFFICIENT FUNDS CHQ 118207", dr=590, chq="118207")
add(date(2026, 1, 10), "TRF-FIXED DEPOSIT BOOKED A/C 5501", dr=600000)
add(date(2026, 2, 6), "NEFT CR-ITD-INCOME TAX REFUND AY 2025-26", cr=18560)
for d, amt in ((date(2025, 6, 30), 2450.0), (date(2025, 9, 30), 3120.0),
               (date(2025, 12, 31), 2890.0), (date(2026, 3, 31), 3340.0)):
    add(d, "INT.PD-SB INTEREST", cr=amt)
add(date(2026, 3, 28), "INT.PD-FD INTEREST A/C 5501", cr=11250)

txns.sort(key=lambda t: t[0])

# --- Write Excel like a bank export
wb = Workbook()
ws = wb.active
ws.title = "Statement"
headers = ["Txn Date", "Value Date", "Particulars", "Chq No", "Withdrawal Amt", "Deposit Amt", "Closing Balance"]
ws.append(headers)
navy = PatternFill("solid", fgColor="14213D")
for c in ws[1]:
    c.font = Font(bold=True, color="FFFFFF")
    c.fill = navy
    c.alignment = Alignment(horizontal="center")

bal = 450000.0
low = bal
for d, text, chq, dr, cr in txns:
    bal = round(bal + cr - dr, 2)
    low = min(low, bal)
    ws.append([d, d, text, chq or None, dr or None, cr or None, bal])

thin = Side(style="thin", color="D9D9D9")
for row in ws.iter_rows(min_row=2):
    row[0].number_format = row[1].number_format = "DD/MM/YYYY"
    for c in row[4:7]:
        c.number_format = "#,##,##0.00"
    for c in row:
        c.border = Border(bottom=thin)
for col, w in zip("ABCDEFG", (12, 12, 58, 10, 16, 16, 18)):
    ws.column_dimensions[col].width = w
ws.freeze_panes = "A2"

out = "samples/Sample_Statement_2_Dr_Kavita_Rao.xlsx"
wb.save(out)
print(f"Wrote {out}: {len(txns)} rows, closing balance {bal:,.2f}, lowest balance {low:,.2f}")
