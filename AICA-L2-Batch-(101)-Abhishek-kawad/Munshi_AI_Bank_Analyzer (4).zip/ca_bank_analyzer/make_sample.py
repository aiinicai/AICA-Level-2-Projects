"""Generates a realistic sample bank statement (sample_statement.csv) for the demo.
All names and numbers are fictitious."""
import csv
import random
from datetime import date, timedelta

random.seed(7)
rows = []
start = date(2026, 4, 1)

fixed = [
    # (day_offset, narration, debit, credit)
    (0, "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY APR", 0, 125000),
    (2, "ACH DR-HDFC HOME LOAN EMI", 42000, 0),
    (3, "UPI/BIGBASKET/GROCERY", 3850, 0),
    (5, "CASH DEPOSIT-BRANCH ANNA NAGAR", 0, 180000),
    (7, "ATM WDL-CHENNAI T NAGAR", 20000, 0),
    (9, "UPI/TNEB/ELECTRICITY BILL", 2940, 0),
    (11, "NEFT DR-LIC OF INDIA-PREMIUM", 35000, 0),
    (14, "IMPS CR-RAMESH KUMAR-RENT RECEIVED", 0, 28000),
    (16, "UPI/SWIGGY/FOOD", 640, 0),
    (18, "RTGS DR-SHREE BUILDERS-PROPERTY ADVANCE", 500000, 0),
    (20, "CHQ RETURN CHARGES-INSUFFICIENT FUNDS", 590, 0),
    (22, "NEFT DR-ZERODHA BROKING-SHARES", 75000, 0),
    (25, "INT.PD-SB INTEREST", 0, 2140),
    (30, "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY MAY", 0, 125000),
    (32, "ACH DR-HDFC HOME LOAN EMI", 42000, 0),
    (34, "CASH DEPOSIT-CDM ADYAR", 0, 49000),
    (35, "CASH DEPOSIT-CDM ADYAR", 0, 49000),
    (36, "CASH DEPOSIT-CDM ADYAR", 0, 49000),
    (38, "UPI/AMAZON/SHOPPING", 12999, 0),
    (40, "IMPS CR-RAMESH KUMAR-RENT RECEIVED", 0, 28000),
    (43, "NEFT CR-XYZ CONSULTING-PROFESSIONAL FEES", 0, 90000),
    (45, "UPI/ICICI PRU/MUTUAL FUND SIP", 10000, 0),
    (47, "NEFT DR-ST JOSEPH SCHOOL-TUITION FEES", 45000, 0),
    (50, "ATM WDL-CHENNAI VELACHERY", 25000, 0),
    (55, "DIV-INFOSYS LTD-FINAL DIVIDEND", 0, 4300),
    (60, "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY JUN", 0, 125000),
    (62, "ACH DR-HDFC HOME LOAN EMI", 42000, 0),
    (64, "UPI/STAR HEALTH/MEDICLAIM PREMIUM", 24500, 0),
    (66, "CASH DEPOSIT-BRANCH ANNA NAGAR", 0, 300000),
    (68, "IMPS CR-RAMESH KUMAR-RENT RECEIVED", 0, 28000),
    (70, "NEFT DR-SELF-TRANSFER TO SBI A/C", 200000, 0),
    (72, "UPI/BIGBASKET/GROCERY", 4210, 0),
    (75, "NEFT CR-XYZ CONSULTING-PROFESSIONAL FEES", 0, 90000),
    (78, "TDS DEDUCTED ON FD INTEREST", 1200, 0),
    (79, "INT.PD-FD INTEREST", 0, 12000),
    (85, "UPI/IRCTC/TRAVEL", 6400, 0),
    (90, "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY JUL", 0, 125000),
    (92, "ACH DR-HDFC HOME LOAN EMI", 42000, 0),
    (95, "CASH WDL-SELF CHQ 004512", 100000, 0),
    (97, "IMPS CR-RAMESH KUMAR-RENT RECEIVED", 0, 28000),
    (100, "UPI/TNEB/ELECTRICITY BILL", 3320, 0),
    (103, "IMPS CR-UNKNOWN-9876543210", 0, 250000),
    (106, "NEFT CR-XYZ CONSULTING-PROFESSIONAL FEES", 0, 90000),
    (110, "GST PAYMENT-CBIC", 16200, 0),
    (115, "INT.PD-SB INTEREST", 0, 2380),
    (120, "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY AUG", 0, 125000),
    (122, "ACH DR-HDFC HOME LOAN EMI", 42000, 0),
    (125, "CASH DEPOSIT-BRANCH ANNA NAGAR", 0, 450000),
    (127, "IMPS CR-RAMESH KUMAR-RENT RECEIVED", 0, 28000),
    (130, "NEFT DR-ADVANCE TAX-CHALLAN 280", 60000, 0),
    (133, "UPI/SWIGGY/FOOD", 980, 0),
    (136, "NEFT CR-XYZ CONSULTING-PROFESSIONAL FEES", 0, 90000),
    (140, "UPI/AMAZON/SHOPPING", 8450, 0),
    (145, "ATM WDL-CHENNAI T NAGAR", 20000, 0),
    (150, "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY SEP", 0, 125000),
    (152, "ACH DR-HDFC HOME LOAN EMI", 42000, 0),
    (155, "IMPS CR-RAMESH KUMAR-RENT RECEIVED", 0, 28000),
    (158, "RTGS CR-SUNRISE TRADERS-LOAN RECEIVED", 0, 400000),
    (162, "NEFT DR-ZERODHA BROKING-SHARES", 150000, 0),
    (170, "UPI/BIGBASKET/GROCERY", 3990, 0),
]

balance = 385000.0
for i, (off, narr, dr, cr) in enumerate(fixed, 1):
    balance += cr - dr
    rows.append({
        "Date": (start + timedelta(days=off)).strftime("%d-%m-%Y"),
        "Narration": narr,
        "Ref No": f"TXN{100000 + i}",
        "Debit": dr if dr else "",
        "Credit": cr if cr else "",
        "Balance": round(balance, 2),
    })

with open("sample_statement.csv", "w", newline="") as f:
    f.write("SPECIMEN STATEMENT - FICTITIOUS DATA FOR SOFTWARE DEMONSTRATION\n")
    f.write("Account Name: MR. SURESH IYER (FICTITIOUS)\n")
    f.write("Account No: XXXXXXXX1234\n\n")
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
    w.writeheader()
    w.writerows(rows)
print(f"Wrote {len(rows)} rows, closing balance {balance:,.0f}")
