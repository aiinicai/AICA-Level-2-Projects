# Munshi AI - Smart Bank Statement Analyzer for CA Offices

AICA Level 2 (ICAI) - Capstone Project

Reads a client's bank statement(s) from **any bank, in PDF / Excel / CSV**, and in seconds:
- recognises the bank and its statement layout, and checks every row against the running balance
- shows opening balance, credits, debits, closing balance, cash deposited and cash withdrawn
- categorises every transaction using a **keyword database you control**; any category can be changed
  in the Transactions tab, with an option to remember it as a keyword
- combines **several accounts of one client** and matches transfers between the client's own accounts
- summarises **counterparties** (received from / paid to each party) and highlights two-way parties
- flags compliance red flags (large / split cash deposits, unexplained credits, loans, bounces, high-value items)
- prepares a Tax View: income heads for the ITR and possible deductions / TDS credits
- drafts a query letter to the client and exports a full Excel working paper

## Quick start on Windows

Double-click **Run_Munshi_AI.bat**. The first run installs the packages (2-5 minutes, needs internet);
after that it opens straight in your browser. Keep the black window open while using the app.

## How to run manually (Windows / Mac)

```
pip install -r requirements.txt
streamlit run app.py
```
The app opens at http://localhost:8501

## Statements it can read

| Input | Notes |
|---|---|
| PDF with table borders | e.g. SBI-type layouts |
| PDF without borders | e.g. HDFC-type layouts; columns found from header positions |
| Password-protected PDF | a password box appears automatically |
| Excel .xlsx / .xls | including ".xls" files that are really HTML (common in net banking) |
| CSV / TXT | comma, semicolon, tab or pipe separated |

It finds the header row even when account details sit above it, understands column names used by
Indian banks (Txn Date / Tran Date / Value Dt, Narration / Particulars / Transaction Remarks,
Withdrawal Amt. / DR / Debit, Deposit Amt. / CR / Credit, single Amount + Dr/Cr column, balances
like "12,345.00 Cr"), joins narrations that wrap over several lines, and handles newest-first
statements. The bank name is recognised from its name or IFSC code (40 banks).
If a file is read wrongly, the **Statement Info** tab lets you choose the header row and map columns yourself.
Scanned (image-only) PDFs need OCR first.

## Several accounts of one client

Select all the client's statements together in the upload box (or open the demo *Sample 1 + D*).
- One combined view: opening and closing balances are added across accounts
- A debit in one account and a credit of the same amount in another account within 3 days are matched
  as an **Own Account Transfer** (settings in the sidebar) and are not treated as income, expense or
  unexplained credit
- The **Accounts** tab lists each account and the matched pairs, with a balance chart per account

## Changing a category

In the **Transactions** tab pick a new category in the *Category* column (the column only offers names
from the list; to use a new name, first type it in **Need a category that is not in the list?** and click
**Add category** - it is saved for future use). Tick **Remember** to also save the
*Keyword* shown (edit it if needed) so future statements are categorised the same way, then click
**Save category changes**. Manual changes are remembered (in `keywords.db`) and can be undone.

## Counterparties tab

Party names are read from each narration (e.g. *NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY* → ACME TECHNOLOGIES PVT LTD).
The tab shows received and paid totals per party, highlights parties you both received from and paid to
(review for related parties, loans or circular movement) and lists any party's transactions.

## Keywords & Categories tab

- Shows the full keyword list (110+ built in); edit, add or delete rows and click Save
- Upload your own list from Excel/CSV (columns: Keyword, Category, Applies To, Priority) - add to or replace the list
- Lists the narrations in the current statement that no keyword matched, with one-click "add keyword"
- "Test a narration" shows which keyword and category a narration would get
- Keywords are stored in `keywords.db` (SQLite) next to the app, so they are remembered

## Files

| File | What it does |
|---|---|
| `app.py` | Streamlit screens (tabs, uploads, downloads) |
| `parsers.py` | Reads PDF / Excel / CSV from different banks, detects bank, header and columns, balance check |
| `keywords_db.py` | Keyword database and saved manual category changes |
| `analyzer.py` | Categorisation, counterparties, multi-account combining and transfer matching, red flags, summaries, client letter, Excel export |
| `sample_statement.csv` | Demo 1: salaried individual (CSV) |
| `samples/Sample_Statement_2_Dr_Kavita_Rao.xlsx` | Demo 2: doctor's clinic, full FY (Excel) |
| `samples/Sample_A_SBI_layout_ruled_table.pdf` | Demo A: PDF with table borders |
| `samples/Sample_B_HDFC_layout_LOCKED.pdf` | Demo B: PDF without borders, **password AICA2026** |
| `samples/Sample_C_Kotak_layout_DrCr.xlsx` | Demo C: account details above the table, Amount + Dr/Cr column, newest first |
| `samples/Sample_D_Suresh_Iyer_second_account_SBI.pdf` | Second account of Sample 1's client, for the multi-account demo |
| `samples/Sample_Keywords_Upload.xlsx` | Example keyword file to upload (fixes the uncategorised entries in Demo C) |
| `make_sample.py`, `make_sample2.py`, `make_test_statements.py` | Scripts that generated the demo files |

All sample statements are fictitious and marked as specimens.

## Disclaimer

Red-flag thresholds are configurable review triggers, not legal conclusions. Verify against the law in force
(including the Income-tax Act, 2025 where applicable). The output assists the CA and does not replace
professional judgement. Everything runs on your own computer; no statement data is sent anywhere.
