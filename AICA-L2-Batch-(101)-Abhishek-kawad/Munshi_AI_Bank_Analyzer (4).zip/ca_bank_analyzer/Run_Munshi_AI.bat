@echo off
title Munshi AI - Bank Statement Analyzer
color 1F
cd /d "%~dp0"

echo ============================================================
echo    MUNSHI AI - Smart Bank Statement Analyzer
echo    AICA Level 2 Project
echo ============================================================
echo.

REM ---- 1. Find Python ------------------------------------------------
set PY=
python --version >nul 2>&1
if not errorlevel 1 set PY=python
if not defined PY (
    py --version >nul 2>&1
    if not errorlevel 1 set PY=py
)
if not defined PY goto nopython

echo [1/3] Python found:
%PY% --version
echo.

REM ---- 2. Install packages only if missing (first run) -----------------
%PY% -c "import streamlit, pandas, openpyxl, pdfplumber, pypdf, xlrd, lxml" >nul 2>&1
if errorlevel 1 (
    echo [2/3] First run: installing required packages. This takes 2-5 minutes...
    echo.
    %PY% -m pip install --upgrade pip
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 goto installfail
) else (
    echo [2/3] Required packages already installed.
)
echo.

REM ---- Skip Streamlit's first-time email question ----------------------
if not exist "%USERPROFILE%\.streamlit" mkdir "%USERPROFILE%\.streamlit"
if not exist "%USERPROFILE%\.streamlit\credentials.toml" (
    echo [general]> "%USERPROFILE%\.streamlit\credentials.toml"
    echo email = "">> "%USERPROFILE%\.streamlit\credentials.toml"
)

REM ---- 3. Start the app ------------------------------------------------
echo [3/3] Starting Munshi AI... your browser will open automatically.
echo       If it does not, open http://localhost:8501
echo.
echo       KEEP THIS WINDOW OPEN while using the app.
echo       Close this window to stop the app.
echo ============================================================
echo.
%PY% -m streamlit run app.py --browser.gatherUsageStats false
echo.
echo The app has stopped.
pause
exit /b

:nopython
echo  Python is not installed on this computer.
echo.
echo  1. Download Python 3.10 or later from https://www.python.org/downloads/
echo  2. During installation TICK the box "Add Python to PATH"
echo  3. Then double-click this file again.
echo.
start https://www.python.org/downloads/
pause
exit /b

:installfail
echo.
echo  Package installation failed. Please check your internet connection
echo  and run this file again.
echo.
pause
exit /b
