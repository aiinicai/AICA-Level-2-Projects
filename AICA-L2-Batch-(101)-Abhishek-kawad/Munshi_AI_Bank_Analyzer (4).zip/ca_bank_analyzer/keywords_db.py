"""
keywords_db.py  -  The keyword database that decides each transaction's category.

Stored in a small SQLite file (keywords.db) next to the app, so keywords
you add or upload are remembered every time the app opens.

Table: keywords
    keyword     text that must appear in the bank narration (e.g. "SALARY")
    category    category to give the transaction (e.g. "Salary Income")
    applies_to  Credit / Debit / Both  - which side of the statement it applies to
    priority    lower number is checked first (use it to resolve clashes)
    source      Built-in / User

Matching rule: a keyword must START a word in the narration, so "EMI" matches
"HOME LOAN EMI" but not "PREMIUM", and "ATM" does not match "TREATMENT".
"""
from __future__ import annotations

import os
import re
import sqlite3

import pandas as pd

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "keywords.db")
COLUMNS = ["Keyword", "Category", "Applies To", "Priority", "Source"]
SIDES = ["Both", "Credit", "Debit"]

# Categories the red-flag checks look for. Renaming these breaks those checks.
SPECIAL_CATEGORIES = {
    "Cash Deposit": "set automatically from the narration (CASH / CDM)",
    "Cash Withdrawal": "set automatically from the narration (CASH WDL / ATM)",
    "Unidentified Credit": "any credit no keyword matched - large ones are red-flagged",
    "Uncategorised Debit": "any debit no keyword matched",
    "Loan Received": "red-flagged: obtain loan confirmation",
    "Cheque Bounce Charges": "red-flagged: ask which cheque bounced",
}

# (keyword, category, applies_to, priority). Lower priority is checked first.
# Order matters, e.g. TDS before INTEREST ("TDS ON FD INTEREST").
BUILT_IN = [
    # --- Income
    ("SALARY", "Salary Income", "Credit", 20), ("SAL CR", "Salary Income", "Credit", 20),
    ("PENSION", "Pension Income", "Credit", 20),
    ("SALARY", "Salary Paid", "Debit", 20), ("WAGES", "Salary Paid", "Debit", 20),
    ("RENT", "Rent Received", "Credit", 22), ("RENT", "Rent Paid", "Debit", 22),
    ("PROFESSIONAL FEES", "Professional / Business Receipts", "Credit", 24),
    ("CONSULT", "Professional / Business Receipts", "Credit", 24),
    ("SETTLEMENT", "Professional / Business Receipts", "Credit", 24),
    ("COLLECTION", "Professional / Business Receipts", "Credit", 24),
    ("PROFESSIONAL FEES", "Professional Fees Paid", "Debit", 24),
    ("TDS", "TDS Deducted", "Debit", 26), ("TDS", "TDS Refund", "Credit", 26),
    ("INT.PD", "Interest Income", "Credit", 28), ("INT PD", "Interest Income", "Credit", 28),
    ("INT CR", "Interest Income", "Credit", 28), ("INTEREST", "Interest Income", "Credit", 28),
    ("INTEREST", "Interest Paid", "Debit", 28),
    ("DIV-", "Dividend Income", "Credit", 30), ("DIVIDEND", "Dividend Income", "Credit", 30),
    ("ACH CR", "Dividend Income", "Credit", 31),
    ("REFUND", "Refund Received", "Credit", 60), ("CASHBACK", "Refund Received", "Credit", 60),
    ("REVERSAL", "Refund Received", "Credit", 60),
    # --- Loans
    ("LOAN RECEIVED", "Loan Received", "Credit", 32), ("LOAN DISB", "Loan Received", "Credit", 32),
    ("HOME LOAN", "Home Loan EMI", "Debit", 34), ("HOUSING LOAN", "Home Loan EMI", "Debit", 34),
    ("EMI", "Loan EMI (Other)", "Debit", 35), ("LOAN", "Loan EMI (Other)", "Debit", 36),
    # --- Insurance / deductions
    ("LIC", "Insurance Premium", "Debit", 38), ("INSURANCE", "Insurance Premium", "Debit", 38),
    ("PREMIUM", "Insurance Premium", "Debit", 38), ("MEDICLAIM", "Insurance Premium", "Debit", 38),
    ("STAR HEALTH", "Insurance Premium", "Debit", 38), ("HDFC LIFE", "Insurance Premium", "Debit", 38),
    ("SBI LIFE", "Insurance Premium", "Debit", 38), ("MAX LIFE", "Insurance Premium", "Debit", 38),
    ("INSURANCE", "Insurance Claim", "Credit", 38),
    ("TUITION", "Children Tuition Fees", "Debit", 40), ("SCHOOL", "Children Tuition Fees", "Debit", 40),
    # --- Investments
    ("ZERODHA", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("GROWW", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("UPSTOX", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("SHARES", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("MUTUAL FUND", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("MF SIP", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("SIP", "Investments (Shares/MF/PPF/FD)", "Debit", 43),
    ("BROKING", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("PPF", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("NPS", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("FIXED DEPOSIT", "Investments (Shares/MF/PPF/FD)", "Debit", 42),
    ("ZERODHA", "Investment Redemption", "Credit", 42), ("GROWW", "Investment Redemption", "Credit", 42),
    ("MUTUAL FUND", "Investment Redemption", "Credit", 42), ("REDEMPTION", "Investment Redemption", "Credit", 42),
    ("FD CLOSURE", "Investment Redemption", "Credit", 42),
    ("PROPERTY", "Property Purchase / Advance", "Debit", 44), ("BUILDERS", "Property Purchase / Advance", "Debit", 44),
    ("PROPERTY", "Property Sale Receipt", "Credit", 44),
    # --- Taxes
    ("ADVANCE TAX", "Taxes Paid", "Debit", 46), ("CHALLAN 280", "Taxes Paid", "Debit", 46),
    ("CBDT", "Taxes Paid", "Debit", 46), ("GST PAYMENT", "Taxes Paid", "Debit", 46),
    ("CBIC", "Taxes Paid", "Debit", 46), ("GSTN", "Taxes Paid", "Debit", 46),
    ("ITD", "Tax Refund", "Credit", 46), ("INCOME TAX REFUND", "Tax Refund", "Credit", 46),
    ("CPC", "Tax Refund", "Credit", 46),
    # --- Spending
    ("CREDIT CARD", "Credit Card Payment", "Debit", 48), ("CC PAYMENT", "Credit Card Payment", "Debit", 48),
    ("VEHICLE", "Vehicle Purchase", "Debit", 50),
    ("DISTRIBUTOR", "Business Purchases", "Debit", 52), ("SUPPLIES", "Business Purchases", "Debit", 52),
    ("SURGICAL", "Business Purchases", "Debit", 52), ("PHARMA", "Business Purchases", "Debit", 52),
    ("SELF", "Self Transfer Out", "Debit", 54), ("TRANSFER TO", "Self Transfer Out", "Debit", 54),
    ("SELF", "Self Transfer In", "Credit", 54), ("TRANSFER FROM", "Self Transfer In", "Credit", 54),
    ("CHQ RETURN", "Cheque Bounce Charges", "Debit", 56), ("RETURN CHARGES", "Cheque Bounce Charges", "Debit", 56),
    ("BOUNCE", "Cheque Bounce Charges", "Debit", 56),
    ("SMS CHG", "Bank Charges", "Debit", 57), ("CHARGES", "Bank Charges", "Debit", 58),
    ("ANNUAL FEE", "Bank Charges", "Debit", 58),
    ("GROCERY", "Household / Food", "Debit", 62), ("BIGBASKET", "Household / Food", "Debit", 62),
    ("SWIGGY", "Household / Food", "Debit", 62), ("ZOMATO", "Household / Food", "Debit", 62),
    ("BLINKIT", "Household / Food", "Debit", 62), ("FOOD", "Household / Food", "Debit", 62),
    ("ELECTRICITY", "Utilities", "Debit", 64), ("TNEB", "Utilities", "Debit", 64),
    ("BESCOM", "Utilities", "Debit", 64), ("MSEDCL", "Utilities", "Debit", 64),
    ("BROADBAND", "Utilities", "Debit", 64), ("RECHARGE", "Utilities", "Debit", 64),
    ("BILL", "Utilities", "Debit", 66),
    ("AMAZON", "Shopping", "Debit", 68), ("FLIPKART", "Shopping", "Debit", 68),
    ("MYNTRA", "Shopping", "Debit", 68), ("SHOPPING", "Shopping", "Debit", 68),
    ("IRCTC", "Travel", "Debit", 70), ("TRAVEL", "Travel", "Debit", 70),
    ("UBER", "Travel", "Debit", 70), ("OLA", "Travel", "Debit", 70),
    ("MAKEMYTRIP", "Travel", "Debit", 70), ("FUEL", "Travel", "Debit", 70),
]


# ---------------------------------------------------------------------------
def _connect():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS keywords (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        keyword TEXT NOT NULL, category TEXT NOT NULL,
        applies_to TEXT NOT NULL DEFAULT 'Both',
        priority INTEGER NOT NULL DEFAULT 10,
        source TEXT NOT NULL DEFAULT 'User')""")
    return con


def _builtin_frame() -> pd.DataFrame:
    return pd.DataFrame([(k, c, s, p, "Built-in") for k, c, s, p in BUILT_IN], columns=COLUMNS)


def clean(df: pd.DataFrame, default_source: str = "User") -> pd.DataFrame:
    """Validate a keyword table (from the editor or an uploaded file)."""
    df = df.copy()
    # accept loose column names in uploaded files
    rename = {}
    for c in df.columns:
        n = str(c).strip().lower().replace("_", " ")
        if n in ("keyword", "keywords", "key word", "narration contains", "text"):
            rename[c] = "Keyword"
        elif n in ("category", "categories", "head", "ledger"):
            rename[c] = "Category"
        elif n in ("applies to", "type", "side", "dr/cr", "credit/debit"):
            rename[c] = "Applies To"
        elif n in ("priority", "order"):
            rename[c] = "Priority"
        elif n == "source":
            rename[c] = "Source"
    df = df.rename(columns=rename)
    if "Keyword" not in df or "Category" not in df:
        raise ValueError("File must have at least two columns: Keyword and Category.")
    if "Applies To" not in df:
        df["Applies To"] = "Both"
    if "Priority" not in df:
        df["Priority"] = 10
    if "Source" not in df:
        df["Source"] = default_source

    df["Keyword"] = df["Keyword"].astype(str).str.strip().str.upper()
    df["Category"] = df["Category"].astype(str).str.strip()
    df = df[(df["Keyword"] != "") & (df["Keyword"] != "NAN") &
            (df["Category"] != "") & (df["Category"].str.lower() != "nan")]

    def side(v):
        v = str(v).strip().lower()
        if v.startswith(("cr", "dep", "rec", "in")):
            return "Credit"
        if v.startswith(("dr", "deb", "wit", "pay", "out")):
            return "Debit"
        return "Both"

    df["Applies To"] = df["Applies To"].map(side)
    df["Priority"] = pd.to_numeric(df["Priority"], errors="coerce").fillna(10).astype(int)
    df["Source"] = df["Source"].fillna(default_source).astype(str)
    df = df.drop_duplicates(subset=["Keyword", "Applies To"], keep="first")
    return df[COLUMNS].reset_index(drop=True)


def load() -> pd.DataFrame:
    """Return all keywords; seed with the built-in list the first time."""
    con = _connect()
    n = con.execute("SELECT COUNT(*) FROM keywords").fetchone()[0]
    con.close()
    if n == 0:
        save(_builtin_frame())
    con = _connect()
    df = pd.read_sql_query(
        "SELECT keyword AS 'Keyword', category AS 'Category', applies_to AS 'Applies To', "
        "priority AS 'Priority', source AS 'Source' FROM keywords ORDER BY priority, LENGTH(keyword) DESC", con)
    con.close()
    return df


def save(df: pd.DataFrame) -> int:
    """Replace the whole table with df. Returns rows saved."""
    df = clean(df)
    con = _connect()
    with con:
        con.execute("DELETE FROM keywords")
        con.executemany(
            "INSERT INTO keywords (keyword, category, applies_to, priority, source) VALUES (?,?,?,?,?)",
            df[COLUMNS].itertuples(index=False, name=None))
    con.close()
    return len(df)


def merge_upload(uploaded: pd.DataFrame, replace: bool = False) -> tuple[int, int]:
    """Add uploaded keywords. Uploaded rows win over existing ones with the same
    keyword and side. Returns (rows in upload, total rows now)."""
    new = clean(uploaded, default_source="User")
    if replace:
        return len(new), save(new)
    combined = pd.concat([new, load()], ignore_index=True)
    return len(new), save(combined)  # clean() keeps the first (uploaded) duplicate


def add_one(keyword: str, category: str, applies_to: str = "Both", priority: int = 10) -> int:
    row = pd.DataFrame([[keyword, category, applies_to, priority, "User"]], columns=COLUMNS)
    return merge_upload(row)[1]


def reset_to_builtin() -> int:
    return save(_builtin_frame())


def template() -> pd.DataFrame:
    return pd.DataFrame([
        ["SWIGGY", "Household / Food", "Debit", 10],
        ["ACME TECHNOLOGIES", "Salary Income", "Credit", 10],
        ["RAMESH KUMAR", "Rent Received", "Credit", 10],
        ["GODADDY", "Business Expenses", "Debit", 10],
    ], columns=["Keyword", "Category", "Applies To", "Priority"])


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------
class Categoriser:
    """Compiled keyword list - build once per statement for speed."""

    def __init__(self, kw: pd.DataFrame | None = None):
        kw = load() if kw is None else kw
        kw = kw.sort_values(["Priority"], kind="stable")
        kw = kw.assign(_len=kw["Keyword"].str.len()).sort_values(
            ["Priority", "_len"], ascending=[True, False], kind="stable")
        self.rules = [(re.compile(r"(?<![A-Z0-9])" + re.escape(k)), k, c, s)
                      for k, c, s in kw[["Keyword", "Category", "Applies To"]].itertuples(index=False)]

    def match(self, narration: str, is_credit: bool):
        """Return (category, keyword that matched) or (None, None)."""
        n = str(narration).upper()
        side = "Credit" if is_credit else "Debit"
        for rx, k, c, s in self.rules:
            if s in ("Both", side) and rx.search(n):
                return c, k
        # Fallback: PDFs often wrap a word across lines ("COL LECTION"),
        # so try again ignoring spaces (only for keywords of 5+ letters).
        squashed = re.sub(r"\s+", "", n)
        for rx, k, c, s in self.rules:
            kk = k.replace(" ", "")
            if s in ("Both", side) and len(kk) >= 5 and kk in squashed:
                return c, k
        return None, None


# ---------------------------------------------------------------------------
# Manual category changes (made in the Transactions tab)
# ---------------------------------------------------------------------------
def _ov_connect():
    con = sqlite3.connect(DB_PATH)
    con.execute("""CREATE TABLE IF NOT EXISTS overrides (
        txn_key TEXT PRIMARY KEY, category TEXT NOT NULL,
        changed_on TEXT DEFAULT CURRENT_TIMESTAMP)""")
    return con


def load_overrides() -> dict:
    con = _ov_connect()
    d = dict(con.execute("SELECT txn_key, category FROM overrides").fetchall())
    con.close()
    return d


def save_overrides(changes: dict) -> None:
    """changes: {txn_key: category}"""
    con = _ov_connect()
    with con:
        con.executemany("INSERT OR REPLACE INTO overrides (txn_key, category) VALUES (?, ?)", changes.items())
    con.close()


def clear_overrides(keys) -> int:
    keys = list(keys)
    con = _ov_connect()
    with con:
        con.executemany("DELETE FROM overrides WHERE txn_key = ?", [(k,) for k in keys])
    con.close()
    return len(keys)


# ---------------------------------------------------------------------------
# Your own categories (added from the Transactions or Keywords tab)
# ---------------------------------------------------------------------------
def _cat_connect():
    con = sqlite3.connect(DB_PATH)
    con.execute("CREATE TABLE IF NOT EXISTS categories (name TEXT PRIMARY KEY)")
    return con


def load_custom_categories() -> list:
    con = _cat_connect()
    names = [r[0] for r in con.execute("SELECT name FROM categories ORDER BY name")]
    con.close()
    return names


def add_category(name: str) -> str:
    name = " ".join(str(name).split())
    if name:
        con = _cat_connect()
        with con:
            con.execute("INSERT OR IGNORE INTO categories (name) VALUES (?)", (name,))
        con.close()
    return name
