"""
app.py  -  "Munshi AI": Smart Bank Statement Analyzer for CA offices.
Run with:   streamlit run app.py
"""
import io
import os

import pandas as pd
import streamlit as st

import analyzer as az
import keywords_db as kdb
import parsers

HERE = os.path.dirname(os.path.abspath(__file__))
st.set_page_config(page_title="Munshi AI - Bank Statement Analyzer", page_icon="📊", layout="wide")
rs = az.rs

DEMOS = {  # label: ([files], client name)
    "Sample 1 - Salaried individual (CSV)": (["sample_statement.csv"], "Mr. Suresh Iyer"),
    "Sample 1 + D - Same client, TWO accounts (CSV + PDF)": (
        ["sample_statement.csv", "samples/Sample_D_Suresh_Iyer_second_account_SBI.pdf"], "Mr. Suresh Iyer"),
    "Sample 2 - Doctor's clinic, full FY (Excel)": (["samples/Sample_Statement_2_Dr_Kavita_Rao.xlsx"], "Dr. Kavita Rao"),
    "Sample A - SBI layout, ruled table (PDF)": (["samples/Sample_A_SBI_layout_ruled_table.pdf"], "Mr. Suresh Iyer"),
    "Sample B - HDFC layout, LOCKED (PDF, password AICA2026)": (["samples/Sample_B_HDFC_layout_LOCKED.pdf"], "Dr. Kavita Rao"),
    "Sample C - Kotak layout, Dr/Cr column (Excel)": (["samples/Sample_C_Kotak_layout_DrCr.xlsx"], "M/s Ganesh Traders"),
}


@st.cache_data(show_spinner="Reading statement...")
def load(data: bytes, name: str, password, mapping_items, header_row, kw: pd.DataFrame):
    mapping = dict(mapping_items) if mapping_items else None
    return az.load_statement(data, password, mapping, kw, header_row, name=name)


def to_xlsx(df: pd.DataFrame) -> bytes:
    buf = io.BytesIO()
    df.to_excel(buf, index=False)
    return buf.getvalue()


def file_keys(name, data):
    return f"map_{name}_{len(data)}", f"hdr_{name}_{len(data)}"


MONEY = st.column_config.NumberColumn(format="%.2f")
DATE = st.column_config.DateColumn(format="DD-MM-YYYY")

# ----------------------------- SIDEBAR --------------------------------------
st.sidebar.title("📊 Munshi AI")
st.sidebar.caption("Smart Bank Statement Analyzer for CA offices")

uploads = st.sidebar.file_uploader("Upload bank statement(s)", type=["pdf", "xlsx", "xls", "csv", "txt"],
                                   accept_multiple_files=True,
                                   help="PDF (including password-protected), Excel or CSV from any bank. "
                                        "Select several files to combine all accounts of one client.")
if not uploads:
    demo = st.sidebar.selectbox("...or open a demo statement", list(DEMOS), index=0)
    paths, default_client = DEMOS[demo]
    files = [(os.path.basename(p), open(os.path.join(HERE, p), "rb").read()) for p in paths]
else:
    files, default_client = [(u.name, u.getvalue()) for u in uploads], ""

passwords = {}
for name, data in files:
    if name.lower().endswith(".pdf") and parsers.is_pdf_locked(data):
        passwords[name] = st.sidebar.text_input(f"🔒 Password for {name}", type="password", key=f"pw_{name}",
                                                help="Banks usually mention the password format in the e-mail "
                                                     "that carried the statement.") or None

client_name = st.sidebar.text_input("Client name", default_client,
                                    key=f"client_{'_'.join(n for n, _ in files)}") or "Client"

with st.sidebar.expander("⚙️ Red-flag thresholds (Rs)"):
    t = az.Thresholds(
        single_cash_deposit=st.number_input("Single cash deposit (PAN limit)", value=50_000, step=5_000),
        cash_receipt_limit=st.number_input("Cash receipt limit", value=2_00_000, step=10_000),
        aggregate_cash_deposit=st.number_input("Aggregate cash deposits (reporting)", value=10_00_000, step=50_000),
        structuring_band_low=st.number_input("Split-deposit band starts at", value=40_000, step=5_000),
        high_value_txn=st.number_input("High-value transaction", value=5_00_000, step=50_000),
        unexplained_credit=st.number_input("Unexplained credit", value=1_00_000, step=10_000),
    )
    st.caption("These are review triggers. Verify against the law in force.")

with st.sidebar.expander("🔁 Own-account transfer matching"):
    match_on = st.toggle("Match transfers between the client's accounts", value=True)
    max_days = st.number_input("Allowed gap between debit and credit (days)", 0, 15, 3)
    min_amt_match = st.number_input("Match without a 'SELF / TRANSFER' word if amount is at least",
                                    value=25_000, step=5_000)
    st.caption("A debit in one account is paired with a credit of the same amount in another account "
               "of this client. Review the pairs in the Accounts tab.")

# ----------------------------- LOAD -----------------------------------------
kw = kdb.load()
overrides = kdb.load_overrides()
loaded, problems = [], {}          # problems: name -> (kind, message, preview, raw)
for name, data in files:
    map_key, hdr_key = file_keys(name, data)
    mapping, header_row = st.session_state.get(map_key), st.session_state.get(hdr_key)
    try:
        d, r = load(data, name, passwords.get(name), tuple(sorted(mapping.items())) if mapping else None,
                    header_row, kw)
        loaded.append((name, d, r))
    except parsers.PasswordRequired as e:
        problems[name] = ("password", str(e), None, None)
    except parsers.StatementError as e:
        problems[name] = ("format", str(e), getattr(e, "preview", None), getattr(e, "raw", None))
    except Exception as e:  # unexpected - show, don't crash
        problems[name] = ("format", f"Could not read this file: {e}", None, None)

df = None
results = {}
if loaded:
    df, results = az.build_view(loaded, overrides, match_on, int(max_days), float(min_amt_match))
    flags = az.find_red_flags(df, t)
    s = az.summary(df)
    multi = s["accounts"] > 1

st.title(f"📊 Bank Statement Analysis - {client_name}" if df is not None else "📊 Munshi AI - Bank Statement Analyzer")
for name, (kind, msg, _, _) in problems.items():
    if kind == "password":
        st.warning(f"🔒 **{name}**: {msg} Please enter its password in the sidebar.")
    else:
        st.error(f"⚠️ **{name}**: {msg} Open the **Statement Info** tab to fix the header row or columns.")

if df is not None:
    all_ok = all(r.rows_ok == r.rows_checked for r in results.values())
    if multi:
        head = f"🏦 {s['accounts']} accounts: {', '.join(results)}"
        check = "✅ all balances reconcile" if all_ok else "⚠️ some rows do not reconcile - see Accounts tab"
    else:
        r = next(iter(results.values()))
        bank = r.bank if r.bank != "Not identified" else "Bank not identified"
        head = f"🏦 {bank}{f'  •  A/c ..{r.account_no}' if r.account_no else ''}  •  {r.file_type}" \
               f"{f' ({r.pages} pages)' if r.pages else ''}"
        check = ("✅ " if all_ok else "⚠️ ") + r.balance_check
    st.caption(f"{head}  •  {s['period']}  •  {s['transactions']} transactions  •  {check}")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Opening balance", rs(s["opening_balance"]))
    c2.metric("Total credits", rs(s["total_credits"]))
    c3.metric("Total debits", rs(s["total_debits"]))
    c4.metric("Closing balance", rs(s["closing_balance"]))
    c5, c6, c7, c8 = st.columns(4)
    c5.metric("Cash deposited", rs(s["cash_deposits"]))
    c6.metric("Cash withdrawn", rs(s["cash_withdrawals"]))
    if multi:
        c7.metric("Own-account transfers", rs(s["own_transfers"]),
                  f"{(df['Transfer ID'] != '').sum() // 2} pairs matched", delta_color="off", delta_arrow="off")
    else:
        c7.metric("Transactions", s["transactions"])
    c8.metric("Red flags", f"{len(flags)}", f"{(flags['Severity'] == 'High').sum() if not flags.empty else 0} high",
              delta_color="inverse")

tabs = st.tabs(["📈 Dashboard", "📄 Transactions", "🚩 Red Flags", "🧾 Tax View", "👥 Counterparties",
                "🏦 Accounts", "✉️ Client Letter", "🏷️ Keywords & Categories", "🔍 Statement Info"])
(tab_dash, tab_txn, tab_flags, tab_tax, tab_cp, tab_acc, tab_letter, tab_kw, tab_info) = tabs


def need_data():
    st.info("Load a statement to see this tab.")


categories = sorted(set(kw["Category"]) | set(kdb.SPECIAL_CATEGORIES) | {"Own Account Transfer"}
                    | (set(df["Category"]) if df is not None else set())
                    | set(kdb.load_custom_categories()))

# ----------------------------- DASHBOARD ------------------------------------
with tab_dash:
    if df is None:
        need_data()
    else:
        left, right = st.columns(2)
        with left:
            st.subheader("Month-wise inflow vs outflow")
            st.bar_chart(az.monthly(df).set_index("Month"), stack=False)
        with right:
            st.subheader("Top categories")
            cats = az.category_totals(df)
            cats["Amount"] = cats["Credits"] + cats["Debits"]
            top10 = cats.nlargest(10, "Amount").set_index("Category")["Amount"]
            st.bar_chart(top10, horizontal=True, sort="-Amount")
        st.subheader("Mode of transactions")
        st.dataframe(df.groupby("Mode").agg(Count=("Narration", "count"), Credits=("Credit", "sum"),
                                            Debits=("Debit", "sum")), width="stretch",
                     column_config={"Credits": MONEY, "Debits": MONEY})

# ----------------------------- TRANSACTIONS ---------------------------------
with tab_txn:
    if df is None:
        need_data()
    else:
        if multi:
            f0, f1, f2, f3, f4 = st.columns([1.3, 2, 2, 1, 1])
            acc_pick = f0.multiselect("Account", list(results))
        else:
            f1, f2, f3, f4 = st.columns([2, 2, 1, 1])
            acc_pick = []
        cat_pick = f1.multiselect("Category", sorted(df["Category"].unique()))
        kw_search = f2.text_input("Search narration")
        min_amt = f3.number_input("Minimum amount", value=0, step=10_000)
        only_bad = f4.checkbox("Balance mismatches only", help="Rows where the running balance does not reconcile")
        view = az.search(df, kw_search, min_amt)
        if acc_pick:
            view = view[view["Account"].isin(acc_pick)]
        if cat_pick:
            view = view[view["Category"].isin(cat_pick)]
        if only_bad:
            view = view[~view["Balance OK"]]

        st.markdown("**To change a category:** pick a new one in the *Category* column. Tick **Remember** to also "
                    "save the *Keyword* (edit it if needed) so future statements get this category automatically. "
                    "Then click **Save category changes**.")
        with st.form("add_category", clear_on_submit=True, border=False):
            nc1, nc2, _ = st.columns([2.2, 1, 2.8], vertical_alignment="bottom")
            new_cat_name = nc1.text_input("Need a category that is not in the list?",
                                          placeholder="e.g. Gift from Relative")
            if nc2.form_submit_button("➕ Add category") and new_cat_name.strip():
                if new_cat_name.strip().lower() in {c.lower() for c in categories}:
                    st.session_state["cat_msg"] = ("info", f"'{new_cat_name.strip()}' is already in the list.")
                else:
                    added = kdb.add_category(new_cat_name)
                    st.session_state["cat_msg"] = ("success", f"Added category **{added}**. "
                                                   "Now pick it in the Category column below and click Save.")
                st.session_state["txn_ver"] = st.session_state.get("txn_ver", 0) + 1   # refresh the table
                st.rerun()
        if "cat_msg" in st.session_state:
            kind, msg = st.session_state.pop("cat_msg")
            getattr(st, kind)(msg)

        base = view.set_index("Key")
        ed = pd.DataFrame(index=base.index)
        if multi:
            ed["Account"] = base["Account"]
        ed["Date"] = base["Date"]
        ed["Narration"] = base["Narration"]
        ed["Debit"] = base["Debit"]
        ed["Credit"] = base["Credit"]
        ed["Category"] = base["Category"]
        ed["Remember"] = False
        ed["Keyword"] = [az.suggest_keyword(n) for n in base["Narration"]]
        ed["Decided by"] = base["Matched Keyword"]
        ed["Counterparty"] = base["Counterparty"]
        ed["Balance"] = base["Balance"]
        ed["Bal ✓"] = base["Balance OK"].map({True: "✓", False: "✗"})
        ver = st.session_state.get("txn_ver", 0)          # bumped after each save -> fresh table
        sig = f"{acc_pick}{cat_pick}{kw_search}{min_amt}{only_bad}{len(df)}{ver}"
        edited = st.data_editor(
            ed, hide_index=True, width="stretch", height=min(560, 38 + 35 * max(len(ed), 1)),
            key=f"txn_editor_{hash(sig)}",
            disabled=[c for c in ed.columns if c not in ("Category", "Remember", "Keyword")],
            column_config={"Date": DATE, "Debit": MONEY, "Credit": MONEY, "Balance": MONEY,
                           "Narration": st.column_config.TextColumn(width="large"),
                           "Category": st.column_config.SelectboxColumn(options=categories, required=True,
                                                                        width="medium"),
                           "Remember": st.column_config.CheckboxColumn(help="Also save the keyword for future"),
                           "Keyword": st.column_config.TextColumn(help="Text from the narration to remember"),
                           "Bal ✓": st.column_config.TextColumn(width="small",
                                                                help="✗ = running balance does not reconcile")})
        changed = edited.index[edited["Category"] != ed["Category"]]
        remember = edited.index[edited["Remember"]]
        b1, b2, b3 = st.columns([1.3, 1.3, 3])
        if b1.button(f"💾 Save category changes ({len(changed)})", type="primary",
                     disabled=len(changed) == 0 and len(remember) == 0):
            kdb.save_overrides({k: edited.at[k, "Category"] for k in changed})
            added = []
            for k in remember:
                word = str(edited.at[k, "Keyword"] or "").strip()
                if word:
                    side = "Credit" if edited.at[k, "Credit"] > 0 else "Debit"
                    kdb.add_one(word, edited.at[k, "Category"], side)
                    added.append(word.upper())
            st.session_state["txn_ver"] = ver + 1
            st.toast(f"Saved {len(changed)} change(s)" + (f"; remembered keyword(s): {', '.join(added)}" if added else ""))
            st.rerun()
        manual_here = [k for k in df["Key"] if k in overrides]
        if manual_here and b2.button(f"↺ Undo manual changes ({len(manual_here)})"):
            kdb.clear_overrides(manual_here)
            st.session_state["txn_ver"] = ver + 1
            st.rerun()
        st.caption(f"{len(view)} rows • In {rs(view['Credit'].sum())} • Out {rs(view['Debit'].sum())}  •  "
                   "'Decided by' shows the keyword, transfer match or manual change behind each category.")

# ----------------------------- RED FLAGS ------------------------------------
with tab_flags:
    if df is None:
        need_data()
    elif flags.empty:
        st.success("No red flags found with the current thresholds.")
    else:
        for sev, colour in (("High", "🔴"), ("Medium", "🟠"), ("Low", "🟡")):
            part = flags[flags["Severity"] == sev]
            if not part.empty:
                st.markdown(f"### {colour} {sev} ({len(part)})")
                st.dataframe(part.drop(columns=["Severity"]), width="stretch", hide_index=True,
                             column_config={"Amount": MONEY})

# ----------------------------- TAX VIEW -------------------------------------
with tab_tax:
    if df is None:
        need_data()
    else:
        a, b = st.columns(2)
        with a:
            st.subheader("Income heads seen in bank")
            st.dataframe(az.income_summary(df), hide_index=True, width="stretch", column_config={"Amount": MONEY})
            st.caption("Match with Form 26AS / AIS before filing. Own-account transfers are excluded.")
        with b:
            st.subheader("Possible deductions & tax credits")
            st.dataframe(az.deduction_hints(df), hide_index=True, width="stretch", column_config={"Amount": MONEY})

# ----------------------------- COUNTERPARTIES -------------------------------
with tab_cp:
    if df is None:
        need_data()
    else:
        cps = az.counterparty_summary(df)
        two = cps[cps["Two-way"]]
        m1, m2, m3 = st.columns(3)
        m1.metric("Parties", len(cps))
        m2.metric("Received from parties", rs(cps.loc[~cps["Counterparty"].isin(az.GENERIC_PARTIES), "Received"].sum()))
        m3.metric("Two-way parties", len(two))
        cp_cfg = {"Received": MONEY, "Paid": MONEY, "Net": MONEY, "First": DATE, "Last": DATE,
                  "Two-way": st.column_config.CheckboxColumn()}
        if not two.empty:
            st.warning("**Parties you both received money from and paid money to.** Review these for related "
                       "parties, loans given or taken, or money going round in a circle.")
            st.dataframe(two.drop(columns=["Two-way"]), hide_index=True, width="stretch", column_config=cp_cfg)
        st.subheader("All parties")
        p1, p2 = st.columns([2, 1])
        cp_search = p1.text_input("Search party")
        cp_min = p2.number_input("Minimum total (received + paid)", value=0, step=10_000)
        shown = cps[cps["Counterparty"].str.contains(cp_search, case=False, regex=False)] if cp_search else cps
        shown = shown[(shown["Received"] + shown["Paid"]) >= cp_min]
        st.dataframe(shown, hide_index=True, width="stretch", column_config=cp_cfg)
        st.caption("Party names are read from the narration (text between NEFT/UPI/IMPS codes). "
                   "CASH, BANK, GOVT and OWN ACCOUNTS group entries that have no outside party.")
        party = st.selectbox("See the transactions of a party", shown["Counterparty"], index=None,
                             placeholder="Choose a party")
        if party:
            d = df[df["Counterparty"] == party]
            st.dataframe(d[(["Account"] if multi else []) + ["Date", "Narration", "Debit", "Credit", "Category"]],
                         hide_index=True, width="stretch", column_config={"Date": DATE, "Debit": MONEY, "Credit": MONEY})

# ----------------------------- ACCOUNTS -------------------------------------
with tab_acc:
    if df is None:
        need_data()
    else:
        acc = az.account_summary(df, results)
        st.subheader("Accounts in this view")
        st.dataframe(acc, hide_index=True, width="stretch",
                     column_config={"From": DATE, "To": DATE, "Opening balance": MONEY, "Credits": MONEY,
                                    "Debits": MONEY, "Closing balance": MONEY})
        if not multi:
            st.info("To combine accounts, select **all statements of the client together** in the upload box "
                    "(or open the demo *Sample 1 + D*). The app then shows one combined view and matches "
                    "transfers between the client's own accounts.")
        else:
            ot = az.own_transfers(df)
            st.subheader(f"Transfers between own accounts ({len(ot)} matched)")
            if ot.empty:
                st.write("No matching transfers found with the current settings (sidebar → Own-account transfer matching).")
            else:
                st.dataframe(ot, hide_index=True, width="stretch",
                             column_config={"Paid on": DATE, "Received on": DATE, "Amount": MONEY})
                st.caption("Both sides of each pair get the category **Own Account Transfer**, so they are not "
                           "treated as income, expense or unexplained credits. If a pair is wrong, change its "
                           "category in the Transactions tab.")
            st.subheader("Balance by account over time")
            bal = df.pivot_table(index="Date", columns="Account", values="Balance", aggfunc="last").ffill()
            st.line_chart(bal)

# ----------------------------- CLIENT LETTER --------------------------------
with tab_letter:
    if df is None:
        need_data()
    else:
        letter = az.client_query_letter(flags, client_name)
        st.text_area("Draft query letter (editable)", letter, height=380)
        st.download_button("⬇️ Download letter (.txt)", letter, file_name=f"queries_{client_name}.txt")

# ----------------------------- KEYWORDS -------------------------------------
with tab_kw:
    st.markdown("Every transaction's category comes from this keyword list. If a keyword appears at the "
                "start of a word in the narration, the transaction gets that category. "
                "Changes are saved in `keywords.db` and used for every statement from now on.")
    k1, k2, k3 = st.columns(3)
    k1.metric("Keywords", len(kw))
    k2.metric("Added by you", int((kw["Source"] == "User").sum()))
    k3.metric("Categories", kw["Category"].nunique())

    # ---- uncategorised entries from the current statement
    if df is not None:
        unc = az.uncategorised(df)
        with st.expander(f"❓ Uncategorised in this statement ({len(unc)}) - add keywords for them",
                         expanded=len(unc) > 0):
            if unc.empty:
                st.success("Every transaction in this statement matched a keyword.")
            else:
                st.dataframe(unc, hide_index=True, width="stretch",
                             column_config={"Amount": st.column_config.NumberColumn(format="%.2f")})
                with st.form("quick_add", clear_on_submit=True):
                    st.markdown("**Add a keyword for one of these**")
                    q1, q2, q3 = st.columns([3, 3, 1])
                    pick = q1.selectbox("Narration", unc["Narration"] + "  [" + unc["Side"] + "]")
                    narr, side = pick.rsplit("  [", 1)
                    side = side.rstrip("]")
                    kw_text = q1.text_input("Keyword (edit to a short, unique part of the narration)",
                                            az.suggest_keyword(narr))
                    cat_new = q2.selectbox("Category", categories, index=None, accept_new_options=True,
                                           placeholder="Pick or type a new category")
                    pr = q3.number_input("Priority", value=10, step=1)
                    if st.form_submit_button("➕ Add keyword") and kw_text and cat_new:
                        kdb.add_category(cat_new)
                        kdb.add_one(kw_text, cat_new, side, int(pr))
                        st.success(f"Added '{kw_text.upper()}' → {cat_new}")
                        st.rerun()

    c_left, c_right = st.columns(2)
    # ---- upload
    with c_left:
        st.subheader("⬆️ Upload keywords")
        up = st.file_uploader("Excel or CSV with columns: Keyword, Category, Applies To (Credit/Debit/Both), "
                              "Priority", type=["xlsx", "csv"], key="kw_upload")
        mode = st.radio("When importing", ["Add to existing list (uploaded rows win on clashes)",
                                           "Replace the whole list"], horizontal=False)
        if up is not None and st.button("Import keywords", type="primary"):
            try:
                new = pd.read_excel(up) if up.name.lower().endswith("xlsx") else pd.read_csv(up)
                n_new, total = kdb.merge_upload(new, replace=mode.startswith("Replace"))
                st.success(f"Imported {n_new} keywords. The list now has {total}.")
                st.rerun()
            except Exception as e:
                st.error(f"Could not import: {e}")
        d1, d2 = st.columns(2)
        d1.download_button("⬇️ Blank template", to_xlsx(kdb.template()), "keywords_template.xlsx")
        d2.download_button("⬇️ Current list", to_xlsx(kw), "keywords_current.xlsx")

    # ---- add one / test
    with c_right:
        st.subheader("➕ Add one keyword")
        with st.form("add_one", clear_on_submit=True):
            a1, a2 = st.columns(2)
            new_kw = a1.text_input("Keyword (text in narration)", placeholder="e.g. ACME TECHNOLOGIES")
            new_cat = a2.selectbox("Category", categories, index=None, accept_new_options=True,
                                   placeholder="Pick or type a new category")
            a3, a4 = st.columns(2)
            new_side = a3.selectbox("Applies to", kdb.SIDES)
            new_pr = a4.number_input("Priority (lower is checked first)", value=10, step=1)
            if st.form_submit_button("Add") and new_kw and new_cat:
                kdb.add_category(new_cat)
                kdb.add_one(new_kw, new_cat, new_side, int(new_pr))
                st.success(f"Added '{new_kw.upper()}' → {new_cat}")
                st.rerun()

        st.subheader("🧪 Test a narration")
        tcol1, tcol2 = st.columns([3, 1])
        test_n = tcol1.text_input("Narration", "NEFT CR-ACME TECHNOLOGIES PVT LTD-SALARY APR")
        test_side = tcol2.selectbox("Side", ["Credit", "Debit"])
        mode_t = az.detect_mode(test_n)
        if mode_t == "Cash":
            st.info(f"Mode **Cash** → **{'Cash Deposit' if test_side == 'Credit' else 'Cash Withdrawal'}** "
                    "(cash entries are set automatically)")
        else:
            c, k = kdb.Categoriser(kw).match(test_n, test_side == "Credit")
            if c:
                st.success(f"Category **{c}**  (matched keyword **{k}**, mode {mode_t})")
            else:
                st.warning("No keyword matched → "
                           f"**{'Unidentified Credit' if test_side == 'Credit' else 'Uncategorised Debit'}**")

    # ---- full editable list
    st.subheader("📋 Keyword list")
    search = st.text_input("Filter by keyword or category", key="kw_filter")
    mask = (kw["Keyword"].str.contains(search, case=False, regex=False) |
            kw["Category"].str.contains(search, case=False, regex=False)) if search else pd.Series(True, index=kw.index)
    edited = st.data_editor(
        kw[mask], num_rows="dynamic", width="stretch", hide_index=True, key=f"kw_editor_{search}",
        column_config={
            "Keyword": st.column_config.TextColumn(required=True),
            "Category": st.column_config.SelectboxColumn(options=categories, required=True),
            "Applies To": st.column_config.SelectboxColumn(options=kdb.SIDES, required=True),
            "Priority": st.column_config.NumberColumn(min_value=0, max_value=999, step=1),
            "Source": st.column_config.TextColumn(disabled=True),
        })
    st.caption("Edit cells, add rows at the bottom, or select rows and press Delete. Then click Save. "
               "To use a brand-new category here, add it with 'Add one keyword' above or "
               "'Add category' in the Transactions tab.")
    b1, b2, _ = st.columns([1, 1, 3])
    if b1.button("💾 Save changes", type="primary"):
        edited = edited.copy()
        edited["Source"] = edited["Source"].fillna("User")
        total = kdb.save(pd.concat([kw[~mask], edited], ignore_index=True))
        st.success(f"Saved. {total} keywords.")
        st.rerun()
    with b2.popover("↺ Reset to built-in"):
        st.write("This deletes all your keywords and restores the original list.")
        if st.button("Yes, reset"):
            kdb.reset_to_builtin()
            st.rerun()

    with st.expander("ℹ️ How matching works and special categories"):
        st.markdown(
            "- A keyword must **start a word** in the narration: `EMI` matches *HOME LOAN EMI* but not *PREMIUM*.\n"
            "- Keywords are checked in **Priority** order (lower first); for equal priority the longer keyword wins. "
            "Your keywords default to 10, so they win over the built-in ones (20+).\n"
            "- **Applies To** decides whether a keyword is used for credits, debits or both "
            "(e.g. `RENT` → *Rent Received* on credits and *Rent Paid* on debits).\n"
            "- Categories with **Income** or **Receipts** in the name appear in the Tax View income heads.\n"
            "- These categories drive the red-flag checks, so keep their names unchanged:")
        st.table(pd.DataFrame(list(kdb.SPECIAL_CATEGORIES.items()), columns=["Category", "Used for"]))

# ----------------------------- STATEMENT INFO -------------------------------
with tab_info:
    names = [n for n, _ in files]
    pick = st.selectbox("Statement", names) if len(names) > 1 else names[0]
    data = dict(files)[pick]
    map_key, hdr_key = file_keys(pick, data)
    res = next((r for r in results.values() if getattr(r, "file_name", None) == pick), None)
    prob = problems.get(pick)
    raw_df = res.raw if res is not None else (prob[3] if prob else None)

    st.subheader("How the statement was read")
    if res is not None:
        i1, i2, i3, i4 = st.columns(4)
        i1.metric("Bank detected", res.bank)
        i2.metric("Account no.", f"..{res.account_no}" if res.account_no else "not shown")
        i3.metric("Read using", res.method.split(" (")[0])
        i4.metric("Rows reconciled", f"{res.rows_ok}/{res.rows_checked}")
        st.write(f"**File type:** {res.file_type}{f' ({res.pages} pages)' if res.pages else ''}  •  "
                 f"**Balance check:** {res.balance_check}")
        for n in res.notes:
            st.info(n)
        st.write("**Columns recognised**")
        st.dataframe(pd.DataFrame([(parsers.ROLE_LABELS[r], c) for r, c in res.mapping.items()],
                                  columns=["Field", "Column in statement"]), hide_index=True)
    elif prob:
        st.warning(prob[1])

    if prob and prob[0] == "format" and prob[2] is not None:
        st.warning("The header row could not be found automatically. Here are the first rows of the file:")
        st.dataframe(prob[2], width="stretch")
        hr = st.number_input("The column headings are on row number (as counted in the preview, starting at 1)",
                             min_value=1, max_value=len(prob[2]), value=1)
        if st.button("Use this header row"):
            st.session_state[hdr_key] = int(hr)
            st.rerun()
    raw_cols = list(raw_df.columns) if raw_df is not None else []
    if raw_cols:
        with st.expander("🛠️ Fix column mapping (if something was read wrongly)", expanded=prob is not None):
            current = res.mapping if res is not None else {}
            opts = ["(none)"] + raw_cols
            new_map = {}
            cols = st.columns(4)
            for i, role in enumerate(["date", "narration", "debit", "credit", "amount", "drcr", "balance", "ref"]):
                choice = cols[i % 4].selectbox(parsers.ROLE_LABELS[role], opts,
                                               index=opts.index(current[role]) if current.get(role) in opts else 0,
                                               key=f"sel_{role}_{map_key}")
                if choice != "(none)":
                    new_map[role] = choice
            m1, m2 = st.columns(2)
            if m1.button("Apply mapping", type="primary"):
                st.session_state[map_key] = new_map
                st.rerun()
            if m2.button("Back to automatic"):
                st.session_state.pop(map_key, None)
                st.session_state.pop(hdr_key, None)
                st.rerun()
        with st.expander("Raw table as read from the file"):
            st.dataframe(raw_df.astype(str), width="stretch")
    st.caption("Supported: PDF (with or without table borders, password-protected), Excel (.xlsx/.xls) and CSV. "
               "Scanned image PDFs need OCR first. Bank names are recognised from the name or IFSC code "
               f"for {len(parsers.BANKS)} banks; other banks are read using the column headings.")

# ----------------------------- EXPORT ---------------------------------------
if df is not None:
    st.sidebar.divider()
    info = {"client": client_name, "accounts": ", ".join(results),
            "files": ", ".join(getattr(r, "file_name", "") for r in results.values())}
    st.sidebar.download_button("⬇️ Download Excel working paper",
                               az.to_excel(df, flags, info, az.account_summary(df, results)),
                               file_name=f"bank_analysis_{client_name}.xlsx",
                               mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               width="stretch")
st.sidebar.caption("⚠️ Output assists the CA; it is not a substitute for professional judgement.")
