import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { db } from './server/db.js';
import { extractPassportData } from './server/ocr.js';
import { fetchShekhawatiWeatherLive } from './server/weather.js';
import { GuestRegistration, FoodOrder, ChatMessage, HousekeepingRequest, Invoice, PaymentTransaction, ExpenseItem, ServiceFeedback } from './src/types.js';

dotenv.config();

const ai = new GoogleGenAI();

const PORT = 3000;

async function startServer() {
  const app = express();

  // Allow high-resolution image uploads for passport OCR and guest camera photo
  app.use(express.json({ limit: '25mb' }));
  app.use(express.urlencoded({ limit: '25mb', extended: true }));

  // API Health
  app.get('/api/health', (req: Request, res: Response) => {
    res.json({
      status: 'ok',
      service: 'Heritique Homestay Guest Check-in System',
      timestamp: new Date().toISOString()
    });
  });

  // Universal Authorization for any Email ID (Guest or Staff)
  app.post('/api/auth/authorize', (req: Request, res: Response) => {
    try {
      const { email, role, displayName, staffRole } = req.body;
      if (!email || typeof email !== 'string' || !email.includes('@')) {
        res.status(400).json({ error: 'A valid email address is required for authorization.' });
        return;
      }

      const normalizedEmail = email.trim().toLowerCase();
      const targetRole: 'guest' | 'staff' = role === 'staff' ? 'staff' : 'guest';
      const existingGuest = db.getGuestByEmail(normalizedEmail);

      let name = displayName?.trim();
      let assignedGuestId: string | undefined = undefined;
      let assignedRoom: string | undefined = undefined;

      if (targetRole === 'guest') {
        if (existingGuest) {
          assignedGuestId = existingGuest.id;
          assignedRoom = existingGuest.roomNumber;
          name = name || `${existingGuest.givenName} ${existingGuest.surname}`.trim();
        } else {
          name = name || normalizedEmail.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
        }
      } else {
        // Staff role
        name = name || (normalizedEmail.includes('admin') || normalizedEmail.includes('manager')
          ? 'Thakur Mahendra Singh'
          : normalizedEmail.split('@')[0].replace(/[._-]/g, ' ').replace(/\b\w/g, l => l.toUpperCase()));
      }

      const token = `auth_${Date.now()}_${Math.random().toString(36).slice(2, 10)}`;
      const session = {
        email: normalizedEmail,
        role: targetRole,
        displayName: name || 'User',
        token,
        guestId: assignedGuestId,
        roomNumber: assignedRoom,
        staffRole: targetRole === 'staff' ? (staffRole || 'Front Desk Officer') : undefined,
        authorizedAt: new Date().toISOString()
      };

      res.json({
        success: true,
        session,
        guest: existingGuest || null
      });
    } catch (err: any) {
      console.error('Authorization error:', err);
      res.status(500).json({ error: 'Authorization failed', details: err.message });
    }
  });

  // Lookup Guest by Email
  app.get('/api/guests/by-email/:email', (req: Request, res: Response) => {
    const guest = db.getGuestByEmail(req.params.email);
    if (!guest) {
      res.status(404).json({ error: 'Guest not found for given email' });
      return;
    }
    res.json(guest);
  });

  // Admin Auth (Simple secure role verification)
  app.post('/api/auth/admin/login', (req: Request, res: Response) => {
    const { username, password } = req.body;
    // Default admin credential or PIN or any authorized email
    if (username && (username.includes('@') || username === 'admin' || (password === 'heritage123' || password === 'admin' || password === '1924'))) {
      res.json({
        success: true,
        user: {
          id: 'EMP-01',
          name: username.includes('@') ? username.split('@')[0] : 'Thakur Mahendra Singh',
          email: username.includes('@') ? username : 'manager@heritique.com',
          role: 'General Manager',
          token: `token_${Date.now()}`
        }
      });
    } else {
      res.status(401).json({ success: false, message: 'Invalid employee credentials.' });
    }
  });

  // Passport OCR Endpoint
  app.post('/api/ocr/passport', async (req: Request, res: Response) => {
    try {
      const { image } = req.body;
      if (!image) {
        res.status(400).json({ error: 'Image data is required for passport OCR' });
        return;
      }
      const extracted = await extractPassportData(image);
      res.json({ success: true, data: extracted });
    } catch (err: any) {
      console.error('Passport OCR extraction failed:', err);
      res.status(500).json({ error: 'Failed to extract passport information', details: err.message });
    }
  });

  // Guest Check-in Registration
  app.post('/api/guests/checkin', (req: Request, res: Response) => {
    try {
      const body = req.body;
      const newGuest: GuestRegistration = {
        id: `GUEST-${Math.floor(1000 + Math.random() * 9000)}`,
        checkInDate: body.checkInDate || new Date().toISOString().split('T')[0],
        checkOutDate: body.checkOutDate || new Date(Date.now() + 3 * 86400000).toISOString().split('T')[0],
        roomNumber: body.roomNumber || 'Suite 102 - Gulab Mahal',
        roomType: body.roomType || 'Heritage Courtyard Suite',
        roomRate: Number(body.roomRate) || 6200,
        status: 'active',
        guestType: body.guestType || 'foreign',
        givenName: body.givenName || '',
        surname: body.surname || '',
        gender: body.gender || 'Male',
        dob: body.dob || '',
        nationality: body.nationality || '',
        passportNumber: body.passportNumber || '',
        passportIssueDate: body.passportIssueDate || '',
        passportExpiryDate: body.passportExpiryDate || '',
        passportIssuePlace: body.passportIssuePlace || '',
        visaNumber: body.visaNumber || 'N/A',
        visaType: body.visaType || 'Tourist e-Visa',
        visaIssueDate: body.visaIssueDate || '',
        visaExpiryDate: body.visaExpiryDate || '',
        visaIssuePlace: body.visaIssuePlace || '',
        arrivedFromCity: body.arrivedFromCity || '',
        arrivedFromCountry: body.arrivedFromCountry || '',
        arrivalDateInCountry: body.arrivalDateInCountry || '',
        portOfArrival: body.portOfArrival || '',
        nextDestination: body.nextDestination || '',
        purposeOfVisit: body.purposeOfVisit || 'Tourism & Heritage Leisure',
        employedInIndia: Boolean(body.employedInIndia),
        homeAddress: body.homeAddress || '',
        homeCountry: body.homeCountry || '',
        phone: body.phone || '',
        email: body.email || '',
        emergencyContact: body.emergencyContact || '',
        guestPhoto: body.guestPhoto,
        passportDocument: body.passportDocument,
        visaDocument: body.visaDocument,
        signature: body.signature,
        verificationStatus: body.guestType === 'foreign' ? 'verified' : 'verified',
        createdAt: new Date().toISOString(),
        notes: body.notes || 'Checked in via Self-Service Guest PWA portal.'
      };

      const saved = db.addGuest(newGuest);
      res.status(201).json({ success: true, guest: saved });
    } catch (err: any) {
      console.error('Error processing guest check-in:', err);
      res.status(500).json({ error: 'Failed to process check-in', details: err.message });
    }
  });

  // Get all guests
  app.get('/api/guests', (req: Request, res: Response) => {
    const guests = db.getGuests();
    res.json(guests);
  });

  // Get single guest
  app.get('/api/guests/:id', (req: Request, res: Response) => {
    const guest = db.getGuestById(req.params.id);
    if (!guest) {
      res.status(404).json({ error: 'Guest not found' });
      return;
    }
    res.json(guest);
  });

  // Update guest status / verification
  app.patch('/api/guests/:id', (req: Request, res: Response) => {
    const updated = db.updateGuest(req.params.id, req.body);
    if (!updated) {
      res.status(404).json({ error: 'Guest not found' });
      return;
    }
    res.json(updated);
  });

  // Delete guest
  app.delete('/api/guests/:id', (req: Request, res: Response) => {
    const success = db.deleteGuest(req.params.id);
    res.json({ success });
  });

  // Government Form C export (Official Foreigners Registration Format)
  app.get('/api/export/form-c/:guestId', (req: Request, res: Response) => {
    const guest = db.getGuestById(req.params.guestId);
    if (!guest) {
      res.status(404).json({ error: 'Guest registration not found' });
      return;
    }

    const formC = {
      hotelDetails: {
        establishmentName: 'Heritique Homestay & Heritage Haveli',
        state: 'Rajasthan',
        district: 'Jaipur',
        registeredLicenseNo: 'RAJ-TOURISM-HST-1924-B',
        contactPhone: '+91 141 289 9000',
        contactEmail: 'concierge@heritiquehomestay.com',
      },
      foreignGuestDetails: {
        registrationId: guest.id,
        fullName: `${guest.givenName} ${guest.surname}`,
        gender: guest.gender,
        dateOfBirth: guest.dob,
        nationality: guest.nationality,
        permanentAddress: `${guest.homeAddress}, ${guest.homeCountry}`,
        contactNumber: guest.phone,
        email: guest.email,
        passport: {
          number: guest.passportNumber,
          placeOfIssue: guest.passportIssuePlace,
          dateOfIssue: guest.passportIssueDate,
          expiryDate: guest.passportExpiryDate
        },
        visa: {
          number: guest.visaNumber,
          type: guest.visaType,
          placeOfIssue: guest.visaIssuePlace,
          validTill: guest.visaExpiryDate
        },
        arrivalDetails: {
          portOfArrivalInCountry: guest.portOfArrival,
          arrivalDateInCountry: guest.arrivalDateInCountry,
          arrivedFromCityCountry: `${guest.arrivedFromCity}, ${guest.arrivedFromCountry}`,
          checkInAtHomestay: guest.checkInDate,
          proposedDurationOfStayNights: 4,
          nextIntendedDestination: guest.nextDestination,
          purposeOfVisit: guest.purposeOfVisit,
          employedInIndia: guest.employedInIndia ? 'Yes' : 'No'
        },
        verificationStatus: guest.verificationStatus,
        complianceDeclaration: 'I declare that the information furnished above is correct to the best of my knowledge and belief pursuant to Form C Rule 14 Foreigners Registration Act.',
        timestampReported: new Date().toISOString()
      }
    };

    res.json(formC);
  });

  // Food Menu
  app.get('/api/food/menu', (req: Request, res: Response) => {
    res.json(db.getMenu());
  });

  // Food Orders
  app.get('/api/food/orders', (req: Request, res: Response) => {
    res.json(db.getOrders());
  });

  app.post('/api/food/orders', (req: Request, res: Response) => {
    try {
      const { guestId, guestName, roomNumber, items, specialInstructions } = req.body;
      if (!items || !items.length) {
        res.status(400).json({ error: 'Order items are required' });
        return;
      }

      const subtotal = items.reduce((acc: number, item: any) => acc + (item.price * item.quantity), 0);
      const taxes = Math.round(subtotal * 0.05); // 5% GST on dining
      const total = subtotal + taxes;

      const newOrder: FoodOrder = {
        id: `ORD-${Math.floor(100 + Math.random() * 900)}`,
        guestId: guestId || 'GUEST-8021',
        guestName: guestName || 'Heritique Guest',
        roomNumber: roomNumber || 'Suite 101',
        items,
        subtotal,
        taxes,
        total,
        status: 'placed',
        specialInstructions: specialInstructions || '',
        placedAt: new Date().toISOString(),
        estimatedMinutes: 25
      };

      const saved = db.addOrder(newOrder);
      res.status(201).json({ success: true, order: saved });
    } catch (err: any) {
      res.status(500).json({ error: 'Failed to place order', details: err.message });
    }
  });

  app.patch('/api/food/orders/:id/status', (req: Request, res: Response) => {
    const { status } = req.body;
    const updated = db.updateOrderStatus(req.params.id, status);
    if (!updated) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    res.json(updated);
  });

  // Billing Folios
  app.get('/api/billing', (req: Request, res: Response) => {
    res.json(db.getBillingFolios());
  });

  app.get('/api/billing/:guestId', (req: Request, res: Response) => {
    const folio = db.getBillingByGuestId(req.params.guestId);
    if (!folio) {
      res.status(404).json({ error: 'Billing folio not found' });
      return;
    }
    res.json(folio);
  });

  app.post('/api/billing/:guestId/pay', (req: Request, res: Response) => {
    const { amount, method } = req.body;
    const updated = db.recordPayment(req.params.guestId, Number(amount) || 0, method || 'Card');
    if (!updated) {
      res.status(404).json({ error: 'Billing folio not found' });
      return;
    }
    res.json(updated);
  });

  // Chat Concierge
  app.get('/api/chats', (req: Request, res: Response) => {
    const guestId = req.query.guestId as string | undefined;
    res.json(db.getChats(guestId));
  });

  app.post('/api/chats', (req: Request, res: Response) => {
    const { guestId, roomNumber, sender, senderName, message } = req.body;
    if (!message) {
      res.status(400).json({ error: 'Message text is required' });
      return;
    }

    const newMsg: ChatMessage = {
      id: `chat-${Date.now()}`,
      guestId: guestId || 'GUEST-8021',
      roomNumber: roomNumber || 'Suite 101',
      sender: sender || 'guest',
      senderName: senderName || 'Guest',
      message,
      timestamp: new Date().toISOString(),
      read: sender === 'staff'
    };

    db.addChatMessage(newMsg);

    // If sent by guest, simulate smart concierge acknowledgment after brief pause
    if (sender === 'guest') {
      setTimeout(() => {
        let reply = 'Thank you for your message! Our front desk officer is attending to this promptly.';
        const lower = message.toLowerCase();
        if (lower.includes('towel') || lower.includes('linen') || lower.includes('clean') || lower.includes('water')) {
          reply = 'Certainly! Housekeeping has been alerted to bring fresh supplies to your suite within 10 minutes.';
        } else if (lower.includes('breakfast') || lower.includes('food') || lower.includes('dinner') || lower.includes('tea') || lower.includes('menu')) {
          reply = 'Our royal kitchen is at your service! Fresh breakfast is served 7:30 AM - 10:30 AM in the Courtyard, or you can order anytime from our In-Room Dining menu.';
        } else if (lower.includes('tour') || lower.includes('visit') || lower.includes('city') || lower.includes('sightseeing') || lower.includes('guide')) {
          reply = 'We arrange guided walking heritage tours through the old city gates and sunset tea at the rooftop terrace. We would love to book this for you!';
        } else if (lower.includes('checkout') || lower.includes('check out') || lower.includes('bill')) {
          reply = 'Our standard checkout is 11:00 AM. You can review your itemized folio under the Billing tab, and express digital checkout is supported.';
        }

        db.addChatMessage({
          id: `chat-${Date.now() + 1}`,
          guestId: newMsg.guestId,
          roomNumber: newMsg.roomNumber,
          sender: 'concierge_ai',
          senderName: 'Heritique Concierge',
          message: reply,
          timestamp: new Date().toISOString(),
          read: false
        });
      }, 1200);
    }

    res.status(201).json(newMsg);
  });

  // Weather Widget for Shekhawati, Rajasthan with Search Grounding
  app.get('/api/weather/shekhawati', async (req: Request, res: Response) => {
    try {
      const forceRefresh = req.query.refresh === 'true';
      const weatherData = await fetchShekhawatiWeatherLive(forceRefresh);
      res.json(weatherData);
    } catch (err: any) {
      console.error('Weather API error:', err);
      res.status(500).json({ error: 'Failed to fetch Shekhawati weather', details: err.message });
    }
  });

  // Housekeeping Requests
  app.get('/api/housekeeping', (req: Request, res: Response) => {
    const guestId = req.query.guestId as string | undefined;
    res.json(db.getHousekeepingRequests(guestId));
  });

  app.post('/api/housekeeping', (req: Request, res: Response) => {
    try {
      const { guestId, guestName, roomNumber, requestType, preferredTime, notes } = req.body;
      if (!requestType) {
        res.status(400).json({ error: 'Housekeeping request type is required (Standard Tidy, Deep Clean, or Fresh Towels)' });
        return;
      }

      const newRequest: HousekeepingRequest = {
        id: `HK-${Math.floor(100 + Math.random() * 900)}`,
        guestId: guestId || 'GUEST-8021',
        guestName: guestName || 'Heritique Guest',
        roomNumber: roomNumber || 'Suite 101',
        requestType,
        preferredTime: preferredTime || 'Immediate (Next 30 mins)',
        notes: notes || '',
        status: 'pending',
        requestedAt: new Date().toISOString()
      };

      const saved = db.addHousekeepingRequest(newRequest);
      res.status(201).json({ success: true, request: saved });
    } catch (err: any) {
      console.error('Failed to create housekeeping request:', err);
      res.status(500).json({ error: 'Failed to submit housekeeping request', details: err.message });
    }
  });

  app.patch('/api/housekeeping/:id/status', (req: Request, res: Response) => {
    const { status, assignedStaff } = req.body;
    const updated = db.updateHousekeepingStatus(req.params.id, status, assignedStaff);
    if (!updated) {
      res.status(404).json({ error: 'Housekeeping request not found' });
      return;
    }
    res.json(updated);
  });

  // Automated Invoice Generation & Checkout System
  app.post('/api/checkout/request-invoice', (req: Request, res: Response) => {
    try {
      const { guestId, checkoutDate, additionalServices } = req.body;
      if (!guestId) {
        res.status(400).json({ error: 'guestId is required to generate invoice' });
        return;
      }

      const invoice = db.generateInvoice(guestId, { checkoutDate, additionalServices });
      res.json({ success: true, invoice });
    } catch (err: any) {
      console.error('Invoice generation error:', err);
      res.status(500).json({ error: 'Failed to generate invoice', details: err.message });
    }
  });

  app.get('/api/checkout/invoice/:guestId', (req: Request, res: Response) => {
    const invoice = db.getInvoiceByGuestId(req.params.guestId);
    if (!invoice) {
      res.status(404).json({ error: 'Invoice not found' });
      return;
    }
    res.json(invoice);
  });

  app.get('/api/invoices', (req: Request, res: Response) => {
    res.json(db.getAllInvoices());
  });

  // Process Online Payment via Secure Gateway (Stripe, PayPal, UPI)
  app.post('/api/checkout/pay', (req: Request, res: Response) => {
    try {
      const { invoiceId, guestId, amount, gateway, paymentDetails } = req.body;
      if (!guestId || !amount) {
        res.status(400).json({ error: 'guestId and amount are required' });
        return;
      }

      const result = db.processPayment({
        invoiceId: invoiceId || '',
        guestId,
        amount: Number(amount),
        gateway: gateway || 'Stripe',
        paymentDetails: paymentDetails || {}
      });

      res.json(result);
    } catch (err: any) {
      console.error('Checkout payment error:', err);
      res.status(500).json({ error: 'Payment processing failed', details: err.message });
    }
  });

  // Payment Transactions Log
  app.get('/api/transactions', (req: Request, res: Response) => {
    const guestId = req.query.guestId as string | undefined;
    res.json(db.getTransactions(guestId));
  });

  // ==========================================
  // EXPENSES & ACCOUNTS MANAGEMENT
  // ==========================================
  app.get('/api/expenses', (req: Request, res: Response) => {
    try {
      const expenses = db.getExpenses();
      res.json(expenses);
    } catch (err: any) {
      console.error('Error fetching expenses:', err);
      res.status(500).json({ error: 'Failed to fetch expenses', details: err.message });
    }
  });

  app.post('/api/expenses', (req: Request, res: Response) => {
    try {
      const { title, category, amount, paymentMethod, date, submittedBy, notes, receiptUrl } = req.body;
      if (!title || !amount) {
        res.status(400).json({ error: 'Title and amount are required for expense entry' });
        return;
      }

      const newExpense: ExpenseItem = {
        id: `EXP-${Date.now().toString().slice(-4)}`,
        title,
        category: category || 'Other',
        amount: Number(amount) || 0,
        date: date || new Date().toISOString().split('T')[0],
        paymentMethod: paymentMethod || 'Cash',
        submittedBy: submittedBy || 'Staff Member',
        submittedAt: new Date().toISOString(),
        status: 'pending_approval',
        notes: notes || '',
        receiptUrl: receiptUrl || undefined
      };

      const saved = db.addExpense(newExpense);
      res.status(201).json({ success: true, expense: saved });
    } catch (err: any) {
      console.error('Error recording expense:', err);
      res.status(500).json({ error: 'Failed to record expense', details: err.message });
    }
  });

  app.patch('/api/expenses/:id/status', (req: Request, res: Response) => {
    try {
      const { status, approvedBy, rejectionReason } = req.body;
      if (!status || (status !== 'approved' && status !== 'rejected')) {
        res.status(400).json({ error: 'Status must be approved or rejected' });
        return;
      }

      const updated = db.updateExpenseStatus(req.params.id, status, approvedBy, rejectionReason);
      if (!updated) {
        res.status(404).json({ error: 'Expense item not found' });
        return;
      }
      res.json({ success: true, expense: updated });
    } catch (err: any) {
      console.error('Error updating expense status:', err);
      res.status(500).json({ error: 'Failed to update expense', details: err.message });
    }
  });

  // ==========================================
  // POST-SERVICE FEEDBACK MODULE (Dining, Housekeeping, Stay & Checkout)
  // ==========================================
  app.get('/api/feedback', (req: Request, res: Response) => {
    try {
      const { guestId, category, targetId } = req.query;
      const feedbacks = db.getFeedbacks({
        guestId: guestId ? String(guestId) : undefined,
        category: category ? String(category) : undefined,
        targetId: targetId ? String(targetId) : undefined
      });
      res.json(feedbacks);
    } catch (err: any) {
      console.error('Error fetching feedbacks:', err);
      res.status(500).json({ error: 'Failed to fetch feedback records', details: err.message });
    }
  });

  app.post('/api/feedback', (req: Request, res: Response) => {
    try {
      const { 
        guestId, 
        guestName, 
        guestEmail, 
        roomNumber, 
        category, 
        targetId, 
        targetTitle, 
        rating, 
        qualityRating,
        speedRating,
        courtesyRating,
        tags, 
        comments, 
        npsScore 
      } = req.body;

      if (!guestId || !roomNumber || !category || !rating) {
        res.status(400).json({ error: 'guestId, roomNumber, category, and rating are required.' });
        return;
      }

      const newFeedback: ServiceFeedback = {
        id: `FB-${Date.now().toString().slice(-6)}`,
        guestId,
        guestName: guestName || 'Haveli Guest',
        guestEmail: guestEmail || undefined,
        roomNumber,
        category,
        targetId: targetId || undefined,
        targetTitle: targetTitle || (category === 'dining' ? 'In-Room Dining Order' : category === 'housekeeping' ? 'Housekeeping Service' : 'Heritage Stay Experience'),
        rating: Math.min(5, Math.max(1, Number(rating))),
        qualityRating: qualityRating ? Math.min(5, Math.max(1, Number(qualityRating))) : undefined,
        speedRating: speedRating ? Math.min(5, Math.max(1, Number(speedRating))) : undefined,
        courtesyRating: courtesyRating ? Math.min(5, Math.max(1, Number(courtesyRating))) : undefined,
        tags: Array.isArray(tags) ? tags : [],
        comments: comments || '',
        npsScore: npsScore ? Math.min(10, Math.max(1, Number(npsScore))) : undefined,
        createdAt: new Date().toISOString(),
        followUpStatus: 'thanked'
      };

      const saved = db.addFeedback(newFeedback);

      // Automated courteous acknowledgment chat
      db.getChats(guestId); // ensure chats loaded
      const categoryLabel = category === 'dining' ? 'culinary dining' : category === 'housekeeping' ? 'housekeeping & linen' : 'stay & hospitality';
      const thankYouMsg = `Padharo Sa! Thakur Mahendra Singh & the Heritique Haveli team sincerely thank you for rating your ${categoryLabel} experience (${rating}★). Your review has been saved in our Master Operations Ledger.`;
      
      // Post system chat message
      try {
        db.addChatMessage({
          id: `chat-fb-${Date.now()}`,
          guestId,
          roomNumber,
          sender: 'concierge_ai',
          senderName: 'Heritique Front Desk',
          message: thankYouMsg,
          timestamp: new Date().toISOString(),
          read: false
        });
      } catch {
        // non-blocking
      }

      res.status(201).json({ success: true, feedback: saved });
    } catch (err: any) {
      console.error('Error submitting feedback:', err);
      res.status(500).json({ error: 'Failed to record feedback', details: err.message });
    }
  });

  app.patch('/api/feedback/:id/status', (req: Request, res: Response) => {
    try {
      const { status } = req.body;
      if (!status) {
        res.status(400).json({ error: 'Status is required' });
        return;
      }
      const updated = db.updateFeedbackFollowUp(req.params.id, status);
      if (!updated) {
        res.status(404).json({ error: 'Feedback record not found' });
        return;
      }
      res.json({ success: true, feedback: updated });
    } catch (err: any) {
      console.error('Error updating feedback status:', err);
      res.status(500).json({ error: 'Failed to update feedback status', details: err.message });
    }
  });

  // ==========================================
  // GEMINI AI ITINERARY PLANNER (Jaipur & Rajasthan)
  // ==========================================
  app.post('/api/ai/plan-itinerary', async (req: Request, res: Response) => {
    try {
      const { 
        destination = 'Jaipur (Pink City)', 
        days = 2, 
        travelStyle = 'Heritage & Palaces', 
        partyType = 'Couple / Explorer',
        preferences = '' 
      } = req.body;

      const homestayLocation = '1458, Rathi Building, Partanion Ka Rasta, Johari Bazar, Jaipur, Rajasthan 302003';

      const prompt = `You are the master royal travel concierge of "Heritique Haveli Homestay", situated in the heart of the historic walled city of Jaipur at ${homestayLocation}.
A staying guest has requested an authentic, personalized Rajasthan travel itinerary with the following parameters:

- Base / Starting Point: Heritique Haveli Homestay (${homestayLocation} - right off Johari Bazar near Badi Chaupar, Hawa Mahal)
- Destination: ${destination}
- Duration: ${days} Day(s)
- Travel Style / Theme: ${travelStyle}
- Group Type: ${partyType}
- Special Notes / Preferences: ${preferences ? preferences : 'None specified, provide the best local insider secrets'}

Please generate a richly detailed, realistic, and culturally immersive itinerary.
Format your output as a valid JSON object with the following structure:
{
  "title": "A captivating, regal title for this itinerary",
  "summary": "2-3 sentences overview capturing the spirit of the trip starting from Partanion Ka Rasta, Johari Bazar",
  "startingPointTip": "Specific walking and transport advice when stepping out of Heritique Haveli in Johari Bazar",
  "days": [
    {
      "dayNumber": 1,
      "theme": "Theme of Day 1 (e.g., Royal Walled City & Fortress Sunsets)",
      "morning": {
        "time": "8:00 AM - 12:30 PM",
        "title": "Title of morning activity",
        "description": "Engaging description with insider haveli advice, walking directions from Johari Bazar, and photo spots.",
        "location": "Name of monument / spot",
        "recommendedFood": "Local morning snack or chai spot nearby"
      },
      "afternoon": {
        "time": "1:00 PM - 5:00 PM",
        "title": "Title of afternoon activity",
        "description": "Engaging description of afternoon exploration.",
        "location": "Name of monument / palace",
        "recommendedFood": "Authentic lunch recommendation"
      },
      "evening": {
        "time": "5:30 PM - 9:30 PM",
        "title": "Title of evening activity",
        "description": "Sunset views, courtyard cultural evening, or Johari Bazar jewelry and textile walking route.",
        "location": "Sunset point or bazaar",
        "recommendedFood": "Dinner or dessert recommendation"
      }
    }
  ],
  "localInsiderSecrets": [
    "Secret 1: Tip about Johari Bazar gems, Partanion Ka Rasta brass artisans, or hidden courtyards",
    "Secret 2: Photography advice for light on pink sandstone",
    "Secret 3: Tuk-tuk or cab fair estimates from Johari Bazar",
    "Secret 4: Heritage shopping tip (block-print quilts, meenakari jewelry, bandhani sarees)"
  ],
  "essentialPackingAndEtiquette": [
    "Footwear & temple etiquette advice",
    "Best time of day to avoid crowds"
  ]
}

Ensure all advice reflects the exact geography of Jaipur starting from Johari Bazar and Partanion Ka Rasta! Return ONLY the JSON object, without surrounding codeblocks or markdown formatting if possible.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: prompt
      });

      const responseText = response.text || '';
      // Clean JSON if model returned markdown code fences
      const cleanJson = responseText.replace(/```json\s*/gi, '').replace(/```\s*$/gi, '').trim();
      let parsedData;
      try {
        parsedData = JSON.parse(cleanJson);
      } catch {
        parsedData = {
          title: `${days}-Day ${travelStyle} Journey in ${destination}`,
          rawText: responseText
        };
      }

      res.json({ success: true, itinerary: parsedData });
    } catch (err: any) {
      console.error('AI Itinerary generator error:', err);
      res.status(500).json({ error: 'Failed to generate itinerary', details: err.message });
    }
  });

  // Vite middleware in development vs. static in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Heritique Homestay server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
