import { doc, setDoc, getDocs, collection } from 'firebase/firestore';
import { firestore } from './firebase';
import { GuestRegistration, FoodOrder, HousekeepingRequest, Invoice } from '../types';

/**
 * Sync guest to Firestore
 */
export async function syncGuestToFirestore(guest: GuestRegistration) {
  try {
    await setDoc(doc(firestore, 'guests', guest.id), {
      ...guest,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log(`[Firestore] Synced guest ${guest.id}`);
  } catch (err) {
    console.warn(`[Firestore] Could not sync guest ${guest.id}:`, err);
  }
}

/**
 * Sync dining order to Firestore
 */
export async function syncOrderToFirestore(order: FoodOrder) {
  try {
    await setDoc(doc(firestore, 'orders', order.id), {
      ...order,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log(`[Firestore] Synced order ${order.id}`);
  } catch (err) {
    console.warn(`[Firestore] Could not sync order ${order.id}:`, err);
  }
}

/**
 * Sync housekeeping request to Firestore
 */
export async function syncHousekeepingToFirestore(request: HousekeepingRequest) {
  try {
    await setDoc(doc(firestore, 'housekeeping', request.id), {
      ...request,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log(`[Firestore] Synced housekeeping ${request.id}`);
  } catch (err) {
    console.warn(`[Firestore] Could not sync housekeeping ${request.id}:`, err);
  }
}

/**
 * Sync invoice to Firestore
 */
export async function syncInvoiceToFirestore(invoice: Invoice) {
  try {
    await setDoc(doc(firestore, 'invoices', invoice.id), {
      ...invoice,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    console.log(`[Firestore] Synced invoice ${invoice.id}`);
  } catch (err) {
    console.warn(`[Firestore] Could not sync invoice ${invoice.id}:`, err);
  }
}

/**
 * Bulk sync all app data to Firestore
 */
export async function bulkSyncToFirestore(data: {
  guests: GuestRegistration[];
  orders: FoodOrder[];
  housekeeping: HousekeepingRequest[];
  invoices: Invoice[];
}) {
  const results = {
    guests: 0,
    orders: 0,
    housekeeping: 0,
    invoices: 0
  };

  for (const g of data.guests) {
    try {
      await setDoc(doc(firestore, 'guests', g.id), g, { merge: true });
      results.guests++;
    } catch (e) {
      console.warn('Firestore guest sync error:', e);
    }
  }

  for (const o of data.orders) {
    try {
      await setDoc(doc(firestore, 'orders', o.id), o, { merge: true });
      results.orders++;
    } catch (e) {
      console.warn('Firestore order sync error:', e);
    }
  }

  for (const h of data.housekeeping) {
    try {
      await setDoc(doc(firestore, 'housekeeping', h.id), h, { merge: true });
      results.housekeeping++;
    } catch (e) {
      console.warn('Firestore housekeeping sync error:', e);
    }
  }

  for (const inv of data.invoices) {
    try {
      await setDoc(doc(firestore, 'invoices', inv.id), inv, { merge: true });
      results.invoices++;
    } catch (e) {
      console.warn('Firestore invoice sync error:', e);
    }
  }

  return results;
}
