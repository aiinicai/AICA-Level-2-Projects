import { GuestRegistration, FoodOrder, HousekeepingRequest, Invoice, ExpenseItem, ServiceFeedback } from '../types';

export interface HomestaySpreadsheetInfo {
  id: string;
  name: string;
  webViewLink?: string;
  modifiedTime?: string;
}

const SHEETS_API_BASE = 'https://sheets.googleapis.com/v4/spreadsheets';
const DRIVE_API_BASE = 'https://www.googleapis.com/drive/v3';

export const MASTER_SHEET_TITLE = 'Heritique Haveli Homestay - Master Operations Ledger';
const DRIVE_FOLDER_NAME = 'Heritique Haveli - Guest Documents';

/**
 * List spreadsheets from the user's Google Drive
 */
export async function listSpreadsheets(accessToken: string): Promise<HomestaySpreadsheetInfo[]> {
  const query = encodeURIComponent("mimeType='application/vnd.google-apps.spreadsheet' and trashed=false");
  const res = await fetch(`${DRIVE_API_BASE}/files?q=${query}&fields=files(id,name,webViewLink,modifiedTime)&orderBy=modifiedTime desc&pageSize=25`, {
    headers: { Authorization: `Bearer ${accessToken}` }
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'Failed to list Google Sheets from Drive');
  }

  const data = await res.json();
  return data.files || [];
}

/**
 * Find or create a dedicated Google Drive folder for guest identity documents
 */
export async function getOrCreateDriveFolder(accessToken: string): Promise<string | undefined> {
  try {
    const query = encodeURIComponent(`mimeType='application/vnd.google-apps.folder' and name='${DRIVE_FOLDER_NAME}' and trashed=false`);
    const searchRes = await fetch(`${DRIVE_API_BASE}/files?q=${query}&fields=files(id,name)`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });

    if (searchRes.ok) {
      const data = await searchRes.json();
      if (data.files && data.files.length > 0) {
        return data.files[0].id;
      }
    }

    // Create folder if not found
    const createRes = await fetch(`${DRIVE_API_BASE}/files`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: DRIVE_FOLDER_NAME,
        mimeType: 'application/vnd.google-apps.folder'
      })
    });

    if (createRes.ok) {
      const folderData = await createRes.json();
      return folderData.id;
    }
  } catch (err) {
    console.warn('Could not create/find Google Drive folder, uploading to root:', err);
  }
  return undefined;
}

/**
 * Upload base64 image or document to Google Drive and return webViewLink
 */
export async function uploadBase64ToDrive(
  accessToken: string,
  fileName: string,
  base64DataUrl: string,
  folderId?: string
): Promise<{ fileId: string; webViewLink: string }> {
  try {
    const matches = base64DataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    const mimeType = matches ? matches[1] : 'image/jpeg';
    const base64Data = matches ? matches[2] : base64DataUrl;

    const byteCharacters = atob(base64Data);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: mimeType });

    const metadata: any = {
      name: fileName,
      mimeType
    };
    if (folderId) {
      metadata.parents = [folderId];
    }

    const form = new FormData();
    form.append('metadata', new Blob([JSON.stringify(metadata)], { type: 'application/json' }));
    form.append('file', blob);

    const uploadRes = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`
      },
      body: form
    });

    if (!uploadRes.ok) {
      const err = await uploadRes.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to upload document to Google Drive');
    }

    const fileData = await uploadRes.json();
    const webViewLink = fileData.webViewLink || `https://drive.google.com/file/d/${fileData.id}/view?usp=sharing`;

    // Attempt to make readable by anyone with the link
    fetch(`${DRIVE_API_BASE}/files/${fileData.id}/permissions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ role: 'reader', type: 'anyone' })
    }).catch(() => {});

    return {
      fileId: fileData.id,
      webViewLink
    };
  } catch (err: any) {
    console.error('Error uploading file to Drive:', err);
    throw err;
  }
}

/**
 * Requirement 7: Every day check in to be saved in same or single or common google sheet.
 * Retrieves existing master spreadsheet or creates it ONCE.
 */
export async function getOrCreateMasterSpreadsheet(accessToken: string): Promise<{ spreadsheetId: string; spreadsheetUrl: string; isNew: boolean }> {
  // 1. Check local storage cache
  const savedId = localStorage.getItem('heritique_master_spreadsheet_id');
  if (savedId) {
    try {
      const checkRes = await fetch(`${SHEETS_API_BASE}/${savedId}?fields=spreadsheetId,properties.title`, {
        headers: { Authorization: `Bearer ${accessToken}` }
      });
      if (checkRes.ok) {
        const data = await checkRes.json();
        return {
          spreadsheetId: data.spreadsheetId,
          spreadsheetUrl: `https://docs.google.com/spreadsheets/d/${data.spreadsheetId}/edit`,
          isNew: false
        };
      }
    } catch {
      // Continue to search Drive if stale
    }
  }

  // 2. Search user's Drive for existing Master Operations Ledger
  try {
    const existingList = await listSpreadsheets(accessToken);
    const existing = existingList.find(s => s.name === MASTER_SHEET_TITLE);
    if (existing) {
      localStorage.setItem('heritique_master_spreadsheet_id', existing.id);
      return {
        spreadsheetId: existing.id,
        spreadsheetUrl: existing.webViewLink || `https://docs.google.com/spreadsheets/d/${existing.id}/edit`,
        isNew: false
      };
    }
  } catch (err) {
    console.warn('Could not list drive spreadsheets:', err);
  }

  // 3. Create single master spreadsheet once
  const created = await createHomestaySpreadsheet(accessToken, MASTER_SHEET_TITLE);
  localStorage.setItem('heritique_master_spreadsheet_id', created.spreadsheetId);
  return { ...created, isNew: true };
}

/**
 * Creates the master Heritique Homestay operations spreadsheet in Google Sheets
 */
export async function createHomestaySpreadsheet(
  accessToken: string, 
  title: string = MASTER_SHEET_TITLE
): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
  const body = {
    properties: {
      title
    },
    sheets: [
      {
        properties: {
          title: 'Guest Register & Form C',
          gridProperties: { rowCount: 200, columnCount: 20 }
        }
      },
      {
        properties: {
          title: 'In-Room Dining Orders',
          gridProperties: { rowCount: 150, columnCount: 10 }
        }
      },
      {
        properties: {
          title: 'Housekeeping Log',
          gridProperties: { rowCount: 150, columnCount: 9 }
        }
      },
      {
        properties: {
          title: 'Billing Folios & Invoices',
          gridProperties: { rowCount: 150, columnCount: 12 }
        }
      },
      {
        properties: {
          title: 'Expenses & Accounts',
          gridProperties: { rowCount: 150, columnCount: 11 }
        }
      },
      {
        properties: {
          title: 'Service Feedback',
          gridProperties: { rowCount: 150, columnCount: 16 }
        }
      }
    ]
  };

  const res = await fetch(SHEETS_API_BASE, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(body)
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || 'Failed to create Google Spreadsheet');
  }

  const result = await res.json();
  const spreadsheetId = result.spreadsheetId;
  const spreadsheetUrl = result.spreadsheetUrl || `https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`;

  // Populate headers and styling
  await initializeSpreadsheetHeaders(accessToken, spreadsheetId);

  return { spreadsheetId, spreadsheetUrl };
}

/**
 * Initialize headers in each sheet tab
 */
async function initializeSpreadsheetHeaders(accessToken: string, spreadsheetId: string) {
  const guestHeaders = [
    'Registration ID', 'Full Name', 'Email', 'Phone', 'Assigned Suite', 
    'Nationality', 'ID / Passport No', 'Status', 'Check-In Date', 'Check-Out Date', 
    'Purpose of Visit', 'Visa / ID Details', 'Form C / Reg No', 'Next Destination', 
    'Registered At', 'Form C Status',
    'Passport/ID Document (Drive Link)', 'Guest Photo (Drive Link)', 'Guest Signature (Drive Link)'
  ];

  const diningHeaders = [
    'Order ID', 'Guest ID', 'Guest Name', 'Suite / Room', 'Items Summary', 
    'Item Count', 'Order Total (₹)', 'Status', 'Special Requests', 'Placed At'
  ];

  const housekeepingHeaders = [
    'Request ID', 'Guest ID', 'Guest Name', 'Suite / Room', 'Service Type', 
    'Preferred Time', 'Status', 'Notes', 'Requested At'
  ];

  const billingHeaders = [
    'Invoice ID', 'Guest ID', 'Guest Name', 'Suite / Room', 'Base Room Charges (₹)', 
    'Dining Charges (₹)', 'Levy & Taxes (₹)', 'Grand Total (₹)', 'Paid Amount (₹)', 
    'Balance Due (₹)', 'Status', 'Issued At'
  ];

  const expenseHeaders = [
    'Expense ID', 'Title', 'Category', 'Amount (₹)', 'Date', 
    'Payment Method', 'Submitted By', 'Status', 'Approved By', 'Approved At', 'Notes'
  ];

  const feedbackHeaders = [
    'Feedback ID', 'Guest ID', 'Guest Name', 'Suite / Room', 'Category', 
    'Target Reference ID', 'Service / Order Description', 'Rating (Stars)', 
    'Quality (1-5)', 'Speed (1-5)', 'Staff Courtesy (1-5)', 
    'Key Highlights / Tags', 'Guest Comments & Review', 'NPS Score (1-10)', 
    'Submitted At', 'Follow-up Status'
  ];

  const valueRanges = [
    { range: "'Guest Register & Form C'!A1:S1", values: [guestHeaders] },
    { range: "'In-Room Dining Orders'!A1:J1", values: [diningHeaders] },
    { range: "'Housekeeping Log'!A1:I1", values: [housekeepingHeaders] },
    { range: "'Billing Folios & Invoices'!A1:L1", values: [billingHeaders] },
    { range: "'Expenses & Accounts'!A1:K1", values: [expenseHeaders] },
    { range: "'Service Feedback'!A1:P1", values: [feedbackHeaders] }
  ];

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values:batchUpdate`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      valueInputOption: 'USER_ENTERED',
      data: valueRanges
    })
  });
}

/**
 * Requirement 6: Format guest registration row with document Drive links
 */
function formatGuestRow(g: GuestRegistration) {
  return [
    g.id,
    `${g.givenName} ${g.surname}`.trim(),
    g.email || '',
    g.phone || '',
    g.roomNumber || '',
    g.nationality || (g.guestType === 'domestic' ? 'Indian' : 'Foreign'),
    g.passportNumber || '',
    g.status || 'active',
    g.checkInDate || '',
    g.checkOutDate || '',
    g.purposeOfVisit || 'Heritage Tourism',
    g.visaNumber ? `Visa: ${g.visaNumber} (exp ${g.visaExpiryDate || 'N/A'})` : (g.idType ? `${g.idType} Verified` : 'Govt ID Verified'),
    `FORM-C-${g.id}`,
    g.nextDestination || 'Johari Bazar, Jaipur',
    g.createdAt || new Date().toISOString(),
    g.status === 'active' ? 'Active In-House' : 'Departed / Settled',
    g.driveDocumentLink || (g.passportDocument ? '[Attached locally / Form C]' : ''),
    g.drivePhotoLink || (g.guestPhoto ? '[Attached locally / Camera]' : ''),
    g.driveSignatureLink || (g.signature ? '[Signed on Digital Pad]' : '')
  ];
}

/**
 * Sync all guests to the Google Sheet tab
 */
export async function syncGuestsToSheet(
  accessToken: string, 
  spreadsheetId: string, 
  guests: GuestRegistration[]
) {
  const rows = guests.map(formatGuestRow);

  // Clear existing rows below header
  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Guest Register & Form C'!A2:S500:clear`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  }).catch(() => {});

  if (rows.length > 0) {
    const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Guest Register & Form C'!A2:S${rows.length + 1}?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: rows })
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to update guests in Google Sheet');
    }
  }

  return { success: true, count: rows.length };
}

/**
 * Sync dining orders to the Google Sheet tab
 */
export async function syncOrdersToSheet(
  accessToken: string,
  spreadsheetId: string,
  orders: FoodOrder[]
) {
  const rows = orders.map(o => {
    const itemsSummary = o.items.map(i => `${i.name} (${i.quantity}x)`).join(', ');
    const itemCount = o.items.reduce((sum, i) => sum + i.quantity, 0);
    return [
      o.id,
      o.guestId,
      o.guestName,
      o.roomNumber,
      itemsSummary,
      itemCount,
      o.total,
      o.status,
      o.specialInstructions || '',
      o.placedAt
    ];
  });

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'In-Room Dining Orders'!A2:J500:clear`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  }).catch(() => {});

  if (rows.length > 0) {
    const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'In-Room Dining Orders'!A2:J${rows.length + 1}?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: rows })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to sync dining orders to Google Sheet');
    }
  }

  return { success: true, count: rows.length };
}

/**
 * Sync housekeeping requests to the Google Sheet tab
 */
export async function syncHousekeepingToSheet(
  accessToken: string,
  spreadsheetId: string,
  requests: HousekeepingRequest[]
) {
  const rows = requests.map(h => [
    h.id,
    h.guestId,
    h.guestName,
    h.roomNumber,
    h.requestType,
    h.preferredTime,
    h.status,
    h.notes || '',
    h.requestedAt
  ]);

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Housekeeping Log'!A2:I500:clear`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  }).catch(() => {});

  if (rows.length > 0) {
    const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Housekeeping Log'!A2:I${rows.length + 1}?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: rows })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to sync housekeeping to Google Sheet');
    }
  }

  return { success: true, count: rows.length };
}

/**
 * Sync invoices to the Google Sheet tab
 */
export async function syncInvoicesToSheet(
  accessToken: string,
  spreadsheetId: string,
  invoices: Invoice[]
) {
  const rows = invoices.map(inv => [
    inv.id,
    inv.guestId,
    inv.guestName,
    inv.roomNumber,
    inv.roomRatePerNight * inv.nights,
    inv.subtotal - (inv.roomRatePerNight * inv.nights),
    inv.taxes + inv.conservationLevy,
    inv.grandTotal,
    inv.paidAmount,
    inv.balanceDue,
    inv.status,
    inv.generatedAt
  ]);

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Billing Folios & Invoices'!A2:L500:clear`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  }).catch(() => {});

  if (rows.length > 0) {
    const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Billing Folios & Invoices'!A2:L${rows.length + 1}?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: rows })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to sync invoices to Google Sheet');
    }
  }

  return { success: true, count: rows.length };
}

/**
 * Sync expenses to the Google Sheet tab
 */
export async function syncExpensesToSheet(
  accessToken: string,
  spreadsheetId: string,
  expenses: ExpenseItem[]
) {
  const rows = expenses.map(exp => [
    exp.id,
    exp.title,
    exp.category,
    exp.amount,
    exp.date,
    exp.paymentMethod,
    exp.submittedBy,
    exp.status === 'approved' ? 'Approved' : (exp.status === 'rejected' ? 'Rejected' : 'Pending Approval'),
    exp.approvedBy || '',
    exp.approvedAt || '',
    exp.notes || ''
  ]);

  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Expenses & Accounts'!A2:K500:clear`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  }).catch(() => {});

  if (rows.length > 0) {
    const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Expenses & Accounts'!A2:K${rows.length + 1}?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: rows })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to sync expenses to Google Sheet');
    }
  }

  return { success: true, count: rows.length };
}

/**
 * Append a single newly checked-in guest directly to the common master Google Sheet
 */
export async function appendGuestToSheet(
  accessToken: string,
  spreadsheetId: string,
  guest: GuestRegistration
) {
  const row = formatGuestRow(guest);

  const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Guest Register & Form C'!A:S:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ values: [row] })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    console.error('Failed to append guest to Google Sheet:', err);
  }
}

/**
 * Ensure 'Service Feedback' sheet tab exists in an existing spreadsheet
 */
export async function ensureServiceFeedbackTab(accessToken: string, spreadsheetId: string) {
  try {
    const metaRes = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}?fields=sheets.properties.title`, {
      headers: { Authorization: `Bearer ${accessToken}` }
    });
    if (!metaRes.ok) return;
    const meta = await metaRes.json();
    const existingTitles: string[] = (meta.sheets || []).map((s: any) => s.properties?.title);
    if (!existingTitles.includes('Service Feedback')) {
      // Add sheet tab
      const addRes = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}:batchUpdate`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          requests: [
            {
              addSheet: {
                properties: {
                  title: 'Service Feedback',
                  gridProperties: { rowCount: 150, columnCount: 16 }
                }
              }
            }
          ]
        })
      });

      if (addRes.ok) {
        // Populate header row
        const feedbackHeaders = [
          'Feedback ID', 'Guest ID', 'Guest Name', 'Suite / Room', 'Category', 
          'Target Reference ID', 'Service / Order Description', 'Rating (Stars)', 
          'Quality (1-5)', 'Speed (1-5)', 'Staff Courtesy (1-5)', 
          'Key Highlights / Tags', 'Guest Comments & Review', 'NPS Score (1-10)', 
          'Submitted At', 'Follow-up Status'
        ];
        await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Service Feedback'!A1:P1?valueInputOption=USER_ENTERED`, {
          method: 'PUT',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ values: [feedbackHeaders] })
        });
      }
    }
  } catch (err) {
    console.warn('Could not verify/create Service Feedback tab:', err);
  }
}

/**
 * Format feedback record for Google Sheet row
 */
export function formatFeedbackRow(fb: ServiceFeedback) {
  return [
    fb.id,
    fb.guestId,
    fb.guestName,
    fb.roomNumber,
    fb.category === 'dining' ? 'In-Room Dining' : fb.category === 'housekeeping' ? 'Housekeeping & Linen' : 'Stay Experience & Checkout',
    fb.targetId || 'N/A',
    fb.targetTitle || (fb.category === 'stay_checkout' ? 'Overall Stay & Checkout' : 'Service Request'),
    `${fb.rating} ★ (${fb.rating}/5)`,
    fb.qualityRating ? `${fb.qualityRating}/5` : 'N/A',
    fb.speedRating ? `${fb.speedRating}/5` : 'N/A',
    fb.courtesyRating ? `${fb.courtesyRating}/5` : 'N/A',
    (fb.tags && fb.tags.length > 0) ? fb.tags.join(', ') : 'None',
    fb.comments || '',
    fb.npsScore ? `${fb.npsScore}/10` : 'N/A',
    fb.createdAt,
    fb.followUpStatus ? fb.followUpStatus.toUpperCase() : 'THANKED'
  ];
}

/**
 * Sync all post-service feedback to Google Sheet 'Service Feedback' tab
 */
export async function syncFeedbackToSheet(
  accessToken: string,
  spreadsheetId: string,
  feedbacks: ServiceFeedback[]
) {
  await ensureServiceFeedbackTab(accessToken, spreadsheetId);
  const rows = feedbacks.map(formatFeedbackRow);

  // Clear existing rows below header
  await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Service Feedback'!A2:P500:clear`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${accessToken}` }
  }).catch(() => {});

  if (rows.length > 0) {
    const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Service Feedback'!A2:P${rows.length + 1}?valueInputOption=USER_ENTERED`, {
      method: 'PUT',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ values: rows })
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      throw new Error(err?.error?.message || 'Failed to sync service feedback to Google Sheet');
    }
  }

  return { success: true, count: rows.length };
}

/**
 * Append a single newly submitted feedback directly to Google Sheet 'Service Feedback' tab
 */
export async function appendFeedbackToSheet(
  accessToken: string,
  spreadsheetId: string,
  feedback: ServiceFeedback
) {
  await ensureServiceFeedbackTab(accessToken, spreadsheetId);
  const row = formatFeedbackRow(feedback);

  const res = await fetch(`${SHEETS_API_BASE}/${spreadsheetId}/values/'Service Feedback'!A:P:append?valueInputOption=USER_ENTERED`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ values: [row] })
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    console.error('Failed to append feedback to Google Sheet:', err);
  }
}

