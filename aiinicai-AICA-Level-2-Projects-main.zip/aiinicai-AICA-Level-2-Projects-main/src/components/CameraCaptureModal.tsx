import React, { useState, useRef, useEffect } from 'react';
import { Camera, RefreshCw, Check, X, SwitchCamera, AlertCircle, Upload, Smartphone } from 'lucide-react';
import { optimizeImageForOcr } from '../utils/imageUtils';

interface CameraCaptureModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCapture: (dataUrl: string) => void;
  title: string;
  guideMode?: 'passport' | 'selfie';
}

export const CameraCaptureModal: React.FC<CameraCaptureModalProps> = ({
  isOpen,
  onClose,
  onCapture,
  title,
  guideMode = 'selfie'
}) => {
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>(guideMode === 'passport' ? 'environment' : 'user');
  const [capturedImage, setCapturedImage] = useState<string | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isInitializing, setIsInitializing] = useState(false);
  const [isProcessingImage, setIsProcessingImage] = useState(false);

  const startCamera = async () => {
    setIsInitializing(true);
    setCameraError(null);
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
    }

    try {
      const constraints: MediaStreamConstraints = {
        video: {
          facingMode: facingMode,
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      };

      const mediaStream = await navigator.mediaDevices.getUserMedia(constraints);
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err: any) {
      console.warn('Camera access issue:', err);
      setCameraError(
        err.name === 'NotAllowedError'
          ? 'Camera permission was denied. You can upload an image file instead or allow camera access in browser settings.'
          : 'Unable to access device camera. Please use the file upload option below.'
      );
    } finally {
      setIsInitializing(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      startCamera();
    } else {
      stopCamera();
    }
    return () => {
      stopCamera();
    };
  }, [isOpen, facingMode]);

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setCapturedImage(null);
  };

  const takeSnapshot = async () => {
    const video = videoRef.current;
    if (!video) return;

    setIsProcessingImage(true);
    try {
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth || 1280;
      canvas.height = video.videoHeight || 720;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Flip horizontally if front camera selfie
      if (facingMode === 'user') {
        ctx.translate(canvas.width, 0);
        ctx.scale(-1, 1);
      }
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const rawDataUrl = canvas.toDataURL('image/jpeg', 0.95);
      const optimized = await optimizeImageForOcr(rawDataUrl, 1600, 0.85);
      setCapturedImage(optimized);
    } catch (err) {
      console.warn('Image capture optimization issue:', err);
    } finally {
      setIsProcessingImage(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessingImage(true);
    try {
      const optimized = await optimizeImageForOcr(file, 1600, 0.85);
      setCapturedImage(optimized);
    } catch (err) {
      console.warn('File read issue:', err);
    } finally {
      setIsProcessingImage(false);
    }
  };

  const confirmCapture = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      stopCamera();
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div id="camera-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg overflow-hidden rounded-2xl border border-amber-500/30 bg-[#0d1f15] text-[#f7f4ea] shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-amber-500/20 px-5 py-4 bg-[#142b1f]">
          <div className="flex items-center gap-2">
            <Camera className="w-5 h-5 text-[#d4af37]" />
            <h3 className="font-display font-medium text-lg text-[#f7f4ea]">{title}</h3>
          </div>
          <button
            onClick={() => { stopCamera(); onClose(); }}
            className="rounded-lg p-1.5 text-amber-200/60 hover:bg-black/30 hover:text-amber-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder Area */}
        <div className="relative bg-black aspect-4/3 flex items-center justify-center overflow-hidden">
          {capturedImage ? (
            <img src={capturedImage} alt="Captured" className="w-full h-full object-cover" />
          ) : cameraError ? (
            <div className="p-6 text-center max-w-xs space-y-3">
              <AlertCircle className="w-10 h-10 text-amber-400 mx-auto" />
              <p className="text-xs text-amber-200/80">{cameraError}</p>
              <label className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-amber-500 text-black font-semibold text-xs cursor-pointer hover:bg-amber-400 transition-colors shadow">
                <Upload className="w-4 h-4" />
                Select Photo from Device
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>
            </div>
          ) : (
            <>
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
              />

              {/* Guidelines overlay */}
              <div className="pointer-events-none absolute inset-6 rounded-2xl border-2 border-dashed border-[#d4af37]/60 flex flex-col items-center justify-between p-4">
                <span className="text-[11px] bg-black/60 px-3 py-1 rounded-full text-amber-300 font-medium tracking-wide">
                  {guideMode === 'passport' ? 'Align Passport Page & MRZ inside frame' : 'Center Face in oval portrait'}
                </span>
                {guideMode === 'selfie' && (
                  <div className="w-44 h-56 rounded-full border-2 border-amber-400/40" />
                )}
                <span className="text-[10px] text-amber-200/70 bg-black/40 px-2 py-0.5 rounded">
                  Ensure good lighting and no flash reflections
                </span>
              </div>
            </>
          )}

          {isProcessingImage && (
            <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center gap-2 text-[#d4af37] text-xs z-10">
              <RefreshCw className="w-7 h-7 animate-spin text-[#d4af37]" />
              <span className="font-medium">Optimizing camera capture...</span>
            </div>
          )}

          {isInitializing && (
            <div className="absolute inset-0 bg-black/70 flex items-center justify-center gap-2 text-amber-300 text-xs">
              <RefreshCw className="w-5 h-5 animate-spin" />
              Initializing camera sensor...
            </div>
          )}
        </div>

        {/* Controls Bar */}
        <div className="p-4 bg-[#142b1f] border-t border-amber-500/20 flex items-center justify-between">
          {capturedImage ? (
            <>
              <button
                type="button"
                onClick={() => setCapturedImage(null)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-medium text-amber-300 bg-black/40 border border-amber-500/30 hover:bg-black/60"
              >
                <RefreshCw className="w-4 h-4" /> Retake
              </button>
              <button
                type="button"
                onClick={confirmCapture}
                className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl text-xs font-semibold bg-[#d4af37] text-[#0d1f15] hover:bg-[#e6c454] shadow-lg transition-all"
              >
                <Check className="w-4 h-4" /> Use This Photo
              </button>
            </>
          ) : (
            <>
              <label className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs text-amber-300/80 hover:text-amber-200 bg-black/30 border border-amber-500/20 cursor-pointer" title="Take photo directly with native phone camera">
                <Smartphone className="w-3.5 h-3.5 text-[#d4af37]" />
                <span className="hidden xs:inline">Phone Cam</span>
                <input type="file" accept="image/*" capture="environment" onChange={handleFileUpload} className="hidden" />
              </label>

              <button
                type="button"
                onClick={takeSnapshot}
                disabled={Boolean(cameraError) || isInitializing || isProcessingImage}
                className="w-14 h-14 rounded-full bg-white border-4 border-[#d4af37] flex items-center justify-center shadow-xl hover:scale-105 active:scale-95 transition-transform disabled:opacity-50"
                title="Capture Photo"
              >
                <div className="w-10 h-10 rounded-full bg-[#d4af37]" />
              </button>

              <button
                type="button"
                onClick={() => setFacingMode(prev => prev === 'user' ? 'environment' : 'user')}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs text-amber-300/80 hover:text-amber-200 bg-black/30 border border-amber-500/20"
                title="Switch Camera"
              >
                <SwitchCamera className="w-4 h-4" />
                Flip
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
