import React, { useState, useEffect } from 'react';
import { 
  Sparkles, CheckCircle2, Clock, Shield, Bell, 
  Send, AlertCircle, RefreshCw, Feather, Check,
  ChevronRight, Calendar, User, CheckCircle, Star
} from 'lucide-react';
import { HousekeepingRequest, HousekeepingType, GuestRegistration } from '../types';
import { fetchHousekeepingRequests, createHousekeepingRequest } from '../utils/api';
import { FeedbackModal } from './FeedbackModal';

interface HousekeepingSectionProps {
  currentGuest: GuestRegistration | null;
  onSuccessNotification?: (msg: string) => void;
}

const HOUSEKEEPING_TYPES: {
  type: HousekeepingType;
  title: string;
  badge: string;
  description: string;
  estimatedMins: number;
  items: string[];
}[] = [
  {
    type: 'Standard Tidy',
    title: 'Standard Tidy & Refresh',
    badge: 'Popular • Daily Maintenance',
    description: 'Crisp bed making, floor sweep & damp mop, dust surfaces, empty wastebaskets, and replenish fresh filtered earthen drinking water.',
    estimatedMins: 20,
    items: ['Bed made & pillows fluffed', 'Floor swept & mopped', 'Trash bins cleared', 'Water carafes replenished']
  },
  {
    type: 'Deep Clean',
    title: 'Heritage Deep Clean',
    badge: 'Thorough • Full Sanitization',
    description: 'Complete suite sanitization, bathroom scrub & disinfection, fresh bed linen & duvet cover change, and royal lavender room mist.',
    estimatedMins: 45,
    items: ['Complete linen & duvet replacement', 'Bathroom scrubbing & disinfection', 'Upholstery & rug vacuumed', 'Aromatherapy lavender mist']
  },
  {
    type: 'Fresh Towels',
    title: 'Fresh Towels & Toiletries',
    badge: 'Quick Delivery • 15 Mins',
    description: 'Set of plush 600 GSM organic cotton bath sheets, hand towels, bath mats, and replenishment of handmade ayurvedic neem & sandalwood soaps.',
    estimatedMins: 15,
    items: ['2x Luxury plush bath towels', '2x Hand & face towels', 'Ayurvedic soaps & shampoo', 'Fresh cotton bath mats']
  }
];

const TIME_OPTIONS = [
  'Immediate (Next 30 mins)',
  'Morning (9:00 - 11:00 AM)',
  'Afternoon (2:00 - 4:00 PM)',
  'Evening Turndown (6:00 - 8:00 PM)'
];

export const HousekeepingSection: React.FC<HousekeepingSectionProps> = ({
  currentGuest,
  onSuccessNotification
}) => {
  const [selectedType, setSelectedType] = useState<HousekeepingType>('Standard Tidy');
  const [selectedTime, setSelectedTime] = useState<string>('Immediate (Next 30 mins)');
  const [cleaningNotes, setCleaningNotes] = useState<string>('');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [requests, setRequests] = useState<HousekeepingRequest[]>([]);
  const [isLoadingRequests, setIsLoadingRequests] = useState<boolean>(true);
  const [feedbackMsg, setFeedbackMsg] = useState<string | null>(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState<boolean>(false);
  const [selectedFeedbackReq, setSelectedFeedbackReq] = useState<HousekeepingRequest | null>(null);

  const guestId = currentGuest?.id || 'GUEST-8021';
  const guestName = currentGuest ? `${currentGuest.givenName} ${currentGuest.surname}` : 'Elena Rostova';
  const roomNumber = currentGuest?.roomNumber || 'Suite 101 - The Royal Haveli';

  const loadRequests = async () => {
    try {
      const data = await fetchHousekeepingRequests(guestId);
      setRequests(data);
    } catch (err) {
      console.error('Error fetching housekeeping requests:', err);
    } finally {
      setIsLoadingRequests(false);
    }
  };

  useEffect(() => {
    loadRequests();
    const interval = setInterval(loadRequests, 5000);
    return () => clearInterval(interval);
  }, [guestId]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setFeedbackMsg(null);

    try {
      const res = await createHousekeepingRequest({
        guestId,
        guestName,
        roomNumber,
        requestType: selectedType,
        preferredTime: selectedTime,
        notes: cleaningNotes.trim()
      });

      if (res.success) {
        setFeedbackMsg(`Your request for "${selectedType}" has been logged! Our floor staff will attend to ${roomNumber}.`);
        if (onSuccessNotification) {
          onSuccessNotification(`Housekeeping request submitted for ${selectedType}`);
        }
        setCleaningNotes('');
        loadRequests();
      }
    } catch (err: any) {
      alert(`Could not submit request: ${err.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div id="housekeeping-service-panel" className="space-y-6">
      {/* Intro Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#d4af37] bg-black/40 px-2.5 py-0.5 rounded-full border border-amber-500/20">
              Palace Housekeeping &amp; Linen Service
            </span>
            <span className="text-xs text-amber-200/60">• {roomNumber}</span>
          </div>
          <h3 className="font-display font-bold text-xl sm:text-2xl text-[#f7f4ea] mt-1">
            Housekeeping &amp; Cleaning Request
          </h3>
          <p className="text-xs text-amber-200/70">
            Select your preferred cleaning requirement. Our haveli floor captains attend to all requests promptly.
          </p>
        </div>

        <button
          onClick={loadRequests}
          className="text-xs text-[#d4af37] hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#142b1f] border border-amber-500/20 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Refresh Status</span>
        </button>
      </div>

      {feedbackMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2.5 shadow-lg animate-fadeIn">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{feedbackMsg}</span>
        </div>
      )}

      {/* 3 Housekeeping Request Type Toggle Cards */}
      <div className="space-y-2">
        <label className="block text-xs font-bold text-amber-300 uppercase tracking-wider">
          1. Select Cleaning Request Type:
        </label>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
          {HOUSEKEEPING_TYPES.map(item => {
            const isSelected = selectedType === item.type;
            return (
              <div
                key={item.type}
                onClick={() => setSelectedType(item.type)}
                className={`cursor-pointer rounded-2xl p-4 border transition-all relative ${
                  isSelected
                    ? 'bg-gradient-to-br from-[#1b3a29] to-[#12261b] border-[#d4af37] shadow-xl ring-2 ring-[#d4af37]/40'
                    : 'bg-[#0d1f15]/90 border-amber-500/20 hover:border-amber-500/40 opacity-90'
                }`}
              >
                {isSelected && (
                  <span className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#d4af37] text-[#0d1f15] flex items-center justify-center text-xs font-bold shadow">
                    ✓
                  </span>
                )}
                <span className="text-[10px] font-semibold text-[#d4af37] bg-black/40 px-2 py-0.5 rounded-full border border-amber-500/20">
                  {item.badge}
                </span>
                <h4 className="font-display font-bold text-base text-[#f7f4ea] mt-2">
                  {item.type}
                </h4>
                <p className="text-xs text-amber-200/70 leading-relaxed mt-1">
                  {item.description}
                </p>

                <div className="mt-3 pt-2.5 border-t border-amber-500/10 space-y-1">
                  {item.items.map((sub, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-[11px] text-amber-200/60">
                      <span className="text-[#d4af37]">•</span>
                      <span>{sub}</span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Form Details: Preferred Time & Custom Cleaning Requirement */}
      <form onSubmit={handleSubmit} className="bg-[#12261b] rounded-2xl border border-amber-500/20 p-5 space-y-4 shadow-xl">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Preferred Timing */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-amber-200/90 flex items-center justify-between">
              <span>2. Preferred Service Time Slot:</span>
              <span className="text-[11px] text-[#d4af37]">{selectedTime}</span>
            </label>
            <div className="grid grid-cols-2 gap-2 text-xs">
              {TIME_OPTIONS.map(time => (
                <button
                  key={time}
                  type="button"
                  onClick={() => setSelectedTime(time)}
                  className={`px-3 py-2 rounded-xl text-left font-medium border text-[11px] transition-all ${
                    selectedTime === time
                      ? 'bg-[#d4af37] text-[#0d1f15] font-bold border-[#d4af37] shadow'
                      : 'bg-[#0a1810] text-amber-200/70 border-amber-500/20 hover:border-amber-500/40'
                  }`}
                >
                  {time}
                </button>
              ))}
            </div>
          </div>

          {/* Specific Cleaning Requirement / Notes */}
          <div className="space-y-1.5">
            <label className="block text-xs font-bold text-amber-200/90">
              3. Specific Cleaning Requirements or Instructions:
            </label>
            <textarea
              rows={3}
              value={cleaningNotes}
              onChange={e => setCleaningNotes(e.target.value)}
              placeholder="e.g. Please do not disturb until 10:30 AM, extra lavender pillows, replenish almond-sandalwood soaps..."
              className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] p-3 text-xs text-amber-100 placeholder:text-amber-200/40 focus:border-[#d4af37] focus:outline-none"
            />
          </div>
        </div>

        {/* Submit Button */}
        <div className="flex items-center justify-between pt-2 border-t border-amber-500/10">
          <span className="text-[11px] text-amber-200/60 hidden sm:inline">
            Floor attendants notify via concierge chat once service commences.
          </span>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-[#d4af37] text-[#0d1f15] font-bold text-xs hover:bg-[#e4bf4d] active:scale-95 transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {isSubmitting ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Submitting Request...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Submit {selectedType} Request</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Guest Request History & Live Status Tracker */}
      <div className="space-y-3">
        <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider flex items-center justify-between">
          <span>Active &amp; Recent Housekeeping Requests</span>
          <span className="text-[11px] text-amber-200/60 font-normal">{requests.length} requests logged</span>
        </h4>

        {isLoadingRequests ? (
          <div className="py-6 text-center text-xs text-amber-200/50">
            Loading housekeeping activity...
          </div>
        ) : requests.length === 0 ? (
          <div className="p-4 rounded-xl bg-black/20 border border-amber-500/10 text-center text-xs text-amber-200/50">
            No active housekeeping requests for this room yet. Select a service above to request cleaning or fresh linen.
          </div>
        ) : (
          <div className="space-y-2">
            {requests.map(req => {
              const isCompleted = req.status === 'completed';
              const isInProgress = req.status === 'in_progress';
              return (
                <div
                  key={req.id}
                  className="bg-[#12261b] rounded-xl border border-amber-500/20 p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <strong className="text-amber-100 font-semibold text-sm">
                        {req.requestType}
                      </strong>
                      <span className="text-[10px] font-mono text-[#d4af37] bg-black/30 px-2 py-0.5 rounded border border-amber-500/20">
                        #{req.id}
                      </span>
                    </div>
                    <p className="text-[11px] text-amber-200/70">
                      Time Slot: <strong className="text-amber-200">{req.preferredTime}</strong>
                      {req.notes && <span> • Note: "{req.notes}"</span>}
                    </p>
                    <p className="text-[10px] text-amber-200/40">
                      Requested at {new Date(req.requestedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      {req.assignedStaff && <span> • Assigned Attendant: <strong className="text-amber-300">{req.assignedStaff}</strong></span>}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider flex items-center gap-1 ${
                      isCompleted
                        ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                        : isInProgress
                        ? 'bg-amber-950 text-amber-300 border border-amber-500/40 animate-pulse'
                        : 'bg-black/40 text-amber-200/80 border border-amber-500/20'
                    }`}>
                      {isCompleted ? (
                        <>
                          <CheckCircle className="w-3 h-3 text-emerald-400" /> Completed
                        </>
                      ) : isInProgress ? (
                        <>
                          <Clock className="w-3 h-3 text-amber-400" /> In Progress
                        </>
                      ) : (
                        <>
                          <Clock className="w-3 h-3 text-amber-200/60" /> Pending Floor Staff
                        </>
                      )}
                    </span>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFeedbackReq(req);
                        setIsFeedbackOpen(true);
                      }}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/40 border border-amber-500/30 text-[#d4af37] hover:text-white hover:bg-black/60 transition-all font-semibold text-[10px]"
                    >
                      <Star className="w-3 h-3 fill-current" />
                      <span>Rate Service</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Post-Service Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        currentGuest={currentGuest}
        initialCategory="housekeeping"
        initialTargetId={selectedFeedbackReq?.id}
        initialTargetTitle={selectedFeedbackReq ? `Request #${selectedFeedbackReq.id} (${selectedFeedbackReq.requestType})` : 'Housekeeping & Room Care'}
        housekeepingRequests={requests}
      />
    </div>
  );
};
