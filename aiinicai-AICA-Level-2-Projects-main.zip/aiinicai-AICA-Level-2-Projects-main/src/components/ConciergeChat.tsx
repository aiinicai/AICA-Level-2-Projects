import React, { useState, useEffect, useRef } from 'react';
import { 
  MessageSquare, Send, Sparkles, User, Shield, Clock, 
  Bell, Feather, CheckCircle2, ChevronRight, RefreshCw, Shirt
} from 'lucide-react';
import { ChatMessage, GuestRegistration } from '../types';
import { fetchChats, sendChatMessage } from '../utils/api';
import { HousekeepingSection } from './HousekeepingSection';

interface ConciergeChatProps {
  currentGuest: GuestRegistration | null;
}

const QUICK_PROMPTS = [
  'What time is breakfast served in the courtyard?',
  'Please send 2 fresh bath towels to my suite',
  'What is the status of my kitchen dining order?',
  'Could you arrange a local heritage walking tour?',
  'How do I request express checkout & final invoice?'
];

export const ConciergeChat: React.FC<ConciergeChatProps> = ({ currentGuest }) => {
  const [activeConciergeTab, setActiveConciergeTab] = useState<'chat' | 'housekeeping'>('chat');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const guestId = currentGuest?.id || 'GUEST-8021';
  const guestName = currentGuest ? `${currentGuest.givenName} ${currentGuest.surname}` : 'Elena Rostova';
  const roomNumber = currentGuest?.roomNumber || 'Suite 101 - The Royal Haveli';

  const loadMessages = async () => {
    try {
      const data = await fetchChats(guestId);
      setMessages(data);
    } catch (err) {
      console.error('Error fetching chats:', err);
    }
  };

  useEffect(() => {
    loadMessages();
    const timer = setInterval(loadMessages, 3000); // Polling for real-time messages
    return () => clearInterval(timer);
  }, [guestId]);

  useEffect(() => {
    if (activeConciergeTab === 'chat') {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, activeConciergeTab]);

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || inputText;
    if (!text.trim() || isSending) return;

    setIsSending(true);
    setInputText('');

    try {
      await sendChatMessage({
        guestId,
        roomNumber,
        sender: 'guest',
        senderName: guestName,
        message: text.trim()
      });
      loadMessages();
    } catch (err: any) {
      alert(`Could not send message: ${err.message}`);
    } finally {
      setIsSending(false);
    }
  };

  const handleHousekeepingSuccess = (msg: string) => {
    setNotificationMsg(msg);
    setTimeout(() => setNotificationMsg(null), 5000);
    loadMessages();
  };

  return (
    <div id="concierge-section-wrapper" className="max-w-4xl mx-auto space-y-6">
      {/* Top Concierge Header with Sub-tabs (Live Butler Chat vs Housekeeping Request) */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#d4af37] bg-black/40 px-3 py-1 rounded-full border border-amber-500/20">
            24/7 Haveli Guest Services
          </span>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#f7f4ea] mt-1.5">
            Concierge &amp; Butler Services
          </h2>
          <p className="text-xs text-amber-200/70">
            Attending to {guestName} • {roomNumber}
          </p>
        </div>

        {/* Section Tabs: Chat vs Housekeeping */}
        <div className="flex items-center gap-1.5 p-1 rounded-2xl bg-[#142b1f] border border-amber-500/30 shadow-inner">
          <button
            onClick={() => setActiveConciergeTab('chat')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeConciergeTab === 'chat'
                ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
                : 'text-amber-200/80 hover:text-white'
            }`}
          >
            <MessageSquare className="w-4 h-4" />
            <span>Butler Chat</span>
          </button>

          <button
            onClick={() => setActiveConciergeTab('housekeeping')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${
              activeConciergeTab === 'housekeeping'
                ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
                : 'text-amber-200/80 hover:text-white'
            }`}
          >
            <Sparkles className="w-4 h-4 text-[#e6ca65]" />
            <span>Housekeeping Request</span>
          </button>
        </div>
      </div>

      {notificationMsg && (
        <div className="p-3 rounded-2xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 shadow animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{notificationMsg}</span>
        </div>
      )}

      {/* View 1: Housekeeping Request Tab */}
      {activeConciergeTab === 'housekeeping' && (
        <HousekeepingSection
          currentGuest={currentGuest}
          onSuccessNotification={handleHousekeepingSuccess}
        />
      )}

      {/* View 2: Live Concierge Chat */}
      {activeConciergeTab === 'chat' && (
        <div id="concierge-chat-container" className="h-[620px] flex flex-col rounded-2xl border border-amber-500/30 bg-[#0d1f15] shadow-2xl overflow-hidden">
          {/* Chat Header */}
          <div className="bg-[#142b1f] border-b border-amber-500/20 px-5 py-3.5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-[#1b3a29] border border-[#d4af37] flex items-center justify-center text-[#d4af37]">
                  <MessageSquare className="w-5 h-5" />
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-400 border-2 border-[#142b1f] rounded-full" />
              </div>
              <div>
                <h3 className="font-display font-semibold text-base text-[#f7f4ea]">
                  Heritique Front Desk &amp; Concierge
                </h3>
                <p className="text-[11px] text-amber-200/60">
                  Live assistance for {roomNumber} • Typical reply time: &lt; 2 mins
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveConciergeTab('housekeeping')}
                className="hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-xl bg-[#1b3a29] border border-amber-500/30 text-amber-200 hover:text-white text-[11px] font-semibold transition-colors"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" />
                <span>Request Housekeeping</span>
              </button>
              <span className="text-[10px] text-emerald-400 font-semibold bg-emerald-950/80 px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> Online
              </span>
            </div>
          </div>

          {/* Quick Prompts Bar */}
          <div className="bg-[#0a1810] px-4 py-2 border-b border-amber-500/10 flex items-center gap-2 overflow-x-auto text-[11px] text-amber-200/70 shrink-0">
            <span className="text-[#d4af37] font-semibold shrink-0">Quick Ask:</span>
            {QUICK_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(prompt)}
                className="whitespace-nowrap px-2.5 py-1 rounded-full bg-[#142b1f] border border-amber-500/20 text-amber-200 hover:border-amber-500/40 hover:text-white transition-colors"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Messages List */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-radial from-[#12261b]/30 to-[#07130c]">
            {messages.map((msg) => {
              const isGuest = msg.sender === 'guest';
              const isAI = msg.sender === 'concierge_ai';
              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${isGuest ? 'items-end' : 'items-start'}`}
                >
                  <div className="flex items-center gap-1.5 mb-1 px-1 text-[10px] text-amber-200/60">
                    {isGuest ? (
                      <>
                        <span>You ({msg.senderName})</span>
                        <User className="w-3 h-3 text-[#d4af37]" />
                      </>
                    ) : (
                      <>
                        <Shield className="w-3 h-3 text-emerald-400" />
                        <span className="font-semibold text-amber-300">
                          {msg.senderName} {isAI && '• Automated Butler'}
                        </span>
                      </>
                    )}
                    <span>• {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>

                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-xs leading-relaxed shadow ${
                      isGuest
                        ? 'bg-[#d4af37] text-[#0d1f15] font-medium rounded-tr-none'
                        : isAI
                        ? 'bg-[#1b3a29] text-amber-100 border border-amber-500/30 rounded-tl-none'
                        : 'bg-[#173826] text-amber-100 border border-emerald-500/30 rounded-tl-none'
                    }`}
                  >
                    {msg.message}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Message Input */}
          <div className="bg-[#142b1f] border-t border-amber-500/20 p-3 flex items-center gap-2">
            <input
              type="text"
              value={inputText}
              onChange={e => setInputText(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter') handleSend();
              }}
              placeholder={`Message front desk from ${roomNumber}...`}
              className="flex-1 rounded-xl border border-amber-500/30 bg-[#0a1810] px-4 py-2.5 text-xs text-amber-100 placeholder:text-amber-200/40 focus:border-[#d4af37] focus:outline-none"
            />
            <button
              onClick={() => handleSend()}
              disabled={!inputText.trim() || isSending}
              className="p-2.5 rounded-xl bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed shadow"
              title="Send Message"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
