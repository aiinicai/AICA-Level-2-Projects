import React, { useState, useEffect } from 'react';
import { 
  Receipt, CreditCard, ShieldCheck, CheckCircle2, Download, 
  Printer, ArrowRight, X, Clock, AlertCircle, RefreshCw, 
  Building2, QrCode, Lock, Sparkles, Check, Car, Coffee, Gift, Star
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Invoice, PaymentTransaction, GuestRegistration, BillingFolio } from '../types';
import { requestCheckoutInvoice, processCheckoutPayment } from '../utils/api';
import { FeedbackModal } from './FeedbackModal';

interface InvoiceCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentGuest: GuestRegistration | null;
  onCheckoutSuccess?: (invoice: Invoice, txn: PaymentTransaction) => void;
}

export const InvoiceCheckoutModal: React.FC<InvoiceCheckoutModalProps> = ({
  isOpen,
  onClose,
  currentGuest,
  onCheckoutSuccess
}) => {
  const [invoice, setInvoice] = useState<Invoice | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isProcessingPayment, setIsProcessingPayment] = useState<boolean>(false);
  const [activeGateway, setActiveGateway] = useState<'Stripe' | 'PayPal' | 'UPI'>('Stripe');
  const [completedTxn, setCompletedTxn] = useState<PaymentTransaction | null>(null);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState<boolean>(false);
  const [checkoutDateInput, setCheckoutDateInput] = useState<string>(
    currentGuest?.checkOutDate || new Date().toISOString().split('T')[0]
  );

  // Optional add-on services at checkout
  const [selectedAddons, setSelectedAddons] = useState<{ [key: string]: boolean }>({});

  // Stripe form fields
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExp, setCardExp] = useState('08/29');
  const [cardCvc, setCardCvc] = useState('888');
  const [cardName, setCardName] = useState(
    currentGuest ? `${currentGuest.givenName} ${currentGuest.surname}` : 'Elena Rostova'
  );
  const [postalCode, setPostalCode] = useState('302001');

  // PayPal fields
  const [paypalEmail, setPaypalEmail] = useState(
    currentGuest?.email || 'guest@heritiquehomestay.com'
  );

  // UPI fields
  const [upiId, setUpiId] = useState('guest@okhdfcbank');

  const guestId = currentGuest?.id || 'GUEST-8021';

  const loadInvoice = async () => {
    setIsLoading(true);
    try {
      const addons: { description: string; price: number }[] = [];
      if (selectedAddons['transfer']) {
        addons.push({ description: 'Chauffeur Haveli Transfer to Jaipur Airport/Station', price: 1200 });
      }
      if (selectedAddons['late_checkout']) {
        addons.push({ description: 'Extended Late Checkout Privilege (until 3:00 PM)', price: 800 });
      }
      if (selectedAddons['souvenir']) {
        addons.push({ description: 'Royal Shekhawati Hand-Painted Fresco Art Keepsake', price: 650 });
      }

      const res = await requestCheckoutInvoice({
        guestId,
        checkoutDate: checkoutDateInput,
        additionalServices: addons
      });

      setInvoice(res.invoice);
    } catch (err) {
      console.error('Failed to load invoice:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadInvoice();
    }
  }, [isOpen, checkoutDateInput, selectedAddons]);

  const toggleAddon = (key: string) => {
    setSelectedAddons(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const handlePayAndCheckout = async () => {
    if (!invoice || isProcessingPayment) return;
    setIsProcessingPayment(true);

    try {
      const res = await processCheckoutPayment({
        invoiceId: invoice.id,
        guestId: invoice.guestId,
        amount: invoice.balanceDue > 0 ? invoice.balanceDue : invoice.grandTotal,
        gateway: activeGateway,
        paymentDetails: {
          cardBrand: 'Visa',
          cardLast4: cardNumber.replace(/\s/g, '').slice(-4) || '4242',
          cardholderName: cardName,
          paypalEmail,
          upiId
        }
      });

      if (res.success) {
        setInvoice(res.invoice);
        setCompletedTxn(res.transaction);
        setPaymentSuccess(true);

        try {
          confetti({
            particleCount: 80,
            spread: 70,
            origin: { y: 0.6 }
          });
        } catch {
          // ignore confetti if unsupported
        }

        if (onCheckoutSuccess) {
          onCheckoutSuccess(res.invoice, res.transaction);
        }
      }
    } catch (err: any) {
      alert(`Payment processing failed: ${err.message}`);
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-3xl my-8 rounded-3xl border border-amber-500/40 bg-[#0d1f15] text-[#f7f4ea] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Bar */}
        <div className="bg-[#142b1f] border-b border-amber-500/20 px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#1b3a29] border border-[#d4af37] flex items-center justify-center text-[#d4af37]">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-display font-bold text-base sm:text-lg text-[#f7f4ea]">
                Automated Guest Checkout &amp; Tax Invoice
              </h3>
              <p className="text-[11px] text-amber-200/60">
                Heritique Homestay • Room {invoice?.roomNumber || currentGuest?.roomNumber} • Folio #{invoice?.id || 'Calculating...'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsFeedbackOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-[#1b3a29] border border-[#d4af37]/50 text-[#d4af37] hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Rate Your Stay & Homestay Experience"
            >
              <Star className="w-3.5 h-3.5 fill-current" />
              <span className="hidden sm:inline">Rate Stay</span>
            </button>

            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-xl bg-[#1b3a29] border border-amber-500/30 text-amber-200 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Print Invoice / Save as PDF"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print / PDF</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-xl text-amber-300 hover:text-white hover:bg-black/30 transition-colors"
              title="Close Modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 text-xs">
          {isLoading && !invoice ? (
            <div className="py-16 text-center text-amber-200/60">
              <RefreshCw className="w-8 h-8 mx-auto mb-2 text-[#d4af37] animate-spin" />
              Calculating room rates, dates, dining orders &amp; tax calculations...
            </div>
          ) : invoice && (
            <>
              {/* Payment Success Alert */}
              {paymentSuccess && (
                <div className="p-4 rounded-2xl bg-emerald-950/90 border border-emerald-500/50 text-emerald-200 space-y-1.5 animate-fadeIn">
                  <div className="flex items-center gap-2 font-bold text-sm text-emerald-300">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                    <span>Checkout Payment Successful! Bill Settled in Full</span>
                  </div>
                  <p className="text-[11px] text-emerald-200/80">
                    Transaction ID: <span className="font-mono text-white">{completedTxn?.gatewayTransactionId}</span> • Processed via {completedTxn?.gateway} Gateway.
                    Your room status has been marked as <strong className="text-white">Checked Out</strong>. Thank you for staying with us!
                  </p>
                </div>
              )}

              {/* Post-Checkout Service Feedback Banner */}
              {(paymentSuccess || invoice.status === 'paid') && (
                <div className="p-4 rounded-2xl bg-gradient-to-r from-[#1b3a29] to-[#0d1f15] border-2 border-[#d4af37] text-amber-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 shadow-xl">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-[#d4af37] text-[#0d1f15] flex items-center justify-center font-bold shrink-0 shadow">
                      <Star className="w-5 h-5 fill-current" />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-sm text-white flex items-center gap-2">
                        <span>Rate Your Stay &amp; Homestay Experience</span>
                        <span className="text-[9px] font-sans font-bold uppercase tracking-wider bg-black/40 text-[#d4af37] px-2 py-0.5 rounded border border-[#d4af37]/30">
                          Feedback Module
                        </span>
                      </h4>
                      <p className="text-[11px] text-amber-200/70 mt-0.5">
                        How was your 1924 Haveli stay, Rajput dining, and checkout? Stored in Google Sheet <strong>'Service Feedback'</strong> tab.
                      </p>
                    </div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setIsFeedbackOpen(true)}
                    className="px-4 py-2 rounded-xl bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] active:scale-95 transition-all font-bold text-xs flex items-center gap-1.5 shrink-0 shadow-lg"
                  >
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>Rate Stay Now ★</span>
                  </button>
                </div>
              )}

              {/* Printable Official Invoice Card */}
              <div id="printable-tax-invoice" className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-6 space-y-5 shadow-inner relative">
                {/* Paid Seal Watermark if settled */}
                {invoice.status === 'paid' && (
                  <div className="absolute top-8 right-8 pointer-events-none select-none border-4 border-emerald-500/60 text-emerald-400 font-extrabold uppercase text-xl px-4 py-1 rounded-xl rotate-[-12deg] tracking-widest bg-emerald-950/40 backdrop-blur-xs">
                    PAID IN FULL
                  </div>
                )}

                {/* Letterhead */}
                <div className="flex flex-col sm:flex-row justify-between items-start border-b border-amber-500/20 pb-4 gap-4">
                  <div>
                    <h2 className="font-display font-bold text-2xl text-[#d4af37] tracking-tight">
                      HERITIQUE HOMESTAY
                    </h2>
                    <p className="text-xs text-amber-200/80 font-serif italic">
                      The Royal Haveli &amp; Rajputana Heritage Sanctuary
                    </p>
                    <p className="text-[10px] text-amber-200/50 mt-1">
                      Shekhawati Region • Jaipur-Sikar Heritage Highway, Rajasthan 302001
                    </p>
                    <p className="text-[10px] text-amber-200/50 font-mono">
                      GSTIN: 08AAACH1924R1Z5 • Reg: RAJ-TOURISM-HST-1924-B
                    </p>
                  </div>

                  <div className="sm:text-right space-y-1">
                    <span className="text-[10px] font-bold uppercase tracking-wider bg-black/40 text-[#d4af37] px-2.5 py-0.5 rounded-full border border-amber-500/30">
                      Official Tax Invoice
                    </span>
                    <p className="font-mono text-sm font-bold text-white mt-1">
                      {invoice.id}
                    </p>
                    <p className="text-[10px] text-amber-200/60">
                      Generated: {new Date(invoice.generatedAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                {/* Guest and Stay Details Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-black/30 p-3.5 rounded-xl border border-amber-500/10 text-xs">
                  <div>
                    <span className="text-[10px] text-amber-200/50 block">Guest Name</span>
                    <span className="font-semibold text-amber-100">{invoice.guestName}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-200/50 block">Assigned Suite</span>
                    <span className="font-semibold text-amber-100">{invoice.roomNumber}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-200/50 block">Check-in Date</span>
                    <span className="font-semibold text-amber-100">{invoice.checkInDate}</span>
                  </div>
                  <div>
                    <span className="text-[10px] text-amber-200/50 block">Checkout Date</span>
                    <span className="font-semibold text-amber-100">{invoice.checkOutDate}</span>
                  </div>
                </div>

                {/* Itemized Charges Table */}
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                    Itemized Calculation of Charges
                  </h4>
                  <div className="rounded-xl border border-amber-500/20 overflow-hidden text-xs">
                    <table className="w-full text-left">
                      <thead className="bg-[#173826] text-amber-200/80 border-b border-amber-500/20">
                        <tr>
                          <th className="py-2 px-3">Service / Particulars</th>
                          <th className="py-2 px-3 text-center">Qty / Nights</th>
                          <th className="py-2 px-3 text-right">Unit Tariff</th>
                          <th className="py-2 px-3 text-right">Amount (₹)</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-amber-500/10 bg-[#0d1f15]">
                        {invoice.items.map((item) => (
                          <tr key={item.id}>
                            <td className="py-2 px-3">
                              <p className="font-medium text-amber-100">{item.description}</p>
                              <span className="text-[10px] text-amber-200/50 uppercase tracking-wider">{item.category}</span>
                            </td>
                            <td className="py-2 px-3 text-center text-amber-200/70">{item.quantity}</td>
                            <td className="py-2 px-3 text-right text-amber-200/70">
                              {item.unitPrice > 0 ? `₹${item.unitPrice.toLocaleString('en-IN')}` : 'Included'}
                            </td>
                            <td className="py-2 px-3 text-right font-medium text-amber-100">
                              ₹{item.total.toLocaleString('en-IN')}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Totals Breakdown */}
                <div className="flex flex-col sm:flex-row justify-between gap-4 pt-3 border-t border-amber-500/20">
                  <div className="space-y-2 text-[11px] text-amber-200/60 max-w-sm">
                    <div className="flex items-center gap-2">
                      <QrCode className="w-10 h-10 text-[#d4af37] bg-black/40 p-1 rounded border border-amber-500/30" />
                      <div>
                        <span className="font-mono text-[9px] block text-amber-200/70">{invoice.qrVerificationCode}</span>
                        <span className="text-[10px] text-emerald-400 font-semibold">Digitally Verified Rajputana Homestay Folio</span>
                      </div>
                    </div>
                    <p>Statutory foreign guest Form C compliance record synchronized with Bureau of Immigration.</p>
                  </div>

                  <div className="w-full sm:w-72 space-y-1.5 text-xs">
                    <div className="flex justify-between text-amber-200/70">
                      <span>Subtotal Charges</span>
                      <span>₹{invoice.subtotal.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-amber-200/70">
                      <span>Heritage Monument Levy (5%)</span>
                      <span>₹{invoice.conservationLevy.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-amber-200/70">
                      <span>GST (12% Room / 5% Food)</span>
                      <span>₹{invoice.taxes.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-amber-500/20">
                      <span>Grand Total</span>
                      <span className="text-[#d4af37]">₹{invoice.grandTotal.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-xs text-emerald-400">
                      <span>Deposits &amp; Payments Recorded</span>
                      <span>- ₹{invoice.paidAmount.toLocaleString('en-IN')}</span>
                    </div>
                    <div className="flex justify-between text-base font-bold text-[#d4af37] bg-black/40 p-2.5 rounded-lg border border-amber-500/30">
                      <span>Outstanding Balance</span>
                      <span>₹{invoice.balanceDue.toLocaleString('en-IN')}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Departure Add-ons (Only if not yet paid) */}
              {invoice.status !== 'paid' && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
                    Add Departure Services to Final Bill:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <button
                      type="button"
                      onClick={() => toggleAddon('transfer')}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        selectedAddons['transfer']
                          ? 'bg-[#1b3a29] border-[#d4af37] text-white shadow'
                          : 'bg-[#12261b] border-amber-500/20 text-amber-200/70 hover:border-amber-500/40'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <Car className="w-4 h-4 text-[#d4af37]" />
                        <span className="font-bold text-xs">+₹1,200</span>
                      </div>
                      <strong className="block text-xs text-amber-100">Airport Transfer</strong>
                      <span className="text-[10px] text-amber-200/50">Jaipur Airport / Railway station</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleAddon('late_checkout')}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        selectedAddons['late_checkout']
                          ? 'bg-[#1b3a29] border-[#d4af37] text-white shadow'
                          : 'bg-[#12261b] border-amber-500/20 text-amber-200/70 hover:border-amber-500/40'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <Clock className="w-4 h-4 text-[#d4af37]" />
                        <span className="font-bold text-xs">+₹800</span>
                      </div>
                      <strong className="block text-xs text-amber-100">Late Checkout</strong>
                      <span className="text-[10px] text-amber-200/50">Retain suite until 3:00 PM</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => toggleAddon('souvenir')}
                      className={`p-3 rounded-xl border text-left transition-all ${
                        selectedAddons['souvenir']
                          ? 'bg-[#1b3a29] border-[#d4af37] text-white shadow'
                          : 'bg-[#12261b] border-amber-500/20 text-amber-200/70 hover:border-amber-500/40'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <Gift className="w-4 h-4 text-[#d4af37]" />
                        <span className="font-bold text-xs">+₹650</span>
                      </div>
                      <strong className="block text-xs text-amber-100">Fresco Keepsake</strong>
                      <span className="text-[10px] text-amber-200/50">Handmade miniature painting</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Secure Payment Gateway Section (Only if balance due > 0) */}
              {invoice.balanceDue > 0 && !paymentSuccess && (
                <div className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-5 space-y-4 shadow-xl">
                  <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
                    <div>
                      <h4 className="font-display font-bold text-base text-amber-100 flex items-center gap-2">
                        <Lock className="w-4 h-4 text-emerald-400" />
                        <span>Secure Online Payment Gateway</span>
                      </h4>
                      <p className="text-[11px] text-amber-200/60">
                        256-bit SSL encrypted • Instant digital settlement
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                        PCI-DSS Level 1
                      </span>
                    </div>
                  </div>

                  {/* Gateway Selector Tabs (Stripe, PayPal, UPI) */}
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveGateway('Stripe')}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                        activeGateway === 'Stripe'
                          ? 'bg-[#d4af37] text-[#0d1f15] border-[#d4af37] shadow'
                          : 'bg-[#0a1810] text-amber-200/80 border-amber-500/20 hover:border-amber-500/40'
                      }`}
                    >
                      <CreditCard className="w-4 h-4" />
                      <span>Stripe Cards</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveGateway('PayPal')}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                        activeGateway === 'PayPal'
                          ? 'bg-[#d4af37] text-[#0d1f15] border-[#d4af37] shadow'
                          : 'bg-[#0a1810] text-amber-200/80 border-amber-500/20 hover:border-amber-500/40'
                      }`}
                    >
                      <span className="font-sans font-extrabold italic text-sm">P</span>
                      <span>PayPal</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => setActiveGateway('UPI')}
                      className={`py-2 px-3 rounded-xl border text-xs font-bold transition-all flex items-center justify-center gap-2 ${
                        activeGateway === 'UPI'
                          ? 'bg-[#d4af37] text-[#0d1f15] border-[#d4af37] shadow'
                          : 'bg-[#0a1810] text-amber-200/80 border-amber-500/20 hover:border-amber-500/40'
                      }`}
                    >
                      <QrCode className="w-4 h-4" />
                      <span>UPI / QR</span>
                    </button>
                  </div>

                  {/* Gateway 1: Stripe Credit / Debit Card Form */}
                  {activeGateway === 'Stripe' && (
                    <div className="space-y-3 bg-[#0a1810] p-4 rounded-xl border border-amber-500/20">
                      <div className="flex items-center justify-between text-[11px] text-amber-200/70 pb-1 border-b border-amber-500/10">
                        <span className="font-semibold text-amber-300">Stripe Elements Payment</span>
                        <span>Visa • Mastercard • Amex</span>
                      </div>

                      <div className="space-y-2">
                        <div>
                          <label className="block text-[10px] text-amber-200/60 uppercase">Cardholder Full Name</label>
                          <input
                            type="text"
                            value={cardName}
                            onChange={e => setCardName(e.target.value)}
                            className="w-full rounded-lg border border-amber-500/30 bg-black/40 px-3 py-2 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] text-amber-200/60 uppercase">Card Number</label>
                          <input
                            type="text"
                            value={cardNumber}
                            onChange={e => setCardNumber(e.target.value)}
                            placeholder="4242 4242 4242 4242"
                            className="w-full rounded-lg border border-amber-500/30 bg-black/40 px-3 py-2 text-xs font-mono text-[#d4af37] focus:border-[#d4af37] focus:outline-none"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="block text-[10px] text-amber-200/60 uppercase">Expires (MM/YY)</label>
                            <input
                              type="text"
                              value={cardExp}
                              onChange={e => setCardExp(e.target.value)}
                              placeholder="MM/YY"
                              className="w-full rounded-lg border border-amber-500/30 bg-black/40 px-3 py-2 text-xs font-mono text-amber-100 focus:border-[#d4af37] focus:outline-none"
                            />
                          </div>
                          <div>
                            <label className="block text-[10px] text-amber-200/60 uppercase">CVC / CVV</label>
                            <input
                              type="password"
                              maxLength={4}
                              value={cardCvc}
                              onChange={e => setCardCvc(e.target.value)}
                              placeholder="•••"
                              className="w-full rounded-lg border border-amber-500/30 bg-black/40 px-3 py-2 text-xs font-mono text-amber-100 focus:border-[#d4af37] focus:outline-none"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Gateway 2: PayPal */}
                  {activeGateway === 'PayPal' && (
                    <div className="space-y-3 bg-[#0a1810] p-4 rounded-xl border border-amber-500/20 text-center">
                      <p className="text-xs text-amber-200/80">
                        Log in with your PayPal wallet or pay with PayPal Express.
                      </p>
                      <input
                        type="email"
                        value={paypalEmail}
                        onChange={e => setPaypalEmail(e.target.value)}
                        placeholder="PayPal Account Email"
                        className="w-full max-w-sm mx-auto rounded-lg border border-amber-500/30 bg-black/40 px-3 py-2 text-xs text-amber-100 text-center focus:border-[#d4af37] focus:outline-none"
                      />
                      <p className="text-[10px] text-amber-200/50">
                        PayPal Buyer Protection &amp; Instant Currency Conversion (USD/EUR to INR)
                      </p>
                    </div>
                  )}

                  {/* Gateway 3: UPI / QR */}
                  {activeGateway === 'UPI' && (
                    <div className="space-y-3 bg-[#0a1810] p-4 rounded-xl border border-amber-500/20">
                      <div className="flex flex-col sm:flex-row items-center gap-4">
                        <div className="w-24 h-24 bg-white p-2 rounded-xl flex items-center justify-center shrink-0">
                          <QrCode className="w-20 h-20 text-[#0d1f15]" />
                        </div>
                        <div className="space-y-1.5 text-center sm:text-left">
                          <strong className="text-xs text-amber-100 block">Scan with any UPI App</strong>
                          <p className="text-[11px] text-amber-200/60">
                            Google Pay, PhonePe, Paytm, BHIM, or your bank's UPI app.
                          </p>
                          <input
                            type="text"
                            value={upiId}
                            onChange={e => setUpiId(e.target.value)}
                            placeholder="username@okhdfcbank"
                            className="w-full rounded-lg border border-amber-500/30 bg-black/40 px-3 py-1.5 text-xs text-amber-100 font-mono focus:border-[#d4af37] focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Action Pay Button */}
                  <button
                    onClick={handlePayAndCheckout}
                    disabled={isProcessingPayment}
                    className="w-full py-3.5 rounded-xl font-bold bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] active:scale-95 transition-all text-xs flex items-center justify-center gap-2 shadow-xl disabled:opacity-50"
                  >
                    {isProcessingPayment ? (
                      <>
                        <RefreshCw className="w-4 h-4 animate-spin" />
                        <span>Authorizing with {activeGateway} Gateway...</span>
                      </>
                    ) : (
                      <>
                        <Lock className="w-4 h-4" />
                        <span>Confirm Online Settlement &amp; Checkout (₹{invoice.balanceDue.toLocaleString('en-IN')})</span>
                      </>
                    )}
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Post-Service Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        currentGuest={currentGuest}
        initialCategory="stay_checkout"
        initialTargetId={invoice?.id || 'stay'}
        initialTargetTitle={invoice ? `Stay Invoice #${invoice.id} (${invoice.roomNumber})` : 'Heritage Homestay Experience & Checkout'}
      />
    </div>
  );
};
