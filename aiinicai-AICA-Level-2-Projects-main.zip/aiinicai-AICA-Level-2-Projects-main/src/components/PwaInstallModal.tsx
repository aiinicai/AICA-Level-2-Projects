import React from 'react';
import { Download, Smartphone, Laptop, Check, X, Share, PlusSquare, WifiOff } from 'lucide-react';
import { usePwaInstall } from '../hooks/usePwaInstall';

interface PwaInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PwaInstallModal: React.FC<PwaInstallModalProps> = ({ isOpen, onClose }) => {
  const { isInstallable, isInstalled, isIOS, triggerInstall } = usePwaInstall();

  if (!isOpen) return null;

  const handleInstallClick = async () => {
    const success = await triggerInstall();
    if (success) {
      onClose();
    }
  };

  return (
    <div id="pwa-install-modal-overlay" className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md overflow-hidden rounded-2xl border border-amber-500/30 bg-[#0d1f15] text-[#f7f4ea] shadow-2xl p-6">
        {/* Close */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 rounded-lg p-1.5 text-amber-200/60 hover:bg-black/30 hover:text-amber-200 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Icon & Title */}
        <div className="text-center space-y-3 mb-6">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-[#1b3a29] to-[#0a1810] border-2 border-[#d4af37] p-2 shadow-xl flex items-center justify-center">
            <img src="/icon.svg" alt="Heritique Icon" className="w-12 h-12" />
          </div>
          <div>
            <h3 className="font-display font-bold text-xl text-[#d4af37]">Install Heritique Homestay App</h3>
            <p className="text-xs text-amber-200/70 mt-1">
              Seamless offline guest check-in, in-room dining, and live concierge access
            </p>
          </div>
        </div>

        {/* Status / Benefits */}
        <div className="bg-[#142b1f]/80 rounded-xl p-4 border border-amber-500/20 space-y-2.5 mb-6 text-xs text-amber-100/90">
          <div className="flex items-start gap-2.5">
            <WifiOff className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
            <span><strong>Offline Resilience:</strong> View homestay maps, emergency numbers, and stay credentials even without active internet.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <Smartphone className="w-4 h-4 text-[#d4af37] shrink-0 mt-0.5" />
            <span><strong>One-Tap Access:</strong> Launches full-screen like a native app on iOS, Android, macOS, and Windows.</span>
          </div>
          <div className="flex items-start gap-2.5">
            <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span><strong>Instant Updates:</strong> Real-time alerts on food orders, room delivery, and host messages.</span>
          </div>
        </div>

        {/* Platform Guidance */}
        {isInstalled ? (
          <div className="text-center p-4 rounded-xl bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-xs">
            <Check className="w-6 h-6 mx-auto mb-1 text-emerald-400" />
            Heritique Homestay is already installed on this device!
          </div>
        ) : isIOS ? (
          <div className="bg-black/40 rounded-xl p-4 border border-amber-500/20 space-y-2 text-xs text-amber-200/80">
            <p className="font-semibold text-amber-300 flex items-center gap-1.5">
              <Share className="w-4 h-4" /> Install on Apple iOS (Safari):
            </p>
            <ol className="list-decimal list-inside space-y-1 text-amber-100/70 pl-1">
              <li>Tap the <strong>Share</strong> button (box with upward arrow) at the bottom of Safari.</li>
              <li>Scroll down and select <strong className="text-amber-200">"Add to Home Screen"</strong> <PlusSquare className="w-3.5 h-3.5 inline mx-1 text-amber-300" />.</li>
              <li>Tap <strong>Add</strong> at top right to install instantly.</li>
            </ol>
          </div>
        ) : isInstallable ? (
          <button
            onClick={handleInstallClick}
            className="w-full py-3 px-4 rounded-xl font-semibold bg-[#d4af37] text-[#0d1f15] hover:bg-[#e6c454] active:scale-[0.98] transition-all flex items-center justify-center gap-2 shadow-lg shadow-amber-900/30 text-sm"
          >
            <Download className="w-4 h-4" /> Install App Now
          </button>
        ) : (
          <div className="bg-black/40 rounded-xl p-4 border border-amber-500/20 space-y-2 text-xs text-amber-200/80">
            <p className="font-semibold text-amber-300 flex items-center gap-1.5">
              <Laptop className="w-4 h-4" /> Desktop & Android Install:
            </p>
            <p className="text-amber-100/70">
              Click the <strong className="text-amber-200">Install icon (down-arrow in computer monitor or address bar)</strong> in Chrome / Edge / Brave, or select <em>Menu (⋮) &gt; "Install Heritique Homestay"</em>.
            </p>
          </div>
        )}

        <button
          onClick={onClose}
          className="w-full mt-3 py-2 text-xs text-amber-300/60 hover:text-amber-300 text-center transition-colors"
        >
          Dismiss
        </button>
      </div>
    </div>
  );
};
