import React, { useState } from 'react';
import { Camera, Upload, Sparkles, CheckCircle, RefreshCw, FileText, Eye, Smartphone, ArrowDown, AlertCircle } from 'lucide-react';
import { scanPassportOcr } from '../utils/api';
import { PassportOCRResult } from '../types';
import { CameraCaptureModal } from './CameraCaptureModal';
import { optimizeImageForOcr } from '../utils/imageUtils';

interface PassportOcrSectionProps {
  onExtracted: (data: PassportOCRResult, imageBase64: string) => void;
  currentDocument?: string;
}

export const PassportOcrSection: React.FC<PassportOcrSectionProps> = ({ onExtracted, currentDocument }) => {
  const [isCameraOpen, setIsCameraOpen] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [scanStatusText, setScanStatusText] = useState('Optimizing and analyzing passport...');
  const [extractedData, setExtractedData] = useState<PassportOCRResult | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(currentDocument || null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const processPassportImage = async (rawBase64OrFile: string | File) => {
    setIsScanning(true);
    setErrorMsg(null);
    setScanStatusText('Compressing photo for fast transmission...');

    try {
      // 1. Optimize image (scale to max 1600px, 85% JPEG quality)
      // This prevents Express 413 Payload Too Large and Cloud Run timeouts on high-res mobile photos
      const optimizedBase64 = await optimizeImageForOcr(rawBase64OrFile, 1600, 0.85);
      setPreviewImage(optimizedBase64);

      setScanStatusText('Gemini AI Vision reading passport & MRZ lines...');
      const res = await scanPassportOcr(optimizedBase64);

      if (res.success && res.data) {
        setExtractedData(res.data);
        onExtracted(res.data, optimizedBase64);
        setScanStatusText('Details extracted successfully!');
      } else {
        throw new Error('Could not parse passport details from image.');
      }
    } catch (err: any) {
      console.error('OCR Error:', err);
      const msg = err.message || '';
      setErrorMsg(
        msg.includes('413')
          ? 'Image file was too large. Please take a closer snapshot or select another image.'
          : msg.length > 5 && !msg.includes('object')
            ? msg
            : 'Could not automatically read passport text. Please ensure the bio-data page and MRZ lines at the bottom are in focus and glare-free.'
      );
    } finally {
      setIsScanning(false);
    }
  };

  const handleNativeCamera = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processPassportImage(file);
    e.target.value = ''; // Reset input for repeated captures
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processPassportImage(file);
    e.target.value = '';
  };

  const scrollToGuestForm = () => {
    const el = document.getElementById('form-c-guest-details') || document.getElementById('guest-details-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div id="passport-ocr-section" className="rounded-2xl border border-amber-500/30 bg-[#12261b]/90 p-5 shadow-xl space-y-4">
      {/* Title & Badge */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-500/20 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-amber-500/10 border border-amber-500/30 text-[#d4af37]">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h3 className="font-display font-semibold text-lg text-amber-100 flex items-center gap-2">
              Instant Passport AI OCR
              <span className="text-[10px] font-sans font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40">
                Form C Auto-Fill
              </span>
            </h3>
            <p className="text-xs text-amber-200/70">
              Snap photo from mobile camera or upload passport for automatic demographic extraction into guest details
            </p>
          </div>
        </div>
      </div>

      {/* Capture Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Mobile Camera & Upload Trigger Options */}
        <div className="space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
            {/* 1. Native Mobile Camera (Most reliable on mobile phones) */}
            <label className="p-3.5 rounded-xl border border-amber-500/40 bg-gradient-to-b from-[#1b3e2b] to-[#142d20] hover:bg-[#1f4732] active:scale-[0.98] transition-all flex flex-col items-center justify-center gap-1.5 text-center cursor-pointer group shadow-md">
              <div className="w-9 h-9 rounded-full bg-amber-500/20 text-[#d4af37] flex items-center justify-center group-hover:scale-110 transition-transform">
                <Smartphone className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-amber-100">Phone Camera</span>
              <span className="text-[10px] text-amber-200/60">Snap with phone lens</span>
              <input
                type="file"
                accept="image/*"
                capture="environment"
                onChange={handleNativeCamera}
                className="hidden"
              />
            </label>

            {/* 2. Live Web Viewfinder */}
            <button
              type="button"
              onClick={() => setIsCameraOpen(true)}
              className="p-3.5 rounded-xl border border-amber-500/30 bg-[#173324] hover:bg-[#1f422f] active:scale-[0.98] transition-all flex flex-col items-center justify-center gap-1.5 text-center group"
            >
              <div className="w-9 h-9 rounded-full bg-amber-500/20 text-[#d4af37] flex items-center justify-center group-hover:scale-110 transition-transform">
                <Camera className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-amber-100">Live Lens</span>
              <span className="text-[10px] text-amber-200/60">Webcam viewfinder</span>
            </button>

            {/* 3. Upload File / Gallery */}
            <label className="p-3.5 rounded-xl border border-amber-500/30 bg-[#173324] hover:bg-[#1f422f] active:scale-[0.98] transition-all flex flex-col items-center justify-center gap-1.5 text-center cursor-pointer group">
              <div className="w-9 h-9 rounded-full bg-amber-500/20 text-[#d4af37] flex items-center justify-center group-hover:scale-110 transition-transform">
                <Upload className="w-5 h-5" />
              </div>
              <span className="text-xs font-semibold text-amber-100">Upload File</span>
              <span className="text-[10px] text-amber-200/60">Gallery, JPG or PDF</span>
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Tips */}
          <div className="rounded-xl bg-black/30 p-3 border border-amber-500/10 text-[11px] text-amber-200/70 space-y-1">
            <p className="font-medium text-amber-300">💡 Mobile Photography Tip for Form C:</p>
            <p>Ensure the 2-line MRZ machine code at the bottom of the passport page is in sharp focus without glare. The AI will extract all details and auto-fill the guest form below.</p>
          </div>
        </div>

        {/* Document Preview & Extraction Status */}
        <div className="relative rounded-xl border border-amber-500/30 bg-[#0c1a12] p-3 flex flex-col justify-between min-h-[180px] overflow-hidden">
          {isScanning ? (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 p-4 text-center">
              <div className="relative">
                <RefreshCw className="w-8 h-8 text-[#d4af37] animate-spin" />
                <Sparkles className="w-4 h-4 text-amber-300 absolute -top-1 -right-1 animate-bounce" />
              </div>
              <div>
                <p className="text-xs font-semibold text-amber-200">{scanStatusText}</p>
                <p className="text-[10px] text-amber-200/60 mt-1">Reading Name, Passport #, Nationality, DOB, and Expiry date...</p>
              </div>
            </div>
          ) : previewImage ? (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-amber-300 font-medium">
                <span className="flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4 text-emerald-400" /> Passport Scanned &amp; Loaded
                </span>
                <label className="text-[11px] text-amber-400/80 hover:text-amber-300 underline cursor-pointer">
                  Retake Photo
                  <input type="file" accept="image/*" capture="environment" onChange={handleNativeCamera} className="hidden" />
                </label>
              </div>

              <div className="relative rounded-lg overflow-hidden border border-amber-500/20 max-h-32 bg-black/60">
                <img src={previewImage} alt="Passport Scan" className="w-full h-32 object-cover object-top" />
                <div className="absolute bottom-1 right-2 bg-black/75 px-2 py-0.5 rounded text-[10px] text-amber-300 flex items-center gap-1">
                  <Eye className="w-3 h-3" /> Form C Document
                </div>
              </div>

              {extractedData && (
                <div className="space-y-2">
                  <div className="text-[11px] bg-emerald-950/60 border border-emerald-500/40 rounded-lg p-2.5 text-emerald-200 space-y-1">
                    <div className="flex items-center justify-between font-semibold text-white">
                      <span>✓ Auto-Filled to Guest Details</span>
                      <span className="text-[10px] text-emerald-300 font-mono">
                        Confidence: {Math.round((extractedData.confidence || 0.95) * 100)}%
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-1 text-[11px] pt-1 border-t border-emerald-500/20 text-emerald-100">
                      <div>Name: <strong className="text-white">{extractedData.givenName} {extractedData.surname}</strong></div>
                      <div>Pass #: <strong className="text-white">{extractedData.passportNumber}</strong></div>
                      <div>Nation: <strong className="text-white">{extractedData.nationality}</strong></div>
                      <div>DOB: <strong className="text-white">{extractedData.dob || '—'}</strong></div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={scrollToGuestForm}
                    className="w-full py-1.5 px-3 rounded-lg bg-emerald-900/60 hover:bg-emerald-800/80 border border-emerald-500/40 text-emerald-200 text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                  >
                    <ArrowDown className="w-3.5 h-3.5" /> View Auto-Filled Form Details Below
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-4 text-amber-200/50">
              <FileText className="w-8 h-8 mb-2 opacity-40 text-[#d4af37]" />
              <p className="text-xs font-medium text-amber-200/70">No passport document loaded yet</p>
              <p className="text-[10px] text-amber-200/40 mt-0.5">Use "Phone Camera", "Live Lens", or upload an image above</p>
            </div>
          )}

          {errorMsg && (
            <div className="text-[11px] text-amber-200 bg-amber-950/70 p-3 rounded-lg mt-2 border border-amber-500/40 space-y-2">
              <div className="flex items-start gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-amber-100">Notice:</p>
                  <p className="text-amber-200/90 leading-relaxed">{errorMsg}</p>
                </div>
              </div>
              <div className="flex items-center gap-2 pt-1 border-t border-amber-500/20">
                {previewImage && (
                  <button
                    type="button"
                    onClick={() => processPassportImage(previewImage)}
                    className="px-2.5 py-1 rounded bg-amber-800/60 hover:bg-amber-700/80 text-amber-100 text-[11px] font-medium transition-colors flex items-center gap-1"
                  >
                    <RefreshCw className="w-3 h-3" /> Retry AI Scan
                  </button>
                )}
                <button
                  type="button"
                  onClick={scrollToGuestForm}
                  className="px-2.5 py-1 rounded bg-[#173324] hover:bg-[#1f422f] text-amber-200 text-[11px] font-medium border border-amber-500/30 transition-colors flex items-center gap-1"
                >
                  <ArrowDown className="w-3 h-3" /> Enter Details Manually Below
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      <CameraCaptureModal
        isOpen={isCameraOpen}
        onClose={() => setIsCameraOpen(false)}
        onCapture={(data) => processPassportImage(data)}
        title="Photograph Foreign Guest Passport"
        guideMode="passport"
      />
    </div>
  );
};
