import React, { useState } from 'react';
import { 
  Compass, ClipboardCheck, Utensils, Receipt, MessageSquare, 
  Shield, ArrowRight, Sparkles, MapPin, Calendar, CheckCircle2, 
  Mail, Lock, User, UserCheck, LogOut, KeyRound, Star, 
  Clock, Coffee, Phone, ChevronRight, Eye, ShieldCheck, Heart
} from 'lucide-react';
import { AuthSession, UserRole, GuestRegistration } from '../types';
import { authorizeWithEmail } from '../utils/api';
import { googleSignIn } from '../services/firebase';
import { WeatherWidget } from './WeatherWidget';
import { FeedbackModal } from './FeedbackModal';

interface HomePageProps {
  onNavigateTab: (tab: 'home' | 'about' | 'checkin' | 'dining' | 'billing' | 'chat' | 'admin' | 'itinerary') => void;
  authSession: AuthSession | null;
  onOpenAuthModal: (role?: UserRole, suggestedEmail?: string) => void;
  onSignOut: () => void;
  currentGuest: GuestRegistration | null;
  onAuthSuccess?: (session: AuthSession) => void;
  onAuthorized?: (session: AuthSession) => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigateTab,
  authSession,
  onOpenAuthModal,
  onSignOut,
  currentGuest,
  onAuthSuccess,
  onAuthorized
}) => {
  // Local sign-up / sign-in state on Home page
  const [emailInput, setEmailInput] = useState('');
  const [roleInput, setRoleInput] = useState<UserRole>('guest');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  const [authSuccessMsg, setAuthSuccessMsg] = useState<string | null>(null);
  const [isFeedbackModalOpen, setIsFeedbackModalOpen] = useState(false);

  // Requirement: Do not allow ordering from home page until guest or staff logs in via email
  const handleInitiateDiningOrder = () => {
    if (!authSession) {
      setAuthError('Please sign in or authorize with your email address to order in-room dining.');
      onOpenAuthModal('guest');
      return;
    }
    onNavigateTab('dining');
  };

  const handleHomeAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    setAuthSuccessMsg(null);

    const email = emailInput.trim().toLowerCase();
    if (!email || !email.includes('@')) {
      setAuthError('Please enter a valid email address');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await authorizeWithEmail({
        email,
        role: roleInput,
        staffRole: roleInput === 'staff' ? 'Front Desk Officer' : undefined
      });

      if (res.success && res.session) {
        if (typeof onAuthSuccess === 'function') {
          try { onAuthSuccess(res.session); } catch (e) { console.error('onAuthSuccess error:', e); }
        }
        if (typeof onAuthorized === 'function') {
          try { onAuthorized(res.session); } catch (e) { console.error('onAuthorized error:', e); }
        }
        setAuthSuccessMsg(`Welcome, ${res.session.displayName || email}! You are now authorized.`);
        setEmailInput('');
      } else {
        setAuthError(res.error || 'Authorization failed. Please try again.');
      }
    } catch (err: any) {
      setAuthError(err.message || 'Authorization service unavailable');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleHomeGoogleSignIn = async () => {
    setAuthError(null);
    setAuthSuccessMsg(null);
    setIsSubmitting(true);
    try {
      const result = await googleSignIn();
      if (result && result.user.email) {
        const res = await authorizeWithEmail({
          email: result.user.email,
          role: roleInput,
          displayName: result.user.displayName || undefined,
          staffRole: roleInput === 'staff' ? 'Front Desk Officer' : undefined
        });
        if (res.success && res.session) {
          if (typeof onAuthSuccess === 'function') {
            try { onAuthSuccess(res.session); } catch (e) { console.error('onAuthSuccess error:', e); }
          }
          if (typeof onAuthorized === 'function') {
            try { onAuthorized(res.session); } catch (e) { console.error('onAuthorized error:', e); }
          }
          setAuthSuccessMsg(`Welcome, ${res.session.displayName || result.user.email}! You are authorized.`);
        }
      }
    } catch (err: any) {
      console.error('Google sign-in error:', err);
      setAuthError(err.message || 'Google sign-in was cancelled or failed.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-16 pb-12">
      {/* Hero Section with Royal Heritage Architecture Background */}
      <section className="relative rounded-3xl overflow-hidden shadow-2xl border border-[#d8c5aa] bg-[#fbf6ee]">
        {/* Background Image Container with Royal Rajasthan Sandstone Haveli */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1599661046289-e31897846e41?auto=format&fit=crop&w=2000&q=85"
            alt="Rajasthan Royal Heritage Palace & Haveli"
            className="w-full h-full object-cover object-center transform scale-105"
            referrerPolicy="no-referrer"
          />
          {/* Light Warm Sandstone & Ivory Gradient Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-[#f7f2e8]/95 via-[#f5ede0]/90 to-[#ede0cc]/80 backdrop-blur-[2px]" />
          {/* Subtle Royal Jali / Filigree Texture */}
          <div className="absolute inset-0 opacity-[0.03] bg-[radial-gradient(#8a2517_1px,transparent_1px)] [background-size:16px_16px]" />
        </div>

        {/* Hero Content Grid */}
        <div className="relative z-10 max-w-6xl mx-auto px-6 py-12 sm:py-16 lg:py-20">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            
            {/* Left Column: Royal Welcome & Value Proposition */}
            <div className="lg:col-span-7 space-y-6">
              {/* Royal Rajputana Badge */}
              <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#8a2517]/10 border border-[#8a2517]/25 text-[#8a2517] text-xs font-semibold tracking-wide shadow-sm">
                <span className="w-2 h-2 rounded-full bg-[#8a2517] animate-pulse" />
                <span className="font-serif">पधारो म्हारे देश • Established 1924</span>
                <span className="text-[#c59b27] font-bold">★ 100-Year Haveli</span>
              </div>

              {/* Grand Display Headline */}
              <div className="space-y-2">
                <h1 className="font-display font-bold text-3xl sm:text-4xl lg:text-5xl text-[#241c16] tracking-tight leading-[1.15]">
                  Experience Regal Living at <span className="text-[#8a2517] underline decoration-[#c59b27] decoration-2 underline-offset-8">Heritique</span> Haveli
                </h1>
                <p className="font-serif italic text-lg sm:text-xl text-[#755943]">
                  A 1924 Rajputana Heritage Homestay in the Heart of Rajasthan
                </p>
              </div>

              <p className="text-sm sm:text-base text-[#4a3b30] leading-relaxed max-w-xl">
                Step through hand-carved stone archways into an authentic sanctuary of golden sandstone jharokhas, tranquil courtyards, and warm Rajput hospitality. Enjoy instant seamless digital check-in with statutory Form C compliance.
              </p>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  id="hero-guest-checkin-btn"
                  onClick={() => onNavigateTab('checkin')}
                  className="px-6 py-3.5 rounded-2xl bg-gradient-to-r from-[#8a2517] to-[#a32e1d] text-white font-bold text-sm shadow-xl hover:shadow-2xl hover:brightness-110 active:scale-95 transition-all flex items-center gap-2"
                >
                  <ClipboardCheck className="w-5 h-5 text-[#f5d998]" />
                  <span>Begin Guest Check-in</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <button
                  id="hero-about-property-btn"
                  onClick={() => onNavigateTab('about')}
                  className="px-5 py-3.5 rounded-2xl bg-[#fffdfa] border-2 border-[#d8c5aa] text-[#4a3b30] font-bold text-sm hover:border-[#8a2517] hover:text-[#8a2517] shadow-md transition-all flex items-center gap-2"
                >
                  <Compass className="w-4 h-4 text-[#c59b27]" />
                  <span>About Property</span>
                </button>

                <button
                  id="hero-room-dining-btn"
                  onClick={handleInitiateDiningOrder}
                  className={`px-5 py-3.5 rounded-2xl border text-sm font-semibold shadow-sm transition-all flex items-center gap-2 ${
                    authSession 
                      ? 'bg-[#fffdfa] border-[#8a2517]/30 text-[#8a2517] hover:bg-[#8a2517] hover:text-white' 
                      : 'bg-[#fffdfa]/80 border-[#d8c5aa] text-[#4a3b30] hover:bg-[#fffdfa]'
                  }`}
                  title={authSession ? 'Order In-Room Dining' : 'Email login required to order dining'}
                >
                  <Utensils className="w-4 h-4 text-[#8a2517]" />
                  <span>Royal Rasoi Dining</span>
                  {!authSession ? (
                    <span className="ml-1 inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                      <Lock className="w-2.5 h-2.5" /> Login to Order
                    </span>
                  ) : (
                    <span className="ml-1 inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                      <CheckCircle2 className="w-2.5 h-2.5" /> Order
                    </span>
                  )}
                </button>
              </div>

              {/* Key Trust & Heritage Badges */}
              <div className="grid grid-cols-3 gap-3 pt-4 border-t border-[#d8c5aa]/60 max-w-lg">
                <div className="p-2.5 rounded-xl bg-[#fffdfa]/70 border border-[#e8dac6]">
                  <p className="text-[11px] font-bold text-[#8a2517] flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#24613b]" /> FRRO Compliant
                  </p>
                  <p className="text-[10px] text-[#695646]">Official Form C generation</p>
                </div>
                <div className="p-2.5 rounded-xl bg-[#fffdfa]/70 border border-[#e8dac6]">
                  <p className="text-[11px] font-bold text-[#8a2517] flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-[#c59b27]" /> 14 Royal Suites
                  </p>
                  <p className="text-[10px] text-[#695646]">Jharokha &amp; Chowk views</p>
                </div>
                <div className="p-2.5 rounded-xl bg-[#fffdfa]/70 border border-[#e8dac6]">
                  <p className="text-[11px] font-bold text-[#8a2517] flex items-center gap-1">
                    <Coffee className="w-3.5 h-3.5 text-[#8a2517]" /> Mewari Cuisine
                  </p>
                  <p className="text-[10px] text-[#695646]">Fresh organic rasoi</p>
                </div>
              </div>
            </div>

            {/* Right Column: Prominent Sign Up / Sign In Card on Home Page */}
            <div className="lg:col-span-5">
              <div className="rounded-3xl bg-[#fffdfa] p-6 sm:p-7 shadow-2xl border-2 border-[#d8c5aa] relative overflow-hidden">
                {/* Decorative corner royal ornament */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-[#8a2517]/10 to-transparent rounded-bl-full pointer-events-none" />

                {/* Card Header */}
                <div className="space-y-1.5 pb-4 border-b border-[#ebdcc8]">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 text-[#8a2517]">
                      <div className="w-8 h-8 rounded-xl bg-[#8a2517]/10 border border-[#8a2517]/20 flex items-center justify-center">
                        <KeyRound className="w-4 h-4 text-[#8a2517]" />
                      </div>
                      <h3 className="font-display font-bold text-lg text-[#241c16]">
                        {authSession ? 'Your Active Stay Pass' : 'Sign In / Register Stay'}
                      </h3>
                    </div>

                    <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#c59b27]/15 text-[#856113] border border-[#c59b27]/30">
                      Universal Access
                    </span>
                  </div>
                  <p className="text-xs text-[#695646]">
                    {authSession 
                      ? 'You are authorized on Heritique Homestay network.' 
                      : 'Enter any valid email ID to access your reservation, check-in, or staff portal.'}
                  </p>
                </div>

                {/* Active Session Display */}
                {authSession ? (
                  <div className="py-4 space-y-4">
                    <div className="p-4 rounded-2xl bg-[#f7f2e8] border border-[#d8c5aa] space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <UserCheck className="w-5 h-5 text-[#24613b]" />
                          <div>
                            <p className="text-xs font-bold text-[#241c16]">
                              {authSession.displayName || 'Distinguished Guest'}
                            </p>
                            <p className="text-[11px] font-mono text-[#755943]">
                              {authSession.email}
                            </p>
                          </div>
                        </div>
                        <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                          authSession.role === 'staff' 
                            ? 'bg-[#8a2517] text-white' 
                            : 'bg-[#24613b] text-white'
                        }`}>
                          {authSession.role === 'staff' ? (authSession.staffRole || 'Staff') : 'Royal Guest'}
                        </span>
                      </div>

                      {currentGuest && (
                        <div className="pt-2 border-t border-[#ebdcc8] text-xs flex items-center justify-between text-[#695646]">
                          <span>Assigned Suite: <strong>{currentGuest.roomNumber}</strong></span>
                          <span>Folio: <strong>{currentGuest.passportOrIdNumber || 'Verified'}</strong></span>
                        </div>
                      )}
                    </div>

                    {/* Quick navigation actions for signed-in user */}
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => onNavigateTab('dining')}
                        className="p-2 rounded-xl bg-[#8a2517] text-white text-[11px] font-bold shadow hover:bg-[#a32e1d] transition-all flex items-center justify-center gap-1"
                      >
                        <Utensils className="w-3.5 h-3.5 text-[#f5d998]" /> Dining
                      </button>
                      <button
                        onClick={() => onNavigateTab('checkin')}
                        className="p-2 rounded-xl bg-[#fffdfa] border border-[#d8c5aa] text-[#4a3b30] text-[11px] font-bold hover:border-[#8a2517] transition-all flex items-center justify-center gap-1"
                      >
                        <ClipboardCheck className="w-3.5 h-3.5 text-[#8a2517]" /> Check-in
                      </button>
                      <button
                        onClick={() => onNavigateTab('billing')}
                        className="p-2 rounded-xl bg-[#fffdfa] border border-[#d8c5aa] text-[#4a3b30] text-[11px] font-bold hover:border-[#8a2517] transition-all flex items-center justify-center gap-1"
                      >
                        <Receipt className="w-3.5 h-3.5 text-[#8a2517]" /> Folio
                      </button>
                    </div>

                    <div className="flex items-center justify-between pt-1">
                      <button
                        onClick={() => onOpenAuthModal(authSession.role, authSession.email)}
                        className="text-xs text-[#8a2517] font-semibold hover:underline flex items-center gap-1"
                      >
                        <Sparkles className="w-3.5 h-3.5 text-[#c59b27]" /> Switch Account / Role
                      </button>
                      <button
                        onClick={onSignOut}
                        className="text-xs text-[#8a2517] hover:text-red-700 font-semibold flex items-center gap-1"
                      >
                        <LogOut className="w-3.5 h-3.5" /> Sign Out
                      </button>
                    </div>
                  </div>
                ) : (
                  /* Sign Up / Sign In Form */
                  <form onSubmit={handleHomeAuth} className="py-4 space-y-3.5">
                    {/* Role Selector Tabs on Home Card */}
                    <div className="grid grid-cols-2 p-1 rounded-xl bg-[#f4ece1] border border-[#e0cfb7] text-xs">
                      <button
                        type="button"
                        onClick={() => setRoleInput('guest')}
                        className={`py-1.5 rounded-lg font-bold transition-all flex items-center justify-center gap-1.5 ${
                          roleInput === 'guest'
                            ? 'bg-[#8a2517] text-white shadow-sm'
                            : 'text-[#695646] hover:text-[#241c16]'
                        }`}
                      >
                        <User className="w-3.5 h-3.5" /> Guest Sign In
                      </button>

                      <button
                        type="button"
                        onClick={() => setRoleInput('staff')}
                        className={`py-1.5 rounded-lg font-bold transition-all flex items-center justify-center gap-1.5 ${
                          roleInput === 'staff'
                            ? 'bg-[#8a2517] text-white shadow-sm'
                            : 'text-[#695646] hover:text-[#241c16]'
                        }`}
                      >
                        <Shield className="w-3.5 h-3.5" /> Staff Access
                      </button>
                    </div>

                    {/* Social Login Options */}
                    <div className="space-y-2">
                      <button
                        type="button"
                        onClick={handleHomeGoogleSignIn}
                        disabled={isSubmitting}
                        className="w-full py-2.5 px-3.5 rounded-xl bg-white border border-[#d8c5aa] text-[#241c16] hover:bg-[#fbf8f2] font-semibold text-xs shadow-sm hover:shadow transition-all flex items-center justify-center gap-2.5 disabled:opacity-50"
                      >
                        <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48">
                          <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                          <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                          <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                          <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                        </svg>
                        <span>Login with Google</span>
                      </button>

                      <div className="grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEmailInput('guest@icloud.com');
                          }}
                          className="py-2 px-3 rounded-xl bg-white border border-[#d8c5aa] text-[#241c16] hover:bg-[#fbf8f2] font-semibold text-xs shadow-sm transition-all flex items-center justify-center gap-1.5"
                        >
                          <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 170 170">
                            <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.05-7.74-7.85-12.14-14.41-6.1-9.04-10.88-19.4-14.33-31.07-3.46-11.68-5.19-22.75-5.19-33.22 0-14.38 3.59-26.35 10.77-35.91 7.18-9.56 16.27-14.46 27.27-14.7 4.8 0 10.15 1.25 16.06 3.76 5.9 2.51 9.77 3.86 11.61 4.05 1.57-.2 5.56-1.57 11.96-4.11 6.4-2.54 11.75-3.69 16.05-3.46 12.31.64 22.37 5.48 30.18 14.52-10.77 6.54-16.04 15.69-15.82 27.46.22 9.38 3.84 17.27 10.86 23.66 7.02 6.4 15.42 10.12 25.19 11.16-2.02 6.08-4.49 12.08-7.41 18-2.92 5.91-5.74 11.1-8.47 15.58zM119.22 31.84c0-7.39 2.66-14.18 7.98-20.37 5.32-6.19 11.89-9.98 19.7-11.37.11 1 .16 1.83.16 2.49 0 7.2-2.82 14.07-8.45 20.61-5.63 6.54-12.44 10.29-20.43 11.25-.1-.85-.16-1.72-.16-2.61z" />
                          </svg>
                          <span>Apple</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setEmailInput('guest@yahoo.com');
                          }}
                          className="py-2 px-3 rounded-xl bg-white border border-[#d8c5aa] text-[#241c16] hover:bg-[#fbf8f2] font-semibold text-xs shadow-sm transition-all flex items-center justify-center gap-1.5"
                        >
                          <span className="font-bold text-[#720e9e]">Y!</span>
                          <span>Yahoo</span>
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <div className="flex-1 h-px bg-[#d8c5aa]/60" />
                      <span className="text-[10px] text-[#755943] uppercase tracking-wider font-semibold">Or with Email</span>
                      <div className="flex-1 h-px bg-[#d8c5aa]/60" />
                    </div>

                    {/* Email Input Field */}
                    <div className="space-y-1">
                      <label className="block text-xs font-semibold text-[#4a3b30] flex items-center justify-between">
                        <span>Email Address</span>
                        <span className="text-[10px] text-[#856113]">Any email supported</span>
                      </label>
                      <div className="relative">
                        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-[#755943]">
                          <Mail className="w-4 h-4" />
                        </div>
                        <input
                          type="email"
                          value={emailInput}
                          onChange={e => setEmailInput(e.target.value)}
                          placeholder="your.email@example.com"
                          required
                          className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-[#d8c5aa] bg-[#fbf8f2] text-[#241c16] placeholder-[#a6927e] text-xs focus:border-[#8a2517] focus:outline-none transition-colors"
                        />
                      </div>
                    </div>

                    {authError && (
                      <div className="p-2 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs">
                        {authError}
                      </div>
                    )}

                    {authSuccessMsg && (
                      <div className="p-2 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span>{authSuccessMsg}</span>
                      </div>
                    )}

                    {/* Action Submit Button */}
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="w-full py-3 rounded-xl bg-[#8a2517] text-white font-bold text-xs shadow-lg hover:bg-[#a32e1d] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isSubmitting ? (
                        <span>Authorizing...</span>
                      ) : (
                        <>
                          <KeyRound className="w-4 h-4 text-[#f5d998]" />
                          <span>{roleInput === 'guest' ? 'Sign In / Register as Guest' : 'Authorize Staff Portal'}</span>
                        </>
                      )}
                    </button>

                    {/* Additional Options */}
                    <div className="pt-2 border-t border-[#ebdcc8]">
                      <button
                        type="button"
                        onClick={() => onOpenAuthModal(roleInput, emailInput)}
                        className="w-full py-1.5 text-center text-xs text-[#755943] hover:text-[#8a2517] font-medium"
                      >
                        Advanced Authorization &amp; Host PIN →
                      </button>
                    </div>
                  </form>
                )}
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Shekhawati Rajasthan Weather Widget (Google Search Grounding) */}
      <section>
        <WeatherWidget />
      </section>

      {/* Guest Quick Services Highlights: Housekeeping, Invoice, AI Itinerary & Service Feedback */}
      <section className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Housekeeping Request Highlight */}
        <div 
          onClick={() => onNavigateTab('chat')}
          className="cursor-pointer rounded-2xl bg-[#fffdfa] border-2 border-[#d8c5aa] hover:border-[#8a2517] p-5 shadow-md hover:shadow-xl transition-all flex items-start gap-4 group"
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8a2517] to-[#a32e1d] text-[#f5d998] flex items-center justify-center shrink-0 shadow group-hover:scale-105 transition-transform">
            <Sparkles className="w-6 h-6" />
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8a2517] bg-[#8a2517]/10 px-2.5 py-0.5 rounded-full border border-[#8a2517]/20">
                Housekeeping
              </span>
              <span className="text-xs font-bold text-[#8a2517] group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                Request &rarr;
              </span>
            </div>
            <h4 className="font-display font-bold text-base text-[#241c16] group-hover:text-[#8a2517] transition-colors">
              Suite Housekeeping
            </h4>
            <p className="text-xs text-[#695646]">
              Standard Tidy, Deep Clean, or Fresh Towels with custom timing for your suite.
            </p>
          </div>
        </div>

        {/* Automated Checkout Invoice Highlight */}
        <div 
          onClick={() => onNavigateTab('billing')}
          className="cursor-pointer rounded-2xl bg-[#fffdfa] border-2 border-[#d8c5aa] hover:border-[#c59b27] p-5 shadow-md hover:shadow-xl transition-all flex items-start gap-4 group"
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#c59b27] to-[#856113] text-white flex items-center justify-center shrink-0 shadow group-hover:scale-105 transition-transform">
            <Receipt className="w-6 h-6" />
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#856113] bg-[#c59b27]/15 px-2.5 py-0.5 rounded-full border border-[#c59b27]/30">
                Online Checkout
              </span>
              <span className="text-xs font-bold text-[#856113] group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                Invoice &rarr;
              </span>
            </div>
            <h4 className="font-display font-bold text-base text-[#241c16] group-hover:text-[#856113] transition-colors">
              Automated Invoice &amp; Pay
            </h4>
            <p className="text-xs text-[#695646]">
              Automated itemized billing. Settle securely via <strong>Stripe, PayPal, or UPI</strong>.
            </p>
          </div>
        </div>

        {/* AI Rajasthan Itinerary Planner Highlight */}
        <div 
          onClick={() => onNavigateTab('itinerary')}
          className="cursor-pointer rounded-2xl bg-[#fffdfa] border-2 border-[#d8c5aa] hover:border-[#24613b] p-5 shadow-md hover:shadow-xl transition-all flex items-start gap-4 group"
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#24613b] to-[#164126] text-[#f5d998] flex items-center justify-center shrink-0 shadow group-hover:scale-105 transition-transform">
            <Compass className="w-6 h-6" />
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#24613b] bg-[#24613b]/10 px-2.5 py-0.5 rounded-full border border-[#24613b]/20">
                AI Concierge
              </span>
              <span className="text-xs font-bold text-[#24613b] group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                Plan Tour &rarr;
              </span>
            </div>
            <h4 className="font-display font-bold text-base text-[#241c16] group-hover:text-[#24613b] transition-colors">
              AI Rajasthan Itinerary
            </h4>
            <p className="text-xs text-[#695646]">
              Custom day-by-day plans for Jaipur, Amber Fort, Johari Bazar, and desert heritage tours.
            </p>
          </div>
        </div>

        {/* Post-Service Feedback Highlight */}
        <div 
          onClick={() => setIsFeedbackModalOpen(true)}
          className="cursor-pointer rounded-2xl bg-[#fffdfa] border-2 border-[#d8c5aa] hover:border-[#8a2517] p-5 shadow-md hover:shadow-xl transition-all flex items-start gap-4 group"
        >
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#8a2517] to-[#59140b] text-[#f5d998] flex items-center justify-center shrink-0 shadow group-hover:scale-105 transition-transform">
            <Star className="w-6 h-6 fill-current" />
          </div>
          <div className="space-y-1 flex-1">
            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-wider text-[#8a2517] bg-[#8a2517]/10 px-2.5 py-0.5 rounded-full border border-[#8a2517]/20">
                Service Feedback
              </span>
              <span className="text-xs font-bold text-[#8a2517] group-hover:translate-x-1 transition-transform flex items-center gap-0.5">
                Rate &rarr;
              </span>
            </div>
            <h4 className="font-display font-bold text-base text-[#241c16] group-hover:text-[#8a2517] transition-colors">
              Rate Meals, Service or Stay
            </h4>
            <p className="text-xs text-[#695646]">
              Rate individual dining orders, room care requests, or your complete stay. Stored in Google Sheet <strong>'Service Feedback'</strong> tab.
            </p>
          </div>
        </div>
      </section>

      {/* 4 Core Portals Navigation Grid */}
      <section className="space-y-4">
        <div className="text-center space-y-1">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#241c16]">
            Royal Hospitality &amp; Guest Services
          </h2>
          <p className="font-serif italic text-sm text-[#755943]">
            Seamless digital elegance honoring 100 years of Rajput tradition
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Card 1: Guest Check-in */}
          <div 
            onClick={() => onNavigateTab('checkin')}
            className="group cursor-pointer rounded-2xl bg-[#fffdfa] p-6 border-2 border-[#d8c5aa] hover:border-[#8a2517] shadow-md hover:shadow-xl transition-all space-y-4"
          >
            <div className="w-12 h-12 rounded-xl bg-[#8a2517]/10 border border-[#8a2517]/20 flex items-center justify-center text-[#8a2517] group-hover:scale-110 transition-transform">
              <ClipboardCheck className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-lg text-[#241c16] group-hover:text-[#8a2517] transition-colors flex items-center justify-between">
                <span>Guest Check-in</span>
                <ChevronRight className="w-4 h-4 text-[#c59b27] group-hover:translate-x-1 transition-transform" />
              </h3>
              <p className="text-xs text-[#695646] leading-relaxed">
                Self check-in with Passport OCR, live selfie camera capture, and automatic Government Form C generation.
              </p>
            </div>
            <div className="pt-2 text-[11px] font-bold text-[#8a2517] flex items-center gap-1">
              <span>Start Check-in</span> &rarr;
            </div>
          </div>

          {/* Card 2: About Property */}
          <div 
            onClick={() => onNavigateTab('about')}
            className="group cursor-pointer rounded-2xl bg-[#fffdfa] p-6 border-2 border-[#d8c5aa] hover:border-[#8a2517] shadow-md hover:shadow-xl transition-all space-y-4"
          >
            <div className="w-12 h-12 rounded-xl bg-[#c59b27]/15 border border-[#c59b27]/30 flex items-center justify-center text-[#856113] group-hover:scale-110 transition-transform">
              <Compass className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-lg text-[#241c16] group-hover:text-[#8a2517] transition-colors flex items-center justify-between">
                <span>About Property</span>
                <ChevronRight className="w-4 h-4 text-[#c59b27] group-hover:translate-x-1 transition-transform" />
              </h3>
              <p className="text-xs text-[#695646] leading-relaxed">
                Discover the 1924 Shekhawati Haveli architecture, carved sandstone jharokhas, baori pool, and royal suites.
              </p>
            </div>
            <div className="pt-2 text-[11px] font-bold text-[#8a2517] flex items-center gap-1">
              <span>Explore History</span> &rarr;
            </div>
          </div>

          {/* Card 3: Royal Dining */}
          <div 
            onClick={handleInitiateDiningOrder}
            className="group cursor-pointer rounded-2xl bg-[#fffdfa] p-6 border-2 border-[#d8c5aa] hover:border-[#8a2517] shadow-md hover:shadow-xl transition-all space-y-4"
          >
            <div className="flex items-center justify-between">
              <div className="w-12 h-12 rounded-xl bg-[#8a2517]/10 border border-[#8a2517]/20 flex items-center justify-center text-[#8a2517] group-hover:scale-110 transition-transform">
                <Utensils className="w-6 h-6" />
              </div>
              {!authSession ? (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-900 border border-amber-300">
                  <Lock className="w-2.5 h-2.5" /> Login Required
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 border border-emerald-300">
                  <CheckCircle2 className="w-2.5 h-2.5" /> Ready to Order
                </span>
              )}
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-lg text-[#241c16] group-hover:text-[#8a2517] transition-colors flex items-center justify-between">
                <span>Royal Rasoi Dining</span>
                <ChevronRight className="w-4 h-4 text-[#c59b27] group-hover:translate-x-1 transition-transform" />
              </h3>
              <p className="text-xs text-[#695646] leading-relaxed">
                Order authentic Mewari &amp; Shekhawati delicacies, courtyard afternoon chai, and room service delivered to your suite.
              </p>
            </div>
            <div className="pt-2 text-[11px] font-bold text-[#8a2517] flex items-center justify-between">
              <span>{authSession ? 'Order Cuisine' : 'Log In via Email to Order'}</span>
              <span>&rarr;</span>
            </div>
          </div>

          {/* Card 4: Concierge & Folio */}
          <div 
            onClick={() => onNavigateTab('chat')}
            className="group cursor-pointer rounded-2xl bg-[#fffdfa] p-6 border-2 border-[#d8c5aa] hover:border-[#8a2517] shadow-md hover:shadow-xl transition-all space-y-4"
          >
            <div className="w-12 h-12 rounded-xl bg-[#24613b]/10 border border-[#24613b]/20 flex items-center justify-center text-[#24613b] group-hover:scale-110 transition-transform">
              <MessageSquare className="w-6 h-6" />
            </div>
            <div className="space-y-1">
              <h3 className="font-display font-bold text-lg text-[#241c16] group-hover:text-[#8a2517] transition-colors flex items-center justify-between">
                <span>Palace Concierge</span>
                <ChevronRight className="w-4 h-4 text-[#c59b27] group-hover:translate-x-1 transition-transform" />
              </h3>
              <p className="text-xs text-[#695646] leading-relaxed">
                24/7 AI Butler and Front Desk assistance for heritage walks, taxi booking, linen requests, and billing queries.
              </p>
            </div>
            <div className="pt-2 text-[11px] font-bold text-[#8a2517] flex items-center gap-1">
              <span>Chat with Butler</span> &rarr;
            </div>
          </div>
        </div>
      </section>

      {/* Architectural Visual Showcase Preview */}
      <section className="rounded-3xl bg-[#fffdfa] border-2 border-[#d8c5aa] p-8 shadow-xl space-y-8">
        <div className="flex flex-col md:flex-row items-start md:items-end justify-between gap-4 border-b border-[#ebdcc8] pb-6">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-widest text-[#8a2517]">
              Rajasthan Royal Architecture
            </span>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#241c16]">
              A Centenary of Sandstone &amp; Soul
            </h2>
            <p className="font-serif italic text-sm text-[#755943]">
              Handcrafted in 1924 by master stone artisans of Jaisalmer and Jaipur
            </p>
          </div>

          <button
            onClick={() => onNavigateTab('about')}
            className="px-4 py-2 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] text-[#8a2517] text-xs font-bold hover:bg-[#8a2517] hover:text-white transition-all flex items-center gap-1.5"
          >
            <span>Read Complete Property Archive</span> &rarr;
          </button>
        </div>

        {/* Image Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Feature 1 */}
          <div className="rounded-2xl overflow-hidden border border-[#d8c5aa] shadow-sm group">
            <div className="h-48 overflow-hidden relative">
              <img
                src="https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?auto=format&fit=crop&w=800&q=80"
                alt="Zenana Chowk Courtyard"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#241c16]/80 text-white text-[10px] font-bold">
                The Central Chowk
              </div>
            </div>
            <div className="p-4 bg-[#fcf8f2] space-y-1">
              <h4 className="font-display font-bold text-sm text-[#241c16]">Open-Sky Sandstone Courtyard</h4>
              <p className="text-xs text-[#695646]">
                Surrounded by ornate colonnades, marble fountains, and fragrant night-blooming jasmine for evening musical soirees.
              </p>
            </div>
          </div>

          {/* Feature 2 */}
          <div className="rounded-2xl overflow-hidden border border-[#d8c5aa] shadow-sm group">
            <div className="h-48 overflow-hidden relative">
              <img
                src="https://images.unsplash.com/photo-1609766857041-ed402ea8069a?auto=format&fit=crop&w=800&q=80"
                alt="Jharokha Carved Balcony"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#241c16]/80 text-white text-[10px] font-bold">
                Carved Jharokhas
              </div>
            </div>
            <div className="p-4 bg-[#fcf8f2] space-y-1">
              <h4 className="font-display font-bold text-sm text-[#241c16]">Intricate Stone Lattice Jali</h4>
              <p className="text-xs text-[#695646]">
                Traditional Rajasthani stone screens engineered for natural desert cooling while offering panoramic sunset views.
              </p>
            </div>
          </div>

          {/* Feature 3 */}
          <div className="rounded-2xl overflow-hidden border border-[#d8c5aa] shadow-sm group">
            <div className="h-48 overflow-hidden relative">
              <img
                src="https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=800&q=80"
                alt="Baori Plunge Pool"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute top-3 left-3 px-2.5 py-1 rounded-md bg-[#241c16]/80 text-white text-[10px] font-bold">
                Stepwell Oasis
              </div>
            </div>
            <div className="p-4 bg-[#fcf8f2] space-y-1">
              <h4 className="font-display font-bold text-sm text-[#241c16]">Baori-Inspired Plunge Pool</h4>
              <p className="text-xs text-[#695646]">
                Architectural homage to Rajasthan’s geometric stepwells, framed by sandstone arches and fragrant bougainvillea.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Guest Assurance Footer Strip */}
      <div className="rounded-2xl bg-[#f4ece1] border border-[#d8c5aa] p-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#8a2517] text-white flex items-center justify-center shrink-0 shadow">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-display font-bold text-sm text-[#241c16]">Statutory Form C Compliant Homestay</h4>
            <p className="text-xs text-[#695646]">Foreign &amp; domestic traveler registration compliant with Bureau of Immigration &amp; Ministry of Tourism.</p>
          </div>
        </div>

        <button
          onClick={() => onNavigateTab('checkin')}
          className="px-5 py-2.5 rounded-xl bg-[#8a2517] text-white text-xs font-bold shadow hover:bg-[#a32e1d] transition-all whitespace-nowrap"
        >
          Check In Now
        </button>
      </div>

      {/* Post-Service Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackModalOpen}
        onClose={() => setIsFeedbackModalOpen(false)}
        currentGuest={currentGuest}
        authSession={authSession}
      />
    </div>
  );
};
