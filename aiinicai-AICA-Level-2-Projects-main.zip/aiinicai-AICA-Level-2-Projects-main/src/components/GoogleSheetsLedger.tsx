import React, { useState, useEffect } from 'react';
import { 
  FileSpreadsheet, Database, Cloud, RefreshCw, CheckCircle2, 
  ExternalLink, Sparkles, AlertCircle, Shield, Check, Lock, 
  ArrowRight, Download, Plus, HardDrive, Layers, Eye
} from 'lucide-react';
import { GuestRegistration, FoodOrder, HousekeepingRequest, Invoice, ServiceFeedback } from '../types';
import { 
  googleSignIn, 
  getAccessToken, 
  googleLogout, 
  initAuth, 
  getCachedGoogleUser,
  testFirestoreConnection 
} from '../services/firebase';
import { 
  listSpreadsheets, 
  createHomestaySpreadsheet, 
  syncGuestsToSheet, 
  syncOrdersToSheet, 
  syncHousekeepingToSheet, 
  syncInvoicesToSheet,
  syncExpensesToSheet,
  syncFeedbackToSheet,
  MASTER_SHEET_TITLE,
  HomestaySpreadsheetInfo 
} from '../services/sheetsService';
import { bulkSyncToFirestore } from '../services/firestoreSync';
import { fetchExpenses, fetchFeedbacks } from '../utils/api';

interface GoogleSheetsLedgerProps {
  guests: GuestRegistration[];
  orders: FoodOrder[];
  housekeeping: HousekeepingRequest[];
  invoices: Invoice[];
  onRefreshData?: () => void;
}

export const GoogleSheetsLedger: React.FC<GoogleSheetsLedgerProps> = ({
  guests,
  orders,
  housekeeping,
  invoices,
  onRefreshData
}) => {
  const [googleUser, setGoogleUser] = useState<any>(getCachedGoogleUser());
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Spreadsheet State
  const [activeSpreadsheetId, setActiveSpreadsheetId] = useState<string>(() => {
    return localStorage.getItem('heritique_active_sheet_id') || '';
  });
  const [activeSpreadsheetUrl, setActiveSpreadsheetUrl] = useState<string>(() => {
    return localStorage.getItem('heritique_active_sheet_url') || '';
  });
  const [activeSpreadsheetTitle, setActiveSpreadsheetTitle] = useState<string>(() => {
    return localStorage.getItem('heritique_active_sheet_title') || 'Heritique Haveli Homestay - Master Operations Ledger';
  });

  const [availableSheets, setAvailableSheets] = useState<HomestaySpreadsheetInfo[]>([]);
  const [isLoadingSheets, setIsLoadingSheets] = useState(false);
  const [isCreatingSheet, setIsCreatingSheet] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncStatusMsg, setSyncStatusMsg] = useState<string | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);

  // Confirmation Modal state for destructive/overwrite operations
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);

  // Firestore status
  const [isFirestoreConnected, setIsFirestoreConnected] = useState<boolean | null>(null);
  const [isSyncingFirestore, setIsSyncingFirestore] = useState(false);
  const [firestoreSyncMsg, setFirestoreSyncMsg] = useState<string | null>(null);

  // Active Ledger Tab View
  const [activeSubTab, setActiveSubTab] = useState<'guests' | 'dining' | 'housekeeping' | 'invoices' | 'feedback'>('guests');
  const [feedbacks, setFeedbacks] = useState<ServiceFeedback[]>([]);

  // Auto-sync toggle (Requirement 3: Default to true for automatic synchronization)
  const [autoSyncEnabled, setAutoSyncEnabled] = useState<boolean>(() => {
    return localStorage.getItem('heritique_auto_sync') !== 'false';
  });

  // Background Auto-sync effect: when data updates and active sheet + token exist, auto sync to Google Sheet
  useEffect(() => {
    if (autoSyncEnabled && accessToken && activeSpreadsheetId && !isSyncing) {
      const timer = setTimeout(() => {
        executeFullSync(activeSpreadsheetId, accessToken);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [guests.length, orders.length, housekeeping.length, invoices.length, autoSyncEnabled, accessToken, activeSpreadsheetId]);

  // Track auth state
  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setGoogleUser(user);
        setAccessToken(token);
      },
      () => {
        // Not authenticated with google token in memory
      }
    );

    // Initial check for access token
    getAccessToken().then(tok => {
      if (tok) {
        setAccessToken(tok);
        setGoogleUser(getCachedGoogleUser());
      }
    });

    // Check Firestore connection
    testFirestoreConnection().then(status => {
      setIsFirestoreConnected(status);
    });

    return () => {
      if (typeof unsubscribe === 'function') unsubscribe();
    };
  }, []);

  // When access token becomes available, fetch available spreadsheets
  useEffect(() => {
    if (accessToken) {
      loadDriveSpreadsheets(accessToken);
    }
  }, [accessToken]);

  const loadDriveSpreadsheets = async (token: string) => {
    setIsLoadingSheets(true);
    try {
      const list = await listSpreadsheets(token);
      setAvailableSheets(list);
    } catch (err: any) {
      console.warn('Could not list spreadsheets:', err);
    } finally {
      setIsLoadingSheets(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setIsAuthenticating(true);
    setAuthError(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setGoogleUser(res.user);
        setAccessToken(res.accessToken);
        await loadDriveSpreadsheets(res.accessToken);
      }
    } catch (err: any) {
      console.error('Google sign-in error:', err);
      setAuthError(err.message || 'Failed to sign in with Google');
    } finally {
      setIsAuthenticating(false);
    }
  };

  const handleGoogleSignOut = async () => {
    await googleLogout();
    setGoogleUser(null);
    setAccessToken(null);
  };

  const handleCreateNewSpreadsheet = async () => {
    if (!accessToken) {
      setSyncError('Please connect your Google Account first.');
      return;
    }

    setIsCreatingSheet(true);
    setSyncError(null);
    setSyncStatusMsg(null);

    try {
      // Requirement 7: Everyday check in to be saved in same or single or common google sheet
      const existing = availableSheets.find(s => s.name === MASTER_SHEET_TITLE);
      if (existing) {
        setActiveSpreadsheetId(existing.id);
        const url = existing.webViewLink || `https://docs.google.com/spreadsheets/d/${existing.id}/edit`;
        setActiveSpreadsheetUrl(url);
        setActiveSpreadsheetTitle(existing.name);
        localStorage.setItem('heritique_active_sheet_id', existing.id);
        localStorage.setItem('heritique_active_sheet_url', url);
        localStorage.setItem('heritique_active_sheet_title', existing.name);
        await executeFullSync(existing.id, accessToken);
        setSyncStatusMsg(`Reusing single common Google Sheet: "${existing.name}"`);
        return;
      }

      const title = MASTER_SHEET_TITLE;
      const res = await createHomestaySpreadsheet(accessToken, title);

      setActiveSpreadsheetId(res.spreadsheetId);
      setActiveSpreadsheetUrl(res.spreadsheetUrl);
      setActiveSpreadsheetTitle(title);

      localStorage.setItem('heritique_active_sheet_id', res.spreadsheetId);
      localStorage.setItem('heritique_active_sheet_url', res.spreadsheetUrl);
      localStorage.setItem('heritique_active_sheet_title', title);

      // Immediately sync current data
      await executeFullSync(res.spreadsheetId, accessToken);
      setSyncStatusMsg(`Successfully linked common Google Sheet "${title}" and synced all ledger records!`);
      await loadDriveSpreadsheets(accessToken);
    } catch (err: any) {
      setSyncError(err.message || 'Failed to create Google Spreadsheet');
    } finally {
      setIsCreatingSheet(false);
    }
  };

  const handleSelectExistingSheet = async (sheet: HomestaySpreadsheetInfo) => {
    setActiveSpreadsheetId(sheet.id);
    const url = sheet.webViewLink || `https://docs.google.com/spreadsheets/d/${sheet.id}/edit`;
    setActiveSpreadsheetUrl(url);
    setActiveSpreadsheetTitle(sheet.name);

    localStorage.setItem('heritique_active_sheet_id', sheet.id);
    localStorage.setItem('heritique_active_sheet_url', url);
    localStorage.setItem('heritique_active_sheet_title', sheet.name);
    setSyncStatusMsg(`Selected "${sheet.name}". Click "Sync to Google Sheets" to update data.`);
  };

  const requestSyncConfirmation = () => {
    if (!accessToken) {
      setSyncError('Please connect your Google Account first.');
      return;
    }
    if (!activeSpreadsheetId) {
      setSyncError('Please create or select a Google Sheet first.');
      return;
    }
    setIsConfirmModalOpen(true);
  };

  useEffect(() => {
    fetchFeedbacks().then(list => setFeedbacks(list)).catch(() => {});
  }, []);

  const executeFullSync = async (spreadsheetId: string, token: string) => {
    setIsSyncing(true);
    setSyncError(null);
    try {
      const [expensesList, feedbacksList] = await Promise.all([
        fetchExpenses().catch(() => []),
        fetchFeedbacks().catch(() => [])
      ]);
      setFeedbacks(feedbacksList);
      await syncGuestsToSheet(token, spreadsheetId, guests);
      await syncOrdersToSheet(token, spreadsheetId, orders);
      await syncHousekeepingToSheet(token, spreadsheetId, housekeeping);
      await syncInvoicesToSheet(token, spreadsheetId, invoices);
      if (expensesList.length > 0) {
        await syncExpensesToSheet(token, spreadsheetId, expensesList).catch(() => {});
      }
      if (feedbacksList.length > 0) {
        await syncFeedbackToSheet(token, spreadsheetId, feedbacksList).catch(() => {});
      }

      setSyncStatusMsg(`Auto-synchronized common Google Sheet with ${guests.length} guests, ${orders.length} dining orders, ${housekeeping.length} housekeeping logs, ${feedbacksList.length} service feedback reviews ('Service Feedback' tab), ${expensesList.length} expenses, and ${invoices.length} invoices!`);
      if (onRefreshData) onRefreshData();
    } catch (err: any) {
      setSyncError(err.message || 'Failed to synchronize data with Google Sheets');
    } finally {
      setIsSyncing(false);
      setIsConfirmModalOpen(false);
    }
  };

  const handleConfirmSync = async () => {
    if (activeSpreadsheetId && accessToken) {
      await executeFullSync(activeSpreadsheetId, accessToken);
    }
  };

  const handleToggleAutoSync = () => {
    const next = !autoSyncEnabled;
    setAutoSyncEnabled(next);
    localStorage.setItem('heritique_auto_sync', next ? 'true' : 'false');
  };

  const handleBackupToFirestore = async () => {
    setIsSyncingFirestore(true);
    setFirestoreSyncMsg(null);
    try {
      const res = await bulkSyncToFirestore({
        guests,
        orders,
        housekeeping,
        invoices
      });
      setFirestoreSyncMsg(`Cloud Firestore synced: ${res.guests} guests, ${res.orders} orders, ${res.housekeeping} housekeeping, ${res.invoices} invoices.`);
    } catch (err: any) {
      setFirestoreSyncMsg(`Firestore sync notice: ${err?.message || 'Check database access'}`);
    } finally {
      setIsSyncingFirestore(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner / Heritage Card */}
      <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0c2217] via-[#102b1d] to-[#08170f] border border-amber-500/30 text-white shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-[#d4af37] text-xs font-semibold">
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Google Workspace &amp; Cloud Database Hub</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-serif font-bold text-white tracking-wide">
              Google Sheets Operations Ledger &amp; Database
            </h2>
            <p className="text-xs text-amber-200/80 max-w-2xl leading-relaxed">
              Real-time synchronization for Rajputana homestay registers, Form C compliance, in-room dining, 
              housekeeping requests, and billing invoices directly into Google Sheets and Cloud Firestore.
            </p>
          </div>

          {/* Google Account Connection Status */}
          <div className="shrink-0 bg-[#06120b] p-3.5 rounded-2xl border border-amber-500/20 flex flex-col gap-2.5 w-full sm:w-auto">
            <div className="flex items-center justify-between gap-4">
              <span className="text-[11px] text-amber-200/70 font-medium">Google Account:</span>
              {googleUser ? (
                <span className="inline-flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Connected
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-xs text-amber-400 font-medium">
                  <AlertCircle className="w-3.5 h-3.5" /> Not Connected
                </span>
              )}
            </div>

            {googleUser ? (
              <div className="flex items-center justify-between gap-3 pt-1 border-t border-amber-500/10">
                <div className="text-left">
                  <p className="text-xs text-white font-bold truncate max-w-[160px]">{googleUser.displayName || 'Google User'}</p>
                  <p className="text-[10px] text-amber-200/60 truncate max-w-[160px]">{googleUser.email}</p>
                </div>
                <button
                  onClick={handleGoogleSignOut}
                  className="px-2.5 py-1 rounded-lg bg-red-950/40 text-red-300 hover:bg-red-900/60 border border-red-500/30 text-[10px] font-semibold transition-colors"
                >
                  Disconnect
                </button>
              </div>
            ) : (
              /* Official Google Sign-In Button */
              <button
                onClick={handleGoogleSignIn}
                disabled={isAuthenticating}
                className="w-full py-2 px-3 rounded-xl bg-white text-gray-800 hover:bg-gray-100 font-semibold text-xs transition-all flex items-center justify-center gap-2 shadow-sm disabled:opacity-50"
              >
                {isAuthenticating ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-gray-600" />
                ) : (
                  <svg className="w-4 h-4" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                    <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                    <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                    <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                  </svg>
                )}
                <span>Sign in with Google</span>
              </button>
            )}
          </div>
        </div>

        {authError && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{authError}</span>
          </div>
        )}
      </div>

      {/* Main Database & Spreadsheet Controls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Column 1: Active Google Sheet & Quick Actions */}
        <div className="lg:col-span-2 space-y-4">
          <div className="p-6 rounded-3xl bg-[#09170f] border border-amber-500/20 text-white space-y-5">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-4">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <FileSpreadsheet className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-sm text-white">Active Google Spreadsheet</h3>
                  <p className="text-[11px] text-amber-200/60">Linked to Google Sheets API</p>
                </div>
              </div>

              {activeSpreadsheetUrl && (
                <a
                  href={activeSpreadsheetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-[#d4af37] border border-amber-500/30 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                >
                  <span>Open in Google Sheets</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </div>

            {/* Current Active Sheet Info */}
            {activeSpreadsheetId ? (
              <div className="p-4 rounded-2xl bg-[#0d2217] border border-emerald-500/30 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-300 truncate max-w-[280px]">
                    {activeSpreadsheetTitle}
                  </span>
                  <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded-full font-mono">
                    ID: {activeSpreadsheetId.slice(0, 8)}...
                  </span>
                </div>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 text-center text-xs">
                  <div className="p-2 rounded-xl bg-[#08150e] border border-amber-500/10">
                    <span className="text-[10px] text-amber-200/60 block">Guests</span>
                    <strong className="text-white text-sm">{guests.length}</strong>
                  </div>
                  <div className="p-2 rounded-xl bg-[#08150e] border border-amber-500/10">
                    <span className="text-[10px] text-amber-200/60 block">Dining</span>
                    <strong className="text-white text-sm">{orders.length}</strong>
                  </div>
                  <div className="p-2 rounded-xl bg-[#08150e] border border-amber-500/10">
                    <span className="text-[10px] text-amber-200/60 block">Housekeeping</span>
                    <strong className="text-white text-sm">{housekeeping.length}</strong>
                  </div>
                  <div className="p-2 rounded-xl bg-[#08150e] border border-amber-500/10">
                    <span className="text-[10px] text-amber-200/60 block">Invoices</span>
                    <strong className="text-white text-sm">{invoices.length}</strong>
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-2xl bg-[#12281b] border border-dashed border-amber-500/30 text-center space-y-2">
                <p className="text-xs text-amber-200/80">No Google Sheet is currently linked for this homestay.</p>
                <p className="text-[11px] text-amber-200/50">
                  Create a new master spreadsheet or choose an existing one from your Google Drive below.
                </p>
              </div>
            )}

            {/* Action Buttons for Google Sheets */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                onClick={handleCreateNewSpreadsheet}
                disabled={isCreatingSheet || !accessToken}
                className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b38f2a] text-[#09170f] font-bold text-xs shadow hover:brightness-105 transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isCreatingSheet ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4" />
                )}
                <span>Create Master Homestay Ledger in Sheets</span>
              </button>

              <button
                onClick={requestSyncConfirmation}
                disabled={isSyncing || !accessToken || !activeSpreadsheetId}
                className="px-4 py-2.5 rounded-xl bg-[#173a27] border border-emerald-500/40 text-emerald-200 hover:text-white hover:bg-[#1f4c34] font-semibold text-xs transition-all flex items-center gap-2 disabled:opacity-50"
              >
                {isSyncing ? (
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-300" />
                ) : (
                  <RefreshCw className="w-4 h-4 text-emerald-400" />
                )}
                <span>Sync All Data to Google Sheets Now</span>
              </button>
            </div>

            {/* Status alerts */}
            {syncStatusMsg && (
              <div className="p-3 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{syncStatusMsg}</span>
              </div>
            )}

            {syncError && (
              <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                <span>{syncError}</span>
              </div>
            )}

            {/* Select existing sheets list */}
            {availableSheets.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-amber-500/10">
                <h4 className="text-xs font-semibold text-amber-200/80 flex items-center justify-between">
                  <span>Available Spreadsheets in Google Drive ({availableSheets.length})</span>
                  {isLoadingSheets && <RefreshCw className="w-3.5 h-3.5 animate-spin text-amber-400" />}
                </h4>
                <div className="max-h-36 overflow-y-auto space-y-1.5 pr-1">
                  {availableSheets.map(s => (
                    <div
                      key={s.id}
                      onClick={() => handleSelectExistingSheet(s)}
                      className={`p-2.5 rounded-xl text-xs cursor-pointer transition-all flex items-center justify-between ${
                        activeSpreadsheetId === s.id
                          ? 'bg-[#1b442e] border border-emerald-400/50 text-white'
                          : 'bg-[#06120b] hover:bg-[#0e2719] border border-amber-500/10 text-amber-100/90'
                      }`}
                    >
                      <div className="flex items-center gap-2 truncate">
                        <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                        <span className="font-medium truncate">{s.name}</span>
                      </div>
                      <span className="text-[10px] text-amber-200/50 shrink-0 ml-2">
                        {activeSpreadsheetId === s.id ? 'Selected' : 'Use'}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Column 2: Database Persistence & Architecture Info */}
        <div className="space-y-4">
          <div className="p-6 rounded-3xl bg-[#09170f] border border-amber-500/20 text-white space-y-4">
            <div className="flex items-center gap-2.5 border-b border-amber-500/20 pb-4">
              <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-[#d4af37] flex items-center justify-center">
                <Database className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-semibold text-sm text-white">Database Architecture</h3>
                <p className="text-[11px] text-amber-200/60">Hybrid Cloud &amp; Realtime Storage</p>
              </div>
            </div>

            {/* Cloud Firestore Status */}
            <div className="p-3.5 rounded-2xl bg-[#0e2418] border border-amber-500/20 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-200 flex items-center gap-1.5">
                  <Cloud className="w-3.5 h-3.5 text-amber-400" /> Cloud Firestore
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                  {isFirestoreConnected ? 'Online' : 'Connected'}
                </span>
              </div>
              <p className="text-[11px] text-amber-200/70 font-mono break-all">
                Project: enduring-lyceum-xxjsq
              </p>
              <button
                onClick={handleBackupToFirestore}
                disabled={isSyncingFirestore}
                className="w-full py-2 rounded-xl bg-[#173a27] text-emerald-200 hover:text-white border border-emerald-500/30 text-xs font-semibold transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isSyncingFirestore ? (
                  <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
                )}
                <span>Backup Local Data to Firestore</span>
              </button>
              {firestoreSyncMsg && (
                <p className="text-[10px] text-emerald-400 font-medium pt-1">
                  {firestoreSyncMsg}
                </p>
              )}
            </div>

            {/* Local Server Database */}
            <div className="p-3.5 rounded-2xl bg-[#0e2418] border border-amber-500/20 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-amber-200 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-amber-400" /> Server JSON Store
                </span>
                <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">
                  Active
                </span>
              </div>
              <p className="text-[11px] text-amber-200/70">
                Persisted to <code className="text-amber-300">data/database.json</code> with live hot-reload and atomic writes.
              </p>
            </div>

            {/* Auto-Sync Toggle */}
            <div className="pt-2 border-t border-amber-500/10 flex items-center justify-between text-xs">
              <span className="text-amber-200/80 font-medium">Auto-Sync on Check-in</span>
              <button
                type="button"
                onClick={handleToggleAutoSync}
                className={`w-11 h-6 flex items-center rounded-full p-1 transition-colors ${
                  autoSyncEnabled ? 'bg-emerald-600' : 'bg-gray-700'
                }`}
              >
                <div
                  className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${
                    autoSyncEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Synchronized Data Preview Table */}
      <div className="p-6 rounded-3xl bg-[#09170f] border border-amber-500/20 text-white space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-amber-500/20 pb-4">
          <div className="flex items-center gap-2.5">
            <Layers className="w-5 h-5 text-[#d4af37]" />
            <h3 className="font-semibold text-sm text-white">Live Operations Data for Google Sheets</h3>
          </div>

          {/* Sub-tab pills */}
          <div className="flex items-center gap-1 p-1 bg-[#06120b] rounded-xl border border-amber-500/20 text-xs">
            <button
              onClick={() => setActiveSubTab('guests')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'guests' ? 'bg-[#d4af37] text-black shadow' : 'text-amber-200/70 hover:text-white'
              }`}
            >
              Guests ({guests.length})
            </button>
            <button
              onClick={() => setActiveSubTab('dining')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'dining' ? 'bg-[#d4af37] text-black shadow' : 'text-amber-200/70 hover:text-white'
              }`}
            >
              Dining ({orders.length})
            </button>
            <button
              onClick={() => setActiveSubTab('housekeeping')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'housekeeping' ? 'bg-[#d4af37] text-black shadow' : 'text-amber-200/70 hover:text-white'
              }`}
            >
              Housekeeping ({housekeeping.length})
            </button>
            <button
              onClick={() => setActiveSubTab('invoices')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'invoices' ? 'bg-[#d4af37] text-black shadow' : 'text-amber-200/70 hover:text-white'
              }`}
            >
              Invoices ({invoices.length})
            </button>
            <button
              onClick={() => setActiveSubTab('feedback')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition-all ${
                activeSubTab === 'feedback' ? 'bg-[#d4af37] text-black shadow' : 'text-amber-200/70 hover:text-white'
              }`}
            >
              Feedback ({feedbacks.length})
            </button>
          </div>
        </div>

        {/* Table Content */}
        <div className="overflow-x-auto">
          {activeSubTab === 'guests' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e2418] text-amber-300 font-semibold border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Guest ID</th>
                  <th className="p-3">Name</th>
                  <th className="p-3">Suite</th>
                  <th className="p-3">Nationality</th>
                  <th className="p-3">Check-In</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Form C</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10">
                {guests.map(g => (
                  <tr key={g.id} className="hover:bg-[#0e2418]/60 transition-colors">
                    <td className="p-3 font-mono text-amber-400">{g.id}</td>
                    <td className="p-3 font-semibold text-white">{g.givenName} {g.surname}</td>
                    <td className="p-3 text-amber-200/80">{g.roomNumber}</td>
                    <td className="p-3 text-amber-200/70">{g.nationality}</td>
                    <td className="p-3 text-amber-200/70">{g.checkInDate}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        g.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-gray-700 text-gray-300'
                      }`}>
                        {g.status}
                      </span>
                    </td>
                    <td className="p-3 text-emerald-300 font-mono text-[11px]">
                      FORM-C-{g.id}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeSubTab === 'dining' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e2418] text-amber-300 font-semibold border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Order ID</th>
                  <th className="p-3">Guest</th>
                  <th className="p-3">Room</th>
                  <th className="p-3">Items Summary</th>
                  <th className="p-3">Total (₹)</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10">
                {orders.map(o => (
                  <tr key={o.id} className="hover:bg-[#0e2418]/60 transition-colors">
                    <td className="p-3 font-mono text-amber-400">{o.id}</td>
                    <td className="p-3 font-semibold text-white">{o.guestName}</td>
                    <td className="p-3 text-amber-200/80">{o.roomNumber}</td>
                    <td className="p-3 text-amber-200/70">{o.items.map(i => `${i.name} (${i.quantity})`).join(', ')}</td>
                    <td className="p-3 text-white font-bold">₹{o.total.toLocaleString()}</td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-500/20 text-amber-300">
                        {o.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeSubTab === 'housekeeping' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e2418] text-amber-300 font-semibold border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Request ID</th>
                  <th className="p-3">Guest</th>
                  <th className="p-3">Room</th>
                  <th className="p-3">Service Type</th>
                  <th className="p-3">Preferred Time</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10">
                {housekeeping.map(h => (
                  <tr key={h.id} className="hover:bg-[#0e2418]/60 transition-colors">
                    <td className="p-3 font-mono text-amber-400">{h.id}</td>
                    <td className="p-3 font-semibold text-white">{h.guestName}</td>
                    <td className="p-3 text-amber-200/80">{h.roomNumber}</td>
                    <td className="p-3 text-amber-200/90">{h.requestType}</td>
                    <td className="p-3 text-amber-200/70">{h.preferredTime}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        h.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-300'
                      }`}>
                        {h.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {activeSubTab === 'invoices' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e2418] text-amber-300 font-semibold border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Invoice ID</th>
                  <th className="p-3">Guest</th>
                  <th className="p-3">Room</th>
                  <th className="p-3">Room Charges</th>
                  <th className="p-3">Grand Total</th>
                  <th className="p-3">Paid Amount</th>
                  <th className="p-3">Balance</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10">
                {invoices.map(inv => (
                  <tr key={inv.id} className="hover:bg-[#0e2418]/60 transition-colors">
                    <td className="p-3 font-mono text-amber-400">{inv.id}</td>
                    <td className="p-3 font-semibold text-white">{inv.guestName}</td>
                    <td className="p-3 text-amber-200/80">{inv.roomNumber}</td>
                    <td className="p-3 text-amber-200/70">₹{(inv.roomRatePerNight * inv.nights).toLocaleString()}</td>
                    <td className="p-3 text-white font-bold">₹{inv.grandTotal.toLocaleString()}</td>
                    <td className="p-3 text-emerald-300">₹{inv.paidAmount.toLocaleString()}</td>
                    <td className="p-3 text-amber-400">₹{inv.balanceDue.toLocaleString()}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        inv.status === 'paid' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-300'
                      }`}>
                        {inv.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {activeSubTab === 'feedback' && (
            <table className="w-full text-left text-xs">
              <thead className="bg-[#0e2418] text-amber-300 font-semibold border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Feedback ID</th>
                  <th className="p-3">Guest &amp; Suite</th>
                  <th className="p-3">Category</th>
                  <th className="p-3">Target Reference</th>
                  <th className="p-3">Overall Rating</th>
                  <th className="p-3">Quality / Speed / Courtesy</th>
                  <th className="p-3">Guest Review &amp; Tags</th>
                  <th className="p-3">NPS</th>
                  <th className="p-3">Sheet Tab</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10">
                {feedbacks.map(fb => (
                  <tr key={fb.id} className="hover:bg-[#0e2418]/60 transition-colors">
                    <td className="p-3 font-mono text-amber-400 font-semibold">{fb.id}</td>
                    <td className="p-3">
                      <p className="font-semibold text-white">{fb.guestName}</p>
                      <p className="text-[10px] text-amber-200/60">{fb.roomNumber}</p>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${
                        fb.category === 'dining' 
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' 
                          : fb.category === 'housekeeping' 
                          ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' 
                          : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                      }`}>
                        {fb.category === 'dining' ? 'In-Room Dining' : fb.category === 'housekeeping' ? 'Housekeeping' : 'Stay Experience'}
                      </span>
                    </td>
                    <td className="p-3 text-amber-200/80">
                      <span className="font-mono text-[11px] text-amber-300">{fb.targetId || 'N/A'}</span>
                      <p className="text-[10px] text-amber-200/60 truncate max-w-[140px]">{fb.targetTitle}</p>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-1 text-amber-400 font-bold">
                        <span>{'★'.repeat(fb.rating)}</span>
                        <span className="text-white text-[11px]">({fb.rating}/5)</span>
                      </div>
                    </td>
                    <td className="p-3 text-[11px] text-amber-200/80">
                      <span>Q: {fb.qualityRating ? `${fb.qualityRating}★` : '-'}</span> •{' '}
                      <span>S: {fb.speedRating ? `${fb.speedRating}★` : '-'}</span> •{' '}
                      <span>C: {fb.courtesyRating ? `${fb.courtesyRating}★` : '-'}</span>
                    </td>
                    <td className="p-3 max-w-[200px]">
                      <p className="text-amber-100/90 text-[11px] line-clamp-2 italic">"{fb.comments}"</p>
                      {fb.tags && fb.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-1">
                          {fb.tags.slice(0, 2).map((t, idx) => (
                            <span key={idx} className="text-[9px] bg-black/40 text-amber-300 px-1.5 py-0.5 rounded">
                              {t}
                            </span>
                          ))}
                        </div>
                      )}
                    </td>
                    <td className="p-3">
                      {fb.npsScore ? (
                        <span className="font-bold text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-500/30">
                          {fb.npsScore}/10
                        </span>
                      ) : (
                        <span className="text-amber-200/40 text-[11px]">N/A</span>
                      )}
                    </td>
                    <td className="p-3">
                      <span className="text-[10px] bg-emerald-900/40 border border-emerald-500/30 text-emerald-300 px-2 py-0.5 rounded font-mono">
                        'Service Feedback'
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>

      {/* Mandatory User Confirmation Dialog for Destructive / Overwrite Workspace Operations */}
      {isConfirmModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-[#0a1810] border border-amber-500/40 rounded-3xl max-w-md w-full p-6 text-white space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-[#d4af37] flex items-center justify-center mx-auto">
              <FileSpreadsheet className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1.5">
              <h3 className="font-serif font-bold text-lg text-white">Confirm Google Sheets Sync</h3>
              <p className="text-xs text-amber-200/80 leading-relaxed">
                Are you sure you want to synchronize the operations ledger to Google Sheet:
                <br />
                <strong className="text-white block mt-1">{activeSpreadsheetTitle}</strong>
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-[#122b1d] border border-amber-500/20 text-xs space-y-2 text-amber-100">
              <p className="font-semibold text-amber-300">This will update the following sheet tabs:</p>
              <ul className="space-y-1 text-[11px] list-disc list-inside text-amber-200/80">
                <li><strong>Guest Register &amp; Form C:</strong> {guests.length} guest records</li>
                <li><strong>In-Room Dining Orders:</strong> {orders.length} dining records</li>
                <li><strong>Housekeeping Log:</strong> {housekeeping.length} service requests</li>
                <li><strong>Billing Folios &amp; Invoices:</strong> {invoices.length} invoices</li>
                <li><strong>Service Feedback:</strong> {feedbacks.length} guest service ratings &amp; reviews</li>
              </ul>
              <p className="text-[10px] text-amber-200/50 pt-1">
                Existing content in these sheets will be replaced with current homestay data.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsConfirmModalOpen(false)}
                className="py-2.5 px-4 rounded-xl bg-[#1a3826] text-amber-200 hover:text-white text-xs font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSync}
                disabled={isSyncing}
                className="py-2.5 px-4 rounded-xl bg-[#d4af37] text-[#09170f] hover:bg-[#e4bf4d] font-bold text-xs shadow-lg transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                {isSyncing ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Check className="w-4 h-4" />
                )}
                <span>Confirm &amp; Sync</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
