import React, { useState, useEffect } from 'react';
import { 
  Sun, CloudSun, CloudRain, Wind, Droplets, Compass, 
  RefreshCw, ExternalLink, ShieldCheck, Thermometer, 
  Sparkles, Clock, AlertCircle, CheckCircle2
} from 'lucide-react';
import { ShekhawatiWeather } from '../types';
import { fetchShekhawatiWeather } from '../utils/api';

export const WeatherWidget: React.FC = () => {
  const [weather, setWeather] = useState<ShekhawatiWeather | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [showSources, setShowSources] = useState<boolean>(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const loadWeather = async (forceRefresh = false) => {
    if (forceRefresh) setIsRefreshing(true);
    else setIsLoading(true);
    setErrorMsg(null);

    try {
      const data = await fetchShekhawatiWeather(forceRefresh);
      setWeather(data);
    } catch (err: any) {
      console.error('Error fetching weather:', err);
      setErrorMsg('Could not load live weather. Showing regional climate estimate.');
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadWeather();
  }, []);

  const getWeatherIcon = (iconName?: string) => {
    switch (iconName) {
      case 'rainy':
        return <CloudRain className="w-8 h-8 text-sky-500 animate-bounce" />;
      case 'cloudy':
        return <CloudSun className="w-8 h-8 text-amber-500" />;
      case 'windy':
        return <Wind className="w-8 h-8 text-teal-600 animate-pulse" />;
      case 'haze':
        return <CloudSun className="w-8 h-8 text-amber-600" />;
      default:
        return <Sun className="w-8 h-8 text-[#d97706] animate-spin" style={{ animationDuration: '24s' }} />;
    }
  };

  if (isLoading && !weather) {
    return (
      <div className="rounded-3xl border-2 border-[#d8c5aa] bg-[#fffdfa] p-6 shadow-xl flex items-center justify-center min-h-[160px]">
        <div className="flex items-center gap-3 text-sm text-[#755943]">
          <RefreshCw className="w-5 h-5 text-[#8a2517] animate-spin" />
          <span>Fetching live Shekhawati weather via Google Search grounding...</span>
        </div>
      </div>
    );
  }

  return (
    <div id="shekhawati-weather-widget" className="rounded-3xl border-2 border-[#d8c5aa] bg-gradient-to-br from-[#fffdfa] via-[#fbf7f0] to-[#f5ecdd] p-6 shadow-xl space-y-5 relative overflow-hidden">
      {/* Decorative Traditional Rajputana Arch Motif in subtle opacity */}
      <div className="absolute -top-10 -right-10 w-44 h-44 rounded-full bg-[#c59b27]/10 pointer-events-none blur-2xl" />
      <div className="absolute -bottom-10 -left-10 w-44 h-44 rounded-full bg-[#8a2517]/5 pointer-events-none blur-2xl" />

      {/* Header bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#ebdcc8] pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider bg-[#8a2517]/10 border border-[#8a2517]/25 text-[#8a2517]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#8a2517] animate-ping" />
              Live Destination Climate
            </span>
            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300">
              <ShieldCheck className="w-3 h-3 text-emerald-600" />
              Search Grounded
            </span>
          </div>
          <h3 className="font-display font-bold text-xl sm:text-2xl text-[#241c16] mt-1 flex items-center gap-2">
            <span>Shekhawati Regional Weather</span>
            <span className="text-xs font-serif italic text-[#755943] font-normal hidden md:inline">
              (Sikar • Jhunjhunu • Fatehpur Haveli Belt)
            </span>
          </h3>
          <p className="text-xs text-[#755943] flex items-center gap-2 mt-0.5">
            <Clock className="w-3.5 h-3.5 text-[#c59b27]" />
            <span>Updated {weather?.lastUpdated ? new Date(weather.lastUpdated).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'recently'}</span>
            {weather?.isCached && <span className="text-[10px] text-[#9b806d]">• Cached for speed</span>}
          </p>
        </div>

        {/* Refresh & Citations Toggle */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => loadWeather(true)}
            disabled={isRefreshing}
            className="px-3 py-1.5 rounded-xl bg-[#fffdfa] border border-[#d8c5aa] text-[#4a3b30] hover:text-[#8a2517] hover:border-[#8a2517] text-xs font-semibold shadow-sm transition-all flex items-center gap-1.5 disabled:opacity-50"
            title="Re-query live Google Search grounding for latest conditions"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#8a2517]' : ''}`} />
            <span>{isRefreshing ? 'Refreshing...' : 'Refresh'}</span>
          </button>

          <button
            onClick={() => setShowSources(!showSources)}
            className="px-3 py-1.5 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] text-[#755943] hover:text-[#241c16] text-xs font-semibold shadow-sm transition-all flex items-center gap-1"
            title="View Google Search Grounding verification sources"
          >
            <ExternalLink className="w-3.5 h-3.5 text-[#c59b27]" />
            <span>Sources ({weather?.groundingSources?.length || 0})</span>
          </button>
        </div>
      </div>

      {errorMsg && (
        <div className="p-2.5 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Weather Card Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center">
        {/* Left: Temperature & Core Metric */}
        <div className="md:col-span-4 flex items-center gap-4 bg-[#fffdfa] p-4 rounded-2xl border border-[#ebdcc8] shadow-sm">
          <div className="p-3 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center shrink-0">
            {getWeatherIcon(weather?.conditionIcon)}
          </div>
          <div>
            <div className="flex items-baseline gap-2">
              <span className="font-display font-extrabold text-4xl sm:text-5xl text-[#241c16] tracking-tight">
                {weather?.temperatureC ?? 33}°C
              </span>
              <span className="text-base text-[#755943] font-semibold">
                / {weather?.temperatureF ?? 91}°F
              </span>
            </div>
            <p className="font-semibold text-xs text-[#8a2517] uppercase tracking-wide mt-0.5">
              {weather?.condition ?? 'Mostly Sunny & Clear'}
            </p>
            <p className="text-[11px] text-[#755943]">
              Feels like {weather?.feelsLikeC ?? 34}°C
            </p>
          </div>
        </div>

        {/* Center: Micro Metrics (Humidity, Wind, Rain, AQI) */}
        <div className="md:col-span-4 grid grid-cols-2 gap-2 text-xs">
          <div className="bg-[#fffdfa] p-3 rounded-xl border border-[#ebdcc8] flex items-center gap-2.5 shadow-xs">
            <Droplets className="w-4 h-4 text-sky-600 shrink-0" />
            <div>
              <span className="text-[10px] text-[#755943] block">Humidity</span>
              <strong className="text-[#241c16] font-semibold">{weather?.humidity ?? 56}%</strong>
            </div>
          </div>

          <div className="bg-[#fffdfa] p-3 rounded-xl border border-[#ebdcc8] flex items-center gap-2.5 shadow-xs">
            <Wind className="w-4 h-4 text-teal-600 shrink-0" />
            <div>
              <span className="text-[10px] text-[#755943] block">Wind</span>
              <strong className="text-[#241c16] font-semibold">{weather?.windSpeedKmH ?? 10} km/h</strong>
            </div>
          </div>

          <div className="bg-[#fffdfa] p-3 rounded-xl border border-[#ebdcc8] flex items-center gap-2.5 shadow-xs">
            <Thermometer className="w-4 h-4 text-amber-600 shrink-0" />
            <div>
              <span className="text-[10px] text-[#755943] block">Rain Chance</span>
              <strong className="text-[#241c16] font-semibold">{weather?.precipitationChance ?? 5}%</strong>
            </div>
          </div>

          <div className="bg-[#fffdfa] p-3 rounded-xl border border-[#ebdcc8] flex items-center gap-2.5 shadow-xs">
            <Sparkles className="w-4 h-4 text-[#c59b27] shrink-0" />
            <div>
              <span className="text-[10px] text-[#755943] block">Air Quality</span>
              <strong className="text-[#241c16] font-semibold text-[11px]">{weather?.airQuality ?? 'Moderate (AQI 82)'}</strong>
            </div>
          </div>
        </div>

        {/* Right: Butler Advice for Guests staying at Heritique Homestay */}
        <div className="md:col-span-4 bg-[#8a2517]/5 border border-[#8a2517]/20 p-4 rounded-2xl space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-bold text-[#8a2517]">
            <Compass className="w-3.5 h-3.5 text-[#c59b27]" />
            <span>Homestay Butler's Daily Advice</span>
          </div>
          <p className="text-xs text-[#4a3b30] leading-relaxed">
            {weather?.guestAdvice || 'Ideal conditions for morning courtyard breakfast & evening rooftop haveli fresco viewing. Carry light cottons and sun protection during midday heritage walks.'}
          </p>
        </div>
      </div>

      {/* 4-Period Daily Horizon (Morning / Afternoon / Evening / Night) */}
      {weather?.forecast && weather.forecast.length > 0 && (
        <div className="pt-2 border-t border-[#ebdcc8]/80">
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#755943] block mb-2">
            Today's Shekhawati Horizon
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {weather.forecast.map((fc, idx) => (
              <div key={idx} className="bg-[#fffdfa] p-2.5 rounded-xl border border-[#ebdcc8] text-center shadow-xs">
                <span className="text-[11px] font-bold text-[#8a2517] block">{fc.timeOfDay}</span>
                <span className="font-display font-bold text-lg text-[#241c16] block">{fc.tempC}°C</span>
                <span className="text-[10px] text-[#755943] leading-tight block">{fc.condition}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search Grounding Sources Accordion / Panel */}
      {showSources && weather?.groundingSources && weather.groundingSources.length > 0 && (
        <div className="p-4 rounded-2xl bg-[#f4ece1] border border-[#d8c5aa] text-xs space-y-2 animate-fadeIn">
          <div className="flex items-center justify-between">
            <span className="font-bold text-[#241c16] flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              Verified Google Search Grounding Citations
            </span>
            <span className="text-[10px] text-[#755943]">Real-time live search references</span>
          </div>
          <p className="text-[11px] text-[#5c493a]">
            These live search citations ground the current meteorological conditions for the Shekhawati region (Fatehpur, Sikar, Jhunjhunu, Churu) in Rajasthan:
          </p>
          <ul className="space-y-1.5 pt-1">
            {weather.groundingSources.map((source, i) => (
              <li key={i} className="flex items-center gap-2">
                <span className="text-[10px] font-mono text-[#8a2517] font-bold">[{i + 1}]</span>
                <a
                  href={source.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#8a2517] hover:underline font-medium text-xs flex items-center gap-1 truncate max-w-full"
                >
                  <span className="truncate">{source.title || source.url}</span>
                  <ExternalLink className="w-3 h-3 shrink-0" />
                </a>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
