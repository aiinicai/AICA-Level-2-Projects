import React, { useState } from 'react';
import { 
  Compass, MapPin, Calendar, Clock, Star, ShieldCheck, 
  Utensils, Sparkles, CheckCircle2, ChevronRight, ArrowRight, 
  Phone, Mail, Coffee, Award, Trees, Waves, BedDouble, Users
} from 'lucide-react';

interface AboutPropertyProps {
  onNavigateTab: (tab: 'home' | 'about' | 'checkin' | 'dining' | 'billing' | 'chat' | 'admin') => void;
}

const ROOM_SHOWCASES = [
  {
    id: 'maharaja',
    title: 'The Maharaja Heritage Suite (Suite 101)',
    tag: 'Signature Suite',
    description: 'A regal master sanctuary spanning 750 sq.ft with an authentic 18th-century carved teakwood four-poster bed, private jharokha overlooking the Aravalli hills, and an Italian marble soaking bath.',
    features: ['Private Jharokha Balcony', 'Vintage Belgian Chandelier', 'Heritage Brass Soaking Tub', 'Complimentary Royal High Tea'],
    image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
    rate: '₹9,500 / night'
  },
  {
    id: 'courtyard',
    title: 'Rajputana Courtyard Chamber (Room 102)',
    tag: 'Direct Chowk Access',
    description: 'Opening directly into the fragrant jasmine courtyard and central water fountain, this chamber showcases hand-dressed yellow Jaisalmer sandstone pillars and vintage silk furnishings.',
    features: ['Direct Garden Chowk Access', 'Hand-carved Sandstone Pillars', 'Artisan Block-printed Linens', 'Morning Peafowl Awakening'],
    image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=1000&q=80',
    rate: '₹6,800 / night'
  },
  {
    id: 'fresco',
    title: 'Shekhawati Fresco Deluxe (Room 104)',
    tag: 'Historic Frescoes',
    description: 'Adorned with restored 1920s natural vegetable dye murals depicting royal processions and mythological legends, paired with contemporary five-star ensuite comforts.',
    features: ['Original 1924 Fresco Ceilings', 'Arched Colonnade Alcove', 'Rain Shower & Organic Ayurvedic Toiletries', 'Heritage Writing Desk'],
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1000&q=80',
    rate: '₹5,500 / night'
  }
];

const HERITAGE_PILLARS = [
  {
    title: 'Hand-Carved Jharokhas',
    subtitle: 'Passive Desert Air Conditioning',
    desc: 'The intricate stone lattice (jali) creates a Venturi effect, compressing incoming air to naturally cool the chambers by up to 6°C during hot desert afternoons.',
    icon: Sparkles
  },
  {
    title: 'The Zenana Chowk',
    subtitle: 'Central Open-Sky Courtyard',
    desc: 'Constructed according to traditional Rajput Vastu Shastra principles, fostering ventilation, rainwater percolation, and stargazing.',
    icon: Trees
  },
  {
    title: 'Baori Plunge Pool',
    subtitle: 'Stepwell Architectural Homage',
    desc: 'Inspired by the geometric stepwells of Abhaneri, our natural stone plunge pool is lined with cool green marble and fed by fresh rainwater filtration.',
    icon: Waves
  },
  {
    title: 'Centenary Lineage',
    subtitle: 'Commissioned 1924',
    desc: 'Built by Thakur Saheb Bhawani Singh Ji as a monsoon retreat and diplomatic guest manor, preserved meticulously for four generations.',
    icon: Award
  }
];

export const AboutProperty: React.FC<AboutPropertyProps> = ({ onNavigateTab }) => {
  const [selectedRoom, setSelectedRoom] = useState(ROOM_SHOWCASES[0]);

  return (
    <div className="space-y-16 pb-16">
      {/* Hero Header Banner */}
      <section className="relative rounded-3xl overflow-hidden shadow-2xl border border-[#d8c5aa] bg-[#fbf6ee]">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1599661046827-dacff0c0f09a?auto=format&fit=crop&w=2000&q=85"
            alt="Heritique Haveli Architecture"
            className="w-full h-full object-cover object-center"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-[#fbf8f2]/95 via-[#f6efe2]/90 to-[#ede0cc]/80" />
        </div>

        <div className="relative z-10 max-w-5xl mx-auto px-6 py-14 sm:py-18 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#8a2517]/10 border border-[#8a2517]/25 text-[#8a2517] text-xs font-semibold">
            <Compass className="w-3.5 h-3.5" />
            <span>Centenary Heritage Haveli • Established 1924</span>
          </div>

          <h1 className="font-display font-bold text-3xl sm:text-5xl text-[#241c16] tracking-tight">
            The Royal Story of <span className="text-[#8a2517]">Heritique Haveli</span>
          </h1>

          <p className="font-serif italic text-base sm:text-lg text-[#755943] max-w-2xl">
            A living chronicle of Rajasthan’s golden age, where handcrafted Jaisalmer stone, Rajput courtyards, and warm homestay hospitality welcome the world.
          </p>

          <div className="pt-2 flex flex-wrap gap-3">
            <button
              onClick={() => onNavigateTab('checkin')}
              className="px-6 py-3 rounded-xl bg-[#8a2517] text-white font-bold text-xs shadow-lg hover:bg-[#a32e1d] transition-all flex items-center gap-2"
            >
              <span>Guest Check-in Online</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigateTab('dining')}
              className="px-5 py-3 rounded-xl bg-[#fffdfa] border border-[#d8c5aa] text-[#4a3b30] font-bold text-xs hover:border-[#8a2517] transition-all"
            >
              Royal Rasoi Menu
            </button>
          </div>
        </div>
      </section>

      {/* The Story & Architecture Section */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
        <div className="lg:col-span-6 space-y-5">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-widest text-[#8a2517]">Architectural Heritage</span>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#241c16]">
              Stone That Whispers Centuries of Grace
            </h2>
          </div>

          <p className="text-sm text-[#4a3b30] leading-relaxed">
            Commissioned in the winter of 1924 by Thakur Saheb Bhawani Singh, Heritique was designed as an oasis of intellectual retreat and noble Rajput fellowship. Master stone carvers from Jaisalmer and fresco painters from Shekhawati spent five years chiseling the sandstone colonnades, jharokha balconies, and high-arched zenana courtyards.
          </p>

          <p className="text-sm text-[#4a3b30] leading-relaxed">
            Today, meticulously restored by the fourth-generation descendants, Heritique balances timeless heritage preservation with modern luxury—featuring ultra-fast fiber connectivity, modern ensuite rain showers, and paperless check-in compliance for international and domestic guests.
          </p>

          <div className="grid grid-cols-2 gap-4 pt-2">
            <div className="p-3.5 rounded-2xl bg-[#fffdfa] border border-[#d8c5aa]">
              <p className="text-2xl font-display font-bold text-[#8a2517]">100+</p>
              <p className="text-xs font-medium text-[#695646]">Years of Royal Lineage</p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#fffdfa] border border-[#d8c5aa]">
              <p className="text-2xl font-display font-bold text-[#8a2517]">14</p>
              <p className="text-xs font-medium text-[#695646]">Bespoke Heritage Suites</p>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 relative">
          <div className="rounded-3xl overflow-hidden border-2 border-[#d8c5aa] shadow-2xl relative">
            <img
              src="https://images.unsplash.com/photo-1609766857041-ed402ea8069a?auto=format&fit=crop&w=1200&q=85"
              alt="Carved Stone Colonnade of Heritique"
              className="w-full h-[400px] object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-[#241c16]/90 via-[#241c16]/40 to-transparent p-6 text-white">
              <p className="text-xs font-bold uppercase tracking-wider text-[#c59b27]">Carved Jharokha Colonnade</p>
              <p className="text-sm font-serif italic">Hand-chiseled yellow Jaisalmer sandstone filtering the golden desert dusk.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Heritage Architecture Features Grid */}
      <section className="space-y-6">
        <div className="text-center space-y-1">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#241c16]">
            Architectural Marvels of the Haveli
          </h2>
          <p className="font-serif italic text-sm text-[#755943]">
            Traditional design elements crafted for luxury, comfort, and sustainable desert living
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {HERITAGE_PILLARS.map((pillar, idx) => {
            const Icon = pillar.icon;
            return (
              <div key={idx} className="rounded-2xl bg-[#fffdfa] p-6 border-2 border-[#d8c5aa] shadow-md space-y-3">
                <div className="w-10 h-10 rounded-xl bg-[#8a2517]/10 border border-[#8a2517]/25 flex items-center justify-center text-[#8a2517]">
                  <Icon className="w-5 h-5" />
                </div>
                <div className="space-y-1">
                  <h3 className="font-display font-bold text-base text-[#241c16]">{pillar.title}</h3>
                  <p className="text-[11px] font-semibold text-[#8a2517]">{pillar.subtitle}</p>
                  <p className="text-xs text-[#695646] leading-relaxed pt-1">{pillar.desc}</p>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Royal Suites & Chambers Showcase */}
      <section className="rounded-3xl bg-[#fffdfa] border-2 border-[#d8c5aa] p-8 shadow-xl space-y-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 border-b border-[#ebdcc8] pb-6">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-widest text-[#8a2517]">Accommodations</span>
            <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#241c16]">
              Royal Chambers &amp; Suites
            </h2>
            <p className="font-serif italic text-sm text-[#755943]">
              Every suite is an individually curated gallery of Rajput antique heirlooms
            </p>
          </div>

          <div className="flex gap-2">
            {ROOM_SHOWCASES.map(room => (
              <button
                key={room.id}
                onClick={() => setSelectedRoom(room)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  selectedRoom.id === room.id
                    ? 'bg-[#8a2517] text-white shadow'
                    : 'bg-[#f4ece1] text-[#695646] hover:text-[#241c16]'
                }`}
              >
                {room.tag}
              </button>
            ))}
          </div>
        </div>

        {/* Active Room Showcase Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7 rounded-2xl overflow-hidden border border-[#d8c5aa] shadow-lg relative h-80 sm:h-96">
            <img
              src={selectedRoom.image}
              alt={selectedRoom.title}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 px-3 py-1 rounded-full bg-[#8a2517] text-white text-xs font-bold shadow">
              {selectedRoom.tag}
            </div>
            <div className="absolute bottom-4 right-4 px-3 py-1.5 rounded-xl bg-white/95 backdrop-blur text-[#8a2517] text-xs font-bold shadow border border-[#d8c5aa]">
              {selectedRoom.rate}
            </div>
          </div>

          <div className="lg:col-span-5 space-y-4">
            <h3 className="font-display font-bold text-2xl text-[#241c16]">
              {selectedRoom.title}
            </h3>

            <p className="text-xs sm:text-sm text-[#4a3b30] leading-relaxed">
              {selectedRoom.description}
            </p>

            <div className="space-y-2 pt-2">
              <p className="text-xs font-bold uppercase tracking-wider text-[#8a2517]">Suite Amenities &amp; Details:</p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {selectedRoom.features.map((feat, i) => (
                  <div key={i} className="flex items-center gap-2 text-xs text-[#524134]">
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#24613b] shrink-0" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="pt-4 border-t border-[#ebdcc8] flex items-center gap-3">
              <button
                onClick={() => onNavigateTab('checkin')}
                className="px-5 py-2.5 rounded-xl bg-[#8a2517] text-white text-xs font-bold shadow hover:bg-[#a32e1d] transition-all flex items-center gap-1.5"
              >
                <BedDouble className="w-4 h-4" /> Check-in to this Suite
              </button>
              <button
                onClick={() => onNavigateTab('chat')}
                className="px-4 py-2.5 rounded-xl bg-[#fffdfa] border border-[#d8c5aa] text-[#4a3b30] text-xs font-semibold hover:border-[#8a2517] transition-all"
              >
                Inquire via Concierge
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Heritage Experiences & Guest Services */}
      <section className="space-y-6">
        <div className="text-center space-y-1">
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#241c16]">
            Curated Rajputana Experiences
          </h2>
          <p className="font-serif italic text-sm text-[#755943]">
            Unforgettable moments steeped in desert tradition and imperial grandeur
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="rounded-2xl bg-[#fffdfa] p-6 border border-[#d8c5aa] shadow space-y-3">
            <div className="text-2xl">🪕</div>
            <h4 className="font-display font-bold text-base text-[#241c16]">Evening Folk Music by the Bonfire</h4>
            <p className="text-xs text-[#695646] leading-relaxed">
              Listen to hereditary Manganiyar folk balladeers narrating legends of Rajput valor under starlit skies in the central chowk.
            </p>
          </div>

          <div className="rounded-2xl bg-[#fffdfa] p-6 border border-[#d8c5aa] shadow space-y-3">
            <div className="text-2xl">🍲</div>
            <h4 className="font-display font-bold text-base text-[#241c16]">Royal Mewari Culinary Feast</h4>
            <p className="text-xs text-[#695646] leading-relaxed">
              Multi-course Rajput thali prepared using heirloom family recipes, organic kitchen-garden vegetables, and stone-ground desert spices.
            </p>
          </div>

          <div className="rounded-2xl bg-[#fffdfa] p-6 border border-[#d8c5aa] shadow space-y-3">
            <div className="text-2xl">🏛️</div>
            <h4 className="font-display font-bold text-base text-[#241c16]">Guided Haveli Heritage Walk</h4>
            <p className="text-xs text-[#695646] leading-relaxed">
              Explore secret stepwells, ancient artisan fresco workshops, and spice bazars guided by our palace historian.
            </p>
          </div>
        </div>
      </section>

      {/* Location, Contact & Check-in Callout */}
      <section className="rounded-3xl bg-[#f4ece1] border-2 border-[#d8c5aa] p-8 shadow-md">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-8 space-y-3">
            <div className="flex items-center gap-2 text-[#8a2517]">
              <MapPin className="w-5 h-5" />
              <span className="text-xs font-bold uppercase tracking-wider">Estate Location &amp; Connectivity</span>
            </div>
            <h3 className="font-display font-bold text-xl sm:text-2xl text-[#241c16]">
              Heritique Haveli, Heritage Chowk, Shekhawati, Rajasthan 333001
            </h3>
            <p className="text-xs text-[#695646] leading-relaxed">
              Nestled 35 minutes from the airport and 15 minutes from the heritage railway junction. Chauffeur transfers in vintage or luxury vehicles available on prior notice through our Concierge.
            </p>
            <div className="flex flex-wrap gap-4 pt-1 text-xs text-[#524134]">
              <span className="flex items-center gap-1 font-semibold">
                <Phone className="w-3.5 h-3.5 text-[#8a2517]" /> +91 141 289 1924
              </span>
              <span className="flex items-center gap-1 font-semibold">
                <Mail className="w-3.5 h-3.5 text-[#8a2517]" /> concierge@heritique.com
              </span>
            </div>
          </div>

          <div className="lg:col-span-4 flex flex-col gap-2.5">
            <button
              onClick={() => onNavigateTab('checkin')}
              className="w-full py-3.5 px-4 rounded-xl bg-[#8a2517] text-white font-bold text-xs shadow-lg hover:bg-[#a32e1d] transition-all flex items-center justify-center gap-2"
            >
              <ShieldCheck className="w-4 h-4" /> Begin Digital Guest Check-in
            </button>
            <button
              onClick={() => onNavigateTab('home')}
              className="w-full py-2.5 px-4 rounded-xl bg-[#fffdfa] border border-[#d8c5aa] text-[#4a3b30] font-bold text-xs hover:border-[#8a2517] transition-all"
            >
              Back to Home
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
