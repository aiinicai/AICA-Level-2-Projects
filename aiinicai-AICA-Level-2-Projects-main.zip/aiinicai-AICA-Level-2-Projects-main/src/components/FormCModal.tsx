import React from 'react';
import { X, Printer, ShieldCheck, Download } from 'lucide-react';
import { GuestRegistration } from '../types';

interface FormCModalProps {
  guest: GuestRegistration | null;
  isOpen: boolean;
  onClose: () => void;
}

export const FormCModal: React.FC<FormCModalProps> = ({ guest, isOpen, onClose }) => {
  if (!isOpen || !guest) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-2xl border border-amber-500/30 bg-white text-slate-900 shadow-2xl p-6 md:p-8 my-8 form-c-print">
        {/* Actions bar (hidden in print) */}
        <div className="no-print flex justify-between items-center pb-4 border-b border-gray-200 mb-6">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded bg-amber-100 text-amber-900 font-bold text-xs uppercase tracking-wider">
              Statutory Form C Record
            </span>
            <span className="text-xs text-gray-500 font-mono">Reg ID: {guest.id}</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-900 text-white rounded-lg text-xs font-semibold hover:bg-slate-800 transition-colors flex items-center gap-1.5 shadow"
            >
              <Printer className="w-4 h-4" /> Print / Save Form C PDF
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Form C Body */}
        <div className="space-y-6 text-xs text-slate-800">
          {/* Header */}
          <div className="text-center border-b-2 border-slate-900 pb-4">
            <h2 className="text-lg font-bold uppercase tracking-widest text-slate-900">
              GOVERNMENT OF INDIA • FORM 'C'
            </h2>
            <p className="text-[11px] font-semibold text-slate-700">
              (See Rule 14 of the Registration of Foreigners Rules, 1992 / BoI Guidelines)
            </p>
            <p className="text-[10px] text-slate-600 uppercase mt-1">
              Hotel / Guest House Arrival Report for Foreign Guests
            </p>
          </div>

          {/* Hotel Information */}
          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded border border-slate-300">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-semibold">1. Name &amp; Address of Hotel / Homestay:</p>
              <p className="font-bold text-slate-900 text-xs">HERITIQUE HOMESTAY (Heritage Haveli)</p>
              <p className="text-[11px] text-slate-700">Jaipur Heritage Enclave, Rajasthan 302001, India</p>
            </div>
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-semibold">Homestay Govt Registration No.:</p>
              <p className="font-mono font-bold text-slate-900 text-xs">RAJ-TOURISM-HST-1924-B</p>
              <p className="text-[10px] text-slate-600">Contact: +91 141 289 9000 • frontdesk@heritique.in</p>
            </div>
          </div>

          {/* Demographic Data Grid */}
          <div className="border border-slate-300 rounded overflow-hidden">
            <table className="w-full border-collapse">
              <tbody>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold w-1/3">2. Full Name of Foreign Guest:</td>
                  <td className="p-2 font-bold text-slate-900 uppercase">
                    {guest.surname}, {guest.givenName}
                  </td>
                  <td rowSpan={4} className="p-2 border-l border-slate-300 text-center w-28 bg-slate-50 align-middle">
                    {guest.guestPhoto ? (
                      <img src={guest.guestPhoto} alt="Guest" className="w-24 h-28 object-cover mx-auto rounded border border-slate-400" />
                    ) : (
                      <div className="w-24 h-28 border border-dashed border-slate-400 rounded flex items-center justify-center text-[10px] text-slate-400">
                        Photo
                      </div>
                    )}
                    <span className="text-[9px] text-slate-500 block mt-1">Facial Image</span>
                  </td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">3. Sex / Gender:</td>
                  <td className="p-2">{guest.gender}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">4. Date of Birth (YYYY-MM-DD):</td>
                  <td className="p-2 font-mono">{guest.dob}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">5. Nationality:</td>
                  <td className="p-2 font-bold">{guest.nationality}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">6. Permanent Home Address:</td>
                  <td colSpan={2} className="p-2">{guest.homeAddress}, {guest.homeCountry}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">7. Passport Particulars:</td>
                  <td colSpan={2} className="p-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                      <div><span className="text-slate-500 block text-[9px]">Passport No:</span> <strong>{guest.passportNumber}</strong></div>
                      <div><span className="text-slate-500 block text-[9px]">Place of Issue:</span> {guest.passportIssuePlace || 'N/A'}</div>
                      <div><span className="text-slate-500 block text-[9px]">Date of Issue:</span> {guest.passportIssueDate || 'N/A'}</div>
                      <div><span className="text-slate-500 block text-[9px]">Expiry Date:</span> <strong>{guest.passportExpiryDate}</strong></div>
                    </div>
                  </td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">8. Visa Particulars:</td>
                  <td colSpan={2} className="p-2">
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
                      <div><span className="text-slate-500 block text-[9px]">Visa No:</span> <strong>{guest.visaNumber || 'N/A'}</strong></div>
                      <div><span className="text-slate-500 block text-[9px]">Visa Type:</span> {guest.visaType || 'Tourist'}</div>
                      <div><span className="text-slate-500 block text-[9px]">Valid Until:</span> {guest.visaExpiryDate || 'N/A'}</div>
                      <div><span className="text-slate-500 block text-[9px]">Issuing Office:</span> {guest.visaIssuePlace || 'N/A'}</div>
                    </div>
                  </td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">9. Date of Arrival in India:</td>
                  <td colSpan={2} className="p-2">{guest.arrivalDateInCountry} (Port: {guest.portOfArrival || 'New Delhi DEL'})</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">10. Arrived From:</td>
                  <td colSpan={2} className="p-2">{guest.arrivedFromCity}, {guest.arrivedFromCountry}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">11. Check-in Date &amp; Suite:</td>
                  <td colSpan={2} className="p-2 font-bold">{guest.checkInDate} • {guest.roomNumber}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">12. Next Intended Destination:</td>
                  <td colSpan={2} className="p-2">{guest.nextDestination || 'Undisclosed'}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">13. Purpose of Visit:</td>
                  <td colSpan={2} className="p-2">{guest.purposeOfVisit}</td>
                </tr>
                <tr className="border-b border-slate-200">
                  <td className="p-2 bg-slate-100 font-semibold">14. Contact in India / Phone:</td>
                  <td colSpan={2} className="p-2">{guest.phone} • Email: {guest.email}</td>
                </tr>
                <tr>
                  <td className="p-2 bg-slate-100 font-semibold">15. Emergency Contact:</td>
                  <td colSpan={2} className="p-2">{guest.emergencyContact || 'N/A'}</td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Signatures & Declarations */}
          <div className="pt-4 grid grid-cols-2 gap-6 border-t-2 border-slate-900">
            <div>
              <p className="text-[10px] text-slate-500 uppercase font-semibold mb-1">
                Guest Digital Signature &amp; Date:
              </p>
              {guest.signature ? (
                <img src={guest.signature} alt="Guest Signature" className="h-16 object-contain bg-slate-50 p-1 border border-slate-300 rounded" />
              ) : (
                <div className="h-16 border-b border-dashed border-slate-400 flex items-end">
                  <span className="text-[10px] text-slate-400 italic">Signature digitally captured on check-in</span>
                </div>
              )}
              <p className="text-[10px] text-slate-600 mt-1">Date: {guest.checkInDate}</p>
            </div>

            <div className="text-right">
              <p className="text-[10px] text-slate-500 uppercase font-semibold mb-1">
                For Heritique Homestay:
              </p>
              <div className="h-16 flex flex-col justify-end items-end">
                <span className="font-serif italic font-semibold text-slate-900 text-sm">Thakur M. Singh</span>
                <span className="text-[10px] text-slate-600">Authorized Signatory / Estate Manager</span>
              </div>
              <p className="text-[10px] text-slate-600 mt-1">Status: Registered &amp; Verified with FRRO portal</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
