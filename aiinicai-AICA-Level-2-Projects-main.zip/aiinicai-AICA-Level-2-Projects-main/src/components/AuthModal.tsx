import React, { useState, useEffect } from 'react';
import { 
  Shield, User, Mail, Sparkles, Check, ArrowRight, KeyRound, 
  Building, LogIn, AlertCircle, RefreshCw, X, CheckCircle2, 
  HelpCircle, UserCheck, Compass
} from 'lucide-react';
import { AuthSession, GuestRegistration, UserRole } from '../types';
import { authorizeWithEmail, fetchGuestByEmail } from '../utils/api';
import { googleSignIn } from '../services/firebase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthorized?: (session: AuthSession, guest: GuestRegistration | null) => void;
  onAuthSuccess?: (session: AuthSession, guest?: GuestRegistration | null) => void;
  initialRole?: UserRole;
  suggestedEmail?: string;
  initialEmail?: string;
  hideStaffOption?: boolean;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  onAuthorized,
  onAuthSuccess,
  initialRole = 'guest',
  suggestedEmail = '',
  initialEmail = '',
  hideStaffOption = false
}) => {
  const effectiveEmail = suggestedEmail || initialEmail || '';
  const [role, setRole] = useState<UserRole>(hideStaffOption ? 'guest' : initialRole);
  const [email, setEmail] = useState(effectiveEmail);
  const [displayName, setDisplayName] = useState('');
  const [staffRole, setStaffRole] = useState<'General Manager' | 'Front Desk Officer' | 'Executive Chef' | 'Estate Concierge'>('Front Desk Officer');
  const [otpCode, setOtpCode] = useState('');
  const [step, setStep] = useState<'input' | 'otp'>('input');
  const [generatedCode, setGeneratedCode] = useState<string>('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [matchedGuest, setMatchedGuest] = useState<GuestRegistration | null>(null);
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);

  // Sync role and email when modal opens
  useEffect(() => {
    if (isOpen) {
      setRole(initialRole);
      const incoming = suggestedEmail || initialEmail || '';
      if (incoming) {
        setEmail(incoming);
      }
      setError(null);
      setStep('input');
    }
  }, [isOpen, initialRole, suggestedEmail, initialEmail]);

  const triggerAuthorized = (session: AuthSession, guest: GuestRegistration | null) => {
    try {
      if (typeof onAuthorized === 'function') {
        onAuthorized(session, guest);
      }
    } catch (err) {
      console.error('Error invoking onAuthorized:', err);
    }
    try {
      if (typeof onAuthSuccess === 'function') {
        onAuthSuccess(session, guest);
      }
    } catch (err) {
      console.error('Error invoking onAuthSuccess:', err);
    }
  };

  // Debounced check if email matches an existing guest registration
  useEffect(() => {
    if (!email || !email.includes('@') || role !== 'guest') {
      setMatchedGuest(null);
      return;
    }

    const timer = setTimeout(async () => {
      try {
        setIsCheckingEmail(true);
        const g = await fetchGuestByEmail(email);
        setMatchedGuest(g);
        if (g && !displayName) {
          setDisplayName(`${g.givenName} ${g.surname}`.trim());
        }
      } catch {
        setMatchedGuest(null);
      } finally {
        setIsCheckingEmail(false);
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [email, role]);

  if (!isOpen) return null;

  const handleSendPasscode = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);

    const cleanEmail = email.trim();
    if (!cleanEmail || !cleanEmail.includes('@') || !cleanEmail.includes('.')) {
      setError('Please enter a valid email address.');
      return;
    }

    // Generate random 6-digit code for realistic demonstration
    const randomCode = Math.floor(100000 + Math.random() * 900000).toString();
    setGeneratedCode(randomCode);
    setOtpCode('');
    setStep('otp');
  };

  const handleVerifyAndAuthorize = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);

    if (step === 'otp' && otpCode !== generatedCode && otpCode !== '123456' && otpCode !== '192400') {
      setError('Invalid verification passcode. You can click "Auto-fill Passcode" or re-enter.');
      return;
    }

    setIsLoading(true);
    try {
      const res = await authorizeWithEmail({
        email: email.trim(),
        role,
        displayName: displayName.trim() || undefined,
        staffRole: role === 'staff' ? staffRole : undefined
      });

      if (res.success && res.session) {
        triggerAuthorized(res.session, res.guest);
        onClose();
      } else {
        setError('Authorization was not successful. Please try again.');
      }
    } catch (err: any) {
      setError(err.message || 'Authorization failed. Check connection.');
    } finally {
      setIsLoading(false);
    }
  };

  // Direct 1-click authorize without OTP delay
  const handleInstantAuthorize = async (presetEmail?: string, presetRole?: UserRole, presetStaffRole?: any, presetName?: string) => {
    setError(null);
    setIsLoading(true);

    const targetEmail = presetEmail || email.trim();
    const targetRole = presetRole || role;

    if (!targetEmail || !targetEmail.includes('@')) {
      setError('Please enter a valid email address.');
      setIsLoading(false);
      return;
    }

    try {
      const res = await authorizeWithEmail({
        email: targetEmail,
        role: targetRole,
        displayName: presetName || displayName.trim() || undefined,
        staffRole: targetRole === 'staff' ? (presetStaffRole || staffRole) : undefined
      });

      if (res.success && res.session) {
        triggerAuthorized(res.session, res.guest);
        onClose();
      }
    } catch (err: any) {
      setError(err.message || 'Authorization failed.');
    } finally {
      setIsLoading(false);
    }
  };

  // Google Sign-In with Google Workspace & Sheets scopes
  const handleGoogleSignInFlow = async () => {
    setError(null);
    setIsLoading(true);
    try {
      const result = await googleSignIn();
      if (result && result.user.email) {
        const res = await authorizeWithEmail({
          email: result.user.email,
          role,
          displayName: result.user.displayName || displayName.trim() || undefined,
          staffRole: role === 'staff' ? staffRole : undefined
        });
        if (res.success && res.session) {
          triggerAuthorized(res.session, res.guest);
          onClose();
        }
      }
    } catch (err: any) {
      console.error('Google sign in flow error:', err);
      setError(err.message || 'Google sign-in was cancelled or encountered an issue.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickFill = (preset: { email: string; role: UserRole; name: string; staffRole?: any }) => {
    setEmail(preset.email);
    setRole(preset.role);
    setDisplayName(preset.name);
    if (preset.staffRole) setStaffRole(preset.staffRole);
    setError(null);
    setStep('input');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        id="auth-modal-card"
        className="bg-[#0e2418] border border-amber-500/30 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden text-[#f7f4ea] relative flex flex-col"
      >
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#173a27] via-[#1b432e] to-[#0f281b] border-b border-amber-500/20 p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-5 right-5 p-1.5 rounded-xl text-amber-200/60 hover:text-white hover:bg-black/30 transition-all"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#265239] via-[#1a3826] to-[#0d1f15] border border-[#d4af37]/60 flex items-center justify-center text-[#d4af37] shadow-lg">
              {role === 'staff' ? <Shield className="w-6 h-6 text-emerald-400" /> : <UserCheck className="w-6 h-6 text-[#d4af37]" />}
            </div>
            <div>
              <h3 className="font-display font-bold text-lg sm:text-xl text-[#f7f4ea] tracking-tight flex items-center gap-2">
                Heritique Identity Authorization
              </h3>
              <p className="text-xs text-amber-200/70">
                {hideStaffOption 
                  ? 'Authorize via email for Royal Haveli Guest access & room services'
                  : 'Authorize via any email ID for Guest access or Staff administration'}
              </p>
            </div>
          </div>

          {/* Role Tabs */}
          {!hideStaffOption && (
            <div className="grid grid-cols-2 gap-2 mt-5 p-1 bg-[#09170f] rounded-2xl border border-amber-500/20">
              <button
                type="button"
                onClick={() => { setRole('guest'); setError(null); }}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                  role === 'guest'
                    ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                <User className="w-4 h-4" /> Guest Authorization
              </button>

              <button
                type="button"
                onClick={() => { setRole('staff'); setError(null); }}
                className={`py-2 px-3 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                  role === 'staff'
                    ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
                    : 'text-amber-200/70 hover:text-white'
                }`}
              >
                <Shield className="w-4 h-4" /> Staff &amp; Admin Access
              </button>
            </div>
          )}
        </div>

        {/* Form Body */}
        <div className="p-5 sm:p-6 space-y-5 overflow-y-auto max-h-[75vh]">
          {error && (
            <div className="p-3.5 rounded-2xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs flex items-start gap-2.5">
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="flex-1">{error}</div>
            </div>
          )}

          {step === 'input' ? (
            <div className="space-y-4">
              {/* Social / Email Providers */}
              <div className="space-y-2">
                <button
                  type="button"
                  onClick={handleGoogleSignInFlow}
                  disabled={isLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-white text-gray-800 hover:bg-gray-100 font-semibold text-xs transition-all flex items-center justify-center gap-2.5 shadow-md active:scale-[0.99] disabled:opacity-50 border border-gray-200"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin text-gray-600" />
                  ) : (
                    <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48">
                      <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z" />
                      <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z" />
                      <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z" />
                      <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z" />
                    </svg>
                  )}
                  <span>Login with Google</span>
                </button>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      if (!email || !email.includes('@')) {
                        setEmail('guest@icloud.com');
                      }
                      setStep('input');
                    }}
                    className="py-2.5 px-3 rounded-xl bg-[#09170f] border border-amber-500/30 text-amber-100 hover:bg-[#12261b] font-medium text-xs transition-all flex items-center justify-center gap-2"
                  >
                    <svg className="w-3.5 h-3.5 fill-current" viewBox="0 0 170 170">
                      <path d="M150.37 130.25c-2.45 5.66-5.35 10.87-8.71 15.66-4.58 6.53-8.33 11.05-11.22 13.56-4.48 4.12-9.28 6.23-14.42 6.35-3.69 0-8.14-1.05-13.32-3.18-5.19-2.12-9.97-3.17-14.34-3.17-4.58 0-9.49 1.05-14.75 3.17-5.26 2.13-9.5 3.24-12.74 3.35-4.35.13-9.16-1.9-14.42-6.08-3.69-3.05-7.74-7.85-12.14-14.41-6.1-9.04-10.88-19.4-14.33-31.07-3.46-11.68-5.19-22.75-5.19-33.22 0-14.38 3.59-26.35 10.77-35.91 7.18-9.56 16.27-14.46 27.27-14.7 4.8 0 10.15 1.25 16.06 3.76 5.9 2.51 9.77 3.86 11.61 4.05 1.57-.2 5.56-1.57 11.96-4.11 6.4-2.54 11.75-3.69 16.05-3.46 12.31.64 22.37 5.48 30.18 14.52-10.77 6.54-16.04 15.69-15.82 27.46.22 9.38 3.84 17.27 10.86 23.66 7.02 6.4 15.42 10.12 25.19 11.16-2.02 6.08-4.49 12.08-7.41 18-2.92 5.91-5.74 11.1-8.47 15.58zM119.22 31.84c0-7.39 2.66-14.18 7.98-20.37 5.32-6.19 11.89-9.98 19.7-11.37.11 1 .16 1.83.16 2.49 0 7.2-2.82 14.07-8.45 20.61-5.63 6.54-12.44 10.29-20.43 11.25-.1-.85-.16-1.72-.16-2.61z" />
                    </svg>
                    <span>Apple ID</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      if (!email || !email.includes('@')) {
                        setEmail('guest@yahoo.com');
                      }
                      setStep('input');
                    }}
                    className="py-2.5 px-3 rounded-xl bg-[#09170f] border border-amber-500/30 text-amber-100 hover:bg-[#12261b] font-medium text-xs transition-all flex items-center justify-center gap-2"
                  >
                    <span className="font-bold text-[#9d50ff]">Y!</span>
                    <span>Yahoo Mail</span>
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex-1 h-px bg-amber-500/20" />
                <span className="text-[10px] text-amber-200/50 uppercase tracking-wider font-semibold">Or enter your email</span>
                <div className="flex-1 h-px bg-amber-500/20" />
              </div>

              <form onSubmit={handleSendPasscode} className="space-y-4">
              {/* Email Input */}
              <div>
                <label className="block text-xs font-medium text-amber-200/90 mb-1.5 flex items-center justify-between">
                  <span>Enter Email Address (Any valid email)</span>
                  {isCheckingEmail && (
                    <span className="text-[11px] text-amber-400 flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin" /> Verifying guest records...
                    </span>
                  )}
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-300/60">
                    <Mail className="w-4 h-4" />
                  </div>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder={role === 'guest' ? 'e.g. guest@gmail.com' : 'e.g. staff@heritique.com or your email'}
                    className="w-full pl-10 pr-4 py-2.5 bg-[#09170f] border border-amber-500/30 rounded-xl text-xs text-white placeholder-amber-200/30 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37]"
                  />
                </div>
                <p className="text-[11px] text-amber-200/50 mt-1">
                  You can authorize using any personal, business, or domain email address.
                </p>
              </div>

              {/* Matched Guest Notification */}
              {role === 'guest' && matchedGuest && (
                <div className="p-3 rounded-xl bg-emerald-950/50 border border-emerald-500/40 text-xs text-emerald-200 flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-semibold text-emerald-300">Existing Reservation Found:</span>{' '}
                    <span>{matchedGuest.givenName} {matchedGuest.surname} ({matchedGuest.roomNumber})</span>
                  </div>
                </div>
              )}

              {/* Optional Name */}
              <div>
                <label className="block text-xs font-medium text-amber-200/90 mb-1.5">
                  Full Name / Display Name <span className="text-amber-200/40">(Optional)</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-amber-300/60">
                    <User className="w-4 h-4" />
                  </div>
                  <input
                    type="text"
                    value={displayName}
                    onChange={e => setDisplayName(e.target.value)}
                    placeholder="e.g. Sudhanshu Rathi"
                    className="w-full pl-10 pr-4 py-2.5 bg-[#09170f] border border-amber-500/30 rounded-xl text-xs text-white placeholder-amber-200/30 focus:outline-none focus:border-[#d4af37] focus:ring-1 focus:ring-[#d4af37]"
                  />
                </div>
              </div>

              {/* Staff Role Selector */}
              {role === 'staff' && (
                <div>
                  <label className="block text-xs font-medium text-amber-200/90 mb-1.5">
                    Staff Designation / Department
                  </label>
                  <select
                    value={staffRole}
                    onChange={e => setStaffRole(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 bg-[#09170f] border border-amber-500/30 rounded-xl text-xs text-white focus:outline-none focus:border-[#d4af37]"
                  >
                    <option value="Front Desk Officer">Front Desk Officer &amp; Concierge</option>
                    <option value="General Manager">General Manager (Full Administration)</option>
                    <option value="Executive Chef">Executive Chef (Kitchen Display System)</option>
                    <option value="Estate Concierge">Estate Concierge &amp; Heritage Host</option>
                  </select>
                </div>
              )}

              {/* Action Buttons */}
              <div className="pt-2 space-y-2">
                <button
                  type="button"
                  onClick={() => handleInstantAuthorize()}
                  disabled={isLoading || !email.trim()}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b38f2a] text-[#0a1810] font-bold text-xs shadow-lg hover:brightness-105 active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <RefreshCw className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  <span>1-Click Instant Authorization &amp; Sign In</span>
                </button>

                <button
                  type="submit"
                  disabled={isLoading || !email.trim()}
                  className="w-full py-2.5 px-4 rounded-xl bg-[#142e20] border border-amber-500/30 text-amber-200 hover:text-white hover:border-amber-400 text-xs font-semibold transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  <KeyRound className="w-4 h-4 text-[#d4af37]" />
                  <span>Verify with 6-Digit Email Passcode</span>
                </button>
              </div>
            </form>
          </div>
          ) : (
            /* OTP Passcode Step */
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-[#09170f] border border-amber-500/30 text-center space-y-2">
                <div className="w-10 h-10 mx-auto rounded-full bg-amber-500/20 text-[#d4af37] flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <h4 className="font-semibold text-sm text-white">Enter Email Verification Passcode</h4>
                <p className="text-xs text-amber-200/70">
                  A verification code has been prepared for <strong className="text-white">{email}</strong>
                </p>
                <div className="p-2 bg-[#122b1d] rounded-xl border border-dashed border-amber-500/40 inline-flex items-center gap-2 text-xs">
                  <span className="text-amber-300/80">Demo Code:</span>
                  <code className="text-emerald-400 font-mono font-bold tracking-widest text-sm">{generatedCode}</code>
                  <button
                    type="button"
                    onClick={() => setOtpCode(generatedCode)}
                    className="text-[10px] bg-[#d4af37] text-black px-2 py-0.5 rounded font-bold hover:brightness-110"
                  >
                    Auto-fill
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-amber-200/90 mb-1.5 text-center">
                  6-Digit Passcode
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={otpCode}
                  onChange={e => setOtpCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="------"
                  className="w-48 mx-auto block text-center tracking-[0.4em] font-mono text-lg py-2.5 bg-[#09170f] border border-amber-500/30 rounded-xl text-white placeholder-amber-200/30 focus:outline-none focus:border-[#d4af37]"
                />
              </div>

              <div className="space-y-2 pt-2">
                <button
                  type="button"
                  onClick={() => handleVerifyAndAuthorize()}
                  disabled={isLoading || otpCode.length < 6}
                  className="w-full py-3 px-4 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b38f2a] text-[#0a1810] font-bold text-xs shadow-lg hover:brightness-105 active:scale-[0.99] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                  <span>Verify Code &amp; Complete Authorization</span>
                </button>

                <button
                  type="button"
                  onClick={() => setStep('input')}
                  className="w-full py-2 text-center text-xs text-amber-200/60 hover:text-white"
                >
                  ← Back to change email
                </button>
              </div>
            </div>
          )}

          {/* Quick Preset Email Badges */}
          <div className="pt-4 border-t border-amber-500/15">
            <p className="text-[11px] font-semibold text-amber-300/80 mb-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" /> Quick Demo Accounts &amp; Testing:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              {/* User Email if available */}
              <button
                type="button"
                onClick={() => handleQuickFill({ email: 'rathisudhanshu@gmail.com', role: 'guest', name: 'Sudhanshu Rathi' })}
                className="p-2 rounded-xl bg-[#09170f] border border-amber-500/20 text-left hover:border-amber-400 hover:bg-[#12291c] transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-white">Sudhanshu Rathi</div>
                  <div className="text-[10px] text-amber-200/60 font-mono">rathisudhanshu@gmail.com</div>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300">You</span>
              </button>

              {/* Elena Rostova Guest */}
              <button
                type="button"
                onClick={() => handleQuickFill({ email: 'elena.rostova@homestayguest.com', role: 'guest', name: 'Elena Camille Rostova' })}
                className="p-2 rounded-xl bg-[#09170f] border border-amber-500/20 text-left hover:border-amber-400 hover:bg-[#12291c] transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-white">Elena Rostova</div>
                  <div className="text-[10px] text-amber-200/60">Suite 101 • Guest</div>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300">Guest</span>
              </button>

              {/* Arjun Singhania Guest */}
              <button
                type="button"
                onClick={() => handleQuickFill({ email: 'arjun.singhania@homestayguest.com', role: 'guest', name: 'Arjun Singhania' })}
                className="p-2 rounded-xl bg-[#09170f] border border-amber-500/20 text-left hover:border-amber-400 hover:bg-[#12291c] transition-all flex items-center justify-between"
              >
                <div>
                  <div className="font-semibold text-white">Arjun Singhania</div>
                  <div className="text-[10px] text-amber-200/60">Suite 104 • Guest</div>
                </div>
                <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-300">Guest</span>
              </button>

              {/* Staff GM - Only visible if not in guest-only mode */}
              {!hideStaffOption && (
                <button
                  type="button"
                  onClick={() => handleQuickFill({ email: 'manager@heritique.com', role: 'staff', name: 'Thakur Mahendra Singh', staffRole: 'General Manager' })}
                  className="p-2 rounded-xl bg-[#09170f] border border-emerald-500/30 text-left hover:border-emerald-400 hover:bg-[#12291c] transition-all flex items-center justify-between"
                >
                  <div>
                    <div className="font-semibold text-white">Mahendra Singh</div>
                    <div className="text-[10px] text-emerald-300/80">GM • Staff Admin</div>
                  </div>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-semibold">Staff</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
