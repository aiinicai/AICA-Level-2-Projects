import React, { useState, useEffect } from 'react';
import { Camera, CheckCircle2, ShieldCheck, User, Globe, FileText, Calendar, Building, Sparkles, MapPin, Phone, Mail, ArrowRight, Eye, UserCheck, FileCheck, Check, ExternalLink } from 'lucide-react';
import confetti from 'canvas-confetti';
import { GuestRegistration, PassportOCRResult, AuthSession, UserRole } from '../types';
import { checkinGuest } from '../utils/api';
import { PassportOcrSection } from './PassportOcrSection';
import { CameraCaptureModal } from './CameraCaptureModal';
import { SignaturePad } from './SignaturePad';
import { HomestayRulesModal } from './HomestayRulesModal';
import { normalizeDateToIso } from '../utils/imageUtils';
import { syncGuestToFirestore } from '../services/firestoreSync';
import { appendGuestToSheet, uploadBase64ToDrive, getOrCreateDriveFolder, getOrCreateMasterSpreadsheet } from '../services/sheetsService';
import { getAccessToken } from '../services/firebase';

interface GuestCheckinFormProps {
  onCheckinSuccess: (guest: GuestRegistration) => void;
  onNavigateTab: (tab: 'dining' | 'billing' | 'chat' | 'admin') => void;
  authSession?: AuthSession | null;
  onOpenAuthModal?: (role?: UserRole, suggestedEmail?: string) => void;
}

const AVAILABLE_ROOMS = [
  {
    number: 'Suite 101 - The Royal Haveli',
    type: 'Heritage Grand Suite (Jharokha Balcony)',
    rate: 7500,
    desc: 'King four-poster bed, antique brass accents, courtyard fountain view',
    image: 'https://images.unsplash.com/photo-1590490360182-c33d57733427?auto=format&fit=crop&w=600&q=80'
  },
  {
    number: 'Suite 102 - Gulab Mahal',
    type: 'Royal Garden Suite (Rose Courtyard)',
    rate: 6200,
    desc: 'Teak wood carvings, private verandah overlooking flowering bougainvillea',
    image: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=600&q=80'
  },
  {
    number: 'Suite 103 - Aravali Verandah',
    type: 'Heritage View Room (Hillside Terrace)',
    rate: 5800,
    desc: 'Hand-painted fresco motifs, heritage bay window with panoramic sunrise views',
    image: 'https://images.unsplash.com/photo-1591088398332-8a7791972843?auto=format&fit=crop&w=600&q=80'
  },
  {
    number: 'Suite 104 - Sheesh Mahal Pavilion',
    type: 'Palace Suite with Private Plunge Tub',
    rate: 8900,
    desc: 'Intricate Rajasthani mirror work, copper soaking tub, butler service',
    image: 'https://images.unsplash.com/photo-1578683010236-d716f9a3f461?auto=format&fit=crop&w=600&q=80'
  }
];

export const GuestCheckinForm: React.FC<GuestCheckinFormProps> = ({ 
  onCheckinSuccess, 
  onNavigateTab,
  authSession,
  onOpenAuthModal 
}) => {
  const [guestType, setGuestType] = useState<'foreign' | 'domestic'>('foreign');
  const [selectedRoom, setSelectedRoom] = useState(AVAILABLE_ROOMS[0]);
  const [isPhotoModalOpen, setIsPhotoModalOpen] = useState(false);
  const [isRulesModalOpen, setIsRulesModalOpen] = useState(false);
  const [agreedToHomestayRules, setAgreedToHomestayRules] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadStatusMsg, setUploadStatusMsg] = useState<string | null>(null);
  const [submittedGuest, setSubmittedGuest] = useState<GuestRegistration | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    givenName: authSession?.role === 'guest' && authSession.displayName ? authSession.displayName.split(' ')[0] : '',
    surname: authSession?.role === 'guest' && authSession.displayName && authSession.displayName.split(' ').length > 1 ? authSession.displayName.split(' ').slice(1).join(' ') : '',
    gender: 'Female' as 'Male' | 'Female' | 'Other',
    dob: '1992-06-14',
    nationality: 'French (France)',
    passportNumber: '',
    passportIssueDate: '2021-04-10',
    passportExpiryDate: '2031-04-09',
    passportIssuePlace: 'Paris',
    // Domestic Indian Law fields
    idType: 'Aadhaar Card' as 'Aadhaar Card' | 'Voter ID' | 'Driving License' | 'Indian Passport',
    idNumber: '',
    fatherOrSpouseName: '',
    city: 'Jaipur',
    state: 'Rajasthan',
    pincode: '302003',
    visaNumber: 'IND9082341-T',
    visaType: 'e-Tourist Visa',
    visaIssueDate: '2026-08-01',
    visaExpiryDate: '2027-07-31',
    visaIssuePlace: 'BoI Delhi Portal',
    arrivedFromCity: 'Paris',
    arrivedFromCountry: 'France',
    arrivalDateInCountry: new Date(Date.now() - 2 * 86400000).toISOString().split('T')[0],
    portOfArrival: 'Indira Gandhi International Airport, New Delhi',
    nextDestination: 'Udaipur Heritage Palace',
    purposeOfVisit: 'Cultural Heritage Study & Leisure Tourism',
    employedInIndia: false,
    homeAddress: '24 Rue des Rosiers, 4th Arrondissement',
    homeCountry: 'France',
    phone: '+33 6 45 92 11 08',
    email: authSession?.email || 'elena.rostova@homestayguest.com',
    emergencyContact: 'Pierre Rostova (+33 6 12 34 56 78)',
    checkInDate: new Date().toISOString().split('T')[0],
    checkOutDate: new Date(Date.now() + 4 * 86400000).toISOString().split('T')[0],
    specialRequests: 'Quiet courtyard room, preference for authentic home-cooked vegetarian meals.'
  });

  // Switch defaults when switching guestType
  useEffect(() => {
    if (guestType === 'domestic') {
      setFormData(prev => ({
        ...prev,
        nationality: 'Indian',
        homeCountry: 'India',
        arrivedFromCity: prev.arrivedFromCity === 'Paris' ? 'New Delhi' : prev.arrivedFromCity,
        arrivedFromCountry: 'India',
        homeAddress: prev.homeAddress === '24 Rue des Rosiers, 4th Arrondissement' ? 'B-14, Vaishali Nagar' : prev.homeAddress,
        phone: prev.phone.startsWith('+33') ? '+91 98290 12345' : prev.phone
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        nationality: prev.nationality === 'Indian' ? 'French (France)' : prev.nationality,
        homeCountry: prev.homeCountry === 'India' ? 'France' : prev.homeCountry
      }));
    }
  }, [guestType]);

  // Update email if authSession changes
  useEffect(() => {
    if (authSession?.email) {
      setFormData(prev => ({
        ...prev,
        email: authSession.email,
        givenName: prev.givenName || (authSession.displayName ? authSession.displayName.split(' ')[0] : prev.givenName),
        surname: prev.surname || (authSession.displayName && authSession.displayName.split(' ').length > 1 ? authSession.displayName.split(' ').slice(1).join(' ') : prev.surname)
      }));
    }
  }, [authSession]);

  const [guestPhoto, setGuestPhoto] = useState<string | null>(null);
  const [passportDocument, setPassportDocument] = useState<string | null>(null);
  const [signature, setSignature] = useState<string | null>(null);
  const [agreedToCompliance, setAgreedToCompliance] = useState(true);
  const [ocrAutoFilled, setOcrAutoFilled] = useState(false);

  // Handle OCR auto-fill
  const handleOcrData = (data: PassportOCRResult, imageB64: string) => {
    setPassportDocument(imageB64);
    
    // Normalize date strings into YYYY-MM-DD for standard HTML5 date inputs
    const normalizedDob = normalizeDateToIso(data.dob);
    const normalizedIssueDate = normalizeDateToIso(data.passportIssueDate);
    const normalizedExpiryDate = normalizeDateToIso(data.passportExpiryDate);

    let genderVal: 'Female' | 'Male' | 'Other' = 'Female';
    if (data.gender) {
      const g = data.gender.toString().trim().toLowerCase();
      if (g.startsWith('m')) genderVal = 'Male';
      else if (g.startsWith('f')) genderVal = 'Female';
      else genderVal = 'Other';
    }

    setFormData(prev => ({
      ...prev,
      givenName: (data.givenName || '').trim() || prev.givenName || '',
      surname: (data.surname || '').trim() || prev.surname || '',
      gender: genderVal,
      dob: normalizedDob || prev.dob || '',
      nationality: (data.nationality || '').trim() || prev.nationality || '',
      passportNumber: data.passportNumber ? data.passportNumber.replace(/[^A-Za-z0-9]/g, '').toUpperCase() : (prev.passportNumber || ''),
      passportIssueDate: normalizedIssueDate || prev.passportIssueDate || '',
      passportExpiryDate: normalizedExpiryDate || prev.passportExpiryDate || '',
      passportIssuePlace: (data.passportIssuePlace || '').trim() || prev.passportIssuePlace || ''
    }));

    setGuestType('foreign');
    setOcrAutoFilled(true);

    // Smoothly scroll down to Guest Details so on mobile screen user sees the populated fields
    setTimeout(() => {
      const el = document.getElementById('form-c-guest-details');
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }, 300);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const checked = (e.target as HTMLInputElement).checked;
      setFormData(prev => ({ ...prev, [name]: checked }));
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (guestType === 'domestic') {
      if (!formData.givenName || !formData.idNumber) {
        alert('Please provide the Guest Full Name and Government ID Number (Aadhaar / Voter ID / DL) as mandated by Indian Law.');
        return;
      }
    } else {
      if (!formData.givenName || !formData.passportNumber) {
        alert('Please provide at least the Guest Name and Passport Number (mandatory for Government Form C registration).');
        return;
      }
    }
    if (!signature) {
      alert('Please provide the guest digital signature at the bottom of the registration.');
      return;
    }
    if (!agreedToHomestayRules) {
      alert('Please check and agree to the Heritique Haveli Homestay Rules and Terms & Conditions to complete check-in.');
      return;
    }

    setIsSubmitting(true);
    setUploadStatusMsg('Processing registration & document compliance...');

    let driveDocLink: string | undefined = undefined;
    let drivePicLink: string | undefined = undefined;
    let driveSigLink: string | undefined = undefined;

    // Requirement 6: When documents like passport, photo and signature of guest are captured at check in,
    // save them in Google Drive and put the link of such documents in Google Sheet columns
    try {
      const gToken = await getAccessToken().catch(() => null);
      if (gToken) {
        setUploadStatusMsg('Saving guest documents to Google Drive folder...');
        const folderId = await getOrCreateDriveFolder(gToken).catch(() => undefined);
        const guestSlug = `${formData.givenName}_${formData.surname || ''}`.replace(/[^A-Za-z0-9]/g, '_');
        const timestamp = Date.now();

        if (passportDocument) {
          try {
            const up = await uploadBase64ToDrive(gToken, `${guestSlug}_ID_Doc_${timestamp}.jpg`, passportDocument, folderId);
            driveDocLink = up.webViewLink;
          } catch (e) {
            console.warn('Google Drive document upload warning:', e);
          }
        }

        if (guestPhoto) {
          try {
            const up = await uploadBase64ToDrive(gToken, `${guestSlug}_Photo_${timestamp}.jpg`, guestPhoto, folderId);
            drivePicLink = up.webViewLink;
          } catch (e) {
            console.warn('Google Drive photo upload warning:', e);
          }
        }

        if (signature) {
          try {
            const up = await uploadBase64ToDrive(gToken, `${guestSlug}_Signature_${timestamp}.png`, signature, folderId);
            driveSigLink = up.webViewLink;
          } catch (e) {
            console.warn('Google Drive signature upload warning:', e);
          }
        }
      }
    } catch (driveErr) {
      console.warn('Drive document pipeline notice:', driveErr);
    }

    try {
      const payload: Partial<GuestRegistration> = {
        ...formData,
        guestType,
        passportNumber: guestType === 'domestic' ? formData.idNumber : formData.passportNumber,
        nationality: guestType === 'domestic' ? 'Indian' : formData.nationality,
        roomNumber: selectedRoom.number,
        roomType: selectedRoom.type,
        roomRate: selectedRoom.rate,
        guestPhoto: guestPhoto || undefined,
        passportDocument: passportDocument || undefined,
        signature: signature || undefined,
        driveDocumentLink: driveDocLink,
        drivePhotoLink: drivePicLink,
        driveSignatureLink: driveSigLink
      };

      const result = await checkinGuest(payload);
      if (result.success && result.guest) {
        setSubmittedGuest(result.guest);
        onCheckinSuccess(result.guest);

        // Multi-layer Database persistence: Sync to Cloud Firestore
        syncGuestToFirestore(result.guest).catch(e => console.warn('Firestore guest sync:', e));

        // Requirement 7: Everyday check in saved in same or single common google sheet
        getAccessToken().then(async tok => {
          if (tok) {
            try {
              const master = await getOrCreateMasterSpreadsheet(tok);
              await appendGuestToSheet(tok, master.spreadsheetId, result.guest!);
            } catch (e) {
              console.warn('Master Google Sheets auto-sync notice:', e);
            }
          }
        });

        // Celebratory Confetti
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#d4af37', '#2e6b48', '#e5c05d', '#ffffff']
        });
      }
    } catch (err: any) {
      alert(`Error submitting check-in: ${err.message}`);
    } finally {
      setIsSubmitting(false);
      setUploadStatusMsg(null);
    }
  };

  // Success view
  if (submittedGuest) {
    return (
      <div id="checkin-success-view" className="max-w-2xl mx-auto py-8 px-4 space-y-6 animate-in zoom-in-95 duration-300">
        <div className="rounded-2xl border-2 border-[#d4af37] bg-gradient-to-b from-[#142b1f] to-[#0a1810] p-6 text-center space-y-4 shadow-2xl">
          <div className="w-16 h-16 rounded-full bg-[#d4af37]/20 border border-[#d4af37] text-[#d4af37] mx-auto flex items-center justify-center">
            <CheckCircle2 className="w-9 h-9" />
          </div>
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-widest text-[#d4af37] bg-black/40 px-3 py-1 rounded-full border border-amber-500/30">
              Check-in Confirmed &amp; Form C Logged
            </span>
            <h2 className="font-display font-bold text-2xl text-[#f7f4ea] mt-2">
              Padharo Mhare Des!
            </h2>
            <p className="text-sm text-amber-200/80">
              Welcome to Heritique Homestay, <strong>{submittedGuest.givenName} {submittedGuest.surname}</strong>
            </p>
          </div>

          {/* Pass Card */}
          <div className="rounded-xl bg-[#09150e] border border-amber-500/20 p-5 text-left space-y-3">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-2">
              <div>
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider">Suite Assigned</span>
                <p className="font-display font-semibold text-base text-[#d4af37]">{submittedGuest.roomNumber}</p>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider">Registration ID</span>
                <p className="font-mono text-xs text-amber-100 font-bold">{submittedGuest.id}</p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <span className="text-amber-200/60 text-[10px] block">Check-in Date</span>
                <span className="text-amber-100 font-medium">{submittedGuest.checkInDate}</span>
              </div>
              <div>
                <span className="text-amber-200/60 text-[10px] block">Check-out Date</span>
                <span className="text-amber-100 font-medium">{submittedGuest.checkOutDate}</span>
              </div>
              <div>
                <span className="text-amber-200/60 text-[10px] block">Govt Form C Status</span>
                <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                  <ShieldCheck className="w-3.5 h-3.5" /> Verified
                </span>
              </div>
            </div>
          </div>

          {/* Quick Action Navigation */}
          <div className="pt-2 flex flex-col sm:flex-row gap-3 justify-center">
            <button
              onClick={() => onNavigateTab('dining')}
              className="py-3 px-5 rounded-xl bg-[#d4af37] text-[#0d1f15] font-semibold text-xs hover:bg-[#e2be4b] transition-all flex items-center justify-center gap-2 shadow-lg"
            >
              Order Welcome Tea &amp; Dining <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigateTab('chat')}
              className="py-3 px-5 rounded-xl bg-[#1a3826] text-amber-200 border border-amber-500/30 font-medium text-xs hover:bg-[#234b33] transition-all flex items-center justify-center gap-2"
            >
              Message Front Desk Concierge
            </button>
            <button
              onClick={() => {
                setSubmittedGuest(null);
                setFormData(prev => ({ ...prev, givenName: '', surname: '', passportNumber: '' }));
                setPassportDocument(null);
                setGuestPhoto(null);
                setSignature(null);
              }}
              className="py-3 px-4 rounded-xl bg-black/40 text-amber-300/80 border border-amber-500/20 text-xs hover:text-amber-200 transition-all"
            >
              Check-in Another Guest
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div id="guest-checkin-container" className="max-w-4xl mx-auto space-y-6">
      {/* Intro Header */}
      <div className="text-center space-y-2 mb-2">
        <span className="text-xs font-semibold uppercase tracking-widest text-[#8a2517] bg-[#f4ece1] px-3 py-1 rounded-full border border-[#d8c5aa]">
          Official Government Compliance &amp; Express Haveli Arrival
        </span>
        <h2 className="font-display font-bold text-3xl text-[#241c16]">
          Heritique Guest Registration
        </h2>
        <p className="text-xs sm:text-sm text-[#695646] max-w-xl mx-auto">
          Scan passport for automated Form C demographics or complete details below with live camera photo verification.
        </p>
      </div>

      {/* Email Authorization Banner */}
      <div className="rounded-2xl border border-[#d8c5aa] bg-[#f4ece1] p-4 flex flex-col sm:flex-row items-center justify-between gap-3 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#ebdcc8] border border-[#d8c5aa] flex items-center justify-center text-[#8a2517]">
            <Mail className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-[#241c16]">
                {authSession ? `Authorized Account: ${authSession.displayName || authSession.email}` : 'Universal Email Authorization'}
              </span>
              <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                authSession 
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-300' 
                  : 'bg-amber-100 text-amber-800 border border-amber-300'
              }`}>
                {authSession ? (authSession.role === 'staff' ? 'Staff Verified' : 'Guest Verified') : 'Any Email Supported'}
              </span>
            </div>
            <p className="text-[11px] text-[#695646]">
              {authSession 
                ? `Active Email: ${authSession.email} • Stay & billing folios sync automatically` 
                : 'Enter or authorize via any email address for instant registration retrieval & folio sync'}
            </p>
          </div>
        </div>

        {onOpenAuthModal && (
          <button
            type="button"
            onClick={() => onOpenAuthModal('guest', formData.email)}
            className="px-3.5 py-1.5 rounded-xl bg-[#8a2517] text-white hover:bg-[#a32e1d] text-xs font-medium transition-all shadow-sm flex items-center gap-1.5 whitespace-nowrap"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#f5d998]" />
            <span>{authSession ? 'Switch Email' : 'Authorize via Email'}</span>
          </button>
        )}
      </div>

      {/* Guest Type Toggle */}
      <div className="flex justify-center">
        <div className="inline-flex rounded-xl p-1 bg-[#f4ece1] border border-[#d8c5aa] shadow-inner">
          <button
            type="button"
            onClick={() => setGuestType('foreign')}
            className={`px-5 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              guestType === 'foreign'
                ? 'bg-[#8a2517] text-white shadow-sm'
                : 'text-[#695646] hover:text-[#241c16]'
            }`}
          >
            <Globe className="w-3.5 h-3.5" /> Foreign National (Govt Form C Mandatory)
          </button>
          <button
            type="button"
            onClick={() => setGuestType('domestic')}
            className={`px-5 py-2 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              guestType === 'domestic'
                ? 'bg-[#8a2517] text-white shadow-sm'
                : 'text-[#695646] hover:text-[#241c16]'
            }`}
          >
            <User className="w-3.5 h-3.5" /> Domestic Traveler (Govt Photo ID)
          </button>
        </div>
      </div>

      {/* Passport OCR AI Scanner */}
      <PassportOcrSection
        onExtracted={handleOcrData}
        currentDocument={passportDocument || undefined}
      />

      {/* Main Registration Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Step 1: Room Selection */}
        <div className="rounded-2xl border border-amber-500/30 bg-[#12261b]/90 p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 border-b border-amber-500/20 pb-3">
            <Building className="w-5 h-5 text-[#d4af37]" />
            <h3 className="font-display font-semibold text-lg text-amber-100">1. Select Haveli Suite &amp; Stay Dates</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {AVAILABLE_ROOMS.map(room => {
              const isSelected = selectedRoom.number === room.number;
              return (
                <div
                  key={room.number}
                  onClick={() => setSelectedRoom(room)}
                  className={`cursor-pointer rounded-xl border p-3 flex gap-3 transition-all relative overflow-hidden ${
                    isSelected
                      ? 'border-[#d4af37] bg-[#1a3826] ring-1 ring-[#d4af37]'
                      : 'border-amber-500/20 bg-[#0a1810] hover:border-amber-500/40'
                  }`}
                >
                  <img src={room.image} alt={room.number} className="w-20 h-20 rounded-lg object-cover shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-display font-semibold text-sm text-[#f7f4ea] truncate">{room.number}</p>
                    <p className="text-[11px] text-amber-200/60 line-clamp-1">{room.desc}</p>
                    <div className="mt-2 flex items-baseline gap-1">
                      <span className="font-display font-bold text-sm text-[#d4af37]">₹{room.rate.toLocaleString('en-IN')}</span>
                      <span className="text-[10px] text-amber-200/50">/ night</span>
                    </div>
                  </div>
                  {isSelected && (
                    <div className="absolute top-2 right-2 bg-[#d4af37] text-[#0d1f15] rounded-full p-0.5">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          {/* Dates */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
            <div>
              <label className="block text-xs font-medium text-amber-200/80 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#d4af37]" /> Check-in Date
              </label>
              <input
                type="date"
                name="checkInDate"
                value={formData.checkInDate}
                onChange={handleInputChange}
                required
                className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-amber-200/80 mb-1 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#d4af37]" /> Check-out Date
              </label>
              <input
                type="date"
                name="checkOutDate"
                value={formData.checkOutDate}
                onChange={handleInputChange}
                required
                className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Step 2: Personal & Identity Demographics */}
        <div id="form-c-guest-details" className="rounded-2xl border border-amber-500/30 bg-[#12261b]/90 p-5 shadow-xl space-y-4 transition-all">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-3 flex-wrap gap-2">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-[#d4af37]" />
              <h3 className="font-display font-semibold text-lg text-amber-100">
                {guestType === 'domestic' 
                  ? '2. Domestic Traveler Registration (Statutory Indian Sarais Act 1867 & Police Verification)'
                  : '2. Guest Personal & Identity Details (Statutory Govt Form C / BoI)'}
              </h3>
            </div>
            {ocrAutoFilled && (
              <span className="text-[11px] font-semibold text-emerald-300 bg-emerald-950/70 border border-emerald-500/40 px-2.5 py-1 rounded-full flex items-center gap-1.5 animate-pulse">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                OCR Auto-Populated
              </span>
            )}
          </div>

          {ocrAutoFilled && (
            <div className="rounded-xl border border-emerald-500/40 bg-emerald-950/40 p-3 text-xs text-emerald-200 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong>Document scanned:</strong> Identity details have been extracted and pre-filled. Please verify or update if necessary.
                </span>
              </div>
            </div>
          )}

          {/* DOMESTIC INDIAN TRAVELLER FORM (As per Indian Law & Sarais Act 1867) */}
          {guestType === 'domestic' ? (
            <div className="space-y-4">
              <div className="p-3 rounded-xl bg-[#173826]/70 border border-emerald-500/30 text-xs text-emerald-200 flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong>Indian Hospitality Compliance:</strong> Foreign Form C is not applicable to Indian citizens. As per Rajasthan Sarais Act and Local Police Hotel Regulations, please provide an Officially Valid Document (OVD) and residential address.
                </span>
              </div>

              {/* ID Document Selection & Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Government ID Proof Type (OVD) *</label>
                  <select
                    name="idType"
                    value={formData.idType}
                    onChange={handleInputChange}
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="Aadhaar Card">Aadhaar Card (UIDAI - Masked / Last 4 Digits)</option>
                    <option value="Voter ID">Voter ID Card (Election Commission of India)</option>
                    <option value="Driving License">Indian Driving License (State Transport Authority)</option>
                    <option value="Indian Passport">Indian Passport (Republic of India)</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">{formData.idType} Number *</label>
                  <input
                    type="text"
                    name="idNumber"
                    value={formData.idNumber}
                    onChange={handleInputChange}
                    placeholder={
                      formData.idType === 'Aadhaar Card' ? 'e.g. XXXX-XXXX-4819' :
                      formData.idType === 'Voter ID' ? 'e.g. RJ/14/082/109283' :
                      formData.idType === 'Driving License' ? 'e.g. RJ14 20210089211' : 'e.g. Z9082341'
                    }
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 uppercase focus:border-[#d4af37] focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Personal Details */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">First / Given Name *</label>
                  <input
                    type="text"
                    name="givenName"
                    value={formData.givenName}
                    onChange={handleInputChange}
                    placeholder="e.g. Vikramaditya"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Last / Surname *</label>
                  <input
                    type="text"
                    name="surname"
                    value={formData.surname}
                    onChange={handleInputChange}
                    placeholder="e.g. Rathore"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Father / Spouse / Guardian Name *</label>
                  <input
                    type="text"
                    name="fatherOrSpouseName"
                    value={formData.fatherOrSpouseName}
                    onChange={handleInputChange}
                    placeholder="Mandatory per Sarais Act"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Gender *</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              {/* DOB, Nationality, Purpose of Visit */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Date of Birth *</label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleInputChange}
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Nationality *</label>
                  <input
                    type="text"
                    name="nationality"
                    value="Indian"
                    readOnly
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810]/70 px-3.5 py-2.5 text-amber-200 font-semibold cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Purpose of Visit *</label>
                  <select
                    name="purposeOfVisit"
                    value={formData.purposeOfVisit}
                    onChange={handleInputChange}
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="Heritage Tourism & Leisure">Heritage Tourism &amp; Leisure</option>
                    <option value="Business, Gemstones & Trade">Business, Gemstones &amp; Trade (Johari Bazar)</option>
                    <option value="Wedding / Family Function">Wedding / Family Function</option>
                    <option value="Religious / Govind Dev Ji Darshan">Pilgrimage / Temple Visit</option>
                    <option value="Transit / Educational">Transit / Cultural Study</option>
                  </select>
                </div>
              </div>

              {/* Permanent Address in India */}
              <div className="pt-3 border-t border-amber-500/20 space-y-3">
                <span className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block">
                  🇮🇳 Permanent Residential Address in India
                </span>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="sm:col-span-2">
                    <label className="block font-medium text-amber-200/80 mb-1">Street / House / Colony Address *</label>
                    <input
                      type="text"
                      name="homeAddress"
                      value={formData.homeAddress}
                      onChange={handleInputChange}
                      placeholder="e.g. B-14, Green Park, Near City Chowk"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">City / District *</label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      placeholder="e.g. Jaipur"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">State / Union Territory *</label>
                    <select
                      name="state"
                      value={formData.state}
                      onChange={handleInputChange}
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="Rajasthan">Rajasthan</option>
                      <option value="Delhi">Delhi (NCR)</option>
                      <option value="Maharashtra">Maharashtra</option>
                      <option value="Gujarat">Gujarat</option>
                      <option value="Uttar Pradesh">Uttar Pradesh</option>
                      <option value="Haryana">Haryana</option>
                      <option value="Punjab">Punjab</option>
                      <option value="Madhya Pradesh">Madhya Pradesh</option>
                      <option value="Karnataka">Karnataka</option>
                      <option value="Tamil Nadu">Tamil Nadu</option>
                      <option value="West Bengal">West Bengal</option>
                      <option value="Telangana">Telangana</option>
                      <option value="Kerala">Kerala</option>
                      <option value="Bihar">Bihar</option>
                      <option value="Uttarakhand">Uttarakhand</option>
                      <option value="Himachal Pradesh">Himachal Pradesh</option>
                      <option value="Goa">Goa</option>
                      <option value="Other">Other State / UT</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">PIN Code (6 Digits) *</label>
                    <input
                      type="text"
                      name="pincode"
                      value={formData.pincode}
                      onChange={handleInputChange}
                      maxLength={6}
                      placeholder="e.g. 302003"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2 text-amber-100 font-mono focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Arrived From (City &amp; State)</label>
                    <input
                      type="text"
                      name="arrivedFromCity"
                      value={formData.arrivedFromCity}
                      onChange={handleInputChange}
                      placeholder="e.g. New Delhi"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Next Destination (City &amp; State)</label>
                    <input
                      type="text"
                      name="nextDestination"
                      value={formData.nextDestination}
                      onChange={handleInputChange}
                      placeholder="e.g. Udaipur, Rajasthan"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-1">
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Mobile / WhatsApp (+91) *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+91 98290 12345"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none font-mono"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="guest@domain.com"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          ) : (
            /* FOREIGN NATIONAL FORM C FIELDS */
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Given / First Names *</label>
                  <input
                    type="text"
                    name="givenName"
                    value={formData.givenName}
                    onChange={handleInputChange}
                    placeholder="e.g. Elena Camille"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Surname / Family Name *</label>
                  <input
                    type="text"
                    name="surname"
                    value={formData.surname}
                    onChange={handleInputChange}
                    placeholder="e.g. Rostova"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Gender *</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="Female">Female</option>
                    <option value="Male">Male</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Date of Birth *</label>
                  <input
                    type="date"
                    name="dob"
                    value={formData.dob}
                    onChange={handleInputChange}
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Nationality / Citizenship *</label>
                  <input
                    type="text"
                    name="nationality"
                    value={formData.nationality}
                    onChange={handleInputChange}
                    placeholder="e.g. French / France"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Passport Number *</label>
                  <input
                    type="text"
                    name="passportNumber"
                    value={formData.passportNumber}
                    onChange={handleInputChange}
                    placeholder="e.g. 21FB84920"
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 uppercase focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Passport Issue Date</label>
                  <input
                    type="date"
                    name="passportIssueDate"
                    value={formData.passportIssueDate}
                    onChange={handleInputChange}
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Passport Expiry Date *</label>
                  <input
                    type="date"
                    name="passportExpiryDate"
                    value={formData.passportExpiryDate}
                    onChange={handleInputChange}
                    required
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block font-medium text-amber-200/80 mb-1">Passport Place of Issue</label>
                  <input
                    type="text"
                    name="passportIssuePlace"
                    value={formData.passportIssuePlace}
                    onChange={handleInputChange}
                    placeholder="e.g. Paris / Prefecture"
                    className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>
              </div>

              {/* Visa Section for Foreign Guests */}
              <div className="pt-4 border-t border-amber-500/20">
                <span className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-3">
                  🛂 Foreigner Visa Details (Mandatory for Government FRRO Compliance)
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Visa Number *</label>
                    <input
                      type="text"
                      name="visaNumber"
                      value={formData.visaNumber}
                      onChange={handleInputChange}
                      placeholder="e.g. IND9082341-T"
                      required={guestType === 'foreign'}
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 uppercase focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Visa Type</label>
                    <input
                      type="text"
                      name="visaType"
                      value={formData.visaType}
                      onChange={handleInputChange}
                      placeholder="e.g. e-Tourist Visa"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Visa Valid Till</label>
                    <input
                      type="date"
                      name="visaExpiryDate"
                      value={formData.visaExpiryDate}
                      onChange={handleInputChange}
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Visa Place of Issue</label>
                    <input
                      type="text"
                      name="visaIssuePlace"
                      value={formData.visaIssuePlace}
                      onChange={handleInputChange}
                      placeholder="e.g. BoI Portal / Paris Embassy"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Travel Route & Port of Arrival */}
              <div className="pt-4 border-t border-amber-500/20">
                <span className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-3">
                  ✈️ Port of Arrival &amp; Travel Route
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Arrived From (City &amp; Country)</label>
                    <input
                      type="text"
                      name="arrivedFromCity"
                      value={formData.arrivedFromCity}
                      onChange={handleInputChange}
                      placeholder="e.g. Paris, France"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Port of Arrival in India</label>
                    <input
                      type="text"
                      name="portOfArrival"
                      value={formData.portOfArrival}
                      onChange={handleInputChange}
                      placeholder="e.g. Delhi IGI Airport (DEL)"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Next Intended Destination</label>
                    <input
                      type="text"
                      name="nextDestination"
                      value={formData.nextDestination}
                      onChange={handleInputChange}
                      placeholder="e.g. Udaipur / Agra"
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              {/* Permanent Address & Contact */}
              <div className="pt-4 border-t border-amber-500/20">
                <span className="text-[11px] font-semibold text-[#d4af37] uppercase tracking-wider block mb-3">
                  🏠 Permanent Home Address &amp; Contact
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs">
                  <div className="sm:col-span-2">
                    <label className="block font-medium text-amber-200/80 mb-1">Permanent Home Address *</label>
                    <input
                      type="text"
                      name="homeAddress"
                      value={formData.homeAddress}
                      onChange={handleInputChange}
                      placeholder="Street, City, State, Postal Code"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Phone / WhatsApp *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      placeholder="+33 6 45 92 11 08"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block font-medium text-amber-200/80 mb-1">Email Address *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      placeholder="guest@domain.com"
                      required
                      className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Step 3: Photo, Documents & Signature */}
        <div className="rounded-2xl border border-amber-500/30 bg-[#12261b]/90 p-5 shadow-xl space-y-5">
          <div className="flex items-center gap-2 border-b border-amber-500/20 pb-3">
            <Camera className="w-5 h-5 text-[#d4af37]" />
            <h3 className="font-display font-semibold text-lg text-amber-100">
              3. Guest Facial Photo Verification, Document Capture &amp; Digital Signature
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Live Camera Guest Photo */}
            <div className="space-y-3">
              <label className="block text-xs font-medium text-amber-200/80">
                Live Guest Facial Photograph * (Saved to Google Drive &amp; Police Record)
              </label>
              {guestPhoto ? (
                <div className="relative rounded-xl border border-amber-500/30 bg-black/40 p-2 text-center">
                  <img src={guestPhoto} alt="Guest" className="w-32 h-32 rounded-xl object-cover mx-auto border border-[#d4af37]" />
                  <button
                    type="button"
                    onClick={() => setIsPhotoModalOpen(true)}
                    className="mt-2 text-xs text-amber-300 underline hover:text-amber-200"
                  >
                    Retake Guest Photo
                  </button>
                </div>
              ) : (
                <div
                  onClick={() => setIsPhotoModalOpen(true)}
                  className="rounded-xl border-2 border-dashed border-amber-500/30 bg-[#0c1a12] p-6 text-center cursor-pointer hover:border-[#d4af37] transition-all group"
                >
                  <div className="w-12 h-12 rounded-full bg-amber-500/20 text-[#d4af37] flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition-transform">
                    <Camera className="w-6 h-6" />
                  </div>
                  <p className="text-xs font-semibold text-amber-100">Click Live Photo from Camera</p>
                  <p className="text-[10px] text-amber-200/50 mt-1">Tap to open webcam portrait viewfinder</p>
                </div>
              )}
            </div>

            {/* Signature Pad */}
            <div className="space-y-2">
              <SignaturePad onSignatureChange={setSignature} initialSignature={signature || undefined} />
            </div>
          </div>

          {/* Statutory Compliance Checkbox */}
          <div className="pt-3 border-t border-amber-500/20 space-y-3">
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <input
                type="checkbox"
                checked={agreedToCompliance}
                onChange={(e) => setAgreedToCompliance(e.target.checked)}
                className="mt-1 rounded border-amber-500/40 text-[#d4af37] focus:ring-0 w-4 h-4 accent-[#d4af37]"
              />
              <span className="text-xs text-amber-200/80 leading-relaxed">
                <strong>Statutory Declaration:</strong> I hereby declare that all information furnished is authentic, true, and complete pursuant to {guestType === 'domestic' ? 'the Sarais Act 1867 & Local Hotel Regulations' : 'Rule 14 of the Foreigners Registration Act & Form C rules'}. I consent to secure archiving of documents in Heritique Homestay operations ledger.
              </span>
            </label>

            {/* Requirement 5: Homestay Rules & Terms Checkbox */}
            <div className="p-3.5 rounded-2xl bg-[#0a1810] border border-amber-500/40">
              <label className="flex items-start gap-3 cursor-pointer select-none">
                <input
                  type="checkbox"
                  required
                  checked={agreedToHomestayRules}
                  onChange={(e) => setAgreedToHomestayRules(e.target.checked)}
                  className="mt-1 rounded border-amber-500/40 text-[#d4af37] focus:ring-0 w-4.5 h-4.5 accent-[#d4af37]"
                />
                <div className="text-xs text-amber-200/90 leading-relaxed">
                  <div className="flex items-center gap-1.5 font-bold text-amber-100 mb-0.5">
                    <Check className="w-3.5 h-3.5 text-[#d4af37]" />
                    <span>I agree to and sign the Heritique Haveli Homestay Rules &amp; Terms:</span>
                  </div>
                  <span>
                    I confirm adherence to the 1924 heritage structure conservation rules, non-smoking policy inside heritage suites, peaceful quiet hours (10:00 PM – 7:00 AM), and homestay guest check-in terms.
                  </span>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.preventDefault();
                      setIsRulesModalOpen(true);
                    }}
                    className="ml-2 inline-flex items-center gap-1 text-[#d4af37] font-bold underline hover:text-white"
                  >
                    <span>[View Homestay Rules &amp; Terms]</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                </div>
              </label>
            </div>
          </div>
        </div>

        {uploadStatusMsg && (
          <div className="p-3 rounded-xl bg-amber-950/80 border border-amber-500/40 text-amber-200 text-xs flex items-center justify-center gap-2 animate-pulse">
            <Sparkles className="w-4 h-4 text-[#d4af37]" />
            <span>{uploadStatusMsg}</span>
          </div>
        )}

        {/* Submit Button */}
        <div className="text-center pt-2">
          <button
            type="submit"
            disabled={isSubmitting || !agreedToCompliance || !agreedToHomestayRules}
            className="w-full sm:w-auto min-w-[280px] py-3.5 px-8 rounded-xl font-display font-semibold text-base bg-gradient-to-r from-[#d4af37] via-[#e6c454] to-[#d4af37] text-[#0d1f15] hover:opacity-95 active:scale-[0.99] transition-all shadow-xl shadow-amber-950/40 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <span className="flex items-center justify-center gap-2">
                <Sparkles className="w-5 h-5 animate-spin" /> Transmitting Registration &amp; Drive Sync...
              </span>
            ) : (
              <span className="flex items-center justify-center gap-2">
                {guestType === 'domestic' ? 'Complete Domestic Check-in' : 'Complete Form C & Foreigner Check-in'} <ArrowRight className="w-5 h-5" />
              </span>
            )}
          </button>
          {!agreedToHomestayRules && (
            <p className="text-[11px] text-amber-300/70 mt-2">
              * Please accept the Homestay Rules &amp; Terms checkbox above to proceed with check-in.
            </p>
          )}
        </div>
      </form>

      {/* Homestay Rules & Terms Modal */}
      <HomestayRulesModal
        isOpen={isRulesModalOpen}
        onClose={() => setIsRulesModalOpen(false)}
        onAccept={() => {
          setAgreedToHomestayRules(true);
          setIsRulesModalOpen(false);
        }}
      />

      {/* Camera Capture Modal for Guest Photo */}
      <CameraCaptureModal
        isOpen={isPhotoModalOpen}
        onClose={() => setIsPhotoModalOpen(false)}
        onCapture={(img) => setGuestPhoto(img)}
        title="Capture Live Guest Verification Photo"
        guideMode="selfie"
      />
    </div>
  );
};
