import React, { useState, useEffect } from 'react';
import { Utensils, ShoppingBag, Plus, Minus, Check, Clock, Sparkles, ChefHat, AlertCircle, ArrowRight, Lock, Star } from 'lucide-react';
import { MenuItem, FoodOrder, GuestRegistration, OrderItem, AuthSession, UserRole } from '../types';
import { fetchMenu, fetchOrders, placeFoodOrder } from '../utils/api';
import { FeedbackModal } from './FeedbackModal';

interface DiningMenuSectionProps {
  currentGuest: GuestRegistration | null;
  onNavigateTab: (tab: 'billing' | 'chat') => void;
  authSession?: AuthSession | null;
  onOpenAuthModal?: (role?: UserRole, suggestedEmail?: string) => void;
}

export const DiningMenuSection: React.FC<DiningMenuSectionProps> = ({ 
  currentGuest, 
  onNavigateTab,
  authSession,
  onOpenAuthModal 
}) => {
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [orders, setOrders] = useState<FoodOrder[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [onlyVeg, setOnlyVeg] = useState(false);
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [specialInstructions, setSpecialInstructions] = useState('');
  const [isSubmittingOrder, setIsSubmittingOrder] = useState(false);
  const [orderSuccessMsg, setOrderSuccessMsg] = useState<string | null>(null);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [selectedFeedbackOrder, setSelectedFeedbackOrder] = useState<FoodOrder | null>(null);

  const loadData = async () => {
    try {
      const [menu, allOrders] = await Promise.all([fetchMenu(), fetchOrders()]);
      setMenuItems(menu);
      if (currentGuest) {
        setOrders(allOrders.filter(o => o.guestId === currentGuest.id));
      } else {
        setOrders(allOrders);
      }
    } catch (err) {
      console.error('Failed loading dining data:', err);
    }
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 8000); // Polling for order status updates
    return () => clearInterval(interval);
  }, [currentGuest]);

  const categories = ['All', 'Royal Breakfast', 'Heritage Thali', 'Courtyard Delicacies', 'Afternoon Chai & Snacks', 'Desserts & Beverages'];

  const filteredItems = menuItems.filter(item => {
    const matchesCat = selectedCategory === 'All' || item.category === selectedCategory;
    const matchesVeg = !onlyVeg || item.isVeg;
    return matchesCat && matchesVeg;
  });

  const addToCart = (item: MenuItem) => {
    setCart(prev => {
      const existing = prev.find(i => i.menuItemId === item.id);
      if (existing) {
        return prev.map(i => i.menuItemId === item.id ? { ...i, quantity: i.quantity + 1 } : i);
      }
      return [...prev, { menuItemId: item.id, name: item.name, price: item.price, quantity: 1 }];
    });
  };

  const updateQuantity = (menuItemId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(i => i.menuItemId === menuItemId ? { ...i, quantity: i.quantity + delta } : i)
        .filter(i => i.quantity > 0);
    });
  };

  const cartSubtotal = cart.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);
  const cartTaxes = Math.round(cartSubtotal * 0.05); // 5% GST
  const cartTotal = cartSubtotal + cartTaxes;

  const handlePlaceOrder = async () => {
    if (!cart.length) return;

    // Strict requirement: Guest or Staff must be logged in via email
    if (!authSession) {
      if (onOpenAuthModal) onOpenAuthModal('guest');
      return;
    }

    setIsSubmittingOrder(true);
    setOrderSuccessMsg(null);

    try {
      const targetGuestId = authSession.guestId || currentGuest?.id || `GUEST-${authSession.email.split('@')[0]}`;
      const targetGuestName = authSession.displayName || (currentGuest ? `${currentGuest.givenName} ${currentGuest.surname}` : authSession.email);
      const targetRoom = authSession.roomNumber || currentGuest?.roomNumber || 'Suite 101 - The Royal Haveli';

      const res = await placeFoodOrder({
        guestId: targetGuestId,
        guestName: targetGuestName,
        roomNumber: targetRoom,
        items: cart,
        specialInstructions
      });

      if (res.success) {
        setCart([]);
        setSpecialInstructions('');
        setOrderSuccessMsg(`Order #${res.order.id} confirmed for ${targetRoom}! Freshly sent to the Haveli kitchen.`);
        loadData();
      }
    } catch (err: any) {
      alert(`Could not place order: ${err.message}`);
    } finally {
      setIsSubmittingOrder(false);
    }
  };

  return (
    <div id="dining-menu-section" className="space-y-8">
      {/* Header Banner */}
      <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-r from-[#173826] via-[#12281c] to-[#0d1f15] p-6 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <span className="text-xs font-semibold uppercase tracking-widest text-[#d4af37] bg-black/40 px-3 py-1 rounded-full border border-amber-500/20">
            Estate In-Room Dining &amp; Courtyard Kitchen
          </span>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#f7f4ea]">
            Authentic Royal Heritage Culinary
          </h2>
          <p className="text-xs sm:text-sm text-amber-200/70 max-w-xl">
            Prepared with organic grains, farm-fresh spices, and centuries-old slow-cooked Rajputana and Mughal recipes.
          </p>
        </div>
        <div className="bg-black/40 border border-amber-500/30 rounded-xl p-3 text-right shrink-0">
          <span className="text-[10px] text-amber-200/60 uppercase block">Serving Room:</span>
          <span className="font-display font-semibold text-sm text-[#d4af37]">
            {authSession ? (authSession.roomNumber || currentGuest?.roomNumber || 'Assigned Suite') : 'Sign-in Required'}
          </span>
        </div>
      </div>

      {/* Auth Banner if neither guest nor staff is logged in */}
      {!authSession && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500/15 via-[#8a2517]/20 to-amber-500/10 border-2 border-amber-500/40 text-amber-100 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#8a2517] text-white flex items-center justify-center shrink-0 shadow">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white">Email Sign-In Required for Room Dining</h4>
              <p className="text-[11px] text-amber-200/80">
                Please sign in with your email or complete guest check-in before placing in-room dining orders.
              </p>
            </div>
          </div>
          <button
            onClick={() => onOpenAuthModal?.('guest')}
            className="px-4 py-2.5 rounded-xl bg-[#d4af37] text-[#0a1810] font-bold text-xs hover:bg-[#e2be4b] transition-all shrink-0 shadow flex items-center gap-1.5"
          >
            <Lock className="w-3.5 h-3.5" /> Sign In with Email to Order
          </button>
        </div>
      )}

      {/* Active Orders Tracker */}
      {orders.length > 0 && (
        <div className="rounded-2xl border border-amber-500/30 bg-[#0e2117] p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-amber-500/20 pb-2">
            <h3 className="font-display font-semibold text-base text-amber-100 flex items-center gap-2">
              <Clock className="w-4 h-4 text-[#d4af37]" /> Active Kitchen Orders
            </h3>
            <span className="text-xs text-amber-200/60 font-mono">{orders.length} order(s) placed</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {orders.slice(0, 2).map(ord => (
              <div key={ord.id} className="rounded-xl border border-amber-500/20 bg-[#142d20] p-3.5 space-y-2.5">
                <div className="flex justify-between items-start">
                  <div>
                    <span className="font-mono text-xs font-bold text-[#d4af37]">{ord.id}</span>
                    <p className="text-xs text-amber-100 font-medium">
                      {ord.items.map(i => `${i.quantity}x ${i.name}`).join(', ')}
                    </p>
                  </div>
                  <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                    ord.status === 'delivered'
                      ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-300'
                      : ord.status === 'preparing'
                      ? 'bg-amber-950 border border-amber-500/40 text-amber-300 animate-pulse'
                      : 'bg-blue-950 border border-blue-500/40 text-blue-300'
                  }`}>
                    {ord.status.replace('_', ' ')}
                  </span>
                </div>

                {/* Progress bar */}
                <div className="w-full bg-black/40 rounded-full h-1.5 overflow-hidden">
                  <div
                    className="bg-[#d4af37] h-full transition-all duration-500"
                    style={{
                      width: ord.status === 'placed' ? '25%' : ord.status === 'preparing' ? '60%' : ord.status === 'on_the_way' ? '85%' : '100%'
                    }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px] text-amber-200/60 pt-1">
                  <span>Room: {ord.roomNumber} • ₹{ord.total}</span>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedFeedbackOrder(ord);
                      setIsFeedbackOpen(true);
                    }}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-black/40 border border-amber-500/30 text-[#d4af37] hover:text-white hover:bg-black/60 transition-all font-semibold text-[10px]"
                  >
                    <Star className="w-3 h-3 fill-current" />
                    <span>Rate this Meal</span>
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Categories & Filter Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-1.5">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-[#d4af37] text-[#0d1f15] font-semibold shadow-md'
                  : 'bg-[#142d20] text-amber-200/70 border border-amber-500/20 hover:text-amber-100 hover:border-amber-500/40'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-amber-200/80 bg-[#142d20] border border-amber-500/20 px-3 py-1.5 rounded-lg">
          <input
            type="checkbox"
            checked={onlyVeg}
            onChange={e => setOnlyVeg(e.target.checked)}
            className="rounded accent-emerald-500 w-3.5 h-3.5"
          />
          <span className="inline-flex items-center gap-1 font-semibold text-emerald-400">
            🌱 Pure Vegetarian
          </span>
        </label>
      </div>

      {/* Main Grid: Menu + Cart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Menu Items (2 Columns) */}
        <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
          {filteredItems.map(item => {
            const inCart = cart.find(c => c.menuItemId === item.id);
            return (
              <div
                key={item.id}
                className="rounded-2xl border border-amber-500/20 bg-[#12261b] hover:border-amber-500/40 transition-all flex flex-col justify-between overflow-hidden shadow-lg group"
              >
                <div className="relative h-44 overflow-hidden bg-black/40">
                  <img
                    src={item.image}
                    alt={item.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-2 left-2 flex gap-1">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${
                      item.isVeg ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-500/40' : 'bg-red-950/80 text-red-300 border border-red-500/40'
                    }`}>
                      {item.isVeg ? '● VEG' : '▲ NON-VEG'}
                    </span>
                    {item.heritageTag && (
                      <span className="text-[10px] font-medium px-2 py-0.5 rounded-md bg-black/70 text-amber-300 border border-amber-500/30">
                        {item.heritageTag}
                      </span>
                    )}
                  </div>
                  <div className="absolute bottom-2 right-2 bg-black/80 px-2.5 py-1 rounded-lg border border-amber-500/30">
                    <span className="font-display font-bold text-sm text-[#d4af37]">₹{item.price}</span>
                  </div>
                </div>

                <div className="p-4 flex-1 flex flex-col justify-between space-y-3">
                  <div>
                    <h4 className="font-display font-semibold text-base text-[#f7f4ea] leading-snug">{item.name}</h4>
                    <p className="text-xs text-amber-200/60 mt-1 line-clamp-2 leading-relaxed">{item.description}</p>
                  </div>

                  <div className="pt-2 border-t border-amber-500/10 flex items-center justify-between">
                    <span className="text-[11px] text-amber-200/50">{item.category}</span>

                    {inCart ? (
                      <div className="flex items-center gap-2 bg-[#1b3a29] border border-amber-500/30 rounded-lg px-2 py-1">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="text-amber-300 hover:text-white p-0.5"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="text-xs font-bold text-amber-100 min-w-4 text-center">{inCart.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="text-amber-300 hover:text-white p-0.5"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => addToCart(item)}
                        className="py-1.5 px-3.5 rounded-lg bg-[#d4af37] text-[#0d1f15] hover:bg-[#e2bd49] active:scale-95 transition-all text-xs font-semibold flex items-center gap-1 shadow"
                      >
                        <Plus className="w-3.5 h-3.5" /> Add to Order
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Sticky Cart & Order Summary (1 Column) */}
        <div className="lg:col-span-1">
          <div className="sticky top-20 rounded-2xl border border-amber-500/30 bg-[#12261b] p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-amber-500/20 pb-3">
              <h3 className="font-display font-semibold text-lg text-amber-100 flex items-center gap-2">
                <ShoppingBag className="w-5 h-5 text-[#d4af37]" /> Your Room Order
              </h3>
              <span className="text-xs bg-[#d4af37]/20 text-[#d4af37] px-2 py-0.5 rounded-full font-bold">
                {cart.reduce((a, b) => a + b.quantity, 0)} items
              </span>
            </div>

            {cart.length === 0 ? (
              <div className="py-8 text-center text-amber-200/50 space-y-2">
                <ChefHat className="w-8 h-8 mx-auto text-amber-500/40" />
                <p className="text-xs">Your dining cart is empty.</p>
                <p className="text-[10px] text-amber-200/40">Select dishes from the menu to order to your suite.</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                  {cart.map(item => (
                    <div key={item.menuItemId} className="flex items-center justify-between text-xs py-1.5 border-b border-amber-500/10">
                      <div className="flex-1 min-w-0 pr-2">
                        <p className="text-amber-100 font-medium truncate">{item.name}</p>
                        <span className="text-[10px] text-amber-200/60">₹{item.price} each</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateQuantity(item.menuItemId, -1)}
                          className="w-5 h-5 rounded bg-black/40 text-amber-300 flex items-center justify-center hover:bg-black/60"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="text-xs font-bold text-amber-100 min-w-3 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.menuItemId, 1)}
                          className="w-5 h-5 rounded bg-black/40 text-amber-300 flex items-center justify-center hover:bg-black/60"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                        <span className="font-mono font-semibold text-amber-200 min-w-10 text-right">
                          ₹{item.price * item.quantity}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Special Instructions */}
                <div>
                  <label className="block text-[11px] font-medium text-amber-200/80 mb-1">
                    Kitchen Notes / Dietary Preferences
                  </label>
                  <input
                    type="text"
                    value={specialInstructions}
                    onChange={e => setSpecialInstructions(e.target.value)}
                    placeholder="e.g. Mild spice, serve on courtyard table"
                    className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3 py-2 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
                  />
                </div>

                {/* Subtotal breakdown */}
                <div className="space-y-1.5 pt-2 border-t border-amber-500/20 text-xs">
                  <div className="flex justify-between text-amber-200/70">
                    <span>Subtotal</span>
                    <span>₹{cartSubtotal}</span>
                  </div>
                  <div className="flex justify-between text-amber-200/70">
                    <span>Taxes &amp; Service (5% GST)</span>
                    <span>₹{cartTaxes}</span>
                  </div>
                  <div className="flex justify-between font-bold text-sm text-[#d4af37] pt-1 border-t border-amber-500/10">
                    <span>Total Bill</span>
                    <span>₹{cartTotal}</span>
                  </div>
                  <p className="text-[10px] text-amber-200/50 italic">
                    * Charges will be charged automatically to your room billing folio.
                  </p>
                </div>

                {/* Order Button */}
                {authSession ? (
                  <button
                    onClick={handlePlaceOrder}
                    disabled={isSubmittingOrder}
                    className="w-full py-3 rounded-xl font-display font-semibold text-xs bg-[#d4af37] text-[#0d1f15] hover:bg-[#e2bd49] active:scale-[0.99] transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {isSubmittingOrder ? (
                      <span>Sending to Chefs...</span>
                    ) : (
                      <span>Send Order to Room (₹{cartTotal})</span>
                    )}
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => onOpenAuthModal?.('guest')}
                    className="w-full py-3 rounded-xl font-display font-semibold text-xs bg-[#8a2517] text-white hover:bg-[#a32e1d] active:scale-[0.99] transition-all shadow-lg flex items-center justify-center gap-2"
                  >
                    <Lock className="w-4 h-4 text-[#f5d998]" />
                    <span>Sign In with Email to Place Order (₹{cartTotal})</span>
                  </button>
                )}
              </div>
            )}

            {orderSuccessMsg && (
              <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/30 text-emerald-300 text-xs flex items-start gap-2">
                <Check className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                <span>{orderSuccessMsg}</span>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Post-Service Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        currentGuest={currentGuest}
        authSession={authSession}
        initialCategory="dining"
        initialTargetId={selectedFeedbackOrder?.id}
        initialTargetTitle={selectedFeedbackOrder ? `Order #${selectedFeedbackOrder.id} (${selectedFeedbackOrder.items.map(i => i.name).join(', ')})` : 'In-Room Dining Experience'}
        orders={orders}
      />
    </div>
  );
};
