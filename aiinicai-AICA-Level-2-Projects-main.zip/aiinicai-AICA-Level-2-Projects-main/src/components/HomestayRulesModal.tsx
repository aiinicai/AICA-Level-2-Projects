import React from 'react';
import { Shield, Check, X, FileText, AlertCircle, Heart, Clock, Volume2 } from 'lucide-react';

interface HomestayRulesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAccept?: () => void;
}

export const HomestayRulesModal: React.FC<HomestayRulesModalProps> = ({
  isOpen,
  onClose,
  onAccept
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] flex flex-col rounded-3xl bg-[#fffdfa] border-2 border-[#d8c5aa] shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#8a2517] to-[#a32e1d] text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center border border-white/20">
              <Shield className="w-5 h-5 text-[#f5d998]" />
            </div>
            <div>
              <h3 className="font-display font-bold text-lg text-white">
                Heritique Haveli Homestay Rules &amp; Terms
              </h3>
              <p className="text-[11px] text-[#f5ecd8]">
                1458, Rathi Building, Partanion Ka Rasta, Johari Bazar, Jaipur
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-5 text-xs text-[#5c493a] leading-relaxed">
          <div className="p-3.5 rounded-2xl bg-[#f4ece1] border border-[#d8c5aa] text-[11px] text-[#695646]">
            Welcome to Heritique Haveli. As an authentic 100-year-old Rajputana residential property registered under the Rajasthan Tourism (Homestay) Scheme and Government of India Ministry of Tourism guidelines, all staying guests agree to the following statutory and house guidelines:
          </div>

          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-lg bg-[#8a2517]/10 text-[#8a2517] font-bold flex items-center justify-center shrink-0 mt-0.5">
                1
              </div>
              <div>
                <h4 className="font-bold text-[#241c16] text-xs">Statutory Identity Registration (Indian Law)</h4>
                <p>
                  As mandated by local Police &amp; the Ministry of Home Affairs, all domestic guests must present a valid government-issued photo ID (Aadhaar Card, Driving Licence, Voter ID, or Indian Passport). Foreign nationals must complete statutory Form C with valid Passport &amp; Visa details.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-lg bg-[#8a2517]/10 text-[#8a2517] font-bold flex items-center justify-center shrink-0 mt-0.5">
                2
              </div>
              <div>
                <h4 className="font-bold text-[#241c16] text-xs">Heritage Architecture &amp; Fresco Conservation</h4>
                <p>
                  Heritique Haveli features delicate 1924 stone jharokhas, carved teakwood doors, and natural vegetable-dye frescoes. Defacing, scratching, or sticking adhesive to historic walls or antique furniture is strictly prohibited and subject to structural restoration fines.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-lg bg-[#8a2517]/10 text-[#8a2517] font-bold flex items-center justify-center shrink-0 mt-0.5">
                3
              </div>
              <div>
                <h4 className="font-bold text-[#241c16] text-xs">Strict Non-Smoking Policy</h4>
                <p>
                  Smoking or vaping is strictly prohibited inside all heritage chambers, suites, bathrooms, and corridors. Smoking is only permitted at the open-air central courtyard designated smoking zone.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-lg bg-[#8a2517]/10 text-[#8a2517] font-bold flex items-center justify-center shrink-0 mt-0.5">
                4
              </div>
              <div>
                <h4 className="font-bold text-[#241c16] text-xs">Quiet Hours &amp; Neighborhood Harmony</h4>
                <p>
                  In respect of other haveli residents and the traditional Johari Bazar heritage neighborhood, peaceful quiet hours are observed between <strong>10:00 PM and 7:00 AM</strong>. Loud music and boisterous courtyard gatherings are not permitted late night.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-lg bg-[#8a2517]/10 text-[#8a2517] font-bold flex items-center justify-center shrink-0 mt-0.5">
                5
              </div>
              <div>
                <h4 className="font-bold text-[#241c16] text-xs">Visitor Policy</h4>
                <p>
                  For the security of all guests and statutory compliance, non-resident visitors are welcome in the ground-floor chowk / reception up to 9:00 PM. No unregistered overnight visitors are permitted in private suites.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-lg bg-[#8a2517]/10 text-[#8a2517] font-bold flex items-center justify-center shrink-0 mt-0.5">
                6
              </div>
              <div>
                <h4 className="font-bold text-[#241c16] text-xs">Check-in (12:00 PM) &amp; Check-out (11:00 AM)</h4>
                <p>
                  Late checkout is subject to suite availability. Luggage storage is complimentary at front desk for guests exploring Johari Bazar or Amber Fort prior to departure.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-[#f4ece1] border-t border-[#d8c5aa] flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl border border-[#d8c5aa] bg-white text-[#5c493a] text-xs font-semibold hover:bg-gray-50"
          >
            Close
          </button>
          {onAccept && (
            <button
              type="button"
              onClick={() => {
                onAccept();
                onClose();
              }}
              className="px-6 py-2.5 rounded-xl bg-[#8a2517] text-white font-bold text-xs shadow hover:bg-[#a32e1d] flex items-center gap-1.5"
            >
              <Check className="w-4 h-4 text-[#f5d998]" />
              <span>I Understand &amp; Agree</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
