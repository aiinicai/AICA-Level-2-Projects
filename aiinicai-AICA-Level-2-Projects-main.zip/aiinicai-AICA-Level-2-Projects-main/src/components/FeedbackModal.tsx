import React, { useState, useEffect } from 'react';
import { 
  Star, Utensils, Sparkles, CheckCircle2, X, Send, 
  MessageSquare, ThumbsUp, Heart, ShieldCheck, Clock,
  FileSpreadsheet, ExternalLink, RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ServiceFeedback, FeedbackCategory, GuestRegistration, AuthSession, FoodOrder, HousekeepingRequest } from '../types';
import { submitFeedback } from '../utils/api';
import { appendFeedbackToSheet } from '../services/sheetsService';
import { getAccessToken } from '../services/firebase';

interface FeedbackModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentGuest: GuestRegistration | null;
  authSession?: AuthSession | null;
  initialCategory?: FeedbackCategory;
  initialTargetId?: string;
  initialTargetTitle?: string;
  orders?: FoodOrder[];
  housekeepingRequests?: HousekeepingRequest[];
  onFeedbackSubmitted?: (feedback: ServiceFeedback) => void;
}

const DINING_TAGS = [
  'Authentic Flavors', 'Served Piping Hot', 'Rich Spices', 'Melt-in-Mouth Texture',
  'Prompt Room Service', 'Elegant Brass Tableware', 'Fresh Desi Ghee', 'Generous Portions'
];

const HOUSEKEEPING_TAGS = [
  'Spotless Linen', 'Pleasant Fragrance', 'Quick Turnaround', 'Courteous Attendant',
  'Neat Towel Arrangement', 'Clean Bathroom', 'Polite Communication', 'Quiet & Discreet'
];

const STAY_TAGS = [
  '1924 Royal Heritage Charm', 'Peaceful Courtyard Ambience', 'Fountain & Garden View',
  'Gracious Rajput Hospitality', 'Smooth Digital Checkout', 'Authentic Thali Meals',
  'Knowledgeable Host Guidance', 'Fast Guest Wi-Fi'
];

export const FeedbackModal: React.FC<FeedbackModalProps> = ({
  isOpen,
  onClose,
  currentGuest,
  authSession,
  initialCategory = 'dining',
  initialTargetId,
  initialTargetTitle,
  orders = [],
  housekeepingRequests = [],
  onFeedbackSubmitted
}) => {
  const [category, setCategory] = useState<FeedbackCategory>(initialCategory);
  const [targetId, setTargetId] = useState<string>(initialTargetId || '');
  const [targetTitle, setTargetTitle] = useState<string>(initialTargetTitle || '');
  
  // Rating states
  const [rating, setRating] = useState<number>(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [qualityRating, setQualityRating] = useState<number>(5);
  const [speedRating, setSpeedRating] = useState<number>(5);
  const [courtesyRating, setCourtesyRating] = useState<number>(5);
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [comments, setComments] = useState<string>('');
  const [npsScore, setNpsScore] = useState<number>(10);

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [isSubmittedSuccess, setIsSubmittedSuccess] = useState<boolean>(false);
  const [sheetSyncStatus, setSheetSyncStatus] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Sync props when modal opens
  useEffect(() => {
    if (isOpen) {
      setCategory(initialCategory);
      setTargetId(initialTargetId || '');
      setTargetTitle(initialTargetTitle || '');
      setIsSubmittedSuccess(false);
      setSheetSyncStatus(null);
      setErrorMsg(null);
      setSelectedTags([]);
      setComments('');
    }
  }, [isOpen, initialCategory, initialTargetId, initialTargetTitle]);

  // When category changes, auto-adjust initial target if not set
  useEffect(() => {
    if (category === 'dining') {
      if (!targetId && orders.length > 0) {
        const first = orders[0];
        setTargetId(first.id);
        setTargetTitle(`Order #${first.id} (${first.items.map(i => i.name).join(', ')})`);
      } else if (!targetId) {
        setTargetTitle('In-Room Dining Experience');
      }
    } else if (category === 'housekeeping') {
      if (!targetId && housekeepingRequests.length > 0) {
        const first = housekeepingRequests[0];
        setTargetId(first.id);
        setTargetTitle(`Request #${first.id} (${first.requestType})`);
      } else if (!targetId) {
        setTargetTitle('Housekeeping & Room Care');
      }
    } else if (category === 'stay_checkout') {
      setTargetId('stay');
      setTargetTitle('Complete Homestay Experience & Checkout');
    }
  }, [category, orders, housekeepingRequests]);

  if (!isOpen) return null;

  const guestId = currentGuest?.id || authSession?.guestId || 'GUEST-8021';
  const guestName = currentGuest 
    ? `${currentGuest.givenName} ${currentGuest.surname}`.trim() 
    : (authSession?.displayName || 'Elena Rostova');
  const roomNumber = currentGuest?.roomNumber || authSession?.roomNumber || 'Suite 101 - The Royal Haveli';
  const guestEmail = currentGuest?.email || authSession?.email || 'guest@heritique.com';

  const toggleTag = (tag: string) => {
    if (selectedTags.includes(tag)) {
      setSelectedTags(prev => prev.filter(t => t !== tag));
    } else {
      setSelectedTags(prev => [...prev, tag]);
    }
  };

  const getRatingLabel = (val: number) => {
    switch (val) {
      case 5: return 'Exceptional • Royal Standard';
      case 4: return 'Very Good • Exceeded Expectations';
      case 3: return 'Good • Satisfactory';
      case 2: return 'Fair • Needs Attention';
      case 1: return 'Poor • Disappointing';
      default: return '';
    }
  };

  const currentAvailableTags = category === 'dining' 
    ? DINING_TAGS 
    : category === 'housekeeping' 
    ? HOUSEKEEPING_TAGS 
    : STAY_TAGS;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setErrorMsg(null);

    try {
      const payload: Partial<ServiceFeedback> = {
        guestId,
        guestName,
        guestEmail,
        roomNumber,
        category,
        targetId: targetId || undefined,
        targetTitle: targetTitle || undefined,
        rating,
        qualityRating,
        speedRating,
        courtesyRating,
        tags: selectedTags,
        comments: comments.trim(),
        npsScore: category === 'stay_checkout' ? npsScore : undefined
      };

      const res = await submitFeedback(payload);

      if (res.success && res.feedback) {
        // Direct sync to Google Sheet under 'Service Feedback' tab if token & sheet exist
        const activeSheetId = localStorage.getItem('heritique_active_sheet_id') || localStorage.getItem('heritique_master_spreadsheet_id');
        const token = await getAccessToken();

        if (activeSheetId && token) {
          try {
            await appendFeedbackToSheet(token, activeSheetId, res.feedback);
            setSheetSyncStatus('Saved and recorded in Google Sheet "Service Feedback" tab');
          } catch (sheetErr: any) {
            console.warn('Google Sheet append note:', sheetErr);
            setSheetSyncStatus('Saved locally (will auto-sync to Google Sheet upon next ledger refresh)');
          }
        } else {
          setSheetSyncStatus('Saved in Operations Ledger (connect Google Sheets in Admin to sync live)');
        }

        setIsSubmittedSuccess(true);
        try {
          confetti({
            particleCount: 60,
            spread: 60,
            origin: { y: 0.6 }
          });
        } catch {
          // ignore
        }

        if (onFeedbackSubmitted) {
          onFeedbackSubmitted(res.feedback);
        }
      }
    } catch (err: any) {
      console.error('Error submitting feedback:', err);
      setErrorMsg(err.message || 'Could not submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 overflow-y-auto">
      <div className="w-full max-w-2xl my-6 rounded-3xl border border-amber-500/40 bg-[#0d1f15] text-[#f7f4ea] shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Top Bar */}
        <div className="bg-[#142b1f] border-b border-amber-500/20 px-6 py-4 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#1b3a29] border border-[#d4af37] flex items-center justify-center text-[#d4af37] shadow">
              <Star className="w-5 h-5 fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-display font-bold text-base sm:text-lg text-[#f7f4ea]">
                  Post-Service Feedback
                </h3>
                <span className="text-[10px] font-bold uppercase tracking-wider bg-black/40 text-[#d4af37] px-2 py-0.5 rounded-full border border-amber-500/30">
                  Google Sheet Synced
                </span>
              </div>
              <p className="text-[11px] text-amber-200/60 font-serif italic">
                Heritique Haveli • {roomNumber} • {guestName}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-amber-200/60 hover:text-white hover:bg-black/30 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {isSubmittedSuccess ? (
            /* Thank You Success Screen */
            <div className="text-center py-8 space-y-5">
              <div className="w-16 h-16 mx-auto rounded-2xl bg-gradient-to-br from-[#d4af37] to-[#8a2517] text-white flex items-center justify-center shadow-xl">
                <CheckCircle2 className="w-9 h-9" />
              </div>
              
              <div className="space-y-2">
                <span className="text-xs font-serif italic text-[#d4af37] tracking-wider uppercase font-semibold">
                  Padharo Mhare Des • Dhanyawad Sa
                </span>
                <h3 className="font-display font-bold text-2xl text-white">
                  Thank You for Your Royal Feedback!
                </h3>
                <p className="text-xs text-amber-200/70 max-w-md mx-auto leading-relaxed">
                  Your review has been recorded in our permanent <strong>Master Operations Ledger</strong> under the <strong>Service Feedback</strong> tab. It guides Thakur Mahendra Singh and the haveli culinary &amp; housekeeping teams in preserving genuine Rajput hospitality.
                </p>
              </div>

              {sheetSyncStatus && (
                <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-black/40 border border-emerald-500/40 text-emerald-300 text-xs font-medium">
                  <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                  <span>{sheetSyncStatus}</span>
                </div>
              )}

              <div className="pt-4 flex justify-center gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl font-bold bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] transition-all text-xs shadow-lg"
                >
                  Close &amp; Return
                </button>
              </div>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Category Selector Tabs */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-amber-200/80 uppercase tracking-wider block">
                  1. Select Service to Rate
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => { setCategory('dining'); setTargetId(''); }}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center gap-1.5 text-center ${
                      category === 'dining'
                        ? 'bg-[#1b3a29] border-[#d4af37] text-white shadow-md'
                        : 'bg-[#0a1810] border-amber-500/20 text-amber-200/70 hover:border-amber-500/40'
                    }`}
                  >
                    <Utensils className="w-4 h-4 text-[#d4af37]" />
                    <span>In-Room Dining</span>
                    <span className="text-[10px] font-normal text-amber-200/50">Meals &amp; Chai</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setCategory('housekeeping'); setTargetId(''); }}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center gap-1.5 text-center ${
                      category === 'housekeeping'
                        ? 'bg-[#1b3a29] border-[#d4af37] text-white shadow-md'
                        : 'bg-[#0a1810] border-amber-500/20 text-amber-200/70 hover:border-amber-500/40'
                    }`}
                  >
                    <Sparkles className="w-4 h-4 text-[#d4af37]" />
                    <span>Housekeeping</span>
                    <span className="text-[10px] font-normal text-amber-200/50">Linen &amp; Tidy</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => { setCategory('stay_checkout'); setTargetId('stay'); }}
                    className={`p-3 rounded-2xl border text-xs font-bold transition-all flex flex-col items-center gap-1.5 text-center ${
                      category === 'stay_checkout'
                        ? 'bg-[#1b3a29] border-[#d4af37] text-white shadow-md'
                        : 'bg-[#0a1810] border-amber-500/20 text-amber-200/70 hover:border-amber-500/40'
                    }`}
                  >
                    <Heart className="w-4 h-4 text-[#d4af37]" />
                    <span>Stay &amp; Checkout</span>
                    <span className="text-[10px] font-normal text-amber-200/50">Overall Experience</span>
                  </button>
                </div>
              </div>

              {/* Target Service / Order Selection (if multiple orders or requests exist) */}
              {category === 'dining' && (
                <div className="space-y-1.5 bg-black/30 p-3.5 rounded-2xl border border-amber-500/20">
                  <label className="text-[11px] font-semibold text-amber-200/70 block">
                    {orders.length > 0 ? 'Choose Specific Dining Order:' : 'Dining Order or Meal Description:'}
                  </label>
                  {orders.length > 0 ? (
                    <select
                      value={targetId}
                      onChange={e => {
                        const selected = orders.find(o => o.id === e.target.value);
                        setTargetId(e.target.value);
                        if (selected) {
                          setTargetTitle(`Order #${selected.id} (${selected.items.map(i => i.name).join(', ')})`);
                        }
                      }}
                      className="w-full rounded-xl border border-amber-500/30 bg-[#12261b] px-3 py-2 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    >
                      {orders.map(ord => (
                        <option key={ord.id} value={ord.id}>
                          Order #{ord.id} • {ord.items.map(i => `${i.quantity}x ${i.name}`).join(', ')} (₹{ord.total})
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={targetTitle}
                      onChange={e => setTargetTitle(e.target.value)}
                      placeholder="e.g. Royal Thali Dinner, Morning Masala Chai, Ghevar..."
                      className="w-full rounded-xl border border-amber-500/30 bg-[#12261b] px-3 py-2 text-xs text-amber-100 placeholder-amber-200/40 focus:border-[#d4af37] focus:outline-none"
                    />
                  )}
                </div>
              )}

              {category === 'housekeeping' && (
                <div className="space-y-1.5 bg-black/30 p-3.5 rounded-2xl border border-amber-500/20">
                  <label className="text-[11px] font-semibold text-amber-200/70 block">
                    {housekeepingRequests.length > 0 ? 'Choose Specific Housekeeping Request:' : 'Room Care / Housekeeping Description:'}
                  </label>
                  {housekeepingRequests.length > 0 ? (
                    <select
                      value={targetId}
                      onChange={e => {
                        const selected = housekeepingRequests.find(h => h.id === e.target.value);
                        setTargetId(e.target.value);
                        if (selected) {
                          setTargetTitle(`Request #${selected.id} (${selected.requestType})`);
                        }
                      }}
                      className="w-full rounded-xl border border-amber-500/30 bg-[#12261b] px-3 py-2 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
                    >
                      {housekeepingRequests.map(h => (
                        <option key={h.id} value={h.id}>
                          Request #{h.id} • {h.requestType} ({h.preferredTime}) — Status: {h.status}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <input
                      type="text"
                      value={targetTitle}
                      onChange={e => setTargetTitle(e.target.value)}
                      placeholder="e.g. Fresh Towels & Lavender Mist, Evening Turndown Service..."
                      className="w-full rounded-xl border border-amber-500/30 bg-[#12261b] px-3 py-2 text-xs text-amber-100 placeholder-amber-200/40 focus:border-[#d4af37] focus:outline-none"
                    />
                  )}
                </div>
              )}

              {/* Star Rating Section */}
              <div className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-5 text-center space-y-2">
                <label className="text-xs font-bold text-amber-200/80 uppercase tracking-wider block">
                  2. Overall Experience Rating
                </label>
                <div className="flex items-center justify-center gap-2 pt-1">
                  {[1, 2, 3, 4, 5].map(star => {
                    const isFilled = (hoverRating !== null ? hoverRating >= star : rating >= star);
                    return (
                      <button
                        type="button"
                        key={star}
                        onClick={() => setRating(star)}
                        onMouseEnter={() => setHoverRating(star)}
                        onMouseLeave={() => setHoverRating(null)}
                        className="p-1 transition-transform hover:scale-125 focus:outline-none"
                      >
                        <Star 
                          className={`w-8 h-8 transition-colors ${
                            isFilled 
                              ? 'text-[#d4af37] fill-[#d4af37] drop-shadow-[0_0_8px_rgba(212,175,55,0.6)]' 
                              : 'text-amber-500/30 hover:text-amber-500/60'
                          }`} 
                        />
                      </button>
                    );
                  })}
                </div>
                <p className="text-xs font-semibold text-[#d4af37] pt-1">
                  {getRatingLabel(hoverRating || rating)}
                </p>
              </div>

              {/* Aspect Breakdowns: Quality, Speed, Courtesy */}
              <div className="space-y-3">
                <label className="text-xs font-bold text-amber-200/80 uppercase tracking-wider block">
                  3. Key Service Dimensions (1 to 5)
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Quality */}
                  <div className="bg-[#0a1810] p-3 rounded-xl border border-amber-500/20 space-y-1.5">
                    <span className="text-[11px] font-semibold text-amber-200/70 block">
                      {category === 'dining' ? 'Food Flavor & Taste' : category === 'housekeeping' ? 'Cleanliness & Freshness' : 'Room Comfort & Ambience'}
                    </span>
                    <div className="flex items-center justify-between gap-1">
                      {[1, 2, 3, 4, 5].map(v => (
                        <button
                          type="button"
                          key={v}
                          onClick={() => setQualityRating(v)}
                          className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                            qualityRating === v
                              ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                              : 'bg-black/30 text-amber-200/50 hover:bg-black/50'
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Speed */}
                  <div className="bg-[#0a1810] p-3 rounded-xl border border-amber-500/20 space-y-1.5">
                    <span className="text-[11px] font-semibold text-amber-200/70 block">
                      {category === 'dining' ? 'Delivery Promptness' : category === 'housekeeping' ? 'Response Speed' : 'Checkout & Settling Ease'}
                    </span>
                    <div className="flex items-center justify-between gap-1">
                      {[1, 2, 3, 4, 5].map(v => (
                        <button
                          type="button"
                          key={v}
                          onClick={() => setSpeedRating(v)}
                          className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                            speedRating === v
                              ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                              : 'bg-black/30 text-amber-200/50 hover:bg-black/50'
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Courtesy */}
                  <div className="bg-[#0a1810] p-3 rounded-xl border border-amber-500/20 space-y-1.5">
                    <span className="text-[11px] font-semibold text-amber-200/70 block">
                      Rajputana Hospitality
                    </span>
                    <div className="flex items-center justify-between gap-1">
                      {[1, 2, 3, 4, 5].map(v => (
                        <button
                          type="button"
                          key={v}
                          onClick={() => setCourtesyRating(v)}
                          className={`w-7 h-7 rounded-lg text-xs font-bold transition-all ${
                            courtesyRating === v
                              ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                              : 'bg-black/30 text-amber-200/50 hover:bg-black/50'
                          }`}
                        >
                          {v}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Quick Highlight Tags */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-amber-200/80 uppercase tracking-wider block">
                  4. What stood out the most? (Tap tags)
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {currentAvailableTags.map(tag => {
                    const isSelected = selectedTags.includes(tag);
                    return (
                      <button
                        type="button"
                        key={tag}
                        onClick={() => toggleTag(tag)}
                        className={`px-3 py-1.5 rounded-full text-xs transition-all ${
                          isSelected
                            ? 'bg-[#d4af37] text-[#0d1f15] font-bold shadow'
                            : 'bg-[#12261b] text-amber-200/70 border border-amber-500/20 hover:border-amber-500/40'
                        }`}
                      >
                        {isSelected ? '✓ ' : '+ '} {tag}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* NPS Recommendation Score (for stay & checkout) */}
              {category === 'stay_checkout' && (
                <div className="bg-black/30 p-4 rounded-2xl border border-amber-500/20 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-amber-100">
                      How likely are you to recommend Heritique Haveli to friends &amp; family?
                    </span>
                    <span className="font-bold text-[#d4af37] text-sm">{npsScore} / 10</span>
                  </div>
                  <div className="flex items-center justify-between gap-1 pt-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(n => (
                      <button
                        type="button"
                        key={n}
                        onClick={() => setNpsScore(n)}
                        className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition-all ${
                          npsScore === n
                            ? 'bg-[#d4af37] text-[#0d1f15] shadow-md scale-105'
                            : 'bg-[#142b1f] text-amber-200/60 hover:text-white'
                        }`}
                      >
                        {n}
                      </button>
                    ))}
                  </div>
                  <div className="flex justify-between text-[10px] text-amber-200/50">
                    <span>1: Not Likely</span>
                    <span>10: Absolutely Recommend</span>
                  </div>
                </div>
              )}

              {/* Comments & Review Text */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-amber-200/80 uppercase tracking-wider block">
                  5. Detailed Feedback / Special Mentions
                </label>
                <textarea
                  rows={3}
                  value={comments}
                  onChange={e => setComments(e.target.value)}
                  placeholder={
                    category === 'dining'
                      ? 'Tell us about the flavor, portion, favorite dishes, or any chef compliments...'
                      : category === 'housekeeping'
                      ? 'Mention how the room tidying or linen service met your expectations...'
                      : 'Share your favorite memories, heritage architectural impressions, or staff hospitality...'
                  }
                  className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] p-3 text-xs text-amber-100 placeholder:text-amber-200/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>

              {errorMsg && (
                <div className="p-3 rounded-xl bg-red-950/60 border border-red-500/40 text-red-200 text-xs">
                  {errorMsg}
                </div>
              )}

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3.5 rounded-xl font-bold bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] active:scale-95 transition-all text-xs flex items-center justify-center gap-2 shadow-xl disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>Recording Feedback in Operations Ledger...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit Royal Feedback &amp; Sync to Google Sheet</span>
                    </>
                  )}
                </button>
                <p className="text-center text-[10px] text-amber-200/50 mt-2">
                  Auto-synchronizes to Google Sheets Master Operations Ledger under <strong>'Service Feedback'</strong> tab.
                </p>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
