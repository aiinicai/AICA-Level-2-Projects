import React, { useState } from 'react';
import { 
  Sparkles, Compass, MapPin, Calendar, Clock, Utensils, 
  Camera, ShoppingBag, ShieldCheck, ChevronRight, Copy, 
  Check, Printer, RefreshCw, X, ArrowRight, Heart
} from 'lucide-react';
import { AuthSession } from '../types';

interface AiItineraryPlannerProps {
  isOpen?: boolean;
  onClose?: () => void;
  authSession?: AuthSession | null;
}

export const AiItineraryPlanner: React.FC<AiItineraryPlannerProps> = ({
  isOpen = true,
  onClose,
  authSession
}) => {
  const [destination, setDestination] = useState('Jaipur (Pink City & Amber Fort)');
  const [days, setDays] = useState(2);
  const [travelStyle, setTravelStyle] = useState('Heritage, Forts & Architecture');
  const [partyType, setPartyType] = useState('Couple / Romantic Explorer');
  const [preferences, setPreferences] = useState('');
  
  const [isLoading, setIsLoading] = useState(false);
  const [itinerary, setItinerary] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const homestayAddress = '1458, Rathi Building, Partanion Ka Rasta, Johari Bazar, Jaipur, Rajasthan 302003';

  const handleGenerateItinerary = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/plan-itinerary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          destination,
          days,
          travelStyle,
          partyType,
          preferences
        })
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to generate travel plan');
      }

      setItinerary(data.itinerary);
    } catch (err: any) {
      console.error('Error generating AI itinerary:', err);
      setError(err.message || 'Unable to connect to AI itinerary concierge. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = () => {
    if (!itinerary) return;
    const text = typeof itinerary.rawText === 'string' ? itinerary.rawText : JSON.stringify(itinerary, null, 2);
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#8a2517] via-[#9e2d1d] to-[#6d1c10] text-white p-6 sm:p-8 shadow-2xl border border-[#d4af37]/40">
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#f5d998]/15 border border-[#f5d998]/30 text-[#f5d998] text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 animate-pulse" />
              <span>AI Royal Travel Concierge • Powered by Gemini</span>
            </div>
            <h2 className="font-display font-bold text-2xl sm:text-3xl tracking-tight text-[#fffdfa]">
              Personalized Rajasthan &amp; Jaipur Itinerary Planner
            </h2>
            <p className="text-xs sm:text-sm text-[#f5ecd8] leading-relaxed">
              Curated daily routes beginning at your doorstep in <strong>Johari Bazar</strong>, linking historic Rajput fortresses, royal bazaars, and legendary culinary stops.
            </p>
          </div>

          {onClose && (
            <button
              onClick={onClose}
              className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all shrink-0"
              title="Close Itinerary Planner"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Input Selection Grid */}
      <div className="rounded-3xl bg-[#fffdfa] border-2 border-[#d8c5aa] p-6 sm:p-8 shadow-xl space-y-6">
        <div className="flex items-center gap-2 text-[#8a2517] border-b border-[#ebdcc8] pb-3">
          <Compass className="w-5 h-5 text-[#c59b27]" />
          <h3 className="font-display font-bold text-lg text-[#241c16]">
            Configure Your Royal Journey
          </h3>
        </div>

        {/* Departure Point confirmation */}
        <div className="p-3.5 rounded-2xl bg-[#f4ece1] border border-[#d8c5aa] text-xs flex items-center gap-3">
          <MapPin className="w-4 h-4 text-[#8a2517] shrink-0" />
          <div className="flex-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#755943] block">Starting Base</span>
            <span className="font-semibold text-[#241c16]">Heritique Haveli: {homestayAddress}</span>
          </div>
          <span className="text-[10px] bg-[#8a2517]/10 text-[#8a2517] font-bold px-2 py-0.5 rounded border border-[#8a2517]/20">
            Johari Bazar Gate
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
          {/* Destination */}
          <div className="space-y-1.5">
            <label className="block font-bold text-[#4a3b30]">Destination</label>
            <select
              value={destination}
              onChange={e => setDestination(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#d8c5aa] bg-[#fbf8f2] text-[#241c16] font-medium focus:border-[#8a2517] focus:outline-none"
            >
              <option value="Jaipur (Pink City & Amber Fort)">Jaipur (Pink City, Amber Fort & Bazaars)</option>
              <option value="Udaipur (City of Lakes & Mewar)">Udaipur (City of Lakes & Mewar Palaces)</option>
              <option value="Jodhpur (Blue City & Mehrangarh)">Jodhpur (Blue City & Mehrangarh Fort)</option>
              <option value="Jaisalmer (Golden Fort & Thar Desert)">Jaisalmer (Golden Sand Dunes & Fort)</option>
              <option value="Grand Royal Rajasthan Circuit">Grand Royal Rajasthan Circuit (Jaipur - Jodhpur - Udaipur)</option>
            </select>
          </div>

          {/* Days */}
          <div className="space-y-1.5">
            <label className="block font-bold text-[#4a3b30]">Trip Duration</label>
            <div className="grid grid-cols-4 gap-2">
              {[1, 2, 3, 5].map(d => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setDays(d)}
                  className={`py-2 rounded-xl font-bold transition-all text-center border ${
                    days === d 
                      ? 'bg-[#8a2517] text-white border-[#8a2517] shadow-sm' 
                      : 'bg-[#fbf8f2] text-[#5c493a] border-[#d8c5aa] hover:bg-[#fffdfa]'
                  }`}
                >
                  {d} {d === 1 ? 'Day' : 'Days'}
                </button>
              ))}
            </div>
          </div>

          {/* Travel Style */}
          <div className="space-y-1.5">
            <label className="block font-bold text-[#4a3b30]">Travel Style &amp; Passion</label>
            <select
              value={travelStyle}
              onChange={e => setTravelStyle(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#d8c5aa] bg-[#fbf8f2] text-[#241c16] font-medium focus:border-[#8a2517] focus:outline-none"
            >
              <option value="Heritage, Forts & Architecture">Heritage, Forts &amp; Palace Architecture</option>
              <option value="Johari Bazar Gem & Textile Shopping">Johari Bazar Gem, Block-Print &amp; Jewelry Shopping</option>
              <option value="Royal Mewari & Rajputana Food Trail">Royal Mewari &amp; Rajputana Street Food Trail</option>
              <option value="Photography, Sunsets & Stepwells">Photography, Golden Hour Sunsets &amp; Ancient Stepwells</option>
              <option value="Relaxed Haveli Retreat & Culture">Relaxed Haveli Retreat, High Chai &amp; Folk Music</option>
            </select>
          </div>

          {/* Group Type */}
          <div className="space-y-1.5">
            <label className="block font-bold text-[#4a3b30]">Who is Traveling?</label>
            <select
              value={partyType}
              onChange={e => setPartyType(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-[#d8c5aa] bg-[#fbf8f2] text-[#241c16] font-medium focus:border-[#8a2517] focus:outline-none"
            >
              <option value="Couple / Romantic Explorer">Couple / Romantic Gateway</option>
              <option value="Solo Heritage Traveler">Solo Heritage Traveler</option>
              <option value="Family with Children">Family with Children</option>
              <option value="Friends / Photography Group">Friends / Photography Group</option>
            </select>
          </div>
        </div>

        {/* Special Requests */}
        <div className="space-y-1.5 text-xs">
          <label className="block font-bold text-[#4a3b30]">Custom Requests / Must-Visit Wishes (Optional)</label>
          <input
            type="text"
            value={preferences}
            onChange={e => setPreferences(e.target.value)}
            placeholder="e.g. Sunrise at Nahargarh Fort, authentic Ghevar at LMB Johari Bazar, blue pottery shopping"
            className="w-full px-3.5 py-2.5 rounded-xl border border-[#d8c5aa] bg-[#fbf8f2] text-[#241c16] placeholder-[#a6927e] focus:border-[#8a2517] focus:outline-none"
          />
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs">
            {error}
          </div>
        )}

        {/* Action Button */}
        <button
          onClick={handleGenerateItinerary}
          disabled={isLoading}
          className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-[#8a2517] to-[#a32e1d] text-white font-bold text-sm shadow-xl hover:shadow-2xl hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2.5 disabled:opacity-50"
        >
          {isLoading ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-[#f5d998]" />
              <span>Consulting Royal Palace Archives &amp; Crafting Itinerary...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-[#f5d998]" />
              <span>Generate AI Itinerary (Starting from Johari Bazar)</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </div>

      {/* Generated Itinerary Display */}
      {itinerary && (
        <div id="itinerary-print-area" className="rounded-3xl bg-[#fffdfa] border-2 border-[#d8c5aa] p-6 sm:p-8 shadow-2xl space-y-8 animate-in fade-in duration-300">
          {/* Itinerary Title Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-[#ebdcc8] pb-6">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-[#8a2517] px-2.5 py-0.5 rounded-full bg-[#8a2517]/10 border border-[#8a2517]/20">
                Curated Royal Experience
              </span>
              <h3 className="font-display font-bold text-2xl text-[#241c16]">
                {itinerary.title || `${days}-Day Journey across ${destination}`}
              </h3>
              {itinerary.summary && (
                <p className="text-xs sm:text-sm text-[#695646] max-w-3xl leading-relaxed">
                  {itinerary.summary}
                </p>
              )}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="px-3.5 py-2 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] text-[#5c493a] hover:text-[#241c16] text-xs font-semibold flex items-center gap-1.5 transition-all"
                title="Copy itinerary details"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-[#8a2517]" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
              <button
                onClick={handlePrint}
                className="px-3.5 py-2 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] text-[#5c493a] hover:text-[#241c16] text-xs font-semibold flex items-center gap-1.5 transition-all"
                title="Print or Save as PDF"
              >
                <Printer className="w-4 h-4 text-[#8a2517]" />
                <span>Print</span>
              </button>
            </div>
          </div>

          {/* Starting point tip */}
          {itinerary.startingPointTip && (
            <div className="p-4 rounded-2xl bg-[#f7f2e8] border border-[#d8c5aa] flex items-start gap-3 text-xs text-[#5c493a]">
              <MapPin className="w-5 h-5 text-[#8a2517] shrink-0 mt-0.5" />
              <div>
                <strong className="text-[#241c16] block font-semibold">Johari Bazar Departure Tip:</strong>
                <span>{itinerary.startingPointTip}</span>
              </div>
            </div>
          )}

          {/* Days Accordion / Cards */}
          {Array.isArray(itinerary.days) && itinerary.days.length > 0 ? (
            <div className="space-y-6">
              {itinerary.days.map((day: any) => (
                <div key={day.dayNumber} className="rounded-2xl border border-[#d8c5aa] bg-[#fcf9f5] overflow-hidden shadow-sm">
                  {/* Day Header */}
                  <div className="bg-[#f4ece1] px-5 py-3 border-b border-[#d8c5aa] flex items-center justify-between">
                    <span className="font-display font-bold text-sm text-[#8a2517]">
                      Day {day.dayNumber}: {day.theme}
                    </span>
                    <span className="text-[10px] font-bold text-[#755943] bg-white px-2 py-0.5 rounded border border-[#d8c5aa]">
                      Full Day Plan
                    </span>
                  </div>

                  {/* Day Parts Grid */}
                  <div className="p-5 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    {/* Morning */}
                    {day.morning && (
                      <div className="rounded-xl p-4 bg-white border border-[#e0cfb7] space-y-2">
                        <div className="flex items-center justify-between text-[#8a2517] font-semibold text-[11px]">
                          <span>🌅 Morning</span>
                          <span className="font-mono">{day.morning.time}</span>
                        </div>
                        <h4 className="font-display font-bold text-sm text-[#241c16]">
                          {day.morning.title}
                        </h4>
                        <p className="text-[#695646] leading-relaxed">
                          {day.morning.description}
                        </p>
                        {day.morning.recommendedFood && (
                          <div className="pt-2 border-t border-gray-100 flex items-center gap-1.5 text-[#8a2517] font-medium text-[11px]">
                            <Utensils className="w-3.5 h-3.5" />
                            <span>{day.morning.recommendedFood}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Afternoon */}
                    {day.afternoon && (
                      <div className="rounded-xl p-4 bg-white border border-[#e0cfb7] space-y-2">
                        <div className="flex items-center justify-between text-[#c59b27] font-semibold text-[11px]">
                          <span>☀️ Afternoon</span>
                          <span className="font-mono">{day.afternoon.time}</span>
                        </div>
                        <h4 className="font-display font-bold text-sm text-[#241c16]">
                          {day.afternoon.title}
                        </h4>
                        <p className="text-[#695646] leading-relaxed">
                          {day.afternoon.description}
                        </p>
                        {day.afternoon.recommendedFood && (
                          <div className="pt-2 border-t border-gray-100 flex items-center gap-1.5 text-[#8a2517] font-medium text-[11px]">
                            <Utensils className="w-3.5 h-3.5" />
                            <span>{day.afternoon.recommendedFood}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {/* Evening */}
                    {day.evening && (
                      <div className="rounded-xl p-4 bg-white border border-[#e0cfb7] space-y-2">
                        <div className="flex items-center justify-between text-[#24613b] font-semibold text-[11px]">
                          <span>🌙 Evening Sunset</span>
                          <span className="font-mono">{day.evening.time}</span>
                        </div>
                        <h4 className="font-display font-bold text-sm text-[#241c16]">
                          {day.evening.title}
                        </h4>
                        <p className="text-[#695646] leading-relaxed">
                          {day.evening.description}
                        </p>
                        {day.evening.recommendedFood && (
                          <div className="pt-2 border-t border-gray-100 flex items-center gap-1.5 text-[#8a2517] font-medium text-[11px]">
                            <Utensils className="w-3.5 h-3.5" />
                            <span>{day.evening.recommendedFood}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-4 rounded-xl bg-gray-50 text-xs text-gray-700 whitespace-pre-wrap font-sans">
              {itinerary.rawText || JSON.stringify(itinerary, null, 2)}
            </div>
          )}

          {/* Local Secrets & Shopping */}
          {Array.isArray(itinerary.localInsiderSecrets) && itinerary.localInsiderSecrets.length > 0 && (
            <div className="rounded-2xl border border-amber-300 bg-amber-50/60 p-5 space-y-2">
              <h4 className="font-display font-bold text-sm text-[#8a2517] flex items-center gap-2">
                <ShoppingBag className="w-4 h-4 text-[#c59b27]" />
                <span>Johari Bazar &amp; Haveli Host Insider Secrets</span>
              </h4>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-[#5c493a]">
                {itinerary.localInsiderSecrets.map((secret: string, idx: number) => (
                  <li key={idx} className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#8a2517] mt-1.5 shrink-0" />
                    <span>{secret}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Practical Advice */}
          {Array.isArray(itinerary.essentialPackingAndEtiquette) && itinerary.essentialPackingAndEtiquette.length > 0 && (
            <div className="rounded-2xl border border-[#d8c5aa] bg-[#f4ece1]/50 p-4 text-xs text-[#695646] flex flex-wrap items-center gap-4">
              <span className="font-bold text-[#241c16] flex items-center gap-1">
                <ShieldCheck className="w-4 h-4 text-[#24613b]" /> Travel Notes:
              </span>
              {itinerary.essentialPackingAndEtiquette.map((note: string, idx: number) => (
                <span key={idx} className="bg-white px-2.5 py-1 rounded-lg border border-[#d8c5aa]">
                  {note}
                </span>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
