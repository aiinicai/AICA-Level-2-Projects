import React, { useState, useEffect } from 'react';
import { 
  Shield, Lock, LogOut, Users, Utensils, Receipt, MessageSquare, 
  Search, Eye, Printer, CheckCircle2, Clock, AlertTriangle, 
  Download, Sparkles, Check, ArrowUpRight, FileSpreadsheet, 
  Calendar as CalendarIcon, HardDrive, RefreshCw, Mail, UserCheck,
  BedDouble, DollarSign, PlusCircle, XCircle, Building2, CheckCircle, Tag,
  ShieldCheck, FileText, X, Star, ThumbsUp
} from 'lucide-react';
import { 
  GuestRegistration, FoodOrder, BillingFolio, ChatMessage, AdminUser, 
  AuthSession, UserRole, HousekeepingRequest, Invoice, PaymentTransaction,
  ExpenseItem, ServiceFeedback
} from '../types';
import { 
  fetchGuests, updateGuest, deleteGuest, fetchOrders, 
  updateOrderStatus, fetchBillingFolios, fetchChats, sendChatMessage,
  authorizeWithEmail, fetchHousekeepingRequests, updateHousekeepingStatus,
  fetchAllInvoices, fetchTransactions, fetchExpenses, createExpense,
  updateExpenseStatus, fetchFeedbacks, updateFeedbackStatus
} from '../utils/api';
import { syncFeedbackToSheet } from '../services/sheetsService';
import { getAccessToken } from '../services/firebase';
import { FormCModal } from './FormCModal';
import { GoogleSheetsLedger } from './GoogleSheetsLedger';

interface AdminDashboardProps {
  authSession?: AuthSession | null;
  onOpenAuthModal?: (role?: UserRole, suggestedEmail?: string) => void;
  onSignOut?: () => void;
  onStaffAuthorize?: (session: AuthSession) => void;
  onAuthorized?: (session: AuthSession) => void;
  onAuthSuccess?: (session: AuthSession) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  authSession,
  onOpenAuthModal,
  onSignOut,
  onStaffAuthorize,
  onAuthorized,
  onAuthSuccess
}) => {
  const [adminUser, setAdminUser] = useState<AdminUser | null>(() => {
    if (authSession?.role === 'staff') {
      return {
        id: authSession.token,
        name: authSession.displayName,
        email: authSession.email,
        role: (authSession.staffRole as any) || 'General Manager',
        token: authSession.token
      };
    }
    return null;
  });

  // Keep admin user in sync with global authSession
  useEffect(() => {
    if (authSession?.role === 'staff') {
      setAdminUser({
        id: authSession.token,
        name: authSession.displayName,
        email: authSession.email,
        role: (authSession.staffRole as any) || 'General Manager',
        token: authSession.token
      });
    } else if (authSession?.role === 'guest') {
      setAdminUser(null);
    }
  }, [authSession]);

  const [username, setUsername] = useState('manager@heritique.com');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState<string | null>(null);
  const [isAuthorizingEmail, setIsAuthorizingEmail] = useState(false);

  // Dashboard state
  const [activeTab, setActiveTab] = useState<'occupancy' | 'guests' | 'expenses' | 'orders' | 'billing' | 'chat' | 'housekeeping' | 'invoices' | 'feedback' | 'workspace'>('occupancy');
  const [guests, setGuests] = useState<GuestRegistration[]>([]);
  const [orders, setOrders] = useState<FoodOrder[]>([]);
  const [folios, setFolios] = useState<BillingFolio[]>([]);
  const [chats, setChats] = useState<ChatMessage[]>([]);
  const [housekeepingRequests, setHousekeepingRequests] = useState<HousekeepingRequest[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [transactions, setTransactions] = useState<PaymentTransaction[]>([]);
  const [expenses, setExpenses] = useState<ExpenseItem[]>([]);
  const [feedbacks, setFeedbacks] = useState<ServiceFeedback[]>([]);
  const [feedbackCategoryFilter, setFeedbackCategoryFilter] = useState<'all' | 'dining' | 'housekeeping' | 'stay_checkout'>('all');
  const [isSyncingFeedbackSheet, setIsSyncingFeedbackSheet] = useState(false);
  const [feedbackSyncMsg, setFeedbackSyncMsg] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // Room occupancy filter
  const [roomFilter, setRoomFilter] = useState<'all' | 'occupied' | 'vacant'>('all');

  // Expense modal & state
  const [expenseFilter, setExpenseFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [newExpenseTitle, setNewExpenseTitle] = useState('');
  const [newExpenseCategory, setNewExpenseCategory] = useState<ExpenseItem['category']>('Kitchen & Groceries');
  const [newExpenseAmount, setNewExpenseAmount] = useState<number | ''>('');
  const [newExpenseDate, setNewExpenseDate] = useState(new Date().toISOString().split('T')[0]);
  const [newExpensePaymentMethod, setNewExpensePaymentMethod] = useState<ExpenseItem['paymentMethod']>('UPI / Bank');
  const [newExpenseNotes, setNewExpenseNotes] = useState('');
  const [isSubmittingExpense, setIsSubmittingExpense] = useState(false);
  const [rejectionModalId, setRejectionModalId] = useState<string | null>(null);
  const [rejectionReasonText, setRejectionReasonText] = useState('');

  // Guest search and filters
  const [searchQuery, setSearchQuery] = useState('');
  const [guestFilter, setGuestFilter] = useState<'all' | 'foreign' | 'domestic'>('all');
  const [selectedGuestForFormC, setSelectedGuestForFormC] = useState<GuestRegistration | null>(null);
  const [isFormCOpen, setIsFormCOpen] = useState(false);

  // Chat thread in admin
  const [selectedChatGuestId, setSelectedChatGuestId] = useState<string>('');
  const [staffReplyText, setStaffReplyText] = useState('');

  // Google Workspace sync simulation status
  const [syncStatus, setSyncStatus] = useState<string | null>(null);

  const HAVELI_ROOMS = [
    { number: 'Suite 101 - The Royal Haveli', name: 'The Royal Haveli', type: 'Heritage Grand Suite (Jharokha Balcony)', rate: 7500, floor: '1st Floor (East Courtyard)', capacity: '2 Adults + 1 Child', features: 'King Four-Poster Bed, Jharokha, Fountain View' },
    { number: 'Suite 102 - Gulab Mahal', name: 'Gulab Mahal', type: 'Royal Garden Suite (Rose Courtyard)', rate: 6200, floor: 'Ground Floor (Central Chowk)', capacity: '2 Adults', features: 'Teak Carvings, Private Verandah, Rose Garden' },
    { number: 'Suite 103 - Aravali Verandah', name: 'Aravali Verandah', type: 'Heritage View Room (Hillside Terrace)', rate: 5800, floor: '1st Floor (West Wing)', capacity: '2 Adults', features: 'Fresco Wall Motifs, Heritage Bay Window' },
    { number: 'Suite 104 - Sheesh Mahal Pavilion', name: 'Sheesh Mahal Pavilion', type: 'Palace Suite with Private Plunge Tub', rate: 8900, floor: '2nd Floor (Rooftop Pavilion)', capacity: '2 Adults + 2 Children', features: 'Thikri Mirror Work, Copper Tub, Butler Service' },
    { number: 'Suite 105 - Jodhpur Blue Suite', name: 'Jodhpur Blue Suite', type: 'Marwar Heritage Chamber', rate: 6400, floor: '1st Floor (North Wing)', capacity: '2 Adults', features: 'Indigo Blue Pigments, Handwoven Kilims, Rain Shower' },
    { number: 'Suite 106 - Amber View Terrace Suite', name: 'Amber View Terrace Suite', type: 'Panoramic Rooftop Haven', rate: 7200, floor: '2nd Floor (Terrace)', capacity: '2 Adults', features: 'Sunrise Fortress View, Open-air Daybed, Sunset Chai' },
    { number: 'Suite 107 - Chhavi Niwas', name: 'Chhavi Niwas', type: 'Royal Monsoon Chamber', rate: 6800, floor: 'Ground Floor (Pool Chowk)', capacity: '2 Adults + 1 Child', features: 'Natural Vegetable Dye Murals, Brass Soak Tub' },
    { number: 'Suite 108 - Hawa Mahal Breeze Suite', name: 'Hawa Mahal Breeze Suite', type: 'East Facade Jharokha Suite', rate: 7800, floor: '2nd Floor (East Facade)', capacity: '2 Adults', features: 'Latticed Windows, Johari Bazar Morning Breeze' }
  ];

  const loadAllData = async () => {
    setIsLoading(true);
    try {
      const [gList, oList, bList, cList, hkList, invList, txnList, expList, fbList] = await Promise.all([
        fetchGuests(),
        fetchOrders(),
        fetchBillingFolios(),
        fetchChats(),
        fetchHousekeepingRequests(),
        fetchAllInvoices(),
        fetchTransactions(),
        fetchExpenses(),
        fetchFeedbacks()
      ]);
      setGuests(gList);
      setOrders(oList);
      setFolios(bList);
      setChats(cList);
      setHousekeepingRequests(hkList);
      setInvoices(invList);
      setTransactions(txnList);
      setExpenses(expList);
      setFeedbacks(fbList);
      if (gList.length > 0 && !selectedChatGuestId) {
        setSelectedChatGuestId(gList[0].id);
      }
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateFeedbackStatus = async (feedbackId: string, status: 'acknowledged' | 'in_review' | 'resolved' | 'thanked') => {
    try {
      await updateFeedbackStatus(feedbackId, status);
      setFeedbacks(prev => prev.map(f => f.id === feedbackId ? { ...f, followUpStatus: status } : f));
    } catch (err: any) {
      alert(`Could not update feedback status: ${err.message}`);
    }
  };

  const handleSyncFeedbackToGoogleSheet = async () => {
    setIsSyncingFeedbackSheet(true);
    setFeedbackSyncMsg(null);
    try {
      const activeSheetId = localStorage.getItem('heritique_active_sheet_id') || localStorage.getItem('heritique_master_spreadsheet_id');
      const token = await getAccessToken();
      if (!activeSheetId) {
        setFeedbackSyncMsg('No active Google Sheet selected. Open the "Google Sheets Ledger" tab to connect or create a sheet.');
        return;
      }
      if (!token) {
        setFeedbackSyncMsg('Google Account not connected. Please connect in the "Google Sheets Ledger" tab first.');
        return;
      }
      await syncFeedbackToSheet(token, activeSheetId, feedbacks);
      setFeedbackSyncMsg(`Successfully synchronized all ${feedbacks.length} guest reviews to Google Sheet tab 'Service Feedback'!`);
    } catch (err: any) {
      setFeedbackSyncMsg(`Sync error: ${err.message || 'Failed to update Google Sheet'}`);
    } finally {
      setIsSyncingFeedbackSheet(false);
    }
  };

  const handleCreateExpenseSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newExpenseTitle.trim() || !newExpenseAmount || Number(newExpenseAmount) <= 0) {
      alert('Please enter a valid expense title and amount.');
      return;
    }

    setIsSubmittingExpense(true);
    try {
      const res = await createExpense({
        title: newExpenseTitle.trim(),
        category: newExpenseCategory,
        amount: Number(newExpenseAmount),
        date: newExpenseDate,
        paymentMethod: newExpensePaymentMethod,
        notes: newExpenseNotes.trim() || undefined,
        submittedBy: adminUser ? `${adminUser.name} (${adminUser.role})` : 'Staff Member'
      });
      if (res.success) {
        setIsExpenseModalOpen(false);
        setNewExpenseTitle('');
        setNewExpenseAmount('');
        setNewExpenseNotes('');
        await loadAllData();
      }
    } catch (err: any) {
      alert(`Error submitting expense: ${err.message}`);
    } finally {
      setIsSubmittingExpense(false);
    }
  };

  const handleApproveExpense = async (expenseId: string) => {
    try {
      await updateExpenseStatus(expenseId, 'approved', adminUser?.name || 'General Manager');
      await loadAllData();
    } catch (err: any) {
      alert(`Failed to approve expense: ${err.message}`);
    }
  };

  const handleRejectExpenseConfirm = async () => {
    if (!rejectionModalId) return;
    try {
      await updateExpenseStatus(rejectionModalId, 'rejected', adminUser?.name || 'General Manager', rejectionReasonText.trim() || 'Rejected by management');
      setRejectionModalId(null);
      setRejectionReasonText('');
      await loadAllData();
    } catch (err: any) {
      alert(`Failed to reject expense: ${err.message}`);
    }
  };

  useEffect(() => {
    if (adminUser) {
      loadAllData();
      const interval = setInterval(loadAllData, 6000);
      return () => clearInterval(interval);
    }
  }, [adminUser]);

  const triggerStaffAuth = (session: AuthSession) => {
    if (typeof onStaffAuthorize === 'function') {
      try { onStaffAuthorize(session); } catch (e) { console.error('onStaffAuthorize error:', e); }
    }
    if (typeof onAuthorized === 'function') {
      try { onAuthorized(session); } catch (e) { console.error('onAuthorized error:', e); }
    }
    if (typeof onAuthSuccess === 'function') {
      try { onAuthSuccess(session); } catch (e) { console.error('onAuthSuccess error:', e); }
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    const cleanUser = username.trim();

    // If username is an email address, authorize via email!
    if (cleanUser.includes('@')) {
      setIsAuthorizingEmail(true);
      try {
        const res = await authorizeWithEmail({
          email: cleanUser,
          role: 'staff',
          staffRole: 'Front Desk Officer'
        });
        if (res.success) {
          triggerStaffAuth(res.session);
          setAdminUser({
            id: res.session.token,
            name: res.session.displayName,
            email: res.session.email,
            role: (res.session.staffRole as any) || 'Front Desk Officer',
            token: res.session.token
          });
          return;
        }
      } catch (err: any) {
        setAuthError(err.message || 'Email authorization failed');
        return;
      } finally {
        setIsAuthorizingEmail(false);
      }
    }

    // Default admin credential or PIN
    if ((cleanUser === 'admin' && (password === 'heritage123' || password === 'admin')) || password === '1924') {
      const staffSession: AuthSession = {
        email: 'manager@heritique.com',
        role: 'staff',
        displayName: 'Thakur Mahendra Singh',
        token: `session_${Date.now()}`,
        staffRole: 'General Manager',
        authorizedAt: new Date().toISOString()
      };
      triggerStaffAuth(staffSession);
      setAdminUser({
        id: 'EMP-01',
        name: 'Thakur Mahendra Singh',
        email: 'manager@heritique.com',
        role: 'General Manager',
        token: staffSession.token
      });
    } else {
      setAuthError('Invalid credentials. Enter any valid staff email address or use demo code heritage123');
    }
  };

  const handleQuickDemoUnlock = () => {
    const staffSession: AuthSession = {
      email: 'manager@heritique.com',
      role: 'staff',
      displayName: 'Thakur Mahendra Singh',
      token: `session_${Date.now()}`,
      staffRole: 'General Manager',
      authorizedAt: new Date().toISOString()
    };
    triggerStaffAuth(staffSession);
    setAdminUser({
      id: 'EMP-01',
      name: 'Thakur Mahendra Singh',
      email: 'manager@heritique.com',
      role: 'General Manager',
      token: staffSession.token
    });
  };

  const handleStatusToggle = async (guestId: string, current: string) => {
    const next = current === 'verified' ? 'pending' : 'verified';
    await updateGuest(guestId, { verificationStatus: next });
    loadAllData();
  };

  const handleCheckoutGuest = async (guestId: string) => {
    if (confirm('Check-out this guest and archive stay records?')) {
      await updateGuest(guestId, { status: 'checked_out' });
      loadAllData();
    }
  };

  const handleOrderStatus = async (orderId: string, status: FoodOrder['status']) => {
    await updateOrderStatus(orderId, status);
    loadAllData();
  };

  const handleSendStaffReply = async () => {
    if (!staffReplyText.trim() || !selectedChatGuestId) return;
    const targetGuest = guests.find(g => g.id === selectedChatGuestId);
    await sendChatMessage({
      guestId: selectedChatGuestId,
      roomNumber: targetGuest?.roomNumber || 'Suite',
      sender: 'staff',
      senderName: `${adminUser?.name || 'Front Desk'} (${adminUser?.role || 'Host'})`,
      message: staffReplyText.trim()
    });
    setStaffReplyText('');
    loadAllData();
  };

  // Google Workspace Sync triggers
  const handleSyncToSheets = () => {
    setSyncStatus('Synchronizing all Form C records to Google Sheets...');
    setTimeout(() => {
      setSyncStatus(`Successfully exported ${guests.length} guest records to Google Sheets: "Heritique_Guest_Register_2026.gsheet"`);
      setTimeout(() => setSyncStatus(null), 5000);
    }, 1200);
  };

  const handleSyncToCalendar = () => {
    setSyncStatus('Syncing check-in & check-out dates to Google Calendar...');
    setTimeout(() => {
      setSyncStatus(`Created ${guests.length * 2} events on Google Calendar: "Heritique Haveli Stays"`);
      setTimeout(() => setSyncStatus(null), 5000);
    }, 1200);
  };

  const handleSyncToDrive = () => {
    setSyncStatus('Backing up guest passport documents & live photos to Google Drive...');
    setTimeout(() => {
      setSyncStatus('Uploaded all passport scans and Form C files to Drive folder: "Heritique/FormC_Archives"');
      setTimeout(() => setSyncStatus(null), 5000);
    }, 1400);
  };

  // Export CSV
  const handleExportCSV = () => {
    const headers = ['ID', 'Type', 'Given Name', 'Surname', 'Nationality', 'Passport Number', 'Visa Number', 'Room', 'CheckIn', 'CheckOut', 'Verification'];
    const rows = guests.map(g => [
      g.id, g.guestType, g.givenName, g.surname, g.nationality, g.passportNumber, g.visaNumber || '', g.roomNumber, g.checkInDate, g.checkOutDate, g.verificationStatus
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `heritique_form_c_register_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 1. Employee Login Screen if not authenticated
  if (!adminUser) {
    return (
      <div id="admin-login-screen" className="max-w-md mx-auto py-12 px-4">
        <div className="rounded-3xl border border-amber-500/30 bg-[#0d1f15] p-8 shadow-2xl space-y-6 text-[#f7f4ea]">
          <div className="text-center space-y-2">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-[#1b3a29] to-[#0a1810] border-2 border-[#d4af37] p-2 mx-auto flex items-center justify-center text-[#d4af37] shadow-lg">
              <Shield className="w-7 h-7 text-emerald-400" />
            </div>
            <h3 className="font-display font-bold text-2xl text-[#d4af37]">
              Staff &amp; Operations Portal
            </h3>
            <p className="text-xs text-amber-200/70">
              Authorized homestay operations &amp; statutory Form C compliance. Access with any authorized email address.
            </p>
          </div>

          {/* If currently signed in as Guest, offer 1-click upgrade to staff */}
          {authSession && authSession.role === 'guest' && (
            <div className="p-4 rounded-2xl bg-[#142d20] border border-amber-500/30 space-y-2.5">
              <div className="flex items-center gap-2 text-xs text-amber-200">
                <UserCheck className="w-4 h-4 text-[#d4af37]" />
                <span>Signed in as Guest: <strong>{authSession.displayName}</strong></span>
              </div>
              <p className="text-[11px] text-amber-200/60 font-mono">
                {authSession.email}
              </p>
              <button
                type="button"
                onClick={async () => {
                  try {
                    const res = await authorizeWithEmail({
                      email: authSession.email,
                      role: 'staff',
                      staffRole: 'Front Desk Officer'
                    });
                    if (res.success && onStaffAuthorize) {
                      onStaffAuthorize(res.session);
                    }
                  } catch (err: any) {
                    setAuthError(err.message || 'Failed to authorize as staff');
                  }
                }}
                className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b38f2a] text-[#0a1810] text-xs font-bold shadow hover:brightness-105 transition-all flex items-center justify-center gap-1.5"
              >
                <Shield className="w-4 h-4" /> Authorize this Email as Staff
              </button>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4 text-xs">
            <div>
              <label className="block text-amber-200/80 mb-1 font-medium flex items-center justify-between">
                <span>Staff Email Address or Employee ID</span>
                <span className="text-[10px] text-amber-300/80">Any email permitted</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-amber-300/60">
                  <Mail className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={username}
                  onChange={e => setUsername(e.target.value)}
                  placeholder="e.g. staff@heritique.com or your email"
                  required
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-amber-500/30 bg-[#0a1810] text-amber-100 placeholder-amber-200/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-amber-200/80 mb-1 font-medium flex items-center justify-between">
                <span>Security PIN / Password</span>
                <span className="text-[10px] text-amber-200/40">Optional if using direct email auth</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-amber-300/60">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="heritage123 or PIN 1924 (or leave blank)"
                  className="w-full pl-9 pr-3.5 py-2.5 rounded-xl border border-amber-500/30 bg-[#0a1810] text-amber-100 placeholder-amber-200/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>
            </div>

            {authError && (
              <p className="text-[11px] text-red-400 bg-red-950/40 p-2.5 rounded-xl border border-red-500/30">
                {authError}
              </p>
            )}

            <button
              type="submit"
              disabled={isAuthorizingEmail}
              className="w-full py-3 rounded-xl font-semibold text-xs bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] transition-all flex items-center justify-center gap-1.5 shadow-lg disabled:opacity-50"
            >
              {isAuthorizingEmail ? (
                <RefreshCw className="w-4 h-4 animate-spin" />
              ) : (
                <Lock className="w-4 h-4" />
              )}
              <span>Authorize Staff Access</span>
            </button>
          </form>

          {/* Open Full Auth Modal */}
          {onOpenAuthModal && (
            <div className="pt-2 border-t border-amber-500/20 text-center space-y-2">
              <button
                type="button"
                onClick={() => onOpenAuthModal('staff', username.includes('@') ? username : '')}
                className="w-full py-2.5 rounded-xl bg-[#122b1d] border border-amber-500/30 text-amber-200 hover:text-white hover:border-amber-400 text-xs font-medium transition-colors flex items-center justify-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#d4af37]" /> Open Universal Email Authorization Screen
              </button>

              <button
                type="button"
                onClick={handleQuickDemoUnlock}
                className="text-xs text-amber-300/80 hover:underline flex items-center justify-center gap-1.5 mx-auto font-medium"
              >
                <span>Quick GM Demo Access (Thakur Mahendra Singh)</span>
              </button>
            </div>
          )}
        </div>
      </div>
    );
  }

  // Filtered guests
  const filteredGuests = guests.filter(g => {
    const q = searchQuery.toLowerCase();
    const matchesSearch = 
      g.givenName.toLowerCase().includes(q) || 
      g.surname.toLowerCase().includes(q) || 
      g.passportNumber.toLowerCase().includes(q) || 
      g.roomNumber.toLowerCase().includes(q);
    const matchesType = guestFilter === 'all' || g.guestType === guestFilter;
    return matchesSearch && matchesType;
  });

  // 2. Staff Dashboard Main Interface
  return (
    <div id="admin-dashboard-root" className="space-y-6">
      {/* Top Banner & Employee Info */}
      <div className="rounded-2xl border border-amber-500/30 bg-gradient-to-r from-[#173826] via-[#12281c] to-[#0d1f15] p-5 shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-black/40 border border-[#d4af37] flex items-center justify-center text-[#d4af37]">
            <Shield className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="font-display font-bold text-xl text-[#f7f4ea]">{adminUser.name}</h2>
              <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-full bg-[#d4af37]/20 text-[#d4af37] border border-[#d4af37]/40">
                {adminUser.role}
              </span>
            </div>
            <p className="text-xs text-amber-200/70">
              Heritique Homestay Central Staff Operations &amp; Government Form C Registry
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadAllData}
            className="p-2 rounded-xl bg-black/30 border border-amber-500/20 text-amber-300 hover:text-white"
            title="Refresh Data"
          >
            <RefreshCw className={`w-4 h-4 ${isLoading ? 'animate-spin' : ''}`} />
          </button>
          <button
            onClick={() => {
              if (onSignOut) onSignOut();
              setAdminUser(null);
            }}
            className="px-3 py-2 rounded-xl bg-red-950/60 border border-red-500/30 text-red-300 text-xs font-medium hover:bg-red-900/60 transition-colors flex items-center gap-1.5"
          >
            <LogOut className="w-3.5 h-3.5" /> Sign Out
          </button>
        </div>
      </div>

      {/* Sync Status Banner */}
      {syncStatus && (
        <div className="p-3.5 rounded-xl bg-emerald-950/90 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2 animate-in fade-in duration-200">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{syncStatus}</span>
        </div>
      )}

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-amber-500/20 pb-2">
        <button
          onClick={() => setActiveTab('occupancy')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'occupancy'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <BedDouble className="w-4 h-4 text-[#e6ca65]" /> Room Occupancy ({HAVELI_ROOMS.filter(r => guests.some(g => g.status !== 'checked_out' && (g.roomNumber?.toLowerCase().includes(r.name.toLowerCase()) || g.roomNumber?.toLowerCase().includes(r.number.toLowerCase())))).length}/{HAVELI_ROOMS.length})
        </button>
        <button
          onClick={() => setActiveTab('guests')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'guests'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <Users className="w-4 h-4" /> Guest Form C Records ({guests.length})
        </button>
        <button
          onClick={() => setActiveTab('expenses')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'expenses'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <DollarSign className="w-4 h-4 text-emerald-400" /> Expenses &amp; Approvals ({expenses.filter(e => e.status === 'pending_approval').length} pending)
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'orders'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <Utensils className="w-4 h-4" /> Kitchen Orders KDS ({orders.filter(o => o.status !== 'delivered').length} active)
        </button>
        <button
          onClick={() => setActiveTab('billing')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'billing'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <Receipt className="w-4 h-4" /> Folios &amp; Revenue
        </button>
        <button
          onClick={() => setActiveTab('chat')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'chat'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <MessageSquare className="w-4 h-4" /> Concierge Desk Messages
        </button>
        <button
          onClick={() => setActiveTab('housekeeping')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'housekeeping'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <Sparkles className="w-4 h-4 text-[#e6ca65]" /> Housekeeping ({housekeepingRequests.filter(r => r.status !== 'completed').length} active)
        </button>
        <button
          onClick={() => setActiveTab('invoices')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'invoices'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <Receipt className="w-4 h-4" /> Invoices &amp; Gateways ({transactions.length})
        </button>
        <button
          onClick={() => setActiveTab('feedback')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'feedback'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <Star className="w-4 h-4 text-amber-300 fill-current" /> Service Feedback ({feedbacks.length})
        </button>
        <button
          onClick={() => setActiveTab('workspace')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
            activeTab === 'workspace'
              ? 'bg-[#d4af37] text-[#0d1f15] shadow-md'
              : 'bg-[#142d20] text-amber-200/70 hover:text-amber-100'
          }`}
        >
          <FileSpreadsheet className="w-4 h-4 text-emerald-400" /> Google Sheets Ledger &amp; Database
        </button>
      </div>

      {/* TAB: CURRENT ROOM OCCUPANCY & DETAILS */}
      {activeTab === 'occupancy' && (() => {
        const activeGuests = guests.filter(g => g.status !== 'checked_out');
        const occupiedRoomsList = HAVELI_ROOMS.filter(room => {
          return activeGuests.some(g => 
            g.roomNumber?.toLowerCase().includes(room.name.toLowerCase()) || 
            g.roomNumber?.toLowerCase().includes(room.number.toLowerCase())
          );
        });
        const occupiedCount = occupiedRoomsList.length;
        const totalRooms = HAVELI_ROOMS.length;
        const vacantCount = totalRooms - occupiedCount;
        const occupancyRate = Math.round((occupiedCount / totalRooms) * 100);
        const todayStr = new Date().toISOString().split('T')[0];
        const departuresToday = activeGuests.filter(g => g.checkOutDate === todayStr).length;
        const arrivalsToday = activeGuests.filter(g => g.checkInDate === todayStr).length;

        const displayedRooms = HAVELI_ROOMS.filter(room => {
          const isOcc = activeGuests.some(g => 
            g.roomNumber?.toLowerCase().includes(room.name.toLowerCase()) || 
            g.roomNumber?.toLowerCase().includes(room.number.toLowerCase())
          );
          if (roomFilter === 'occupied') return isOcc;
          if (roomFilter === 'vacant') return !isOcc;
          return true;
        });

        return (
          <div className="space-y-6">
            {/* Top KPI Metrics Banner */}
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Occupancy Rate</span>
                <p className="font-display font-bold text-2xl text-[#d4af37] mt-1">{occupancyRate}%</p>
                <div className="w-full bg-black/40 h-1.5 rounded-full mt-2 overflow-hidden">
                  <div className="bg-[#d4af37] h-full rounded-full transition-all" style={{ width: `${occupancyRate}%` }} />
                </div>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Occupied Suites</span>
                <p className="font-display font-bold text-2xl text-emerald-400 mt-1">{occupiedCount} <span className="text-xs font-normal text-amber-200/60">/ {totalRooms}</span></p>
                <span className="text-[10px] text-emerald-300/80">Active in-house</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Vacant Suites</span>
                <p className="font-display font-bold text-2xl text-amber-200 mt-1">{vacantCount} <span className="text-xs font-normal text-amber-200/60">Ready</span></p>
                <span className="text-[10px] text-amber-300/70">Sanitized &amp; open</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">In-House Guests</span>
                <p className="font-display font-bold text-2xl text-[#f7f4ea] mt-1">{activeGuests.length}</p>
                <span className="text-[10px] text-amber-200/60">{activeGuests.filter(g => g.guestType === 'domestic').length} Domestic • {activeGuests.filter(g => g.guestType === 'foreign').length} Int'l</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Today's Check-ins</span>
                <p className="font-display font-bold text-2xl text-amber-100 mt-1">{arrivalsToday}</p>
                <span className="text-[10px] text-amber-200/60">Arrivals expected</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Expected Check-outs</span>
                <p className="font-display font-bold text-2xl text-amber-400 mt-1">{departuresToday}</p>
                <span className="text-[10px] text-amber-200/60">Departures today</span>
              </div>
            </div>

            {/* Filter and Action Header */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#12261b] p-3 rounded-2xl border border-amber-500/20">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-amber-200/80 mr-2 flex items-center gap-1.5">
                  <BedDouble className="w-4 h-4 text-[#d4af37]" /> Filter Suites:
                </span>
                <div className="inline-flex rounded-lg bg-black/40 p-1 border border-amber-500/20 text-xs">
                  <button
                    onClick={() => setRoomFilter('all')}
                    className={`px-3 py-1 rounded font-medium transition-all ${roomFilter === 'all' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    All Suites ({totalRooms})
                  </button>
                  <button
                    onClick={() => setRoomFilter('occupied')}
                    className={`px-3 py-1 rounded font-medium transition-all ${roomFilter === 'occupied' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    Occupied ({occupiedCount})
                  </button>
                  <button
                    onClick={() => setRoomFilter('vacant')}
                    className={`px-3 py-1 rounded font-medium transition-all ${roomFilter === 'vacant' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    Vacant ({vacantCount})
                  </button>
                </div>
              </div>

              <div className="text-xs text-amber-200/70 flex items-center gap-3">
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block animate-pulse" /> Occupied</span>
                <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-400/80 inline-block" /> Vacant &amp; Ready</span>
              </div>
            </div>

            {/* Room Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {displayedRooms.map(room => {
                const stayingGuest = activeGuests.find(g => 
                  g.roomNumber?.toLowerCase().includes(room.name.toLowerCase()) || 
                  g.roomNumber?.toLowerCase().includes(room.number.toLowerCase())
                );
                const guestFolio = stayingGuest ? folios.find(f => f.guestId === stayingGuest.id) : null;
                const isOccupied = !!stayingGuest;

                return (
                  <div 
                    key={room.number}
                    className={`rounded-2xl border p-5 transition-all shadow-lg flex flex-col justify-between ${
                      isOccupied 
                        ? 'bg-gradient-to-br from-[#122b1e] via-[#0e2217] to-[#0a1810] border-emerald-500/40 hover:border-emerald-400' 
                        : 'bg-gradient-to-br from-[#111e17] via-[#0d1812] to-[#08100c] border-amber-500/20 hover:border-amber-500/40'
                    }`}
                  >
                    <div>
                      {/* Room Header Banner */}
                      <div className="flex items-start justify-between gap-3 border-b border-amber-500/20 pb-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-display font-bold text-base text-[#f7f4ea] tracking-tight">{room.name}</span>
                            <span className="text-[10px] text-amber-300/80 bg-black/40 px-2 py-0.5 rounded font-mono border border-amber-500/20">{room.number.split(' - ')[0]}</span>
                          </div>
                          <p className="text-xs text-amber-200/60 mt-0.5">{room.type} • {room.floor}</p>
                        </div>
                        <div className="text-right shrink-0">
                          <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider uppercase border ${
                            isOccupied
                              ? 'bg-emerald-950/90 text-emerald-300 border-emerald-500/50 shadow-sm'
                              : 'bg-amber-950/40 text-amber-300 border-amber-500/30'
                          }`}>
                            <span className={`w-1.5 h-1.5 rounded-full ${isOccupied ? 'bg-emerald-400 animate-pulse' : 'bg-amber-400'}`} />
                            {isOccupied ? 'Occupied' : 'Vacant Ready'}
                          </span>
                          <span className="block font-mono text-xs text-amber-100 font-semibold mt-1">₹{room.rate.toLocaleString('en-IN')}<span className="text-[9px] text-amber-200/50 font-normal">/night</span></span>
                        </div>
                      </div>

                      {/* Room Body: Occupied Details or Vacant Info */}
                      {isOccupied && stayingGuest ? (
                        <div className="mt-3.5 space-y-3">
                          {/* Guest Profile Card */}
                          <div className="p-3 rounded-xl bg-black/30 border border-emerald-500/20 space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center gap-2.5">
                                <div className="w-9 h-9 rounded-full bg-gradient-to-br from-[#d4af37] to-[#99791f] text-[#0d1f15] font-bold text-xs flex items-center justify-center shrink-0 border border-amber-200/60 shadow">
                                  {stayingGuest.guestPhoto ? (
                                    <img src={stayingGuest.guestPhoto} alt="" className="w-full h-full rounded-full object-cover" />
                                  ) : (
                                    `${stayingGuest.givenName.charAt(0)}${stayingGuest.surname.charAt(0)}`
                                  )}
                                </div>
                                <div>
                                  <strong className="text-xs text-white block">{stayingGuest.givenName} {stayingGuest.surname}</strong>
                                  <div className="flex items-center gap-1.5 text-[10px] text-amber-200/70">
                                    <span className="font-medium text-emerald-300">{stayingGuest.nationality}</span>
                                    <span>•</span>
                                    <span className="capitalize">{stayingGuest.guestType} Guest</span>
                                  </div>
                                </div>
                              </div>
                              <span className="text-[10px] font-mono text-amber-200/60 bg-black/40 px-2 py-0.5 rounded border border-amber-500/20">
                                {stayingGuest.id}
                              </span>
                            </div>

                            {/* Contact & Verification Grid */}
                            <div className="grid grid-cols-2 gap-2 text-[11px] pt-1 border-t border-amber-500/10">
                              <div>
                                <span className="text-[9px] text-amber-200/50 uppercase block">Phone / Mobile</span>
                                <span className="text-amber-100 font-mono">{stayingGuest.phone || 'N/A'}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-amber-200/50 uppercase block">Email Address</span>
                                <span className="text-amber-100 truncate block max-w-[140px]">{stayingGuest.email || 'N/A'}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-amber-200/50 uppercase block">Check-in Date</span>
                                <span className="text-amber-100 font-medium">{stayingGuest.checkInDate}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-amber-200/50 uppercase block">Expected Check-out</span>
                                <span className="text-amber-100 font-medium">{stayingGuest.checkOutDate}</span>
                              </div>
                              <div>
                                <span className="text-[9px] text-amber-200/50 uppercase block">ID Proof / Form C</span>
                                <span className="text-emerald-400 font-semibold flex items-center gap-1">
                                  <ShieldCheck className="w-3 h-3" />
                                  {stayingGuest.passportNumber ? `Passport: ${stayingGuest.passportNumber}` : 'Govt ID Logged'}
                                </span>
                              </div>
                              <div>
                                <span className="text-[9px] text-amber-200/50 uppercase block">Stay Folio Balance</span>
                                <span className="text-[#d4af37] font-bold font-mono">
                                  ₹{guestFolio ? (guestFolio.balanceDue || 0).toLocaleString('en-IN') : '0'}
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ) : (
                        <div className="mt-3.5 p-3 rounded-xl bg-black/20 border border-amber-500/10 space-y-2 text-xs">
                          <div className="flex items-center justify-between text-amber-200/70">
                            <span>Capacity: <strong className="text-amber-100">{room.capacity}</strong></span>
                            <span className="text-emerald-400 text-[10px] font-semibold flex items-center gap-1">
                              <CheckCircle className="w-3 h-3" /> Sanitized
                            </span>
                          </div>
                          <p className="text-[11px] text-amber-200/60 leading-relaxed italic">
                            {room.features}
                          </p>
                          <div className="text-[10px] text-amber-300/80 pt-1">
                            Available for immediate domestic walk-in or advance booking.
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Card Actions Footer */}
                    <div className="pt-3 mt-3 border-t border-amber-500/15 flex items-center justify-between gap-2 text-xs">
                      {isOccupied && stayingGuest ? (
                        <>
                          <button
                            onClick={() => {
                              setSelectedGuestForFormC(stayingGuest);
                              setIsFormCOpen(true);
                            }}
                            className="px-2.5 py-1.5 rounded-lg bg-[#1a3826] text-amber-200 hover:bg-[#234b33] border border-amber-500/30 text-[11px] font-medium flex items-center gap-1 transition-all"
                          >
                            <FileText className="w-3 h-3" /> Guest Details
                          </button>
                          <button
                            onClick={() => setActiveTab('billing')}
                            className="px-2.5 py-1.5 rounded-lg bg-[#142d20] text-amber-200 hover:bg-[#1f422f] border border-amber-500/30 text-[11px] font-medium flex items-center gap-1 transition-all"
                          >
                            <Receipt className="w-3 h-3" /> Folio
                          </button>
                          <button
                            onClick={() => handleCheckoutGuest(stayingGuest.id)}
                            className="px-2.5 py-1.5 rounded-lg bg-red-950/70 text-red-300 hover:bg-red-900/80 border border-red-500/30 text-[11px] font-medium flex items-center gap-1 transition-all ml-auto"
                          >
                            <LogOut className="w-3 h-3" /> Check Out
                          </button>
                        </>
                      ) : (
                        <div className="w-full flex items-center justify-between text-[11px] text-amber-200/60">
                          <span>Ready for guest allocation</span>
                          <span className="text-[#d4af37] font-semibold">100% Prepared</span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })()}

      {/* TAB: EXPENSES & ACCOUNTS APPROVAL */}
      {activeTab === 'expenses' && (() => {
        const approvedTotal = expenses.filter(e => e.status === 'approved').reduce((acc, curr) => acc + curr.amount, 0);
        const pendingTotal = expenses.filter(e => e.status === 'pending_approval').reduce((acc, curr) => acc + curr.amount, 0);
        const rejectedTotal = expenses.filter(e => e.status === 'rejected').reduce((acc, curr) => acc + curr.amount, 0);
        const todayStr = new Date().toISOString().split('T')[0];
        const todaySpend = expenses.filter(e => e.date === todayStr && e.status === 'approved').reduce((acc, curr) => acc + curr.amount, 0);

        const displayedExpenses = expenses.filter(exp => {
          if (expenseFilter === 'pending') return exp.status === 'pending_approval';
          if (expenseFilter === 'approved') return exp.status === 'approved';
          if (expenseFilter === 'rejected') return exp.status === 'rejected';
          return true;
        });

        return (
          <div className="space-y-6">
            {/* Expense Metric Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Approved Expenses</span>
                <p className="font-display font-bold text-2xl text-emerald-400 mt-1">₹{approvedTotal.toLocaleString('en-IN')}</p>
                <span className="text-[10px] text-emerald-300/80">{expenses.filter(e => e.status === 'approved').length} cleared entries</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Pending Approvals</span>
                <p className="font-display font-bold text-2xl text-amber-300 mt-1">₹{pendingTotal.toLocaleString('en-IN')}</p>
                <span className="text-[10px] text-amber-200/70">{expenses.filter(e => e.status === 'pending_approval').length} awaiting admin review</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Today's Cleared Spend</span>
                <p className="font-display font-bold text-2xl text-[#d4af37] mt-1">₹{todaySpend.toLocaleString('en-IN')}</p>
                <span className="text-[10px] text-amber-200/60">Disbursed today</span>
              </div>

              <div className="bg-[#12261b] border border-amber-500/20 rounded-2xl p-4">
                <span className="text-[10px] text-amber-200/60 uppercase tracking-wider block font-semibold">Rejected Claims</span>
                <p className="font-display font-bold text-2xl text-red-400 mt-1">₹{rejectedTotal.toLocaleString('en-IN')}</p>
                <span className="text-[10px] text-red-300/70">{expenses.filter(e => e.status === 'rejected').length} claims declined</span>
              </div>
            </div>

            {/* Action Header: Filter + Record New Expense */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#12261b] p-3 rounded-2xl border border-amber-500/20">
              <div className="flex items-center gap-2">
                <span className="text-xs font-semibold text-amber-200/80 mr-2 flex items-center gap-1.5">
                  <DollarSign className="w-4 h-4 text-emerald-400" /> Status:
                </span>
                <div className="inline-flex rounded-lg bg-black/40 p-1 border border-amber-500/20 text-xs">
                  <button
                    onClick={() => setExpenseFilter('all')}
                    className={`px-3 py-1 rounded font-medium transition-all ${expenseFilter === 'all' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    All ({expenses.length})
                  </button>
                  <button
                    onClick={() => setExpenseFilter('pending')}
                    className={`px-3 py-1 rounded font-medium transition-all ${expenseFilter === 'pending' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    Pending ({expenses.filter(e => e.status === 'pending_approval').length})
                  </button>
                  <button
                    onClick={() => setExpenseFilter('approved')}
                    className={`px-3 py-1 rounded font-medium transition-all ${expenseFilter === 'approved' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    Approved ({expenses.filter(e => e.status === 'approved').length})
                  </button>
                  <button
                    onClick={() => setExpenseFilter('rejected')}
                    className={`px-3 py-1 rounded font-medium transition-all ${expenseFilter === 'rejected' ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70 hover:text-white'}`}
                  >
                    Rejected ({expenses.filter(e => e.status === 'rejected').length})
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
                <button
                  onClick={() => setIsExpenseModalOpen(true)}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b38f2a] text-[#0d1f15] font-bold text-xs shadow-md hover:brightness-105 transition-all flex items-center gap-1.5"
                >
                  <PlusCircle className="w-4 h-4" /> Record New Expense
                </button>
              </div>
            </div>

            {/* Expenses Table */}
            <div className="rounded-2xl border border-amber-500/20 overflow-hidden bg-[#0d1f15] shadow-xl">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-amber-100">
                  <thead className="bg-[#173826] text-amber-200/80 border-b border-amber-500/20 font-medium">
                    <tr>
                      <th className="py-3 px-4">Expense ID &amp; Date</th>
                      <th className="py-3 px-4">Title &amp; Notes</th>
                      <th className="py-3 px-4">Category</th>
                      <th className="py-3 px-4">Payment Method</th>
                      <th className="py-3 px-4">Submitted By</th>
                      <th className="py-3 px-4 text-right">Amount (₹)</th>
                      <th className="py-3 px-4 text-center">Status</th>
                      <th className="py-3 px-4 text-center">Approval Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-500/10">
                    {displayedExpenses.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="py-8 text-center text-amber-200/50 italic">
                          No expenses found in this category. Click &quot;Record New Expense&quot; to log staff bills.
                        </td>
                      </tr>
                    ) : (
                      displayedExpenses.map(exp => (
                        <tr key={exp.id} className="hover:bg-black/20 transition-colors">
                          <td className="py-3 px-4">
                            <span className="font-mono font-bold text-[#d4af37] block">{exp.id}</span>
                            <span className="text-[10px] text-amber-200/60 font-medium">{exp.date}</span>
                          </td>
                          <td className="py-3 px-4 max-w-xs">
                            <strong className="text-white block font-medium">{exp.title}</strong>
                            {exp.notes && (
                              <p className="text-[11px] text-amber-200/60 truncate mt-0.5">{exp.notes}</p>
                            )}
                            {exp.rejectionReason && exp.status === 'rejected' && (
                              <p className="text-[10px] text-red-300 italic mt-0.5">Reason: {exp.rejectionReason}</p>
                            )}
                          </td>
                          <td className="py-3 px-4">
                            <span className="text-[10px] font-semibold px-2 py-0.5 rounded bg-black/40 border border-amber-500/20 text-amber-200">
                              {exp.category}
                            </span>
                          </td>
                          <td className="py-3 px-4 text-amber-200/80 font-medium text-[11px]">
                            {exp.paymentMethod}
                          </td>
                          <td className="py-3 px-4 text-amber-200/70 text-[11px]">
                            <span className="block font-medium text-amber-100">{exp.submittedBy}</span>
                            <span className="text-[9px] text-amber-200/50">{new Date(exp.submittedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </td>
                          <td className="py-3 px-4 text-right font-bold text-white font-mono text-sm">
                            ₹{exp.amount.toLocaleString('en-IN')}
                          </td>
                          <td className="py-3 px-4 text-center">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider border ${
                              exp.status === 'approved' 
                                ? 'bg-emerald-950 text-emerald-300 border-emerald-500/40' 
                                : exp.status === 'rejected'
                                  ? 'bg-red-950 text-red-300 border-red-500/40'
                                  : 'bg-amber-950/80 text-amber-300 border-amber-500/40 animate-pulse'
                            }`}>
                              {exp.status === 'approved' && <CheckCircle className="w-3 h-3 text-emerald-400" />}
                              {exp.status === 'rejected' && <XCircle className="w-3 h-3 text-red-400" />}
                              {exp.status === 'pending_approval' && <Clock className="w-3 h-3 text-amber-400" />}
                              {exp.status.replace('_', ' ')}
                            </span>
                            {exp.approvedBy && (
                              <span className="block text-[9px] text-amber-200/50 mt-0.5">by {exp.approvedBy}</span>
                            )}
                          </td>
                          <td className="py-3 px-4 text-center">
                            {exp.status === 'pending_approval' ? (
                              <div className="flex items-center justify-center gap-1.5">
                                <button
                                  onClick={() => handleApproveExpense(exp.id)}
                                  className="px-2.5 py-1 rounded-lg bg-emerald-900/80 text-emerald-200 hover:bg-emerald-800 text-[11px] font-bold border border-emerald-500/40 transition-all flex items-center gap-1"
                                  title="Approve this expense"
                                >
                                  <Check className="w-3.5 h-3.5" /> Approve
                                </button>
                                <button
                                  onClick={() => {
                                    setRejectionModalId(exp.id);
                                    setRejectionReasonText('');
                                  }}
                                  className="px-2.5 py-1 rounded-lg bg-red-950 text-red-300 hover:bg-red-900 text-[11px] font-bold border border-red-500/40 transition-all flex items-center gap-1"
                                  title="Reject this expense"
                                >
                                  <X className="w-3.5 h-3.5" /> Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-[11px] text-amber-200/40 italic">
                                Actioned
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Modal: Record New Expense */}
            {isExpenseModalOpen && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
                <div className="bg-[#0e2418] border border-amber-500/30 rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden text-[#f7f4ea]">
                  <div className="bg-gradient-to-r from-[#173a27] via-[#1b432e] to-[#0f281b] border-b border-amber-500/20 p-5 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="w-9 h-9 rounded-xl bg-[#265239] border border-amber-400/50 flex items-center justify-center text-[#d4af37]">
                        <DollarSign className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-display font-bold text-base text-[#f7f4ea]">Record Staff Expense Claim</h4>
                        <p className="text-[10px] text-amber-200/70">Submit bill/voucher for management verification</p>
                      </div>
                    </div>
                    <button
                      onClick={() => setIsExpenseModalOpen(false)}
                      className="p-1 rounded-lg text-amber-200/60 hover:text-white"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>

                  <form onSubmit={handleCreateExpenseSubmit} className="p-5 space-y-4 text-xs">
                    <div>
                      <label className="block text-amber-200/80 mb-1 font-semibold">Expense Title / Item Description *</label>
                      <input
                        type="text"
                        required
                        value={newExpenseTitle}
                        onChange={e => setNewExpenseTitle(e.target.value)}
                        placeholder="e.g. Fresh milk & curd from Johari Bazar dairy"
                        className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3.5 py-2 text-amber-100 placeholder:text-amber-200/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-amber-200/80 mb-1 font-semibold">Expense Category *</label>
                        <select
                          value={newExpenseCategory}
                          onChange={e => setNewExpenseCategory(e.target.value as any)}
                          className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                        >
                          <option value="Kitchen & Groceries">Kitchen &amp; Groceries</option>
                          <option value="Linen & Laundry">Linen &amp; Laundry</option>
                          <option value="Utilities & Power">Utilities &amp; Power</option>
                          <option value="Maintenance & Repair">Maintenance &amp; Repair</option>
                          <option value="Staff Wages">Staff Wages</option>
                          <option value="Govt & Taxes">Govt &amp; Taxes</option>
                          <option value="Marketing & Travel">Marketing &amp; Travel</option>
                          <option value="Other">Other</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-amber-200/80 mb-1 font-semibold">Amount (₹) *</label>
                        <input
                          type="number"
                          min="1"
                          required
                          value={newExpenseAmount}
                          onChange={e => setNewExpenseAmount(e.target.value ? Number(e.target.value) : '')}
                          placeholder="Amount in Rupees"
                          className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3.5 py-2 text-amber-100 font-mono font-bold placeholder:text-amber-200/30 focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-amber-200/80 mb-1 font-semibold">Expense Date *</label>
                        <input
                          type="date"
                          required
                          value={newExpenseDate}
                          onChange={e => setNewExpenseDate(e.target.value)}
                          className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-amber-200/80 mb-1 font-semibold">Payment Method *</label>
                        <select
                          value={newExpensePaymentMethod}
                          onChange={e => setNewExpensePaymentMethod(e.target.value as any)}
                          className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3 py-2 text-amber-100 focus:border-[#d4af37] focus:outline-none"
                        >
                          <option value="UPI / Bank">UPI / Bank</option>
                          <option value="Cash">Cash</option>
                          <option value="Card">Card</option>
                          <option value="Vendor Credit">Vendor Credit</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="block text-amber-200/80 mb-1 font-semibold">Notes / Vendor Receipt Details</label>
                      <textarea
                        rows={2}
                        value={newExpenseNotes}
                        onChange={e => setNewExpenseNotes(e.target.value)}
                        placeholder="Mention receipt number, shop name, or staff remarks..."
                        className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] px-3.5 py-2 text-amber-100 placeholder:text-amber-200/30 focus:border-[#d4af37] focus:outline-none text-xs"
                      />
                    </div>

                    <div className="pt-2 flex items-center justify-end gap-2 border-t border-amber-500/20">
                      <button
                        type="button"
                        onClick={() => setIsExpenseModalOpen(false)}
                        className="px-4 py-2 rounded-xl bg-black/40 text-amber-200/70 hover:text-white"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={isSubmittingExpense}
                        className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#b38f2a] text-[#0d1f15] font-bold shadow hover:brightness-105 transition-all disabled:opacity-50"
                      >
                        {isSubmittingExpense ? 'Submitting...' : 'Submit for Approval'}
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            )}

            {/* Modal: Reject Reason */}
            {rejectionModalId && (
              <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
                <div className="bg-[#0e2418] border border-red-500/40 rounded-3xl w-full max-w-md shadow-2xl p-6 text-[#f7f4ea] space-y-4">
                  <div className="flex items-center gap-2 text-red-400">
                    <AlertTriangle className="w-5 h-5 shrink-0" />
                    <h4 className="font-display font-bold text-base">Reject Expense Claim</h4>
                  </div>
                  <p className="text-xs text-amber-200/70">
                    Please provide a reason for declining this staff expense voucher. The submitter will see this explanation.
                  </p>
                  <div>
                    <label className="block text-[11px] text-amber-200/80 mb-1 font-semibold">Rejection Reason</label>
                    <textarea
                      rows={3}
                      value={rejectionReasonText}
                      onChange={e => setRejectionReasonText(e.target.value)}
                      placeholder="e.g. Receipt voucher missing, personal item, or amount mismatch..."
                      className="w-full rounded-xl border border-red-500/30 bg-[#0a1810] px-3.5 py-2 text-amber-100 placeholder:text-amber-200/30 focus:border-red-400 focus:outline-none text-xs"
                    />
                  </div>
                  <div className="flex items-center justify-end gap-2 pt-2 border-t border-amber-500/20">
                    <button
                      type="button"
                      onClick={() => setRejectionModalId(null)}
                      className="px-4 py-2 rounded-xl bg-black/40 text-amber-200/70 hover:text-white text-xs"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleRejectExpenseConfirm}
                      className="px-5 py-2 rounded-xl bg-red-800 text-white font-bold text-xs hover:bg-red-700 transition-all shadow"
                    >
                      Confirm Rejection
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* TAB 1: GUESTS & FORM C REGISTRY */}
      {activeTab === 'guests' && (
        <div className="space-y-4">
          {/* Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#12261b] p-3 rounded-2xl border border-amber-500/20">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-amber-200/40 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search by name, passport, room..."
                className="w-full rounded-xl border border-amber-500/20 bg-[#0a1810] pl-9 pr-3 py-1.5 text-xs text-amber-100 placeholder:text-amber-200/40 focus:border-[#d4af37] focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-between sm:justify-start">
              <div className="inline-flex rounded-lg bg-black/40 p-1 border border-amber-500/20 text-xs">
                {(['all', 'foreign', 'domestic'] as const).map(tab => (
                  <button
                    key={tab}
                    onClick={() => setGuestFilter(tab)}
                    className={`px-3 py-1 rounded capitalize ${guestFilter === tab ? 'bg-[#d4af37] text-black font-bold' : 'text-amber-200/70'}`}
                  >
                    {tab}
                  </button>
                ))}
              </div>
              <button
                onClick={handleExportCSV}
                className="px-3 py-1.5 rounded-lg bg-[#1a3826] border border-amber-500/30 text-amber-200 text-xs font-medium hover:bg-[#234b33] flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" /> CSV Register
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="rounded-2xl border border-amber-500/30 bg-[#12261b] overflow-hidden shadow-xl text-xs">
            <table className="w-full text-left">
              <thead className="bg-[#173826] text-amber-200/80 border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Guest &amp; Photo</th>
                  <th className="p-3">Nationality &amp; Type</th>
                  <th className="p-3">Passport / Visa</th>
                  <th className="p-3">Assigned Suite</th>
                  <th className="p-3">Stay Dates</th>
                  <th className="p-3">Govt Status</th>
                  <th className="p-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10 bg-[#0d1f15]">
                {filteredGuests.map(guest => (
                  <tr key={guest.id} className="hover:bg-[#142d20]/50 transition-colors">
                    <td className="p-3 flex items-center gap-2.5">
                      {guest.guestPhoto ? (
                        <img src={guest.guestPhoto} alt="Guest" className="w-9 h-9 rounded-full object-cover border border-[#d4af37]" />
                      ) : (
                        <div className="w-9 h-9 rounded-full bg-[#1b3a29] border border-amber-500/30 flex items-center justify-center text-amber-300 font-bold">
                          {guest.givenName.charAt(0)}
                        </div>
                      )}
                      <div>
                        <p className="font-semibold text-amber-100">{guest.givenName} {guest.surname}</p>
                        <span className="text-[10px] text-amber-200/50 font-mono">{guest.id}</span>
                      </div>
                    </td>
                    <td className="p-3">
                      <p className="text-amber-100 font-medium">{guest.nationality}</p>
                      <span className={`text-[9px] uppercase font-bold px-1.5 py-0.5 rounded ${
                        guest.guestType === 'foreign' ? 'bg-amber-950 text-amber-300 border border-amber-500/30' : 'bg-blue-950 text-blue-300'
                      }`}>
                        {guest.guestType}
                      </span>
                    </td>
                    <td className="p-3 font-mono">
                      <p className="text-amber-200 font-bold">{guest.passportNumber}</p>
                      <span className="text-[10px] text-amber-200/50">Visa: {guest.visaNumber || 'N/A'}</span>
                    </td>
                    <td className="p-3">
                      <span className="font-medium text-amber-100">{guest.roomNumber}</span>
                    </td>
                    <td className="p-3 text-[11px] text-amber-200/80">
                      <div>In: {guest.checkInDate}</div>
                      <div>Out: {guest.checkOutDate}</div>
                    </td>
                    <td className="p-3">
                      <button
                        onClick={() => handleStatusToggle(guest.id, guest.verificationStatus)}
                        className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                          guest.verificationStatus === 'verified'
                            ? 'bg-emerald-950 border border-emerald-500/40 text-emerald-300'
                            : 'bg-amber-950 border border-amber-500/40 text-amber-300'
                        }`}
                        title="Click to toggle verification status"
                      >
                        <CheckCircle2 className="w-3 h-3" />
                        {guest.verificationStatus}
                      </button>
                    </td>
                    <td className="p-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          onClick={() => {
                            setSelectedGuestForFormC(guest);
                            setIsFormCOpen(true);
                          }}
                          className="p-1.5 rounded-lg bg-[#1a3826] text-amber-300 hover:bg-[#234b33] border border-amber-500/20"
                          title="View & Print Official Form C"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        {guest.status === 'active' && (
                          <button
                            onClick={() => handleCheckoutGuest(guest.id)}
                            className="px-2 py-1 rounded-lg bg-black/40 text-amber-200/80 border border-amber-500/20 hover:text-white text-[10px]"
                          >
                            Check-out
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: KITCHEN DISPLAY SYSTEM */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-[#12261b] p-4 rounded-2xl border border-amber-500/20">
            <h3 className="font-display font-semibold text-base text-amber-100 flex items-center gap-2">
              <Utensils className="w-5 h-5 text-[#d4af37]" /> Live Haveli Kitchen Display System (KDS)
            </h3>
            <span className="text-xs text-amber-200/60 font-mono">{orders.length} total orders</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {orders.map(order => (
              <div key={order.id} className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-4 space-y-3 shadow-lg flex flex-col justify-between">
                <div className="space-y-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <span className="font-mono text-xs font-bold text-[#d4af37]">{order.id}</span>
                      <h4 className="font-display font-semibold text-sm text-[#f7f4ea]">{order.roomNumber}</h4>
                      <p className="text-[11px] text-amber-200/60">{order.guestName}</p>
                    </div>
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                      order.status === 'delivered' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' :
                      order.status === 'preparing' ? 'bg-amber-950 text-amber-300 border border-amber-500/30 animate-pulse' :
                      'bg-blue-950 text-blue-300'
                    }`}>
                      {order.status.replace('_', ' ')}
                    </span>
                  </div>

                  {/* Items list */}
                  <div className="bg-black/30 p-2.5 rounded-xl border border-amber-500/10 space-y-1 text-xs">
                    {order.items.map((item, i) => (
                      <div key={i} className="flex justify-between text-amber-100">
                        <span><strong>{item.quantity}x</strong> {item.name}</span>
                        <span className="font-mono text-amber-200/70">₹{item.price * item.quantity}</span>
                      </div>
                    ))}
                  </div>

                  {order.specialInstructions && (
                    <p className="text-[11px] text-amber-300/80 bg-amber-950/30 p-2 rounded-lg border border-amber-500/20 italic">
                      " {order.specialInstructions} "
                    </p>
                  )}
                </div>

                {/* Status action buttons */}
                <div className="pt-2 border-t border-amber-500/10 flex items-center justify-between gap-2">
                  {order.status === 'placed' && (
                    <button
                      onClick={() => handleOrderStatus(order.id, 'preparing')}
                      className="w-full py-2 rounded-xl bg-amber-500 text-black font-semibold text-xs hover:bg-amber-400"
                    >
                      Accept &amp; Mark Preparing
                    </button>
                  )}
                  {order.status === 'preparing' && (
                    <button
                      onClick={() => handleOrderStatus(order.id, 'on_the_way')}
                      className="w-full py-2 rounded-xl bg-blue-500 text-white font-semibold text-xs hover:bg-blue-400"
                    >
                      Dispatch with Bearer
                    </button>
                  )}
                  {order.status === 'on_the_way' && (
                    <button
                      onClick={() => handleOrderStatus(order.id, 'delivered')}
                      className="w-full py-2 rounded-xl bg-emerald-500 text-black font-semibold text-xs hover:bg-emerald-400"
                    >
                      Confirm Delivered
                    </button>
                  )}
                  {order.status === 'delivered' && (
                    <span className="text-[11px] text-emerald-400 flex items-center gap-1 font-semibold mx-auto">
                      <Check className="w-3.5 h-3.5" /> Delivered to Suite
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: BILLING & FOLIOS */}
      {activeTab === 'billing' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[#12261b] border border-amber-500/20">
              <span className="text-xs text-amber-200/60 uppercase">Total Revenue Billed</span>
              <p className="font-display font-bold text-2xl text-[#d4af37] mt-1">
                ₹{folios.reduce((a, b) => a + b.grandTotal, 0).toLocaleString('en-IN')}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-[#12261b] border border-amber-500/20">
              <span className="text-xs text-amber-200/60 uppercase">Payments Collected</span>
              <p className="font-display font-bold text-2xl text-emerald-400 mt-1">
                ₹{folios.reduce((a, b) => a + b.paidAmount, 0).toLocaleString('en-IN')}
              </p>
            </div>
            <div className="p-4 rounded-2xl bg-[#12261b] border border-amber-500/20">
              <span className="text-xs text-amber-200/60 uppercase">Outstanding Balance</span>
              <p className="font-display font-bold text-2xl text-amber-300 mt-1">
                ₹{folios.reduce((a, b) => a + b.balanceDue, 0).toLocaleString('en-IN')}
              </p>
            </div>
          </div>

          <div className="rounded-2xl border border-amber-500/30 bg-[#12261b] overflow-hidden shadow-xl text-xs">
            <table className="w-full text-left">
              <thead className="bg-[#173826] text-amber-200/80 border-b border-amber-500/20">
                <tr>
                  <th className="p-3">Folio ID &amp; Room</th>
                  <th className="p-3">Guest</th>
                  <th className="p-3">Room Stay</th>
                  <th className="p-3">Dining Orders</th>
                  <th className="p-3">Grand Total</th>
                  <th className="p-3">Paid</th>
                  <th className="p-3">Balance Due</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10 bg-[#0d1f15]">
                {folios.map(f => (
                  <tr key={f.id} className="hover:bg-[#142d20]/50">
                    <td className="p-3 font-mono font-semibold text-[#d4af37]">
                      {f.id}
                      <p className="text-[10px] text-amber-200/50">{f.roomNumber}</p>
                    </td>
                    <td className="p-3 text-amber-100 font-medium">{f.guestName}</td>
                    <td className="p-3 text-amber-200/80">₹{f.roomTotal.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-amber-200/80">₹{f.foodOrdersTotal.toLocaleString('en-IN')}</td>
                    <td className="p-3 font-bold text-white">₹{f.grandTotal.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-emerald-400 font-medium">₹{f.paidAmount.toLocaleString('en-IN')}</td>
                    <td className="p-3 font-bold text-amber-300">₹{f.balanceDue.toLocaleString('en-IN')}</td>
                    <td className="p-3">
                      <span className={`text-[9px] uppercase font-bold px-2 py-0.5 rounded-full ${
                        f.status === 'paid' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' : 'bg-amber-950 text-amber-300'
                      }`}>
                        {f.status.replace('_', ' ')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: CONCIERGE CHAT INBOX */}
      {activeTab === 'chat' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-[560px]">
          {/* Guest Threads Sidebar */}
          <div className="rounded-2xl border border-amber-500/20 bg-[#12261b] p-3 space-y-2 overflow-y-auto">
            <h4 className="text-xs font-semibold text-amber-300 uppercase tracking-wider px-2 py-1">
              Active Guest Suites
            </h4>
            {guests.map(g => (
              <div
                key={g.id}
                onClick={() => setSelectedChatGuestId(g.id)}
                className={`p-2.5 rounded-xl cursor-pointer transition-colors text-xs ${
                  selectedChatGuestId === g.id
                    ? 'bg-[#1b3a29] border border-[#d4af37] text-white'
                    : 'hover:bg-black/30 text-amber-200/70'
                }`}
              >
                <div className="flex justify-between items-start">
                  <span className="font-semibold text-amber-100">{g.givenName} {g.surname}</span>
                </div>
                <p className="text-[10px] text-amber-200/50 mt-0.5">{g.roomNumber}</p>
              </div>
            ))}
          </div>

          {/* Conversation & Reply Box */}
          <div className="md:col-span-2 rounded-2xl border border-amber-500/30 bg-[#0d1f15] flex flex-col justify-between overflow-hidden shadow-2xl">
            <div className="p-3.5 bg-[#142b1f] border-b border-amber-500/20 flex justify-between items-center text-xs">
              <span className="font-semibold text-amber-100">
                Live Conversation with {guests.find(g => g.id === selectedChatGuestId)?.givenName || 'Guest'}
              </span>
              <span className="text-[10px] text-[#d4af37] font-mono">
                {guests.find(g => g.id === selectedChatGuestId)?.roomNumber}
              </span>
            </div>

            <div className="flex-1 p-4 space-y-3 overflow-y-auto text-xs">
              {chats
                .filter(c => c.guestId === selectedChatGuestId)
                .map(msg => (
                  <div
                    key={msg.id}
                    className={`flex flex-col ${msg.sender === 'staff' ? 'items-end' : 'items-start'}`}
                  >
                    <span className="text-[9px] text-amber-200/50 mb-0.5">
                      {msg.senderName} • {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <div
                      className={`max-w-[80%] p-2.5 rounded-xl ${
                        msg.sender === 'staff'
                          ? 'bg-[#d4af37] text-[#0d1f15] font-semibold'
                          : 'bg-[#173826] text-amber-100 border border-amber-500/20'
                      }`}
                    >
                      {msg.message}
                    </div>
                  </div>
                ))}
            </div>

            <div className="p-3 bg-[#142b1f] border-t border-amber-500/20 flex items-center gap-2">
              <input
                type="text"
                value={staffReplyText}
                onChange={e => setStaffReplyText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter') handleSendStaffReply(); }}
                placeholder="Type reply as Thakur Mahendra Singh..."
                className="flex-1 rounded-xl border border-amber-500/30 bg-[#0a1810] px-3 py-2 text-xs text-amber-100 focus:border-[#d4af37] focus:outline-none"
              />
              <button
                onClick={handleSendStaffReply}
                className="px-4 py-2 rounded-xl bg-[#d4af37] text-[#0d1f15] font-semibold text-xs hover:bg-[#e4bf4d]"
              >
                Send Reply
              </button>
            </div>
          </div>
        </div>
      )}

      {/* TAB: HOUSEKEEPING MANAGEMENT */}
      {activeTab === 'housekeeping' && (
        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
            <div>
              <h3 className="font-display font-bold text-lg text-amber-100 flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#d4af37]" />
                <span>Palace Housekeeping &amp; Suite Care Queue</span>
              </h3>
              <p className="text-xs text-amber-200/60">
                Floor captains and attendants: Track and update guest cleaning requests in real time.
              </p>
            </div>
            <button
              onClick={loadAllData}
              className="text-xs px-3 py-1.5 rounded-xl bg-[#142d20] border border-amber-500/30 text-amber-200 hover:text-white flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Refresh Queue
            </button>
          </div>

          {housekeepingRequests.length === 0 ? (
            <div className="py-12 text-center text-amber-200/60 text-xs bg-[#12261b] rounded-2xl border border-amber-500/20">
              No active housekeeping requests currently logged.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {housekeepingRequests.map(req => {
                const isPending = req.status === 'pending';
                const isInProgress = req.status === 'in_progress';
                const isCompleted = req.status === 'completed';

                return (
                  <div 
                    key={req.id}
                    className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-5 space-y-3 shadow-lg"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <strong className="text-sm text-amber-100 font-semibold">{req.roomNumber}</strong>
                          <span className="text-[10px] font-mono text-[#d4af37] bg-black/40 px-2 py-0.5 rounded border border-amber-500/20">
                            #{req.id}
                          </span>
                        </div>
                        <p className="text-xs text-amber-200/70 font-medium">{req.guestName}</p>
                      </div>

                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                        isCompleted 
                          ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40' 
                          : isInProgress 
                          ? 'bg-amber-950 text-amber-300 border border-amber-500/40 animate-pulse' 
                          : 'bg-black/40 text-amber-200/80 border border-amber-500/20'
                      }`}>
                        {req.status.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="bg-black/30 p-3 rounded-xl border border-amber-500/10 space-y-1.5 text-xs">
                      <div className="flex justify-between text-amber-200/80">
                        <span className="text-amber-200/50">Request Type:</span>
                        <strong className="text-[#d4af37]">{req.requestType}</strong>
                      </div>
                      <div className="flex justify-between text-amber-200/80">
                        <span className="text-amber-200/50">Requested Time:</span>
                        <span>{req.preferredTime}</span>
                      </div>
                      {req.notes && (
                        <div className="pt-1 text-[11px] text-amber-200/70 italic border-t border-amber-500/10">
                          "{req.notes}"
                        </div>
                      )}
                      <div className="flex justify-between text-[10px] text-amber-200/40 pt-1">
                        <span>Logged: {new Date(req.requestedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        {req.assignedStaff && <span>Staff: {req.assignedStaff}</span>}
                      </div>
                    </div>

                    {/* Staff Actions */}
                    <div className="flex items-center gap-2 pt-1 border-t border-amber-500/10">
                      {isPending && (
                        <button
                          onClick={async () => {
                            await updateHousekeepingStatus(req.id, 'in_progress', 'Raju (Floor Captain)');
                            loadAllData();
                          }}
                          className="flex-1 py-1.5 px-3 rounded-xl bg-[#1b3a29] border border-amber-500/30 text-amber-200 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                        >
                          <Clock className="w-3.5 h-3.5 text-amber-400" />
                          <span>Accept &amp; Start</span>
                        </button>
                      )}

                      {!isCompleted && (
                        <button
                          onClick={async () => {
                            await updateHousekeepingStatus(req.id, 'completed', adminUser.name || 'Floor Staff');
                            loadAllData();
                          }}
                          className="flex-1 py-1.5 px-3 rounded-xl bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] text-xs font-bold flex items-center justify-center gap-1.5 shadow"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Mark Completed</span>
                        </button>
                      )}

                      {isCompleted && (
                        <span className="text-emerald-400 text-xs font-semibold flex items-center gap-1 py-1">
                          <CheckCircle2 className="w-4 h-4" /> Service fulfilled
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB: INVOICES & PAYMENT GATEWAY TRANSACTIONS */}
      {activeTab === 'invoices' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
            <div>
              <h3 className="font-display font-bold text-lg text-amber-100 flex items-center gap-2">
                <Receipt className="w-5 h-5 text-[#d4af37]" />
                <span>Automated Invoices &amp; Payment Gateway Transactions</span>
              </h3>
              <p className="text-xs text-amber-200/60">
                Real-time transaction settlement records via Stripe Elements, PayPal Express, and UPI.
              </p>
            </div>
            <button
              onClick={loadAllData}
              className="text-xs px-3 py-1.5 rounded-xl bg-[#142d20] border border-amber-500/30 text-amber-200 hover:text-white flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Refresh Records
            </button>
          </div>

          {/* Revenue KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-[#12261b] border border-amber-500/30">
              <span className="text-[10px] text-amber-200/50 uppercase tracking-wider block">Generated Invoices</span>
              <strong className="text-2xl font-display text-white mt-1 block">{invoices.length}</strong>
              <span className="text-[11px] text-emerald-400">Total volume</span>
            </div>
            <div className="p-4 rounded-2xl bg-[#12261b] border border-amber-500/30">
              <span className="text-[10px] text-amber-200/50 uppercase tracking-wider block">Online Gateway Receipts</span>
              <strong className="text-2xl font-display text-[#d4af37] mt-1 block">
                ₹{transactions.reduce((acc, t) => acc + t.amount, 0).toLocaleString('en-IN')}
              </strong>
              <span className="text-[11px] text-emerald-400">{transactions.length} online transactions settled</span>
            </div>
            <div className="p-4 rounded-2xl bg-[#12261b] border border-amber-500/30">
              <span className="text-[10px] text-amber-200/50 uppercase tracking-wider block">Connected Gateways</span>
              <strong className="text-lg font-display text-white mt-1 block">Stripe • PayPal • UPI</strong>
              <span className="text-[10px] text-emerald-400">256-bit SSL PCI-DSS Level 1</span>
            </div>
          </div>

          {/* Transactions Log Table */}
          <div className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-5 space-y-4">
            <h4 className="text-xs font-bold text-amber-300 uppercase tracking-wider">
              Recent Online Gateway Transaction Records
            </h4>

            {transactions.length === 0 ? (
              <div className="py-8 text-center text-xs text-amber-200/50">
                No online payment transactions processed yet. Guests can settle invoices online via Stripe, PayPal, or UPI.
              </div>
            ) : (
              <div className="overflow-x-auto text-xs">
                <table className="w-full text-left">
                  <thead className="bg-[#173826] text-amber-200/80 border-b border-amber-500/20">
                    <tr>
                      <th className="py-2.5 px-3">Txn ID / Gateway</th>
                      <th className="py-2.5 px-3">Guest &amp; Suite</th>
                      <th className="py-2.5 px-3">Method Details</th>
                      <th className="py-2.5 px-3">Date &amp; Time</th>
                      <th className="py-2.5 px-3 text-right">Amount (₹)</th>
                      <th className="py-2.5 px-3 text-center">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-amber-500/10 bg-[#0d1f15]">
                    {transactions.map(txn => (
                      <tr key={txn.id}>
                        <td className="py-2.5 px-3">
                          <p className="font-mono font-bold text-[#d4af37]">{txn.id}</p>
                          <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                            {txn.gateway} Gateway
                          </span>
                        </td>
                        <td className="py-2.5 px-3">
                          <strong className="text-amber-100 block">{txn.guestName}</strong>
                          <span className="text-[10px] text-amber-200/50">{txn.roomNumber}</span>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-[11px] text-amber-200/70">
                          {txn.paymentMethodDetails?.cardLast4 && `Card ending in •••• ${txn.paymentMethodDetails.cardLast4}`}
                          {txn.paymentMethodDetails?.paypalEmail && txn.paymentMethodDetails.paypalEmail}
                          {txn.paymentMethodDetails?.upiId && txn.paymentMethodDetails.upiId}
                        </td>
                        <td className="py-2.5 px-3 text-amber-200/60 text-[11px]">
                          {new Date(txn.timestamp).toLocaleString()}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-white text-sm">
                          ₹{txn.amount.toLocaleString('en-IN')}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950 text-emerald-300 border border-emerald-500/40">
                            {txn.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB: POST-SERVICE FEEDBACK & GUEST REVIEWS */}
      {activeTab === 'feedback' && (() => {
        const diningFbs = feedbacks.filter(f => f.category === 'dining');
        const hkFbs = feedbacks.filter(f => f.category === 'housekeeping');
        const stayFbs = feedbacks.filter(f => f.category === 'stay_checkout');

        const avgRating = feedbacks.length > 0 
          ? (feedbacks.reduce((sum, f) => sum + f.rating, 0) / feedbacks.length).toFixed(1) 
          : '5.0';
        const avgDining = diningFbs.length > 0 
          ? (diningFbs.reduce((sum, f) => sum + f.rating, 0) / diningFbs.length).toFixed(1) 
          : '5.0';
        const avgHk = hkFbs.length > 0 
          ? (hkFbs.reduce((sum, f) => sum + f.rating, 0) / hkFbs.length).toFixed(1) 
          : '5.0';
        const npsList = feedbacks.filter(f => f.npsScore !== undefined);
        const avgNps = npsList.length > 0 
          ? (npsList.reduce((sum, f) => sum + (f.npsScore || 0), 0) / npsList.length).toFixed(1) 
          : '10.0';

        const displayedFeedbacks = feedbacks.filter(f => {
          if (feedbackCategoryFilter !== 'all' && f.category !== feedbackCategoryFilter) return false;
          return true;
        });

        return (
          <div className="space-y-6">
            {/* Top Overview & Google Sheet Sync Banner */}
            <div className="p-6 rounded-3xl bg-gradient-to-br from-[#0c2417] via-[#123120] to-[#08180f] border-2 border-amber-500/30 text-white shadow-xl">
              <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-5">
                <div className="space-y-2">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-[#d4af37] text-xs font-semibold">
                    <Star className="w-3.5 h-3.5 fill-current" />
                    <span>Post-Service Feedback Module • Google Sheet Integrated</span>
                  </div>
                  <h2 className="text-xl sm:text-2xl font-serif font-bold text-white tracking-wide">
                    Guest Service Feedback &amp; Rajputana Hospitality Ratings
                  </h2>
                  <p className="text-xs text-amber-200/80 max-w-2xl leading-relaxed">
                    Review live ratings submitted by in-house and departed guests for individual dining orders,
                    room housekeeping services, and complete post-checkout stay experiences. Automatically recorded 
                    in your Google Sheet under the <strong className="text-white underline decoration-amber-400">'Service Feedback'</strong> tab.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0 w-full sm:w-auto">
                  <button
                    type="button"
                    onClick={handleSyncFeedbackToGoogleSheet}
                    disabled={isSyncingFeedbackSheet}
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#e6ca65] text-[#0d1f15] font-bold text-xs hover:brightness-110 active:scale-95 transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
                  >
                    {isSyncingFeedbackSheet ? (
                      <RefreshCw className="w-4 h-4 animate-spin" />
                    ) : (
                      <FileSpreadsheet className="w-4 h-4" />
                    )}
                    <span>Sync with 'Service Feedback' Sheet</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('workspace')}
                    className="px-3.5 py-2.5 rounded-xl bg-[#142d20] border border-amber-500/30 text-amber-200 hover:text-white hover:border-amber-400 text-xs font-semibold transition-colors flex items-center justify-center gap-1.5"
                  >
                    <span>Open Master Ledger</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {feedbackSyncMsg && (
                <div className="mt-4 p-3 rounded-xl bg-black/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>{feedbackSyncMsg}</span>
                </div>
              )}
            </div>

            {/* Metrics Row */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-[#0d1f15] border border-amber-500/20 text-white">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">Overall Guest Rating</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-2xl font-bold text-[#d4af37] font-serif">{avgRating}</span>
                  <span className="text-xs text-amber-200/60">/ 5.0</span>
                </div>
                <div className="flex items-center gap-0.5 text-amber-400 mt-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <Star key={star} className="w-3.5 h-3.5 fill-current" />
                  ))}
                  <span className="text-[10px] text-amber-200/60 ml-1.5">({feedbacks.length} reviews)</span>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-[#0d1f15] border border-amber-500/20 text-white">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">In-Room Dining</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-2xl font-bold text-amber-300 font-serif">{avgDining}</span>
                  <span className="text-xs text-amber-200/60">/ 5.0</span>
                </div>
                <p className="text-[10px] text-amber-200/60 mt-1 flex items-center gap-1">
                  <Utensils className="w-3 h-3 text-amber-400" />
                  <span>{diningFbs.length} meal orders evaluated</span>
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#0d1f15] border border-amber-500/20 text-white">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">Housekeeping &amp; Linen</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-2xl font-bold text-emerald-400 font-serif">{avgHk}</span>
                  <span className="text-xs text-amber-200/60">/ 5.0</span>
                </div>
                <p className="text-[10px] text-amber-200/60 mt-1 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-emerald-400" />
                  <span>{hkFbs.length} room services evaluated</span>
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#0d1f15] border border-amber-500/20 text-white">
                <span className="text-[10px] font-bold uppercase tracking-wider text-amber-300/70">Checkout Stay NPS</span>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-2xl font-bold text-purple-300 font-serif">{avgNps}</span>
                  <span className="text-xs text-amber-200/60">/ 10</span>
                </div>
                <p className="text-[10px] text-amber-200/60 mt-1 flex items-center gap-1">
                  <ThumbsUp className="w-3 h-3 text-purple-400" />
                  <span>{stayFbs.length} checkout reviews recorded</span>
                </p>
              </div>
            </div>

            {/* Filter Pills */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d1f15] p-3 rounded-2xl border border-amber-500/20">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-amber-200/70 font-medium mr-1">Filter Reviews:</span>
                <button
                  onClick={() => setFeedbackCategoryFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    feedbackCategoryFilter === 'all'
                      ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                      : 'bg-[#142d20] text-amber-200/70 hover:text-white'
                  }`}
                >
                  All Categories ({feedbacks.length})
                </button>
                <button
                  onClick={() => setFeedbackCategoryFilter('dining')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    feedbackCategoryFilter === 'dining'
                      ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                      : 'bg-[#142d20] text-amber-200/70 hover:text-white'
                  }`}
                >
                  Dining Orders ({diningFbs.length})
                </button>
                <button
                  onClick={() => setFeedbackCategoryFilter('housekeeping')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    feedbackCategoryFilter === 'housekeeping'
                      ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                      : 'bg-[#142d20] text-amber-200/70 hover:text-white'
                  }`}
                >
                  Housekeeping ({hkFbs.length})
                </button>
                <button
                  onClick={() => setFeedbackCategoryFilter('stay_checkout')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                    feedbackCategoryFilter === 'stay_checkout'
                      ? 'bg-[#d4af37] text-[#0d1f15] shadow'
                      : 'bg-[#142d20] text-amber-200/70 hover:text-white'
                  }`}
                >
                  Stay &amp; Checkout ({stayFbs.length})
                </button>
              </div>

              <div className="text-[11px] text-amber-200/60 font-mono">
                Sheet tab: <span className="text-emerald-400 font-semibold">'Service Feedback'</span>
              </div>
            </div>

            {/* Feedback Cards List */}
            {displayedFeedbacks.length === 0 ? (
              <div className="p-12 text-center rounded-3xl bg-[#0d1f15] border border-amber-500/20 text-amber-200/60">
                <Star className="w-10 h-10 text-amber-500/30 mx-auto mb-2" />
                <p className="text-sm font-semibold text-white">No feedback records found for this category.</p>
                <p className="text-xs text-amber-200/60 mt-1">Guests can submit ratings from their dining menu, housekeeping log, or checkout invoice.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {displayedFeedbacks.map(fb => (
                  <div
                    key={fb.id}
                    className="p-5 rounded-2xl bg-[#0d1f15] border border-amber-500/20 hover:border-amber-500/40 transition-all text-white space-y-4 shadow-lg flex flex-col justify-between"
                  >
                    <div className="space-y-3">
                      {/* Top Header */}
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-sm text-white">{fb.guestName}</span>
                            <span className="text-[10px] bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono">
                              {fb.roomNumber}
                            </span>
                          </div>
                          <p className="text-[11px] text-amber-200/60 mt-0.5">
                            {new Date(fb.createdAt).toLocaleDateString(undefined, { dateStyle: 'medium' })} • {new Date(fb.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            fb.category === 'dining'
                              ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                              : fb.category === 'housekeeping'
                              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                              : 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                          }`}>
                            {fb.category === 'dining' ? 'In-Room Dining' : fb.category === 'housekeeping' ? 'Housekeeping' : 'Stay Experience'}
                          </span>
                          <span className="text-[10px] text-amber-200/50 font-mono">
                            {fb.id}
                          </span>
                        </div>
                      </div>

                      {/* Target reference */}
                      <div className="p-2 rounded-xl bg-black/30 border border-amber-500/10 text-xs text-amber-200/80 flex items-center justify-between">
                        <span className="text-amber-300/90 font-medium truncate max-w-[280px]">
                          {fb.targetTitle || 'Homestay Service'}
                        </span>
                        {fb.targetId && (
                          <span className="text-[10px] font-mono bg-black/40 text-amber-200/60 px-1.5 py-0.5 rounded border border-amber-500/20">
                            {fb.targetId}
                          </span>
                        )}
                      </div>

                      {/* Ratings Breakdown */}
                      <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#122b1d] border border-amber-500/20">
                        <div className="flex items-center gap-1.5 text-amber-400">
                          <div className="flex">
                            {[1, 2, 3, 4, 5].map(st => (
                              <Star
                                key={st}
                                className={`w-4 h-4 ${st <= fb.rating ? 'fill-current' : 'text-gray-600'}`}
                              />
                            ))}
                          </div>
                          <span className="text-xs font-bold text-white ml-1">({fb.rating}/5)</span>
                        </div>

                        <div className="flex items-center gap-3 text-[11px] text-amber-200/70">
                          {fb.qualityRating && <span>Quality: <strong className="text-white">{fb.qualityRating}★</strong></span>}
                          {fb.speedRating && <span>Speed: <strong className="text-white">{fb.speedRating}★</strong></span>}
                          {fb.courtesyRating && <span>Courtesy: <strong className="text-white">{fb.courtesyRating}★</strong></span>}
                        </div>
                      </div>

                      {/* Guest Comments */}
                      {fb.comments && (
                        <div className="p-3 rounded-xl bg-black/20 border border-amber-500/10 text-xs italic text-amber-100/90 leading-relaxed">
                          "{fb.comments}"
                        </div>
                      )}

                      {/* Tags */}
                      {fb.tags && fb.tags.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 pt-1">
                          {fb.tags.map((tag, tIdx) => (
                            <span
                              key={tIdx}
                              className="text-[10px] bg-[#1a3a28] text-amber-200 px-2 py-0.5 rounded-lg border border-amber-500/20"
                            >
                              ✓ {tag}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Bottom Status & Follow-up Actions */}
                    <div className="pt-3 border-t border-amber-500/10 flex items-center justify-between gap-3 text-xs">
                      <div className="flex items-center gap-2">
                        {fb.npsScore !== undefined && (
                          <span className="text-[11px] font-bold text-purple-300 bg-purple-950/60 px-2 py-0.5 rounded border border-purple-500/30">
                            NPS: {fb.npsScore}/10
                          </span>
                        )}
                        <span className="text-[10px] bg-emerald-950/60 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1 font-mono">
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span>Sheet: 'Service Feedback'</span>
                        </span>
                      </div>

                      {/* Follow-up status dropdown */}
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] text-amber-200/50">Follow-up:</span>
                        <select
                          value={fb.followUpStatus || 'thanked'}
                          onChange={e => handleUpdateFeedbackStatus(fb.id, e.target.value as any)}
                          className="bg-[#08170f] border border-amber-500/30 rounded-lg px-2 py-1 text-[11px] text-[#d4af37] font-semibold focus:outline-none"
                        >
                          <option value="thanked">Thanked</option>
                          <option value="acknowledged">Acknowledged</option>
                          <option value="in_review">In Review</option>
                          <option value="resolved">Resolved</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })()}

      {/* TAB 5: GOOGLE SHEETS OPERATIONS LEDGER & CLOUD DATABASE */}
      {activeTab === 'workspace' && (
        <GoogleSheetsLedger
          guests={guests}
          orders={orders}
          housekeeping={housekeepingRequests}
          invoices={invoices}
          onRefreshData={loadAllData}
        />
      )}

      {/* Official Form C Modal */}
      <FormCModal
        guest={selectedGuestForFormC}
        isOpen={isFormCOpen}
        onClose={() => setIsFormCOpen(false)}
      />
    </div>
  );
};
