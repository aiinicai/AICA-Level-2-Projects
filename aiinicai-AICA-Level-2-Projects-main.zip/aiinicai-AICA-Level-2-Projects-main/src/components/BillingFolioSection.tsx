import React, { useState, useEffect } from 'react';
import { 
  Receipt, CreditCard, Download, CheckCircle, Clock, 
  ShieldCheck, Printer, ArrowRight, DollarSign, Sparkles, Lock, Star 
} from 'lucide-react';
import { BillingFolio, GuestRegistration } from '../types';
import { fetchGuestBilling, payBilling } from '../utils/api';
import { InvoiceCheckoutModal } from './InvoiceCheckoutModal';
import { FeedbackModal } from './FeedbackModal';

interface BillingFolioSectionProps {
  currentGuest: GuestRegistration | null;
}

export const BillingFolioSection: React.FC<BillingFolioSectionProps> = ({ currentGuest }) => {
  const [folio, setFolio] = useState<BillingFolio | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [isFeedbackOpen, setIsFeedbackOpen] = useState(false);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payMethod, setPayMethod] = useState<'Card' | 'UPI' | 'Cash'>('Card');
  const [isProcessingPay, setIsProcessingPay] = useState(false);
  const [paySuccessMsg, setPaySuccessMsg] = useState<string | null>(null);

  const guestId = currentGuest?.id || 'GUEST-8021';

  const loadBilling = async () => {
    setIsLoading(true);
    try {
      const data = await fetchGuestBilling(guestId);
      setFolio(data);
      setPayAmount(data.balanceDue);
    } catch (err) {
      console.error('Error fetching billing:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadBilling();
  }, [guestId]);

  const handlePayment = async () => {
    if (payAmount <= 0) return;
    setIsProcessingPay(true);
    try {
      const updated = await payBilling(guestId, payAmount, payMethod);
      setFolio(updated);
      setPaySuccessMsg(`Payment of ₹${payAmount.toLocaleString('en-IN')} recorded successfully.`);
      setIsPayModalOpen(false);
    } catch (err: any) {
      alert(`Payment failed: ${err.message}`);
    } finally {
      setIsProcessingPay(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (isLoading || !folio) {
    return (
      <div className="py-16 text-center text-amber-200/60 text-xs">
        <Receipt className="w-8 h-8 mx-auto mb-2 text-[#d4af37] animate-pulse" />
        Calculating room folio &amp; dining charges...
      </div>
    );
  }

  return (
    <div id="billing-folio-container" className="max-w-3xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-amber-500/20 pb-4">
        <div>
          <span className="text-[10px] font-bold uppercase tracking-widest text-[#d4af37] bg-black/40 px-3 py-1 rounded-full border border-amber-500/20">
            Official Guest Account Statement
          </span>
          <h2 className="font-display font-bold text-2xl sm:text-3xl text-[#f7f4ea] mt-1.5">
            Guest Stay &amp; Dining Folio
          </h2>
          <p className="text-xs text-amber-200/70">
            Heritique Homestay • Room {folio.roomNumber} • Folio #{folio.id}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2 no-print">
          <button
            onClick={() => setIsFeedbackOpen(true)}
            className="px-3 py-2 rounded-xl bg-[#1b3a29] border border-[#d4af37]/60 text-[#d4af37] text-xs font-semibold hover:bg-[#244b36] hover:text-white transition-colors flex items-center gap-1.5"
            title="Rate Your Stay & Homestay Experience"
          >
            <Star className="w-4 h-4 fill-current" />
            <span>Rate Stay</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3 py-2 rounded-xl bg-[#173826] border border-amber-500/30 text-amber-200 text-xs font-semibold hover:bg-[#1f4832] transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" /> Print / PDF
          </button>
          <button
            onClick={() => setIsCheckoutModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#e6ca65] text-[#0d1f15] text-xs font-bold hover:brightness-110 active:scale-95 transition-all flex items-center gap-1.5 shadow-lg"
          >
            <Sparkles className="w-4 h-4" />
            <span>Automated Invoice &amp; Checkout</span>
          </button>
          {folio.balanceDue > 0 && (
            <button
              onClick={() => {
                setPayAmount(folio.balanceDue);
                setIsPayModalOpen(true);
              }}
              className="px-3 py-2 rounded-xl bg-[#1b3a29] border border-amber-500/40 text-amber-200 text-xs font-bold hover:bg-[#234b35] transition-all flex items-center gap-1.5"
            >
              <CreditCard className="w-4 h-4 text-[#d4af37]" /> Quick Settle
            </button>
          )}
        </div>
      </div>

      {/* Express Checkout Callout Banner */}
      <div className="p-4 rounded-2xl bg-gradient-to-r from-[#173826] via-[#1b3a29] to-[#12261b] border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-lg no-print">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#0d1f15] border border-[#d4af37] flex items-center justify-center text-[#d4af37] shrink-0">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <h4 className="font-display font-bold text-sm text-[#f7f4ea] flex items-center gap-1.5">
              <span>Automated Invoice Generation &amp; Digital Checkout</span>
              <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/30">
                Stripe &amp; PayPal Integrated
              </span>
            </h4>
            <p className="text-xs text-amber-200/70">
              Calculate stays, dining orders &amp; departure transfers automatically. Settle online with instant verification.
            </p>
          </div>
        </div>

        <button
          onClick={() => setIsCheckoutModalOpen(true)}
          className="w-full sm:w-auto px-4 py-2 rounded-xl bg-[#d4af37] text-[#0d1f15] text-xs font-bold hover:bg-[#e4bf4d] active:scale-95 transition-all shadow whitespace-nowrap flex items-center justify-center gap-1.5"
        >
          <span>Generate Final Invoice</span> &rarr;
        </button>
      </div>

      {paySuccessMsg && (
        <div className="p-3 rounded-xl bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{paySuccessMsg}</span>
        </div>
      )}

      {/* Official Folio Invoice Card */}
      <div className="rounded-2xl border border-amber-500/30 bg-[#12261b] p-6 shadow-2xl space-y-6">
        {/* Letterhead */}
        <div className="flex justify-between items-start border-b border-amber-500/20 pb-5">
          <div>
            <h3 className="font-display font-bold text-xl text-[#d4af37]">HERITIQUE HOMESTAY</h3>
            <p className="text-[11px] text-amber-200/60">The Grand Rajputana Estate &amp; Heritage Haveli</p>
            <p className="text-[10px] text-amber-200/50">Jaipur - Rajasthan 302001 • Reg: RAJ-TOURISM-HST-1924</p>
          </div>
          <div className="text-right text-xs">
            <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
              folio.status === 'paid'
                ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/40'
                : 'bg-amber-950 text-amber-300 border border-amber-500/40'
            }`}>
              {folio.status === 'paid' ? 'Paid in Full' : 'Active Balance'}
            </span>
            <p className="text-amber-200/60 text-[10px] mt-2">Date: {new Date().toLocaleDateString()}</p>
          </div>
        </div>

        {/* Guest and Stay Info */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs bg-black/30 p-3.5 rounded-xl border border-amber-500/10">
          <div>
            <span className="text-[10px] text-amber-200/50 block">Guest Name</span>
            <span className="font-semibold text-amber-100">{folio.guestName}</span>
          </div>
          <div>
            <span className="text-[10px] text-amber-200/50 block">Assigned Suite</span>
            <span className="font-semibold text-amber-100">{folio.roomNumber}</span>
          </div>
          <div>
            <span className="text-[10px] text-amber-200/50 block">Check-in</span>
            <span className="font-semibold text-amber-100">{folio.checkInDate}</span>
          </div>
          <div>
            <span className="text-[10px] text-amber-200/50 block">Check-out</span>
            <span className="font-semibold text-amber-100">{folio.checkOutDate}</span>
          </div>
        </div>

        {/* Itemized Table */}
        <div className="space-y-3">
          <h4 className="text-xs font-semibold uppercase tracking-wider text-amber-300">
            Itemized Statement of Charges
          </h4>
          <div className="rounded-xl border border-amber-500/20 overflow-hidden text-xs">
            <table className="w-full text-left">
              <thead className="bg-[#173826] text-amber-200/80 border-b border-amber-500/20">
                <tr>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-center">Qty / Nights</th>
                  <th className="py-2.5 px-3 text-right">Unit Rate</th>
                  <th className="py-2.5 px-3 text-right">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-amber-500/10 bg-[#0d1f15]">
                <tr>
                  <td className="py-2.5 px-3">
                    <p className="font-medium text-amber-100">Suite Lodging &amp; Breakfast</p>
                    <span className="text-[10px] text-amber-200/50">{folio.roomNumber}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center text-amber-200/70">{folio.nights} nights</td>
                  <td className="py-2.5 px-3 text-right text-amber-200/70">₹{folio.roomRatePerNight.toLocaleString('en-IN')}</td>
                  <td className="py-2.5 px-3 text-right font-medium text-amber-100">₹{folio.roomTotal.toLocaleString('en-IN')}</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3">
                    <p className="font-medium text-amber-100">In-Room Dining &amp; High Tea</p>
                    <span className="text-[10px] text-amber-200/50">Culinary orders billed to suite</span>
                  </td>
                  <td className="py-2.5 px-3 text-center text-amber-200/70">—</td>
                  <td className="py-2.5 px-3 text-right text-amber-200/70">—</td>
                  <td className="py-2.5 px-3 text-right font-medium text-amber-100">₹{folio.foodOrdersTotal.toLocaleString('en-IN')}</td>
                </tr>
                <tr>
                  <td className="py-2.5 px-3">
                    <p className="font-medium text-amber-100">Heritage Walking Tour &amp; Estate Naturalist</p>
                    <span className="text-[10px] text-amber-200/50">Stepwell excursion &amp; heritage conservation</span>
                  </td>
                  <td className="py-2.5 px-3 text-center text-amber-200/70">1 session</td>
                  <td className="py-2.5 px-3 text-right text-amber-200/70">₹500</td>
                  <td className="py-2.5 px-3 text-right font-medium text-amber-100">₹{folio.experiencesTotal.toLocaleString('en-IN')}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* Totals & Tax calculation */}
        <div className="flex flex-col sm:flex-row justify-between gap-4 pt-2 border-t border-amber-500/20 text-xs">
          <div className="space-y-1 text-amber-200/60 text-[11px] max-w-xs">
            <p><strong>Government Tax Note:</strong> GST levied as per hospitality tariff rules (12% room stay, 5% dining). Includes 5% Heritage Monument Preservation Fund.</p>
            <p>Payment accepted in INR, International Visa/MasterCard, and UPI.</p>
          </div>

          <div className="w-full sm:w-72 space-y-2">
            <div className="flex justify-between text-amber-200/70">
              <span>Subtotal</span>
              <span>₹{(folio.roomTotal + folio.foodOrdersTotal + folio.experiencesTotal).toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-amber-200/70">
              <span>Heritage Conservation (5%)</span>
              <span>₹{folio.conservationLevy.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-amber-200/70">
              <span>Goods &amp; Services Tax (GST 12%)</span>
              <span>₹{folio.taxes.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-amber-500/20">
              <span>Grand Total</span>
              <span className="text-[#d4af37]">₹{folio.grandTotal.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-xs text-emerald-400">
              <span>Payments Received</span>
              <span>- ₹{folio.paidAmount.toLocaleString('en-IN')}</span>
            </div>
            <div className="flex justify-between text-base font-bold text-[#d4af37] bg-black/40 p-2.5 rounded-lg border border-amber-500/30">
              <span>Balance Due</span>
              <span>₹{folio.balanceDue.toLocaleString('en-IN')}</span>
            </div>
          </div>
        </div>

        {/* Payments History */}
        {folio.payments.length > 0 && (
          <div className="pt-2 border-t border-amber-500/20">
            <h5 className="text-[11px] font-semibold text-amber-300 uppercase tracking-wider mb-2">
              Payment Receipts Log
            </h5>
            <div className="space-y-1 text-xs">
              {folio.payments.map((p, idx) => (
                <div key={idx} className="flex justify-between bg-black/20 px-3 py-1.5 rounded text-amber-200/80">
                  <span>{new Date(p.date).toLocaleDateString()} • {p.method} ({p.reference})</span>
                  <span className="font-semibold text-emerald-400">+₹{p.amount.toLocaleString('en-IN')}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Settle Payment Modal */}
      {isPayModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-2xl border border-amber-500/30 bg-[#0d1f15] text-[#f7f4ea] p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center border-b border-amber-500/20 pb-3">
              <h3 className="font-display font-semibold text-lg text-amber-100">Settle Room Balance</h3>
              <button onClick={() => setIsPayModalOpen(false)} className="text-amber-300 hover:text-white text-xs">
                Cancel
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-amber-200/80 mb-1">Amount to Pay (₹)</label>
                <input
                  type="number"
                  value={payAmount}
                  onChange={e => setPayAmount(Number(e.target.value))}
                  max={folio.balanceDue}
                  className="w-full rounded-xl border border-amber-500/30 bg-[#0a1810] px-3.5 py-2.5 text-base font-bold text-[#d4af37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-amber-200/80 mb-1">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Card', 'UPI', 'Cash'] as const).map(method => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPayMethod(method)}
                      className={`py-2 px-3 rounded-lg border text-xs font-semibold ${
                        payMethod === method
                          ? 'border-[#d4af37] bg-[#d4af37] text-[#0d1f15]'
                          : 'border-amber-500/20 bg-black/30 text-amber-200 hover:border-amber-500/40'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <button
              onClick={handlePayment}
              disabled={isProcessingPay || payAmount <= 0}
              className="w-full py-3 rounded-xl font-semibold bg-[#d4af37] text-[#0d1f15] hover:bg-[#e4bf4d] transition-all text-xs flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
            >
              {isProcessingPay ? 'Recording Transaction...' : `Confirm Payment of ₹${payAmount.toLocaleString('en-IN')}`}
            </button>
          </div>
        </div>
      )}

      {/* Automated Invoice & Digital Checkout Modal */}
      <InvoiceCheckoutModal
        isOpen={isCheckoutModalOpen}
        onClose={() => setIsCheckoutModalOpen(false)}
        currentGuest={currentGuest}
        onCheckoutSuccess={() => {
          loadBilling();
        }}
      />

      {/* Post-Service Feedback Modal */}
      <FeedbackModal
        isOpen={isFeedbackOpen}
        onClose={() => setIsFeedbackOpen(false)}
        currentGuest={currentGuest}
        initialCategory="stay_checkout"
        initialTargetId={folio?.id ? `FOLIO-${folio.id}` : 'stay'}
        initialTargetTitle="Heritage Haveli Stay & Dining Folio"
      />
    </div>
  );
};
