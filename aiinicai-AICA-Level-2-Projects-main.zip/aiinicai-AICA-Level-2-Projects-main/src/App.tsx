import React, { useState, useEffect } from 'react';
import { 
  Compass, ClipboardCheck, Utensils, Receipt, MessageSquare, 
  Shield, Download, Wifi, WifiOff, Sparkles, Phone, MapPin, 
  FileText, CheckCircle2, ChevronRight, Menu, X, Mail, UserCheck, 
  LogOut, User, KeyRound
} from 'lucide-react';
import { GuestRegistration, AuthSession, UserRole } from './types';
import { fetchGuests, fetchGuestByEmail } from './utils/api';
import { usePwaInstall } from './hooks/usePwaInstall';
import { PwaInstallModal } from './components/PwaInstallModal';
import { GuestCheckinForm } from './components/GuestCheckinForm';
import { DiningMenuSection } from './components/DiningMenuSection';
import { BillingFolioSection } from './components/BillingFolioSection';
import { ConciergeChat } from './components/ConciergeChat';
import { AdminDashboard } from './components/AdminDashboard';
import { FormCModal } from './components/FormCModal';
import { AuthModal } from './components/AuthModal';
import { HomePage } from './components/HomePage';
import { AboutProperty } from './components/AboutProperty';
import { AiItineraryPlanner } from './components/AiItineraryPlanner';

export default function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'about' | 'checkin' | 'dining' | 'billing' | 'chat' | 'itinerary' | 'admin'>('home');
  const [isCheckedIn, setIsCheckedIn] = useState<boolean>(() => {
    try {
      return localStorage.getItem('heritique_guest_checked_in') === 'true';
    } catch {
      return false;
    }
  });
  const [currentGuest, setCurrentGuest] = useState<GuestRegistration | null>(() => {
    try {
      const saved = localStorage.getItem('heritique_current_guest');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isFormCOpen, setIsFormCOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Universal Email Authorization State
  const [authSession, setAuthSession] = useState<AuthSession | null>(() => {
    try {
      const saved = localStorage.getItem('heritique_auth_session');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [authModalRole, setAuthModalRole] = useState<UserRole>('guest');
  const [authModalSuggestedEmail, setAuthModalSuggestedEmail] = useState('');

  const { isInstallable, isInstalled, promptInstall, isModalOpen, closeModal } = usePwaInstall();

  // Boolean flag: Is the user a checked-in guest?
  // When a guest checks in or is logged in as guest, they must NOT see the staff admin tab or option.
  const isGuestCheckedIn = Boolean(
    (isCheckedIn || currentGuest || authSession?.role === 'guest') &&
    authSession?.role !== 'staff'
  );

  // If a checked-in guest is currently on the admin tab, redirect them to home
  useEffect(() => {
    if (isGuestCheckedIn && activeTab === 'admin') {
      setActiveTab('home');
    }
  }, [isGuestCheckedIn, activeTab]);

  // Save auth session to localStorage and sync active guest
  useEffect(() => {
    if (authSession) {
      localStorage.setItem('heritique_auth_session', JSON.stringify(authSession));
      if (authSession.role === 'guest') {
        fetchGuestByEmail(authSession.email).then(g => {
          if (g) {
            setCurrentGuest(g);
            setIsCheckedIn(true);
            try {
              localStorage.setItem('heritique_current_guest', JSON.stringify(g));
              localStorage.setItem('heritique_guest_checked_in', 'true');
            } catch (e) {
              console.error(e);
            }
          }
        }).catch(err => console.error('Error fetching guest by auth email:', err));
      }
    } else {
      localStorage.removeItem('heritique_auth_session');
    }
  }, [authSession]);

  // Monitor online/offline status for PWA
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Fetch active guest if authSession is guest and not already in state
  useEffect(() => {
    const loadGuestByAuth = async () => {
      try {
        if (authSession?.role === 'guest' && !currentGuest) {
          const matched = await fetchGuestByEmail(authSession.email);
          if (matched) {
            setCurrentGuest(matched);
            setIsCheckedIn(true);
            localStorage.setItem('heritique_guest_checked_in', 'true');
            localStorage.setItem('heritique_current_guest', JSON.stringify(matched));
          }
        }
      } catch (err) {
        console.error('Error fetching guest for auth session:', err);
      }
    };
    loadGuestByAuth();
  }, [authSession]);

  const handleCheckinSuccess = (guest: GuestRegistration) => {
    setCurrentGuest(guest);
    setIsCheckedIn(true);
    try {
      localStorage.setItem('heritique_guest_checked_in', 'true');
      localStorage.setItem('heritique_current_guest', JSON.stringify(guest));
    } catch (e) {
      console.error('Failed saving guest checkin state:', e);
    }

    // Automatically authorize session with guest email if not already staff
    if (!authSession || authSession.role === 'guest') {
      const session: AuthSession = {
        email: guest.email,
        role: 'guest',
        displayName: `${guest.givenName} ${guest.surname}`,
        guestId: guest.id,
        roomNumber: guest.roomNumber,
        token: `guest_${guest.id}_${Date.now()}`,
        authorizedAt: new Date().toISOString()
      };
      setAuthSession(session);
    }
  };

  const handleAuthSuccess = async (session: AuthSession) => {
    setAuthSession(session);
    if (session.role === 'staff') {
      setIsCheckedIn(false);
      localStorage.removeItem('heritique_guest_checked_in');
      setActiveTab('admin');
    } else if (session.role === 'guest') {
      try {
        const guestData = await fetchGuestByEmail(session.email);
        if (guestData) {
          setCurrentGuest(guestData);
          setIsCheckedIn(true);
          localStorage.setItem('heritique_guest_checked_in', 'true');
          localStorage.setItem('heritique_current_guest', JSON.stringify(guestData));
        }
      } catch (err) {
        console.error('Error finding guest by email on auth:', err);
      }
    }
  };

  const handleSignOut = () => {
    setAuthSession(null);
    setIsCheckedIn(false);
    setCurrentGuest(null);
    try {
      localStorage.removeItem('heritique_auth_session');
      localStorage.removeItem('heritique_guest_checked_in');
      localStorage.removeItem('heritique_current_guest');
    } catch (e) {
      console.error(e);
    }
    setActiveTab('home');
  };

  const openAuthModal = (role: UserRole = 'guest', suggestedEmail: string = '') => {
    setAuthModalRole(role);
    setAuthModalSuggestedEmail(suggestedEmail || (authSession ? authSession.email : ''));
    setIsAuthModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#fbf8f2] text-[#241c16] flex flex-col font-sans selection:bg-[#d4af37] selection:text-[#241c16]">
      {/* Top Heritage Header & Nav Bar */}
      <header className="sticky top-0 z-40 bg-[#fffdfa]/95 backdrop-blur-md border-b border-[#d8c5aa] shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-20">
            {/* Brand Logo & Name */}
            <div 
              onClick={() => setActiveTab('home')}
              className="cursor-pointer flex items-center gap-3 group select-none"
            >
              <div className="w-11 h-11 rounded-2xl bg-gradient-to-br from-[#8a2517] via-[#9e2d1d] to-[#6d1c10] border border-[#d4af37]/60 p-2 flex items-center justify-center text-[#f5d998] shadow-md group-hover:scale-105 transition-all">
                <Compass className="w-6 h-6 group-hover:rotate-45 transition-transform duration-500" />
              </div>
              <div>
                <h1 className="font-display font-bold text-xl sm:text-2xl text-[#241c16] tracking-tight flex items-center gap-2">
                  HERITIQUE
                  <span className="text-[10px] font-sans font-semibold uppercase tracking-widest text-[#8a2517] px-2 py-0.5 rounded bg-[#8a2517]/10 border border-[#8a2517]/20">
                    Homestay
                  </span>
                </h1>
                <p className="text-[10px] sm:text-[11px] text-[#755943] font-serif italic tracking-wide">
                  The Royal Haveli &amp; Heritage Check-in
                </p>
              </div>
            </div>

            {/* Desktop Navigation Tabs */}
            <nav className="hidden xl:flex items-center gap-1 bg-[#f4ece1] p-1.5 rounded-2xl border border-[#d8c5aa] text-xs shadow-inner">
              <button
                onClick={() => setActiveTab('home')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'home'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <Compass className="w-3.5 h-3.5" /> Home
              </button>

              <button
                onClick={() => setActiveTab('about')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'about'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5" /> About Property
              </button>

              <button
                onClick={() => setActiveTab('checkin')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'checkin'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <ClipboardCheck className="w-3.5 h-3.5" /> Guest Check-in
              </button>

              <button
                onClick={() => setActiveTab('dining')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'dining'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <Utensils className="w-3.5 h-3.5" /> Room Dining
              </button>

              <button
                onClick={() => setActiveTab('billing')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'billing'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <Receipt className="w-3.5 h-3.5" /> Stay Folio
              </button>

              <button
                onClick={() => setActiveTab('chat')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'chat'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <MessageSquare className="w-3.5 h-3.5" /> Concierge
              </button>

              <button
                onClick={() => setActiveTab('itinerary')}
                className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                  activeTab === 'itinerary'
                    ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                    : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <Compass className="w-3.5 h-3.5 text-[#c59b27]" /> AI Itinerary
              </button>

              {/* Staff Admin is strictly hidden for checked-in guests */}
              {!isGuestCheckedIn && (
                <button
                  onClick={() => setActiveTab('admin')}
                  className={`px-3 py-2 rounded-xl font-medium transition-all flex items-center gap-1.5 ${
                    activeTab === 'admin'
                      ? 'bg-[#8a2517] text-white font-bold shadow-sm'
                      : 'text-[#5c493a] hover:text-[#241c16] hover:bg-[#ebdcc8]/50'
                  }`}
                >
                  <Shield className="w-3.5 h-3.5 text-[#24613b]" /> Staff Admin
                </button>
              )}
            </nav>

            {/* Right Action Icons: Auth Status + PWA Install + Online Status */}
            <div className="flex items-center gap-2">
              {/* Universal Email Authorization Button / Profile Chip */}
              {authSession ? (
                <div className="flex items-center gap-1.5 bg-[#f4ece1] p-1 rounded-2xl border border-[#d8c5aa]">
                  <button
                    onClick={() => openAuthModal(authSession.role, authSession.email)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                      authSession.role === 'staff'
                        ? 'bg-[#8a2517] text-white shadow-sm'
                        : 'bg-[#fffdfa] border border-[#d8c5aa] text-[#241c16]'
                    }`}
                    title={`Signed in as ${authSession.role}: ${authSession.email}. Click to manage or switch account.`}
                  >
                    {authSession.role === 'staff' ? (
                      <Shield className="w-3.5 h-3.5 text-[#f5d998]" />
                    ) : (
                      <UserCheck className="w-3.5 h-3.5 text-[#24613b]" />
                    )}
                    <span className="hidden md:inline max-w-[110px] truncate">
                      {authSession.displayName || authSession.email.split('@')[0]}
                    </span>
                    <span className={`text-[9px] uppercase font-bold px-1.5 py-0.2 rounded ${
                      authSession.role === 'staff'
                        ? 'bg-[#f5d998] text-[#8a2517]'
                        : 'bg-[#24613b] text-white'
                    }`}>
                      {authSession.role}
                    </span>
                  </button>

                  <button
                    onClick={handleSignOut}
                    className="p-1.5 rounded-xl text-[#755943] hover:text-red-700 hover:bg-red-50 transition-colors"
                    title="Sign Out / Switch User"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => openAuthModal('guest')}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#8a2517] text-white hover:bg-[#a32e1d] text-xs font-bold shadow transition-all active:scale-95"
                  title="Authorize with any email ID for guest or staff"
                >
                  <Mail className="w-3.5 h-3.5 text-[#f5d998]" />
                  <span className="hidden sm:inline">Sign In / Sign Up</span>
                  <span className="sm:hidden">Sign In</span>
                </button>
              )}

              {/* PWA Install Button */}
              <button
                id="pwa-install-menu-btn"
                onClick={promptInstall}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] text-[#5c493a] hover:text-[#241c16] text-xs font-semibold shadow-sm transition-all"
                title={isInstalled ? 'App already installed on device' : 'Install Heritique App for Desktop & Mobile offline access'}
              >
                <Download className="w-3.5 h-3.5 text-[#8a2517]" />
                <span className="hidden 2xl:inline">{isInstalled ? 'Installed' : 'Install App'}</span>
              </button>

              {/* Network Status Badge */}
              <div 
                className={`p-2 rounded-xl border text-xs flex items-center gap-1.5 ${
                  isOnline 
                    ? 'border-emerald-200 bg-emerald-50 text-emerald-800' 
                    : 'border-amber-200 bg-amber-50 text-amber-800'
                }`}
                title={isOnline ? 'Online • Live Cloud Synchronization' : 'Offline Mode • Local PWA Cache active'}
              >
                {isOnline ? <Wifi className="w-3.5 h-3.5 text-emerald-600" /> : <WifiOff className="w-3.5 h-3.5 text-amber-600" />}
              </div>

              {/* Mobile Menu Hamburger */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="xl:hidden p-2 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] text-[#5c493a] hover:text-[#241c16]"
              >
                {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Collapsible Navigation */}
          {isMobileMenuOpen && (
            <div className="xl:hidden py-3 border-t border-[#d8c5aa] space-y-1.5">
              {/* Mobile Auth Button */}
              <div className="p-2 rounded-xl bg-[#f4ece1] border border-[#d8c5aa] mb-2">
                {authSession ? (
                  <div className="flex items-center justify-between">
                    <div className="text-xs">
                      <span className="text-[#755943] block text-[10px] uppercase font-bold">Authorized Account</span>
                      <strong className="text-[#241c16]">{authSession.displayName}</strong>
                      <span className="text-[#755943] block font-mono text-[10px]">{authSession.email} ({authSession.role})</span>
                    </div>
                    <button
                      onClick={() => { handleSignOut(); setIsMobileMenuOpen(false); }}
                      className="px-2.5 py-1 rounded-lg bg-red-100 border border-red-200 text-red-700 text-xs font-medium"
                    >
                      Sign Out
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => { openAuthModal('guest'); setIsMobileMenuOpen(false); }}
                    className="w-full py-2 rounded-lg bg-[#8a2517] text-white font-bold text-xs flex items-center justify-center gap-1.5"
                  >
                    <Mail className="w-4 h-4 text-[#f5d998]" /> Sign In / Sign Up with Email
                  </button>
                )}
              </div>

              <button
                onClick={() => { setActiveTab('home'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'home' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><Compass className="w-4 h-4" /> Home</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              <button
                onClick={() => { setActiveTab('about'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'about' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><Sparkles className="w-4 h-4" /> About Property</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              <button
                onClick={() => { setActiveTab('checkin'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'checkin' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><ClipboardCheck className="w-4 h-4" /> Guest Check-in &amp; OCR</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              <button
                onClick={() => { setActiveTab('dining'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'dining' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><Utensils className="w-4 h-4" /> In-Room Dining Menu</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              <button
                onClick={() => { setActiveTab('billing'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'billing' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><Receipt className="w-4 h-4" /> Guest Stay Folio &amp; Bill</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              <button
                onClick={() => { setActiveTab('chat'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'chat' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><MessageSquare className="w-4 h-4" /> Concierge Live Chat</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              <button
                onClick={() => { setActiveTab('itinerary'); setIsMobileMenuOpen(false); }}
                className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                  activeTab === 'itinerary' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                }`}
              >
                <span className="flex items-center gap-2"><Compass className="w-4 h-4 text-[#c59b27]" /> AI Rajasthan Itinerary Planner</span>
                <ChevronRight className="w-4 h-4 opacity-60" />
              </button>

              {!isGuestCheckedIn && (
                <button
                  onClick={() => { setActiveTab('admin'); setIsMobileMenuOpen(false); }}
                  className={`w-full px-4 py-2.5 rounded-xl text-left text-xs font-semibold flex items-center justify-between ${
                    activeTab === 'admin' ? 'bg-[#8a2517] text-white' : 'text-[#5c493a] hover:bg-[#ebdcc8]/50'
                  }`}
                >
                  <span className="flex items-center gap-2"><Shield className="w-4 h-4 text-[#24613b]" /> Staff &amp; Admin Dashboard</span>
                  <ChevronRight className="w-4 h-4 opacity-60" />
                </button>
              )}

              <button
                onClick={() => { promptInstall(); setIsMobileMenuOpen(false); }}
                className="w-full px-4 py-2.5 rounded-xl bg-[#fffdfa] text-[#5c493a] text-xs font-semibold flex items-center justify-center gap-2 border border-[#d8c5aa] mt-2"
              >
                <Download className="w-4 h-4 text-[#8a2517]" /> Install App on Mobile / Desktop
              </button>
            </div>
          )}
        </div>
      </header>

      {/* Guest Context Bar */}
      {currentGuest && (
        <div className="bg-[#f4ece1] border-b border-[#d8c5aa] px-4 py-2.5 text-xs text-[#5c493a]">
          <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse" />
              <span>Checked-in Guest:</span>
              <strong className="text-[#241c16]">{currentGuest.givenName} {currentGuest.surname}</strong>
              <span className="text-[#755943] hidden sm:inline">({currentGuest.nationality})</span>
              <span className="bg-[#fffdfa] text-[#8a2517] font-semibold px-2 py-0.5 rounded border border-[#d8c5aa]">
                {currentGuest.roomNumber}
              </span>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsFormCOpen(true)}
                className="text-[#8a2517] hover:underline text-[11px] font-semibold flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5" /> View Form C Record
              </button>
              <span className="text-[#c5b59f]">|</span>
              <span className="text-[11px] text-[#755943] font-mono">
                Folio ID: {currentGuest.id}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* Main View Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'home' && (
          <HomePage
            onNavigateTab={tab => setActiveTab(tab)}
            authSession={authSession}
            onOpenAuthModal={openAuthModal}
            onSignOut={handleSignOut}
            currentGuest={currentGuest}
            onAuthSuccess={handleAuthSuccess}
            onAuthorized={handleAuthSuccess}
          />
        )}

        {activeTab === 'about' && (
          <AboutProperty
            onNavigateTab={tab => setActiveTab(tab)}
          />
        )}

        {activeTab === 'checkin' && (
          <GuestCheckinForm
            onCheckinSuccess={handleCheckinSuccess}
            onNavigateTab={tab => setActiveTab(tab)}
            authSession={authSession}
            onOpenAuthModal={openAuthModal}
          />
        )}

        {activeTab === 'dining' && (
          <DiningMenuSection
            currentGuest={currentGuest}
            onNavigateTab={tab => setActiveTab(tab)}
            authSession={authSession}
            onOpenAuthModal={openAuthModal}
          />
        )}

        {activeTab === 'billing' && (
          <BillingFolioSection
            currentGuest={currentGuest}
          />
        )}

        {activeTab === 'chat' && (
          <ConciergeChat
            currentGuest={currentGuest}
          />
        )}

        {activeTab === 'itinerary' && (
          <AiItineraryPlanner
            authSession={authSession}
            isOpen={true}
          />
        )}

        {activeTab === 'admin' && !isGuestCheckedIn && (
          <AdminDashboard 
            authSession={authSession}
            onOpenAuthModal={openAuthModal}
            onSignOut={handleSignOut}
            onStaffAuthorize={handleAuthSuccess}
            onAuthorized={handleAuthSuccess}
            onAuthSuccess={handleAuthSuccess}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-[#d8c5aa] bg-[#f4ece1] text-[#695646] text-xs py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-4">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-[#d8c5aa]/60 pb-6">
            <div>
              <h4 className="font-display font-semibold text-sm text-[#8a2517]">HERITIQUE HAVELI HOMESTAY</h4>
              <p className="text-[11px] text-[#755943] mt-0.5">
                Authentic Rajputana Haveli • Built 1924 • Heritage Hospitality &amp; Architectural Conservation
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5 text-[#8a2517]" /> Shekhawati, Rajasthan</span>
              <span className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5 text-[#8a2517]" /> +91 141 289 1924</span>
              <span className="flex items-center gap-1.5"><Wifi className="w-3.5 h-3.5 text-[#8a2517]" /> Haveli-Guest-WiFi (High-Speed)</span>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-[10px] text-[#8a7664]">
            <p>
              Statutory compliance maintained under Foreigners Registration Act &amp; Government Form C Rules.
            </p>
            <p className="flex items-center gap-2">
              <span>Full PWA Offline Support Enabled</span>
              <span>•</span>
              <button 
                onClick={promptInstall}
                className="text-[#8a2517] font-semibold hover:underline"
              >
                Install to Home Screen
              </button>
            </p>
          </div>
        </div>
      </footer>

      {/* PWA Install Guidance Modal */}
      <PwaInstallModal
        isOpen={isModalOpen}
        onClose={closeModal}
      />

      {/* Form C Full Government Record Viewer Modal */}
      <FormCModal
        guest={currentGuest}
        isOpen={isFormCOpen}
        onClose={() => setIsFormCOpen(false)}
      />

      {/* Universal Email Authorization Modal for Guest & Staff */}
      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        onAuthorized={(session) => handleAuthSuccess(session)}
        onAuthSuccess={handleAuthSuccess}
        initialRole={authModalRole}
        suggestedEmail={authModalSuggestedEmail}
        initialEmail={authModalSuggestedEmail}
      />
    </div>
  );
}
