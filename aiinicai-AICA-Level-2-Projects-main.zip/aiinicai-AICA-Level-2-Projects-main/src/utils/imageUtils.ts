/**
 * Utilities for optimizing, resizing, and normalizing camera photos on mobile & desktop
 * before sending to OCR and backend storage.
 */

export async function optimizeImageForOcr(
  input: File | Blob | string,
  maxDimension = 2048,
  quality = 0.88
): Promise<string> {
  return new Promise((resolve, reject) => {
    // If already a data string
    if (typeof input === 'string') {
      // If it's a PDF data URI, return as-is
      if (input.startsWith('data:application/pdf')) {
        resolve(input);
        return;
      }

      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const { width, height } = calculateAspectRatioFit(img.width, img.height, maxDimension, maxDimension);
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(input);
            return;
          }
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', quality);
          resolve(compressed);
        } catch {
          resolve(input);
        }
      };
      img.onerror = () => resolve(input);
      img.src = input;
      return;
    }

    // Input is a File or Blob
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      if (!dataUrl) {
        reject(new Error('Failed to read image file'));
        return;
      }

      // Check for PDF files
      if (input instanceof File && (input.type === 'application/pdf' || input.name.toLowerCase().endsWith('.pdf'))) {
        resolve(dataUrl);
        return;
      }

      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        try {
          const { width, height } = calculateAspectRatioFit(img.width, img.height, maxDimension, maxDimension);
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(dataUrl);
            return;
          }
          ctx.imageSmoothingEnabled = true;
          ctx.imageSmoothingQuality = 'high';
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, width, height);
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', quality);
          resolve(compressed);
        } catch {
          resolve(dataUrl);
        }
      };
      img.onerror = () => resolve(dataUrl);
      img.src = dataUrl;
    };
    reader.onerror = () => reject(new Error('Failed to read image buffer'));
    reader.readAsDataURL(input);
  });
}

function calculateAspectRatioFit(
  srcWidth: number,
  srcHeight: number,
  maxWidth: number,
  maxHeight: number
): { width: number; height: number } {
  if (srcWidth <= maxWidth && srcHeight <= maxHeight) {
    return { width: srcWidth, height: srcHeight };
  }
  const ratio = Math.min(maxWidth / srcWidth, maxHeight / srcHeight);
  return {
    width: Math.round(srcWidth * ratio),
    height: Math.round(srcHeight * ratio)
  };
}

/**
 * Normalizes any passport date format (DD/MM/YYYY, DD-MMM-YYYY, YYYY.MM.DD, etc.)
 * into standard HTML5 date input format (YYYY-MM-DD).
 */
export function normalizeDateToIso(dateStr?: string | null): string {
  if (!dateStr) return '';
  const trimmed = dateStr.trim();
  
  // Already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;

  // DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
  const dmyMatch = trimmed.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
  if (dmyMatch) {
    const day = dmyMatch[1].padStart(2, '0');
    const month = dmyMatch[2].padStart(2, '0');
    const year = dmyMatch[3];
    return `${year}-${month}-${day}`;
  }

  // YYYY/MM/DD or YYYY.MM.DD
  const ymdMatch = trimmed.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);
  if (ymdMatch) {
    return `${ymdMatch[1]}-${ymdMatch[2].padStart(2, '0')}-${ymdMatch[3].padStart(2, '0')}`;
  }

  // Text month: 14 JUN 1992, 14-Jun-1992, 14 June 1992, Jun 14 1992
  const months: Record<string, string> = {
    jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
    jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
  };
  const textMonthMatch = trimmed.match(/(\d{1,2})[\s\-\,\.]*([a-zA-Z]{3,9})[\s\-\,\.]*(\d{4})/i) ||
                         trimmed.match(/([a-zA-Z]{3,9})[\s\-\,\.]*(\d{1,2})[\s\-\,\.]*(\d{4})/i);
  if (textMonthMatch) {
    let day = '';
    let mon = '';
    let year = '';
    if (isNaN(Number(textMonthMatch[1]))) {
      mon = textMonthMatch[1].slice(0, 3).toLowerCase();
      day = textMonthMatch[2].padStart(2, '0');
      year = textMonthMatch[3];
    } else {
      day = textMonthMatch[1].padStart(2, '0');
      mon = textMonthMatch[2].slice(0, 3).toLowerCase();
      year = textMonthMatch[3];
    }
    if (months[mon]) {
      return `${year}-${months[mon]}-${day}`;
    }
  }

  // MRZ YYMMDD format (6 digits)
  if (/^\d{6}$/.test(trimmed)) {
    const yy = parseInt(trimmed.slice(0, 2), 10);
    const mm = trimmed.slice(2, 4);
    const dd = trimmed.slice(4, 6);
    const curYY = new Date().getFullYear() % 100;
    const fullYear = yy > curYY + 15 ? `19${yy}` : `20${yy.toString().padStart(2, '0')}`;
    return `${fullYear}-${mm}-${dd}`;
  }

  return trimmed;
}
