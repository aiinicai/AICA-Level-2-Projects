import { 
  GuestRegistration, MenuItem, FoodOrder, BillingFolio, ChatMessage, 
  PassportOCRResult, AuthSession, HousekeepingRequest, Invoice, 
  PaymentTransaction, ShekhawatiWeather, ExpenseItem, ServiceFeedback 
} from '../types';

export async function authorizeWithEmail(params: {
  email: string;
  role: 'guest' | 'staff';
  displayName?: string;
  staffRole?: string;
}): Promise<{ success: boolean; session: AuthSession; guest: GuestRegistration | null; error?: string }> {
  const res = await fetch('/api/auth/authorize', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Authorization failed' }));
    throw new Error(err.error || 'Authorization failed');
  }
  return res.json();
}

export async function fetchGuestByEmail(email: string): Promise<GuestRegistration | null> {
  const res = await fetch(`/api/guests/by-email/${encodeURIComponent(email)}`);
  if (res.status === 404) return null;
  if (!res.ok) throw new Error('Failed to query guest by email');
  return res.json();
}

export async function fetchHealth() {
  const res = await fetch('/api/health');
  return res.json();
}

export async function checkinGuest(data: Partial<GuestRegistration>): Promise<{ success: boolean; guest: GuestRegistration }> {
  const res = await fetch('/api/guests/checkin', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Check-in failed' }));
    throw new Error(err.error || 'Check-in failed');
  }
  return res.json();
}

export async function fetchGuests(): Promise<GuestRegistration[]> {
  const res = await fetch('/api/guests');
  if (!res.ok) throw new Error('Failed to fetch guests');
  return res.json();
}

export async function updateGuest(id: string, updates: Partial<GuestRegistration>): Promise<GuestRegistration> {
  const res = await fetch(`/api/guests/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  if (!res.ok) throw new Error('Failed to update guest');
  return res.json();
}

export async function deleteGuest(id: string): Promise<{ success: boolean }> {
  const res = await fetch(`/api/guests/${id}`, { method: 'DELETE' });
  return res.json();
}

export async function scanPassportOcr(imageBase64: string): Promise<{ success: boolean; data: PassportOCRResult }> {
  const res = await fetch('/api/ocr/passport', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ image: imageBase64 })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'OCR request failed' }));
    throw new Error(err.details || err.error || 'Failed to scan passport');
  }
  return res.json();
}

export async function fetchMenu(): Promise<MenuItem[]> {
  const res = await fetch('/api/food/menu');
  if (!res.ok) throw new Error('Failed to fetch menu');
  return res.json();
}

export async function fetchOrders(): Promise<FoodOrder[]> {
  const res = await fetch('/api/food/orders');
  if (!res.ok) throw new Error('Failed to fetch orders');
  return res.json();
}

export async function placeFoodOrder(orderData: Partial<FoodOrder>): Promise<{ success: boolean; order: FoodOrder }> {
  const res = await fetch('/api/food/orders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(orderData)
  });
  if (!res.ok) throw new Error('Failed to place order');
  return res.json();
}

export async function updateOrderStatus(orderId: string, status: FoodOrder['status']): Promise<FoodOrder> {
  const res = await fetch(`/api/food/orders/${orderId}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status })
  });
  if (!res.ok) throw new Error('Failed to update order status');
  return res.json();
}

export async function fetchBillingFolios(): Promise<BillingFolio[]> {
  const res = await fetch('/api/billing');
  if (!res.ok) throw new Error('Failed to fetch billing folios');
  return res.json();
}

export async function fetchGuestBilling(guestId: string): Promise<BillingFolio> {
  const res = await fetch(`/api/billing/${guestId}`);
  if (!res.ok) throw new Error('Failed to fetch guest billing');
  return res.json();
}

export async function payBilling(guestId: string, amount: number, method: string): Promise<BillingFolio> {
  const res = await fetch(`/api/billing/${guestId}/pay`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ amount, method })
  });
  if (!res.ok) throw new Error('Failed to record payment');
  return res.json();
}

export async function fetchChats(guestId?: string): Promise<ChatMessage[]> {
  const url = guestId ? `/api/chats?guestId=${encodeURIComponent(guestId)}` : '/api/chats';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch chats');
  return res.json();
}

export async function sendChatMessage(msg: Partial<ChatMessage>): Promise<ChatMessage> {
  const res = await fetch('/api/chats', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(msg)
  });
  if (!res.ok) throw new Error('Failed to send message');
  return res.json();
}

export async function fetchFormCExport(guestId: string) {
  const res = await fetch(`/api/export/form-c/${guestId}`);
  if (!res.ok) throw new Error('Failed to fetch Form C export');
  return res.json();
}

// Weather Widget (Search Grounded)
export async function fetchShekhawatiWeather(forceRefresh = false): Promise<ShekhawatiWeather> {
  const url = forceRefresh ? '/api/weather/shekhawati?refresh=true' : '/api/weather/shekhawati';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch Shekhawati weather');
  return res.json();
}

// Housekeeping Requests
export async function fetchHousekeepingRequests(guestId?: string): Promise<HousekeepingRequest[]> {
  const url = guestId ? `/api/housekeeping?guestId=${encodeURIComponent(guestId)}` : '/api/housekeeping';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch housekeeping requests');
  return res.json();
}

export async function createHousekeepingRequest(payload: {
  guestId: string;
  guestName: string;
  roomNumber: string;
  requestType: 'Standard Tidy' | 'Deep Clean' | 'Fresh Towels';
  preferredTime: string;
  notes?: string;
}): Promise<{ success: boolean; request: HousekeepingRequest }> {
  const res = await fetch('/api/housekeeping', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to create request' }));
    throw new Error(err.error || 'Failed to submit housekeeping request');
  }
  return res.json();
}

export async function updateHousekeepingStatus(id: string, status: string, assignedStaff?: string): Promise<HousekeepingRequest> {
  const res = await fetch(`/api/housekeeping/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, assignedStaff })
  });
  if (!res.ok) throw new Error('Failed to update housekeeping status');
  return res.json();
}

// Automated Invoices & Express Checkout
export async function requestCheckoutInvoice(payload: {
  guestId: string;
  checkoutDate?: string;
  additionalServices?: { description: string; price: number }[];
}): Promise<{ success: boolean; invoice: Invoice }> {
  const res = await fetch('/api/checkout/request-invoice', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error('Failed to generate automated invoice');
  return res.json();
}

export async function fetchGuestInvoice(guestId: string): Promise<Invoice> {
  const res = await fetch(`/api/checkout/invoice/${guestId}`);
  if (!res.ok) throw new Error('Failed to fetch guest invoice');
  return res.json();
}

export async function fetchAllInvoices(): Promise<Invoice[]> {
  const res = await fetch('/api/invoices');
  if (!res.ok) throw new Error('Failed to fetch invoices');
  return res.json();
}

export async function processCheckoutPayment(payload: {
  invoiceId: string;
  guestId: string;
  amount: number;
  gateway: 'Stripe' | 'PayPal' | 'UPI' | 'Card';
  paymentDetails: any;
}): Promise<{ success: boolean; transaction: PaymentTransaction; invoice: Invoice }> {
  const res = await fetch('/api/checkout/pay', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Payment failed' }));
    throw new Error(err.error || 'Payment transaction failed');
  }
  return res.json();
}

export async function fetchTransactions(guestId?: string): Promise<PaymentTransaction[]> {
  const url = guestId ? `/api/transactions?guestId=${encodeURIComponent(guestId)}` : '/api/transactions';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch transactions');
  return res.json();
}

// Expenses & Accounts Management
export async function fetchExpenses(): Promise<ExpenseItem[]> {
  const res = await fetch('/api/expenses');
  if (!res.ok) throw new Error('Failed to fetch expenses');
  return res.json();
}

export async function createExpense(payload: Partial<ExpenseItem>): Promise<{ success: boolean; expense: ExpenseItem }> {
  const res = await fetch('/api/expenses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to record expense' }));
    throw new Error(err.error || 'Failed to submit expense');
  }
  return res.json();
}

export async function updateExpenseStatus(
  id: string, 
  status: 'approved' | 'rejected' | 'pending_approval', 
  approvedBy?: string, 
  rejectionReason?: string
): Promise<{ success: boolean; expense: ExpenseItem }> {
  const res = await fetch(`/api/expenses/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, approvedBy, rejectionReason })
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to update expense status' }));
    throw new Error(err.error || 'Failed to update expense status');
  }
  return res.json();
}

// Post-Service Feedback API
export async function fetchFeedbacks(params?: { guestId?: string; category?: string }): Promise<ServiceFeedback[]> {
  const query = new URLSearchParams();
  if (params?.guestId) query.set('guestId', params.guestId);
  if (params?.category) query.set('category', params.category);
  const url = query.toString() ? `/api/feedback?${query.toString()}` : '/api/feedback';
  const res = await fetch(url);
  if (!res.ok) throw new Error('Failed to fetch feedback records');
  return res.json();
}

export async function submitFeedback(payload: Partial<ServiceFeedback>): Promise<{ success: boolean; feedback: ServiceFeedback }> {
  const res = await fetch('/api/feedback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: 'Failed to submit feedback' }));
    throw new Error(err.error || 'Failed to record feedback');
  }
  return res.json();
}

export async function updateFeedbackStatus(
  id: string, 
  status: 'acknowledged' | 'in_review' | 'resolved' | 'thanked'
): Promise<{ success: boolean; feedback: ServiceFeedback }> {
  const res = await fetch(`/api/feedback/${id}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status })
  });
  if (!res.ok) throw new Error('Failed to update feedback status');
  return res.json();
}

