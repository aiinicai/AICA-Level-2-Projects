export interface GuestRegistration {
  id: string;
  checkInDate: string;
  checkOutDate: string;
  roomNumber: string;
  roomType: string;
  roomRate: number;
  status: 'active' | 'checked_out' | 'pending_verification';
  guestType: 'foreign' | 'domestic';

  // Personal Info (Compliant with Govt Foreign Registration / Form C and Indian Domestic Homestay Law)
  givenName: string;
  surname: string;
  gender: 'Male' | 'Female' | 'Other';
  dob: string;
  nationality: string;
  
  // Domestic Traveller specifics (Indian Law)
  idType?: 'Aadhaar Card' | 'Driving Licence' | 'Voter ID' | 'Indian Passport';
  fatherOrSpouseName?: string;
  permanentAddressIndia?: string;
  comingFromCityState?: string;
  vehicleNumber?: string;

  // Passport Details
  passportNumber: string;
  passportIssueDate: string;
  passportExpiryDate: string;
  passportIssuePlace: string;

  // Visa Details
  visaNumber: string;
  visaType: string;
  visaIssueDate: string;
  visaExpiryDate: string;
  visaIssuePlace: string;

  // Travel Details
  arrivedFromCity: string;
  arrivedFromCountry: string;
  arrivalDateInCountry: string;
  portOfArrival: string;
  nextDestination: string;
  purposeOfVisit: string;
  employedInIndia: boolean;

  // Contact Details
  homeAddress: string;
  homeCountry: string;
  phone: string;
  email: string;
  emergencyContact: string;

  // Uploaded media & documents (Local & Google Drive links)
  guestPhoto?: string; // base64 or URL
  passportDocument?: string; // base64 or URL
  visaDocument?: string; // base64 or URL
  signature?: string; // base64 canvas signature
  driveDocumentLink?: string; // Google Drive Web View Link
  drivePhotoLink?: string; // Google Drive Web View Link
  driveSignatureLink?: string; // Google Drive Web View Link

  // Metadata
  createdAt: string;
  verificationStatus: 'verified' | 'pending' | 'flagged';
  notes?: string;
}

export interface MenuItem {
  id: string;
  name: string;
  category: 'Breakfast' | 'Lunch' | 'Dinner' | 'Chai & Snacks' | 'Desserts & Beverages' | 'Royal Breakfast' | 'Heritage Thali' | 'Courtyard Delicacies' | 'Afternoon Chai & Snacks';
  description: string;
  price: number;
  isVeg: boolean;
  isSpicy?: boolean;
  heritageTag?: string;
  image: string;
}

export interface ExpenseItem {
  id: string;
  title: string;
  category: 'Kitchen & Groceries' | 'Linen & Laundry' | 'Utilities & Power' | 'Maintenance & Repair' | 'Staff Wages' | 'Govt & Taxes' | 'Marketing & Travel' | 'Other';
  amount: number;
  date: string;
  paymentMethod: 'Cash' | 'UPI / Bank' | 'Card' | 'Vendor Credit';
  submittedBy: string; // Staff name or email
  submittedAt: string;
  status: 'pending_approval' | 'approved' | 'rejected';
  receiptUrl?: string;
  notes?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectionReason?: string;
}

export interface OrderItem {
  menuItemId: string;
  name: string;
  quantity: number;
  price: number;
  notes?: string;
}

export interface FoodOrder {
  id: string;
  guestId: string;
  guestName: string;
  roomNumber: string;
  items: OrderItem[];
  subtotal: number;
  taxes: number;
  total: number;
  status: 'placed' | 'preparing' | 'on_the_way' | 'delivered' | 'cancelled';
  specialInstructions?: string;
  placedAt: string;
  deliveredAt?: string;
  estimatedMinutes: number;
}

export interface BillingPayment {
  id: string;
  date: string;
  amount: number;
  method: 'Card' | 'UPI' | 'Cash' | 'Bank Transfer';
  reference?: string;
}

export interface BillingFolio {
  id: string;
  guestId: string;
  guestName: string;
  roomNumber: string;
  checkInDate: string;
  checkOutDate: string;
  roomRatePerNight: number;
  nights: number;
  roomTotal: number;
  foodOrdersTotal: number;
  experiencesTotal: number;
  conservationLevy: number; // 5%
  taxes: number; // 12% GST
  grandTotal: number;
  paidAmount: number;
  balanceDue: number;
  status: 'unpaid' | 'paid' | 'partially_paid';
  payments: BillingPayment[];
}

export interface ChatMessage {
  id: string;
  guestId: string;
  roomNumber: string;
  sender: 'guest' | 'staff' | 'concierge_ai' | 'system';
  senderName: string;
  message: string;
  timestamp: string;
  read: boolean;
}

export type UserRole = 'guest' | 'staff';

export interface AuthSession {
  email: string;
  role: UserRole;
  displayName: string;
  token: string;
  guestId?: string;
  roomNumber?: string;
  staffRole?: 'General Manager' | 'Front Desk Officer' | 'Executive Chef' | 'Estate Concierge';
  authorizedAt: string;
}

export interface AdminUser {
  id: string;
  name: string;
  email?: string;
  role: 'General Manager' | 'Front Desk Officer' | 'Executive Chef' | 'Estate Concierge';
  token: string;
}

export interface PassportOCRResult {
  givenName?: string;
  surname?: string;
  gender?: 'Male' | 'Female' | 'Other';
  dob?: string;
  nationality?: string;
  passportNumber?: string;
  passportIssueDate?: string;
  passportExpiryDate?: string;
  passportIssuePlace?: string;
  rawExtractedText?: string;
  confidence?: number;
}

// Housekeeping Request Feature
export type HousekeepingType = 'Standard Tidy' | 'Deep Clean' | 'Fresh Towels';
export type HousekeepingStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';

export interface HousekeepingRequest {
  id: string;
  guestId: string;
  guestName: string;
  roomNumber: string;
  requestType: HousekeepingType;
  preferredTime: string;
  notes?: string;
  status: HousekeepingStatus;
  requestedAt: string;
  completedAt?: string;
  assignedStaff?: string;
}

// Automated Invoice Generation & Payment System
export interface InvoiceItem {
  id: string;
  category: 'accommodation' | 'dining' | 'service' | 'levy' | 'tax';
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

export interface Invoice {
  id: string; // e.g. "INV-2026-8021"
  guestId: string;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  roomNumber: string;
  roomType: string;
  checkInDate: string;
  checkOutDate: string;
  nights: number;
  roomRatePerNight: number;
  items: InvoiceItem[];
  subtotal: number;
  conservationLevy: number; // 5% Heritage Monument Preservation Fund
  taxes: number; // 12% GST room, 5% dining
  grandTotal: number;
  paidAmount: number;
  balanceDue: number;
  status: 'unpaid' | 'paid' | 'refunded';
  generatedAt: string;
  paidAt?: string;
  paymentGateway?: 'Stripe' | 'PayPal' | 'UPI' | 'Card';
  transactionId?: string;
  qrVerificationCode?: string;
  notes?: string;
}

export interface PaymentTransaction {
  id: string;
  invoiceId: string;
  guestId: string;
  guestName: string;
  roomNumber: string;
  amount: number;
  currency: 'INR' | 'USD';
  gateway: 'Stripe' | 'PayPal' | 'UPI' | 'Card';
  gatewayTransactionId: string;
  status: 'succeeded' | 'pending' | 'failed';
  paymentMethodDetails: {
    cardBrand?: string;
    cardLast4?: string;
    paypalEmail?: string;
    upiId?: string;
  };
  timestamp: string;
  receiptUrl?: string;
}

// Shekhawati Weather Widget with Search Grounding
export interface WeatherGroundingSource {
  title: string;
  url: string;
}

export interface ShekhawatiWeather {
  region: string;
  temperatureC: number;
  temperatureF: number;
  condition: string;
  conditionIcon: 'sunny' | 'cloudy' | 'rainy' | 'haze' | 'clear' | 'windy';
  feelsLikeC: number;
  humidity: number;
  windSpeedKmH: number;
  precipitationChance: number;
  airQuality: string;
  summary: string;
  guestAdvice: string;
  forecast: {
    timeOfDay: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
    tempC: number;
    condition: string;
  }[];
  groundingSources: WeatherGroundingSource[];
  lastUpdated: string;
  isCached?: boolean;
}

// Post-Service Feedback Module (Dining, Housekeeping, Stay & Checkout)
export type FeedbackCategory = 'dining' | 'housekeeping' | 'stay_checkout';

export interface ServiceFeedback {
  id: string; // e.g. "FB-101"
  guestId: string;
  guestName: string;
  guestEmail?: string;
  roomNumber: string;
  category: FeedbackCategory; // 'dining' | 'housekeeping' | 'stay_checkout'
  targetId?: string; // Order ID (ORD-501), Housekeeping ID (HK-901), Invoice ID (INV-...), or 'stay'
  targetTitle?: string; // e.g. "Royal Heritage Thali & Chaas (Order #ORD-501)"
  rating: number; // 1 to 5 stars
  qualityRating?: number; // 1 to 5 stars (Food taste / Cleanliness / Suite comfort)
  speedRating?: number; // 1 to 5 stars (Delivery speed / Promptness / Checkout ease)
  courtesyRating?: number; // 1 to 5 stars (Staff courtesy / Rajputana hospitality)
  tags: string[]; // e.g. ["Authentic Flavors", "Piping Hot", "Spotless Linen"]
  comments: string;
  npsScore?: number; // 1 to 10 (Would recommend to friends/fellow travelers)
  createdAt: string;
  followUpStatus?: 'acknowledged' | 'in_review' | 'resolved' | 'thanked';
}

