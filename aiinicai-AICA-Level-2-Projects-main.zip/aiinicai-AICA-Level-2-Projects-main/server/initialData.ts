import { GuestRegistration, MenuItem, FoodOrder, BillingFolio, ChatMessage, ExpenseItem, ServiceFeedback } from '../src/types.js';

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  // --- BREAKFAST ---
  {
    id: 'menu-bf-1',
    name: 'Jaipur Pyaaz Kachori with Meethi Imli & Kadhi',
    category: 'Breakfast',
    description: 'Crispy golden flaky crust pastry stuffed with spiced caramelized onions, paired with sweet tamarind saunth and warm Rajasthani kadhi.',
    price: 180,
    isVeg: true,
    isSpicy: true,
    heritageTag: 'Johari Bazar Morning Icon',
    image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-bf-2',
    name: 'Jodhpur Mirchi Bada with Mint Coriander Chutney',
    category: 'Breakfast',
    description: 'Jumbo Bhavnagri mild green peppers stuffed with spiced hing-aloo masala, crisp gram flour batter, served piping hot.',
    price: 160,
    isVeg: true,
    isSpicy: true,
    heritageTag: 'Marwar Classic',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-bf-3',
    name: 'Bedmi Puri with Mathura Aloo Jhol & Methi Launji',
    category: 'Breakfast',
    description: '4 puffed urad dal-crusted whole wheat pooris served with rustic cumin-potato curry and sweet-sour fenugreek raisin pickle.',
    price: 260,
    isVeg: true,
    heritageTag: 'Courtyard Breakfast',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-bf-4',
    name: 'Mewari Paneer Paratha with Desi White Makhan',
    category: 'Breakfast',
    description: 'Two griddle-roasted whole wheat parathas stuffed with fresh chenna paneer, green herbs, served with organic white butter and pickle.',
    price: 240,
    isVeg: true,
    heritageTag: 'Homestay Farm Kitchen',
    image: 'https://images.unsplash.com/photo-1589301760014-d929f3979dbc?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-bf-5',
    name: 'Indori-Rajasthani Poha with Ratlami Sev & Pomegranate',
    category: 'Breakfast',
    description: 'Light steamed flattened rice tempered with mustard, fennel seeds, turmeric, peanuts, and topped with crisp sev and fresh lemon.',
    price: 150,
    isVeg: true,
    heritageTag: 'Light Morning Plate',
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80'
  },

  // --- LUNCH ---
  {
    id: 'menu-ln-1',
    name: 'Royal Rajasthani Dal Baati Churma Thali',
    category: 'Lunch',
    description: 'Signature Haveli Thali: 3 wheat baatis steeped in pure cow desi ghee, spiced 5-lentil Panchmel dal, wheat jaggery Churma, Gatte, and garlic chutney.',
    price: 580,
    isVeg: true,
    heritageTag: "Royal Rajputana Grand Platter",
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-ln-2',
    name: 'Rajasthani Gatte Ki Sabzi with Phulkas',
    category: 'Lunch',
    description: 'Tender poached gram flour dumplings simmered in a spiced curd and fenugreek leaf gravy, served with 4 ghee phulkas.',
    price: 360,
    isVeg: true,
    heritageTag: 'Traditional Desert Staple',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-ln-3',
    name: 'Desert Ker Sangri Delicacy',
    category: 'Lunch',
    description: 'Rare wild desert capers (ker) and sun-dried beans (sangri) slow-cooked in cold-pressed mustard oil with whole red chillies and dry mango.',
    price: 440,
    isVeg: true,
    heritageTag: 'Thar Desert Treasure',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-ln-4',
    name: 'Mewari Paneer Lababdar with Missi Roti',
    category: 'Lunch',
    description: 'Rich cottage cheese cubes cooked in a velvety tomato-cashew nut gravy, served with 2 freshly baked carom-seed missi rotis.',
    price: 420,
    isVeg: true,
    heritageTag: 'Haveli Rasoi Favorite',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-ln-5',
    name: 'Marwari Kadhi Pakora with Jeera Basmati Rice',
    category: 'Lunch',
    description: 'Tangy churned buttermilk stew simmered with crispy onion-besan pakoras, served alongside long-grain tempered cumin rice.',
    price: 320,
    isVeg: true,
    heritageTag: 'Comfort Food Heritage',
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80'
  },

  // --- DINNER ---
  {
    id: 'menu-dn-1',
    name: 'Authentic Rajputana Laal Maas',
    category: 'Dinner',
    description: 'Slow-braised tender goat meat cooked over wood charcoal in mustard oil with fiery Mathania sun-dried red chillies and smoked ghee dhungar.',
    price: 640,
    isVeg: false,
    isSpicy: true,
    heritageTag: 'Warrior Feast Tradition',
    image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-dn-2',
    name: 'Shahi Malai Kofta in Kesar Cashew Sauce',
    category: 'Dinner',
    description: 'Silken dumplings of mawa and cottage cheese stuffed with pistachios, swimming in an aromatic white cardamom-cashew gravy, served with warqi paratha.',
    price: 480,
    isVeg: true,
    heritageTag: 'Regal Banquet Dish',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-dn-3',
    name: 'Bajra Roti with Desi Ghee, Gur & Lahsun Chutney',
    category: 'Dinner',
    description: 'Hand-pressed pearl millet flatbread brushed with pure cow ghee, served with organic Kolhapur jaggery and spicy stone-ground garlic chutney.',
    price: 250,
    isVeg: true,
    heritageTag: 'Village Hearth Warmth',
    image: 'https://images.unsplash.com/photo-1610057099443-fde8c4d50f91?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-dn-4',
    name: 'Govind Gatte Shahi Curry with Steamed Rice',
    category: 'Dinner',
    description: 'Jaipur royal palace specialty: large gram flour gattas filled with khoya, nuts, and green chillies in a rich spiced yoghurt gravy.',
    price: 430,
    isVeg: true,
    heritageTag: 'Pink City Royal Court',
    image: 'https://images.unsplash.com/photo-1585937421612-70a008356fbe?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-dn-5',
    name: 'Jodhpuri Kabuli Pulao with Smoked Boondi Raita',
    category: 'Dinner',
    description: 'Grand royal pulao layered with aromatic saffron rice, crispy fried bread croutons, seasonal vegetables, cashews, and raisins.',
    price: 380,
    isVeg: true,
    heritageTag: 'Celebratory Heritage Rice',
    image: 'https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?auto=format&fit=crop&w=600&q=80'
  },

  // --- CHAI & SNACKS ---
  {
    id: 'menu-sn-1',
    name: 'Kulhad Masala Chai & Bikaneri Bhujia Platter',
    category: 'Chai & Snacks',
    description: 'Fragrant earthen pot tea slow-boiled with fresh ginger, green cardamom, cinnamon, and tulsi, served with crisp moth dal bhujia and salted mathri.',
    price: 150,
    isVeg: true,
    heritageTag: 'Evening Courtyard Soiree',
    image: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-sn-2',
    name: 'Jaipur Samosa Chaat with Dahi & Saunth',
    category: 'Chai & Snacks',
    description: 'Crushed spiced potato samosas topped with fresh churned sweet curd, mint chutney, tamarind saunth, sev, and pomegranate seeds.',
    price: 190,
    isVeg: true,
    heritageTag: 'Johari Street Flavor',
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=600&q=80'
  },

  // --- DESSERTS & BEVERAGES ---
  {
    id: 'menu-ds-1',
    name: 'Traditional Jaipur Rabdi Malpua',
    category: 'Desserts & Beverages',
    description: 'Two delicate fennel-scented pancakes soaked in saffron syrup, crowned with slow-reduced creamy pistachio rabdi and silver varq.',
    price: 280,
    isVeg: true,
    heritageTag: 'Mewari Royal Sweet',
    image: 'https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-ds-2',
    name: 'Jaipur Paneer Malai Ghevar',
    category: 'Desserts & Beverages',
    description: 'Iconic Rajasthani honeycomb pastry disc made with clarified butter, soaked in cardamom syrup and generously topped with thick malai and pistachios.',
    price: 320,
    isVeg: true,
    heritageTag: 'Teej & Gangaur Icon',
    image: 'https://images.unsplash.com/photo-1599490659213-e2b9527bd087?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 'menu-ds-3',
    name: 'Matka Smoked Masala Buttermilk (Chaas)',
    category: 'Desserts & Beverages',
    description: 'Refreshing churned farm curd tempered with roasted cumin, rock salt, mint, and delicately smoked with clove in hot cow ghee.',
    price: 130,
    isVeg: true,
    heritageTag: 'Desert Thirst Quencher',
    image: 'https://images.unsplash.com/photo-1556881286-fc6915169721?auto=format&fit=crop&w=600&q=80'
  }
];

export const INITIAL_EXPENSES: ExpenseItem[] = [
  {
    id: 'EXP-101',
    title: 'Daily Fresh Vegetables & Dairy from Johari Bazar Mandi',
    category: 'Kitchen & Groceries',
    amount: 3850,
    date: '2026-09-25',
    paymentMethod: 'UPI / Bank',
    submittedBy: 'Ramesh (Kitchen Head)',
    submittedAt: '2026-09-25T08:30:00.000Z',
    status: 'approved',
    approvedBy: 'Sudhanshu Rathi (Manager)',
    approvedAt: '2026-09-25T09:15:00.000Z',
    notes: 'Potatoes, onions, green chillies, paneer, and 20L fresh milk for breakfast & chai.'
  },
  {
    id: 'EXP-102',
    title: 'Heritage Suite Organic Linen Laundry & Dry Cleaning',
    category: 'Linen & Laundry',
    amount: 2400,
    date: '2026-09-26',
    paymentMethod: 'Cash',
    submittedBy: 'Shanti Devi (Housekeeping)',
    submittedAt: '2026-09-26T10:00:00.000Z',
    status: 'approved',
    approvedBy: 'Sudhanshu Rathi (Manager)',
    approvedAt: '2026-09-26T10:45:00.000Z',
    notes: '24 duvet covers, bedsheets, and towel sets cleaned by heritage textile wash service.'
  },
  {
    id: 'EXP-103',
    title: 'Courtyard Sandstone Fountain Pump Maintenance',
    category: 'Maintenance & Repair',
    amount: 1850,
    date: '2026-09-26',
    paymentMethod: 'Cash',
    submittedBy: 'Bhanwar Singh (Estate Staff)',
    submittedAt: '2026-09-26T11:20:00.000Z',
    status: 'pending_approval',
    notes: 'Replaced water impeller and brass filter for Zenana Chowk marble fountain.'
  },
  {
    id: 'EXP-104',
    title: '5 Tins Pure Cow Desi Ghee for Royal Rasoi Cooking',
    category: 'Kitchen & Groceries',
    amount: 6500,
    date: '2026-09-26',
    paymentMethod: 'UPI / Bank',
    submittedBy: 'Ramesh (Kitchen Head)',
    submittedAt: '2026-09-26T12:00:00.000Z',
    status: 'pending_approval',
    notes: 'Saras A2 pure cow ghee for Dal Baati Churma and rasoi sweets.'
  }
];

export const INITIAL_GUESTS: GuestRegistration[] = [
  {
    id: 'GUEST-8021',
    checkInDate: '2026-09-16',
    checkOutDate: '2026-09-20',
    roomNumber: 'Suite 101 - The Royal Haveli',
    roomType: 'Heritage Grand Suite',
    roomRate: 7500,
    status: 'active',
    guestType: 'foreign',
    givenName: 'Elena Camille',
    surname: 'Rostova',
    gender: 'Female',
    dob: '1992-06-14',
    nationality: 'French (France)',
    passportNumber: '21FB84920',
    passportIssueDate: '2021-04-10',
    passportExpiryDate: '2031-04-09',
    passportIssuePlace: 'Paris, France',
    visaNumber: 'IND9082341-T',
    visaType: 'e-Tourist Visa (1 Year)',
    visaIssueDate: '2026-08-01',
    visaExpiryDate: '2027-07-31',
    visaIssuePlace: 'New Delhi BoI Portal',
    arrivedFromCity: 'Paris',
    arrivedFromCountry: 'France',
    arrivalDateInCountry: '2026-09-14',
    portOfArrival: 'Indira Gandhi International Airport, New Delhi (DEL)',
    nextDestination: 'Udaipur Heritage Palace, Rajasthan',
    purposeOfVisit: 'Cultural Heritage Study & Leisure Tourism',
    employedInIndia: false,
    homeAddress: '24 Rue des Rosiers, 4th Arrondissement, Paris',
    homeCountry: 'France',
    phone: '+33 6 45 92 11 08',
    email: 'elena.rostova@homestayguest.com',
    emergencyContact: 'Pierre Rostova (+33 6 12 34 56 78)',
    verificationStatus: 'verified',
    createdAt: '2026-09-16T11:45:00.000Z',
    notes: 'Requested quiet courtyard room and early breakfast.'
  },
  {
    id: 'GUEST-8022',
    checkInDate: '2026-09-17',
    checkOutDate: '2026-09-19',
    roomNumber: 'Suite 104 - Gulab Mahal',
    roomType: 'Royal Garden Suite',
    roomRate: 5800,
    status: 'active',
    guestType: 'domestic',
    givenName: 'Arjun & Meera',
    surname: 'Singhania',
    gender: 'Male',
    dob: '1988-11-23',
    nationality: 'Indian',
    passportNumber: 'Z8941029',
    passportIssueDate: '2019-03-12',
    passportExpiryDate: '2029-03-11',
    passportIssuePlace: 'Mumbai, India',
    visaNumber: 'N/A (Domestic Citizen)',
    visaType: 'Domestic',
    visaIssueDate: '2026-01-01',
    visaExpiryDate: '2099-12-31',
    visaIssuePlace: 'N/A',
    arrivedFromCity: 'Mumbai',
    arrivedFromCountry: 'India',
    arrivalDateInCountry: '2026-09-17',
    portOfArrival: 'Jaipur Airport',
    nextDestination: 'Mumbai',
    purposeOfVisit: 'Anniversary Celebration & Art Photography',
    employedInIndia: true,
    homeAddress: 'Flat 12B, Sea Green Apartments, Worli, Mumbai 400018',
    homeCountry: 'India',
    phone: '+91 98201 54321',
    email: 'arjun.singhania@homestayguest.com',
    emergencyContact: 'Raj Singhania (+91 98200 11223)',
    verificationStatus: 'verified',
    createdAt: '2026-09-17T09:15:00.000Z',
    notes: 'Anniversary setup requested in suite.'
  }
];

export const INITIAL_ORDERS: FoodOrder[] = [
  {
    id: 'ORD-501',
    guestId: 'GUEST-8021',
    guestName: 'Elena Camille Rostova',
    roomNumber: 'Suite 101 - The Royal Haveli',
    items: [
      { menuItemId: 'menu-1', name: 'Royal Heritage Thali', quantity: 1, price: 650 },
      { menuItemId: 'menu-7', name: 'Clay Pot Masala Buttermilk (Chaas)', quantity: 1, price: 150 }
    ],
    subtotal: 800,
    taxes: 40,
    total: 840,
    status: 'preparing',
    specialInstructions: 'Please make the dal with mild chillies.',
    placedAt: '2026-09-17T11:20:00.000Z',
    estimatedMinutes: 20
  },
  {
    id: 'ORD-502',
    guestId: 'GUEST-8022',
    guestName: 'Arjun Singhania',
    roomNumber: 'Suite 104 - Gulab Mahal',
    items: [
      { menuItemId: 'menu-4', name: 'Jodhpuri Onion Kachori & High Tea', quantity: 2, price: 280 }
    ],
    subtotal: 560,
    taxes: 28,
    total: 588,
    status: 'delivered',
    specialInstructions: 'Serve at the garden verandah table.',
    placedAt: '2026-09-17T09:40:00.000Z',
    deliveredAt: '2026-09-17T10:05:00.000Z',
    estimatedMinutes: 25
  }
];

export const INITIAL_CHATS: ChatMessage[] = [
  {
    id: 'chat-1',
    guestId: 'GUEST-8021',
    roomNumber: 'Suite 101 - The Royal Haveli',
    sender: 'system',
    senderName: 'Heritique Concierge',
    message: 'Padharo Mhare Des! Welcome to Heritique Homestay, Elena. We are thrilled to host you. Let us know if you need anything for your stay.',
    timestamp: '2026-09-16T12:00:00.000Z',
    read: true
  },
  {
    id: 'chat-2',
    guestId: 'GUEST-8021',
    roomNumber: 'Suite 101 - The Royal Haveli',
    sender: 'guest',
    senderName: 'Elena Rostova',
    message: 'Thank you so much! The courtyard is stunning. Could you please let me know what time the morning heritage bird-watching tour begins?',
    timestamp: '2026-09-16T14:15:00.000Z',
    read: true
  },
  {
    id: 'chat-3',
    guestId: 'GUEST-8021',
    roomNumber: 'Suite 101 - The Royal Haveli',
    sender: 'staff',
    senderName: 'Thakur Mahendra Singh (Host)',
    message: 'Namaste Elena! Our naturalists assemble by the Stepwell fountain at 6:45 AM. Binoculars and herbal tea will be arranged for you.',
    timestamp: '2026-09-16T14:22:00.000Z',
    read: true
  }
];

export const INITIAL_FEEDBACK: ServiceFeedback[] = [
  {
    id: 'FB-901',
    guestId: 'GUEST-8022',
    guestName: 'Arjun Singhania',
    guestEmail: 'arjun.singhania@homestayguest.com',
    roomNumber: 'Suite 104 - Gulab Mahal',
    category: 'dining',
    targetId: 'ORD-502',
    targetTitle: 'Jodhpuri Onion Kachori & High Tea (Order #ORD-502)',
    rating: 5,
    qualityRating: 5,
    speedRating: 5,
    courtesyRating: 5,
    tags: ['Crisp & Flavorful', 'Served Piping Hot', 'Courtyard Verandah Service'],
    comments: 'The onion kachoris had an authentic Marwari spice balance. Served piping hot in the rose courtyard with fragrant cardamom masala chai. Superb culinary experience!',
    createdAt: '2026-09-26T10:15:00.000Z',
    followUpStatus: 'thanked'
  },
  {
    id: 'FB-902',
    guestId: 'GUEST-8021',
    guestName: 'Elena Rostova',
    guestEmail: 'elena.rostova@homestayguest.com',
    roomNumber: 'Suite 101 - The Royal Haveli',
    category: 'housekeeping',
    targetId: 'HK-901',
    targetTitle: 'Fresh Towels & Lavender Room Mist (Req #HK-901)',
    rating: 5,
    qualityRating: 5,
    speedRating: 5,
    courtesyRating: 5,
    tags: ['Spotless Linen', 'Prompt Floor Staff', 'Aromatic Mist'],
    comments: 'Raju arrived in less than 15 minutes. The towels were plush, immaculate, and the natural lavender mist made the heritage four-poster bedroom smell heavenly.',
    createdAt: '2026-09-26T14:30:00.000Z',
    followUpStatus: 'thanked'
  },
  {
    id: 'FB-903',
    guestId: 'GUEST-8022',
    guestName: 'Arjun Singhania',
    guestEmail: 'arjun.singhania@homestayguest.com',
    roomNumber: 'Suite 104 - Gulab Mahal',
    category: 'stay_checkout',
    targetId: 'stay',
    targetTitle: '2-Night Heritage Stay Experience & Digital Checkout',
    rating: 5,
    qualityRating: 5,
    speedRating: 5,
    courtesyRating: 5,
    npsScore: 10,
    tags: ['Royal Rajput Hospitality', 'Preserved 1924 Architecture', 'Instant UPI Checkout', 'Peaceful Courtyard'],
    comments: 'Our anniversary at Heritique Haveli was unforgettable. The 100-year-old fresco details, genuine personal warmth of Thakur Mahendra Singh, and seamless digital checkout with instant invoice made this the finest homestay in Rajasthan.',
    createdAt: '2026-09-27T08:00:00.000Z',
    followUpStatus: 'thanked'
  }
];

