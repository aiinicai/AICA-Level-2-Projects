import { GoogleGenAI, Type } from "@google/genai";
import { PassportOCRResult } from '../src/types.js';

let genAIClient: GoogleGenAI | null = null;

function getGenAIClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn('GEMINI_API_KEY is not defined in server environment');
    return null;
  }
  if (!genAIClient) {
    genAIClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
  return genAIClient;
}

const ISO_COUNTRY_MAP: Record<string, string> = {
  FRA: 'France',
  USA: 'United States',
  GBR: 'United Kingdom',
  DEU: 'Germany',
  AUS: 'Australia',
  CAN: 'Canada',
  JPN: 'Japan',
  ESP: 'Spain',
  ITA: 'Italy',
  NLD: 'Netherlands',
  CHE: 'Switzerland',
  IND: 'India',
  RUS: 'Russia',
  CHN: 'China',
  BRA: 'Brazil',
  ZAF: 'South Africa',
  SGP: 'Singapore',
  MYS: 'Malaysia',
  THA: 'Thailand',
  NZL: 'New Zealand',
  SWE: 'Sweden',
  NOR: 'Norway',
  DNK: 'Denmark',
  FIN: 'Finland',
  BEL: 'Belgium',
  AUT: 'Austria',
  IRL: 'Ireland',
  PRT: 'Portugal',
  GRC: 'Greece',
  MEX: 'Mexico',
  ARG: 'Argentina',
  KOR: 'South Korea',
  ISR: 'Israel',
  TUR: 'Turkey',
  ARE: 'United Arab Emirates'
};

/**
 * Normalizes any passport date format (DD/MM/YYYY, DD-MMM-YYYY, YYYY.MM.DD, etc.)
 * into standard ISO format (YYYY-MM-DD) for HTML5 date inputs.
 */
function normalizeDateToIso(dateStr?: string | null): string {
  if (!dateStr) return '';
  const trimmed = dateStr.trim();

  // Already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) return trimmed;

  // DD/MM/YYYY or DD-MM-YYYY or DD.MM.YYYY
  const dmyMatch = trimmed.match(/^(\d{1,2})[\/\-\.](\d{1,2})[\/\-\.](\d{4})$/);
  if (dmyMatch) {
    const day = dmyMatch[1].padStart(2, '0');
    const month = dmyMatch[2].padStart(2, '0');
    const year = dmyMatch[3];
    return `${year}-${month}-${day}`;
  }

  // YYYY/MM/DD or YYYY.MM.DD
  const ymdMatch = trimmed.match(/^(\d{4})[\/\-\.](\d{1,2})[\/\-\.](\d{1,2})$/);
  if (ymdMatch) {
    return `${ymdMatch[1]}-${ymdMatch[2].padStart(2, '0')}-${ymdMatch[3].padStart(2, '0')}`;
  }

  // Text month: 14 JUN 1992, 14-Jun-1992, 14 June 1992, Jun 14 1992
  const months: Record<string, string> = {
    jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
    jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
  };
  const textMonthMatch = trimmed.match(/(\d{1,2})[\s\-\,\.]*([a-zA-Z]{3,9})[\s\-\,\.]*(\d{4})/i) ||
                         trimmed.match(/([a-zA-Z]{3,9})[\s\-\,\.]*(\d{1,2})[\s\-\,\.]*(\d{4})/i);
  if (textMonthMatch) {
    let day = '';
    let mon = '';
    let year = '';
    if (isNaN(Number(textMonthMatch[1]))) {
      mon = textMonthMatch[1].slice(0, 3).toLowerCase();
      day = textMonthMatch[2].padStart(2, '0');
      year = textMonthMatch[3];
    } else {
      day = textMonthMatch[1].padStart(2, '0');
      mon = textMonthMatch[2].slice(0, 3).toLowerCase();
      year = textMonthMatch[3];
    }
    if (months[mon]) {
      return `${year}-${months[mon]}-${day}`;
    }
  }

  // MRZ YYMMDD format (6 digits)
  if (/^\d{6}$/.test(trimmed)) {
    const yy = parseInt(trimmed.slice(0, 2), 10);
    const mm = trimmed.slice(2, 4);
    const dd = trimmed.slice(4, 6);
    const curYY = new Date().getFullYear() % 100;
    const fullYear = yy > curYY + 15 ? `19${yy}` : `20${yy.toString().padStart(2, '0')}`;
    return `${fullYear}-${mm}-${dd}`;
  }

  return trimmed;
}

/**
 * Helper to parse ICAO 9303 MRZ machine-readable lines if present in text
 */
function parseMrzText(text: string): Partial<PassportOCRResult> {
  const lines = text.split(/[\r\n]+/).map(l => l.trim().replace(/\s+/g, '')).filter(l => l.length >= 30);
  for (let i = 0; i < lines.length; i++) {
    const line1 = lines[i];
    const line2 = lines[i + 1] || '';

    // Standard TD3 (Passport) MRZ line 1 starts with P< or P
    if (line1.startsWith('P<') || line1.startsWith('P')) {
      const countryCode = line1.slice(2, 5).replace(/</g, '').toUpperCase();
      const namePart = line1.slice(5);
      const [surnameRaw, givenRaw] = namePart.split('<<');
      const surname = surnameRaw ? surnameRaw.replace(/</g, ' ').trim() : '';
      const givenName = givenRaw ? givenRaw.replace(/</g, ' ').trim() : '';

      let passportNumber = '';
      let nationality = ISO_COUNTRY_MAP[countryCode] || countryCode;
      let dob = '';
      let gender: 'Male' | 'Female' | 'Other' = 'Other';
      let expiry = '';

      if (line2 && line2.length >= 28) {
        passportNumber = line2.slice(0, 9).replace(/</g, '').trim();
        const natCode = line2.slice(10, 13).replace(/</g, '').toUpperCase();
        if (ISO_COUNTRY_MAP[natCode]) {
          nationality = ISO_COUNTRY_MAP[natCode];
        }
        dob = normalizeDateToIso(line2.slice(13, 19));
        const genderChar = line2[20];
        gender = genderChar === 'M' ? 'Male' : genderChar === 'F' ? 'Female' : 'Other';
        expiry = normalizeDateToIso(line2.slice(21, 27));
      }

      if (surname || givenName || passportNumber) {
        return {
          surname,
          givenName,
          nationality,
          passportNumber,
          dob,
          gender,
          passportExpiryDate: expiry
        };
      }
    }
  }
  return {};
}

export async function extractPassportData(imageBase64OrDataUrl: string): Promise<PassportOCRResult> {
  // Robust data URI and base64 extraction
  let base64Data = imageBase64OrDataUrl.trim();
  let mimeType = 'image/jpeg';

  if (base64Data.startsWith('data:')) {
    const commaIndex = base64Data.indexOf(',');
    if (commaIndex !== -1) {
      const header = base64Data.substring(0, commaIndex);
      base64Data = base64Data.substring(commaIndex + 1);

      const mimeMatch = header.match(/data:([a-zA-Z0-9\/-]+)/);
      if (mimeMatch) {
        mimeType = mimeMatch[1].toLowerCase();
      }
    }
  }

  // Strip all whitespace, line breaks and carriage returns from base64 string
  base64Data = base64Data.replace(/[\r\n\s]/g, '');

  // Normalize mimeType for Gemini Vision
  if (mimeType.includes('pdf')) {
    mimeType = 'application/pdf';
  } else if (mimeType.includes('png')) {
    mimeType = 'image/png';
  } else if (mimeType.includes('webp')) {
    mimeType = 'image/webp';
  } else if (mimeType.includes('heic') || mimeType.includes('heif')) {
    mimeType = 'image/heic';
  } else {
    mimeType = 'image/jpeg';
  }

  const ai = getGenAIClient();
  if (!ai) {
    throw new Error('AI Vision Service is not configured. GEMINI_API_KEY environment variable is missing.');
  }

  // Active multimodal models: gemini-3.1-flash-lite is responsive and has available quota
  const candidateModels = ['gemini-3.1-flash-lite', 'gemini-flash-lite-latest', 'gemini-flash-latest', 'gemini-3.8-flash'];
  let lastError: any = null;

  for (const modelName of candidateModels) {
    try {
      const response = await ai.models.generateContent({
        model: modelName,
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  data: base64Data,
                  mimeType: mimeType
                }
              },
              {
                text: `You are an expert Passport, Visa, and Identity Verification OCR specialist for Indian Government Foreign Guest Form C Compliance and Domestic Guest Registration.
Examine this identity document or passport photograph carefully.

INSPECTION INSTRUCTIONS:
1. MULTI-ORIENTATION: Mobile camera photos may be taken vertically (portrait) while the passport is horizontal. The document may be rotated 90° clockwise, 90° counter-clockwise, or upside down. Rotate your reading perspective mentally to read all text accurately regardless of photo orientation.
2. TYPES OF DOCUMENTS: This can be an international passport, Indian passport, Visa sticker/e-Visa, or Government photo ID (Aadhaar, Voter ID, Driver's License, National ID).
3. BIOMETRIC DETAILS TO EXTRACT:
- givenName: First and middle names (e.g. "Elena Camille", "John William", "Rohan")
- surname: Family name / Surname / Nom (e.g. "Smith", "Rostova", "Sharma"). If only a single name appears on the document, set givenName to that name and leave surname empty.
- gender: Exactly "Male", "Female", or "Other".
- dob: Date of birth in YYYY-MM-DD format (e.g. "1990-05-18").
- nationality: Country of citizenship (e.g. "France", "United States", "India", "United Kingdom", "Germany", "Australia", "Japan", etc.).
- passportNumber: Alphanumeric document or passport number without spaces or punctuation.
- passportIssueDate: Date of issue in YYYY-MM-DD format (if visible).
- passportExpiryDate: Date of expiry in YYYY-MM-DD format (if visible).
- passportIssuePlace: Issuing authority, city, or place of issue (e.g. "Paris", "Washington", "New Delhi", "London").
- rawExtractedText: All readable text from the document, especially any 2-line or 3-line MRZ codes (starting with P<, I<, V<) and bio-data fields.

CRITICAL INSTRUCTIONS:
- Format all dates (dob, passportIssueDate, passportExpiryDate) strictly as YYYY-MM-DD.
- If a field is not present or cannot be read, set it to "". Do NOT fabricate information.
- Output ONLY valid JSON matching the schema.`
              }
            ]
          }
        ],
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              givenName: { type: Type.STRING },
              surname: { type: Type.STRING },
              gender: { type: Type.STRING },
              dob: { type: Type.STRING },
              nationality: { type: Type.STRING },
              passportNumber: { type: Type.STRING },
              passportIssueDate: { type: Type.STRING },
              passportExpiryDate: { type: Type.STRING },
              passportIssuePlace: { type: Type.STRING },
              rawExtractedText: { type: Type.STRING },
              confidence: { type: Type.NUMBER }
            }
          }
        }
      });

      if (response && response.text) {
        const cleanJson = response.text.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
        const parsed = JSON.parse(cleanJson) as PassportOCRResult;

        // Clean name fields
        parsed.givenName = (parsed.givenName || '').trim();
        parsed.surname = (parsed.surname || '').trim();

        // If surname is missing but givenName has multiple words, split last word into surname
        if (!parsed.surname && parsed.givenName.includes(' ')) {
          const parts = parsed.givenName.split(/\s+/);
          parsed.surname = parts.pop() || '';
          parsed.givenName = parts.join(' ');
        }

        // Clean passport number
        if (parsed.passportNumber) {
          parsed.passportNumber = parsed.passportNumber.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        }

        // Expand 3-letter country codes
        if (parsed.nationality) {
          const codeUpper = parsed.nationality.trim().toUpperCase();
          if (ISO_COUNTRY_MAP[codeUpper]) {
            parsed.nationality = ISO_COUNTRY_MAP[codeUpper];
          }
        }

        // Standardize gender
        if (parsed.gender) {
          const g = parsed.gender.trim().toLowerCase();
          if (g.startsWith('f')) parsed.gender = 'Female';
          else if (g.startsWith('m')) parsed.gender = 'Male';
          else parsed.gender = 'Other';
        } else {
          parsed.gender = 'Female';
        }

        // Normalize all dates to YYYY-MM-DD
        parsed.dob = normalizeDateToIso(parsed.dob);
        parsed.passportIssueDate = normalizeDateToIso(parsed.passportIssueDate);
        parsed.passportExpiryDate = normalizeDateToIso(parsed.passportExpiryDate);
        parsed.confidence = parsed.confidence || 0.96;

        // Cross-check with MRZ parser on rawExtractedText if some fields are missing
        if (parsed.rawExtractedText) {
          const mrz = parseMrzText(parsed.rawExtractedText);
          if (!parsed.passportNumber && mrz.passportNumber) parsed.passportNumber = mrz.passportNumber;
          if (!parsed.surname && mrz.surname) parsed.surname = mrz.surname;
          if (!parsed.givenName && mrz.givenName) parsed.givenName = mrz.givenName;
          if (!parsed.dob && mrz.dob) parsed.dob = mrz.dob;
          if (!parsed.nationality && mrz.nationality) parsed.nationality = mrz.nationality;
          if (!parsed.passportExpiryDate && mrz.passportExpiryDate) parsed.passportExpiryDate = mrz.passportExpiryDate;
        }

        // Verify that we extracted meaningful identity data
        if (parsed.passportNumber || parsed.givenName || parsed.surname || parsed.dob) {
          return parsed;
        }

        console.log(`Model ${modelName} returned no key fields, trying next fallback...`);
      }
    } catch (err: any) {
      const errMsg = err?.message || (typeof err === 'string' ? err : JSON.stringify(err));
      console.log(`OCR candidate ${modelName} unavailable (${errMsg.slice(0, 80)}). Trying fallback...`);
      lastError = err;
    }
  }

  // Backup: Attempt MRZ parse on any raw text representation
  const mrzParsed = parseMrzText(imageBase64OrDataUrl);
  if (mrzParsed.passportNumber || mrzParsed.surname || mrzParsed.givenName) {
    return {
      givenName: mrzParsed.givenName || '',
      surname: mrzParsed.surname || '',
      gender: mrzParsed.gender || 'Other',
      dob: normalizeDateToIso(mrzParsed.dob),
      nationality: mrzParsed.nationality || '',
      passportNumber: mrzParsed.passportNumber || '',
      passportIssueDate: '',
      passportExpiryDate: normalizeDateToIso(mrzParsed.passportExpiryDate),
      passportIssuePlace: '',
      rawExtractedText: 'Extracted via MRZ Scanner',
      confidence: 0.9
    };
  }

  // Throw authentic, actionable error message
  throw new Error(
    lastError?.message?.includes('503') || lastError?.message?.includes('UNAVAILABLE')
      ? 'The AI vision service is currently experiencing high demand. Please try again in a few moments.'
      : 'Could not detect passport details from the uploaded image. Please ensure the passport bio-data page or MRZ lines are in focus, well-lit, and glare-free.'
  );
}
