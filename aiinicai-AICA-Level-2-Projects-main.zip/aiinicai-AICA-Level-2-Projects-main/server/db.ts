import fs from 'fs';
import path from 'path';
import { 
  GuestRegistration, MenuItem, FoodOrder, BillingFolio, ChatMessage,
  HousekeepingRequest, HousekeepingStatus, Invoice, InvoiceItem, PaymentTransaction, ExpenseItem,
  ServiceFeedback
} from '../src/types.js';
import { INITIAL_GUESTS, INITIAL_MENU_ITEMS, INITIAL_ORDERS, INITIAL_CHATS, INITIAL_EXPENSES, INITIAL_FEEDBACK } from './initialData.js';

interface DatabaseSchema {
  guests: GuestRegistration[];
  menuItems: MenuItem[];
  orders: FoodOrder[];
  billingFolios: BillingFolio[];
  chats: ChatMessage[];
  housekeepingRequests: HousekeepingRequest[];
  invoices: Invoice[];
  transactions: PaymentTransaction[];
  expenses: ExpenseItem[];
  feedbacks: ServiceFeedback[];
  lastUpdated: string;
}

const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'homestay_data.json');

function computeBilling(guest: GuestRegistration, orders: FoodOrder[]): BillingFolio {
  const checkIn = new Date(guest.checkInDate || Date.now());
  const checkOut = new Date(guest.checkOutDate || Date.now());
  const diffTime = Math.max(1, Math.round((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)));
  const roomTotal = (guest.roomRate || 5500) * diffTime;
  
  const guestOrders = orders.filter(o => o.guestId === guest.id && o.status !== 'cancelled');
  const foodOrdersTotal = guestOrders.reduce((acc, curr) => acc + curr.total, 0);
  const experiencesTotal = 500; // Heritage estate conservation contribution & guide
  const subtotal = roomTotal + foodOrdersTotal + experiencesTotal;
  const conservationLevy = Math.round(subtotal * 0.05);
  const taxes = Math.round(subtotal * 0.12);
  const grandTotal = subtotal + conservationLevy + taxes;
  const paidAmount = guest.status === 'checked_out' ? grandTotal : Math.round(roomTotal * 0.5);
  const balanceDue = Math.max(0, grandTotal - paidAmount);

  return {
    id: `FOLIO-${guest.id}`,
    guestId: guest.id,
    guestName: `${guest.givenName} ${guest.surname}`.trim(),
    roomNumber: guest.roomNumber,
    checkInDate: guest.checkInDate,
    checkOutDate: guest.checkOutDate,
    roomRatePerNight: guest.roomRate || 5500,
    nights: diffTime,
    roomTotal,
    foodOrdersTotal,
    experiencesTotal,
    conservationLevy,
    taxes,
    grandTotal,
    paidAmount,
    balanceDue,
    status: balanceDue === 0 ? 'paid' : (paidAmount > 0 ? 'partially_paid' : 'unpaid'),
    payments: [
      {
        id: `PAY-${Date.now()}-1`,
        date: guest.checkInDate,
        amount: paidAmount,
        method: 'Card',
        reference: 'AUTH-PRE-9921'
      }
    ]
  };
}

class HomestayDatabase {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDataDirectory();
    this.data = this.loadData();
  }

  private ensureDataDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadData(): DatabaseSchema {
    const initialHousekeeping: HousekeepingRequest[] = [
      {
        id: 'HK-901',
        guestId: 'GUEST-8021',
        guestName: 'Elena Rostova',
        roomNumber: 'Suite 101 - The Royal Haveli',
        requestType: 'Fresh Towels',
        preferredTime: 'Immediate (Next 30 mins)',
        notes: '2 extra large bath towels and lavender room mist please.',
        status: 'completed',
        requestedAt: new Date(Date.now() - 3600000 * 2).toISOString(),
        completedAt: new Date(Date.now() - 3600000).toISOString(),
        assignedStaff: 'Raju (Floor Captain)'
      },
      {
        id: 'HK-902',
        guestId: 'GUEST-8022',
        guestName: 'Vikram & Ananya Malhotra',
        roomNumber: 'Suite 103 - Shekhawati Fresco',
        requestType: 'Standard Tidy',
        preferredTime: 'Morning (9:00 - 11:00 AM)',
        notes: 'Please tidy before we return from morning haveli walk.',
        status: 'in_progress',
        requestedAt: new Date(Date.now() - 1800000).toISOString(),
        assignedStaff: 'Shanti Devi'
      }
    ];

    if (fs.existsSync(DB_FILE)) {
      try {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        parsed.housekeepingRequests = parsed.housekeepingRequests || initialHousekeeping;
        parsed.invoices = parsed.invoices || [];
        parsed.transactions = parsed.transactions || [];
        parsed.expenses = parsed.expenses && parsed.expenses.length > 0 ? parsed.expenses : INITIAL_EXPENSES;
        parsed.feedbacks = parsed.feedbacks && parsed.feedbacks.length > 0 ? parsed.feedbacks : INITIAL_FEEDBACK;
        // Ensure menuItems reflects the updated Rajasthani cuisine
        parsed.menuItems = INITIAL_MENU_ITEMS;
        return parsed;
      } catch (err) {
        console.error('Failed to parse database file, resetting to initial dataset:', err);
      }
    }

    const initialBilling = INITIAL_GUESTS.map(g => computeBilling(g, INITIAL_ORDERS));
    const initial: DatabaseSchema = {
      guests: INITIAL_GUESTS,
      menuItems: INITIAL_MENU_ITEMS,
      orders: INITIAL_ORDERS,
      billingFolios: initialBilling,
      chats: INITIAL_CHATS,
      housekeepingRequests: initialHousekeeping,
      invoices: [],
      transactions: [],
      expenses: INITIAL_EXPENSES,
      feedbacks: INITIAL_FEEDBACK,
      lastUpdated: new Date().toISOString()
    };

    this.saveDataDirect(initial);
    return initial;
  }

  private saveDataDirect(data: DatabaseSchema) {
    try {
      this.ensureDataDirectory();
      fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error persisting database:', err);
    }
  }

  private persist() {
    this.data.lastUpdated = new Date().toISOString();
    this.saveDataDirect(this.data);
  }

  // Guests
  public getGuests(): GuestRegistration[] {
    return this.data.guests;
  }

  public getGuestById(id: string): GuestRegistration | undefined {
    return this.data.guests.find(g => g.id === id);
  }

  public getGuestByEmail(email: string): GuestRegistration | undefined {
    if (!email) return undefined;
    const norm = email.trim().toLowerCase();
    return this.data.guests.find(g => (g.email || '').trim().toLowerCase() === norm);
  }

  public addGuest(guest: GuestRegistration): GuestRegistration {
    this.data.guests.unshift(guest);
    // Automatically generate billing folio
    const folio = computeBilling(guest, this.data.orders);
    this.data.billingFolios.unshift(folio);
    
    // Add automated welcome chat
    const welcomeChat: ChatMessage = {
      id: `chat-${Date.now()}`,
      guestId: guest.id,
      roomNumber: guest.roomNumber,
      sender: 'concierge_ai',
      senderName: 'Heritique Concierge',
      message: `Namaste ${guest.givenName}! Welcome to ${guest.roomNumber}. Your check-in registration has been received and logged in our system. You can browse our dining menu, check your folio, or message us here anytime for room service and travel advice.`,
      timestamp: new Date().toISOString(),
      read: false
    };
    this.data.chats.push(welcomeChat);

    this.persist();
    return guest;
  }

  public updateGuest(id: string, updates: Partial<GuestRegistration>): GuestRegistration | null {
    const index = this.data.guests.findIndex(g => g.id === id);
    if (index === -1) return null;
    this.data.guests[index] = { ...this.data.guests[index], ...updates };
    
    // Update folio
    const folioIndex = this.data.billingFolios.findIndex(b => b.guestId === id);
    if (folioIndex !== -1) {
      this.data.billingFolios[folioIndex] = computeBilling(this.data.guests[index], this.data.orders);
    }
    this.persist();
    return this.data.guests[index];
  }

  public deleteGuest(id: string): boolean {
    const prevLen = this.data.guests.length;
    this.data.guests = this.data.guests.filter(g => g.id !== id);
    this.data.billingFolios = this.data.billingFolios.filter(b => b.guestId !== id);
    this.data.orders = this.data.orders.filter(o => o.guestId !== id);
    this.data.chats = this.data.chats.filter(c => c.guestId !== id);
    this.persist();
    return this.data.guests.length < prevLen;
  }

  // Menu
  public getMenu(): MenuItem[] {
    return this.data.menuItems;
  }

  // Orders
  public getOrders(): FoodOrder[] {
    return this.data.orders;
  }

  public addOrder(order: FoodOrder): FoodOrder {
    this.data.orders.unshift(order);
    // Recalculate billing
    const folioIndex = this.data.billingFolios.findIndex(b => b.guestId === order.guestId);
    if (folioIndex !== -1) {
      const guest = this.data.guests.find(g => g.id === order.guestId);
      if (guest) {
        this.data.billingFolios[folioIndex] = computeBilling(guest, this.data.orders);
      }
    }

    // Add chat update for order confirmation
    const orderChat: ChatMessage = {
      id: `chat-${Date.now()}`,
      guestId: order.guestId,
      roomNumber: order.roomNumber,
      sender: 'staff',
      senderName: 'Royal Haveli Kitchen',
      message: `Your culinary order #${order.id.slice(-4)} for ${order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')} has been received by our chefs and is being freshly prepared (~${order.estimatedMinutes} mins).`,
      timestamp: new Date().toISOString(),
      read: false
    };
    this.data.chats.push(orderChat);

    this.persist();
    return order;
  }

  public updateOrderStatus(orderId: string, status: FoodOrder['status']): FoodOrder | null {
    const order = this.data.orders.find(o => o.id === orderId);
    if (!order) return null;
    order.status = status;
    if (status === 'delivered') {
      order.deliveredAt = new Date().toISOString();
    }

    // Send real-time chat notification to guest
    const statusMessages: Record<string, string> = {
      preparing: `Your order #${order.id.slice(-4)} is currently sizzling in the kitchen.`,
      on_the_way: `Your order #${order.id.slice(-4)} is on its way to ${order.roomNumber}!`,
      delivered: `Order #${order.id.slice(-4)} has been delivered. Bon Appétit! Please ring us if you need extra condiments or tea.`
    };
    if (statusMessages[status]) {
      this.data.chats.push({
        id: `chat-${Date.now()}`,
        guestId: order.guestId,
        roomNumber: order.roomNumber,
        sender: 'staff',
        senderName: 'Room Service Concierge',
        message: statusMessages[status],
        timestamp: new Date().toISOString(),
        read: false
      });
    }

    this.persist();
    return order;
  }

  // Billing
  public getBillingFolios(): BillingFolio[] {
    return this.data.billingFolios;
  }

  public getBillingByGuestId(guestId: string): BillingFolio | undefined {
    let folio = this.data.billingFolios.find(b => b.guestId === guestId);
    if (!folio) {
      const guest = this.data.guests.find(g => g.id === guestId);
      if (guest) {
        folio = computeBilling(guest, this.data.orders);
        this.data.billingFolios.push(folio);
        this.persist();
      }
    }
    return folio;
  }

  public recordPayment(guestId: string, amount: number, method: 'Card' | 'UPI' | 'Cash' | 'Bank Transfer'): BillingFolio | null {
    const folio = this.getBillingByGuestId(guestId);
    if (!folio) return null;

    folio.payments.push({
      id: `PAY-${Date.now()}`,
      date: new Date().toISOString(),
      amount,
      method,
      reference: `RCPT-${Math.floor(100000 + Math.random() * 900000)}`
    });

    folio.paidAmount += amount;
    folio.balanceDue = Math.max(0, folio.grandTotal - folio.paidAmount);
    folio.status = folio.balanceDue === 0 ? 'paid' : 'partially_paid';

    this.persist();
    return folio;
  }

  // Chats
  public getChats(guestId?: string): ChatMessage[] {
    if (guestId) {
      return this.data.chats.filter(c => c.guestId === guestId);
    }
    return this.data.chats;
  }

  public addChatMessage(msg: ChatMessage): ChatMessage {
    this.data.chats.push(msg);
    this.persist();
    return msg;
  }

  // Housekeeping Requests
  public getHousekeepingRequests(guestId?: string): HousekeepingRequest[] {
    if (guestId) {
      return (this.data.housekeepingRequests || []).filter(r => r.guestId === guestId);
    }
    return this.data.housekeepingRequests || [];
  }

  public addHousekeepingRequest(req: HousekeepingRequest): HousekeepingRequest {
    if (!this.data.housekeepingRequests) this.data.housekeepingRequests = [];
    this.data.housekeepingRequests.unshift(req);

    // Send instant automated concierge confirmation chat
    const typeLabel = req.requestType;
    const timeLabel = req.preferredTime;
    const confirmChat: ChatMessage = {
      id: `chat-${Date.now()}`,
      guestId: req.guestId,
      roomNumber: req.roomNumber,
      sender: 'concierge_ai',
      senderName: 'Housekeeping Desk',
      message: `Namaste! We received your housekeeping request for "${typeLabel}" (${timeLabel}). Our estate floor supervisor has assigned staff to your suite. Request ID: #${req.id}.`,
      timestamp: new Date().toISOString(),
      read: false
    };
    this.data.chats.push(confirmChat);

    this.persist();
    return req;
  }

  public updateHousekeepingStatus(id: string, status: HousekeepingStatus, assignedStaff?: string): HousekeepingRequest | null {
    if (!this.data.housekeepingRequests) return null;
    const item = this.data.housekeepingRequests.find(r => r.id === id);
    if (!item) return null;

    item.status = status;
    if (assignedStaff) item.assignedStaff = assignedStaff;
    if (status === 'completed') {
      item.completedAt = new Date().toISOString();
      this.data.chats.push({
        id: `chat-${Date.now()}`,
        guestId: item.guestId,
        roomNumber: item.roomNumber,
        sender: 'staff',
        senderName: item.assignedStaff || 'Housekeeping Staff',
        message: `Your housekeeping service (${item.requestType}) for ${item.roomNumber} has been completed with fresh linen and room refresh. Please let us know if anything else is needed!`,
        timestamp: new Date().toISOString(),
        read: false
      });
    }

    this.persist();
    return item;
  }

  // Automated Invoice Generation & Checkout System
  public generateInvoice(guestId: string, options?: { checkoutDate?: string; additionalServices?: { description: string; price: number }[] }): Invoice {
    const guest = this.getGuestById(guestId) || INITIAL_GUESTS[0];
    const checkIn = new Date(guest.checkInDate || Date.now());
    const checkOut = options?.checkoutDate ? new Date(options.checkoutDate) : new Date(guest.checkOutDate || Date.now());
    const nights = Math.max(1, Math.round((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)));
    const roomRatePerNight = guest.roomRate || 5500;
    const roomTotal = roomRatePerNight * nights;

    const guestOrders = (this.data.orders || []).filter(o => o.guestId === guest.id && o.status !== 'cancelled');
    const foodOrdersTotal = guestOrders.reduce((sum, o) => sum + o.total, 0);

    const items: InvoiceItem[] = [
      {
        id: `ITEM-ROOM-${guest.id}`,
        category: 'accommodation',
        description: `Lodging (${guest.roomType || 'Heritage Courtyard Suite'}) - ${guest.roomNumber}`,
        quantity: nights,
        unitPrice: roomRatePerNight,
        total: roomTotal
      }
    ];

    // Itemize food orders
    if (guestOrders.length > 0) {
      guestOrders.forEach((order) => {
        items.push({
          id: `ITEM-FOOD-${order.id}`,
          category: 'dining',
          description: `In-Room Dining (Order #${order.id.slice(-4)}: ${order.items.map(i => `${i.quantity}x ${i.name}`).join(', ')})`,
          quantity: 1,
          unitPrice: order.total,
          total: order.total
        });
      });
    }

    // Additional homestay experiences or custom additions
    const baseExperiences: { description: string; price: number }[] = [
      { description: 'Guided Stepwell & Haveli Fresco Walking Tour', price: 500 }
    ];
    if (options?.additionalServices && options.additionalServices.length > 0) {
      baseExperiences.push(...options.additionalServices);
    }

    baseExperiences.forEach((exp, idx) => {
      items.push({
        id: `ITEM-SRV-${idx + 1}`,
        category: 'service',
        description: exp.description,
        quantity: 1,
        unitPrice: exp.price,
        total: exp.price
      });
    });

    const servicesTotal = baseExperiences.reduce((sum, e) => sum + e.price, 0);
    const subtotal = roomTotal + foodOrdersTotal + servicesTotal;
    const conservationLevy = Math.round(subtotal * 0.05); // 5% Heritage Monument Preservation Fund
    const taxes = Math.round(roomTotal * 0.12 + foodOrdersTotal * 0.05 + servicesTotal * 0.12); // GST
    const grandTotal = subtotal + conservationLevy + taxes;

    // Check existing payments recorded in billing folio
    const folio = this.getBillingByGuestId(guest.id);
    const previouslyPaid = folio ? folio.paidAmount : 0;
    const balanceDue = Math.max(0, grandTotal - previouslyPaid);

    const invoiceId = `INV-2026-${guest.id.replace(/[^0-9]/g, '') || Math.floor(1000 + Math.random() * 9000)}`;

    const newInvoice: Invoice = {
      id: invoiceId,
      guestId: guest.id,
      guestName: `${guest.givenName} ${guest.surname}`.trim(),
      guestEmail: guest.email || '',
      guestPhone: guest.phone || '',
      roomNumber: guest.roomNumber,
      roomType: guest.roomType || 'Heritage Courtyard Suite',
      checkInDate: guest.checkInDate,
      checkOutDate: options?.checkoutDate || guest.checkOutDate,
      nights,
      roomRatePerNight,
      items,
      subtotal,
      conservationLevy,
      taxes,
      grandTotal,
      paidAmount: previouslyPaid,
      balanceDue,
      status: balanceDue === 0 ? 'paid' : 'unpaid',
      generatedAt: new Date().toISOString(),
      qrVerificationCode: `HERITIQUE-INV-${invoiceId}-GSTIN-08AAACH1924R1Z5`,
      notes: 'Official Tax Invoice under Govt. of Rajasthan Hospitality & Tourism Rules.'
    };

    if (!this.data.invoices) this.data.invoices = [];
    const existingIndex = this.data.invoices.findIndex(inv => inv.guestId === guest.id);
    if (existingIndex !== -1) {
      this.data.invoices[existingIndex] = newInvoice;
    } else {
      this.data.invoices.unshift(newInvoice);
    }

    this.persist();
    return newInvoice;
  }

  public getInvoiceByGuestId(guestId: string): Invoice | undefined {
    let invoice = (this.data.invoices || []).find(inv => inv.guestId === guestId);
    if (!invoice) {
      invoice = this.generateInvoice(guestId);
    }
    return invoice;
  }

  public getInvoiceById(id: string): Invoice | undefined {
    return (this.data.invoices || []).find(inv => inv.id === id);
  }

  public getAllInvoices(): Invoice[] {
    return this.data.invoices || [];
  }

  public processPayment(payload: {
    invoiceId: string;
    guestId: string;
    amount: number;
    gateway: 'Stripe' | 'PayPal' | 'UPI' | 'Card';
    paymentDetails: any;
  }): { success: boolean; transaction: PaymentTransaction; invoice: Invoice } {
    let invoice = this.getInvoiceById(payload.invoiceId) || this.getInvoiceByGuestId(payload.guestId);
    if (!invoice) {
      invoice = this.generateInvoice(payload.guestId);
    }

    const gatewayTxnId = payload.gateway === 'Stripe'
      ? `pi_${Math.random().toString(36).substring(2, 14)}`
      : payload.gateway === 'PayPal'
      ? `PAYPAL-TXN-${Date.now()}`
      : `UPI-REF-${Math.floor(100000000000 + Math.random() * 900000000000)}`;

    const transaction: PaymentTransaction = {
      id: `TXN-${Date.now()}`,
      invoiceId: invoice.id,
      guestId: invoice.guestId,
      guestName: invoice.guestName,
      roomNumber: invoice.roomNumber,
      amount: payload.amount,
      currency: 'INR',
      gateway: payload.gateway,
      gatewayTransactionId: gatewayTxnId,
      status: 'succeeded',
      paymentMethodDetails: {
        cardBrand: payload.paymentDetails?.cardBrand || 'Visa',
        cardLast4: payload.paymentDetails?.cardLast4 || '4242',
        paypalEmail: payload.paymentDetails?.paypalEmail,
        upiId: payload.paymentDetails?.upiId
      },
      timestamp: new Date().toISOString(),
      receiptUrl: `https://heritique.homestay/receipts/${invoice.id}`
    };

    if (!this.data.transactions) this.data.transactions = [];
    this.data.transactions.unshift(transaction);

    // Update Invoice status
    invoice.paidAmount = invoice.grandTotal;
    invoice.balanceDue = 0;
    invoice.status = 'paid';
    invoice.paidAt = new Date().toISOString();
    invoice.paymentGateway = payload.gateway;
    invoice.transactionId = transaction.id;

    // Update Guest status to checked_out
    this.updateGuest(invoice.guestId, { status: 'checked_out' });

    // Update Billing Folio
    const folio = this.getBillingByGuestId(invoice.guestId);
    if (folio) {
      folio.payments.push({
        id: `PAY-${Date.now()}`,
        date: new Date().toISOString(),
        amount: payload.amount,
        method: payload.gateway === 'Card' || payload.gateway === 'Stripe' ? 'Card' : payload.gateway === 'UPI' ? 'UPI' : 'Bank Transfer',
        reference: gatewayTxnId
      });
      folio.paidAmount = folio.grandTotal;
      folio.balanceDue = 0;
      folio.status = 'paid';
    }

    // Add automated farewell & checkout receipt chat
    this.data.chats.push({
      id: `chat-${Date.now()}`,
      guestId: invoice.guestId,
      roomNumber: invoice.roomNumber,
      sender: 'concierge_ai',
      senderName: 'Heritique Front Desk',
      message: `Thank you for staying at Heritique Homestay! Your checkout has been processed and invoice #${invoice.id} settled in full via ${payload.gateway} (₹${payload.amount.toLocaleString('en-IN')}). Safe travels and padharo sa!`,
      timestamp: new Date().toISOString(),
      read: false
    });

    this.persist();
    return { success: true, transaction, invoice };
  }

  public getTransactions(guestId?: string): PaymentTransaction[] {
    if (guestId) {
      return (this.data.transactions || []).filter(t => t.guestId === guestId);
    }
    return this.data.transactions || [];
  }

  // Expenses
  public getExpenses(): ExpenseItem[] {
    return this.data.expenses || [];
  }

  public addExpense(expense: ExpenseItem): ExpenseItem {
    if (!this.data.expenses) {
      this.data.expenses = [];
    }
    this.data.expenses.unshift(expense);
    this.persist();
    return expense;
  }

  public updateExpenseStatus(
    id: string, 
    status: 'approved' | 'rejected', 
    approvedBy?: string, 
    rejectionReason?: string
  ): ExpenseItem | undefined {
    if (!this.data.expenses) {
      this.data.expenses = [];
    }
    const exp = this.data.expenses.find(e => e.id === id);
    if (!exp) return undefined;

    exp.status = status;
    if (status === 'approved') {
      exp.approvedBy = approvedBy || 'Admin';
      exp.approvedAt = new Date().toISOString();
      exp.rejectionReason = undefined;
    } else {
      exp.rejectionReason = rejectionReason || 'Declined by Admin';
      exp.approvedBy = approvedBy || 'Admin';
      exp.approvedAt = new Date().toISOString();
    }

    this.persist();
    return exp;
  }

  // Post-Service Feedback Methods
  public getFeedbacks(filters?: { guestId?: string; category?: string; targetId?: string }): ServiceFeedback[] {
    if (!this.data.feedbacks) {
      this.data.feedbacks = INITIAL_FEEDBACK;
    }
    let list = this.data.feedbacks;
    if (filters?.guestId) {
      list = list.filter(f => f.guestId === filters.guestId);
    }
    if (filters?.category) {
      list = list.filter(f => f.category === filters.category);
    }
    if (filters?.targetId) {
      list = list.filter(f => f.targetId === filters.targetId);
    }
    return list;
  }

  public addFeedback(feedback: ServiceFeedback): ServiceFeedback {
    if (!this.data.feedbacks) {
      this.data.feedbacks = [];
    }
    this.data.feedbacks.unshift(feedback);
    this.persist();
    return feedback;
  }

  public updateFeedbackFollowUp(
    id: string, 
    status: 'acknowledged' | 'in_review' | 'resolved' | 'thanked'
  ): ServiceFeedback | undefined {
    if (!this.data.feedbacks) {
      this.data.feedbacks = [];
    }
    const fb = this.data.feedbacks.find(f => f.id === id);
    if (!fb) return undefined;
    fb.followUpStatus = status;
    this.persist();
    return fb;
  }
}

export const db = new HomestayDatabase();
