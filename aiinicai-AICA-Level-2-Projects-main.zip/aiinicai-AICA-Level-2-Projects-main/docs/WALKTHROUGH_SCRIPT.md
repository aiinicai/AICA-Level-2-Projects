# 5-Minute Technical & Operational Walkthrough Script
## Heritique Haveli Homestay: Guest Management, Form C Compliance, PWA & Google Workspace Integration

---

### Walkthrough Metadata
- **Presenter Role:** Lead Full-Stack Solutions Architect & Hospitality Engineer
- **Target Audience:** Technical Evaluators, Hotel Operations Directors, Ministry of Tourism Auditors, and Full-Stack Developers
- **Format:** Live Interactive Demo with Screen-by-Screen Visual Cues and Technical Deep Dive
- **Total Duration:** Exactly 5 Minutes (0:00 – 5:00)
- **Live URLs:**
  - Development App URL: `https://ais-dev-hkgrdukbtx7seqytol6yqq-915110563099.asia-southeast1.run.app`
  - Production / Preview URL: `https://ais-pre-hkgrdukbtx7seqytol6yqq-915110563099.asia-southeast1.run.app`

---

## Timeline Breakdown

```
[0:00 - 0:45] Minute 1: Introduction, Architecture & PWA Offline-First Foundation
[0:45 - 1:45] Minute 2: Passport OCR, Live Camera Selfie & Statutory Form C Compliance
[1:45 - 2:45] Minute 3: In-Room Dining, Housekeeping & AI Concierge with Search Grounding
[2:45 - 3:45] Minute 4: Itemized Invoicing, Multi-Gateway Checkout & Post-Service Feedback
[3:45 - 5:00] Minute 5: Google Sheets Master Operations Ledger, Staff Admin & Q&A Conclusion
```

---

### Minute 1 (0:00 - 0:45) — Architecture Overview & PWA Foundation
**Screen Action:**
- Show the Landing Page (`HomePage.tsx`). Note the Rajputana heritage aesthetic, responsive layout, weather widget with Google Search grounding, and PWA Install modal trigger.
- Open Chrome DevTools (`F12` -> Application tab) briefly to display Service Worker status, Web App Manifest (`manifest.json`), and standalone display mode.

**Spoken Script:**
> *"Namaste and welcome. Today I am presenting the Heritique Haveli Guest Management System—a full-stack, Progressive Web Application purpose-built for Rajasthan’s luxury boutique heritage properties.*
> 
> *Behind this regal 1924 Shekhawati aesthetic lies a modern, decoupled enterprise architecture: a React 19 and TypeScript frontend styled with Tailwind CSS, an Express TypeScript proxy backend, and bidirectional integration with Google Workspace—specifically Google Sheets API v4 and Google Drive API v3—alongside Firebase Authentication and Cloud Firestore.*
> 
> *As a PWA, it complies with modern offline-first standards: service workers cache static app shells, an offline banner alerts travelers in low-connectivity desert zones, and install prompts allow guests and estate staff to run it as a standalone app on iOS, Android, and desktop without app store friction."*

---

### Minute 2 (0:45 - 1:45) — Passport OCR, Live Selfie & Statutory Form C Compliance
**Screen Action:**
- Navigate to the **Guest Check-in** tab (`/checkin`).
- Click "Upload Passport or ID Document" or select the sample passport.
- Show the optical extraction of Given Name, Surname, Passport Number, Nationality, DOB, and Expiry Date.
- Open the live **Selfie Camera modal** (`CameraCaptureModal.tsx`), show camera canvas feed, take a picture, and sign on the canvas `SignaturePad.tsx`.
- Click **"Complete Check-in & Generate Form C"**. Show the generated Bureau of Immigration Form C certificate modal.

**Spoken Script:**
> *"Let’s inspect our most critical compliance feature: automated statutory check-in. In India, hotels hosting foreign travelers must submit Bureau of Immigration Form C records within 24 hours.*
> 
> *Guests can simply upload a passport scan or camera photo. Our server-side Gemini 2.5 Multimodal pipeline parses the Machine Readable Zone (MRZ) and visual fields, extracting name, document number, nationality, and expiry with zero client-side regex fragility.*
> 
> *Next, we capture the guest's live photo via WebRTC MediaDevices and their legal signature via a HTML5 vector canvas pad. Upon submission, the applet automatically generates an official, printable Form C document with statutory registration numbers, while uploading base64 assets to Google Drive and recording the row in Google Sheets."*

---

### Minute 3 (1:45 - 2:45) — In-Room Dining, Housekeeping & AI Concierge with Search Grounding
**Screen Action:**
- Click the **In-Room Dining** tab (`DiningMenuSection.tsx`). Show the authentic Marwari menu (Dal Baati Churma, Ker Sangri, Jodhpuri Kachori).
- Add items to the cart, select delivery time, and place an order. Notice the live order status progress bar.
- Switch to the **AI Itinerary** tab (`AiItineraryPlanner.tsx`). Generate a 3-day cultural tour of Jaipur & Amber Fort.
- Highlight the **Weather Widget** (`WeatherWidget.tsx`) showing live Shekhawati temperatures and grounding citations from Google Search.

**Spoken Script:**
> *"For in-house guest services, we provide a contactless In-Room Dining module and Housekeeping portal. Guests order authentic Marwari culinary delicacies, customized with spice levels and room delivery instructions. The order immediately syncs to the kitchen and updates the guest's billing folio.*
> 
> *Furthermore, guests can plan heritage excursions through our AI Itinerary Concierge. Powered by Gemini 2.5 with Google Search Grounding, it generates day-by-day itineraries tailored to current weather conditions, local Johari Bazar festivals, and monument hours, citing live web references rather than hallucinated historical facts."*

---

### Minute 4 (2:45 - 3:45) — Itemized Billing, Payment Gateways & Post-Service Feedback
**Screen Action:**
- Click **Billing & Folio** (`BillingFolioSection.tsx`). Show real-time accumulation of room charges, dining tabs, and the 5% Heritage Monument Conservation Fund + GST taxes.
- Click **"Automated Invoice & Checkout"** (`InvoiceCheckoutModal.tsx`).
- Demonstrate selecting payment gateways: **Stripe**, **PayPal**, or **UPI QR Code**. Complete simulated instant payment.
- Show the post-checkout **"Rate Your Stay & Homestay Experience"** banner. Click "Rate Stay Now ★".
- In the `FeedbackModal.tsx`, rate 5 stars, select tags (*Authentic Flavors*, *Spotless Linen*, *Royal Rajput Hospitality*), input review, adjust NPS to 10, and submit. Show confetti and live Google Sheet synchronization notice.

**Spoken Script:**
> *"Upon departure, checkout is fully automated. The system computes room tariffs, dining orders, service requests, and statutory taxes into an official GST-compliant Tax Invoice.*
> 
> *Guests can settle their folio instantly through Stripe credit card, PayPal international, or Indian UPI QR code. Once settled, the room status shifts to checked-out, and the post-service feedback module activates.*
> 
> *Guests can rate specific dining orders, individual housekeeping calls, or their overall stay across three discrete dimensions: Quality, Speed, and Staff Courtesy. Every rating, tag, comment, and Net Promoter Score is immediately dispatched to our database and appended into the dedicated 'Service Feedback' tab in Google Sheets."*

---

### Minute 5 (3:45 - 5:00) — Google Sheets Master Ledger, Staff Admin & Closing
**Screen Action:**
- Switch to the **Staff Admin** tab (`AdminDashboard.tsx`). Log in using GM demo or staff email.
- Show the 8 Haveli suite occupancy cards with live statuses.
- Click the **Service Feedback** tab in Admin: show average rating cards (4.9★), category breakdown, and follow-up status toggles (*Thanked*, *Acknowledged*, *Resolved*).
- Click the **Google Sheets Ledger & Database** tab (`GoogleSheetsLedger.tsx`).
- Show the 6 sub-tabs: *Guest Register & Form C*, *In-Room Dining Orders*, *Housekeeping Log*, *Billing Folios & Invoices*, *Service Feedback*, and *Firestore Cloud Backup*.
- Click **"Confirm & Sync to Google Sheets"**. Show the Google Sheets API response.

**Spoken Script:**
> *"Finally, let’s view the management cockpit. For homestay owners and managers like Thakur Mahendra Singh, our Staff Dashboard unifies room occupancy, expense approvals, KDS kitchen orders, and guest feedback.*
> 
> *Our Google Sheets Operations Ledger acts as the central single source of truth. With a single click or automatic check-in trigger, the applet synchronizes all data across six distinct Google Sheet tabs without requiring hotel staff to learn complex legacy software.*
> 
> *In summary, Heritique Haveli pairs 100-year-old Rajputana warmth with an ironclad, enterprise-ready cloud stack: automated Form C compliance, real-time Google Workspace two-way synchronization, Google Search-grounded AI planning, and seamless post-service feedback loops. Thank you, and I look forward to your questions."*
