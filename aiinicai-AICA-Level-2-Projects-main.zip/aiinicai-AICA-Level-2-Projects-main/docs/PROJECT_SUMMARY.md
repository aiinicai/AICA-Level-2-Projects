# Project Summary Document
## Heritique Haveli Homestay: Guest Management, Form C Compliance, PWA & Google Workspace Integration

---

## 1. Executive Summary
**Heritique Haveli Homestay** is a production-grade, full-stack Progressive Web Application (PWA) designed for boutique heritage hotels, havelis, and royal homestays across Rajasthan and India. It bridges the gap between regal 1924 Shekhawati Rajputana hospitality and modern cloud hospitality workflows.

The system addresses three critical operational bottlenecks faced by boutique hotels:
1. **Statutory Regulatory Compliance (Form C):** Foreign guests must be registered with the Indian Bureau of Immigration within 24 hours. The app eliminates manual clerical friction through AI-driven multimodal Passport OCR, camera selfie capture, digital vector signature pad, and instant Form C certificate generation.
2. **Contactless In-House Guest Experience:** In-room dining ordering with real-time order tracking, housekeeping & linen scheduling, Gemini 2.5 AI itinerary planning with live Google Search grounding, itemized billing folios, and automated checkout payment gateways (Stripe, PayPal, UPI).
3. **Operations Single Source of Truth:** Direct two-way integration with **Google Sheets API v4** and **Google Drive API v3**, maintaining a centralized **Master Operations Ledger** across six dedicated tabs (Guest Register & Form C, Dining Orders, Housekeeping Log, Invoices, Expenses, and Service Feedback), backed up by **Cloud Firestore**.

---

## 2. Technical Stack & Architectural Design

### 2.1 Frontend Architecture
- **Framework:** React 19 SPA running on Vite 6 with TypeScript.
- **Styling:** Tailwind CSS with custom royal Rajputana theme (`#0c2217` deep emerald, `#d4af37` burnished gold, `#8a2517` royal terracotta, `#fcf8f2` sandstone parchment).
- **Icons & Animation:** Lucide-React vector icon set, canvas confetti celebrations, custom SVG decorative jharokha borders.
- **Client Capabilities:** HTML5 WebRTC MediaDevices camera capture, Vector HTML5 Canvas for digital signatures, offline storage sync.
- **PWA Compliance:** Custom Service Worker (`public/sw.js`), Web App Manifest (`public/manifest.json`), 192x192 & 512x512 maskable icons, online/offline state detection, and in-app install banner modal.

### 2.2 Backend Architecture
- **Server Framework:** Express running under Node.js (`server.ts` entry point with TypeScript).
- **Vite Integration:** Mounted as `vite.middlewares` in development mode (`npm run dev`), serving optimized static bundles in production (`npm start`).
- **Database Architecture:**
  - **Local Persistence Layer:** Thread-safe JSON database (`data/database.json` via `server/db.ts`) with atomic write buffers and initial mock seeding for offline testability.
  - **Cloud Database:** Cloud Firestore with strict document collections (`guests`, `orders`, `housekeeping`, `invoices`, `feedbacks`) and security rules (`firestore.rules`).
- **Google Workspace API Client:**
  - Google Sheets API v4 (`https://sheets.googleapis.com/v4/spreadsheets`)
  - Google Drive API v3 (`https://www.googleapis.com/drive/v3`)
  - OAuth 2.0 Client credentials via Firebase Auth Google Provider with scoped access token caching.
- **Artificial Intelligence & Grounding:**
  - `@google/genai` TypeScript SDK with server-side proxy route `/api/ai/itinerary`.
  - Gemini 2.5 Flash model with Google Search Tool Grounding enabled for live Rajasthan weather, travel advisories, and monument schedules.

---

## 3. Core Functional Modules

| Module Name | Component / File | Functional Capabilities |
| :--- | :--- | :--- |
| **Self-Service Guest Check-in & OCR** | `GuestCheckinForm.tsx`, `PassportOcrSection.tsx` | Multimodal passport MRZ extraction, national ID handling, live camera selfie, digital signature pad, auto-generates Form C registration number. |
| **Official Form C Compliance** | `FormCModal.tsx`, `server/db.ts` | Formats compliant Bureau of Immigration certificate, provides print/PDF export, uploads passport scans to Google Drive folder. |
| **In-Room Dining Menu & KDS** | `DiningMenuSection.tsx`, `server.ts` | Marwari cuisine catalog, spice customization, cart calculation, order status tracking (placed, preparing, on the way, delivered). |
| **Housekeeping & Room Care** | `HousekeepingSection.tsx` | Standard Tidy, Deep Clean, Fresh Towels, Turn-down service with custom preferred time slot and staff assignment. |
| **Automated Invoicing & Payment** | `InvoiceCheckoutModal.tsx`, `BillingFolioSection.tsx` | Itemized charges (nights + dining + services + 5% Heritage Fund + 12% GST), integration with Stripe, PayPal, and UPI QR codes, instant PDF tax invoice. |
| **Post-Service Feedback Module** | `FeedbackModal.tsx`, `sheetsService.ts` | Evaluates individual dining orders, housekeeping requests, or stay after checkout. Multi-dimensional ratings (Quality, Speed, Staff Courtesy), tags, comments, NPS score (1-10), synced directly to Google Sheet 'Service Feedback' tab. |
| **AI Rajasthan Itinerary Planner** | `AiItineraryPlanner.tsx`, `server.ts` | Gemini 2.5 Flash multi-day tour builder for Jaipur, Amber Fort, Johari Bazar, and desert heritage tours with real-time web grounding. |
| **Shekhawati Weather Grounding** | `WeatherWidget.tsx`, `server.ts` | Real-time weather, heat advisories, clothing recommendations, and source grounding citations via Google Search. |
| **Staff Admin Management Cockpit** | `AdminDashboard.tsx` | Suite occupancy visualizer, expense approvals, KDS kitchen orders, concierge guest chat, and service feedback analytics. |
| **Google Sheets Operations Ledger** | `GoogleSheetsLedger.tsx`, `sheetsService.ts` | Master Operations Ledger creation and sync across 6 tabs, Google Account authentication, backup to Cloud Firestore. |

---

## 4. Google Sheets Master Ledger Specification

The Master Spreadsheet (`Heritique Haveli Homestay - Master Operations Ledger`) is structured across six primary tabs:

1. **`Guest Register & Form C` (19 Columns):**
   - Registration ID, Full Name, Email, Phone, Assigned Suite, Nationality, ID / Passport No, Status, Check-In Date, Check-Out Date, Purpose of Visit, Visa / ID Details, Form C / Reg No, Next Destination, Registered At, Form C Status, Passport/ID Document (Drive Link), Guest Photo (Drive Link), Guest Signature (Drive Link).
2. **`In-Room Dining Orders` (10 Columns):**
   - Order ID, Guest ID, Guest Name, Suite / Room, Items Summary, Item Count, Order Total (₹), Status, Special Requests, Placed At.
3. **`Housekeeping Log` (9 Columns):**
   - Request ID, Guest ID, Guest Name, Suite / Room, Service Type, Preferred Time, Status, Notes, Requested At.
4. **`Billing Folios & Invoices` (12 Columns):**
   - Invoice ID, Guest ID, Guest Name, Suite / Room, Base Room Charges (₹), Dining Charges (₹), Levy & Taxes (₹), Grand Total (₹), Paid Amount (₹), Balance Due (₹), Status, Issued At.
5. **`Expenses & Accounts` (11 Columns):**
   - Expense ID, Title, Category, Amount (₹), Date, Payment Method, Submitted By, Status, Approved By, Approved At, Notes.
6. **`Service Feedback` (16 Columns):**
   - Feedback ID, Guest ID, Guest Name, Suite / Room, Category, Target Reference ID, Service / Order Description, Rating (Stars), Quality (1-5), Speed (1-5), Staff Courtesy (1-5), Key Highlights / Tags, Guest Comments & Review, NPS Score (1-10), Submitted At, Follow-up Status.

---

## 5. Security, Privacy & Compliance Measures

1. **API Key Isolation:** All Google Gen AI and Firebase service keys execute exclusively in server-side proxy routes (`/api/*`). No private keys or model tokens are exposed in client bundles.
2. **Access Token Management:** Google OAuth 2.0 access tokens are held exclusively in memory (`cachedAccessToken` in `src/services/firebase.ts`) and never stored in `localStorage` or `sessionStorage`.
3. **Statutory Form C Privacy:** Documents uploaded by foreign nationals are stored in a dedicated Google Drive folder (`Heritique Haveli - Guest Documents`) with explicit permission ACLs.
4. **Sanitized User Input:** File uploads (Passport documents, photos, signatures) validate MIME types and base64 byte headers prior to transit.
5. **Role-Based Access Control:** Strict UI separation between guests and staff. Checked-in guests are prevented from accessing staff administration or internal folios.

---

## 6. Verification & System Health
- **TypeScript Static Verification:** `tsc --noEmit` passes with 0 syntax or type warnings.
- **Production Build:** Vite optimized production bundle builds successfully (`npm run build`).
- **Linter:** ESLint clean (`npm run lint`).
