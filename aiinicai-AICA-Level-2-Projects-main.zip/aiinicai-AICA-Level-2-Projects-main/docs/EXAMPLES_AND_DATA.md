# Example Files & Data Specifications
## Heritique Haveli Homestay: API Payloads, Sample Data & Google Sheet Rows

---

### Overview
This document contains comprehensive example datasets, REST API request/response payloads, and representative row structures as stored in the **Google Sheets Master Operations Ledger**.

---

## 1. Statutory Form C Guest Registration

### 1.1 Sample API Request (`POST /api/guests`)
```json
{
  "givenName": "Elena Camille",
  "surname": "Rostova",
  "gender": "Female",
  "dob": "1992-06-14",
  "nationality": "French (France)",
  "passportNumber": "21FB84920",
  "passportIssueDate": "2021-04-10",
  "passportExpiryDate": "2031-04-09",
  "passportIssuePlace": "Paris, France",
  "visaNumber": "IND9082341-T",
  "visaType": "e-Tourist Visa (1 Year)",
  "visaExpiryDate": "2027-07-31",
  "arrivedFromCity": "Paris",
  "arrivedFromCountry": "France",
  "arrivalDateInCountry": "2026-09-14",
  "portOfArrival": "Indira Gandhi International Airport, New Delhi (DEL)",
  "nextDestination": "Udaipur Heritage Palace, Rajasthan",
  "purposeOfVisit": "Cultural Heritage Study & Leisure Tourism",
  "phone": "+33 6 45 92 11 08",
  "email": "elena.rostova@homestayguest.com",
  "roomNumber": "Suite 101 - The Royal Haveli",
  "roomRate": 7500,
  "checkInDate": "2026-09-16",
  "checkOutDate": "2026-09-20",
  "guestType": "foreign",
  "verificationStatus": "verified"
}
```

### 1.2 Form C Google Sheet Row (`'Guest Register & Form C'` Tab)
| Col | Field | Sample Value |
| :--- | :--- | :--- |
| **A** | Registration ID | `GUEST-8021` |
| **B** | Full Name | `Elena Camille Rostova` |
| **C** | Email | `elena.rostova@homestayguest.com` |
| **D** | Phone | `+33 6 45 92 11 08` |
| **E** | Assigned Suite | `Suite 101 - The Royal Haveli` |
| **F** | Nationality | `French (France)` |
| **G** | ID / Passport No | `21FB84920` |
| **H** | Status | `active` |
| **I** | Check-In Date | `2026-09-16` |
| **J** | Check-Out Date | `2026-09-20` |
| **K** | Purpose of Visit | `Cultural Heritage Study & Leisure Tourism` |
| **L** | Visa / ID Details | `Visa: IND9082341-T (exp 2027-07-31)` |
| **M** | Form C / Reg No | `FORM-C-GUEST-8021` |
| **N** | Next Destination | `Udaipur Heritage Palace, Rajasthan` |
| **O** | Registered At | `2026-09-16T11:45:00.000Z` |
| **P** | Form C Status | `Active In-House` |
| **Q** | Passport Document (Drive Link) | `https://drive.google.com/file/d/1A2b3C.../view?usp=sharing` |
| **R** | Guest Photo (Drive Link) | `https://drive.google.com/file/d/2B3c4D.../view?usp=sharing` |
| **S** | Guest Signature (Drive Link) | `https://drive.google.com/file/d/3C4d5E.../view?usp=sharing` |

---

## 2. In-Room Dining Order

### 2.1 Sample API Request (`POST /api/orders`)
```json
{
  "guestId": "GUEST-8021",
  "guestName": "Elena Rostova",
  "roomNumber": "Suite 101 - The Royal Haveli",
  "items": [
    {
      "id": "menu-main-1",
      "name": "Royal Shekhawati Dal Baati Churma Thali",
      "price": 650,
      "quantity": 1,
      "spiceLevel": "Medium"
    },
    {
      "id": "menu-ds-3",
      "name": "Matka Smoked Masala Buttermilk (Chaas)",
      "price": 130,
      "quantity": 2
    }
  ],
  "specialInstructions": "Please serve with extra cow ghee and lemon on the side."
}
```

### 2.2 Dining Google Sheet Row (`'In-Room Dining Orders'` Tab)
| Col | Header | Sample Value |
| :--- | :--- | :--- |
| **A** | Order ID | `ORD-501` |
| **B** | Guest ID | `GUEST-8021` |
| **C** | Guest Name | `Elena Rostova` |
| **D** | Suite / Room | `Suite 101 - The Royal Haveli` |
| **E** | Items Summary | `Royal Shekhawati Dal Baati Churma Thali (1x), Matka Smoked Chaas (2x)` |
| **F** | Item Count | `3` |
| **G** | Order Total (₹) | `910` |
| **H** | Status | `delivered` |
| **I** | Special Requests | `Please serve with extra cow ghee and lemon on the side.` |
| **J** | Placed At | `2026-09-26T13:10:00.000Z` |

---

## 3. Housekeeping Service Request

### 3.1 Sample API Request (`POST /api/housekeeping`)
```json
{
  "guestId": "GUEST-8021",
  "guestName": "Elena Rostova",
  "roomNumber": "Suite 101 - The Royal Haveli",
  "requestType": "Fresh Towels & Linen",
  "preferredTime": "14:30 - 15:00",
  "notes": "Extra bath towels and refill organic lavender room fragrance mist."
}
```

### 3.2 Housekeeping Google Sheet Row (`'Housekeeping Log'` Tab)
| Col | Header | Sample Value |
| :--- | :--- | :--- |
| **A** | Request ID | `HK-901` |
| **B** | Guest ID | `GUEST-8021` |
| **C** | Guest Name | `Elena Rostova` |
| **D** | Suite / Room | `Suite 101 - The Royal Haveli` |
| **E** | Service Type | `Fresh Towels & Linen` |
| **F** | Preferred Time | `14:30 - 15:00` |
| **G** | Status | `completed` |
| **H** | Notes | `Extra bath towels and refill organic lavender room fragrance mist.` |
| **I** | Requested At | `2026-09-26T13:45:00.000Z` |

---

## 4. Post-Service Feedback & Rating

### 4.1 Sample API Request (`POST /api/feedback`)
```json
{
  "guestId": "GUEST-8021",
  "guestName": "Elena Rostova",
  "guestEmail": "elena.rostova@homestayguest.com",
  "roomNumber": "Suite 101 - The Royal Haveli",
  "category": "dining",
  "targetId": "ORD-501",
  "targetTitle": "Royal Shekhawati Dal Baati Churma Thali (Order #ORD-501)",
  "rating": 5,
  "qualityRating": 5,
  "speedRating": 5,
  "courtesyRating": 5,
  "tags": ["Authentic Flavors", "Served Piping Hot", "Fresh Desi Ghee"],
  "comments": "The baati was perfectly baked with pure cow ghee and the dal was fragrant with authentic spices. Delivered in warm brass cookware in under 25 minutes.",
  "npsScore": 10
}
```

### 4.2 Service Feedback Google Sheet Row (`'Service Feedback'` Tab)
| Col | Header | Sample Value |
| :--- | :--- | :--- |
| **A** | Feedback ID | `FB-901` |
| **B** | Guest ID | `GUEST-8021` |
| **C** | Guest Name | `Elena Rostova` |
| **D** | Suite / Room | `Suite 101 - The Royal Haveli` |
| **E** | Category | `In-Room Dining` |
| **F** | Target Reference ID | `ORD-501` |
| **G** | Service / Order Description | `Royal Shekhawati Dal Baati Churma Thali (Order #ORD-501)` |
| **H** | Rating (Stars) | `5 ★ (5/5)` |
| **I** | Quality (1-5) | `5/5` |
| **J** | Speed (1-5) | `5/5` |
| **K** | Staff Courtesy (1-5) | `5/5` |
| **L** | Key Highlights / Tags | `Authentic Flavors, Served Piping Hot, Fresh Desi Ghee` |
| **M** | Guest Comments & Review | `The baati was perfectly baked with pure cow ghee and the dal was fragrant with authentic spices.` |
| **N** | NPS Score (1-10) | `10/10` |
| **O** | Submitted At | `2026-09-26T14:15:00.000Z` |
| **P** | Follow-up Status | `THANKED` |

---

## 5. Automated Checkout Tax Invoice

### 5.1 Sample API Response (`POST /api/invoices/checkout`)
```json
{
  "id": "INV-2026-8021",
  "guestId": "GUEST-8021",
  "guestName": "Elena Camille Rostova",
  "roomNumber": "Suite 101 - The Royal Haveli",
  "roomRatePerNight": 7500,
  "nights": 4,
  "roomTotal": 30000,
  "diningTotal": 2450,
  "experiencesTotal": 1000,
  "subtotal": 33450,
  "conservationLevy": 1673,
  "taxes": 3843,
  "grandTotal": 38966,
  "paidAmount": 38966,
  "balanceDue": 0,
  "status": "paid",
  "paymentGateway": "UPI",
  "transactionId": "TXN-UPI-904128",
  "generatedAt": "2026-09-20T10:00:00.000Z"
}
```

---

## 6. Sample cURL Test Commands

```bash
# 1. Fetch live feedback records
curl -s http://localhost:3000/api/feedback

# 2. Submit post-service feedback
curl -s -X POST http://localhost:3000/api/feedback \
  -H "Content-Type: application/json" \
  -d '{
    "guestId": "GUEST-8022",
    "guestName": "Arjun Singhania",
    "roomNumber": "Suite 104 - Gulab Mahal",
    "category": "stay_checkout",
    "rating": 5,
    "qualityRating": 5,
    "speedRating": 5,
    "courtesyRating": 5,
    "tags": ["Royal Rajput Hospitality", "Preserved 1924 Architecture"],
    "comments": "An unforgettable experience in the heart of Shekhawati.",
    "npsScore": 10
  }'

# 3. Check real-time Shekhawati weather with Google Search grounding
curl -s http://localhost:3000/api/weather/shekhawati

# 4. Generate AI Rajasthan Itinerary
curl -s -X POST http://localhost:3000/api/ai/itinerary \
  -H "Content-Type: application/json" \
  -d '{
    "destination": "Jaipur & Amber Fort",
    "days": 3,
    "style": "Heritage & Culinary",
    "guestProfile": "International couple"
  }'
```
