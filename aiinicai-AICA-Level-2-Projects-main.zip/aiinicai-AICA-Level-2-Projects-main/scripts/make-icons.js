import fs from 'fs';
import zlib from 'zlib';

function createPng(width, height, r, g, b) {
  // Simple valid PNG generator with raw RGBA buffer
  const buffer = Buffer.alloc(width * height * 4 + height);
  let offset = 0;
  for (let y = 0; y < height; y++) {
    buffer[offset++] = 0; // Filter type 0 (None)
    for (let x = 0; x < width; x++) {
      // Draw dark heritage green background with golden diamond border
      const isBorder = x < 12 || x > width - 12 || y < 12 || y > height - 12;
      const dx = Math.abs(x - width / 2);
      const dy = Math.abs(y - height / 2);
      const isDiamond = Math.abs(dx + dy - width * 0.35) < 6;
      const isCenter = dx < width * 0.15 && dy < height * 0.15;

      if (isBorder || isDiamond || isCenter) {
        // Gold (#D4AF37)
        buffer[offset++] = 212;
        buffer[offset++] = 175;
        buffer[offset++] = 55;
        buffer[offset++] = 255;
      } else {
        // Deep Heritage Green (#1A3826)
        buffer[offset++] = 26;
        buffer[offset++] = 56;
        buffer[offset++] = 38;
        buffer[offset++] = 255;
      }
    }
  }

  const compressed = zlib.deflateSync(buffer);

  function createChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type);
    const crcBuf = Buffer.alloc(4);
    // Simple CRC32
    let c = 0xffffffff;
    const table = new Uint32Array(256);
    for (let n = 0; n < 256; n++) {
      let v = n;
      for (let k = 0; k < 8; k++) {
        v = (v & 1) ? (0xedb88320 ^ (v >>> 1)) : (v >>> 1);
      }
      table[n] = v;
    }
    for (let i = 0; i < typeBuf.length; i++) c = table[(c ^ typeBuf[i]) & 0xff] ^ (c >>> 8);
    for (let i = 0; i < data.length; i++) c = table[(c ^ data[i]) & 0xff] ^ (c >>> 8);
    crcBuf.writeUInt32BE((c ^ 0xffffffff) >>> 0, 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // Bit depth
  ihdr[9] = 6; // Color type RGBA
  ihdr[10] = 0; // Compression
  ihdr[11] = 0; // Filter
  ihdr[12] = 0; // Interlace

  const ihdrChunk = createChunk('IHDR', ihdr);
  const idatChunk = createChunk('IDAT', compressed);
  const iendChunk = createChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

fs.writeFileSync('./public/icon-192.png', createPng(192, 192, 26, 56, 38));
fs.writeFileSync('./public/icon-512.png', createPng(512, 512, 26, 56, 38));
console.log('Generated icon-192.png and icon-512.png successfully.');
