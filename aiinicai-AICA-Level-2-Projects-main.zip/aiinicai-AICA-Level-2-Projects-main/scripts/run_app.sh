#!/usr/bin/env bash
# ==============================================================================
# Heritique Haveli Homestay Applet Executable Launcher
# ==============================================================================
set -e

PORT="${PORT:-3000}"
HOST="${HOST:-0.0.0.0}"
NODE_ENV="${NODE_ENV:-development}"

echo "===================================================================="
echo " Starting Heritique Haveli Homestay Web Application & PWA"
echo " Environment: ${NODE_ENV} | Port: ${PORT}"
echo "===================================================================="

# Check node & npm
if ! command -v node &> /dev/null; then
    echo "[ERROR] Node.js is not installed or not in PATH."
    exit 1
fi

if ! command -v npm &> /dev/null; then
    echo "[ERROR] npm is not installed or not in PATH."
    exit 1
fi

echo "[1/4] Node.js version: $(node -v)"
echo "[2/4] Verifying TypeScript codebase..."
npm run lint --if-present

echo "[3/4] Ensuring build artifacts..."
npm run build

echo "[4/4] Starting server process on port ${PORT}..."
export PORT="${PORT}"
export NODE_ENV="${NODE_ENV}"

# Run backend with tsx or node
if [ -f "server.ts" ]; then
    npx tsx server.ts
else
    npm start
fi
