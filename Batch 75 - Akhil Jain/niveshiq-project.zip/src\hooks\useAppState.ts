import { useState, useEffect, useMemo, useCallback } from 'react';
import { AppState, DerivedFinancials, FinancialGoal, Portfolio } from '../models/types';
import { DEFAULT_RETURNS, STRATEGIES } from '../data/constants';
import { calcRiskCapacity, levelFromScore, capacityReasons, num } from '../engines/riskCapacityEngine';
import { calcAppetite } from '../engines/riskAppetiteEngine';
import {
  allocationBuckets,
  interpolateAllocation,
  nearestStrategyKey,
  recommendedLabel,
  computeBlendedReturn,
} from '../engines/portfolioEngine';
import { computeActionPlan } from '../engines/actionPlanEngine';
import { loadStateFromStorage, saveStateToStorage, clearStorage } from '../services/storageService';
import { DEMO_PROFILE, DEMO_PORTFOLIO, DEMO_APPETITE_ANSWERS } from '../data/demoInvestor';
import { importPortfolioFromBroker } from '../services/mockBrokerService';
import { fetchAIInsights, fetchAIChatResponse } from '../services/ai/aiService';
import { buildAISummary } from '../services/ai/OpenAIProvider';

export const INITIAL_STATE: AppState = {
  screen: 0,
  profile: {
    age: '',
    maritalStatus: 'Married',
    dependents: 0,
    retirementAge: 60,
    annualIncome: '',
    monthlyExpenses: '',
    monthlyEMI: '',
    incomeStability: 'Stable',
    emergencyFund: '',
    outstandingLoans: '',
    goals: [],
  },
  portfolio: {
    mode: 'import',
    stocks: 0,
    equityMF: 0,
    debtMF: 0,
    fdRd: 0,
    epfPpf: 0,
    gold: 0,
    nps: 0,
    bonds: 0,
    cash: 0,
    other: 0,
    imported: false,
    brokerName: '',
  },
  newGoal: {
    type: 'Retirement',
    name: '',
    targetAmount: '',
    yearsRemaining: '',
    currentMonthlyContribution: '',
  },
  goalIdCounter: 1,
  appetiteAnswers: [null, null, null, null, null],
  selectedStrategy: null,
  strategyOverridden: false,
  riskAcknowledged: false,
  returnAssumptions: { ...DEFAULT_RETURNS },
  aiSettings: {
    endpoint: 'https://api.openai.com/v1/chat/completions',
    apiKey: '',
    model: 'gpt-4.5',
  },
  aiConsent: false,
  aiInsightText: '',
  aiChatHistory: [],
  aiInsightLoading: false,
  aiInsightError: '',
  formError: '',
};

export function useAppState() {
  const [state, setState] = useState<AppState>(() => {
    const loaded = loadStateFromStorage();
    if (!loaded) return INITIAL_STATE;
    return {
      ...INITIAL_STATE,
      ...loaded,
      profile: {
        ...INITIAL_STATE.profile,
        ...loaded.profile,
        goals: loaded.profile?.goals || [],
      },
      newGoal: loaded.newGoal || INITIAL_STATE.newGoal,
      returnAssumptions: loaded.returnAssumptions || INITIAL_STATE.returnAssumptions,
      aiSettings: loaded.aiSettings || INITIAL_STATE.aiSettings,
      aiChatHistory: loaded.aiChatHistory || INITIAL_STATE.aiChatHistory,
    };
  });

  useEffect(() => {
    saveStateToStorage(state);
  }, [state]);

  const financials: DerivedFinancials = useMemo(() => {
    const cap = calcRiskCapacity(state.profile, state.portfolio);
    const capLevel = levelFromScore(cap.score);
    const appetite = calcAppetite(state.appetiteAnswers);
    const appLevel = appetite.level;
    const recLevelCont = capLevel * 0.55 + appLevel * 0.45;
    const recLabel = recommendedLabel(recLevelCont);
    const gap = appLevel - capLevel;
    const alloc = allocationBuckets(state.portfolio);
    const recAlloc = interpolateAllocation(recLevelCont);
    const selectedKey = state.selectedStrategy || nearestStrategyKey(recLevelCont);
    const selectedStrategyObj = STRATEGIES[selectedKey] || STRATEGIES['conservative'];
    const selectedLevel = selectedStrategyObj.level;
    const riskAlert = selectedLevel - capLevel >= 2;
    const reasons = capacityReasons(cap, state.profile);
    const blendedReturnPct = computeBlendedReturn(selectedStrategyObj, state.returnAssumptions);
    const actionPlan = computeActionPlan(state, cap, alloc, selectedStrategyObj, blendedReturnPct);

    return {
      cap,
      capLevel,
      appetite,
      appLevel,
      recLevelCont,
      recLabel,
      gap,
      alloc,
      recAlloc,
      selectedKey,
      selectedStrategyObj,
      selectedLevel,
      riskAlert,
      reasons,
      blendedReturnPct,
      actionPlan,
    };
  }, [state.profile, state.portfolio, state.appetiteAnswers, state.selectedStrategy, state.returnAssumptions]);

  const setScreen = useCallback((screen: number) => {
    setState((prev) => ({ ...prev, screen, formError: '' }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const loadDemoInvestor = useCallback(() => {
    setState((prev) => ({
      ...prev,
      profile: DEMO_PROFILE,
      portfolio: DEMO_PORTFOLIO,
      goalIdCounter: 3,
      appetiteAnswers: DEMO_APPETITE_ANSWERS,
      selectedStrategy: 'aggressive',
      strategyOverridden: true,
      riskAcknowledged: false,
      returnAssumptions: { ...DEFAULT_RETURNS },
      formError: '',
      screen: 1,
    }));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const resetAll = useCallback(() => {
    clearStorage();
    setState(INITIAL_STATE);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const updateProfile = useCallback((path: string, value: any) => {
    setState((prev) => {
      // newGoal lives on state directly, not on state.profile
      if (path.startsWith('newGoal.')) {
        const field = path.slice('newGoal.'.length) as keyof typeof prev.newGoal;
        return { ...prev, newGoal: { ...prev.newGoal, [field]: value }, formError: '' };
      }
      // General profile path traversal (shallow-copy each intermediate object)
      const keys = path.split('.');
      const nextProfile = { ...prev.profile } as any;
      let curr = nextProfile;
      for (let i = 0; i < keys.length - 1; i++) {
        curr[keys[i]] = { ...curr[keys[i]] };
        curr = curr[keys[i]];
      }
      curr[keys[keys.length - 1]] = value;
      return { ...prev, profile: nextProfile, formError: '' };
    });
  }, []);

  const updatePortfolio = useCallback((key: keyof Portfolio, value: any) => {
    setState((prev) => ({
      ...prev,
      portfolio: {
        ...prev.portfolio,
        [key]: value,
      },
    }));
  }, []);

  const importBrokerPortfolio = useCallback(async (brokerName: string) => {
    const importedData = await importPortfolioFromBroker(brokerName);
    setState((prev) => ({
      ...prev,
      portfolio: {
        ...prev.portfolio,
        ...importedData,
      },
    }));
  }, []);

  const addGoal = useCallback(() => {
    setState((prev) => {
      const ng = prev.newGoal;
      if (!num(ng.targetAmount) || num(ng.targetAmount) <= 0 || !num(ng.yearsRemaining) || num(ng.yearsRemaining) <= 0) {
        return { ...prev, formError: 'Please enter a valid target amount and years remaining for the goal.' };
      }
      const name = ng.type === 'Other' ? ng.name || 'Other Goal' : ng.type;
      const newGoalObj: FinancialGoal = {
        id: prev.goalIdCounter,
        type: ng.type,
        name,
        targetAmount: num(ng.targetAmount),
        yearsRemaining: num(ng.yearsRemaining),
        currentMonthlyContribution: num(ng.currentMonthlyContribution),
        sample: false,
      };
      return {
        ...prev,
        profile: {
          ...prev.profile,
          goals: [...(prev.profile.goals || []), newGoalObj],
        },
        goalIdCounter: prev.goalIdCounter + 1,
        newGoal: INITIAL_STATE.newGoal,
        formError: '',
      };
    });
  }, []);

  const removeGoal = useCallback((id: number) => {
    setState((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        goals: (prev.profile.goals || []).filter((g) => g.id !== id),
      },
    }));
  }, []);

  const promoteGoal = useCallback((id: number) => {
    setState((prev) => ({
      ...prev,
      profile: {
        ...prev.profile,
        goals: (prev.profile.goals || []).map((g) => (g.id === id ? { ...g, sample: false } : g)),
      },
    }));
  }, []);

  const updateAppetiteAnswer = useCallback((index: number, value: number) => {
    setState((prev) => {
      const nextAnswers = [...prev.appetiteAnswers];
      nextAnswers[index] = value;
      return { ...prev, appetiteAnswers: nextAnswers };
    });
  }, []);

  const selectStrategy = useCallback((key: string) => {
    setState((prev) => {
      const recKey = nearestStrategyKey(financials.recLevelCont);
      return {
        ...prev,
        selectedStrategy: key,
        strategyOverridden: key !== recKey,
        riskAcknowledged: false,
      };
    });
  }, [financials.recLevelCont]);

  const useRecommendedStrategy = useCallback(() => {
    const recKey = nearestStrategyKey(financials.recLevelCont);
    setState((prev) => ({
      ...prev,
      selectedStrategy: recKey,
      strategyOverridden: false,
      riskAcknowledged: false,
    }));
  }, [financials.recLevelCont]);

  const acknowledgeRisk = useCallback(() => {
    setState((prev) => ({ ...prev, riskAcknowledged: true }));
  }, []);

  const updateReturnAssumption = useCallback((key: keyof AppState['returnAssumptions'], value: number) => {
    setState((prev) => ({
      ...prev,
      returnAssumptions: {
        ...prev.returnAssumptions,
        [key]: value,
      },
    }));
  }, []);

  const resetReturnAssumptions = useCallback(() => {
    setState((prev) => ({ ...prev, returnAssumptions: { ...DEFAULT_RETURNS } }));
  }, []);

  const updateAISettings = useCallback((key: keyof AppState['aiSettings'], value: string) => {
    setState((prev) => ({
      ...prev,
      aiSettings: {
        ...prev.aiSettings,
        [key]: value,
      },
    }));
  }, []);

  const setAIConsent = useCallback((consent: boolean) => {
    setState((prev) => ({ ...prev, aiConsent: consent }));
  }, []);

  const setAIResult = useCallback((text: string, loading: boolean, error: string) => {
    setState((prev) => ({
      ...prev,
      aiInsightText: text,
      aiInsightLoading: loading,
      aiInsightError: error,
    }));
  }, []);

  const clearAIKey = useCallback(() => {
    setState((prev) => ({
      ...prev,
      aiSettings: { ...prev.aiSettings, apiKey: '' },
      aiInsightText: '',
      aiChatHistory: [],
      aiInsightError: '',
    }));
  }, []);

  const generateAIInsights = useCallback(async () => {
    const useMock = !state.aiSettings.apiKey;
    
    if (!useMock && !state.aiConsent) {
      setState((prev) => ({
        ...prev,
        aiInsightError: 'Please check the consent box before generating insights.',
      }));
      return;
    }

    setState((prev) => ({
      ...prev,
      aiInsightLoading: true,
      aiInsightError: '',
      aiChatHistory: [],
    }));

    try {
      const summary = buildAISummary(state, financials);
      const text = await fetchAIInsights(state, financials, useMock);
      setState((prev) => ({
        ...prev,
        aiChatHistory: [
          { role: 'user' as const, content: summary },
          { role: 'assistant' as const, content: text },
        ],
        aiInsightText: text,
        aiInsightLoading: false,
        aiInsightError: '',
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        aiInsightLoading: false,
        aiInsightError: err?.message || 'Failed to generate AI insights.',
      }));
    }
  }, [state, financials]);

  const sendAIChatMessage = useCallback(async (messageText: string) => {
    if (!messageText.trim()) return;
    const useMock = !state.aiSettings.apiKey;

    const currentHistory: AppState['aiChatHistory'] = [...state.aiChatHistory, { role: 'user' as const, content: messageText }];

    setState((prev) => ({
      ...prev,
      aiChatHistory: [...prev.aiChatHistory, { role: 'user' as const, content: messageText }],
      aiInsightLoading: true,
      aiInsightError: '',
    }));

    try {
      const reply = await fetchAIChatResponse(state, currentHistory, useMock);
      setState((prev) => ({
        ...prev,
        aiChatHistory: [...prev.aiChatHistory, { role: 'assistant' as const, content: reply }],
        aiInsightLoading: false,
        aiInsightError: '',
      }));
    } catch (err: any) {
      setState((prev) => ({
        ...prev,
        aiInsightLoading: false,
        aiInsightError: err?.message || 'Failed to send message to AI.',
      }));
    }
  }, [state]);

  return {
    state,
    setState,
    financials,
    setScreen,
    loadDemoInvestor,
    resetAll,
    updateProfile,
    updatePortfolio,
    importBrokerPortfolio,
    addGoal,
    removeGoal,
    promoteGoal,
    updateAppetiteAnswer,
    selectStrategy,
    useRecommendedStrategy,
    acknowledgeRisk,
    updateReturnAssumption,
    resetReturnAssumptions,
    updateAISettings,
    setAIConsent,
    setAIResult,
    clearAIKey,
    generateAIInsights,
    sendAIChatMessage,
  };
}
