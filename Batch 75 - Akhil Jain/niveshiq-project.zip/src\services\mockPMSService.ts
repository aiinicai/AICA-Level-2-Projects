export interface PMSProduct {
  name: string;
  riskLevel: 'Low' | 'Medium' | 'High';
  indicativeAllocation: string;
  horizon: string;
  feeStructure: string;
}

export function getMockPMSProducts(): PMSProduct[] {
  return [
    {
      name: 'Conservative PMS',
      riskLevel: 'Low',
      indicativeAllocation: '40% Equity / 60% Debt',
      horizon: '3–5 years',
      feeStructure: '~1.5% p.a. + performance fee (illustrative)',
    },
    {
      name: 'Balanced PMS',
      riskLevel: 'Medium',
      indicativeAllocation: '65% Equity / 35% Debt',
      horizon: '5–7 years',
      feeStructure: '~2.0% p.a. + performance fee (illustrative)',
    },
    {
      name: 'Growth PMS',
      riskLevel: 'High',
      indicativeAllocation: '85% Equity / 15% Debt',
      horizon: '7+ years',
      feeStructure: '~2.5% p.a. + performance fee (illustrative)',
    },
  ];
}
