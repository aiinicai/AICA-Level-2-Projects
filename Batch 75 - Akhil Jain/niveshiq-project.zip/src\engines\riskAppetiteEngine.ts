import { RiskAppetiteResult, RiskLevel } from '../models/types';

export function calcAppetite(answers: (number | null)[]): RiskAppetiteResult {
  const valid = answers.filter((a) => a != null && a !== undefined && !isNaN(Number(a))) as number[];
  if (valid.length === 0) return { score: 3, level: 3, answered: 0 };
  const avg = valid.reduce((a, b) => a + Number(b), 0) / valid.length;
  const level = Math.max(1, Math.min(5, Math.round(avg))) as RiskLevel;
  return { score: avg, level, answered: valid.length };
}
