import React from 'react';
import { DerivedFinancials } from '../models/types';
import { ActionCard } from '../components/ActionCard';
import { Disclaimer } from '../components/Disclaimer';

interface ActionPlanScreenProps {
  financials: DerivedFinancials;
  onBack: () => void;
  onContinue: () => void;
}

export const ActionPlanScreen: React.FC<ActionPlanScreenProps> = ({
  financials,
  onBack,
  onContinue,
}) => {
  const actions = financials.actionPlan;

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fade-in-up">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient">
          What Should You Do Next?
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          A prioritized, plain-language action plan generated from your profile, portfolio, and chosen strategy.
          Goal projections use a blended return of{' '}
          <strong className="text-indigo-400">{financials.blendedReturnPct.toFixed(1)}% p.a.</strong>{' '}
          from your <strong className="text-slate-300">{financials.selectedStrategyObj.label}</strong> strategy.
        </p>
      </div>

      {/* Stats strip */}
      {actions.length > 0 && (
        <div className="flex flex-wrap gap-3">
          {['High', 'Medium', 'Low'].map((p) => {
            const count = actions.filter((a) => a.priority === p).length;
            if (count === 0) return null;
            const colors: Record<string, string> = { High: '#f87171', Medium: '#fbbf24', Low: '#34d399' };
            return (
              <div key={p} className="px-3.5 py-2 rounded-xl text-xs font-bold flex items-center gap-2"
                style={{ background: `${colors[p]}12`, border: `1px solid ${colors[p]}25`, color: colors[p] }}>
                <span>{count}</span>
                <span className="text-[10px] uppercase tracking-wider opacity-80">{p} Priority</span>
              </div>
            );
          })}
        </div>
      )}

      {/* Action Cards */}
      <div className="space-y-5">
        {actions.length === 0 ? (
          <div className="section-card p-10 text-center space-y-3">
            <div className="text-4xl">✅</div>
            <h3 className="text-lg font-bold text-white">No Critical Action Gaps Identified</h3>
            <p className="text-xs text-slate-500 max-w-lg mx-auto">
              Your financial metrics align well with your target allocation and emergency buffers. Continue to review your plan periodically.
            </p>
          </div>
        ) : (
          actions.map((act, i) => (
            <ActionCard key={act.title} action={act} index={i} />
          ))
        )}
      </div>

      {/* Bottom Nav */}
      <div className="flex justify-between pt-2">
        <button onClick={onBack} className="btn-secondary">← Back</button>
        <button onClick={onContinue} className="btn-primary">Explore & Implement →</button>
      </div>

      <Disclaimer />
    </div>
  );
};
