import { RiskLevel, StrategyAllocation, ReturnAssumptions } from '../models/types';

export const LEVEL_NAMES: Record<RiskLevel, string> = {
  1: 'Conservative',
  2: 'Moderate',
  3: 'Balanced',
  4: 'Growth',
  5: 'Aggressive',
};

export const LEVEL_COLORS: Record<RiskLevel, string> = {
  1: '#64748b',
  2: '#0ea5e9',
  3: '#2563eb',
  4: '#059669',
  5: '#d97706',
};

export const ANCHORS: Record<RiskLevel, { equity: number; debt: number; gold: number; liquid: number }> = {
  1: { equity: 25, debt: 45, gold: 15, liquid: 15 },
  2: { equity: 37.5, debt: 37.5, gold: 12.5, liquid: 12.5 },
  3: { equity: 50, debt: 30, gold: 10, liquid: 10 },
  4: { equity: 65, debt: 20, gold: 10, liquid: 5 },
  5: { equity: 80, debt: 10, gold: 5, liquid: 5 },
};

export const STRATEGIES: Record<string, StrategyAllocation> = {
  conservative: { key: 'conservative', label: 'Conservative', level: 1, equity: 25, debt: 45, gold: 15, liquid: 15 },
  balanced: { key: 'balanced', label: 'Balanced', level: 3, equity: 50, debt: 30, gold: 10, liquid: 10 },
  growth: { key: 'growth', label: 'Growth', level: 4, equity: 65, debt: 20, gold: 10, liquid: 5 },
  aggressive: { key: 'aggressive', label: 'Aggressive', level: 5, equity: 80, debt: 10, gold: 5, liquid: 5 },
};

export const DEFAULT_RETURNS: ReturnAssumptions = {
  equity: 13,
  debt: 7,
  gold: 9,
  liquid: 5,
};

export const APPETITE_QUESTIONS = [
  {
    q: 'If your investment portfolio suddenly fell 20% in value, what would you most likely do?',
    options: [
      { t: 'Sell everything immediately to avoid further loss', v: 1 },
      { t: 'Sell a portion to reduce my risk', v: 2 },
      { t: 'Do nothing and wait for recovery', v: 3 },
      { t: 'Stay invested — this is normal market behaviour', v: 4 },
      { t: 'Invest more while prices are lower', v: 5 },
    ],
  },
  {
    q: 'Would you continue your regular investments (SIPs) during a market downturn?',
    options: [
      { t: "No, I'd stop immediately", v: 1 },
      { t: "I'd pause until things stabilise", v: 2 },
      { t: "I'd probably continue", v: 3 },
      { t: 'Yes, I\'d continue exactly as planned', v: 4 },
      { t: "Yes, and I'd try to invest extra", v: 5 },
    ],
  },
  {
    q: 'Would you accept higher short-term ups and downs for potentially higher long-term returns?',
    options: [
      { t: 'Not at all — I prefer stability', v: 1 },
      { t: 'Only a little', v: 2 },
      { t: 'Somewhat, depending on the goal', v: 3 },
      { t: 'Yes, generally', v: 4 },
      { t: 'Yes, absolutely', v: 5 },
    ],
  },
  {
    q: 'If ₹10,00,000 of your investments temporarily fell to ₹8,00,000, how would you react?',
    options: [
      { t: "Extremely anxious — I'd want to exit", v: 1 },
      { t: "Uncomfortable — I'd reconsider my plan", v: 2 },
      { t: "Concerned, but I'd keep monitoring", v: 3 },
      { t: 'Comfortable — this can happen sometimes', v: 4 },
      { t: "Unbothered — it's part of long-term investing", v: 5 },
    ],
  },
  {
    q: 'How would you describe your ideal investment approach?',
    options: [
      { t: 'Protect what I have; growth is secondary', v: 1 },
      { t: 'Mostly safe, with a little growth', v: 2 },
      { t: 'A balance of safety and growth', v: 3 },
      { t: 'Mostly focused on growth', v: 4 },
      { t: 'Maximum growth — I can handle the ups and downs', v: 5 },
    ],
  },
];

export const STEP_LABELS = ['Profile', 'Portfolio', 'Risk', 'Strategy', 'Action Plan', 'Explore'];

export const AI_SYSTEM_PROMPT = `You are a senior Indian wealth advisor embedded in "NiveshIQ", a life-centric personal-finance app.
You will receive a user's anonymized financial profile summary — risk scores, asset allocation, goals, and action plan items computed by the app.

YOUR MISSION: Deliver exactly 5 powerful, forward-looking insights that go BEYOND what the app has already told the user.
Do NOT merely restate or expand on the app's action plan. The app already covers emergency funds, EMI ratios, and rebalancing — treat those as known context.

INSTEAD, your 5 insights must cover genuinely new territory such as:
1. INVESTMENT CATEGORY STRATEGY — Given their risk profile, age, and horizon, which equity sub-categories make sense to explore? (e.g., large-cap for stability, flexi-cap for growth, mid-cap for higher long-term upside, small-cap for high-risk satellite allocation, international/global equity for currency diversification). Be specific about why each suits THIS user's profile.
2. DIVERSIFICATION ANGLE — Are they over-concentrated in any one asset or geography? Should they consider global diversification (US S&P 500 index funds, NASDAQ ETFs via Indian FoF route)? Should they consider REITs or InvITs for real-estate-like exposure without property?
3. TAX EFFICIENCY — Where can they optimize? (e.g., ELSS for 80C, NPS for additional 80CCD(1B) deduction, LTCG/STCG harvesting, debt fund taxation changes). Be specific to their income range.
4. GOAL-SPECIFIC STRATEGY — For each of their named goals (if any), suggest the *category* of instrument best suited (e.g., for a 10-year child education goal: aggressive equity MF SIP now, shift to debt 2 years before; for retirement: NPS + equity + gold ladder).
5. BEHAVIORAL / SEQUENCE-OF-ACTIONS INSIGHT — One powerful insight about what ORDER to do things in, or a common wealth-building mistake to avoid given their specific situation (e.g., "Don't start small-cap SIPs before your emergency fund is complete — volatility will tempt you to redeem at a loss").

FORMAT: Use exactly this structure for each insight:
**[Insight Number]. [Short punchy title]**
[2–4 sentences of specific, actionable advice. Reference their actual numbers where relevant.]

RULES:
- Never recommend specific fund names, stock tickers, or predict specific returns.
- Always add an educational caveat where needed ("This is illustrative — consult a SEBI-registered advisor before acting").
- Keep each insight to 3–5 sentences. Be crisp and confident — like a senior advisor, not a textbook.
- Assume the user is a reasonably financially literate Indian urban professional.
- The combined output should be 300–450 words.`;

export const LEARN_CATS = [
  { name: 'Equity', desc: 'Ownership in companies. Higher long-term growth potential, but prices can swing significantly in the short term.', url: 'https://investor.sebi.gov.in/' },
  { name: 'Mutual Funds', desc: 'Pooled investments managed by professionals, offering diversification across stocks, bonds or both.', url: 'https://www.amfiindia.com/' },
  { name: 'Fixed Income', desc: 'Bonds, FDs and similar instruments aiming for steadier, more predictable returns with lower volatility.', url: 'https://investor.sebi.gov.in/' },
  { name: 'Gold', desc: 'A traditional store of value in India, often used to diversify a portfolio and hedge against uncertainty.', url: 'https://investor.sebi.gov.in/' },
  { name: 'NPS / Retirement', desc: 'A government-backed, long-term retirement savings scheme with a mix of equity and debt exposure.', url: 'https://www.pfrda.org.in/' },
  { name: 'REITs / InvITs', desc: 'Ways to invest in real estate or infrastructure assets through the stock exchange, without buying property directly.', url: 'https://investor.sebi.gov.in/' },
];

export const FD_RATES = [
  { bank: 'Bank A', y1: '6.75%', y2: '6.90%', y3: '6.95%' },
  { bank: 'Bank B', y1: '6.80%', y2: '7.00%', y3: '7.10%' },
  { bank: 'Bank C', y1: '6.65%', y2: '6.85%', y3: '7.00%' },
];
