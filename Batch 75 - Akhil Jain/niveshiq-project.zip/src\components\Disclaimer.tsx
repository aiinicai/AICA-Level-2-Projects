import React from 'react';

export const Disclaimer: React.FC = () => {
  return (
    <footer className="mt-12 pt-6 border-t border-slate-800/80 text-center text-[11px] text-slate-400 leading-relaxed max-w-4xl mx-auto px-4 pb-8">
      This application is a <strong>DEMO / MVP prototype</strong> for illustrative and educational purposes only. All figures, return rates, and mock integrations shown are simulated (Demo Data) and do not constitute financial, investment, tax, or legal advice. Deterministic calculation engines provide baseline risk estimates.
    </footer>
  );
};
