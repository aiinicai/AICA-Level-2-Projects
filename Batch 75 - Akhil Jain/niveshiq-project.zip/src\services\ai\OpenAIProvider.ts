import { AIProvider } from './AIProvider';
import { AppState, DerivedFinancials } from '../../models/types';
import { AI_SYSTEM_PROMPT, LEVEL_NAMES } from '../../data/constants';
import { fmtINR } from '../../engines/actionPlanEngine';

export class OpenAIProvider implements AIProvider {
  name = 'OpenAI';

  async generateInsights(state: AppState, financials: DerivedFinancials): Promise<string> {
    const cfg = state.aiSettings;
    if (!cfg.apiKey) {
      throw new Error('Please enter an API key to use this optional feature.');
    }
    if (!state.aiConsent) {
      throw new Error('Please check the consent box before generating insights.');
    }

    const summary = buildAISummary(state, financials);

    const res = await fetch(cfg.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [
          { role: 'system', content: AI_SYSTEM_PROMPT },
          { role: 'user', content: summary },
        ],
        temperature: 0.6,
        max_tokens: 900,
      }),
    });

    if (!res.ok) {
      throw new Error(
        `Request failed (HTTP ${res.status}). Check model/key or CORS restrictions.`
      );
    }

    const data = await res.json();
    return data.choices?.[0]?.message?.content || 'No response content received from API.';
  }

  async generateChatResponse(state: AppState, messages: { role: 'user' | 'assistant' | 'system'; content: string }[]): Promise<string> {
    const cfg = state.aiSettings;
    if (!cfg.apiKey) {
      throw new Error('Please enter an API key to use this optional feature.');
    }
    if (!state.aiConsent) {
      throw new Error('Please check the consent box before generating insights.');
    }

    const res = await fetch(cfg.endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [
          { role: 'system', content: AI_SYSTEM_PROMPT },
          ...messages,
        ],
        temperature: 0.6,
        max_tokens: 900,
      }),
    });

    if (!res.ok) {
      throw new Error(
        `Request failed (HTTP ${res.status}). Check model/key or CORS restrictions.`
      );
    }

    const data = await res.json();
    return data.choices?.[0]?.message?.content || 'No response content received from API.';
  }
}

export function buildAISummary(state: AppState, D: DerivedFinancials): string {
  const p = state.profile;
  const annualIncome = Number(p.annualIncome) || 0;
  const monthlyIncome = annualIncome / 12;
  const monthlyExpenses = Number(p.monthlyExpenses) || 0;
  const monthlyEMI = Number(p.monthlyEMI) || 0;
  const monthlySurplus = Math.max(monthlyIncome - monthlyExpenses - monthlyEMI, 0);
  const retirementAge = Number(p.retirementAge) || 60;
  const age = Number(p.age) || 0;
  const yearsToRetirement = Math.max(retirementAge - age, 0);

  const goals =
    (p.goals || [])
      .filter((g) => !g.sample)
      .map(
        (g) =>
          `- ${g.name}: target ${fmtINR(g.targetAmount)} in ${g.yearsRemaining} years, currently saving ${fmtINR(g.currentMonthlyContribution)}/month`
      )
      .join('\n') || 'None specified.';

  const actionTitles = D.actionPlan.map((a) => `${a.title} (${a.priority})`).join('; ') || 'None flagged.';

  return `
=== USER FINANCIAL SNAPSHOT (ANONYMIZED) ===
Age: ${p.age || 'N/A'} | Retirement Age: ${retirementAge} | Years to Retirement: ${yearsToRetirement}
Marital Status: ${p.maritalStatus} | Dependents: ${p.dependents}
Income Stability: ${p.incomeStability}

Annual Income: ${fmtINR(annualIncome)}
Monthly Income: ${fmtINR(monthlyIncome)}
Monthly Essential Expenses: ${fmtINR(monthlyExpenses)}
Monthly EMI/Debt Payments: ${fmtINR(monthlyEMI)}
Estimated Monthly Investable Surplus: ${fmtINR(monthlySurplus)}

Emergency Fund: ${fmtINR(p.emergencyFund)} → ${D.cap.efMonths.toFixed(1)} months of expenses (target: 6 months)
Outstanding Loans: ${fmtINR(p.outstandingLoans)} | Debt-to-Income Ratio: ${D.cap.dtiRatio.toFixed(2)}x
EMI-to-Income Ratio: ${(D.cap.emiRatio * 100).toFixed(0)}%

=== RISK PROFILE ===
Financial Stability Score: ${Math.round(D.cap.score)}/100
Risk Capacity: ${LEVEL_NAMES[D.capLevel]} (Level ${D.capLevel}/5)
Risk Appetite: ${LEVEL_NAMES[D.appLevel]} (Level ${D.appLevel}/5)
Risk Gap (Appetite minus Capacity): ${D.gap > 0 ? '+' : ''}${D.gap} (${D.gap > 1 ? 'user wants more risk than they can absorb' : D.gap < -1 ? 'user is more conservative than finances require' : 'well-aligned'})
Recommended Profile: ${D.recLabel}

=== PORTFOLIO ===
Total Portfolio Value: ${fmtINR(D.alloc.total)}
Current Allocation — Equity: ${D.alloc.equityPct.toFixed(0)}% | Debt: ${D.alloc.debtPct.toFixed(0)}% | Gold: ${D.alloc.goldPct.toFixed(0)}% | Liquid: ${D.alloc.liquidPct.toFixed(0)}%
Selected Strategy: ${D.selectedStrategyObj.label} → Target Equity: ${D.selectedStrategyObj.equity}% | Debt: ${D.selectedStrategyObj.debt}% | Gold: ${D.selectedStrategyObj.gold}% | Liquid: ${D.selectedStrategyObj.liquid}%
Blended Illustrative Return: ${D.blendedReturnPct.toFixed(1)}% p.a.

=== GOALS ===
${goals}

=== APP-GENERATED ACTION PLAN (ALREADY SHOWN TO USER — DO NOT REPEAT) ===
${actionTitles}

Now provide your 5 powerful advisor-level insights that go BEYOND the action plan above.
`.trim();
}

