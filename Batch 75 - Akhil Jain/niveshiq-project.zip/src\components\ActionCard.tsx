import React from 'react';
import { ActionItem } from '../models/types';

interface ActionCardProps {
  action: ActionItem;
  index: number;
}

const PRIORITY_STYLES: Record<string, { bar: string; badge: string; badgeText: string; badgeBorder: string }> = {
  High: {
    bar: '#f87171',
    badge: 'rgba(239,68,68,0.1)',
    badgeText: '#f87171',
    badgeBorder: 'rgba(239,68,68,0.25)',
  },
  Medium: {
    bar: '#fbbf24',
    badge: 'rgba(251,191,36,0.1)',
    badgeText: '#fbbf24',
    badgeBorder: 'rgba(251,191,36,0.25)',
  },
  Low: {
    bar: '#34d399',
    badge: 'rgba(16,185,129,0.1)',
    badgeText: '#34d399',
    badgeBorder: 'rgba(16,185,129,0.25)',
  },
};

export const ActionCard: React.FC<ActionCardProps> = ({ action, index }) => {
  const ps = PRIORITY_STYLES[action.priority] || PRIORITY_STYLES.Low;

  return (
    <div
      className="rounded-2xl overflow-hidden card-hover"
      style={{
        background: 'linear-gradient(145deg, rgba(255,255,255,0.035) 0%, rgba(255,255,255,0.01) 100%)',
        border: '1px solid rgba(255,255,255,0.07)',
        boxShadow: '0 4px 24px rgba(0,0,0,0.2)',
        borderLeft: `4px solid ${ps.bar}`,
      }}
    >
      <div className="p-6 space-y-4">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-3 pb-3"
          style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
          <h3 className="text-base sm:text-lg font-bold text-white tracking-tight flex items-center gap-2.5">
            <span
              className="w-7 h-7 rounded-full text-xs font-black flex items-center justify-center shrink-0"
              style={{ background: `${ps.bar}22`, color: ps.bar, border: `1px solid ${ps.bar}44` }}
            >
              {index + 1}
            </span>
            {action.title}
          </h3>
          <span
            className="px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider rounded-full"
            style={{ background: ps.badge, color: ps.badgeText, border: `1px solid ${ps.badgeBorder}` }}
          >
            {action.priority} Priority
          </span>
        </div>

        {/* Metrics Row */}
        <div
          className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 rounded-xl text-xs sm:text-sm"
          style={{ background: 'rgba(2,6,23,0.5)', border: '1px solid rgba(255,255,255,0.05)' }}
        >
          <div>
            <span className="text-slate-500 font-semibold">{action.curLabel}: </span>
            <strong className="text-slate-200">{action.curVal}</strong>
          </div>
          <div>
            <span className="text-slate-500 font-semibold">{action.tgtLabel}: </span>
            <strong style={{ color: '#818cf8' }}>{action.tgtVal}</strong>
          </div>
        </div>

        {/* Reason */}
        <div
          className="p-4 rounded-xl text-xs sm:text-sm text-slate-400 leading-relaxed"
          style={{ background: 'rgba(255,255,255,0.02)', borderLeft: `3px solid ${ps.bar}60` }}
        >
          {action.reason}
        </div>

        {/* Insights */}
        {action.insights && action.insights.length > 0 && (
          <ul className="space-y-2 pt-1">
            {action.insights.map((ins, i) => (
              <li key={i} className="flex items-start gap-2 text-xs text-slate-500">
                <span style={{ color: ps.bar }} className="font-bold mt-0.5 shrink-0">›</span>
                <span>{ins}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};
