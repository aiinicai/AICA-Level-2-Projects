import { Profile, Portfolio } from '../models/types';
import { DEFAULT_RETURNS } from './constants';

export const DEMO_PROFILE: Profile = {
  age: 38,
  maritalStatus: 'Married',
  dependents: 2,
  retirementAge: 60,
  annualIncome: 2400000,
  monthlyExpenses: 75000,
  monthlyEMI: 35000,
  incomeStability: 'Stable',
  emergencyFund: 250000,
  outstandingLoans: 4500000,
  goals: [
    {
      id: 1,
      type: 'Retirement',
      name: 'Retirement',
      targetAmount: 50000000,
      yearsRemaining: 22,
      currentMonthlyContribution: 15000,
      sample: true,
    },
    {
      id: 2,
      type: 'Child Education',
      name: "Child's Education",
      targetAmount: 5000000,
      yearsRemaining: 12,
      currentMonthlyContribution: 10000,
      sample: true,
    },
  ],
};

export const DEMO_PORTFOLIO: Portfolio = {
  mode: 'import',
  stocks: 450000,
  equityMF: 650000,
  debtMF: 200000,
  fdRd: 300000,
  epfPpf: 250000,
  gold: 150000,
  nps: 100000,
  bonds: 0,
  cash: 150000,
  other: 0,
  imported: true,
  brokerName: 'Zerodha',
};

export const DEMO_APPETITE_ANSWERS = [5, 5, 5, 5, 5];
export const DEMO_SELECTED_STRATEGY = 'aggressive';
export const DEMO_RETURN_ASSUMPTIONS = { ...DEFAULT_RETURNS };
