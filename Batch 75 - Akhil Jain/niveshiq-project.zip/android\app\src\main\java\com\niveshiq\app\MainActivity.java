package com.niveshiq.app;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
