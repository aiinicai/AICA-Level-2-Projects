import React from 'react';
import { AppState, DerivedFinancials, Portfolio } from '../models/types';
import { PortfolioChart } from '../components/PortfolioChart';
import { Disclaimer } from '../components/Disclaimer';

interface PortfolioScreenProps {
  state: AppState;
  financials: DerivedFinancials;
  onUpdatePortfolio: (key: keyof Portfolio, value: any) => void;
  onImportBroker: (brokerName: string) => void;
  onBack: () => void;
  onContinue: () => void;
}

const BROKERS = ['Zerodha', 'Groww', 'ICICI Direct', 'Other Broker'];

export const PortfolioScreen: React.FC<PortfolioScreenProps> = ({
  state,
  financials,
  onUpdatePortfolio,
  onImportBroker,
  onBack,
  onContinue,
}) => {
  const p = state.portfolio;
  const isImportMode = p.mode === 'import';

  type NumericAssetKey = 'stocks' | 'equityMF' | 'debtMF' | 'fdRd' | 'epfPpf' | 'gold' | 'nps' | 'bonds' | 'cash' | 'other';
  const fields: Array<{ key: NumericAssetKey; label: string }> = [
    { key: 'stocks', label: 'Stocks' },
    { key: 'equityMF', label: 'Equity Mutual Funds' },
    { key: 'debtMF', label: 'Debt Mutual Funds' },
    { key: 'fdRd', label: 'FD / RD' },
    { key: 'epfPpf', label: 'EPF / PPF' },
    { key: 'gold', label: 'Gold' },
    { key: 'nps', label: 'NPS' },
    { key: 'bonds', label: 'Bonds' },
    { key: 'cash', label: 'Cash / Savings' },
    { key: 'other', label: 'Other Investments' },
  ];

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fade-in-up">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient">
          What Do You Currently Own?
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          Import a demo portfolio or enter holdings manually to establish your baseline asset allocation.
        </p>
      </div>

      {/* Mode Switcher */}
      <div className="flex gap-1.5 p-1.5 rounded-2xl max-w-sm"
        style={{ background: 'rgba(15,23,42,0.8)', border: '1px solid rgba(255,255,255,0.06)' }}>
        {[{ label: 'Import Portfolio (Demo)', mode: 'import' }, { label: 'Enter Manually', mode: 'manual' }].map((m) => (
          <button
            key={m.mode}
            onClick={() => onUpdatePortfolio('mode', m.mode)}
            className={`flex-1 py-2.5 rounded-xl font-bold text-xs transition-all duration-200 ${
              p.mode === m.mode ? 'text-white' : 'text-slate-500 hover:text-slate-300'
            }`}
            style={p.mode === m.mode ? {
              background: 'linear-gradient(135deg, #4f46e5, #7c3aed)',
              boxShadow: '0 2px 12px rgba(99,102,241,0.3)',
            } : {}}
          >
            {m.label}
          </button>
        ))}
      </div>

      {/* Mode Content */}
      {isImportMode ? (
        <div className="section-card">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-white tracking-tight">Mock Broker Integrations</h2>
            <span className="px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-wider rounded-full"
              style={{ background: 'rgba(251,191,36,0.1)', color: '#fbbf24', border: '1px solid rgba(251,191,36,0.2)' }}>
              Demo Data
            </span>
          </div>
          <p className="text-xs text-slate-500">
            Simulated single-click integrations for testing. No actual broker credentials are requested or stored.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {BROKERS.map((b) => (
              <div
                key={b}
                className="p-4 rounded-xl flex items-center justify-between card-hover"
                style={{ background: 'rgba(2,6,23,0.7)', border: '1px solid rgba(255,255,255,0.06)' }}
              >
                <div>
                  <span className="font-bold text-sm text-white">{b}</span>
                  <span className="ml-2 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: 'rgba(99,102,241,0.15)', color: '#818cf8', border: '1px solid rgba(99,102,241,0.2)' }}>
                    Mock
                  </span>
                </div>
                <button
                  onClick={() => onImportBroker(b)}
                  className="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all hover:scale-105"
                  style={{ background: 'rgba(99,102,241,0.15)', color: '#818cf8', border: '1px solid rgba(99,102,241,0.25)' }}
                >
                  Import
                </button>
              </div>
            ))}
          </div>

          {p.imported && (
            <div className="p-3.5 rounded-xl text-xs font-semibold flex items-center gap-2"
              style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)', color: '#34d399' }}>
              ✅ Demo portfolio imported from <strong>{p.brokerName}</strong>. Adjust values under "Enter Manually".
            </div>
          )}
        </div>
      ) : (
        <div className="section-card">
          <h2 className="section-title">Manual Portfolio Holdings (₹)</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {fields.map((f) => (
              <div key={f.key}>
                <label className="field-label">{f.label}</label>
                <input
                  type="number"
                  value={p[f.key] || ''}
                  onChange={(e) => onUpdatePortfolio(f.key, e.target.value === '' ? 0 : parseFloat(e.target.value))}
                  placeholder="0"
                  className="input-field"
                />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Allocation Chart */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-white tracking-tight">Current Asset Allocation</h2>
        <PortfolioChart alloc={financials.alloc} />
      </div>

      {/* Bottom Nav */}
      <div className="flex justify-between pt-2">
        <button onClick={onBack} className="btn-secondary">← Back</button>
        <button onClick={onContinue} className="btn-primary">Assess My Risk Profile →</button>
      </div>

      <Disclaimer />
    </div>
  );
};
