import React from 'react';
import { AppState, DerivedFinancials } from '../models/types';
import { APPETITE_QUESTIONS, LEVEL_COLORS, LEVEL_NAMES } from '../data/constants';
import { RiskGauge } from '../components/RiskGauge';
import { RiskGapCard } from '../components/RiskGapCard';
import { Disclaimer } from '../components/Disclaimer';

interface RiskProfileScreenProps {
  state: AppState;
  financials: DerivedFinancials;
  onUpdateAppetite: (index: number, val: number) => void;
  onBack: () => void;
  onContinue: () => void;
}

export const RiskProfileScreen: React.FC<RiskProfileScreenProps> = ({
  state,
  financials,
  onUpdateAppetite,
  onBack,
  onContinue,
}) => {
  const appetite = financials.appetite;
  const cap = financials.cap;

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fade-in-up">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient">
          Your Financial Risk Profile
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          We separate <strong className="text-slate-400">what you want</strong> (Risk Appetite) from{' '}
          <strong className="text-slate-400">what your finances can support</strong> (Risk Capacity).
        </p>
      </div>

      {/* Grid: Appetite vs Capacity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Risk Appetite */}
        <div className="section-card flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-3"
              style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <div>
                <h2 className="text-base font-bold text-white tracking-tight">Risk Appetite</h2>
                <span className="text-xs text-slate-500">Psychological Willingness ({appetite.answered}/5 answered)</span>
              </div>
              <span className="px-2 py-1 text-[9px] font-bold uppercase tracking-wider rounded-full"
                style={{ background: 'rgba(251,191,36,0.1)', color: '#fbbf24', border: '1px solid rgba(251,191,36,0.2)' }}>
                Assessment
              </span>
            </div>

            <div className="space-y-5">
              {APPETITE_QUESTIONS.map((qq, qi) => (
                <div key={qi} className="space-y-2">
                  <p className="text-xs font-semibold text-slate-300">
                    {qi + 1}. {qq.q}
                  </p>
                  <div className="space-y-1.5">
                    {qq.options.map((o) => {
                      const isChecked = state.appetiteAnswers[qi] === o.v;
                      return (
                        <label
                          key={o.v}
                          className={`flex items-start gap-2.5 p-2.5 rounded-xl text-xs cursor-pointer transition-all duration-150 ${
                            isChecked ? 'text-white font-semibold' : 'text-slate-500 hover:text-slate-300'
                          }`}
                          style={isChecked ? {
                            background: 'rgba(99,102,241,0.15)',
                            border: '1px solid rgba(99,102,241,0.35)',
                          } : {
                            background: 'rgba(2,6,23,0.6)',
                            border: '1px solid rgba(255,255,255,0.05)',
                          }}
                        >
                          <input
                            type="radio"
                            name={`q_${qi}`}
                            checked={isChecked}
                            onChange={() => onUpdateAppetite(qi, o.v)}
                            className="mt-0.5 accent-indigo-500"
                          />
                          <span>{o.t}</span>
                        </label>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-5 pt-4 flex items-center justify-between"
            style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Assessed Appetite</span>
            <span className="text-xl font-extrabold" style={{ color: LEVEL_COLORS[financials.appLevel] }}>
              {LEVEL_NAMES[financials.appLevel]}
            </span>
          </div>
        </div>

        {/* Risk Capacity */}
        <div className="section-card flex flex-col justify-between">
          <div className="space-y-5">
            <div className="flex items-center justify-between pb-3"
              style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              <div>
                <h2 className="text-base font-bold text-white tracking-tight">Risk Capacity</h2>
                <span className="text-xs text-slate-500">Financial Ability to Absorb Risk</span>
              </div>
              <span className="px-2 py-1 text-[9px] font-bold uppercase tracking-wider rounded-full"
                style={{ background: 'rgba(99,102,241,0.1)', color: '#818cf8', border: '1px solid rgba(99,102,241,0.2)' }}>
                Deterministic
              </span>
            </div>

            {/* Score cards */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 rounded-xl space-y-1"
                style={{ background: 'rgba(2,6,23,0.8)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Stability Score</span>
                <div className="text-3xl font-black text-white mt-1">
                  {Math.round(cap.score)}<span className="text-xs text-slate-600 font-normal">/100</span>
                </div>
              </div>
              <div className="p-4 rounded-xl space-y-1"
                style={{ background: 'rgba(2,6,23,0.8)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Risk Capacity</span>
                <div className="text-2xl font-black mt-1" style={{ color: LEVEL_COLORS[financials.capLevel] }}>
                  {LEVEL_NAMES[financials.capLevel]}
                </div>
              </div>
            </div>

            {/* Breakdown */}
            <details className="rounded-xl p-4 text-xs text-slate-400 group"
              style={{ background: 'rgba(2,6,23,0.7)', border: '1px solid rgba(255,255,255,0.06)' }}>
              <summary className="font-bold text-indigo-400 cursor-pointer focus:outline-none flex items-center justify-between">
                <span>Why did we calculate this score?</span>
                <span className="text-slate-600 group-open:rotate-180 transition-transform">▼</span>
              </summary>
              <ul className="space-y-1.5 pt-3 text-slate-400"
                style={{ borderTop: '1px solid rgba(255,255,255,0.05)', marginTop: '12px' }}>
                <li>• <strong className="text-slate-300">Emergency Fund:</strong> {cap.efMonths.toFixed(1)} months of essential expenses</li>
                <li>• <strong className="text-slate-300">Income Stability:</strong> {state.profile.incomeStability}</li>
                <li>• <strong className="text-slate-300">Dependents:</strong> {state.profile.dependents}</li>
                <li>• <strong className="text-slate-300">EMI Burden:</strong> ≈ {(cap.emiRatio * 100).toFixed(0)}% of monthly income</li>
                <li>• <strong className="text-slate-300">Outstanding Debt:</strong> ≈ {cap.dtiRatio.toFixed(2)}x annual income</li>
                <li>• <strong className="text-slate-300">Investment Horizon:</strong> {cap.horizon} years to planned retirement</li>
              </ul>
            </details>
          </div>

          <div className="text-xs text-slate-600 italic pt-2">
            Deterministic risk capacity is based on your balance sheet health, cash flows, and time horizon.
          </div>
        </div>
      </div>

      {/* Gauge */}
      <div className="section-card space-y-5">
        <h2 className="text-base font-bold text-white tracking-tight">Recommended Risk Profile Spectrum</h2>
        <RiskGauge
          appetiteLevel={financials.appLevel}
          capacityLevel={financials.capLevel}
          recommendedLevel={financials.recLevelCont}
        />
      </div>

      {/* Risk Gap */}
      <RiskGapCard gap={financials.gap} reasons={financials.reasons} />

      {/* Bottom Nav */}
      <div className="flex justify-between pt-2">
        <button onClick={onBack} className="btn-secondary">← Back</button>
        <button onClick={onContinue} className="btn-primary">Continue to Strategy →</button>
      </div>

      <Disclaimer />
    </div>
  );
};
