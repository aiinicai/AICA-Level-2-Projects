import React from 'react';
import { PortfolioAllocation } from '../models/types';
import { fmtINR } from '../engines/actionPlanEngine';

interface PortfolioChartProps {
  alloc: PortfolioAllocation;
  size?: number;
  strokeWidth?: number;
}

export const PortfolioChart: React.FC<PortfolioChartProps> = ({
  alloc,
  size = 200,
  strokeWidth = 26,
}) => {
  const segments = [
    { label: 'Equity / Growth', pct: alloc.equityPct, color: '#3b82f6', amount: alloc.equity },
    { label: 'Debt / Fixed Income', pct: alloc.debtPct, color: '#10b981', amount: alloc.debt },
    { label: 'Gold / Alternatives', pct: alloc.goldPct, color: '#f59e0b', amount: alloc.gold },
    { label: 'Liquid / Cash', pct: alloc.liquidPct, color: '#64748b', amount: alloc.liquid },
  ];

  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;

  let cumulativeOffset = 0;

  return (
    <div className="flex flex-col sm:flex-row items-center gap-8 bg-slate-900/60 border border-slate-800 p-6 rounded-2xl">
      {/* SVG Donut Chart */}
      <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Background circle */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke="#1e293b"
            strokeWidth={strokeWidth}
          />
          {segments.map((seg, i) => {
            const dashLength = (Math.max(seg.pct, 0) / 100) * circumference;
            const strokeOffset = -cumulativeOffset;
            cumulativeOffset += dashLength;

            return (
              <circle
                key={i}
                cx={size / 2}
                cy={size / 2}
                r={radius}
                fill="none"
                stroke={seg.color}
                strokeWidth={strokeWidth}
                strokeDasharray={`${dashLength} ${circumference - dashLength}`}
                strokeDashoffset={strokeOffset}
                className="transition-all duration-500 hover:opacity-80"
              />
            );
          })}
        </svg>

        {/* Center metric */}
        <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2">
          <div className="text-lg font-black text-white tracking-tight">
            {fmtINR(alloc.total)}
          </div>
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
            Total Value
          </div>
        </div>
      </div>

      {/* Legend Breakdown */}
      <div className="flex-1 space-y-3 w-full">
        {segments.map((seg) => (
          <div key={seg.label} className="flex items-center justify-between text-xs sm:text-sm">
            <div className="flex items-center gap-2.5">
              <span
                className="w-3 h-3 rounded-full flex-shrink-0"
                style={{ backgroundColor: seg.color }}
              />
              <span className="font-semibold text-slate-200">{seg.label}</span>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-bold text-white">{seg.pct.toFixed(0)}%</span>
              <span className="text-xs font-medium text-slate-400 min-w-[80px] text-right">
                {fmtINR(seg.amount)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
