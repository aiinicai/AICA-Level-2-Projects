import React from 'react';
import { AppState, DerivedFinancials, ReturnAssumptions } from '../models/types';
import { LEVEL_NAMES } from '../data/constants';
import { StrategySelector } from '../components/StrategySelector';
import { AllocationComparison } from '../components/AllocationComparison';
import { Disclaimer } from '../components/Disclaimer';
import { fmtINR } from '../engines/actionPlanEngine';

interface StrategyScreenProps {
  state: AppState;
  financials: DerivedFinancials;
  onSelectStrategy: (key: string) => void;
  onUseRecommended: () => void;
  onAcknowledgeRisk: () => void;
  onUpdateReturn: (key: keyof ReturnAssumptions, val: number) => void;
  onResetReturns: () => void;
  onBack: () => void;
  onContinue: () => void;
}

export const StrategyScreen: React.FC<StrategyScreenProps> = ({
  state,
  financials,
  onSelectStrategy,
  onUseRecommended,
  onAcknowledgeRisk,
  onUpdateReturn,
  onResetReturns,
  onBack,
  onContinue,
}) => {
  const selectedStrategy = financials.selectedStrategyObj;
  const showAlert = financials.riskAlert && !state.riskAcknowledged;
  const ra = state.returnAssumptions;

  const returnFields: Array<{ key: keyof ReturnAssumptions; label: string }> = [
    { key: 'equity', label: 'Equity / Growth' },
    { key: 'debt', label: 'Debt / Fixed Income' },
    { key: 'gold', label: 'Gold / Alternatives' },
    { key: 'liquid', label: 'Liquid / Cash' },
  ];

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fade-in-up">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient">
          Select Your Investment Strategy
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          Illustrative demo asset allocations. You may select any strategy, including aggressive options.
        </p>
      </div>

      <StrategySelector
        selectedKey={financials.selectedKey}
        recommendedKey={financials.selectedKey}
        onSelect={onSelectStrategy}
      />

      {/* ⚠️ Risk Alert */}
      {showAlert && (
        <div className="p-6 rounded-2xl space-y-4"
          style={{
            background: 'linear-gradient(135deg, rgba(239,68,68,0.08), rgba(239,68,68,0.04))',
            border: '1px solid rgba(239,68,68,0.25)',
          }}>
          <div className="flex items-center gap-3 font-extrabold text-base" style={{ color: '#f87171' }}>
            <span className="text-2xl">⚠️</span> Risk Alert: Aggressive Strategy Override
          </div>
          <p className="text-xs sm:text-sm leading-relaxed" style={{ color: '#fca5a5' }}>
            The selected strategy (<strong>{selectedStrategy.label}</strong>) is materially more aggressive than your
            current financial capacity (<strong>{LEVEL_NAMES[financials.capLevel]}</strong>) comfortably supports.
          </p>
          <div className="flex flex-wrap gap-3 pt-1">
            <button onClick={onUseRecommended} className="btn-primary"
              style={{ background: 'linear-gradient(135deg, #059669, #10b981)', boxShadow: '0 0 16px rgba(16,185,129,0.3)' }}>
              Use Recommended Strategy
            </button>
            <button
              onClick={onAcknowledgeRisk}
              className="px-5 py-2.5 rounded-xl font-bold text-xs transition-all"
              style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.25)', color: '#fca5a5' }}
            >
              Continue With My Strategy
            </button>
          </div>
        </div>
      )}

      {/* Allocation Comparison */}
      <div className="space-y-4">
        <h2 className="text-base font-bold text-white tracking-tight">
          Current Allocation vs Target ({selectedStrategy.label})
        </h2>
        <AllocationComparison alloc={financials.alloc} target={selectedStrategy} />

        {financials.alloc.total > 0 && (
          <div className="p-4 rounded-xl text-xs text-slate-400"
            style={{ background: 'rgba(2,6,23,0.7)', border: '1px solid rgba(255,255,255,0.06)' }}>
            Approx. rebalance amount:{' '}
            <strong className="text-white">
              {fmtINR(Math.abs(financials.alloc.equity - (financials.alloc.total * selectedStrategy.equity) / 100))}
            </strong>{' '}
            between equity and debt/gold/liquid categories to align with target.
          </div>
        )}
      </div>

      {/* Return Assumptions */}
      <div className="section-card">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white tracking-tight">
            Return Assumptions (% p.a.)
          </h2>
          <button
            onClick={onResetReturns}
            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors"
          >
            Reset to Defaults
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 pt-1">
          {returnFields.map((rf) => (
            <div key={rf.key}>
              <label className="field-label">{rf.label}</label>
              <div className="relative">
                <input
                  type="number"
                  step="0.5"
                  value={ra[rf.key]}
                  onChange={(e) => onUpdateReturn(rf.key, parseFloat(e.target.value) || 0)}
                  className="input-field pr-8"
                />
                <span className="absolute right-3 top-2.5 text-xs text-slate-600 font-bold">%</span>
              </div>
            </div>
          ))}
        </div>

        <div className="pt-4 flex items-center justify-between"
          style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
          <span className="text-xs font-bold uppercase tracking-widest text-slate-500">
            Blended Return for "{selectedStrategy.label}"
          </span>
          <span className="text-2xl font-extrabold text-gradient-blue">
            {financials.blendedReturnPct.toFixed(1)}% p.a.
          </span>
        </div>
      </div>

      {/* Bottom Nav */}
      <div className="flex justify-between pt-2">
        <button onClick={onBack} className="btn-secondary">← Back</button>
        <button onClick={onContinue} className="btn-primary">Continue to Action Plan →</button>
      </div>

      <Disclaimer />
    </div>
  );
};
