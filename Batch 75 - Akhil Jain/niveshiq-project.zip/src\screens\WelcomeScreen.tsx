import React from 'react';
import { Disclaimer } from '../components/Disclaimer';

interface WelcomeScreenProps {
  onLoadDemo: () => void;
  onStartFresh: () => void;
}

const FEATURES = [
  {
    num: '01',
    title: 'Understand You',
    desc: 'Income, expenses, debt, dependents, emergency fund and financial goals — all in one place.',
    accent: '#4f46e5',
    glow: 'rgba(79,70,229,0.15)',
  },
  {
    num: '02',
    title: 'Assess Risk',
    desc: 'Risk Appetite (what you want) vs Risk Capacity (what your finances can support) — separated.',
    accent: '#7c3aed',
    glow: 'rgba(124,58,237,0.15)',
  },
  {
    num: '03',
    title: 'Recommend Allocation',
    desc: 'A blended, explainable strategy — not a one-size-fits-all age-based rule.',
    accent: '#0ea5e9',
    glow: 'rgba(14,165,233,0.15)',
  },
  {
    num: '04',
    title: 'Explain & Act',
    desc: 'A prioritized action plan and AI-powered deeper insights — in plain language.',
    accent: '#10b981',
    glow: 'rgba(16,185,129,0.15)',
  },
];

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onLoadDemo, onStartFresh }) => {
  return (
    <div className="min-h-[88vh] flex flex-col justify-between pt-8 sm:pt-16 px-4 max-w-5xl mx-auto animate-fade-in-up">
      <div className="space-y-10">
        {/* Badge */}
        <div className="text-center">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-[11px] font-bold uppercase tracking-widest rounded-full"
            style={{ background: 'rgba(251,191,36,0.08)', color: '#fbbf24', border: '1px solid rgba(251,191,36,0.2)' }}>
            ⚡ Demo / MVP — Life-Centric Wealth Advisory
          </span>
        </div>

        {/* Hero Title */}
        <div className="text-center space-y-5">
          <h1 className="text-4xl sm:text-6xl font-black tracking-tight leading-tight max-w-4xl mx-auto">
            <span className="text-white">Build a portfolio around your life —</span>
            <br />
            <span className="text-gradient">not just your age.</span>
          </h1>
          <p className="text-base sm:text-xl font-medium text-slate-500 max-w-2xl mx-auto leading-relaxed">
            Understand your financial position, risk appetite and risk capacity before deciding how aggressively to invest.
          </p>
        </div>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onLoadDemo}
            className="btn-primary w-full sm:w-auto text-base"
          >
            <span>⚡</span> Try Demo Investor
          </button>
          <button
            onClick={onStartFresh}
            className="btn-secondary w-full sm:w-auto text-base"
          >
            Analyse My Financial Profile
          </button>
        </div>

        {/* Feature Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4 text-left">
          {FEATURES.map((f, i) => (
            <div
              key={f.num}
              className="glass-card p-5 space-y-3 card-hover"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center text-xs font-black"
                style={{ background: f.glow, color: f.accent, border: `1px solid ${f.accent}33` }}
              >
                {f.num}
              </div>
              <h3 className="font-bold text-white text-sm tracking-tight">{f.title}</h3>
              <p className="text-xs text-slate-500 leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      <Disclaimer />
    </div>
  );
};
