# NiveshIQ - Personal Finance & Risk Planning Application

## Tech Stack
- Frontend: React 18, TypeScript, Tailwind CSS, Vite
- Mobile Engine: Capacitor 6 (Android)
- Testing: Vitest

## How to Run the Web Application

1. Ensure Node.js (v18 or higher) is installed.
2. In this directory, open a terminal and run:
   npm install
   npm run dev
3. Open your browser at the local URL displayed (typically http://localhost:5173).

## Other Available Commands
- npm run build   : Compiles production-ready bundle into dist/
- npm test        : Runs unit tests (Vitest)
- npm run cap:sync: Syncs the web build with the Android project

## Android Project
The android/ folder contains the native Android Studio project.
To open in Android Studio:
   npm run build
   npx cap open android
Or open the android directory directly in Android Studio.

## Standalone Demo
You can also open 1NiveshIQ.htm directly in any web browser without running any commands.
