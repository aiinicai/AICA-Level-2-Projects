import React from 'react';
import { FinancialGoal } from '../models/types';
import { fmtINR } from '../engines/actionPlanEngine';

interface GoalCardProps {
  goal: FinancialGoal;
  onRemove: (id: number) => void;
  onPromote?: (id: number) => void;
}

const GOAL_ICONS: Record<string, string> = {
  'Retirement': '🏡',
  'Child Education': '🎓',
  'Home Purchase': '🏠',
  'Other': '🎯',
};

export const GoalCard: React.FC<GoalCardProps> = ({ goal, onRemove, onPromote }) => {
  const icon = GOAL_ICONS[goal.type] || '🎯';

  return (
    <div className="rounded-xl p-3.5 card-hover flex flex-col sm:flex-row sm:items-center justify-between gap-3"
      style={{
        background: 'rgba(255,255,255,0.025)',
        border: '1px solid rgba(255,255,255,0.07)',
        borderLeft: '3px solid rgba(99,102,241,0.5)',
      }}>
      <div className="flex items-start gap-3">
        <span className="text-lg mt-0.5">{icon}</span>
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <strong className="text-sm font-bold text-white">{goal.name}</strong>
            <span className="text-[10px] font-medium text-slate-500">({goal.type})</span>
            {goal.sample && (
              <span className="px-1.5 py-0.5 text-[9px] font-bold rounded-full"
                style={{ background: 'rgba(251,191,36,0.1)', color: '#fbbf24', border: '1px solid rgba(251,191,36,0.2)' }}>
                SAMPLE
              </span>
            )}
          </div>
          <div className="text-xs text-slate-500 flex flex-wrap gap-x-2 gap-y-0.5">
            <span>Target: <strong className="text-slate-300">{fmtINR(goal.targetAmount)}</strong></span>
            <span className="text-slate-700">•</span>
            <span>{goal.yearsRemaining} yrs</span>
            {goal.currentMonthlyContribution > 0 && (
              <>
                <span className="text-slate-700">•</span>
                <span>Saving <strong className="text-indigo-400">{fmtINR(goal.currentMonthlyContribution)}/mo</strong></span>
              </>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center gap-2 shrink-0">
        {goal.sample && onPromote && (
          <button
            onClick={() => onPromote(goal.id)}
            className="px-3 py-1.5 text-xs font-semibold rounded-lg transition-all"
            style={{ background: 'rgba(99,102,241,0.15)', color: '#818cf8', border: '1px solid rgba(99,102,241,0.25)' }}
          >
            Use in My Plan
          </button>
        )}
        <button
          onClick={() => onRemove(goal.id)}
          className="w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold transition-all hover:scale-105"
          style={{ background: 'rgba(239,68,68,0.1)', color: '#f87171', border: '1px solid rgba(239,68,68,0.2)' }}
          title="Remove Goal"
        >
          ✕
        </button>
      </div>
    </div>
  );
};
