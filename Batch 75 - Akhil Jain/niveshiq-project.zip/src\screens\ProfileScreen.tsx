import React from 'react';
import { AppState, GoalType } from '../models/types';
import { GoalCard } from '../components/GoalCard';
import { Disclaimer } from '../components/Disclaimer';

interface ProfileScreenProps {
  state: AppState;
  onUpdateProfile: (path: string, value: any) => void;
  onAddGoal: () => void;
  onRemoveGoal: (id: number) => void;
  onPromoteGoal: (id: number) => void;
  onContinue: () => void;
}

export const ProfileScreen: React.FC<ProfileScreenProps> = ({
  state,
  onUpdateProfile,
  onAddGoal,
  onRemoveGoal,
  onPromoteGoal,
  onContinue,
}) => {
  const p = state.profile;
  const ng = state.newGoal;

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-fade-in-up">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient">
          Understand Your Financial Position
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          Tell us a little about yourself. We'll use this to evaluate your financial stability and risk capacity.
        </p>
      </div>

      {/* Grid 1: Personal & Income */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Personal Details */}
        <div className="section-card">
          <h2 className="section-title">Personal Details</h2>

          <div className="space-y-1">
            <label className="field-label">Age</label>
            <input
              type="number"
              value={p.age}
              onChange={(e) => onUpdateProfile('age', e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="e.g. 38"
              className="input-field"
            />
          </div>

          <div className="space-y-1">
            <label className="field-label">Marital Status</label>
            <select
              value={p.maritalStatus}
              onChange={(e) => onUpdateProfile('maritalStatus', e.target.value)}
              className="select-field"
            >
              {['Single', 'Married', 'Divorced', 'Widowed'].map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1">
            <label className="field-label flex justify-between">
              <span>Number of Dependents</span>
              <span className="text-slate-600 font-normal">Children, parents, spouse</span>
            </label>
            <input
              type="number"
              value={p.dependents}
              onChange={(e) => onUpdateProfile('dependents', parseFloat(e.target.value) || 0)}
              className="input-field"
            />
          </div>

          <div className="space-y-1">
            <label className="field-label">Planned Retirement Age</label>
            <input
              type="number"
              value={p.retirementAge}
              onChange={(e) => onUpdateProfile('retirementAge', parseFloat(e.target.value) || 60)}
              className="input-field"
            />
          </div>
        </div>

        {/* Income & Expenses */}
        <div className="section-card">
          <h2 className="section-title">Income & Expenses</h2>

          <div className="space-y-1">
            <label className="field-label">Annual Income (₹)</label>
            <input
              type="number"
              value={p.annualIncome}
              onChange={(e) => onUpdateProfile('annualIncome', e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="e.g. 2400000"
              className="input-field"
            />
          </div>

          <div className="space-y-1">
            <label className="field-label flex justify-between">
              <span>Monthly Essential Expenses (₹)</span>
              <span className="text-slate-600 font-normal">Rent, groceries, utilities</span>
            </label>
            <input
              type="number"
              value={p.monthlyExpenses}
              onChange={(e) => onUpdateProfile('monthlyExpenses', e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="e.g. 75000"
              className="input-field"
            />
          </div>

          <div className="space-y-1">
            <label className="field-label">Monthly EMI / Debt Payments (₹)</label>
            <input
              type="number"
              value={p.monthlyEMI}
              onChange={(e) => onUpdateProfile('monthlyEMI', e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="e.g. 35000"
              className="input-field"
            />
          </div>

          <div className="space-y-1">
            <label className="field-label">Income Stability</label>
            <select
              value={p.incomeStability}
              onChange={(e) => onUpdateProfile('incomeStability', e.target.value)}
              className="select-field"
            >
              {['Very Stable', 'Stable', 'Variable', 'Highly Variable'].map((o) => (
                <option key={o} value={o}>{o}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Grid 2: Position & Goals */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {/* Financial Position */}
        <div className="section-card">
          <h2 className="section-title">Existing Financial Position</h2>

          <div className="space-y-1">
            <label className="field-label flex justify-between">
              <span>Emergency Fund (₹)</span>
              <span className="text-slate-600 font-normal">Savings / Liquid funds</span>
            </label>
            <input
              type="number"
              value={p.emergencyFund}
              onChange={(e) => onUpdateProfile('emergencyFund', e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="e.g. 250000"
              className="input-field"
            />
          </div>

          <div className="space-y-1">
            <label className="field-label">Total Outstanding Loans (₹)</label>
            <input
              type="number"
              value={p.outstandingLoans}
              onChange={(e) => onUpdateProfile('outstandingLoans', e.target.value === '' ? '' : parseFloat(e.target.value))}
              placeholder="e.g. 4500000"
              className="input-field"
            />
          </div>
        </div>

        {/* Financial Goals */}
        <div className="section-card">
          <h2 className="section-title">Financial Goals</h2>

          <div className="space-y-3">
            {p.goals.length === 0 ? (
              <p className="text-xs text-slate-500 italic">
                No goals added yet. Add at least one goal below (e.g. Retirement, Child Education).
              </p>
            ) : (
              p.goals.map((g) => (
                <GoalCard
                  key={g.id}
                  goal={g}
                  onRemove={onRemoveGoal}
                  onPromote={onPromoteGoal}
                />
              ))
            )}
          </div>

          {/* Add Goal Form */}
          <div className="pt-4 space-y-3" style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500">+ Add New Goal</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="field-label">Goal Type</label>
                <select
                  value={ng.type}
                  onChange={(e) => onUpdateProfile('newGoal.type', e.target.value as GoalType)}
                  className="select-field text-xs"
                >
                  {['Retirement', 'Child Education', 'Home Purchase', 'Other'].map((t) => (
                    <option key={t} value={t}>{t}</option>
                  ))}
                </select>
              </div>

              {ng.type === 'Other' && (
                <div>
                  <label className="field-label">Goal Name</label>
                  <input
                    type="text"
                    value={ng.name}
                    onChange={(e) => onUpdateProfile('newGoal.name', e.target.value)}
                    placeholder="e.g. World Trip"
                    className="input-field text-xs"
                  />
                </div>
              )}

              <div>
                <label className="field-label">Target Amount (₹)</label>
                <input
                  type="number"
                  value={ng.targetAmount}
                  onChange={(e) => onUpdateProfile('newGoal.targetAmount', e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="e.g. 5000000"
                  className="input-field text-xs"
                />
              </div>

              <div>
                <label className="field-label">Years Remaining</label>
                <input
                  type="number"
                  value={ng.yearsRemaining}
                  onChange={(e) => onUpdateProfile('newGoal.yearsRemaining', e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="e.g. 12"
                  className="input-field text-xs"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="field-label">Monthly Saving (optional)</label>
                <input
                  type="number"
                  value={ng.currentMonthlyContribution}
                  onChange={(e) => onUpdateProfile('newGoal.currentMonthlyContribution', e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="e.g. 10000"
                  className="input-field text-xs"
                />
              </div>
            </div>

            <button
              onClick={onAddGoal}
              className="px-4 py-2 rounded-xl text-xs font-bold text-white transition-all duration-200 hover:scale-[1.02]"
              style={{
                background: 'linear-gradient(135deg, rgba(79,70,229,0.3), rgba(124,58,237,0.3))',
                border: '1px solid rgba(99,102,241,0.3)',
              }}
            >
              + Add Goal to Profile
            </button>
          </div>
        </div>
      </div>

      {state.formError && (
        <div className="p-4 rounded-xl text-xs font-semibold"
          style={{ background: 'rgba(239,68,68,0.08)', border: '1px solid rgba(239,68,68,0.2)', color: '#f87171' }}>
          ⚠ {state.formError}
        </div>
      )}

      {/* Quote Banner */}
      <blockquote
        className="p-5 rounded-2xl text-sm leading-relaxed"
        style={{
          background: 'linear-gradient(135deg, rgba(79,70,229,0.08), rgba(124,58,237,0.05))',
          border: '1px solid rgba(99,102,241,0.2)',
          color: '#c7d2fe',
        }}
      >
        Your investment strategy should reflect not just how much risk you are comfortable taking, but also how much risk your current financial position can support.
      </blockquote>

      {/* Bottom Nav */}
      <div className="flex justify-end pt-2">
        <button onClick={onContinue} className="btn-primary">
          Continue to Portfolio →
        </button>
      </div>

      <Disclaimer />
    </div>
  );
};
