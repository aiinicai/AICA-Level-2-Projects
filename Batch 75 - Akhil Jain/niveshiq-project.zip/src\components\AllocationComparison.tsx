import React from 'react';
import { PortfolioAllocation, StrategyAllocation } from '../models/types';

interface AllocationComparisonProps {
  alloc: PortfolioAllocation;
  target: StrategyAllocation;
}

export const AllocationComparison: React.FC<AllocationComparisonProps> = ({ alloc, target }) => {
  const categories = [
    { label: 'Equity / Growth', current: alloc.equityPct, target: target.equity, color: '#3b82f6' },
    { label: 'Debt / Fixed Income', current: alloc.debtPct, target: target.debt, color: '#10b981' },
    { label: 'Gold / Alternatives', current: alloc.goldPct, target: target.gold, color: '#f59e0b' },
    { label: 'Liquid / Cash', current: alloc.liquidPct, target: target.liquid, color: '#64748b' },
  ];

  return (
    <div className="space-y-4 bg-slate-900/60 border border-slate-800 p-6 rounded-2xl">
      <div className="flex justify-between items-center text-xs font-bold text-slate-400 uppercase tracking-wider border-b border-slate-800 pb-3">
        <span>Asset Class</span>
        <div className="flex items-center gap-6">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-blue-500" /> Current
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-600" /> Target ({target.label})
          </span>
        </div>
      </div>

      <div className="space-y-5">
        {categories.map((cat) => (
          <div key={cat.label} className="space-y-2">
            <div className="flex justify-between text-xs sm:text-sm font-semibold">
              <span className="text-slate-200">{cat.label}</span>
              <span className="text-slate-400">
                <span className="text-white font-bold">{cat.current.toFixed(0)}%</span> →{' '}
                <span className="text-blue-400 font-bold">{cat.target}%</span>
              </span>
            </div>

            {/* Current vs Target double bars */}
            <div className="space-y-1.5">
              {/* Current Bar */}
              <div className="h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500"
                  style={{
                    width: `${Math.min(cat.current, 100)}%`,
                    backgroundColor: cat.color,
                  }}
                />
              </div>
              {/* Target Bar */}
              <div className="h-2.5 bg-slate-800/60 rounded-full overflow-hidden">
                <div
                  className="h-full rounded-full transition-all duration-500 opacity-50"
                  style={{
                    width: `${Math.min(cat.target, 100)}%`,
                    backgroundColor: cat.color,
                  }}
                />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
