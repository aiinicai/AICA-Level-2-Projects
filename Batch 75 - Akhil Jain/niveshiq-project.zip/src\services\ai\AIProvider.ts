import { AppState, DerivedFinancials } from '../../models/types';

export interface AIProvider {
  name: string;
  generateInsights(state: AppState, financials: DerivedFinancials): Promise<string>;
  generateChatResponse(state: AppState, messages: { role: 'user' | 'assistant' | 'system'; content: string }[]): Promise<string>;
}
