import { Portfolio, PortfolioAllocation, RiskLevel, ReturnAssumptions } from '../models/types';
import { ANCHORS, DEFAULT_RETURNS, LEVEL_NAMES } from '../data/constants';

export function sumPortfolio(p: Portfolio): number {
  const num = (v: any) => {
    const x = parseFloat(v);
    return isNaN(x) ? 0 : x;
  };
  return (
    num(p.stocks) +
    num(p.equityMF) +
    num(p.debtMF) +
    num(p.fdRd) +
    num(p.epfPpf) +
    num(p.gold) +
    num(p.nps) +
    num(p.bonds) +
    num(p.cash) +
    num(p.other)
  );
}

export function allocationBuckets(p: Portfolio): PortfolioAllocation {
  const num = (v: any) => {
    const x = parseFloat(v);
    return isNaN(x) ? 0 : x;
  };
  const equity = num(p.stocks) + num(p.equityMF);
  const debt = num(p.debtMF) + num(p.fdRd) + num(p.epfPpf) + num(p.bonds) + num(p.nps);
  const gold = num(p.gold);
  const liquid = num(p.cash) + num(p.other);
  const total = equity + debt + gold + liquid;
  return {
    equity,
    debt,
    gold,
    liquid,
    total,
    equityPct: total ? (equity / total) * 100 : 0,
    debtPct: total ? (debt / total) * 100 : 0,
    goldPct: total ? (gold / total) * 100 : 0,
    liquidPct: total ? (liquid / total) * 100 : 0,
  };
}

export function interpolateAllocation(level: number): { equity: number; debt: number; gold: number; liquid: number } {
  const lo = Math.floor(level) as RiskLevel;
  const hi = Math.ceil(level) as RiskLevel;
  if (lo === hi) return ANCHORS[Math.max(1, Math.min(5, lo)) as RiskLevel];
  const t = level - lo;
  const a = ANCHORS[lo];
  const b = ANCHORS[hi];
  const lerp = (k: 'equity' | 'debt' | 'gold' | 'liquid') => a[k] + (b[k] - a[k]) * t;
  return { equity: lerp('equity'), debt: lerp('debt'), gold: lerp('gold'), liquid: lerp('liquid') };
}

export function nearestStrategyKey(recLevel: number): string {
  const keys: Array<[string, number]> = [
    ['conservative', 1],
    ['balanced', 3],
    ['growth', 4],
    ['aggressive', 5],
  ];
  let best = 'conservative';
  let bd = Infinity;
  keys.forEach((k) => {
    const d = Math.abs(k[1] - recLevel);
    if (d < bd - 1e-9) {
      bd = d;
      best = k[0];
    }
  });
  return best;
}

export function computeBlendedReturn(
  allocPct: { equity: number; debt: number; gold: number; liquid: number },
  returns?: ReturnAssumptions
): number {
  const r = returns || DEFAULT_RETURNS;
  return (allocPct.equity * r.equity + allocPct.debt * r.debt + allocPct.gold * r.gold + allocPct.liquid * r.liquid) / 100;
}

export function recommendedLabel(rec: number): string {
  if (Number.isInteger(rec)) return LEVEL_NAMES[rec as RiskLevel];
  const lo = LEVEL_NAMES[Math.floor(rec) as RiskLevel];
  const hi = LEVEL_NAMES[Math.ceil(rec) as RiskLevel];
  return `${lo} ${hi}`;
}
