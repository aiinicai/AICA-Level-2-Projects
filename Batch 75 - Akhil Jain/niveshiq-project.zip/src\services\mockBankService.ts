import { FD_RATES } from '../data/constants';

export interface FDRateInfo {
  bank: string;
  y1: string;
  y2: string;
  y3: string;
}

export function getMockFDRates(): FDRateInfo[] {
  return FD_RATES;
}

export function calculateFDMaturity(principal: number, annualRatePct: number, years: number): {
  maturityValue: number;
  interestEarned: number;
} {
  const p = Math.max(0, principal);
  const r = Math.max(0, annualRatePct);
  const y = Math.max(0, years);
  const maturityValue = p * Math.pow(1 + r / 100, y);
  return {
    maturityValue,
    interestEarned: Math.max(0, maturityValue - p),
  };
}
