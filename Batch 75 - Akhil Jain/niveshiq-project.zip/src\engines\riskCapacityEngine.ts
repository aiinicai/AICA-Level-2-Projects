import { Profile, Portfolio, RiskCapacityResult, RiskLevel } from '../models/types';
import { sumPortfolio } from './portfolioEngine';

export function num(v: any): number {
  const x = parseFloat(v);
  return isNaN(x) ? 0 : x;
}

export function calcRiskCapacity(profile: Profile, portfolio: Portfolio): RiskCapacityResult {
  const annualIncome = num(profile.annualIncome);
  const monthlyIncome = annualIncome / 12;
  const monthlyExpenses = num(profile.monthlyExpenses);
  const emergencyFund = num(profile.emergencyFund);
  const monthlyEMI = num(profile.monthlyEMI);
  const outstandingLoans = num(profile.outstandingLoans);
  const dependents = num(profile.dependents);
  const age = num(profile.age);
  const retirementAge = num(profile.retirementAge) || 60;

  const efMonths = monthlyExpenses > 0 ? emergencyFund / monthlyExpenses : 0;
  const efScore = Math.min(efMonths / 6, 1) * 20;

  const emiRatio = monthlyIncome > 0 ? monthlyEMI / monthlyIncome : 0;
  const emiScore = Math.max(0, 1 - emiRatio / 0.5) * 10;

  const dtiRatio = annualIncome > 0 ? outstandingLoans / annualIncome : 0;
  const dtiScore = Math.max(0, 1 - dtiRatio / 2) * 15;

  const stabilityMap: Record<string, number> = {
    'Very Stable': 15,
    'Stable': 11,
    'Variable': 6,
    'Highly Variable': 2,
  };
  const stabilityScore = stabilityMap[profile.incomeStability] ?? 8;

  const depScore = Math.max(0, 10 - Math.min(dependents, 4) * 2.5);

  const horizon = Math.max(retirementAge - age, 0);
  const horizonScore = Math.min(horizon / 30, 1) * 15;

  const totalInvestments = sumPortfolio(portfolio);
  const assetRatio = annualIncome > 0 ? totalInvestments / annualIncome : 0;
  const assetScore = Math.min(assetRatio / 2, 1) * 15;

  let penalty = 0;
  (profile.goals || [])
    .filter((g) => !g.sample)
    .forEach((g) => {
      if (num(g.yearsRemaining) > 0 && num(g.yearsRemaining) <= 3 && num(g.targetAmount) > 0) {
        penalty += 5;
      }
    });
  penalty = Math.min(penalty, 15);

  let score = efScore + emiScore + dtiScore + stabilityScore + depScore + horizonScore + assetScore - penalty;
  score = Math.max(0, Math.min(100, score));

  return {
    score,
    efScore,
    emiScore,
    dtiScore,
    stabilityScore,
    depScore,
    horizonScore,
    assetScore,
    penalty,
    efMonths,
    emiRatio,
    dtiRatio,
    horizon,
    assetRatio,
  };
}

export function levelFromScore(score: number): RiskLevel {
  if (score < 20) return 1;
  if (score < 40) return 2;
  if (score < 60) return 3;
  if (score < 80) return 4;
  return 5;
}

export function capacityReasons(cap: RiskCapacityResult, profile: Profile): string[] {
  const items = [
    { ratio: cap.efScore / 20, text: `Emergency fund covers only about ${cap.efMonths.toFixed(1)} months of expenses (target: 6 months).` },
    { ratio: cap.emiScore / 10, text: `Monthly EMI/debt payments take up a notable share of income.` },
    { ratio: cap.dtiScore / 15, text: `Outstanding loans are high relative to annual income.` },
    { ratio: cap.stabilityScore / 15, text: `Income stability is rated "${profile.incomeStability}", which adds some uncertainty.` },
    { ratio: cap.depScore / 10, text: `You have ${num(profile.dependents)} dependent(s) relying on your income.` },
    { ratio: cap.horizonScore / 15, text: `Your investment horizon to retirement is relatively short (${cap.horizon} years).` },
    { ratio: cap.assetScore / 15, text: `Your existing investment base relative to income is still developing.` },
  ];
  if (cap.penalty > 0) {
    items.push({ ratio: 0, text: `You have important goals due within the next 3 years, which reduces flexibility to take risk.` });
  }
  return items
    .filter((i) => i.ratio < 0.6)
    .sort((a, b) => a.ratio - b.ratio)
    .slice(0, 4)
    .map((i) => i.text);
}
