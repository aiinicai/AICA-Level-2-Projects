import { AIProvider } from './AIProvider';
import { OpenAIProvider } from './OpenAIProvider';
import { MockAIProvider } from './MockAIProvider';
import { AppState, DerivedFinancials } from '../../models/types';

export function getAIProvider(useMock = false): AIProvider {
  if (useMock) {
    return new MockAIProvider();
  }
  return new OpenAIProvider();
}

export async function fetchAIInsights(state: AppState, financials: DerivedFinancials, useMock = false): Promise<string> {
  const provider = getAIProvider(useMock);
  return provider.generateInsights(state, financials);
}

export async function fetchAIChatResponse(state: AppState, messages: { role: 'user' | 'assistant' | 'system'; content: string }[], useMock = false): Promise<string> {
  const provider = getAIProvider(useMock);
  return provider.generateChatResponse(state, messages);
}
