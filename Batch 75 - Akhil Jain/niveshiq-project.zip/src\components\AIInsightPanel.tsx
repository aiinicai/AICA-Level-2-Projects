import React, { useState, useRef, useEffect } from 'react';
import { AISettings } from '../models/types';

interface AIInsightPanelProps {
  aiSettings: AISettings;
  aiConsent: boolean;
  aiChatHistory: Array<{ role: 'user' | 'assistant' | 'system'; content: string }>;
  aiInsightLoading: boolean;
  aiInsightError: string;
  onUpdateSettings: (key: keyof AISettings, value: string) => void;
  onUpdateConsent: (consent: boolean) => void;
  onGenerate: () => void;
  onSendChatMessage: (message: string) => void;
  onClearKey: () => void;
}

export const AIInsightPanel: React.FC<AIInsightPanelProps> = ({
  aiSettings,
  aiConsent,
  aiChatHistory,
  aiInsightLoading,
  aiInsightError,
  onUpdateSettings,
  onUpdateConsent,
  onGenerate,
  onSendChatMessage,
  onClearKey,
}) => {
  const [chatInput, setChatInput] = useState('');
  const [showConfig, setShowConfig] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom of chat when new messages are added or loading starts
  useEffect(() => {
    if (chatBottomRef.current) {
      chatBottomRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [aiChatHistory, aiInsightLoading]);

  const handleSend = () => {
    if (!chatInput.trim() || aiInsightLoading) return;
    onSendChatMessage(chatInput.trim());
    setChatInput('');
  };

  return (
    <div 
      className="rounded-3xl p-6 space-y-6 transition-all duration-300 relative overflow-hidden"
      style={{
        background: 'linear-gradient(135deg, rgba(30, 27, 75, 0.4) 0%, rgba(15, 23, 42, 0.6) 100%)',
        border: '1px solid rgba(139, 92, 246, 0.18)',
        boxShadow: '0 12px 40px rgba(0,0,0,0.4), 0 0 32px rgba(124,58,237,0.03)',
      }}
    >
      {/* Decorative gradient sphere background */}
      <div className="absolute top-0 right-0 w-36 h-36 bg-violet-600/5 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-violet-500/10">
        <div>
          <h3 className="text-base font-extrabold text-white tracking-tight flex items-center gap-2">
            <span className="text-lg">🤖</span>
            <span>Premium AI Wealth Insights</span>
          </h3>
          <p className="text-[11px] text-violet-300/70 mt-0.5">
            Powered by ChatGPT model {aiSettings.model || '4.5'} · Active Advisor Session
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowConfig(!showConfig)}
            className="px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider text-indigo-300 hover:text-white transition-colors"
            style={{ background: 'rgba(99, 102, 241, 0.08)', border: '1px solid rgba(99, 102, 241, 0.15)' }}
          >
            ⚙️ Config
          </button>
          <span className="px-2.5 py-1 text-[9px] font-extrabold uppercase tracking-wider rounded-full bg-violet-500/10 text-violet-300 border border-violet-500/20">
            Client-Side Only
          </span>
        </div>
      </div>

      {/* Expandable Configuration */}
      {showConfig && (
        <div className="p-4 rounded-2xl bg-slate-950/70 border border-slate-800/80 space-y-4 animate-fade-in-up">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">OpenAI API Connection</h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="field-label">API Endpoint</label>
              <input
                type="text"
                value={aiSettings.endpoint}
                onChange={(e) => onUpdateSettings('endpoint', e.target.value)}
                className="input-field text-xs"
              />
            </div>
            <div>
              <label className="field-label">Model Name</label>
              <input
                type="text"
                value={aiSettings.model}
                onChange={(e) => onUpdateSettings('model', e.target.value)}
                className="input-field text-xs"
              />
            </div>
          </div>

          <div>
            <label className="field-label">OpenAI API Key</label>
            <div className="flex gap-2">
              <input
                type="password"
                value={aiSettings.apiKey}
                onChange={(e) => onUpdateSettings('apiKey', e.target.value)}
                placeholder="sk-..."
                className="input-field text-xs flex-1"
                style={{ borderColor: aiSettings.apiKey ? 'rgba(124, 58, 237, 0.3)' : undefined }}
              />
              {aiSettings.apiKey && (
                <button
                  onClick={onClearKey}
                  className="px-3 py-2 rounded-xl text-xs font-bold bg-rose-500/10 border border-rose-500/20 text-rose-400 hover:bg-rose-500/20 transition-colors"
                >
                  Clear Key
                </button>
              )}
            </div>
          </div>

          <p className="text-[10px] text-slate-500 leading-relaxed">
            Your API Key remains in your browser's local state. Data is transmitted directly to OpenAI's endpoint, preserving full client privacy.
          </p>
        </div>
      )}

      {/* Main Content Area */}
      {aiChatHistory.length === 0 ? (
        /* Setup / Generate Call to Action */
        <div className="space-y-5 py-3">
          <p className="text-xs text-slate-400 leading-relaxed">
            Generate 5 highly customized, advisor-grade insights tailored to your profile. AI details specific mutual fund categories (Mid/Small Cap splits, Global allocation hedges), custom tax-efficiency levers, and your wealth-building sequence of actions.
          </p>

          {/* Consent Checkbox */}
          <label className="flex items-start gap-3 p-3.5 rounded-2xl cursor-pointer transition-colors hover:bg-violet-950/10"
            style={{ background: 'rgba(2, 6, 23, 0.4)', border: '1px solid rgba(255, 255, 255, 0.04)' }}>
            <input
              type="checkbox"
              checked={aiConsent}
              onChange={(e) => onUpdateConsent(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded text-violet-600 focus:ring-violet-500 border-slate-700 bg-slate-900 accent-violet-500 shrink-0"
            />
            <span className="text-[11px] text-slate-400 leading-relaxed select-none">
              I consent to send my anonymized financial metrics (risk capacity score, current portfolio allocation, outstanding debt, and remaining goals) directly to OpenAI using my key.
            </span>
          </label>

          {/* Generate Button */}
          <div className="flex justify-start">
            <button
              onClick={onGenerate}
              disabled={aiInsightLoading}
              className="btn-primary w-full sm:w-auto"
            >
              {aiInsightLoading ? (
                <>
                  <span className="animate-spin text-sm">✦</span> Building Portfolio Insights…
                </>
              ) : (
                <>✨ Generate AI Insights</>
              )}
            </button>
          </div>
        </div>
      ) : (
        /* Interactive Chat History */
        <div className="space-y-4">
          <div 
            className="max-h-[500px] overflow-y-auto space-y-4 pr-2 scrollbar-thin flex flex-col"
            style={{ scrollbarWidth: 'thin' }}
          >
            {aiChatHistory.map((msg, idx) => {
              // Hide the system prompt and the very first user prompt which contains the raw data summary
              if (msg.role === 'system') return null;
              if (msg.role === 'user' && idx === 0) return null;

              const isAssistant = msg.role === 'assistant';
              return (
                <div
                  key={idx}
                  className={`flex ${isAssistant ? 'justify-start' : 'justify-end'} animate-fade-in-up`}
                >
                  <div
                    className={`max-w-[88%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed whitespace-pre-wrap transition-all duration-300 ${
                      isAssistant
                        ? 'bg-slate-900/60 border border-slate-800/80 text-slate-100 rounded-tl-none'
                        : 'bg-indigo-600/90 text-white rounded-tr-none shadow-md shadow-indigo-950/20'
                    }`}
                    style={isAssistant ? {
                      background: 'rgba(15, 23, 42, 0.45)',
                      border: '1px solid rgba(139, 92, 246, 0.08)',
                      boxShadow: '0 4px 16px rgba(0,0,0,0.15)',
                    } : undefined}
                  >
                    <div className="font-extrabold uppercase text-[9px] tracking-wider mb-1.5 opacity-65 flex items-center gap-1.5">
                      <span>{isAssistant ? '🤖 NiveshIQ Advisor' : '👤 You'}</span>
                    </div>
                    <div className="prose prose-invert max-w-none text-slate-300">
                      {msg.content}
                    </div>
                  </div>
                </div>
              );
            })}

            {/* AI Loading indicator */}
            {aiInsightLoading && (
              <div className="flex justify-start animate-fade-in-up">
                <div 
                  className="rounded-2xl rounded-tl-none p-4 text-xs sm:text-sm flex items-center gap-3 text-indigo-300"
                  style={{ background: 'rgba(15, 23, 42, 0.45)', border: '1px solid rgba(139, 92, 246, 0.08)' }}
                >
                  <span className="flex gap-1">
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </span>
                  <span className="font-semibold tracking-wide text-[10px] uppercase text-indigo-400/80">Analyzing financial strategy...</span>
                </div>
              </div>
            )}
            
            <div ref={chatBottomRef} />
          </div>

          {/* Follow-up Interactive Input Bar */}
          <div 
            className="flex items-center gap-2 pt-4 border-t border-violet-500/10"
          >
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSend();
              }}
              placeholder="Ask a follow-up question (e.g. 'tell me more about tax harvesting')..."
              className="input-field text-xs flex-1"
              disabled={aiInsightLoading}
            />
            <button
              onClick={handleSend}
              disabled={aiInsightLoading || !chatInput.trim()}
              className="btn-primary py-3 px-5 shrink-0"
              style={{
                borderRadius: '12px',
                height: '42px',
              }}
            >
              Send ➔
            </button>
          </div>
        </div>
      )}

      {/* Error Message */}
      {aiInsightError && (
        <div 
          className="p-4 rounded-xl text-xs flex items-start gap-2.5"
          style={{ 
            background: 'rgba(239, 68, 68, 0.05)', 
            border: '1px solid rgba(239, 68, 68, 0.2)', 
            color: '#f87171' 
          }}
        >
          <span className="text-sm">⚠️</span>
          <div>
            <strong className="font-bold block mb-0.5">Session Error</strong>
            <span>{aiInsightError}</span>
          </div>
        </div>
      )}
    </div>
  );
};
