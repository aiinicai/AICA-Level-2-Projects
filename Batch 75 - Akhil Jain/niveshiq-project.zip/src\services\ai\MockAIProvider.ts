import { AIProvider } from './AIProvider';
import { AppState, DerivedFinancials } from '../../models/types';
import { LEVEL_NAMES } from '../../data/constants';

export class MockAIProvider implements AIProvider {
  name = 'Mock AI (Offline Demo)';

  async generateInsights(state: AppState, D: DerivedFinancials): Promise<string> {
    await new Promise((resolve) => setTimeout(resolve, 1200)); // Simulate API delay

    const capName = LEVEL_NAMES[D.capLevel];
    const appName = LEVEL_NAMES[D.appLevel];
    const equityPct = D.alloc.equityPct.toFixed(0);
    const targetEquity = D.selectedStrategyObj.equity;
    const efMonths = D.cap.efMonths.toFixed(1);
    const horizon = D.cap.horizon;
    const strategy = D.selectedStrategyObj.label;

    // Tailor equity sub-category advice to risk level
    const equitySubAdvice =
      D.capLevel <= 2
        ? 'focus predominantly on large-cap index funds and multi-asset funds — they provide equity growth with lower volatility, suitable for your Conservative capacity'
        : D.capLevel === 3
        ? 'consider a core-satellite approach: ~60% large-cap/flexi-cap as your core, and ~40% mid-cap for incremental growth over your horizon'
        : 'a diversified equity mix of large-cap (anchor), mid-cap (growth engine), and a small satellite in small-cap (5–10%) can maximize long-term compounding, given your higher risk capacity';

    const globalAdvice =
      D.appLevel >= 3
        ? 'with Indian equity concentrating your returns in one economy, allocating 5–10% of your equity sleeve to global index funds (e.g., US S&P 500 or NASDAQ FoF) provides currency diversification and exposure to global tech growth'
        : 'at your current risk appetite, domestic large-cap and debt instruments are a priority — global equity can be explored after your core Indian portfolio is well-established';

    const taxAdvice =
      Number(D.alloc.total) > 500000
        ? 'with a meaningful portfolio, LTCG harvesting (realizing ₹1.25 lakh annual equity LTCG tax-free each year) is a simple optimization. Also consider NPS Tier-1 for an additional ₹50,000 deduction under 80CCD(1B) on top of your 80C limit'
        : 'ELSS (Equity Linked Savings Scheme) serves double duty — equity growth + 80C deduction — making it an efficient starting point before exploring broader mutual fund categories';

    return `### 🤖 NiveshIQ AI — 5 Deeper Advisor Insights  *(Demo Mode)*

---

**1. Equity Sub-Category Strategy**
Given your ${appName} appetite and ${capName} capacity with a ${horizon}-year horizon, ${equitySubAdvice}. Avoid chasing thematic or sectoral funds early — build your broad equity base first. *(Illustrative — consult a SEBI-registered advisor before acting.)*

---

**2. Global Diversification Angle**
Your current allocation (${equityPct}% equity, targeting ${targetEquity}%) appears India-only. ${globalAdvice}. REITs and InvITs are also worth exploring as a 5% allocation for real-estate-like income without property ownership, especially for ${strategy} strategy investors. *(Illustrative — consult a SEBI-registered advisor before acting.)*

---

**3. Tax Efficiency Levers**
${taxAdvice}. For debt exposure, prefer debt mutual funds (if held > 3 years, taxed at slab rate now — but still more liquid than FDs) or target-maturity bond funds that match your goal timelines, reducing reinvestment risk. *(Tax rules change — verify with a tax advisor.)*

---

**4. Goal-Specific Instrument Strategy**
For long-horizon goals (${horizon}+ years), an aggressive SIP-heavy approach in equity makes sense — the math of compounding rewards early, sustained investment. For any goal within 3 years, shift that specific corpus to liquid funds or short-duration debt funds now — do NOT let volatility delay your plan. If you have a child education goal 10+ years out, consider a dedicated SIP in flexi-cap or aggressive hybrid fund; begin shifting to debt 2–3 years before the goal date. *(Illustrative — returns are not guaranteed.)*

---

**5. Sequence of Actions — The Wealth-Building Order**
The most common mistake of ${appName}-appetite investors: starting mid-cap or small-cap SIPs before the emergency fund is complete. A 30–40% market correction will tempt you to pause or redeem those SIPs at a loss, permanently damaging compounding. The correct sequence: (1) Emergency fund → (2) High-interest debt payoff → (3) Core equity SIPs → (4) Satellite/thematic exposure. With your current emergency coverage of ${efMonths} months, step 1 is your gating priority before expanding into higher-volatility categories.`;
  }

  async generateChatResponse(state: AppState, messages: { role: 'user' | 'assistant' | 'system'; content: string }[]): Promise<string> {
    await new Promise((resolve) => setTimeout(resolve, 1000)); // Simulate delay
    const lastUserMessage = [...messages].reverse().find(m => m.role === 'user')?.content || '';
    
    // Check key phrases in user message to give responsive mock replies
    const msg = lastUserMessage.toLowerCase();
    if (msg.includes('small cap') || msg.includes('mid cap') || msg.includes('smallcap') || msg.includes('midcap')) {
      return `For Small-Cap and Mid-Cap equity categories, here are the recommendations:
1. **Mid-Caps:** Act as the growth engine. Focus on quality mid-cap mutual funds with a 5-7 year horizon.
2. **Small-Caps:** Treat as satellite allocations (max 10% of equity). They have high volatility but offer strong compounding potential over 10+ years.
3. **Large-Caps/Flexi-Caps:** Keep 60-70% of your equity sleeve in Large-Cap or Flexi-Cap funds for stability.`;
    }
    if (msg.includes('tax') || msg.includes('harvest') || msg.includes('elss') || msg.includes('nps')) {
      return `Here are specific tax optimization strategies:
- **LTCG Harvesting:** Realize up to ₹1.25 lakh of equity long-term capital gains tax-free each financial year, then immediately reinvest to step up your acquisition cost base.
- **NPS (Section 80CCD(1B)):** Dedicate ₹50,000 extra to National Pension System for direct deduction beyond the ₹1.5L limit under Section 80C.
- **ELSS:** Excellent for lock-in discipline (3 years) while satisfying Section 80C requirements.`;
    }
    if (msg.includes('global') || msg.includes('international') || msg.includes('us') || msg.includes('s&p') || msg.includes('nasdaq')) {
      return `Geographic diversification hedges country-specific risk. Consider allocating 10% of your equity component to:
1. **US S&P 500 Index Funds / Nasdaq 100 ETFs:** Invest via Indian Fund-of-Funds (FoF).
2. **Global Active Funds:** Diversify across US, Europe, and Asia.
*Note: Debt-like taxation applies to international funds in India, so keep horizons long (>3-5 years).*`;
    }
    if (msg.includes('emergency') || msg.includes('safe') || msg.includes('buffer')) {
      return `Maintain emergency reserves only in liquid instruments (liquid funds, high-yield savings, sweep-in FDs). Never put emergency reserves in equity, as a market drop could force you to liquidate at a loss in a crisis. Your current buffer covers ${state.profile.emergencyFund ? 'a portion' : '0'} of your monthly needs; prioritize filling this to 6 months of expenses.`;
    }
    return `Excellent question. Regarding your profile, remember to keep your SIPs structured, maintain your target asset allocation (rebalancing when categories drift by >5%), and increase equity exposure systematically. Let me know if you would like me to detail lock-in periods, rebalancing logic, or specific instrument types!`;
  }
}

