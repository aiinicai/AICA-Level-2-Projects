import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  subValue?: string;
  tooltip?: string;
  badge?: {
    text: string;
    variant: 'demo' | 'blue' | 'green' | 'amber' | 'red';
  };
  highlightColor?: string;
  className?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({
  label,
  value,
  subValue,
  tooltip,
  badge,
  highlightColor,
  className = '',
}) => {
  const badgeClasses = {
    demo: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    blue: 'bg-blue-500/10 text-blue-400 border-blue-500/20',
    green: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    amber: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    red: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
  };

  return (
    <div className={`bg-slate-900/60 border border-slate-800/80 rounded-2xl p-5 backdrop-blur-sm shadow-xl flex flex-col justify-between ${className}`}>
      <div>
        <div className="flex items-center justify-between gap-2 mb-2">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            {label}
            {tooltip && (
              <span className="cursor-help text-slate-500 hover:text-slate-300" title={tooltip}>
                ⓘ
              </span>
            )}
          </span>
          {badge && (
            <span className={`px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide border rounded-full ${badgeClasses[badge.variant]}`}>
              {badge.text}
            </span>
          )}
        </div>

        <div
          className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white"
          style={{ color: highlightColor || undefined }}
        >
          {value}
        </div>
      </div>

      {subValue && (
        <div className="mt-2 text-xs font-medium text-slate-400 border-t border-slate-800/60 pt-2">
          {subValue}
        </div>
      )}
    </div>
  );
};
