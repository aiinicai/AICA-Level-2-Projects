export type RiskLevel = 1 | 2 | 3 | 4 | 5;

export type IncomeStability = 'Very Stable' | 'Stable' | 'Variable' | 'Highly Variable';

export type GoalType = 'Retirement' | 'Child Education' | 'Home Purchase' | 'Other';

export interface FinancialGoal {
  id: number;
  type: GoalType;
  name: string;
  targetAmount: number;
  yearsRemaining: number;
  currentMonthlyContribution: number;
  sample?: boolean;
}

export interface Profile {
  age: number | '';
  maritalStatus: 'Single' | 'Married' | 'Divorced' | 'Widowed';
  dependents: number;
  retirementAge: number;
  annualIncome: number | '';
  monthlyExpenses: number | '';
  monthlyEMI: number | '';
  incomeStability: IncomeStability;
  emergencyFund: number | '';
  outstandingLoans: number | '';
  goals: FinancialGoal[];
}

export interface Portfolio {
  mode: 'import' | 'manual';
  stocks: number;
  equityMF: number;
  debtMF: number;
  fdRd: number;
  epfPpf: number;
  gold: number;
  nps: number;
  bonds: number;
  cash: number;
  other: number;
  imported: boolean;
  brokerName: string;
}

export interface StrategyAllocation {
  key: string;
  label: string;
  level: RiskLevel;
  equity: number;
  debt: number;
  gold: number;
  liquid: number;
}

export interface ReturnAssumptions {
  equity: number;
  debt: number;
  gold: number;
  liquid: number;
}

export interface AISettings {
  endpoint: string;
  apiKey: string;
  model: string;
}

export interface RiskCapacityResult {
  score: number;
  efScore: number;
  emiScore: number;
  dtiScore: number;
  stabilityScore: number;
  depScore: number;
  horizonScore: number;
  assetScore: number;
  penalty: number;
  efMonths: number;
  emiRatio: number;
  dtiRatio: number;
  horizon: number;
  assetRatio: number;
}

export interface RiskAppetiteResult {
  score: number;
  level: RiskLevel;
  answered: number;
}

export interface PortfolioAllocation {
  equity: number;
  debt: number;
  gold: number;
  liquid: number;
  total: number;
  equityPct: number;
  debtPct: number;
  goldPct: number;
  liquidPct: number;
}

export interface ActionItem {
  title: string;
  priority: 'High' | 'Medium' | 'Low';
  curLabel: string;
  curVal: string;
  tgtLabel: string;
  tgtVal: string;
  reason: string;
  insights?: string[];
}

export interface DerivedFinancials {
  cap: RiskCapacityResult;
  capLevel: RiskLevel;
  appetite: RiskAppetiteResult;
  appLevel: RiskLevel;
  recLevelCont: number;
  recLabel: string;
  gap: number;
  alloc: PortfolioAllocation;
  recAlloc: { equity: number; debt: number; gold: number; liquid: number };
  selectedKey: string;
  selectedStrategyObj: StrategyAllocation;
  selectedLevel: RiskLevel;
  riskAlert: boolean;
  reasons: string[];
  blendedReturnPct: number;
  actionPlan: ActionItem[];
}

export interface AppState {
  screen: number;
  profile: Profile;
  portfolio: Portfolio;
  newGoal: {
    type: GoalType;
    name: string;
    targetAmount: number | '';
    yearsRemaining: number | '';
    currentMonthlyContribution: number | '';
  };
  goalIdCounter: number;
  appetiteAnswers: (number | null)[];
  selectedStrategy: string | null;
  strategyOverridden: boolean;
  riskAcknowledged: boolean;
  returnAssumptions: ReturnAssumptions;
  aiSettings: AISettings;
  aiConsent: boolean;
  aiInsightText: string;
  aiChatHistory: { role: 'user' | 'assistant' | 'system'; content: string }[];
  aiInsightLoading: boolean;
  aiInsightError: string;
  formError: string;
}
