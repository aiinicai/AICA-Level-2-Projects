import React, { useState } from 'react';
import { AppState, DerivedFinancials, AISettings } from '../models/types';
import { LEARN_CATS, FD_RATES } from '../data/constants';
import { calculateFDMaturity } from '../services/mockBankService';
import { getMockPMSProducts } from '../services/mockPMSService';
import { AIInsightPanel } from '../components/AIInsightPanel';
import { Disclaimer } from '../components/Disclaimer';
import { fmtINR } from '../engines/actionPlanEngine';

interface ExploreScreenProps {
  state: AppState;
  financials: DerivedFinancials;
  onUpdateAISettings: (key: keyof AISettings, val: string) => void;
  onUpdateAIConsent: (consent: boolean) => void;
  onGenerateAIInsights: () => void;
  onSendAIChatMessage: (message: string) => void;
  onClearAIKey: () => void;
  onNavigate: (screen: number) => void;
}

export const ExploreScreen: React.FC<ExploreScreenProps> = ({
  state,
  financials,
  onUpdateAISettings,
  onUpdateAIConsent,
  onGenerateAIInsights,
  onSendAIChatMessage,
  onClearAIKey,
  onNavigate,
}) => {
  const [fdPrincipal, setFdPrincipal] = useState<number>(100000);
  const [fdRate, setFdRate] = useState<number>(7);
  const [fdYears, setFdYears] = useState<number>(3);
  const [fdResult, setFdResult] = useState<{ maturityValue: number; interestEarned: number } | null>(null);

  const pmsProducts = getMockPMSProducts();
  const rebalance =
    financials.alloc.total > 0
      ? ((financials.alloc.equityPct - financials.selectedStrategyObj.equity) / 100) * financials.alloc.total
      : 0;

  const handleCalcFD = () => {
    const res = calculateFDMaturity(fdPrincipal, fdRate, fdYears);
    setFdResult(res);
  };

  return (
    <div className="space-y-10 max-w-5xl mx-auto animate-fade-in-up">
      <div>
        <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-gradient">
          Explore Investment Options
        </h1>
        <p className="text-sm text-slate-500 mt-2">
          Learn the basics from official investor education bodies, and test mock implementations.
        </p>
      </div>

      {/* Section A: Learn */}
      <div className="space-y-4">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-bold text-white tracking-tight">A. Learn Before You Invest</h2>
          <div className="flex-1 h-px" style={{ background: 'rgba(255,255,255,0.05)' }} />
        </div>
        <p className="text-xs text-slate-500">
          Official investor education resources from SEBI, AMFI, and PFRDA.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {LEARN_CATS.map((c) => (
            <div
              key={c.name}
              className="glass-card p-5 flex flex-col justify-between space-y-4 card-hover"
            >
              <div className="space-y-2">
                <h3 className="font-bold text-white text-base">{c.name}</h3>
                <p className="text-xs text-slate-500 leading-relaxed">{c.desc}</p>
              </div>
              <a href={c.url} target="_blank" rel="noopener noreferrer">
                <button
                  className="px-4 py-2 rounded-xl text-xs font-semibold transition-all hover:scale-[1.02]"
                  style={{ background: 'rgba(99,102,241,0.1)', color: '#818cf8', border: '1px solid rgba(99,102,241,0.2)' }}
                >
                  Learn More ↗
                </button>
              </a>
            </div>
          ))}
        </div>
      </div>

      {/* Section B: Mock Implementations */}
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-bold text-white tracking-tight">B. Mock Implementation Integrations</h2>
          <div className="flex-1 h-px" style={{ background: 'rgba(255,255,255,0.05)' }} />
        </div>

        {/* FD Comparison */}
        <div className="section-card">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>🏦</span> Compare FD Rates
            </h3>
            <span className="px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider rounded-full"
              style={{ background: 'rgba(251,191,36,0.1)', color: '#fbbf24', border: '1px solid rgba(251,191,36,0.2)' }}>
              Demo Data
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead>
                <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}
                  className="text-slate-500 font-semibold uppercase tracking-wider">
                  <th className="py-2.5 px-3">Institution</th>
                  <th className="py-2.5 px-3 text-right">1 Year</th>
                  <th className="py-2.5 px-3 text-right">2 Year</th>
                  <th className="py-2.5 px-3 text-right">3 Year</th>
                </tr>
              </thead>
              <tbody>
                {FD_RATES.map((r, i) => (
                  <tr key={r.bank}
                    className="text-slate-300 font-medium"
                    style={{ borderBottom: i < FD_RATES.length - 1 ? '1px solid rgba(255,255,255,0.04)' : 'none' }}>
                    <td className="py-2.5 px-3 font-bold text-white">{r.bank}</td>
                    <td className="py-2.5 px-3 text-right">{r.y1}</td>
                    <td className="py-2.5 px-3 text-right">{r.y2}</td>
                    <td className="py-2.5 px-3 text-right">{r.y3}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* FD Calculator */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4"
            style={{ borderTop: '1px solid rgba(255,255,255,0.06)' }}>
            <div>
              <label className="field-label">Principal (₹)</label>
              <input type="number" value={fdPrincipal}
                onChange={(e) => setFdPrincipal(parseFloat(e.target.value) || 0)}
                className="input-field text-xs" />
            </div>
            <div>
              <label className="field-label">Rate (% p.a.)</label>
              <input type="number" step="0.1" value={fdRate}
                onChange={(e) => setFdRate(parseFloat(e.target.value) || 0)}
                className="input-field text-xs" />
            </div>
            <div>
              <label className="field-label">Years</label>
              <input type="number" value={fdYears}
                onChange={(e) => setFdYears(parseFloat(e.target.value) || 0)}
                className="input-field text-xs" />
            </div>
          </div>

          <button onClick={handleCalcFD}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white transition-all hover:scale-[1.02]"
            style={{ background: 'rgba(99,102,241,0.15)', border: '1px solid rgba(99,102,241,0.25)' }}>
            Calculate Maturity (Illustrative)
          </button>

          {fdResult && (
            <div className="p-4 rounded-xl space-y-1.5"
              style={{ background: 'rgba(2,6,23,0.7)', border: '1px solid rgba(255,255,255,0.07)' }}>
              <div className="text-xs text-slate-500">Maturity Value</div>
              <div className="text-xl font-extrabold text-white">{fmtINR(fdResult.maturityValue)}</div>
              <div className="text-xs text-slate-500">
                Interest Earned: <strong style={{ color: '#34d399' }}>{fmtINR(fdResult.interestEarned)}</strong>
              </div>
            </div>
          )}
        </div>

        {/* Broker Status */}
        <div className="section-card">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>📈</span> Broker Portfolio Status
            </h3>
            {state.portfolio.imported && (
              <span className="px-2.5 py-1 text-[9px] font-extrabold uppercase rounded-full"
                style={{ background: 'rgba(16,185,129,0.1)', color: '#34d399', border: '1px solid rgba(16,185,129,0.2)' }}>
                {state.portfolio.brokerName} Connected
              </span>
            )}
          </div>

          {state.portfolio.imported ? (
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl text-xs"
              style={{ background: 'rgba(2,6,23,0.7)', border: '1px solid rgba(255,255,255,0.06)' }}>
              {[
                { label: 'Portfolio Value', val: fmtINR(financials.alloc.total), color: '#fff' },
                { label: 'Current Equity', val: `${financials.alloc.equityPct.toFixed(0)}%`, color: '#fff' },
                { label: 'Target Equity', val: `${financials.selectedStrategyObj.equity}%`, color: '#818cf8' },
                { label: 'Potential Rebalance', val: fmtINR(Math.abs(rebalance)), color: '#fbbf24' },
              ].map((item) => (
                <div key={item.label}>
                  <span className="text-slate-500 block mb-1 font-semibold">{item.label}</span>
                  <strong className="text-sm font-bold" style={{ color: item.color }}>{item.val}</strong>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-xs text-slate-500">
              No demo portfolio connected yet.{' '}
              <button onClick={() => onNavigate(2)} className="font-bold hover:underline" style={{ color: '#818cf8' }}>
                Go to Portfolio Screen
              </button>
            </div>
          )}
        </div>

        {/* PMS */}
        <div className="section-card">
          <div className="flex items-center justify-between pb-3"
            style={{ borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <span>🏢</span> PMS (Portfolio Management Services)
            </h3>
            <span className="px-2 py-0.5 text-[9px] font-bold uppercase rounded-full"
              style={{ background: 'rgba(255,255,255,0.05)', color: '#64748b', border: '1px solid rgba(255,255,255,0.07)' }}>
              Demo / Educational
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            {pmsProducts.map((pms) => (
              <div key={pms.name} className="p-4 rounded-xl space-y-2 card-hover"
                style={{ background: 'rgba(2,6,23,0.7)', border: '1px solid rgba(255,255,255,0.06)' }}>
                <h4 className="font-bold text-white text-sm">{pms.name}</h4>
                <div className="text-xs text-slate-500 space-y-1">
                  <div>Risk Level: <strong className="text-slate-300">{pms.riskLevel}</strong></div>
                  <div>Allocation: <span className="text-slate-400">{pms.indicativeAllocation}</span></div>
                  <div>Horizon: <span className="text-slate-400">{pms.horizon}</span></div>
                  <div>Fee: <span className="text-slate-600 text-[10px]">{pms.feeStructure}</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Insight Panel */}
        <AIInsightPanel
          aiSettings={state.aiSettings}
          aiConsent={state.aiConsent}
          aiChatHistory={state.aiChatHistory || []}
          aiInsightLoading={state.aiInsightLoading}
          aiInsightError={state.aiInsightError}
          onUpdateSettings={onUpdateAISettings}
          onUpdateConsent={onUpdateAIConsent}
          onGenerate={onGenerateAIInsights}
          onSendChatMessage={onSendAIChatMessage}
          onClearKey={onClearAIKey}
        />
      </div>

      {/* Bottom Nav */}
      <div className="flex justify-between pt-2">
        <button onClick={() => onNavigate(5)} className="btn-secondary">← Back to Action Plan</button>
        <button onClick={() => onNavigate(1)} className="btn-primary"
          style={{ background: 'linear-gradient(135deg, #4f46e5, #7c3aed)' }}>
          Restart Journey ↺
        </button>
      </div>

      <Disclaimer />
    </div>
  );
};
