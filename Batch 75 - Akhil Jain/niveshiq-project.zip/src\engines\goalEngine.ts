/**
 * Future value of an ongoing monthly SIP at monthly rate over n months (ordinary annuity)
 */
export function futureValueOfSIP(monthlyAmount: number, annualRatePct: number, months: number): number {
  const r = annualRatePct / 100 / 12;
  if (months <= 0) return 0;
  if (r === 0) return monthlyAmount * months;
  return monthlyAmount * ((Math.pow(1 + r, months) - 1) / r);
}

/**
 * Required monthly SIP to reach a target future value
 */
export function requiredSIP(targetAmount: number, annualRatePct: number, months: number): number {
  const r = annualRatePct / 100 / 12;
  if (months <= 0) return targetAmount;
  if (r === 0) return targetAmount / months;
  return (targetAmount * r) / (Math.pow(1 + r, months) - 1);
}
