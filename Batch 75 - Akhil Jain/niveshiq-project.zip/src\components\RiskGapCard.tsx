import React from 'react';

interface RiskGapCardProps {
  gap: number;
  reasons: string[];
}

export const RiskGapCard: React.FC<RiskGapCardProps> = ({ gap, reasons }) => {
  const isHigher = gap > 0;
  const isLower = gap < 0;

  const gapColor = isHigher
    ? 'text-amber-400'
    : isLower
    ? 'text-blue-400'
    : 'text-emerald-400';

  const gapMsg = isHigher
    ? 'Your preferred risk level is higher than the level your current financial position comfortably supports.'
    : isLower
    ? "Your financial position could comfortably support a bit more investment risk than you're currently choosing — that's completely fine, comfort matters too."
    : 'Your comfort with risk and your financial ability to take risk are well aligned.';

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Risk Gap Diagnostic (Appetite − Capacity)
          </span>
          <div className={`text-3xl font-black mt-1 tracking-tight ${gapColor}`}>
            {isHigher ? `+${gap}` : gap} level{Math.abs(gap) === 1 ? '' : 's'}
          </div>
        </div>
        <div className="px-3 py-1.5 rounded-xl bg-slate-800/60 border border-slate-700/60 text-xs font-semibold text-slate-300">
          {isHigher ? '⚠️ Risk Exposure Alert' : isLower ? '🛡️ Conservative Comfort' : '✅ Balanced Alignment'}
        </div>
      </div>

      <div className="p-4 rounded-xl bg-slate-800/40 border border-slate-700/40 text-sm text-slate-200 leading-relaxed">
        {gapMsg}
      </div>

      {reasons.length > 0 && (
        <div className="space-y-2 pt-2">
          <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400">
            Key Capacity Drivers
          </h4>
          <ul className="space-y-1.5 text-xs text-slate-300">
            {reasons.map((r, i) => (
              <li key={i} className="flex items-start gap-2">
                <span className="text-amber-400 font-bold">•</span>
                <span>{r}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};
