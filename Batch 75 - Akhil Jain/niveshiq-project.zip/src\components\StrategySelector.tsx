import React from 'react';
import { STRATEGIES } from '../data/constants';

interface StrategySelectorProps {
  selectedKey: string;
  recommendedKey: string;
  onSelect: (key: string) => void;
}

export const StrategySelector: React.FC<StrategySelectorProps> = ({
  selectedKey,
  recommendedKey,
  onSelect,
}) => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {Object.values(STRATEGIES).map((s) => {
        const isSelected = selectedKey === s.key;
        const isRecommended = recommendedKey === s.key;

        return (
          <button
            key={s.key}
            onClick={() => onSelect(s.key)}
            className={`relative text-left p-5 rounded-2xl border transition-all duration-200 focus:outline-none flex flex-col justify-between ${
              isSelected
                ? 'bg-gradient-to-b from-blue-900/40 to-slate-900 border-blue-500 shadow-xl shadow-blue-500/10 ring-2 ring-blue-500/30'
                : 'bg-slate-900/50 border-slate-800 hover:border-slate-700 hover:bg-slate-900/80'
            }`}
          >
            <div>
              <div className="flex items-center justify-between gap-2 mb-2">
                <h3 className="text-lg font-bold text-white tracking-tight">{s.label}</h3>
                {isRecommended && (
                  <span className="px-2 py-0.5 text-[10px] font-extrabold uppercase tracking-wide bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full">
                    Recommended
                  </span>
                )}
              </div>

              <div className="space-y-1 text-xs text-slate-300 font-medium">
                <div>Equity {s.equity}% · Debt {s.debt}%</div>
                <div>Gold {s.gold}% · Liquid {s.liquid}%</div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-xs font-semibold">
              <span className={isSelected ? 'text-blue-400 font-bold' : 'text-slate-400'}>
                {isSelected ? '✓ Active Strategy' : 'Select Strategy'}
              </span>
              <span className="text-slate-400">Level {s.level}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
};
