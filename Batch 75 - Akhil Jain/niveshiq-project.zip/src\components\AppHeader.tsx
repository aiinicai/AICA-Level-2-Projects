import React from 'react';

interface AppHeaderProps {
  currentScreen: number;
  onNavigate: (screen: number) => void;
  onRestart: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({ currentScreen, onNavigate, onRestart }) => {
  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl border-b border-white/[0.06] text-white"
      style={{ background: 'rgba(2, 6, 23, 0.85)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand */}
        <div
          onClick={() => onNavigate(0)}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl flex items-center justify-center font-black text-xl shadow-lg group-hover:scale-105 transition-transform animate-glow-pulse"
            style={{ background: 'linear-gradient(135deg, #4f46e5, #7c3aed)', boxShadow: '0 0 16px rgba(99,102,241,0.4)' }}>
            N
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-lg tracking-tight text-gradient">NiveshIQ</span>
              <span className="px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase rounded-full"
                style={{ background: 'rgba(251,191,36,0.1)', color: '#fbbf24', border: '1px solid rgba(251,191,36,0.2)' }}>
                DEMO / MVP
              </span>
            </div>
            <p className="text-[11px] text-slate-500 font-medium hidden sm:block tracking-wide">
              Life-Centric Wealth Intelligence
            </p>
          </div>
        </div>

        {/* Quick Nav Links */}
        <div className="flex items-center gap-1 sm:gap-1.5">
          {currentScreen !== 0 && (
            <>
              {[['Profile', 1], ['Portfolio', 2], ['Risk', 3]].map(([label, screen]) => (
                <button
                  key={label}
                  onClick={() => onNavigate(screen as number)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all duration-200 ${
                    currentScreen === screen
                      ? 'text-indigo-300'
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                  style={currentScreen === screen ? {
                    background: 'rgba(99,102,241,0.15)',
                    border: '1px solid rgba(99,102,241,0.3)'
                  } : { background: 'transparent', border: '1px solid transparent' }}
                >
                  {label}
                </button>
              ))}
            </>
          )}

          <button
            onClick={onRestart}
            className="ml-2 px-3 py-1.5 text-xs font-semibold rounded-lg text-slate-400 hover:text-white transition-all flex items-center gap-1.5"
            style={{ background: 'rgba(30,41,59,0.5)', border: '1px solid rgba(255,255,255,0.07)' }}
          >
            <span>↺</span>
            <span className="hidden sm:inline">Restart</span>
          </button>
        </div>
      </div>
    </header>
  );
};
