import React from 'react';
import { LEVEL_COLORS, LEVEL_NAMES } from '../data/constants';
import { RiskLevel } from '../models/types';
import { recommendedLabel } from '../engines/portfolioEngine';

interface RiskGaugeProps {
  appetiteLevel: RiskLevel;
  capacityLevel: RiskLevel;
  recommendedLevel: number;
}

export const RiskGauge: React.FC<RiskGaugeProps> = ({
  appetiteLevel,
  capacityLevel,
  recommendedLevel,
}) => {
  const getPct = (val: number) => Math.max(0, Math.min(100, ((val - 1) / 4) * 100));

  const appetitePct = getPct(appetiteLevel);
  const capacityPct = getPct(capacityLevel);
  const recommendedPct = getPct(recommendedLevel);

  const rows = [
    {
      label: 'YOU WANT TO TAKE (Appetite)',
      levelVal: appetiteLevel,
      pct: appetitePct,
      color: LEVEL_COLORS[appetiteLevel],
      name: LEVEL_NAMES[appetiteLevel],
    },
    {
      label: 'YOU CAN SUPPORT (Capacity)',
      levelVal: capacityLevel,
      pct: capacityPct,
      color: LEVEL_COLORS[capacityLevel],
      name: LEVEL_NAMES[capacityLevel],
    },
    {
      label: 'RECOMMENDED ZONE',
      levelVal: recommendedLevel,
      pct: recommendedPct,
      color: LEVEL_COLORS[Math.round(recommendedLevel) as RiskLevel],
      name: recommendedLabel(recommendedLevel),
      isPrimary: true,
    },
  ];

  return (
    <div className="space-y-6">
      {rows.map((r) => (
        <div key={r.label} className="bg-slate-900/40 p-4 rounded-xl border border-slate-800/80">
          <div className="flex justify-between items-center mb-2">
            <span className={`text-xs font-bold uppercase tracking-wider ${r.isPrimary ? 'text-blue-400' : 'text-slate-400'}`}>
              {r.label}
            </span>
            <span className="text-sm font-extrabold" style={{ color: r.color }}>
              {r.name}
            </span>
          </div>

          <div className="relative h-3 bg-slate-800 rounded-full overflow-visible">
            {/* Gradient background track */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-slate-600 via-blue-500 to-amber-500 opacity-40" />

            {/* Marker pin */}
            <div
              className={`absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-5 h-5 rounded-full border-2 border-white shadow-lg transition-all duration-300 ${
                r.isPrimary ? 'ring-4 ring-blue-500/40 scale-125' : ''
              }`}
              style={{
                left: `${r.pct}%`,
                backgroundColor: r.color,
              }}
            />
          </div>
        </div>
      ))}

      {/* Spectrum axis labels */}
      <div className="flex justify-between text-[11px] font-semibold text-slate-400 px-1 pt-1">
        <span>Conservative</span>
        <span>Moderate</span>
        <span>Balanced</span>
        <span>Growth</span>
        <span>Aggressive</span>
      </div>
    </div>
  );
};
