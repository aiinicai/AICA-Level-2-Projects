import React from 'react';
import { STEP_LABELS } from '../data/constants';

interface ProgressStepperProps {
  currentStep: number; // 1 to 6
  onStepClick: (step: number) => void;
}

export const ProgressStepper: React.FC<ProgressStepperProps> = ({ currentStep, onStepClick }) => {
  const steps = STEP_LABELS;
  const progressPct = ((currentStep - 1) / (steps.length - 1)) * 100;

  return (
    <div className="w-full my-6 px-2 sm:px-4 animate-fade-in-up">
      <div className="relative flex items-center justify-between">
        {/* Background track */}
        <div className="absolute top-5 left-0 w-full h-0.5 rounded-full z-0"
          style={{ background: 'rgba(255,255,255,0.06)' }} />

        {/* Filled progress */}
        <div
          className="absolute top-5 left-0 h-0.5 rounded-full z-0 transition-all duration-500"
          style={{
            width: `${progressPct}%`,
            background: 'linear-gradient(90deg, #4f46e5, #7c3aed)',
            boxShadow: '0 0 8px rgba(99,102,241,0.5)',
          }}
        />

        {steps.map((label, index) => {
          const stepNum = index + 1;
          const isActive = stepNum === currentStep;
          const isDone = stepNum < currentStep;

          return (
            <button
              key={label}
              onClick={() => onStepClick(stepNum)}
              className="relative z-10 flex flex-col items-center group focus:outline-none"
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-xs transition-all duration-300 ${
                  isActive ? 'animate-glow-pulse scale-110' : 'hover:scale-105'
                }`}
                style={
                  isActive
                    ? {
                        background: 'linear-gradient(135deg, #4f46e5, #7c3aed)',
                        boxShadow: '0 0 20px rgba(99,102,241,0.6)',
                        color: '#fff',
                      }
                    : isDone
                    ? {
                        background: 'linear-gradient(135deg, #059669, #10b981)',
                        boxShadow: '0 0 12px rgba(16,185,129,0.3)',
                        color: '#fff',
                      }
                    : {
                        background: 'rgba(30,41,59,0.8)',
                        border: '1px solid rgba(255,255,255,0.07)',
                        color: 'rgba(148,163,184,0.7)',
                      }
                }
              >
                {isDone ? '✓' : stepNum}
              </div>
              <span
                className={`mt-2 text-[10px] sm:text-[11px] font-semibold tracking-wide transition-colors ${
                  isActive
                    ? 'text-indigo-400'
                    : isDone
                    ? 'text-emerald-500'
                    : 'text-slate-600 group-hover:text-slate-400'
                }`}
              >
                {label}
              </span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
