import React from 'react';
import { useAppState } from './hooks/useAppState';
import { AppHeader } from './components/AppHeader';
import { ProgressStepper } from './components/ProgressStepper';
import { WelcomeScreen } from './screens/WelcomeScreen';
import { ProfileScreen } from './screens/ProfileScreen';
import { PortfolioScreen } from './screens/PortfolioScreen';
import { RiskProfileScreen } from './screens/RiskProfileScreen';
import { StrategyScreen } from './screens/StrategyScreen';
import { ActionPlanScreen } from './screens/ActionPlanScreen';
import { ExploreScreen } from './screens/ExploreScreen';

export const App: React.FC = () => {
  const {
    state,
    financials,
    setScreen,
    loadDemoInvestor,
    resetAll,
    updateProfile,
    updatePortfolio,
    importBrokerPortfolio,
    addGoal,
    removeGoal,
    promoteGoal,
    updateAppetiteAnswer,
    selectStrategy,
    useRecommendedStrategy,
    acknowledgeRisk,
    updateReturnAssumption,
    resetReturnAssumptions,
    updateAISettings,
    setAIConsent,
    setAIResult,
    clearAIKey,
    generateAIInsights,
    sendAIChatMessage,
  } = useAppState();

  const renderActiveScreen = () => {
    switch (state.screen) {
      case 0:
        return (
          <WelcomeScreen
            onLoadDemo={loadDemoInvestor}
            onStartFresh={() => setScreen(1)}
          />
        );
      case 1:
        return (
          <ProfileScreen
            state={state}
            onUpdateProfile={updateProfile}
            onAddGoal={addGoal}
            onRemoveGoal={removeGoal}
            onPromoteGoal={promoteGoal}
            onContinue={() => setScreen(2)}
          />
        );
      case 2:
        return (
          <PortfolioScreen
            state={state}
            financials={financials}
            onUpdatePortfolio={updatePortfolio}
            onImportBroker={importBrokerPortfolio}
            onBack={() => setScreen(1)}
            onContinue={() => setScreen(3)}
          />
        );
      case 3:
        return (
          <RiskProfileScreen
            state={state}
            financials={financials}
            onUpdateAppetite={updateAppetiteAnswer}
            onBack={() => setScreen(2)}
            onContinue={() => setScreen(4)}
          />
        );
      case 4:
        return (
          <StrategyScreen
            state={state}
            financials={financials}
            onSelectStrategy={selectStrategy}
            onUseRecommended={useRecommendedStrategy}
            onAcknowledgeRisk={acknowledgeRisk}
            onUpdateReturn={updateReturnAssumption}
            onResetReturns={resetReturnAssumptions}
            onBack={() => setScreen(3)}
            onContinue={() => setScreen(5)}
          />
        );
      case 5:
        return (
          <ActionPlanScreen
            financials={financials}
            onBack={() => setScreen(4)}
            onContinue={() => setScreen(6)}
          />
        );
      case 6:
        return (
          <ExploreScreen
            state={state}
            financials={financials}
            onUpdateAISettings={updateAISettings}
            onUpdateAIConsent={setAIConsent}
            onGenerateAIInsights={generateAIInsights}
            onSendAIChatMessage={sendAIChatMessage}
            onClearAIKey={clearAIKey}
            onNavigate={setScreen}
          />
        );
      default:
        return (
          <WelcomeScreen
            onLoadDemo={loadDemoInvestor}
            onStartFresh={() => setScreen(1)}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-blue-600 selection:text-white pb-12">
      {/* Header */}
      <AppHeader
        currentScreen={state.screen}
        onNavigate={setScreen}
        onRestart={resetAll}
      />

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-4">
        {state.screen > 0 && (
          <ProgressStepper
            currentStep={state.screen}
            onStepClick={setScreen}
          />
        )}

        {renderActiveScreen()}
      </main>
    </div>
  );
};

export default App;
