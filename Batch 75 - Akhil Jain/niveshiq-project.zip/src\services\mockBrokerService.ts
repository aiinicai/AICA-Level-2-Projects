import { Portfolio } from '../models/types';
import { DEMO_PORTFOLIO } from '../data/demoInvestor';

export interface BrokerAdapter {
  name: string;
  importPortfolio(): Promise<Partial<Portfolio>>;
}

export class MockBrokerAdapter implements BrokerAdapter {
  constructor(public name: string) {}

  async importPortfolio(): Promise<Partial<Portfolio>> {
    // Return realistic mock holdings
    return {
      mode: 'import',
      stocks: 450000,
      equityMF: 650000,
      debtMF: 200000,
      fdRd: 300000,
      epfPpf: 250000,
      gold: 150000,
      nps: 100000,
      bonds: 0,
      cash: 150000,
      other: 0,
      imported: true,
      brokerName: this.name,
    };
  }
}

export const mockBrokerAdapters: Record<string, BrokerAdapter> = {
  Zerodha: new MockBrokerAdapter('Zerodha'),
  Groww: new MockBrokerAdapter('Groww'),
  'ICICI Direct': new MockBrokerAdapter('ICICI Direct'),
  'Other Broker': new MockBrokerAdapter('Other Broker'),
};

export async function importPortfolioFromBroker(brokerName: string): Promise<Partial<Portfolio>> {
  const adapter = mockBrokerAdapters[brokerName] || new MockBrokerAdapter(brokerName);
  return adapter.importPortfolio();
}
