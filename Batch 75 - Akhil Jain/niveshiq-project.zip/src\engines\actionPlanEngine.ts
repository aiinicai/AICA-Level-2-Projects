import { ActionItem, AppState, PortfolioAllocation, RiskCapacityResult, StrategyAllocation } from '../models/types';
import { num } from './riskCapacityEngine';
import { futureValueOfSIP, requiredSIP } from './goalEngine';

export function fmtINR(n: any): string {
  const x = Number(n) || 0;
  return '₹' + Math.round(x).toLocaleString('en-IN');
}

export function computeActionPlan(
  state: AppState,
  cap: RiskCapacityResult,
  alloc: PortfolioAllocation,
  selectedAlloc: StrategyAllocation,
  blendedReturnPct: number
): ActionItem[] {
  const profile = state.profile;
  const actions: ActionItem[] = [];

  /* 1. Emergency Fund */
  if (cap.efMonths < 6 && num(profile.monthlyExpenses) > 0) {
    const target = num(profile.monthlyExpenses) * 6;
    const gapAmt = Math.max(target - num(profile.emergencyFund), 0);
    const topUp12 = gapAmt / 12;
    actions.push({
      title: 'Strengthen Your Emergency Fund',
      priority: cap.efMonths < 3 ? 'High' : 'Medium',
      curLabel: 'Current',
      curVal: `${fmtINR(profile.emergencyFund)} (${cap.efMonths.toFixed(1)} months)`,
      tgtLabel: 'Target',
      tgtVal: `${fmtINR(target)} (6 months)`,
      reason: `We recommend strengthening your emergency fund because you currently have approximately ${cap.efMonths.toFixed(1)} months of essential expenses covered — a comfortable safety net typically covers around 6 months.`,
      insights: [
        `Shortfall to target: approximately ${fmtINR(gapAmt)}.`,
        `Saving around ${fmtINR(topUp12)}/month would close this gap in about 12 months.`,
        `Keep this fund in liquid instruments (savings account, liquid fund, sweep-in FD) — not in equity — since it needs to be accessible without loss of value in an emergency.`,
      ],
    });
  }

  /* 2. Equity concentration vs target */
  if (alloc.total > 0) {
    const diff = alloc.equityPct - selectedAlloc.equity;
    if (Math.abs(diff) >= 7) {
      const stressImpact = alloc.equity * 0.2;
      actions.push({
        title: diff > 0 ? 'Reduce Equity Concentration' : 'Consider Increasing Equity Exposure',
        priority: 'Medium',
        curLabel: 'Current Equity',
        curVal: `${alloc.equityPct.toFixed(0)}%`,
        tgtLabel: 'Target Equity',
        tgtVal: `${selectedAlloc.equity}%`,
        reason:
          diff > 0
            ? `Your portfolio currently holds more in equity (${alloc.equityPct.toFixed(0)}%) than your chosen strategy's target (${selectedAlloc.equity}%), which can mean larger temporary swings than intended.`
            : `Your portfolio currently holds less in equity (${alloc.equityPct.toFixed(0)}%) than your chosen strategy's target (${selectedAlloc.equity}%), which may mean lower long-term growth potential than intended.`,
        insights:
          diff > 0
            ? [
                `Illustrative stress-test: a 20% market correction on your current equity holdings (${fmtINR(alloc.equity)}) would mean a temporary paper loss of roughly ${fmtINR(stressImpact)}.`,
                `Approx. ${fmtINR(Math.abs(alloc.equity - (alloc.total * selectedAlloc.equity) / 100))} could be gradually moved from equity into debt/gold/liquid to realign with your target — ideally in tranches, not all at once.`,
                `This is about exposure management, not a signal to exit the market entirely.`,
              ]
            : [
                `Being underweight equity relative to your target may mean relying more heavily on debt/gold returns, which are typically lower over the long term.`,
                `Consider increasing equity exposure gradually (e.g., via staggered SIPs) rather than all at once, to average out entry price.`,
              ],
      });
    }
  }

  /* 3. Goal-based SIP shortfalls */
  const usedReturn = blendedReturnPct;
  (profile.goals || [])
    .filter((g) => !g.sample)
    .forEach((g) => {
      const target = num(g.targetAmount);
      const years = num(g.yearsRemaining);
      if (target <= 0 || years <= 0 || years <= 3) return;
      const months = years * 12;
      const reqSIP = requiredSIP(target, usedReturn, months);
      const current = num(g.currentMonthlyContribution);
      if (reqSIP > current * 1.1) {
        const projectedFV = futureValueOfSIP(current, usedReturn, months);
        const shortfall = Math.max(target - projectedFV, 0);
        actions.push({
          title: `Increase Savings Towards "${g.name}"`,
          priority: reqSIP > current * 1.5 ? 'High' : 'Medium',
          curLabel: 'Current',
          curVal: `${fmtINR(current)}/month`,
          tgtLabel: 'Suggested (illustrative)',
          tgtVal: `~${fmtINR(reqSIP)}/month`,
          reason: `Based on a target of ${fmtINR(target)} in ${years} years, and an illustrative blended return of ~${usedReturn.toFixed(1)}% p.a. (derived from your selected ${selectedAlloc.label} allocation), your current contribution may fall short of this goal.`,
          insights: [
            `At your current pace of ${fmtINR(current)}/month, you're projected to reach approximately ${fmtINR(projectedFV)} by the target date — a shortfall of about ${fmtINR(shortfall)}.`,
            `The ~${usedReturn.toFixed(1)}% assumed return comes from blending your Equity/Debt/Gold/Liquid mix with the return assumptions you set on the Strategy screen — adjust those if you'd like to see this recalculated.`,
            `This is illustrative only — actual returns will vary and are not guaranteed.`,
          ],
        });
      }
    });

  /* 4. Short-term goal protection */
  const shortTerm = (profile.goals || []).filter((g) => !g.sample && num(g.yearsRemaining) > 0 && num(g.yearsRemaining) <= 3);
  if (shortTerm.length > 0) {
    const totalNear = shortTerm.reduce((s, g) => s + num(g.targetAmount), 0);
    actions.push({
      title: 'Protect Your Short-Term Goals',
      priority: 'High',
      curLabel: 'Goals due soon',
      curVal: shortTerm.map((g) => g.name).join(', '),
      tgtLabel: 'Approach',
      tgtVal: 'Keep in low-volatility / liquid instruments',
      reason: 'Money needed within the next 3 years should generally avoid high market-linked volatility, since there is less time to recover from a downturn before the funds are needed.',
      insights: [
        `Combined target for these near-term goals: approximately ${fmtINR(totalNear)}.`,
        `Consider holding this amount in FDs, short-duration debt funds, or liquid funds rather than equity — prioritizing capital protection over growth for this portion.`,
      ],
    });
  }

  /* 5. Debt burden */
  if (cap.dtiRatio > 1 || cap.emiRatio > 0.4) {
    actions.push({
      title: 'Manage High Debt Load',
      priority: cap.emiRatio > 0.5 ? 'High' : 'Medium',
      curLabel: 'EMI Share',
      curVal: `≈ ${(cap.emiRatio * 100).toFixed(0)}% of monthly income`,
      tgtLabel: 'Target',
      tgtVal: 'Below ~40% of income where possible',
      reason: 'A high share of income going towards debt repayment reduces flexibility and increases financial risk if income is disrupted.',
      insights: [
        `Outstanding loans are approximately ${cap.dtiRatio.toFixed(2)}x your annual income.`,
        `Paying down high-interest debt often provides a guaranteed "return" equal to the loan's interest rate — which can exceed what many debt instruments yield, so it's often worth prioritizing over incremental new investing.`,
      ],
    });
  }

  const order: Record<string, number> = { High: 0, Medium: 1, Low: 2 };
  actions.sort((a, b) => order[a.priority] - order[b.priority]);
  return actions;
}
