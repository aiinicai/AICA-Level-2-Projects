import { describe, it, expect } from 'vitest';
import { calcRiskCapacity, levelFromScore } from '../riskCapacityEngine';
import { calcAppetite } from '../riskAppetiteEngine';
import { sumPortfolio, allocationBuckets, interpolateAllocation, nearestStrategyKey, computeBlendedReturn } from '../portfolioEngine';
import { futureValueOfSIP, requiredSIP } from '../goalEngine';
import { computeActionPlan } from '../actionPlanEngine';
import { DEMO_PROFILE, DEMO_PORTFOLIO } from '../../data/demoInvestor';
import { INITIAL_STATE } from '../../hooks/useAppState';
import { STRATEGIES, DEFAULT_RETURNS } from '../../data/constants';

describe('NiveshIQ Financial Engines', () => {
  it('should calculate risk capacity accurately for demo investor', () => {
    const cap = calcRiskCapacity(DEMO_PROFILE, DEMO_PORTFOLIO);
    expect(cap.score).toBeGreaterThan(0);
    expect(cap.score).toBeLessThanOrEqual(100);
    expect(cap.efMonths).toBeCloseTo(250000 / 75000, 1);
    expect(levelFromScore(cap.score)).toBeGreaterThanOrEqual(1);
    expect(levelFromScore(cap.score)).toBeLessThanOrEqual(5);
  });

  it('should calculate risk appetite average score correctly', () => {
    const answers = [5, 5, 5, 5, 5];
    const app = calcAppetite(answers);
    expect(app.score).toBe(5);
    expect(app.level).toBe(5);
    expect(app.answered).toBe(5);
  });

  it('should calculate total portfolio value and allocation percentages', () => {
    const total = sumPortfolio(DEMO_PORTFOLIO);
    expect(total).toBe(2250000);

    const alloc = allocationBuckets(DEMO_PORTFOLIO);
    expect(alloc.total).toBe(2250000);
    expect(alloc.equityPct + alloc.debtPct + alloc.goldPct + alloc.liquidPct).toBeCloseTo(100, 1);
  });

  it('should interpolate strategy allocations continuously', () => {
    const level3_5 = interpolateAllocation(3.5);
    expect(level3_5.equity).toBe(57.5);
    expect(level3_5.debt).toBe(25);
  });

  it('should match nearest strategy key', () => {
    expect(nearestStrategyKey(4.8)).toBe('aggressive');
    expect(nearestStrategyKey(1.2)).toBe('conservative');
  });

  it('should compute blended expected returns', () => {
    const blended = computeBlendedReturn(STRATEGIES['aggressive'], DEFAULT_RETURNS);
    // 80% * 13 + 10% * 7 + 5% * 9 + 5% * 5 = 10.4 + 0.7 + 0.45 + 0.25 = 11.8%
    expect(blended).toBeCloseTo(11.8, 1);
  });

  it('should accurately calculate SIP annuity formulas', () => {
    const months = 120; // 10 years
    const fv = futureValueOfSIP(10000, 12, months);
    expect(fv).toBeGreaterThan(1200000); // Principal is 1.2M, compound return is higher

    const req = requiredSIP(2000000, 12, months);
    expect(req).toBeLessThan(200000);
  });

  it('should generate prioritized action items for demo investor', () => {
    const cap = calcRiskCapacity(DEMO_PROFILE, DEMO_PORTFOLIO);
    const alloc = allocationBuckets(DEMO_PORTFOLIO);
    const actions = computeActionPlan(
      { ...INITIAL_STATE, profile: DEMO_PROFILE, portfolio: DEMO_PORTFOLIO },
      cap,
      alloc,
      STRATEGIES['aggressive'],
      11.8
    );

    expect(actions.length).toBeGreaterThan(0);
    expect(['High', 'Medium', 'Low']).toContain(actions[0].priority);
  });
});
