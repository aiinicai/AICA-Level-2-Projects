"""Vendor details form, quotation form, and the side-by-side quotation comparison window."""
from __future__ import annotations

from datetime import date

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QDialog, QFrame, QHBoxLayout, QLineEdit, QScrollArea, QVBoxLayout, QWidget,
)

from zari.config import EXPENSE_CATEGORIES
from zari.db.repo_vendors import RepositoryError
from zari.logic import quotes as quote_logic
from zari.logic.money import format_aed, format_input
from zari.logic.validation import QUOTE_STATUSES, validate_quote, validate_vendor
from zari.ui import theme
from zari.ui.dialogs import FormDialog, OptionalDateField, confirm, info
from zari.ui.widgets import (
    Badge, Card, clear_layout, icon_button, make_button, make_label, shrinkable,
)

STATUS_COLORS = {"Requested": theme.IVORY_MUTED, "Received": theme.ROSE, "Selected": theme.SUCCESS,
                 "Rejected": theme.DANGER}


def stars(rating: int | None) -> str:
    return "Not rated" if not rating else "★" * rating + "☆" * (5 - rating)


# ---------------------------------------------------------------------------- forms
class VendorDialog(FormDialog):
    def __init__(self, parent, vendor=None, category: str | None = None, name: str = ""):
        super().__init__(parent, "Edit vendor" if vendor else "New vendor", "Vendor directory", width=520)
        self.name = QLineEdit(vendor.name if vendor else name)
        self.category = QComboBox()
        self.category.addItems(EXPENSE_CATEGORIES)
        self.category.setCurrentText(vendor.category if vendor else (category or "Other"))
        self.contact = QLineEdit(vendor.contact_name if vendor else "")
        self.phone = QLineEdit(vendor.phone if vendor else "")
        self.phone.setPlaceholderText("+971 50 123 4567")
        self.email = QLineEdit(vendor.email if vendor else "")
        self.notes = QLineEdit(vendor.notes if vendor else "")
        self.add_field("name", "Vendor name", self.name)
        self.add_field("category", "Main category", self.category, row_with="start")
        self.add_field("contact", "Contact person", self.contact, row_with="end")
        self.add_field("phone", "Phone", self.phone, row_with="start")
        self.add_field("email", "Email", self.email, row_with="end")
        self.add_field("notes", "Notes", self.notes)

    def collect(self) -> dict:
        return validate_vendor(self.name.text(), self.category.currentText(), self.contact.text(),
                               self.phone.text(), self.email.text(), self.notes.text())


class QuoteDialog(FormDialog):
    def __init__(self, parent, repo, event_id: int, quote=None, requirement: str = "", category: str | None = None):
        super().__init__(parent, "Edit quotation" if quote else "Add quotation", "Vendor quotes", width=560)
        self.repo = repo
        self.requirement = QComboBox()
        self.requirement.setEditable(True)
        reqs = sorted({q.requirement for q in repo.list_quotes(event_id)}, key=str.lower)
        self.requirement.addItems(reqs)
        self.requirement.setCurrentText(quote.requirement if quote else requirement)
        self.requirement.lineEdit().setPlaceholderText("What are you buying? e.g. Wedding photography")
        self.category = QComboBox()
        self.category.addItems(EXPENSE_CATEGORIES)
        self.category.setCurrentText(quote.category if quote else (category or "Other"))
        self.vendor = QComboBox()
        self._load_vendors(quote.vendor_id if quote else None)
        new_vendor = make_button("New vendor", icon_name="plus")
        new_vendor.clicked.connect(self._new_vendor)
        vendor_row = QWidget()
        vendor_row.setObjectName("Transparent")
        h = QHBoxLayout(vendor_row)
        h.setContentsMargins(0, 0, 0, 0)
        h.addWidget(self.vendor, 1)
        h.addWidget(new_vendor)
        self.amount = QLineEdit(format_input(quote.amount) if quote else "")
        self.amount.setPlaceholderText("Total price in AED")
        self.deposit = QLineEdit(format_input(quote.deposit) if quote and quote.deposit else "")
        self.deposit.setPlaceholderText("Optional")
        self.valid = OptionalDateField(quote.valid_until if quote else None)
        self.rating = QComboBox()
        self.rating.addItem("Not rated", 0)
        for n in range(1, 6):
            self.rating.addItem(f"{'★' * n}  ({n} of 5)", n)
        self.rating.setCurrentIndex(quote.rating if quote and quote.rating else 0)
        self.status = QComboBox()
        self.status.addItems(QUOTE_STATUSES)
        self.status.setCurrentText(quote.status if quote else "Received")
        self.notes = QLineEdit(quote.notes if quote else "")
        self.notes.setPlaceholderText("What's included, payment terms, your impression...")
        self.add_field("requirement", "Requirement", self.requirement)
        self.add_field("category", "Category", self.category, row_with="start")
        self.add_field("status", "Status", self.status, row_with="end")
        self.add_field("vendor", "Vendor", vendor_row)
        self.add_field("amount", "Quoted price (AED)", self.amount, row_with="start")
        self.add_field("deposit", "Deposit (AED)", self.deposit, row_with="end")
        self.add_field("valid_until", "Quote valid until", self.valid, row_with="start")
        self.add_field("rating", "Your rating", self.rating, row_with="end")
        self.add_field("notes", "Notes", self.notes)
        self._rows["vendor"] = (self.vendor, self._rows["vendor"][1])

    def _load_vendors(self, select_id: int | None) -> None:
        self.vendor.clear()
        for v in self.repo.list_vendors():
            self.vendor.addItem(f"{v.name}  ·  {v.category}", v.id)
        if select_id is not None:
            self.vendor.setCurrentIndex(max(0, self.vendor.findData(select_id)))
        elif self.vendor.count():
            self.vendor.setCurrentIndex(-1)
            self.vendor.setPlaceholderText("Choose a vendor")

    def _new_vendor(self) -> None:
        dlg = VendorDialog(self, category=self.category.currentText())
        if dlg.exec():
            try:
                vid = self.repo.add_vendor(dlg.result_data)
            except RepositoryError as exc:
                info(self, "Could not add vendor", str(exc))
                return
            self._load_vendors(vid)

    def collect(self) -> dict:
        return validate_quote(self.requirement.currentText(), self.category.currentText(),
                              self.vendor.currentData(), self.amount.text(), self.deposit.text(),
                              self.valid.value(), self.rating.currentData(), self.status.currentText(),
                              self.notes.text())


# ---------------------------------------------------------------------------- comparison window
class QuotesDialog(QDialog):
    def __init__(self, parent, ctx, event_id: int):
        super().__init__(parent)
        self.ctx, self.event_id = ctx, event_id
        ev = ctx.repo.get_event(event_id)
        self.setWindowTitle(f"Vendor quotes - {ev.name}")
        self.resize(980, 700)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)   # lets you go full screen
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 18)
        root.setSpacing(10)
        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Compare vendors", "eyebrow"))
        titles.addWidget(make_label(f"Quotations: {ev.name}", "h2"))
        head.addLayout(titles)
        head.addStretch(1)
        add = make_button("Add quotation", "primary", "plus")
        add.clicked.connect(lambda: self._add())
        head.addWidget(add, 0, Qt.AlignmentFlag.AlignBottom)
        root.addLayout(head)
        root.addWidget(make_label(
            "Zari highlights the lowest price and the top-rated quote and suggests a best value (lowest price per "
            "rating point). You always choose: nothing is selected automatically.", "small", wrap=True))
        self.scroller = QScrollArea()
        self.scroller.setWidgetResizable(True)
        self.scroller.setFrameShape(QFrame.Shape.NoFrame)
        self.body = QWidget()
        self.body.setObjectName("Transparent")
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(0, 0, 8, 0)
        self.body_layout.setSpacing(14)
        self.scroller.setWidget(self.body)
        root.addWidget(self.scroller, 1)
        ctx.changed.connect(self.refresh)
        self.refresh()

    def done(self, result: int) -> None:
        try:
            self.ctx.changed.disconnect(self.refresh)
        except (RuntimeError, TypeError):
            pass
        super().done(result)

    # ---- actions --------------------------------------------------------------------
    def _add(self, requirement: str = "", category: str | None = None) -> None:
        if not self.ctx.repo.list_vendors():
            info(self, "Add a vendor first", "Quotes belong to a vendor. You will be asked to add one now.")
            dlg = VendorDialog(self)
            if not dlg.exec():
                return
            try:
                self.ctx.repo.add_vendor(dlg.result_data)
            except RepositoryError as exc:
                info(self, "Could not add vendor", str(exc))
                return
        dlg = QuoteDialog(self, self.ctx.repo, self.event_id, requirement=requirement, category=category)
        if dlg.exec():
            self.ctx.repo.add_quote(self.event_id, dlg.result_data)
            self.ctx.data_changed("Quotation added")

    def _edit(self, q) -> None:
        dlg = QuoteDialog(self, self.ctx.repo, self.event_id, q)
        if dlg.exec():
            try:
                self.ctx.repo.update_quote(q.id, dlg.result_data)
            except RepositoryError as exc:
                info(self, "Could not change this quote", str(exc))
                return
            self.ctx.data_changed("Quotation updated")

    def _select(self, q) -> None:
        self.ctx.repo.select_quote(q.id)
        self.ctx.data_changed(f"{q.vendor_name} selected for \"{q.requirement}\"")

    def _unselect(self, q) -> None:
        self.ctx.repo.set_quote_status(q.id, "Received")
        self.ctx.data_changed("Selection removed")

    def _set_status(self, q, status: str) -> None:
        self.ctx.repo.set_quote_status(q.id, status)
        self.ctx.data_changed()

    def _delete(self, q) -> None:
        if confirm(self, "Delete this quotation?", f"{q.vendor_name}'s quote of {format_aed(q.amount)} will be removed."):
            self.ctx.repo.delete_quote(q.id)
            self.ctx.data_changed("Quotation deleted")

    def _to_expense(self, q) -> None:
        if confirm(self, "Record as an expense?",
                   f"{format_aed(q.amount)} to {q.vendor_name} for \"{q.requirement}\" becomes an actual expense. "
                   "It stops counting as committed, so it is never counted twice.", action="Create expense", danger=False):
            try:
                self.ctx.repo.convert_quote_to_expense(q.id)
            except RepositoryError as exc:
                info(self, "Could not create the expense", str(exc))
                return
            self.ctx.data_changed("Expense created from the quote")

    # ---- drawing --------------------------------------------------------------------
    def refresh(self) -> None:
        clear_layout(self.body_layout)
        groups = quote_logic.group_quotes(self.ctx.repo.list_quotes(self.event_id), self.ctx.today)
        if not groups:
            self.body_layout.addWidget(make_label(
                "No quotations yet. Click \"Add quotation\" to record what each vendor offered for the same "
                "requirement (for example three photographers), then compare them here.", "muted", wrap=True))
        for g in groups:
            self.body_layout.addWidget(self._group_card(g))
        self.body_layout.addStretch(1)

    def _group_card(self, g) -> Card:
        card = Card(shadow=False)
        v = QVBoxLayout(card)
        v.setContentsMargins(18, 14, 18, 14)
        v.setSpacing(6)
        head = QHBoxLayout()
        head.addWidget(make_label(g.requirement, "h3"))
        head.addWidget(Badge(g.category, theme.GOLD))
        head.addStretch(1)
        more = make_button("Another quote for this", "link")
        more.clicked.connect(lambda _=False, grp=g: self._add(grp.requirement, grp.category))
        head.addWidget(more)
        v.addLayout(head)
        if g.selected is None:
            v.addWidget(make_label("Nothing selected yet.", "small"))
        for view in g.views:
            v.addWidget(self._quote_row(view))
        return card

    def _quote_row(self, view) -> QWidget:
        q = view.quote
        rejected = q.status == "Rejected"
        row = QFrame()
        row.setObjectName("QuoteRow")
        border = theme.rgba(theme.SUCCESS, 0.8) if q.status == "Selected" else theme.rgba(theme.GOLD, 0.2)
        row.setStyleSheet(f"QFrame#QuoteRow {{ background: {theme.rgba('#000000', 0.16)}; "
                          f"border: 1px solid {border}; border-radius: 10px; }}")
        h = QHBoxLayout(row)
        h.setContentsMargins(14, 10, 10, 10)
        h.setSpacing(12)

        left = QVBoxLayout()
        left.setSpacing(3)
        title = QHBoxLayout()
        title.setSpacing(6)
        name = shrinkable(make_label(q.vendor_name, "body", color=theme.IVORY_MUTED if rejected else theme.IVORY))
        title.addWidget(name, 1)
        title.addWidget(Badge(q.status, STATUS_COLORS[q.status]))
        left.addLayout(title)
        tags = QHBoxLayout()
        tags.setSpacing(6)
        if view.is_lowest:
            tags.addWidget(Badge("Lowest price", theme.SUCCESS))
        if view.is_top_rated:
            tags.addWidget(Badge("Top rated", theme.GOLD))
        if view.is_suggested:
            tags.addWidget(Badge("Suggested best value", theme.ROSE, filled=True))
        if view.expired:
            tags.addWidget(Badge("Expired", theme.DANGER))
        if q.expense_id:
            tags.addWidget(Badge("Recorded as expense", theme.IVORY_MUTED))
        tags.addStretch(1)
        left.addLayout(tags)
        bits = [stars(q.rating)]
        if q.deposit:
            bits.append(f"deposit {format_aed(q.deposit)}")
        if q.valid_until:
            bits.append(f"valid until {q.valid_until:%d %b %Y}")
        if q.notes:
            bits.append(q.notes)
        left.addWidget(shrinkable(make_label("   ·   ".join(bits), "small")))
        h.addLayout(left, 1)

        price = QVBoxLayout()
        price.setSpacing(0)
        price.addWidget(make_label(format_aed(q.amount), "h3", color=theme.GOLD_SOFT, align=Qt.AlignmentFlag.AlignRight))
        if view.vs_lowest_pct is not None:
            note = "cheapest" if view.vs_lowest_pct < 0.05 else f"+{view.vs_lowest_pct:.0f}% vs lowest"
            price.addWidget(make_label(note, "small", align=Qt.AlignmentFlag.AlignRight))
        h.addLayout(price)

        buttons = QHBoxLayout()
        buttons.setSpacing(4)
        if q.status == "Selected" and not q.expense_id:
            exp = make_button("Make expense", "primary")
            exp.clicked.connect(lambda _=False, quote=q: self._to_expense(quote))
            buttons.addWidget(exp)
            un = make_button("Unselect")
            un.clicked.connect(lambda _=False, quote=q: self._unselect(quote))
            buttons.addWidget(un)
        elif not rejected and not q.expense_id:
            sel = make_button("Select", "primary")
            sel.clicked.connect(lambda _=False, quote=q: self._select(quote))
            buttons.addWidget(sel)
        if rejected:
            back = make_button("Reopen")
            back.clicked.connect(lambda _=False, quote=q: self._set_status(quote, "Received"))
            buttons.addWidget(back)
        elif q.status != "Selected":
            rej = make_button("Reject")
            rej.clicked.connect(lambda _=False, quote=q: self._set_status(quote, "Rejected"))
            buttons.addWidget(rej)
        e = icon_button("edit", "Edit quotation")
        e.clicked.connect(lambda _=False, quote=q: self._edit(quote))
        d = icon_button("trash", "Delete quotation", danger=True)
        d.clicked.connect(lambda _=False, quote=q: self._delete(quote))
        buttons.addWidget(e)
        buttons.addWidget(d)
        h.addLayout(buttons)
        return row
