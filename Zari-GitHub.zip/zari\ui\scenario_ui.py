"""What-if planner. Nothing here changes your event until you press "Apply to event"."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLineEdit,
    QScrollArea, QSpinBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from zari.config import EXPENSE_CATEGORIES
from zari.logic import scenario
from zari.logic.finance import format_margin
from zari.logic.money import format_aed, format_bp
from zari.logic.validation import ValidationError, validate_scenario
from zari.ui import theme
from zari.ui.dialogs import confirm, info
from zari.ui.widgets import Card, make_button, make_label, set_label_color


def _signed(fils: int) -> str:
    return ("+" if fils > 0 else "") + format_aed(fils) if fils else "no change"


class ScenarioDialog(QDialog):
    NEW = "(new scenario)"

    def __init__(self, parent, ctx, event_id: int):
        super().__init__(parent)
        self.ctx, self.event_id = ctx, event_id
        repo = ctx.repo
        self.ev = repo.get_event(event_id)
        self.base = scenario.base_costs(repo.list_expenses(event_id), repo.list_quotes(event_id))
        self.saved = repo.list_scenarios(event_id)
        self.setWindowTitle(f"Scenario planner - {self.ev.name}")
        self.resize(1120, 720)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)   # lets you go full screen

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 18)
        root.setSpacing(10)
        root.addWidget(make_label("What-if planning", "eyebrow"))
        root.addWidget(make_label(f"Scenarios: {self.ev.name}", "h2"))
        root.addWidget(make_label(
            "Try a different guest count, price changes or contingency and see the effect on profit. This is a "
            "sandbox: your real event, payments and expenses are not touched unless you press \"Apply to event\". "
            "Costs are today's expenses plus quotes you have selected.", "small", wrap=True))

        body = QHBoxLayout()
        body.setSpacing(18)
        root.addLayout(body, 1)

        # ---------------- left: inputs ----------------
        left = Card(shadow=False)
        lv = QVBoxLayout(left)
        lv.setContentsMargins(18, 16, 18, 16)
        lv.setSpacing(6)
        left.setFixedWidth(400)
        picker = QHBoxLayout()
        self.picker = QComboBox()
        self._fill_picker()
        self.picker.currentIndexChanged.connect(self._load_selected)
        picker.addWidget(self.picker, 1)
        self.delete_btn = make_button("Delete", "danger")
        self.delete_btn.clicked.connect(self._delete_saved)
        picker.addWidget(self.delete_btn)
        lv.addWidget(make_label("Scenario", "eyebrow"))
        lv.addLayout(picker)
        self.name = QLineEdit("Scenario A")
        lv.addWidget(make_label("Name", "eyebrow"))
        lv.addWidget(self.name)

        row = QHBoxLayout()
        row.setSpacing(10)
        col1, col2 = QVBoxLayout(), QVBoxLayout()
        self.guests = QSpinBox()
        self.guests.setRange(1, 50_000)
        self.guests.setValue(self.ev.guests)
        self.guests.valueChanged.connect(self._recalc)
        col1.addWidget(make_label(f"Guests (now {self.ev.guests:,})", "eyebrow"))
        col1.addWidget(self.guests)
        self.contingency = QLineEdit(format_bp(self.ev.contingency_bp).rstrip("%") if self.ev.contingency_bp else "")
        self.contingency.setPlaceholderText("0")
        self.contingency.textChanged.connect(self._recalc)
        col2.addWidget(make_label("Contingency %", "eyebrow"))
        col2.addWidget(self.contingency)
        row.addLayout(col1)
        row.addLayout(col2)
        lv.addLayout(row)

        crow = QHBoxLayout()
        cc = QVBoxLayout()
        self.contract_pct = QLineEdit()
        self.contract_pct.setPlaceholderText("0")
        self.contract_pct.textChanged.connect(self._recalc)
        cc.addWidget(make_label("Contract value change %", "eyebrow"))
        cc.addWidget(self.contract_pct)
        crow.addLayout(cc, 1)
        match = make_button("Match to guests")
        match.setToolTip("Scale the contract value in proportion to the guest count")
        match.clicked.connect(self._match_guests)
        crow.addWidget(match, 0, Qt.AlignmentFlag.AlignBottom)
        lv.addLayout(crow)

        lv.addSpacing(4)
        lv.addWidget(make_label("Cost lines", "eyebrow"))
        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(4)
        for c, t in enumerate(("Category", "Today", "Price %", "Per guest")):
            grid.addWidget(make_label(t, "small"), 0, c)
        self.adjust: dict[str, QLineEdit] = {}
        self.per_guest: dict[str, QCheckBox] = {}
        for r, (cat, cost) in enumerate(self.base.items(), 1):
            grid.addWidget(make_label(cat, "body"), r, 0)
            grid.addWidget(make_label(format_aed(cost), "small"), r, 1)
            e = QLineEdit()
            e.setPlaceholderText("0")
            e.setMaximumWidth(70)
            e.textChanged.connect(self._recalc)
            cb = QCheckBox()
            cb.setChecked(cat == "Catering")
            cb.setToolTip("Tick if this cost grows or shrinks with the number of guests")
            cb.toggled.connect(self._recalc)
            grid.addWidget(e, r, 2)
            grid.addWidget(cb, r, 3, Qt.AlignmentFlag.AlignCenter)
            self.adjust[cat], self.per_guest[cat] = e, cb
        if not self.base:
            grid.addWidget(make_label("No expenses or selected quotes yet - add some to model costs.", "small", wrap=True), 1, 0, 1, 4)
        lv.addLayout(grid)
        self.message = make_label("", "small", color=theme.DANGER, wrap=True)
        self.message.hide()
        lv.addWidget(self.message)
        lv.addStretch(1)
        buttons = QHBoxLayout()
        self.save_btn = make_button("Save scenario", icon_name="check")
        self.save_btn.clicked.connect(self._save)
        self.apply_btn = make_button("Apply to event", "primary")
        self.apply_btn.clicked.connect(self._apply)
        buttons.addWidget(self.save_btn)
        buttons.addWidget(self.apply_btn)
        lv.addLayout(buttons)
        body.addWidget(left)

        # ---------------- right: comparison ----------------
        right = QVBoxLayout()
        right.addWidget(make_label("Comparison", "eyebrow"))
        self.table = QTableWidget()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        right.addWidget(self.table, 1)
        self.verdict = make_label("", "body", wrap=True)
        right.addWidget(self.verdict)
        body.addLayout(right, 1)

        close = make_button("Close")
        close.clicked.connect(self.accept)
        foot = QHBoxLayout()
        foot.addStretch(1)
        foot.addWidget(close)
        root.addLayout(foot)
        self._load_selected()

    # ---- helpers --------------------------------------------------------------------
    def _fill_picker(self) -> None:
        self.picker.blockSignals(True)
        self.picker.clear()
        self.picker.addItem(self.NEW, None)
        for s in self.saved:
            self.picker.addItem(s.name, s.id)
        self.picker.blockSignals(False)

    def _form_values(self) -> dict:
        return dict(name=self.name.text(), guests=self.guests.value(), contract_pct=self.contract_pct.text(),
                    contingency_pct=self.contingency.text(),
                    adjust_pct={c: e.text() for c, e in self.adjust.items()},
                    per_guest=[c for c, cb in self.per_guest.items() if cb.isChecked()])

    def _plan(self) -> tuple[scenario.Plan | None, dict | None]:
        try:
            d = validate_scenario(**self._form_values())
        except ValidationError as exc:
            self.message.setText(" ".join(exc.errors.values()))
            self.message.show()
            return None, None
        self.message.hide()
        return scenario.Plan(d["name"], d["guests"], d["contract_bp"], d["contingency_bp"], d["adjust_bp"],
                             d["per_guest"]), d

    def _load_selected(self) -> None:
        sid = self.picker.currentData()
        s = next((x for x in self.saved if x.id == sid), None)
        self.delete_btn.setEnabled(s is not None)
        for w in (self.guests, self.contingency, self.contract_pct, *self.adjust.values(), *self.per_guest.values()):
            w.blockSignals(True)
        if s is None:
            self.name.setText(f"Scenario {chr(65 + len(self.saved) % 26)}")
            self.guests.setValue(self.ev.guests)
            self.contract_pct.clear()
            for c, e in self.adjust.items():
                e.clear()
            for c, cb in self.per_guest.items():
                cb.setChecked(c == "Catering")
        else:
            self.name.setText(s.name)
            self.guests.setValue(s.guests)
            self.contingency.setText(format_bp(s.contingency_bp).rstrip("%") if s.contingency_bp else "")
            self.contract_pct.setText(format_bp(s.contract_bp).rstrip("%") if s.contract_bp else "")
            for c, e in self.adjust.items():
                e.setText(format_bp(s.adjust_bp[c]).rstrip("%") if c in s.adjust_bp else "")
            for c, cb in self.per_guest.items():
                cb.setChecked(c in s.per_guest)
        for w in (self.guests, self.contingency, self.contract_pct, *self.adjust.values(), *self.per_guest.values()):
            w.blockSignals(False)
        self._recalc()

    def _match_guests(self) -> None:
        pct = (self.guests.value() / max(1, self.ev.guests) - 1) * 100
        self.contract_pct.setText(f"{pct:.2f}".rstrip("0").rstrip("."))

    # ---- calculation ----------------------------------------------------------------
    def _recalc(self, *_) -> None:
        plan, _data = self._plan()
        ev = self.ev
        columns = [("Current plan", scenario.baseline(self.base, ev.contract_value, ev.guests, ev.contingency_bp))]
        for s in self.saved:
            p = scenario.Plan(s.name, s.guests, s.contract_bp, s.contingency_bp, s.adjust_bp, s.per_guest)
            columns.append((s.name, scenario.project(self.base, ev.contract_value, ev.guests, p)))
        working = None
        if plan is not None:
            working = scenario.project(self.base, ev.contract_value, ev.guests, plan)
            columns.append((f"{plan.name} (editing)", working))
        self.apply_btn.setEnabled(working is not None)
        self.save_btn.setEnabled(working is not None)
        self._render(columns, working)

    def _render(self, columns, working) -> None:
        cats = [c for c in EXPENSE_CATEGORIES if any(c in p.category_costs for _n, p in columns)]
        rows = [("Guests", lambda p: f"{p.guests:,}", None), ("Contract value", lambda p: format_aed(p.contract), "contract")]
        rows += [(c, (lambda p, c=c: format_aed(p.category_costs.get(c, 0))), ("cost", c)) for c in cats]
        rows += [("Costs before contingency", lambda p: format_aed(p.subtotal), "subtotal"),
                 ("Contingency", lambda p: format_aed(p.contingency), "contingency"),
                 ("Total cost", lambda p: format_aed(p.total_cost), "total"),
                 ("Gross profit", lambda p: format_aed(p.profit), "profit"),
                 ("Margin", lambda p: format_margin(p.margin), None)]
        self.table.setColumnCount(len(columns) + 1)
        self.table.setRowCount(len(rows))
        self.table.setHorizontalHeaderLabels([""] + [n for n, _p in columns])
        bold_rows = {"Gross profit", "Total cost", "Margin"}
        for r, (label, fmt, _key) in enumerate(rows):
            item = QTableWidgetItem(label)
            if label in bold_rows:
                f = item.font()
                f.setBold(True)
                item.setFont(f)
            self.table.setItem(r, 0, item)
            for c, (_n, proj) in enumerate(columns, 1):
                cell = QTableWidgetItem(fmt(proj))
                cell.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                if label in ("Gross profit", "Margin"):
                    negative = proj.profit < 0
                    cell.setForeground(QColor(theme.DANGER if negative else theme.SUCCESS))
                if label in bold_rows:
                    f = cell.font()
                    f.setBold(True)
                    cell.setFont(f)
                self.table.setItem(r, c, cell)
        base = columns[0][1]
        if working is None:
            self.verdict.setText("")
            return
        d_profit = working.profit - base.profit
        self.verdict.setText(
            f"{working.name}: gross profit {format_aed(working.profit)} ({_signed(d_profit)} vs the current plan), "
            f"margin {format_margin(working.margin)}.")
        set_label_color(self.verdict, theme.SUCCESS if d_profit > 0 else (theme.DANGER if d_profit < 0 else theme.IVORY))

    # ---- actions --------------------------------------------------------------------
    def _save(self) -> None:
        _plan, data = self._plan()
        if data is None:
            return
        existing = next((s for s in self.saved if s.name.lower() == data["name"].lower()), None)
        if existing and not confirm(self, "Replace this scenario?", f"A scenario called \"{existing.name}\" "
                                    "already exists. It will be replaced.", action="Replace", danger=False):
            return
        if existing:
            self.ctx.repo.delete_scenario(existing.id)
        sid = self.ctx.repo.save_scenario(self.event_id, data)
        self.saved = self.ctx.repo.list_scenarios(self.event_id)
        self._fill_picker()
        self.picker.setCurrentIndex(max(0, self.picker.findData(sid)))
        self._load_selected()
        self.ctx.notify(f"Scenario \"{data['name']}\" saved (your event is unchanged)")

    def _delete_saved(self) -> None:
        sid = self.picker.currentData()
        s = next((x for x in self.saved if x.id == sid), None)
        if s and confirm(self, "Delete this scenario?", f"\"{s.name}\" will be removed. Your event is not affected."):
            self.ctx.repo.delete_scenario(s.id)
            self.saved = self.ctx.repo.list_scenarios(self.event_id)
            self._fill_picker()
            self._load_selected()

    def _apply(self) -> None:
        plan, _data = self._plan()
        if plan is None:
            return
        proj = scenario.project(self.base, self.ev.contract_value, self.ev.guests, plan)
        ev = self.ev
        if not confirm(
            self, "Apply this scenario to the real event?",
            f"This will change \"{ev.name}\":\n\n"
            f"   Guests: {ev.guests:,} -> {plan.guests:,}\n"
            f"   Contract value: {format_aed(ev.contract_value)} -> {format_aed(proj.contract)}\n"
            f"   Contingency: {format_bp(ev.contingency_bp)} -> {format_bp(plan.contingency_bp)}\n\n"
            "Expenses and payments are not changed. A safety backup is saved first.",
            action="Apply to event", danger=False):
            return
        self.ctx.repo.apply_scenario(self.event_id, plan.guests, proj.contract, plan.contingency_bp)
        self.ev = self.ctx.repo.get_event(self.event_id)
        self.ctx.data_changed("Scenario applied to the event")
        self._recalc()
