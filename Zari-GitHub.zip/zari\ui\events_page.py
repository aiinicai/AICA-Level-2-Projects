"""Events page: search, filter, sort and manage every event as a card."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QComboBox, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLineEdit, QProgressBar, QScrollArea, QVBoxLayout,
    QWidget,
)

from zari.config import EVENT_STATUSES
from zari.exports.excel_export import export_all_events
from zari.logic.finance import countdown_text
from zari.logic.money import format_aed
from zari.ui import icons, theme
from zari.ui.dashboard_page import _pixmap_label
from zari.ui.dialogs import info
from zari.ui.event_actions import add_event_flow, delete_event_flow, edit_event_flow
from zari.ui.widgets import (
    Badge, ClickableFrame, Ornament, add_shadow, make_button, make_label, sample_badge, shrinkable, status_badge,
)

CARD_MIN_WIDTH = 400
SORTS = ["Date: soonest first", "Date: latest first", "Contract value: high to low", "Name: A to Z"]


class EventsPage(QScrollArea):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._cols = 0
        self._cards: list[QWidget] = []
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root = QWidget()
        root.setObjectName("PageRoot")
        self.setWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(36, 30, 36, 36)
        lay.setSpacing(16)

        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Portfolio", "eyebrow"))
        titles.addWidget(make_label("Events", "h1"))
        head.addLayout(titles)
        head.addStretch(1)
        export = make_button("Export Excel", icon_name="download", tooltip="Export every event and its totals")
        export.clicked.connect(self._export_all)
        add = make_button("Add event", "primary", "plus")
        add.clicked.connect(self._add)
        head.addWidget(export, 0, Qt.AlignmentFlag.AlignBottom)
        head.addWidget(add, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(head)
        lay.addWidget(Ornament(width_limit=900))

        filters = QHBoxLayout()
        filters.setSpacing(10)
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search name, client, venue or type...")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.refresh)
        self.status = QComboBox()
        self.status.addItem("All statuses")
        self.status.addItems(EVENT_STATUSES)
        self.status.currentIndexChanged.connect(self.refresh)
        self.sort = QComboBox()
        self.sort.addItems(SORTS)
        self.sort.currentIndexChanged.connect(self.refresh)
        filters.addWidget(self.search, 1)
        filters.addWidget(self.status)
        filters.addWidget(self.sort)
        lay.addLayout(filters)
        self.count = make_label("", "small")
        lay.addWidget(self.count)

        self.grid_host = QWidget()
        self.grid_host.setObjectName("Transparent")
        self.grid = QGridLayout(self.grid_host)
        self.grid.setContentsMargins(0, 0, 0, 0)
        self.grid.setSpacing(18)
        lay.addWidget(self.grid_host)
        self.empty = make_label("", "muted", align=Qt.AlignmentFlag.AlignCenter, wrap=True)
        self.empty.hide()
        lay.addWidget(self.empty)
        lay.addStretch(1)

    # ---- actions --------------------------------------------------------------------
    def _add(self) -> None:
        new_id = add_event_flow(self.window(), self.ctx)
        if new_id:
            self.ctx.event_requested.emit(new_id)

    def _export_all(self) -> None:
        events = self.ctx.repo.list_events()
        if not events:
            info(self.window(), "Nothing to export", "There are no events yet.")
            return
        path, _ = QFileDialog.getSaveFileName(self.window(), "Export all events", "zari-events.xlsx",
                                              "Excel workbook (*.xlsx)")
        if not path:
            return
        try:
            export_all_events(path, events)
        except OSError as exc:
            info(self.window(), "Could not save the file",
                 f"{exc}\n\nIf the file is open in Excel, close it and try again.")
            return
        self.ctx.notify(f"Exported {len(events)} events to {path}")

    # ---- list -----------------------------------------------------------------------
    def _filtered(self):
        q = self.search.text().strip().lower()
        status = self.status.currentText()
        out = []
        for e in self.ctx.repo.list_events():
            if status != "All statuses" and e.status != status:
                continue
            if q and not any(q in s.lower() for s in (e.name, e.client, e.venue, e.type)):
                continue
            out.append(e)
        key = self.sort.currentIndex()
        if key == 0:
            out.sort(key=lambda e: (e.date, e.name))
        elif key == 1:
            out.sort(key=lambda e: (e.date, e.name), reverse=True)
        elif key == 2:
            out.sort(key=lambda e: e.contract_value, reverse=True)
        else:
            out.sort(key=lambda e: e.name.lower())
        return out

    def refresh(self, *_) -> None:
        events = self._filtered()
        total = len(self.ctx.repo.list_events())
        self.count.setText(f"Showing {len(events)} of {total} event{'s' if total != 1 else ''}")
        for old in self._cards:
            old.setParent(None)
            old.deleteLater()
        while self.grid.count():
            self.grid.takeAt(0)
        self._cards = [self._card(e) for e in events]
        self._cols = 0
        self._layout_cards()
        if not events:
            self.empty.setText("No events yet. Click \"Add event\" to create your first one." if total == 0
                               else "No events match your search or filter.")
        self.empty.setVisible(not events)

    def _layout_cards(self) -> None:
        cols = max(1, self.grid_host.width() // CARD_MIN_WIDTH) if self.grid_host.width() > 50 else 2
        if cols == self._cols and self.grid.count() == len(self._cards):
            return
        self._cols = cols
        while self.grid.count():
            self.grid.takeAt(0)
        for i, card in enumerate(self._cards):
            self.grid.addWidget(card, i // cols, i % cols, Qt.AlignmentFlag.AlignTop)
        for c in range(cols):
            self.grid.setColumnStretch(c, 1)

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._layout_cards()

    def _card(self, e) -> QWidget:
        f = e.fin
        card = ClickableFrame("EventCard")
        card.setStyleSheet(
            f"QFrame#EventCard {{ background: {theme.CARD}; border: 1px solid {theme.rgba(theme.GOLD, 0.55)}; border-radius: 16px; }}"
            f"QFrame#EventCard:hover {{ background: {theme.CARD_HI}; border-color: {theme.GOLD}; }}")
        add_shadow(card)
        card.clicked.connect(lambda eid=e.id: self.ctx.event_requested.emit(eid))
        v = QVBoxLayout(card)
        v.setContentsMargins(20, 18, 20, 16)
        v.setSpacing(8)

        top = QHBoxLayout()
        top.addWidget(make_label(e.name, "h3", wrap=True), 1)
        if e.is_sample:
            top.addWidget(sample_badge(), 0, Qt.AlignmentFlag.AlignTop)
        v.addLayout(top)
        v.addWidget(make_label(e.client, "muted"))
        badges = QHBoxLayout()
        badges.setSpacing(8)
        badges.addWidget(status_badge(e.status))
        badges.addWidget(Badge(e.type, theme.ROSE))
        badges.addStretch(1)
        v.addLayout(badges)

        info_row = QHBoxLayout()
        info_row.setSpacing(6)
        info_row.addWidget(_pixmap_label("calendar", 15))
        info_row.addWidget(make_label(f"{e.date:%d %b %Y}", "small"))
        info_row.addWidget(make_label(countdown_text(e.date, self.ctx.today), "small", color=theme.GOLD))
        info_row.addStretch(1)
        info_row.addWidget(make_label(f"{e.guests:,} guests", "small"))
        v.addLayout(info_row)
        venue = QHBoxLayout()
        venue.setSpacing(6)
        venue.addWidget(_pixmap_label("pin", 15))
        venue.addWidget(shrinkable(make_label(e.venue, "small")), 1)
        v.addLayout(venue)

        money = QHBoxLayout()
        money.addWidget(make_label(format_aed(f.contract), "h3", color=theme.GOLD_SOFT))
        money.addStretch(1)
        money.addWidget(make_label("Balance " + format_aed(f.balance_due), "small",
                                   color=theme.WARNING if f.balance_due else theme.SUCCESS))
        v.addLayout(money)
        bar = QProgressBar()
        bar.setRange(0, 1000)
        bar.setValue(int(f.progress * 1000))
        bar.setTextVisible(False)
        bar.setFixedHeight(8)
        v.addWidget(bar)

        actions = QHBoxLayout()
        actions.setSpacing(8)
        edit = make_button("Edit", icon_name="edit")
        edit.clicked.connect(lambda _=False, eid=e.id: edit_event_flow(self.window(), self.ctx, eid))
        delete = make_button("Delete", "danger", "trash")
        delete.clicked.connect(lambda _=False, eid=e.id: delete_event_flow(self.window(), self.ctx, eid))
        actions.addStretch(1)
        actions.addWidget(edit)
        actions.addWidget(delete)
        v.addLayout(actions)
        return card
