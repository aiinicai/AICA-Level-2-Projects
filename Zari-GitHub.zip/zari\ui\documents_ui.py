"""Attach files to an event (invoices, contracts, receipts, quotes) and open / remove them."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QComboBox, QFileDialog, QHBoxLayout, QLineEdit, QVBoxLayout

from zari.logic import attachments
from zari.logic.money import format_aed
from zari.logic.validation import DOC_KINDS, ValidationError, validate_document
from zari.ui import theme
from zari.ui.dialogs import FormDialog, confirm, info
from zari.ui.widgets import Badge, Card, divider, icon_button, make_button, make_label, shrinkable

FILE_FILTER = ("Documents and images (*.pdf *.jpg *.jpeg *.png *.tif *.tiff *.bmp *.webp *.doc *.docx *.xls *.xlsx "
               "*.csv *.txt *.ppt *.pptx *.msg *.eml);;All files (*.*)")
KIND_COLORS = {"Invoice": theme.GOLD, "Receipt": theme.SUCCESS, "Contract": theme.ROSE,
               "Quote": theme.WARNING, "Other": theme.IVORY_MUTED}


class AttachDialog(FormDialog):
    """Choose the document type, an optional title, and (optionally) the expense it belongs to."""

    def __init__(self, parent, paths: list[str], expenses):
        super().__init__(parent, "Attach to this event", "Documents", width=520)
        self.paths = paths
        names = "\n".join(Path(p).name for p in paths[:6]) + (f"\n... and {len(paths) - 6} more" if len(paths) > 6 else "")
        self.files_label = make_label(names, "body", wrap=True)
        self.add_field("files", f"{len(paths)} file{'s' if len(paths) != 1 else ''} selected", self.files_label)
        self.kind = QComboBox()
        self.kind.addItems(DOC_KINDS)
        self.add_field("kind", "Type", self.kind)
        self.title = QLineEdit(Path(paths[0]).stem if len(paths) == 1 else "")
        self.title.setPlaceholderText("Each file's own name is used" if len(paths) > 1 else "")
        self.title.setEnabled(len(paths) == 1)
        self.add_field("title", "Title", self.title)
        self.expense = QComboBox()
        self.expense.addItem("Not linked to an expense", None)
        for x in expenses:
            self.expense.addItem(f"{x.description} - {format_aed(x.amount)}", x.id)
        self.add_field("expense", "Link to expense (optional)", self.expense)

    def collect(self) -> dict:
        if len(self.paths) == 1:
            data = validate_document(self.kind.currentText(), self.title.text())
        else:
            data = validate_document(self.kind.currentText(), "multiple")
        problems = {}
        for p in self.paths:
            try:
                attachments.check_file(Path(p))
            except attachments.AttachmentError as exc:
                problems["files"] = str(exc)
                break
        if problems:
            raise ValidationError(problems)
        data["expense_id"] = self.expense.currentData()
        return data


def attach_files_flow(window, ctx, event_id: int, paths: list[str] | None = None) -> int:
    """Pick files (or use dropped ones), ask for details, copy them in. Returns how many were attached."""
    if paths is None:
        paths, _ = QFileDialog.getOpenFileNames(window, "Attach files to this event", str(Path.home()), FILE_FILTER)
    if not paths:
        return 0
    dlg = AttachDialog(window, paths, ctx.repo.list_expenses(event_id))
    if not dlg.exec():
        return 0
    d = dlg.result_data
    added = 0
    for p in paths:
        try:
            stored, original, size = attachments.store_file(Path(p), str(event_id))
        except attachments.AttachmentError as exc:
            info(window, "Could not attach a file", str(exc))
            continue
        title = d["title"] if len(paths) == 1 else Path(p).stem
        ctx.repo.add_document(event_id, {"kind": d["kind"], "title": title}, stored, original, size, d["expense_id"])
        added += 1
    if added:
        ctx.data_changed(f"{added} document{'s' if added != 1 else ''} attached")
    return added


def open_document(window, doc) -> None:
    path = attachments.attachment_path(doc.stored_name)
    if not path.is_file():
        info(window, "File not found", f"The stored copy is missing:\n{path}")
        return
    QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))


def documents_card(window, ctx, event) -> Card:
    docs = ctx.repo.list_documents(event.id)
    card = Card(shadow=False)
    v = QVBoxLayout(card)
    v.setContentsMargins(18, 16, 18, 16)
    v.setSpacing(8)
    head = QHBoxLayout()
    head.addWidget(make_label("Documents", "h3"))
    head.addWidget(make_label(f"{len(docs)} attached", "small"))
    head.addStretch(1)
    add = make_button("Attach file", "primary", "plus", tooltip="Upload invoices, contracts, receipts... "
                                                               "(you can also drop files onto this panel)")
    add.clicked.connect(lambda: attach_files_flow(window, ctx, event.id))
    head.addWidget(add)
    v.addLayout(head)
    if not docs:
        v.addWidget(make_label("No documents yet. Attach invoices, contracts or receipts, or drop files here.", "small"))
    for d in docs:
        v.addWidget(divider())
        row = QHBoxLayout()
        row.setSpacing(8)
        row.addWidget(Badge(d.kind, KIND_COLORS.get(d.kind, theme.GOLD)))
        col = QVBoxLayout()
        col.setSpacing(0)
        col.addWidget(shrinkable(make_label(d.title, "body")))
        meta = f"{d.original_name}  ·  {attachments.human_size(d.size)}  ·  {d.added_at[:10]}"
        if d.expense_label:
            meta += f"  ·  expense: {d.expense_label}"
        col.addWidget(shrinkable(make_label(meta, "small")))
        row.addLayout(col, 1)
        op = icon_button("file", "Open this document")
        op.clicked.connect(lambda _=False, doc=d: open_document(window, doc))
        rm = icon_button("trash", "Remove from this event", danger=True)
        rm.clicked.connect(lambda _=False, doc=d: _remove(window, ctx, doc))
        row.addWidget(op)
        row.addWidget(rm)
        v.addLayout(row)
    return card


def _remove(window, ctx, doc) -> None:
    if confirm(window, "Remove this document?",
               f"\"{doc.title}\" will be detached from the event. The stored file is kept in your Zari folder "
               "so nothing is lost if you restore an older backup.", action="Remove"):
        ctx.repo.delete_document(doc.id)
        ctx.data_changed("Document removed")
