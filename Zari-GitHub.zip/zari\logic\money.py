"""Money handling.

All amounts are stored as integer *fils* (1 AED = 100 fils) so that adding
thousands of payments never produces floating-point rounding drift.
"""
from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

from zari.config import MAX_AMOUNT_FILS


def to_fils(value) -> int:
    """Convert a Decimal / int / str AED value to integer fils."""
    return int((Decimal(str(value)) * 100).quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def parse_amount(text: str) -> int:
    """Parse user input such as 'AED 385,000' or '1250.50' into fils.

    Raises ValueError with a user-friendly message when the text is not a
    sensible non-negative amount.
    """
    cleaned = (text or "").strip()
    if not cleaned:
        raise ValueError("Please enter an amount.")
    cleaned = re.sub(r"(?i)\baed\b|د\.إ", "", cleaned).replace(",", "").replace(" ", "")
    if not re.fullmatch(r"\d+(\.\d+)?", cleaned):
        raise ValueError("Amount must be a positive number, e.g. 12,500 or 1250.50.")
    try:
        d = Decimal(cleaned)
    except InvalidOperation:  # pragma: no cover - regex already guards this
        raise ValueError("Amount is not a valid number.")
    if d != d.quantize(Decimal("0.01")):
        raise ValueError("Amount can have at most 2 decimal places.")
    fils = to_fils(d)
    if fils > MAX_AMOUNT_FILS:
        raise ValueError("Amount is unrealistically large - please check it.")
    return fils


def format_aed(fils: int, prefix: bool = True) -> str:
    """'AED 385,000' for whole dirhams, 'AED 1,250.50' otherwise."""
    sign = "-" if fils < 0 else ""
    whole, cents = divmod(abs(int(fils)), 100)
    body = f"{whole:,}" if cents == 0 else f"{whole:,}.{cents:02d}"
    return f"{sign}AED {body}" if prefix else f"{sign}{body}"


def format_input(fils: int) -> str:
    """Editable text for a form field, with thousand separators and no AED prefix."""
    return format_aed(fils, prefix=False)


def parse_percent(text: str, lo: float, hi: float) -> int:
    """'12.5' or '12.5%' -> basis points (1250). Raises ValueError with a friendly message."""
    cleaned = (text or "").strip().replace("%", "").replace(" ", "")
    if cleaned in ("", "+", "-"):
        return 0
    if not re.fullmatch(r"[+-]?\d+(\.\d{1,2})?", cleaned):
        raise ValueError("Enter a percentage such as 10 or -7.5.")
    value = Decimal(cleaned)
    if not (Decimal(str(lo)) <= value <= Decimal(str(hi))):
        raise ValueError(f"Percentage must be between {lo:g} and {hi:g}.")
    return int(value * 100)


def format_bp(bp: int, signed: bool = False) -> str:
    value = bp / 100
    return f"{value:+.1f}%" if signed else f"{value:.1f}%".replace(".0%", "%")


def apply_bp(fils: int, bp: int) -> int:
    """fils * (1 + bp/10000), rounded half-up, in pure integer maths."""
    num = fils * (10000 + bp)
    return (num + 5000) // 10000 if num >= 0 else -((-num + 5000) // 10000)


def format_axis(fils: int) -> str:
    """Chart axis label: 0, 500, 120k, 1.2M."""
    aed = fils / 100
    if aed >= 1_000_000:
        v = aed / 1_000_000
        return f"{v:g}M"
    if aed >= 1_000:
        v = aed / 1_000
        return f"{v:g}k"
    return f"{aed:g}"
