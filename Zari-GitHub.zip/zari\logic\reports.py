"""Assemble the tables used by the Reports page and its Excel / PDF exports."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from zari.logic import budget as budget_logic


@dataclass(frozen=True)
class EventRow:
    event: object
    contract: int
    received: int
    balance_due: int
    budget: int
    actual: int
    committed: int
    variance: int | None   # budget - (actual + committed); None when no budget was set
    profit: int
    margin: float | None


@dataclass(frozen=True)
class VendorPayable:
    vendor: str
    items: int
    total: int
    paid: int
    unpaid: int
    next_due: date | None


def _group(items, key):
    out: dict = {}
    for i in items:
        out.setdefault(key(i), []).append(i)
    return out


def event_rows(summaries, budgets_by_event, expenses, quotes) -> list[EventRow]:
    exp_by, quo_by = _group(expenses, lambda x: x.event_id), _group(quotes, lambda q: q.event_id)
    rows = []
    for ev in summaries:
        s = budget_logic.summarize(budgets_by_event.get(ev.id, {}), exp_by.get(ev.id, []), quo_by.get(ev.id, []))
        f = ev.fin
        rows.append(EventRow(ev, f.contract, f.received, f.balance_due, s.total_budget, s.total_actual,
                             s.total_committed, s.remaining if s.total_budget else None, f.profit, f.margin))
    return rows


def budget_vs_actual(summaries, budgets_by_event, expenses, quotes) -> list[tuple]:
    """[(event, CategoryLine), ...] for every category that has a budget or any spend."""
    exp_by, quo_by = _group(expenses, lambda x: x.event_id), _group(quotes, lambda q: q.event_id)
    out = []
    for ev in summaries:
        for line in budget_logic.category_lines(budgets_by_event.get(ev.id, {}), exp_by.get(ev.id, []),
                                                quo_by.get(ev.id, [])):
            out.append((ev, line))
    return out


def vendor_payables(summaries, expenses, include_inactive: bool = False) -> list[VendorPayable]:
    """Spend per vendor across active events, with how much is still unpaid and the next due date."""
    active = {e.id for e in summaries if include_inactive or e.is_active}
    groups = _group([x for x in expenses if x.event_id in active and x.vendor.strip()],
                    lambda x: x.vendor.strip().lower())
    rows = []
    for items in groups.values():
        unpaid_items = [x for x in items if not x.paid]
        dues = [x.due_date for x in unpaid_items if x.due_date]
        rows.append(VendorPayable(items[0].vendor.strip(), len(items), sum(x.amount for x in items),
                                  sum(x.amount for x in items if x.paid), sum(x.amount for x in unpaid_items),
                                  min(dues) if dues else None))
    return sorted(rows, key=lambda r: (-r.unpaid, r.vendor.lower()))
