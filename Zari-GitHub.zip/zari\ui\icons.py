"""Gold line icons drawn with QPainter, so no image files are needed."""
from __future__ import annotations

import math
from functools import lru_cache

from PySide6.QtCore import QPointF, QRectF, Qt
from PySide6.QtGui import QColor, QIcon, QPainter, QPainterPath, QPen, QPixmap

from zari.ui import theme

SIZE = 48  # drawn at 2x then scaled for crisp rendering


def _pen(color: QColor, w: float = 3.0) -> QPen:
    p = QPen(color, w)
    p.setCapStyle(Qt.PenCapStyle.RoundCap)
    p.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
    return p


def _dashboard(p, c):
    for x, y in ((8, 8), (27, 8), (8, 27), (27, 27)):
        p.drawRoundedRect(QRectF(x, y, 13, 13), 3, 3)


def _events(p, c):  # lotus
    cx, cy = 24, 30
    for ang in (-50, 0, 50):
        p.save()
        p.translate(cx, cy)
        p.rotate(ang)
        path = QPainterPath()
        path.moveTo(0, 0)
        path.cubicTo(-9, -8, -7, -20, 0, -24)
        path.cubicTo(7, -20, 9, -8, 0, 0)
        p.drawPath(path)
        p.restore()
    p.drawLine(QPointF(10, 38), QPointF(38, 38))


def _calendar(p, c):
    p.drawRoundedRect(QRectF(8, 11, 32, 29), 5, 5)
    p.drawLine(QPointF(8, 20), QPointF(40, 20))
    p.drawLine(QPointF(16, 6), QPointF(16, 14))
    p.drawLine(QPointF(32, 6), QPointF(32, 14))
    for x, y in ((15, 27), (24, 27), (33, 27), (15, 34), (24, 34)):
        p.drawPoint(QPointF(x, y))


def _scan(p, c):  # receipt with scan line
    path = QPainterPath()
    path.moveTo(11, 6)
    path.lineTo(37, 6)
    path.lineTo(37, 42)
    for i in range(4):
        x = 37 - (i + 1) * 6.5
        path.lineTo(x + 3.25, 38)
        path.lineTo(x, 42)
    path.lineTo(11, 42)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(17, 15), QPointF(31, 15))
    p.drawLine(QPointF(17, 22), QPointF(31, 22))
    p.drawLine(QPointF(17, 29), QPointF(25, 29))


def _pin(p, c):
    path = QPainterPath()
    path.moveTo(24, 43)
    path.cubicTo(10, 28, 9, 22, 9, 19)
    path.arcTo(QRectF(9, 5, 30, 28), 180, -180)
    path.cubicTo(39, 22, 38, 28, 24, 43)
    p.drawPath(path)
    p.drawEllipse(QPointF(24, 19), 5, 5)


def _edit(p, c):
    path = QPainterPath()
    path.moveTo(10, 38)
    path.lineTo(13, 28)
    path.lineTo(32, 9)
    path.lineTo(39, 16)
    path.lineTo(20, 35)
    path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(27, 14), QPointF(34, 21))


def _trash(p, c):
    p.drawLine(QPointF(8, 13), QPointF(40, 13))
    p.drawLine(QPointF(18, 13), QPointF(18, 8))
    p.drawLine(QPointF(18, 8), QPointF(30, 8))
    p.drawLine(QPointF(30, 8), QPointF(30, 13))
    path = QPainterPath()
    path.moveTo(12, 13)
    path.lineTo(14, 41)
    path.lineTo(34, 41)
    path.lineTo(36, 13)
    p.drawPath(path)
    p.drawLine(QPointF(20, 20), QPointF(20, 34))
    p.drawLine(QPointF(28, 20), QPointF(28, 34))


def _plus(p, c):
    p.drawLine(QPointF(24, 10), QPointF(24, 38))
    p.drawLine(QPointF(10, 24), QPointF(38, 24))


def _left(p, c):
    p.drawPolyline([QPointF(30, 10), QPointF(16, 24), QPointF(30, 38)])


def _right(p, c):
    p.drawPolyline([QPointF(18, 10), QPointF(32, 24), QPointF(18, 38)])


def _close(p, c):
    p.drawLine(QPointF(12, 12), QPointF(36, 36))
    p.drawLine(QPointF(36, 12), QPointF(12, 36))


def _download(p, c):
    p.drawLine(QPointF(24, 8), QPointF(24, 30))
    p.drawPolyline([QPointF(14, 22), QPointF(24, 32), QPointF(34, 22)])
    p.drawLine(QPointF(10, 40), QPointF(38, 40))


def _clip(p, c):  # paperclip (attachment)
    path = QPainterPath()
    path.moveTo(32, 14)
    path.lineTo(16, 30)
    path.arcTo(QRectF(10, 24, 12, 12), 135, 180)
    path.lineTo(34, 18)
    path.arcTo(QRectF(28, 10, 12, 12), 315, 180)
    path.lineTo(18, 36)
    p.drawPath(path)


def _check(p, c):
    p.drawPolyline([QPointF(10, 25), QPointF(20, 35), QPointF(38, 13)])


def _sun(p, c):  # backup / save
    p.drawRoundedRect(QRectF(8, 8, 32, 32), 5, 5)
    p.drawRect(QRectF(15, 8, 18, 11))
    p.drawRect(QRectF(15, 28, 18, 12))


def _restore(p, c):
    p.drawArc(QRectF(9, 9, 30, 30), 40 * 16, 270 * 16)
    p.drawPolyline([QPointF(35, 5), QPointF(37, 14), QPointF(28, 13)])


def _mandala(p, c):
    cx = cy = 24
    for i in range(8):
        p.save()
        p.translate(cx, cy)
        p.rotate(i * 45)
        path = QPainterPath()
        path.moveTo(0, -6)
        path.cubicTo(-6, -12, -5, -19, 0, -22)
        path.cubicTo(5, -19, 6, -12, 0, -6)
        p.drawPath(path)
        p.restore()
    p.drawEllipse(QPointF(cx, cy), 4, 4)


def _vendors(p, c):  # shop front
    p.drawLine(QPointF(8, 20), QPointF(8, 40))
    p.drawLine(QPointF(40, 20), QPointF(40, 40))
    p.drawLine(QPointF(8, 40), QPointF(40, 40))
    path = QPainterPath()
    path.moveTo(6, 20); path.lineTo(10, 8); path.lineTo(38, 8); path.lineTo(42, 20)
    p.drawPath(path)
    for x in (6, 18, 30):
        p.drawArc(QRectF(x, 14, 12, 12), 180 * 16, 180 * 16)
    p.drawRect(QRectF(20, 29, 8, 11))


def _reports(p, c):  # bar chart
    p.drawLine(QPointF(8, 8), QPointF(8, 40))
    p.drawLine(QPointF(8, 40), QPointF(42, 40))
    for x, h in ((14, 12), (23, 22), (32, 17)):
        p.drawRect(QRectF(x, 40 - h, 6, h))


def _guests(p, c):  # two people
    p.drawEllipse(QPointF(18, 15), 6, 6)
    p.drawArc(QRectF(7, 24, 22, 20), 0, 180 * 16)
    p.drawEllipse(QPointF(33, 18), 5, 5)
    p.drawArc(QRectF(26, 26, 18, 16), 0, 180 * 16)


def _sliders(p, c):  # scenario planning
    for y, x in ((14, 18), (24, 30), (34, 14)):
        p.drawLine(QPointF(8, y), QPointF(40, y))
        p.setBrush(QColor(theme.BURGUNDY_DEEP))
        p.drawEllipse(QPointF(x, y), 4.5, 4.5)
        p.setBrush(Qt.BrushStyle.NoBrush)


def _file(p, c):
    path = QPainterPath()
    path.moveTo(12, 6); path.lineTo(29, 6); path.lineTo(38, 15); path.lineTo(38, 42); path.lineTo(12, 42)
    path.closeSubpath()
    p.drawPath(path)
    p.drawPolyline([QPointF(29, 6), QPointF(29, 15), QPointF(38, 15)])
    p.drawLine(QPointF(18, 25), QPointF(32, 25))
    p.drawLine(QPointF(18, 32), QPointF(32, 32))


def _expand(p, c):  # four outward corners
    for sx, sy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        cx, cy = (8 if sx > 0 else 40), (8 if sy > 0 else 40)
        p.drawPolyline([QPointF(cx + 11 * sx, cy), QPointF(cx, cy), QPointF(cx, cy + 11 * sy)])


def _collapse(p, c):  # four inward corners
    for sx, sy in ((1, 1), (-1, 1), (1, -1), (-1, -1)):
        cx, cy = (19 if sx > 0 else 29), (19 if sy > 0 else 29)
        p.drawPolyline([QPointF(cx - 11 * sx, cy), QPointF(cx, cy), QPointF(cx, cy - 11 * sy)])


def _alert(p, c):
    path = QPainterPath()
    path.moveTo(24, 7); path.lineTo(42, 39); path.lineTo(6, 39); path.closeSubpath()
    p.drawPath(path)
    p.drawLine(QPointF(24, 18), QPointF(24, 29))
    p.drawPoint(QPointF(24, 34))


_DRAW = {
    "dashboard": _dashboard, "events": _events, "calendar": _calendar, "scan": _scan, "pin": _pin,
    "edit": _edit, "trash": _trash, "plus": _plus, "left": _left, "right": _right, "close": _close,
    "download": _download, "clip": _clip, "check": _check, "backup": _sun, "restore": _restore,
    "mandala": _mandala, "vendors": _vendors, "reports": _reports, "guests": _guests,
    "sliders": _sliders, "file": _file, "alert": _alert, "expand": _expand, "collapse": _collapse,
}


@lru_cache(maxsize=256)
def icon(name: str, color: str = theme.GOLD) -> QIcon:
    pm = QPixmap(SIZE, SIZE)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c = QColor(color)
    p.setPen(_pen(c))
    p.setBrush(Qt.BrushStyle.NoBrush)
    _DRAW[name](p, c)
    p.end()
    return QIcon(pm)


def pixmap(name: str, size: int, color: str = theme.GOLD):
    return icon(name, color).pixmap(size, size)
