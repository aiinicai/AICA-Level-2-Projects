"""Cards shown inside the event panel: Budget, Vendor quotes, Guests, Scenario planning."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QGridLayout, QHBoxLayout, QLineEdit, QProgressBar, QVBoxLayout

from zari.config import EXPENSE_CATEGORIES
from zari.logic import budget as budget_logic
from zari.logic.money import format_aed, format_bp, format_input, parse_percent
from zari.logic.validation import ValidationError, validate_budget_amount
from zari.ui import theme
from zari.ui.widgets import Badge, BudgetChart, Card, divider, make_button, make_label, set_label_color

STATUS_COLOR = {"none": theme.IVORY_MUTED, "ok": theme.SUCCESS, "warning": theme.WARNING, "over": theme.DANGER}
STATUS_TEXT = {"none": "No budget", "ok": "On track", "warning": "Near limit", "over": "Over budget"}


class BudgetCard(Card):
    """Budget per category with estimated / committed / actual side by side. Edits save as you leave a field."""

    def __init__(self, ctx, event, on_saved):
        super().__init__(shadow=False)
        self.ctx, self.event_id, self._on_saved = ctx, event.id, on_saved
        self._widgets: dict[str, dict] = {}
        v = QVBoxLayout(self)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(8)
        head = QHBoxLayout()
        head.addWidget(make_label("Budget", "h3"))
        self.badge = Badge("", theme.IVORY_MUTED)
        head.addWidget(self.badge)
        head.addStretch(1)
        v.addLayout(head)
        self.caption = make_label("", "small", wrap=True)
        v.addWidget(self.caption)

        grid = QGridLayout()
        grid.setHorizontalSpacing(8)
        grid.setVerticalSpacing(5)
        for c, (title, tip) in enumerate((("Category", ""), ("Budget (AED)", "What you plan to spend"),
                                          ("Committed", "Quotes you selected, not yet recorded as expenses"),
                                          ("Actual", "Expenses recorded so far"), ("Left", "Budget - actual - committed"))):
            lab = make_label(title, "eyebrow")
            lab.setToolTip(tip)
            grid.addWidget(lab, 0, c)
        self._budgets = ctx.repo.get_budgets(event.id)
        for r, cat in enumerate(EXPENSE_CATEGORIES, 1):
            grid.addWidget(make_label(cat, "body"), r, 0)
            edit = QLineEdit(format_input(self._budgets[cat]) if cat in self._budgets else "")
            edit.setPlaceholderText("-")
            edit.setMaximumWidth(120)
            edit.editingFinished.connect(lambda c=cat: self._save(c))
            grid.addWidget(edit, r, 1)
            committed, actual, left = make_label("", "small"), make_label("", "small"), make_label("", "small")
            for col, w in ((2, committed), (3, actual), (4, left)):
                w.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                grid.addWidget(w, r, col)
            self._widgets[cat] = {"edit": edit, "committed": committed, "actual": actual, "left": left}
        grid.setColumnStretch(0, 2)
        grid.setColumnStretch(2, 2)
        grid.setColumnStretch(3, 2)
        grid.setColumnStretch(4, 2)
        v.addLayout(grid)

        v.addWidget(make_label("Budget vs actual", "eyebrow"))
        self.chart = BudgetChart()
        v.addWidget(self.chart)
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(8)
        v.addWidget(self.bar)
        self.totals = make_label("", "small", wrap=True)
        v.addWidget(self.totals)
        v.addWidget(divider())
        cont = QHBoxLayout()
        cont.addWidget(make_label("Contingency reserve %", "small"))
        self.contingency = QLineEdit(format_bp(event.contingency_bp).rstrip("%") if event.contingency_bp else "")
        self.contingency.setPlaceholderText("0")
        self.contingency.setMaximumWidth(80)
        self.contingency.setToolTip("A cushion held back from the budget for surprises")
        self.contingency.editingFinished.connect(self._save_contingency)
        cont.addWidget(self.contingency)
        self.cont_note = make_label("", "small")
        cont.addWidget(self.cont_note, 1)
        v.addLayout(cont)
        self.error = make_label("", "small", color=theme.DANGER, wrap=True)
        self.error.hide()
        v.addWidget(self.error)
        self.update_numbers()

    # ---- numbers --------------------------------------------------------------------
    def update_numbers(self) -> None:
        repo = self.ctx.repo
        ev = repo.get_event(self.event_id)
        summary = budget_logic.summarize(repo.get_budgets(self.event_id), repo.list_expenses(self.event_id),
                                         repo.list_quotes(self.event_id), ev.contingency_bp)
        lines = {l.category: l for l in summary.lines}
        self.chart.set_rows([(l.category, l.budget, l.actual, l.committed) for l in summary.lines])
        for cat, w in self._widgets.items():
            l = lines.get(cat)
            w["committed"].setText(format_aed(l.committed) if l and l.committed else "-")
            w["actual"].setText(format_aed(l.actual) if l and l.actual else "-")
            if l and (l.budget or l.projected):
                w["left"].setText(format_aed(l.remaining) if l.budget else "no budget")
                set_label_color(w["left"], STATUS_COLOR[l.status])
            else:
                w["left"].setText("-")
                set_label_color(w["left"], theme.IVORY_MUTED)
        self.badge.setText(STATUS_TEXT[summary.status])
        color = STATUS_COLOR[summary.status]
        self.badge.setStyleSheet(
            f"background: {theme.rgba(color, 0.16)}; color: {color}; border: 1px solid {theme.rgba(color, 0.7)};"
            "border-radius: 10px; padding: 2px 9px;")
        if summary.total_budget:
            self.bar.setValue(min(1000, int(summary.total_projected / summary.total_budget * 1000)))
            self.caption.setText(
                f"Budget {format_aed(summary.total_budget)} · actual {format_aed(summary.total_actual)} + committed "
                f"{format_aed(summary.total_committed)} = {format_aed(summary.total_projected)} projected.")
            left = summary.remaining
            self.totals.setText(
                f"{format_aed(left)} left" if left >= 0 else f"Over budget by {format_aed(-left)}")
            set_label_color(self.totals, STATUS_COLOR["ok" if left >= 0 else "over"])
        else:
            self.bar.setValue(0)
            self.caption.setText("Set a budget per category to track estimated vs committed vs actual costs. "
                                 "Selected vendor quotes count as committed until you record them as expenses.")
            self.totals.setText("")
        if summary.contingency:
            self.cont_note.setText(f"= {format_aed(summary.contingency)} held back; "
                                   f"{format_aed(summary.remaining_after_contingency)} left after it")
        else:
            self.cont_note.setText("")
        if summary.total_quoted:
            self.cont_note.setText((self.cont_note.text() + "   " if self.cont_note.text() else "") +
                                   f"Open quotes (cheapest): {format_aed(summary.total_quoted)}")

    # ---- saving ---------------------------------------------------------------------
    def _save(self, cat: str) -> None:
        edit = self._widgets[cat]["edit"]
        try:
            fils = validate_budget_amount(edit.text())
        except ValidationError as exc:
            self._flag(edit, str(exc))
            return
        self._flag(edit, None)
        if fils == self.ctx.repo.get_budgets(self.event_id).get(cat, 0):
            return
        self.ctx.repo.set_budget(self.event_id, cat, fils)
        edit.setText(format_input(fils) if fils else "")
        self._on_saved()
        self.update_numbers()
        self.ctx.data_changed()

    def _save_contingency(self) -> None:
        try:
            bp = parse_percent(self.contingency.text(), 0, 100)
        except ValueError as exc:
            self._flag(self.contingency, str(exc))
            return
        self._flag(self.contingency, None)
        if bp == self.ctx.repo.get_event(self.event_id).contingency_bp:
            return
        self.ctx.repo.set_contingency(self.event_id, bp)
        self._on_saved()
        self.update_numbers()
        self.ctx.data_changed()

    def _flag(self, widget, message: str | None) -> None:
        widget.setProperty("invalid", bool(message))
        widget.style().unpolish(widget)
        widget.style().polish(widget)
        self.error.setText(message or "")
        self.error.setVisible(bool(message))


def _tool_card(title: str, summary: str, button_text: str, icon: str, on_click, note: str = "") -> Card:
    card = Card(shadow=False)
    h = QHBoxLayout(card)
    h.setContentsMargins(18, 14, 18, 14)
    col = QVBoxLayout()
    col.setSpacing(2)
    col.addWidget(make_label(title, "h3"))
    col.addWidget(make_label(summary, "small", wrap=True))
    if note:
        col.addWidget(make_label(note, "small", color=theme.WARNING, wrap=True))
    h.addLayout(col, 1)
    b = make_button(button_text, icon_name=icon)
    b.clicked.connect(on_click)
    h.addWidget(b, 0, Qt.AlignmentFlag.AlignVCenter)
    return card


def quotes_card(ctx, event, on_open) -> Card:
    quotes = ctx.repo.list_quotes(event.id)
    reqs = {q.requirement.strip().lower() for q in quotes}
    selected = [q for q in quotes if q.status == "Selected"]
    committed = sum(q.amount for q in selected if not q.expense_id)
    summary = (f"{len(quotes)} quotation(s) for {len(reqs)} requirement(s) · {len(selected)} selected"
               + (f" · {format_aed(committed)} committed" if committed else "")) if quotes else \
        "Record what each vendor offered and compare them side by side."
    return _tool_card("Vendor quotes", summary, "Compare quotes", "vendors", on_open)


def guests_card(ctx, event, on_open) -> Card:
    s = ctx.repo.guest_stats(event.id)
    if s["parties"]:
        summary = (f"{s['parties']} invitations · {s['confirmed']} confirmed ({s['heads_confirmed']} people) · "
                   f"{s['pending']} pending · {s['declined']} declined · expected {event.guests:,}")
        note = "Confirmed headcount is above the expected guest count." if s["heads_confirmed"] > event.guests else ""
    else:
        summary, note = "Track invitations and RSVPs. Import a list from Excel or add guests one by one.", ""
    return _tool_card("Guests & RSVP", summary, "Manage guests", "guests", on_open, note)


def scenarios_card(ctx, event, on_open) -> Card:
    n = len(ctx.repo.list_scenarios(event.id))
    summary = (f"{n} saved scenario(s). " if n else "") + \
        "Test guest count, price changes and contingency without touching the real event."
    return _tool_card("Scenario planning", summary, "Open planner", "sliders", on_open)
