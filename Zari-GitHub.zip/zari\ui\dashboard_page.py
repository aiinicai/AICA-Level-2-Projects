"""Home page: arch header, five live stat cards, upcoming events, chart, tasks, settings strip."""
from __future__ import annotations

from datetime import date, datetime

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QButtonGroup, QFileDialog, QFrame, QGridLayout, QHBoxLayout, QScrollArea, QSizePolicy, QVBoxLayout, QWidget,
)

from zari.config import db_path
from zari.db.database import DatabaseError
from zari.logic import alerts as alerts_logic
from zari.logic import finance
from zari.logic.finance import countdown_text, format_margin, margin_level
from zari.logic.money import format_aed
from zari.ui import icons, theme
from zari.ui.dialogs import confirm, info
from zari.ui.tasks_panel import TasksPanel
from zari.ui.widgets import (
    ArchHeader, BarChart, Card, ClickableFrame, Ornament, StatCard, clear_layout, make_button, make_label,
    sample_badge, set_label_color, shrinkable, status_badge,
)


class DashboardPage(QScrollArea):
    view_all_events = Signal()

    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root = QWidget()
        root.setObjectName("PageRoot")
        self.setWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(36, 26, 36, 36)
        lay.setSpacing(22)

        self.arch = ArchHeader()
        lay.addWidget(self.arch)

        # stat cards
        stats = QGridLayout()
        stats.setSpacing(16)
        self.cards = {
            "next": StatCard("Next 30 days"), "revenue": StatCard("Revenue this month"),
            "outstanding": StatCard("Outstanding"), "margin": StatCard("Avg. margin"),
            "tasks": StatCard("Pending tasks"),
        }
        for i, c in enumerate(self.cards.values()):
            stats.addWidget(c, 0, i)
            stats.setColumnStretch(i, 1)
        lay.addLayout(stats)

        # upcoming + chart
        mid = QHBoxLayout()
        mid.setSpacing(18)
        self.upcoming_card = Card()
        self.upcoming_layout = QVBoxLayout(self.upcoming_card)
        self.upcoming_layout.setContentsMargins(22, 20, 22, 20)
        self.upcoming_layout.setSpacing(10)
        mid.addWidget(self.upcoming_card, 5)

        self.chart_card = Card()
        cl = QVBoxLayout(self.chart_card)
        cl.setContentsMargins(22, 20, 22, 16)
        cl.setSpacing(8)
        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Last six months", "eyebrow"))
        self.chart_title = make_label("Revenue", "h3")
        titles.addWidget(self.chart_title)
        head.addLayout(titles)
        head.addStretch(1)
        group = QButtonGroup(self)
        self.mode = "Revenue"
        self.mode_buttons = {}
        for name in ("Revenue", "Profit"):
            b = make_button(name, "pill")
            b.setCheckable(True)
            b.setChecked(name == "Revenue")
            b.clicked.connect(lambda _=False, n=name: self._set_mode(n))
            group.addButton(b)
            self.mode_buttons[name] = b
            head.addWidget(b)
        cl.addLayout(head)
        self.chart = BarChart()
        cl.addWidget(self.chart, 1)
        self.chart_note = make_label("", "small", wrap=True)
        cl.addWidget(self.chart_note)
        mid.addWidget(self.chart_card, 6)
        lay.addLayout(mid)

        self.alerts_card = Card()
        self.alerts_layout = QVBoxLayout(self.alerts_card)
        self.alerts_layout.setContentsMargins(22, 18, 22, 18)
        self.alerts_layout.setSpacing(8)
        lay.addWidget(self.alerts_card)

        self.tasks = TasksPanel(ctx)
        lay.addWidget(self.tasks)
        lay.addWidget(self._settings_strip())
        lay.addStretch(1)

    # ---- settings strip -------------------------------------------------------------
    def _settings_strip(self) -> Card:
        card = Card(shadow=False)
        outer = QVBoxLayout(card)
        outer.setContentsMargins(22, 14, 22, 14)
        outer.setSpacing(10)
        row = QHBoxLayout()
        row.setSpacing(10)
        outer.addLayout(row)
        row.addWidget(_pixmap_label("mandala", 26))
        text = QVBoxLayout()
        text.setSpacing(0)
        text.addWidget(make_label("Your data is saved on this device", "body"))
        self.path_label = make_label(f"Stored in {db_path().parent}. Nothing is sent online.", "small")
        self.path_label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.path_label.setToolTip(str(db_path().parent))
        text.addWidget(self.path_label)
        row.addLayout(text, 1)
        self.sample_note = make_label("", "small", color=theme.ROSE)
        row.addWidget(self.sample_note)
        backup = make_button("Backup", icon_name="backup", tooltip="Save a copy of all your data")
        backup.clicked.connect(self._backup)
        restore = make_button("Restore", icon_name="restore", tooltip="Replace current data with a backup file")
        restore.clicked.connect(self._restore)
        self.remove_btn = make_button("Remove sample data", tooltip="Delete only the example events and tasks")
        self.remove_btn.clicked.connect(self._remove_samples)
        reset = make_button("Reset demo data", "danger", tooltip="Re-create the example events and tasks")
        reset.clicked.connect(self._reset_demo)
        buttons = QHBoxLayout()
        buttons.setSpacing(10)
        buttons.addStretch(1)
        for b in (backup, restore, self.remove_btn, reset):
            buttons.addWidget(b)
        outer.addLayout(buttons)
        return card

    def _backup(self) -> None:
        name = f"zari-backup-{date.today():%Y%m%d}.db"
        path, _ = QFileDialog.getSaveFileName(self.window(), "Save a backup", name, "Zari backup (*.db)")
        if not path:
            return
        try:
            self.ctx.repo.db.backup_to(path)
        except Exception as exc:  # disk full, permission, locked file...
            info(self.window(), "Backup failed", str(exc))
            return
        self.ctx.notify(f"Backup saved to {path}")

    def _restore(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self.window(), "Choose a backup to restore", "", "Zari backup (*.db)")
        if not path:
            return
        if not confirm(self.window(), "Restore from this backup?",
                       "Your current data will be replaced by the backup. A safety copy of your current data "
                       "is saved automatically first.", action="Restore", danger=True):
            return
        try:
            safety = self.ctx.repo.db.restore_from(path)
        except DatabaseError as exc:
            info(self.window(), "Could not restore", str(exc))
            return
        self.ctx.data_changed()
        info(self.window(), "Backup restored", f"Your previous data was kept at:\n{safety}")

    def _reset_demo(self) -> None:
        if confirm(self.window(), "Reset demo data?",
                   "This re-creates the sample events, payments and tasks. Your own events and tasks are not "
                   "touched. Any edits you made to sample records (including payments added to them) are replaced.",
                   action="Reset demo data"):
            self.ctx.repo.seed_sample_data(self.ctx.today)
            self.ctx.data_changed("Demo data reset")

    def _remove_samples(self) -> None:
        if confirm(self.window(), "Remove sample data?",
                   "Only the example events and tasks are deleted (with their payments and expenses). "
                   "Your own records are not touched.", action="Remove"):
            self.ctx.repo.remove_sample_data()
            self.ctx.data_changed("Sample data removed")

    # ---- chart ----------------------------------------------------------------------
    def _set_mode(self, mode: str) -> None:
        self.mode = mode
        self.refresh()

    # ---- refresh --------------------------------------------------------------------
    def refresh(self) -> None:
        repo, today = self.ctx.repo, self.ctx.today
        events, payments, tasks = repo.list_events(), repo.list_payments(), repo.list_tasks()
        s = finance.dashboard_stats(events, payments, tasks, today)

        self.arch.set_texts(
            finance.greeting(datetime.now().hour), f"{today:%A, %d %B %Y}   ·   {s.next_30_days} event{'s' if s.next_30_days != 1 else ''} "
                       f"in the next 30 days")

        c = self.cards
        c["next"].set(str(s.next_30_days), "events, not cancelled")
        c["revenue"].set(format_aed(s.revenue_this_month), f"{today:%B %Y}")
        c["outstanding"].set(format_aed(s.outstanding), "owed by clients",
                             color=theme.WARNING if s.outstanding else theme.SUCCESS)
        level = margin_level(s.avg_margin)
        c["margin"].set(format_margin(s.avg_margin), {"success": "Healthy", "warning": "Watch closely",
                                                       "danger": "Too low", "muted": "No data yet"}[level],
                        color=theme.LEVEL_COLORS[level], note_color=theme.LEVEL_COLORS[level])
        c["tasks"].set(str(s.pending_tasks), f"{s.overdue_tasks} overdue",
                       note_color=theme.DANGER if s.overdue_tasks else theme.IVORY_MUTED)

        self._refresh_upcoming(events, today)

        labels, revenue, profit = finance.monthly_series(payments, {e.id: e for e in events}, today)
        values, color = (revenue, theme.GOLD) if self.mode == "Revenue" else (profit, theme.ROSE)
        self.chart.set_data(labels, values, color, self.mode)
        self.chart_title.setText(f"{self.mode} by month")
        self.chart_note.setText(
            f"{self.mode} total over six months: {format_aed(sum(values))}"
            + ("   ·   profit = each payment × its event's margin" if self.mode == "Profit" else
               "   ·   payments received, by payment date"))

        self._refresh_alerts(events, today)
        self.tasks.refresh()
        has_sample = repo.has_sample_data()
        self.remove_btn.setVisible(has_sample)
        self.sample_note.setText("Showing sample data" if has_sample else "")

    def _refresh_alerts(self, events, today) -> None:
        repo = self.ctx.repo
        items = alerts_logic.build_alerts(events, repo.list_all_expenses(), repo.list_all_budgets(),
                                          repo.list_all_quotes(), today, limit=8)
        lay = self.alerts_layout
        clear_layout(lay)
        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Needs attention", "eyebrow"))
        titles.addWidget(make_label("Alerts", "h3"))
        head.addLayout(titles)
        head.addStretch(1)
        head.addWidget(make_label(f"{len(items)} item{'s' if len(items) != 1 else ''}" if items else "", "small"))
        lay.addLayout(head)
        if not items:
            lay.addWidget(make_label("All clear: no overdue vendor payments, budget overruns or expiring quotes.",
                                     "muted", color=theme.SUCCESS))
            return
        colors = {"danger": theme.DANGER, "warning": theme.WARNING, "info": theme.ROSE}
        for a in items:
            row = ClickableFrame("AlertRow", overdue=a.level == "danger")
            if a.event_id is not None:
                row.clicked.connect(lambda eid=a.event_id: self.ctx.event_requested.emit(eid))
            h = QHBoxLayout(row)
            h.setContentsMargins(14, 8, 14, 8)
            h.setSpacing(10)
            dot = make_label("")
            dot.setFixedSize(10, 10)
            dot.setStyleSheet(f"background: {colors[a.level]}; border-radius: 5px;")
            h.addWidget(dot)
            h.addWidget(shrinkable(make_label(a.text, "body")), 1)
            lay.addWidget(row)

    def _refresh_upcoming(self, events, today) -> None:
        lay = self.upcoming_layout
        clear_layout(lay)
        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Coming up", "eyebrow"))
        titles.addWidget(make_label("Upcoming events", "h3"))
        head.addLayout(titles)
        head.addStretch(1)
        view_all = make_button("View all", "link")
        view_all.clicked.connect(self.view_all_events.emit)
        head.addWidget(view_all, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(head)
        lay.addWidget(Ornament())

        items = finance.upcoming_events(events, today, 6)
        if not items:
            lay.addWidget(make_label("No upcoming events. Add one from the Events page.", "muted"))
        for e in items:
            row = ClickableFrame("EventRow")
            row.clicked.connect(lambda eid=e.id: self.ctx.event_requested.emit(eid))
            v = QVBoxLayout(row)
            v.setContentsMargins(14, 10, 14, 10)
            v.setSpacing(3)
            top = QHBoxLayout()
            top.setSpacing(8)
            top.addWidget(shrinkable(make_label(e.name, "body")), 1)
            if e.is_sample:
                top.addWidget(sample_badge())
            top.addWidget(make_label(countdown_text(e.date, today), "body", color=theme.GOLD))
            v.addLayout(top)
            bottom = QHBoxLayout()
            bottom.setSpacing(6)
            bottom.addWidget(make_label(f"{e.date:%a, %d %b %Y}", "small"))
            bottom.addWidget(_pixmap_label("pin", 14))
            bottom.addWidget(shrinkable(make_label(e.venue, "small")), 1)
            bottom.addWidget(status_badge(e.status))
            v.addLayout(bottom)
            lay.addWidget(row)
        lay.addStretch(1)


def _pixmap_label(name: str, size: int):
    lab = make_label("")
    lab.setPixmap(icons.pixmap(name, size))
    lab.setFixedSize(size + 2, size + 2)
    return lab
