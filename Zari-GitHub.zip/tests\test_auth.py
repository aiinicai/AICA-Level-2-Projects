import pytest

from zari import auth, config
from zari.auth import AccountStore, AuthError
from zari.db.database import Database
from zari.db.repository import Repository
from zari.logic.validation import validate_event


@pytest.fixture()
def store(data_dir):
    clock = {"t": 1000.0}
    s = AccountStore(data_dir, clock=lambda: clock["t"])
    s.clock = clock
    yield s
    s.close()


def test_first_account_is_owner_and_login_works(store):
    a = store.create("Arya", "Arya S", "Sunrise2026")
    assert a.username == "arya" and a.is_owner
    b = store.create("meera", "Meera", "Marigold#77")
    assert not b.is_owner
    assert store.verify("ARYA", "Sunrise2026").display_name == "Arya S"


def test_passwords_are_hashed_not_stored(store):
    store.create("arya", "Arya", "Sunrise2026")
    raw = store.conn.execute("SELECT salt, pw_hash FROM accounts").fetchone()
    assert b"Sunrise2026" not in raw["pw_hash"] and len(raw["salt"]) == 16
    store.create("meera", "Meera", "Sunrise2026")  # same password -> different salt/hash
    hashes = {r["pw_hash"] for r in store.conn.execute("SELECT pw_hash FROM accounts")}
    assert len(hashes) == 2


@pytest.mark.parametrize("username,password", [
    ("ab", "Sunrise2026"), ("bad name", "Sunrise2026"), ("arya", "short1"),
    ("arya", "onlyletters"), ("arya", "12345678"), ("arya123", "arya123"),
])
def test_rejects_weak_or_invalid(store, username, password):
    with pytest.raises(AuthError):
        store.create(username, "x", password)


def test_duplicate_username_rejected(store):
    store.create("arya", "A", "Sunrise2026")
    with pytest.raises(AuthError, match="taken"):
        store.create("ARYA", "B", "Another2026")


def test_wrong_password_and_unknown_user_give_same_message(store):
    store.create("arya", "A", "Sunrise2026")
    with pytest.raises(AuthError) as e1:
        store.verify("arya", "wrong-pass1")
    with pytest.raises(AuthError) as e2:
        store.verify("nobody", "whatever1")
    assert str(e1.value) == str(e2.value) == "Wrong username or password."


def test_lockout_after_repeated_failures_then_recovers(store):
    store.create("arya", "A", "Sunrise2026")
    for _ in range(auth.MAX_FAILS):
        with pytest.raises(AuthError):
            store.verify("arya", "bad-pass-1")
    with pytest.raises(AuthError, match="Too many"):
        store.verify("arya", "Sunrise2026")  # even the right password is refused while locked
    store.clock["t"] += auth.LOCK_SECONDS + 1
    assert store.verify("arya", "Sunrise2026").username == "arya"


def test_change_and_reset_password(store):
    owner = store.create("arya", "A", "Sunrise2026")
    other = store.create("meera", "M", "Marigold#77")
    store.change_password("meera", "Marigold#77", "NewSecret9")
    with pytest.raises(AuthError):
        store.verify("meera", "Marigold#77")
    assert store.verify("meera", "NewSecret9")
    with pytest.raises(AuthError):
        store.change_password("meera", "wrong-old-1", "Whatever99")
    store.reset_password(owner, "meera", "ResetByOwner5")
    assert store.verify("meera", "ResetByOwner5")
    with pytest.raises(AuthError, match="owner"):
        store.reset_password(other, "arya", "Hijack12345")


def test_each_user_has_separate_private_data(data_dir):
    try:
        config.set_current_user("arya")
        db_a = Database(config.db_path())
        repo_a = Repository(db_a)
        repo_a.add_event(validate_event("Arya's Wedding", "C", "Wedding", "2026-12-01", "V", 10, "Confirmed", "1000"))

        config.set_current_user("meera")
        db_m = Database(config.db_path())
        repo_m = Repository(db_m)
        assert repo_m.list_events() == []  # Meera cannot see Arya's events
        repo_m.add_event(validate_event("Meera's Gala", "C", "Gala", "2026-12-02", "V", 10, "Confirmed", "2000"))

        assert [e.name for e in repo_a.list_events()] == ["Arya's Wedding"]
        assert config.db_path().parent != (data_dir / "users" / "arya")
        assert (data_dir / "users" / "arya" / "zari.db").is_file()
        assert (data_dir / "users" / "meera" / "zari.db").is_file()
        assert config.invoices_dir().parent.name == "meera" and config.backups_dir().parent.name == "meera"
        db_a.close()
        db_m.close()
    finally:
        config.set_current_user(None)


def test_adopt_legacy_data_moves_old_database(data_dir):
    legacy = Database(data_dir / "zari.db")
    Repository(legacy).add_event(validate_event("Old", "C", "Wedding", "2026-12-01", "V", 10, "Confirmed", "1000"))
    legacy.close()
    (data_dir / "invoices").mkdir()
    (data_dir / "invoices" / "a.png").write_bytes(b"x")
    assert auth.legacy_data_exists(data_dir)
    assert auth.adopt_legacy_data("arya", data_dir)
    assert not auth.legacy_data_exists(data_dir)
    moved = Database(data_dir / "users" / "arya" / "zari.db")
    assert [e.name for e in Repository(moved).list_events()] == ["Old"]
    assert (data_dir / "users" / "arya" / "invoices" / "a.png").is_file()
    moved.close()
