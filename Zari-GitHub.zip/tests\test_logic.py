from datetime import date, datetime, timezone
from types import SimpleNamespace

import pytest

from zari.logic import finance
from zari.logic.calendar_export import build_ics, google_calendar_url
from zari.logic.money import format_aed, format_axis, parse_amount
from zari.logic.validation import ValidationError, validate_event, validate_expense, validate_payment, validate_task


# ---- money -------------------------------------------------------------------------
@pytest.mark.parametrize("text,fils", [
    ("385,000", 38_500_000), ("AED 385,000", 38_500_000), ("1250.50", 125_050),
    ("aed 0.99", 99), ("  12 500 ", 1_250_000),
])
def test_parse_amount_ok(text, fils):
    assert parse_amount(text) == fils


@pytest.mark.parametrize("text", ["", "abc", "-5", "1.234", "12..3", "1e5", "99999999999999"])
def test_parse_amount_rejects(text):
    with pytest.raises(ValueError):
        parse_amount(text)


def test_format_aed():
    assert format_aed(38_500_000) == "AED 385,000"
    assert format_aed(125_050) == "AED 1,250.50"
    assert format_aed(-100_000) == "-AED 1,000"
    assert format_aed(0) == "AED 0"


def test_no_float_drift():
    total = sum(parse_amount("0.10") for _ in range(1000))
    assert total == 10_000 and format_aed(total) == "AED 100"


def test_format_axis():
    assert format_axis(12_000_000) == "120k"
    assert format_axis(50_000) == "500"
    assert format_axis(150_000_000) == "1.5M"


# ---- finance -----------------------------------------------------------------------
def test_financials_basic():
    f = finance.compute_financials(38_500_000, 25_000_000, 28_700_000, 11_700_000, "Confirmed")
    assert f.balance_due == 13_500_000
    assert f.profit == 9_800_000
    assert round(f.margin, 1) == 25.5
    assert round(f.progress, 3) == round(25 / 38.5, 3)


def test_cancelled_event_has_no_balance_due():
    assert finance.compute_financials(500_000, 100_000, 0, 0, "Cancelled").balance_due == 0


def test_overpaid_never_negative_balance():
    f = finance.compute_financials(100_000, 150_000, 0, 0, "Confirmed")
    assert f.balance_due == 0 and f.progress == 1.0


def test_zero_contract():
    f = finance.compute_financials(0, 0, 5_000, 0, "Enquiry")
    assert f.margin is None and finance.margin_level(f.margin) == "muted"


@pytest.mark.parametrize("m,level", [(35, "success"), (20.01, "success"), (20, "warning"),
                                     (10, "warning"), (9.99, "danger"), (-4, "danger")])
def test_margin_levels(m, level):
    assert finance.margin_level(m) == level


def test_countdown():
    t = date(2026, 10, 21)
    assert finance.countdown_text(t, t) == "Today"
    assert finance.countdown_text(date(2026, 10, 22), t) == "Tomorrow"
    assert finance.countdown_text(date(2026, 10, 30), t) == "in 9 days"
    assert finance.countdown_text(date(2026, 10, 11), t) == "10 days ago"


@pytest.mark.parametrize("hour,text", [
    (0, "Good night"), (4, "Good night"), (5, "Good morning"), (11, "Good morning"),
    (12, "Good afternoon"), (16, "Good afternoon"), (17, "Good evening"), (20, "Good evening"),
    (21, "Good night"), (23, "Good night"),
])
def test_greeting_by_hour(hour, text):
    assert finance.greeting(hour) == text


def test_months_back_wraps_year():
    assert finance.months_back(date(2026, 2, 10), 6) == [
        (2025, 9), (2025, 10), (2025, 11), (2025, 12), (2026, 1), (2026, 2)]


# ---- dashboard stats on sample data -------------------------------------------------
def test_dashboard_stats_from_sample_data(repo):
    today = date(2026, 10, 21)
    repo.seed_sample_data(today)
    events, payments, tasks = repo.list_events(), repo.list_payments(), repo.list_tasks()
    stats = finance.dashboard_stats(events, payments, tasks, today)

    active = [e for e in events if e.status != "Cancelled"]
    in_window = [e for e in active if 0 <= (e.date - today).days <= 30]
    assert stats.next_30_days == len(in_window) > 0
    assert stats.outstanding == sum(max(0, e.contract_value - e.received) for e in active)
    assert all(e.status != "Cancelled" for e in finance.upcoming_events(events, today))
    pending = [t for t in tasks if not t.done]
    assert stats.pending_tasks == len(pending)
    assert stats.overdue_tasks == sum(1 for t in pending if t.due < today) > 0

    labels, revenue, profit = finance.monthly_series(payments, {e.id: e for e in events}, today)
    assert len(labels) == len(revenue) == len(profit) == 6
    this_month = sum(p.amount for p in payments if (p.date.year, p.date.month) == (2026, 10))
    assert revenue[-1] == this_month == stats.revenue_this_month


def test_profit_is_payment_times_margin():
    assert finance.share_of_payment(10_000_000, 25.0) == 2_500_000
    assert finance.share_of_payment(10_000_000, None) == 0


# ---- validation --------------------------------------------------------------------
def good_event(**over):
    base = dict(name="A", client="B", type_="Wedding", date_="2026-12-01", venue="V",
                guests=100, status="Confirmed", contract="100,000")
    base.update(over)
    return base


def test_validate_event_ok():
    data = validate_event(**good_event())
    assert data["contract_value"] == 10_000_000 and data["date"] == "2026-12-01"


def test_validate_event_collects_all_errors():
    with pytest.raises(ValidationError) as exc:
        validate_event(**good_event(name=" ", client="", venue="", guests=0, contract="x", date_="nope"))
    assert set(exc.value.errors) == {"name", "client", "venue", "guests", "contract", "date"}


def test_validate_payment_and_expense_and_task():
    assert validate_payment("5,000", date(2026, 1, 1), "Deposit")["amount"] == 500_000
    with pytest.raises(ValidationError):
        validate_payment("0", date(2026, 1, 1), "Deposit")
    with pytest.raises(ValidationError):
        validate_expense("Nonsense", "x", "10")
    assert validate_expense("Venue", "Hall", "10")["amount"] == 1000
    with pytest.raises(ValidationError):
        validate_task("", date(2026, 1, 1), "Urgent", None)


# ---- calendar ----------------------------------------------------------------------
def fake_event():
    return SimpleNamespace(id=7, name="Kapoor, Mehta; Wedding", venue="Palace\nAbu Dhabi", type="Wedding",
                           client="Kapoor", guests=450, date=date(2026, 11, 3))


def test_ics_is_valid_and_escaped():
    ics = build_ics([fake_event()], now=datetime(2026, 10, 21, tzinfo=timezone.utc))
    assert ics.startswith("BEGIN:VCALENDAR\r\n") and ics.endswith("END:VCALENDAR\r\n")
    assert "DTSTART;VALUE=DATE:20261103" in ics and "DTEND;VALUE=DATE:20261104" in ics
    assert "SUMMARY:Kapoor\\, Mehta\\; Wedding" in ics
    assert "LOCATION:Palace\\nAbu Dhabi" in ics
    assert all(len(line.encode()) <= 75 for line in ics.split("\r\n"))


def test_google_link_has_title_date_venue():
    url = google_calendar_url(fake_event())
    assert url.startswith("https://calendar.google.com/calendar/render?action=TEMPLATE")
    assert "dates=20261103%2F20261104" in url and "Kapoor%2C+Mehta" in url and "Abu+Dhabi" in url
