"""Calendar page: month grid, Google Calendar links and .ics export."""
from __future__ import annotations

import calendar
from datetime import date
from pathlib import Path

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import QFileDialog, QFrame, QGridLayout, QHBoxLayout, QScrollArea, QVBoxLayout, QWidget

from zari.logic import finance
from zari.logic.calendar_export import build_ics, google_calendar_url, safe_filename
from zari.ui import theme
from zari.ui.dialogs import info
from zari.ui.widgets import (
    Card, ClickableFrame, ElidedButton, Ornament, clear_layout, icon_button, make_button, make_label, status_badge,
)

WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
MAX_CHIPS = 3


class CalendarPage(QScrollArea):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        today = ctx.today
        self.year, self.month = today.year, today.month
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root = QWidget()
        root.setObjectName("PageRoot")
        self.setWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(36, 30, 36, 36)
        lay.setSpacing(16)

        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Schedule", "eyebrow"))
        self.title = make_label("", "h1")
        titles.addWidget(self.title)
        head.addLayout(titles)
        head.addStretch(1)
        prev = icon_button("left", "Previous month")
        prev.clicked.connect(lambda: self._shift(-1))
        nxt = icon_button("right", "Next month")
        nxt.clicked.connect(lambda: self._shift(1))
        today_btn = make_button("Today")
        today_btn.clicked.connect(self._go_today)
        export = make_button("Export all upcoming (.ics)", "primary", "download")
        export.clicked.connect(self._export_all)
        for w in (prev, today_btn, nxt, export):
            head.addWidget(w, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(head)
        lay.addWidget(Ornament(width_limit=900))

        self.grid_card = Card()
        gl = QVBoxLayout(self.grid_card)
        gl.setContentsMargins(14, 14, 14, 14)
        gl.setSpacing(6)
        wk = QGridLayout()
        wk.setHorizontalSpacing(6)
        for i, d in enumerate(WEEKDAYS):
            wk.addWidget(make_label(d, "eyebrow", align=Qt.AlignmentFlag.AlignCenter), 0, i)
            wk.setColumnStretch(i, 1)
        gl.addLayout(wk)
        self.grid = QGridLayout()
        self.grid.setSpacing(6)
        for i in range(7):
            self.grid.setColumnStretch(i, 1)
        gl.addLayout(self.grid)
        lay.addWidget(self.grid_card)

        self.list_card = Card()
        self.list_layout = QVBoxLayout(self.list_card)
        self.list_layout.setContentsMargins(22, 20, 22, 20)
        self.list_layout.setSpacing(8)
        lay.addWidget(self.list_card)
        lay.addStretch(1)

    # ---- navigation -----------------------------------------------------------------
    def _shift(self, delta: int) -> None:
        m = self.month + delta
        self.year += (m - 1) // 12
        self.month = (m - 1) % 12 + 1
        self.refresh()

    def _go_today(self) -> None:
        self.year, self.month = self.ctx.today.year, self.ctx.today.month
        self.refresh()

    # ---- exports --------------------------------------------------------------------
    def _save_ics(self, events, default_name: str) -> None:
        path, _ = QFileDialog.getSaveFileName(self.window(), "Save calendar file", default_name,
                                              "Calendar file (*.ics)")
        if not path:
            return
        try:
            Path(path).write_text(build_ics(events), encoding="utf-8", newline="")
        except OSError as exc:
            info(self.window(), "Could not save the file", str(exc))
            return
        self.ctx.notify(f"Saved {len(events)} event{'s' if len(events) != 1 else ''} to {path}")

    def _export_all(self) -> None:
        upcoming = finance.upcoming_events(self.ctx.repo.list_events(), self.ctx.today, None)
        if not upcoming:
            info(self.window(), "Nothing to export", "There are no upcoming events.")
            return
        self._save_ics(upcoming, "zari-upcoming-events.ics")

    # ---- drawing --------------------------------------------------------------------
    def refresh(self) -> None:
        today = self.ctx.today
        events = [e for e in self.ctx.repo.list_events() if e.is_active]
        by_day: dict[date, list] = {}
        for e in events:
            by_day.setdefault(e.date, []).append(e)

        self.title.setText(f"{calendar.month_name[self.month]} {self.year}")
        clear_layout(self.grid)
        weeks = calendar.Calendar(firstweekday=0).monthdatescalendar(self.year, self.month)
        for r, week in enumerate(weeks):
            self.grid.setRowMinimumHeight(r, 108)
            for c, day in enumerate(week):
                self.grid.addWidget(self._cell(day, by_day.get(day, []), today), r, c)

        clear_layout(self.list_layout)
        self.list_layout.addWidget(make_label("Add to your calendar", "eyebrow"))
        self.list_layout.addWidget(make_label("Upcoming events", "h3"))
        note = make_label("Google Calendar opens in your browser only when you click it. "
                          "Apple / Outlook saves a .ics file you can open or import.", "small", wrap=True)
        self.list_layout.addWidget(note)
        upcoming = finance.upcoming_events(self.ctx.repo.list_events(), today, None)
        if not upcoming:
            self.list_layout.addWidget(make_label("No upcoming events.", "muted"))
        for e in upcoming:
            self.list_layout.addWidget(self._upcoming_row(e, today))

    def _cell(self, day: date, events: list, today: date) -> QFrame:
        in_month = day.month == self.month
        is_today = day == today
        cell = QFrame()
        cell.setObjectName("DayCell")
        border = f"2px solid {theme.GOLD}" if is_today else f"1px solid {theme.rgba(theme.GOLD, 0.2 if in_month else 0.08)}"
        bg = theme.rgba(theme.GOLD, 0.16) if is_today else theme.rgba("#000000", 0.14 if in_month else 0.06)
        cell.setStyleSheet(f"QFrame#DayCell {{ background: {bg}; border: {border}; border-radius: 10px; }}")
        v = QVBoxLayout(cell)
        v.setContentsMargins(6, 5, 6, 5)
        v.setSpacing(2)
        num = make_label(str(day.day), "body",
                         color=theme.GOLD if is_today else (theme.IVORY if in_month else theme.rgba(theme.IVORY, 0.35)))
        if is_today:
            f = num.font()
            f.setBold(True)
            num.setFont(f)
        v.addWidget(num)
        for e in events[:MAX_CHIPS]:
            chip = ElidedButton(e.name, theme.STATUS_COLORS.get(e.status, theme.GOLD))
            chip.clicked.connect(lambda _=False, eid=e.id: self.ctx.event_requested.emit(eid))
            v.addWidget(chip)
        if len(events) > MAX_CHIPS:
            v.addWidget(make_label(f"+{len(events) - MAX_CHIPS} more", "small"))
        v.addStretch(1)
        return cell

    def _upcoming_row(self, e, today: date) -> QWidget:
        row = ClickableFrame("UpRow")
        row.clicked.connect(lambda eid=e.id: self.ctx.event_requested.emit(eid))
        h = QHBoxLayout(row)
        h.setContentsMargins(14, 10, 12, 10)
        h.setSpacing(10)
        text = QVBoxLayout()
        text.setSpacing(1)
        text.addWidget(make_label(e.name, "body"))
        text.addWidget(make_label(f"{e.date:%a, %d %b %Y}  ·  {finance.countdown_text(e.date, today)}  ·  {e.venue}",
                                  "small"))
        h.addLayout(text, 1)
        h.addWidget(status_badge(e.status))
        g = make_button("Google Calendar", tooltip="Open a pre-filled event in Google Calendar (in your browser)")
        g.clicked.connect(lambda _=False, ev=e: QDesktopServices.openUrl(QUrl(google_calendar_url(ev))))
        a = make_button("Apple / Outlook", icon_name="download", tooltip="Download a .ics calendar file")
        a.clicked.connect(lambda _=False, ev=e: self._save_ics([ev], f"{safe_filename(ev.name)}.ics"))
        h.addWidget(g)
        h.addWidget(a)
        return row
