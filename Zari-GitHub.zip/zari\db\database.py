"""SQLite connection, versioned schema migrations, backup and restore."""
from __future__ import annotations

import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

from zari.config import backups_dir

# Each entry upgrades the database by one version. NEVER edit an old entry once
# released - append a new one instead. PRAGMA user_version records how far we are.
MIGRATIONS: list[str] = [
    # --- version 1: initial schema ---------------------------------------------------
    """
    CREATE TABLE events (
        id             INTEGER PRIMARY KEY,
        name           TEXT    NOT NULL CHECK (length(trim(name)) > 0),
        client         TEXT    NOT NULL CHECK (length(trim(client)) > 0),
        type           TEXT    NOT NULL CHECK (type IN ('Wedding','Corporate','Gala','Conference','Private')),
        date           TEXT    NOT NULL CHECK (date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
        venue          TEXT    NOT NULL CHECK (length(trim(venue)) > 0),
        guests         INTEGER NOT NULL CHECK (guests >= 1),
        status         TEXT    NOT NULL CHECK (status IN ('Enquiry','Confirmed','In Progress','Completed','Cancelled')),
        contract_value INTEGER NOT NULL CHECK (contract_value >= 0),
        notes          TEXT    NOT NULL DEFAULT '',
        is_sample      INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0,1)),
        created_at     TEXT    NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_events_date ON events(date);

    CREATE TABLE payments (
        id         INTEGER PRIMARY KEY,
        event_id   INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        amount     INTEGER NOT NULL CHECK (amount > 0),
        date       TEXT    NOT NULL,
        label      TEXT    NOT NULL CHECK (length(trim(label)) > 0),
        created_at TEXT    NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_payments_event ON payments(event_id);
    CREATE INDEX idx_payments_date  ON payments(date);

    CREATE TABLE expenses (
        id           INTEGER PRIMARY KEY,
        event_id     INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        category     TEXT    NOT NULL CHECK (category IN
                       ('Venue','Catering','Decor','Entertainment','Photography','Staff','Transport','Other')),
        description  TEXT    NOT NULL CHECK (length(trim(description)) > 0),
        amount       INTEGER NOT NULL CHECK (amount > 0),
        paid         INTEGER NOT NULL DEFAULT 0 CHECK (paid IN (0,1)),
        vendor       TEXT    NOT NULL DEFAULT '',
        invoice_no   TEXT    NOT NULL DEFAULT '',
        invoice_file TEXT    NOT NULL DEFAULT '',
        date         TEXT,
        created_at   TEXT    NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_expenses_event ON expenses(event_id);

    CREATE TABLE tasks (
        id         INTEGER PRIMARY KEY,
        title      TEXT    NOT NULL CHECK (length(trim(title)) > 0),
        event_id   INTEGER REFERENCES events(id) ON DELETE SET NULL,
        due        TEXT    NOT NULL,
        priority   TEXT    NOT NULL CHECK (priority IN ('Low','Medium','High')),
        done       INTEGER NOT NULL DEFAULT 0 CHECK (done IN (0,1)),
        is_sample  INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0,1)),
        created_at TEXT    NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_tasks_due ON tasks(due);
    """,
    # --- version 2: documents, budgets, vendors, quotes, guests, scenarios ----------
    """
    ALTER TABLE expenses ADD COLUMN due_date TEXT;
    ALTER TABLE events   ADD COLUMN contingency_bp INTEGER NOT NULL DEFAULT 0
        CHECK (contingency_bp BETWEEN 0 AND 10000);

    CREATE TABLE vendors (
        id           INTEGER PRIMARY KEY,
        name         TEXT NOT NULL UNIQUE COLLATE NOCASE CHECK (length(trim(name)) > 0),
        category     TEXT NOT NULL DEFAULT 'Other' CHECK (category IN
                       ('Venue','Catering','Decor','Entertainment','Photography','Staff','Transport','Other')),
        contact_name TEXT NOT NULL DEFAULT '',
        phone        TEXT NOT NULL DEFAULT '',
        email        TEXT NOT NULL DEFAULT '',
        notes        TEXT NOT NULL DEFAULT '',
        is_sample    INTEGER NOT NULL DEFAULT 0 CHECK (is_sample IN (0,1)),
        created_at   TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE quotes (
        id          INTEGER PRIMARY KEY,
        event_id    INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        requirement TEXT NOT NULL CHECK (length(trim(requirement)) > 0),
        category    TEXT NOT NULL CHECK (category IN
                      ('Venue','Catering','Decor','Entertainment','Photography','Staff','Transport','Other')),
        vendor_id   INTEGER NOT NULL REFERENCES vendors(id) ON DELETE RESTRICT,
        amount      INTEGER NOT NULL CHECK (amount > 0),
        deposit     INTEGER NOT NULL DEFAULT 0 CHECK (deposit >= 0 AND deposit <= amount),
        valid_until TEXT,
        rating      INTEGER CHECK (rating IS NULL OR rating BETWEEN 1 AND 5),
        status      TEXT NOT NULL DEFAULT 'Received' CHECK (status IN ('Requested','Received','Selected','Rejected')),
        notes       TEXT NOT NULL DEFAULT '',
        expense_id  INTEGER REFERENCES expenses(id) ON DELETE SET NULL,
        created_at  TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_quotes_event ON quotes(event_id);

    CREATE TABLE budgets (
        event_id INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        category TEXT NOT NULL CHECK (category IN
                   ('Venue','Catering','Decor','Entertainment','Photography','Staff','Transport','Other')),
        amount   INTEGER NOT NULL CHECK (amount > 0),
        PRIMARY KEY (event_id, category)
    );

    CREATE TABLE guests (
        id         INTEGER PRIMARY KEY,
        event_id   INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        name       TEXT NOT NULL CHECK (length(trim(name)) > 0),
        phone      TEXT NOT NULL DEFAULT '',
        email      TEXT NOT NULL DEFAULT '',
        party_size INTEGER NOT NULL DEFAULT 1 CHECK (party_size BETWEEN 1 AND 50),
        grp        TEXT NOT NULL DEFAULT '',
        invited    INTEGER NOT NULL DEFAULT 0 CHECK (invited IN (0,1)),
        rsvp       TEXT NOT NULL DEFAULT 'Pending' CHECK (rsvp IN ('Pending','Confirmed','Declined')),
        notes      TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_guests_event ON guests(event_id);

    CREATE TABLE documents (
        id            INTEGER PRIMARY KEY,
        event_id      INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        expense_id    INTEGER REFERENCES expenses(id) ON DELETE SET NULL,
        kind          TEXT NOT NULL DEFAULT 'Other' CHECK (kind IN ('Invoice','Receipt','Contract','Quote','Other')),
        title         TEXT NOT NULL CHECK (length(trim(title)) > 0),
        stored_name   TEXT NOT NULL,
        original_name TEXT NOT NULL,
        size          INTEGER NOT NULL CHECK (size >= 0),
        added_at      TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE INDEX idx_documents_event ON documents(event_id);

    CREATE TABLE scenarios (
        id                   INTEGER PRIMARY KEY,
        event_id             INTEGER NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        name                 TEXT NOT NULL CHECK (length(trim(name)) > 0),
        guests               INTEGER NOT NULL CHECK (guests >= 1),
        contract_bp          INTEGER NOT NULL DEFAULT 0,
        contingency_bp       INTEGER NOT NULL DEFAULT 0 CHECK (contingency_bp >= 0),
        per_guest_categories TEXT NOT NULL DEFAULT 'Catering',
        created_at           TEXT NOT NULL DEFAULT (datetime('now'))
    );
    CREATE TABLE scenario_adjust (
        scenario_id INTEGER NOT NULL REFERENCES scenarios(id) ON DELETE CASCADE,
        category    TEXT NOT NULL,
        change_bp   INTEGER NOT NULL,
        PRIMARY KEY (scenario_id, category)
    );
    """,
]

SCHEMA_VERSION = len(MIGRATIONS)
REQUIRED_TABLES = {"events", "payments", "expenses", "tasks"}
KEEP_AUTO_BACKUPS = 15


class DatabaseError(Exception):
    """Raised with a user-readable message for backup / restore problems."""


class Database:
    def __init__(self, path: Path | str):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn: sqlite3.Connection = self._connect()
        self._migrate()

    # ---- connection ----------------------------------------------------------------
    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def close(self) -> None:
        self.conn.close()

    # ---- schema --------------------------------------------------------------------
    def _migrate(self) -> None:
        current = self.conn.execute("PRAGMA user_version").fetchone()[0]
        if current > SCHEMA_VERSION:
            raise DatabaseError(
                "This database was created by a newer version of Zari. "
                "Please update the app instead of opening it with this version."
            )
        for version in range(current, SCHEMA_VERSION):
            # executescript() commits first, so wrap each step in its own transaction.
            script = f"BEGIN;\n{MIGRATIONS[version]}\nPRAGMA user_version = {version + 1};\nCOMMIT;"
            try:
                self.conn.executescript(script)
            except sqlite3.Error:
                if self.conn.in_transaction:
                    self.conn.execute("ROLLBACK")
                raise
        self.conn.execute("PRAGMA foreign_keys = ON")

    # ---- backup / restore ----------------------------------------------------------
    def backup_to(self, dest: Path | str) -> Path:
        """Write a consistent copy of the live database (safe while the app is open)."""
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        target = sqlite3.connect(dest)
        try:
            self.conn.backup(target)
        finally:
            target.close()
        return dest

    def safety_backup(self, reason: str) -> Path:
        """Automatic backup taken before risky operations. Old ones are pruned."""
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        dest = self.backup_to(backups_dir() / f"auto-{reason}-{stamp}.db")
        autos = sorted(backups_dir().glob("auto-*.db"), key=lambda p: p.stat().st_mtime)
        for old in autos[:-KEEP_AUTO_BACKUPS]:
            old.unlink(missing_ok=True)
        return dest

    @staticmethod
    def validate_backup_file(src: Path | str) -> None:
        """Raise DatabaseError unless `src` is a healthy Zari database we can open."""
        src = Path(src)
        if not src.is_file():
            raise DatabaseError("That file does not exist.")
        try:
            probe = sqlite3.connect(f"file:{src.as_posix()}?mode=ro", uri=True)
            try:
                if probe.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                    raise DatabaseError("That backup file is damaged (integrity check failed).")
                tables = {r[0] for r in probe.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not REQUIRED_TABLES <= tables:
                    raise DatabaseError("That file is not a Zari backup (expected tables are missing).")
                if probe.execute("PRAGMA user_version").fetchone()[0] > SCHEMA_VERSION:
                    raise DatabaseError("That backup was made by a newer version of Zari.")
            finally:
                probe.close()
        except sqlite3.DatabaseError as exc:
            raise DatabaseError(f"That file is not a valid database: {exc}") from exc

    def restore_from(self, src: Path | str) -> Path:
        """Replace the live database with a backup. Returns the safety copy of the old data."""
        src = Path(src)
        self.validate_backup_file(src)
        safety = self.safety_backup("before-restore")
        self.conn.close()
        try:
            shutil.copyfile(src, self.path)
        finally:
            self.conn = self._connect()
        self._migrate()  # upgrades older backups to the current schema
        return safety
