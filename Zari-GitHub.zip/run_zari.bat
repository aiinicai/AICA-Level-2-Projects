@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
    echo Zari is not set up yet. Running setup first...
    call setup_zari.bat
)
start "" ".venv\Scripts\pythonw.exe" -m zari
