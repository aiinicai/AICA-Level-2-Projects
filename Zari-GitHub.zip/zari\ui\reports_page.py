"""Reports page: event-wise financial summary, budget vs actual, vendor payables, with exports."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QFileDialog, QFrame, QHBoxLayout, QHeaderView, QScrollArea, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from zari.exports.report_export import (
    BUDGET_COLS, EVENT_COLS, VENDOR_COLS, export_reports_excel, export_reports_pdf,
)
from zari.logic import reports
from zari.logic.finance import format_margin, margin_level
from zari.logic.money import format_aed
from zari.ui import theme
from zari.ui.dialogs import info
from zari.ui.widgets import BudgetChart, Card, Ornament, make_button, make_label

ROW_H = 30
STATUS_TEXT = {"none": "No budget", "ok": "On track", "warning": "Near limit", "over": "Over budget"}
STATUS_COLOR = {"none": theme.IVORY_MUTED, "ok": theme.SUCCESS, "warning": theme.WARNING, "over": theme.DANGER}


def _table(cols: list[str]) -> QTableWidget:
    t = QTableWidget(0, len(cols))
    t.setHorizontalHeaderLabels(cols)
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
    t.setAlternatingRowColors(True)
    t.verticalHeader().setVisible(False)
    t.verticalHeader().setDefaultSectionSize(ROW_H)
    t.setShowGrid(False)
    t.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
    h = t.horizontalHeader()
    h.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)  # never cut event / vendor names short
    h.setStretchLastSection(True)
    h.setMinimumSectionSize(70)
    t.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
    return t


def _fill(t: QTableWidget, rows: list[list], right_from: int, colors: dict | None = None) -> None:
    """rows: list of cell texts. colors: {(row, col): hex colour}."""
    t.setRowCount(len(rows))
    for r, row in enumerate(rows):
        for c, text in enumerate(row):
            item = QTableWidgetItem(str(text))
            if c >= right_from:
                item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            if colors and (r, c) in colors:
                item.setForeground(QColor(colors[(r, c)]))
            t.setItem(r, c, item)
    t.setFixedHeight(t.horizontalHeader().height() + ROW_H * max(1, len(rows)) + 22)  # room for a scrollbar


def _money(v) -> str:
    return "-" if v is None else format_aed(v)


class ReportsPage(QScrollArea):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self._data: tuple = ([], [], [])
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root = QWidget()
        root.setObjectName("PageRoot")
        self.setWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(36, 30, 36, 36)
        lay.setSpacing(16)

        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Insights", "eyebrow"))
        titles.addWidget(make_label("Reports", "h1"))
        head.addLayout(titles)
        head.addStretch(1)
        self.include_cancelled = QCheckBox("Include cancelled events")
        self.include_cancelled.toggled.connect(self.refresh)
        head.addWidget(self.include_cancelled, 0, Qt.AlignmentFlag.AlignBottom)
        xl = make_button("Excel", icon_name="download", tooltip="Export all three tables to one Excel workbook")
        xl.clicked.connect(lambda: self._export("xlsx"))
        pdf = make_button("PDF", icon_name="download", tooltip="Export a printable PDF report")
        pdf.clicked.connect(lambda: self._export("pdf"))
        head.addWidget(xl, 0, Qt.AlignmentFlag.AlignBottom)
        head.addWidget(pdf, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(head)
        lay.addWidget(Ornament(width_limit=900))
        lay.addWidget(make_label(
            "Every figure here uses the same calculations as the rest of Zari, so exported totals match the screen. "
            "Budget left = budget minus actual expenses minus quotes you have committed to.", "small", wrap=True))

        chart_card = Card()
        cv = QVBoxLayout(chart_card)
        cv.setContentsMargins(20, 18, 20, 18)
        cv.setSpacing(8)
        cv.addWidget(make_label("Diagram", "eyebrow"))
        cv.addWidget(make_label("Budget vs actual by event", "h3"))
        cv.addWidget(make_label("Events with a budget or spending. Pale outline = budget, gold = actual, rose = "
                                "committed quotes, red = over budget.", "small", wrap=True))
        self.chart = BudgetChart()
        cv.addWidget(self.chart)
        lay.addWidget(chart_card)

        self.events_table = _table(EVENT_COLS)
        self.budget_table = _table(BUDGET_COLS)
        self.vendor_table = _table(VENDOR_COLS)
        for title, sub, table in (("Events: contract, budget and profit", "One row per event", self.events_table),
                                  ("Budget by category", "Estimated vs committed vs actual", self.budget_table),
                                  ("Vendor payables", "What each vendor has cost and what you still owe", self.vendor_table)):
            card = Card()
            v = QVBoxLayout(card)
            v.setContentsMargins(20, 18, 20, 18)
            v.setSpacing(8)
            v.addWidget(make_label(sub, "eyebrow"))
            v.addWidget(make_label(title, "h3"))
            v.addWidget(table)
            lay.addWidget(card)
        lay.addStretch(1)

    # ---- data -----------------------------------------------------------------------
    def _collect(self):
        repo = self.ctx.repo
        events = [e for e in repo.list_events() if self.include_cancelled.isChecked() or e.is_active]
        expenses, quotes, budgets = repo.list_all_expenses(), repo.list_all_quotes(), repo.list_all_budgets()
        return (reports.event_rows(events, budgets, expenses, quotes),
                reports.budget_vs_actual(events, budgets, expenses, quotes),
                reports.vendor_payables(events, expenses))

    def refresh(self, *_) -> None:
        self._data = self._collect()
        event_rows, budget_rows, vendor_rows = self._data
        self.chart.set_rows([(r.event.name, r.budget, r.actual, r.committed) for r in event_rows
                             if r.budget or r.actual or r.committed])

        rows, colors = [], {}
        for i, r in enumerate(event_rows):
            e = r.event
            rows.append([e.name, f"{e.date:%d %b %Y}", e.status, _money(r.contract), _money(r.received),
                         _money(r.balance_due), _money(r.budget) if r.budget else "-", _money(r.actual),
                         _money(r.committed) if r.committed else "-", _money(r.variance), _money(r.profit),
                         format_margin(r.margin)])
            if r.variance is not None and r.variance < 0:
                colors[(i, 9)] = theme.DANGER
            colors[(i, 10)] = theme.SUCCESS if r.profit >= 0 else theme.DANGER
            colors[(i, 11)] = theme.LEVEL_COLORS[margin_level(r.margin)]
            if r.balance_due:
                colors[(i, 5)] = theme.WARNING
        if event_rows:
            rows.append(["Total", "", "", _money(sum(r.contract for r in event_rows)),
                         _money(sum(r.received for r in event_rows)), _money(sum(r.balance_due for r in event_rows)),
                         _money(sum(r.budget for r in event_rows)), _money(sum(r.actual for r in event_rows)),
                         _money(sum(r.committed for r in event_rows)), "", _money(sum(r.profit for r in event_rows)), ""])
        _fill(self.events_table, rows, 3, colors)
        self._bold_last_row(self.events_table, bool(event_rows))

        rows, colors = [], {}
        for i, (e, l) in enumerate(budget_rows):
            rows.append([e.name, l.category, _money(l.budget) if l.budget else "-", _money(l.quoted) if l.quoted else "-",
                         _money(l.committed) if l.committed else "-", _money(l.actual) if l.actual else "-",
                         _money(l.remaining) if l.budget else "-",
                         f"{l.used_pct:.0f}%" if l.used_pct is not None else "-", STATUS_TEXT[l.status]])
            colors[(i, 8)] = STATUS_COLOR[l.status]
            if l.budget and l.remaining < 0:
                colors[(i, 6)] = theme.DANGER
        _fill(self.budget_table, rows, 2, colors)

        rows, colors = [], {}
        for i, p in enumerate(vendor_rows):
            rows.append([p.vendor, p.items, _money(p.total), _money(p.paid), _money(p.unpaid),
                         f"{p.next_due:%d %b %Y}" if p.next_due else "-"])
            if p.unpaid:
                colors[(i, 4)] = theme.WARNING
            if p.next_due and p.next_due < self.ctx.today and p.unpaid:
                colors[(i, 5)] = theme.DANGER
        if vendor_rows:
            rows.append(["Total", sum(p.items for p in vendor_rows), _money(sum(p.total for p in vendor_rows)),
                         _money(sum(p.paid for p in vendor_rows)), _money(sum(p.unpaid for p in vendor_rows)), ""])
        _fill(self.vendor_table, rows, 1, colors)
        self._bold_last_row(self.vendor_table, bool(vendor_rows))

    @staticmethod
    def _bold_last_row(table: QTableWidget, has_total: bool) -> None:
        if not has_total:
            return
        r = table.rowCount() - 1
        for c in range(table.columnCount()):
            item = table.item(r, c)
            if item:
                f = item.font()
                f.setBold(True)
                item.setFont(f)

    # ---- export ---------------------------------------------------------------------
    def _export(self, kind: str) -> None:
        event_rows, budget_rows, vendor_rows = self._data
        if not event_rows:
            info(self.window(), "Nothing to export", "There are no events to report on yet.")
            return
        ext, label = ("xlsx", "Excel workbook (*.xlsx)") if kind == "xlsx" else ("pdf", "PDF document (*.pdf)")
        path, _ = QFileDialog.getSaveFileName(self.window(), "Export report", f"zari-report.{ext}", label)
        if not path:
            return
        try:
            (export_reports_excel if kind == "xlsx" else export_reports_pdf)(path, event_rows, budget_rows, vendor_rows)
        except OSError as exc:
            info(self.window(), "Could not save the file",
                 f"{exc}\n\nIf the file is open in Excel or a PDF viewer, close it and try again.")
            return
        self.ctx.notify(f"Report exported to {path}")
