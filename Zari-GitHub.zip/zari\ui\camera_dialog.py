"""Take a photo of an invoice with a webcam (or any camera Windows exposes)."""
from __future__ import annotations

import tempfile
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtGui import QImage
from PySide6.QtMultimedia import QCamera, QImageCapture, QMediaCaptureSession, QMediaDevices
from PySide6.QtMultimediaWidgets import QVideoWidget
from PySide6.QtWidgets import QComboBox, QDialog, QHBoxLayout, QLabel, QStackedWidget, QVBoxLayout

from zari.ui import theme
from zari.ui.dialogs import info
from zari.ui.widgets import make_button, make_label, set_label_color

NO_CAMERA_HELP = ("No camera was found. Plug in a webcam, or check that Windows allows apps to use it "
                  "(Settings > Privacy & security > Camera). You can also choose a photo from a file instead.")


def cameras_available() -> bool:
    return bool(QMediaDevices.videoInputs())


class CameraDialog(QDialog):
    """Live preview -> Capture -> review -> 'Use this photo' (saved as a JPEG in the temp folder)."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Take a photo of the invoice")
        self.setModal(True)
        self.photo_path: str | None = None
        self._image: QImage | None = None
        self.camera: QCamera | None = None

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 18)
        root.setSpacing(8)
        root.addWidget(make_label("Invoice scanner", "eyebrow"))
        root.addWidget(make_label("Take a photo", "h2"))
        root.addWidget(make_label("Hold the invoice flat, fill the frame, in good light. Make sure the total is "
                                  "sharp and readable.", "small", wrap=True))
        self.devices = QMediaDevices.videoInputs()
        self.picker = QComboBox()
        for d in self.devices:
            self.picker.addItem(d.description())
        self.picker.setVisible(len(self.devices) > 1)
        self.picker.currentIndexChanged.connect(self._start_camera)
        root.addWidget(self.picker)

        self.stack = QStackedWidget()
        self.video = QVideoWidget()
        self.video.setMinimumSize(640, 400)
        self.still = QLabel()
        self.still.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.still.setMinimumSize(640, 400)
        self.stack.addWidget(self.video)
        self.stack.addWidget(self.still)
        root.addWidget(self.stack, 1)
        self.status = make_label("Starting the camera...", "small", wrap=True)
        root.addWidget(self.status)

        row = QHBoxLayout()
        row.addStretch(1)
        self.cancel_btn = make_button("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        self.retake_btn = make_button("Retake")
        self.retake_btn.clicked.connect(self._retake)
        self.capture_btn = make_button("Capture", "primary", "scan")
        self.capture_btn.clicked.connect(self._capture)
        self.capture_btn.setEnabled(False)
        self.use_btn = make_button("Use this photo", "primary", "check")
        self.use_btn.clicked.connect(self._use)
        for b in (self.cancel_btn, self.retake_btn, self.capture_btn, self.use_btn):
            row.addWidget(b)
        root.addLayout(row)
        self._show_live(True)

        self.session = QMediaCaptureSession()
        self.capture = QImageCapture()
        self.session.setImageCapture(self.capture)
        self.session.setVideoOutput(self.video)
        self.capture.imageCaptured.connect(self._on_captured)
        self.capture.errorOccurred.connect(lambda _id, _err, msg: self._fail(msg))
        self.capture.readyForCaptureChanged.connect(lambda ok: self.capture_btn.setEnabled(ok and self._live))
        if self.devices:
            self._start_camera()

    # ---- camera ---------------------------------------------------------------------
    def _start_camera(self) -> None:
        if self.camera is not None:
            self.camera.stop()
        self.camera = QCamera(self.devices[self.picker.currentIndex()])
        self.camera.errorOccurred.connect(lambda _err, msg: self._fail(msg))
        self.session.setCamera(self.camera)
        self.camera.start()
        self.status.setText("Camera ready. Press Capture when the invoice is in view.")
        set_label_color(self.status, theme.IVORY_MUTED)

    def _fail(self, message: str) -> None:
        self.status.setText(f"The camera reported a problem: {message or 'unknown error'}. "
                            "Check that no other app is using it and that Windows allows camera access.")
        set_label_color(self.status, theme.DANGER)
        self.capture_btn.setEnabled(False)

    # ---- states ---------------------------------------------------------------------
    _live = True

    def _show_live(self, live: bool) -> None:
        self._live = live
        self.stack.setCurrentIndex(0 if live else 1)
        self.capture_btn.setVisible(live)
        self.retake_btn.setVisible(not live)
        self.use_btn.setVisible(not live)

    def _capture(self) -> None:
        self.capture_btn.setEnabled(False)
        self.capture.capture()

    def _on_captured(self, _id: int, image: QImage) -> None:
        self._image = image
        self.still.setPixmap(__import__("PySide6.QtGui", fromlist=["QPixmap"]).QPixmap.fromImage(image).scaled(
            self.still.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        self._show_live(False)
        self.status.setText("Is the total clearly readable? If not, retake the photo.")

    def _retake(self) -> None:
        self._image = None
        self._show_live(True)
        self.capture_btn.setEnabled(self.capture.isReadyForCapture())

    def _use(self) -> None:
        if self._image is None:
            return
        path = Path(tempfile.gettempdir()) / f"invoice_photo_{datetime.now():%Y%m%d_%H%M%S}.jpg"
        if not self._image.save(str(path), "JPG", 92):
            self._fail("could not save the photo")
            return
        self.photo_path = str(path)
        self.accept()

    def done(self, result: int) -> None:
        if self.camera is not None:
            self.camera.stop()
        super().done(result)


def take_photo(parent) -> str | None:
    """Open the camera window. Returns the saved photo path, or None (cancelled / no camera)."""
    if not cameras_available():
        info(parent, "No camera found", NO_CAMERA_HELP)
        return None
    dlg = CameraDialog(parent)
    return dlg.photo_path if dlg.exec() else None
