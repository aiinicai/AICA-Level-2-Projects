"""Draw the Zari app icon (gold mandala on burgundy) and save assets/zari.ico.   python tools/make_icon.py"""
import os
import sys
from pathlib import Path

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from PIL import Image  # noqa: E402
from PySide6.QtCore import QRectF, Qt  # noqa: E402
from PySide6.QtGui import QBrush, QColor, QImage, QLinearGradient, QPainter, QPen  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from zari.ui import icons, theme  # noqa: E402


def main() -> None:
    app = QApplication([])
    size = 512
    img = QImage(size, size, QImage.Format.Format_ARGB32)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    grad = QLinearGradient(0, 0, 0, size)
    grad.setColorAt(0, QColor("#7A2347"))
    grad.setColorAt(1, QColor(theme.BURGUNDY_DEEP))
    p.setBrush(QBrush(grad))
    p.setPen(QPen(QColor(theme.GOLD), 10))
    p.drawRoundedRect(QRectF(10, 10, size - 20, size - 20), 96, 96)
    p.setPen(QPen(QColor(theme.GOLD), 4))
    p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawRoundedRect(QRectF(38, 38, size - 76, size - 76), 72, 72)
    p.scale(size / 48 * 0.74, size / 48 * 0.74)
    p.translate(48 * 0.175, 48 * 0.175)
    pen = QPen(QColor(theme.GOLD_SOFT), 2.4)
    pen.setCapStyle(Qt.PenCapStyle.RoundCap)
    p.setPen(pen)
    icons._DRAW["mandala"](p, QColor(theme.GOLD))
    p.end()
    out = ROOT / "assets" / "zari.ico"
    out.parent.mkdir(exist_ok=True)
    tmp = ROOT / "assets" / "_icon.png"
    img.save(str(tmp))
    Image.open(tmp).save(out, sizes=[(s, s) for s in (16, 24, 32, 48, 64, 128, 256)])
    tmp.unlink()
    print("saved", out)


if __name__ == "__main__":
    main()
