"""Reusable building blocks: labels, cards, badges, buttons, the arch header, the chart."""
from __future__ import annotations

import math

from PySide6.QtCore import QPointF, QRectF, QSize, Qt, Signal
from PySide6.QtGui import (
    QBrush, QColor, QFont, QFontMetrics, QLinearGradient, QPainter, QPainterPath, QPen, QPixmap,
    QRadialGradient,
)
from PySide6.QtWidgets import (
    QAbstractButton, QFrame, QGraphicsDropShadowEffect, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
    QToolTip, QVBoxLayout, QWidget,
)

from zari.logic.money import format_aed, format_axis
from zari.ui import icons, theme
from zari.ui.theme import qcolor


# ---------------------------------------------------------------------------- labels
def make_label(text: str = "", kind: str = "body", color: str | None = None, wrap: bool = False,
               align: Qt.AlignmentFlag | None = None) -> QLabel:
    """kind: body | muted | eyebrow | h1 | h2 | h3 | num | small"""
    lab = QLabel(text)
    f = QFont(theme.BODY_FONT)
    col = color or theme.IVORY
    if kind == "eyebrow":
        f.setPointSizeF(7.5)
        f.setWeight(QFont.Weight.DemiBold)
        f.setCapitalization(QFont.Capitalization.AllUppercase)
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 2.2)
        col = color or theme.GOLD
    elif kind in ("h1", "h2", "h3", "num"):
        f = theme.heading_font({"h1": 30, "h2": 20, "h3": 15, "num": 28}[kind], bold=True)
    elif kind == "muted":
        f.setPointSizeF(9.5)
        col = color or theme.IVORY_MUTED
    elif kind == "small":
        f.setPointSizeF(8.5)
        col = color or theme.IVORY_MUTED
    else:
        f.setPointSizeF(10)
    lab.setFont(f)
    lab.setStyleSheet(f"color: {col}; background: transparent;")
    lab.setWordWrap(wrap)
    if align is not None:
        lab.setAlignment(align)
    return lab


def shrinkable(label: QLabel) -> QLabel:
    """Allow a label to be narrower than its text (it clips) so long names never widen the page."""
    label.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
    label.setMinimumWidth(0)
    return label


def set_label_color(label: QLabel, color: str) -> None:
    label.setStyleSheet(f"color: {color}; background: transparent;")


def make_button(text: str = "", variant: str = "", icon_name: str | None = None,
                icon_color: str | None = None, tooltip: str = "") -> QPushButton:
    b = QPushButton(text)
    if variant:
        b.setProperty("variant", variant)
    if icon_name:
        default = theme.BURGUNDY_DEEP if variant == "primary" else (theme.DANGER if variant == "danger" else theme.GOLD)
        b.setIcon(icons.icon(icon_name, icon_color or default))
        b.setIconSize(QSize(18, 18))
    if tooltip:
        b.setToolTip(tooltip)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    return b


def icon_button(icon_name: str, tooltip: str, color: str | None = None, danger: bool = False) -> QPushButton:
    b = make_button(variant="icon", icon_name=icon_name, icon_color=color or (theme.DANGER if danger else None),
                    tooltip=tooltip)
    b.setFixedSize(32, 32)
    return b


def add_shadow(widget: QWidget, blur: int = 28, alpha: int = 110) -> None:
    eff = QGraphicsDropShadowEffect(widget)
    eff.setBlurRadius(blur)
    eff.setOffset(0, 8)
    eff.setColor(QColor(0, 0, 0, alpha))
    widget.setGraphicsEffect(eff)


def clear_layout(layout) -> None:
    while layout.count():
        item = layout.takeAt(0)
        w = item.widget()
        if w is not None:
            w.setParent(None)
            w.deleteLater()
        elif item.layout() is not None:
            clear_layout(item.layout())


# ---------------------------------------------------------------------------- cards
class Card(QFrame):
    def __init__(self, parent=None, shadow: bool = True, inner: bool = False):
        super().__init__(parent)
        self.setObjectName("CardInner" if inner else "Card")
        if shadow and not inner:
            add_shadow(self)


def divider() -> QFrame:
    d = QFrame()
    d.setObjectName("Divider")
    d.setFixedHeight(1)
    return d


class ClickableFrame(QFrame):
    """A row that highlights on hover and emits `clicked` (child buttons keep their own clicks)."""

    clicked = Signal()

    def __init__(self, name: str = "Row", overdue: bool = False):
        super().__init__()
        self.setObjectName(name)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        base = theme.rgba(theme.DANGER, 0.12) if overdue else theme.rgba("#000000", 0.14)
        self.setStyleSheet(
            f"QFrame#{name} {{ background: {base}; border: 1px solid {theme.rgba(theme.GOLD, 0.2)}; border-radius: 12px; }}"
            f"QFrame#{name}:hover {{ background: {theme.rgba(theme.GOLD, 0.13)}; border-color: {theme.rgba(theme.GOLD, 0.75)}; }}"
        )

    def mouseReleaseEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and self.rect().contains(e.position().toPoint()):
            self.clicked.emit()
        super().mouseReleaseEvent(e)


class Badge(QLabel):
    """Small rounded coloured pill: status, priority, category."""

    def __init__(self, text: str, color: str, filled: bool = False):
        super().__init__(text)
        f = QFont(theme.BODY_FONT)
        f.setPointSizeF(8)
        f.setWeight(QFont.Weight.DemiBold)
        f.setCapitalization(QFont.Capitalization.AllUppercase)
        f.setLetterSpacing(QFont.SpacingType.AbsoluteSpacing, 0.8)
        self.setFont(f)
        bg = theme.rgba(color, 0.85 if filled else 0.16)
        fg = theme.BURGUNDY_DEEP if filled else color
        self.setStyleSheet(
            f"background: {bg}; color: {fg}; border: 1px solid {theme.rgba(color, 0.7)};"
            "border-radius: 10px; padding: 2px 9px;"
        )
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Fixed)


def status_badge(status: str) -> Badge:
    return Badge(status, theme.STATUS_COLORS.get(status, theme.GOLD))


def sample_badge() -> Badge:
    b = Badge("Sample", theme.ROSE)
    b.setToolTip("Sample data - not a real event. Remove it from the Dashboard settings strip.")
    return b


class Ornament(QWidget):
    """A thin gold line with a centred diamond: a classic Indian invitation divider."""

    def __init__(self, parent=None, width_limit: int | None = None):
        super().__init__(parent)
        self.setFixedHeight(16)
        self._limit = width_limit

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, cy = self.width(), self.height() / 2
        half = min(w, self._limit or w) / 2
        cx = w / 2
        grad = QLinearGradient(cx - half, 0, cx + half, 0)
        grad.setColorAt(0, qcolor(theme.GOLD, 0))
        grad.setColorAt(0.35, qcolor(theme.GOLD, 0.9))
        grad.setColorAt(0.65, qcolor(theme.GOLD, 0.9))
        grad.setColorAt(1, qcolor(theme.GOLD, 0))
        p.setPen(QPen(QBrush(grad), 1))
        p.drawLine(QPointF(cx - half, cy), QPointF(cx - 10, cy))
        p.drawLine(QPointF(cx + 10, cy), QPointF(cx + half, cy))
        p.setPen(QPen(qcolor(theme.GOLD), 1.2))
        p.setBrush(qcolor(theme.GOLD))
        d = QPainterPath()
        d.moveTo(cx, cy - 5); d.lineTo(cx + 5, cy); d.lineTo(cx, cy + 5); d.lineTo(cx - 5, cy); d.closeSubpath()
        p.drawPath(d)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx - 12, cy), 1.4, 1.4)
        p.drawEllipse(QPointF(cx + 12, cy), 1.4, 1.4)


class ToggleSwitch(QAbstractButton):
    """Paid / unpaid switch."""

    def __init__(self, checked: bool = False):
        super().__init__()
        self.setCheckable(True)
        self.setChecked(checked)
        self.setFixedSize(44, 24)
        self.setCursor(Qt.CursorShape.PointingHandCursor)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        on = self.isChecked()
        track = QRectF(1, 1, 42, 22)
        p.setPen(QPen(qcolor(theme.SUCCESS if on else theme.GOLD, 0.9), 1.2))
        p.setBrush(qcolor(theme.SUCCESS, 0.3) if on else qcolor("#000000", 0.25))
        p.drawRoundedRect(track, 11, 11)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qcolor(theme.SUCCESS if on else theme.GOLD))
        p.drawEllipse(QPointF(33 if on else 12, 12), 8, 8)


class ElidedButton(QPushButton):
    """Clickable chip that truncates its text with an ellipsis (calendar events)."""

    def __init__(self, text: str, color: str):
        super().__init__(text)
        self._color = color
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(20)
        self.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Fixed)
        self.setToolTip(text)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        r = QRectF(self.rect()).adjusted(0.5, 0.5, -0.5, -0.5)
        p.setPen(QPen(qcolor(self._color, 0.7), 1))
        p.setBrush(qcolor(self._color, 0.28 if self.underMouse() else 0.16))
        p.drawRoundedRect(r, 5, 5)
        f = self.font()
        f.setPointSizeF(8)
        p.setFont(f)
        p.setPen(qcolor(theme.IVORY))
        text = QFontMetrics(f).elidedText(self.text(), Qt.TextElideMode.ElideRight, int(r.width() - 10))
        p.drawText(r.adjusted(5, 0, -5, 0), Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft, text)


# ---------------------------------------------------------------------------- background
def _flower(p: QPainter, cx: float, cy: float, r: float, petals: int = 8) -> None:
    for i in range(petals):
        p.save()
        p.translate(cx, cy)
        p.rotate(i * 360 / petals)
        path = QPainterPath()
        path.moveTo(0, -r * 0.22)
        path.cubicTo(-r * 0.30, -r * 0.5, -r * 0.22, -r * 0.85, 0, -r)
        path.cubicTo(r * 0.22, -r * 0.85, r * 0.30, -r * 0.5, 0, -r * 0.22)
        p.drawPath(path)
        p.restore()
    p.drawEllipse(QPointF(cx, cy), r * 0.14, r * 0.14)


def _pattern_tile(size: int = 128) -> QPixmap:
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    p.setPen(QPen(qcolor(theme.GOLD, 0.075), 1.1))
    p.setBrush(Qt.BrushStyle.NoBrush)
    c = size / 2
    _flower(p, c, c, 26)
    p.drawEllipse(QPointF(c, c), 34, 34)
    for x, y in ((0, 0), (size, 0), (0, size), (size, size)):
        _flower(p, x, y, 18, 6)
    d = 5
    for x, y in ((c, 0), (0, c), (size, c), (c, size)):
        path = QPainterPath()
        path.moveTo(x, y - d); path.lineTo(x + d, y); path.lineTo(x, y + d); path.lineTo(x - d, y); path.closeSubpath()
        p.drawPath(path)
    p.end()
    return pm


class PatternBackground(QWidget):
    """Burgundy page with a faint tiled jaali / lotus pattern."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._tile = None

    def paintEvent(self, _):
        if self._tile is None:
            self._tile = _pattern_tile()
        p = QPainter(self)
        p.fillRect(self.rect(), QColor(theme.BURGUNDY))
        p.fillRect(self.rect(), QBrush(self._tile))


# ---------------------------------------------------------------------------- arch header
def arch_path(rect: QRectF, rise: float) -> QPainterPath:
    """Pointed Mughal-style arch: straight sides, curved shoulders meeting at an apex."""
    l, t, r, b = rect.left(), rect.top(), rect.right(), rect.bottom()
    cx = (l + r) / 2
    w = rect.width()
    path = QPainterPath()
    path.moveTo(l, b)
    path.lineTo(l, t + rise)
    path.cubicTo(l, t + rise * 0.42, l + w * 0.27, t + rise * 0.20, cx, t)
    path.cubicTo(r - w * 0.27, t + rise * 0.20, r, t + rise * 0.42, r, t + rise)
    path.lineTo(r, b)
    path.closeSubpath()
    return path


class ArchHeader(QFrame):
    """The signature dashboard header: gold arch outline, inner line and a soft glow from the top."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(220)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(40, 74, 40, 22)
        lay.setSpacing(4)
        lay.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        self.eyebrow = make_label("Zari  ·  Event & Finance Studio", "eyebrow", align=Qt.AlignmentFlag.AlignCenter)
        self.title = make_label("", "h1", align=Qt.AlignmentFlag.AlignCenter)
        self.subtitle = make_label("", "muted", align=Qt.AlignmentFlag.AlignCenter)
        self.orn = Ornament(width_limit=360)
        for w in (self.eyebrow, self.title, self.orn, self.subtitle):
            lay.addWidget(w)

    def set_texts(self, title: str, subtitle: str) -> None:
        self.title.setText(title)
        self.subtitle.setText(subtitle)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        full_w, h = self.width(), self.height()
        margin = 4.0
        w = min(full_w, 860)                      # a centred arch, not a full-width dome
        x0 = (full_w - w) / 2
        rise = min(120.0, h * 0.55)
        outer = QRectF(x0 + margin, margin, w - 2 * margin, h + 40)  # runs off the bottom: arch is "open"
        path = arch_path(outer, rise)

        # base fill + glow fading down from the apex
        p.save()
        p.setClipPath(path)
        fill = QLinearGradient(0, 0, 0, h)
        fill.setColorAt(0, qcolor("#7A2347"))
        fill.setColorAt(1, qcolor(theme.CARD, 0.65))
        p.fillPath(path, QBrush(fill))
        glow = QRadialGradient(QPointF(full_w / 2, margin), h * 1.05)
        glow.setColorAt(0, qcolor(theme.ROSE, 0.42))
        glow.setColorAt(0.5, qcolor(theme.ROSE, 0.12))
        glow.setColorAt(1, qcolor(theme.ROSE, 0))
        p.fillRect(self.rect(), QBrush(glow))
        # faint mandala behind the title
        p.setPen(QPen(qcolor(theme.GOLD, 0.12), 1.1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        _flower(p, full_w / 2, h * 0.52, min(h, w) * 0.62, 16)
        p.restore()

        # outer gold outline and the second thin inner line
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.setPen(QPen(qcolor(theme.GOLD), 2.0))
        p.drawPath(path)
        inner = arch_path(outer.adjusted(11, 11, -11, 0), rise - 6)
        p.setPen(QPen(qcolor(theme.GOLD, 0.55), 1.0))
        p.drawPath(inner)
        # small lotus finial at the apex
        p.setPen(QPen(qcolor(theme.GOLD), 1.3))
        p.setBrush(qcolor(theme.BURGUNDY_DEEP))
        p.drawEllipse(QPointF(full_w / 2, margin + 17), 9, 9)
        p.setBrush(Qt.BrushStyle.NoBrush)
        _flower(p, full_w / 2, margin + 17, 7, 8)


# ---------------------------------------------------------------------------- stat card
class StatCard(Card):
    clicked = Signal()

    def __init__(self, eyebrow: str):
        super().__init__()
        self.setMinimumHeight(128)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 18, 20, 16)
        lay.setSpacing(2)
        self.eyebrow = make_label(eyebrow, "eyebrow")
        self.value = make_label("-", "num")
        # Let the card shrink below the text's natural width; _fit() scales the font instead.
        self.value.setSizePolicy(QSizePolicy.Policy.Ignored, QSizePolicy.Policy.Preferred)
        self.note = make_label("", "small", wrap=True)
        lay.addWidget(self.eyebrow)
        lay.addStretch(1)
        lay.addWidget(self.value)
        lay.addWidget(self.note)

    def set(self, value: str, note: str = "", color: str | None = None, note_color: str | None = None) -> None:
        self.value.setText(value)
        set_label_color(self.value, color or theme.IVORY)
        self.note.setText(note)
        set_label_color(self.note, note_color or theme.IVORY_MUTED)
        self.note.setVisible(bool(note))
        self._fit()

    def _fit(self) -> None:
        """Shrink the big number until it fits, so 'AED 1,250,000' never gets clipped."""
        avail = self.width() - 52
        size = 28.0
        while size > 13:
            f = theme.heading_font(size, bold=True)
            if QFontMetrics(f).horizontalAdvance(self.value.text()) <= avail:
                break
            size -= 1
        self.value.setFont(theme.heading_font(size, bold=True))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._fit()


# ---------------------------------------------------------------------------- bar chart
def nice_ceiling(value: float) -> tuple[float, float]:
    """Return (axis_max, step) with 4 intervals and friendly round numbers."""
    if value <= 0:
        return 4.0, 1.0
    raw = value / 4
    mag = 10 ** math.floor(math.log10(raw))
    for m in (1, 2, 2.5, 5, 10):
        step = m * mag
        if step * 4 >= value:
            return step * 4, step
    return value, value / 4  # pragma: no cover


class BarChart(QWidget):
    """Six-month bar chart with a thin gold axis, k-style labels and hover tooltips."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumHeight(250)
        self.setMouseTracking(True)
        self._labels: list[str] = []
        self._values: list[int] = []
        self._color = theme.GOLD
        self._series = "Revenue"
        self._hover = -1

    def set_data(self, labels, values, color: str, series: str) -> None:
        self._labels, self._values, self._color, self._series = list(labels), list(values), color, series
        self.update()

    # layout helpers
    def _plot_rect(self) -> QRectF:
        return QRectF(52, 14, self.width() - 66, self.height() - 14 - 30)

    def _bar_rect(self, i: int, ymax: float) -> QRectF:
        plot = self._plot_rect()
        n = max(1, len(self._values))
        slot = plot.width() / n
        bw = min(46.0, slot * 0.55)
        h = max(0.0, self._values[i] / 100 / ymax) * plot.height() if ymax else 0
        return QRectF(plot.left() + slot * i + (slot - bw) / 2, plot.bottom() - h, bw, h)

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        plot = self._plot_rect()
        top = max([v / 100 for v in self._values] + [0])
        ymax, step = nice_ceiling(top)
        f = QFont(theme.BODY_FONT)
        f.setPointSizeF(8.5)
        p.setFont(f)
        for k in range(5):
            y = plot.bottom() - plot.height() * k / 4
            p.setPen(QPen(qcolor(theme.GOLD, 0.18), 1, Qt.PenStyle.DashLine if k else Qt.PenStyle.SolidLine))
            p.drawLine(QPointF(plot.left(), y), QPointF(plot.right(), y))
            p.setPen(qcolor(theme.IVORY_MUTED))
            p.drawText(QRectF(0, y - 9, plot.left() - 8, 18),
                       Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter, format_axis(int(step * k * 100)))
        n = len(self._values)
        for i in range(n):
            r = self._bar_rect(i, ymax)
            hovered = i == self._hover
            col = qcolor(self._color, 1.0 if hovered else 0.82)
            grad = QLinearGradient(0, r.top(), 0, plot.bottom())
            grad.setColorAt(0, col)
            grad.setColorAt(1, qcolor(self._color, 0.45))
            path = QPainterPath()
            if r.height() > 0.5:
                path.addRoundedRect(r, 5, 5)
                p.setPen(QPen(qcolor(theme.GOLD_SOFT, 0.5), 1) if hovered else Qt.PenStyle.NoPen)
                p.fillPath(path, QBrush(grad))
                if hovered:
                    p.drawPath(path)
            p.setPen(qcolor(theme.IVORY if hovered else theme.IVORY_MUTED))
            slot = plot.width() / max(1, n)
            p.drawText(QRectF(plot.left() + slot * i, plot.bottom() + 6, slot, 20), Qt.AlignmentFlag.AlignCenter,
                       self._labels[i])
        if not any(self._values):
            p.setPen(qcolor(theme.IVORY_MUTED))
            p.drawText(plot, Qt.AlignmentFlag.AlignCenter, "No payments recorded in this period")

    def _index_at(self, x: float) -> int:
        plot = self._plot_rect()
        n = len(self._values)
        if n == 0 or not (plot.left() <= x <= plot.right()):
            return -1
        return min(n - 1, int((x - plot.left()) / (plot.width() / n)))

    def mouseMoveEvent(self, e):
        i = self._index_at(e.position().x())
        if i != self._hover:
            self._hover = i
            self.update()
        if i >= 0:
            QToolTip.showText(e.globalPosition().toPoint(),
                              f"{self._labels[i]}\n{self._series}: {format_aed(self._values[i])}", self)
        else:
            QToolTip.hideText()

    def leaveEvent(self, _):
        self._hover = -1
        self.update()


# ---------------------------------------------------------------------------- budget vs actual chart
class BudgetChart(QWidget):
    """Horizontal bars per row: pale outline = budget, gold = actual spend, rose = committed (selected quotes),
    red = the part that is over budget. Hover a row for exact AED amounts."""

    ROW_H = 30
    LABEL_W = 118
    VALUE_W = 120
    LEGEND_H = 30

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMouseTracking(True)
        self._rows: list[tuple] = []
        self._hover = -1
        self.set_rows([])

    def set_rows(self, rows) -> None:
        """rows: [(label, budget_fils, actual_fils, committed_fils)]"""
        self._rows = list(rows)
        self.setMinimumHeight(max(1, len(self._rows)) * self.ROW_H + self.LEGEND_H + 14)
        self.updateGeometry()
        self.update()

    def sizeHint(self):
        return QSize(560, self.minimumHeight())

    def _scale(self) -> float:
        return max([max(b, a + c) for _l, b, a, c in self._rows] + [1])

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        f = QFont(theme.BODY_FONT)
        f.setPointSizeF(8.5)
        p.setFont(f)
        if not self._rows:
            p.setPen(qcolor(theme.IVORY_MUTED))
            p.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, "Set a budget or add expenses to see the chart")
            return
        x0 = self.LABEL_W
        plot_w = max(40, self.width() - self.LABEL_W - self.VALUE_W)
        scale = self._scale()
        fm = QFontMetrics(f)
        for i, (label, budget, actual, committed) in enumerate(self._rows):
            y = 6 + i * self.ROW_H
            bar_top, bar_h = y + 5, self.ROW_H - 12
            if i == self._hover:
                p.fillRect(QRectF(0, y, self.width(), self.ROW_H), qcolor(theme.GOLD, 0.08))
            p.setPen(qcolor(theme.IVORY))
            p.drawText(QRectF(0, y, self.LABEL_W - 8, self.ROW_H),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft,
                       fm.elidedText(label, Qt.TextElideMode.ElideRight, self.LABEL_W - 10))
            if budget:
                p.setPen(QPen(qcolor(theme.GOLD, 0.8), 1))
                p.setBrush(qcolor("#000000", 0.18))
                p.drawRoundedRect(QRectF(x0, bar_top, budget / scale * plot_w, bar_h), 4, 4)
            a_w, c_w = actual / scale * plot_w, committed / scale * plot_w
            p.setPen(Qt.PenStyle.NoPen)
            inner_top, inner_h = bar_top + 2, bar_h - 4
            if a_w > 0:
                p.setBrush(qcolor(theme.GOLD))
                p.drawRoundedRect(QRectF(x0 + 1, inner_top, max(a_w - 1, 2), inner_h), 3, 3)
            if c_w > 0:
                p.setBrush(qcolor(theme.ROSE))
                p.drawRoundedRect(QRectF(x0 + a_w, inner_top, c_w, inner_h), 3, 3)
            projected = actual + committed
            over = bool(budget) and projected > budget
            if over:
                ox = x0 + budget / scale * plot_w
                p.setBrush(qcolor(theme.DANGER))
                p.drawRect(QRectF(ox, inner_top, (projected - budget) / scale * plot_w, inner_h))
                p.setPen(QPen(qcolor(theme.IVORY), 1.4))
                p.drawLine(QPointF(ox, bar_top - 3), QPointF(ox, bar_top + bar_h + 3))
            p.setPen(qcolor(theme.DANGER if over else theme.IVORY_MUTED))
            text = f"{format_axis(projected)} / {format_axis(budget)}" if budget else f"{format_axis(projected)} (no budget)"
            p.drawText(QRectF(self.width() - self.VALUE_W + 8, y, self.VALUE_W - 8, self.ROW_H),
                       Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignRight, text)
        # legend
        ly = 6 + len(self._rows) * self.ROW_H + 6
        lx = x0
        for text, color, outline in (("Budget", "#000000", theme.GOLD), ("Actual", theme.GOLD, None),
                                     ("Committed", theme.ROSE, None), ("Over budget", theme.DANGER, None)):
            p.setBrush(qcolor(color, 0.18 if outline else 1.0))
            p.setPen(QPen(qcolor(outline, 0.8), 1) if outline else Qt.PenStyle.NoPen)
            p.drawRoundedRect(QRectF(lx, ly + 4, 14, 9), 2, 2)
            p.setPen(qcolor(theme.IVORY_MUTED))
            p.drawText(QPointF(lx + 19, ly + 13), text)
            lx += 19 + fm.horizontalAdvance(text) + 18

    def mouseMoveEvent(self, e):
        i = int((e.position().y() - 6) // self.ROW_H)
        i = i if 0 <= i < len(self._rows) else -1
        if i != self._hover:
            self._hover = i
            self.update()
        if i >= 0:
            label, budget, actual, committed = self._rows[i]
            left = budget - actual - committed
            QToolTip.showText(e.globalPosition().toPoint(),
                              f"{label}\nBudget: {format_aed(budget) if budget else 'not set'}\n"
                              f"Actual: {format_aed(actual)}\nCommitted: {format_aed(committed)}\n"
                              + (f"Left: {format_aed(left)}" if budget else ""), self)
        else:
            QToolTip.hideText()

    def leaveEvent(self, _):
        self._hover = -1
        self.update()
