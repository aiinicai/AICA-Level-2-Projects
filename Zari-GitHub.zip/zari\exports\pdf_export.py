"""Complete one-event PDF report (ReportLab): details, finances, budget vs actual with chart, payments,
expenses, vendor payables, quotations, guests, scenarios and documents."""
from __future__ import annotations

from datetime import date
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import KeepTogether, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from zari.exports.charts import budget_drawing
from zari.logic.finance import format_margin
from zari.logic.money import format_aed, format_bp

BURGUNDY = colors.HexColor("#5E1530")
GOLD = colors.HexColor("#C9A961")
INK = colors.HexColor("#3B2A30")
CONTENT_W = 174 * mm

STATUS_TEXT = {"none": "No budget", "ok": "On track", "warning": "Near limit", "over": "Over budget"}


def _plain(text: str) -> str:
    """Latin-1-safe text for plain table cells (no XML escaping: these are not Paragraphs)."""
    return str(text).encode("cp1252", "replace").decode("cp1252")


def _safe(text: str) -> str:
    """Built-in PDF fonts only cover Latin-1; replace anything else instead of crashing."""
    return escape(str(text).encode("cp1252", "replace").decode("cp1252"))


def _table(data, col_widths, right_cols=(), bold_last: bool = False, red_cells=()):
    t = Table(data, colWidths=col_widths, repeatRows=1)
    style = [
        ("BACKGROUND", (0, 0), (-1, 0), BURGUNDY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("GRID", (0, 0), (-1, -1), 0.4, GOLD), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F1E4")]),
        ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
    ]
    style += [("ALIGN", (c, 0), (c, -1), "RIGHT") for c in right_cols]
    if bold_last and len(data) > 1:
        style += [("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
                  ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#EBDDC3"))]
    style += [("TEXTCOLOR", (c, r), (c, r), colors.HexColor("#C0392B")) for r, c in red_cells]
    t.setStyle(TableStyle(style))
    return t


def _kv_table(rows, widths=(84 * mm, 90 * mm)):
    t = Table([[_plain(k), _plain(v)] for k, v in rows], colWidths=list(widths))
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("TEXTCOLOR", (0, 0), (0, -1), BURGUNDY), ("LINEBELOW", (0, 0), (-1, -1), 0.3, GOLD),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("TOPPADDING", (0, 0), (-1, -1), 3),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 3)]))
    return t


def _m(v) -> str:
    return "-" if v is None else format_aed(v)


def build_story(report) -> list:
    ev, f = report.event, report.event.fin
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Title"], textColor=BURGUNDY, fontName="Times-Bold", fontSize=22,
                        alignment=0, spaceAfter=2)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=BURGUNDY, fontName="Times-Bold", fontSize=13,
                        spaceBefore=10, spaceAfter=4)
    h3 = ParagraphStyle("h3", parent=styles["Heading3"], textColor=INK, fontName="Helvetica-Bold", fontSize=9,
                        spaceBefore=6, spaceAfter=2)
    body = ParagraphStyle("b", parent=styles["BodyText"], fontSize=8.5, leading=11)
    small = ParagraphStyle("s", parent=body, fontSize=7.5, textColor=colors.HexColor("#6B5A60"))
    story: list = []

    # ---- title ----
    story += [Paragraph(_safe(ev.name), h1),
              Paragraph(_safe(f"{ev.type}  |  {ev.date:%A, %d %B %Y}  |  {ev.venue}  |  Status: {ev.status}"), body),
              Paragraph(f"Complete event report generated {report.today:%d %b %Y}. All amounts in AED.", small),
              Spacer(1, 3 * mm)]

    # ---- 1. details ----
    story.append(Paragraph("1. Event details", h2))
    story.append(_kv_table([
        ("Client", ev.client), ("Event type", ev.type), ("Date", f"{ev.date:%d %b %Y}"), ("Venue", ev.venue),
        ("Expected guests", f"{ev.guests:,}"), ("Status", ev.status), ("Contract value", format_aed(ev.contract_value)),
        ("Contingency reserve", format_bp(ev.contingency_bp) if ev.contingency_bp else "None")]))

    # ---- 2. financial summary ----
    b = report.budget
    story.append(Paragraph("2. Financial summary", h2))
    summary = [("Contract value", format_aed(f.contract)), ("Payments received", format_aed(f.received)),
               ("Balance due from client", format_aed(f.balance_due)), ("Total expenses recorded", format_aed(f.expenses)),
               ("   of which unpaid to vendors", format_aed(f.unpaid_expenses)),
               ("Committed (selected quotes not yet expenses)", format_aed(b.total_committed)),
               ("Projected cost (expenses + committed)", format_aed(b.total_projected)),
               ("Gross profit (contract - expenses)", format_aed(f.profit)), ("Profit margin", format_margin(f.margin))]
    if b.total_budget:
        summary += [("Total budget", format_aed(b.total_budget)),
                    ("Budget left (after actual + committed)", format_aed(b.remaining))]
    story.append(_kv_table(summary))

    # ---- 3. budget vs actual ----
    story.append(Paragraph("3. Budget vs actual", h2))
    if b.lines:
        rows = [["Category", "Budget", "Open quotes", "Committed", "Actual", "Left", "Status"]]
        red = []
        for i, l in enumerate(b.lines, 1):
            rows.append([l.category, _m(l.budget) if l.budget else "-", _m(l.quoted) if l.quoted else "-",
                         _m(l.committed) if l.committed else "-", _m(l.actual) if l.actual else "-",
                         _m(l.remaining) if l.budget else "-", STATUS_TEXT[l.status]])
            if l.budget and l.remaining < 0:
                red.append((i, 5))
        rows.append(["Total", _m(b.total_budget) if b.total_budget else "-", _m(b.total_quoted) if b.total_quoted else "-",
                     _m(b.total_committed) if b.total_committed else "-", _m(b.total_actual),
                     _m(b.remaining) if b.total_budget else "-", STATUS_TEXT[b.status]])
        story.append(_table(rows, [30 * mm, 26 * mm, 24 * mm, 24 * mm, 26 * mm, 24 * mm, 20 * mm], right_cols=(1, 2, 3, 4, 5),
                            bold_last=True, red_cells=red))
        if b.contingency:
            story.append(Paragraph(
                f"Contingency reserve {format_bp(ev.contingency_bp)} = {format_aed(b.contingency)} held back; "
                f"{format_aed(b.remaining_after_contingency)} left after it.", small))
        story += [Spacer(1, 3 * mm), budget_drawing(report.chart_rows, width=CONTENT_W, title="Budget vs actual by category")]
    else:
        story.append(Paragraph("No budget has been set and no expenses recorded yet.", body))

    # ---- 4. payments ----
    story.append(Paragraph("4. Payments received", h2))
    if report.payments:
        rows = [["Date", "Label", "Amount"]] + [[f"{p.date:%d %b %Y}", _plain(p.label), format_aed(p.amount)]
                                                  for p in report.payments]
        rows.append(["", f"Total ({f.progress * 100:.0f}% of contract)", format_aed(f.received)])
        story.append(_table(rows, [35 * mm, 99 * mm, 40 * mm], right_cols=(2,), bold_last=True))
    else:
        story.append(Paragraph("No payments recorded.", body))

    # ---- 5. expenses ----
    story.append(Paragraph("5. Expenses", h2))
    if report.expenses:
        rows = [["Category", "Description", "Vendor", "Invoice", "Due", "Status", "Amount"]]
        for e in report.expenses:
            rows.append([e.category, Paragraph(_safe(e.description), body), Paragraph(_safe(e.vendor or "-"), body),
                         _plain(e.invoice_no or "-"), f"{e.due_date:%d %b}" if e.due_date and not e.paid else "-",
                         "Paid" if e.paid else "Unpaid", format_aed(e.amount)])
        rows.append(["Total", f"of which unpaid: {format_aed(f.unpaid_expenses)}", "", "", "", "", format_aed(f.expenses)])
        story.append(_table(rows, [24 * mm, 46 * mm, 30 * mm, 18 * mm, 13 * mm, 20 * mm, 23 * mm], right_cols=(6,),
                            bold_last=True))
    else:
        story.append(Paragraph("No expenses recorded.", body))

    # ---- 6. vendor payables ----
    story.append(Paragraph("6. Vendor payables for this event", h2))
    if report.vendor_rows:
        rows = [["Vendor", "Items", "Total", "Paid", "Unpaid", "Next payment due"]]
        for p in report.vendor_rows:
            rows.append([_plain(p.vendor), p.items, format_aed(p.total), format_aed(p.paid), format_aed(p.unpaid),
                         f"{p.next_due:%d %b %Y}" if p.next_due else "-"])
        rows.append(["Total", sum(p.items for p in report.vendor_rows), format_aed(sum(p.total for p in report.vendor_rows)),
                     format_aed(sum(p.paid for p in report.vendor_rows)),
                     format_aed(sum(p.unpaid for p in report.vendor_rows)), ""])
        story.append(_table(rows, [44 * mm, 14 * mm, 28 * mm, 28 * mm, 28 * mm, 32 * mm], right_cols=(1, 2, 3, 4),
                            bold_last=True))
    else:
        story.append(Paragraph("No expenses with a vendor name recorded.", body))

    # ---- 7. quotations ----
    story.append(Paragraph("7. Vendor quotations", h2))
    if report.quote_groups:
        for g in report.quote_groups:
            rows = [["Vendor", "Price", "vs lowest", "Deposit", "Rating", "Valid until", "Status / notes"]]
            for v in g.views:
                q = v.quote
                tags = [q.status] + [t for t, on in (("lowest price", v.is_lowest), ("top rated", v.is_top_rated),
                                                     ("suggested best value", v.is_suggested), ("expired", v.expired),
                                                     ("now an expense", bool(q.expense_id))) if on]
                rows.append([Paragraph(_safe(q.vendor_name), body), format_aed(q.amount),
                             "-" if v.vs_lowest_pct is None else ("cheapest" if v.vs_lowest_pct < 0.05 else f"+{v.vs_lowest_pct:.0f}%"),
                             format_aed(q.deposit) if q.deposit else "-", f"{q.rating}/5" if q.rating else "-",
                             f"{q.valid_until:%d %b %Y}" if q.valid_until else "-",
                             Paragraph(_safe(", ".join(tags)), small)])
            story.append(KeepTogether([Paragraph(_safe(f"{g.requirement}  ({g.category})"), h3),
                                       _table(rows, [38 * mm, 24 * mm, 17 * mm, 22 * mm, 14 * mm, 24 * mm, 35 * mm],
                                              right_cols=(1, 2, 3, 4))]))
        story.append(Paragraph("Zari highlights facts and suggests a best value; the vendor is always chosen by you.", small))
    else:
        story.append(Paragraph("No quotations recorded.", body))

    # ---- 8. guests ----
    gs = report.guest_stats
    story.append(Paragraph("8. Guests and RSVP", h2))
    if report.guests:
        story.append(Paragraph(
            f"{gs['parties']} invitations covering {gs['heads_total']} people. Confirmed: {gs['confirmed']} "
            f"({gs['heads_confirmed']} people). Pending: {gs['pending']} ({gs['heads_pending']} people). "
            f"Declined: {gs['declined']}. Expected guests: {ev.guests:,}. "
            "Phone numbers and emails are intentionally not included in this report.", body))
        rows = [["Name", "Party", "Group", "Invited", "RSVP"]] + [
            [Paragraph(_safe(g.name), body), g.party_size, _plain(g.group or "-"), "Yes" if g.invited else "No", g.rsvp]
            for g in report.guests]
        story += [Spacer(1, 2 * mm), _table(rows, [70 * mm, 16 * mm, 46 * mm, 18 * mm, 24 * mm], right_cols=(1,))]
    else:
        story.append(Paragraph("No guests recorded.", body))

    # ---- 9. scenarios ----
    story.append(Paragraph("9. Scenario comparison", h2))
    cols = [("Current plan", report.baseline)] + [(s.name, p) for s, p in report.scenarios]
    if len(cols) > 1:
        rows = [["", *[_plain(n) for n, _p in cols]],
                ["Guests", *[f"{p.guests:,}" for _n, p in cols]],
                ["Contract value", *[format_aed(p.contract) for _n, p in cols]],
                ["Costs before contingency", *[format_aed(p.subtotal) for _n, p in cols]],
                ["Contingency", *[format_aed(p.contingency) for _n, p in cols]],
                ["Total cost", *[format_aed(p.total_cost) for _n, p in cols]],
                ["Gross profit", *[format_aed(p.profit) for _n, p in cols]],
                ["Margin", *[format_margin(p.margin) for _n, p in cols]]]
        first = 46 * mm
        rest = (CONTENT_W - first) / len(cols)
        story.append(_table(rows, [first] + [rest] * len(cols), right_cols=tuple(range(1, len(cols) + 1))))
        story.append(Paragraph("Scenarios are what-if plans only; they do not change the event's real figures.", small))
    else:
        story.append(Paragraph("No scenarios saved.", body))

    # ---- 10. documents ----
    story.append(Paragraph("10. Attached documents", h2))
    if report.documents:
        rows = [["Type", "Title", "File", "Linked expense", "Added"]] + [
            [d.kind, Paragraph(_safe(d.title), body), Paragraph(_safe(d.original_name), body),
             Paragraph(_safe(d.expense_label or "-"), body), d.added_at[:10]] for d in report.documents]
        story.append(_table(rows, [20 * mm, 48 * mm, 46 * mm, 40 * mm, 20 * mm]))
    else:
        story.append(Paragraph("No documents attached.", body))
    return story


def export_event_pdf(path: str | Path, report) -> Path:
    name = _plain(report.event.name)

    def footer(canvas, doc):
        canvas.saveState()
        canvas.setFont("Helvetica", 7.5)
        canvas.setFillColor(colors.HexColor("#6B5A60"))
        canvas.drawString(18 * mm, 9 * mm, f"Zari  |  {name}")
        canvas.drawRightString(A4[0] - 18 * mm, 9 * mm, f"Page {doc.page}")
        canvas.setStrokeColor(GOLD)
        canvas.line(18 * mm, 12 * mm, A4[0] - 18 * mm, 12 * mm)
        canvas.restoreState()

    path = Path(path)
    doc = SimpleDocTemplate(str(path), pagesize=A4, leftMargin=18 * mm, rightMargin=18 * mm, topMargin=16 * mm,
                            bottomMargin=18 * mm, title=name, author="Zari")
    doc.build(build_story(report), onFirstPage=footer, onLaterPages=footer)
    return path
