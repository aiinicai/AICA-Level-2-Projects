"""Excel exports. Numbers are written as real numbers (AED), computed from the same integer-fils values
the app shows, so exported totals always agree with the screen."""
from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

from zari.exports.charts import add_excel_budget_chart
from zari.logic.finance import format_margin
from zari.logic.money import format_bp

AED_FMT = '"AED" #,##0.00'
HEADER_FILL = PatternFill("solid", fgColor="5E1530")
HEADER_FONT = Font(bold=True, color="FBF5EC")
BOLD = Font(bold=True)
STATUS_TEXT = {"none": "No budget", "ok": "On track", "warning": "Near limit", "over": "Over budget"}


def _aed(fils: int | None) -> float | None:
    return None if fils is None else fils / 100


def harden_workbook(wb) -> None:
    """Zari never writes formulas, so any cell openpyxl would treat as one is really user text that
    starts with '=', '+', '-' or '@'. Store it as plain text so opening the file can't run anything."""
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if cell.data_type == "f":
                    cell.data_type = "s"


def _header(ws, row: int, titles: list[str]) -> None:
    for col, title in enumerate(titles, 1):
        c = ws.cell(row=row, column=col, value=title)
        c.fill, c.font = HEADER_FILL, HEADER_FONT
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _autosize(ws) -> None:
    for col in ws.columns:
        width = max((len(str(c.value)) for c in col if c.value is not None and not str(c.value).startswith("<")), default=8)
        ws.column_dimensions[get_column_letter(col[0].column)].width = min(max(width + 3, 12), 48)


def _table(ws, titles, rows, money_cols=(), start_row: int = 1, total_label: str | None = None, total_cols=()):
    """Write a header + rows; money_cols (1-based) get AED formatting. Optional totals row. Returns last data row."""
    _header(ws, start_row, titles)
    r = start_row
    for r, values in enumerate(rows, start_row + 1):
        for c, v in enumerate(values, 1):
            cell = ws.cell(row=r, column=c, value=_aed(v) if (c in money_cols and isinstance(v, int)) else v)
            if c in money_cols and isinstance(v, int):
                cell.number_format = AED_FMT
    last = r if rows else start_row
    if total_label and rows:
        tr = last + 1
        ws.cell(row=tr, column=1, value=total_label).font = BOLD
        for c in total_cols:
            total = sum(v[c - 1] for v in rows if isinstance(v[c - 1], int))
            cell = ws.cell(row=tr, column=c, value=_aed(total) if c in money_cols else total)
            cell.font = BOLD
            if c in money_cols:
                cell.number_format = AED_FMT
    return last


def export_event_workbook(path: str | Path, report) -> Path:
    """One workbook with every part of the event: summary, budget (with chart), payments, expenses,
    vendors, quotes, guests (no contact details), scenarios and documents."""
    ev, f, b = report.event, report.event.fin, report.budget
    wb = Workbook()

    # ---- Summary ----
    ws = wb.active
    ws.title = "Summary"
    rows = [
        ("Event", ev.name), ("Client", ev.client), ("Type", ev.type), ("Date", ev.date.isoformat()),
        ("Venue", ev.venue), ("Expected guests", ev.guests), ("Status", ev.status), (None, None),
        ("Contract value", _aed(f.contract)), ("Payments received", _aed(f.received)),
        ("Balance due from client", _aed(f.balance_due)), ("Total expenses recorded", _aed(f.expenses)),
        ("   of which unpaid to vendors", _aed(f.unpaid_expenses)), ("Committed (selected quotes)", _aed(b.total_committed)),
        ("Projected cost (expenses + committed)", _aed(b.total_projected)), ("Gross profit", _aed(f.profit)),
        ("Profit margin", format_margin(f.margin)), (None, None),
        ("Total budget", _aed(b.total_budget)), ("Budget left", _aed(b.remaining) if b.total_budget else None),
        ("Contingency reserve", format_bp(ev.contingency_bp) if ev.contingency_bp else "None"),
        (None, None), ("Report generated", report.today.isoformat()),
    ]
    for r, (k, v) in enumerate(rows, 1):
        if k is None:
            continue
        ws.cell(row=r, column=1, value=k).font = BOLD
        cell = ws.cell(row=r, column=2, value=v)
        if isinstance(v, float):
            cell.number_format = AED_FMT
    _autosize(ws)

    # ---- Budget (+ chart) ----
    wsb = wb.create_sheet("Budget vs Actual")
    lines = [[l.category, l.budget, l.quoted, l.committed, l.actual, l.remaining if l.budget else None,
              f"{l.used_pct:.0f}%" if l.used_pct is not None else "-", STATUS_TEXT[l.status]] for l in b.lines]
    last = _table(wsb, ["Category", "Budget", "Open quotes (cheapest)", "Committed", "Actual", "Left", "Used", "Status"],
                  lines, money_cols=(2, 3, 4, 5, 6), total_label="Total", total_cols=(2, 3, 4, 5))
    if lines:
        wsb.cell(row=last + 1, column=6, value=_aed(b.remaining) if b.total_budget else None).number_format = AED_FMT
        wsb.cell(row=last + 1, column=6).font = BOLD
        wsb.cell(row=last + 3, column=1, value="Contingency reserve").font = BOLD
        wsb.cell(row=last + 3, column=2, value=_aed(b.contingency)).number_format = AED_FMT
        wsb.cell(row=last + 4, column=1, value="Left after contingency").font = BOLD
        wsb.cell(row=last + 4, column=2, value=_aed(b.remaining_after_contingency)).number_format = AED_FMT
        add_excel_budget_chart(wsb, 2, last, "J2", "Budget vs actual by category", 1, 2, 5, 4)
    _autosize(wsb)

    # ---- Payments ----
    wsp = wb.create_sheet("Payments")
    _table(wsp, ["Date", "Label", "Amount"], [[p.date.isoformat(), p.label, p.amount] for p in report.payments],
           money_cols=(3,), total_label="Total", total_cols=(3,))
    _autosize(wsp)

    # ---- Expenses ----
    wse = wb.create_sheet("Expenses")
    _table(wse, ["Category", "Description", "Vendor", "Invoice no.", "Expense date", "Payment due", "Status", "Amount"],
           [[e.category, e.description, e.vendor, e.invoice_no, e.date.isoformat() if e.date else "",
             e.due_date.isoformat() if e.due_date else "", "Paid" if e.paid else "Unpaid", e.amount]
            for e in report.expenses], money_cols=(8,), total_label="Total", total_cols=(8,))
    _autosize(wse)

    # ---- Vendors ----
    wsv = wb.create_sheet("Vendor payables")
    _table(wsv, ["Vendor", "Items", "Total", "Paid", "Unpaid", "Next payment due"],
           [[p.vendor, p.items, p.total, p.paid, p.unpaid, p.next_due.isoformat() if p.next_due else ""]
            for p in report.vendor_rows], money_cols=(3, 4, 5), total_label="Total", total_cols=(2, 3, 4, 5))
    _autosize(wsv)

    # ---- Quotes ----
    wsq = wb.create_sheet("Quotations")
    qrows = []
    for g in report.quote_groups:
        for v in g.views:
            q = v.quote
            tags = ", ".join(t for t, on in (("lowest price", v.is_lowest), ("top rated", v.is_top_rated),
                                             ("suggested best value", v.is_suggested), ("expired", v.expired),
                                             ("now an expense", bool(q.expense_id))) if on)
            qrows.append([g.requirement, g.category, q.vendor_name, q.amount,
                          None if v.vs_lowest_pct is None else round(v.vs_lowest_pct, 1), q.deposit,
                          q.rating or "", q.valid_until.isoformat() if q.valid_until else "", q.status, tags, q.notes])
    _table(wsq, ["Requirement", "Category", "Vendor", "Price", "% above lowest", "Deposit", "Rating (1-5)", "Valid until",
                 "Status", "Highlights", "Notes"], qrows, money_cols=(4, 6))
    _autosize(wsq)

    # ---- Guests (no contact details, on purpose) ----
    wsg = wb.create_sheet("Guests")
    gs = report.guest_stats
    wsg.cell(row=1, column=1, value="Contact details are intentionally not included in this report.").font = Font(italic=True)
    wsg.cell(row=2, column=1, value=f"{gs['parties']} invitations, {gs['heads_total']} people  |  confirmed {gs['confirmed']} "
                                    f"({gs['heads_confirmed']} people)  |  pending {gs['pending']}  |  declined {gs['declined']}  |  "
                                    f"expected {ev.guests:,}")
    _table(wsg, ["Name", "Party size", "Group", "Invited", "RSVP", "Notes"],
           [[g.name, g.party_size, g.group, "Yes" if g.invited else "No", g.rsvp, g.notes] for g in report.guests],
           start_row=4)
    _autosize(wsg)

    # ---- Scenarios ----
    wss = wb.create_sheet("Scenarios")
    cols = [("Current plan", report.baseline)] + [(s.name, p) for s, p in report.scenarios]
    wss_rows = [("Guests", lambda p: p.guests, False), ("Contract value", lambda p: p.contract, True),
                ("Costs before contingency", lambda p: p.subtotal, True), ("Contingency", lambda p: p.contingency, True),
                ("Total cost", lambda p: p.total_cost, True), ("Gross profit", lambda p: p.profit, True),
                ("Margin", lambda p: format_margin(p.margin), False)]
    _header(wss, 1, [""] + [n for n, _p in cols])
    for r, (label, fn, money) in enumerate(wss_rows, 2):
        wss.cell(row=r, column=1, value=label).font = BOLD
        for c, (_n, p) in enumerate(cols, 2):
            v = fn(p)
            cell = wss.cell(row=r, column=c, value=_aed(v) if money else v)
            if money:
                cell.number_format = AED_FMT
    wss.cell(row=len(wss_rows) + 3, column=1, value="Scenarios are what-if plans; they do not change the real event.").font = Font(italic=True)
    _autosize(wss)

    # ---- Documents ----
    wsd = wb.create_sheet("Documents")
    _table(wsd, ["Type", "Title", "File", "Size (KB)", "Linked expense", "Added"],
           [[d.kind, d.title, d.original_name, round(d.size / 1024, 1), d.expense_label or "", d.added_at[:10]]
            for d in report.documents])
    _autosize(wsd)

    harden_workbook(wb)
    path = Path(path)
    wb.save(path)
    return path


def export_all_events(path: str | Path, summaries) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "Events"
    _header(ws, 1, ["Event", "Client", "Type", "Date", "Venue", "Guests", "Status",
                    "Contract value", "Received", "Balance due", "Expenses", "Gross profit", "Margin"])
    for i, e in enumerate(summaries, 2):
        f = e.fin
        values = [e.name, e.client, e.type, e.date.isoformat(), e.venue, e.guests, e.status,
                  _aed(f.contract), _aed(f.received), _aed(f.balance_due), _aed(f.expenses),
                  _aed(f.profit), format_margin(f.margin)]
        for col, v in enumerate(values, 1):
            cell = ws.cell(row=i, column=col, value=v)
            if 8 <= col <= 12:
                cell.number_format = AED_FMT
    _autosize(ws)
    harden_workbook(wb)
    path = Path(path)
    wb.save(path)
    return path
