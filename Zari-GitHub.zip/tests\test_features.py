"""Vendors/quotes, budgets, scenarios, guests, documents, alerts, reports and the v1 -> v2 upgrade."""
import sqlite3
from datetime import date, timedelta

import pytest

from zari.db import database
from zari.db.database import SCHEMA_VERSION, Database
from zari.db.repo_vendors import RepositoryError
from zari.logic import alerts, attachments, budget, quotes as quote_logic, reports, scenario
from zari.logic.money import apply_bp, format_bp, parse_percent
from zari.logic.validation import (
    ValidationError, validate_budget_amount, validate_document, validate_event, validate_expense, validate_guest,
    validate_payment, validate_quote, validate_scenario, validate_vendor,
)

TODAY = date(2026, 10, 21)


def D(n):
    return TODAY + timedelta(days=n)


def mk_event(repo, name="Gala", guests=100, contract="200,000", status="Confirmed"):
    return repo.add_event(validate_event(name, "Client", "Gala", D(30), "Venue", guests, status, contract))


def mk_vendor(repo, name, category="Catering"):
    return repo.add_vendor(validate_vendor(name, category))


def mk_quote(repo, eid, vendor_id, amount, req="Catering for guests", cat="Catering", rating=None,
             status="Received", valid=None, deposit=""):
    return repo.add_quote(eid, validate_quote(req, cat, vendor_id, amount, deposit, valid, rating, status))


# ---- upgrade from the first released schema ------------------------------------------
def test_v1_database_upgrades_to_current_without_losing_data(tmp_path):
    path = tmp_path / "old.db"
    c = sqlite3.connect(path)
    c.executescript(f"BEGIN;{database.MIGRATIONS[0]}PRAGMA user_version = 1;COMMIT;")
    c.execute("INSERT INTO events (name, client, type, date, venue, guests, status, contract_value)"
              " VALUES ('Old','C','Wedding','2026-12-01','V',50,'Confirmed',1000000)")
    c.execute("INSERT INTO expenses (event_id, category, description, amount) VALUES (1,'Venue','Hall',500000)")
    c.commit()
    c.close()
    db = Database(path)
    assert db.conn.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert db.conn.execute("SELECT name FROM events").fetchone()[0] == "Old"
    assert db.conn.execute("SELECT due_date, amount FROM expenses").fetchone()[:] == (None, 500000)
    tables = {r[0] for r in db.conn.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    assert {"vendors", "quotes", "budgets", "guests", "documents", "scenarios"} <= tables
    db.close()


# ---- percentages ----------------------------------------------------------------------
def test_percent_helpers():
    assert parse_percent("12.5%", -90, 500) == 1250 and parse_percent("-7", -90, 500) == -700
    assert parse_percent("", 0, 100) == 0
    for bad in ("abc", "1.234", "600"):
        with pytest.raises(ValueError):
            parse_percent(bad, -90, 500)
    assert apply_bp(10_000_00, 1000) == 11_000_00 and apply_bp(1001, -5000) == 501  # half-up
    assert format_bp(1250) == "12.5%" and format_bp(500) == "5%" and format_bp(800, signed=True) == "+8.0%"


# ---- vendors & quotes -----------------------------------------------------------------
def test_vendor_crud_unique_and_delete_protection(repo):
    vid = mk_vendor(repo, "Marigold Studio", "Decor")
    with pytest.raises(RepositoryError, match="already exists"):
        repo.add_vendor(validate_vendor("marigold studio", "Decor"))
    repo.update_vendor(vid, validate_vendor("Marigold Studio LLC", "Decor", "Sunita", "+971 50 123 4567", "a@b.co"))
    assert repo.get_vendor(vid).phone == "+971 50 123 4567"
    eid = mk_event(repo)
    qid = mk_quote(repo, eid, vid, "5,000", "Stage", "Decor")
    with pytest.raises(RepositoryError, match="quotation"):
        repo.delete_vendor(vid)
    repo.delete_quote(qid)
    repo.delete_vendor(vid)
    assert repo.list_vendors() == []


def test_vendor_validation():
    with pytest.raises(ValidationError) as e:
        validate_vendor("", "Nonsense", phone="abc", email="not-an-email")
    assert set(e.value.errors) == {"name", "category", "phone", "email"}


def test_quote_validation():
    with pytest.raises(ValidationError) as e:
        validate_quote("", "Venue", None, "100", "500", None, 9, "Received")
    assert {"requirement", "vendor", "deposit", "rating"} <= set(e.value.errors)


def test_selecting_a_quote_is_manual_and_exclusive(repo):
    eid = mk_event(repo)
    v1, v2, v3 = (mk_vendor(repo, n) for n in ("Cheap Caterers", "Good Caterers", "Best Caterers"))
    q1 = mk_quote(repo, eid, v1, "10,000", rating=2)
    q2 = mk_quote(repo, eid, v2, "12,000", rating=5)
    q3 = mk_quote(repo, eid, v3, "15,000", rating=4)
    assert all(q.status == "Received" for q in repo.list_quotes(eid))  # nothing is auto-selected
    repo.select_quote(q2)
    repo.select_quote(q3)  # choosing another one un-selects the previous
    status = {q.id: q.status for q in repo.list_quotes(eid)}
    assert status == {q1: "Received", q2: "Received", q3: "Selected"}


def test_comparison_highlights_but_does_not_choose(repo):
    eid = mk_event(repo)
    cheap = mk_vendor(repo, "Cheap"); good = mk_vendor(repo, "Good"); pricey = mk_vendor(repo, "Pricey")
    mk_quote(repo, eid, cheap, "10,000", rating=2)
    mk_quote(repo, eid, good, "11,000", rating=5)
    mk_quote(repo, eid, pricey, "20,000", rating=5)
    mk_quote(repo, eid, mk_vendor(repo, "Rejected One"), "5,000", rating=5, status="Rejected")
    (group,) = quote_logic.group_quotes(repo.list_quotes(eid), TODAY)
    by_vendor = {v.quote.vendor_name: v for v in group.views}
    assert by_vendor["Cheap"].is_lowest and not by_vendor["Good"].is_lowest
    assert by_vendor["Good"].is_top_rated and by_vendor["Pricey"].is_top_rated
    assert by_vendor["Good"].is_suggested and not by_vendor["Cheap"].is_suggested  # value, not just price
    assert round(by_vendor["Good"].vs_lowest_pct) == 10
    assert not by_vendor["Rejected One"].is_lowest  # rejected quotes never count as the cheapest
    assert group.selected is None  # nothing chosen on your behalf


def test_expired_quotes_flagged_and_not_suggested(repo):
    eid = mk_event(repo)
    a, b = mk_vendor(repo, "A"), mk_vendor(repo, "B")
    mk_quote(repo, eid, a, "10,000", rating=5, valid=D(-3))
    mk_quote(repo, eid, b, "12,000", rating=3, valid=D(10))
    (g,) = quote_logic.group_quotes(repo.list_quotes(eid), TODAY)
    views = {v.quote.vendor_name: v for v in g.views}
    assert views["A"].expired and not views["A"].is_suggested and views["B"].is_suggested


# ---- budget: separate cost layers, no double counting ----------------------------------
def test_budget_layers_and_no_double_counting_on_conversion(repo):
    eid = mk_event(repo)
    v = mk_vendor(repo, "Caterer")
    repo.set_budget(eid, "Catering", validate_budget_amount("50,000"))
    repo.add_expense(eid, validate_expense("Catering", "Starters", "10,000"))
    open_q = mk_quote(repo, eid, mk_vendor(repo, "Rival"), "30,000", "Main course", "Catering")
    sel_q = mk_quote(repo, eid, v, "20,000", "Dessert", "Catering")
    repo.select_quote(sel_q)

    s = budget.summarize(repo.get_budgets(eid), repo.list_expenses(eid), repo.list_quotes(eid))
    (line,) = s.lines
    assert (line.budget, line.actual, line.committed, line.quoted) == (5_000_000, 1_000_000, 2_000_000, 3_000_000)
    assert line.projected == 3_000_000 and line.remaining == 2_000_000 and line.status == "ok"

    repo.convert_quote_to_expense(sel_q)
    s2 = budget.summarize(repo.get_budgets(eid), repo.list_expenses(eid), repo.list_quotes(eid))
    (line2,) = s2.lines
    assert (line2.actual, line2.committed) == (3_000_000, 0)   # moved from committed to actual ...
    assert line2.projected == line.projected                    # ... and counted exactly once
    with pytest.raises(RepositoryError, match="already"):
        repo.convert_quote_to_expense(sel_q)
    with pytest.raises(RepositoryError, match="Select"):
        repo.convert_quote_to_expense(open_q)

    # deleting the expense returns the quote to "committed" (still counted once)
    exp = next(x for x in repo.list_expenses(eid) if x.description == "Dessert")
    repo.delete_expense(exp.id)
    (line3,) = budget.summarize(repo.get_budgets(eid), repo.list_expenses(eid), repo.list_quotes(eid)).lines
    assert line3.committed == 2_000_000 and line3.projected == line.projected


def test_budget_status_flags_and_contingency(repo):
    eid = mk_event(repo)
    repo.set_budget(eid, "Venue", 10_000_00)
    repo.set_budget(eid, "Decor", 10_000_00)
    repo.add_expense(eid, validate_expense("Venue", "Hall", "9,500"))     # 95% -> approaching limit
    repo.add_expense(eid, validate_expense("Decor", "Flowers", "11,000"))  # over
    s = budget.summarize(repo.get_budgets(eid), repo.list_expenses(eid), repo.list_quotes(eid), 1000)
    by = {l.category: l for l in s.lines}
    assert by["Venue"].status == "warning" and by["Decor"].status == "over"
    assert s.contingency == 2_000_00 and s.total_budget == 20_000_00
    assert s.remaining == -500_00 and s.status == "over"
    repo.set_budget(eid, "Decor", 0)  # clearing a budget removes the allocation
    assert "Decor" not in repo.get_budgets(eid)
    repo.set_contingency(eid, 500)
    assert repo.get_event(eid).contingency_bp == 500


# ---- scenarios ------------------------------------------------------------------------
def test_scenario_projection_math():
    base = {"Catering": 100_000_00, "Venue": 50_000_00}
    now = scenario.baseline(base, 300_000_00, 100)
    assert now.total_cost == 150_000_00 and now.profit == 150_000_00 and round(now.margin) == 50
    plan = scenario.Plan("More guests", 150, contract_bp=2000, contingency_bp=500,
                         adjust_bp={"Venue": 1000}, per_guest=("Catering",))
    p = scenario.project(base, 300_000_00, 100, plan)
    assert p.category_costs == {"Catering": 150_000_00, "Venue": 55_000_00}   # catering scales, venue +10%
    assert p.subtotal == 205_000_00 and p.contingency == 10_250_00 and p.total_cost == 215_250_00
    assert p.contract == 360_000_00 and p.profit == 144_750_00


def test_saving_a_scenario_never_changes_real_records(repo):
    eid = mk_event(repo, guests=100, contract="200,000")
    repo.add_expense(eid, validate_expense("Catering", "Food", "40,000"))
    before = (repo.get_event(eid), repo.list_expenses(eid), repo.list_payments(eid))
    data = validate_scenario("Bigger party", 180, "10", "5", {"Catering": "8", "Venue": ""}, ("Catering",))
    sid = repo.save_scenario(eid, data)
    after = (repo.get_event(eid), repo.list_expenses(eid), repo.list_payments(eid))
    assert before == after
    (saved,) = repo.list_scenarios(eid)
    assert (saved.name, saved.guests, saved.contract_bp, saved.contingency_bp) == ("Bigger party", 180, 1000, 500)
    assert saved.adjust_bp == {"Catering": 800} and saved.per_guest == ("Catering",)
    repo.delete_scenario(sid)
    assert repo.list_scenarios(eid) == []


def test_applying_a_scenario_updates_only_guests_contract_contingency(repo, data_dir):
    eid = mk_event(repo, guests=100, contract="200,000")
    repo.add_payment(eid, validate_payment("50,000", D(-5), "Deposit"))
    repo.add_expense(eid, validate_expense("Catering", "Food", "40,000"))
    repo.apply_scenario(eid, 150, 25_000_000, 500)
    ev = repo.get_event(eid)
    assert (ev.guests, ev.contract_value, ev.contingency_bp) == (150, 25_000_000, 500)
    assert ev.received == 5_000_000 and ev.expenses == 4_000_000   # money records untouched
    assert list((data_dir / "backups").glob("auto-before-apply-scenario-*.db"))


def test_scenario_validation():
    with pytest.raises(ValidationError) as e:
        validate_scenario("", 0, "999", "-5", {"Venue": "abc"}, ())
    assert {"name", "guests", "contract_pct", "contingency_pct", "adjust_Venue"} <= set(e.value.errors)


# ---- guests ---------------------------------------------------------------------------
def test_guest_stats_import_and_duplicates(repo):
    eid = mk_event(repo, guests=100)
    g = lambda name, size, rsvp, phone="": validate_guest(name, phone, "", size, "Family", rsvp != "Pending", rsvp)  # noqa: E731
    repo.add_guest(eid, g("Khan family", 4, "Confirmed"))
    repo.add_guest(eid, g("Rao family", 3, "Pending"))
    gid = repo.add_guest(eid, g("Bose", 2, "Declined"))
    s = repo.guest_stats(eid)
    assert (s["parties"], s["confirmed"], s["pending"], s["declined"]) == (3, 1, 1, 1)
    assert (s["heads_confirmed"], s["heads_pending"], s["heads_total"]) == (4, 3, 9)

    repo.set_guest_rsvp(gid, "Confirmed")
    assert repo.guest_stats(eid)["heads_confirmed"] == 6

    added, skipped = repo.import_guests(eid, [g("Khan family", 4, "Confirmed"), g("New Person", 1, "Pending")])
    assert (added, skipped) == (1, 1)
    repo.delete_guest(gid)
    assert repo.guest_stats(eid)["parties"] == 3


def test_guest_validation():
    with pytest.raises(ValidationError) as e:
        validate_guest("", "abc", "bad", 0, "", False, "Maybe")
    assert {"name", "phone", "email", "party_size", "rsvp"} <= set(e.value.errors)


def test_deleting_event_removes_its_guests_quotes_budgets(repo):
    eid = mk_event(repo)
    repo.add_guest(eid, validate_guest("A", "", "", 1, "", False, "Pending"))
    mk_quote(repo, eid, mk_vendor(repo, "V"), "1,000")
    repo.set_budget(eid, "Venue", 1000_00)
    repo.delete_event(eid)
    for table in ("guests", "quotes", "budgets"):
        assert repo.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] == 0
    assert len(repo.list_vendors()) == 1  # the vendor directory entry stays


# ---- documents -------------------------------------------------------------------------
def test_attach_store_list_delete_keeps_file(repo, tmp_path):
    eid = mk_event(repo)
    xid = repo.add_expense(eid, validate_expense("Venue", "Hall hire", "1,000"))
    src = tmp_path / "contract.pdf"
    src.write_bytes(b"%PDF-1.4 fake")
    stored, original, size = attachments.store_file(src, str(eid))
    did = repo.add_document(eid, validate_document("Contract", "Venue contract"), stored, original, size, expense_id=xid)
    (doc,) = repo.list_documents(eid)
    assert (doc.kind, doc.title, doc.original_name, doc.expense_label) == ("Contract", "Venue contract", "contract.pdf", "Hall hire")
    path = attachments.attachment_path(doc.stored_name)
    assert path.read_bytes() == b"%PDF-1.4 fake"
    repo.delete_document(did)
    assert repo.list_documents(eid) == [] and path.exists()  # record removed, file kept for safety
    repo.delete_expense(xid)  # deleting an expense never deletes attachments of the event


def test_attachment_safety_rules(tmp_path):
    for name in ("setup.exe", "run.bat", "x.ps1", "evil.js"):
        f = tmp_path / name
        f.write_bytes(b"x")
        with pytest.raises(attachments.AttachmentError, match="cannot be attached"):
            attachments.check_file(f)
    empty = tmp_path / "empty.pdf"
    empty.write_bytes(b"")
    with pytest.raises(attachments.AttachmentError, match="empty"):
        attachments.check_file(empty)
    with pytest.raises(attachments.AttachmentError, match="could not be found"):
        attachments.check_file(tmp_path / "missing.pdf")
    big = tmp_path / "big.pdf"
    with open(big, "wb") as fh:
        fh.truncate(attachments.MAX_BYTES + 1)
    with pytest.raises(attachments.AttachmentError, match="limit"):
        attachments.check_file(big)
    assert attachments.attachment_path("../../etc/passwd").name == "passwd"  # no path tricks
    assert attachments.human_size(2048) == "2 KB"


# ---- alerts & reports -------------------------------------------------------------------
def test_alerts_cover_payments_budgets_quotes_and_losses(repo):
    eid = mk_event(repo, name="Alert Gala", contract="20,000")
    repo.add_expense(eid, {**validate_expense("Venue", "Hall", "6,000", "Palace"), "due_date": D(-2).isoformat()})
    repo.add_expense(eid, {**validate_expense("Catering", "Food", "8,000", "Spice"), "due_date": D(3).isoformat()})
    repo.add_expense(eid, validate_expense("Decor", "Flowers", "9,000"))  # total 23k > 20k contract -> loss
    repo.set_budget(eid, "Venue", 5_000_00)                                # 6k vs 5k -> over budget
    v = mk_vendor(repo, "Quote Co")
    mk_quote(repo, eid, v, "1,000", valid=D(2))                            # expiring soon
    mk_quote(repo, eid, v, "1,500", req="Other need", status="Selected", valid=D(-1))  # selected but expired
    paid = repo.add_expense(eid, {**validate_expense("Other", "Paid already", "100"), "due_date": D(-9).isoformat()})
    repo.set_expense_paid(paid, True)

    out = alerts.build_alerts(repo.list_events(), repo.list_all_expenses(), repo.list_all_budgets(),
                              repo.list_all_quotes(), TODAY, limit=None)
    text = " | ".join(a.text for a in out)
    assert "Overdue: AED 6,000 to Palace" in text and "Due " in text and "AED 8,000 to Spice" in text
    assert "Venue is over budget by AED 1,000" in text and "making a loss of AED 3,100" in text
    assert "expires" in text and "expired" in text
    assert "Paid already" not in text                       # paid items never alert
    assert [a.level for a in out] == sorted((a.level for a in out), key={"danger": 0, "warning": 1}.get)


def test_alerts_ignore_cancelled_events(repo):
    eid = mk_event(repo, status="Cancelled")
    repo.add_expense(eid, {**validate_expense("Venue", "Hall", "6,000"), "due_date": D(-2).isoformat()})
    assert alerts.build_alerts(repo.list_events(), repo.list_all_expenses(), {}, [], TODAY) == []


def test_reports_event_rows_and_vendor_payables(repo):
    repo.seed_sample_data(TODAY)
    events, exps = repo.list_events(), repo.list_all_expenses()
    rows = reports.event_rows(events, repo.list_all_budgets(), exps, repo.list_all_quotes())
    kapoor = next(r for r in rows if r.event.name.startswith("Kapoor"))
    assert kapoor.budget == 324_000_00 and kapoor.actual == kapoor.event.expenses
    assert kapoor.committed == 18_500_00                       # the selected sample quote
    assert kapoor.variance == kapoor.budget - kapoor.actual - kapoor.committed
    assert next(r for r in rows if r.event.name.startswith("Singh")).variance is None  # no budget set

    pay = reports.vendor_payables(events, exps)
    assert sum(p.total for p in pay) == sum(p.paid + p.unpaid for p in pay)
    saffron = next(p for p in pay if p.vendor == "Saffron Royale Catering")
    assert saffron.unpaid == 96_000_00 and saffron.next_due == D(5)
    assert all(p.vendor != "" for p in pay)


def test_sample_data_has_new_modules_and_removes_cleanly(repo):
    repo.seed_sample_data(TODAY)
    assert len(repo.list_vendors()) == 12 and repo.list_all_quotes() and repo.list_all_budgets()
    kap = next(e for e in repo.list_events() if e.name.startswith("Kapoor"))
    assert repo.guest_stats(kap.id)["parties"] == 7 and kap.contingency_bp == 500
    mine = mk_vendor(repo, "My Own Vendor")
    repo.remove_sample_data()
    assert [v.name for v in repo.list_vendors()] == ["My Own Vendor"] and mine
    assert repo.list_all_quotes() == [] and repo.list_events() == []


def test_expense_due_date_roundtrip(repo):
    eid = mk_event(repo)
    xid = repo.add_expense(eid, validate_expense("Venue", "Hall", "1,000", due=D(7)))
    assert repo.get_expense(xid).due_date == D(7)
    repo.update_expense(xid, validate_expense("Venue", "Hall", "1,000", due=None))
    assert repo.get_expense(xid).due_date is None
