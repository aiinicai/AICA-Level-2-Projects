"""Clearly-labelled SAMPLE data so the app is not empty on first launch.

Everything created from here is flagged is_sample=1 in the database and shows a
"Sample" badge in the UI. Dates are relative to today so the dashboard looks alive.
Amounts are written in whole AED for readability and converted to fils on insert.
"""
from __future__ import annotations

from datetime import date, timedelta

# (name, client, type, days_from_today, venue, guests, status, contract_aed,
#  [(label, days_from_today, amount_aed)],
#  [(category, description, vendor, amount_aed, paid)])
_EVENTS = [
    ("Kapoor-Mehta Royal Wedding", "Kapoor & Mehta families", "Wedding", 9,
     "Emirates Palace, Abu Dhabi", 450, "Confirmed", 385_000,
     [("Deposit", -62, 150_000), ("Second instalment", -21, 100_000)],
     [("Venue", "Ballroom hire, 2 days", "Emirates Palace", 118_000, True),
      ("Catering", "Wedding banquet, 450 covers", "Saffron Royale Catering", 96_000, False, 5),
      ("Decor", "Mandap, florals and draping", "Marigold Studio", 52_000, True),
      ("Entertainment", "Live band and dhol team", "Raag Entertainment", 21_000, False, 25)]),
    ("Sharma Sangeet Night", "Priya Sharma", "Private", 3,
     "Atlantis The Royal, Dubai", 220, "In Progress", 142_000,
     [("Deposit", -40, 60_000), ("Balance", -4, 40_000)],
     [("Venue", "Terrace buyout", "Atlantis The Royal", 41_000, True),
      ("Entertainment", "DJ and choreographer", "Beat Baraat", 18_500, True),
      ("Catering", "Cocktail menu", "Spice Route Events", 38_000, False, -2)]),
    ("Al Falasi Corporate Gala", "Al Falasi Holdings", "Gala", 21,
     "Burj Al Arab, Dubai", 300, "Confirmed", 260_000,
     [("Deposit", -30, 130_000)],
     [("Venue", "Skyview ballroom", "Burj Al Arab", 95_000, True),
      ("Catering", "Seated dinner, 300 guests", "Burj Al Arab", 70_000, False, 15),
      ("Photography", "Photo and highlight film", "Lumen Studios", 14_000, False, 20)]),
    ("Reddy-Iyer Mehendi Brunch", "Anika Reddy", "Private", 1,
     "Jumeirah Zabeel Saray, Dubai", 80, "In Progress", 68_000,
     [("Deposit", -25, 34_000), ("Balance", -2, 34_000)],
     [("Venue", "Garden pavilion", "Jumeirah Zabeel Saray", 16_000, True),
      ("Decor", "Floral swings and seating", "Marigold Studio", 12_500, True),
      ("Staff", "Mehendi artists (6)", "Henna House", 5_200, True)]),
    ("Dubai Fintech Summit Dinner", "Meridian Events Group", "Corporate", 34,
     "Madinat Jumeirah, Dubai", 150, "Enquiry", 95_000, [], []),
    ("Nair Wedding Reception", "Nair & Pillai families", "Wedding", -12,
     "Four Seasons Resort, Jumeirah", 280, "Completed", 310_000,
     [("Deposit", -95, 120_000), ("Second instalment", -50, 100_000), ("Final balance", -14, 90_000)],
     [("Venue", "Beachfront lawn and ballroom", "Four Seasons Resort", 88_000, True),
      ("Catering", "South Indian wedding feast", "Annapoorna Catering", 82_000, True),
      ("Decor", "Kerala-style floral theme", "Marigold Studio", 46_000, True),
      ("Photography", "Photo, video and drone", "Lumen Studios", 24_000, True),
      ("Entertainment", "Chenda melam and live music", "Raag Entertainment", 19_000, True)]),
    ("Singh Anniversary Gala", "Gurpreet Singh", "Gala", -45,
     "Palazzo Versace, Dubai", 160, "Completed", 120_000,
     [("Deposit", -78, 60_000), ("Second instalment", -46, 30_000)],
     [("Venue", "Ballroom hire", "Palazzo Versace", 40_000, True),
      ("Catering", "Punjabi fine-dining menu", "Spice Route Events", 45_000, True),
      ("Entertainment", "Bhangra troupe and singer", "Beat Baraat", 27_000, True)]),
    ("Khanna Destination Wedding", "Khanna family", "Wedding", 60,
     "Bab Al Shams Desert Resort", 350, "Cancelled", 500_000,
     [("Deposit", -48, 100_000)], []),
    ("Hospitality Leaders Conference", "Gulf Hospitality Council", "Conference", -80,
     "Dubai World Trade Centre", 400, "Completed", 180_000,
     [("Deposit", -120, 90_000), ("Balance", -75, 90_000)],
     [("Venue", "Hall 4 and breakout rooms", "DWTC", 62_000, True),
      ("Catering", "Lunch and coffee breaks", "Saffron Royale Catering", 38_000, True),
      ("Staff", "Registration and ushers", "Prime Hospitality Staffing", 14_000, True)]),
    ("Ahuja Roka Ceremony", "Ahuja family", "Private", 14,
     "The Palace Downtown, Dubai", 60, "Confirmed", 55_000,
     [("Deposit", -10, 20_000)],
     [("Venue", "Private dining room", "The Palace Downtown", 14_000, False),
      ("Decor", "Floral backdrop and thaals", "Marigold Studio", 6_500, False)]),
]

# (title, days_from_today, priority, event name or None, done)
_TASKS = [
    ("Confirm final guest count with caterer", 2, "High", "Kapoor-Mehta Royal Wedding", False),
    ("Send seating plan to venue", 5, "Medium", "Kapoor-Mehta Royal Wedding", False),
    ("Collect balance from Sharma family", -1, "High", "Sharma Sangeet Night", False),
    ("Book dhol players for baraat", -3, "Medium", "Kapoor-Mehta Royal Wedding", False),
    ("Finalise gala run-of-show", 12, "Medium", "Al Falasi Corporate Gala", False),
    ("Order mehendi favours", 0, "Low", "Reddy-Iyer Mehendi Brunch", False),
    ("Send thank-you notes to Nair family", -6, "Low", "Nair Wedding Reception", True),
]



# Vendor directory: (name, category, contact, phone, email)
_VENDORS = [
    ("Emirates Palace", "Venue", "Events desk", "+971 2 555 0101", "events@sample-palace.example"),
    ("Burj Al Arab", "Venue", "Banqueting team", "+971 4 555 0102", "banquets@sample-burj.example"),
    ("Saffron Royale Catering", "Catering", "Chef Imran", "+971 50 555 0103", "orders@sample-saffron.example"),
    ("Spice Route Events", "Catering", "Neha Kulkarni", "+971 50 555 0104", "hello@sample-spiceroute.example"),
    ("Annapoorna Catering", "Catering", "Mr. Nair", "+971 55 555 0105", "info@sample-annapoorna.example"),
    ("Marigold Studio", "Decor", "Sunita Rao", "+971 52 555 0106", "studio@sample-marigold.example"),
    ("Glow Productions", "Decor", "Karan Shah", "+971 56 555 0107", "karan@sample-glow.example"),
    ("Raag Entertainment", "Entertainment", "Vikram", "+971 50 555 0108", "book@sample-raag.example"),
    ("Beat Baraat", "Entertainment", "DJ Rohan", "+971 54 555 0109", "rohan@sample-beatbaraat.example"),
    ("Lumen Studios", "Photography", "Anjali Mehra", "+971 55 555 0110", "shoots@sample-lumen.example"),
    ("Frame & Fable", "Photography", "Tariq", "+971 52 555 0111", "hi@sample-framefable.example"),
    ("Candid Karma", "Photography", "Divya", "+971 50 555 0112", "team@sample-candidkarma.example"),
]

# Budgets by event name: category -> AED
_BUDGETS = {
    "Kapoor-Mehta Royal Wedding": {"Venue": 125_000, "Catering": 100_000, "Decor": 50_000,
                                   "Entertainment": 25_000, "Photography": 24_000},
    "Sharma Sangeet Night": {"Venue": 45_000, "Entertainment": 18_000, "Catering": 36_000},
    "Al Falasi Corporate Gala": {"Venue": 95_000, "Catering": 65_000, "Photography": 14_000, "Decor": 30_000},
    "Nair Wedding Reception": {"Venue": 90_000, "Catering": 80_000, "Decor": 45_000, "Photography": 25_000},
}
_CONTINGENCY_BP = {"Kapoor-Mehta Royal Wedding": 500, "Al Falasi Corporate Gala": 500}

# (event, requirement, category, vendor, amount, deposit, valid_days (None = no expiry), rating, status)
_QUOTES = [
    ("Kapoor-Mehta Royal Wedding", "Wedding photography and film", "Photography", "Lumen Studios", 24_000, 8_000, 12, 5, "Received"),
    ("Kapoor-Mehta Royal Wedding", "Wedding photography and film", "Photography", "Frame & Fable", 19_500, 6_000, 12, 3, "Received"),
    ("Kapoor-Mehta Royal Wedding", "Wedding photography and film", "Photography", "Candid Karma", 27_000, 9_000, 20, 4, "Received"),
    ("Kapoor-Mehta Royal Wedding", "Mehendi night catering", "Catering", "Saffron Royale Catering", 18_500, 5_000, 30, 4, "Selected"),
    ("Kapoor-Mehta Royal Wedding", "Mehendi night catering", "Catering", "Spice Route Events", 17_000, 4_000, 30, 3, "Received"),
    ("Al Falasi Corporate Gala", "Stage and lighting", "Decor", "Marigold Studio", 32_000, 10_000, 25, 4, "Received"),
    ("Al Falasi Corporate Gala", "Stage and lighting", "Decor", "Glow Productions", 28_500, 8_000, 4, 3, "Received"),
]

# (event, name, phone, email, party_size, group, invited, rsvp)
_GUESTS = [
    ("Kapoor-Mehta Royal Wedding", "Sample: Anand & Priya Kapoor", "+971 50 555 0201", "anand@sample.example", 4, "Groom's family", 1, "Confirmed"),
    ("Kapoor-Mehta Royal Wedding", "Sample: Rajesh Mehta", "+971 50 555 0202", "rajesh@sample.example", 6, "Bride's family", 1, "Confirmed"),
    ("Kapoor-Mehta Royal Wedding", "Sample: Sunita Verma", "+971 55 555 0203", "", 3, "Bride's family", 1, "Confirmed"),
    ("Kapoor-Mehta Royal Wedding", "Sample: The Iyer family", "+971 52 555 0204", "iyer@sample.example", 5, "Friends", 1, "Pending"),
    ("Kapoor-Mehta Royal Wedding", "Sample: Dr. Farah Khan", "+971 56 555 0205", "farah@sample.example", 2, "Colleagues", 1, "Declined"),
    ("Kapoor-Mehta Royal Wedding", "Sample: Vikram Oberoi", "+971 54 555 0206", "", 2, "Colleagues", 1, "Pending"),
    ("Kapoor-Mehta Royal Wedding", "Sample: The Desai family", "+971 50 555 0207", "desai@sample.example", 7, "Groom's family", 0, "Pending"),
    ("Sharma Sangeet Night", "Sample: Meera Sharma", "+971 55 555 0208", "meera@sample.example", 4, "Family", 1, "Confirmed"),
    ("Sharma Sangeet Night", "Sample: Arjun Bajaj", "+971 52 555 0209", "", 2, "Friends", 1, "Confirmed"),
]


def build(today: date) -> dict:
    """Return plain-Python rows (amounts in AED) ready for the repository to insert."""
    d = lambda n: (today + timedelta(days=n)).isoformat()  # noqa: E731
    events = []
    for (name, client, typ, off, venue, guests, status, contract, pays, exps) in _EVENTS:
        events.append({
            "name": name, "client": client, "type": typ, "date": d(off), "venue": venue,
            "guests": guests, "status": status, "contract_aed": contract,
            "contingency_bp": _CONTINGENCY_BP.get(name, 0),
            "budgets": _BUDGETS.get(name, {}),
            "payments": [(label, d(o), amt) for label, o, amt in pays],
            "expenses": [(e[0], e[1], e[2], e[3], e[4], d(off - 1), d(e[5]) if len(e) > 5 else None) for e in exps],
        })
    return {
        "events": events,
        "vendors": list(_VENDORS),
        "quotes": [(ev, req, cat, vendor, amt, dep, d(valid) if valid is not None else None, rating, status)
                   for ev, req, cat, vendor, amt, dep, valid, rating, status in _QUOTES],
        "guests": list(_GUESTS),
        "tasks": [(title, d(o), pr, ev, done) for title, o, pr, ev, done in _TASKS],
    }
