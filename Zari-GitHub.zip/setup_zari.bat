@echo off
REM One-time setup: creates a private Python environment and installs Zari's packages.
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
    echo Python was not found. Install Python 3.10 or newer from https://www.python.org/downloads/
    echo and tick "Add python.exe to PATH" during installation, then run this file again.
    pause
    exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
    echo Creating Python environment...
    py -m venv .venv
)
echo Installing packages (this can take a few minutes the first time)...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
echo.
echo Setup complete. Double-click run_zari.bat to start Zari.
pause
