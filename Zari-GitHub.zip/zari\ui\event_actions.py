"""Add / edit / delete flows shared by the Events page and the detail panel."""
from __future__ import annotations

from zari.ui.dialogs import EventDialog, confirm


def add_event_flow(window, ctx) -> int | None:
    dlg = EventDialog(window)
    if dlg.exec():
        new_id = ctx.repo.add_event(dlg.result_data)
        ctx.data_changed("Event created")
        return new_id
    return None


def edit_event_flow(window, ctx, event_id: int) -> None:
    ev = ctx.repo.get_event(event_id)
    if ev is None:
        return
    dlg = EventDialog(window, ev)
    if dlg.exec():
        ctx.repo.update_event(ev.id, dlg.result_data)
        ctx.data_changed("Event updated")


def delete_event_flow(window, ctx, event_id: int) -> bool:
    ev = ctx.repo.get_event(event_id)
    if ev is None:
        return False
    n = ctx.repo.event_record_counts(ev.id)
    has_money = bool(n["payments"] or n["expenses"])
    detail = (f"This will also permanently remove its {n['payments']} payment(s) and {n['expenses']} expense(s).\n\n"
              "A safety backup is saved first, so you can undo this with Restore."
              if has_money else "It has no payments or expenses.")
    if confirm(window, f"Delete \"{ev.name}\"?", detail):
        ctx.repo.delete_event(ev.id)
        ctx.data_changed("Event deleted")
        return True
    return False
