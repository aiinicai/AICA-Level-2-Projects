"""Plain data classes returned by the repository. Amounts are integer fils."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from zari.logic.finance import EventFinancials, compute_financials


def parse_iso(value: str | None) -> date | None:
    return date.fromisoformat(value) if value else None


@dataclass
class Event:
    id: int
    name: str
    client: str
    type: str
    date: date
    venue: str
    guests: int
    status: str
    contract_value: int
    notes: str
    is_sample: bool
    contingency_bp: int = 0


@dataclass
class EventSummary(Event):
    """An event plus the totals needed to calculate its finances."""
    received: int = 0
    expenses: int = 0
    unpaid_expenses: int = 0

    @property
    def fin(self) -> EventFinancials:
        return compute_financials(
            self.contract_value, self.received, self.expenses, self.unpaid_expenses, self.status
        )

    @property
    def is_active(self) -> bool:
        return self.status != "Cancelled"


@dataclass
class Payment:
    id: int
    event_id: int
    amount: int
    date: date
    label: str


@dataclass
class Expense:
    id: int
    event_id: int
    category: str
    description: str
    amount: int
    paid: bool
    vendor: str
    invoice_no: str
    invoice_file: str
    date: date | None
    due_date: date | None = None


@dataclass
class Vendor:
    id: int
    name: str
    category: str
    contact_name: str
    phone: str
    email: str
    notes: str
    is_sample: bool = False


@dataclass
class Quote:
    id: int
    event_id: int
    requirement: str
    category: str
    vendor_id: int
    vendor_name: str
    amount: int
    deposit: int
    valid_until: date | None
    rating: int | None
    status: str
    notes: str
    expense_id: int | None


@dataclass
class Guest:
    id: int
    event_id: int
    name: str
    phone: str
    email: str
    party_size: int
    group: str
    invited: bool
    rsvp: str
    notes: str


@dataclass
class Document:
    id: int
    event_id: int
    expense_id: int | None
    expense_label: str | None
    kind: str
    title: str
    stored_name: str
    original_name: str
    size: int
    added_at: str


@dataclass
class Scenario:
    id: int
    event_id: int
    name: str
    guests: int
    contract_bp: int
    contingency_bp: int
    per_guest: tuple
    adjust_bp: dict


@dataclass
class Task:
    id: int
    title: str
    event_id: int | None
    event_name: str | None
    due: date
    priority: str
    done: bool
    is_sample: bool
