"""Right-hand slide-in panel: event details, payments, expenses and live finances."""
from __future__ import annotations

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QFileDialog, QFrame, QGridLayout, QHBoxLayout, QLineEdit, QProgressBar, QScrollArea, QVBoxLayout, QWidget,
)

from zari.config import invoices_dir
from zari.exports.event_report import collect as collect_event_report
from zari.exports.excel_export import export_event_workbook
from zari.exports.pdf_export import export_event_pdf
from zari.logic.calendar_export import safe_filename
from zari.logic.finance import countdown_text, format_margin, margin_level
from zari.logic.money import format_aed, format_input, parse_amount
from zari.ui import icons, theme
from zari.ui.dialogs import ExpenseDialog, PaymentDialog, confirm, info
from zari.ui.documents_ui import attach_files_flow, documents_card
from zari.ui.event_actions import delete_event_flow, edit_event_flow
from zari.ui.event_sections import BudgetCard, guests_card, quotes_card, scenarios_card
from zari.ui.guests_ui import GuestsDialog
from zari.ui.quotes_ui import QuotesDialog
from zari.ui.scenario_ui import ScenarioDialog
from zari.ui.invoice_dialog import scan_invoice
from zari.ui.widgets import (
    Badge, Card, ToggleSwitch, clear_layout, divider, icon_button, make_button, make_label, sample_badge,
    set_label_color, status_badge,
)

PANEL_WIDTH = 600


class EventPanel(QFrame):
    closed = Signal()
    expanded_changed = Signal(bool)

    def __init__(self, ctx, parent=None):
        super().__init__(parent)
        self.ctx = ctx
        self.event_id: int | None = None
        self.skip_refresh = False   # set by the budget card, which updates itself without a full rebuild
        self.expanded = False       # False = side panel, True = the whole window (two columns)
        self.setObjectName("SidePanel")
        self.setFixedWidth(PANEL_WIDTH)
        self.setAcceptDrops(True)   # drop files onto the panel to attach them
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        top = QHBoxLayout()
        top.setContentsMargins(24, 16, 14, 8)
        top.addWidget(make_label("Event details", "eyebrow"))
        top.addStretch(1)
        self.expand_btn = icon_button("expand", "Open full screen")
        self.expand_btn.clicked.connect(lambda: self.set_expanded(not self.expanded))
        top.addWidget(self.expand_btn)
        close = icon_button("close", "Close panel")
        close.clicked.connect(self.close_panel)
        top.addWidget(close)
        outer.addLayout(top)
        outer.addWidget(divider())

        self.scroller = QScrollArea()
        self.scroller.setWidgetResizable(True)
        self.scroller.setFrameShape(QFrame.Shape.NoFrame)
        self.scroller.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.body = QWidget()
        self.body.setObjectName("Transparent")
        self.body_layout = QVBoxLayout(self.body)
        self.body_layout.setContentsMargins(24, 18, 24, 28)
        self.body_layout.setSpacing(16)
        self.scroller.setWidget(self.body)
        outer.addWidget(self.scroller, 1)

    # ---- public ---------------------------------------------------------------------
    def show_event(self, event_id: int) -> None:
        self.event_id = event_id
        self.scroller.verticalScrollBar().setValue(0)
        self.refresh()

    def close_panel(self) -> None:
        self.event_id = None
        self.closed.emit()

    def set_expanded(self, on: bool) -> None:
        """Switch between the side panel (600 px) and the whole window with two columns."""
        if on == self.expanded:
            return
        self.expanded = on
        self.expand_btn.setIcon(icons.icon("collapse" if on else "expand", theme.GOLD))
        self.expand_btn.setToolTip("Back to the side panel (Esc)" if on else "Open full screen")
        self.expanded_changed.emit(on)
        self.skip_refresh = False
        self.refresh()

    def current_width(self) -> int:
        parent = self.parentWidget()
        return parent.width() if self.expanded and parent is not None else PANEL_WIDTH

    # ---- drag & drop attachments ----------------------------------------------------
    def dragEnterEvent(self, e):
        if self.event_id is not None and e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls() if u.isLocalFile()]
        paths = [p for p in paths if p and __import__("os").path.isfile(p)]
        if paths and self.event_id is not None:
            e.acceptProposedAction()
            attach_files_flow(self.window(), self.ctx, self.event_id, paths)

    def refresh(self) -> None:
        if self.skip_refresh:
            self.skip_refresh = False
            return
        if self.event_id is None:
            return
        ev = self.ctx.repo.get_event(self.event_id)
        if ev is None:
            self.close_panel()
            return
        pos = self.scroller.verticalScrollBar().value()
        clear_layout(self.body_layout)
        # Side panel: one column. Full screen: two columns, centred, so wide screens are actually used.
        cols = QHBoxLayout()
        cols.setSpacing(22)
        left = QVBoxLayout()
        left.setSpacing(16)
        if self.expanded:
            right = QVBoxLayout()
            right.setSpacing(16)
            cols.addLayout(left, 1)
            cols.addLayout(right, 1)
            self.body_layout.setContentsMargins(36, 22, 36, 34)
        else:
            right = left
            cols.addLayout(left, 1)
            self.body_layout.setContentsMargins(24, 18, 24, 28)
        self._left, self._right = left, right
        self.body_layout.addLayout(cols)
        self._build(ev)
        left.addStretch(1)
        if right is not left:
            right.addStretch(1)
        self.body_layout.addStretch(1)
        self.scroller.verticalScrollBar().setValue(pos)

    # ---- building -------------------------------------------------------------------
    def _build(self, ev) -> None:
        repo, f = self.ctx.repo, ev.fin
        lay = self._left

        # title
        lay.addWidget(make_label(ev.name, "h2", wrap=True))
        badges = QHBoxLayout()
        badges.setSpacing(8)
        badges.addWidget(status_badge(ev.status))
        badges.addWidget(Badge(ev.type, theme.ROSE))
        if ev.is_sample:
            badges.addWidget(sample_badge())
        badges.addStretch(1)
        lay.addLayout(badges)
        lay.addWidget(make_label(f"Client: {ev.client}", "muted"))

        actions = QHBoxLayout()
        actions.setSpacing(8)
        edit = make_button("Edit", icon_name="edit")
        edit.clicked.connect(self._edit_event)
        xl = make_button("Excel", icon_name="download",
                         tooltip="Full event workbook: summary, budget (with chart), payments, expenses, vendors, "
                                 "quotes, guests, scenarios, documents")
        xl.clicked.connect(lambda: self._export("xlsx"))
        pdf = make_button("PDF", icon_name="download",
                          tooltip="Full event report: details, finances, budget vs actual chart, payments, expenses, "
                                  "vendors, quotes, guests, scenarios, documents")
        pdf.clicked.connect(lambda: self._export("pdf"))
        delete = make_button("Delete", "danger", "trash")
        delete.clicked.connect(self._delete_event)
        for b in (edit, xl, pdf):
            actions.addWidget(b)
        actions.addStretch(1)
        actions.addWidget(delete)
        lay.addLayout(actions)

        # details
        details = Card(shadow=False, inner=True)
        grid = QGridLayout(details)
        grid.setContentsMargins(18, 14, 18, 14)
        grid.setHorizontalSpacing(24)
        grid.setVerticalSpacing(10)
        # (title, text, grid row, grid column, column span)
        items = [("Date", f"{ev.date:%a, %d %b %Y}  ·  {countdown_text(ev.date, self.ctx.today)}", 0, 0, 1),
                 ("Guests", f"{ev.guests:,}", 0, 1, 1),
                 ("Venue", ev.venue, 2, 0, 2)]
        for title, text, row, col, span in items:
            grid.addWidget(make_label(title, "eyebrow"), row, col, 1, span)
            grid.addWidget(make_label(text, "body", wrap=True), row + 1, col, 1, span)
        grid.setColumnStretch(0, 3)
        grid.setColumnStretch(1, 1)
        lay.addWidget(details)

        # contract value (editable)
        contract_row = QHBoxLayout()
        contract_row.setSpacing(10)
        box = QVBoxLayout()
        box.setSpacing(4)
        box.addWidget(make_label("Contract value (AED) - editable", "eyebrow"))
        self.contract_edit = QLineEdit(format_input(ev.contract_value))
        self.contract_edit.setStyleSheet("font-size: 18px; font-weight: 600;")
        self.contract_edit.returnPressed.connect(self._save_contract)
        box.addWidget(self.contract_edit)
        contract_row.addLayout(box, 1)
        upd = make_button("Update", "primary")
        upd.clicked.connect(self._save_contract)
        contract_row.addWidget(upd, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(contract_row)

        # finance tiles
        tiles = QGridLayout()
        tiles.setSpacing(10)
        level = margin_level(f.margin)
        data = [("Total expenses", format_aed(f.expenses), theme.IVORY,
                 f"{format_aed(f.unpaid_expenses)} unpaid" if f.unpaid_expenses else "All paid"),
                ("Balance due", format_aed(f.balance_due), theme.WARNING if f.balance_due else theme.SUCCESS,
                 "Cancelled - nothing due" if ev.status == "Cancelled" else "From client"),
                ("Gross profit", format_aed(f.profit), theme.SUCCESS if f.profit >= 0 else theme.DANGER,
                 "Contract - expenses"),
                ("Profit margin", format_margin(f.margin), theme.LEVEL_COLORS[level],
                 {"success": "Healthy (above 20%)", "warning": "Watch closely (10-20%)",
                  "danger": "Low (below 10%)", "muted": "Set a contract value"}[level])]
        for i, (k, v, c, note) in enumerate(data):
            t = Card(shadow=False, inner=True)
            tl = QVBoxLayout(t)
            tl.setContentsMargins(16, 12, 16, 12)
            tl.setSpacing(1)
            tl.addWidget(make_label(k, "eyebrow"))
            val = make_label(v, "h3", color=c)
            tl.addWidget(val)
            tl.addWidget(make_label(note, "small"))
            tiles.addWidget(t, i // 2, i % 2)
        lay.addLayout(tiles)

        # Left column: budget and planning tools. Right column (full screen): money in / money out + files.
        # In the narrow side panel both names point at the same single column, in this same order.
        lay.addWidget(BudgetCard(self.ctx, ev, self._skip_next_refresh))
        self._payments_section(ev)
        self._expenses_section(ev)
        window = self.window()
        lay.addWidget(quotes_card(self.ctx, ev, lambda: QuotesDialog(window, self.ctx, ev.id).exec()))
        lay.addWidget(guests_card(self.ctx, ev, lambda: GuestsDialog(window, self.ctx, ev.id).exec()))
        lay.addWidget(scenarios_card(self.ctx, ev, lambda: ScenarioDialog(window, self.ctx, ev.id).exec()))
        self._right.addWidget(documents_card(window, self.ctx, ev))

    def _skip_next_refresh(self) -> None:
        self.skip_refresh = True

    def _section_header(self, title: str, buttons: list) -> QHBoxLayout:
        row = QHBoxLayout()
        row.addWidget(make_label(title, "h3"))
        row.addStretch(1)
        for b in buttons:
            row.addWidget(b)
        return row

    def _payments_section(self, ev) -> None:
        f = ev.fin
        card = Card(shadow=False)
        v = QVBoxLayout(card)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(10)
        add = make_button("Add payment", "primary", "plus")
        add.clicked.connect(self._add_payment)
        v.addLayout(self._section_header("Payments received", [add]))

        bar = QProgressBar()
        bar.setRange(0, 1000)
        bar.setValue(int(f.progress * 1000))
        bar.setTextVisible(False)
        v.addWidget(bar)
        pct = f"{f.progress * 100:.0f}%" if f.contract else "-"
        v.addWidget(make_label(f"{format_aed(f.received)} of {format_aed(f.contract)}  ·  {pct} received", "muted"))

        payments = self.ctx.repo.list_payments(ev.id)
        if not payments:
            v.addWidget(make_label("No payments recorded yet.", "small"))
        for p in payments:
            row = QHBoxLayout()
            col = QVBoxLayout()
            col.setSpacing(0)
            col.addWidget(make_label(p.label, "body"))
            col.addWidget(make_label(f"{p.date:%d %b %Y}", "small"))
            row.addLayout(col, 1)
            row.addWidget(make_label(format_aed(p.amount), "body", color=theme.SUCCESS))
            e = icon_button("edit", "Edit payment")
            e.clicked.connect(lambda _=False, pay=p: self._edit_payment(pay))
            d = icon_button("trash", "Delete payment", danger=True)
            d.clicked.connect(lambda _=False, pay=p: self._delete_payment(pay))
            row.addWidget(e)
            row.addWidget(d)
            v.addWidget(divider())
            v.addLayout(row)
        self._right.addWidget(card)

    def _expenses_section(self, ev) -> None:
        card = Card(shadow=False)
        v = QVBoxLayout(card)
        v.setContentsMargins(18, 16, 18, 16)
        v.setSpacing(8)
        scan = make_button("Scan invoice", icon_name="scan", tooltip="Read an invoice photo and add it as an expense")
        scan.clicked.connect(lambda: scan_invoice(self.window(), self.ctx, ev.id))
        add = make_button("Add expense", "primary", "plus")
        add.clicked.connect(self._add_expense)
        v.addLayout(self._section_header("Expenses", [scan, add]))

        expenses = self.ctx.repo.list_expenses(ev.id)
        if not expenses:
            v.addWidget(make_label("No expenses yet. Add one by hand or scan an invoice photo.", "small"))
        for x in expenses:
            v.addWidget(divider())
            grid = QGridLayout()
            grid.setHorizontalSpacing(8)
            grid.setVerticalSpacing(2)
            grid.addWidget(make_label(x.description, "body", wrap=True), 0, 0, 1, 3)
            grid.addWidget(make_label(format_aed(x.amount), "body", color=theme.IVORY), 0, 3, Qt.AlignmentFlag.AlignRight)
            meta = QHBoxLayout()
            meta.setSpacing(8)
            meta.addWidget(Badge(x.category, theme.GOLD))
            if x.vendor:
                meta.addWidget(make_label(x.vendor, "small"))
            if x.due_date and not x.paid:
                days = (x.due_date - self.ctx.today).days
                if days < 0:
                    meta.addWidget(Badge(f"Overdue {-days}d", theme.DANGER))
                elif days <= 7:
                    meta.addWidget(Badge(f"Due {x.due_date:%d %b}", theme.WARNING))
                else:
                    meta.addWidget(make_label(f"due {x.due_date:%d %b}", "small"))
            meta.addStretch(1)
            grid.addLayout(meta, 1, 0, 1, 2)
            ctrl = QHBoxLayout()
            ctrl.setSpacing(2)
            sw = ToggleSwitch(x.paid)
            sw.setToolTip("Paid to the vendor" if x.paid else "Not yet paid")
            sw.toggled.connect(lambda on, exp=x: self._toggle_paid(exp, on))
            ctrl.addWidget(make_label("Paid" if x.paid else "Unpaid", "small",
                                      color=theme.SUCCESS if x.paid else theme.WARNING))
            ctrl.addWidget(sw)
            if x.invoice_file:
                clip = icon_button("clip", "Open the invoice image")
                clip.clicked.connect(lambda _=False, name=x.invoice_file: self._open_invoice(name))
                ctrl.addWidget(clip)
            e = icon_button("edit", "Edit expense")
            e.clicked.connect(lambda _=False, exp=x: self._edit_expense(exp))
            d = icon_button("trash", "Delete expense", danger=True)
            d.clicked.connect(lambda _=False, exp=x: self._delete_expense(exp))
            ctrl.addWidget(e)
            ctrl.addWidget(d)
            grid.addLayout(ctrl, 1, 2, 1, 2, Qt.AlignmentFlag.AlignRight)
            grid.setColumnStretch(0, 1)
            v.addLayout(grid)
        self._right.addWidget(card)

    # ---- event actions --------------------------------------------------------------
    def _edit_event(self) -> None:
        edit_event_flow(self.window(), self.ctx, self.event_id)

    def _delete_event(self) -> None:
        delete_event_flow(self.window(), self.ctx, self.event_id)

    def _save_contract(self) -> None:
        try:
            fils = parse_amount(self.contract_edit.text())
        except ValueError as exc:
            self.contract_edit.setProperty("invalid", True)
            self.contract_edit.style().unpolish(self.contract_edit)
            self.contract_edit.style().polish(self.contract_edit)
            self.ctx.notify(str(exc))
            return
        self.ctx.repo.set_contract_value(self.event_id, fils)
        self.ctx.data_changed(f"Contract value set to {format_aed(fils)}")

    def _export(self, kind: str) -> None:
        ev = self.ctx.repo.get_event(self.event_id)
        ext, label = ("xlsx", "Excel workbook (*.xlsx)") if kind == "xlsx" else ("pdf", "PDF document (*.pdf)")
        path, _ = QFileDialog.getSaveFileName(self.window(), "Export event", f"{safe_filename(ev.name)}.{ext}", label)
        if not path:
            return
        try:
            # One complete report: details, finances, budget vs actual (+chart), payments, expenses, vendor
            # payables, quotations, guests (no contacts), scenarios and documents.
            report = collect_event_report(self.ctx.repo, ev.id, self.ctx.today)
            (export_event_workbook if kind == "xlsx" else export_event_pdf)(path, report)
        except OSError as exc:
            info(self.window(), "Could not save the file",
                 f"{exc}\n\nIf the file is open in Excel or a PDF viewer, close it and try again.")
            return
        self.ctx.notify(f"Exported to {path}")

    # ---- payments -------------------------------------------------------------------
    def _check_overpay(self, new_total: int, contract: int) -> bool:
        if contract > 0 and new_total > contract:
            return confirm(self.window(), "Payments exceed the contract",
                           f"Payments would total {format_aed(new_total)}, more than the contract value of "
                           f"{format_aed(contract)}.\n\nSave anyway?", action="Save anyway", danger=False)
        return True

    def _add_payment(self) -> None:
        ev = self.ctx.repo.get_event(self.event_id)
        suggestion = "Deposit" if ev.received == 0 else ("Balance" if ev.fin.balance_due else "Extras")
        dlg = PaymentDialog(self.window(), suggested_label=suggestion)
        if dlg.exec() and self._check_overpay(ev.received + dlg.result_data["amount"], ev.contract_value):
            self.ctx.repo.add_payment(ev.id, dlg.result_data)
            self.ctx.data_changed("Payment recorded")

    def _edit_payment(self, pay) -> None:
        ev = self.ctx.repo.get_event(self.event_id)
        dlg = PaymentDialog(self.window(), pay)
        if dlg.exec() and self._check_overpay(ev.received - pay.amount + dlg.result_data["amount"], ev.contract_value):
            self.ctx.repo.update_payment(pay.id, dlg.result_data)
            self.ctx.data_changed("Payment updated")

    def _delete_payment(self, pay) -> None:
        if confirm(self.window(), "Delete this payment?",
                   f"{pay.label} of {format_aed(pay.amount)} received on {pay.date:%d %b %Y} will be removed "
                   "and the event's balance due will increase."):
            self.ctx.repo.delete_payment(pay.id)
            self.ctx.data_changed("Payment deleted")

    # ---- expenses -------------------------------------------------------------------
    def _vendor_names(self) -> list[str]:
        return [v.name for v in self.ctx.repo.list_vendors()]

    def _add_expense(self) -> None:
        dlg = ExpenseDialog(self.window(), vendor_names=self._vendor_names())
        if dlg.exec():
            self.ctx.repo.add_expense(self.event_id, dlg.result_data)
            self.ctx.data_changed("Expense added")

    def _edit_expense(self, exp) -> None:
        dlg = ExpenseDialog(self.window(), exp, self._vendor_names())
        if dlg.exec():
            self.ctx.repo.update_expense(exp.id, dlg.result_data)
            self.ctx.data_changed("Expense updated")

    def _delete_expense(self, exp) -> None:
        if confirm(self.window(), "Delete this expense?",
                   f"{exp.description} ({format_aed(exp.amount)}) will be removed and the event's profit will change."):
            self.ctx.repo.delete_expense(exp.id)
            self.ctx.data_changed("Expense deleted")

    def _toggle_paid(self, exp, on: bool) -> None:
        self.ctx.repo.set_expense_paid(exp.id, on)
        self.ctx.data_changed("Marked as paid" if on else "Marked as unpaid")

    def _open_invoice(self, name: str) -> None:
        path = invoices_dir() / name
        if not path.is_file():
            info(self.window(), "Invoice image not found", f"The stored file is missing:\n{path}")
            return
        QDesktopServices.openUrl(QUrl.fromLocalFile(str(path)))
