"""UI tests for sign-in, documents, budget, quotes, guests, scenarios, vendors, reports and alerts."""
import os
from datetime import timedelta

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import QObject  # noqa: E402
from PySide6.QtGui import QColor, QImage  # noqa: E402
from PySide6.QtWidgets import QApplication, QDialog, QWidget  # noqa: E402

from zari import auth  # noqa: E402
from zari.auth import AccountStore  # noqa: E402
from zari.logic import attachments  # noqa: E402
from zari.logic.money import format_aed  # noqa: E402
from zari.ui import theme  # noqa: E402
from zari.ui.context import AppContext  # noqa: E402
from zari.ui.main_window import MainWindow  # noqa: E402

CONFIRM_MODULES = ("tasks_panel", "event_panel", "event_actions", "invoice_dialog", "dashboard_page",
                   "documents_ui", "quotes_ui", "guests_ui", "scenario_ui", "vendors_page")


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    theme.init_fonts()
    app.setStyleSheet(theme.stylesheet())
    return app


@pytest.fixture()
def messages():
    return []


@pytest.fixture()
def win(qapp, repo, monkeypatch, messages):
    for mod in CONFIRM_MODULES:
        monkeypatch.setattr(f"zari.ui.{mod}.confirm", lambda *a, **k: True)
    for mod in ("documents_ui", "quotes_ui", "guests_ui", "vendors_page", "invoice_dialog"):
        monkeypatch.setattr(f"zari.ui.{mod}.info", lambda parent, title, text, _m=messages: _m.append((title, text)))
    repo.seed_sample_data()
    w = MainWindow(AppContext(repo))
    w.show()
    qapp.processEvents()
    yield w
    w.close()


def kapoor(win):
    return next(e for e in win.ctx.repo.list_events() if e.name.startswith("Kapoor"))


# ---- guard: attributes must never shadow Qt methods (this crashed a dialog once) ----------
def test_no_widget_attribute_shadows_a_qt_method(win, tmp_path):
    from zari.ui.dialogs import EventDialog, ExpenseDialog, PaymentDialog
    from zari.ui.guests_ui import GuestForm, GuestsDialog
    from zari.ui.invoice_dialog import InvoiceDialog, ScanSourceDialog
    from zari.ui.login import AccountDialog, LoginDialog
    from zari.ui.quotes_ui import QuoteDialog, QuotesDialog, VendorDialog
    from zari.ui.scenario_ui import ScenarioDialog

    ev = kapoor(win)
    img = tmp_path / "x.png"
    im = QImage(50, 50, QImage.Format.Format_RGB32)
    im.fill(QColor("white"))
    im.save(str(img))
    store = AccountStore(win.ctx.repo.db.path.parent)
    owner = store.create("arya", "Arya", "Sunrise2026")
    dialogs = [EventDialog(win), PaymentDialog(win), ExpenseDialog(win), GuestForm(win), GuestsDialog(win, win.ctx, ev.id),
               InvoiceDialog(win, win.ctx, str(img), ev.id), ScanSourceDialog(win), LoginDialog(store),
               AccountDialog(win, store, owner), QuoteDialog(win, win.ctx.repo, ev.id), QuotesDialog(win, win.ctx, ev.id),
               VendorDialog(win), ScenarioDialog(win, win.ctx, ev.id)]
    win.open_panel(ev.id)
    objects = list(win.findChildren(QObject)) + dialogs
    for d in dialogs:
        objects += d.findChildren(QObject)
    qt_names = {n for n in dir(QWidget) if not n.startswith("_")}
    for obj in objects:
        # PySide caches its own SignalInstance objects in vars(); only OUR attributes matter.
        clashes = [n for n, v in vars(obj).items() if n in qt_names and type(v).__name__ != "SignalInstance"]
        assert not clashes, f"{type(obj).__name__} has attributes that shadow Qt methods: {clashes}"
    for d in dialogs:
        if isinstance(d, (InvoiceDialog,)):
            d._worker.wait(5000)
        d.close()
    store.close()


# ---- sign in ----------------------------------------------------------------------------
def test_login_dialog_first_account_then_sign_in(qapp, data_dir):
    from zari.ui.login import LoginDialog
    store = AccountStore(data_dir)
    first = LoginDialog(store)
    assert first.pages.currentIndex() == 1  # no accounts yet -> create-account page
    first.c_name.setText("Arya S")
    first.c_user.setText("Arya")
    first.c_pw.setText("Sunrise2026")
    first.c_pw2.setText("Different1")
    first._create()
    assert first.account is None and "do not match" in first.create_error.text()
    first.c_pw2.setText("Sunrise2026")
    first._create()
    assert first.account.username == "arya" and first.account.is_owner

    second = LoginDialog(store)
    assert second.pages.currentIndex() == 0
    second.user_box.setCurrentText("arya")
    second.pw.setText("wrong-pass1")
    second._sign_in()
    assert second.account is None and second.signin_error.text() == "Wrong username or password."
    second.pw.setText("Sunrise2026")
    second._sign_in()
    assert second.account.display_name == "Arya S"
    assert auth.last_user() == "arya"
    store.close()


# ---- documents ----------------------------------------------------------------------------
def test_attach_invoice_pdf_and_files_to_an_event(win, tmp_path, monkeypatch):
    from zari.ui import documents_ui
    ev = kapoor(win)
    repo = win.ctx.repo
    f1 = tmp_path / "venue-contract.pdf"
    f1.write_bytes(b"%PDF-1.4 contract")
    f2 = tmp_path / "receipt.jpg"
    f2.write_bytes(b"jpgdata")
    bad = tmp_path / "evil.exe"
    bad.write_bytes(b"MZ")

    def fake_exec(self):
        self.kind.setCurrentText("Contract")
        self._on_save()
        return hasattr(self, "result_data")
    monkeypatch.setattr(documents_ui.AttachDialog, "exec", fake_exec)

    before = repo.count_documents(ev.id)
    assert documents_ui.attach_files_flow(win, win.ctx, ev.id, [str(f1), str(f2)]) == 2
    docs = repo.list_documents(ev.id)
    assert len(docs) == before + 2 and {d.kind for d in docs[:2]} == {"Contract"}
    assert all(attachments.attachment_path(d.stored_name).is_file() for d in docs[:2])
    assert documents_ui.attach_files_flow(win, win.ctx, ev.id, [str(bad)]) == 0  # executables are refused
    assert repo.count_documents(ev.id) == before + 2

    win.open_panel(ev.id)
    texts = [w.text() for w in win.panel.findChildren(QWidget) if hasattr(w, "text") and callable(w.text)]
    assert "venue-contract" in texts or any("venue-contract" in t for t in texts)
    documents_ui._remove(win, win.ctx, docs[0])
    assert repo.count_documents(ev.id) == before + 1


def test_drop_files_on_the_panel_opens_the_attach_flow(win, tmp_path, monkeypatch):
    from PySide6.QtCore import QMimeData, QUrl, QPoint, Qt
    from PySide6.QtGui import QDropEvent
    from zari.ui import event_panel
    seen = {}
    monkeypatch.setattr(event_panel, "attach_files_flow", lambda w, ctx, eid, paths: seen.update(eid=eid, paths=paths))
    f = tmp_path / "scan.pdf"
    f.write_bytes(b"x")
    ev = kapoor(win)
    win.open_panel(ev.id)
    mime = QMimeData()
    mime.setUrls([QUrl.fromLocalFile(str(f)), QUrl.fromLocalFile(str(tmp_path / "folder-does-not-exist"))])
    drop = QDropEvent(QPoint(10, 10), Qt.DropAction.CopyAction, mime, Qt.MouseButton.LeftButton, Qt.KeyboardModifier.NoModifier)
    win.panel.dropEvent(drop)
    from pathlib import Path
    assert seen["eid"] == ev.id and [Path(p) for p in seen["paths"]] == [f]


def test_invoice_pdf_scan_creates_expense_and_document(win, tmp_path):
    from reportlab.lib.pagesizes import A4
    from reportlab.pdfgen import canvas
    from zari.ui import invoice_dialog as idlg

    pdf = tmp_path / "invoice.pdf"
    c = canvas.Canvas(str(pdf), pagesize=A4)
    y = 800
    for line in ("Lumen Studios", "TAX INVOICE", "Invoice No: LS-88", "Invoice Date: 05/10/2026",
                 "Photo and film package   14,000.00", "VAT 5%   700.00", "Grand Total AED   14,700.00"):
        c.drawString(60, y, line)
        y -= 22
    c.save()
    repo = win.ctx.repo
    ev = kapoor(win)
    n_docs, n_exp = repo.count_documents(ev.id), len(repo.list_expenses(ev.id))
    dlg = idlg.InvoiceDialog(win, win.ctx, str(pdf), ev.id)
    dlg._worker.wait(10000)
    QApplication.processEvents()
    assert dlg.vendor.text() == "Lumen Studios" and dlg.amount.text() == "14700"
    assert dlg.category.currentText() == "Photography" and dlg.invoice_no.text() == "LS-88"
    assert not dlg.preview.pixmap().isNull()  # first page is shown
    dlg._save()
    exp = next(x for x in repo.list_expenses(ev.id) if x.invoice_no == "LS-88")
    docs = [d for d in repo.list_documents(ev.id) if d.expense_id == exp.id]
    assert len(repo.list_expenses(ev.id)) == n_exp + 1 and repo.count_documents(ev.id) == n_docs + 1
    assert docs[0].kind == "Invoice" and docs[0].original_name == "invoice.pdf" and docs[0].title == "Lumen Studios #LS-88"
    assert exp.amount == 1_470_000


def test_camera_helpers_without_hardware(win, messages, monkeypatch):
    from zari.ui import camera_dialog
    monkeypatch.setattr(camera_dialog, "cameras_available", lambda: False)
    monkeypatch.setattr(camera_dialog, "info", lambda p, t, m: messages.append((t, m)))
    assert camera_dialog.take_photo(win) is None
    assert messages and "No camera" in messages[0][0]


# ---- budget card ----------------------------------------------------------------------------
def test_budget_card_saves_without_rebuilding_panel(win):
    from zari.ui.event_sections import BudgetCard
    ev = kapoor(win)
    repo = win.ctx.repo
    win.open_panel(ev.id)
    card = next(w for w in win.panel.findChildren(BudgetCard))
    edit = card._widgets["Transport"]["edit"]
    edit.setText("7,500")
    edit.editingFinished.emit()
    assert repo.get_budgets(ev.id)["Transport"] == 750_000
    assert card._widgets["Transport"]["left"].text() == "AED 7,500"
    assert win.panel.skip_refresh is False  # consumed by the refresh that the save triggered
    edit.setText("abc")
    edit.editingFinished.emit()
    assert not card.error.isHidden() and repo.get_budgets(ev.id)["Transport"] == 750_000
    edit.setText("")
    edit.editingFinished.emit()
    assert "Transport" not in repo.get_budgets(ev.id)
    card.contingency.setText("12.5")
    card.contingency.editingFinished.emit()
    assert repo.get_event(ev.id).contingency_bp == 1250


# ---- quotes ---------------------------------------------------------------------------------
def test_quotes_dialog_select_convert_and_numbers(win):
    from zari.logic import budget
    from zari.ui.quotes_ui import QuotesDialog
    ev = kapoor(win)
    repo = win.ctx.repo
    dlg = QuotesDialog(win, win.ctx, ev.id)
    photo = [q for q in repo.list_quotes(ev.id) if q.requirement.startswith("Wedding photography")]
    lumen = next(q for q in photo if q.vendor_name == "Lumen Studios")
    cheapest = min(photo, key=lambda q: q.amount)
    assert cheapest.vendor_name == "Frame & Fable" and all(q.status != "Selected" for q in photo)

    def committed():
        s = budget.summarize(repo.get_budgets(ev.id), repo.list_expenses(ev.id), repo.list_quotes(ev.id))
        return s.total_committed, s.total_actual
    c0, a0 = committed()
    dlg._select(lumen)                                   # the user's choice, not the cheapest
    assert repo.get_quote(lumen.id).status == "Selected"
    assert committed() == (c0 + lumen.amount, a0)
    dlg._to_expense(repo.get_quote(lumen.id))
    assert committed() == (c0, a0 + lumen.amount)        # moved, not doubled
    assert repo.get_quote(lumen.id).expense_id
    dlg._set_status(cheapest, "Rejected")
    assert repo.get_quote(cheapest.id).status == "Rejected"
    dlg.close()


def test_quote_form_validation_and_new_vendor(win):
    from zari.ui.quotes_ui import QuoteDialog
    ev = kapoor(win)
    dlg = QuoteDialog(win, win.ctx.repo, ev.id)
    dlg._on_save()
    assert not hasattr(dlg, "result_data")
    assert not dlg._rows["requirement"][1].isHidden() and not dlg._rows["vendor"][1].isHidden()
    dlg.requirement.setCurrentText("DJ for the reception")
    dlg.vendor.setCurrentIndex(dlg.vendor.findData(win.ctx.repo.list_vendors()[0].id))
    dlg.amount.setText("6,000")
    dlg.deposit.setText("7,000")
    dlg._on_save()
    assert "deposit" in " ".join(e.text() for _k, (_w, e) in dlg._rows.items() if not e.isHidden()).lower()
    dlg.deposit.setText("2,000")
    dlg._on_save()
    assert dlg.result_data["amount"] == 600_000 and dlg.result_data["deposit"] == 200_000


# ---- guests ---------------------------------------------------------------------------------
def test_guests_dialog_masking_filters_rsvp_and_export(win, tmp_path, monkeypatch):
    from PySide6.QtWidgets import QFileDialog
    from openpyxl import load_workbook
    from zari.ui import guests_ui
    ev = kapoor(win)
    dlg = guests_ui.GuestsDialog(win, win.ctx, ev.id)
    assert dlg.table.rowCount() == 7
    contact_col = dlg.COLS.index("Contact")
    first = dlg.table.item(0, contact_col).text()
    assert "anand" not in first.lower() and "+971" not in first and "•" in first   # masked by default
    dlg.show_contacts.setChecked(True)
    assert "+971" in dlg.table.item(0, contact_col).text()
    dlg.show_contacts.setChecked(False)

    dlg.rsvp_filter.setCurrentText("Pending")
    assert dlg.table.rowCount() == 3
    dlg.rsvp_filter.setCurrentIndex(0)
    dlg.search.setText("desai")
    assert dlg.table.rowCount() == 1
    dlg.table.selectRow(0)
    dlg._mark("Confirmed")
    stats = win.ctx.repo.guest_stats(ev.id)
    assert stats["confirmed"] == 4 and "People" not in dlg.summary.text()
    dlg.search.setText("")

    out = tmp_path / "guests.xlsx"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(out), ""))
    monkeypatch.setattr(dlg, "_ask_contacts", lambda: False)
    dlg._export()
    headers = [c.value for c in load_workbook(out)["Guests"][1]]
    assert "Phone" not in headers and "Email" not in headers and "Name" in headers
    monkeypatch.setattr(dlg, "_ask_contacts", lambda: True)
    dlg._export()
    assert "Phone" in [c.value for c in load_workbook(out)["Guests"][1]]
    dlg.close()


def test_guest_excel_import_roundtrip_and_bad_rows(win, tmp_path, monkeypatch):
    from openpyxl import Workbook
    from PySide6.QtWidgets import QFileDialog
    from zari.exports import guest_excel
    from zari.ui import guests_ui
    ev = kapoor(win)
    wb = Workbook()
    ws = wb.active
    ws.append(["Name", "Phone", "Email", "Party size", "Group", "Invited", "RSVP", "Notes"])
    ws.append(["Imported Family", "+971 50 111 2222", "imp@mail.com", 4, "Friends", "Yes", "confirmed", ""])
    ws.append(["", "", "", 1, "", "", "", ""])                       # no name -> problem
    ws.append(["Bad Size", "", "", "abc", "", "", "", ""])           # bad size -> problem
    ws.append(['=HYPERLINK("http://x")', "", "", 1, "", "", "", ""])  # a real Excel formula: refused, never imported
    path = tmp_path / "in.xlsx"
    wb.save(path)
    rows, problems = guest_excel.read_guests(path)
    assert [r["name"] for r in rows] == ["Imported Family"] and len(problems) == 3
    assert rows[0]["rsvp"] == "Confirmed" and rows[0]["invited"] is True
    assert guest_excel.read_guests(tmp_path / "nope.xlsx")[0] == []

    dlg = guests_ui.GuestsDialog(win, win.ctx, ev.id)
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(path), ""))
    n = len(win.ctx.repo.list_guests(ev.id))
    dlg._import()
    assert len(win.ctx.repo.list_guests(ev.id)) == n + 1
    dlg._import()   # importing the same file again adds nobody
    assert len(win.ctx.repo.list_guests(ev.id)) == n + 1
    dlg.close()
    from zari.logic.validation import validate_guest
    win.ctx.repo.add_guest(ev.id, validate_guest('=HYPERLINK("http://evil")', "", "", 1, "", False, "Pending"))
    out = guest_excel.export_guests(tmp_path / "out.xlsx", win.ctx.repo.list_guests(ev.id))
    from openpyxl import load_workbook
    cell = [c for row in load_workbook(out)["Guests"].iter_rows() for c in row if str(c.value).startswith("=HYPER")][0]
    assert cell.data_type == "s"   # stored as text, cannot run as a formula


# ---- scenarios ------------------------------------------------------------------------------
def test_scenario_dialog_sandbox_save_and_apply(win):
    from zari.ui.scenario_ui import ScenarioDialog
    ev = kapoor(win)
    repo = win.ctx.repo
    dlg = ScenarioDialog(win, win.ctx, ev.id)
    before = (repo.get_event(ev.id).guests, repo.get_event(ev.id).contract_value, repo.list_expenses(ev.id))
    dlg.guests.setValue(ev.guests + 50)
    dlg.contract_pct.setText("10")
    dlg.adjust["Venue"].setText("5")
    assert dlg.table.columnCount() == 3 and dlg.table.rowCount() >= 6
    headers = [dlg.table.horizontalHeaderItem(c).text() for c in range(dlg.table.columnCount())]
    assert headers[1] == "Current plan" and headers[-1].endswith("(editing)")
    assert (repo.get_event(ev.id).guests, repo.get_event(ev.id).contract_value, repo.list_expenses(ev.id)) == before

    dlg.contract_pct.setText("not a number")
    assert not dlg.message.isHidden() and not dlg.apply_btn.isEnabled()
    dlg.contract_pct.setText("10")

    dlg.name.setText("Bigger party")
    dlg._save()
    (saved,) = repo.list_scenarios(ev.id)
    assert saved.guests == ev.guests + 50 and saved.contract_bp == 1000 and saved.adjust_bp == {"Venue": 500}
    assert (repo.get_event(ev.id).guests, repo.get_event(ev.id).contract_value) == before[:2]   # still untouched

    dlg._apply()
    after = repo.get_event(ev.id)
    assert after.guests == ev.guests + 50 and after.contract_value == ev.contract_value * 110 // 100
    assert repo.list_expenses(ev.id) == before[2]       # costs never rewritten
    dlg.picker.setCurrentIndex(1)
    dlg._delete_saved()
    assert repo.list_scenarios(ev.id) == []
    dlg.close()


# ---- vendors page -----------------------------------------------------------------------------
def test_vendors_page_search_edit_delete_rules(win, messages):
    page = win.pages["vendors"]
    repo = win.ctx.repo
    assert "12 of 12" in page.count.text()
    page.search.setText("candid")
    assert "1 of 12" in page.count.text()
    page.search.setText("")
    page.category.setCurrentText("Photography")
    assert "3 of 12" in page.count.text()
    page.category.setCurrentIndex(0)
    lumen = next(v for v in repo.list_vendors() if v.name == "Lumen Studios")
    page._delete(lumen)                           # has quotes -> blocked with a clear message
    assert messages and "quotation" in messages[-1][1] and repo.get_vendor(lumen.id)
    unused = next(v for v in repo.list_vendors() if v.name == "Annapoorna Catering")
    page._delete(unused)
    assert repo.get_vendor(unused.id) is None


# ---- reports page -----------------------------------------------------------------------------
def test_reports_page_matches_logic_and_exports(win, tmp_path, monkeypatch):
    from openpyxl import load_workbook
    from PySide6.QtWidgets import QFileDialog
    page = win.pages["reports"]
    page.refresh()
    event_rows, budget_rows, vendor_rows = page._data
    assert all(r.event.status != "Cancelled" for r in event_rows)
    assert page.events_table.rowCount() == len(event_rows) + 1   # + totals row
    last = page.events_table.rowCount() - 1
    assert page.events_table.item(last, 3).text() == format_aed(sum(r.contract for r in event_rows))
    assert page.events_table.item(last, 10).text() == format_aed(sum(r.profit for r in event_rows))
    page.include_cancelled.setChecked(True)
    assert any(r.event.status == "Cancelled" for r in page._data[0])
    page.include_cancelled.setChecked(False)

    xlsx, pdf = tmp_path / "r.xlsx", tmp_path / "r.pdf"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(xlsx), ""))
    page._export("xlsx")
    wb = load_workbook(xlsx)
    assert wb.sheetnames == ["Events", "Budget vs Actual", "Vendor payables"]
    ws = wb["Events"]
    assert ws.max_row == len(event_rows) + 2                     # header + rows + totals
    assert ws.cell(row=ws.max_row, column=4).value == sum(r.contract for r in event_rows) / 100
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(pdf), ""))
    page._export("pdf")
    assert pdf.read_bytes().startswith(b"%PDF") and pdf.stat().st_size > 2000


# ---- alerts on the dashboard --------------------------------------------------------------------
def test_dashboard_alerts_card_shows_and_opens_events(win):
    dash = win.pages["dashboard"]
    texts = " | ".join(w.text() for w in dash.alerts_card.findChildren(QWidget) if hasattr(w, "text") and callable(w.text))
    assert "Overdue" in texts and "Sharma" in texts           # sample overdue catering payment
    opened = []
    win.ctx.event_requested.connect(opened.append)
    from zari.ui.widgets import ClickableFrame
    rows = dash.alerts_card.findChildren(ClickableFrame)
    assert rows and len(rows) <= 8
    rows[0].clicked.emit()
    assert opened


def test_expense_due_date_shows_in_panel_and_dialog(win):
    from zari.ui.dialogs import ExpenseDialog
    ev = next(e for e in win.ctx.repo.list_events() if e.name.startswith("Sharma"))
    exp = next(x for x in win.ctx.repo.list_expenses(ev.id) if x.due_date)
    dlg = ExpenseDialog(win, exp, ["Spice Route Events"])
    assert dlg.due.value() == exp.due_date
    dlg.due.clear()
    dlg._on_save()
    assert dlg.result_data["due_date"] is None
    win.open_panel(ev.id)
    texts = " | ".join(w.text() for w in win.panel.findChildren(QWidget) if hasattr(w, "text") and callable(w.text))
    assert "Overdue 2d" in texts
