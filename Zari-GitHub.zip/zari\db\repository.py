"""All database reads and writes. No UI code in here, no business rules beyond integrity."""
from __future__ import annotations

from datetime import date

from zari.db.database import Database
from zari.db.models import EventSummary, Expense, Payment, Task, parse_iso
from zari.db.repo_budget import BudgetMixin
from zari.db.repo_documents import DocumentMixin
from zari.db.repo_guests import GuestMixin
from zari.db.repo_vendors import VendorMixin
from zari.logic import sample_data
from zari.logic.money import to_fils

_EVENT_SELECT = """
SELECT e.*,
       COALESCE((SELECT SUM(amount) FROM payments WHERE event_id = e.id), 0)               AS received,
       COALESCE((SELECT SUM(amount) FROM expenses WHERE event_id = e.id), 0)               AS expenses,
       COALESCE((SELECT SUM(amount) FROM expenses WHERE event_id = e.id AND paid = 0), 0)  AS unpaid_expenses
FROM events e
"""


def _event(row) -> EventSummary:
    return EventSummary(
        id=row["id"], name=row["name"], client=row["client"], type=row["type"],
        date=parse_iso(row["date"]), venue=row["venue"], guests=row["guests"],
        status=row["status"], contract_value=row["contract_value"], notes=row["notes"],
        is_sample=bool(row["is_sample"]), contingency_bp=row["contingency_bp"], received=row["received"],
        expenses=row["expenses"], unpaid_expenses=row["unpaid_expenses"],
    )


def _expense(row) -> Expense:
    return Expense(
        id=row["id"], event_id=row["event_id"], category=row["category"],
        description=row["description"], amount=row["amount"], paid=bool(row["paid"]),
        vendor=row["vendor"], invoice_no=row["invoice_no"], invoice_file=row["invoice_file"],
        date=parse_iso(row["date"]), due_date=parse_iso(row["due_date"]),
    )


class Repository(VendorMixin, BudgetMixin, GuestMixin, DocumentMixin):
    def __init__(self, db: Database):
        self.db = db

    @property
    def conn(self):
        # Always go through the Database so a restore (which reopens the file) is picked up.
        return self.db.conn

    # ===== events ====================================================================
    def list_events(self) -> list[EventSummary]:
        rows = self.conn.execute(_EVENT_SELECT + " ORDER BY e.date, e.name").fetchall()
        return [_event(r) for r in rows]

    def get_event(self, event_id: int) -> EventSummary | None:
        row = self.conn.execute(_EVENT_SELECT + " WHERE e.id = ?", (event_id,)).fetchone()
        return _event(row) if row else None

    def add_event(self, data: dict, is_sample: bool = False) -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO events (name, client, type, date, venue, guests, status, contract_value, is_sample)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (data["name"], data["client"], data["type"], data["date"], data["venue"],
                 data["guests"], data["status"], data["contract_value"], int(is_sample)),
            )
        return cur.lastrowid

    def update_event(self, event_id: int, data: dict) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE events SET name=?, client=?, type=?, date=?, venue=?, guests=?, status=?,"
                " contract_value=? WHERE id=?",
                (data["name"], data["client"], data["type"], data["date"], data["venue"],
                 data["guests"], data["status"], data["contract_value"], event_id),
            )

    def set_contract_value(self, event_id: int, fils: int) -> None:
        with self.conn:
            self.conn.execute("UPDATE events SET contract_value=? WHERE id=?", (fils, event_id))

    def event_record_counts(self, event_id: int) -> dict:
        c = self.conn
        return {
            "payments": c.execute("SELECT COUNT(*) FROM payments WHERE event_id=?", (event_id,)).fetchone()[0],
            "expenses": c.execute("SELECT COUNT(*) FROM expenses WHERE event_id=?", (event_id,)).fetchone()[0],
            "tasks": c.execute("SELECT COUNT(*) FROM tasks WHERE event_id=?", (event_id,)).fetchone()[0],
        }

    def delete_event(self, event_id: int) -> None:
        """Delete an event and (by cascade) its payments and expenses.

        If it carries financial records we first write an automatic backup, so
        a mistaken delete can always be undone with Restore.
        """
        counts = self.event_record_counts(event_id)
        if counts["payments"] or counts["expenses"]:
            self.db.safety_backup("before-delete-event")
        with self.conn:
            self.conn.execute("DELETE FROM events WHERE id=?", (event_id,))

    # ===== payments ==================================================================
    def list_payments(self, event_id: int | None = None) -> list[Payment]:
        sql = "SELECT * FROM payments"
        args: tuple = ()
        if event_id is not None:
            sql += " WHERE event_id = ?"
            args = (event_id,)
        rows = self.conn.execute(sql + " ORDER BY date, id", args).fetchall()
        return [Payment(r["id"], r["event_id"], r["amount"], parse_iso(r["date"]), r["label"]) for r in rows]

    def add_payment(self, event_id: int, data: dict) -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO payments (event_id, amount, date, label) VALUES (?,?,?,?)",
                (event_id, data["amount"], data["date"], data["label"]),
            )
        return cur.lastrowid

    def update_payment(self, payment_id: int, data: dict) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE payments SET amount=?, date=?, label=? WHERE id=?",
                (data["amount"], data["date"], data["label"], payment_id),
            )

    def delete_payment(self, payment_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM payments WHERE id=?", (payment_id,))

    # ===== expenses ==================================================================
    def list_expenses(self, event_id: int) -> list[Expense]:
        rows = self.conn.execute(
            "SELECT * FROM expenses WHERE event_id=? ORDER BY category, id", (event_id,)
        ).fetchall()
        return [_expense(r) for r in rows]

    def list_all_expenses(self) -> list[Expense]:
        return [_expense(r) for r in self.conn.execute("SELECT * FROM expenses ORDER BY event_id, id")]

    def get_expense(self, expense_id: int) -> Expense | None:
        row = self.conn.execute("SELECT * FROM expenses WHERE id=?", (expense_id,)).fetchone()
        return _expense(row) if row else None

    def add_expense(self, event_id: int, data: dict, paid: bool = False, invoice_file: str = "") -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO expenses (event_id, category, description, amount, paid, vendor,"
                " invoice_no, invoice_file, date, due_date) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (event_id, data["category"], data["description"], data["amount"], int(paid),
                 data.get("vendor", ""), data.get("invoice_no", ""), invoice_file, data.get("date"),
                 data.get("due_date")),
            )
        return cur.lastrowid

    def update_expense(self, expense_id: int, data: dict) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE expenses SET category=?, description=?, amount=?, vendor=?, due_date=? WHERE id=?",
                (data["category"], data["description"], data["amount"], data.get("vendor", ""),
                 data.get("due_date"), expense_id),
            )

    def set_expense_paid(self, expense_id: int, paid: bool) -> None:
        with self.conn:
            self.conn.execute("UPDATE expenses SET paid=? WHERE id=?", (int(paid), expense_id))

    def delete_expense(self, expense_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM expenses WHERE id=?", (expense_id,))

    def find_duplicate_expense(self, event_id: int, amount: int, vendor: str, invoice_no: str) -> Expense | None:
        """Spot a likely double entry: same invoice number, or same vendor + amount."""
        if invoice_no:
            row = self.conn.execute(
                "SELECT * FROM expenses WHERE event_id=? AND invoice_no=? AND lower(vendor)=lower(?)",
                (event_id, invoice_no, vendor),
            ).fetchone()
            if row:
                return _expense(row)
        if vendor:
            row = self.conn.execute(
                "SELECT * FROM expenses WHERE event_id=? AND amount=? AND lower(vendor)=lower(?)",
                (event_id, amount, vendor),
            ).fetchone()
            if row:
                return _expense(row)
        return None

    # ===== tasks =====================================================================
    def list_tasks(self) -> list[Task]:
        rows = self.conn.execute(
            "SELECT t.*, e.name AS event_name FROM tasks t LEFT JOIN events e ON e.id = t.event_id"
            " ORDER BY t.due, t.id"
        ).fetchall()
        return [Task(r["id"], r["title"], r["event_id"], r["event_name"], parse_iso(r["due"]),
                     r["priority"], bool(r["done"]), bool(r["is_sample"])) for r in rows]

    def add_task(self, data: dict) -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO tasks (title, event_id, due, priority) VALUES (?,?,?,?)",
                (data["title"], data["event_id"], data["due"], data["priority"]),
            )
        return cur.lastrowid

    def update_task(self, task_id: int, data: dict) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE tasks SET title=?, event_id=?, due=?, priority=? WHERE id=?",
                (data["title"], data["event_id"], data["due"], data["priority"], task_id),
            )

    def set_task_done(self, task_id: int, done: bool) -> None:
        with self.conn:
            self.conn.execute("UPDATE tasks SET done=? WHERE id=?", (int(done), task_id))

    def delete_task(self, task_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))

    # ===== sample data ===============================================================
    def has_any_data(self) -> bool:
        return bool(self.conn.execute("SELECT 1 FROM events LIMIT 1").fetchone()
                    or self.conn.execute("SELECT 1 FROM tasks LIMIT 1").fetchone())

    def has_sample_data(self) -> bool:
        return bool(self.conn.execute("SELECT 1 FROM events WHERE is_sample=1 LIMIT 1").fetchone()
                    or self.conn.execute("SELECT 1 FROM tasks WHERE is_sample=1 LIMIT 1").fetchone())

    def remove_sample_data(self) -> None:
        """Delete only records flagged as sample. Your own events are never touched."""
        with self.conn:
            self._delete_sample_rows()

    def _delete_sample_rows(self) -> None:
        self.conn.execute("DELETE FROM tasks WHERE is_sample=1")
        self.conn.execute("DELETE FROM events WHERE is_sample=1")  # cascades to payments, expenses, quotes, guests...
        # Sample vendors go too, unless one of YOUR quotes still refers to it.
        self.conn.execute("DELETE FROM vendors WHERE is_sample=1 AND id NOT IN (SELECT vendor_id FROM quotes)")

    def seed_sample_data(self, today: date | None = None) -> None:
        """Insert (or re-insert) the sample set in one transaction."""
        today = today or date.today()
        payload = sample_data.build(today)
        with self.conn:
            self._delete_sample_rows()
            vendor_ids: dict[str, int] = {}
            for name, category, contact, phone, email in payload["vendors"]:
                row = self.conn.execute("SELECT id FROM vendors WHERE name=?", (name,)).fetchone()
                if row:  # you already have a vendor with this name: use yours, don't duplicate it
                    vendor_ids[name] = row["id"]
                    continue
                cur = self.conn.execute(
                    "INSERT INTO vendors (name, category, contact_name, phone, email, is_sample) VALUES (?,?,?,?,?,1)",
                    (name, category, contact, phone, email))
                vendor_ids[name] = cur.lastrowid
            ids: dict[str, int] = {}
            for ev in payload["events"]:
                cur = self.conn.execute(
                    "INSERT INTO events (name, client, type, date, venue, guests, status, contract_value,"
                    " contingency_bp, is_sample) VALUES (?,?,?,?,?,?,?,?,?,1)",
                    (ev["name"], ev["client"], ev["type"], ev["date"], ev["venue"], ev["guests"],
                     ev["status"], to_fils(ev["contract_aed"]), ev["contingency_bp"]),
                )
                eid = ids[ev["name"]] = cur.lastrowid
                self.conn.executemany(
                    "INSERT INTO payments (event_id, label, date, amount) VALUES (?,?,?,?)",
                    [(eid, label, dt, to_fils(amt)) for label, dt, amt in ev["payments"]],
                )
                self.conn.executemany(
                    "INSERT INTO expenses (event_id, category, description, vendor, amount, paid, date, due_date)"
                    " VALUES (?,?,?,?,?,?,?,?)",
                    [(eid, cat, desc, vendor, to_fils(amt), int(paid), dt, due)
                     for cat, desc, vendor, amt, paid, dt, due in ev["expenses"]],
                )
                self.conn.executemany(
                    "INSERT INTO budgets (event_id, category, amount) VALUES (?,?,?)",
                    [(eid, cat, to_fils(amt)) for cat, amt in ev["budgets"].items()],
                )
            self.conn.executemany(
                "INSERT INTO quotes (event_id, requirement, category, vendor_id, amount, deposit, valid_until,"
                " rating, status) VALUES (?,?,?,?,?,?,?,?,?)",
                [(ids[ev], req, cat, vendor_ids[vendor], to_fils(amt), to_fils(dep), valid, rating, status)
                 for ev, req, cat, vendor, amt, dep, valid, rating, status in payload["quotes"]],
            )
            self.conn.executemany(
                "INSERT INTO guests (event_id, name, phone, email, party_size, grp, invited, rsvp)"
                " VALUES (?,?,?,?,?,?,?,?)",
                [(ids[ev], name, phone, email, size, grp, invited, rsvp)
                 for ev, name, phone, email, size, grp, invited, rsvp in payload["guests"]],
            )
            self.conn.executemany(
                "INSERT INTO tasks (title, due, priority, event_id, done, is_sample) VALUES (?,?,?,?,?,1)",
                [(t, due, pr, ids.get(ev), int(done)) for t, due, pr, ev, done in payload["tasks"]],
            )
