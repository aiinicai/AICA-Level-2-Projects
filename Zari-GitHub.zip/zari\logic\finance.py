"""Financial calculations. Pure functions: no database, no UI.

Definitions (used consistently everywhere in the app):
  * active event      - any event whose status is not "Cancelled"
  * balance due       - contract value minus payments received (never below 0;
                        exactly 0 for a cancelled event)
  * gross profit      - contract value minus total expenses
  * margin %          - gross profit / contract value * 100
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta
from decimal import Decimal, ROUND_HALF_UP

from zari.config import MARGIN_GOOD, MARGIN_WARN


@dataclass(frozen=True)
class EventFinancials:
    contract: int
    received: int
    expenses: int
    unpaid_expenses: int
    balance_due: int
    profit: int
    margin: float | None  # percent; None when the contract value is zero
    progress: float       # received / contract, clamped to 0..1


def compute_financials(contract: int, received: int, expenses: int,
                       unpaid_expenses: int, status: str) -> EventFinancials:
    balance = 0 if status == "Cancelled" else max(0, contract - received)
    profit = contract - expenses
    margin = (profit / contract * 100) if contract > 0 else None
    progress = min(1.0, received / contract) if contract > 0 else 0.0
    return EventFinancials(contract, received, expenses, unpaid_expenses, balance, profit, margin, progress)


def margin_level(margin: float | None) -> str:
    """'success' (>20%), 'warning' (10-20%), 'danger' (<10%), 'muted' (unknown)."""
    if margin is None:
        return "muted"
    if margin > MARGIN_GOOD:
        return "success"
    if margin >= MARGIN_WARN:
        return "warning"
    return "danger"


def format_margin(margin: float | None) -> str:
    return "-" if margin is None else f"{margin:.1f}%"


def greeting(hour: int) -> str:
    """Time-of-day greeting: morning 5-11, afternoon 12-16, evening 17-20, night otherwise."""
    if 5 <= hour < 12:
        return "Good morning"
    if 12 <= hour < 17:
        return "Good afternoon"
    if 17 <= hour < 21:
        return "Good evening"
    return "Good night"


def countdown_text(event_date: date, today: date) -> str:
    days = (event_date - today).days
    if days == 0:
        return "Today"
    if days == 1:
        return "Tomorrow"
    if days > 1:
        return f"in {days} days"
    if days == -1:
        return "Yesterday"
    return f"{-days} days ago"


def share_of_payment(payment_fils: int, margin: float | None) -> int:
    """Profit attributable to one payment = payment x the event's margin."""
    if margin is None:
        return 0
    value = Decimal(payment_fils) * Decimal(str(margin)) / Decimal(100)
    return int(value.quantize(Decimal("1"), rounding=ROUND_HALF_UP))


def months_back(today: date, count: int = 6) -> list[tuple[int, int]]:
    """(year, month) pairs for the last `count` months, oldest first, ending this month."""
    y, m = today.year, today.month
    out = []
    for _ in range(count):
        out.append((y, m))
        m -= 1
        if m == 0:
            m, y = 12, y - 1
    return out[::-1]


def monthly_series(payments, summaries_by_id: dict, today: date, count: int = 6):
    """Return (labels, revenue, profit) lists, one entry per month (fils)."""
    keys = months_back(today, count)
    revenue = {k: 0 for k in keys}
    profit = {k: 0 for k in keys}
    for p in payments:
        k = (p.date.year, p.date.month)
        if k not in revenue:
            continue
        revenue[k] += p.amount
        ev = summaries_by_id.get(p.event_id)
        if ev is not None:
            profit[k] += share_of_payment(p.amount, ev.fin.margin)
    labels = [date(y, m, 1).strftime("%b") for y, m in keys]
    return labels, [revenue[k] for k in keys], [profit[k] for k in keys]


@dataclass(frozen=True)
class DashboardStats:
    next_30_days: int
    revenue_this_month: int
    outstanding: int
    avg_margin: float | None
    pending_tasks: int
    overdue_tasks: int


def dashboard_stats(summaries, payments, tasks, today: date) -> DashboardStats:
    horizon = today + timedelta(days=30)
    active = [e for e in summaries if e.is_active]
    margins = [e.fin.margin for e in active if e.fin.margin is not None]
    pending = [t for t in tasks if not t.done]
    return DashboardStats(
        next_30_days=sum(1 for e in active if today <= e.date <= horizon),
        revenue_this_month=sum(
            p.amount for p in payments if (p.date.year, p.date.month) == (today.year, today.month)
        ),
        outstanding=sum(e.fin.balance_due for e in active),
        avg_margin=(sum(margins) / len(margins)) if margins else None,
        pending_tasks=len(pending),
        overdue_tasks=sum(1 for t in pending if t.due < today),
    )


def upcoming_events(summaries, today: date, limit: int | None = 6):
    items = sorted((e for e in summaries if e.is_active and e.date >= today), key=lambda e: (e.date, e.name))
    return items if limit is None else items[:limit]
