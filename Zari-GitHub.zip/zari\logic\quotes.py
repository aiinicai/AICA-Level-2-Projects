"""Compare vendor quotations for the same requirement.

Zari highlights facts (lowest price, top rated) and offers a *suggestion* of best value
(lowest price per rating point). It never selects a vendor for you.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date


@dataclass
class QuoteView:
    quote: object
    vs_lowest_pct: float | None = None   # +12.5 means 12.5% dearer than the cheapest live quote
    is_lowest: bool = False
    is_top_rated: bool = False
    is_suggested: bool = False
    expired: bool = False


@dataclass
class RequirementGroup:
    requirement: str
    category: str
    views: list = field(default_factory=list)

    @property
    def selected(self):
        return next((v.quote for v in self.views if v.quote.status == "Selected"), None)

    @property
    def lowest(self):
        return next((v.quote for v in self.views if v.is_lowest), None)


def group_quotes(quotes, today: date) -> list[RequirementGroup]:
    groups: dict[str, RequirementGroup] = {}
    for q in quotes:
        g = groups.setdefault(q.requirement.strip().lower(), RequirementGroup(q.requirement, q.category))
        g.views.append(QuoteView(q, expired=bool(q.valid_until and q.valid_until < today
                                                 and q.status in ("Requested", "Received")
                                                 and not q.expense_id)))
    for g in groups.values():
        g.views.sort(key=lambda v: (v.quote.status == "Rejected", v.quote.amount))
        live = [v for v in g.views if v.quote.status != "Rejected"]
        if live:
            lowest = min(v.quote.amount for v in live)
            for v in live:
                v.vs_lowest_pct = (v.quote.amount / lowest - 1) * 100
                v.is_lowest = v.quote.amount == lowest
            rated = [v for v in live if v.quote.rating]
            if rated:
                best = max(v.quote.rating for v in rated)
                for v in rated:
                    v.is_top_rated = v.quote.rating == best
            candidates = [v for v in rated if not v.expired]
            if len(live) >= 2 and candidates:
                pick = min(candidates, key=lambda v: v.quote.amount / v.quote.rating)
                pick.is_suggested = True
    return sorted(groups.values(), key=lambda g: g.requirement.lower())
