"""Dashboard task list with inline add / edit, filters, priorities and overdue highlighting."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QButtonGroup, QCheckBox, QComboBox, QFrame, QHBoxLayout, QLineEdit, QVBoxLayout, QWidget,
)

from zari.config import PRIORITIES
from zari.logic.validation import ValidationError, validate_task
from zari.ui import theme
from zari.ui.dialogs import confirm, from_qdate, make_date_edit, to_qdate
from zari.ui.widgets import Badge, Card, clear_layout, icon_button, make_button, make_label, shrinkable


class TasksPanel(Card):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.filter = "all"
        self.editing_id: int | None = None
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 20)
        lay.setSpacing(12)

        head = QHBoxLayout()
        head.addWidget(make_label("Tasks", "h3"))
        self.count = make_label("", "small")
        head.addWidget(self.count)
        head.addStretch(1)
        group = QButtonGroup(self)
        self._filter_buttons = {}
        for key, text in (("all", "All"), ("pending", "Pending"), ("done", "Done")):
            b = make_button(text, "pill")
            b.setCheckable(True)
            b.setChecked(key == "all")
            b.clicked.connect(lambda _=False, k=key: self._set_filter(k))
            group.addButton(b)
            self._filter_buttons[key] = b
            head.addWidget(b)
        lay.addLayout(head)

        # inline form
        form = QHBoxLayout()
        form.setSpacing(8)
        self.title = QLineEdit()
        self.title.setPlaceholderText("Add a task...")
        self.title.returnPressed.connect(self._submit)
        self.event_box = QComboBox()
        self.event_box.setMinimumWidth(170)
        self.due = make_date_edit()
        self.priority = QComboBox()
        self.priority.addItems(PRIORITIES)
        self.priority.setCurrentText("Medium")
        self.submit = make_button("Add", "primary", "plus")
        self.submit.clicked.connect(self._submit)
        self.cancel_edit = make_button("Cancel")
        self.cancel_edit.clicked.connect(self._reset_form)
        self.cancel_edit.hide()
        form.addWidget(self.title, 3)
        form.addWidget(self.event_box, 2)
        form.addWidget(self.due, 0)
        form.addWidget(self.priority, 0)
        form.addWidget(self.submit)
        form.addWidget(self.cancel_edit)
        lay.addLayout(form)
        self.error = make_label("", "small", color=theme.DANGER)
        self.error.hide()
        lay.addWidget(self.error)

        self.rows = QVBoxLayout()
        self.rows.setSpacing(6)
        lay.addLayout(self.rows)

    # ---- data -----------------------------------------------------------------------
    def refresh(self) -> None:
        # event picker
        current = self.event_box.currentData()
        self.event_box.blockSignals(True)
        self.event_box.clear()
        self.event_box.addItem("No linked event", None)
        for e in self.ctx.repo.list_events():
            self.event_box.addItem(e.name, e.id)
        idx = self.event_box.findData(current)
        self.event_box.setCurrentIndex(max(0, idx))
        self.event_box.blockSignals(False)

        tasks = self.ctx.repo.list_tasks()
        shown = [t for t in tasks if self.filter == "all" or (self.filter == "pending") != t.done]
        pending = sum(1 for t in tasks if not t.done)
        self.count.setText(f"  {pending} pending")
        clear_layout(self.rows)
        if not shown:
            msg = {"all": "No tasks yet - add your first one above.",
                   "pending": "Nothing pending. Well done!", "done": "No completed tasks yet."}[self.filter]
            self.rows.addWidget(make_label(msg, "muted"))
        for t in shown:
            self.rows.addWidget(self._row(t))

    def _row(self, t) -> QWidget:
        today = self.ctx.today
        overdue = not t.done and t.due < today
        frame = QFrame()
        frame.setObjectName("TaskRow")
        border = theme.rgba(theme.DANGER, 0.7) if overdue else theme.rgba(theme.GOLD, 0.18)
        bg = theme.rgba(theme.DANGER, 0.13) if overdue else theme.rgba("#000000", 0.12)
        frame.setStyleSheet(f"QFrame#TaskRow {{ background: {bg}; border: 1px solid {border}; border-radius: 10px; }}")
        row = QHBoxLayout(frame)
        row.setContentsMargins(12, 8, 8, 8)
        row.setSpacing(10)

        cb = QCheckBox()
        cb.setChecked(t.done)
        cb.setToolTip("Mark as done" if not t.done else "Mark as not done")
        cb.toggled.connect(lambda on, tid=t.id: self._toggle(tid, on))
        row.addWidget(cb)

        text = QVBoxLayout()
        text.setSpacing(0)
        title = shrinkable(make_label(t.title, "body", color=theme.IVORY_MUTED if t.done else theme.IVORY))
        if t.done:
            f = title.font()
            f.setStrikeOut(True)
            title.setFont(f)
        text.addWidget(title)
        if t.event_name:
            text.addWidget(make_label(t.event_name, "small"))
        row.addLayout(text, 1)

        if overdue:
            days = (today - t.due).days
            due = make_label(f"Overdue · {days} day{'s' if days != 1 else ''}", "small", color=theme.DANGER)
            f = due.font()
            f.setWeight(QFont.Weight.DemiBold)
            due.setFont(f)
        else:
            due = make_label(f"Due {t.due:%d %b}", "small")
        row.addWidget(due)
        row.addWidget(Badge(t.priority, theme.PRIORITY_COLORS[t.priority]))
        edit = icon_button("edit", "Edit task")
        edit.clicked.connect(lambda _=False, task=t: self._start_edit(task))
        delete = icon_button("trash", "Delete task", danger=True)
        delete.clicked.connect(lambda _=False, task=t: self._delete(task))
        row.addWidget(edit)
        row.addWidget(delete)
        return frame

    # ---- actions --------------------------------------------------------------------
    def _set_filter(self, key: str) -> None:
        self.filter = key
        self.refresh()

    def _toggle(self, task_id: int, done: bool) -> None:
        self.ctx.repo.set_task_done(task_id, done)
        self.ctx.data_changed()

    def _start_edit(self, t) -> None:
        self.editing_id = t.id
        self.title.setText(t.title)
        self.due.setDate(to_qdate(t.due))
        self.priority.setCurrentText(t.priority)
        self.event_box.setCurrentIndex(max(0, self.event_box.findData(t.event_id)))
        self.submit.setText("Save")
        self.cancel_edit.show()
        self.title.setFocus()

    def _reset_form(self) -> None:
        self.editing_id = None
        self.title.clear()
        self.priority.setCurrentText("Medium")
        self.event_box.setCurrentIndex(0)
        self.submit.setText("Add")
        self.cancel_edit.hide()
        self.error.hide()
        self.title.setProperty("invalid", False)
        self.title.style().unpolish(self.title)
        self.title.style().polish(self.title)

    def _submit(self) -> None:
        try:
            data = validate_task(self.title.text(), from_qdate(self.due.date()),
                                 self.priority.currentText(), self.event_box.currentData())
        except ValidationError as exc:
            self.error.setText(" ".join(exc.errors.values()))
            self.error.show()
            self.title.setProperty("invalid", "title" in exc.errors)
            self.title.style().unpolish(self.title)
            self.title.style().polish(self.title)
            return
        if self.editing_id is None:
            self.ctx.repo.add_task(data)
            msg = "Task added"
        else:
            self.ctx.repo.update_task(self.editing_id, data)
            msg = "Task updated"
        self._reset_form()
        self.ctx.data_changed(msg)

    def _delete(self, t) -> None:
        if confirm(self.window(), "Delete this task?", f"\"{t.title}\" will be removed."):
            if self.editing_id == t.id:
                self._reset_form()
            self.ctx.repo.delete_task(t.id)
            self.ctx.data_changed("Task deleted")
