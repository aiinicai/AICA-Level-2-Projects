"""Guest list: add / edit / remove, RSVP tracking, search, Excel import and export.

Privacy: phone numbers and emails are hidden (masked) until you switch "Show contact details" on,
and Excel exports leave them out unless you tick the box in the export prompt.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QHeaderView, QLineEdit, QSpinBox,
    QTableWidget, QTableWidgetItem, QVBoxLayout,
)

from zari.exports import guest_excel
from zari.logic.validation import RSVP_STATES, validate_guest
from zari.ui import theme
from zari.ui.dialogs import FormDialog, confirm, info
from zari.ui.widgets import Badge, make_button, make_label, set_label_color

RSVP_COLORS = {"Confirmed": theme.SUCCESS, "Pending": theme.WARNING, "Declined": theme.DANGER}


def mask_phone(phone: str) -> str:
    digits = [c for c in phone if c.isdigit()]
    return "" if not phone else ("•••• " + "".join(digits[-3:]) if len(digits) >= 3 else "••••")


def mask_email(email: str) -> str:
    if "@" not in email:
        return "" if not email else "••••"
    local, domain = email.split("@", 1)
    return f"{local[:1]}•••@{domain}"


class GuestForm(FormDialog):
    def __init__(self, parent, guest=None, default_group: str = ""):
        super().__init__(parent, "Edit guest" if guest else "Add guest", "Guest list", width=520)
        self.name = QLineEdit(guest.name if guest else "")
        self.name.setPlaceholderText("Guest or family name")
        self.party = QSpinBox()
        self.party.setRange(0, 50)
        self.party.setValue(guest.party_size if guest else 1)
        self.party.setToolTip("How many people this invitation covers")
        self.group = QLineEdit(guest.group if guest else default_group)
        self.group.setPlaceholderText("e.g. Bride's family, Colleagues")
        self.phone = QLineEdit(guest.phone if guest else "")
        self.email = QLineEdit(guest.email if guest else "")
        self.rsvp = QComboBox()
        self.rsvp.addItems(RSVP_STATES)
        self.rsvp.setCurrentText(guest.rsvp if guest else "Pending")
        self.invited = QCheckBox("Invitation sent")
        self.invited.setChecked(guest.invited if guest else False)
        self.notes = QLineEdit(guest.notes if guest else "")
        self.notes.setPlaceholderText("Dietary needs, seating wishes...")
        self.add_field("name", "Name", self.name)
        self.add_field("party_size", "Party size", self.party, row_with="start")
        self.add_field("group", "Group", self.group, row_with="end")
        self.add_field("phone", "Phone", self.phone, row_with="start")
        self.add_field("email", "Email", self.email, row_with="end")
        self.add_field("rsvp", "RSVP", self.rsvp, row_with="start")
        self.add_field("invited", "Invitation", self.invited, row_with="end")
        self.add_field("notes", "Notes", self.notes)

    def collect(self) -> dict:
        return validate_guest(self.name.text(), self.phone.text(), self.email.text(), self.party.value(),
                              self.group.text(), self.invited.isChecked(), self.rsvp.currentText(), self.notes.text())


class GuestsDialog(QDialog):
    COLS = ["Name", "Party", "Group", "Invited", "RSVP", "Contact", "Notes"]

    def __init__(self, parent, ctx, event_id: int):
        super().__init__(parent)
        self.ctx, self.event_id = ctx, event_id
        self.ev = ctx.repo.get_event(event_id)
        self.setWindowTitle(f"Guests - {self.ev.name}")
        self.resize(1040, 680)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)   # lets you go full screen
        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 18)
        root.setSpacing(10)

        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Guest list & RSVP", "eyebrow"))
        titles.addWidget(make_label(self.ev.name, "h2"))
        head.addLayout(titles)
        head.addStretch(1)
        for text, icon, slot in (("Template", "download", self._template), ("Import Excel", "download", self._import),
                                 ("Export Excel", "download", self._export)):
            b = make_button(text, icon_name=icon)
            b.clicked.connect(slot)
            head.addWidget(b, 0, Qt.AlignmentFlag.AlignBottom)
        add = make_button("Add guest", "primary", "plus")
        add.clicked.connect(self._add)
        head.addWidget(add, 0, Qt.AlignmentFlag.AlignBottom)
        root.addLayout(head)

        self.summary = make_label("", "body", wrap=True)
        root.addWidget(self.summary)

        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search name, group or notes...")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.refresh)
        self.rsvp_filter = QComboBox()
        self.rsvp_filter.addItems(["All RSVPs"] + RSVP_STATES)
        self.rsvp_filter.currentIndexChanged.connect(self.refresh)
        self.show_contacts = QCheckBox("Show contact details")
        self.show_contacts.setToolTip("Phone numbers and emails are hidden unless you switch this on.")
        self.show_contacts.toggled.connect(self.refresh)
        filters.addWidget(self.search, 1)
        filters.addWidget(self.rsvp_filter)
        filters.addWidget(self.show_contacts)
        root.addLayout(filters)

        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setShowGrid(False)
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        hdr.setStretchLastSection(True)
        for i, w in enumerate((250, 60, 150, 70, 100, 290)):
            self.table.setColumnWidth(i, w)
        self.table.doubleClicked.connect(lambda _i: self._edit())
        root.addWidget(self.table, 1)

        actions = QHBoxLayout()
        actions.addWidget(make_label("With selected:", "small"))
        for state in RSVP_STATES:
            b = make_button(f"Mark {state.lower()}")
            b.clicked.connect(lambda _=False, s=state: self._mark(s))
            actions.addWidget(b)
        actions.addStretch(1)
        edit = make_button("Edit", icon_name="edit")
        edit.clicked.connect(self._edit)
        rm = make_button("Remove", "danger", "trash")
        rm.clicked.connect(self._remove)
        actions.addWidget(edit)
        actions.addWidget(rm)
        root.addLayout(actions)
        self.guests = []
        ctx.changed.connect(self.refresh)
        self.refresh()

    def done(self, result: int) -> None:
        try:
            self.ctx.changed.disconnect(self.refresh)
        except (RuntimeError, TypeError):
            pass
        super().done(result)

    # ---- data -----------------------------------------------------------------------
    def _visible(self):
        q = self.search.text().strip().lower()
        state = self.rsvp_filter.currentText()
        out = []
        for g in self.ctx.repo.list_guests(self.event_id):
            if state != "All RSVPs" and g.rsvp != state:
                continue
            if q and not any(q in s.lower() for s in (g.name, g.group, g.notes)):
                continue
            out.append(g)
        return out

    def refresh(self, *_) -> None:
        self.ev = self.ctx.repo.get_event(self.event_id) or self.ev
        s = self.ctx.repo.guest_stats(self.event_id)
        expected = self.ev.guests
        over = s["heads_confirmed"] > expected
        self.summary.setText(
            f"{s['parties']} invitations covering {s['heads_total']} people  ·  "
            f"{s['confirmed']} confirmed ({s['heads_confirmed']} people), {s['pending']} pending "
            f"({s['heads_pending']} people), {s['declined']} declined  ·  expected guests: {expected:,}"
            + ("  -  confirmed headcount is above the expected count!" if over else ""))
        set_label_color(self.summary, theme.WARNING if over else theme.IVORY)
        self.guests = self._visible()
        self.table.setRowCount(len(self.guests))
        reveal = self.show_contacts.isChecked()
        for r, g in enumerate(self.guests):
            contact = " · ".join(x for x in ((g.phone, g.email) if reveal else (mask_phone(g.phone), mask_email(g.email))) if x)
            cells = [g.name, str(g.party_size), g.group, "Yes" if g.invited else "No", g.rsvp, contact, g.notes]
            for c, text in enumerate(cells):
                item = QTableWidgetItem(text)
                if c in (1, 3):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if c == 4:
                    from PySide6.QtGui import QColor
                    item.setForeground(QColor(RSVP_COLORS[g.rsvp]))
                self.table.setItem(r, c, item)

    def _selected(self):
        rows = sorted({i.row() for i in self.table.selectedIndexes()})
        return [self.guests[r] for r in rows if r < len(self.guests)]

    # ---- actions --------------------------------------------------------------------
    def _add(self) -> None:
        dlg = GuestForm(self)
        if dlg.exec():
            self.ctx.repo.add_guest(self.event_id, dlg.result_data)
            self.ctx.data_changed("Guest added")

    def _edit(self) -> None:
        sel = self._selected()
        if len(sel) != 1:
            info(self, "Choose one guest", "Select a single guest to edit.")
            return
        dlg = GuestForm(self, sel[0])
        if dlg.exec():
            self.ctx.repo.update_guest(sel[0].id, dlg.result_data)
            self.ctx.data_changed("Guest updated")

    def _mark(self, state: str) -> None:
        sel = self._selected()
        if not sel:
            info(self, "Select guests first", "Click one or more guests in the list, then choose an RSVP status.")
            return
        for g in sel:
            self.ctx.repo.set_guest_rsvp(g.id, state)
        self.ctx.data_changed(f"{len(sel)} marked {state.lower()}")

    def _remove(self) -> None:
        sel = self._selected()
        if not sel:
            info(self, "Select guests first", "Click one or more guests in the list to remove them.")
            return
        names = ", ".join(g.name for g in sel[:3]) + (f" and {len(sel) - 3} more" if len(sel) > 3 else "")
        if confirm(self, f"Remove {len(sel)} guest(s)?", names):
            for g in sel:
                self.ctx.repo.delete_guest(g.id)
            self.ctx.data_changed("Guests removed")

    def _template(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Save the guest list template", "guest-list-template.xlsx",
                                              "Excel workbook (*.xlsx)")
        if path:
            try:
                guest_excel.write_template(path)
            except OSError as exc:
                info(self, "Could not save the file", str(exc))
                return
            self.ctx.notify(f"Template saved to {path}")

    def _import(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import guests from Excel", str(Path.home()),
                                              "Excel workbook (*.xlsx)")
        if not path:
            return
        rows, problems = guest_excel.read_guests(path)
        if not rows and problems:
            info(self, "Nothing to import", "\n".join(problems[:8]))
            return
        msg = f"{len(rows)} guest row(s) are ready to import."
        if problems:
            msg += f"\n\n{len(problems)} row(s) will be skipped:\n" + "\n".join(problems[:8])
            msg += "\n..." if len(problems) > 8 else ""
        msg += "\n\nGuests already on the list (same name and contact details) are not added twice."
        if not confirm(self, "Import guests?", msg, action="Import", danger=False):
            return
        added, dupes = self.ctx.repo.import_guests(self.event_id, rows)
        self.ctx.data_changed(f"Imported {added} guest(s)" + (f", {dupes} already on the list" if dupes else ""))

    def _ask_contacts(self) -> bool | None:
        """True = include phone/email, False = leave them out, None = cancel the export."""
        from PySide6.QtWidgets import QMessageBox
        box = QMessageBox(self)
        box.setWindowTitle("Export guest list")
        box.setText("<b>Include phone numbers and emails?</b>")
        box.setInformativeText("Contact details are private. Leave them out unless you really need them in the file.")
        box.setIcon(QMessageBox.Icon.NoIcon)
        without = box.addButton("Without contacts", QMessageBox.ButtonRole.AcceptRole)
        without.setProperty("variant", "primary")
        with_ = box.addButton("Include contacts", QMessageBox.ButtonRole.DestructiveRole)
        box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(without)
        box.exec()
        clicked = box.clickedButton()
        return False if clicked is without else (True if clicked is with_ else None)

    def _export(self) -> None:
        guests = self.ctx.repo.list_guests(self.event_id)
        if not guests:
            info(self, "Nothing to export", "The guest list is empty.")
            return
        include = self._ask_contacts()
        if include is None:
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export guest list", "guest-list.xlsx", "Excel workbook (*.xlsx)")
        if not path:
            return
        try:
            guest_excel.export_guests(path, guests, include_contacts=include)
        except OSError as exc:
            info(self, "Could not save the file", f"{exc}\n\nIf the file is open in Excel, close it and try again.")
            return
        self.ctx.notify(f"Exported {len(guests)} invitations to {path}")
