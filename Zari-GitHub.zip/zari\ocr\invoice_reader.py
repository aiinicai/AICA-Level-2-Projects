"""Run Tesseract OCR (offline, on this PC) on an invoice photo and parse the result."""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

from zari.ocr import pdf_reader
from zari.ocr.invoice_parser import InvoiceFields, parse_invoice_text

SUPPORTED_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp", ".pdf"}
INSTALL_HELP = (
    "Zari reads invoices with Tesseract, a free OCR program that runs on your PC.\n\n"
    "To install it, open Windows Terminal and run:\n"
    "    winget install UB-Mannheim.TesseractOCR\n\n"
    "Then restart Zari. (You can still enter the invoice details by hand below.)"
)


class OcrUnavailable(Exception):
    """Tesseract is not installed / not found."""


class OcrFailed(Exception):
    """The image could not be read."""


def find_tesseract() -> str | None:
    found = shutil.which("tesseract")
    if found:
        return found
    candidates = [
        Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Tesseract-OCR" / "tesseract.exe",
        Path(os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")) / "Tesseract-OCR" / "tesseract.exe",
        Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "Tesseract-OCR" / "tesseract.exe",
    ]
    for c in candidates:
        if c.is_file():
            return str(c)
    return None


def _prepare(path: Path):
    """Make the photo easier for OCR: upright, greyscale, high contrast, big enough."""
    from PIL import Image, ImageOps

    with Image.open(path) as img:
        img = ImageOps.exif_transpose(img)
        img = ImageOps.autocontrast(img.convert("L"))
        if max(img.size) < 1800:
            scale = 1800 / max(img.size)
            img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
        return img.copy()



def _ocr_image(path: Path, exe: str) -> str:
    import pytesseract

    pytesseract.pytesseract.tesseract_cmd = exe
    try:
        image = _prepare(path)
    except Exception as exc:  # corrupted / unreadable image
        raise OcrFailed(f"Could not open that image: {exc}") from exc
    try:
        langs = pytesseract.get_languages(config="")
        lang = "eng+ara" if "ara" in langs and "eng" in langs else "eng"
        return pytesseract.image_to_string(image, lang=lang, config="--psm 6")
    except Exception as exc:
        raise OcrFailed(f"Tesseract could not read the invoice: {exc}") from exc


def _read_pdf(path: Path) -> InvoiceFields:
    """Digital PDF -> use its own text (no OCR needed). Scanned PDF -> OCR each page."""
    try:
        text = pdf_reader.embedded_text(path)
    except pdf_reader.PdfError as exc:
        raise OcrFailed(str(exc)) from exc
    if len(text.strip()) >= pdf_reader.MIN_TEXT_CHARS:
        return parse_invoice_text(text)
    exe = find_tesseract()
    if not exe:
        raise OcrUnavailable("This PDF is a scan (a picture of a page), so it needs OCR.\n\n" + INSTALL_HELP)
    with tempfile.TemporaryDirectory() as tmp:
        try:
            pages = pdf_reader.render_pages(path, Path(tmp))
        except pdf_reader.PdfError as exc:
            raise OcrFailed(str(exc)) from exc
        return parse_invoice_text("\n".join(_ocr_image(p, exe) for p in pages))


def read_invoice(path: str | Path) -> InvoiceFields:
    path = Path(path)
    if path.suffix.lower() not in SUPPORTED_SUFFIXES:
        raise OcrFailed("Please choose a photo (JPG, PNG, TIFF, BMP, WEBP) or a PDF.")
    if path.suffix.lower() == ".pdf":
        return _read_pdf(path)
    exe = find_tesseract()
    if not exe:
        raise OcrUnavailable(INSTALL_HELP)
    return parse_invoice_text(_ocr_image(path, exe))
