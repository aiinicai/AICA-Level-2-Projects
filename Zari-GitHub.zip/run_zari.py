"""Launcher used to build Zari.exe (PyInstaller needs a plain script rather than `python -m zari`)."""
import sys

if __name__ == "__main__":
    if len(sys.argv) >= 3 and sys.argv[1] == "--selftest":
        from zari.selftest import run
        sys.exit(run(sys.argv[2]))
    from zari.__main__ import main
    sys.exit(main())
