"""Turn raw OCR text from an invoice into structured fields.

OCR text is messy, so every field carries a confidence flag. The review screen
highlights low-confidence or missing fields so a human always checks before saving.
Dates are read day-first (UAE convention).
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import date

MONTHS = {m: i for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}

_NUM = r"\d{1,3}(?:[,\s]\d{3})+(?:\.\d{1,2})?|\d+(?:\.\d{1,2})?"
_AMOUNT_RE = re.compile(rf"(?<![\w.,/-])({_NUM})(?![\w/-])")
_DATE_NUMERIC = re.compile(r"\b(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{2,4})\b")
_DATE_ISO = re.compile(r"\b(\d{4})[/\-.](\d{1,2})[/\-.](\d{1,2})\b")
_DATE_DMY_TEXT = re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?[\s\-]+([A-Za-z]{3,9})\.?,?[\s\-]+(\d{2,4})\b")
_DATE_MDY_TEXT = re.compile(r"\b([A-Za-z]{3,9})\.?\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b")
_INVOICE_NO = re.compile(r"(?i)(?:invoice|inv|bill|receipt)\s*(?:no\.?|number|#|:)?\s*[:#]?\s*([A-Z0-9][A-Z0-9\-/]{2,24})")

_STRONG_TOTAL = ("grand total", "total amount", "amount due", "balance due", "net payable",
                 "total due", "total payable", "amount payable", "total (aed)", "total aed", "total incl")
_NOT_VENDOR = ("invoice", "tax", "receipt", "bill to", "date", "trn", "tel", "phone", "www.",
               "http", "email", "@", "page ", "p.o", "po box", "address", "customer")

CATEGORY_KEYWORDS = {
    "Catering": ("cater", "food", "restaurant", "kitchen", "buffet", "bakery", "sweets", "beverage"),
    "Decor": ("flower", "floral", "decor", "lighting", "drape", "styling", "furniture", "rental"),
    "Photography": ("photo", "video", "studio", "film", "cinema", "drone"),
    "Entertainment": ("dj ", "band", "music", "singer", "artist", "entertain", "sound", "dhol", "dance"),
    "Venue": ("hotel", "venue", "hall", "resort", "palace", "ballroom", "banquet", "convention"),
    "Transport": ("transport", "limousine", "limo", "car rental", "taxi", "bus ", "logistics", "chauffeur"),
    "Staff": ("staff", "manpower", "security", "hospitality staffing", "ushers", "labour", "recruit"),
}


@dataclass
class InvoiceFields:
    vendor: str = ""
    invoice_date: date | None = None
    invoice_no: str = ""
    total_aed: str = ""          # plain text for the form field, e.g. "12500.50"
    vat_aed: str = ""
    category: str = "Other"
    description: str = ""
    raw_text: str = ""
    # field name -> True when we are NOT confident and the user should double-check
    uncertain: dict = field(default_factory=dict)


def _to_decimal_text(token: str) -> str:
    return token.replace(",", "").replace(" ", "")


def _amounts_in(line: str) -> list[float]:
    out = []
    for m in _AMOUNT_RE.finditer(line):
        text = _to_decimal_text(m.group(1))
        if len(text.replace(".", "")) > 10:  # phone numbers, TRNs, long references
            continue
        try:
            out.append(float(text))
        except ValueError:
            continue
    return out


def _is_date_line(line: str) -> bool:
    return bool(_DATE_NUMERIC.search(line) or _DATE_ISO.search(line) or _DATE_DMY_TEXT.search(line))


def _make_date(y: int, m: int, d: int) -> date | None:
    if y < 100:
        y += 2000
    try:
        result = date(y, m, d)
    except ValueError:
        return None
    return result if 2000 <= result.year <= 2100 else None


def find_dates(line: str) -> list[date]:
    """Dates on one line. OCR often inserts stray spaces ("12/1 0/2026"), so retry with those squeezed out."""
    found = _find_dates(line)
    if not found:
        squeezed = re.sub(r"(?<=[\d/.\-])\s+(?=[\d/.\-])", "", line)
        if squeezed != line:
            found = _find_dates(squeezed)
    return found


def _find_dates(line: str) -> list[date]:
    found: list[date] = []
    for m in _DATE_ISO.finditer(line):
        d = _make_date(int(m[1]), int(m[2]), int(m[3]))
        if d:
            found.append(d)
    for m in _DATE_NUMERIC.finditer(line):
        d = _make_date(int(m[3]), int(m[2]), int(m[1]))  # day-first
        if d:
            found.append(d)
    for m in _DATE_DMY_TEXT.finditer(line):
        mon = MONTHS.get(m[2][:3].lower())
        if mon:
            d = _make_date(int(m[3]), mon, int(m[1]))
            if d:
                found.append(d)
    for m in _DATE_MDY_TEXT.finditer(line):
        mon = MONTHS.get(m[1][:3].lower())
        if mon:
            d = _make_date(int(m[3]), mon, int(m[2]))
            if d:
                found.append(d)
    return found


def _pick_date(lines: list[str]) -> tuple[date | None, bool]:
    """Prefer a date on an 'invoice date' / 'date' line, ignoring due dates."""
    for line in lines:
        low = line.lower()
        if "date" in low and "due" not in low:
            dates = find_dates(line)
            if dates:
                return dates[0], False
    for line in lines:
        if "due" not in line.lower():
            dates = find_dates(line)
            if dates:
                return dates[0], True
    return None, True


def _pick_total(lines: list[str]) -> tuple[float | None, bool]:
    strong = []
    weak = []
    for line in lines:
        low = line.lower()
        if "sub total" in low or "subtotal" in low or "total vat" in low or "total tax" in low:
            continue
        nums = [n for n in _amounts_in(line) if n > 0]
        if not nums:
            continue
        if any(k in low for k in _STRONG_TOTAL):
            strong.append(max(nums))
        elif "total" in low:
            weak.append(max(nums))
    if strong:
        return strong[-1], False   # the last "grand total" style line is normally the final figure
    if weak:
        return weak[-1], False
    # Last resort: biggest plausible number on a non-date line. Flag it as uncertain.
    candidates = [n for line in lines if not _is_date_line(line) for n in _amounts_in(line) if n > 0]
    return (max(candidates), True) if candidates else (None, True)


def _pick_vat(lines: list[str]) -> float | None:
    for line in lines:
        low = line.lower()
        if ("vat" in low or "tax" in low) and "trn" not in low and "registration" not in low:
            nums = [n for n in _amounts_in(line) if n > 0 and n != 5]  # skip the "5%" rate itself
            if nums:
                return nums[-1]
    return None


def _pick_vendor(lines: list[str]) -> tuple[str, bool]:
    for line in lines[:8]:
        text = re.sub(r"[^\w&.,'\- ]+", " ", line).strip()
        letters = sum(c.isalpha() for c in text)
        if letters < 3 or any(k in text.lower() for k in _NOT_VENDOR):
            continue
        if sum(c.isdigit() for c in text) > letters:
            continue
        return " ".join(text.split())[:80], False
    return "", True


def guess_category(text: str) -> str:
    low = f" {text.lower()} "
    best, best_hits = "Other", 0
    for category, words in CATEGORY_KEYWORDS.items():
        hits = sum(low.count(w) for w in words)
        if hits > best_hits:
            best, best_hits = category, hits
    return best


def _fmt_amount(value: float) -> str:
    return f"{value:.2f}".rstrip("0").rstrip(".") if value != int(value) else str(int(value))


def parse_invoice_text(text: str) -> InvoiceFields:
    lines = [ln.strip() for ln in (text or "").splitlines() if ln.strip()]
    result = InvoiceFields(raw_text=text or "")
    if not lines:
        result.uncertain = {k: True for k in ("vendor", "date", "total", "category")}
        return result

    result.vendor, vendor_unsure = _pick_vendor(lines)
    result.invoice_date, date_unsure = _pick_date(lines)
    total, total_unsure = _pick_total(lines)
    if total is not None:
        result.total_aed = _fmt_amount(total)
    vat = _pick_vat(lines)
    if vat is not None:
        result.vat_aed = _fmt_amount(vat)

    for line in lines:
        m = _INVOICE_NO.search(line)
        if m and any(c.isdigit() for c in m.group(1)):
            result.invoice_no = m.group(1)
            break

    result.category = guess_category(" ".join(lines))
    result.description = f"Invoice from {result.vendor}" if result.vendor else "Scanned invoice"
    if result.invoice_no:
        result.description += f" #{result.invoice_no}"
    result.uncertain = {
        "vendor": vendor_unsure,
        "date": date_unsure,
        "total": total_unsure or total is None,
        "category": result.category == "Other",
    }
    return result
