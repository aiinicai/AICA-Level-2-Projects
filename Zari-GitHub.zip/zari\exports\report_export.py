"""Excel and PDF versions of the Reports page. Numbers come from the same logic as the screen."""
from __future__ import annotations

from datetime import date
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from zari.exports.charts import add_excel_budget_chart, budget_drawing
from zari.exports.excel_export import AED_FMT, _aed, _autosize, _header, harden_workbook
from zari.exports.pdf_export import BURGUNDY, GOLD, _plain
from zari.logic.finance import format_margin
from zari.logic.money import format_aed

EVENT_COLS = ["Event", "Date", "Status", "Contract", "Received", "Balance due", "Budget", "Actual cost",
              "Committed", "Budget left", "Gross profit", "Margin"]
BUDGET_COLS = ["Event", "Category", "Budget", "Quoted (open)", "Committed", "Actual", "Remaining", "Used", "Status"]
VENDOR_COLS = ["Vendor", "Items", "Total", "Paid", "Unpaid", "Next payment due"]


def _event_values(r):
    f = r.event
    return [f.name, f.date.isoformat(), f.status, r.contract, r.received, r.balance_due, r.budget, r.actual,
            r.committed, r.variance, r.profit, format_margin(r.margin)]


def _budget_values(ev, l):
    return [ev.name, l.category, l.budget, l.quoted, l.committed, l.actual, l.remaining if l.budget else None,
            f"{l.used_pct:.0f}%" if l.used_pct is not None else "-", {"none": "No budget", "ok": "On track",
                                                                       "warning": "Near limit", "over": "Over budget"}[l.status]]


def _vendor_values(p):
    return [p.vendor, p.items, p.total, p.paid, p.unpaid, p.next_due.isoformat() if p.next_due else ""]


def export_reports_excel(path: str | Path, event_rows, budget_rows, vendor_rows) -> Path:
    wb = Workbook()
    sheets = [("Events", EVENT_COLS, [_event_values(r) for r in event_rows], range(4, 12)),
              ("Budget vs Actual", BUDGET_COLS, [_budget_values(e, l) for e, l in budget_rows], range(3, 8)),
              ("Vendor payables", VENDOR_COLS, [_vendor_values(p) for p in vendor_rows], range(3, 6))]
    for i, (title, cols, rows, money_cols) in enumerate(sheets):
        ws = wb.active if i == 0 else wb.create_sheet()
        ws.title = title
        _header(ws, 1, cols)
        for r, values in enumerate(rows, 2):
            for c, v in enumerate(values, 1):
                is_money = c in money_cols and isinstance(v, int) and not (title == "Vendor payables" and c == 2)
                cell = ws.cell(row=r, column=c, value=_aed(v) if is_money else v)
                if is_money:
                    cell.number_format = AED_FMT
        # totals row (sum of the money columns that are always numeric)
        if rows and title != "Budget vs Actual":
            tr = len(rows) + 2
            ws.cell(row=tr, column=1, value="Total").font = Font(bold=True)
            for c in money_cols:
                if title == "Events" and c in (10,):   # budget-left is blank for events without a budget
                    continue
                total = sum(v[c - 1] for v in rows if isinstance(v[c - 1], int))
                cell = ws.cell(row=tr, column=c, value=_aed(total))
                cell.number_format, cell.font = AED_FMT, Font(bold=True)
        _autosize(ws)
        if title == "Events" and event_rows:
            add_excel_budget_chart(ws, 2, len(event_rows) + 1, "N2", "Budget vs actual by event", 1, 7, 8, 9)
    harden_workbook(wb)
    path = Path(path)
    wb.save(path)
    return path


def _pdf_table(cols, rows, widths, right_from: int):
    data = [cols] + [[_plain(v) if isinstance(v, str) else v for v in row] for row in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), BURGUNDY), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"), ("FONTSIZE", (0, 0), (-1, -1), 7.5),
        ("GRID", (0, 0), (-1, -1), 0.3, GOLD), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (right_from, 0), (-1, -1), "RIGHT"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F8F1E4")])]))
    return t


def _money(v):
    return format_aed(v) if isinstance(v, int) else (v if v is not None else "-")


def export_reports_pdf(path: str | Path, event_rows, budget_rows, vendor_rows) -> Path:
    styles = getSampleStyleSheet()
    h1 = ParagraphStyle("h1", parent=styles["Title"], textColor=BURGUNDY, fontName="Times-Bold", fontSize=20)
    h2 = ParagraphStyle("h2", parent=styles["Heading2"], textColor=BURGUNDY, fontName="Times-Bold")
    story = [Paragraph("Zari - Financial report", h1),
             Paragraph(f"Generated {date.today():%d %b %Y}. All amounts in AED.", styles["BodyText"]),
             Spacer(1, 5 * mm)]
    chart_rows = sorted(((r.event.name, r.budget, r.actual, r.committed) for r in event_rows if r.budget or r.actual),
                        key=lambda row: -max(row[1], row[2] + row[3]))[:12]
    if chart_rows:
        story += [budget_drawing(chart_rows, width=270 * mm, row_h=18, title="Budget vs actual by event"),
                  Spacer(1, 4 * mm)]
    story.append(Paragraph("Events: budget against actual", h2))
    rows = [[v[0], v[1], v[2]] + [_money(x) for x in v[3:11]] + [v[11]] for v in map(_event_values, event_rows)]
    story.append(_pdf_table(EVENT_COLS, rows, [44 * mm, 20 * mm, 19 * mm] + [20 * mm] * 8 + [14 * mm], 3))
    story += [Spacer(1, 6 * mm), Paragraph("Budget by category", h2)]
    brows = [[v[0], v[1]] + [_money(x) for x in v[2:7]] + [v[7], v[8]] for v in (_budget_values(e, l) for e, l in budget_rows)]
    story.append(_pdf_table(BUDGET_COLS, brows or [["-"] * len(BUDGET_COLS)],
                            [50 * mm, 24 * mm] + [24 * mm] * 5 + [14 * mm, 22 * mm], 2))
    story += [Spacer(1, 6 * mm), Paragraph("Vendor payables", h2)]
    vrows = [[v[0], v[1]] + [_money(x) for x in v[2:5]] + [v[5]] for v in map(_vendor_values, vendor_rows)]
    story.append(_pdf_table(VENDOR_COLS, vrows or [["-"] * len(VENDOR_COLS)], [70 * mm, 16 * mm, 32 * mm, 32 * mm, 32 * mm, 32 * mm], 1))
    path = Path(path)
    SimpleDocTemplate(str(path), pagesize=landscape(A4), leftMargin=12 * mm, rightMargin=12 * mm,
                      topMargin=12 * mm, bottomMargin=12 * mm, title="Zari report").build(story)
    return path
