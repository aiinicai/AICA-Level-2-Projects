"""Vendor directory: contacts plus what you have quoted, spent and still owe each vendor."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFrame, QHBoxLayout, QLineEdit, QScrollArea, QVBoxLayout, QWidget, QComboBox

from zari.config import EXPENSE_CATEGORIES
from zari.db.repo_vendors import RepositoryError
from zari.logic import reports
from zari.logic.money import format_aed
from zari.ui import theme
from zari.ui.dialogs import confirm, info
from zari.ui.quotes_ui import VendorDialog
from zari.ui.widgets import (
    Badge, ClickableFrame, Ornament, clear_layout, icon_button, make_button, make_label, sample_badge, shrinkable,
)


class VendorsPage(QScrollArea):
    def __init__(self, ctx):
        super().__init__()
        self.ctx = ctx
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        root = QWidget()
        root.setObjectName("PageRoot")
        self.setWidget(root)
        lay = QVBoxLayout(root)
        lay.setContentsMargins(36, 30, 36, 36)
        lay.setSpacing(14)

        head = QHBoxLayout()
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(make_label("Directory", "eyebrow"))
        titles.addWidget(make_label("Vendors", "h1"))
        head.addLayout(titles)
        head.addStretch(1)
        add = make_button("Add vendor", "primary", "plus")
        add.clicked.connect(self._add)
        head.addWidget(add, 0, Qt.AlignmentFlag.AlignBottom)
        lay.addLayout(head)
        lay.addWidget(Ornament(width_limit=900))

        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Search vendor, contact, phone or email...")
        self.search.setClearButtonEnabled(True)
        self.search.textChanged.connect(self.refresh)
        self.category = QComboBox()
        self.category.addItem("All categories")
        self.category.addItems(EXPENSE_CATEGORIES)
        self.category.currentIndexChanged.connect(self.refresh)
        filters.addWidget(self.search, 1)
        filters.addWidget(self.category)
        lay.addLayout(filters)
        self.count = make_label("", "small")
        lay.addWidget(self.count)
        self.list = QVBoxLayout()
        self.list.setSpacing(10)
        lay.addLayout(self.list)
        lay.addStretch(1)

    # ---- actions --------------------------------------------------------------------
    def _add(self) -> None:
        dlg = VendorDialog(self.window())
        if dlg.exec():
            try:
                self.ctx.repo.add_vendor(dlg.result_data)
            except RepositoryError as exc:
                info(self.window(), "Could not add vendor", str(exc))
                return
            self.ctx.data_changed("Vendor added")

    def _edit(self, vendor) -> None:
        dlg = VendorDialog(self.window(), vendor)
        if dlg.exec():
            try:
                self.ctx.repo.update_vendor(vendor.id, dlg.result_data)
            except RepositoryError as exc:
                info(self.window(), "Could not save vendor", str(exc))
                return
            self.ctx.data_changed("Vendor updated")

    def _delete(self, vendor) -> None:
        if confirm(self.window(), f"Delete \"{vendor.name}\"?",
                   "The vendor is removed from your directory. Expenses already recorded with this vendor's "
                   "name are kept."):
            try:
                self.ctx.repo.delete_vendor(vendor.id)
            except RepositoryError as exc:
                info(self.window(), "Cannot delete this vendor", str(exc))
                return
            self.ctx.data_changed("Vendor deleted")

    # ---- list -----------------------------------------------------------------------
    def refresh(self, *_) -> None:
        repo = self.ctx.repo
        vendors = repo.list_vendors()
        q = self.search.text().strip().lower()
        cat = self.category.currentText()
        shown = [v for v in vendors
                 if (cat == "All categories" or v.category == cat)
                 and (not q or any(q in s.lower() for s in (v.name, v.contact_name, v.phone, v.email)))]
        quotes_by = {}
        for qt in repo.list_all_quotes():
            quotes_by.setdefault(qt.vendor_id, []).append(qt)
        pay = {p.vendor.lower(): p for p in reports.vendor_payables(repo.list_events(), repo.list_all_expenses())}

        self.count.setText(f"Showing {len(shown)} of {len(vendors)} vendor{'s' if len(vendors) != 1 else ''}")
        clear_layout(self.list)
        if not shown:
            self.list.addWidget(make_label(
                "No vendors yet. Add the caterers, venues and suppliers you work with, then record their quotations "
                "inside each event." if not vendors else "No vendors match your search.", "muted", wrap=True))
        for v in shown:
            qs = quotes_by.get(v.id, [])
            spend = pay.get(v.name.lower())
            row = ClickableFrame("VendorRow")
            row.clicked.connect(lambda vendor=v: self._edit(vendor))
            h = QHBoxLayout(row)
            h.setContentsMargins(18, 12, 12, 12)
            h.setSpacing(12)
            left = QVBoxLayout()
            left.setSpacing(2)
            top = QHBoxLayout()
            top.setSpacing(8)
            top.addWidget(make_label(v.name, "h3"))
            top.addWidget(Badge(v.category, theme.GOLD))
            if v.is_sample:
                top.addWidget(sample_badge())
            top.addStretch(1)
            left.addLayout(top)
            contact = "  ·  ".join(x for x in (v.contact_name, v.phone, v.email) if x) or "No contact details yet"
            left.addWidget(shrinkable(make_label(contact, "small")))
            h.addLayout(left, 1)
            stats = QVBoxLayout()
            stats.setSpacing(1)
            stats.addWidget(make_label(f"{len(qs)} quotation{'s' if len(qs) != 1 else ''}"
                                       + (f" · {sum(1 for x in qs if x.status == 'Selected')} selected" if qs else ""),
                                       "small", align=Qt.AlignmentFlag.AlignRight))
            stats.addWidget(make_label(
                f"Spent {format_aed(spend.total)}  ·  unpaid {format_aed(spend.unpaid)}" if spend else "No spend recorded",
                "small", color=theme.WARNING if spend and spend.unpaid else theme.IVORY_MUTED,
                align=Qt.AlignmentFlag.AlignRight))
            h.addLayout(stats)
            e = icon_button("edit", "Edit vendor")
            e.clicked.connect(lambda _=False, vendor=v: self._edit(vendor))
            d = icon_button("trash", "Delete vendor", danger=True)
            d.clicked.connect(lambda _=False, vendor=v: self._delete(vendor))
            h.addWidget(e)
            h.addWidget(d)
            self.list.addWidget(row)
