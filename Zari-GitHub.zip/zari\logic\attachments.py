"""Storing attached files (invoices, contracts...) safely inside the user's own data folder."""
from __future__ import annotations

import shutil
import uuid
from pathlib import Path

from zari.config import invoices_dir

MAX_BYTES = 25 * 1024 * 1024
# Files Zari will open on request: refuse anything that could run code when double-clicked.
BLOCKED_SUFFIXES = {".exe", ".bat", ".cmd", ".com", ".msi", ".scr", ".ps1", ".vbs", ".vbe", ".js", ".jse",
                    ".wsf", ".lnk", ".reg", ".dll", ".jar", ".hta", ".cpl", ".msc"}


class AttachmentError(Exception):
    """User-readable reason a file could not be attached."""


def human_size(n: int) -> str:
    if n < 1024:
        return f"{n} B"
    if n < 1024 * 1024:
        return f"{n / 1024:.0f} KB"
    return f"{n / (1024 * 1024):.1f} MB"


def attachment_path(stored_name: str) -> Path:
    return invoices_dir() / Path(stored_name).name  # .name blocks any path tricks


def check_file(src: Path) -> int:
    """Validate a file for attaching; returns its size in bytes."""
    src = Path(src)
    if not src.is_file():
        raise AttachmentError(f"\"{src.name}\" could not be found.")
    if src.suffix.lower() in BLOCKED_SUFFIXES:
        raise AttachmentError(f"\"{src.name}\": programs and scripts ({src.suffix}) cannot be attached.")
    size = src.stat().st_size
    if size == 0:
        raise AttachmentError(f"\"{src.name}\" is empty.")
    if size > MAX_BYTES:
        raise AttachmentError(f"\"{src.name}\" is {human_size(size)}; the limit is {human_size(MAX_BYTES)}.")
    return size


def store_file(src: Path, prefix: str) -> tuple[str, str, int]:
    """Copy `src` into the user's attachment folder. Returns (stored_name, original_name, size)."""
    src = Path(src)
    size = check_file(src)
    stored = f"{prefix}_{uuid.uuid4().hex[:10]}{src.suffix.lower()}"
    try:
        shutil.copyfile(src, invoices_dir() / stored)
    except OSError as exc:
        raise AttachmentError(f"Could not copy \"{src.name}\": {exc}") from exc
    return stored, src.name, size
