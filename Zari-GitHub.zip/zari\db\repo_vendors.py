"""Vendor directory and quotations (mixed into Repository)."""
from __future__ import annotations

import sqlite3

from zari.db.models import Quote, Vendor, parse_iso


class RepositoryError(Exception):
    """A user-readable problem with a requested change."""


def _vendor(r) -> Vendor:
    return Vendor(r["id"], r["name"], r["category"], r["contact_name"], r["phone"], r["email"], r["notes"],
                  bool(r["is_sample"]))


def _quote(r) -> Quote:
    return Quote(r["id"], r["event_id"], r["requirement"], r["category"], r["vendor_id"], r["vendor_name"],
                 r["amount"], r["deposit"], parse_iso(r["valid_until"]), r["rating"], r["status"], r["notes"],
                 r["expense_id"])


_QUOTE_SELECT = "SELECT q.*, v.name AS vendor_name FROM quotes q JOIN vendors v ON v.id = q.vendor_id"


class VendorMixin:
    # ---- vendors --------------------------------------------------------------------
    def list_vendors(self) -> list[Vendor]:
        return [_vendor(r) for r in self.conn.execute("SELECT * FROM vendors ORDER BY name COLLATE NOCASE")]

    def get_vendor(self, vendor_id: int) -> Vendor | None:
        r = self.conn.execute("SELECT * FROM vendors WHERE id=?", (vendor_id,)).fetchone()
        return _vendor(r) if r else None

    def add_vendor(self, data: dict) -> int:
        try:
            with self.conn:
                cur = self.conn.execute(
                    "INSERT INTO vendors (name, category, contact_name, phone, email, notes) VALUES (?,?,?,?,?,?)",
                    (data["name"], data["category"], data["contact_name"], data["phone"], data["email"], data["notes"]))
        except sqlite3.IntegrityError:
            raise RepositoryError(f"A vendor called \"{data['name']}\" already exists.") from None
        return cur.lastrowid

    def update_vendor(self, vendor_id: int, data: dict) -> None:
        try:
            with self.conn:
                self.conn.execute(
                    "UPDATE vendors SET name=?, category=?, contact_name=?, phone=?, email=?, notes=? WHERE id=?",
                    (data["name"], data["category"], data["contact_name"], data["phone"], data["email"],
                     data["notes"], vendor_id))
        except sqlite3.IntegrityError:
            raise RepositoryError(f"A vendor called \"{data['name']}\" already exists.") from None

    def vendor_quote_count(self, vendor_id: int) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM quotes WHERE vendor_id=?", (vendor_id,)).fetchone()[0]

    def delete_vendor(self, vendor_id: int) -> None:
        n = self.vendor_quote_count(vendor_id)
        if n:
            raise RepositoryError(f"This vendor has {n} quotation(s) and cannot be deleted. "
                                  "Delete or reassign those quotes first.")
        with self.conn:
            self.conn.execute("DELETE FROM vendors WHERE id=?", (vendor_id,))

    # ---- quotes ---------------------------------------------------------------------
    def list_quotes(self, event_id: int) -> list[Quote]:
        rows = self.conn.execute(_QUOTE_SELECT + " WHERE q.event_id=? ORDER BY q.requirement COLLATE NOCASE, q.amount",
                                 (event_id,)).fetchall()
        return [_quote(r) for r in rows]

    def list_all_quotes(self) -> list[Quote]:
        return [_quote(r) for r in self.conn.execute(_QUOTE_SELECT + " ORDER BY q.event_id, q.requirement")]

    def vendor_quotes(self, vendor_id: int) -> list[Quote]:
        rows = self.conn.execute(_QUOTE_SELECT + " WHERE q.vendor_id=? ORDER BY q.id DESC", (vendor_id,)).fetchall()
        return [_quote(r) for r in rows]

    def get_quote(self, quote_id: int) -> Quote | None:
        r = self.conn.execute(_QUOTE_SELECT + " WHERE q.id=?", (quote_id,)).fetchone()
        return _quote(r) if r else None

    def add_quote(self, event_id: int, data: dict) -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO quotes (event_id, requirement, category, vendor_id, amount, deposit, valid_until,"
                " rating, status, notes) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (event_id, data["requirement"], data["category"], data["vendor_id"], data["amount"], data["deposit"],
                 data["valid_until"], data["rating"], "Received" if data["status"] == "Selected" else data["status"],
                 data["notes"]))
        qid = cur.lastrowid
        if data["status"] == "Selected":
            self.select_quote(qid)
        return qid

    def update_quote(self, quote_id: int, data: dict) -> None:
        q = self.get_quote(quote_id)
        if q is not None and q.expense_id and (data["amount"] != q.amount or data["vendor_id"] != q.vendor_id):
            raise RepositoryError("This quote has already been turned into an expense. Edit the expense instead.")
        with self.conn:
            self.conn.execute(
                "UPDATE quotes SET requirement=?, category=?, vendor_id=?, amount=?, deposit=?, valid_until=?,"
                " rating=?, notes=? WHERE id=?",
                (data["requirement"], data["category"], data["vendor_id"], data["amount"], data["deposit"],
                 data["valid_until"], data["rating"], data["notes"], quote_id))
        if data["status"] == "Selected":
            self.select_quote(quote_id)
        elif q is not None and data["status"] != q.status:
            self.set_quote_status(quote_id, data["status"])

    def set_quote_status(self, quote_id: int, status: str) -> None:
        if status == "Selected":
            self.select_quote(quote_id)
            return
        with self.conn:
            self.conn.execute("UPDATE quotes SET status=? WHERE id=?", (status, quote_id))

    def select_quote(self, quote_id: int) -> None:
        """Choose this quote for its requirement. Any previously selected rival goes back to 'Received'.

        The choice is always made by you - Zari only highlights the cheapest / best rated for reference.
        """
        q = self.get_quote(quote_id)
        if q is None:
            return
        with self.conn:
            self.conn.execute(
                "UPDATE quotes SET status='Received' WHERE event_id=? AND lower(requirement)=lower(?)"
                " AND status='Selected' AND id<>? AND expense_id IS NULL",
                (q.event_id, q.requirement, quote_id))
            self.conn.execute("UPDATE quotes SET status='Selected' WHERE id=?", (quote_id,))

    def delete_quote(self, quote_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM quotes WHERE id=?", (quote_id,))

    def convert_quote_to_expense(self, quote_id: int) -> int:
        """Record the selected quote as an actual expense. From then on it counts once (as actual), not twice."""
        q = self.get_quote(quote_id)
        if q is None:
            raise RepositoryError("That quote no longer exists.")
        if q.expense_id:
            raise RepositoryError("This quote has already been converted to an expense.")
        if q.status != "Selected":
            raise RepositoryError("Select this quote first, then convert it to an expense.")
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO expenses (event_id, category, description, amount, paid, vendor) VALUES (?,?,?,?,0,?)",
                (q.event_id, q.category, q.requirement, q.amount, q.vendor_name))
            self.conn.execute("UPDATE quotes SET expense_id=? WHERE id=?", (cur.lastrowid, quote_id))
        return cur.lastrowid
