@echo off
REM Builds the Windows program:  dist\Zari\Zari.exe   (run setup_zari.bat once before this)
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo Run setup_zari.bat first.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" -m pip install --quiet pyinstaller
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
".venv\Scripts\python.exe" tools\make_icon.py
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --windowed --name Zari --icon assets\zari.ico ^
    --add-data "assets;assets" --exclude-module tkinter --exclude-module pytest --exclude-module _pytest run_zari.py
if errorlevel 1 (
    echo Build failed.
    pause
    exit /b 1
)
echo.
echo Built: dist\Zari\Zari.exe   (keep the whole Zari folder together; make a desktop shortcut to Zari.exe)
pause
