"""Guest list and RSVP tracking (mixed into Repository)."""
from __future__ import annotations

from zari.db.models import Guest


def _guest(r) -> Guest:
    return Guest(r["id"], r["event_id"], r["name"], r["phone"], r["email"], r["party_size"], r["grp"],
                 bool(r["invited"]), r["rsvp"], r["notes"])


class GuestMixin:
    def list_guests(self, event_id: int) -> list[Guest]:
        rows = self.conn.execute("SELECT * FROM guests WHERE event_id=? ORDER BY name COLLATE NOCASE, id",
                                 (event_id,)).fetchall()
        return [_guest(r) for r in rows]

    def add_guest(self, event_id: int, data: dict) -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO guests (event_id, name, phone, email, party_size, grp, invited, rsvp, notes)"
                " VALUES (?,?,?,?,?,?,?,?,?)",
                (event_id, data["name"], data["phone"], data["email"], data["party_size"], data["group"],
                 int(data["invited"]), data["rsvp"], data["notes"]))
        return cur.lastrowid

    def update_guest(self, guest_id: int, data: dict) -> None:
        with self.conn:
            self.conn.execute(
                "UPDATE guests SET name=?, phone=?, email=?, party_size=?, grp=?, invited=?, rsvp=?, notes=?"
                " WHERE id=?",
                (data["name"], data["phone"], data["email"], data["party_size"], data["group"],
                 int(data["invited"]), data["rsvp"], data["notes"], guest_id))

    def set_guest_rsvp(self, guest_id: int, rsvp: str) -> None:
        with self.conn:
            # Replying implies they were invited.
            self.conn.execute("UPDATE guests SET rsvp=?, invited=CASE WHEN ?<>'Pending' THEN 1 ELSE invited END"
                              " WHERE id=?", (rsvp, rsvp, guest_id))

    def delete_guest(self, guest_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM guests WHERE id=?", (guest_id,))

    def has_guest(self, event_id: int, name: str, phone: str, email: str) -> bool:
        return bool(self.conn.execute(
            "SELECT 1 FROM guests WHERE event_id=? AND lower(name)=lower(?) AND phone=? AND lower(email)=lower(?)",
            (event_id, name, phone, email)).fetchone())

    def import_guests(self, event_id: int, rows: list[dict]) -> tuple[int, int]:
        """Add many guests in ONE transaction (all or nothing). Returns (added, skipped_duplicates)."""
        added = skipped = 0
        with self.conn:
            for d in rows:
                if self.has_guest(event_id, d["name"], d["phone"], d["email"]):
                    skipped += 1
                    continue
                self.conn.execute(
                    "INSERT INTO guests (event_id, name, phone, email, party_size, grp, invited, rsvp, notes)"
                    " VALUES (?,?,?,?,?,?,?,?,?)",
                    (event_id, d["name"], d["phone"], d["email"], d["party_size"], d["group"],
                     int(d["invited"]), d["rsvp"], d["notes"]))
                added += 1
        return added, skipped

    def guest_stats(self, event_id: int) -> dict:
        """Parties and heads by RSVP state. Heads = sum of party sizes."""
        stats = {"parties": 0, "invited": 0, "confirmed": 0, "declined": 0, "pending": 0,
                 "heads_confirmed": 0, "heads_pending": 0, "heads_total": 0}
        for g in self.list_guests(event_id):
            stats["parties"] += 1
            stats["invited"] += int(g.invited)
            stats["heads_total"] += g.party_size
            key = g.rsvp.lower()
            stats[key] += 1
            if g.rsvp == "Confirmed":
                stats["heads_confirmed"] += g.party_size
            elif g.rsvp == "Pending":
                stats["heads_pending"] += g.party_size
        return stats
