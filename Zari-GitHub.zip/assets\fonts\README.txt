﻿Put Cormorant Garamond and Inter .ttf/.otf font files in this folder to use them in Zari.
