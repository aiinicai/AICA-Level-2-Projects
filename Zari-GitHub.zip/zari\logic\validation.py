"""Input validation. Every function returns a cleaned dict or raises ValidationError."""
from __future__ import annotations

import re
from datetime import date, datetime

from zari.config import EVENT_STATUSES, EVENT_TYPES, EXPENSE_CATEGORIES, PRIORITIES
from zari.logic.money import parse_amount, parse_percent


class ValidationError(Exception):
    """Holds one message per problem field: {'name': 'Please enter ...'}."""

    def __init__(self, errors: dict[str, str]):
        self.errors = errors
        super().__init__("; ".join(errors.values()))


def _as_date(value, field: str, errors: dict, label: str) -> str | None:
    if isinstance(value, datetime):
        value = value.date()
    if isinstance(value, date):
        return value.isoformat()
    try:
        return datetime.strptime(str(value).strip(), "%Y-%m-%d").date().isoformat()
    except (ValueError, TypeError):
        errors[field] = f"{label} is not a valid date."
        return None


def _required_text(value, field: str, errors: dict, label: str, max_len: int = 120) -> str:
    text = " ".join(str(value or "").split())
    if not text:
        errors[field] = f"{label} is required."
    elif len(text) > max_len:
        errors[field] = f"{label} is too long (max {max_len} characters)."
    return text


def _amount(value, field: str, errors: dict, label: str, allow_zero: bool) -> int:
    try:
        fils = parse_amount(value) if isinstance(value, str) else int(value)
    except ValueError as exc:
        errors[field] = str(exc)
        return 0
    if fils == 0 and not allow_zero:
        errors[field] = f"{label} must be greater than zero."
    return fils


def validate_event(name, client, type_, date_, venue, guests, status, contract) -> dict:
    errors: dict[str, str] = {}
    data = {
        "name": _required_text(name, "name", errors, "Event name"),
        "client": _required_text(client, "client", errors, "Client name"),
        "venue": _required_text(venue, "venue", errors, "Venue"),
        "date": _as_date(date_, "date", errors, "Event date"),
        "contract_value": _amount(contract, "contract", errors, "Contract value", allow_zero=True),
    }
    if type_ not in EVENT_TYPES:
        errors["type"] = "Choose an event type."
    if status not in EVENT_STATUSES:
        errors["status"] = "Choose a status."
    try:
        g = int(guests)
        if g < 1 or g > 50_000:
            raise ValueError
    except (ValueError, TypeError):
        errors["guests"] = "Guest count must be a whole number between 1 and 50,000."
        g = 0
    data.update(type=type_, status=status, guests=g)
    if errors:
        raise ValidationError(errors)
    return data


def validate_payment(amount, date_, label) -> dict:
    errors: dict[str, str] = {}
    data = {
        "amount": _amount(amount, "amount", errors, "Amount", allow_zero=False),
        "date": _as_date(date_, "date", errors, "Payment date"),
        "label": _required_text(label, "label", errors, "Label", 60),
    }
    if errors:
        raise ValidationError(errors)
    return data


def validate_expense(category, description, amount, vendor="", invoice_no="", date_=None, due=None) -> dict:
    errors: dict[str, str] = {}
    if category not in EXPENSE_CATEGORIES:
        errors["category"] = "Choose a category."
    data = {
        "category": category,
        "description": _required_text(description, "description", errors, "Description", 160),
        "amount": _amount(amount, "amount", errors, "Amount", allow_zero=False),
        "vendor": " ".join(str(vendor or "").split())[:120],
        "invoice_no": " ".join(str(invoice_no or "").split())[:60],
        "date": _as_date(date_, "date", errors, "Expense date") if date_ else None,
        "due_date": _as_date(due, "due", errors, "Payment due date") if due else None,
    }
    if errors:
        raise ValidationError(errors)
    return data


_EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]{2,}$")
_PHONE = re.compile(r"^[+\d][\d\s().-]{4,24}$")
QUOTE_STATUSES = ["Requested", "Received", "Selected", "Rejected"]
DOC_KINDS = ["Invoice", "Receipt", "Contract", "Quote", "Other"]
RSVP_STATES = ["Pending", "Confirmed", "Declined"]


def _contact(phone, email, errors: dict) -> tuple[str, str]:
    phone = " ".join(str(phone or "").split())
    email = str(email or "").strip()
    if phone and not _PHONE.match(phone):
        errors["phone"] = "Phone may contain digits, spaces, + - ( ) only."
    if email and not _EMAIL.match(email):
        errors["email"] = "That email address does not look right."
    return phone, email


def validate_vendor(name, category, contact_name="", phone="", email="", notes="") -> dict:
    errors: dict[str, str] = {}
    data = {"name": _required_text(name, "name", errors, "Vendor name", 80),
            "contact_name": " ".join(str(contact_name or "").split())[:80],
            "notes": str(notes or "").strip()[:500]}
    if category not in EXPENSE_CATEGORIES:
        errors["category"] = "Choose a category."
    data["category"] = category
    data["phone"], data["email"] = _contact(phone, email, errors)
    if errors:
        raise ValidationError(errors)
    return data


def validate_quote(requirement, category, vendor_id, amount, deposit, valid_until, rating, status, notes="") -> dict:
    errors: dict[str, str] = {}
    data = {"requirement": _required_text(requirement, "requirement", errors, "Requirement", 120),
            "amount": _amount(amount, "amount", errors, "Quoted price", allow_zero=False),
            "deposit": _amount(deposit, "deposit", errors, "Deposit", allow_zero=True) if str(deposit).strip() else 0,
            "valid_until": _as_date(valid_until, "valid_until", errors, "Valid-until date") if valid_until else None,
            "notes": str(notes or "").strip()[:500]}
    if category not in EXPENSE_CATEGORIES:
        errors["category"] = "Choose a category."
    if not vendor_id:
        errors["vendor"] = "Choose a vendor (or add a new one)."
    if status not in QUOTE_STATUSES:
        errors["status"] = "Choose a status."
    if "amount" not in errors and "deposit" not in errors and data["deposit"] > data["amount"]:
        errors["deposit"] = "Deposit cannot be more than the quoted price."
    rating = int(rating) if rating not in (None, "", 0) else None
    if rating is not None and not 1 <= rating <= 5:
        errors["rating"] = "Rating must be 1 to 5."
    data.update(category=category, vendor_id=vendor_id, status=status, rating=rating)
    if errors:
        raise ValidationError(errors)
    return data


def validate_guest(name, phone, email, party_size, group, invited, rsvp, notes="") -> dict:
    errors: dict[str, str] = {}
    data = {"name": _required_text(name, "name", errors, "Guest name", 100),
            "group": " ".join(str(group or "").split())[:60],
            "invited": bool(invited), "notes": str(notes or "").strip()[:300]}
    data["phone"], data["email"] = _contact(phone, email, errors)
    try:
        size = int(party_size)
        if not 1 <= size <= 50:
            raise ValueError
    except (TypeError, ValueError):
        errors["party_size"] = "Party size must be a whole number from 1 to 50."
        size = 1
    if rsvp not in RSVP_STATES:
        errors["rsvp"] = "Choose an RSVP status."
    data.update(party_size=size, rsvp=rsvp)
    if errors:
        raise ValidationError(errors)
    return data


def validate_document(kind, title) -> dict:
    errors: dict[str, str] = {}
    if kind not in DOC_KINDS:
        errors["kind"] = "Choose a document type."
    data = {"kind": kind, "title": _required_text(title, "title", errors, "Title", 120)}
    if errors:
        raise ValidationError(errors)
    return data


def validate_budget_amount(text) -> int:
    errors: dict[str, str] = {}
    fils = _amount(text or "0", "amount", errors, "Budget", allow_zero=True)
    if errors:
        raise ValidationError(errors)
    return fils


def validate_scenario(name, guests, contract_pct, contingency_pct, adjust_pct: dict, per_guest) -> dict:
    errors: dict[str, str] = {}
    data = {"name": _required_text(name, "name", errors, "Scenario name", 60)}
    try:
        g = int(guests)
        if not 1 <= g <= 50_000:
            raise ValueError
    except (TypeError, ValueError):
        errors["guests"] = "Guest count must be a whole number between 1 and 50,000."
        g = 1
    try:
        data["contract_bp"] = parse_percent(contract_pct, -90, 500)
    except ValueError as exc:
        errors["contract_pct"] = str(exc)
    try:
        data["contingency_bp"] = parse_percent(contingency_pct, 0, 100)
    except ValueError as exc:
        errors["contingency_pct"] = str(exc)
    adjust: dict[str, int] = {}
    for cat, text in adjust_pct.items():
        try:
            bp = parse_percent(text, -90, 300)
        except ValueError as exc:
            errors[f"adjust_{cat}"] = f"{cat}: {exc}"
            continue
        if bp:
            adjust[cat] = bp
    data.update(guests=g, adjust_bp=adjust, per_guest=tuple(sorted(c for c in per_guest if c in EXPENSE_CATEGORIES)))
    if errors:
        raise ValidationError(errors)
    return data


def validate_task(title, due, priority, event_id) -> dict:
    errors: dict[str, str] = {}
    data = {
        "title": _required_text(title, "title", errors, "Task title", 140),
        "due": _as_date(due, "due", errors, "Due date"),
        "event_id": event_id or None,
    }
    if priority not in PRIORITIES:
        errors["priority"] = "Choose a priority."
    data["priority"] = priority
    if errors:
        raise ValidationError(errors)
    return data
