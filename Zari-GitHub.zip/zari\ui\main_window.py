"""Main window: sidebar navigation, page stack, slide-in event panel and toast messages."""
from __future__ import annotations

from PySide6.QtCore import QEasingCurve, QPoint, QPropertyAnimation, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QKeySequence, QPainter, QShortcut
from PySide6.QtWidgets import (
    QButtonGroup, QFrame, QHBoxLayout, QLabel, QMainWindow, QStackedWidget, QVBoxLayout, QWidget,
)

from zari.config import APP_NAME, TAGLINE
from zari.ui import icons, theme
from zari.ui.calendar_page import CalendarPage
from zari.ui.context import AppContext
from zari.ui.dashboard_page import DashboardPage
from zari.ui.event_panel import PANEL_WIDTH, EventPanel
from zari.ui.events_page import EventsPage
from zari.ui.invoice_dialog import scan_invoice
from zari.ui.reports_page import ReportsPage
from zari.ui.vendors_page import VendorsPage
from zari.ui.widgets import Ornament, PatternBackground, make_button, make_label


class Scrim(QWidget):
    """Dims the page behind the open side panel; clicking it closes the panel."""

    def __init__(self, parent, on_click):
        super().__init__(parent)
        self._on_click = on_click

    def paintEvent(self, _):
        QPainter(self).fillRect(self.rect(), QColor(20, 4, 12, 140))

    def mousePressEvent(self, _):
        self._on_click()


class MainWindow(QMainWindow):
    sign_out_requested = Signal()
    closed_by_user = Signal()   # the window's X button was used (not Sign out)

    def __init__(self, ctx: AppContext, account=None, store=None):
        super().__init__()
        self.signing_out = False
        self.ctx = ctx
        self.account, self.store = account, store
        self.setWindowTitle(f"{APP_NAME}  -  {TAGLINE}")
        self.setWindowIcon(icons.icon("mandala", theme.GOLD))
        self.setMinimumSize(1180, 740)
        self.resize(1380, 880)

        central = PatternBackground()
        self.setCentralWidget(central)
        self.central = central
        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ---- sidebar
        side = QFrame()
        side.setObjectName("Sidebar")
        side.setFixedWidth(236)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(18, 26, 18, 20)
        sl.setSpacing(6)
        logo = QLabel()
        logo.setPixmap(icons.pixmap("mandala", 52))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sl.addWidget(logo)
        sl.addWidget(make_label(APP_NAME, "h1", color=theme.GOLD_SOFT, align=Qt.AlignmentFlag.AlignCenter))
        sl.addWidget(make_label("Event & Finance", "eyebrow", align=Qt.AlignmentFlag.AlignCenter))
        sl.addSpacing(6)
        sl.addWidget(Ornament())
        sl.addSpacing(14)

        self.stack = QStackedWidget()
        self.pages = {
            "dashboard": DashboardPage(ctx), "events": EventsPage(ctx), "vendors": VendorsPage(ctx),
            "reports": ReportsPage(ctx), "calendar": CalendarPage(ctx),
        }
        group = QButtonGroup(self)
        self.nav = {}
        for i, (key, text, icon_name) in enumerate((("dashboard", "Dashboard", "dashboard"),
                                                    ("events", "Events", "events"),
                                                    ("vendors", "Vendors", "vendors"),
                                                    ("reports", "Reports", "reports"),
                                                    ("calendar", "Calendar", "calendar"))):
            b = make_button(text, "nav", icon_name)
            b.setCheckable(True)
            b.setIconSize(b.iconSize() * 1.15)
            b.clicked.connect(lambda _=False, k=key: self.show_page(k))
            group.addButton(b)
            self.nav[key] = b
            sl.addWidget(b)
            self.stack.addWidget(self.pages[key])
        sl.addStretch(1)
        scan = make_button("Scan invoice", "primary", "scan", tooltip="Take a photo of an invoice and add it as an expense")
        scan.setMinimumHeight(42)
        scan.clicked.connect(lambda: scan_invoice(self, ctx))
        sl.addWidget(scan)
        sl.addSpacing(8)
        if account is not None:
            sl.addWidget(make_label(account.display_name, "body", align=Qt.AlignmentFlag.AlignCenter))
            row = QHBoxLayout()
            row.setSpacing(6)
            acct = make_button("Account")
            acct.clicked.connect(self._open_account)
            out = make_button("Sign out")
            out.clicked.connect(self.sign_out_requested.emit)
            row.addWidget(acct)
            row.addWidget(out)
            sl.addLayout(row)
        sl.addWidget(make_label("Private to your account, on this PC", "small", align=Qt.AlignmentFlag.AlignCenter))
        root.addWidget(side)
        root.addWidget(self.stack, 1)

        # ---- side panel + scrim (children of the central widget, floating above the pages)
        self.scrim = Scrim(central, self.close_panel)
        self.scrim.hide()
        self.panel = EventPanel(ctx, central)
        self.panel.hide()
        self.panel.closed.connect(self.close_panel)
        self.panel.expanded_changed.connect(self._on_expanded)
        self.anim = QPropertyAnimation(self.panel, b"pos", self)
        self.anim.setDuration(260)
        self.anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self.anim.finished.connect(self._after_anim)
        self._panel_open = False

        # ---- toast
        self.toast = QLabel(central)
        self.toast.setStyleSheet(
            f"background: {theme.BURGUNDY_DEEP}; color: {theme.IVORY}; border: 1px solid {theme.GOLD};"
            "border-radius: 18px; padding: 9px 20px; font-size: 13px;")
        self.toast.hide()
        self._toast_timer = QTimer(self)
        self._toast_timer.setSingleShot(True)
        self._toast_timer.timeout.connect(self.toast.hide)

        # ---- wiring
        ctx.changed.connect(self.refresh_all)
        ctx.toast.connect(self.show_toast)
        ctx.event_requested.connect(self.open_panel)
        self.pages["dashboard"].view_all_events.connect(lambda: self.show_page("events"))
        QShortcut(QKeySequence(Qt.Key.Key_Escape), self, activated=self._escape)

        self.show_page("dashboard")
        self.refresh_all()

    def closeEvent(self, e):
        if not self.signing_out:
            self.closed_by_user.emit()
        super().closeEvent(e)

    def _open_account(self) -> None:
        from zari.ui.login import AccountDialog
        AccountDialog(self, self.store, self.account).exec()

    # ---- navigation -----------------------------------------------------------------
    def show_page(self, key: str) -> None:
        self.nav[key].setChecked(True)
        self.stack.setCurrentWidget(self.pages[key])
        self.pages[key].refresh()

    def refresh_all(self) -> None:
        for page in self.pages.values():
            page.refresh()
        self.panel.refresh()

    # ---- side panel -----------------------------------------------------------------
    def _panel_geometry(self, open_: bool) -> tuple[QPoint, int]:
        w, h = self.central.width(), self.central.height()
        return QPoint(w - self.panel.current_width() if open_ else w, 0), h

    def open_panel(self, event_id: int) -> None:
        self.panel.show_event(event_id)
        if self._panel_open:
            return
        self._panel_open = True
        pos, h = self._panel_geometry(True)
        start, _ = self._panel_geometry(False)
        self.scrim.setGeometry(0, 0, self.central.width(), h)
        self.scrim.setVisible(not self.panel.expanded)
        self.scrim.raise_()
        self.panel.setFixedWidth(self.panel.current_width())
        self.panel.setFixedHeight(h)
        self.panel.move(start)
        self.panel.show()
        self.panel.raise_()
        self.toast.raise_()
        self.anim.stop()
        self.anim.setStartValue(start)
        self.anim.setEndValue(pos)
        self.anim.start()

    def close_panel(self) -> None:
        if not self._panel_open:
            return
        self._panel_open = False
        self.panel.event_id = None
        end, _ = self._panel_geometry(False)
        self.anim.stop()
        self.anim.setStartValue(self.panel.pos())
        self.anim.setEndValue(end)
        self.anim.start()
        self.scrim.hide()

    def _on_expanded(self, on: bool) -> None:
        """Full screen: the panel covers the whole window; back: a 600 px panel with the page dimmed behind."""
        w, h = self.central.width(), self.central.height()
        self.panel.setFixedWidth(self.panel.current_width())
        self.panel.move(w - self.panel.current_width(), 0)
        self.scrim.setVisible(self._panel_open and not on)
        self.scrim.setGeometry(0, 0, w, h)
        if self._panel_open:
            self.panel.raise_()
            self.toast.raise_()

    def _escape(self) -> None:
        if self.panel.expanded and self._panel_open:
            self.panel.set_expanded(False)   # first Esc leaves full screen, the second closes the panel
        else:
            self.close_panel()

    def _after_anim(self) -> None:
        if not self._panel_open:
            self.panel.hide()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        w, h = self.central.width(), self.central.height()
        self.scrim.setGeometry(0, 0, w, h)
        self.panel.setFixedHeight(h)
        self.panel.setFixedWidth(self.panel.current_width())
        if self._panel_open:
            self.panel.move(w - self.panel.current_width(), 0)
        self._place_toast()

    # ---- toast ----------------------------------------------------------------------
    def show_toast(self, message: str) -> None:
        self.toast.setText(message if len(message) < 110 else message[:107] + "...")
        self.toast.adjustSize()
        self._place_toast()
        self.toast.show()
        self.toast.raise_()
        self._toast_timer.start(3200)

    def _place_toast(self) -> None:
        self.toast.move((self.central.width() - self.toast.width()) // 2, self.central.height() - 70)
