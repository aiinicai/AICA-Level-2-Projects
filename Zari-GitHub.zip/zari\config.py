"""Application-wide constants and file locations."""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "Zari"
TAGLINE = "Event & Finance Studio"

if getattr(sys, "frozen", False):   # running as the packaged Zari.exe
    PROJECT_ROOT = Path(getattr(sys, "_MEIPASS", Path(sys.executable).parent))
else:
    PROJECT_ROOT = Path(__file__).resolve().parent.parent
ASSETS_DIR = PROJECT_ROOT / "assets"


_current_user: str | None = None


def data_root() -> Path:
    """Top-level Zari folder (accounts live here; each user gets a sub-folder).

    Deliberately NOT inside OneDrive: cloud sync can corrupt an open SQLite file.
    Override with the ZARI_DATA_DIR environment variable (the tests do this).
    """
    override = os.environ.get("ZARI_DATA_DIR")
    base = Path(override) if override else Path(os.environ.get("LOCALAPPDATA", Path.home())) / "Zari"
    base.mkdir(parents=True, exist_ok=True)
    return base


def set_current_user(username: str | None) -> None:
    global _current_user
    _current_user = username


def current_user() -> str | None:
    return _current_user


def user_dir(username: str) -> Path:
    p = data_root() / "users" / username
    p.mkdir(parents=True, exist_ok=True)
    return p


def data_dir() -> Path:
    """The signed-in user's private folder (or the root when nobody is signed in, e.g. in tests)."""
    return user_dir(_current_user) if _current_user else data_root()


def db_path() -> Path:
    return data_dir() / "zari.db"


def invoices_dir() -> Path:
    p = data_dir() / "invoices"
    p.mkdir(parents=True, exist_ok=True)
    return p


def backups_dir() -> Path:
    p = data_dir() / "backups"
    p.mkdir(parents=True, exist_ok=True)
    return p


def log_path() -> Path:
    return data_dir() / "zari.log"


EVENT_TYPES = ["Wedding", "Corporate", "Gala", "Conference", "Private"]
EVENT_STATUSES = ["Enquiry", "Confirmed", "In Progress", "Completed", "Cancelled"]
EXPENSE_CATEGORIES = [
    "Venue", "Catering", "Decor", "Entertainment",
    "Photography", "Staff", "Transport", "Other",
]
PRIORITIES = ["Low", "Medium", "High"]

# Margin thresholds (percent) for the green / amber / red colouring.
MARGIN_GOOD = 20.0
MARGIN_WARN = 10.0

MAX_AMOUNT_FILS = 10_000_000_000 * 100  # AED 10 billion sanity ceiling
