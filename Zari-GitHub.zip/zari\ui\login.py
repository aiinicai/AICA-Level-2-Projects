"""Sign-in / create-account window and the account settings dialog."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFrame, QHBoxLayout, QLabel, QLineEdit, QStackedWidget, QVBoxLayout, QWidget,
)

from zari import auth, config
from zari.auth import Account, AccountStore, AuthError
from zari.ui import icons, theme
from zari.ui.dialogs import FormDialog, info
from zari.ui.widgets import Card, Ornament, make_button, make_label, set_label_color


def _password_field(placeholder: str = "") -> QLineEdit:
    f = QLineEdit()
    f.setEchoMode(QLineEdit.EchoMode.Password)
    f.setPlaceholderText(placeholder)
    return f


def _labelled(text: str, widget: QWidget) -> QWidget:
    box = QWidget()
    box.setObjectName("Transparent")
    lay = QVBoxLayout(box)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(4)
    lay.addWidget(make_label(text, "eyebrow"))
    lay.addWidget(widget)
    return box


class LoginDialog(QDialog):
    def __init__(self, store: AccountStore, parent=None):
        super().__init__(parent)
        self.store = store
        self.account: Account | None = None
        self.setWindowTitle("Zari - Sign in")
        self.setWindowIcon(icons.icon("mandala", theme.GOLD))
        self.setFixedWidth(460)
        root = QVBoxLayout(self)
        root.setContentsMargins(36, 28, 36, 28)
        root.setSpacing(6)

        logo = QLabel()
        logo.setPixmap(icons.pixmap("mandala", 56))
        logo.setAlignment(Qt.AlignmentFlag.AlignCenter)
        root.addWidget(logo)
        root.addWidget(make_label("Zari", "h1", color=theme.GOLD_SOFT, align=Qt.AlignmentFlag.AlignCenter))
        root.addWidget(make_label("Event & Finance Studio", "eyebrow", align=Qt.AlignmentFlag.AlignCenter))
        root.addWidget(Ornament())
        root.addSpacing(8)

        self.pages = QStackedWidget()
        self.pages.addWidget(self._signin_page())
        self.pages.addWidget(self._create_page())
        root.addWidget(self.pages)
        self._show_signin() if store.has_accounts() else self._show_create()

    # ---- pages ----------------------------------------------------------------------
    def _signin_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("Transparent")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(10)
        v.addWidget(make_label("Welcome back. Your events and clients are private to your account.", "muted",
                               wrap=True, align=Qt.AlignmentFlag.AlignCenter))
        self.user_box = QComboBox()
        self.user_box.setEditable(True)
        self.user_box.addItems([a.username for a in self.store.accounts()])
        self.user_box.setCurrentText(auth.last_user())
        self.pw = _password_field()
        self.pw.returnPressed.connect(self._sign_in)
        show = QCheckBox("Show password")
        show.toggled.connect(lambda on: self.pw.setEchoMode(
            QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password))
        self.signin_error = make_label("", "small", color=theme.DANGER, wrap=True)
        self.signin_error.hide()
        go = make_button("Sign in", "primary")
        go.setMinimumHeight(40)
        go.setDefault(True)
        go.clicked.connect(self._sign_in)
        new = make_button("Create a new account", "link")
        new.clicked.connect(self._show_create)
        for w in (_labelled("Username", self.user_box), _labelled("Password", self.pw), show,
                  self.signin_error, go):
            v.addWidget(w)
        v.addWidget(new, 0, Qt.AlignmentFlag.AlignCenter)
        return page

    def _create_page(self) -> QWidget:
        page = QWidget()
        page.setObjectName("Transparent")
        v = QVBoxLayout(page)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(8)
        self.create_intro = make_label("", "muted", wrap=True, align=Qt.AlignmentFlag.AlignCenter)
        v.addWidget(self.create_intro)
        self.c_name = QLineEdit()
        self.c_name.setPlaceholderText("e.g. Arya Sudhakar")
        self.c_user = QLineEdit()
        self.c_user.setPlaceholderText("e.g. arya (letters and numbers)")
        self.c_pw = _password_field("At least 8 characters, letters and numbers")
        self.c_pw2 = _password_field()
        self.c_pw2.returnPressed.connect(self._create)
        self.adopt = QCheckBox("Move my existing Zari data into this account")
        self.adopt.setChecked(True)
        self.create_error = make_label("", "small", color=theme.DANGER, wrap=True)
        self.create_error.hide()
        go = make_button("Create account", "primary")
        go.setMinimumHeight(40)
        go.clicked.connect(self._create)
        self.back = make_button("Back to sign in", "link")
        self.back.clicked.connect(self._show_signin)
        for w in (_labelled("Your name", self.c_name), _labelled("Username", self.c_user),
                  _labelled("Password", self.c_pw), _labelled("Confirm password", self.c_pw2),
                  self.adopt, self.create_error, go):
            v.addWidget(w)
        v.addWidget(self.back, 0, Qt.AlignmentFlag.AlignCenter)
        return page

    def _show_signin(self) -> None:
        self.pages.setCurrentIndex(0)
        self.pw.clear()
        self.pw.setFocus() if self.user_box.currentText() else self.user_box.setFocus()

    def _show_create(self) -> None:
        first = not self.store.has_accounts()
        self.create_intro.setText(
            "Welcome to Zari. Create the first account - it becomes the owner account, which can add other "
            "users and reset their passwords (but cannot read their data)." if first else
            "Create a separate account. Its events, payments and invoices stay private from other accounts.")
        self.back.setVisible(not first)
        self.adopt.setVisible(first and auth.legacy_data_exists())
        self.pages.setCurrentIndex(1)
        self.c_name.setFocus()
        self.adjustSize()

    # ---- actions --------------------------------------------------------------------
    def _sign_in(self) -> None:
        try:
            self.account = self.store.verify(self.user_box.currentText(), self.pw.text())
        except AuthError as exc:
            self.signin_error.setText(str(exc))
            self.signin_error.show()
            self.pw.clear()
            self.pw.setFocus()
            return
        auth.remember_user(self.account.username)
        self.accept()

    def _create(self) -> None:
        if self.c_pw.text() != self.c_pw2.text():
            self.create_error.setText("The two passwords do not match.")
            self.create_error.show()
            return
        try:
            account = self.store.create(self.c_user.text(), self.c_name.text(), self.c_pw.text())
        except AuthError as exc:
            self.create_error.setText(str(exc))
            self.create_error.show()
            return
        if self.adopt.isVisible() and self.adopt.isChecked():
            auth.adopt_legacy_data(account.username)
        self.account = account
        auth.remember_user(account.username)
        self.accept()


# ---------------------------------------------------------------------------- account settings
class _PasswordForm(FormDialog):
    """Generic 'enter a new password' dialog used for reset and add-user."""

    def __init__(self, parent, title: str, eyebrow: str, fields: list[tuple[str, str, bool]]):
        super().__init__(parent, title, eyebrow)
        self.inputs: dict[str, QLineEdit] = {}
        for key, label, secret in fields:
            w = _password_field() if secret else QLineEdit()
            self.inputs[key] = w
            self.add_field(key, label, w)

    def collect(self) -> dict:
        return {k: w.text() for k, w in self.inputs.items()}


class AccountDialog(QDialog):
    def __init__(self, parent, store: AccountStore, account: Account):
        super().__init__(parent)
        self.store, self.account = store, account
        self.setWindowTitle("Your account")
        self.setMinimumWidth(520)
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 24, 28, 22)
        v.setSpacing(8)
        v.addWidget(make_label("Account", "eyebrow"))
        v.addWidget(make_label(account.display_name, "h2"))
        v.addWidget(make_label(f"Signed in as {account.username}" + ("  (owner)" if account.is_owner else "") +
                               f"\nYour data folder: {config.data_dir()}", "small"))
        v.addSpacing(6)
        change = make_button("Change my password")
        change.clicked.connect(self._change_password)
        v.addWidget(change, 0, Qt.AlignmentFlag.AlignLeft)

        if account.is_owner:
            v.addSpacing(8)
            head = QHBoxLayout()
            head.addWidget(make_label("Users on this PC", "h3"))
            head.addStretch(1)
            add = make_button("Add user", "primary", "plus")
            add.clicked.connect(self._add_user)
            head.addWidget(add)
            v.addLayout(head)
            self.users_box = QVBoxLayout()
            self.users_box.setSpacing(6)
            v.addLayout(self.users_box)
            self._fill_users()
        close = make_button("Close")
        close.clicked.connect(self.accept)
        v.addSpacing(8)
        v.addWidget(close, 0, Qt.AlignmentFlag.AlignRight)

    def _fill_users(self) -> None:
        from zari.ui.widgets import clear_layout
        clear_layout(self.users_box)
        for a in self.store.accounts():
            row = QFrame()
            row.setObjectName("CardInner")
            h = QHBoxLayout(row)
            h.setContentsMargins(12, 8, 8, 8)
            h.addWidget(make_label(f"{a.display_name}  ({a.username})" + ("  - owner" if a.is_owner else ""), "body"), 1)
            if not a.is_owner:
                b = make_button("Reset password")
                b.clicked.connect(lambda _=False, u=a.username: self._reset(u))
                h.addWidget(b)
            self.users_box.addWidget(row)

    def _change_password(self) -> None:
        dlg = _PasswordForm(self, "Change password", "Account",
                            [("old", "Current password", True), ("new", "New password", True),
                             ("again", "Repeat new password", True)])
        while dlg.exec():
            d = dlg.result_data
            if d["new"] != d["again"]:
                dlg.show_errors({"again": "The two passwords do not match."})
                continue
            try:
                self.store.change_password(self.account.username, d["old"], d["new"])
            except AuthError as exc:
                dlg.show_errors({"old" if "Wrong" in str(exc) else "new": str(exc)})
                continue
            info(self, "Password changed", "Use your new password next time you sign in.")
            return

    def _reset(self, username: str) -> None:
        dlg = _PasswordForm(self, f"Reset password for {username}", "Owner action",
                            [("new", "New password", True)])
        while dlg.exec():
            try:
                self.store.reset_password(self.account, username, dlg.result_data["new"])
            except AuthError as exc:
                dlg.show_errors({"new": str(exc)})
                continue
            info(self, "Password reset", f"Tell {username} their new password. They can change it from Account.")
            return

    def _add_user(self) -> None:
        dlg = _PasswordForm(self, "Add a user", "Owner action",
                            [("name", "Their name", False), ("user", "Username", False),
                             ("pw", "Temporary password", True)])
        while dlg.exec():
            d = dlg.result_data
            try:
                self.store.create(d["user"], d["name"], d["pw"])
            except AuthError as exc:
                dlg.show_errors({"user" if "sername" in str(exc) or "taken" in str(exc) else "pw": str(exc)})
                continue
            self._fill_users()
            return
