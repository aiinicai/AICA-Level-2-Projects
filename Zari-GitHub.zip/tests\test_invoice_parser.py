from datetime import date

import pytest

from zari.ocr.invoice_parser import find_dates, guess_category, parse_invoice_text
from zari.ocr import invoice_reader

CATERING_INVOICE = """
Saffron Royale Catering LLC
Tel: +971 4 555 1234
TAX INVOICE
TRN 100234567890003
Invoice No: SR-2026-0457
Invoice Date: 12/10/2026
Due Date: 26/10/2026
Buffet - 450 covers      90,000.00
Live stations             6,000.00
Subtotal                 96,000.00
VAT 5%                    4,800.00
Grand Total AED         100,800.00
"""

FLOWERS_INVOICE = """
Marigold Studio Floral Decor
Receipt #A-118
Date: 3 November 2026
Mandap flowers and drapes   12,500
Total   12,500
"""


def test_catering_invoice_full_parse():
    r = parse_invoice_text(CATERING_INVOICE)
    assert r.vendor == "Saffron Royale Catering LLC"
    assert r.total_aed == "100800"
    assert r.vat_aed == "4800"
    assert r.invoice_date == date(2026, 10, 12)  # invoice date, not the due date
    assert r.invoice_no == "SR-2026-0457"
    assert r.category == "Catering"
    assert not any(r.uncertain.values())


def test_simple_receipt():
    r = parse_invoice_text(FLOWERS_INVOICE)
    assert r.vendor == "Marigold Studio Floral Decor"
    assert r.total_aed == "12500"
    assert r.invoice_date == date(2026, 11, 3)
    assert r.category == "Decor"


def test_decimal_amount_formatting():
    r = parse_invoice_text("Acme Rentals\nTotal Amount AED 1,250.50")
    assert r.total_aed == "1250.5"


def test_missing_total_falls_back_and_is_flagged():
    r = parse_invoice_text("Some Vendor Ltd\nItem one 300\nItem two 450")
    assert r.total_aed == "450" and r.uncertain["total"] is True


def test_garbage_and_empty_text_do_not_crash():
    for text in ("", "   \n  ", "@@@ ### !!!\n$$$ %%%", "12345678901234567890"):
        r = parse_invoice_text(text)
        assert r.total_aed == "" and r.invoice_date is None
        assert r.uncertain["total"] is True


@pytest.mark.parametrize("text,expected", [
    ("12/10/2026", date(2026, 10, 12)),         # day-first
    ("2026-10-12", date(2026, 10, 12)),
    ("12.10.26", date(2026, 10, 12)),
    ("12 Oct 2026", date(2026, 10, 12)),
    ("October 12, 2026", date(2026, 10, 12)),
])
def test_date_formats(text, expected):
    assert find_dates(text)[0] == expected


@pytest.mark.parametrize("text", ["Invoice Date: 12/1 0/2026", "Date 12 / 10 / 2026"])
def test_dates_with_ocr_stray_spaces(text):
    assert find_dates(text) == [date(2026, 10, 12)]


def test_real_tesseract_on_a_generated_invoice(tmp_path):
    """Runs only on a PC that has Tesseract installed (skipped otherwise)."""
    if not invoice_reader.find_tesseract():
        pytest.skip("Tesseract is not installed")
    from PIL import Image, ImageDraw, ImageFont
    try:
        font = ImageFont.truetype(r"C:\Windows\Fonts\arial.ttf", 30)
    except OSError:
        pytest.skip("Arial font not available")
    img = Image.new("RGB", (1000, 480), "white")
    d = ImageDraw.Draw(img)
    for i, line in enumerate(["Lumen Photo Studio", "TAX INVOICE", "Invoice No: LS-77", "Invoice Date: 05/10/2026",
                              "Photo and film package     14,000.00", "Grand Total AED         14,700.00"]):
        d.text((40, 30 + i * 60), line, fill="black", font=font)
    path = tmp_path / "inv.png"
    img.save(path)
    r = invoice_reader.read_invoice(path)
    assert r.vendor == "Lumen Photo Studio" and r.invoice_no == "LS-77"
    assert r.invoice_date == date(2026, 10, 5) and r.total_aed == "14700" and r.category == "Photography"


def test_impossible_dates_ignored():
    assert find_dates("31/02/2026") == [] and find_dates("45/13/2026") == []


def test_category_guess():
    assert guess_category("DJ and sound system hire") == "Entertainment"
    assert guess_category("Lumen Photo Studio") == "Photography"
    assert guess_category("Office stationery") == "Other"


def test_reader_rejects_wrong_file_type(tmp_path):
    f = tmp_path / "invoice.docx"
    f.write_text("x")
    with pytest.raises(invoice_reader.OcrFailed):
        invoice_reader.read_invoice(f)


def test_reader_reports_missing_tesseract(tmp_path, monkeypatch):
    monkeypatch.setattr(invoice_reader, "find_tesseract", lambda: None)
    img = tmp_path / "x.png"
    img.write_bytes(b"not really an image")
    with pytest.raises(invoice_reader.OcrUnavailable, match="winget install"):
        invoice_reader.read_invoice(img)
