"""Local accounts: salted password hashing, sign-in throttling, per-user data folders.

Security model (be aware of the limits):
  * Passwords are never stored - only a salted scrypt hash.
  * Every user's data lives in its own folder, and the app only ever opens the signed-in user's folder.
  * The data files themselves are NOT encrypted. Someone with access to your Windows account (or an
    admin) could read them with other tools. Use Windows sign-in and BitLocker for that.
  * A forgotten password cannot be recovered; the owner account can set a new one for other users.
"""
from __future__ import annotations

import hashlib
import hmac
import re
import secrets
import shutil
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from zari import config

USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9_.-]{2,29}$")
MIN_PASSWORD = 8
MAX_FAILS = 5
LOCK_SECONDS = 30
_SCRYPT = dict(n=2**14, r=8, p=1, maxmem=64 * 1024 * 1024, dklen=32)


class AuthError(Exception):
    """A message that is safe to show to the user."""


@dataclass(frozen=True)
class Account:
    id: int
    username: str
    display_name: str
    is_owner: bool


def _hash(password: str, salt: bytes) -> bytes:
    return hashlib.scrypt(password.encode("utf-8"), salt=salt, **_SCRYPT)


def check_password_rules(username: str, password: str) -> None:
    if len(password) < MIN_PASSWORD:
        raise AuthError(f"Password must be at least {MIN_PASSWORD} characters.")
    if password.lower() == username.lower():
        raise AuthError("Password must not be the same as the username.")
    if password.isdigit() or password.isalpha():
        raise AuthError("Use a mix of letters and numbers (or symbols) in the password.")


class AccountStore:
    def __init__(self, root: Path | None = None, clock=time.monotonic):
        self.root = Path(root) if root else config.data_root()
        self.root.mkdir(parents=True, exist_ok=True)
        self._clock = clock
        self._fails: dict[str, tuple[int, float]] = {}
        self.conn = sqlite3.connect(self.root / "accounts.db")
        self.conn.row_factory = sqlite3.Row
        self.conn.execute(
            "CREATE TABLE IF NOT EXISTS accounts ("
            " id INTEGER PRIMARY KEY,"
            " username TEXT NOT NULL UNIQUE,"
            " display_name TEXT NOT NULL,"
            " salt BLOB NOT NULL,"
            " pw_hash BLOB NOT NULL,"
            " is_owner INTEGER NOT NULL DEFAULT 0,"
            " created_at TEXT NOT NULL DEFAULT (datetime('now')))"
        )
        self.conn.commit()

    @staticmethod
    def _account(row) -> Account:
        return Account(row["id"], row["username"], row["display_name"], bool(row["is_owner"]))

    def accounts(self) -> list[Account]:
        return [self._account(r) for r in self.conn.execute("SELECT * FROM accounts ORDER BY username")]

    def has_accounts(self) -> bool:
        return bool(self.conn.execute("SELECT 1 FROM accounts LIMIT 1").fetchone())

    # ---- create -----------------------------------------------------------------------
    def create(self, username: str, display_name: str, password: str) -> Account:
        username = username.strip().lower()
        display_name = " ".join(display_name.split()) or username
        if not USERNAME_RE.match(username):
            raise AuthError("Username must be 3-30 characters: letters, numbers, dot, dash or underscore.")
        check_password_rules(username, password)
        if self.conn.execute("SELECT 1 FROM accounts WHERE username=?", (username,)).fetchone():
            raise AuthError("That username is already taken.")
        salt = secrets.token_bytes(16)
        is_owner = not self.has_accounts()
        with self.conn:
            self.conn.execute(
                "INSERT INTO accounts (username, display_name, salt, pw_hash, is_owner) VALUES (?,?,?,?,?)",
                (username, display_name[:60], salt, _hash(password, salt), int(is_owner)))
        return self.get(username)

    def get(self, username: str) -> Account | None:
        row = self.conn.execute("SELECT * FROM accounts WHERE username=?", (username.strip().lower(),)).fetchone()
        return self._account(row) if row else None

    # ---- sign in ----------------------------------------------------------------------
    def verify(self, username: str, password: str) -> Account:
        key = username.strip().lower()
        fails, locked_until = self._fails.get(key, (0, 0.0))
        now = self._clock()
        if locked_until > now:
            raise AuthError(f"Too many wrong attempts. Try again in {int(locked_until - now) + 1} seconds.")
        row = self.conn.execute("SELECT * FROM accounts WHERE username=?", (key,)).fetchone()
        # Hash even for unknown users so timing does not reveal which usernames exist.
        salt = row["salt"] if row else b"\0" * 16
        candidate = _hash(password, salt)
        if row is None or not hmac.compare_digest(candidate, row["pw_hash"]):
            fails += 1
            self._fails[key] = (fails, now + LOCK_SECONDS if fails >= MAX_FAILS else 0.0)
            raise AuthError("Wrong username or password.")
        self._fails.pop(key, None)
        return self._account(row)

    # ---- manage -----------------------------------------------------------------------
    def change_password(self, username: str, old: str, new: str) -> None:
        self.verify(username, old)
        self._set_password(username, new)

    def reset_password(self, owner: Account, target_username: str, new: str) -> None:
        current = self.get(owner.username)
        if current is None or not current.is_owner:
            raise AuthError("Only the owner account can reset another user's password.")
        if self.get(target_username) is None:
            raise AuthError("That user does not exist.")
        self._set_password(target_username, new)
        self._fails.pop(target_username.strip().lower(), None)

    def _set_password(self, username: str, new: str) -> None:
        username = username.strip().lower()
        check_password_rules(username, new)
        salt = secrets.token_bytes(16)
        with self.conn:
            self.conn.execute("UPDATE accounts SET salt=?, pw_hash=? WHERE username=?",
                              (salt, _hash(new, salt), username))

    def close(self) -> None:
        self.conn.close()


# ---- bringing pre-account data into the first account ---------------------------------
def legacy_data_exists(root: Path | None = None) -> bool:
    return (Path(root) if root else config.data_root()).joinpath("zari.db").is_file()


def adopt_legacy_data(username: str, root: Path | None = None) -> bool:
    """Move the old single-user database, invoices and backups into `username`'s folder."""
    root = Path(root) if root else config.data_root()
    if not legacy_data_exists(root):
        return False
    dest = root / "users" / username
    dest.mkdir(parents=True, exist_ok=True)
    if (dest / "zari.db").exists():
        return False
    for name in ("zari.db", "invoices", "backups", ".sample_data_offered", "zari.log"):
        src = root / name
        if src.exists():
            shutil.move(str(src), str(dest / name))
    return True


# ---- remember the last user name typed on the login screen ----------------------------
def remember_user(username: str) -> None:
    try:
        (config.data_root() / "last_user.txt").write_text(username, encoding="utf-8")
    except OSError:
        pass


def last_user() -> str:
    try:
        return (config.data_root() / "last_user.txt").read_text(encoding="utf-8").strip()
    except OSError:
        return ""
