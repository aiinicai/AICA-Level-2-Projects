"""Entry point:  python -m zari"""
from __future__ import annotations

import logging
import sys
import traceback

from PySide6.QtCore import QTimer
from PySide6.QtWidgets import QApplication, QMessageBox

from zari import config
from zari.auth import AccountStore
from zari.db.database import Database, DatabaseError
from zari.db.repository import Repository
from zari.ui import theme
from zari.ui.context import AppContext
from zari.ui.login import LoginDialog
from zari.ui.main_window import MainWindow

log = logging.getLogger("zari")


def _install_crash_handler() -> None:
    """Log any unexpected error and tell the user, instead of the app silently vanishing."""
    def hook(exc_type, exc, tb):
        log.error("Unhandled error", exc_info=(exc_type, exc, tb))
        text = "".join(traceback.format_exception_only(exc_type, exc)).strip()
        QMessageBox.critical(None, "Zari hit a problem",
                             f"Something unexpected went wrong:\n\n{text}\n\nDetails were saved to:\n{config.log_path()}")
    sys.excepthook = hook


def _first_run_seed(repo: Repository) -> None:
    """Load clearly-labelled SAMPLE data once per account, on that account's first launch."""
    marker = config.data_dir() / ".sample_data_offered"
    if marker.exists():
        return
    if not repo.has_any_data():
        repo.seed_sample_data()
    marker.write_text("sample data was offered on first launch", encoding="utf-8")


class Session:
    """Owns the sign-in -> main window -> sign-out cycle."""

    def __init__(self, app: QApplication, store: AccountStore):
        self.app, self.store = app, store
        self.window: MainWindow | None = None
        self.db: Database | None = None

    def start(self) -> None:
        config.set_current_user(None)
        dialog = LoginDialog(self.store)
        if not dialog.exec():
            self.app.quit()
            return
        account = dialog.account
        config.set_current_user(account.username)
        logging.getLogger().handlers.clear()
        logging.basicConfig(filename=config.log_path(), level=logging.INFO,
                            format="%(asctime)s %(levelname)s %(message)s")
        try:
            self.db = Database(config.db_path())
        except DatabaseError as exc:
            QMessageBox.critical(None, "Zari cannot open your data", str(exc))
            self.app.quit()
            return
        repo = Repository(self.db)
        _first_run_seed(repo)
        self.window = MainWindow(AppContext(repo), account, self.store)
        self.window.sign_out_requested.connect(self.sign_out)
        self.window.closed_by_user.connect(self.app.quit)
        self.window.showMaximized()   # opens using the whole screen

    def sign_out(self) -> None:
        window, db = self.window, self.db
        self.window = self.db = None
        if window is not None:
            window.signing_out = True
            window.close()
            window.deleteLater()
        if db is not None:
            db.close()
        QTimer.singleShot(0, self.start)  # back to the sign-in screen, with nothing left in memory


def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(config.APP_NAME)
    app.setQuitOnLastWindowClosed(False)
    logging.basicConfig(filename=config.data_root() / "zari.log", level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    fonts = theme.init_fonts()
    log.info("Fonts: %s", fonts)
    app.setStyleSheet(theme.stylesheet())
    _install_crash_handler()

    store = AccountStore()
    session = Session(app, store)
    session.start()
    if session.window is None:  # login cancelled (or the data could not be opened)
        return 0
    code = app.exec()
    if session.db is not None:
        session.db.close()
    store.close()
    return code


if __name__ == "__main__":
    sys.exit(main())
