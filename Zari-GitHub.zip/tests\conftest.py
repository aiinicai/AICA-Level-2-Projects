import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def data_dir(tmp_path, monkeypatch):
    monkeypatch.setenv("ZARI_DATA_DIR", str(tmp_path / "data"))
    return tmp_path / "data"


@pytest.fixture()
def repo(data_dir):
    from zari.db.database import Database
    from zari.db.repository import Repository

    db = Database(data_dir / "zari.db")
    yield Repository(db)
    db.close()
