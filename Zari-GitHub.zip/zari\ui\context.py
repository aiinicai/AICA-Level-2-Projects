"""Shared application state handed to every page: the repository plus change signals."""
from __future__ import annotations

from datetime import date

from PySide6.QtCore import QObject, Signal

from zari.db.repository import Repository


class AppContext(QObject):
    changed = Signal()               # any data changed -> pages refresh themselves
    toast = Signal(str)              # small confirmation message at the bottom of the window
    event_requested = Signal(int)    # open the side panel for this event id

    def __init__(self, repo: Repository):
        super().__init__()
        self.repo = repo

    @property
    def today(self) -> date:
        return date.today()

    def notify(self, message: str) -> None:
        self.toast.emit(message)

    def data_changed(self, message: str | None = None) -> None:
        self.changed.emit()
        if message:
            self.toast.emit(message)
