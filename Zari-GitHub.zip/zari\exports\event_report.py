"""Everything about ONE event, gathered once, so the PDF and the Excel export always contain the same facts."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from zari.logic import budget as budget_logic
from zari.logic import quotes as quote_logic
from zari.logic import reports, scenario


@dataclass
class EventReport:
    event: object
    today: date
    payments: list
    expenses: list
    budgets: dict
    budget: budget_logic.BudgetSummary
    quote_groups: list
    guests: list
    guest_stats: dict
    documents: list
    baseline: scenario.Projection
    scenarios: list          # [(Scenario, Projection)]
    vendor_rows: list

    @property
    def projected_cost(self) -> int:
        return self.budget.total_projected

    @property
    def chart_rows(self) -> list[tuple]:
        """(label, budget, actual, committed) for the budget-vs-actual chart."""
        return [(l.category, l.budget, l.actual, l.committed) for l in self.budget.lines]


def collect(repo, event_id: int, today: date | None = None) -> EventReport:
    today = today or date.today()
    ev = repo.get_event(event_id)
    if ev is None:
        raise ValueError("That event no longer exists.")
    expenses = repo.list_expenses(event_id)
    quotes = repo.list_quotes(event_id)
    budgets = repo.get_budgets(event_id)
    base = scenario.base_costs(expenses, quotes)
    plans = []
    for s in repo.list_scenarios(event_id):
        plan = scenario.Plan(s.name, s.guests, s.contract_bp, s.contingency_bp, s.adjust_bp, s.per_guest)
        plans.append((s, scenario.project(base, ev.contract_value, ev.guests, plan)))
    return EventReport(
        event=ev, today=today, payments=repo.list_payments(event_id), expenses=expenses, budgets=budgets,
        budget=budget_logic.summarize(budgets, expenses, quotes, ev.contingency_bp),
        quote_groups=quote_logic.group_quotes(quotes, today),
        guests=repo.list_guests(event_id), guest_stats=repo.guest_stats(event_id),
        documents=repo.list_documents(event_id),
        baseline=scenario.baseline(base, ev.contract_value, ev.guests, ev.contingency_bp),
        scenarios=plans,
        vendor_rows=reports.vendor_payables([ev], expenses, include_inactive=True),
    )
