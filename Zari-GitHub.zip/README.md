# Zari - Event & Finance Studio

A desktop app (Python + PySide6 + SQLite) for luxury wedding and event planners in the UAE: events,
client payments, vendor costs, budgets, quotes, guests, profit, tasks and dates in one place.
Money is in AED. Everything runs on your PC; nothing is sent online.

## Run it on Windows

### As a normal program (no Python needed)

Open **`dist\Zari\Zari.exe`**. Keep the whole `Zari` folder together; right-click `Zari.exe` > *Send to* >
*Desktop (create shortcut)*. To use it on another PC, copy `Zari-Windows.zip`, unzip it anywhere and run
`Zari.exe`. Windows SmartScreen may say "unknown publisher" the first time because the program is not
code-signed: choose *More info* > *Run anyway*. Your data lives in `%LOCALAPPDATA%\Zari`, not in this folder, so
you can replace or move the program without touching your data.

To rebuild the program after changing the code, double-click **build_exe.bat**. To check a build is complete:
`Zari.exe --selftest result.txt` (writes one OK / FAIL line per feature).

### From the source code (for development)

1. Double-click **setup_zari.bat** once (creates a private Python environment and installs packages).
2. Double-click **run_zari.bat** to start Zari.

Or from a terminal in this folder:

```
py -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m zari
```

## Accounts: every person has private data

The first time you start Zari you create an account. That first account is the **owner**: it can add other
users and reset their passwords (but cannot read their data). Each account gets its own folder with its own
database, invoices and backups, so users never see each other's events, clients or money. **Sign out** and
**Account** (change password, manage users) are at the bottom of the sidebar.

- Passwords are stored only as salted scrypt hashes, with a 30-second lock after 5 wrong attempts.
- A forgotten password cannot be recovered by the person themselves; the owner can set a new one
  (Account > Reset password). If the owner forgets theirs, there is no reset - keep it safe.
- Data files are **not encrypted**. Anyone who can sign in to your Windows account can read them with other tools.
  Use Windows sign-in and BitLocker for that.
- If you used an earlier single-user version, the first account offers to move that data into it.

On first launch each account gets clearly-labelled **sample data** (pink "Sample" badge); use
**Remove sample data** on the Dashboard to start with your own.

## Invoices

**Scan invoice** (sidebar, or inside any event) asks for the source:

- **A photo or PDF from your computer.** Digital PDFs (exported from accounting software) are read straight
  from their text - no OCR, most accurate. Scanned PDFs and photos use Tesseract OCR.
- **The camera.** A live preview window; capture, retake, then use the photo.

You always review the detected vendor, date, invoice number, total, category before saving. Zari warns about
likely duplicates, creates the expense, and keeps the file as an attached document of the event.

Tesseract (free, offline) is needed only for photos and scanned PDFs:

```
winget install UB-Mannheim.TesseractOCR
```

Every event also has a **Documents** section: attach any file (invoice, contract, receipt, quote), optionally
linked to an expense. Click **Attach file** or drop files onto the panel. Programs/scripts (.exe, .bat ...) are
refused; the limit is 25 MB per file. Removing a document keeps the stored file so nothing is lost if you
restore an older backup.

## What is in the app

- **Dashboard** - five live stats, upcoming events, Revenue/Profit chart, **Alerts** (overdue vendor payments,
  budget overruns, losses, expiring quotes), tasks, backup / restore.
- **Full screen for an event** - the expand button at the top of an event opens it across the whole window in two
  columns (budget and planning on the left, payments / expenses / documents on the right). Esc steps back. Vendor
  quotes, Guests and Scenario windows can be maximised too, and Zari itself opens maximised.
- **Budget vs actual diagram** - bars per category inside each event's Budget section, and per event on the Reports
  page. Pale outline = budget, gold = actual, rose = committed quotes, red = over budget. Hover for exact AED.
- **Complete event reports** - an event's *PDF* and *Excel* buttons export everything: details, financial summary,
  budget vs actual (with the diagram), payments, expenses (with invoice numbers and due dates), vendor payables,
  quotations (with lowest / top-rated / suggested highlights), guests and RSVP (no contact details), scenario
  comparison and attached documents. The Reports page exports the same figures for all events.
- **Events** - add / edit / delete, search, filter, sort. The side panel holds: editable contract value, live
  profit and margin, **Budget** by category (estimated, committed and actual shown separately, with contingency),
  payments, expenses (with paid switch and payment due dates), **Vendor quotes**, **Guests & RSVP**,
  **Scenario planning**, **Documents**, and Excel / PDF export.
- **Vendors** - directory with contacts, quotes made and what you have spent / still owe each vendor.
- **Reports** - event-wise summary, budget vs actual, vendor payables; export to Excel or PDF.
- **Calendar** - month grid, Google Calendar link, `.ics` for Apple / Outlook.

### How budget, quotes and scenarios work

- *Estimated* = the budget you set per category. *Actual* = expenses recorded. *Committed* = quotes you selected
  but have not recorded as expenses. *Projected* = actual + committed, compared with the budget (flagged amber at
  90%, red when over).
- **Quotes** for the same requirement are compared side by side. Zari marks the lowest price and the top-rated
  quote and *suggests* a best value (lowest price per rating point) - but never selects a vendor for you.
  Turning a selected quote into an expense moves it from committed to actual, so it is counted once.
- **Scenarios** (guest count, price changes, contingency, contract change) are a sandbox. Saving one changes
  nothing. **Apply to event** updates only guests, contract value and contingency, after a confirmation and an
  automatic safety backup. Expenses and payments are never rewritten.
- **Guests**: phone numbers and emails are hidden (masked) until you tick "Show contact details", and Excel
  exports leave them out unless you choose to include them. Import from Excel (validated, duplicates skipped,
  all-or-nothing). A guest template is available in the dialog.

### How the numbers work

- Amounts are stored as whole **fils** (integers), so there is no rounding drift.
- *Balance due* = contract - payments received (never negative; zero for Cancelled events).
- *Gross profit* = contract - total expenses. *Margin* = profit / contract.
- *Outstanding* (dashboard) = sum of balance due over all non-cancelled events.
- Revenue (chart) = payments received per month; Profit = each payment x its event's margin.

## Fonts (optional, for the full look)

Zari looks best with **Cormorant Garamond** (headings) and **Inter** (body). Put the `.ttf` files into
`assets/fonts/`. Without them Zari uses Palatino / Segoe UI.

## Where is my data?

`%LOCALAPPDATA%\Zari\users\<username>\` (outside OneDrive on purpose - cloud sync can corrupt a live database):
`zari.db`, `invoices\` (attached files), `backups\` (automatic safety backups), `zari.log`. Accounts are in
`%LOCALAPPDATA%\Zari\accounts.db`. **Backup** / **Restore** on the Dashboard copy your own data elsewhere.
Safety backups are taken automatically before deleting an event, restoring, and applying a scenario.

## Project layout

```
zari/
  __main__.py, auth.py, config.py
  db/       database.py (schema + migrations), repository.py + repo_*.py (queries), models.py
  logic/    money, finance, budget, quotes, scenario, alerts, reports, validation, attachments, calendar, sample data
  ocr/      invoice_reader.py, invoice_parser.py, pdf_reader.py
  exports/  excel_export, pdf_export, report_export, guest_excel
  ui/       theme, widgets, pages (dashboard, events, vendors, reports, calendar), dialogs, event panel, login
tests/      152 automated tests   ->   .venv\Scripts\python.exe -m pytest
tools/      make_icon.py (draws the app icon)      run_zari.py + build_exe.bat build the .exe
```

## Known limitations

- Invoice OCR is rule-based: always check highlighted fields. Arabic is read only if Tesseract's Arabic language
  pack is installed. Crumpled or handwritten invoices will be unreliable.
- The camera window uses Windows' camera support. It was verified to open and start a live preview on this PC's
  built-in camera, but a full capture-and-save was not exercised here (to avoid photographing the room).
- Invoice reading was tested with real Tesseract on generated invoices (clean and slightly tilted/noisy ones).
  Real phone photos vary a lot: always check the highlighted fields.
- PDF exports use built-in fonts (Latin characters only; other scripts print as "?").
- Per-user data separation is by account folder, not encryption (see Accounts above).
