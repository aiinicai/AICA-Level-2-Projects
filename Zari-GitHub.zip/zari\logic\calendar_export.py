"""Google Calendar links and .ics (Apple / Outlook) file generation. Fully offline."""
from __future__ import annotations

from datetime import date, datetime, timedelta, timezone
from urllib.parse import urlencode


def google_calendar_url(event) -> str:
    """A 'create event' link pre-filled with title, date and venue (all-day event)."""
    start = event.date.strftime("%Y%m%d")
    end = (event.date + timedelta(days=1)).strftime("%Y%m%d")
    params = {
        "action": "TEMPLATE",
        "text": event.name,
        "dates": f"{start}/{end}",
        "location": event.venue,
        "details": f"{event.type} for {event.client} - {event.guests} guests (planned with Zari)",
    }
    return "https://calendar.google.com/calendar/render?" + urlencode(params)


def _escape(text: str) -> str:
    return (text.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,")
            .replace("\r\n", "\\n").replace("\n", "\\n"))


def _fold(line: str) -> list[str]:
    """RFC 5545: lines longer than 75 octets are folded with CRLF + space."""
    raw = line.encode("utf-8")
    if len(raw) <= 75:
        return [line]
    out, cur, size = [], "", 0
    for ch in line:
        b = len(ch.encode("utf-8"))
        limit = 75 if not out else 74
        if size + b > limit:
            out.append(cur)
            cur, size = ch, b
        else:
            cur += ch
            size += b
    out.append(cur)
    return [out[0]] + [" " + part for part in out[1:]]


def build_ics(events, now: datetime | None = None) -> str:
    """Return the text of an .ics calendar containing one all-day VEVENT per event."""
    stamp = (now or datetime.now(timezone.utc)).strftime("%Y%m%dT%H%M%SZ")
    lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Zari//Event Finance Studio//EN",
             "CALSCALE:GREGORIAN", "METHOD:PUBLISH"]
    for ev in events:
        lines += [
            "BEGIN:VEVENT",
            f"UID:zari-event-{ev.id}@zari.local",
            f"DTSTAMP:{stamp}",
            f"DTSTART;VALUE=DATE:{ev.date.strftime('%Y%m%d')}",
            f"DTEND;VALUE=DATE:{(ev.date + timedelta(days=1)).strftime('%Y%m%d')}",
            f"SUMMARY:{_escape(ev.name)}",
            f"LOCATION:{_escape(ev.venue)}",
            f"DESCRIPTION:{_escape(f'{ev.type} for {ev.client} - {ev.guests} guests')}",
            "END:VEVENT",
        ]
    lines.append("END:VCALENDAR")
    folded: list[str] = []
    for line in lines:
        folded.extend(_fold(line))
    return "\r\n".join(folded) + "\r\n"


def safe_filename(text: str) -> str:
    cleaned = "".join(c if c.isalnum() or c in " -_" else "" for c in text).strip().replace(" ", "_")
    return cleaned or "event"
