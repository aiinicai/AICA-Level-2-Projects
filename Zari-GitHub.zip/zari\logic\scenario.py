"""What-if planning. Pure calculations: nothing here (or in the dialog that uses it) touches saved
records. Real data only changes when the user explicitly applies a scenario."""
from __future__ import annotations

from dataclasses import dataclass, field

from zari.config import EXPENSE_CATEGORIES
from zari.logic.budget import actual_by_category, committed_by_category
from zari.logic.money import apply_bp


@dataclass
class Plan:
    name: str
    guests: int
    contract_bp: int = 0
    contingency_bp: int = 0
    adjust_bp: dict = field(default_factory=dict)   # category -> price change in basis points
    per_guest: tuple = ("Catering",)                 # categories whose cost scales with guest count


@dataclass(frozen=True)
class Projection:
    name: str
    guests: int
    contract: int
    category_costs: dict
    subtotal: int
    contingency: int
    total_cost: int
    profit: int
    margin: float | None


def base_costs(expenses, quotes) -> dict[str, int]:
    """What each category costs today: expenses already recorded + quotes you have committed to."""
    actual, committed = actual_by_category(expenses), committed_by_category(quotes)
    return {c: actual.get(c, 0) + committed.get(c, 0)
            for c in EXPENSE_CATEGORIES if actual.get(c, 0) or committed.get(c, 0)}


def _scale(fils: int, num: int, den: int) -> int:
    return (fils * num * 2 + den) // (den * 2)  # integer round-half-up of fils * num / den


def project(base: dict[str, int], contract: int, current_guests: int, plan: Plan) -> Projection:
    current_guests = max(1, current_guests)
    costs: dict[str, int] = {}
    for cat, cost in base.items():
        value = _scale(cost, plan.guests, current_guests) if cat in plan.per_guest else cost
        costs[cat] = apply_bp(value, plan.adjust_bp.get(cat, 0))
    subtotal = sum(costs.values())
    contingency = apply_bp(subtotal, plan.contingency_bp) - subtotal
    total = subtotal + contingency
    new_contract = apply_bp(contract, plan.contract_bp)
    profit = new_contract - total
    margin = (profit / new_contract * 100) if new_contract > 0 else None
    return Projection(plan.name, plan.guests, new_contract, costs, subtotal, contingency, total, profit, margin)


def baseline(base: dict[str, int], contract: int, guests: int, contingency_bp: int = 0) -> Projection:
    """The event as it stands today (the column every scenario is compared against)."""
    return project(base, contract, guests, Plan("Current plan", guests, 0, contingency_bp, {}, ()))
