"""The sign-in -> main window -> sign-out cycle, with each user landing in their own private data."""
import os
from types import SimpleNamespace

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtWidgets import QApplication  # noqa: E402

from zari import config  # noqa: E402
from zari.auth import AccountStore  # noqa: E402
from zari.ui import theme  # noqa: E402


def test_sign_out_returns_to_login_and_users_get_separate_data(data_dir, monkeypatch):
    app = QApplication.instance() or QApplication([])
    theme.init_fonts()
    app.setStyleSheet(theme.stylesheet())
    import zari.__main__ as entry

    store = AccountStore(data_dir)
    arya = store.create("arya", "Arya", "Sunrise2026")
    meera = store.create("meera", "Meera", "Marigold#77")
    logins = [arya, meera, None]  # third login screen is cancelled -> app quits
    shown = []

    class FakeLogin:
        def __init__(self, _store):
            self.account = logins.pop(0)

        def exec(self):
            shown.append(self.account)
            return 1 if self.account else 0

    monkeypatch.setattr(entry, "LoginDialog", FakeLogin)
    quits = []
    session = entry.Session(SimpleNamespace(quit=lambda: quits.append(1)), store)
    try:
        session.start()
        assert session.window.account.username == "arya" and config.current_user() == "arya"
        arya_db = session.db.path
        assert arya_db.parent == data_dir / "users" / "arya"
        # first launch for this account loads clearly-labelled sample data, kept inside Arya's folder
        assert session.window.ctx.repo.has_sample_data()
        session.window.ctx.repo.remove_sample_data()
        session.window.ctx.repo.add_event({"name": "Arya private", "client": "C", "type": "Gala", "date": "2026-12-01",
                                           "venue": "V", "guests": 5, "status": "Confirmed", "contract_value": 100})

        session.sign_out()
        app.processEvents()   # the next login is scheduled with a zero-delay timer
        assert session.window.account.username == "meera" and config.current_user() == "meera"
        assert session.db.path == data_dir / "users" / "meera" / "zari.db" != arya_db
        names = [e.name for e in session.window.ctx.repo.list_events()]
        assert "Arya private" not in names          # Meera cannot see Arya's data
        assert session.window.ctx.repo.has_sample_data()  # but gets her own sample set

        session.sign_out()
        app.processEvents()
        assert session.window is None and quits == [1]   # cancelled login -> quit
        assert config.current_user() is None
    finally:
        if session.window:
            session.window.signing_out = True
            session.window.close()
        if session.db:
            session.db.close()
        config.set_current_user(None)
        store.close()
