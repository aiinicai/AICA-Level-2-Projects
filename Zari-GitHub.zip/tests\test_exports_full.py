"""Complete per-event PDF / Excel reports, the budget-vs-actual diagram, and the full-screen event view."""
import os
from datetime import date

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtCore import Qt  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from zari.exports.charts import budget_drawing  # noqa: E402
from zari.exports.event_report import collect  # noqa: E402
from zari.exports.excel_export import export_event_workbook  # noqa: E402
from zari.exports.pdf_export import export_event_pdf  # noqa: E402
from zari.logic.money import format_aed  # noqa: E402
from zari.ocr import pdf_reader  # noqa: E402
from zari.ui import theme  # noqa: E402
from zari.ui.context import AppContext  # noqa: E402
from zari.ui.main_window import MainWindow  # noqa: E402

TODAY = date(2026, 10, 21)


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    theme.init_fonts()
    app.setStyleSheet(theme.stylesheet())
    return app


@pytest.fixture()
def full(repo, qapp, tmp_path):
    """Kapoor wedding with budgets, quotes, guests, scenario and an attached document."""
    from zari.logic import attachments
    from zari.logic.validation import validate_document, validate_scenario
    repo.seed_sample_data(TODAY)
    ev = next(e for e in repo.list_events() if e.name.startswith("Kapoor"))
    src = tmp_path / "venue-contract.pdf"
    src.write_bytes(b"%PDF-1.4 contract")
    stored, original, size = attachments.store_file(src, str(ev.id))
    repo.add_document(ev.id, validate_document("Contract", "Palace venue contract"), stored, original, size)
    repo.save_scenario(ev.id, validate_scenario("Bigger party", 520, "12", "5", {"Venue": "5"}, ["Catering"]))
    return repo, ev


def test_report_collects_every_section(full):
    repo, ev = full
    r = collect(repo, ev.id, TODAY)
    assert r.event.id == ev.id and r.payments and r.expenses and r.budgets
    assert r.quote_groups and r.guests and r.documents and r.scenarios and r.vendor_rows
    assert r.budget.total_budget == 324_000_00 and r.budget.total_actual == r.event.expenses
    assert r.guest_stats["parties"] == 7
    assert r.baseline.contract == ev.contract_value
    with pytest.raises(ValueError):
        collect(repo, 99999, TODAY)


def test_excel_event_workbook_has_all_sheets_and_matching_numbers(full, tmp_path):
    from openpyxl import load_workbook
    repo, ev = full
    r = collect(repo, ev.id, TODAY)
    path = export_event_workbook(tmp_path / "event.xlsx", r)
    wb = load_workbook(path)
    assert wb.sheetnames == ["Summary", "Budget vs Actual", "Payments", "Expenses", "Vendor payables", "Quotations",
                             "Guests", "Scenarios", "Documents"]
    summary = {row[0].value: row[1].value for row in wb["Summary"].iter_rows() if row[0].value}
    f = r.event.fin
    assert summary["Contract value"] == f.contract / 100 and summary["Total expenses recorded"] == f.expenses / 100
    assert summary["Total budget"] == 324_000 and summary["Committed (selected quotes)"] == 18_500

    bud = wb["Budget vs Actual"]
    assert bud.max_row >= len(r.budget.lines) + 2
    assert bud._charts, "the budget sheet must contain the bar chart"
    totals = [row for row in bud.iter_rows(values_only=True) if row[0] == "Total"][0]
    assert totals[1] == r.budget.total_budget / 100 and totals[4] == r.budget.total_actual / 100

    exp = wb["Expenses"]
    assert [row for row in exp.iter_rows(values_only=True) if row[0] == "Total"][0][7] == f.expenses / 100
    pay = wb["Payments"]
    assert [row for row in pay.iter_rows(values_only=True) if row[0] == "Total"][0][2] == f.received / 100
    assert wb["Quotations"].max_row == 1 + sum(len(g.views) for g in r.quote_groups)
    assert wb["Documents"]["B2"].value == "Palace venue contract"
    assert wb["Scenarios"]["C1"].value == "Bigger party"
    guests = wb["Guests"]
    texts = " ".join(str(c.value) for row in guests.iter_rows() for c in row if c.value)
    assert "+971" not in texts and "@sample.example" not in texts and "Phone" not in texts   # privacy


def test_pdf_event_report_contains_every_section(full, tmp_path, qapp):
    repo, ev = full
    r = collect(repo, ev.id, TODAY)
    pdf = export_event_pdf(tmp_path / "event.pdf", r)
    assert pdf.read_bytes().startswith(b"%PDF")
    text = pdf_reader.embedded_text(pdf)
    for heading in ("1. Event details", "2. Financial summary", "3. Budget vs actual", "4. Payments received",
                    "5. Expenses", "6. Vendor payables", "7. Vendor quotations", "8. Guests and RSVP",
                    "9. Scenario comparison", "10. Attached documents"):
        assert heading in text, heading
    f = r.event.fin
    for needle in ("Kapoor-Mehta Royal Wedding", format_aed(f.contract), format_aed(f.received), format_aed(f.expenses),
                   format_aed(r.budget.total_budget), "Emirates Palace", "Saffron Royale Catering",
                   "Lumen Studios", "Wedding photography and film", "Bigger party", "Palace venue contract",
                   "Contingency reserve", "Budget vs actual by category"):
        assert needle in text, needle
    assert "+971" not in text and "@sample.example" not in text       # no guest contact details
    assert "Sample: Rajesh Mehta" in text                              # but the guest list itself is there


def test_pdf_report_handles_an_empty_event(repo, qapp, tmp_path):
    from zari.logic.validation import validate_event
    eid = repo.add_event(validate_event("Brand new", "Client", "Gala", TODAY, "Venue", 50, "Enquiry", "0"))
    r = collect(repo, eid, TODAY)
    text = pdf_reader.embedded_text(export_event_pdf(tmp_path / "empty.pdf", r))
    assert "No payments recorded." in text and "No expenses recorded." in text and "No quotations recorded." in text
    from openpyxl import load_workbook
    wb = load_workbook(export_event_workbook(tmp_path / "empty.xlsx", r))
    assert len(wb.sheetnames) == 9


def test_pdf_report_survives_special_characters(repo, qapp, tmp_path):
    from zari.logic.validation import validate_event, validate_expense
    eid = repo.add_event(validate_event("Smith & Sons <Gala> – café مرحبا", "A&B", "Gala",
                                        TODAY, "Café \"Royale\"", 50, "Confirmed", "1,000"))
    repo.add_expense(eid, validate_expense("Venue", "Flür & <b>bold</b> – hall", "100", vendor="R&D Ltd"))
    path = export_event_pdf(tmp_path / "special.pdf", collect(repo, eid, TODAY))
    text = pdf_reader.embedded_text(path)
    assert "Smith & Sons" in text and "R&D Ltd" in text            # ampersands are not double-escaped


def test_budget_drawing_for_pdf():
    rows = [("Venue", 100_000_00, 118_000_00, 0), ("Catering", 80_000_00, 50_000_00, 20_000_00), ("Decor", 0, 5_000_00, 0)]
    d = budget_drawing(rows, width=400, title="T")
    assert len(d.contents) > len(rows) * 3          # bars, labels and a legend were drawn
    assert d.height > len(rows) * 15
    assert budget_drawing([], width=400).height > 0  # empty state does not crash


# ---- the diagram widget and full-screen view -------------------------------------------------
@pytest.fixture()
def win(qapp, repo, monkeypatch):
    repo.seed_sample_data()
    w = MainWindow(AppContext(repo))
    w.resize(1500, 900)
    w.show()
    qapp.processEvents()
    yield w
    w.close()


def kapoor(win):
    return next(e for e in win.ctx.repo.list_events() if e.name.startswith("Kapoor"))


def test_budget_chart_in_panel_and_reports(win):
    from zari.ui.event_sections import BudgetCard
    ev = kapoor(win)
    win.open_panel(ev.id)
    card = win.panel.findChildren(BudgetCard)[0]
    assert len(card.chart._rows) == 5
    names = [r[0] for r in card.chart._rows]
    assert names == ["Venue", "Catering", "Decor", "Entertainment", "Photography"]
    venue = card.chart._rows[0]
    assert venue[1] == 125_000_00 and venue[2] == 118_000_00 and venue[3] == 0
    cat = card.chart._rows[1]
    assert cat[2] == 96_000_00 and cat[3] == 18_500_00                      # actual and committed kept separate
    assert not card.chart.grab().isNull()
    # editing a budget updates the diagram without rebuilding the panel
    card._widgets["Transport"]["edit"].setText("9,000")
    card._widgets["Transport"]["edit"].editingFinished.emit()
    assert card.chart._rows[-1][0] == "Transport" and card.chart._rows[-1][1] == 9_000_00

    page = win.pages["reports"]
    page.refresh()
    assert page.chart._rows and all(r[1] or r[2] or r[3] for r in page.chart._rows)
    assert len(page.chart._rows) == sum(1 for r in page._data[0] if r.budget or r.actual or r.committed)


def test_event_opens_full_screen_with_two_columns_and_back(win):
    ev = kapoor(win)
    win.open_panel(ev.id)
    win.anim.setCurrentTime(win.anim.duration())
    QApplication.processEvents()
    assert win.panel.width() == 600 and win.panel.x() == win.central.width() - 600
    assert win.panel._left is win.panel._right                    # one column in the side panel

    win.panel.expand_btn.click()
    QApplication.processEvents()
    assert win.panel.expanded and win.panel.width() == win.central.width() and win.panel.x() == 0
    assert win.panel._left is not win.panel._right                # two columns when full screen
    assert not win.scrim.isVisible()
    from zari.ui.event_sections import BudgetCard
    assert len(win.panel.findChildren(BudgetCard)) == 1           # nothing duplicated by the layout switch
    assert win.panel.expand_btn.toolTip().startswith("Back to the side panel")

    win.resize(1300, 800)                                         # stays full screen when the window changes size
    QApplication.processEvents()
    assert win.panel.width() == win.central.width()

    win._escape()                                                 # first Esc leaves full screen ...
    QApplication.processEvents()
    assert not win.panel.expanded and win.panel.width() == 600 and win._panel_open
    win._escape()                                                 # ... the second closes the panel
    assert not win._panel_open


def test_panel_content_is_identical_in_both_layouts(win):
    from PySide6.QtWidgets import QLabel
    ev = kapoor(win)
    win.open_panel(ev.id)

    def titles():
        return sorted(l.text() for l in win.panel.findChildren(QLabel)
                      if l.text() in ("Budget", "Payments received", "Expenses", "Vendor quotes", "Guests & RSVP",
                                      "Scenario planning", "Documents"))
    compact = titles()
    win.panel.set_expanded(True)
    assert titles() == compact and len(compact) == 7


def test_big_windows_can_be_maximised(win):
    from zari.ui.guests_ui import GuestsDialog
    from zari.ui.quotes_ui import QuotesDialog
    from zari.ui.scenario_ui import ScenarioDialog
    ev = kapoor(win)
    for cls in (QuotesDialog, GuestsDialog, ScenarioDialog):
        d = cls(win, win.ctx, ev.id)
        assert d.windowFlags() & Qt.WindowType.WindowMaximizeButtonHint, cls.__name__
        d.close()
