"""Attached files (invoices, contracts, receipts...) (mixed into Repository)."""
from __future__ import annotations

from zari.db.models import Document

_SELECT = ("SELECT d.*, e.description AS expense_label FROM documents d "
           "LEFT JOIN expenses e ON e.id = d.expense_id")


def _doc(r) -> Document:
    return Document(r["id"], r["event_id"], r["expense_id"], r["expense_label"], r["kind"], r["title"],
                    r["stored_name"], r["original_name"], r["size"], r["added_at"])


class DocumentMixin:
    def list_documents(self, event_id: int) -> list[Document]:
        rows = self.conn.execute(_SELECT + " WHERE d.event_id=? ORDER BY d.id DESC", (event_id,)).fetchall()
        return [_doc(r) for r in rows]

    def count_documents(self, event_id: int) -> int:
        return self.conn.execute("SELECT COUNT(*) FROM documents WHERE event_id=?", (event_id,)).fetchone()[0]

    def add_document(self, event_id: int, data: dict, stored_name: str, original_name: str, size: int,
                     expense_id: int | None = None) -> int:
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO documents (event_id, expense_id, kind, title, stored_name, original_name, size)"
                " VALUES (?,?,?,?,?,?,?)",
                (event_id, expense_id, data["kind"], data["title"], stored_name, original_name, size))
        return cur.lastrowid

    def delete_document(self, doc_id: int) -> None:
        """Removes the record only. The file stays on disk, so restoring an older backup never loses it."""
        with self.conn:
            self.conn.execute("DELETE FROM documents WHERE id=?", (doc_id,))
