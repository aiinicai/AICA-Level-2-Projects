"""Budget tracking: estimated, quoted, committed and actual costs - kept separate, never double counted.

  estimated  = the budget you allocated to a category
  quoted     = cheapest open quote per requirement that you have NOT yet selected or paid (informational)
  committed  = quotes you selected that are not yet recorded as an expense
  actual     = expenses recorded (including quotes converted to expenses)
  projected  = actual + committed   <- the number compared with the budget

A quote turned into an expense moves from "committed" to "actual" - it is only ever counted once.
"""
from __future__ import annotations

from dataclasses import dataclass

from zari.config import EXPENSE_CATEGORIES, MARGIN_WARN
from zari.logic.money import apply_bp

WARN_AT = 0.90  # flag "approaching limit" at 90% of a category budget


@dataclass(frozen=True)
class CategoryLine:
    category: str
    budget: int
    quoted: int
    committed: int
    actual: int
    projected: int
    remaining: int            # budget - projected (negative = overspent)
    used_pct: float | None    # projected / budget * 100
    status: str               # none | ok | warning | over


@dataclass(frozen=True)
class BudgetSummary:
    lines: list
    total_budget: int
    total_quoted: int
    total_committed: int
    total_actual: int
    total_projected: int
    contingency: int          # reserve held back from the budget
    remaining: int            # budget - projected (before contingency)
    remaining_after_contingency: int
    status: str


def _status(budget: int, projected: int) -> str:
    if budget <= 0:
        return "none"
    if projected > budget:
        return "over"
    if projected >= budget * WARN_AT:
        return "warning"
    return "ok"


def committed_by_category(quotes) -> dict[str, int]:
    out: dict[str, int] = {}
    for q in quotes:
        if q.status == "Selected" and not q.expense_id:
            out[q.category] = out.get(q.category, 0) + q.amount
    return out


def quoted_by_category(quotes) -> dict[str, int]:
    """Cheapest open (not rejected, not selected) quote for each requirement still undecided."""
    by_req: dict[str, list] = {}
    for q in quotes:
        by_req.setdefault(q.requirement.strip().lower(), []).append(q)
    out: dict[str, int] = {}
    for group in by_req.values():
        if any(q.status == "Selected" or q.expense_id for q in group):
            continue  # decided already - counted as committed / actual instead
        open_quotes = [q for q in group if q.status != "Rejected"]
        if open_quotes:
            best = min(open_quotes, key=lambda q: q.amount)
            out[best.category] = out.get(best.category, 0) + best.amount
    return out


def actual_by_category(expenses) -> dict[str, int]:
    out: dict[str, int] = {}
    for e in expenses:
        out[e.category] = out.get(e.category, 0) + e.amount
    return out


def category_lines(budgets: dict[str, int], expenses, quotes) -> list[CategoryLine]:
    actual, committed, quoted = actual_by_category(expenses), committed_by_category(quotes), quoted_by_category(quotes)
    lines = []
    for cat in EXPENSE_CATEGORIES:
        b, a, c, q = budgets.get(cat, 0), actual.get(cat, 0), committed.get(cat, 0), quoted.get(cat, 0)
        if not (b or a or c or q):
            continue
        projected = a + c
        lines.append(CategoryLine(cat, b, q, c, a, projected, b - projected,
                                  (projected / b * 100) if b > 0 else None, _status(b, projected)))
    return lines


def summarize(budgets: dict[str, int], expenses, quotes, contingency_bp: int = 0) -> BudgetSummary:
    lines = category_lines(budgets, expenses, quotes)
    total_budget = sum(budgets.values())
    actual = sum(l.actual for l in lines)
    committed = sum(l.committed for l in lines)
    projected = actual + committed
    contingency = apply_bp(total_budget, contingency_bp) - total_budget
    remaining = total_budget - projected
    status = _status(total_budget, projected)
    if status == "ok" and total_budget and remaining - contingency < 0:
        status = "warning"  # inside the budget but eating into the contingency reserve
    if any(l.status == "over" for l in lines) and status in ("ok", "none"):
        status = "warning"
    return BudgetSummary(lines, total_budget, sum(l.quoted for l in lines), committed, actual, projected,
                         contingency, remaining, remaining - contingency, status)
