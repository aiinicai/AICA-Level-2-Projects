"""Guest list import / export through Excel.

Privacy: exports leave out phone numbers and emails unless you explicitly include them.
Imports are validated row by row and added in one go (all or nothing) by the repository.
"""
from __future__ import annotations

from pathlib import Path

from openpyxl import Workbook, load_workbook

from zari.exports.excel_export import HEADER_FILL, HEADER_FONT, _autosize, harden_workbook
from zari.logic.validation import ValidationError, validate_guest

HEADERS = ["Name", "Phone", "Email", "Party size", "Group", "Invited", "RSVP", "Notes"]
MAX_IMPORT_ROWS = 5000


def _write_header(ws, titles) -> None:
    for col, title in enumerate(titles, 1):
        c = ws.cell(row=1, column=col, value=title)
        c.fill, c.font = HEADER_FILL, HEADER_FONT


def export_guests(path: str | Path, guests, include_contacts: bool = False) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "Guests"
    titles = [h for h in HEADERS if include_contacts or h not in ("Phone", "Email")]
    _write_header(ws, titles)
    for r, g in enumerate(guests, 2):
        values = {"Name": g.name, "Phone": g.phone, "Email": g.email, "Party size": g.party_size, "Group": g.group,
                  "Invited": "Yes" if g.invited else "No", "RSVP": g.rsvp, "Notes": g.notes}
        for c, title in enumerate(titles, 1):
            ws.cell(row=r, column=c, value=values[title])
    _autosize(ws)
    harden_workbook(wb)
    path = Path(path)
    wb.save(path)
    return path


def write_template(path: str | Path) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = "Guests"
    _write_header(ws, HEADERS)
    ws.append(["Example Family", "+971 50 000 0000", "example@mail.com", 4, "Bride's side", "Yes", "Pending", ""])
    _autosize(ws)
    path = Path(path)
    wb.save(path)
    return path


def _truthy(value) -> bool:
    return str(value or "").strip().lower() in ("yes", "y", "true", "1", "invited")


def read_guests(path: str | Path) -> tuple[list[dict], list[str]]:
    """Return (valid guest dicts, human-readable problems). Never raises for bad rows."""
    problems: list[str] = []
    try:
        wb = load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:
        return [], [f"Could not open that Excel file: {exc}"]
    ws = wb.worksheets[0]
    rows = ws.iter_rows(values_only=True)
    header = next(rows, None)
    if not header:
        return [], ["The file is empty."]
    index = {str(h).strip().lower(): i for i, h in enumerate(header) if h is not None}
    if "name" not in index:
        return [], ["The first row must contain column titles, including \"Name\"."]

    def cell(row, key, default=""):
        i = index.get(key)
        return row[i] if i is not None and i < len(row) and row[i] is not None else default

    valid: list[dict] = []
    for n, row in enumerate(rows, 2):
        if n > MAX_IMPORT_ROWS + 1:
            problems.append(f"Stopped at row {MAX_IMPORT_ROWS + 1}: too many rows for one import.")
            break
        if all(v in (None, "") for v in row):
            continue
        rsvp = str(cell(row, "rsvp", "Pending")).strip().title() or "Pending"
        try:
            size = cell(row, "party size", 1)
            valid.append(validate_guest(
                cell(row, "name"), str(cell(row, "phone")), str(cell(row, "email")),
                int(float(size)) if str(size).strip() else 1, cell(row, "group"),
                _truthy(cell(row, "invited")) or rsvp != "Pending", rsvp, cell(row, "notes")))
        except (ValidationError, ValueError) as exc:
            msg = "; ".join(exc.errors.values()) if isinstance(exc, ValidationError) else "Party size is not a number"
            problems.append(f"Row {n}: {msg}")
    wb.close()
    return valid, problems
