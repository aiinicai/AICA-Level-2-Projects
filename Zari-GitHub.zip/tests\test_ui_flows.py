"""End-to-end UI tests: drive the real widgets (offscreen) and check the database + numbers."""
import os
from datetime import date, timedelta

import pytest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PySide6.QtGui import QColor, QImage  # noqa: E402
from PySide6.QtWidgets import QApplication  # noqa: E402

from zari.logic import attachments, finance  # noqa: E402
from zari.logic.money import format_aed  # noqa: E402
from zari.ocr.invoice_parser import parse_invoice_text  # noqa: E402
from zari.ui import theme  # noqa: E402
from zari.ui.context import AppContext  # noqa: E402
from zari.ui.main_window import MainWindow  # noqa: E402


@pytest.fixture(scope="module")
def qapp():
    app = QApplication.instance() or QApplication([])
    theme.init_fonts()
    app.setStyleSheet(theme.stylesheet())
    return app


@pytest.fixture()
def win(qapp, repo, monkeypatch):
    # Never block on a modal "Are you sure?" box in tests: auto-confirm.
    for mod in ("zari.ui.tasks_panel", "zari.ui.event_panel", "zari.ui.event_actions", "zari.ui.invoice_dialog",
                "zari.ui.dashboard_page"):
        monkeypatch.setattr(f"{mod}.confirm", lambda *a, **k: True)
    repo.seed_sample_data()
    ctx = AppContext(repo)
    w = MainWindow(ctx)
    w.show()
    qapp.processEvents()
    yield w
    w.close()


def test_stat_cards_match_the_data(win):
    ctx = win.ctx
    s = finance.dashboard_stats(ctx.repo.list_events(), ctx.repo.list_payments(), ctx.repo.list_tasks(), ctx.today)
    cards = win.pages["dashboard"].cards
    assert cards["next"].value.text() == str(s.next_30_days)
    assert cards["revenue"].value.text() == format_aed(s.revenue_this_month)
    assert cards["outstanding"].value.text() == format_aed(s.outstanding)
    assert cards["margin"].value.text() == finance.format_margin(s.avg_margin)
    assert cards["tasks"].value.text() == str(s.pending_tasks)
    assert cards["tasks"].note.text() == f"{s.overdue_tasks} overdue"


def test_chart_toggle_switches_series(win):
    dash = win.pages["dashboard"]
    revenue = list(dash.chart._values)
    dash.mode_buttons["Profit"].click()
    assert dash.chart._series == "Profit" and dash.chart._values != revenue
    dash.mode_buttons["Revenue"].click()
    assert dash.chart._values == revenue


def test_adding_a_payment_updates_dashboard_and_panel(win):
    ctx = win.ctx
    ev = next(e for e in ctx.repo.list_events() if e.name.startswith("Singh"))  # has a balance due
    before = win.pages["dashboard"].cards["outstanding"].value.text()
    from zari.logic.validation import validate_payment
    ctx.repo.add_payment(ev.id, validate_payment("30,000", ctx.today, "Balance"))
    ctx.data_changed()
    after = win.pages["dashboard"].cards["outstanding"].value.text()
    assert before != after
    win.open_panel(ev.id)
    assert win.panel.event_id == ev.id
    assert ctx.repo.get_event(ev.id).fin.balance_due == 0


def test_events_page_search_and_status_filter(win):
    page = win.pages["events"]
    page.search.setText("falasi")
    assert [e.name for e in page._filtered()] == ["Al Falasi Corporate Gala"]
    page.search.setText("")
    page.status.setCurrentText("Cancelled")
    assert [e.status for e in page._filtered()] == ["Cancelled"]
    page.status.setCurrentIndex(0)
    page.search.setText("burj")  # venue search
    assert len(page._filtered()) == 1


def test_task_add_edit_complete_delete(win):
    panel = win.pages["dashboard"].tasks
    repo = win.ctx.repo
    n = len(repo.list_tasks())
    panel.title.setText("Call the florist")
    panel.priority.setCurrentText("High")
    panel.submit.click()
    assert len(repo.list_tasks()) == n + 1
    task = next(t for t in repo.list_tasks() if t.title == "Call the florist")
    assert task.priority == "High"

    panel._start_edit(task)
    panel.title.setText("Call the florist today")
    panel.submit.click()
    assert any(t.title == "Call the florist today" for t in repo.list_tasks())

    panel._toggle(task.id, True)
    assert next(t for t in repo.list_tasks() if t.id == task.id).done
    panel._set_filter("done")
    assert all(t.done for t in repo.list_tasks() if t.id == task.id)
    panel._delete(next(t for t in repo.list_tasks() if t.id == task.id))
    assert len(repo.list_tasks()) == n


def test_empty_task_title_is_rejected(win):
    panel = win.pages["dashboard"].tasks
    n = len(win.ctx.repo.list_tasks())
    panel.title.setText("   ")
    panel.submit.click()
    assert len(win.ctx.repo.list_tasks()) == n and not panel.error.isHidden()


def test_overdue_tasks_are_flagged(win):
    stats = win.pages["dashboard"].cards["tasks"]
    assert stats.note.text().startswith("2 overdue")


def test_contract_value_edit_in_panel(win):
    ev = next(e for e in win.ctx.repo.list_events() if e.name.startswith("Ahuja"))
    win.open_panel(ev.id)
    win.panel.contract_edit.setText("AED 60,000")
    win.panel._save_contract()
    assert win.ctx.repo.get_event(ev.id).contract_value == 6_000_000
    win.panel.contract_edit.setText("abc")
    win.panel._save_contract()  # invalid: must not change anything
    assert win.ctx.repo.get_event(ev.id).contract_value == 6_000_000


def test_panel_closes_when_event_deleted(win):
    ev = win.ctx.repo.list_events()[0]
    win.open_panel(ev.id)
    from zari.ui.event_actions import delete_event_flow
    assert delete_event_flow(win, win.ctx, ev.id)
    assert win.panel.event_id is None and win.ctx.repo.get_event(ev.id) is None


def test_calendar_month_navigation_and_today(win):
    cal = win.pages["calendar"]
    y, m = cal.year, cal.month
    cal._shift(1)
    assert (cal.year, cal.month) == ((y + 1, 1) if m == 12 else (y, m + 1))
    cal._shift(-1)
    cal._go_today()
    assert (cal.year, cal.month) == (win.ctx.today.year, win.ctx.today.month)


def test_invoice_scan_review_and_save(win, tmp_path, monkeypatch):
    """Full invoice flow with OCR text supplied directly (Tesseract itself is not needed here)."""
    from zari.ui import invoice_dialog as idlg

    img = tmp_path / "inv.png"
    image = QImage(300, 400, QImage.Format.Format_RGB32)
    image.fill(QColor("white"))
    assert image.save(str(img))

    repo = win.ctx.repo
    ev = next(e for e in repo.list_events() if e.name.startswith("Ahuja"))
    before = repo.list_expenses(ev.id)

    dlg = idlg.InvoiceDialog(win, win.ctx, str(img), ev.id)
    dlg._worker.wait(5000)
    QApplication.processEvents()
    dlg._on_result(parse_invoice_text(
        "Marigold Studio Floral Decor\nInvoice No: MS-204\nInvoice Date: 12/10/2026\n"
        "Backdrop and thaals  6,500\nVAT 5%  325\nGrand Total AED  6,825"))
    assert dlg.amount.text() == "6825" and dlg.vendor.text() == "Marigold Studio Floral Decor"
    assert dlg.category.currentText() == "Decor"
    dlg._save()

    after = repo.list_expenses(ev.id)
    assert len(after) == len(before) + 1
    new = next(x for x in after if x.invoice_no == "MS-204")
    assert new.amount == 682_500 and new.vendor == "Marigold Studio Floral Decor"
    assert new.invoice_file and attachments.attachment_path(new.invoice_file).is_file()
    assert new.date == date(2026, 10, 12)

    # saving the same invoice again is caught as a likely duplicate (user declines)
    monkeypatch.setattr(idlg, "confirm", lambda *a, **k: False)
    dlg2 = idlg.InvoiceDialog(win, win.ctx, str(img), ev.id)
    dlg2._worker.wait(5000)
    QApplication.processEvents()
    dlg2._on_result(parse_invoice_text(
        "Marigold Studio Floral Decor\nInvoice No: MS-204\nInvoice Date: 12/10/2026\nGrand Total AED 6,825"))
    dlg2._save()
    assert len(repo.list_expenses(ev.id)) == len(after)


def test_invoice_dialog_validates_before_saving(win, tmp_path):
    from zari.ui import invoice_dialog as idlg

    img = tmp_path / "blank.png"
    image = QImage(100, 100, QImage.Format.Format_RGB32)
    image.fill(QColor("white"))
    image.save(str(img))
    dlg = idlg.InvoiceDialog(win, win.ctx, str(img), None)  # no event chosen
    dlg._worker.wait(5000)
    QApplication.processEvents()
    count = lambda: sum(len(win.ctx.repo.list_expenses(e.id)) for e in win.ctx.repo.list_events())  # noqa: E731
    n = count()
    dlg.amount.setText("not a number")
    dlg._save()
    assert count() == n and not dlg._hints["event"].isHidden() and not dlg._hints["amount"].isHidden()


def test_money_in_ui_uses_thousand_separators(win):
    ev = next(e for e in win.ctx.repo.list_events() if e.name.startswith("Kapoor"))
    from zari.ui.dialogs import EventDialog
    dlg = EventDialog(win, ev)
    assert dlg.contract.text() == "385,000"
    dlg._on_save()
    assert dlg.result_data["contract_value"] == 38_500_000


def test_event_dialog_shows_validation_errors(win):
    from zari.ui.dialogs import EventDialog
    dlg = EventDialog(win)
    dlg._on_save()
    assert not hasattr(dlg, "result_data")
    assert not dlg._rows["name"][1].isHidden() and not dlg._rows["venue"][1].isHidden()
