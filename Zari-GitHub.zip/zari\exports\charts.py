"""Budget-vs-actual bar chart drawn with ReportLab shapes (for PDFs) and with openpyxl (for Excel)."""
from __future__ import annotations

from openpyxl.chart import BarChart, Reference
from openpyxl.chart.series import SeriesLabel
from reportlab.graphics.shapes import Drawing, Line, Rect, String
from reportlab.lib import colors

from zari.logic.money import format_axis

TRACK = colors.HexColor("#EFE3D0")
GOLD = colors.HexColor("#C9A961")
BURGUNDY = colors.HexColor("#5E1530")
ROSE = colors.HexColor("#C9738F")
RED = colors.HexColor("#C0392B")
INK = colors.HexColor("#3B2A30")


def _clip(text: str, n: int = 22) -> str:
    text = str(text).encode("cp1252", "replace").decode("cp1252")
    return text if len(text) <= n else text[: n - 1] + "..."


def budget_drawing(rows, width: float = 480, row_h: float = 20, title: str | None = None) -> Drawing:
    """rows: [(label, budget_fils, actual_fils, committed_fils)].

    Pale bar = budget. Dark = actual spend. Rose = committed (selected quotes). Red = the part over budget.
    """
    rows = list(rows)
    top = 26 if title else 8
    legend_h = 26
    height = top + len(rows) * row_h + legend_h + 6
    d = Drawing(width, height)
    if title:
        d.add(String(0, height - 14, title, fontSize=10, fontName="Helvetica-Bold", fillColor=BURGUNDY))
    if not rows:
        d.add(String(0, height - top - 12, "No budget or spending recorded yet.", fontName="Helvetica", fontSize=8, fillColor=INK))
        return d
    label_w, value_w = 105, 92
    x0, plot_w = label_w, width - label_w - value_w
    scale = max(max(b, a + c) for _l, b, a, c in rows) or 1
    for i, (label, budget, actual, committed) in enumerate(rows):
        y = height - top - (i + 1) * row_h + 4
        bar_h = row_h - 8
        d.add(String(0, y + 2, _clip(label), fontName="Helvetica", fontSize=8, fillColor=INK))
        if budget:
            d.add(Rect(x0, y, budget / scale * plot_w, bar_h, fillColor=TRACK, strokeColor=GOLD, strokeWidth=0.6))
        a_w, c_w = actual / scale * plot_w, committed / scale * plot_w
        if a_w:
            d.add(Rect(x0, y + 1.5, a_w, bar_h - 3, fillColor=BURGUNDY, strokeColor=None))
        if c_w:
            d.add(Rect(x0 + a_w, y + 1.5, c_w, bar_h - 3, fillColor=ROSE, strokeColor=None))
        projected = actual + committed
        if budget and projected > budget:
            over_x = x0 + budget / scale * plot_w
            d.add(Rect(over_x, y + 1.5, (projected - budget) / scale * plot_w, bar_h - 3, fillColor=RED, strokeColor=None))
            d.add(Line(over_x, y - 2, over_x, y + bar_h + 2, strokeColor=INK, strokeWidth=0.8))
        text = (f"{format_axis(projected)} / {format_axis(budget)}" if budget else f"{format_axis(projected)} (no budget)")
        d.add(String(width, y + 2, text, fontName="Helvetica", fontSize=7.5, fillColor=RED if budget and projected > budget else INK,
                     textAnchor="end"))
    # legend
    lx, ly = x0, 6
    for text, fill, stroke in (("Budget", TRACK, GOLD), ("Actual", BURGUNDY, None), ("Committed", ROSE, None),
                               ("Over budget", RED, None)):
        d.add(Rect(lx, ly, 9, 7, fillColor=fill, strokeColor=stroke, strokeWidth=0.5))
        d.add(String(lx + 12, ly, text, fontName="Helvetica", fontSize=7.5, fillColor=INK))
        lx += 12 + 5.2 * len(text) + 14
    return d


def add_excel_budget_chart(ws, first_row: int, last_row: int, anchor: str, title: str,
                           cat_col: int, budget_col: int, actual_col: int, committed_col: int | None = None) -> None:
    """A clustered horizontal bar chart: budget vs actual (vs committed) per row of the sheet."""
    if last_row < first_row:
        return
    chart = BarChart()
    chart.type = "bar"
    chart.style = 10
    chart.title = title
    chart.height, chart.width = 9 + 0.6 * (last_row - first_row), 18
    cols = [(budget_col, "Budget"), (actual_col, "Actual")] + ([(committed_col, "Committed")] if committed_col else [])
    for col, name in cols:
        data = Reference(ws, min_col=col, min_row=first_row, max_row=last_row)
        chart.add_data(data, titles_from_data=False)
        chart.series[-1].tx = SeriesLabel(v=name)
    chart.set_categories(Reference(ws, min_col=cat_col, min_row=first_row, max_row=last_row))
    chart.y_axis.title = "AED"
    chart.y_axis.numFmt = "#,##0"
    chart.y_axis.delete = False
    chart.x_axis.delete = False
    ws.add_chart(chart, anchor)
