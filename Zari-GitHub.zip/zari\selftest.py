"""Built-in health check:  Zari.exe --selftest <result-file>

Exercises every feature that loads libraries on demand (PDF/Excel export, PDF reading, camera support,
charts, accounts, the main window) against a throw-away data folder, and writes one line per check to the
result file. It is how the packaged .exe is verified to contain everything it needs.
"""
from __future__ import annotations

import os
import sys
import tempfile
import traceback
from datetime import date
from pathlib import Path


def run(out_path: str) -> int:
    lines: list[str] = []
    failures = 0

    def check(name, fn):
        nonlocal failures
        try:
            detail = fn()
            lines.append(f"OK    {name}" + (f"  ({detail})" if detail else ""))
        except Exception:  # noqa: BLE001 - we want every failure reported, not just the first
            failures += 1
            lines.append(f"FAIL  {name}\n{traceback.format_exc()}")

    tmp = Path(tempfile.mkdtemp(prefix="zari_selftest_"))
    os.environ["ZARI_DATA_DIR"] = str(tmp)

    from PySide6.QtWidgets import QApplication
    app = QApplication.instance() or QApplication(sys.argv[:1])
    state: dict = {}

    def theme_and_fonts():
        from zari.ui import theme
        info = theme.init_fonts()
        app.setStyleSheet(theme.stylesheet())
        return f"{info['heading']} / {info['body']}"

    def accounts():
        from zari import config
        from zari.auth import AccountStore
        store = AccountStore()
        acct = store.create("selftest", "Self Test", "SelfTest2026")
        assert store.verify("selftest", "SelfTest2026").is_owner
        config.set_current_user(acct.username)
        state["store"], state["account"] = store, acct

    def database_and_sample_data():
        from zari import config
        from zari.db.database import Database
        from zari.db.repository import Repository
        db = Database(config.db_path())
        repo = Repository(db)
        repo.seed_sample_data()
        state["repo"] = repo
        return f"{len(repo.list_events())} events"

    def main_window_all_pages():
        from zari.ui.context import AppContext
        from zari.ui.main_window import MainWindow
        w = MainWindow(AppContext(state["repo"]), state["account"], state["store"])
        w.show()
        app.processEvents()
        for key in w.pages:
            w.show_page(key)
            app.processEvents()
        ev = state["repo"].list_events()[0]
        w.open_panel(ev.id)
        w.panel.set_expanded(True)
        app.processEvents()
        assert not w.grab().isNull()
        state["window"] = w
        return f"{len(w.pages)} pages, full-screen panel"

    def dialogs():
        from zari.ui.guests_ui import GuestsDialog
        from zari.ui.quotes_ui import QuotesDialog
        from zari.ui.scenario_ui import ScenarioDialog
        w, repo = state["window"], state["repo"]
        ev = next(e for e in repo.list_events() if repo.guest_stats(e.id)["parties"])
        for cls in (QuotesDialog, GuestsDialog, ScenarioDialog):
            cls(w, w.ctx, ev.id).close()

    def excel_and_pdf_reports():
        from openpyxl import load_workbook
        from zari.exports.event_report import collect
        from zari.exports.excel_export import export_event_workbook
        from zari.exports.pdf_export import export_event_pdf
        from zari.exports.report_export import export_reports_excel, export_reports_pdf
        from zari.logic import reports
        repo = state["repo"]
        ev = next(e for e in repo.list_events() if repo.list_all_budgets().get(e.id))
        rep = collect(repo, ev.id, date.today())
        x = export_event_workbook(tmp / "event.xlsx", rep)
        p = export_event_pdf(tmp / "event.pdf", rep)
        assert len(load_workbook(x).sheetnames) == 9 and p.stat().st_size > 5000
        evs, exps, quo, bud = repo.list_events(), repo.list_all_expenses(), repo.list_all_quotes(), repo.list_all_budgets()
        export_reports_excel(tmp / "r.xlsx", reports.event_rows(evs, bud, exps, quo),
                             reports.budget_vs_actual(evs, bud, exps, quo), reports.vendor_payables(evs, exps))
        export_reports_pdf(tmp / "r.pdf", reports.event_rows(evs, bud, exps, quo),
                           reports.budget_vs_actual(evs, bud, exps, quo), reports.vendor_payables(evs, exps))
        state["pdf"] = p
        return f"event pdf {p.stat().st_size // 1024} KB"

    def pdf_reading_and_invoice_parsing():
        from zari.ocr import invoice_reader, pdf_reader
        text = pdf_reader.embedded_text(state["pdf"])
        assert "Financial summary" in text
        pdf_reader.render_page(state["pdf"], 0, 400)
        fields = invoice_reader.parse_invoice_text("Acme Decor\nInvoice Date: 12/10/2026\nGrand Total AED 1,250.00") \
            if hasattr(invoice_reader, "parse_invoice_text") else None
        from zari.ocr.invoice_parser import parse_invoice_text
        assert parse_invoice_text("Acme Decor\nInvoice Date: 12/10/2026\nGrand Total AED 1,250.00").total_aed == "1250"
        import pytesseract  # noqa: F401  (the Python wrapper; Tesseract itself is optional)
        from PIL import Image  # noqa: F401
        return "tesseract " + ("found" if invoice_reader.find_tesseract() else "not installed (optional)")

    def camera_support():
        from zari.ui import camera_dialog
        return f"{len(camera_dialog.QMediaDevices.videoInputs())} camera(s) detected"

    def calendar_files():
        from zari.logic.calendar_export import build_ics, google_calendar_url
        ev = state["repo"].list_events()[0]
        assert "BEGIN:VCALENDAR" in build_ics([ev]) and google_calendar_url(ev).startswith("https://")

    for name, fn in (("theme and fonts", theme_and_fonts), ("accounts and passwords", accounts),
                     ("database and sample data", database_and_sample_data), ("main window and every page", main_window_all_pages),
                     ("quotes / guests / scenario windows", dialogs), ("Excel and PDF reports", excel_and_pdf_reports),
                     ("PDF reading and invoice parsing", pdf_reading_and_invoice_parsing), ("camera support", camera_support),
                     ("calendar files", calendar_files)):
        check(name, fn)

    if state.get("window") is not None:
        state["window"].signing_out = True
        state["window"].close()
    lines.append("SELFTEST " + ("PASSED" if not failures else f"FAILED ({failures})"))
    Path(out_path).write_text("\n".join(lines) + "\n", encoding="utf-8")
    return 1 if failures else 0
