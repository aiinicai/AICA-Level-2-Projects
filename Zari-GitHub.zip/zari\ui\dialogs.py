"""Pop-up forms (event, payment, expense) and the confirmation helper."""
from __future__ import annotations

from datetime import date

from PySide6.QtCore import QDate, Qt
from PySide6.QtWidgets import (
    QComboBox, QCompleter, QDateEdit, QDialog, QHBoxLayout, QLineEdit, QMessageBox, QSpinBox, QVBoxLayout, QWidget,
)

from zari.config import EVENT_STATUSES, EVENT_TYPES, EXPENSE_CATEGORIES
from zari.logic.money import format_input
from zari.logic.validation import (
    ValidationError, validate_event, validate_expense, validate_payment,
)
from zari.ui import theme
from zari.ui.widgets import make_button, make_label, set_label_color


def to_qdate(d: date) -> QDate:
    return QDate(d.year, d.month, d.day)


def from_qdate(q: QDate) -> date:
    return date(q.year(), q.month(), q.day())


def make_date_edit(d: date | None = None) -> QDateEdit:
    e = QDateEdit()
    e.setCalendarPopup(True)
    e.setDisplayFormat("dd MMM yyyy")
    e.setDate(to_qdate(d or date.today()))
    return e


class OptionalDateField(QWidget):
    """A date that may be left empty ("Not set"), with a clear button."""

    EMPTY = QDate(2000, 1, 1)

    def __init__(self, d: date | None = None):
        super().__init__()
        self.setObjectName("Transparent")
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(4)
        self.edit = QDateEdit()
        self.edit.setCalendarPopup(True)
        self.edit.setDisplayFormat("dd MMM yyyy")
        self.edit.setMinimumDate(self.EMPTY)
        self.edit.setSpecialValueText("Not set")
        row.addWidget(self.edit, 1)
        from zari.ui.widgets import icon_button
        clear = icon_button("close", "Clear the date")
        clear.clicked.connect(self.clear)
        row.addWidget(clear)
        self.set_value(d)

    def set_value(self, d: date | None) -> None:
        self.edit.setDate(to_qdate(d) if d else self.EMPTY)

    def clear(self) -> None:
        self.edit.setDate(self.EMPTY)

    def value(self) -> date | None:
        return None if self.edit.date() == self.EMPTY else from_qdate(self.edit.date())


def confirm(parent, title: str, text: str, action: str = "Delete", danger: bool = True) -> bool:
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(f"<b>{title}</b>")
    box.setInformativeText(text)
    box.setIcon(QMessageBox.Icon.NoIcon)
    cancel = box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
    go = box.addButton(action, QMessageBox.ButtonRole.AcceptRole)
    go.setProperty("variant", "danger" if danger else "primary")
    cancel.setCursor(Qt.CursorShape.PointingHandCursor)
    go.setCursor(Qt.CursorShape.PointingHandCursor)
    box.setDefaultButton(cancel)
    box.exec()
    return box.clickedButton() is go


def info(parent, title: str, text: str) -> None:
    box = QMessageBox(parent)
    box.setWindowTitle(title)
    box.setText(f"<b>{title}</b>")
    box.setInformativeText(text)
    box.setIcon(QMessageBox.Icon.NoIcon)
    box.addButton("OK", QMessageBox.ButtonRole.AcceptRole).setProperty("variant", "primary")
    box.exec()


class FormDialog(QDialog):
    """Base class: titled form with per-field error messages and Save / Cancel."""

    def __init__(self, parent, title: str, eyebrow: str, width: int = 480):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setModal(True)
        self.setMinimumWidth(width)
        self._rows: dict[str, tuple[QWidget, object]] = {}
        root = QVBoxLayout(self)
        root.setContentsMargins(28, 24, 28, 22)
        root.setSpacing(4)
        root.addWidget(make_label(eyebrow, "eyebrow"))
        root.addWidget(make_label(title, "h2"))
        root.addSpacing(8)
        self.form = QVBoxLayout()
        self.form.setSpacing(2)
        root.addLayout(self.form)
        self.error_banner = make_label("", "small", color=theme.DANGER, wrap=True)
        self.error_banner.hide()
        root.addWidget(self.error_banner)
        root.addSpacing(10)
        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.cancel_btn = make_button("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        self.save_btn = make_button("Save", "primary")
        self.save_btn.setDefault(True)
        self.save_btn.clicked.connect(self._on_save)
        buttons.addWidget(self.cancel_btn)
        buttons.addWidget(self.save_btn)
        root.addLayout(buttons)

    def add_field(self, key: str, label: str, widget: QWidget, row_with: str | None = None) -> None:
        err = make_label("", "small", color=theme.DANGER)
        err.hide()
        block = QVBoxLayout()
        block.setSpacing(3)
        block.addWidget(make_label(label, "eyebrow"))
        block.addWidget(widget)
        block.addWidget(err)
        self._rows[key] = (widget, err)
        if row_with and getattr(self, "_pair_row", None) is not None:
            self._pair_row.addLayout(block)
            self._pair_row = None
        elif row_with == "start":
            self._pair_row = QHBoxLayout()
            self._pair_row.setSpacing(14)
            self._pair_row.addLayout(block)
            self.form.addLayout(self._pair_row)
        else:
            self.form.addLayout(block)

    def show_errors(self, errors: dict[str, str]) -> None:
        first = None
        for key, (widget, err) in self._rows.items():
            msg = errors.get(key)
            widget.setProperty("invalid", bool(msg))
            widget.style().unpolish(widget)
            widget.style().polish(widget)
            err.setText(msg or "")
            err.setVisible(bool(msg))
            if msg and first is None:
                first = widget
        extra = [m for k, m in errors.items() if k not in self._rows]
        self.error_banner.setText("\n".join(extra))
        self.error_banner.setVisible(bool(extra))
        if first is not None:
            first.setFocus()

    def collect(self) -> dict:  # pragma: no cover - implemented by subclasses
        raise NotImplementedError

    def _on_save(self) -> None:
        try:
            self.result_data = self.collect()
        except ValidationError as exc:
            self.show_errors(exc.errors)
            return
        self.show_errors({})
        self.accept()


class EventDialog(FormDialog):
    def __init__(self, parent, event=None):
        super().__init__(parent, "Edit event" if event else "New event", "Event details", width=560)
        self.name = QLineEdit(event.name if event else "")
        self.name.setPlaceholderText("e.g. Kapoor-Mehta Royal Wedding")
        self.client = QLineEdit(event.client if event else "")
        self.type = QComboBox()
        self.type.addItems(EVENT_TYPES)
        self.status = QComboBox()
        self.status.addItems(EVENT_STATUSES)
        self.date = make_date_edit(event.date if event else None)
        self.venue = QLineEdit(event.venue if event else "")
        self.venue.setPlaceholderText("e.g. Emirates Palace, Abu Dhabi")
        self.guests = QSpinBox()
        self.guests.setRange(0, 50_000)
        self.guests.setValue(event.guests if event else 100)
        self.contract = QLineEdit(format_input(event.contract_value) if event else "")
        self.contract.setPlaceholderText("e.g. 385,000")
        if event:
            self.type.setCurrentText(event.type)
            self.status.setCurrentText(event.status)
        else:
            self.status.setCurrentText("Enquiry")
        self.add_field("name", "Event name", self.name)
        self.add_field("client", "Client name", self.client)
        self.add_field("type", "Type", self.type, row_with="start")
        self.add_field("status", "Status", self.status, row_with="end")
        self.add_field("date", "Date", self.date, row_with="start")
        self.add_field("guests", "Guest count", self.guests, row_with="end")
        self.add_field("venue", "Venue", self.venue)
        self.add_field("contract", "Contract value (AED)", self.contract)

    def collect(self) -> dict:
        return validate_event(self.name.text(), self.client.text(), self.type.currentText(),
                              from_qdate(self.date.date()), self.venue.text(), self.guests.value(),
                              self.status.currentText(), self.contract.text())


class PaymentDialog(FormDialog):
    def __init__(self, parent, payment=None, suggested_label: str = "Deposit"):
        super().__init__(parent, "Edit payment" if payment else "Record payment", "Payment received")
        self.amount = QLineEdit(format_input(payment.amount) if payment else "")
        self.amount.setPlaceholderText("e.g. 50,000")
        self.date = make_date_edit(payment.date if payment else None)
        self.label = QComboBox()
        self.label.setEditable(True)
        self.label.addItems(["Deposit", "Second instalment", "Balance", "Final balance", "Extras"])
        self.label.setCurrentText(payment.label if payment else suggested_label)
        self.add_field("amount", "Amount (AED)", self.amount)
        self.add_field("date", "Date received", self.date, row_with="start")
        self.add_field("label", "Label", self.label, row_with="end")

    def collect(self) -> dict:
        return validate_payment(self.amount.text(), from_qdate(self.date.date()), self.label.currentText())


class ExpenseDialog(FormDialog):
    def __init__(self, parent, expense=None, vendor_names=()):
        super().__init__(parent, "Edit expense" if expense else "Add expense", "Vendor cost")
        self.category = QComboBox()
        self.category.addItems(EXPENSE_CATEGORIES)
        self.description = QLineEdit(expense.description if expense else "")
        self.description.setPlaceholderText("e.g. Mandap florals and draping")
        self.vendor = QLineEdit(expense.vendor if expense else "")
        self.vendor.setPlaceholderText("Optional - start typing to pick a saved vendor")
        completer = QCompleter(list(vendor_names), self.vendor)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.vendor.setCompleter(completer)
        self.amount = QLineEdit(format_input(expense.amount) if expense else "")
        self.amount.setPlaceholderText("e.g. 12,500")
        self.due = OptionalDateField(expense.due_date if expense else None)
        if expense:
            self.category.setCurrentText(expense.category)
        self.add_field("category", "Category", self.category)
        self.add_field("description", "Description", self.description)
        self.add_field("vendor", "Vendor", self.vendor, row_with="start")
        self.add_field("amount", "Amount (AED)", self.amount, row_with="end")
        self.add_field("due", "Payment due date (optional)", self.due)

    def collect(self) -> dict:
        return validate_expense(self.category.currentText(), self.description.text(),
                                self.amount.text(), self.vendor.text(), due=self.due.value())
