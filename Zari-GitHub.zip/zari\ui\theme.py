"""Colours, fonts and the global Qt stylesheet (luxury Indian wedding invitation look)."""
from __future__ import annotations

from PySide6.QtGui import QColor, QFont, QFontDatabase

from zari.config import ASSETS_DIR

# ---- palette ----------------------------------------------------------------------
BURGUNDY = "#5E1530"        # page background
BURGUNDY_DEEP = "#47102A"   # sidebar, inputs
CARD = "#6D1F3C"            # slightly lighter burgundy fill for cards
CARD_HI = "#7B2948"         # hover
ROSE = "#C9738F"            # secondary
GOLD = "#C9A961"            # borders, icons, highlights
GOLD_SOFT = "#E3CC94"
IVORY = "#FBF5EC"           # text
IVORY_MUTED = "#D9C7BD"
SUCCESS = "#6CC08B"
WARNING = "#E8B04A"
DANGER = "#EF6A5E"

LEVEL_COLORS = {"success": SUCCESS, "warning": WARNING, "danger": DANGER, "muted": IVORY_MUTED}
STATUS_COLORS = {
    "Enquiry": ROSE, "Confirmed": SUCCESS, "In Progress": WARNING,
    "Completed": GOLD, "Cancelled": DANGER,
}
PRIORITY_COLORS = {"Low": IVORY_MUTED, "Medium": WARNING, "High": DANGER}

HEADING_FONT = "Georgia"
BODY_FONT = "Segoe UI"


def qcolor(hex_: str, alpha: float = 1.0) -> QColor:
    c = QColor(hex_)
    c.setAlphaF(alpha)
    return c


def rgba(hex_: str, alpha: float) -> str:
    c = QColor(hex_)
    return f"rgba({c.red()},{c.green()},{c.blue()},{alpha})"


def init_fonts() -> dict:
    """Load any fonts dropped into assets/fonts, then pick the best available families."""
    global HEADING_FONT, BODY_FONT
    for f in (ASSETS_DIR / "fonts").glob("*.[to]tf"):
        QFontDatabase.addApplicationFont(str(f))
    families = set(QFontDatabase.families())

    def pick(options):
        return next((o for o in options if o in families), options[-1])

    HEADING_FONT = pick(["Cormorant Garamond", "Cormorant", "Palatino Linotype", "Georgia"])
    BODY_FONT = pick(["Inter", "Segoe UI Variable Text", "Segoe UI"])
    return {"heading": HEADING_FONT, "body": BODY_FONT,
            "premium_fonts": HEADING_FONT.startswith("Cormorant") and BODY_FONT == "Inter"}


def heading_font(size_pt: float, bold: bool = False) -> QFont:
    f = QFont(HEADING_FONT, 10)
    f.setPointSizeF(size_pt)
    f.setWeight(QFont.Weight.DemiBold if bold else QFont.Weight.Medium)
    return f


def stylesheet() -> str:
    g, iv = GOLD, IVORY
    return f"""
* {{ font-family: "{BODY_FONT}"; color: {iv}; outline: none; }}
QMainWindow, QDialog, QMessageBox {{ background: {BURGUNDY}; }}
QWidget#PageRoot, QWidget#Transparent, QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; }}
QLabel {{ background: transparent; }}
QToolTip {{ background: {BURGUNDY_DEEP}; color: {iv}; border: 1px solid {g}; padding: 6px 8px; }}

QFrame#Card {{
    background: {CARD}; border: 1px solid {rgba(g, 0.55)}; border-radius: 16px;
}}
QFrame#CardInner {{
    background: {rgba('#000000', 0.16)}; border: 1px solid {rgba(g, 0.18)}; border-radius: 12px;
}}
QFrame#Sidebar {{ background: {BURGUNDY_DEEP}; border-right: 1px solid {rgba(g, 0.45)}; }}
QFrame#SidePanel {{ background: {BURGUNDY}; border-left: 1px solid {g}; }}
QFrame#Divider {{ background: {rgba(g, 0.25)}; max-height: 1px; min-height: 1px; border: none; }}

/* ---------- buttons ---------- */
QPushButton {{
    background: transparent; border: 1px solid {rgba(g, 0.7)}; border-radius: 10px;
    padding: 8px 16px; color: {iv}; font-weight: 500;
}}
QPushButton:hover {{ background: {rgba(g, 0.16)}; border-color: {g}; }}
QPushButton:pressed {{ background: {rgba(g, 0.28)}; }}
QPushButton:disabled {{ color: {rgba(iv, 0.35)}; border-color: {rgba(g, 0.25)}; }}
QPushButton[variant="primary"] {{
    background: {g}; color: {BURGUNDY_DEEP}; border: 1px solid {g}; font-weight: 700;
}}
QPushButton[variant="primary"]:hover {{ background: {GOLD_SOFT}; }}
QPushButton[variant="primary"]:disabled {{ background: {rgba(g, 0.35)}; color: {rgba(BURGUNDY_DEEP, 0.7)}; }}
QPushButton[variant="danger"] {{ border-color: {rgba(DANGER, 0.7)}; color: {DANGER}; }}
QPushButton[variant="danger"]:hover {{ background: {rgba(DANGER, 0.18)}; border-color: {DANGER}; }}
QPushButton[variant="icon"] {{ border: none; padding: 5px; border-radius: 8px; }}
QPushButton[variant="icon"]:hover {{ background: {rgba(g, 0.2)}; }}
QPushButton[variant="pill"] {{ border-radius: 14px; padding: 5px 14px; font-size: 12px; }}
QPushButton[variant="pill"]:checked {{ background: {g}; color: {BURGUNDY_DEEP}; font-weight: 700; }}
QPushButton[variant="nav"] {{
    border: none; border-radius: 10px; padding: 11px 14px; text-align: left; font-size: 14px;
    color: {IVORY_MUTED};
}}
QPushButton[variant="nav"]:hover {{ background: {rgba(g, 0.12)}; color: {iv}; }}
QPushButton[variant="nav"]:checked {{
    background: {rgba(g, 0.18)}; color: {iv}; border: 1px solid {rgba(g, 0.55)};
}}
QPushButton[variant="link"] {{
    border: none; background: transparent; color: {g}; padding: 2px 4px; text-decoration: underline;
}}

/* ---------- inputs ---------- */
QLineEdit, QTextEdit, QPlainTextEdit, QSpinBox, QDoubleSpinBox, QDateEdit, QComboBox {{
    background: {BURGUNDY_DEEP}; border: 1px solid {rgba(g, 0.5)}; border-radius: 9px;
    padding: 7px 10px; color: {iv}; selection-background-color: {g}; selection-color: {BURGUNDY_DEEP};
    min-height: 20px;
}}
QLineEdit:focus, QTextEdit:focus, QSpinBox:focus, QDateEdit:focus, QComboBox:focus {{ border: 1px solid {g}; }}
QLineEdit[invalid="true"], QComboBox[invalid="true"], QDateEdit[invalid="true"], QSpinBox[invalid="true"] {{
    border: 1px solid {DANGER};
}}
QLineEdit[warn="true"], QComboBox[warn="true"], QDateEdit[warn="true"] {{ border: 1px solid {WARNING}; }}
QComboBox::drop-down, QDateEdit::drop-down {{ border: none; width: 26px; }}
QComboBox::down-arrow, QDateEdit::down-arrow {{ image: none; width: 0; height: 0;
    border-left: 5px solid transparent; border-right: 5px solid transparent; border-top: 6px solid {g}; margin-right: 8px; }}
QComboBox QAbstractItemView {{
    background: {BURGUNDY_DEEP}; border: 1px solid {g}; selection-background-color: {rgba(g, 0.35)};
    selection-color: {iv}; padding: 4px; outline: none;
}}
QCalendarWidget QWidget {{ background: {BURGUNDY_DEEP}; color: {iv}; }}
QCalendarWidget QToolButton {{ color: {iv}; background: transparent; padding: 4px 8px; border: none; }}
QCalendarWidget QAbstractItemView:enabled {{ color: {iv}; selection-background-color: {g}; selection-color: {BURGUNDY_DEEP}; }}
QCalendarWidget QAbstractItemView:disabled {{ color: {rgba(iv, 0.3)}; }}

QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 18px; height: 18px; border: 1px solid {g}; border-radius: 5px; background: transparent; }}
QCheckBox::indicator:checked {{ background: {g}; image: url(none); }}

/* ---------- scrollbars ---------- */
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {rgba(g, 0.4)}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {rgba(g, 0.7)}; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {rgba(g, 0.4)}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line, QScrollBar::add-page, QScrollBar::sub-page {{ background: none; border: none; width: 0; height: 0; }}

/* ---------- tables ---------- */
QTableWidget, QTableView {{
    background: {rgba('#000000', 0.14)}; alternate-background-color: {rgba('#000000', 0.06)};
    border: 1px solid {rgba(g, 0.3)}; border-radius: 10px; gridline-color: {rgba(g, 0.12)};
    selection-background-color: {rgba(g, 0.28)}; selection-color: {iv};
}}
QTableWidget::item {{ padding: 5px 8px; border: none; }}
QHeaderView::section {{
    background: {BURGUNDY_DEEP}; color: {g}; border: none; border-bottom: 1px solid {rgba(g, 0.5)};
    padding: 7px 8px; font-weight: 600; font-size: 11px;
}}
QTableCornerButton::section {{ background: {BURGUNDY_DEEP}; border: none; }}

QMessageBox QLabel {{ color: {iv}; font-size: 13px; }}
QProgressBar {{ background: {rgba('#000000', 0.3)}; border: 1px solid {rgba(g, 0.4)}; border-radius: 6px; height: 10px; text-align: center; }}
QProgressBar::chunk {{ background: {g}; border-radius: 5px; }}
"""
