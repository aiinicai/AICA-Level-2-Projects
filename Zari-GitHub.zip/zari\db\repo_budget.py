"""Budgets, contingency and what-if scenarios (mixed into Repository)."""
from __future__ import annotations

from zari.db.models import Scenario


class BudgetMixin:
    # ---- budgets --------------------------------------------------------------------
    def get_budgets(self, event_id: int) -> dict[str, int]:
        rows = self.conn.execute("SELECT category, amount FROM budgets WHERE event_id=?", (event_id,)).fetchall()
        return {r["category"]: r["amount"] for r in rows}

    def list_all_budgets(self) -> dict[int, dict[str, int]]:
        out: dict[int, dict[str, int]] = {}
        for r in self.conn.execute("SELECT event_id, category, amount FROM budgets"):
            out.setdefault(r["event_id"], {})[r["category"]] = r["amount"]
        return out

    def set_budget(self, event_id: int, category: str, amount: int) -> None:
        """A budget of 0 clears that category's allocation."""
        with self.conn:
            if amount <= 0:
                self.conn.execute("DELETE FROM budgets WHERE event_id=? AND category=?", (event_id, category))
            else:
                self.conn.execute(
                    "INSERT INTO budgets (event_id, category, amount) VALUES (?,?,?)"
                    " ON CONFLICT(event_id, category) DO UPDATE SET amount=excluded.amount",
                    (event_id, category, amount))

    def set_contingency(self, event_id: int, bp: int) -> None:
        with self.conn:
            self.conn.execute("UPDATE events SET contingency_bp=? WHERE id=?", (bp, event_id))

    # ---- scenarios ------------------------------------------------------------------
    def list_scenarios(self, event_id: int) -> list[Scenario]:
        out = []
        for r in self.conn.execute("SELECT * FROM scenarios WHERE event_id=? ORDER BY id", (event_id,)).fetchall():
            adj = {a["category"]: a["change_bp"] for a in
                   self.conn.execute("SELECT * FROM scenario_adjust WHERE scenario_id=?", (r["id"],))}
            per_guest = tuple(c for c in r["per_guest_categories"].split(",") if c)
            out.append(Scenario(r["id"], r["event_id"], r["name"], r["guests"], r["contract_bp"],
                                r["contingency_bp"], per_guest, adj))
        return out

    def save_scenario(self, event_id: int, data: dict) -> int:
        """Store a what-if plan. This NEVER changes the event, its payments or its expenses."""
        with self.conn:
            cur = self.conn.execute(
                "INSERT INTO scenarios (event_id, name, guests, contract_bp, contingency_bp, per_guest_categories)"
                " VALUES (?,?,?,?,?,?)",
                (event_id, data["name"], data["guests"], data["contract_bp"], data["contingency_bp"],
                 ",".join(data["per_guest"])))
            self.conn.executemany(
                "INSERT INTO scenario_adjust (scenario_id, category, change_bp) VALUES (?,?,?)",
                [(cur.lastrowid, c, bp) for c, bp in data["adjust_bp"].items()])
        return cur.lastrowid

    def delete_scenario(self, scenario_id: int) -> None:
        with self.conn:
            self.conn.execute("DELETE FROM scenarios WHERE id=?", (scenario_id,))

    def apply_scenario(self, event_id: int, guests: int, contract_value: int, contingency_bp: int) -> None:
        """The ONLY way a scenario touches real data: update guests, contract value and contingency.

        Expenses and payments are never altered. A safety backup is taken first.
        """
        self.db.safety_backup("before-apply-scenario")
        with self.conn:
            self.conn.execute("UPDATE events SET guests=?, contract_value=?, contingency_bp=? WHERE id=?",
                              (guests, contract_value, contingency_bp, event_id))
