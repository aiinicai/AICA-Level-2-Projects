"""Dashboard alerts: late vendor payments, budget overruns, loss-making events, expiring quotes."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, timedelta

from zari.logic import budget as budget_logic
from zari.logic.money import format_aed

SOON_DAYS = 7
_ORDER = {"danger": 0, "warning": 1, "info": 2}


@dataclass(frozen=True)
class Alert:
    level: str        # danger | warning | info
    text: str
    event_id: int | None


def build_alerts(summaries, expenses, budgets_by_event: dict, quotes, today: date, limit: int | None = 8) -> list[Alert]:
    events = {e.id: e for e in summaries if e.is_active}
    out: list[Alert] = []
    soon = today + timedelta(days=SOON_DAYS)

    for x in expenses:
        ev = events.get(x.event_id)
        if ev is None or x.paid or x.due_date is None:
            continue
        who = x.vendor or x.description
        if x.due_date < today:
            out.append(Alert("danger", f"Overdue: {format_aed(x.amount)} to {who} was due "
                                       f"{x.due_date:%d %b} ({ev.name})", ev.id))
        elif x.due_date <= soon:
            out.append(Alert("warning", f"Due {x.due_date:%d %b}: {format_aed(x.amount)} to {who} ({ev.name})", ev.id))

    quotes_by_event: dict[int, list] = {}
    for q in quotes:
        quotes_by_event.setdefault(q.event_id, []).append(q)
    expenses_by_event: dict[int, list] = {}
    for x in expenses:
        expenses_by_event.setdefault(x.event_id, []).append(x)

    for eid, ev in events.items():
        lines = budget_logic.category_lines(budgets_by_event.get(eid, {}), expenses_by_event.get(eid, []),
                                            quotes_by_event.get(eid, []))
        for l in lines:
            if l.status == "over":
                out.append(Alert("danger", f"{l.category} is over budget by {format_aed(-l.remaining)} ({ev.name})", eid))
            elif l.status == "warning":
                out.append(Alert("warning", f"{l.category} has used {l.used_pct:.0f}% of its budget ({ev.name})", eid))
        f = ev.fin
        if f.contract > 0 and f.profit < 0:
            out.append(Alert("danger", f"{ev.name} is making a loss of {format_aed(-f.profit)}", eid))
        if ev.status == "Completed" and f.balance_due > 0:
            out.append(Alert("warning", f"{ev.name} is completed but {format_aed(f.balance_due)} is still owed", eid))
        for q in quotes_by_event.get(eid, []):
            if q.valid_until and not q.expense_id and q.status in ("Requested", "Received", "Selected"):
                if q.valid_until < today and q.status == "Selected":
                    out.append(Alert("danger", f"Selected quote from {q.vendor_name} expired {q.valid_until:%d %b} ({ev.name})", eid))
                elif today <= q.valid_until <= soon:
                    out.append(Alert("warning", f"Quote from {q.vendor_name} expires {q.valid_until:%d %b} ({ev.name})", eid))

    out.sort(key=lambda a: _ORDER[a.level])
    return out if limit is None else out[:limit]
