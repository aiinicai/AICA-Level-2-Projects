"""Read invoices that arrive as PDF.

Digital PDFs (exported from accounting software) contain real text, which is far more accurate
than OCR - so Zari uses that first. Scanned PDFs have no text layer; their pages are rendered to
images and passed to Tesseract instead. Uses Qt's built-in PDF engine: nothing extra to install.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize
from PySide6.QtGui import QImage
from PySide6.QtPdf import QPdfDocument

MAX_PAGES = 6            # invoices are short; protects against a 500-page file freezing the app
MIN_TEXT_CHARS = 25      # fewer characters than this means "scanned image, no real text layer"
RENDER_WIDTH = 1800      # pixels: sharp enough for OCR


class PdfError(Exception):
    """User-readable reason the PDF could not be read."""


def _open(path: Path) -> QPdfDocument:
    doc = QPdfDocument()
    err = doc.load(str(path))
    if err != QPdfDocument.Error.None_:
        name = getattr(err, "name", str(err))
        if "Password" in name:
            raise PdfError("This PDF is password protected. Remove the password and try again.")
        raise PdfError("This PDF could not be opened (it may be damaged).")
    if doc.pageCount() == 0:
        raise PdfError("This PDF has no pages.")
    return doc


def page_count(path: str | Path) -> int:
    return _open(Path(path)).pageCount()


def embedded_text(path: str | Path) -> str:
    """Text stored inside the PDF itself (empty for scanned documents)."""
    doc = _open(Path(path))
    parts = []
    for page in range(min(doc.pageCount(), MAX_PAGES)):
        parts.append(doc.getAllText(page).text())
    return "\n".join(p.strip() for p in parts if p.strip())


def render_page(path: str | Path, page: int = 0, width: int = RENDER_WIDTH) -> QImage:
    doc = _open(Path(path))
    page = max(0, min(page, doc.pageCount() - 1))
    size = doc.pagePointSize(page)
    height = int(width * size.height() / size.width()) if size.width() else width
    image = doc.render(page, QSize(width, height))
    if image.isNull():
        raise PdfError("Could not draw this PDF page.")
    return image


def render_pages(path: str | Path, out_dir: Path) -> list[Path]:
    """Render up to MAX_PAGES pages to PNG files in `out_dir` (for OCR)."""
    doc = _open(Path(path))
    files = []
    for page in range(min(doc.pageCount(), MAX_PAGES)):
        file = out_dir / f"page_{page + 1}.png"
        if not render_page(path, page).save(str(file)):
            raise PdfError("Could not prepare the PDF pages for reading.")
        files.append(file)
    return files
