"""Scan an invoice photo -> review the detected fields -> save as an expense."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QCheckBox, QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit,
    QVBoxLayout, QWidget,
)

from zari.config import EXPENSE_CATEGORIES
from zari.logic import attachments
from zari.logic.money import format_aed
from zari.logic.validation import ValidationError, validate_expense
from zari.ocr import invoice_reader, pdf_reader
from zari.ocr.invoice_parser import InvoiceFields
from zari.ui import theme
from zari.ui.dialogs import confirm, from_qdate, info, make_date_edit, to_qdate
from zari.ui.widgets import Card, make_button, make_label, set_label_color

IMAGE_FILTER = "Invoices (*.jpg *.jpeg *.png *.tif *.tiff *.bmp *.webp *.pdf)"


class OcrWorker(QThread):
    finished_ok = Signal(object)
    failed = Signal(str, bool)  # message, tesseract_missing

    def __init__(self, path: str):
        super().__init__()
        self.path = path

    def run(self) -> None:
        try:
            self.finished_ok.emit(invoice_reader.read_invoice(self.path))
        except invoice_reader.OcrUnavailable as exc:
            self.failed.emit(str(exc), True)
        except Exception as exc:  # OcrFailed or anything unexpected: never crash the app
            self.failed.emit(str(exc), False)


def choose_invoice_file(parent) -> str | None:
    path, _ = QFileDialog.getOpenFileName(parent, "Choose an invoice (photo or PDF)", str(Path.home()), IMAGE_FILTER)
    return path or None


def _preview_pixmap(path: str) -> QPixmap:
    if path.lower().endswith(".pdf"):
        try:
            return QPixmap.fromImage(pdf_reader.render_page(path, 0, 720))
        except pdf_reader.PdfError:
            return QPixmap()
    return QPixmap(path)


class InvoiceDialog(QDialog):
    def __init__(self, parent, ctx, image_path: str, event_id: int | None = None, temp: bool = False):
        super().__init__(parent)
        self.ctx = ctx
        self.image_path = image_path
        self.temp = temp   # a camera photo saved in the temp folder: delete it when we are done
        self.setWindowTitle("Scan invoice")
        self.setModal(True)
        self.resize(960, 640)
        self._worker: OcrWorker | None = None

        root = QHBoxLayout(self)
        root.setContentsMargins(24, 22, 24, 20)
        root.setSpacing(22)

        # --- left: the photo ---
        left = QVBoxLayout()
        left.addWidget(make_label("Invoice PDF (first page)" if image_path.lower().endswith(".pdf")
                                  else "Invoice photo", "eyebrow"))
        self.preview = QLabel()
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(330, 440)
        pm = _preview_pixmap(image_path)
        if not pm.isNull():
            self.preview.setPixmap(pm.scaled(360, 520, Qt.AspectRatioMode.KeepAspectRatio,
                                             Qt.TransformationMode.SmoothTransformation))
        else:
            self.preview.setText("Preview not available")
        frame = Card(shadow=False, inner=True)
        fl = QVBoxLayout(frame)
        fl.addWidget(self.preview)
        left.addWidget(frame, 1)
        left.addWidget(make_label(Path(image_path).name, "small"))
        root.addLayout(left, 4)

        # --- right: the form ---
        right = QVBoxLayout()
        right.setSpacing(3)
        right.addWidget(make_label("Review before saving", "eyebrow"))
        right.addWidget(make_label("Scanned invoice", "h2"))
        self.status = make_label("Reading invoice...", "muted", wrap=True)
        right.addWidget(self.status)
        right.addSpacing(6)

        self.event_box = QComboBox()
        for e in ctx.repo.list_events():
            self.event_box.addItem(f"{e.name}  ({e.date:%d %b %Y})", e.id)
        if event_id is not None:
            self.event_box.setCurrentIndex(max(0, self.event_box.findData(event_id)))
        elif self.event_box.count():
            self.event_box.setCurrentIndex(-1)
            self.event_box.setPlaceholderText("Choose the event this cost belongs to")
        self.vendor = QLineEdit()
        self.invoice_no = QLineEdit()
        self.date = make_date_edit()
        self.category = QComboBox()
        self.category.addItems(EXPENSE_CATEGORIES)
        self.description = QLineEdit()
        self.amount = QLineEdit()
        self.amount.setPlaceholderText("Total in AED")
        self.paid = QCheckBox("Already paid to the vendor")
        self._hints: dict[str, QLabel] = {}
        self._widgets = {"event": self.event_box, "vendor": self.vendor, "date": self.date,
                         "category": self.category, "amount": self.amount, "description": self.description}

        right.addWidget(self._field("event", "Event", self.event_box))
        right.addWidget(self._field("vendor", "Vendor", self.vendor))
        pair = QHBoxLayout()
        pair.setSpacing(12)
        pair.addWidget(self._field("invoice_no", "Invoice no.", self.invoice_no))
        pair.addWidget(self._field("date", "Invoice date", self.date))
        right.addLayout(pair)
        pair2 = QHBoxLayout()
        pair2.setSpacing(12)
        pair2.addWidget(self._field("category", "Category", self.category))
        pair2.addWidget(self._field("amount", "Total (AED)", self.amount))
        right.addLayout(pair2)
        right.addWidget(self._field("description", "Description", self.description))
        right.addWidget(self.paid)

        self.vat_note = make_label("", "small")
        right.addWidget(self.vat_note)
        self.raw = QPlainTextEdit()
        self.raw.setReadOnly(True)
        self.raw.setMaximumHeight(90)
        self.raw.setPlaceholderText("Text recognised from the photo appears here.")
        right.addWidget(make_label("Recognised text", "eyebrow"))
        right.addWidget(self.raw)
        right.addStretch(1)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        self.cancel_btn = make_button("Cancel")
        self.cancel_btn.clicked.connect(self.reject)
        self.save_btn = make_button("Save expense", "primary", "check")
        self.save_btn.clicked.connect(self._save)
        buttons.addWidget(self.cancel_btn)
        buttons.addWidget(self.save_btn)
        right.addLayout(buttons)
        root.addLayout(right, 5)

        self._start_ocr()

    # ---- ui helpers -----------------------------------------------------------------
    def _field(self, key: str, label: str, widget: QWidget) -> QWidget:
        box = QWidget()
        box.setObjectName("Transparent")
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 2, 0, 2)
        lay.setSpacing(3)
        lay.addWidget(make_label(label, "eyebrow"))
        lay.addWidget(widget)
        hint = make_label("", "small", color=theme.WARNING)
        hint.hide()
        lay.addWidget(hint)
        self._hints[key] = hint
        return box

    def _flag(self, key: str, message: str | None, kind: str = "warn") -> None:
        widget = self._widgets.get(key)
        hint = self._hints.get(key)
        if widget is not None:
            widget.setProperty("warn", kind == "warn" and bool(message))
            widget.setProperty("invalid", kind == "invalid" and bool(message))
            widget.style().unpolish(widget)
            widget.style().polish(widget)
        if hint is not None:
            hint.setText(message or "")
            set_label_color(hint, theme.DANGER if kind == "invalid" else theme.WARNING)
            hint.setVisible(bool(message))

    # ---- OCR ------------------------------------------------------------------------
    def _start_ocr(self) -> None:
        self.save_btn.setEnabled(False)
        self._worker = OcrWorker(self.image_path)
        self._worker.finished_ok.connect(self._on_result)
        self._worker.failed.connect(self._on_failed)
        self._worker.start()

    def _on_result(self, r: InvoiceFields) -> None:
        self.save_btn.setEnabled(True)
        self.vendor.setText(r.vendor)
        self.invoice_no.setText(r.invoice_no)
        if r.invoice_date:
            self.date.setDate(to_qdate(r.invoice_date))
        self.category.setCurrentText(r.category)
        self.description.setText(r.description)
        self.amount.setText(r.total_aed)
        self.raw.setPlainText(r.raw_text)
        self.vat_note.setText(f"Detected VAT: {format_aed(round(float(r.vat_aed) * 100))} (included in the total)"
                              if r.vat_aed else "")
        checks = {"vendor": "Couldn't find the vendor name - please type it.",
                  "date": "Date not found clearly - please check it.",
                  "total": "Total not found clearly - please check the amount.",
                  "category": "Category is a guess - please confirm."}
        key_map = {"vendor": "vendor", "date": "date", "total": "amount", "category": "category"}
        for k, msg in checks.items():
            self._flag(key_map[k], msg if r.uncertain.get(k) else None)
        if any(r.uncertain.values()):
            self.status.setText("Invoice read. Highlighted fields need a quick check before you save.")
        else:
            self.status.setText("Invoice read. Everything looks complete - please confirm and save.")

    def _on_failed(self, message: str, missing: bool) -> None:
        self.save_btn.setEnabled(True)
        self.status.setText(message)
        set_label_color(self.status, theme.WARNING)
        self.raw.setPlaceholderText("No text could be read. You can still fill in the details by hand.")

    # ---- save -----------------------------------------------------------------------
    def _save(self) -> None:
        errors: dict[str, str] = {}
        event_id = self.event_box.currentData()
        if event_id is None:
            errors["event"] = "Choose the event this invoice belongs to."
        try:
            data = validate_expense(self.category.currentText(), self.description.text(), self.amount.text(),
                                    self.vendor.text(), self.invoice_no.text(), from_qdate(self.date.date()))
        except ValidationError as exc:
            errors.update(exc.errors)
            data = None
        for key in ("event", "vendor", "date", "category", "amount", "description"):
            self._flag(key, errors.get(key), "invalid")
        if errors or data is None:
            return

        dup = self.ctx.repo.find_duplicate_expense(event_id, data["amount"], data["vendor"], data["invoice_no"])
        if dup and not confirm(
            self, "Possible duplicate",
            f"This event already has an expense from {dup.vendor or 'this vendor'} for {format_aed(dup.amount)} "
            f"({dup.description}).\n\nSave this invoice anyway?", action="Save anyway", danger=False,
        ):
            return

        try:
            stored, original, size = attachments.store_file(Path(self.image_path), str(event_id))
        except attachments.AttachmentError as exc:
            self.status.setText(str(exc))
            set_label_color(self.status, theme.DANGER)
            return
        # One transaction's worth of work: the expense, then the document that proves it.
        expense_id = self.ctx.repo.add_expense(event_id, data, paid=self.paid.isChecked(), invoice_file=stored)
        title = " ".join(p for p in (data["vendor"], f"#{data['invoice_no']}" if data["invoice_no"] else "") if p)
        self.ctx.repo.add_document(event_id, {"kind": "Invoice", "title": title or "Scanned invoice"},
                                   stored, original, size, expense_id=expense_id)
        self.ctx.data_changed(f"Expense of {format_aed(data['amount'])} added from invoice")
        self.accept()

    def done(self, result: int) -> None:
        if self._worker is not None and self._worker.isRunning():
            self._worker.wait(15000)
        if self.temp:
            Path(self.image_path).unlink(missing_ok=True)
        super().done(result)


class ScanSourceDialog(QDialog):
    """Ask where the invoice comes from: a file (photo or PDF) or the camera."""

    def __init__(self, parent):
        super().__init__(parent)
        self.setWindowTitle("Scan an invoice")
        self.choice: str | None = None
        v = QVBoxLayout(self)
        v.setContentsMargins(28, 24, 28, 22)
        v.setSpacing(8)
        v.addWidget(make_label("Invoice scanner", "eyebrow"))
        v.addWidget(make_label("Where is the invoice?", "h2"))
        v.addWidget(make_label("Zari reads it on this PC and fills in the expense for you to review.", "muted", wrap=True))
        v.addSpacing(6)
        file_btn = make_button("Choose a photo or PDF from my computer", "primary", "scan")
        file_btn.setMinimumHeight(44)
        file_btn.clicked.connect(lambda: self._pick("file"))
        cam_btn = make_button("Take a photo with the camera", icon_name="scan")
        cam_btn.setMinimumHeight(44)
        cam_btn.clicked.connect(lambda: self._pick("camera"))
        cancel = make_button("Cancel", "link")
        cancel.clicked.connect(self.reject)
        for w in (file_btn, cam_btn):
            v.addWidget(w)
        v.addWidget(cancel, 0, Qt.AlignmentFlag.AlignCenter)

    def _pick(self, choice: str) -> None:
        self.choice = choice
        self.accept()


def scan_invoice(parent, ctx, event_id: int | None = None) -> None:
    """Entry point used by the sidebar button and the event panel."""
    if not ctx.repo.list_events():
        info(parent, "No events yet", "Create an event first, then scan its invoices.")
        return
    chooser = ScanSourceDialog(parent)
    if not chooser.exec():
        return
    temp = False
    if chooser.choice == "camera":
        from zari.ui.camera_dialog import take_photo
        path = take_photo(parent)
        temp = path is not None
    else:
        path = choose_invoice_file(parent)
    if path:
        InvoiceDialog(parent, ctx, path, event_id, temp=temp).exec()
