import sqlite3
from datetime import date

import pytest

from zari.db.database import SCHEMA_VERSION, Database, DatabaseError
from zari.logic.validation import validate_event, validate_expense, validate_payment, validate_task

TODAY = date(2026, 10, 21)


def make_event(repo, **over):
    args = dict(name="Test Event", client="Client", type_="Wedding", date_="2026-12-01", venue="Venue",
                guests=50, status="Confirmed", contract="100,000")
    args.update(over)
    return repo.add_event(validate_event(**args))


def test_schema_version_and_foreign_keys(repo):
    assert repo.conn.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert repo.conn.execute("PRAGMA foreign_keys").fetchone()[0] == 1


def test_event_crud_and_totals(repo):
    eid = make_event(repo)
    repo.add_payment(eid, validate_payment("40,000", date(2026, 10, 1), "Deposit"))
    repo.add_expense(eid, validate_expense("Venue", "Hall", "25,000"), paid=True)
    repo.add_expense(eid, validate_expense("Catering", "Food", "10,000.50"), paid=False)
    ev = repo.get_event(eid)
    assert ev.received == 4_000_000 and ev.expenses == 3_500_050 and ev.unpaid_expenses == 1_000_050
    assert ev.fin.balance_due == 6_000_000 and ev.fin.profit == 6_499_950

    repo.update_event(eid, validate_event("Renamed", "C", "Gala", "2027-01-01", "V", 10, "Completed", "50,000"))
    ev = repo.get_event(eid)
    assert (ev.name, ev.type, ev.contract_value) == ("Renamed", "Gala", 5_000_000)


def test_payment_and_expense_edit_delete(repo):
    eid = make_event(repo)
    pid = repo.add_payment(eid, validate_payment("1,000", date(2026, 10, 1), "Deposit"))
    repo.update_payment(pid, validate_payment("2,000", date(2026, 10, 2), "Balance"))
    p = repo.list_payments(eid)[0]
    assert (p.amount, p.label) == (200_000, "Balance")
    repo.delete_payment(pid)
    assert repo.list_payments(eid) == []

    xid = repo.add_expense(eid, validate_expense("Decor", "Flowers", "500"))
    repo.set_expense_paid(xid, True)
    assert repo.list_expenses(eid)[0].paid is True
    repo.update_expense(xid, validate_expense("Staff", "Ushers", "750", vendor="Acme"))
    x = repo.list_expenses(eid)[0]
    assert (x.category, x.amount, x.vendor) == ("Staff", 75_000, "Acme")
    repo.delete_expense(xid)
    assert repo.list_expenses(eid) == []


def test_database_rejects_bad_data_directly(repo):
    with pytest.raises(sqlite3.IntegrityError):
        repo.conn.execute("INSERT INTO payments (event_id, amount, date, label) VALUES (999, 5, '2026-01-01', 'x')")
    eid = make_event(repo)
    with pytest.raises(sqlite3.IntegrityError):
        repo.conn.execute("INSERT INTO payments (event_id, amount, date, label) VALUES (?, -5, '2026-01-01', 'x')", (eid,))
    with pytest.raises(sqlite3.IntegrityError):
        repo.conn.execute("UPDATE events SET status='Bogus' WHERE id=?", (eid,))


def test_delete_event_cascades_and_takes_safety_backup(repo, data_dir):
    eid = make_event(repo)
    repo.add_payment(eid, validate_payment("1,000", date(2026, 10, 1), "Deposit"))
    repo.add_expense(eid, validate_expense("Venue", "Hall", "500"))
    tid = repo.add_task(validate_task("Call venue", date(2026, 11, 1), "High", eid))
    repo.delete_event(eid)
    assert repo.get_event(eid) is None and repo.list_payments() == []
    task = [t for t in repo.list_tasks() if t.id == tid][0]
    assert task.event_id is None  # task survives, just unlinked
    assert list((data_dir / "backups").glob("auto-before-delete-event-*.db"))


def test_tasks(repo):
    eid = make_event(repo)
    tid = repo.add_task(validate_task("Call venue", date(2026, 11, 1), "High", eid))
    repo.set_task_done(tid, True)
    assert repo.list_tasks()[0].done and repo.list_tasks()[0].event_name == "Test Event"
    repo.update_task(tid, validate_task("Call caterer", date(2026, 11, 2), "Low", None))
    t = repo.list_tasks()[0]
    assert (t.title, t.priority, t.event_id) == ("Call caterer", "Low", None)
    repo.delete_task(tid)
    assert repo.list_tasks() == []


def test_duplicate_expense_detection(repo):
    eid = make_event(repo)
    repo.add_expense(eid, validate_expense("Venue", "Hall", "500", vendor="Palace", invoice_no="INV-7"))
    assert repo.find_duplicate_expense(eid, 50_000, "palace", "")
    assert repo.find_duplicate_expense(eid, 99, "PALACE", "INV-7")
    assert repo.find_duplicate_expense(eid, 51_000, "Palace", "INV-8") is None


def test_sample_data_flagged_and_removable_without_touching_real_data(repo):
    real = make_event(repo, name="My Real Event")
    repo.seed_sample_data(TODAY)
    assert repo.has_sample_data()
    samples = [e for e in repo.list_events() if e.is_sample]
    assert len(samples) >= 8 and not repo.get_event(real).is_sample
    repo.seed_sample_data(TODAY)  # reset must not duplicate
    assert len([e for e in repo.list_events() if e.is_sample]) == len(samples)
    repo.remove_sample_data()
    assert [e.name for e in repo.list_events()] == ["My Real Event"]
    assert not repo.has_sample_data()


# ---- backup / restore --------------------------------------------------------------
def test_backup_and_restore_roundtrip(repo, data_dir, tmp_path):
    make_event(repo, name="Before backup")
    backup = repo.db.backup_to(tmp_path / "my-backup.db")
    make_event(repo, name="After backup")
    assert len(repo.list_events()) == 2

    safety = repo.db.restore_from(backup)
    assert [e.name for e in repo.list_events()] == ["Before backup"]
    assert safety.exists()  # the pre-restore state is kept too
    assert Database(safety).conn.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 2


def test_restore_rejects_garbage_and_foreign_databases(repo, tmp_path):
    junk = tmp_path / "junk.db"
    junk.write_text("this is not a database")
    with pytest.raises(DatabaseError):
        repo.db.restore_from(junk)

    foreign = tmp_path / "foreign.db"
    c = sqlite3.connect(foreign)
    c.execute("CREATE TABLE other (x)")
    c.commit()
    c.close()
    with pytest.raises(DatabaseError):
        repo.db.restore_from(foreign)
    with pytest.raises(DatabaseError):
        repo.db.restore_from(tmp_path / "missing.db")
    assert repo.conn.execute("SELECT 1").fetchone()  # live connection still healthy


def test_restore_rejects_newer_schema(repo, tmp_path):
    newer = tmp_path / "newer.db"
    repo.db.backup_to(newer)
    c = sqlite3.connect(newer)
    c.execute(f"PRAGMA user_version = {SCHEMA_VERSION + 1}")
    c.commit()
    c.close()
    with pytest.raises(DatabaseError, match="newer"):
        repo.db.restore_from(newer)
