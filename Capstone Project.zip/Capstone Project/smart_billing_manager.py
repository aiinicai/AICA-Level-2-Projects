#!/usr/bin/env python3
"""
===============================================================================
PSC BILLING MANAGER
===============================================================================
A complete, professional desktop billing & invoice management application.
Features:
  - Tax Invoices & Provisional Invoices creation for Services
  - Automated calculations (Subtotal, GST breakdown CGST/SGST/IGST, Round off, Grand total)
  - Number-to-Words conversion for totals (Indian Rupee format)
  - Service catalog auto-complete & line service edit/delete
  - HSN Code support (default HSN 9982) & Financial Year management
  - Saved Tax Invoices Log & Saved Provisional Invoices Log with Search_Filter
  - B2C orange text, Credit Note red text, Debit Note blue text in log tables
  - Detailed GSTR-1 Summary with B2B/B2C Tax Invoices, Debit/Credit Notes & Net Totals
  - Client Details Management tab sorted alphabetically with strict 15-character GSTIN validation
  - Business Settings with mandatory check before invoice creation & optional mobile/email
  - ReportLab PDF generation with Tax Invoice Folder / Provisional Invoice Folder & FY subfolders
  - Modern PyQt White / Navy Blue / Crimson Red Theme

Delivered as a single, self-contained Python file.
===============================================================================
"""

import os
import sys
import json
import datetime
import math
import re
import subprocess

# =============================================================================
# SECTION 1: AUTO-DEPENDENCY INSTALLATION
# =============================================================================

def get_app_dir():
    """Gets directory of script or exe."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

APP_DIR = get_app_dir()
DEPS_MARKER = os.path.join(APP_DIR, ".deps_installed")

def ensure_dependencies():
    """Installs required third-party libraries if marker is missing."""
    if not os.path.exists(DEPS_MARKER):
        print("[PSC Billing Manager] First-time setup: Checking & installing dependencies...")
        needed = []
        try:
            import PyQt5
        except ImportError:
            try:
                import PyQt6
            except ImportError:
                needed.append("PyQt5")
        try:
            import reportlab
        except ImportError:
            needed.append("reportlab")
        try:
            import openpyxl
        except ImportError:
            needed.append("openpyxl")
        try:
            import qrcode
        except ImportError:
            needed.append("qrcode[pil]")

        if needed:
            print(f"[PSC Billing Manager] Installing missing packages: {', '.join(needed)}...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install"] + needed)
            except Exception as err:
                print(f"[PSC Billing Manager] Warning installing dependencies via pip: {err}")

        try:
            with open(DEPS_MARKER, "w", encoding="utf-8") as f:
                f.write(f"Installed dependencies at {datetime.datetime.now().isoformat()}\n")
        except Exception as e:
            print(f"Could not write marker file: {e}")

ensure_dependencies()

# Qt Imports (PyQt5 primary, fallback to PyQt6 if needed)
try:
    from PyQt5 import QtWidgets, QtCore, QtGui
    from PyQt5.QtWidgets import (
        QApplication, QMainWindow, QWidget, QTabWidget, QVBoxLayout, QHBoxLayout,
        QFormLayout, QGridLayout, QLabel, QLineEdit, QComboBox, QSpinBox,
        QDoubleSpinBox, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
        QMessageBox, QFileDialog, QGroupBox, QFrame, QSplitter, QDateEdit,
        QTextEdit, QTextBrowser, QScrollArea, QAbstractItemView, QStyle, QShortcut,
        QCheckBox, QDialog, QCompleter, QInputDialog
    )
    from PyQt5.QtCore import Qt, QDate, QTime, QDateTime, pyqtSignal, QSize, QStringListModel, QUrl
    from PyQt5.QtGui import QFont, QColor, QIcon, QPixmap, QImage, QKeySequence, QTextDocument
    IS_PYQT5 = True
except ImportError:
    from PyQt6 import QtWidgets, QtCore, QtGui
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QTabWidget, QVBoxLayout, QHBoxLayout,
        QFormLayout, QGridLayout, QLabel, QLineEdit, QComboBox, QSpinBox,
        QDoubleSpinBox, QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
        QMessageBox, QFileDialog, QGroupBox, QFrame, QSplitter, QDateEdit,
        QTextEdit, QTextBrowser, QScrollArea, QAbstractItemView, QStyle,
        QCheckBox, QDialog, QCompleter, QInputDialog
    )
    from PyQt6.QtCore import Qt, QDate, QTime, QDateTime, pyqtSignal, QSize, QStringListModel, QUrl
    from PyQt6.QtGui import QFont, QColor, QIcon, QPixmap, QImage, QKeySequence, QTextDocument
    IS_PYQT5 = False

# ReportLab Imports for PDF Generation
try:
    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib import colors
    from reportlab.platypus import (
        SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, HRFlowable, KeepTogether
    )
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch, mm
    from reportlab.pdfgen import canvas as rl_canvas
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

# Try to register a Unicode font (Segoe UI on Windows) so the Rupee symbol (₹)
# renders correctly in generated PDFs. Falls back to Helvetica + "Rs." if not.
BASE_FONT = "Helvetica"
BASE_BOLD = "Helvetica-Bold"
SYMBOL_FONT = None  # font that carries ☎ ✉ ⌂ glyphs, if available
RUPEE = "Rs. "
if REPORTLAB_AVAILABLE:
    try:
        _fdir = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
        _regular = os.path.join(_fdir, "segoeui.ttf")
        _bold = os.path.join(_fdir, "segoeuib.ttf")
        if os.path.exists(_regular):
            pdfmetrics.registerFont(TTFont("SegoeUI", _regular))
            BASE_FONT = "SegoeUI"
            RUPEE = "\u20b9"
            if os.path.exists(_bold):
                pdfmetrics.registerFont(TTFont("SegoeUI-Bold", _bold))
                BASE_BOLD = "SegoeUI-Bold"
                try:
                    pdfmetrics.registerFontFamily(
                        "SegoeUI", normal="SegoeUI", bold="SegoeUI-Bold",
                        italic="SegoeUI", boldItalic="SegoeUI-Bold"
                    )
                except Exception:
                    pass
            else:
                BASE_BOLD = "SegoeUI"
        # Segoe UI Symbol carries monochrome ☎ ✉ ⌂ glyphs for contact icons.
        _sym = os.path.join(_fdir, "seguisym.ttf")
        if os.path.exists(_sym):
            pdfmetrics.registerFont(TTFont("SegoeSym", _sym))
            SYMBOL_FONT = "SegoeSym"
    except Exception as _e:
        print(f"Font registration skipped: {_e}")


# =============================================================================
# SECTION 2: PATHS & DIRECTORY CREATION
# =============================================================================

DB_DIR = os.path.join(APP_DIR, "database")
PDF_DIR = os.path.join(APP_DIR, "invoices_pdf")

os.makedirs(DB_DIR, exist_ok=True)
os.makedirs(PDF_DIR, exist_ok=True)

INVOICES_FILE = os.path.join(DB_DIR, "invoices.json")
SELLER_FILE = os.path.join(DB_DIR, "seller.json")
CATALOG_FILE = os.path.join(DB_DIR, "catalog.json")
AUDIT_FILE = os.path.join(DB_DIR, "audit_log.json")
CLIENTS_FILE = os.path.join(DB_DIR, "clients.json")

# Admin password used for protected actions. Kept in one place so it is never
# echoed inside user-facing prompt labels.
ADMIN_PASSWORD = "aical276"

# Default Terms & Conditions (from the standard firm invoice format). Used as the
# starting Notes/Terms for new business profiles and offered as a one-click preset.
DEFAULT_TERMS = (
    "1. Payment is due within 15 days from the date of invoice. Delayed payments shall attract "
    "interest @ 14% p.a. from the due date until the date of actual payment.\n"
    "2. Scope: This invoice covers only the services specifically mentioned above. Additional "
    "services shall be charged separately.\n"
    "3. Statutory Charges: Government/MCA fees, stamp duty, late fees, penalties and other "
    "statutory charges, wherever applicable, shall be borne separately by the client.\n"
    "4. Client Responsibility & Delays: The client shall provide complete and accurate "
    "information/documents within the required timelines. The firm shall not be responsible for "
    "delays arising from late receipt of information/documents, portal/technical issues or "
    "circumstances beyond its reasonable control.\n"
    "5. Payment Reference: Please quote the invoice number while making payment."
)


# =============================================================================
# SECTION 3: UTILITY, GST STATE CODES, GSTIN VALIDATION & MATH HELPERS
# =============================================================================

GST_STATE_CODES = {
    "01": "Jammu & Kashmir", "02": "Himachal Pradesh", "03": "Punjab", "04": "Chandigarh",
    "05": "Uttarakhand", "06": "Haryana", "07": "Delhi", "08": "Rajasthan",
    "09": "Uttar Pradesh", "10": "Bihar", "11": "Sikkim", "12": "Arunachal Pradesh",
    "13": "Nagaland", "14": "Manipur", "15": "Mizoram", "16": "Tripura",
    "17": "Meghalaya", "18": "Assam", "19": "West Bengal", "20": "Jharkhand",
    "21": "Odisha", "22": "Chhattisgarh", "23": "Madhya Pradesh", "24": "Gujarat",
    "26": "Dadra & Nagar Haveli and Daman & Diu", "27": "Maharashtra", "29": "Karnataka",
    "30": "Goa", "31": "Lakshadweep", "32": "Kerala", "33": "Tamil Nadu",
    "34": "Puducherry", "35": "Andaman & Nicobar Islands", "36": "Telangana",
    "37": "Andhra Pradesh", "38": "Ladakh", "97": "Other Territory"
}

def validate_gstin_format(gstin):
    """GSTIN format 15 characters where 1st, 2nd, and 13th characters are numeric."""
    g = gstin.strip().upper()
    if not g:
        return True, ""
    if len(g) != 15:
        return False, f"GSTIN must be exactly 15 characters long (Entered: {len(g)} characters)."

    if not (g[0].isdigit() and g[1].isdigit()):
        return False, f"Invalid GSTIN '{g}': 1st and 2nd characters (State Code) must be numeric digits."

    if not g[12].isdigit():
        return False, f"Invalid GSTIN '{g}': 13th character must be a numeric digit."

    return True, ""


def get_state_from_gstin(gstin):
    """Extracts Indian State Name from first 2 digits of GSTIN."""
    if not gstin or len(gstin.strip()) < 2:
        return ""
    code = gstin.strip()[:2]
    return GST_STATE_CODES.get(code, "Unknown State")


def is_delhi_client(gstin="", state=""):
    """Checks if client state is Delhi."""
    if state and "delhi" in state.strip().lower():
        return True
    if gstin:
        st = get_state_from_gstin(gstin)
        if "delhi" in st.strip().lower():
            return True
    return False


def number_to_words(num):
    """Converts a numerical amount into Indian currency words representation."""
    try:
        num = float(num)
    except (ValueError, TypeError):
        return "Zero Rupees Only"

    if num == 0:
        return "Zero Rupees Only"

    units = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
             "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
    tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]

    def _convert_below_thousand(n):
        res = ""
        if n >= 100:
            res += units[n // 100] + " Hundred "
            n %= 100
        if n >= 20:
            res += tens[n // 10] + " "
            n %= 10
        if n > 0:
            res += units[n] + " "
        return res.strip()

    rupees = int(math.floor(num))
    paise = int(round((num - rupees) * 100))

    if rupees == 0:
        words = "Zero Rupees"
    else:
        parts = []
        if rupees >= 10000000:
            crores = rupees // 10000000
            parts.append(_convert_below_thousand(crores) + " Crore")
            rupees %= 10000000
        if rupees >= 100000:
            lakhs = rupees // 100000
            parts.append(_convert_below_thousand(lakhs) + " Lakh")
            rupees %= 100000
        if rupees >= 1000:
            thousands = rupees // 1000
            parts.append(_convert_below_thousand(thousands) + " Thousand")
            rupees %= 1000
        if rupees > 0:
            parts.append(_convert_below_thousand(rupees))

        words = " ".join(parts) + " Rupees"

    if paise > 0:
        paise_words = _convert_below_thousand(paise)
        words += f" and {paise_words} Paise"

    return words.strip() + " Only"


def get_financial_year_str(dt=None):
    """Calculates Indian Financial Year string e.g. 2026-27 for Apr 1 to Mar 31 cycle."""
    if dt is None:
        dt = datetime.date.today()
    elif isinstance(dt, str):
        try:
            dt = datetime.datetime.strptime(dt[:10], "%Y-%m-%d").date()
        except ValueError:
            dt = datetime.date.today()
    elif isinstance(dt, datetime.datetime):
        dt = dt.date()

    if dt.month >= 4:
        start_yr = dt.year
        end_yr = dt.year + 1
    else:
        start_yr = dt.year - 1
        end_yr = dt.year

    end_yr_short = str(end_yr)[-2:]
    return f"{start_yr}-{end_yr_short}"


def build_upi_uri(seller, amount):
    """Build a UPI deep-link (upi://pay) for the given seller and amount.

    Returns an empty string if the seller has no UPI ID configured.
    """
    upi_id = (seller.get("upi_id") or "").strip()
    if not upi_id:
        return ""
    from urllib.parse import quote
    payee = quote((seller.get("trade_name") or "Payee").strip())
    try:
        amt = f"{float(amount):.2f}"
    except (TypeError, ValueError):
        amt = "0.00"
    return f"upi://pay?pa={upi_id}&pn={payee}&am={amt}&cu=INR"


def make_qr_image(data):
    """Return a PIL RGB image encoding `data`, or None if unavailable."""
    if not data:
        return None
    try:
        import qrcode
        qr = qrcode.QRCode(
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10, border=1
        )
        qr.add_data(data)
        qr.make(fit=True)
        return qr.make_image(fill_color="black", back_color="white").convert("RGB")
    except Exception as e:
        print(f"QR generation failed: {e}")
        return None


def format_inr(amount):
    """Format a number in the Indian invoice style, e.g. 4000 -> '4,000/-'."""
    try:
        val = float(amount)
    except (TypeError, ValueError):
        return str(amount)
    if abs(val - round(val)) < 0.005:
        whole = int(round(val))
        # Indian grouping (lakh/crore) via manual formatting.
        s = str(abs(whole))
        if len(s) > 3:
            last3 = s[-3:]
            rest = s[:-3]
            parts = []
            while len(rest) > 2:
                parts.insert(0, rest[-2:])
                rest = rest[:-2]
            if rest:
                parts.insert(0, rest)
            grouped = ",".join(parts) + "," + last3
        else:
            grouped = s
        sign = "-" if whole < 0 else ""
        return f"{sign}{grouped}/-"
    return f"{val:,.2f}/-"


def open_document(path, print_it=False):
    """Open (or print) a file with the OS default handler, robustly.

    Returns (ok, how) where how is 'print'/'open' on success or an error string.
    """
    if not path or not os.path.exists(path):
        return False, "file not found"
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        return True, "print" if print_it else "open"
    try:
        if print_it and hasattr(os, "startfile"):
            try:
                os.startfile(path, "print")
                return True, "print"
            except Exception:
                os.startfile(path)
                return True, "open"
        if hasattr(os, "startfile"):
            os.startfile(path)
            return True, "open"
        # Non-Windows fallbacks
        opener = "open" if sys.platform == "darwin" else "xdg-open"
        subprocess.Popen([opener, path])
        return True, "open"
    except Exception as e:
        return False, str(e)


def show_msg(parent, title, text, icon="info"):
    """Helper to display message dialogs safely in GUI or headless environments."""
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        print(f"[{icon.upper()}] {title}: {text}")
        return QMessageBox.Ok

    if icon == "warning":
        return QMessageBox.warning(parent, title, text)
    elif icon == "critical":
        return QMessageBox.critical(parent, title, text)
    else:
        return QMessageBox.information(parent, title, text)


def ask_question(parent, title, text):
    """Helper for confirmation questions."""
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        print(f"[QUESTION] {title}: {text} -> Defaulting to Yes")
        return QMessageBox.Yes
    return QMessageBox.question(parent, title, text, QMessageBox.Yes | QMessageBox.No, QMessageBox.No)


def prompt_password(parent, title, label):
    """Helper to safely prompt for password verification."""
    if os.environ.get("QT_QPA_PLATFORM") == "offscreen":
        print(f"[PASSWORD PROMPT] {title}: {label} -> Auto-providing admin password for test")
        return ADMIN_PASSWORD, True

    text, ok = QInputDialog.getText(parent, title, label, QLineEdit.Password)
    return text, ok


# =============================================================================
# SECTION 4: DATA MANAGER (JSON DATABASE)
# =============================================================================

class DataManager:
    """Manages offline persistent storage for seller info, clients, catalog, and invoices."""

    @staticmethod
    def default_seller():
        return {
            "trade_name": "",
            "tagline": "",
            "address": "",
            "mobile": "",
            "email": "",
            "website": "",
            "pan": "",
            "gstin": "",
            "msme_udyam_no": "",
            "msme_type": "",
            "bank_name": "",
            "account_no": "",
            "ifsc_code": "",
            "branch": "",
            "upi_id": "",
            "upi_barcode_path": "",
            "terms": DEFAULT_TERMS,
            "due_days": 15,
            "logo_path": ""
        }

    @classmethod
    def load_seller(cls):
        if not os.path.exists(SELLER_FILE):
            data = cls.default_seller()
            cls.save_seller(data)
            return data
        try:
            with open(SELLER_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return cls.default_seller()

    @classmethod
    def save_seller(cls, data):
        try:
            with open(SELLER_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving seller info: {e}")
            return False

    @classmethod
    def load_clients(cls):
        """Loads client records sorted alphabetically by Client Name."""
        if not os.path.exists(CLIENTS_FILE):
            return []
        try:
            with open(CLIENTS_FILE, "r", encoding="utf-8") as f:
                clients = json.load(f)
                clients.sort(key=lambda c: c.get("name", "").strip().lower())
                return clients
        except Exception:
            return []

    @classmethod
    def save_clients(cls, clients_list):
        try:
            clients_list.sort(key=lambda c: c.get("name", "").strip().lower())
            with open(CLIENTS_FILE, "w", encoding="utf-8") as f:
                json.dump(clients_list, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving clients: {e}")
            return False

    @classmethod
    def save_client(cls, client_data):
        clients = cls.load_clients()
        name = client_data.get("name", "").strip()
        existing_idx = -1
        for idx, c in enumerate(clients):
            if c.get("name", "").strip().lower() == name.lower():
                existing_idx = idx
                break

        if existing_idx >= 0:
            clients[existing_idx] = client_data
        else:
            clients.append(client_data)

        cls.save_clients(clients)
        return True

    @classmethod
    def delete_client(cls, name):
        clients = cls.load_clients()
        clients = [c for c in clients if c.get("name", "").strip().lower() != name.lower()]
        cls.save_clients(clients)

    @classmethod
    def load_invoices(cls):
        if not os.path.exists(INVOICES_FILE):
            return []
        try:
            with open(INVOICES_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    @classmethod
    def save_invoices(cls, invoices_list):
        try:
            with open(INVOICES_FILE, "w", encoding="utf-8") as f:
                json.dump(invoices_list, f, indent=4)
            return True
        except Exception as e:
            print(f"Error saving invoices: {e}")
            return False

    @classmethod
    def load_audit_logs(cls):
        if not os.path.exists(AUDIT_FILE):
            return []
        try:
            with open(AUDIT_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return []

    @classmethod
    def log_audit(cls, action, doc_no, doc_type, customer_name, amount, details=""):
        logs = cls.load_audit_logs()
        entry = {
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "action": action,
            "doc_no": doc_no,
            "doc_type": doc_type,
            "customer_name": customer_name,
            "amount": amount,
            "details": details
        }
        logs.append(entry)
        try:
            with open(AUDIT_FILE, "w", encoding="utf-8") as f:
                json.dump(logs, f, indent=4)
        except Exception as e:
            print(f"Error saving audit log: {e}")

    @classmethod
    def save_invoice(cls, invoice_data):
        invoices = cls.load_invoices()
        existing_idx = -1
        for idx, inv in enumerate(invoices):
            if inv.get("doc_no") == invoice_data.get("doc_no"):
                existing_idx = idx
                break

        if existing_idx >= 0:
            invoices[existing_idx] = invoice_data
            action_type = "UPDATED"
        else:
            invoices.append(invoice_data)
            action_type = "CREATED"

        cls.save_invoices(invoices)
        cls.update_catalog(invoice_data)
        cls.log_audit(
            action_type,
            invoice_data.get("doc_no", ""),
            invoice_data.get("doc_type", ""),
            invoice_data.get("customer_name", ""),
            invoice_data.get("grand_total", 0.0),
            f"{action_type} {invoice_data.get('doc_type')} for {invoice_data.get('customer_name')}"
        )
        return True

    @classmethod
    def update_invoice_issued(cls, doc_no, issued_inv_no):
        invoices = cls.load_invoices()
        target = next((i for i in invoices if i.get("doc_no") == doc_no), None)
        if target:
            target["invoice_issued"] = issued_inv_no
            cls.save_invoices(invoices)
            cls.log_audit(
                "UPDATED",
                doc_no,
                target.get("doc_type", ""),
                target.get("customer_name", ""),
                target.get("grand_total", 0.0),
                f"Updated Invoice Issued reference to {issued_inv_no}"
            )
            return True
        return False

    @classmethod
    def set_invoice_approved(cls, doc_no, approved_inv_no=""):
        """Mark a provisional invoice as approved (locking it from further edits)."""
        invoices = cls.load_invoices()
        target = next((inv for inv in invoices if inv.get("doc_no") == doc_no), None)
        if target:
            target["approved"] = True
            target["approved_at"] = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if approved_inv_no:
                target["invoice_issued"] = approved_inv_no
            cls.save_invoices(invoices)
            cls.log_audit(
                "APPROVED",
                doc_no,
                target.get("doc_type", ""),
                target.get("customer_name", ""),
                target.get("grand_total", 0.0),
                "Provisional invoice approved for main invoice creation"
                + (f" (Invoice {approved_inv_no})" if approved_inv_no else "")
            )
            return True
        return False

    @classmethod
    def add_payment_tranche(cls, doc_no, payment_entry):
        invoices = cls.load_invoices()
        target = None
        for inv in invoices:
            if inv.get("doc_no") == doc_no:
                target = inv
                break

        if target:
            payments = target.get("payments", [])
            payments.append(payment_entry)
            target["payments"] = payments
            cls.save_invoices(invoices)
            cls.log_audit(
                "UPDATED",
                doc_no,
                target.get("doc_type", ""),
                target.get("customer_name", ""),
                payment_entry.get("amount", 0.0),
                f"Recorded Payment Tranche of ₹{payment_entry.get('amount', 0):,.2f} on {payment_entry.get('date', '')}"
            )
            return True
        return False

    @classmethod
    def delete_invoice(cls, doc_no):
        invoices = cls.load_invoices()
        deleted_target = next((inv for inv in invoices if inv.get("doc_no") == doc_no), None)
        invoices = [inv for inv in invoices if inv.get("doc_no") != doc_no]
        cls.save_invoices(invoices)

        if deleted_target:
            cls.log_audit(
                "DELETED",
                doc_no,
                deleted_target.get("doc_type", ""),
                deleted_target.get("customer_name", ""),
                deleted_target.get("grand_total", 0.0),
                f"Deleted {deleted_target.get('doc_type')} #{doc_no} (Authorized with password)"
            )

    @classmethod
    def get_next_doc_no(cls, doc_type, doc_date_str=None, fy_override=None, is_provisional=False):
        fy = fy_override if fy_override else get_financial_year_str(doc_date_str)
        if is_provisional or doc_type == "Provisional Invoice":
            full_prefix = f"PSC/PROV/{fy}/"
        elif doc_type == "Credit Note":
            full_prefix = f"PSC/GST/CN/{fy}/"
        elif doc_type == "Debit Note":
            full_prefix = f"PSC/GST/DN/{fy}/"
        else:
            full_prefix = f"PSC/GST/{fy}/"

        invoices = cls.load_invoices()
        max_num = 0
        for inv in invoices:
            doc_no = inv.get("doc_no", "")
            if doc_no.startswith(full_prefix):
                num_part = doc_no.split("/")[-1]
                try:
                    val = int(num_part)
                    if val > max_num:
                        max_num = val
                except ValueError:
                    pass

        return f"{full_prefix}{max_num + 1:04d}"

    @classmethod
    def load_catalog(cls):
        if not os.path.exists(CATALOG_FILE):
            return {"items": [], "customers": []}
        try:
            with open(CATALOG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"items": [], "customers": []}

    @classmethod
    def update_catalog(cls, invoice):
        catalog = cls.load_catalog()
        customers = catalog.get("customers", [])
        items = catalog.get("items", [])

        cust_name = invoice.get("customer_name", "").strip()
        if cust_name:
            cust_entry = {
                "name": cust_name,
                "mobile": invoice.get("customer_mobile", ""),
                "address": invoice.get("customer_address", ""),
                "gstin": invoice.get("customer_gstin", ""),
                "state": invoice.get("customer_state", "")
            }
            customers = [c for c in customers if c.get("name").lower() != cust_name.lower()]
            customers.append(cust_entry)

        for line in invoice.get("items", []):
            item_name = line.get("name", "").strip()
            if item_name:
                item_entry = {
                    "name": item_name,
                    "hsn": line.get("hsn", "9982"),
                    "amount": line.get("amount", 0.0),
                    "gst_pct": line.get("gst_pct", 18.0)
                }
                items = [i for i in items if i.get("name").lower() != item_name.lower()]
                items.append(item_entry)

        catalog["customers"] = customers
        catalog["items"] = items
        try:
            with open(CATALOG_FILE, "w", encoding="utf-8") as f:
                json.dump(catalog, f, indent=4)
        except Exception as e:
            print(f"Error saving catalog: {e}")


# =============================================================================
# SECTION 5: REPORTLAB PDF GENERATOR
# =============================================================================

class InvoicePDFGenerator:
    """Generates professional Tax Invoice / Credit Note / Debit Note / Provisional Invoice PDFs."""

    @staticmethod
    def _fmt_date(dstr):
        """Format 'YYYY-MM-DD' as e.g. '10th August 2026'."""
        try:
            d = datetime.datetime.strptime(str(dstr)[:10], "%Y-%m-%d").date()
        except (ValueError, TypeError):
            return str(dstr or "")
        day = d.day
        if 11 <= (day % 100) <= 13:
            suf = "th"
        else:
            suf = {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
        return f"{day}{suf} {d.strftime('%B')} {d.year}"

    @staticmethod
    def _due_date(invoice, days=15):
        if invoice.get("due_date"):
            return invoice.get("due_date")
        try:
            d = datetime.datetime.strptime(str(invoice.get("doc_date"))[:10], "%Y-%m-%d").date()
            return (d + datetime.timedelta(days=days)).isoformat()
        except (ValueError, TypeError):
            return ""

    @staticmethod
    def generate_pdf(invoice, seller, output_path):
        """Render a clean, print-ready invoice PDF that matches the firm's
        standard format, populated from Business Settings + invoice data."""
        if not REPORTLAB_AVAILABLE:
            raise RuntimeError("ReportLab library is not available for PDF generation.")

        out_dir = os.path.dirname(output_path)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

        PAGE_W, PAGE_H = A4
        L = 42.0
        R = PAGE_W - 42.0
        W = R - L

        navy = colors.HexColor("#1E3A8A")
        dark = colors.HexColor("#1F2937")
        grey = colors.HexColor("#6B7280")
        hdr_bg = colors.HexColor("#EAF0F8")
        grid = colors.HexColor("#94A3B8")

        c = rl_canvas.Canvas(output_path, pagesize=A4)
        doc_type_title = (invoice.get("doc_type") or "Invoice").upper()
        c.setTitle(f"{doc_type_title} {invoice.get('doc_no', '')}")
        c.setAuthor(seller.get("trade_name", ""))

        def text(x, y, s, size=9, font=None, color=dark, align='left'):
            if s is None or s == "":
                return
            c.setFillColor(color)
            c.setFont(font or BASE_FONT, size)
            if align == 'right':
                c.drawRightString(x, y, str(s))
            elif align == 'center':
                c.drawCentredString(x, y, str(s))
            else:
                c.drawString(x, y, str(s))

        def wrap(s, font, size, maxw):
            out = []
            for para in str(s).replace("\r", "").split("\n"):
                words = para.split()
                if not words:
                    out.append("")
                    continue
                cur = ""
                for wd in words:
                    trial = (cur + " " + wd).strip()
                    if c.stringWidth(trial, font, size) <= maxw:
                        cur = trial
                    else:
                        if cur:
                            out.append(cur)
                        cur = wd
                out.append(cur)
            return out or [""]

        def contact_line(x, y, glyph, value, size=9, color=dark):
            """Draw a contact row: symbol glyph (symbol font) + value (base font)."""
            if not value:
                return
            if SYMBOL_FONT:
                c.setFillColor(navy)
                c.setFont(SYMBOL_FONT, size)
                c.drawString(x, y, glyph)
                gw = c.stringWidth(glyph, SYMBOL_FONT, size)
            else:
                gw = 0
            text(x + gw + 4, y, value, size=size, color=color)

        # ------------------------------------------------------------------
        # 1) HEADER: firm name + tagline (left), logo (right), INVOICE title
        # ------------------------------------------------------------------
        trade = seller.get("trade_name", "Business Name")
        tagline = (seller.get("tagline") or "").strip()

        logo_path = seller.get("logo_path", "")
        if logo_path and os.path.exists(logo_path):
            try:
                c.drawImage(ImageReader(logo_path), R - 96, 762, width=96, height=64,
                            preserveAspectRatio=True, anchor='ne', mask='auto')
            except Exception as e:
                print(f"Could not load logo in PDF: {e}")

        text(L, 804, trade, size=18, font=BASE_BOLD, color=navy)
        if tagline:
            text(L, 789, tagline.upper(), size=10.5, font=BASE_BOLD, color=grey)

        text(R, 748, doc_type_title, size=19, font=BASE_BOLD, color=navy, align='right')

        # ------------------------------------------------------------------
        # 2) Seller identity block (left) + document meta (right)
        # ------------------------------------------------------------------
        ly = 760 if tagline else 772
        if seller.get("pan"):
            text(L, ly, f"PAN: {seller.get('pan')}", size=9.5, font=BASE_BOLD)
            ly -= 14
        if seller.get("gstin"):
            text(L, ly, f"GSTIN: {seller.get('gstin')}", size=9.5, font=BASE_BOLD)
            ly -= 14
        if seller.get("msme_udyam_no"):
            mt = seller.get("msme_type", "")
            suffix = f" ({mt})" if mt else ""
            text(L, ly, f"MSME Udyam: {seller.get('msme_udyam_no')}{suffix}", size=8.5)
            ly -= 13
        for line in wrap(seller.get("address", ""), BASE_FONT, 9, 300):
            if line:
                text(L, ly, line, size=9)
                ly -= 13
        if seller.get("mobile"):
            contact_line(L, ly, "☎", seller.get("mobile"), size=9)
            ly -= 13
        if seller.get("email"):
            contact_line(L, ly, "✉", seller.get("email"), size=9)
            ly -= 13
        if seller.get("website"):
            contact_line(L, ly, "\U0001F310", seller.get("website"), size=9)
            ly -= 13
        seller_bottom = ly

        # Document meta (right)
        mlx = 372
        mvx = 452
        try:
            due_days = int(seller.get("due_days") or 15)
        except (TypeError, ValueError):
            due_days = 15
        text(mlx, 724, "Invoice No.", size=9.5, font=BASE_BOLD, color=navy)
        text(mvx, 724, invoice.get("doc_no", ""), size=9.5)
        text(mlx, 707, "Dated", size=9.5, font=BASE_BOLD, color=navy)
        text(mvx, 707, InvoicePDFGenerator._fmt_date(invoice.get("doc_date", "")), size=9.5)
        text(mlx, 690, "Due Date", size=9.5, font=BASE_BOLD, color=navy)
        text(mvx, 690, InvoicePDFGenerator._fmt_date(InvoicePDFGenerator._due_date(invoice, due_days)), size=9.5)

        # ------------------------------------------------------------------
        # 3) BILL TO
        # ------------------------------------------------------------------
        by = min(seller_bottom - 8, 666)
        text(L, by, "Bill To-", size=10, font=BASE_BOLD, color=navy)
        cy = by - 15
        text(L, cy, invoice.get("customer_name", ""), size=10, font=BASE_BOLD)
        cy -= 13
        detail_lines = []
        if invoice.get("customer_address"):
            detail_lines += wrap(invoice.get("customer_address"), BASE_FONT, 9, 320)
        if invoice.get("customer_gstin"):
            detail_lines.append(f"GSTIN: {invoice.get('customer_gstin')}")
        if invoice.get("customer_state"):
            detail_lines.append(f"State: {invoice.get('customer_state')}")
        for line in detail_lines:
            text(L, cy, line, size=9)
            cy -= 12
        if invoice.get("customer_mobile"):
            contact_line(L, cy, "☎", invoice.get("customer_mobile"), size=9)
            cy -= 12

        # ------------------------------------------------------------------
        # 4) ITEMS TABLE
        # ------------------------------------------------------------------
        x0, x1, x2, x3, x4 = L, 92.0, 372.0, 462.0, R
        ytab = cy - 12
        hrow = 22.0

        def col_lines(y_top, height):
            c.setStrokeColor(grid)
            c.setLineWidth(0.6)
            for xv in (x0, x1, x2, x3, x4):
                c.line(xv, y_top, xv, y_top - height)

        c.setFillColor(hdr_bg)
        c.rect(x0, ytab - hrow, W, hrow, fill=1, stroke=0)
        c.setStrokeColor(grid)
        c.setLineWidth(0.9)
        c.rect(x0, ytab - hrow, W, hrow, fill=0, stroke=1)
        col_lines(ytab, hrow)
        hy = ytab - hrow + 7
        text((x0 + x1) / 2, hy, "S.NO.", size=9, font=BASE_BOLD, color=navy, align='center')
        text(x1 + 6, hy, "DESCRIPTION", size=9, font=BASE_BOLD, color=navy)
        text((x2 + x3) / 2, hy, "SAC Code", size=9, font=BASE_BOLD, color=navy, align='center')
        text((x3 + x4) / 2, hy, f"Amount ({RUPEE})".strip(), size=9, font=BASE_BOLD, color=navy, align='center')

        y = ytab - hrow
        items = invoice.get("items", [])
        for idx, item in enumerate(items, 1):
            desc_lines = wrap(item.get("name", ""), BASE_FONT, 9, (x2 - x1) - 10) or [""]
            rh = max(22.0, 8 + len(desc_lines) * 12)
            c.setStrokeColor(grid)
            c.setLineWidth(0.6)
            c.rect(x0, y - rh, W, rh, fill=0, stroke=1)
            col_lines(y, rh)
            text((x0 + x1) / 2, y - 15, str(idx), size=9, align='center')
            dy = y - 14
            for dl in desc_lines:
                text(x1 + 6, dy, dl, size=9)
                dy -= 12
            text((x2 + x3) / 2, y - 15, str(item.get("hsn", item.get("sac", "")) or ""), size=9, align='center')
            text(x4 - 8, y - 15, format_inr(item.get("amount", 0)), size=9, align='right')
            y -= rh

        # GST row
        total_gst = invoice.get("total_gst", 0.0) or 0.0
        grand_total = invoice.get("grand_total", 0.0) or 0.0
        gst_rh = 20.0
        c.setStrokeColor(grid)
        c.setLineWidth(0.6)
        c.rect(x0, y - gst_rh, W, gst_rh, fill=0, stroke=1)
        col_lines(y, gst_rh)
        text(x1 + 6, y - gst_rh + 6, "GST", size=9, font=BASE_BOLD)
        gst_disp = "NIL" if abs(total_gst) < 0.005 else format_inr(total_gst)
        text(x4 - 8, y - gst_rh + 6, gst_disp, size=9, align='right')
        y -= gst_rh

        # Total row
        tot_rh = 24.0
        c.setFillColor(hdr_bg)
        c.rect(x0, y - tot_rh, W, tot_rh, fill=1, stroke=0)
        c.setStrokeColor(grid)
        c.setLineWidth(0.9)
        c.rect(x0, y - tot_rh, W, tot_rh, fill=0, stroke=1)
        col_lines(y, tot_rh)
        text(x1 + 6, y - tot_rh + 8, "Total", size=11, font=BASE_BOLD)
        text(x4 - 8, y - tot_rh + 8, f"{RUPEE}{format_inr(grand_total)}".strip(), size=11, font=BASE_BOLD, color=navy, align='right')
        y -= tot_rh

        # ------------------------------------------------------------------
        # 5) Amount in words
        # ------------------------------------------------------------------
        y -= 16
        words_str = "Amount In Words- " + number_to_words(grand_total).replace(" Only", " Only.")
        for line in wrap(words_str, BASE_BOLD, 9.5, W):
            text(L, y, line, size=9.5, font=BASE_BOLD)
            y -= 13

        # ------------------------------------------------------------------
        # 6) Payment details (left) + dynamic UPI QR (right)
        # ------------------------------------------------------------------
        y -= 8
        pay_top = y
        text(L, pay_top, "Payment Details-", size=10, font=BASE_BOLD, color=navy)
        rows = [
            ("Bank account Name:", seller.get("bank_name", "")),
            ("Account number:", seller.get("account_no", "")),
            ("IFSC:", seller.get("ifsc_code", "")),
            ("Bank name:", seller.get("bank_name", "")),
            ("Branch:", seller.get("branch", "")),
        ]
        if (seller.get("upi_id") or "").strip():
            rows.append(("UPI ID:", seller.get("upi_id", "")))
        row_h = 17.0
        box_w = 312.0
        box_h2 = row_h * len(rows)
        by2 = pay_top - 6
        c.setStrokeColor(grid)
        c.setLineWidth(0.7)
        c.rect(L, by2 - box_h2, box_w, box_h2, fill=0, stroke=1)
        for i, (lbl, val) in enumerate(rows):
            ry = by2 - (i * row_h)
            if i:
                c.setStrokeColor(colors.HexColor("#D1D5DB"))
                c.line(L, ry, L + box_w, ry)
            text(L + 6, ry - row_h + 5, lbl, size=8.8, font=BASE_BOLD)
            lblw = c.stringWidth(lbl, BASE_BOLD, 8.8)
            text(L + 10 + lblw, ry - row_h + 5, val, size=8.8)

        # QR (right)
        qr_uri = build_upi_uri(seller, grand_total)
        qr_img = make_qr_image(qr_uri)
        qr_size = 108.0
        qr_x = R - qr_size
        qr_top = pay_top + 2
        drew_qr = False
        if qr_img is None:
            fallback = seller.get("upi_barcode_path", "")
            if fallback and os.path.exists(fallback):
                try:
                    text(qr_x + qr_size / 2, qr_top, "Or, Scan below to Pay", size=9, font=BASE_BOLD, color=grey, align='center')
                    c.drawImage(ImageReader(fallback), qr_x, qr_top - 10 - qr_size, qr_size, qr_size,
                                preserveAspectRatio=True, mask='auto')
                    drew_qr = True
                except Exception as e:
                    print(f"Could not load fallback QR image: {e}")
        else:
            text(qr_x + qr_size / 2, qr_top, "Or, Scan below to Pay", size=9, font=BASE_BOLD, color=grey, align='center')
            try:
                import io
                buf = io.BytesIO()
                qr_img.save(buf, format="PNG")
                buf.seek(0)
                c.drawImage(ImageReader(buf), qr_x, qr_top - 10 - qr_size, qr_size, qr_size, mask='auto')
                drew_qr = True
            except Exception as e:
                print(f"Could not render QR: {e}")
            if (seller.get("upi_id") or "").strip():
                text(qr_x + qr_size / 2, qr_top - 10 - qr_size - 11,
                     f"UPI ID: {seller.get('upi_id')}", size=8, color=grey, align='center')

        # Signatory (right, below QR block)
        qr_block_bottom = qr_top - 10 - qr_size - (30 if drew_qr else 0)
        sig_y = min(pay_top - box_h2 - 20, qr_block_bottom)
        text(R, sig_y, f"For {trade}", size=9.5, font=BASE_BOLD, align='right')
        text(R, sig_y - 30, tagline if tagline else "Authorized Signatory", size=9, color=grey, align='right')

        # ------------------------------------------------------------------
        # 7) Terms & Conditions
        # ------------------------------------------------------------------
        ty = min(by2 - box_h2 - 20, sig_y - 46)
        c.setStrokeColor(navy)
        c.setLineWidth(0.8)
        c.line(L, ty + 8, R, ty + 8)
        text(L, ty - 4, "TERMS & CONDITIONS", size=9, font=BASE_BOLD, color=navy)
        tyy = ty - 18
        for para in (seller.get("terms", "") or "").replace("\r", "").split("\n"):
            para = para.strip()
            if not para:
                continue
            for k, line in enumerate(wrap(para, BASE_FONT, 8, W)):
                text(L, tyy, line, size=8, color=dark)
                tyy -= 10.5
            tyy -= 1

        # GST status footer
        if abs(total_gst) < 0.005 and not seller.get("gstin"):
            text(PAGE_W / 2, 34, f"GST Status: {trade} is presently not registered under GST. "
                 "Accordingly, GST has not been charged on this invoice.",
                 size=8, color=grey, align='center')

        c.showPage()
        c.save()
        return output_path


# =============================================================================
# SECTION 6: PYQT STYLING & CUSTOM STYLESHEET
# =============================================================================

APP_STYLE = """
QMainWindow, QDialog {
    background-color: #EEF2F7;
}
QWidget {
    font-family: 'Segoe UI', 'Inter', Arial, sans-serif;
    font-size: 13px;
    color: #0F172A;
}
QToolTip {
    background-color: #0F172A;
    color: #F8FAFC;
    border: none;
    padding: 6px 8px;
    border-radius: 4px;
}

/* ---------- Tabs ---------- */
QTabWidget::pane {
    border: 1px solid #DCE3EC;
    background: #FFFFFF;
    border-radius: 10px;
    top: -1px;
}
QTabBar::tab {
    background: transparent;
    color: #64748B;
    padding: 11px 22px;
    font-weight: 600;
    font-size: 13px;
    border: none;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background: #1E3A8A;
    color: #FFFFFF;
}
QTabBar::tab:hover:!selected {
    background: #DBE4F0;
    color: #1E3A8A;
}

/* ---------- Group cards ---------- */
QGroupBox {
    font-weight: 700;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    margin-top: 16px;
    padding: 14px 12px 10px 12px;
    background-color: #FFFFFF;
}
QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 3px 12px;
    color: #FFFFFF;
    background-color: #1E3A8A;
    border-radius: 6px;
}

/* ---------- Inputs ---------- */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTextEdit {
    border: 1px solid #CBD5E1;
    border-radius: 8px;
    padding: 7px 11px;
    background-color: #FFFFFF;
    min-height: 20px;
    selection-background-color: #2563EB;
    selection-color: #FFFFFF;
}
QLineEdit:hover, QComboBox:hover, QDoubleSpinBox:hover, QDateEdit:hover, QSpinBox:hover, QTextEdit:hover {
    border: 1px solid #94A3B8;
}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QDateEdit:focus, QTextEdit:focus {
    border: 1.6px solid #2563EB;
    background-color: #F8FBFF;
}
QLineEdit:disabled, QComboBox:disabled, QDateEdit:disabled {
    background-color: #F1F5F9;
    color: #94A3B8;
}
QLineEdit[readOnly="true"] {
    background-color: #EFF3F8;
    color: #334155;
}
QComboBox::drop-down, QDateEdit::drop-down {
    subcontrol-origin: padding;
    subcontrol-position: center right;
    width: 24px;
    border: none;
    border-left: 1px solid #E2E8F0;
    margin: 2px;
}
QComboBox::down-arrow, QDateEdit::down-arrow {
    image: url(__ARROW__);
    width: 12px;
    height: 12px;
}
QComboBox QAbstractItemView {
    border: 1px solid #CBD5E1;
    border-radius: 6px;
    background: #FFFFFF;
    selection-background-color: #DBEAFE;
    selection-color: #1E3A8A;
    padding: 4px;
    outline: none;
}

/* ---------- Buttons ---------- */
QPushButton {
    background-color: #2563EB;
    color: white;
    font-weight: 600;
    font-size: 13px;
    border-radius: 8px;
    padding: 8px 16px;
    border: none;
}
QPushButton:hover { background-color: #1D4ED8; }
QPushButton:pressed { background-color: #1E40AF; }
QPushButton:disabled { background-color: #CBD5E1; color: #F1F5F9; }
QPushButton#btnDanger { background-color: #DC2626; }
QPushButton#btnDanger:hover { background-color: #B91C1C; }
QPushButton#btnDanger:disabled { background-color: #FCA5A5; }
QPushButton#btnSuccess { background-color: #059669; }
QPushButton#btnSuccess:hover { background-color: #047857; }
QPushButton#btnSuccess:disabled { background-color: #A7F3D0; color: #ECFDF5; }
QPushButton#btnSecondary { background-color: #64748B; }
QPushButton#btnSecondary:hover { background-color: #475569; }

/* ---------- Checkbox ---------- */
QCheckBox { spacing: 8px; color: #334155; }
QCheckBox::indicator {
    width: 18px; height: 18px;
    border: 1.5px solid #94A3B8;
    border-radius: 5px;
    background: #FFFFFF;
}
QCheckBox::indicator:hover { border-color: #2563EB; }
QCheckBox::indicator:checked {
    background: #2563EB;
    border-color: #2563EB;
    image: none;
}

/* ---------- Tables ---------- */
QTableWidget {
    background-color: #FFFFFF;
    gridline-color: #EDF1F6;
    border: 1px solid #E2E8F0;
    border-radius: 10px;
    selection-background-color: #DBEAFE;
    selection-color: #1E3A8A;
    alternate-background-color: #F7FAFD;
}
QTableWidget::item { padding: 4px 6px; }
QHeaderView::section {
    background-color: #1E3A8A;
    color: white;
    font-weight: 700;
    padding: 9px 6px;
    border: none;
    border-right: 1px solid #2B4BA0;
}
QHeaderView::section:last { border-right: none; }
QTableCornerButton::section { background-color: #1E3A8A; border: none; }

/* ---------- Scrollbars ---------- */
QScrollBar:vertical {
    background: transparent; width: 12px; margin: 2px;
}
QScrollBar::handle:vertical {
    background: #CBD5E1; border-radius: 6px; min-height: 30px;
}
QScrollBar::handle:vertical:hover { background: #94A3B8; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal {
    background: transparent; height: 12px; margin: 2px;
}
QScrollBar::handle:horizontal {
    background: #CBD5E1; border-radius: 6px; min-width: 30px;
}
QScrollBar::handle:horizontal:hover { background: #94A3B8; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

/* ---------- Status bar ---------- */
QStatusBar {
    background-color: #0F172A;
    color: #E2E8F0;
    font-weight: 500;
}
QStatusBar::item { border: none; }
"""


def _ensure_dropdown_arrow_icon():
    """Create (once) a chevron-down PNG used as the combo/date dropdown arrow.
    Returns a QSS-safe (forward-slash) path, or '' on failure."""
    try:
        from PIL import Image, ImageDraw
        assets = os.path.join(APP_DIR, "assets")
        os.makedirs(assets, exist_ok=True)
        path = os.path.join(assets, "chevron_down.png")
        if not os.path.exists(path):
            s = 32
            img = Image.new("RGBA", (s, s), (0, 0, 0, 0))
            d = ImageDraw.Draw(img)
            # A clean chevron (v) drawn as two thick strokes.
            d.line([(7, 12), (16, 21)], fill=(71, 85, 105, 255), width=3)
            d.line([(16, 21), (25, 12)], fill=(71, 85, 105, 255), width=3)
            img.save(path)
        return path.replace("\\", "/")
    except Exception as e:
        print(f"Could not create dropdown arrow icon: {e}")
        return ""


def build_stylesheet():
    """Return APP_STYLE with a real dropdown-arrow image wired in (falls back to
    the native arrow if the icon can't be generated)."""
    arrow = _ensure_dropdown_arrow_icon()
    if arrow:
        return APP_STYLE.replace("__ARROW__", arrow)
    # No custom icon: drop the arrow-image rules so Qt paints its native arrow.
    lines = APP_STYLE.split("\n")
    out, skip = [], False
    for ln in lines:
        if "::down-arrow" in ln and "{" in ln:
            skip = True
            continue
        if skip:
            if "}" in ln:
                skip = False
            continue
        out.append(ln)
    return "\n".join(out)


# =============================================================================
# SECTION 7: MAIN APPLICATION WINDOW
# =============================================================================

class PSCBillingApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PSC Billing Manager - Professional Services Billing Software")
        self.resize(1380, 880)
        self.setMinimumSize(1024, 720)

        # Apply global theme (with a real dropdown arrow wired into the QSS)
        self.setStyleSheet(build_stylesheet())

        # State Variables
        self.seller_info = DataManager.load_seller()

        # UI Setup
        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(12, 12, 12, 12)

        # Top Application Title Bar
        header_frame = QFrame()
        header_frame.setStyleSheet("background-color: #1E3A8A; border-radius: 6px;")
        header_layout = QHBoxLayout(header_frame)
        header_layout.setContentsMargins(15, 10, 15, 10)

        app_title = QLabel("⚡ PSC BILLING MANAGER")
        font_title = QFont("Segoe UI", 16)
        font_title.setBold(True)
        app_title.setFont(font_title)
        app_title.setStyleSheet("color: white;")

        app_subtitle = QLabel("Fast, Offline GST Services Invoicing & Receipts Log")
        app_subtitle.setFont(QFont("Segoe UI", 10))
        app_subtitle.setStyleSheet("color: #93C5FD;")

        header_layout.addWidget(app_title)
        header_layout.addSpacing(10)
        header_layout.addWidget(app_subtitle)
        header_layout.addStretch()

        main_layout.addWidget(header_frame)

        # Tab Widget
        self.tabs = QTabWidget()
        main_layout.addWidget(self.tabs)

        self.tax_invoice_widget = InvoiceFormWidget(is_provisional=False, parent_app=self)
        self.tax_log_widget = InvoiceLogWidget(is_provisional=False, parent_app=self)

        self.prov_invoice_widget = InvoiceFormWidget(is_provisional=True, parent_app=self)
        self.prov_log_widget = InvoiceLogWidget(is_provisional=True, parent_app=self)

        self.clients_widget = ClientDetailsWidget(parent_app=self)
        self.seller_widget = BusinessSettingsWidget(parent_app=self)

        # Tabs Addition
        self.tabs.addTab(self.tax_invoice_widget, "📄 Create Tax Invoice")
        self.tabs.addTab(self.tax_log_widget, "📊 Saved Tax Invoice Log")
        self.tabs.addTab(self.prov_invoice_widget, "📄 Create Provisional Invoice")
        self.tabs.addTab(self.prov_log_widget, "📊 Saved Provisional Invoices Log")
        self.tabs.addTab(self.clients_widget, "👥 Client Details")
        self.tabs.addTab(self.seller_widget, "⚙️ Business Settings")

        self.tabs.currentChanged.connect(self.on_tab_changed)

        # Status Bar
        self.statusBar().showMessage("Ready | PSC Billing Manager Active")

    def on_tab_changed(self, index):
        if index == 1:
            self.tax_log_widget.refresh_log()
        elif index == 3:
            self.prov_log_widget.refresh_log()
        elif index == 4:
            self.clients_widget.refresh_clients_table()

    def reload_all_client_dropdowns(self):
        self.tax_invoice_widget.reload_clients_dropdown()
        self.prov_invoice_widget.reload_clients_dropdown()

    def is_seller_info_complete(self):
        s = self.seller_info
        mandatory = [
            s.get("trade_name"), s.get("address"), s.get("gstin"),
            s.get("bank_name"), s.get("account_no"), s.get("ifsc_code"),
            s.get("branch"), s.get("terms")
        ]
        return all(m and str(m).strip() for m in mandatory)


# =============================================================================
# REUSABLE INVOICE CREATION FORM WIDGET
# =============================================================================

class InvoiceFormWidget(QWidget):
    """Reusable widget for creating Tax Invoices or Provisional Invoices."""
    def __init__(self, is_provisional=False, parent_app=None):
        super().__init__()
        self.is_provisional = is_provisional
        self.parent_app = parent_app

        self.current_items = []
        self.editing_item_index = -1
        self.custom_fy = None

        self.init_ui()
        self.reload_clients_dropdown()
        self.reload_service_catalog()
        self.on_doc_type_changed()

    def init_ui(self):
        # Outer layout hosts the input form (left) and a live bill preview (right)
        # so the invoice updates side-by-side as details are entered.
        outer = QHBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(8)

        left_widget = QWidget()
        layout = QVBoxLayout(left_widget)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(10)

        top_grid = QGridLayout()
        self.top_grid = top_grid
        top_grid.setHorizontalSpacing(12)

        doc_title = "Provisional Document Information" if self.is_provisional else "Document & Financial Year Information"
        doc_group = QGroupBox(doc_title)
        doc_layout = QFormLayout(doc_group)

        fy_layout = QHBoxLayout()
        self.edit_fy = QLineEdit()
        self.edit_fy.setReadOnly(True)
        self.edit_fy.setStyleSheet("background-color: #F1F5F9; color: #1E3A8A; font-weight: bold;")
        self.edit_fy.setText(get_financial_year_str(datetime.date.today()))

        self.btn_change_fy = QPushButton("✏ Change")
        self.btn_change_fy.setObjectName("btnSecondary")
        self.btn_change_fy.setFixedWidth(96)
        self.btn_change_fy.clicked.connect(self.change_financial_year)

        fy_layout.addWidget(self.edit_fy)
        fy_layout.addWidget(self.btn_change_fy)

        self.combo_doc_type = QComboBox()
        if self.is_provisional:
            self.combo_doc_type.addItems(["Provisional Invoice"])
        else:
            self.combo_doc_type.addItems(["Tax Invoice", "Credit Note", "Debit Note"])
        self.combo_doc_type.currentIndexChanged.connect(self.on_doc_type_changed)

        self.edit_doc_no = QLineEdit()
        self.edit_doc_no.setReadOnly(True)
        self.edit_doc_no.setStyleSheet("background-color: #F1F5F9; color: #1E3A8A; font-weight: bold;")
        self.edit_doc_no.setPlaceholderText("Auto-generated Document Number")

        self.date_doc = QDateEdit(QDate.currentDate())
        self.date_doc.setCalendarPopup(True)
        self.date_doc.dateChanged.connect(self.on_doc_date_changed)

        doc_layout.addRow("Financial Year:", fy_layout)
        doc_layout.addRow("Document Type:", self.combo_doc_type)
        doc_layout.addRow("Document No:", self.edit_doc_no)
        doc_layout.addRow("Date:", self.date_doc)

        top_grid.addWidget(doc_group, 0, 0)

        # Original Ref Group Box
        self.ref_group = QGroupBox("Original Invoice Reference (For Notes)")
        ref_layout = QFormLayout(self.ref_group)

        self.combo_orig_inv_no = QComboBox()
        self.combo_orig_inv_no.setEditable(False)
        self.combo_orig_inv_no.currentIndexChanged.connect(self.on_orig_inv_selected)

        self.date_orig_inv = QDateEdit(QDate.currentDate())
        self.date_orig_inv.setCalendarPopup(True)
        self.date_orig_inv.setEnabled(False)

        ref_layout.addRow("Original Inv No:", self.combo_orig_inv_no)
        ref_layout.addRow("Original Inv Date (Auto):", self.date_orig_inv)

        top_grid.addWidget(self.ref_group, 0, 1)

        # Customer Details Group Box
        cust_group = QGroupBox("Client Information (select an existing client or type a new one)")
        cust_layout = QFormLayout(cust_group)

        # Editable combo: pick an existing client OR type a brand-new name inline.
        self.combo_cust_name = QComboBox()
        self.combo_cust_name.setEditable(True)
        self.combo_cust_name.setInsertPolicy(QComboBox.NoInsert)
        self.combo_cust_name.lineEdit().setPlaceholderText("Type or select client name")
        self.combo_cust_name.currentIndexChanged.connect(self.on_client_dropdown_selected)
        self.combo_cust_name.editTextChanged.connect(self.on_client_text_changed)

        self.edit_cust_mobile = QLineEdit()
        self.edit_cust_mobile.setPlaceholderText("Mobile (editable)")
        self.edit_cust_mobile.textChanged.connect(self.update_live_preview)

        self.edit_cust_address = QLineEdit()
        self.edit_cust_address.setPlaceholderText("Address (editable)")
        self.edit_cust_address.textChanged.connect(self.update_live_preview)

        self.edit_cust_gstin = QLineEdit()
        self.edit_cust_gstin.setPlaceholderText("GSTIN (editable) — state auto-detects")
        self.edit_cust_gstin.textChanged.connect(self.on_cust_gstin_changed)

        # State: choose from the standard list (auto-selected from GSTIN, editable).
        self.edit_cust_state = QComboBox()
        self.edit_cust_state.setEditable(True)
        self.edit_cust_state.setInsertPolicy(QComboBox.NoInsert)
        self.edit_cust_state.addItem("")
        for _st in sorted(set(GST_STATE_CODES.values())):
            self.edit_cust_state.addItem(_st)
        self.edit_cust_state.setStyleSheet("font-weight: bold; color: #1E3A8A;")
        self.edit_cust_state.lineEdit().setPlaceholderText("Select or auto-detect state")
        self.edit_cust_state.lineEdit().textEdited.connect(self._mark_state_manual)
        self.edit_cust_state.activated.connect(self._mark_state_manual)
        self._state_manual = False

        self.chk_save_client = QCheckBox("Save as new client to the database when I save this invoice")
        self.chk_save_client.setChecked(True)

        cust_layout.addRow("Client Name*:", self.combo_cust_name)
        cust_layout.addRow("Mobile No:", self.edit_cust_mobile)
        cust_layout.addRow("Address:", self.edit_cust_address)
        cust_layout.addRow("GSTIN:", self.edit_cust_gstin)
        cust_layout.addRow("State:", self.edit_cust_state)
        cust_layout.addRow("", self.chk_save_client)

        top_grid.addWidget(cust_group, 0, 2)
        top_grid.setColumnStretch(0, 1)
        top_grid.setColumnStretch(1, 1)
        top_grid.setColumnStretch(2, 2)

        layout.addLayout(top_grid)

        # 2. Service Input Form Box
        service_group = QGroupBox("Add Service Line")
        service_layout = QHBoxLayout(service_group)

        # Description: choose a previously-used service (autofills HSN/amount/GST)
        # or type a brand-new one.
        self.edit_service_name = QComboBox()
        self.edit_service_name.setEditable(True)
        self.edit_service_name.setInsertPolicy(QComboBox.NoInsert)
        self.edit_service_name.lineEdit().setPlaceholderText("Select a saved service or type a new one")
        self.edit_service_name.editTextChanged.connect(self.update_live_preview)
        self.edit_service_name.activated.connect(self.on_service_selected)

        self.edit_service_hsn = QLineEdit("9982")
        self.edit_service_hsn.setPlaceholderText("HSN/SAC")
        self.edit_service_hsn.setFixedWidth(80)
        self.edit_service_hsn.textChanged.connect(self.update_live_preview)

        self.spin_service_amount = QDoubleSpinBox()
        self.spin_service_amount.setRange(0.0, 10000000.0)
        self.spin_service_amount.setValue(0.0)
        self.spin_service_amount.setDecimals(2)
        self.spin_service_amount.setPrefix("₹")
        self.spin_service_amount.valueChanged.connect(self.calculate_service_preview)

        self.combo_service_gst = QComboBox()
        self.combo_service_gst.addItems(["18%", "0%", "0.1%", "0.25%", "1.5%", "3%", "5%", "40%"])
        self.combo_service_gst.setCurrentIndex(0)
        self.combo_service_gst.currentIndexChanged.connect(self.calculate_service_preview)

        self.lbl_service_total_preview = QLabel("Total: ₹0.00")
        font_preview = QFont("Segoe UI", 10)
        font_preview.setBold(True)
        self.lbl_service_total_preview.setFont(font_preview)
        self.lbl_service_total_preview.setStyleSheet("color: #1E3A8A;")

        self.btn_add_service = QPushButton("➕ Add Service")
        self.btn_add_service.setObjectName("btnSuccess")
        self.btn_add_service.clicked.connect(self.add_or_update_service_line)

        service_layout.addWidget(QLabel("Description:"))
        service_layout.addWidget(self.edit_service_name, 3)
        service_layout.addWidget(QLabel("HSN:"))
        service_layout.addWidget(self.edit_service_hsn)
        service_layout.addWidget(QLabel("Taxable Amount:"))
        service_layout.addWidget(self.spin_service_amount, 2)
        service_layout.addWidget(QLabel("GST %:"))
        service_layout.addWidget(self.combo_service_gst, 1)
        service_layout.addWidget(self.lbl_service_total_preview, 1)
        service_layout.addWidget(self.btn_add_service, 1)

        layout.addWidget(service_group)

        # 3. Services Table Widget
        self.table_items = QTableWidget()
        self.table_items.setAlternatingRowColors(True)
        self.table_items.setColumnCount(8)
        # Two-line headers so nothing is truncated in narrow columns.
        self.table_items.setHorizontalHeaderLabels([
            "S.\nNo.", "Service Description", "HSN/\nSAC", "Taxable\nAmount (₹)",
            "GST\nBreakdown", "GST\nAmount (₹)", "Total\n(₹)", "Actions"
        ])
        _ihdr = self.table_items.horizontalHeader()
        _ihdr.setStretchLastSection(False)
        _ihdr.setDefaultAlignment(Qt.AlignCenter)
        _ihdr.setMinimumHeight(40)
        # Description stretches to absorb remaining width; the rest are sized to fit.
        _ihdr.setSectionResizeMode(1, QHeaderView.Stretch)
        for _c in (0, 2, 3, 4, 5, 6, 7):
            _ihdr.setSectionResizeMode(_c, QHeaderView.Fixed)
        self.table_items.setColumnWidth(0, 40)    # S. No.
        self.table_items.setColumnWidth(2, 60)    # HSN/SAC
        self.table_items.setColumnWidth(3, 92)    # Taxable
        self.table_items.setColumnWidth(4, 88)    # GST Breakdown
        self.table_items.setColumnWidth(5, 92)    # GST Amount
        self.table_items.setColumnWidth(6, 92)    # Total
        self.table_items.setColumnWidth(7, 140)   # Actions
        self.table_items.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table_items.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table_items.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.table_items.verticalHeader().setVisible(False)

        layout.addWidget(self.table_items)

        # 4. Totals Calculation Box
        totals_layout = QHBoxLayout()

        self.lbl_words = QLabel("<b>Amount in Words:</b> Zero Rupees Only")
        self.lbl_words.setStyleSheet("background-color: #EFF6FF; border: 1px solid #93C5FD; padding: 10px; border-radius: 5px;")
        self.lbl_words.setWordWrap(True)

        totals_layout.addWidget(self.lbl_words, 2)

        summary_group = QGroupBox("Bill Total")
        summary_form = QFormLayout(summary_group)
        summary_form.setContentsMargins(15, 10, 15, 10)

        self.lbl_subtotal = QLabel("₹0.00")
        self.lbl_tax_breakdown = QLabel("IGST 18%: ₹0.00")
        self.lbl_tax_breakdown.setStyleSheet("font-weight: normal; color: #1E293B;")

        self.lbl_total_gst = QLabel("₹0.00")
        self.lbl_round_off = QLabel("₹0.00")
        self.lbl_grand_total = QLabel("₹0.00")
        font_gt = QFont("Segoe UI", 12)
        font_gt.setBold(True)
        self.lbl_grand_total.setFont(font_gt)
        self.lbl_grand_total.setStyleSheet("color: #1E3A8A;")

        summary_form.addRow("Subtotal:", self.lbl_subtotal)
        summary_form.addRow("Tax Breakdown:", self.lbl_tax_breakdown)
        summary_form.addRow("Total GST Amount:", self.lbl_total_gst)
        summary_form.addRow("Round Off:", self.lbl_round_off)
        summary_form.addRow("Grand Total:", self.lbl_grand_total)

        totals_layout.addWidget(summary_group, 1)
        layout.addLayout(totals_layout)

        # 5. Bottom Action Buttons Bar
        btn_bar = QHBoxLayout()

        self.btn_new = QPushButton("📄 New")
        self.btn_new.setObjectName("btnSecondary")
        self.btn_new.clicked.connect(self.reset_invoice_form)

        save_title = "💾 Save Provisional Invoice" if self.is_provisional else "💾 Save Invoice"
        self.btn_save = QPushButton(save_title)
        self.btn_save.setObjectName("btnSuccess")
        self.btn_save.clicked.connect(self.save_invoice)

        self.btn_export_pdf = QPushButton("📄 Export PDF")
        self.btn_export_pdf.clicked.connect(self.export_pdf)

        self.btn_preview_pdf = QPushButton("👁 Preview PDF")
        self.btn_preview_pdf.clicked.connect(self.preview_pdf)

        self.btn_print = QPushButton("🖨 Print")
        self.btn_print.clicked.connect(self.print_invoice)

        self.btn_clear = QPushButton("🧹 Clear")
        self.btn_clear.setObjectName("btnDanger")
        self.btn_clear.clicked.connect(self.confirm_clear_form)

        btn_bar.addWidget(self.btn_new)
        btn_bar.addWidget(self.btn_save)
        btn_bar.addWidget(self.btn_export_pdf)
        btn_bar.addWidget(self.btn_preview_pdf)
        btn_bar.addWidget(self.btn_print)
        btn_bar.addStretch()
        btn_bar.addWidget(self.btn_clear)

        layout.addLayout(btn_bar)

        # ---- Right-hand LIVE preview panel (updates side-by-side) ----
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_scroll.setWidget(left_widget)

        preview_panel = self._build_preview_panel()

        preview_panel.setMinimumWidth(440)
        preview_panel.setMaximumWidth(620)

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(left_scroll)
        splitter.addWidget(preview_panel)
        splitter.setStretchFactor(0, 3)
        splitter.setStretchFactor(1, 2)
        splitter.setSizes([860, 540])
        splitter.setChildrenCollapsible(False)
        outer.addWidget(splitter)

        self.update_live_preview()

    def _build_preview_panel(self):
        """Builds the live bill preview widget shown to the right of the form."""
        panel = QGroupBox("Live Bill Preview")
        v = QVBoxLayout(panel)
        v.setContentsMargins(8, 8, 8, 8)
        self.preview_view = QTextBrowser()
        self.preview_view.setOpenExternalLinks(False)
        self.preview_view.setStyleSheet(
            "QTextBrowser { background:#FFFFFF; border:1px solid #CBD5E1; border-radius:4px; }"
        )
        v.addWidget(self.preview_view)
        self._preview_qr_cache = (None, None)  # (uri, QPixmap)
        return panel

    def _preview_qr_pixmap(self, seller, amount):
        """Return a QPixmap of the UPI QR (cached by URI), or None."""
        uri = build_upi_uri(seller, amount)
        if not uri:
            return None
        if self._preview_qr_cache[0] == uri and self._preview_qr_cache[1] is not None:
            return self._preview_qr_cache[1]
        pil = make_qr_image(uri)
        if pil is None:
            return None
        try:
            import io
            buf = io.BytesIO()
            pil.save(buf, format="PNG")
            img = QImage.fromData(buf.getvalue(), "PNG")
            pix = QPixmap.fromImage(img)
            self._preview_qr_cache = (uri, pix)
            return pix
        except Exception:
            return None

    def update_live_preview(self):
        """Render the current form state as a live HTML invoice preview."""
        if not hasattr(self, "preview_view"):
            return

        seller = self.parent_app.seller_info if self.parent_app else DataManager.load_seller()
        data = self.get_invoice_data_from_form()

        # Include an in-progress (uncommitted) service line so the preview updates
        # as the user types, before pressing "Add Service".
        rows = list(data.get("items", []))
        draft_name = self.edit_service_name.currentText().strip()
        draft_amt = self.spin_service_amount.value()
        if self.editing_item_index == -1 and draft_name and draft_amt > 0:
            try:
                gpct = float(self.combo_service_gst.currentText().replace("%", ""))
            except ValueError:
                gpct = 0.0
            gamt = round(draft_amt * gpct / 100.0, 2)
            rows.append({
                "name": draft_name, "hsn": self.edit_service_hsn.text().strip(),
                "amount": draft_amt, "gst_pct": gpct, "gst_amt": gamt,
                "total": draft_amt + gamt, "_draft": True,
            })

        def esc(s):
            return (str(s or "")
                    .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))

        subtotal = sum(i["amount"] for i in rows)
        total_gst = sum(i["gst_amt"] for i in rows)
        grand_total = round(subtotal + total_gst)

        due = InvoicePDFGenerator._fmt_date(InvoicePDFGenerator._due_date(data))
        dated = InvoicePDFGenerator._fmt_date(data.get("doc_date", ""))

        cust_block = esc(data.get("customer_name") or "—")
        for extra in (data.get("customer_address"),
                      (f"GSTIN: {data.get('customer_gstin')}" if data.get("customer_gstin") else ""),
                      (f"Ph: {data.get('customer_mobile')}" if data.get("customer_mobile") else "")):
            if extra:
                cust_block += "<br>" + esc(extra)

        item_rows_html = ""
        for idx, it in enumerate(rows, 1):
            draft = it.get("_draft")
            style = ' style="color:#94A3B8; font-style:italic;"' if draft else ''
            item_rows_html += (
                f"<tr{style}>"
                f"<td align='center'>{idx}</td>"
                f"<td>{esc(it.get('name'))}{' (typing…)' if draft else ''}</td>"
                f"<td align='center'>{esc(it.get('hsn'))}</td>"
                f"<td align='right' style='white-space:nowrap;'>{format_inr(it.get('amount', 0))}</td>"
                f"</tr>"
            )
        if not item_rows_html:
            item_rows_html = "<tr><td colspan='4' align='center' style='color:#94A3B8;'>No service lines yet</td></tr>"

        gst_disp = "NIL" if abs(total_gst) < 0.005 else format_inr(total_gst)
        words = number_to_words(grand_total)

        upi_id = (seller.get("upi_id") or "").strip()
        qr_pix = self._preview_qr_pixmap(seller, grand_total) if (upi_id and grand_total > 0) else None
        qr_html = ""
        if qr_pix is not None:
            self.preview_view.document().addResource(
                QTextDocument.ImageResource, QUrl("upiqr"), qr_pix
            )
            qr_html = (
                "<div align='center'><b>Or, Scan below to Pay</b><br>"
                "<img src='upiqr' width='120' height='120'><br>"
                f"<span style='font-size:8pt;'>UPI ID: {esc(upi_id)} &nbsp;|&nbsp; "
                f"Amount ₹{grand_total:,.0f}</span></div>"
            )
        elif upi_id:
            qr_html = "<div align='center' style='color:#94A3B8;'>UPI QR will appear once amount &gt; 0</div>"

        logo_html = ""
        logo_path = seller.get("logo_path", "")
        if logo_path and os.path.exists(logo_path):
            try:
                pix = QPixmap(logo_path)
                if not pix.isNull():
                    self.preview_view.document().addResource(
                        QTextDocument.ImageResource, QUrl("bizlogo"), pix)
                    logo_html = "<img src='bizlogo' width='70'>"
            except Exception:
                logo_html = ""

        tagline_html = (f"<span style=\"font-size:8.5pt; font-weight:bold; color:#64748B;\">"
                        f"{esc((seller.get('tagline') or '').upper())}</span><br>") if seller.get("tagline") else ""
        html = f"""
        <div style="font-family:'Segoe UI',Arial; color:#1F2937; font-size:9pt;">
          <table width='100%' style="table-layout:fixed;"><tr>
            <td valign='top' width='72%'>
              <span style="font-size:13pt; font-weight:bold; color:#1E3A8A;">{esc(seller.get('trade_name') or 'Business Name')}</span><br>
              {tagline_html}
            </td>
            <td valign='top' align='right' width='28%'>{logo_html}</td>
          </tr></table>
          <table width='100%' style="table-layout:fixed;"><tr>
            <td valign='top' width='58%' style="font-size:8pt;">
              {('<b>PAN:</b> ' + esc(seller.get('pan')) + '<br>') if seller.get('pan') else ''}
              {('<b>GSTIN:</b> ' + esc(seller.get('gstin')) + '<br>') if seller.get('gstin') else ''}
              {esc(seller.get('address'))}<br>
              {('Ph: ' + esc(seller.get('mobile')) + '<br>') if seller.get('mobile') else ''}
              {('Email: ' + esc(seller.get('email'))) if seller.get('email') else ''}
            </td>
            <td valign='top' align='right' width='42%' style="font-size:8pt;">
              <span style="font-size:12pt; font-weight:bold; color:#1E3A8A;">{esc(data.get('doc_type','Invoice')).upper()}</span><br>
              <b>Invoice No.</b> {esc(data.get('doc_no') or '—')}<br>
              <b>Dated</b> {esc(dated)}<br>
              <b>Due Date</b> {esc(due)}
            </td>
          </tr></table>
          <p style="margin:6px 0 2px 0;"><b style="color:#1E3A8A;">Bill To-</b><br>{cust_block}</p>
          <table width='100%' border='1' cellspacing='0' cellpadding='4'
                 style="border-collapse:collapse; border-color:#94A3B8; font-size:8pt; table-layout:fixed;">
            <tr style="background:#EAF0F8; color:#1E3A8A; font-weight:bold;">
              <td align='center' width='9%'>S.NO.</td><td width='51%'>DESCRIPTION</td>
              <td align='center' width='17%'>SAC&nbsp;Code</td>
              <td align='center' width='23%' style="white-space:nowrap;">Amount&nbsp;(₹)</td>
            </tr>
            {item_rows_html}
            <tr><td></td><td><b>GST</b></td><td></td><td align='right' style="white-space:nowrap;">{gst_disp}</td></tr>
            <tr style="background:#EAF0F8; font-weight:bold;">
              <td></td><td>Total</td><td></td><td align='right' style="white-space:nowrap;">₹{format_inr(grand_total)}</td>
            </tr>
          </table>
          <p style="margin:6px 0;"><b>Amount In Words-</b> {esc(words)}.</p>
          <table width='100%'><tr>
            <td valign='top' style="font-size:8pt;">
              <b style="color:#1E3A8A;">Payment Details-</b><br>
              Bank: {esc(seller.get('bank_name') or '—')}<br>
              A/C: {esc(seller.get('account_no') or '—')}<br>
              IFSC: {esc(seller.get('ifsc_code') or '—')}<br>
              Branch: {esc(seller.get('branch') or '—')}
              {('<br>UPI: ' + esc(upi_id)) if upi_id else ''}
            </td>
            <td valign='top' width='45%'>{qr_html}</td>
          </tr></table>
        </div>
        """
        self.preview_view.setHtml(html)

    def reload_clients_dropdown(self):
        clients = DataManager.load_clients()
        current = self.combo_cust_name.currentText() if hasattr(self, "combo_cust_name") else ""
        self.combo_cust_name.blockSignals(True)
        self.combo_cust_name.clear()
        self.combo_cust_name.addItem("-- Select Client --")
        for c in clients:
            self.combo_cust_name.addItem(c.get("name", ""))
        # Typeahead completer over existing client names (both pick & type work).
        names = [c.get("name", "") for c in clients]
        completer = QCompleter(names, self)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setFilterMode(Qt.MatchContains)
        self.combo_cust_name.setCompleter(completer)
        if current and current != "-- Select Client --":
            self.combo_cust_name.setCurrentText(current)
        self.combo_cust_name.blockSignals(False)

    def reload_service_catalog(self):
        """Populate the Service Description dropdown from previously-used services."""
        catalog = DataManager.load_catalog()
        names = sorted({(it.get("name") or "").strip()
                        for it in catalog.get("items", []) if (it.get("name") or "").strip()})
        current = self.edit_service_name.currentText()
        self.edit_service_name.blockSignals(True)
        self.edit_service_name.clear()
        self.edit_service_name.addItem("")
        for n in names:
            self.edit_service_name.addItem(n)
        completer = QCompleter(names, self)
        completer.setCaseSensitivity(Qt.CaseInsensitive)
        completer.setFilterMode(Qt.MatchContains)
        self.edit_service_name.setCompleter(completer)
        self.edit_service_name.setCurrentText(current)
        self.edit_service_name.blockSignals(False)

    def on_service_selected(self, _index=None):
        """Autofill HSN / amount / GST when a saved service is chosen."""
        name = self.edit_service_name.currentText().strip()
        if name:
            catalog = DataManager.load_catalog()
            match = next((it for it in catalog.get("items", [])
                          if (it.get("name") or "").strip().lower() == name.lower()), None)
            if match:
                self.edit_service_hsn.setText(str(match.get("hsn", "9982") or "9982"))
                self.spin_service_amount.setValue(float(match.get("amount", 0.0) or 0.0))
                gpct = match.get("gst_pct", 18.0)
                gidx = self.combo_service_gst.findText(f"{gpct:g}%")
                if gidx >= 0:
                    self.combo_service_gst.setCurrentIndex(gidx)
        self.calculate_service_preview()

    def on_client_dropdown_selected(self):
        cust_name = self.combo_cust_name.currentText()
        if cust_name == "-- Select Client --" or not cust_name:
            self.populate_orig_inv_dropdown()
            self.refresh_services_table()
            self.recalculate_totals()
            return

        # Only auto-fill when an EXISTING client is chosen; typed-in new names
        # leave whatever the user has entered untouched.
        clients = DataManager.load_clients()
        matched = next((c for c in clients if c.get("name", "").strip().lower() == cust_name.strip().lower()), None)
        if matched:
            self.edit_cust_mobile.setText(matched.get("mobile", ""))
            self.edit_cust_address.setText(matched.get("address", ""))
            self.edit_cust_gstin.setText(matched.get("gstin", ""))
            st = matched.get("state", "")
            if not st and matched.get("gstin"):
                st = get_state_from_gstin(matched.get("gstin"))
            self.edit_cust_state.setCurrentText(st)
            self._state_manual = False

        self.populate_orig_inv_dropdown()
        self.refresh_services_table()
        self.recalculate_totals()

    def on_client_text_changed(self, _text):
        """User is typing a client name (possibly a brand-new client)."""
        self.update_live_preview()

    def on_cust_gstin_changed(self):
        """Auto-derive the client state from GSTIN unless the user set it manually."""
        g = self.edit_cust_gstin.text().strip()
        if not self._state_manual:
            st = get_state_from_gstin(g) if len(g) >= 2 else ""
            if st:
                self.edit_cust_state.blockSignals(True)
                self.edit_cust_state.setCurrentText(st)
                self.edit_cust_state.blockSignals(False)
        self.update_live_preview()

    def _mark_state_manual(self, _text):
        self._state_manual = True
        self.update_live_preview()

    def populate_orig_inv_dropdown(self):
        if self.is_provisional:
            self.ref_group.setVisible(False)
            return

        invoices = DataManager.load_invoices()
        cust_name = self.combo_cust_name.currentText()

        self.combo_orig_inv_no.blockSignals(True)
        self.combo_orig_inv_no.clear()
        self.combo_orig_inv_no.addItem("-- Select Original Invoice --")

        for inv in invoices:
            if cust_name and cust_name != "-- Select Client --":
                if inv.get("customer_name", "").strip().lower() != cust_name.strip().lower():
                    continue
            if inv.get("doc_type") == "Tax Invoice":
                self.combo_orig_inv_no.addItem(inv.get("doc_no", ""))

        self.combo_orig_inv_no.blockSignals(False)

    def on_orig_inv_selected(self):
        doc_no = self.combo_orig_inv_no.currentText()
        if doc_no == "-- Select Original Invoice --" or not doc_no:
            return
        invoices = DataManager.load_invoices()
        matched = next((i for i in invoices if i.get("doc_no") == doc_no), None)
        if matched and matched.get("doc_date"):
            qdate = QDate.fromString(matched.get("doc_date"), "yyyy-MM-dd")
            if qdate.isValid():
                self.date_orig_inv.setDate(qdate)

    def on_doc_date_changed(self):
        if not self.custom_fy:
            self.edit_fy.setText(get_financial_year_str(self.date_doc.date().toString("yyyy-MM-dd")))
        self.generate_new_doc_number()

    def change_financial_year(self):
        pwd, ok = prompt_password(self, "Password Required", "Enter Admin Password to change Financial Year:")
        if not ok:
            return

        if pwd != ADMIN_PASSWORD:
            show_msg(self, "Access Denied", "Invalid Password! Cannot change Financial Year.", "critical")
            return

        text, ok_fy = QInputDialog.getText(self, "Change Financial Year", "Enter Financial Year (e.g. 2025-26, 2026-27):", QLineEdit.Normal, self.edit_fy.text())
        if ok_fy and text.strip():
            self.custom_fy = text.strip()
            self.edit_fy.setText(self.custom_fy)
            self.generate_new_doc_number()

    def on_doc_type_changed(self):
        doc_type = self.combo_doc_type.currentText()
        ref_needed = (not self.is_provisional) and doc_type in ["Credit Note", "Debit Note"]
        self.ref_group.setVisible(ref_needed)
        if ref_needed:
            self.populate_orig_inv_dropdown()
        # Collapse the reference column when hidden so Document Info + Client Info
        # spread across the full width instead of leaving an empty gap.
        if hasattr(self, "top_grid"):
            self.top_grid.setColumnStretch(0, 2)
            self.top_grid.setColumnStretch(1, 2 if ref_needed else 0)
            self.top_grid.setColumnStretch(2, 3)
        self.generate_new_doc_number()

    def generate_new_doc_number(self):
        doc_type = self.combo_doc_type.currentText()
        doc_date = self.date_doc.date().toString("yyyy-MM-dd")
        fy = self.edit_fy.text().strip() or get_financial_year_str(doc_date)
        new_no = DataManager.get_next_doc_no(doc_type, doc_date, fy_override=fy, is_provisional=self.is_provisional)
        self.edit_doc_no.setText(new_no)
        self.update_live_preview()

    def calculate_service_preview(self):
        amount = self.spin_service_amount.value()
        gst_str = self.combo_service_gst.currentText().replace("%", "")
        try:
            gst_pct = float(gst_str)
        except ValueError:
            gst_pct = 0.0

        gst_amt = amount * (gst_pct / 100.0)
        total = amount + gst_amt
        self.lbl_service_total_preview.setText(f"Total: ₹{total:,.2f}")
        self.update_live_preview()

    def add_or_update_service_line(self):
        name = self.edit_service_name.currentText().strip()
        if not name:
            show_msg(self, "Validation Error", "Please enter service description.", "warning")
            self.edit_service_name.setFocus()
            return

        hsn = self.edit_service_hsn.text().strip() or "9982"
        amount = round(self.spin_service_amount.value(), 2)
        gst_str = self.combo_service_gst.currentText().replace("%", "")
        try:
            gst_pct = float(gst_str)
        except ValueError:
            gst_pct = 0.0

        gst_amt = round(amount * (gst_pct / 100.0), 2)
        total = round(amount + gst_amt, 2)

        item_data = {
            "name": name,
            "hsn": hsn,
            "qty": 1.0,
            "rate": amount,
            "amount": amount,
            "gst_pct": gst_pct,
            "gst_amt": gst_amt,
            "total": total
        }

        if self.editing_item_index >= 0:
            self.current_items[self.editing_item_index] = item_data
            self.editing_item_index = -1
            self.btn_add_service.setText("➕ Add Service")
        else:
            self.current_items.append(item_data)

        self.edit_service_name.setCurrentText("")
        self.edit_service_hsn.setText("9982")
        self.spin_service_amount.setValue(0.0)
        self.edit_service_name.setFocus()

        self.refresh_services_table()
        self.recalculate_totals()

    def refresh_services_table(self):
        self.table_items.setRowCount(0)
        cust_gstin = self.edit_cust_gstin.text().strip()
        cust_st = self.edit_cust_state.currentText().strip()
        is_delhi = is_delhi_client(cust_gstin, cust_st)

        for idx, item in enumerate(self.current_items):
            self.table_items.insertRow(idx)

            gst_pct = item['gst_pct']
            amount = item['amount']
            gst_amt = item['gst_amt']
            hsn = item.get('hsn', '9982')

            if is_delhi:
                half_pct = gst_pct / 2.0
                half_amt = gst_amt / 2.0
                gst_breakdown_disp = f"CGST {half_pct:g}%\nSGST {half_pct:g}%"
                gst_amount_disp = f"₹{half_amt:,.2f}\n₹{half_amt:,.2f}"
            else:
                gst_breakdown_disp = f"IGST {gst_pct:g}%"
                gst_amount_disp = f"₹{gst_amt:,.2f}"

            self.table_items.setItem(idx, 0, QTableWidgetItem(str(idx + 1)))
            self.table_items.setItem(idx, 1, QTableWidgetItem(item["name"]))
            self.table_items.setItem(idx, 2, QTableWidgetItem(hsn))
            self.table_items.setItem(idx, 3, QTableWidgetItem(f"₹{amount:,.2f}"))
            self.table_items.setItem(idx, 4, QTableWidgetItem(gst_breakdown_disp))
            self.table_items.setItem(idx, 5, QTableWidgetItem(gst_amount_disp))
            self.table_items.setItem(idx, 6, QTableWidgetItem(f"₹{item['total']:,.2f}"))

            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(2, 2, 2, 2)
            actions_layout.setSpacing(6)

            btn_edit = QPushButton("✏")
            btn_edit.setFixedSize(60, 26)
            btn_edit.setToolTip("Edit this line")
            btn_edit.setObjectName("btnSecondary")
            btn_edit.clicked.connect(lambda _, i=idx: self.edit_service_line(i))

            btn_del = QPushButton("🗑")
            btn_del.setFixedSize(60, 26)
            btn_del.setToolTip("Delete this line")
            btn_del.setObjectName("btnDanger")
            btn_del.clicked.connect(lambda _, i=idx: self.delete_service_line(i))

            actions_layout.addWidget(btn_edit)
            actions_layout.addWidget(btn_del)
            actions_layout.setAlignment(Qt.AlignCenter)

            self.table_items.setCellWidget(idx, 7, actions_widget)

    def edit_service_line(self, index):
        if 0 <= index < len(self.current_items):
            item = self.current_items[index]
            self.edit_service_name.setCurrentText(item["name"])
            self.edit_service_hsn.setText(item.get("hsn", "9982"))
            self.spin_service_amount.setValue(item["amount"])
            gst_text = f"{item['gst_pct']:g}%"
            gst_idx = self.combo_service_gst.findText(gst_text)
            if gst_idx >= 0:
                self.combo_service_gst.setCurrentIndex(gst_idx)

            self.editing_item_index = index
            self.btn_add_service.setText("💾 Update")
            self.edit_service_name.setFocus()

    def delete_service_line(self, index):
        if 0 <= index < len(self.current_items):
            del self.current_items[index]
            self.refresh_services_table()
            self.recalculate_totals()

    def recalculate_totals(self):
        subtotal = sum(i["amount"] for i in self.current_items)
        total_gst = sum(i["gst_amt"] for i in self.current_items)
        raw_total = subtotal + total_gst

        grand_total = round(raw_total)
        round_off = grand_total - raw_total

        cust_gstin = self.edit_cust_gstin.text().strip()
        cust_st = self.edit_cust_state.currentText().strip()

        avg_gst_pct = 18.0
        if self.current_items:
            avg_gst_pct = self.current_items[0]["gst_pct"]

        if is_delhi_client(cust_gstin, cust_st):
            half_pct = avg_gst_pct / 2.0
            cgst_sgst = total_gst / 2.0
            self.lbl_tax_breakdown.setText(f"CGST {half_pct:g}%: ₹{cgst_sgst:,.2f} | SGST {half_pct:g}%: ₹{cgst_sgst:,.2f}")
        else:
            self.lbl_tax_breakdown.setText(f"IGST {avg_gst_pct:g}%: ₹{total_gst:,.2f}")

        self.lbl_subtotal.setText(f"₹{subtotal:,.2f}")
        self.lbl_total_gst.setText(f"₹{total_gst:,.2f}")
        self.lbl_round_off.setText(f"₹{round_off:+.2f}")
        self.lbl_grand_total.setText(f"₹{grand_total:,.2f}")

        words = number_to_words(grand_total)
        self.lbl_words.setText(f"<b>Amount in Words:</b> {words}")

        self.update_live_preview()

    def get_invoice_data_from_form(self):
        doc_type = self.combo_doc_type.currentText()
        doc_no = self.edit_doc_no.text().strip()
        doc_date = self.date_doc.date().toString("yyyy-MM-dd")

        cust_name = self.combo_cust_name.currentText().strip()
        cust_mobile = self.edit_cust_mobile.text().strip()
        cust_address = self.edit_cust_address.text().strip()
        cust_gstin = self.edit_cust_gstin.text().strip()
        cust_state = self.edit_cust_state.currentText().strip()

        orig_inv_no = self.combo_orig_inv_no.currentText().strip() if doc_type in ["Credit Note", "Debit Note"] else ""
        orig_inv_date = self.date_orig_inv.date().toString("yyyy-MM-dd") if doc_type in ["Credit Note", "Debit Note"] else ""

        subtotal = sum(i["amount"] for i in self.current_items)
        total_gst = sum(i["gst_amt"] for i in self.current_items)
        raw_total = subtotal + total_gst
        grand_total = round(raw_total)
        round_off = grand_total - raw_total

        return {
            "doc_type": doc_type,
            "doc_no": doc_no,
            "doc_date": doc_date,
            "financial_year": self.edit_fy.text().strip(),
            "is_provisional": self.is_provisional,
            "invoice_issued": "-",
            "customer_name": cust_name,
            "customer_mobile": cust_mobile,
            "customer_address": cust_address,
            "customer_gstin": cust_gstin,
            "customer_state": cust_state,
            "orig_inv_no": orig_inv_no,
            "orig_inv_date": orig_inv_date,
            "items": self.current_items,
            "subtotal": subtotal,
            "total_gst": total_gst,
            "round_off": round_off,
            "grand_total": grand_total,
            "payments": [],
            "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }

    def validate_form(self):
        if self.parent_app and not self.parent_app.is_seller_info_complete():
            show_msg(self, "Business Settings Incomplete", "Cannot create invoice! Please complete all required details in Business Settings first.", "critical")
            self.parent_app.tabs.setCurrentIndex(5)
            return False

        doc_no = self.edit_doc_no.text().strip()
        if not doc_no:
            show_msg(self, "Validation Error", "Document number is required.", "warning")
            return False

        cust_name = self.combo_cust_name.currentText().strip()
        if not cust_name or cust_name == "-- Select Client --":
            show_msg(self, "Validation Error", "Please select a client from the Client Details database.", "warning")
            self.combo_cust_name.setFocus()
            return False

        doc_type = self.combo_doc_type.currentText()
        if doc_type in ["Credit Note", "Debit Note"]:
            orig_no = self.combo_orig_inv_no.currentText().strip()
            if not orig_no or orig_no == "-- Select Original Invoice --":
                show_msg(self, "Validation Error", f"Original Invoice Number is required for {doc_type}.", "warning")
                self.combo_orig_inv_no.setFocus()
                return False

        if not self.current_items:
            show_msg(self, "Validation Error", "Please add at least one service line before saving.", "warning")
            return False

        return True

    def save_invoice(self):
        if not self.validate_form():
            return False

        data = self.get_invoice_data_from_form()

        # Optionally upsert the client to the database from the inline fields.
        self.maybe_save_client_from_form(data)

        if DataManager.save_invoice(data):
            if self.parent_app:
                self.parent_app.statusBar().showMessage(f"Successfully saved {data['doc_type']} #{data['doc_no']}", 5000)
            show_msg(self, "Saved", f"{data['doc_type']} #{data['doc_no']} saved successfully!", "info")
            if self.is_provisional and self.parent_app:
                self.parent_app.prov_log_widget.refresh_log()
            elif self.parent_app:
                self.parent_app.tax_log_widget.refresh_log()
            self.reload_clients_dropdown()
            self.reload_service_catalog()
            if self.parent_app:
                other = (self.parent_app.tax_invoice_widget if self.is_provisional
                         else self.parent_app.prov_invoice_widget)
                if other is not self:
                    other.reload_service_catalog()
                    other.reload_clients_dropdown()
            return True
        return False

    def maybe_save_client_from_form(self, data):
        """Add/update the client record from the inline invoice fields when the
        'Save as new client' toggle is on."""
        if not self.chk_save_client.isChecked():
            return
        name = data.get("customer_name", "").strip()
        if not name or name == "-- Select Client --":
            return
        client_record = {
            "name": name,
            "mobile": data.get("customer_mobile", "").strip(),
            "address": data.get("customer_address", "").strip(),
            "gstin": data.get("customer_gstin", "").strip(),
            "state": data.get("customer_state", "").strip(),
        }
        try:
            DataManager.save_client(client_record)
            if self.parent_app:
                self.parent_app.reload_all_client_dropdowns()
                if hasattr(self.parent_app, "clients_widget"):
                    self.parent_app.clients_widget.refresh_clients_table()
        except Exception as e:
            print(f"Could not save client inline: {e}")

    def get_pdf_target_path(self, data):
        fy = data.get("financial_year", get_financial_year_str(data.get("doc_date")))
        if self.is_provisional or data.get("doc_type") == "Provisional Invoice":
            folder_name = "Provisional Invoice Folder"
        else:
            folder_name = "Tax Invoice Folder"

        sub_dir = os.path.join(PDF_DIR, folder_name, fy)
        os.makedirs(sub_dir, exist_ok=True)
        pdf_filename = f"{data['doc_no'].replace('/', '_')}.pdf"
        return os.path.join(sub_dir, pdf_filename)

    def _seller(self):
        return self.parent_app.seller_info if self.parent_app else DataManager.load_seller()

    def _generate_pdf_safe(self, data, seller_info, pdf_path):
        """Generate the PDF, transparently falling back to a timestamped file if
        the target is locked (e.g. already open in a PDF viewer).
        Returns (actual_path, was_locked)."""
        try:
            InvoicePDFGenerator.generate_pdf(data, seller_info, pdf_path)
            return pdf_path, False
        except (PermissionError, OSError):
            base, ext = os.path.splitext(pdf_path)
            alt = f"{base}_{datetime.datetime.now().strftime('%H%M%S')}{ext}"
            InvoicePDFGenerator.generate_pdf(data, seller_info, alt)
            return alt, True

    def export_pdf(self):
        if not self.validate_form():
            return None

        self.save_invoice()

        data = self.get_invoice_data_from_form()
        pdf_path = self.get_pdf_target_path(data)

        try:
            actual, was_locked = self._generate_pdf_safe(data, self._seller(), pdf_path)
        except Exception as e:
            show_msg(self, "PDF Error", f"Failed to generate PDF:\n{e}", "critical")
            return None

        if self.parent_app:
            self.parent_app.statusBar().showMessage(f"PDF exported: {actual}", 6000)
        # Open the exported PDF so the user gets immediate confirmation.
        ok, how = open_document(actual)
        if not ok:
            show_msg(self, "PDF Exported",
                     f"Invoice PDF saved to:\n{actual}\n\n(Could not auto-open: {how})", "info")
        elif was_locked:
            show_msg(self, "PDF Exported",
                     "The original file was open, so a new copy was saved and opened:\n"
                     f"{actual}\n\nClose the old copy to overwrite it next time.", "warning")
        return actual

    def preview_pdf(self):
        """Quick preview without committing/saving the invoice to the ledger."""
        if not self.current_items:
            show_msg(self, "Nothing to Preview", "Add at least one service line first.", "warning")
            return
        data = self.get_invoice_data_from_form()
        if not data.get("doc_no"):
            self.generate_new_doc_number()
            data = self.get_invoice_data_from_form()

        preview_dir = os.path.join(PDF_DIR, "_previews")
        os.makedirs(preview_dir, exist_ok=True)
        safe_no = (data.get("doc_no") or "preview").replace("/", "_")
        preview_path = os.path.join(preview_dir, f"PREVIEW_{safe_no}.pdf")

        try:
            actual, _ = self._generate_pdf_safe(data, self._seller(), preview_path)
        except Exception as e:
            show_msg(self, "Preview Error", f"Could not build preview:\n{e}", "critical")
            return

        ok, how = open_document(actual)
        if not ok:
            show_msg(self, "Preview Ready",
                     f"Preview saved to:\n{actual}\n\n(Could not auto-open: {how})", "info")
        elif self.parent_app:
            self.parent_app.statusBar().showMessage("Opened PDF preview (not saved to ledger).", 5000)

    def print_invoice(self):
        if not self.validate_form():
            return
        self.save_invoice()
        data = self.get_invoice_data_from_form()
        pdf_path = self.get_pdf_target_path(data)
        try:
            actual, _ = self._generate_pdf_safe(data, self._seller(), pdf_path)
        except Exception as e:
            show_msg(self, "PDF Error", f"Failed to generate PDF for printing:\n{e}", "critical")
            return

        ok, how = open_document(actual, print_it=True)
        if not ok:
            show_msg(self, "Print", f"PDF saved at:\n{actual}\n\nCould not send to printer: {how}", "warning")
        elif self.parent_app:
            msg = "Sent to system print service." if how == "print" else "Opened PDF — use your viewer's Print."
            self.parent_app.statusBar().showMessage(msg, 5000)

    def confirm_clear_form(self):
        reply = ask_question(self, "Clear Form", "Are you sure you want to clear all form fields?")
        if reply == QMessageBox.Yes:
            self.reset_invoice_form()

    def reset_invoice_form(self):
        self.current_items = []
        self.editing_item_index = -1
        self.custom_fy = None
        self.btn_add_service.setText("➕ Add Service")

        self.combo_cust_name.setCurrentIndex(0)
        self.combo_cust_name.setCurrentText("-- Select Client --")
        self.edit_cust_mobile.clear()
        self.edit_cust_address.clear()
        self.edit_cust_gstin.clear()
        self.edit_cust_state.setCurrentText("")
        self._state_manual = False
        self.chk_save_client.setChecked(True)
        self.combo_orig_inv_no.clear()

        self.edit_service_name.setCurrentText("")
        self.edit_service_hsn.setText("9982")
        self.spin_service_amount.setValue(0.0)

        self.edit_fy.setText(get_financial_year_str(self.date_doc.date().toString("yyyy-MM-dd")))
        self.generate_new_doc_number()
        self.refresh_services_table()
        self.recalculate_totals()
        if self.parent_app:
            self.parent_app.statusBar().showMessage("Form cleared.", 3000)

    def prefill_for_new_invoice(self, inv_data):
        """Prefill this (Tax Invoice) form from an approved provisional invoice.

        A fresh main-invoice number is generated; the provisional number is not
        reused. Returns the new document number.
        """
        self.reset_invoice_form()

        type_idx = self.combo_doc_type.findText("Tax Invoice")
        if type_idx >= 0:
            self.combo_doc_type.setCurrentIndex(type_idx)

        if inv_data.get("doc_date"):
            qdate = QDate.fromString(inv_data.get("doc_date"), "yyyy-MM-dd")
            if qdate.isValid():
                self.date_doc.setDate(qdate)

        c_idx = self.combo_cust_name.findText(inv_data.get("customer_name", ""))
        if c_idx >= 0:
            self.combo_cust_name.setCurrentIndex(c_idx)
        else:
            self.combo_cust_name.setCurrentText(inv_data.get("customer_name", ""))
            self.edit_cust_mobile.setText(inv_data.get("customer_mobile", ""))
            self.edit_cust_address.setText(inv_data.get("customer_address", ""))
            self.edit_cust_gstin.setText(inv_data.get("customer_gstin", ""))
            self.edit_cust_state.setCurrentText(inv_data.get("customer_state", ""))
            self._state_manual = True

        self.current_items = [dict(it) for it in inv_data.get("items", [])]
        self.editing_item_index = -1
        self.refresh_services_table()

        # Generate a fresh main Tax Invoice number for the current FY/date.
        self.generate_new_doc_number()
        self.recalculate_totals()
        return self.edit_doc_no.text().strip()


# =============================================================================
# REUSABLE INVOICE LOG WIDGET
# =============================================================================

class InvoiceLogWidget(QWidget):
    """Reusable widget for Saved Tax Invoices Log or Saved Provisional Invoices Log."""
    def __init__(self, is_provisional=False, parent_app=None):
        super().__init__()
        self.is_provisional = is_provisional
        self.parent_app = parent_app

        self.all_invoices = []
        self.filtered_invoices = []

        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # Dashboard Metrics Row
        metrics_layout = QHBoxLayout()

        self.card_total_count = self.create_metric_card("Total Documents", "0", "#3B82F6", 0.0, 0.0, 0.0, 0.0, 0.0, "0 Docs")
        self.card_total_sales = self.create_metric_card("Gross Sales (Invoices)", "₹0.00", "#16A34A", 0.0, 0.0, 0.0, 0.0, 0.0, "0 Docs")
        self.card_total_db = self.create_metric_card("Total Debit Notes", "₹0.00", "#2563EB", 0.0, 0.0, 0.0, 0.0, 0.0, "0 Docs")
        self.card_total_cr = self.create_metric_card("Total Credit Notes", "₹0.00", "#DC2626", 0.0, 0.0, 0.0, 0.0, 0.0, "0 Docs")
        self.card_net_revenue = self.create_metric_card("Net Revenue", "₹0.00", "#1E3A8A", 0.0, 0.0, 0.0, 0.0, 0.0, "Net Total")

        metrics_layout.addWidget(self.card_total_count)
        metrics_layout.addWidget(self.card_total_sales)
        metrics_layout.addWidget(self.card_total_db)
        metrics_layout.addWidget(self.card_total_cr)
        metrics_layout.addWidget(self.card_net_revenue)

        layout.addLayout(metrics_layout)

        box_title = "Search_Filter Saved Provisional Invoices Log" if self.is_provisional else "Search_Filter Saved Invoices Log"
        filter_group = QGroupBox(box_title)
        filter_layout = QHBoxLayout(filter_group)

        self.edit_search = QLineEdit()
        self.edit_search.setPlaceholderText("Search Doc No, Client, Services...")
        self.edit_search.textChanged.connect(self.filter_invoices)

        self.combo_type_filter = QComboBox()
        if self.is_provisional:
            self.combo_type_filter.addItems(["Provisional Invoice"])
        else:
            self.combo_type_filter.addItems(["All Document Types", "Tax Invoice", "Credit Note", "Debit Note"])
        self.combo_type_filter.currentIndexChanged.connect(self.filter_invoices)

        self.combo_quarter_filter = QComboBox()
        self.combo_quarter_filter.addItems(["All Quarters", "Q1 (Apr-Jun)", "Q2 (Jul-Sep)", "Q3 (Oct-Dec)", "Q4 (Jan-Mar)"])
        self.combo_quarter_filter.currentIndexChanged.connect(self.filter_invoices)

        self.combo_month_filter = QComboBox()
        self.combo_month_filter.addItems([
            "All Months", "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ])
        self.combo_month_filter.currentIndexChanged.connect(self.filter_invoices)

        self.btn_gstr1_report = QPushButton("📋 GSTR-1 Summary")
        self.btn_gstr1_report.setObjectName("btnSuccess")
        self.btn_gstr1_report.clicked.connect(self.show_gstr1_summary_dialog)

        self.btn_refresh = QPushButton("🔄 Refresh")
        self.btn_refresh.setObjectName("btnSecondary")
        self.btn_refresh.clicked.connect(self.refresh_log)

        self.btn_export_excel = QPushButton("📊 Export Excel")
        self.btn_export_excel.clicked.connect(self.export_ledger_to_excel)

        self.btn_audit_log = QPushButton("📜 Edit Log")
        self.btn_audit_log.setObjectName("btnSecondary")
        self.btn_audit_log.clicked.connect(self.show_audit_log_dialog)

        filter_layout.addWidget(QLabel("Search:"))
        filter_layout.addWidget(self.edit_search, 2)
        filter_layout.addWidget(QLabel("Type:"))
        filter_layout.addWidget(self.combo_type_filter, 1)
        filter_layout.addWidget(QLabel("Quarter:"))
        filter_layout.addWidget(self.combo_quarter_filter, 1)
        filter_layout.addWidget(QLabel("Month:"))
        filter_layout.addWidget(self.combo_month_filter, 1)

        if not self.is_provisional:
            filter_layout.addWidget(self.btn_gstr1_report, 1)

        filter_layout.addWidget(self.btn_refresh, 1)
        filter_layout.addWidget(self.btn_export_excel, 1)
        filter_layout.addWidget(self.btn_audit_log, 1)

        layout.addWidget(filter_group)

        # Log Table Setup
        self.table_log = QTableWidget()
        self.table_log.setAlternatingRowColors(True)

        if self.is_provisional:
            self.table_log.setColumnCount(14)
            self.table_log.setHorizontalHeaderLabels([
                "Date & Time", "Type", "B2B/B2C", "Doc No", "Client Name", "Services",
                "Subtotal (₹)", "CGST Amount (₹)", "SGST Amount (₹)", "IGST Amount (₹)", "Grand Total (₹)",
                "Ref Inv No", "Invoice Issued", "Actions"
            ])
            self.table_log.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
            self.table_log.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
            self.table_log.horizontalHeader().setSectionResizeMode(13, QHeaderView.Fixed)
            self.table_log.setColumnWidth(13, 360)
            self.table_log.setColumnWidth(0, 140)
            self.table_log.setColumnWidth(1, 110)
            self.table_log.setColumnWidth(2, 75)
            self.table_log.setColumnWidth(3, 160)
            self.table_log.setColumnWidth(6, 110)
            self.table_log.setColumnWidth(7, 140)
            self.table_log.setColumnWidth(8, 140)
            self.table_log.setColumnWidth(9, 140)
            self.table_log.setColumnWidth(10, 120)
            self.table_log.setColumnWidth(11, 84)
            self.table_log.setColumnWidth(12, 180)
        else:
            self.table_log.setColumnCount(15)
            self.table_log.setHorizontalHeaderLabels([
                "Date & Time", "Type", "B2B/B2C", "Doc No", "Client Name", "Services",
                "Subtotal (₹)", "CGST Amount (₹)", "SGST Amount (₹)", "IGST Amount (₹)", "Grand Total (₹)",
                "Ref Inv No", "Amount Received (₹)", "Receipt Details", "Actions"
            ])
            self.table_log.horizontalHeader().setSectionResizeMode(4, QHeaderView.Stretch)
            self.table_log.horizontalHeader().setSectionResizeMode(5, QHeaderView.Stretch)
            self.table_log.horizontalHeader().setSectionResizeMode(14, QHeaderView.Fixed)
            self.table_log.setColumnWidth(14, 480)
            self.table_log.setColumnWidth(0, 140)
            self.table_log.setColumnWidth(1, 90)
            self.table_log.setColumnWidth(2, 75)
            self.table_log.setColumnWidth(3, 160)
            self.table_log.setColumnWidth(6, 110)
            self.table_log.setColumnWidth(7, 140)
            self.table_log.setColumnWidth(8, 140)
            self.table_log.setColumnWidth(9, 140)
            self.table_log.setColumnWidth(10, 120)
            self.table_log.setColumnWidth(11, 84)
            self.table_log.setColumnWidth(12, 160)
            self.table_log.setColumnWidth(13, 160)

        self.table_log.setWordWrap(True)
        self.table_log.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table_log.cellChanged.connect(self.on_cell_changed)

        layout.addWidget(self.table_log)

        # Footer Summary Bar
        self.lbl_log_summary_footer = QLabel("Total Entries: 0 | Net Taxable: ₹0.00 | Net Cumulative Revenue: ₹0.00")
        self.lbl_log_summary_footer.setStyleSheet("font-weight: bold; padding: 6px; background-color: #F1F5F9; border-radius: 4px;")
        layout.addWidget(self.lbl_log_summary_footer)

        self.refresh_log()

    def create_metric_card(self, title, initial_val, color, tax_excl=0.0, c_amt=0.0, s_amt=0.0, i_amt=0.0, inv_incl=0.0, subtitle="0 Docs"):
        frame = QFrame()
        frame.setStyleSheet(f"""
            QFrame {{
                background-color: #FFFFFF;
                border-left: 4px solid {color};
                border-top: 1px solid #CBD5E1;
                border-right: 1px solid #CBD5E1;
                border-bottom: 1px solid #CBD5E1;
                border-radius: 6px;
                padding: 4px;
            }}
        """)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(8, 4, 8, 4)
        layout.setSpacing(1)

        lbl_t = QLabel(title)
        lbl_t.setStyleSheet("color: #64748B; font-size: 11px; font-weight: bold;")

        lbl_v = QLabel(f"Taxable Amount: ₹{tax_excl:,.2f}")
        lbl_v.setObjectName("val_label")
        font_val = QFont("Segoe UI", 10)
        font_val.setBold(True)
        lbl_v.setFont(font_val)
        lbl_v.setStyleSheet(f"color: {color};")

        tax_str = f"CGST: ₹{c_amt:,.2f}\nSGST: ₹{s_amt:,.2f}\nIGST: ₹{i_amt:,.2f}"
        lbl_tax = QLabel(tax_str)
        lbl_tax.setObjectName("tax_label")
        lbl_tax.setStyleSheet("color: #475569; font-size: 10px; font-weight: 500;")

        lbl_v2 = QLabel(f"Invoice Value: ₹{inv_incl:,.2f}")
        lbl_v2.setObjectName("val2_label")
        lbl_v2.setFont(font_val)
        lbl_v2.setStyleSheet(f"color: {color};")

        lbl_sub = QLabel(subtitle)
        lbl_sub.setObjectName("sub_label")
        lbl_sub.setStyleSheet("color: #64748B; font-size: 10px; font-weight: bold;")

        layout.addWidget(lbl_t)
        layout.addWidget(lbl_v)
        layout.addWidget(lbl_tax)
        layout.addWidget(lbl_v2)
        layout.addWidget(lbl_sub)
        return frame

    def refresh_log(self):
        invoices = DataManager.load_invoices()
        if self.is_provisional:
            self.all_invoices = [i for i in invoices if i.get("is_provisional") or i.get("doc_type") == "Provisional Invoice"]
        else:
            self.all_invoices = [i for i in invoices if not i.get("is_provisional") and i.get("doc_type") != "Provisional Invoice"]
        self.filter_invoices()

    def filter_invoices(self):
        self.table_log.blockSignals(True)
        query = self.edit_search.text().strip().lower()
        type_filter = self.combo_type_filter.currentText()
        quarter_filter = self.combo_quarter_filter.currentText()
        month_filter = self.combo_month_filter.currentText()

        month_map = {
            "January": 1, "February": 2, "March": 3, "April": 4, "May": 5, "June": 6,
            "July": 7, "August": 8, "September": 9, "October": 10, "November": 11, "December": 12
        }

        quarter_map = {
            "Q1 (Apr-Jun)": [4, 5, 6],
            "Q2 (Jul-Sep)": [7, 8, 9],
            "Q3 (Oct-Dec)": [10, 11, 12],
            "Q4 (Jan-Mar)": [1, 2, 3]
        }

        filtered = []
        for inv in self.all_invoices:
            if type_filter != "All Document Types" and inv.get("doc_type") != type_filter:
                continue

            dt_str = inv.get("doc_date", inv.get("created_at", ""))
            try:
                dt_val = datetime.datetime.strptime(dt_str[:10], "%Y-%m-%d")
                m_val = dt_val.month
            except Exception:
                m_val = 1

            if quarter_filter != "All Quarters" and quarter_filter in quarter_map:
                if m_val not in quarter_map[quarter_filter]:
                    continue

            if month_filter != "All Months" and month_filter in month_map:
                if m_val != month_map[month_filter]:
                    continue

            if query:
                match_doc = query in inv.get("doc_no", "").lower()
                match_cust = query in inv.get("customer_name", "").lower()
                match_mob = query in inv.get("customer_mobile", "").lower()
                services_str = ", ".join(i.get("name", "") for i in inv.get("items", [])).lower()
                match_srv = query in services_str
                if not (match_doc or match_cust or match_mob or match_srv):
                    continue

            filtered.append(inv)

        self.filtered_invoices = filtered

        sales_invoices = [i for i in filtered if i.get("doc_type") in ["Tax Invoice", "Provisional Invoice"]]
        cr_invoices = [i for i in filtered if i.get("doc_type") == "Credit Note"]
        db_invoices = [i for i in filtered if i.get("doc_type") == "Debit Note"]

        total_count = len(filtered)
        gross_sales = sum(i.get("grand_total", 0) for i in sales_invoices)
        total_cr = sum(i.get("grand_total", 0) for i in cr_invoices)
        total_db = sum(i.get("grand_total", 0) for i in db_invoices)

        sales_sub = sum(i.get("subtotal", 0) for i in sales_invoices)
        cr_sub = sum(i.get("subtotal", 0) for i in cr_invoices)
        db_sub = sum(i.get("subtotal", 0) for i in db_invoices)

        net_rev = gross_sales + total_db - total_cr
        net_sub = sales_sub + db_sub - cr_sub

        def calc_tax_totals(inv_list):
            c_tot, s_tot, i_tot = 0.0, 0.0, 0.0
            for inv in inv_list:
                cust_gstin = inv.get("customer_gstin", "")
                cust_st = inv.get("customer_state", "")
                if not cust_st and cust_gstin:
                    cust_st = get_state_from_gstin(cust_gstin)

                is_delhi = is_delhi_client(cust_gstin, cust_st)
                gst = inv.get("total_gst", 0.0)
                if is_delhi:
                    c_tot += gst / 2.0
                    s_tot += gst / 2.0
                else:
                    i_tot += gst
            return c_tot, s_tot, i_tot

        s_cgst, s_sgst, s_igst = calc_tax_totals(sales_invoices)
        db_cgst, db_sgst, db_igst = calc_tax_totals(db_invoices)
        cr_cgst, cr_sgst, cr_igst = calc_tax_totals(cr_invoices)
        tot_cgst, tot_sgst, tot_igst = calc_tax_totals(filtered)

        net_cgst = s_cgst + db_cgst - cr_cgst
        net_sgst = s_sgst + db_sgst - cr_sgst
        net_igst = s_igst + db_igst - cr_igst

        self.card_total_count.findChild(QLabel, "val_label").setText(f"Taxable Amount: ₹{net_sub:,.2f}")
        self.card_total_count.findChild(QLabel, "tax_label").setText(f"CGST: ₹{tot_cgst:,.2f}\nSGST: ₹{tot_sgst:,.2f}\nIGST: ₹{tot_igst:,.2f}")
        self.card_total_count.findChild(QLabel, "val2_label").setText(f"Invoice Value: ₹{net_rev:,.2f}")
        self.card_total_count.findChild(QLabel, "sub_label").setText(f"{total_count} Total Docs")

        self.card_total_sales.findChild(QLabel, "val_label").setText(f"Taxable Amount: ₹{sales_sub:,.2f}")
        self.card_total_sales.findChild(QLabel, "tax_label").setText(f"CGST: ₹{s_cgst:,.2f}\nSGST: ₹{s_sgst:,.2f}\nIGST: ₹{s_igst:,.2f}")
        self.card_total_sales.findChild(QLabel, "val2_label").setText(f"Invoice Value: ₹{gross_sales:,.2f}")
        self.card_total_sales.findChild(QLabel, "sub_label").setText(f"{len(sales_invoices)} Invoices")

        self.card_total_db.findChild(QLabel, "val_label").setText(f"Taxable Amount: ₹{db_sub:,.2f}")
        self.card_total_db.findChild(QLabel, "tax_label").setText(f"CGST: ₹{db_cgst:,.2f}\nSGST: ₹{db_sgst:,.2f}\nIGST: ₹{db_igst:,.2f}")
        self.card_total_db.findChild(QLabel, "val2_label").setText(f"Invoice Value: ₹{total_db:,.2f}")
        self.card_total_db.findChild(QLabel, "sub_label").setText(f"{len(db_invoices)} Debit Notes")

        self.card_total_cr.findChild(QLabel, "val_label").setText(f"Taxable Amount: ₹{cr_sub:,.2f}")
        self.card_total_cr.findChild(QLabel, "tax_label").setText(f"CGST: ₹{cr_cgst:,.2f}\nSGST: ₹{cr_sgst:,.2f}\nIGST: ₹{cr_igst:,.2f}")
        self.card_total_cr.findChild(QLabel, "val2_label").setText(f"Invoice Value: ₹{total_cr:,.2f}")
        self.card_total_cr.findChild(QLabel, "sub_label").setText(f"{len(cr_invoices)} Credit Notes")

        self.card_net_revenue.findChild(QLabel, "val_label").setText(f"Taxable Amount: ₹{net_sub:,.2f}")
        self.card_net_revenue.findChild(QLabel, "tax_label").setText(f"CGST: ₹{net_cgst:,.2f}\nSGST: ₹{net_sgst:,.2f}\nIGST: ₹{net_igst:,.2f}")
        self.card_net_revenue.findChild(QLabel, "val2_label").setText(f"Invoice Value: ₹{net_rev:,.2f}")
        self.card_net_revenue.findChild(QLabel, "sub_label").setText("Sales + DN - CN")

        self.table_log.setRowCount(0)
        total_table_val = 0.0

        for idx, inv in enumerate(filtered):
            self.table_log.insertRow(idx)
            doc_type = inv.get("doc_type", "Tax Invoice")
            cust_gstin = inv.get("customer_gstin", "").strip()
            cust_st = inv.get("customer_state", "").strip()
            if not cust_st and cust_gstin:
                cust_st = get_state_from_gstin(cust_gstin)

            is_delhi = is_delhi_client(cust_gstin, cust_st)
            b2b_b2c_tag = "B2B" if cust_gstin else "B2C"

            services_lines = []
            subtotal_lines = []
            cgst_lines = []
            sgst_lines = []
            igst_lines = []
            total_lines = []

            for item in inv.get("items", []):
                s_name = item.get("name", "")
                s_amt = item.get("amount", 0.0)
                s_gst = item.get("gst_amt", 0.0)
                s_tot = item.get("total", 0.0)

                services_lines.append(s_name)

                prefix = ""
                if doc_type == "Credit Note":
                    prefix = "-"
                elif doc_type == "Debit Note":
                    prefix = "+"

                subtotal_lines.append(f"{prefix}₹{s_amt:,.2f}")
                total_lines.append(f"{prefix}₹{s_tot:,.2f}")

                if is_delhi:
                    cgst_sgst = s_gst / 2.0
                    cgst_lines.append(f"{prefix}₹{cgst_sgst:,.2f}")
                    sgst_lines.append(f"{prefix}₹{cgst_sgst:,.2f}")
                    igst_lines.append("₹0.00")
                else:
                    cgst_lines.append("₹0.00")
                    sgst_lines.append("₹0.00")
                    igst_lines.append(f"{prefix}₹{s_gst:,.2f}")

            services_summary = "\n".join(services_lines)
            subtotal_summary = "\n".join(subtotal_lines)
            cgst_summary = "\n".join(cgst_lines)
            sgst_summary = "\n".join(sgst_lines)
            igst_summary = "\n".join(igst_lines)
            grand_total_summary = "\n".join(total_lines)

            g_total = inv.get("grand_total", 0.0)
            if doc_type == "Credit Note":
                total_table_val -= g_total
            elif doc_type == "Debit Note":
                total_table_val += g_total
            else:
                total_table_val += g_total

            payments = inv.get("payments", [])
            tot_received = sum(p.get("amount", 0.0) for p in payments)
            receipt_summary = "; ".join(f"{p.get('date')}: ₹{p.get('amount'):,.2f} ({p.get('mode')})" for p in payments) if payments else "No Payments"

            def make_item(txt):
                it = QTableWidgetItem(txt)
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                return it

            self.table_log.setItem(idx, 0, make_item(inv.get("created_at", inv.get("doc_date", ""))))

            type_item = make_item(doc_type)
            if doc_type == "Credit Note":
                type_item.setForeground(QColor("#DC2626"))
            elif doc_type == "Debit Note":
                type_item.setForeground(QColor("#2563EB"))
            self.table_log.setItem(idx, 1, type_item)

            b2b_item = make_item(b2b_b2c_tag)
            b2b_item.setFont(type_item.font())
            if b2b_b2c_tag == "B2B":
                b2b_item.setForeground(QColor("#16A34A"))
            else:
                b2b_item.setForeground(QColor("#EA580C"))
            self.table_log.setItem(idx, 2, b2b_item)

            self.table_log.setItem(idx, 3, make_item(inv.get("doc_no", "")))
            self.table_log.setItem(idx, 4, make_item(inv.get("customer_name", "")))
            self.table_log.setItem(idx, 5, make_item(services_summary))

            item_sub = make_item(subtotal_summary)
            item_cgst = make_item(cgst_summary)
            item_sgst = make_item(sgst_summary)
            item_igst = make_item(igst_summary)
            item_tot = make_item(grand_total_summary)

            if doc_type == "Credit Note":
                item_sub.setForeground(QColor("#DC2626"))
                item_cgst.setForeground(QColor("#DC2626"))
                item_sgst.setForeground(QColor("#DC2626"))
                item_igst.setForeground(QColor("#DC2626"))
                item_tot.setForeground(QColor("#DC2626"))
            elif doc_type == "Debit Note":
                item_sub.setForeground(QColor("#2563EB"))
                item_cgst.setForeground(QColor("#2563EB"))
                item_sgst.setForeground(QColor("#2563EB"))
                item_igst.setForeground(QColor("#2563EB"))
                item_tot.setForeground(QColor("#2563EB"))

            self.table_log.setItem(idx, 6, item_sub)
            self.table_log.setItem(idx, 7, item_cgst)
            self.table_log.setItem(idx, 8, item_sgst)
            self.table_log.setItem(idx, 9, item_igst)
            self.table_log.setItem(idx, 10, item_tot)
            self.table_log.setItem(idx, 11, make_item(inv.get("orig_inv_no", "-")))

            if self.is_provisional:
                is_approved = bool(inv.get("approved"))
                issued_txt = inv.get("invoice_issued", "-")
                if is_approved:
                    issued_txt = f"✅ Approved{(' → ' + inv.get('invoice_issued')) if inv.get('invoice_issued') not in ('', '-', None) else ''}"
                inv_iss_item = QTableWidgetItem(issued_txt)
                # Once approved the provisional invoice is locked (non-editable).
                if is_approved:
                    inv_iss_item.setFlags(inv_iss_item.flags() & ~Qt.ItemIsEditable)
                    inv_iss_item.setForeground(QColor("#16A34A"))
                else:
                    inv_iss_item.setFlags(inv_iss_item.flags() | Qt.ItemIsEditable)
                inv_iss_item.setData(Qt.UserRole, inv.get("doc_no"))
                self.table_log.setItem(idx, 12, inv_iss_item)

                actions_widget = QWidget()
                actions_layout = QHBoxLayout(actions_widget)
                actions_layout.setContentsMargins(2, 2, 2, 2)
                actions_layout.setSpacing(4)

                btn_open = QPushButton("✏ Open")
                btn_open.setFixedSize(84, 26)
                btn_open.setObjectName("btnSecondary")
                btn_open.clicked.connect(lambda _, d=inv: self.load_invoice_into_editor(d))

                btn_approve = QPushButton("✅ Approved" if is_approved else "✔ Approve")
                btn_approve.setFixedSize(104, 26)
                btn_approve.setObjectName("btnSuccess")
                btn_approve.clicked.connect(lambda _, d=inv: self.approve_provisional(d))

                btn_pdf = QPushButton("📄 PDF")
                btn_pdf.setFixedSize(78, 26)
                btn_pdf.clicked.connect(lambda _, d=inv: self.open_pdf_from_log(d))

                btn_del = QPushButton("🗑 Delete")
                btn_del.setFixedSize(96, 26)
                btn_del.setObjectName("btnDanger")
                btn_del.clicked.connect(lambda _, doc_no=inv.get("doc_no"): self.delete_invoice_from_log(doc_no))

                # Approved provisional invoices lock the editable actions.
                if is_approved:
                    btn_approve.setEnabled(False)
                    btn_open.setEnabled(False)

                actions_layout.addWidget(btn_open)
                actions_layout.addWidget(btn_approve)
                actions_layout.addWidget(btn_pdf)
                actions_layout.addWidget(btn_del)
                actions_layout.setAlignment(Qt.AlignCenter)

                self.table_log.setCellWidget(idx, 13, actions_widget)
            else:
                self.table_log.setItem(idx, 12, make_item(f"₹{tot_received:,.2f}"))
                self.table_log.setItem(idx, 13, make_item(receipt_summary))

                actions_widget = QWidget()
                actions_layout = QHBoxLayout(actions_widget)
                actions_layout.setContentsMargins(2, 2, 2, 2)
                actions_layout.setSpacing(4)

                btn_open = QPushButton("✏ Open")
                btn_open.setFixedSize(110, 26)
                btn_open.setObjectName("btnSecondary")
                btn_open.clicked.connect(lambda _, d=inv: self.load_invoice_into_editor(d))

                btn_pdf = QPushButton("📄 PDF")
                btn_pdf.setFixedSize(100, 26)
                btn_pdf.clicked.connect(lambda _, d=inv: self.open_pdf_from_log(d))

                btn_pay = QPushButton("💰 Pay")
                btn_pay.setFixedSize(110, 26)
                btn_pay.setObjectName("btnSuccess")
                btn_pay.clicked.connect(lambda _, d=inv: self.open_payment_dialog(d))

                btn_del = QPushButton("🗑 Delete")
                btn_del.setFixedSize(130, 26)
                btn_del.setObjectName("btnDanger")
                btn_del.clicked.connect(lambda _, doc_no=inv.get("doc_no"): self.delete_invoice_from_log(doc_no))

                actions_layout.addWidget(btn_open)
                actions_layout.addWidget(btn_pdf)
                actions_layout.addWidget(btn_pay)
                actions_layout.addWidget(btn_del)
                actions_layout.setAlignment(Qt.AlignCenter)

                self.table_log.setCellWidget(idx, 14, actions_widget)

        self.lbl_log_summary_footer.setText(
            f"Showing {total_count} Entries | Net Taxable Amount: ₹{net_sub:,.2f} | Net Cumulative Revenue: ₹{total_table_val:,.2f}"
        )
        self.table_log.blockSignals(False)

    def on_cell_changed(self, row, col):
        if self.is_provisional and col == 12:
            item = self.table_log.item(row, col)
            if item:
                doc_no = item.data(Qt.UserRole)
                val = item.text().strip()
                if doc_no:
                    DataManager.update_invoice_issued(doc_no, val)
                    if self.parent_app:
                        self.parent_app.statusBar().showMessage(f"Updated Invoice Issued for #{doc_no} to {val}", 4000)

    def show_gstr1_summary_dialog(self):
        q_filter = self.combo_quarter_filter.currentText()
        m_filter = self.combo_month_filter.currentText()
        dialog = GSTR1ReportDialog(
            getattr(self, 'filtered_invoices', self.all_invoices),
            selected_quarter=q_filter,
            selected_month=m_filter,
            parent=self
        )
        exec_func = getattr(dialog, 'exec_', None) or getattr(dialog, 'exec')
        exec_func()

    def load_invoice_into_editor(self, inv_data):
        pwd, ok = prompt_password(self, "Security Verification Required", f"Enter Password to open Document #{inv_data.get('doc_no')}:")
        if not ok:
            return

        if pwd != ADMIN_PASSWORD:
            show_msg(self, "Access Denied", "Invalid Password! Cannot open invoice into editor.", "critical")
            if self.parent_app:
                self.parent_app.statusBar().showMessage("Open failed: Invalid password.", 4000)
            return

        if self.parent_app:
            if self.is_provisional:
                target_widget = self.parent_app.prov_invoice_widget
                self.parent_app.tabs.setCurrentIndex(2)
            else:
                target_widget = self.parent_app.tax_invoice_widget
                self.parent_app.tabs.setCurrentIndex(0)

            doc_type = inv_data.get("doc_type", "Tax Invoice")
            type_idx = target_widget.combo_doc_type.findText(doc_type)
            if type_idx >= 0:
                target_widget.combo_doc_type.setCurrentIndex(type_idx)

            target_widget.edit_doc_no.setText(inv_data.get("doc_no", ""))
            target_widget.edit_fy.setText(inv_data.get("financial_year", get_financial_year_str(inv_data.get("doc_date"))))
            if inv_data.get("doc_date"):
                qdate = QDate.fromString(inv_data.get("doc_date"), "yyyy-MM-dd")
                if qdate.isValid():
                    target_widget.date_doc.setDate(qdate)

            c_idx = target_widget.combo_cust_name.findText(inv_data.get("customer_name", ""))
            if c_idx >= 0:
                target_widget.combo_cust_name.setCurrentIndex(c_idx)
            else:
                target_widget.combo_cust_name.setCurrentIndex(0)

            target_widget.edit_cust_mobile.setText(inv_data.get("customer_mobile", ""))
            target_widget.edit_cust_address.setText(inv_data.get("customer_address", ""))
            target_widget.edit_cust_gstin.setText(inv_data.get("customer_gstin", ""))
            target_widget.edit_cust_state.setCurrentText(inv_data.get("customer_state", ""))

            target_widget.current_items = list(inv_data.get("items", []))
            target_widget.refresh_services_table()
            target_widget.recalculate_totals()
            self.parent_app.statusBar().showMessage(f"Loaded {doc_type} #{inv_data.get('doc_no')} into editor.", 4000)

    def approve_provisional(self, inv_data):
        """Approve a provisional invoice: lock it and prefill the Create Tax
        Invoice tab so the main invoice can be created from its details."""
        if inv_data.get("approved"):
            show_msg(self, "Already Approved",
                     f"Provisional invoice #{inv_data.get('doc_no')} is already approved.", "info")
            return

        reply = ask_question(
            self, "Approve Provisional Invoice",
            f"Approve provisional invoice #{inv_data.get('doc_no')}?\n\n"
            "This locks it from further editing and opens the Create Tax Invoice "
            "tab prefilled with these details to create the main invoice."
        )
        if reply != QMessageBox.Yes:
            return

        if not self.parent_app:
            return

        target = self.parent_app.tax_invoice_widget
        self.parent_app.tabs.setCurrentIndex(0)
        new_no = target.prefill_for_new_invoice(inv_data)

        DataManager.set_invoice_approved(inv_data.get("doc_no"), approved_inv_no=new_no)
        self.refresh_log()

        self.parent_app.statusBar().showMessage(
            f"Approved #{inv_data.get('doc_no')} → prefilled Tax Invoice {new_no}. Review and Save to finalise.", 6000)
        show_msg(
            self, "Approved",
            f"Provisional invoice #{inv_data.get('doc_no')} approved and locked.\n\n"
            f"A new Tax Invoice ({new_no}) has been prefilled in the 'Create Tax Invoice' "
            "tab. Review the details and click 'Save Invoice' to create the main invoice.",
            "info"
        )

    def open_pdf_from_log(self, inv_data):
        seller_info = self.parent_app.seller_info if self.parent_app else DataManager.load_seller()
        fy = inv_data.get("financial_year", get_financial_year_str(inv_data.get("doc_date")))
        folder_name = "Provisional Invoice Folder" if self.is_provisional else "Tax Invoice Folder"
        sub_dir = os.path.join(PDF_DIR, folder_name, fy)
        os.makedirs(sub_dir, exist_ok=True)
        pdf_path = os.path.join(sub_dir, f"{inv_data.get('doc_no', '').replace('/', '_')}.pdf")

        # Always regenerate so the PDF reflects the latest data/format.
        try:
            actual = pdf_path
            try:
                InvoicePDFGenerator.generate_pdf(inv_data, seller_info, pdf_path)
            except (PermissionError, OSError):
                base, ext = os.path.splitext(pdf_path)
                actual = f"{base}_{datetime.datetime.now().strftime('%H%M%S')}{ext}"
                InvoicePDFGenerator.generate_pdf(inv_data, seller_info, actual)
        except Exception as e:
            show_msg(self, "PDF Error", f"Could not generate PDF: {e}", "critical")
            return

        ok, how = open_document(actual)
        if not ok:
            show_msg(self, "Open PDF", f"PDF saved at:\n{actual}\n\nCould not open: {how}", "warning")

    def open_payment_dialog(self, inv_data):
        dialog = PaymentTrancheDialog(inv_data, self)
        exec_func = getattr(dialog, 'exec_', None) or getattr(dialog, 'exec')
        if exec_func() == QDialog.Accepted:
            self.refresh_log()

    def delete_invoice_from_log(self, doc_no):
        reply = ask_question(self, "Confirm Delete", f"Are you sure you want to delete Document #{doc_no}?")
        if reply != QMessageBox.Yes:
            return

        pwd, ok = prompt_password(self, "Security Password Required", f"Enter Password to delete Document #{doc_no}:")
        if not ok:
            return

        if pwd != ADMIN_PASSWORD:
            show_msg(self, "Access Denied", "Invalid Password! Deletion cancelled.", "critical")
            if self.parent_app:
                self.parent_app.statusBar().showMessage("Deletion failed: Invalid password.", 4000)
            return

        DataManager.delete_invoice(doc_no)
        self.refresh_log()
        show_msg(self, "Deleted", f"Document #{doc_no} deleted successfully.", "info")
        if self.parent_app:
            self.parent_app.statusBar().showMessage(f"Deleted Document #{doc_no}", 4000)

    def export_ledger_to_excel(self):
        if not hasattr(self, 'filtered_invoices') or not self.filtered_invoices:
            show_msg(self, "Export Info", "No invoice entries available to export.", "warning")
            return

        default_path = os.path.join(APP_DIR, f"Ledger_Export_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx")
        file_path, selected_filter = QFileDialog.getSaveFileName(
            self, "Export Ledger Log to Excel", default_path, "Excel Workbook (*.xlsx);;CSV File (*.csv)"
        )

        if not file_path:
            return

        if self.is_provisional:
            headers = [
                "Date & Time", "Doc Type", "B2B/B2C", "Doc No", "Client Name", "Service Description", "HSN/SAC",
                "Mobile No", "Customer GSTIN", "State", "Subtotal (Rs.)", "CGST (Rs.)", "SGST (Rs.)", "IGST (Rs.)",
                "Grand Total (Rs.)", "Ref Inv No", "Invoice Issued"
            ]
        else:
            headers = [
                "Date & Time", "Doc Type", "B2B/B2C", "Doc No", "Client Name", "Service Description", "HSN/SAC",
                "Mobile No", "Customer GSTIN", "State", "Subtotal (Rs.)", "CGST (Rs.)", "SGST (Rs.)", "IGST (Rs.)",
                "Grand Total (Rs.)", "Ref Inv No", "Amount Received (Rs.)", "Receipt Tranches"
            ]

        rows = []
        tot_sub = 0.0
        tot_cgst = 0.0
        tot_sgst = 0.0
        tot_igst = 0.0
        tot_net = 0.0
        tot_rec = 0.0

        for inv in self.filtered_invoices:
            doc_type = inv.get("doc_type", "Tax Invoice")
            cust_gstin = inv.get("customer_gstin", "").strip()
            cust_st = inv.get("customer_state", "").strip()
            if not cust_st and cust_gstin:
                cust_st = get_state_from_gstin(cust_gstin)

            b2b_b2c = "B2B" if cust_gstin else "B2C"
            is_delhi = is_delhi_client(cust_gstin, cust_st)
            payments = inv.get("payments", [])
            tot_received = sum(p.get("amount", 0.0) for p in payments)
            receipt_summary = "; ".join(f"{p.get('date')}: Rs.{p.get('amount'):,.2f} ({p.get('mode')})" for p in payments) if payments else "No Payments"

            items = inv.get("items", [])
            if not items:
                items = [{"name": "Services", "hsn": "9982", "amount": inv.get("subtotal", 0.0), "gst_amt": inv.get("total_gst", 0.0), "total": inv.get("grand_total", 0.0)}]

            for item in items:
                s_name = item.get("name", "")
                hsn = item.get("hsn", "9982")
                sub = item.get("amount", 0.0)
                gst = item.get("gst_amt", 0.0)
                g_total = item.get("total", 0.0)

                if is_delhi:
                    cgst_val = gst / 2.0
                    sgst_val = gst / 2.0
                    igst_val = 0.0
                else:
                    cgst_val = 0.0
                    sgst_val = 0.0
                    igst_val = gst

                if doc_type == "Credit Note":
                    net_val = -g_total
                    cgst_val = -cgst_val
                    sgst_val = -sgst_val
                    igst_val = -igst_val
                    sub_val = -sub
                elif doc_type == "Debit Note":
                    net_val = g_total
                    sub_val = sub
                else:
                    net_val = g_total
                    sub_val = sub

                tot_sub += sub_val
                tot_cgst += cgst_val
                tot_sgst += sgst_val
                tot_igst += igst_val
                tot_net += net_val

                if self.is_provisional:
                    rows.append([
                        inv.get("created_at", inv.get("doc_date", "")),
                        doc_type,
                        b2b_b2c,
                        inv.get("doc_no", ""),
                        inv.get("customer_name", ""),
                        s_name,
                        hsn,
                        inv.get("customer_mobile", ""),
                        inv.get("customer_gstin", ""),
                        inv.get("customer_state", ""),
                        sub_val,
                        cgst_val,
                        sgst_val,
                        igst_val,
                        net_val,
                        inv.get("orig_inv_no", "-"),
                        inv.get("invoice_issued", "-")
                    ])
                else:
                    rows.append([
                        inv.get("created_at", inv.get("doc_date", "")),
                        doc_type,
                        b2b_b2c,
                        inv.get("doc_no", ""),
                        inv.get("customer_name", ""),
                        s_name,
                        hsn,
                        inv.get("customer_mobile", ""),
                        inv.get("customer_gstin", ""),
                        inv.get("customer_state", ""),
                        sub_val,
                        cgst_val,
                        sgst_val,
                        igst_val,
                        net_val,
                        inv.get("orig_inv_no", "-"),
                        tot_received,
                        receipt_summary
                    ])

            tot_rec += tot_received

        is_xlsx = file_path.lower().endswith(".xlsx")
        try:
            if is_xlsx:
                try:
                    import openpyxl
                    from openpyxl.styles import Font, PatternFill, Alignment

                    wb = openpyxl.Workbook()
                    ws = wb.active
                    ws.title = "Saved Invoices Log"

                    header_fill = PatternFill(start_color="1E3A8A", end_color="1E3A8A", fill_type="solid")
                    header_font = Font(name="Segoe UI", size=11, bold=True, color="FFFFFF")
                    header_align = Alignment(horizontal="center", vertical="center")

                    ws.append(headers)
                    for col_num in range(1, len(headers) + 1):
                        cell = ws.cell(row=1, column=col_num)
                        cell.fill = header_fill
                        cell.font = header_font
                        cell.alignment = header_align

                    for row_data in rows:
                        ws.append(row_data)

                    if self.is_provisional:
                        summary_row = [
                            "TOTAL / NET REVENUE", "", "", "", "", "", "", "", "", "",
                            tot_sub, tot_cgst, tot_sgst, tot_igst, tot_net, "", ""
                        ]
                    else:
                        summary_row = [
                            "TOTAL / NET REVENUE", "", "", "", "", "", "", "", "", "",
                            tot_sub, tot_cgst, tot_sgst, tot_igst, tot_net, "", tot_rec, ""
                        ]
                    ws.append(summary_row)
                    last_row_idx = ws.max_row
                    summary_font = Font(name="Segoe UI", size=11, bold=True, color="1E3A8A")
                    summary_fill = PatternFill(start_color="F1F5F9", end_color="F1F5F9", fill_type="solid")

                    for col_num in range(1, len(summary_row) + 1):
                        cell = ws.cell(row=last_row_idx, column=col_num)
                        cell.font = summary_font
                        cell.fill = summary_fill

                    for col in ws.columns:
                        max_len = max(len(str(cell.value or '')) for cell in col)
                        col_letter = openpyxl.utils.get_column_letter(col[0].column)
                        ws.column_dimensions[col_letter].width = max(max_len + 3, 12)

                    wb.save(file_path)
                except ImportError:
                    import csv
                    with open(file_path, "w", newline="", encoding="utf-8-sig") as f:
                        writer = csv.writer(f)
                        writer.writerow(headers)
                        writer.writerows(rows)
            else:
                import csv
                with open(file_path, "w", newline="", encoding="utf-8-sig") as f:
                    writer = csv.writer(f)
                    writer.writerow(headers)
                    writer.writerows(rows)

            if self.parent_app:
                self.parent_app.statusBar().showMessage(f"Log exported to Excel: {file_path}", 5000)
            reply = ask_question(self, "Export Successful", f"Saved Invoices Log exported successfully to:\n{file_path}\n\nDo you want to open the file now?")
            if reply == QMessageBox.Yes:
                try:
                    os.startfile(file_path)
                except Exception as e:
                    show_msg(self, "Open File", f"Could not auto-open file: {e}", "warning")
        except Exception as e:
            show_msg(self, "Export Error", f"Failed to export Excel file: {e}", "critical")

    def show_audit_log_dialog(self):
        dialog = AuditLogDialog(self)
        exec_func = getattr(dialog, 'exec_', None) or getattr(dialog, 'exec')
        exec_func()


# =============================================================================
# CLIENT DETAILS WIDGET
# =============================================================================

class ClientDetailsWidget(QWidget):
    """Widget for Client Details management."""
    def __init__(self, parent_app=None):
        super().__init__()
        self.parent_app = parent_app
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)
        layout.setSpacing(12)

        form_group = QGroupBox("Add / Update Client Record")
        form_layout = QGridLayout(form_group)

        self.edit_client_name = QLineEdit()
        self.edit_client_name.setPlaceholderText("Full Client / Business Name")

        self.edit_client_mobile = QLineEdit()
        self.edit_client_mobile.setPlaceholderText("Mobile / Phone Number")

        self.edit_client_address = QLineEdit()
        self.edit_client_address.setPlaceholderText("Billing Address")

        self.edit_client_gstin = QLineEdit()
        self.edit_client_gstin.setPlaceholderText("15-Digit GSTIN (e.g. 07AAAAA0000A1Z5)")
        self.edit_client_gstin.textChanged.connect(self.auto_extract_client_state)

        self.edit_client_state = QLineEdit()
        self.edit_client_state.setPlaceholderText("State (Auto-picked from GSTIN)")
        self.edit_client_state.setReadOnly(True)
        self.edit_client_state.setStyleSheet("background-color: #F1F5F9; font-weight: bold; color: #1E3A8A;")

        self.btn_save_client = QPushButton("💾 Save Client")
        self.btn_save_client.setObjectName("btnSuccess")
        self.btn_save_client.clicked.connect(self.save_client_record)

        self.btn_clear_client = QPushButton("🧹 Clear Form")
        self.btn_clear_client.setObjectName("btnSecondary")
        self.btn_clear_client.clicked.connect(self.clear_client_form)

        form_layout.addWidget(QLabel("Client Name*:"), 0, 0)
        form_layout.addWidget(self.edit_client_name, 0, 1)
        form_layout.addWidget(QLabel("Mobile No:"), 0, 2)
        form_layout.addWidget(self.edit_client_mobile, 0, 3)

        form_layout.addWidget(QLabel("Billing Address:"), 1, 0)
        form_layout.addWidget(self.edit_client_address, 1, 1, 1, 3)

        form_layout.addWidget(QLabel("GSTIN (15 Chars):"), 2, 0)
        form_layout.addWidget(self.edit_client_gstin, 2, 1)
        form_layout.addWidget(QLabel("State (Auto):"), 2, 2)
        form_layout.addWidget(self.edit_client_state, 2, 3)

        btn_box = QHBoxLayout()
        btn_box.addWidget(self.btn_save_client)
        btn_box.addWidget(self.btn_clear_client)
        btn_box.addStretch()

        form_layout.addLayout(btn_box, 3, 1, 1, 3)
        layout.addWidget(form_group)

        self.table_clients = QTableWidget()
        self.table_clients.setAlternatingRowColors(True)
        self.table_clients.setColumnCount(6)
        self.table_clients.setHorizontalHeaderLabels([
            "S. No.", "Client Name", "Address", "GSTIN", "State", "Actions"
        ])
        self.table_clients.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        self.table_clients.horizontalHeader().setSectionResizeMode(2, QHeaderView.Stretch)
        self.table_clients.horizontalHeader().setSectionResizeMode(5, QHeaderView.Fixed)
        self.table_clients.setColumnWidth(5, 230)
        self.table_clients.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table_clients.setEditTriggers(QAbstractItemView.NoEditTriggers)

        layout.addWidget(self.table_clients)
        self.refresh_clients_table()

    def auto_extract_client_state(self):
        gstin = self.edit_client_gstin.text().strip()
        state = get_state_from_gstin(gstin)
        self.edit_client_state.setText(state)

    def save_client_record(self):
        name = self.edit_client_name.text().strip()
        if not name:
            show_msg(self, "Validation Error", "Client Name is required.", "warning")
            self.edit_client_name.setFocus()
            return

        gstin = self.edit_client_gstin.text().strip().upper()

        if gstin:
            is_valid, err_msg = validate_gstin_format(gstin)
            if not is_valid:
                show_msg(self, "GSTIN Format Error", err_msg, "warning")
                self.edit_client_gstin.setFocus()
                return

        state = self.edit_client_state.text().strip()
        if not state and gstin:
            state = get_state_from_gstin(gstin)

        client_data = {
            "name": name,
            "mobile": self.edit_client_mobile.text().strip(),
            "address": self.edit_client_address.text().strip(),
            "gstin": gstin,
            "state": state
        }

        if DataManager.save_client(client_data):
            show_msg(self, "Saved", f"Client '{name}' saved successfully!", "info")
            self.clear_client_form()
            self.refresh_clients_table()
            if self.parent_app:
                self.parent_app.reload_all_client_dropdowns()

    def clear_client_form(self):
        self.edit_client_name.clear()
        self.edit_client_mobile.clear()
        self.edit_client_address.clear()
        self.edit_client_gstin.clear()
        self.edit_client_state.clear()

    def refresh_clients_table(self):
        clients = DataManager.load_clients()
        self.table_clients.setRowCount(0)

        for idx, c in enumerate(clients):
            self.table_clients.insertRow(idx)
            self.table_clients.setItem(idx, 0, QTableWidgetItem(str(idx + 1)))
            self.table_clients.setItem(idx, 1, QTableWidgetItem(c.get("name", "")))
            self.table_clients.setItem(idx, 2, QTableWidgetItem(c.get("address", "")))
            self.table_clients.setItem(idx, 3, QTableWidgetItem(c.get("gstin", "")))
            self.table_clients.setItem(idx, 4, QTableWidgetItem(c.get("state", "")))

            actions_widget = QWidget()
            actions_layout = QHBoxLayout(actions_widget)
            actions_layout.setContentsMargins(2, 2, 2, 2)
            actions_layout.setSpacing(6)

            btn_edit = QPushButton("✏ Edit")
            btn_edit.setFixedSize(100, 26)
            btn_edit.setObjectName("btnSecondary")
            btn_edit.clicked.connect(lambda _, client_name=c.get("name"): self.edit_client_protected(client_name))

            btn_del = QPushButton("🗑 Delete")
            btn_del.setFixedSize(105, 26)
            btn_del.setObjectName("btnDanger")
            btn_del.clicked.connect(lambda _, client_name=c.get("name"): self.delete_client_protected(client_name))

            actions_layout.addWidget(btn_edit)
            actions_layout.addWidget(btn_del)
            actions_layout.setAlignment(Qt.AlignCenter)

            self.table_clients.setCellWidget(idx, 5, actions_widget)

    def edit_client_protected(self, name):
        pwd, ok = prompt_password(self, "Security Verification", f"Enter Password to edit Client '{name}':")
        if not ok:
            return

        if pwd != ADMIN_PASSWORD:
            show_msg(self, "Access Denied", "Invalid Password! Action cancelled.", "critical")
            return

        clients = DataManager.load_clients()
        matched = next((c for c in clients if c.get("name", "").strip().lower() == name.strip().lower()), None)
        if matched:
            self.edit_client_name.setText(matched.get("name", ""))
            self.edit_client_mobile.setText(matched.get("mobile", ""))
            self.edit_client_address.setText(matched.get("address", ""))
            self.edit_client_gstin.setText(matched.get("gstin", ""))
            self.edit_client_state.setText(matched.get("state", ""))
            self.edit_client_name.setFocus()

    def delete_client_protected(self, name):
        reply = ask_question(self, "Confirm Delete", f"Are you sure you want to delete Client '{name}'?")
        if reply != QMessageBox.Yes:
            return

        pwd, ok = prompt_password(self, "Security Verification", f"Enter Password to delete Client '{name}':")
        if not ok:
            return

        if pwd != ADMIN_PASSWORD:
            show_msg(self, "Access Denied", "Invalid Password! Deletion cancelled.", "critical")
            return

        DataManager.delete_client(name)
        self.refresh_clients_table()
        if self.parent_app:
            self.parent_app.reload_all_client_dropdowns()
        show_msg(self, "Deleted", f"Client '{name}' deleted successfully.", "info")


# =============================================================================
# BUSINESS SETTINGS WIDGET
# =============================================================================

class BusinessSettingsWidget(QWidget):
    """Widget for Business Profile settings."""
    def __init__(self, parent_app=None):
        super().__init__()
        self.parent_app = parent_app
        self.seller_info = parent_app.seller_info if parent_app else DataManager.load_seller()
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(15, 15, 15, 15)

        biz_bank_layout = QHBoxLayout()

        group_biz = QGroupBox("Business Profile Header (Mandatory Details)")
        biz_layout = QFormLayout(group_biz)

        self.edit_seller_trade = QLineEdit(self.seller_info.get("trade_name", ""))

        self.edit_seller_tagline = QLineEdit(self.seller_info.get("tagline", ""))
        self.edit_seller_tagline.setPlaceholderText("e.g. Chartered Accountants (shown under the firm name)")

        self.edit_seller_addr = QLineEdit(self.seller_info.get("address", ""))

        self.edit_seller_mobile = QLineEdit(self.seller_info.get("mobile", ""))
        self.edit_seller_mobile.setPlaceholderText("Optional Mobile / Phone Number")

        self.edit_seller_email = QLineEdit(self.seller_info.get("email", ""))
        self.edit_seller_email.setPlaceholderText("Optional Email Address")

        self.edit_seller_website = QLineEdit(self.seller_info.get("website", ""))
        self.edit_seller_website.setPlaceholderText("Optional Website (e.g. www.yourfirm.com)")

        self.edit_seller_pan = QLineEdit(self.seller_info.get("pan", ""))
        self.edit_seller_pan.setPlaceholderText("Optional PAN (e.g. ABFFK8519A)")

        self.edit_seller_gstin = QLineEdit(self.seller_info.get("gstin", ""))

        self.edit_msme_udyam = QLineEdit(self.seller_info.get("msme_udyam_no", ""))
        self.edit_msme_udyam.setPlaceholderText("Optional MSME Udyam Registration No.")
        # Type of MSME must only appear once a Udyam number is entered.
        self.edit_msme_udyam.textChanged.connect(self.update_msme_type_visibility)

        self.combo_msme_type = QComboBox()
        self.combo_msme_type.addItems(["Micro", "Small", "Medium"])
        msme_t = self.seller_info.get("msme_type", "Micro")
        t_idx = self.combo_msme_type.findText(msme_t)
        if t_idx >= 0:
            self.combo_msme_type.setCurrentIndex(t_idx)
        self.lbl_msme_type = QLabel("Type of MSME:")

        logo_layout = QHBoxLayout()
        self.edit_logo_path = QLineEdit(self.seller_info.get("logo_path", ""))
        btn_browse_logo = QPushButton("Browse...")
        btn_browse_logo.clicked.connect(self.browse_logo_image)
        logo_layout.addWidget(self.edit_logo_path)
        logo_layout.addWidget(btn_browse_logo)

        biz_layout.addRow("Trade / Company Name*:", self.edit_seller_trade)
        biz_layout.addRow("Tagline / Subtitle:", self.edit_seller_tagline)
        biz_layout.addRow("Full Business Address*:", self.edit_seller_addr)
        biz_layout.addRow("Mobile / Phone (Optional):", self.edit_seller_mobile)
        biz_layout.addRow("Email Address (Optional):", self.edit_seller_email)
        biz_layout.addRow("Website (Optional):", self.edit_seller_website)
        biz_layout.addRow("PAN (Optional):", self.edit_seller_pan)
        biz_layout.addRow("GSTIN*:", self.edit_seller_gstin)
        biz_layout.addRow("MSME Udyam No. (Optional):", self.edit_msme_udyam)
        biz_layout.addRow(self.lbl_msme_type, self.combo_msme_type)
        biz_layout.addRow("Logo Image File:", logo_layout)
        # Set initial visibility of the Type of MSME field based on saved Udyam no.
        self.update_msme_type_visibility()

        biz_bank_layout.addWidget(group_biz, 1)

        group_bank = QGroupBox("Bank Account & Payment Details (Shown in Invoice Footer)")
        bank_layout = QFormLayout(group_bank)

        self.edit_bank_name = QLineEdit(self.seller_info.get("bank_name", ""))
        self.edit_bank_acc = QLineEdit(self.seller_info.get("account_no", ""))
        self.edit_bank_ifsc = QLineEdit(self.seller_info.get("ifsc_code", ""))
        self.edit_bank_branch = QLineEdit(self.seller_info.get("branch", ""))

        self.edit_upi_id = QLineEdit(self.seller_info.get("upi_id", ""))
        self.edit_upi_id.setPlaceholderText("e.g. yourname@okaxis (used for the dynamic payment QR)")

        upi_layout = QHBoxLayout()
        self.edit_upi_barcode = QLineEdit(self.seller_info.get("upi_barcode_path", ""))
        self.edit_upi_barcode.setPlaceholderText("Optional fallback QR image (used only if no UPI ID)")
        btn_browse_upi = QPushButton("Browse Barcode...")
        btn_browse_upi.clicked.connect(self.browse_upi_barcode_image)
        upi_layout.addWidget(self.edit_upi_barcode)
        upi_layout.addWidget(btn_browse_upi)

        bank_layout.addRow("Bank Name*:", self.edit_bank_name)
        bank_layout.addRow("Account Number*:", self.edit_bank_acc)
        bank_layout.addRow("IFSC Code*:", self.edit_bank_ifsc)
        bank_layout.addRow("Branch Name*:", self.edit_bank_branch)
        bank_layout.addRow("UPI ID (for dynamic QR):", self.edit_upi_id)
        bank_layout.addRow("UPI Barcode Image:", upi_layout)

        biz_bank_layout.addWidget(group_bank, 1)

        layout.addLayout(biz_bank_layout)

        group_terms = QGroupBox("Terms & Conditions / Notes*  (printed on the invoice)")
        terms_layout = QVBoxLayout(group_terms)

        terms_bar = QHBoxLayout()
        terms_bar.addStretch()
        btn_load_terms = QPushButton("↺ Load Standard T&Cs")
        btn_load_terms.setObjectName("btnSecondary")
        btn_load_terms.clicked.connect(lambda: self.edit_terms.setPlainText(DEFAULT_TERMS))
        terms_bar.addWidget(btn_load_terms)
        terms_layout.addLayout(terms_bar)

        self.edit_terms = QTextEdit()
        self.edit_terms.setText(self.seller_info.get("terms", "") or DEFAULT_TERMS)
        self.edit_terms.setMinimumHeight(130)
        terms_layout.addWidget(self.edit_terms)

        layout.addWidget(group_terms)

        btn_save_seller = QPushButton("💾 Save Business Settings")
        btn_save_seller.setObjectName("btnSuccess")
        btn_save_seller.clicked.connect(self.save_seller_settings)

        layout.addWidget(btn_save_seller)
        layout.addStretch()

    def update_msme_type_visibility(self):
        """Show the Type of MSME selector only when a Udyam number is present."""
        has_udyam = bool(self.edit_msme_udyam.text().strip())
        self.lbl_msme_type.setVisible(has_udyam)
        self.combo_msme_type.setVisible(has_udyam)

    def browse_logo_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select Business Logo Image", "", "Images (*.png *.jpg *.jpeg *.bmp)"
        )
        if file_path:
            self.edit_logo_path.setText(file_path)

    def browse_upi_barcode_image(self):
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Select UPI Barcode QR Image", "", "Images (*.png *.jpg *.jpeg *.bmp)"
        )
        if file_path:
            self.edit_upi_barcode.setText(file_path)

    def save_seller_settings(self):
        trade = self.edit_seller_trade.text().strip()
        addr = self.edit_seller_addr.text().strip()
        mobile = self.edit_seller_mobile.text().strip()
        email = self.edit_seller_email.text().strip()
        gstin = self.edit_seller_gstin.text().strip().upper()
        bank = self.edit_bank_name.text().strip()
        acc = self.edit_bank_acc.text().strip()
        ifsc = self.edit_bank_ifsc.text().strip()
        branch = self.edit_bank_branch.text().strip()
        terms = self.edit_terms.toPlainText().strip()

        if not (trade and addr and gstin and bank and acc and ifsc and branch and terms):
            show_msg(self, "Validation Error", "All mandatory fields (marked with *) must be filled before saving settings.", "warning")
            return

        if gstin:
            is_valid, err_msg = validate_gstin_format(gstin)
            if not is_valid:
                show_msg(self, "Seller GSTIN Error", err_msg, "warning")
                self.edit_seller_gstin.setFocus()
                return

        pwd, ok = prompt_password(self, "Security Verification", "Enter Admin Password to save Business Settings:")
        if not ok:
            return

        if pwd != ADMIN_PASSWORD:
            show_msg(self, "Access Denied", "Invalid Password! Settings not saved.", "critical")
            return

        self.seller_info["trade_name"] = trade
        self.seller_info["tagline"] = self.edit_seller_tagline.text().strip()
        self.seller_info["address"] = addr
        self.seller_info["mobile"] = mobile
        self.seller_info["email"] = email
        self.seller_info["website"] = self.edit_seller_website.text().strip()
        self.seller_info["pan"] = self.edit_seller_pan.text().strip().upper()
        self.seller_info["gstin"] = gstin
        udyam_no = self.edit_msme_udyam.text().strip()
        self.seller_info["msme_udyam_no"] = udyam_no
        # Type of MSME is only meaningful when a Udyam number is registered.
        self.seller_info["msme_type"] = self.combo_msme_type.currentText() if udyam_no else ""
        self.seller_info["bank_name"] = bank
        self.seller_info["account_no"] = acc
        self.seller_info["ifsc_code"] = ifsc
        self.seller_info["branch"] = branch
        self.seller_info["upi_id"] = self.edit_upi_id.text().strip()
        self.seller_info["upi_barcode_path"] = self.edit_upi_barcode.text().strip()
        self.seller_info["terms"] = terms
        self.seller_info["logo_path"] = self.edit_logo_path.text().strip()

        if DataManager.save_seller(self.seller_info):
            if self.parent_app:
                self.parent_app.seller_info = self.seller_info
                self.parent_app.statusBar().showMessage("Business settings updated.", 4000)
            show_msg(self, "Settings Saved", "Business details profile saved successfully!", "info")


# =============================================================================
# SECTION 8: GSTR-1 REPORTS, AUDIT LOG & PAYMENT DIALOGS
# =============================================================================

class GSTR1ReportDialog(QDialog):
    """
    GSTR-1 Summary Reports Dialog displaying:
    - B2B Tax Invoices, B2C Tax Invoices, Total Tax Invoices
    - Separate B2B Debit Note & Credit Note Net Details
    - Separate B2C Debit Note & Credit Note Net Details
    - Net Totals for GSTR-1 Statutory Return Filing
    """
    def __init__(self, invoices_list, selected_quarter="All Quarters", selected_month="All Months", parent=None):
        super().__init__(parent)
        self.invoices_list = invoices_list
        self.selected_quarter = selected_quarter
        self.selected_month = selected_month
        self.setWindowTitle("PSC Billing Manager - GSTR-1 Statutory Reports")
        self.resize(1200, 750)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        top_layout = QHBoxLayout()
        title_lbl = QLabel("📋 GSTR-1 Tax Summary & Statutory Return Details")
        font_t = QFont("Segoe UI", 13, QFont.Bold)
        title_lbl.setFont(font_t)
        title_lbl.setStyleSheet("color: #1E3A8A;")

        filter_lbl = QLabel(f"<b>Filter Period:</b> {self.selected_quarter} | {self.selected_month}")
        filter_lbl.setStyleSheet("background-color: #EFF6FF; color: #1E3A8A; padding: 6px 12px; border-radius: 4px; border: 1px solid #93C5FD;")

        top_layout.addWidget(title_lbl)
        top_layout.addStretch()
        top_layout.addWidget(filter_lbl)

        layout.addLayout(top_layout)

        tab_widget = QTabWidget()
        layout.addWidget(tab_widget)

        # Tab A: B2B_B2C Summary
        b2b_b2c_widget = QWidget()
        b2b_b2c_layout = QVBoxLayout(b2b_b2c_widget)

        b2b_invoices = [i for i in self.invoices_list if i.get("customer_gstin", "").strip() and i.get("doc_type") == "Tax Invoice"]
        b2b_dn = [i for i in self.invoices_list if i.get("customer_gstin", "").strip() and i.get("doc_type") == "Debit Note"]
        b2b_cn = [i for i in self.invoices_list if i.get("customer_gstin", "").strip() and i.get("doc_type") == "Credit Note"]

        b2c_invoices = [i for i in self.invoices_list if not i.get("customer_gstin", "").strip() and i.get("doc_type") == "Tax Invoice"]
        b2c_dn = [i for i in self.invoices_list if not i.get("customer_gstin", "").strip() and i.get("doc_type") == "Debit Note"]
        b2c_cn = [i for i in self.invoices_list if not i.get("customer_gstin", "").strip() and i.get("doc_type") == "Credit Note"]

        def calc_row_vals(doc_list):
            count = len(doc_list)
            taxable = sum(inv.get("subtotal", 0.0) for inv in doc_list)
            c_tot, s_tot, i_tot = 0.0, 0.0, 0.0
            for inv in doc_list:
                cust_gstin = inv.get("customer_gstin", "")
                cust_st = inv.get("customer_state", "")
                if not cust_st and cust_gstin:
                    cust_st = get_state_from_gstin(cust_gstin)

                is_delhi = is_delhi_client(cust_gstin, cust_st)
                gst = inv.get("total_gst", 0.0)
                if is_delhi:
                    c_tot += gst / 2.0
                    s_tot += gst / 2.0
                else:
                    i_tot += gst
            total_val = taxable + c_tot + s_tot + i_tot
            return count, taxable, c_tot, s_tot, i_tot, total_val

        b2b_inv_vals = calc_row_vals(b2b_invoices)
        b2b_dn_vals = calc_row_vals(b2b_dn)
        b2b_cn_vals = calc_row_vals(b2b_cn)

        b2c_inv_vals = calc_row_vals(b2c_invoices)
        b2c_dn_vals = calc_row_vals(b2c_dn)
        b2c_cn_vals = calc_row_vals(b2c_cn)

        tot_inv_cnt = b2b_inv_vals[0] + b2c_inv_vals[0]
        tot_inv_tax = b2b_inv_vals[1] + b2c_inv_vals[1]
        tot_inv_cgst = b2b_inv_vals[2] + b2c_inv_vals[2]
        tot_inv_sgst = b2b_inv_vals[3] + b2c_inv_vals[3]
        tot_inv_igst = b2b_inv_vals[4] + b2c_inv_vals[4]
        tot_inv_val = b2b_inv_vals[5] + b2c_inv_vals[5]

        # Net B2B Debit Note and Credit Note Details (DN - CN)
        net_b2b_notes_cnt = b2b_dn_vals[0] + b2b_cn_vals[0]
        net_b2b_notes_tax = b2b_dn_vals[1] - b2b_cn_vals[1]
        net_b2b_notes_cgst = b2b_dn_vals[2] - b2b_cn_vals[2]
        net_b2b_notes_sgst = b2b_dn_vals[3] - b2b_cn_vals[3]
        net_b2b_notes_igst = b2b_dn_vals[4] - b2b_cn_vals[4]
        net_b2b_notes_tot = b2b_dn_vals[5] - b2b_cn_vals[5]

        # Net B2C Debit Note and Credit Note Details (DN - CN)
        net_b2c_notes_cnt = b2c_dn_vals[0] + b2c_cn_vals[0]
        net_b2c_notes_tax = b2c_dn_vals[1] - b2c_cn_vals[1]
        net_b2c_notes_cgst = b2c_dn_vals[2] - b2c_cn_vals[2]
        net_b2c_notes_sgst = b2c_dn_vals[3] - b2c_cn_vals[3]
        net_b2c_notes_igst = b2c_dn_vals[4] - b2c_cn_vals[4]
        net_b2c_notes_tot = b2c_dn_vals[5] - b2c_cn_vals[5]

        b2b_net_cnt = b2b_inv_vals[0] + b2b_dn_vals[0] + b2b_cn_vals[0]
        b2b_net_tax = b2b_inv_vals[1] + b2b_dn_vals[1] - b2b_cn_vals[1]
        b2b_net_cgst = b2b_inv_vals[2] + b2b_dn_vals[2] - b2b_cn_vals[2]
        b2b_net_sgst = b2b_inv_vals[3] + b2b_dn_vals[3] - b2b_cn_vals[3]
        b2b_net_igst = b2b_inv_vals[4] + b2b_dn_vals[4] - b2b_cn_vals[4]
        b2b_net_tot = b2b_inv_vals[5] + b2b_dn_vals[5] - b2b_cn_vals[5]

        b2c_net_cnt = b2c_inv_vals[0] + b2c_dn_vals[0] + b2c_cn_vals[0]
        b2c_net_tax = b2c_inv_vals[1] + b2c_dn_vals[1] - b2c_cn_vals[1]
        b2c_net_cgst = b2c_inv_vals[2] + b2c_dn_vals[2] - b2c_cn_vals[2]
        b2c_net_sgst = b2c_inv_vals[3] + b2c_dn_vals[3] - b2c_cn_vals[3]
        b2c_net_igst = b2c_inv_vals[4] + b2c_dn_vals[4] - b2c_cn_vals[4]
        b2c_net_tot = b2c_inv_vals[5] + b2c_dn_vals[5] - b2c_cn_vals[5]

        g_cnt = b2b_net_cnt + b2c_net_cnt
        g_tax = b2b_net_tax + b2c_net_tax
        g_cgst = b2b_net_cgst + b2c_net_cgst
        g_sgst = b2b_net_sgst + b2c_net_sgst
        g_igst = b2b_net_igst + b2c_net_igst
        g_tot = b2b_net_tot + b2c_net_tot

        summary_table = QTableWidget()
        summary_table.setColumnCount(7)
        summary_table.setHorizontalHeaderLabels([
            "Category", "No. of Docs", "Taxable Amount (₹)", "CGST (₹)", "SGST (₹)", "IGST (₹)", "Invoice Value (₹)"
        ])
        summary_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        summary_table.setColumnWidth(2, 160)
        summary_table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        # Exact User Table Order:
        # Row 1: B2B Tax Invoices
        # Row 2: B2C Tax Invoices
        # Row 3: Total B2B + B2C Tax Invoices
        # Row 4: B2B Debit Notes
        # Row 5: B2B Credit Notes
        # Row 6: NET B2B Debit Note & Credit Note Details (DN - CN)
        # Row 7: B2C Debit Notes
        # Row 8: B2C Credit Notes
        # Row 9: NET B2C Debit Note & Credit Note Details (DN - CN)
        # Row 10: NET B2B (Invoices + DN - CN)
        # Row 11: NET B2C (Invoices + DN - CN)
        # Row 12: TOTAL (B2B + B2C NET)
        rows_data = [
            ("B2B Tax Invoices", *b2b_inv_vals, False),
            ("B2C Tax Invoices", *b2c_inv_vals, False),
            ("Total B2B + B2C Tax Invoices", tot_inv_cnt, tot_inv_tax, tot_inv_cgst, tot_inv_sgst, tot_inv_igst, tot_inv_val, True),
            ("B2B Debit Notes", *b2b_dn_vals, False),
            ("B2B Credit Notes", *b2b_cn_vals, False),
            ("NET B2B Debit & Credit Notes (DN - CN)", net_b2b_notes_cnt, net_b2b_notes_tax, net_b2b_notes_cgst, net_b2b_notes_sgst, net_b2b_notes_igst, net_b2b_notes_tot, True),
            ("B2C Debit Notes", *b2c_dn_vals, False),
            ("B2C Credit Notes", *b2c_cn_vals, False),
            ("NET B2C Debit & Credit Notes (DN - CN)", net_b2c_notes_cnt, net_b2c_notes_tax, net_b2c_notes_cgst, net_b2c_notes_sgst, net_b2c_notes_igst, net_b2c_notes_tot, True),
            ("NET B2B TAX INVOICES", b2b_net_cnt, b2b_net_tax, b2b_net_cgst, b2b_net_sgst, b2b_net_igst, b2b_net_tot, True),
            ("NET B2C TAX INVOICES", b2c_net_cnt, b2c_net_tax, b2c_net_cgst, b2c_net_sgst, b2c_net_igst, b2c_net_tot, True),
            ("Total (B2B + B2C) (Net of DN CN)", g_cnt, g_tax, g_cgst, g_sgst, g_igst, g_tot, True)
        ]

        summary_table.setRowCount(len(rows_data))
        for r_idx, (cat, cnt, tax, cgst, sgst, igst, tot, is_bold) in enumerate(rows_data):
            f = QFont("Segoe UI", 9)
            if is_bold:
                f.setBold(True)

            it_cat = QTableWidgetItem(cat)
            it_cnt = QTableWidgetItem(str(cnt))
            it_tax = QTableWidgetItem(f"₹{tax:,.2f}")
            it_cgst = QTableWidgetItem(f"₹{cgst:,.2f}")
            it_sgst = QTableWidgetItem(f"₹{sgst:,.2f}")
            it_igst = QTableWidgetItem(f"₹{igst:,.2f}")
            it_tot = QTableWidgetItem(f"₹{tot:,.2f}")

            for it in [it_cat, it_cnt, it_tax, it_cgst, it_sgst, it_igst, it_tot]:
                it.setFont(f)
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)
                if is_bold:
                    it.setBackground(QColor("#F1F5F9"))

            summary_table.setItem(r_idx, 0, it_cat)
            summary_table.setItem(r_idx, 1, it_cnt)
            summary_table.setItem(r_idx, 2, it_tax)
            summary_table.setItem(r_idx, 3, it_cgst)
            summary_table.setItem(r_idx, 4, it_sgst)
            summary_table.setItem(r_idx, 5, it_igst)
            summary_table.setItem(r_idx, 6, it_tot)

        b2b_b2c_layout.addWidget(summary_table)
        tab_widget.addTab(b2b_b2c_widget, "B2B_B2C Summary")

        # Tab B: HSN Summary Table
        hsn_widget = QWidget()
        hsn_layout = QVBoxLayout(hsn_widget)

        hsn_map = {}
        for inv in self.invoices_list:
            cust_gstin = inv.get("customer_gstin", "")
            cust_st = inv.get("customer_state", "")
            if not cust_st and cust_gstin:
                cust_st = get_state_from_gstin(cust_gstin)

            is_delhi = is_delhi_client(cust_gstin, cust_st)

            for item in inv.get("items", []):
                hcode = item.get("hsn", "9982")
                amount = item.get("amount", 0.0)
                gst = item.get("gst_amt", 0.0)

                if is_delhi:
                    cgst = gst / 2.0
                    sgst = gst / 2.0
                    igst = 0.0
                else:
                    cgst = 0.0
                    sgst = 0.0
                    igst = gst

                if hcode not in hsn_map:
                    hsn_map[hcode] = {"taxable": 0.0, "cgst": 0.0, "sgst": 0.0, "igst": 0.0, "total": 0.0}

                hsn_map[hcode]["taxable"] += amount
                hsn_map[hcode]["cgst"] += cgst
                hsn_map[hcode]["sgst"] += sgst
                hsn_map[hcode]["igst"] += igst
                hsn_map[hcode]["total"] += (amount + gst)

        hsn_table = QTableWidget()
        hsn_table.setColumnCount(6)
        hsn_table.setHorizontalHeaderLabels([
            "HSN / SAC Code", "Taxable Amount (₹)", "CGST (₹)", "SGST (₹)", "IGST (₹)", "Total Value (₹)"
        ])
        hsn_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        hsn_table.setColumnWidth(0, 45)
        hsn_table.setColumnWidth(1, 192)
        hsn_table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        tot_rows = len(hsn_map) + 1
        hsn_table.setRowCount(tot_rows)

        hsn_tot_tax = 0.0
        hsn_tot_cgst = 0.0
        hsn_tot_sgst = 0.0
        hsn_tot_igst = 0.0
        hsn_tot_val = 0.0

        for row_idx, (hcode, vals) in enumerate(hsn_map.items()):
            it0 = QTableWidgetItem(hcode)
            it1 = QTableWidgetItem(f"₹{vals['taxable']:,.2f}")
            it2 = QTableWidgetItem(f"₹{vals['cgst']:,.2f}")
            it3 = QTableWidgetItem(f"₹{vals['sgst']:,.2f}")
            it4 = QTableWidgetItem(f"₹{vals['igst']:,.2f}")
            it5 = QTableWidgetItem(f"₹{vals['total']:,.2f}")

            for it in [it0, it1, it2, it3, it4, it5]:
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)

            hsn_table.setItem(row_idx, 0, it0)
            hsn_table.setItem(row_idx, 1, it1)
            hsn_table.setItem(row_idx, 2, it2)
            hsn_table.setItem(row_idx, 3, it3)
            hsn_table.setItem(row_idx, 4, it4)
            hsn_table.setItem(row_idx, 5, it5)

            hsn_tot_tax += vals['taxable']
            hsn_tot_cgst += vals['cgst']
            hsn_tot_sgst += vals['sgst']
            hsn_tot_igst += vals['igst']
            hsn_tot_val += vals['total']

        last_idx = tot_rows - 1
        f_b = QFont("Segoe UI", 9, QFont.Bold)
        it_hsn_tot = QTableWidgetItem("TOTAL HSN SUMMARY")
        it_hsn_tax = QTableWidgetItem(f"₹{hsn_tot_tax:,.2f}")
        it_hsn_cgst = QTableWidgetItem(f"₹{hsn_tot_cgst:,.2f}")
        it_hsn_sgst = QTableWidgetItem(f"₹{hsn_tot_sgst:,.2f}")
        it_hsn_igst = QTableWidgetItem(f"₹{hsn_tot_igst:,.2f}")
        it_hsn_val = QTableWidgetItem(f"₹{hsn_tot_val:,.2f}")

        for it in [it_hsn_tot, it_hsn_tax, it_hsn_cgst, it_hsn_sgst, it_hsn_igst, it_hsn_val]:
            it.setFont(f_b)
            it.setFlags(it.flags() & ~Qt.ItemIsEditable)
            it.setBackground(QColor("#F1F5F9"))

        hsn_table.setItem(last_idx, 0, it_hsn_tot)
        hsn_table.setItem(last_idx, 1, it_hsn_tax)
        hsn_table.setItem(last_idx, 2, it_hsn_cgst)
        hsn_table.setItem(last_idx, 3, it_hsn_sgst)
        hsn_table.setItem(last_idx, 4, it_hsn_igst)
        hsn_table.setItem(last_idx, 5, it_hsn_val)

        hsn_layout.addWidget(hsn_table)
        tab_widget.addTab(hsn_widget, "HSN Code Summary")

        # Tab C: Documents Issued Summary Table
        docs_widget = QWidget()
        docs_layout = QVBoxLayout(docs_widget)

        def get_doc_range(doc_type_name):
            matching = [inv.get("doc_no", "") for inv in self.invoices_list if inv.get("doc_type") == doc_type_name]
            if not matching:
                return "-", "-", 0, 0, 0
            matching.sort()
            from_no = matching[0]
            to_no = matching[-1]
            tot = len(matching)
            canc = 0
            net = tot
            return from_no, to_no, tot, canc, net

        docs_table = QTableWidget()
        docs_table.setColumnCount(6)
        docs_table.setHorizontalHeaderLabels([
            "Document Type", "From Serial No", "To Serial No", "Total Issued", "Cancelled", "Net Issued"
        ])
        docs_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Fixed)
        docs_table.setColumnWidth(0, 110)
        docs_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        docs_table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        doc_types = ["Tax Invoice", "Credit Note", "Debit Note"]
        docs_table.setRowCount(len(doc_types))

        for idx, d_type in enumerate(doc_types):
            f_no, t_no, tot_c, canc_c, net_c = get_doc_range(d_type)
            it0 = QTableWidgetItem(d_type)
            it1 = QTableWidgetItem(f_no)
            it2 = QTableWidgetItem(t_no)
            it3 = QTableWidgetItem(str(tot_c))
            it4 = QTableWidgetItem(str(canc_c))
            it5 = QTableWidgetItem(str(net_c))

            for it in [it0, it1, it2, it3, it4, it5]:
                it.setFlags(it.flags() & ~Qt.ItemIsEditable)

            docs_table.setItem(idx, 0, it0)
            docs_table.setItem(idx, 1, it1)
            docs_table.setItem(idx, 2, it2)
            docs_table.setItem(idx, 3, it3)
            docs_table.setItem(idx, 4, it4)
            docs_table.setItem(idx, 5, it5)

        docs_layout.addWidget(docs_table)
        tab_widget.addTab(docs_widget, "Documents Issued Summary")

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close, alignment=Qt.AlignRight)


class AuditLogDialog(QDialog):
    """Dialog displaying historical audit logs of additions, edits, and deletions with Action filtering."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("PSC Billing Manager - System Audit & Activity Log")
        self.resize(920, 520)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        top_layout = QHBoxLayout()
        title_lbl = QLabel("📜 Invoice System Audit & Edit History Log")
        font_t = QFont("Segoe UI", 12, QFont.Bold)
        title_lbl.setFont(font_t)
        title_lbl.setStyleSheet("color: #1E3A8A;")

        self.combo_action_filter = QComboBox()
        self.combo_action_filter.addItems(["All Actions", "CREATED", "UPDATED", "DELETED"])
        self.combo_action_filter.currentIndexChanged.connect(self.populate_logs)

        top_layout.addWidget(title_lbl)
        top_layout.addStretch()
        top_layout.addWidget(QLabel("Filter by Action:"))
        top_layout.addWidget(self.combo_action_filter)

        layout.addLayout(top_layout)

        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels([
            "Timestamp", "Action", "Document No", "Doc Type", "Customer Name", "Amount (₹)", "Details"
        ])
        self.table.horizontalHeader().setSectionResizeMode(6, QHeaderView.Stretch)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)

        layout.addWidget(self.table)

        btn_close = QPushButton("Close")
        btn_close.clicked.connect(self.accept)
        layout.addWidget(btn_close, alignment=Qt.AlignRight)

        self.populate_logs()

    def populate_logs(self):
        logs = DataManager.load_audit_logs()
        action_filter = getattr(self, 'combo_action_filter', None)
        selected_act = action_filter.currentText() if action_filter else "All Actions"

        self.table.setRowCount(0)

        for entry in reversed(logs):
            act = entry.get("action", "")
            if selected_act != "All Actions" and act != selected_act:
                continue

            row_idx = self.table.rowCount()
            self.table.insertRow(row_idx)

            act_item = QTableWidgetItem(act)
            if act == "CREATED":
                act_item.setForeground(QColor("#16A34A"))
            elif act == "UPDATED":
                act_item.setForeground(QColor("#2563EB"))
            elif act == "DELETED":
                act_item.setForeground(QColor("#DC2626"))

            self.table.setItem(row_idx, 0, QTableWidgetItem(entry.get("timestamp", "")))
            self.table.setItem(row_idx, 1, act_item)
            self.table.setItem(row_idx, 2, QTableWidgetItem(entry.get("doc_no", "")))
            self.table.setItem(row_idx, 3, QTableWidgetItem(entry.get("doc_type", "")))
            self.table.setItem(row_idx, 4, QTableWidgetItem(entry.get("customer_name", "")))
            self.table.setItem(row_idx, 5, QTableWidgetItem(f"₹{entry.get('amount', 0):,.2f}"))
            self.table.setItem(row_idx, 6, QTableWidgetItem(entry.get("details", "")))


class PaymentTrancheDialog(QDialog):
    """Dialog for recording payment receipts in tranches."""
    def __init__(self, invoice_data, parent=None):
        super().__init__(parent)
        self.invoice_data = invoice_data
        self.setWindowTitle(f"Record Payment Receipt - {invoice_data.get('doc_no')}")
        self.resize(520, 380)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)

        g_total = self.invoice_data.get("grand_total", 0.0)
        payments = self.invoice_data.get("payments", [])
        tot_received = sum(p.get("amount", 0.0) for p in payments)
        balance = g_total - tot_received

        info_lbl = QLabel(f"<b>Document #:</b> {self.invoice_data.get('doc_no')}<br/>"
                          f"<b>Client:</b> {self.invoice_data.get('customer_name')}<br/>"
                          f"<b>Total Invoice Amount:</b> ₹{g_total:,.2f}<br/>"
                          f"<b>Already Received:</b> ₹{tot_received:,.2f}<br/>"
                          f"<b>Balance Due:</b> <font color='#DC2626'><b>₹{balance:,.2f}</b></font>")
        info_lbl.setStyleSheet("background-color: #F1F5F9; padding: 10px; border-radius: 6px;")
        layout.addWidget(info_lbl)

        form_group = QGroupBox("New Payment Tranche Receipt")
        form_layout = QFormLayout(form_group)

        self.date_pay = QDateEdit(QDate.currentDate())
        self.date_pay.setCalendarPopup(True)

        self.spin_pay_amount = QDoubleSpinBox()
        self.spin_pay_amount.setRange(0.01, 10000000.0)
        self.spin_pay_amount.setValue(max(balance, 0.0))
        self.spin_pay_amount.setPrefix("₹")

        self.combo_pay_mode = QComboBox()
        self.combo_pay_mode.addItems(["UPI / QR", "Bank Transfer (NEFT/RTGS/IMPS)", "Cheque", "Cash", "Other"])

        self.edit_pay_notes = QLineEdit()
        self.edit_pay_notes.setPlaceholderText("Tranche notes / Ref Transaction ID")

        form_layout.addRow("Receipt Date:", self.date_pay)
        form_layout.addRow("Amount Received*:", self.spin_pay_amount)
        form_layout.addRow("Payment Mode:", self.combo_pay_mode)
        form_layout.addRow("Tranche Notes:", self.edit_pay_notes)

        layout.addWidget(form_group)

        btn_box = QHBoxLayout()
        btn_save = QPushButton("💾 Save Receipt Tranche")
        btn_save.setObjectName("btnSuccess")
        btn_save.clicked.connect(self.save_payment)

        btn_cancel = QPushButton("Cancel")
        btn_cancel.clicked.connect(self.reject)

        btn_box.addWidget(btn_save)
        btn_box.addWidget(btn_cancel)

        layout.addLayout(btn_box)

    def save_payment(self):
        amt = self.spin_pay_amount.value()
        if amt <= 0:
            show_msg(self, "Validation Error", "Payment amount must be greater than zero.", "warning")
            return

        entry = {
            "date": self.date_pay.date().toString("yyyy-MM-dd"),
            "amount": amt,
            "mode": self.combo_pay_mode.currentText(),
            "notes": self.edit_pay_notes.text().strip()
        }

        if DataManager.add_payment_tranche(self.invoice_data.get("doc_no"), entry):
            show_msg(self, "Payment Recorded", f"Payment tranche of ₹{amt:,.2f} recorded successfully!", "info")
            self.accept()


# =============================================================================
# SECTION 9: EXECUTION ENTRY POINT
# =============================================================================

def main():
    app = QApplication(sys.argv)
    app.setApplicationName("PSC Billing Manager")
    window = PSCBillingApp()
    window.show()
    exec_func = getattr(app, 'exec_', None) or getattr(app, 'exec')
    sys.exit(exec_func())

if __name__ == "__main__":
    main()
