"""Desktop window for the e-Invoice <-> Tally reconciliation.  Run:  python app.py  (or run.bat)"""
import os
import queue
import sys
import threading
from datetime import date
from tkinter import filedialog, messagebox

try:
    import customtkinter as ctk
except ImportError:
    messagebox.showerror("Missing library",
                         "The 'customtkinter' library is not installed.\n\n"
                         "Double-click install.bat in the app folder, then start run.bat again.")
    sys.exit(1)

from common import load_config, save_config, to_date
from tally_client import TallyClient
from themes import THEMES, DEFAULT_THEME, get_theme

STATUS_GROUPS = {  # summary tiles: label -> statuses counted
    "Matched": ["Matched"],
    "Mismatches": ["Value mismatch", "GSTIN mismatch", "Date mismatch", "IRN cancelled but active in Tally"],
    "Missing": ["Only in Tally (e-invoice missing)", "Only in e-Invoice (not in Tally)"],
    "B2C": ["B2C / no GSTIN in Tally (not on IRP)"],
}


def _default_period():
    first_this = date.today().replace(day=1)
    last_prev = first_this.fromordinal(first_this.toordinal() - 1)
    return last_prev.replace(day=1), last_prev


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("GST e-Invoice ↔ Tally Prime Reconciliation")
        self.geometry("980x720")
        self.minsize(860, 640)
        self.cfg = load_config()
        self.theme_name = self.cfg.get("ui_theme", DEFAULT_THEME)
        if self.theme_name not in THEMES:
            self.theme_name = DEFAULT_THEME
        self.q = queue.Queue()
        f, t = _default_period()
        self.state_vals = {
            "host": self.cfg["tally"]["host"], "port": str(self.cfg["tally"]["port"]),
            "company": self.cfg["tally"].get("company", ""),
            "companies": [self.cfg["tally"].get("company", "")] if self.cfg["tally"].get("company") else [],
            "from": f.strftime("%d-%m-%Y"), "to": t.strftime("%d-%m-%Y"),
        }
        self.files = []
        self.last_report = None
        self.counts = None
        self.log_lines = []
        self.busy = False
        self._build()
        self.after(200, self._drain)

    # ================================================================ UI
    def _build(self):
        T = self.T = get_theme(self.theme_name)
        ctk.set_appearance_mode(T["mode"])
        self.configure(fg_color=T["bg"])
        for w in self.winfo_children():
            w.destroy()

        f_title = ctk.CTkFont(family="Segoe UI", size=20, weight="bold")
        f_sub = ctk.CTkFont(family="Segoe UI", size=12)
        f_card = ctk.CTkFont(family="Segoe UI", size=14, weight="bold")
        f_lbl = ctk.CTkFont(family="Segoe UI", size=12)
        f_btn = ctk.CTkFont(family="Segoe UI", size=13, weight="bold")
        self.f_tile_num = ctk.CTkFont(family="Segoe UI", size=24, weight="bold")
        self.f_tile_lbl = ctk.CTkFont(family="Segoe UI", size=11)

        # ---------- header
        hdr = ctk.CTkFrame(self, fg_color=T["header"], corner_radius=0, height=72)
        hdr.pack(fill="x")
        hdr.pack_propagate(False)
        box = ctk.CTkFrame(hdr, fg_color="transparent")
        box.pack(side="left", padx=20, pady=10)
        ctk.CTkLabel(box, text="GST e-Invoice  ↔  Tally Prime", font=f_title,
                     text_color=T["header_text"]).pack(anchor="w")
        ctk.CTkLabel(box, text="GSTR-1 reconciliation", font=f_sub,
                     text_color=T["header_sub"]).pack(anchor="w")
        tbox = ctk.CTkFrame(hdr, fg_color="transparent")
        tbox.pack(side="right", padx=20)
        ctk.CTkLabel(tbox, text="Theme", font=f_lbl, text_color=T["header_text"]).pack(side="left", padx=(0, 8))
        theme_menu = ctk.CTkOptionMenu(
            tbox, values=list(THEMES.keys()), command=self._change_theme, width=200,
            fg_color=T["accent"], button_color=T["accent_hover"], button_hover_color=T["accent_hover"],
            text_color=T["accent_text"], dropdown_fg_color=T["card"], dropdown_text_color=T["text"],
            dropdown_hover_color=T["border"], font=f_lbl)
        theme_menu.set(self.theme_name)
        theme_menu.pack(side="left")

        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True, padx=18, pady=14)
        body.grid_columnconfigure((0, 1), weight=1, uniform="c")
        body.grid_rowconfigure(3, weight=1)

        entry_kw = dict(fg_color=T["input_bg"], border_color=T["border"], text_color=T["text"],
                        font=f_lbl, height=32)

        # ---------- card: Tally
        c1 = self._card(body, "①  Tally Prime", f_card)
        c1.grid(row=0, column=0, sticky="nsew", padx=(0, 8), pady=(0, 12))
        row = ctk.CTkFrame(c1, fg_color="transparent"); row.pack(fill="x", padx=16, pady=(4, 6))
        self._lbl(row, "Host", f_lbl).pack(side="left")
        self.host = ctk.CTkEntry(row, width=130, **entry_kw); self.host.pack(side="left", padx=(6, 14))
        self.host.insert(0, self.state_vals["host"])
        self._lbl(row, "Port", f_lbl).pack(side="left")
        self.port = ctk.CTkEntry(row, width=70, **entry_kw); self.port.pack(side="left", padx=6)
        self.port.insert(0, self.state_vals["port"])
        row2 = ctk.CTkFrame(c1, fg_color="transparent"); row2.pack(fill="x", padx=16, pady=(2, 14))
        self.company = ctk.CTkComboBox(
            row2, values=self.state_vals["companies"] or [""], width=260,
            fg_color=T["input_bg"], border_color=T["border"], button_color=T["primary"],
            button_hover_color=T["primary_hover"], text_color=T["text"], dropdown_fg_color=T["card"],
            dropdown_text_color=T["text"], dropdown_hover_color=T["border"], font=f_lbl, height=32)
        self.company.set(self.state_vals["company"])
        self.company.pack(side="left", fill="x", expand=True)
        self._btn(row2, "Load companies", self._load_companies, f_btn, kind="ghost", width=140).pack(side="left", padx=(8, 0))

        # ---------- card: Period
        c2 = self._card(body, "②  Period", f_card)
        c2.grid(row=0, column=1, sticky="nsew", padx=(8, 0), pady=(0, 12))
        row = ctk.CTkFrame(c2, fg_color="transparent"); row.pack(fill="x", padx=16, pady=(4, 6))
        self._lbl(row, "From", f_lbl).pack(side="left")
        self.from_e = ctk.CTkEntry(row, width=120, placeholder_text="DD-MM-YYYY", **entry_kw)
        self.from_e.pack(side="left", padx=(6, 14)); self.from_e.insert(0, self.state_vals["from"])
        self._lbl(row, "To", f_lbl).pack(side="left")
        self.to_e = ctk.CTkEntry(row, width=120, placeholder_text="DD-MM-YYYY", **entry_kw)
        self.to_e.pack(side="left", padx=6); self.to_e.insert(0, self.state_vals["to"])
        self._lbl(c2, "Format: DD-MM-YYYY  (default = last month)", f_lbl, muted=True).pack(anchor="w", padx=16, pady=(2, 14))

        # ---------- card: e-invoice data + actions
        c3 = self._card(body, "③  e-Invoice data & reconcile", f_card)
        c3.grid(row=1, column=0, columnspan=2, sticky="nsew", pady=(0, 12))
        row = ctk.CTkFrame(c3, fg_color="transparent"); row.pack(fill="x", padx=16, pady=(4, 6))
        self.dl_btn = self._btn(row, "⬇  Download from GST portal", lambda: self._start(True), f_btn, kind="accent", width=230)
        self.dl_btn.pack(side="left")
        self._lbl(row, "or", f_lbl, muted=True).pack(side="left", padx=10)
        self._btn(row, "Pick downloaded file(s)", self._pick, f_btn, kind="ghost", width=210).pack(side="left")
        self.run_btn = self._btn(row, "▶  Reconcile with Tally", lambda: self._start(False), f_btn, kind="primary", width=210)
        self.run_btn.pack(side="right")
        self.files_lbl = self._lbl(c3, self._files_text(), f_lbl, muted=not self.files)
        self.files_lbl.pack(anchor="w", padx=16, pady=(2, 14))

        # ---------- summary tiles
        tiles = ctk.CTkFrame(body, fg_color="transparent")
        tiles.grid(row=2, column=0, columnspan=2, sticky="ew", pady=(0, 12))
        tiles.grid_columnconfigure((0, 1, 2, 3, 4), weight=1, uniform="t")
        self.tile_labels = {}
        tile_colors = {"Total": T["info"], "Matched": T["ok"], "Mismatches": T["warn"],
                       "Missing": T["bad"], "B2C": T["muted"]}
        for i, name in enumerate(["Total", "Matched", "Mismatches", "Missing", "B2C"]):
            t = ctk.CTkFrame(tiles, fg_color=T["card"], corner_radius=12, border_width=1, border_color=T["border"])
            t.grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 6, 0))
            bar = ctk.CTkFrame(t, fg_color=tile_colors[name], height=5, corner_radius=3)
            bar.pack(fill="x", padx=10, pady=(8, 0))
            num = ctk.CTkLabel(t, text="–", font=self.f_tile_num, text_color=tile_colors[name])
            num.pack(pady=(4, 0))
            ctk.CTkLabel(t, text=name, font=self.f_tile_lbl, text_color=T["muted"]).pack(pady=(0, 10))
            self.tile_labels[name] = num
        if self.counts:
            self._show_counts(self.counts)

        # ---------- log + footer
        logcard = ctk.CTkFrame(body, fg_color=T["log_bg"], corner_radius=12)
        logcard.grid(row=3, column=0, columnspan=2, sticky="nsew")
        self.log = ctk.CTkTextbox(logcard, fg_color=T["log_bg"], text_color=T["log_fg"],
                                  font=ctk.CTkFont(family="Consolas", size=12), wrap="word",
                                  corner_radius=12, border_width=0)
        self.log.pack(fill="both", expand=True, padx=8, pady=8)
        for tag, col in (("ok", T["ok"]), ("warn", T["warn"]), ("bad", T["bad"]), ("info", T["accent"])):
            self.log.tag_config(tag, foreground=col)
        for line in self.log_lines:
            self._write_log(line)

        foot = ctk.CTkFrame(self, fg_color="transparent")
        foot.pack(fill="x", padx=18, pady=(0, 14))
        self.progress = ctk.CTkProgressBar(foot, mode="indeterminate", progress_color=T["accent"],
                                           fg_color=T["border"], height=6, width=220)
        self.progress.pack(side="left")
        self.progress.set(0)
        self.status_lbl = self._lbl(foot, "Ready", f_lbl, muted=True)
        self.status_lbl.pack(side="left", padx=12)
        self._btn(foot, "Open reports folder", lambda: self._open(self.cfg["folders"]["reports"]),
                  f_btn, kind="ghost", width=170).pack(side="right")
        self.open_btn = self._btn(foot, "Open report", self._open_report, f_btn, kind="primary", width=160)
        self.open_btn.pack(side="right", padx=8)
        self.open_btn.configure(state="normal" if self.last_report else "disabled")
        if self.busy:
            self._set_busy(True)

    # ---------- widget helpers
    def _card(self, parent, title, font):
        T = self.T
        c = ctk.CTkFrame(parent, fg_color=T["card"], corner_radius=14, border_width=1, border_color=T["border"])
        ctk.CTkLabel(c, text=title, font=font, text_color=T["primary"] if T["mode"] == "light" else T["accent"]
                     ).pack(anchor="w", padx=16, pady=(12, 4))
        return c

    def _lbl(self, parent, text, font, muted=False):
        return ctk.CTkLabel(parent, text=text, font=font, text_color=self.T["muted"] if muted else self.T["text"])

    def _btn(self, parent, text, cmd, font, kind="primary", width=160):
        T = self.T
        styles = {
            "primary": dict(fg_color=T["primary"], hover_color=T["primary_hover"], text_color="#FFFFFF"),
            "accent": dict(fg_color=T["accent"], hover_color=T["accent_hover"], text_color=T["accent_text"]),
            "ghost": dict(fg_color="transparent", hover_color=T["border"], text_color=T["text"],
                          border_width=1, border_color=T["primary"]),
        }
        return ctk.CTkButton(parent, text=text, command=cmd, font=font, width=width, height=36,
                             corner_radius=10, **styles[kind])

    def _files_text(self):
        return ("Selected: " + "; ".join(os.path.basename(p) for p in self.files)) if self.files \
            else "No file selected yet"

    # ---------- theme switching (keeps what you typed)
    def _snapshot(self):
        self.state_vals.update(host=self.host.get(), port=self.port.get(), company=self.company.get(),
                               **{"from": self.from_e.get(), "to": self.to_e.get()})

    def _change_theme(self, name):
        self._snapshot()
        self.theme_name = name
        self.cfg["ui_theme"] = name
        self._save_cfg()
        self.after(20, self._build)

    # ================================================================ actions
    def _sync_cfg(self):
        self._snapshot()
        self.cfg["tally"]["host"] = self.state_vals["host"].strip() or "localhost"
        self.cfg["tally"]["port"] = int(self.state_vals["port"].strip() or 9000)
        self.cfg["tally"]["company"] = self.state_vals["company"].strip()
        self.cfg["ui_theme"] = self.theme_name
        self._save_cfg()

    def _save_cfg(self):
        try:
            save_config(self.cfg)
        except Exception:
            pass

    def _load_companies(self):
        self._sync_cfg()
        try:
            names = TallyClient(self.cfg).list_companies()
            self.state_vals["companies"] = names
            self.company.configure(values=names or [""])
            if names and not self.company.get():
                self.company.set(names[0])
            self._log(f"Companies open in Tally: {', '.join(names) or '(none)'}")
        except Exception as e:
            self._log(f"ERROR: {e}")
            messagebox.showerror("Tally", str(e))

    def _pick(self):
        paths = filedialog.askopenfilenames(
            title="Select e-invoice file(s)",
            initialdir=os.path.join(os.path.expanduser("~"), "Desktop"),
            filetypes=[("e-Invoice files", "*.xlsx *.xls *.json *.zip *.csv"), ("All", "*.*")])
        if paths:
            self.files = list(paths)
            self.files_lbl.configure(text=self._files_text(), text_color=self.T["text"])

    def _start(self, download):
        if self.busy:
            return
        self._sync_cfg()
        f, t = to_date(self.state_vals["from"]), to_date(self.state_vals["to"])
        if not f or not t or f > t:
            messagebox.showerror("Period", "Enter valid From / To dates (DD-MM-YYYY).")
            return
        if not download and not self.files:
            messagebox.showinfo("e-Invoice file", "Download from the portal or pick the e-invoice file first.")
            return
        self._set_busy(True)
        threading.Thread(target=self._worker, args=(f, t, download), daemon=True).start()

    def _worker(self, f, t, download):
        from pipeline import run
        try:
            out, results = run(self.cfg, f, t, [] if download else self.files, download=download,
                               log=lambda m: self.q.put(("log", m)))
            counts = {}
            for r in results:
                counts[r["Status"]] = counts.get(r["Status"], 0) + 1
            self.q.put(("done", (str(out), counts)))
        except Exception as e:
            self.q.put(("log", f"ERROR: {e}"))
            self.q.put(("fail", None))

    def _set_busy(self, on):
        self.busy = on
        self.dl_btn.configure(state="disabled" if on else "normal")
        self.run_btn.configure(state="disabled" if on else "normal")
        if on:
            self.progress.start()
            self.status_lbl.configure(text="Working…", text_color=self.T["muted"])
        else:
            self.progress.stop()
            self.progress.set(0)

    def _show_counts(self, counts):
        total = sum(counts.values())
        self.tile_labels["Total"].configure(text=str(total))
        for name, statuses in STATUS_GROUPS.items():
            self.tile_labels[name].configure(text=str(sum(counts.get(s, 0) for s in statuses)))

    def _drain(self):
        try:
            while True:
                kind, payload = self.q.get_nowait()
                if kind == "log":
                    self._log(payload)
                elif kind == "done":
                    self.last_report, self.counts = payload
                    self._show_counts(self.counts)
                    self._set_busy(False)
                    self.open_btn.configure(state="normal")
                    self.status_lbl.configure(text="Done ✔  Report ready", text_color=self.T["ok"])
                elif kind == "fail":
                    self._set_busy(False)
                    self.status_lbl.configure(text="Stopped - see log", text_color=self.T["bad"])
        except queue.Empty:
            pass
        self.after(200, self._drain)

    def _log(self, m):
        self.log_lines.append(m)
        self._write_log(m)

    def _write_log(self, m):
        low = m.lower()
        tag = ("bad" if low.startswith("error") or "only in" in low or "cancelled" in low
               else "warn" if "mismatch" in low or "warning" in low
               else "ok" if "matched" in low or "report saved" in low or "saved download" in low
               else "info" if m.startswith(("Reading", "Fetching", "Logged", "Please", "Select", "Waiting"))
               else None)
        self.log.insert("end", m + "\n", tag) if tag else self.log.insert("end", m + "\n")
        self.log.see("end")

    def _open_report(self):
        if self.last_report:
            self._open(self.last_report)

    @staticmethod
    def _open(path):
        try:
            os.startfile(path)  # Windows
        except AttributeError:
            import subprocess
            subprocess.Popen(["xdg-open", path])


if __name__ == "__main__":
    App().mainloop()
