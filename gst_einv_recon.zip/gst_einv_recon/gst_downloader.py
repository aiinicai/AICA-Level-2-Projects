"""Download the e-invoice Excel from the GST portal (GSTR-1 dashboard).

How it works
  1. Opens a real Chrome/Edge window (Playwright) with a saved profile.
  2. YOU log in (User ID, password, CAPTCHA). The portal requires a human for the
     CAPTCHA, so the app never tries to solve or bypass it.
  3. The app opens the Returns Dashboard. Pick the period > GSTR-1 > View >
     "DOWNLOAD DETAILS FROM E-INVOICES (EXCEL)" > "E-INVOICE DOWNLOAD HISTORY" > File link.
     (The app also tries to click these buttons for you; if the portal layout
     changed, just click them yourself.)
  4. Every file you download in that window is saved automatically to the
     app's downloads folder and handed over to the reconciliation.

One-time setup on your PC:
  pip install playwright
  python -m playwright install chromium     (or set "browser_channel": "msedge"/"chrome")
"""
import time
from pathlib import Path


def download_einvoices(cfg, log=print, auto_click=True):
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        raise RuntimeError("The 'playwright' library is not installed. Close the app, double-click "
                           "install.bat in the app folder, then start run.bat again.")

    portal = cfg["portal"]
    dl_dir = Path(cfg["folders"]["downloads"])
    profile = cfg["folders"]["browser_profile"]
    saved = []

    with sync_playwright() as p:
        kwargs = dict(headless=False, accept_downloads=True, viewport=None,
                      args=["--start-maximized"])
        channel = portal.get("browser_channel")
        if channel:
            kwargs["channel"] = channel
        try:
            ctx = p.chromium.launch_persistent_context(profile, **kwargs)
        except Exception:
            if not channel:
                raise
            log(f"Could not start {channel}; using built-in Chromium instead.")
            kwargs.pop("channel")
            ctx = p.chromium.launch_persistent_context(profile, **kwargs)

        def on_download(dl):
            target = dl_dir / f"{time.strftime('%Y%m%d_%H%M%S')}_{dl.suggested_filename}"
            dl.save_as(str(target))
            saved.append(target)
            log(f"Saved download: {target.name}")

        ctx.on("page", lambda pg: pg.on("download", on_download))
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.on("download", on_download)

        page.goto(portal["login_url"])
        log("Please log in to the GST portal in the browser window (enter CAPTCHA yourself)...")

        deadline = time.time() + portal.get("login_wait_minutes", 5) * 60
        while time.time() < deadline:
            if "/auth/" in page.url or "services/auth" in page.url:
                break
            page.wait_for_timeout(1500)
        else:
            ctx.close()
            raise TimeoutError("Login not completed in time.")
        log("Logged in. Opening Returns Dashboard...")

        page.goto(portal["returns_dashboard_url"])
        log("Select Financial Year / Period and click SEARCH, then open GSTR-1 (VIEW / PREPARE ONLINE).")

        if auto_click:
            _try_auto_click(page, log, portal)

        log("Waiting for the e-invoice file download (click the File link in E-INVOICE DOWNLOAD HISTORY)...")
        deadline = time.time() + portal.get("download_wait_minutes", 10) * 60
        while time.time() < deadline and not saved:
            page.wait_for_timeout(1500)
        # give a moment for any second file (e.g. File2)
        if saved:
            page.wait_for_timeout(4000)
        ctx.close()

    if not saved:
        raise TimeoutError("No file was downloaded.")
    return saved


def _try_auto_click(page, log, portal):
    """Best-effort clicks; harmless if the buttons aren't found (user clicks instead)."""
    wait_ms = portal.get("auto_click_wait_seconds", 180) * 1000
    try:
        btn = page.get_by_role("button", name="DOWNLOAD DETAILS FROM E-INVOICES", exact=False)
        btn.first.wait_for(timeout=wait_ms)
        btn.first.click()
        log("Clicked 'Download details from e-Invoices (Excel)'. The portal prepares the file "
            "(can take a few minutes).")
        page.wait_for_timeout(5000)
        hist = page.get_by_role("button", name="E-INVOICE DOWNLOAD HISTORY", exact=False)
        if hist.count():
            hist.first.click()
            log("Opened E-invoice download history - click the latest File link when it appears.")
    except Exception:
        log("Couldn't find the e-invoice buttons automatically - please click them in the browser.")
