"""Match Tally outward vouchers against e-invoice (IRP) records."""
from common import norm_invoice_no

AMT_FIELDS = ("taxable", "igst", "cgst", "sgst", "cess", "inv_value")

STATUS_ORDER = [
    "Matched",
    "Value mismatch",
    "GSTIN mismatch",
    "Date mismatch",
    "IRN cancelled but active in Tally",
    "Only in Tally (e-invoice missing)",
    "Only in e-Invoice (not in Tally)",
    "B2C / no GSTIN in Tally (not on IRP)",
]


def _is_cancelled(status):
    return "CANCEL" in str(status or "").upper() or str(status or "").upper() in ("CNL",)


def reconcile(tally_rows, einv_rows, matching_cfg):
    tol = float(matching_cfg.get("amount_tolerance", 1.0))
    key = lambda r: (r["doc_type"], norm_invoice_no(r["inv_no"], matching_cfg))

    einv_by_key = {}
    for e in einv_rows:
        einv_by_key.setdefault(key(e), []).append(e)

    results, used = [], set()
    for t in tally_rows:
        k = key(t)
        cands = [e for e in einv_by_key.get(k, []) if id(e) not in used]
        if not cands:
            # fallback: some users book credit notes as a different voucher type
            alt = [e for dt in ("INV", "CRN", "DBN") for e in einv_by_key.get((dt, k[1]), [])
                   if id(e) not in used and e["gstin"] == t["gstin"]]
            cands = alt
        if not cands:
            status = ("B2C / no GSTIN in Tally (not on IRP)" if not t["gstin"]
                      else "Only in Tally (e-invoice missing)")
            results.append(_row(status, t, None, tol))
            continue
        # prefer an active IRN with the same GSTIN
        cands.sort(key=lambda e: (_is_cancelled(e.get("status")), e["gstin"] != t["gstin"]))
        e = cands[0]
        used.add(id(e))
        results.append(_row(_status(t, e, tol, matching_cfg), t, e, tol))

    for e in einv_rows:
        if id(e) not in used:
            if _is_cancelled(e.get("status")):
                continue  # cancelled IRN and not in Tally = fine, nothing to do
            results.append(_row("Only in e-Invoice (not in Tally)", None, e, tol))

    results.sort(key=lambda r: (STATUS_ORDER.index(r["Status"]), str(r["Invoice No"])))
    return results


TAX_FIELDS = ("igst", "cgst", "sgst", "cess")


def _status(t, e, tol, matching_cfg=None):
    matching_cfg = matching_cfg or {}
    if _is_cancelled(e.get("status")):
        return "IRN cancelled but active in Tally"
    if t["gstin"] and e["gstin"] and t["gstin"] != e["gstin"]:
        return "GSTIN mismatch"
    tax_ok = all(abs(t[f] - e[f]) <= tol for f in TAX_FIELDS)
    value_diffs = [f for f in ("taxable", "inv_value")
                   if not (f == "inv_value" and not e[f])  # some sheets don't carry invoice value
                   and abs(t[f] - e[f]) > tol]
    if not tax_ok:
        return "Value mismatch"
    if value_diffs:
        # Tax agrees, only taxable / invoice value differ -> discount or round-off: treat as matched
        cap = float(matching_cfg.get("max_taxable_diff_accepted", 0) or 0)
        accept = matching_cfg.get("accept_taxable_diff_if_tax_matches", True)
        within_cap = cap <= 0 or abs(t["taxable"] - e["taxable"]) <= cap
        if not (accept and within_cap):
            return "Value mismatch"
    if t["inv_date"] and e["inv_date"] and t["inv_date"] != e["inv_date"]:
        return "Date mismatch"
    return "Matched"


def _row(status, t, e, tol):
    t = t or {}
    e = e or {}
    g = lambda d, f, default=0.0: d.get(f, default)
    row = {
        "Status": status,
        "Doc Type": t.get("doc_type") or e.get("doc_type"),
        "Invoice No": t.get("inv_no") or e.get("inv_no"),
        "Tally Date": t.get("inv_date"),
        "e-Inv Date": e.get("inv_date"),
        "Party (Tally)": t.get("party", ""),
        "Party (e-Inv)": e.get("party", ""),
        "GSTIN (Tally)": t.get("gstin", ""),
        "GSTIN (e-Inv)": e.get("gstin", ""),
    }
    diffs = []
    for f, label in (("taxable", "Taxable"), ("igst", "IGST"), ("cgst", "CGST"),
                     ("sgst", "SGST"), ("cess", "Cess"), ("inv_value", "Invoice Value")):
        tv = g(t, f) if t else None
        ev = g(e, f) if e else None
        row[f"{label} (Tally)"] = tv
        row[f"{label} (e-Inv)"] = ev
        d = round((tv or 0) - (ev or 0), 2) if (t and e) else None
        row[f"{label} Diff"] = d
        if d is not None and abs(d) > tol and not (f == "inv_value" and not ev):
            diffs.append(f"{label} {d:+,.2f}")
    row["IRN"] = e.get("irn") or t.get("irn", "")
    row["IRN Status"] = e.get("status", "")
    row["Voucher Type"] = t.get("voucher_type", "")
    if status == "Matched" and diffs:
        row["Remarks"] = "Accepted (discount / round-off, tax matches): " + "; ".join(diffs)
    else:
        row["Remarks"] = "; ".join(diffs) if diffs else _remark(status)
    return row


def _remark(status):
    return {
        "Only in Tally (e-invoice missing)": "B2B voucher has no IRN on portal - generate e-invoice or check invoice number",
        "Only in e-Invoice (not in Tally)": "IRN exists but voucher not found in Tally - book it, or invoice number differs",
        "IRN cancelled but active in Tally": "Cancel/alter voucher in Tally or re-generate IRN",
        "GSTIN mismatch": "Party GSTIN in Tally differs from e-invoice",
        "Date mismatch": "Voucher date differs from e-invoice date",
        "B2C / no GSTIN in Tally (not on IRP)": "Not applicable for e-invoice (check if party is actually registered)",
    }.get(status, "")


def summary(results):
    out = []
    for s in STATUS_ORDER:
        rs = [r for r in results if r["Status"] == s]
        out.append({
            "Status": s,
            "Count": len(rs),
            "Taxable (Tally)": round(sum(r["Taxable (Tally)"] or 0 for r in rs), 2),
            "Taxable (e-Inv)": round(sum(r["Taxable (e-Inv)"] or 0 for r in rs), 2),
            "Tax (Tally)": round(sum((r["IGST (Tally)"] or 0) + (r["CGST (Tally)"] or 0) +
                                     (r["SGST (Tally)"] or 0) + (r["Cess (Tally)"] or 0) for r in rs), 2),
            "Tax (e-Inv)": round(sum((r["IGST (e-Inv)"] or 0) + (r["CGST (e-Inv)"] or 0) +
                                     (r["SGST (e-Inv)"] or 0) + (r["Cess (e-Inv)"] or 0) for r in rs), 2),
        })
    return out
