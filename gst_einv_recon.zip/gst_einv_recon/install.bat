@echo off
cd /d "%~dp0"
echo ============================================
echo  Installing required Python libraries...
echo ============================================
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
  echo.
  echo Install failed. Check that Python is installed and "Add Python to PATH" was ticked.
  pause
  exit /b 1
)
echo.
echo Installing browser support for the GST portal download...
python -m playwright install msedge >nul 2>&1
python -m playwright install chromium
echo.
echo ============================================
echo  Done. Now double-click run.bat
echo ============================================
pause
