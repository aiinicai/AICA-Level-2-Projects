"""Colour combinations for the app window (and the Excel report header)."""

THEMES = {
    "Navy & Saffron": {
        "mode": "light",
        "bg": "#F3F5FA", "card": "#FFFFFF", "border": "#DDE3EE",
        "header": "#14213D", "header_text": "#FFFFFF", "header_sub": "#FCA311",
        "primary": "#1D4E89", "primary_hover": "#163C6B",
        "accent": "#FCA311", "accent_hover": "#E08E00", "accent_text": "#14213D",
        "text": "#14213D", "muted": "#6B7280",
        "input_bg": "#F8FAFD",
        "log_bg": "#0F172A", "log_fg": "#E2E8F0",
        "ok": "#16A34A", "warn": "#D97706", "bad": "#DC2626", "info": "#2563EB",
        "report_header": "14213D",
    },
    "Teal & Coral": {
        "mode": "light",
        "bg": "#F0F7F7", "card": "#FFFFFF", "border": "#CFE5E4",
        "header": "#0F4C5C", "header_text": "#FFFFFF", "header_sub": "#FF8C69",
        "primary": "#127475", "primary_hover": "#0D5A5B",
        "accent": "#FF7F50", "accent_hover": "#E8673A", "accent_text": "#FFFFFF",
        "text": "#0F2E35", "muted": "#5F7A80",
        "input_bg": "#F7FBFB",
        "log_bg": "#0B2B33", "log_fg": "#D8F3F1",
        "ok": "#15803D", "warn": "#C2410C", "bad": "#B91C1C", "info": "#0E7490",
        "report_header": "0F4C5C",
    },
    "Forest & Gold": {
        "mode": "light",
        "bg": "#F5F6F0", "card": "#FFFFFF", "border": "#DCE3D2",
        "header": "#1B4332", "header_text": "#FFFFFF", "header_sub": "#E9C46A",
        "primary": "#2D6A4F", "primary_hover": "#1B4332",
        "accent": "#E9C46A", "accent_hover": "#D4A940", "accent_text": "#1B4332",
        "text": "#1B2D24", "muted": "#66735F",
        "input_bg": "#FAFBF7",
        "log_bg": "#10241B", "log_fg": "#E3F1E8",
        "ok": "#2D6A4F", "warn": "#B7791F", "bad": "#C0392B", "info": "#2B6CB0",
        "report_header": "1B4332",
    },
    "Midnight Purple (dark)": {
        "mode": "dark",
        "bg": "#13111C", "card": "#1E1B2E", "border": "#2E2A45",
        "header": "#0B0A12", "header_text": "#F5F3FF", "header_sub": "#A78BFA",
        "primary": "#7C3AED", "primary_hover": "#6D28D9",
        "accent": "#22D3EE", "accent_hover": "#06B6D4", "accent_text": "#0B0A12",
        "text": "#EDE9FE", "muted": "#A1A1B5",
        "input_bg": "#272339",
        "log_bg": "#0B0A12", "log_fg": "#DDD6FE",
        "ok": "#34D399", "warn": "#FBBF24", "bad": "#F87171", "info": "#60A5FA",
        "report_header": "4C1D95",
    },
}

DEFAULT_THEME = "Navy & Saffron"


def get_theme(name):
    return THEMES.get(name) or THEMES[DEFAULT_THEME]
