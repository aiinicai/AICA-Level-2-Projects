@echo off
cd /d "%~dp0"
python -c "import pandas, openpyxl, requests, playwright, customtkinter" >nul 2>&1
if errorlevel 1 (
  echo Some libraries are missing - installing them now, please wait...
  python -m pip install -r requirements.txt
  python -m playwright install chromium
)
python app.py
if errorlevel 1 pause
