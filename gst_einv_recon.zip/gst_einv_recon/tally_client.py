"""Read outward-supply vouchers (Sales / Credit Note / Debit Note) from Tally Prime.

Tally Prime must have its XML server on:
  F1 (Help) > Settings > Connectivity > Client/Server configuration
  "TallyPrime acts as" = Both (or Server), Port = 9000
and the company must be open (loaded) in Tally.
"""
import re
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

import requests

from common import to_amount, to_date, norm_gstin, norm_doc_type


class TallyError(Exception):
    pass


class TallyClient:
    def __init__(self, cfg):
        t = cfg["tally"]
        self.url = f"http://{t['host']}:{t['port']}"
        self.company = t.get("company", "")
        self.inv_field = t.get("invoice_number_field", "VOUCHERNUMBER").upper()
        self.tax_kw = {k: [w.upper() for w in v] for k, v in t["tax_ledger_keywords"].items()}
        self.roundoff_kw = [w.upper() for w in t.get("round_off_keywords", [])]
        self.tax_ledgers = None  # filled from Tally masters by load_tax_ledgers()

    # ------------------------------------------------------------------ http
    def _post(self, xml_body, timeout=120):
        try:
            r = requests.post(self.url, data=xml_body.encode("utf-8"),
                              headers={"Content-Type": "text/xml;charset=utf-8"},
                              timeout=timeout)
        except requests.ConnectionError:
            raise TallyError(
                f"Cannot reach Tally at {self.url}. Is Tally Prime open, with the "
                "company loaded and port 9000 enabled (F1 > Settings > Connectivity)?")
        raw = r.content
        for enc in ("utf-8", "utf-16"):
            try:
                text = raw.decode(enc)
                break
            except UnicodeDecodeError:
                continue
        else:
            text = raw.decode("latin-1")
        return self._clean(text)

    @staticmethod
    def _clean(text):
        # Tally emits control-char references such as &#4; that break XML parsers
        text = re.sub(r"&#(\d+);", lambda m: "" if int(m.group(1)) < 32 and int(m.group(1)) not in (9, 10, 13) else m.group(0), text)
        text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
        return text

    def _collection_request(self, coll_id, tdl_inner, static_vars=""):
        company = f"<SVCURRENTCOMPANY>{escape(self.company)}</SVCURRENTCOMPANY>" if self.company else ""
        return f"""<ENVELOPE>
 <HEADER><VERSION>1</VERSION><TALLYREQUEST>Export</TALLYREQUEST><TYPE>Collection</TYPE><ID>{coll_id}</ID></HEADER>
 <BODY><DESC>
  <STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>{company}{static_vars}</STATICVARIABLES>
  <TDL><TDLMESSAGE>{tdl_inner}</TDLMESSAGE></TDL>
 </DESC></BODY>
</ENVELOPE>"""

    # ------------------------------------------------------------ companies
    def list_companies(self):
        tdl = """<COLLECTION NAME="AppCompanyList" ISMODIFY="No"><TYPE>Company</TYPE><FETCH>NAME</FETCH></COLLECTION>"""
        xml = self._post(self._collection_request("AppCompanyList", tdl))
        root = ET.fromstring(xml)
        names = []
        for c in root.iter("COMPANY"):
            n = c.get("NAME") or (c.findtext("NAME") or "")
            if n and n not in names:
                names.append(n.strip())
        return names

    # --------------------------------------------------------- ledger GSTIN
    def ledger_gstins(self):
        """Ledger name -> GSTIN (fallback when the voucher has no PartyGSTIN)."""
        tdl = """<COLLECTION NAME="AppLedgerGSTIN" ISMODIFY="No"><TYPE>Ledger</TYPE>
                 <FETCH>NAME, PARTYGSTIN, LEDGSTREGDETAILS.LIST</FETCH></COLLECTION>"""
        xml = self._post(self._collection_request("AppLedgerGSTIN", tdl))
        return parse_ledger_gstins(xml)

    # ------------------------------------------------- ledger classification
    def load_tax_ledgers(self):
        """Build ledger -> 'igst'/'cgst'/'sgst'/'cess' using the Tally masters.

        A ledger is a GST tax ledger only if it sits under Duties & Taxes (any depth).
        Its kind comes from its GST duty head; the name is used only when the duty head is blank.
        So sales ledgers like 'IGST 18% SALE' (under Sales Accounts) are never taken as tax.
        """
        tdl_l = """<COLLECTION NAME="AppLedgerTax" ISMODIFY="No"><TYPE>Ledger</TYPE>
                   <FETCH>NAME, PARENT, GSTDUTYHEAD, TAXTYPE</FETCH></COLLECTION>"""
        tdl_g = """<COLLECTION NAME="AppGroups" ISMODIFY="No"><TYPE>Group</TYPE>
                   <FETCH>NAME, PARENT</FETCH></COLLECTION>"""
        ledgers = parse_masters(self._post(self._collection_request("AppLedgerTax", tdl_l)), "LEDGER")
        groups = parse_masters(self._post(self._collection_request("AppGroups", tdl_g)), "GROUP")
        found = classify_tax_ledgers(ledgers, groups, self.tax_kw)
        self.tax_ledgers = found or None  # nothing found -> use the name fallback instead
        return self.tax_ledgers

    # -------------------------------------------------------------- vouchers
    def outward_vouchers(self, from_date, to_date_):
        if self.tax_ledgers is None:
            try:
                self.load_tax_ledgers()
            except Exception:
                self.tax_ledgers = None  # fall back to name keywords (sales ledgers excluded)
        sv = (f"<SVFROMDATE>{from_date:%Y%m%d}</SVFROMDATE>"
              f"<SVTODATE>{to_date_:%Y%m%d}</SVTODATE>")
        tdl = """<COLLECTION NAME="AppOutwardVch" ISMODIFY="No">
   <TYPE>Voucher</TYPE>
   <FETCH>DATE, VOUCHERNUMBER, REFERENCE, VOUCHERTYPENAME, PARTYLEDGERNAME, PARTYGSTIN,
          ISCANCELLED, ISOPTIONAL, IRN, IRNACKNO, IRNACKDATE,
          ALLLEDGERENTRIES.LIST, LEDGERENTRIES.LIST</FETCH>
   <FILTER>AppIsOutward</FILTER>
 </COLLECTION>
 <SYSTEM TYPE="Formulae" NAME="AppIsOutward">($$IsSales:$VoucherTypeName OR $$IsCreditNote:$VoucherTypeName OR $$IsDebitNote:$VoucherTypeName) AND NOT $IsCancelled AND NOT $IsOptional</SYSTEM>"""
        xml = self._post(self._collection_request("AppOutwardVch", tdl, sv), timeout=600)
        rows = self.parse_vouchers(xml)
        # Date filter in Python too (Tally can ignore SVFROMDATE for custom collections)
        rows = [r for r in rows if r["inv_date"] and from_date <= r["inv_date"] <= to_date_]
        missing = [r for r in rows if not r["gstin"]]
        if missing:
            try:
                led = self.ledger_gstins()
                for r in missing:
                    r["gstin"] = led.get(r["party"].upper(), "")
            except Exception:
                pass
        return rows

    def parse_vouchers(self, xml):
        root = ET.fromstring(xml)
        out = []
        for v in root.iter("VOUCHER"):
            vtype = (v.findtext("VOUCHERTYPENAME") or v.get("VCHTYPE") or "").strip()
            inv_no = (v.findtext(self.inv_field) or v.findtext("VOUCHERNUMBER") or "").strip()
            party = (v.findtext("PARTYLEDGERNAME") or "").strip()
            # Accounting-mode vouchers use ALLLEDGERENTRIES, invoice-mode use LEDGERENTRIES.
            entries = [e for e in v.findall("ALLLEDGERENTRIES.LIST") if e.findtext("LEDGERNAME")]
            if not entries:
                entries = [e for e in v.findall("LEDGERENTRIES.LIST") if e.findtext("LEDGERNAME")]
            igst = cgst = sgst = cess = rnd = party_amt = party_raw = 0.0
            rnd_raw = 0.0
            for e in entries:
                lname = (e.findtext("LEDGERNAME") or "").strip()
                amt = to_amount(e.findtext("AMOUNT"))
                u = lname.upper()
                if party and u == party.upper():
                    party_amt += abs(amt)
                    party_raw += amt
                    continue
                kind = self.tax_kind(u)
                if kind == "igst":
                    igst += abs(amt)
                elif kind == "cgst":
                    cgst += abs(amt)
                elif kind == "sgst":
                    sgst += abs(amt)
                elif kind == "cess":
                    cess += abs(amt)
                elif any(k in u for k in self.roundoff_kw):
                    rnd_raw += amt
            # Round-off increases the invoice value when its sign is opposite to the party entry
            sign = -1.0 if party_raw < 0 else 1.0
            rnd = -rnd_raw * sign
            # Invoice value = party ledger; taxable = invoice value - taxes - round-off.
            taxable = party_amt - igst - cgst - sgst - cess - rnd
            dtype = ("CRN" if "CREDIT" in vtype.upper() else
                     "DBN" if "DEBIT" in vtype.upper() else "INV")
            out.append({
                "source": "Tally",
                "doc_type": norm_doc_type(dtype),
                "inv_no": inv_no,
                "inv_date": to_date(v.findtext("DATE")),
                "gstin": norm_gstin(v.findtext("PARTYGSTIN")),
                "party": party,
                "voucher_type": vtype,
                "inv_value": round(party_amt, 2),
                "taxable": round(taxable, 2),
                "igst": round(igst, 2), "cgst": round(cgst, 2),
                "sgst": round(sgst, 2), "cess": round(cess, 2),
                "irn": (v.findtext("IRN") or "").strip(),
                "ack_no": (v.findtext("IRNACKNO") or "").strip(),
            })
        return out

    def tax_kind(self, upper_name):
        if self.tax_ledgers is not None:
            return self.tax_ledgers.get(upper_name)  # not under Duties & Taxes -> None
        # Fallback (masters unavailable): names, but never sales/purchase/party-type ledgers
        if any(w in upper_name for w in NON_TAX_WORDS):
            return None
        return kind_from_name(upper_name, self.tax_kw)


NON_TAX_WORDS = ("SALE", "PURCHASE", "INCOME", "EXPENSE", "STOCK", "DISCOUNT", "FREIGHT")


def kind_from_name(upper_name, tax_kw):
    for kind in ("igst", "cgst", "sgst", "cess"):
        if any(k in upper_name for k in tax_kw.get(kind, [])):
            return kind
    return None


def kind_from_duty_head(duty_head):
    d = (duty_head or "").upper()
    if "INTEGRATED" in d or "IGST" in d:
        return "igst"
    if "CENTRAL" in d or "CGST" in d:
        return "cgst"
    if "STATE" in d or "SGST" in d or "UTGST" in d:
        return "sgst"
    if "CESS" in d:
        return "cess"
    return None


def parse_masters(xml, tag):
    """-> {NAME_UPPER: {'name','parent','duty_head','tax_type'}}"""
    root = ET.fromstring(xml)
    out = {}
    for m in root.iter(tag):
        name = (m.get("NAME") or m.findtext("NAME") or "").strip()
        if not name:
            continue
        out[name.upper()] = {
            "name": name,
            "parent": (m.findtext("PARENT") or "").strip(),
            "duty_head": (m.findtext("GSTDUTYHEAD") or "").strip(),
            "tax_type": (m.findtext("TAXTYPE") or "").strip(),
        }
    return out


def _belongs_to(group, target, groups):
    seen = set()
    g = (group or "").upper()
    while g and g not in seen:
        if g == target:
            return True
        seen.add(g)
        g = (groups.get(g, {}).get("parent") or "").upper()
    return False


def classify_tax_ledgers(ledgers, groups, tax_kw):
    out = {}
    for key, led in ledgers.items():
        if not _belongs_to(led["parent"], "DUTIES & TAXES", groups):
            continue
        kind = kind_from_duty_head(led["duty_head"]) or kind_from_name(key, tax_kw)
        if kind:
            out[key] = kind
    return out


def parse_ledger_gstins(xml):
    root = ET.fromstring(xml)
    out = {}
    for led in root.iter("LEDGER"):
        name = (led.get("NAME") or led.findtext("NAME") or "").strip()
        g = led.findtext("PARTYGSTIN") or ""
        if not g:
            for reg in led.iter("LEDGSTREGDETAILS.LIST"):
                g = reg.findtext("GSTIN") or ""
                if g:
                    break
        if name and g:
            out[name.upper()] = norm_gstin(g)
    return out
