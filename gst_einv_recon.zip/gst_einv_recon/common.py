"""Shared helpers: config loading, number/date parsing, invoice-number normalisation."""
import json
import re
from datetime import date, datetime
from pathlib import Path

APP_DIR = Path(__file__).resolve().parent


def load_config(path=None):
    path = Path(path) if path else APP_DIR / "config.json"
    with open(path, encoding="utf-8") as f:
        cfg = json.load(f)
    for key, folder in cfg["folders"].items():
        p = Path(folder)
        if not p.is_absolute():
            p = APP_DIR / p
        p.mkdir(parents=True, exist_ok=True)
        cfg["folders"][key] = str(p)
    return cfg


def save_config(cfg, path=None):
    path = Path(path) if path else APP_DIR / "config.json"
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)


_NUM_RE = re.compile(r"-?\d+(?:\.\d+)?")


def to_amount(value):
    """'1,18,000.00', '-1180.00 Dr', 1180 -> float (0.0 when blank)."""
    if value is None:
        return 0.0
    if isinstance(value, (int, float)):
        return 0.0 if value != value else float(value)  # NaN -> 0
    s = str(value).replace(",", "").strip()
    m = _NUM_RE.search(s)
    return float(m.group()) if m else 0.0


_DATE_FORMATS = ("%Y%m%d", "%d-%m-%Y", "%d/%m/%Y", "%d-%b-%Y", "%d-%b-%y",
                 "%Y-%m-%d", "%d.%m.%Y", "%d/%m/%y", "%d-%m-%y")


def to_date(value):
    """Parse the many date shapes Tally / GST portal produce. Returns date or None."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    if hasattr(value, "to_pydatetime"):  # pandas Timestamp
        try:
            return value.to_pydatetime().date()
        except Exception:
            return None
    s = str(value).strip().split(" ")[0]
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(s, fmt).date()
        except ValueError:
            continue
    return None


def norm_gstin(value):
    s = re.sub(r"\s", "", str(value or "")).upper()
    return s if len(s) == 15 else s  # keep as-is; validity checked elsewhere


def norm_invoice_no(value, cfg_matching=None):
    cfg_matching = cfg_matching or {}
    s = str(value or "").strip().upper()
    if s.endswith(".0") and s[:-2].isdigit():  # Excel turned 123 into 123.0
        s = s[:-2]
    s = re.sub(r"\s+", "", s)
    if cfg_matching.get("ignore_special_chars_in_invoice_no"):
        s = re.sub(r"[^A-Z0-9]", "", s)
    if cfg_matching.get("ignore_leading_zeros"):
        s = re.sub(r"(?<![0-9])0+(?=[0-9])", "", s)
    return s


def norm_doc_type(value):
    """Map anything to INV / CRN / DBN."""
    s = str(value or "").strip().upper()
    if s in ("C", "CRN", "CREDIT NOTE", "CREDIT") or "CREDIT" in s:
        return "CRN"
    if s in ("D", "DBN", "DEBIT NOTE", "DEBIT") or "DEBIT" in s:
        return "DBN"
    return "INV"
