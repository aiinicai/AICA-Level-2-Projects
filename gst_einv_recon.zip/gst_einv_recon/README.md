# GST e-Invoice ↔ Tally Prime (GSTR-1) Reconciliation

Downloads the e-invoice data from the GST portal, pulls Sales / Credit Note / Debit Note
vouchers from Tally Prime, and writes an Excel reconciliation report.

## 1. One-time setup (Windows)

1. Install Python 3.10+ from python.org (tick "Add Python to PATH").
2. Open Command Prompt in this folder and run:
   ```
   pip install -r requirements.txt
   python -m playwright install chromium
   ```
3. In **Tally Prime**: `F1 (Help) > Settings > Connectivity > Client/Server configuration`
   - TallyPrime acts as: **Both**
   - Port: **9000**
   Restart Tally and open the company you want to reconcile.

## 2. Use the app

Double-click `install.bat` once (installs all libraries), then `run.bat` to start the app. `run.bat` also installs anything missing by itself.

1. **Load companies from Tally** → pick the company.
2. Enter the period (e.g. 01-10-2026 to 31-10-2026).
3. **Download from GST portal**: a browser opens → you log in (CAPTCHA/OTP are entered by you) →
   the app opens the Returns Dashboard → choose the period → GSTR-1 → **DOWNLOAD DETAILS FROM
   E-INVOICES (EXCEL)** → **E-INVOICE DOWNLOAD HISTORY** → click the File link. The app catches the
   file and reconciles it automatically.
   *Or* download the file yourself and use **Pick downloaded file(s)…** (Excel, JSON or ZIP), then
   **Reconcile with Tally**.
4. **Open report** – saved in the `reports` folder.

Command line alternative:
```
python main.py --list-companies
python main.py --from 01-10-2026 --to 31-10-2026 --company "ABC Pvt Ltd" --download
python main.py --from 01-10-2026 --to 31-10-2026 --company "ABC Pvt Ltd" --file "C:\Users\you\Desktop\einv.xlsx"
```

## 3. What the report shows

| Status | Meaning / action |
|---|---|
| Matched | Same invoice no., GSTIN, date and amounts (within ₹1 tolerance) |
| Value mismatch | Taxable/IGST/CGST/SGST/Cess/invoice value differ – see Remarks for the differences |
| GSTIN mismatch | Party GSTIN in Tally ≠ e-invoice buyer GSTIN |
| Date mismatch | Voucher date ≠ e-invoice date |
| IRN cancelled but active in Tally | IRN cancelled on IRP but voucher still live in Tally |
| Only in Tally (e-invoice missing) | B2B voucher with no IRN – e-invoice not generated, or number differs |
| Only in e-Invoice (not in Tally) | IRN exists but voucher not booked in Tally |
| B2C / no GSTIN | No GSTIN in Tally, so not expected on IRP |

Sheets: Summary, All Documents, plus one sheet per exception type.

## 4. Settings (`config.json`)

- `tally.tax_ledger_keywords` – words used to recognise IGST/CGST/SGST/Cess ledgers (by ledger name).
- `tally.invoice_number_field` – `VOUCHERNUMBER` (default) or `REFERENCE` if your IRN invoice no. is the reference no.
- `matching.amount_tolerance` – default ₹1.
- `matching.accept_taxable_diff_if_tax_matches` – default `true`: when IGST/CGST/SGST/Cess agree, a difference
  in taxable value / invoice value (discount or round-off) is treated as **Matched**, with the difference
  shown in Remarks. Set `false` to report it as Value mismatch.
- `matching.max_taxable_diff_accepted` – `0` = no limit; e.g. `100` accepts only taxable differences up to ₹100.
- `matching.ignore_special_chars_in_invoice_no` – set `true` if e.g. `INV/001` should match `INV-001`.
- `portal.browser_channel` – `"msedge"` or `"chrome"` to use the installed browser instead of Playwright's Chromium.

## 5. Notes

- The GST portal login needs a CAPTCHA and is meant to be done by a person, so the app waits for you to log in.
  A fully unattended download is only possible through a GSP (GST Suvidha Provider) API subscription, after
  "Manage API Access" is enabled on the portal; `pipeline.run()` accepts any file list, so a GSP
  downloader can be plugged in later.
- The portal's e-invoice Excel reflects data as reported to IRP; later edits made in GSTR-1 are not in it.
- Taxable value from Tally = party ledger amount − GST ledgers − round-off, so it works for both
  item-invoice and accounting-invoice vouchers.
