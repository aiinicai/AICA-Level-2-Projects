"""Read e-invoice data downloaded from the GST portal / IRP.

Supported inputs
  * Excel from GSTR-1 dashboard -> "Download details from e-Invoices (Excel)"
    (sheets like b2b / cdnr / exp; one row per tax rate - rows are summed per invoice)
  * Excel/CSV from the e-invoice portal (einvoice.gst.gov.in) download
  * GSTR-1 JSON (b2b / cdnr / exp sections)
  * IRP e-invoice JSON (DocDtls / BuyerDtls / ValDtls schema)
  * .zip containing any of the above
Column names are matched loosely, so small header changes on the portal don't break it.
"""
import json
import re
import zipfile
from pathlib import Path

import pandas as pd

from common import to_amount, to_date, norm_gstin, norm_doc_type

ALIASES = {
    "gstin": ["gstin/uin of recipient", "gstin of recipient", "recipient gstin", "buyer gstin",
              "gstin/uin of buyer", "ctin", "gstin of buyer", "gstin/uin"],
    "party": ["receiver name", "recipient name", "buyer name", "trade/legal name", "legal name of buyer",
              "trade name"],
    "inv_no": ["invoice number", "invoice no", "invoice no.", "note number", "note no",
               "document number", "doc no", "document no", "note/refund voucher number", "doc. no"],
    "inv_date": ["invoice date", "note date", "document date", "doc date", "doc. date",
                 "note/refund voucher date"],
    "inv_value": ["invoice value", "note value", "total invoice value", "document value",
                  "note/refund voucher value", "total value"],
    "taxable": ["taxable value", "taxable amount", "assessable value"],
    "igst": ["integrated tax", "integrated tax amount", "igst", "igst amount"],
    "cgst": ["central tax", "central tax amount", "cgst", "cgst amount"],
    "sgst": ["state/ut tax", "state/ut tax amount", "state tax", "sgst", "sgst/utgst", "sgst amount"],
    "cess": ["cess", "cess amount"],
    "irn": ["irn"],
    "irn_date": ["irn date", "ack date", "acknowledgement date"],
    "ack_no": ["ack no", "ack no.", "acknowledgement number", "ack number"],
    "status": ["e-invoice status", "irn status", "status"],
    "doc_type": ["note type", "document type", "doc type", "type of note", "note type (credit/debit)"],
}


def _key(s):
    return re.sub(r"[^a-z0-9]", "", str(s).lower())


ALIAS_KEYS = {f: {_key(a) for a in al} for f, al in ALIASES.items()}


def _map_columns(columns):
    mapping = {}
    for col in columns:
        k = _key(col)
        for field, keys in ALIAS_KEYS.items():
            if field in mapping.values():
                continue
            if k in keys:
                mapping[col] = field
                break
    return mapping


def _find_header_row(raw):
    """Portal sheets have title rows above the header; find the row that has an invoice-no column."""
    inv_keys = ALIAS_KEYS["inv_no"]
    for i in range(min(15, len(raw))):
        vals = {_key(v) for v in raw.iloc[i].tolist() if pd.notna(v)}
        if vals & inv_keys:
            return i
    return None


def _rows_from_frame(df, sheet_name=""):
    mapping = _map_columns(df.columns)
    if "inv_no" not in mapping.values():
        return []
    df = df.rename(columns=mapping)
    sheet_type = norm_doc_type("CRN" if "cdn" in sheet_name.lower() and "doc_type" not in df.columns else "")
    rows = []
    for _, r in df.iterrows():
        inv = r.get("inv_no")
        if pd.isna(inv) or str(inv).strip() == "" or _key(inv) in ALIAS_KEYS["inv_no"]:
            continue
        rows.append({
            "doc_type": norm_doc_type(r.get("doc_type")) if "doc_type" in df.columns else sheet_type,
            "inv_no": str(inv).strip(),
            "inv_date": to_date(r.get("inv_date")),
            "gstin": norm_gstin(r.get("gstin")) if pd.notna(r.get("gstin")) else "",
            "party": "" if pd.isna(r.get("party")) else str(r.get("party", "")).strip(),
            "inv_value": to_amount(r.get("inv_value")),
            "taxable": to_amount(r.get("taxable")),
            "igst": to_amount(r.get("igst")), "cgst": to_amount(r.get("cgst")),
            "sgst": to_amount(r.get("sgst")), "cess": to_amount(r.get("cess")),
            "irn": "" if pd.isna(r.get("irn")) else str(r.get("irn", "")).strip(),
            "ack_no": "" if pd.isna(r.get("ack_no")) else str(r.get("ack_no", "")).strip(),
            "status": "" if pd.isna(r.get("status")) else str(r.get("status", "")).strip(),
            "sheet": sheet_name,
        })
    return rows


def read_excel(path):
    rows = []
    sheets = pd.read_excel(path, sheet_name=None, header=None, dtype=object)
    for name, raw in sheets.items():
        if raw.empty:
            continue
        h = _find_header_row(raw)
        if h is None:
            continue
        df = raw.iloc[h + 1:].copy()
        df.columns = [str(c).strip() for c in raw.iloc[h].tolist()]
        rows += _rows_from_frame(df, name)
    return rows


def read_csv(path):
    raw = pd.read_csv(path, header=None, dtype=object)
    h = _find_header_row(raw) or 0
    df = raw.iloc[h + 1:].copy()
    df.columns = [str(c).strip() for c in raw.iloc[h].tolist()]
    return _rows_from_frame(df, Path(path).stem)


def read_json(path):
    with open(path, encoding="utf-8-sig") as f:
        data = json.load(f)
    rows = []
    # ---- GSTR-1 JSON
    if isinstance(data, dict) and any(k in data for k in ("b2b", "cdnr", "exp")):
        for party in data.get("b2b", []):
            for inv in party.get("inv", []):
                rows.append(_gstr1_inv(inv, party.get("ctin", ""), "INV", inv.get("inum"), inv.get("idt")))
        for party in data.get("cdnr", []):
            for nt in party.get("nt", []):
                rows.append(_gstr1_inv(nt, party.get("ctin", ""), nt.get("ntty"), nt.get("nt_num"), nt.get("nt_dt")))
        for grp in data.get("exp", []):
            for inv in grp.get("inv", []):
                rows.append(_gstr1_inv(inv, "", "INV", inv.get("inum"), inv.get("idt")))
        return rows
    # ---- IRP e-invoice JSON (single, list, or wrapped)
    docs = data
    if isinstance(data, dict):
        docs = data.get("data") or data.get("Data") or data.get("einvoices") or [data]
    if isinstance(docs, dict):
        docs = [docs]
    for d in docs:
        if isinstance(d, str):
            try:
                d = json.loads(d)
            except Exception:
                continue
        doc = d.get("DocDtls", {})
        buyer = d.get("BuyerDtls", {})
        val = d.get("ValDtls", {})
        rows.append({
            "doc_type": norm_doc_type(doc.get("Typ")),
            "inv_no": str(doc.get("No", "")).strip(),
            "inv_date": to_date(doc.get("Dt")),
            "gstin": norm_gstin(buyer.get("Gstin", "")),
            "party": buyer.get("LglNm", ""),
            "inv_value": to_amount(val.get("TotInvVal")),
            "taxable": to_amount(val.get("AssVal")),
            "igst": to_amount(val.get("IgstVal")), "cgst": to_amount(val.get("CgstVal")),
            "sgst": to_amount(val.get("SgstVal")),
            "cess": to_amount(val.get("CesVal")) + to_amount(val.get("StCesVal")),
            "irn": d.get("Irn", ""), "ack_no": str(d.get("AckNo", "")),
            "status": d.get("Status", ""), "sheet": "json",
        })
    return rows


def _gstr1_inv(inv, ctin, dtype, num, dt):
    tx = ig = cg = sg = cs = 0.0
    for itm in inv.get("itms", []):
        det = itm.get("itm_det", itm)
        tx += to_amount(det.get("txval")); ig += to_amount(det.get("iamt"))
        cg += to_amount(det.get("camt")); sg += to_amount(det.get("samt")); cs += to_amount(det.get("csamt"))
    return {"doc_type": norm_doc_type(dtype), "inv_no": str(num or "").strip(), "inv_date": to_date(dt),
            "gstin": norm_gstin(ctin), "party": "", "inv_value": to_amount(inv.get("val")),
            "taxable": tx, "igst": ig, "cgst": cg, "sgst": sg, "cess": cs,
            "irn": inv.get("irn", ""), "ack_no": "", "status": inv.get("srctyp", ""), "sheet": "gstr1-json"}


def read_any(path, _extract_dir=None):
    path = Path(path)
    suf = path.suffix.lower()
    if suf == ".zip":
        out = []
        dest = Path(_extract_dir or path.with_suffix(""))
        dest.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(path) as z:
            for member in z.namelist():
                if member.endswith("/") or ".." in member:
                    continue
                target = dest / Path(member).name
                with z.open(member) as src, open(target, "wb") as dst:
                    dst.write(src.read())
                if target.suffix.lower() in (".xlsx", ".xls", ".json", ".csv"):
                    out += read_any(target)
        return out
    if suf in (".xlsx", ".xlsm", ".xls"):
        return read_excel(path)
    if suf == ".csv":
        return read_csv(path)
    if suf == ".json":
        return read_json(path)
    raise ValueError(f"Unsupported file type: {path.name}")


def read_files(paths):
    """Read several files and collapse rate-wise rows into one row per document."""
    rows = []
    for p in paths:
        for r in read_any(p):
            r["file"] = Path(p).name
            rows.append(r)
    return aggregate(rows)


def aggregate(rows):
    agg = {}
    for r in rows:
        k = (r["doc_type"], r["inv_no"].upper(), r["gstin"])
        if k not in agg:
            agg[k] = dict(r, source="e-Invoice")
            continue
        a = agg[k]
        for f in ("taxable", "igst", "cgst", "sgst", "cess"):
            a[f] += r[f]
        a["inv_value"] = max(a["inv_value"], r["inv_value"])  # invoice value repeats on each rate row
        for f in ("irn", "ack_no", "status", "party"):
            a[f] = a[f] or r[f]
        if not a["inv_date"]:
            a["inv_date"] = r["inv_date"]
    for a in agg.values():
        for f in ("inv_value", "taxable", "igst", "cgst", "sgst", "cess"):
            a[f] = round(a[f], 2)
    return list(agg.values())
