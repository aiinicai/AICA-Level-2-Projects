"""Write the reconciliation workbook."""
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter

from reconcile import STATUS_ORDER, summary

FILL = {
    "Matched": "C6EFCE",
    "Value mismatch": "FFEB9C",
    "GSTIN mismatch": "FFC7CE",
    "Date mismatch": "FFEB9C",
    "IRN cancelled but active in Tally": "FFC7CE",
    "Only in Tally (e-invoice missing)": "FFC7CE",
    "Only in e-Invoice (not in Tally)": "FFC7CE",
    "B2C / no GSTIN in Tally (not on IRP)": "EDEDED",
}
HEAD_FILL = PatternFill("solid", fgColor="1F4E78")
HEAD_FONT = Font(bold=True, color="FFFFFF")
THIN = Side(style="thin", color="BFBFBF")


def write_report(results, out_dir, company, period_from, period_to, header_color=None):
    global HEAD_FILL
    if header_color:
        HEAD_FILL = PatternFill("solid", fgColor=header_color)
    wb = Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws["A1"] = "e-Invoice vs Tally (GSTR-1) Reconciliation"
    ws["A1"].font = Font(bold=True, size=14)
    ws["A2"] = f"Company: {company or '(active company in Tally)'}"
    ws["A3"] = f"Period: {period_from:%d-%m-%Y} to {period_to:%d-%m-%Y}    Generated: {datetime.now():%d-%m-%Y %H:%M}"
    summ = summary(results)
    _table(ws, summ, start_row=5)
    r = 5 + len(summ) + 1
    ws.cell(r, 1, "Total").font = Font(bold=True)
    for c in range(2, 7):
        col = get_column_letter(c)
        ws.cell(r, c, f"=SUM({col}6:{col}{r - 1})").font = Font(bold=True)
        ws.cell(r, c).number_format = "#,##0.00" if c > 2 else "0"
    for i, row in enumerate(summ, start=6):
        ws.cell(i, 1).fill = PatternFill("solid", fgColor=FILL[row["Status"]])

    ws_all = wb.create_sheet("All Documents")
    _table(ws_all, results, start_row=1, color_status=True)

    for status in STATUS_ORDER:
        rows = [x for x in results if x["Status"] == status]
        if rows and status != "Matched":
            name = "".join(ch for ch in status.split(" (")[0] if ch not in '/\\?*[]:')
            name = " ".join(name.split())[:30]
            _table(wb.create_sheet(name), rows, start_row=1, color_status=True)

    out = Path(out_dir) / f"EInvoice_Recon_{_safe(company)}_{period_from:%Y%m%d}_{period_to:%Y%m%d}.xlsx"
    wb.save(out)
    return out


def _safe(s):
    return "".join(ch for ch in (s or "Tally") if ch.isalnum() or ch in "-_")[:40] or "Tally"


def _table(ws, rows, start_row, color_status=False):
    if not rows:
        ws.cell(start_row, 1, "No records")
        return
    headers = list(rows[0].keys())
    for c, h in enumerate(headers, 1):
        cell = ws.cell(start_row, c, h)
        cell.fill, cell.font = HEAD_FILL, HEAD_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    for i, row in enumerate(rows, start_row + 1):
        for c, h in enumerate(headers, 1):
            v = row[h]
            cell = ws.cell(i, c, v)
            cell.border = Border(bottom=THIN)
            if isinstance(v, float):
                cell.number_format = "#,##0.00"
            elif hasattr(v, "year"):
                cell.number_format = "DD-MM-YYYY"
            if h.endswith("Diff") and isinstance(v, (int, float)) and abs(v) > 1:
                cell.font = Font(color="C00000", bold=True)
        if color_status:
            ws.cell(i, 1).fill = PatternFill("solid", fgColor=FILL.get(row["Status"], "FFFFFF"))
    for c, h in enumerate(headers, 1):
        width = max([len(str(h))] + [len(str(r[h])) for r in rows[:500] if r[h] is not None]) + 2
        ws.column_dimensions[get_column_letter(c)].width = min(max(width, 10), 45)
    ws.freeze_panes = ws.cell(start_row + 1, 2)
    ws.auto_filter.ref = f"A{start_row}:{get_column_letter(len(headers))}{start_row + len(rows)}"
