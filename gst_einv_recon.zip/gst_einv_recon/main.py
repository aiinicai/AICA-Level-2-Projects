"""Command-line entry point.

Examples
  python main.py --from 01-10-2026 --to 31-10-2026 --download
  python main.py --from 01-10-2026 --to 31-10-2026 --file "C:/Users/me/Desktop/einv_oct.xlsx" --company "ABC Pvt Ltd"
  python main.py --list-companies
"""
import argparse
import sys

from common import load_config, to_date
from tally_client import TallyClient, TallyError


def main():
    ap = argparse.ArgumentParser(description="e-Invoice vs Tally Prime GSTR-1 reconciliation")
    ap.add_argument("--from", dest="from_date", help="DD-MM-YYYY")
    ap.add_argument("--to", dest="to_date", help="DD-MM-YYYY")
    ap.add_argument("--file", action="append", default=[], help="e-invoice Excel/JSON/ZIP (repeatable)")
    ap.add_argument("--download", action="store_true", help="open GST portal and capture the download")
    ap.add_argument("--company", help="Tally company name (must be open in Tally)")
    ap.add_argument("--config", help="path to config.json")
    ap.add_argument("--list-companies", action="store_true")
    a = ap.parse_args()

    cfg = load_config(a.config)
    if a.company:
        cfg["tally"]["company"] = a.company

    try:
        if a.list_companies:
            for c in TallyClient(cfg).list_companies():
                print(c)
            return
        f, t = to_date(a.from_date), to_date(a.to_date)
        if not f or not t:
            ap.error("--from and --to are required (DD-MM-YYYY)")
        from pipeline import run
        run(cfg, f, t, a.file, download=a.download)
    except TallyError as e:
        print(f"ERROR: {e}")
        sys.exit(2)


if __name__ == "__main__":
    main()
