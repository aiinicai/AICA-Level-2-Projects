"""End-to-end run: (download) -> read e-invoices -> pull Tally -> reconcile -> Excel report."""
from pathlib import Path

from einvoice_reader import read_files
from reconcile import reconcile
from report import write_report
from tally_client import TallyClient


def run(cfg, from_date, to_date, einvoice_files=None, download=False, log=print):
    files = list(einvoice_files or [])
    if download:
        from gst_downloader import download_einvoices
        files += [str(p) for p in download_einvoices(cfg, log=log)]
    if not files:
        raise ValueError("No e-invoice file given. Download from the portal or pick a file.")

    log(f"Reading e-invoice file(s): {', '.join(Path(f).name for f in files)}")
    einv = read_files(files)
    einv = [e for e in einv if not e["inv_date"] or from_date <= e["inv_date"] <= to_date]
    log(f"  {len(einv)} e-invoice documents in period")
    if not einv:
        log("  WARNING: no documents read - check the file is the e-invoice Excel/JSON.")

    log(f"Fetching sales / credit / debit notes from Tally ({cfg['tally']['host']}:{cfg['tally']['port']})...")
    tally = TallyClient(cfg).outward_vouchers(from_date, to_date)
    log(f"  {len(tally)} vouchers in Tally")

    results = reconcile(tally, einv, cfg["matching"])
    from themes import get_theme
    out = write_report(results, cfg["folders"]["reports"], cfg["tally"].get("company"), from_date, to_date,
                       header_color=get_theme(cfg.get("ui_theme"))["report_header"])
    counts = {}
    for r in results:
        counts[r["Status"]] = counts.get(r["Status"], 0) + 1
    for k, v in counts.items():
        log(f"  {k}: {v}")
    log(f"Report saved: {out}")
    return out, results
