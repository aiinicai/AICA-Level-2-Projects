import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import DocumentEditor from './components/DocumentEditor';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Routes>
        <Route path="/" element={<DocumentEditor />} />
        <Route path="/editor" element={<Navigate to="/" replace />} />
      </Routes>
    </HashRouter>
  );
};

export default App;