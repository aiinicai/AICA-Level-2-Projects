
import React, { useState, useRef, useEffect } from 'react';
import { 
  PlusCircle, FileText, Library, MessageSquare, Chrome, Gift, Video, 
  HelpCircle, Command, Monitor, Moon, Languages, Settings, Clock, 
  Download, Zap, Image as ImageIcon, Table, Sigma, Undo, Redo, ChevronDown, 
  AlignLeft, Bold, Italic, Sparkles, Check, Search, MoreHorizontal, Trash2,
  ArrowLeft, Edit2, FolderOpen, ArrowRight, ThumbsUp, ThumbsDown, Copy,
  Quote, Bookmark, Filter, BookOpen, Lock, File, X, ChevronUp, Code, AtSign,
  List, ListOrdered, Heading1, Heading2, Heading3, Maximize, BarChart2, Loader2,
  ExternalLink, ArrowRightLeft, PenLine, FileJson, FileType, FileCode, SlidersHorizontal,
  ChevronLeft, ChevronRight, Plus, Underline, Strikethrough, Link as LinkIcon
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { GoogleGenAI, Type } from "@google/genai";
import ChatPanel from './ChatPanel';
import html2pdf from 'html2pdf.js';

// Declare KaTeX, Prism, and html2pdf globally
declare global {
    interface Window {
        katex: any;
        Prism: any;
        html2pdf: any;
    }
}

const TRANSLATIONS = {
  en: {
    think: "CA Legal Forms Assistant",
    new: "New Opinion / Draft",
    documents: "Opinions & Drafts",
    library: "Statutory Library",
    aiChat: "Legal Copilot",
    completeSetup: "CA Workspace Setup",
    steps: "0/5 Steps",
    webExtension: "Tax Bar Plugin",
    help: "CA Helpdesk",
    search: "Search acts, sections, precedents...",
    back: "Back",
    untitled: "Untitled Legal Draft",
    seePricing: "CA Firm Plans",
    export: "Export Draft",
    publish: "Finalize & Sign",
    words: "words",
    autocomplete: "Legal Autocomplete",
    accept: "Accept (Tab)",
    tryAgain: "Alternative Phrasing",
    chatGreeting: "Greetings, CA Colleague!",
    chatIntro: "I am CA Legal Forms Assistant, your statutory and legal intelligence assistant for Chartered Accountants. Ask me to research sections, compare precedents, verify CARO 2020 clauses, or draft notice replies.",
    chatPlaceholder: "Ask legal questions, query Income Tax Act, GST, or ITAT case laws...",
    web: "Web Acts",
    promptHistory: "Legal Query History",
    recentPrompts: "RECENT STATUTORY QUERIES",
    sources: "STATUTORY SOURCES & CITATIONS",
    jenniThinking: "CA Legal Forms Assistant is consulting statutory databases...",
    newDoc: "New Legal Draft",
    noDocs: "No drafts found",
    delete: "Delete Draft",
    rename: "Rename Draft",
    cite: "Cite Section / Ruling",
    text: "Format Text",
    searchCitations: "Search Income Tax, GST Acts, ITAT, High Court & SC Precedents...",
    saved: "Draft saved securely",
    saving: "Saving draft..."
  },
  es: {
    think: "CA Legal Forms Assistant",
    new: "Nuevo Borrador Legal",
    documents: "Dictámenes y Leyes",
    library: "Biblioteca Estatutaria",
    aiChat: "Copiloto Legal",
    completeSetup: "Configuración",
    steps: "0/5 Pasos",
    webExtension: "Extensión",
    help: "Ayuda",
    search: "Buscar leyes y fallos...",
    back: "Atrás",
    untitled: "Borrador Legal",
    seePricing: "Planes CA",
    export: "Exportar",
    publish: "Finalizar",
    words: "palabras",
    autocomplete: "Autocompletar Legal",
    accept: "Aceptar",
    tryAgain: "Reintentar",
    chatGreeting: "¡Saludos, Colega CA!",
    chatIntro: "Soy CA Legal Forms Assistant, asistente legal e impositivo para Contadores Públicos.",
    chatPlaceholder: "Consultar leyes tributarias o precedentes...",
    web: "Web",
    promptHistory: "Historial",
    recentPrompts: "RECIENTES",
    sources: "FUENTES",
    jenniThinking: "Consultando bases de datos legales...",
    newDoc: "Nuevo Doc",
    noDocs: "No hay documentos",
    delete: "Eliminar",
    rename: "Renombrar",
    cite: "Citar Ley",
    text: "Texto",
    searchCitations: "Buscar jurisprudencia y artículos...",
    saved: "Borrador guardado",
    saving: "Guardando..."
  },
  fr: {
    think: "CA Legal Forms Assistant",
    new: "Nouveau Projet Juridique",
    documents: "Avis & Actes",
    library: "Bibliothèque Légale",
    aiChat: "Copilote Légal",
    completeSetup: "Configuration",
    steps: "0/5 Étapes",
    webExtension: "Extension",
    help: "Aide",
    search: "Rechercher textes de lois...",
    back: "Retour",
    untitled: "Projet sans titre",
    seePricing: "Tarifs Cabinets",
    export: "Exporter",
    publish: "Signer & Valider",
    words: "mots",
    autocomplete: "Autocomplétion Légale",
    accept: "Accepter",
    tryAgain: "Réessayer",
    chatGreeting: "Bonjour, Confrère Expert-Comptable!",
    chatIntro: "Je suis CA Legal Forms Assistant, votre copilote juridique et fiscal.",
    chatPlaceholder: "Poser une question juridique ou fiscale...",
    web: "Web",
    promptHistory: "Historique",
    recentPrompts: "RÉCENTS",
    sources: "SOURCES",
    jenniThinking: "Recherche dans les bases légales...",
    newDoc: "Nouveau Doc",
    noDocs: "Aucun document",
    delete: "Supprimer",
    rename: "Renommer",
    cite: "Citer Jurisprudence",
    text: "Texte",
    searchCitations: "Rechercher jurisprudences et lois...",
    saved: "Brouillon enregistré",
    saving: "Enregistrement..."
  },
  de: {
    think: "CA Legal Forms Assistant",
    new: "Neuer Rechtsentwurf",
    documents: "Gutachten & Schriftsätze",
    library: "Gesetzesbibliothek",
    aiChat: "Rechts-Copilot",
    completeSetup: "Einrichtung",
    steps: "0/5 Schritte",
    webExtension: "Erweiterung",
    help: "Hilfe",
    search: "Gesetze und Urteile suchen...",
    back: "Zurück",
    untitled: "Rechtsentwurf",
    seePricing: "Kanzleitarife",
    export: "Exportieren",
    publish: "Freigeben",
    words: "Wörter",
    autocomplete: "Rechts-Vervollständigung",
    accept: "Akzeptieren",
    tryAgain: "Erneut versuchen",
    chatGreeting: "Guten Tag, Herr/Frau Wirtschaftsprüfer!",
    chatIntro: "Ich bin CA Legal Forms Assistant, Ihr Assistent für Steuer- und Wirtschaftsrecht.",
    chatPlaceholder: "Rechtliche Fragen oder Urteile anfragen...",
    web: "Web",
    promptHistory: "Verlauf",
    recentPrompts: "LETZTE",
    sources: "QUELLEN",
    jenniThinking: "Prüfe Rechtsdatenbanken...",
    newDoc: "Neues Dok",
    noDocs: "Keine Dokumente",
    delete: "Löschen",
    rename: "Umbenennen",
    cite: "Urteil zitieren",
    text: "Text",
    searchCitations: "Gesetze und Urteile durchsuchen...",
    saved: "Entwurf gespeichert",
    saving: "Speichern..."
  }
};

const CODE_LANGUAGES = [
    'Plaintext', 'Assembly', 'Arduino', 'Bash', 'C', 'Clojure', 'Cpp', 'Csharp', 'Css', 'Dart', 'Diff', 'Docker', 
    'Elixir', 'Elm', 'Erlang', 'F#', 'Fortran', 'Go', 'GraphQL', 'Groovy', 'Haskell', 'HTML', 'Java', 
    'Javascript', 'Json', 'Julia', 'Kotlin', 'Latex', 'Less', 'Lisp', 'Lua', 'Make', 'Markdown', 'Matlab', 
    'Objectivec', 'OCaml', 'Pascal', 'Perl', 'Php', 'PowerShell', 'Prolog', 'Python', 'R', 'Ruby', 'Rust', 
    'Scala', 'Scss', 'Shell', 'Solidity', 'Sql', 'Swift', 'TOML', 'Typescript', 'VB.NET', 'Visual Basic', 
    'Vue', 'Xml', 'Yaml'
].sort();

const PRISM_LANGUAGE_MAP: Record<string, string> = {
    'Plaintext': 'none',
    'Assembly': 'nasm',
    'Arduino': 'arduino',
    'Bash': 'bash',
    'C': 'c',
    'Clojure': 'clojure',
    'Cpp': 'cpp',
    'Csharp': 'csharp',
    'Css': 'css',
    'Dart': 'dart',
    'Diff': 'diff',
    'Docker': 'docker',
    'Elixir': 'elixir',
    'Elm': 'elm',
    'Erlang': 'erlang',
    'F#': 'fsharp',
    'Fortran': 'fortran',
    'Go': 'go',
    'GraphQL': 'graphql',
    'Groovy': 'groovy',
    'Haskell': 'haskell',
    'HTML': 'html',
    'Java': 'java',
    'Javascript': 'javascript',
    'Json': 'json',
    'Julia': 'julia',
    'Kotlin': 'kotlin',
    'Latex': 'latex',
    'Less': 'less',
    'Lisp': 'lisp',
    'Lua': 'lua',
    'Make': 'makefile',
    'Markdown': 'markdown',
    'Matlab': 'matlab',
    'Objectivec': 'objectivec',
    'OCaml': 'ocaml',
    'Pascal': 'pascal',
    'Perl': 'perl',
    'Php': 'php',
    'PowerShell': 'powershell',
    'Prolog': 'prolog',
    'Python': 'python',
    'R': 'r',
    'Ruby': 'ruby',
    'Rust': 'rust',
    'Scala': 'scala',
    'Scss': 'scss',
    'Shell': 'bash',
    'Solidity': 'solidity',
    'Sql': 'sql',
    'Swift': 'swift',
    'TOML': 'toml',
    'Typescript': 'typescript',
    'VB.NET': 'vbnet',
    'Visual Basic': 'visual-basic',
    'Vue': 'javascript',
    'Xml': 'xml',
    'Yaml': 'yaml'
};

  const generateFallbackCitations = (query: string, year?: number | null, category?: string) => {
    const baseYear = year || new Date().getFullYear() - 1;
    const allLaws = [
        {
            id: `cit-sec43b-${Date.now()}-1`,
            title: `Section 43B(h) & MSMED Act Section 15: Disallowance Analysis on Timely Payments`,
            authors: "CBDT & Ministry of MSME",
            journal: "Income Tax Act, 1961 - Clause (h) inserted by Finance Act 2023",
            year: "2024",
            snippet: `Mandatory disallowance for delayed payments beyond 45 days (with agreement) or 15 days (without agreement) to Micro and Small Enterprises. Proviso for payment before ITR filing u/s 139(1) does NOT apply.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Statutory Clause: Section 43B(h) of Income-tax Act, 1961:</strong><br>Any sum payable by the assessee to a Micro or Small Enterprise beyond the time limit specified in Section 15 of the Micro, Small and Medium Enterprises Development Act, 2006 (27 of 2006) shall be allowed as a deduction only in the previous year in which such sum is actually paid.</blockquote>`,
            citedBy: "14,200 CAs",
            isOpenAccess: true,
            type: "Statute",
            category: "Income Tax"
        },
        {
            id: `cit-sec148a-${Date.now()}-2`,
            title: `Section 148A & 148: Procedure & Sanctions for Reassessment Proceedings`,
            authors: "Income Tax Department / CBDT",
            journal: "Income Tax Act, 1961 (New Reassessment Regime)",
            year: "2024",
            snippet: `Assessing officer must conduct inquiry u/s 148A(a), provide show cause notice with insight material u/s 148A(b), and obtain prior sanction of Specified Authority under Section 151 before issuing reassessment notice.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Statutory Clause: Section 148A(b) of Income-tax Act, 1961:</strong><br>The Assessing Officer shall, before issuing any notice under Section 148, provide an opportunity of being heard to the assessee by serving a show cause notice along with the material relied upon, with a minimum notice period of 7 to 30 days.</blockquote>`,
            citedBy: "18,400 CAs",
            isOpenAccess: true,
            type: "Statute",
            category: "Income Tax"
        },
        {
            id: `cit-checkmate-${Date.now()}-3`,
            title: `Checkmate Services P. Ltd. v. CIT [2022] 448 ITR 518 (SC)`,
            authors: "Supreme Court of India (3-Judge Bench)",
            journal: "Supreme Court Reports / 448 ITR 518 (SC)",
            year: "2022",
            snippet: `Landmark ruling holding that employees' contribution towards PF/ESI u/s 36(1)(va) must be deposited strictly within the due date under respective labor welfare Acts. Non-deposit results in permanent disallowance; Section 43B relaxation cannot be availed.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Judicial Ratio: Checkmate Services P. Ltd. v. CIT [2022] 448 ITR 518 (SC):</strong><br>"The non-obstante clause under Section 43B cannot apply to employee contributions covered under Section 36(1)(va) read with Section 2(24)(x). Delayed deposit past the statutory due date under EPF/ESI laws is ineligible for deduction."</blockquote>`,
            citedBy: "38,900 CAs",
            isOpenAccess: true,
            type: "Case Law",
            category: "Case Laws"
        },
        {
            id: `cit-kelvinator-${Date.now()}-4`,
            title: `CIT v. Kelvinator of India Ltd [2010] 320 ITR 561 (SC)`,
            authors: "Supreme Court of India (Full Constitutional Bench)",
            journal: "Supreme Court Reports / 320 ITR 561",
            year: "2010",
            snippet: `Reassessment cannot be initiated on a mere 'change of opinion'. The Assessing Officer must possess tangible fresh material having a live link to escaped income.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Judicial Ratio: CIT v. Kelvinator of India Ltd [2010] 320 ITR 561 (SC):</strong><br>"One must treat the concept of 'change of opinion' as an in-built test to check abuse of power. Hence, after 1st April 1989, the Assessing Officer has power to reopen, provided there is tangible material to come to the conclusion that there is escapement of income."</blockquote>`,
            citedBy: "52,100 CAs",
            isOpenAccess: true,
            type: "Case Law",
            category: "Case Laws"
        },
        {
            id: `cit-rajivbansal-${Date.now()}-5`,
            title: `Union of India v. Rajiv Bansal & Ors. [2024] INSC (SC)`,
            authors: "Supreme Court of India",
            journal: "Supreme Court Tax Reporter 2024",
            year: "2024",
            snippet: `Definitive ruling harmonizing TOLA (Taxation and Other Laws Relaxation Act) extension provisions with Section 149 limitation thresholds for reassessments issued between April 1, 2021 and June 30, 2021.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Judicial Ratio: Union of India v. Rajiv Bansal [2024] INSC:</strong><br>"Notices issued under the old regime deemed to be show-cause notices u/s 148A(b) must strictly satisfy the 3-year or 10-year limitation tests under amended Section 149 read with Section 151 specified authority approvals."</blockquote>`,
            citedBy: "24,500 CAs",
            isOpenAccess: true,
            type: "Case Law",
            category: "Case Laws"
        },
        {
            id: `cit-gst16-${Date.now()}-6`,
            title: `Section 16(2)(aa) & Rule 36(4): ITC Eligibility & GSTR-2B Reconciliation`,
            authors: "Central Board of Indirect Taxes & Customs (CBIC)",
            journal: "Central Goods & Services Tax Act, 2017",
            year: "2023",
            snippet: `Input Tax Credit can only be claimed if invoice details are reflected in Form GSTR-2B generated pursuant to supplier filing in GSTR-1. Mismatch beyond 2B results in statutory demand with interest u/s 50.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Statutory Clause: Section 16(2)(aa) of CGST Act, 2017:</strong><br>No registered person shall be entitled to the credit of any input tax unless the details of the invoice or debit note has been furnished by the supplier in the statement of outward supplies and communicated to the recipient in the manner specified under Section 37.</blockquote>`,
            citedBy: "31,000 CAs",
            isOpenAccess: true,
            type: "Statute",
            category: "GST"
        },
        {
            id: `cit-gst175-${Date.now()}-7`,
            title: `Section 17(5): Apportionment of Credit & Blocked ITC Ineligibility`,
            authors: "CBIC / GST Council",
            journal: "Central Goods & Services Tax Act, 2017",
            year: "2023",
            snippet: `Statutory list of blocked input tax credits including motor vehicles for passenger transport, food and beverages, outdoor catering, employee insurance, works contract for immovable property construction, and CSR goods.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Statutory Clause: Section 17(5) of CGST Act, 2017:</strong><br>Notwithstanding anything contained in sub-section (1) of section 16 and subsection (1) of section 18, input tax credit shall not be available in respect of goods or services or both used for personal consumption, lost, stolen, destroyed, written off, or disposed of by way of gift or free samples.</blockquote>`,
            citedBy: "27,300 CAs",
            isOpenAccess: true,
            type: "Statute",
            category: "GST"
        },
        {
            id: `cit-caro2020-${Date.now()}-8`,
            title: `CARO 2020 Clause (ii)(b): Working Capital Limits against Current Assets`,
            authors: "Ministry of Corporate Affairs (MCA) & ICAI AASB",
            journal: "Companies (Auditor's Report) Order, 2020",
            year: "2024",
            snippet: `Auditors must verify if quarterly statements/stock returns filed with banks for working capital limits exceeding ₹5 Crores agree with the books of account. Differences must be quantified and reported under SA 700.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Audit Requirement: CARO 2020 Clause (ii)(b):</strong><br>"Whether during any point of time of the year, the company has been sanctioned working capital limits in excess of five crore rupees, in aggregate, from banks or financial institutions on the basis of security of current assets; whether the quarterly returns or statements filed by the company are in agreement with the books of account of the Company."</blockquote>`,
            citedBy: "19,800 CAs",
            isOpenAccess: true,
            type: "Audit Standard",
            category: "Corporate & CARO"
        },
        {
            id: `cit-sa700-${Date.now()}-9`,
            title: `ICAI SA 700 (Revised): Forming an Opinion and Reporting on Financial Statements`,
            authors: "Auditing and Assurance Standards Board, ICAI",
            journal: "ICAI Compendium of Standards on Auditing",
            year: "2024",
            snippet: `Mandatory standard governing unmodified and modified auditor opinions, Emphasis of Matter paragraphs, Key Audit Matters (SA 701), and going concern disclosures under SA 570.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Auditing Standard: ICAI SA 700 (Revised):</strong><br>"The auditor shall form an opinion on whether the financial statements are prepared, in all material respects, in accordance with the applicable financial reporting framework and express a clean or modified opinion accordingly."</blockquote>`,
            citedBy: "45,000 CAs",
            isOpenAccess: true,
            type: "Audit Standard",
            category: "ICAI Auditing"
        },
        {
            id: `cit-fema-${Date.now()}-10`,
            title: `FEMA Section 7 & 8: Realisation and Repatriation of Foreign Exchange`,
            authors: "Reserve Bank of India (RBI) Foreign Exchange Dept",
            journal: "Foreign Exchange Management Act, 1999 read with FED Master Directions",
            year: "2023",
            snippet: `Statutory mandate for exporters to realize full export value within 9 months. Late realization without EDPMS approvals attracts compounding under Section 15 of FEMA.`,
            fullClause: `<blockquote class="border-l-4 border-indigo-500 pl-4 py-1.5 my-3 italic bg-indigo-50/50 dark:bg-indigo-950/30 text-slate-800 dark:text-slate-200"><strong>Statutory Clause: Section 8 of FEMA, 1999:</strong><br>Where any amount of foreign exchange is due or has accrued to any person resident in India, such person shall take all reasonable steps to realise and repatriate to India such foreign exchange within such period and in such manner as may be specified by the Reserve Bank.</blockquote>`,
            citedBy: "11,200 CAs",
            isOpenAccess: true,
            type: "Statute",
            category: "FEMA & Banking"
        }
    ];

    if (!query && !category) return allLaws;

    const q = (query || '').toLowerCase().trim();
    return allLaws.filter(law => {
        const matchesCat = !category || category === 'All' || law.category === category;
        const matchesQuery = !q || 
            law.title.toLowerCase().includes(q) || 
            law.snippet.toLowerCase().includes(q) || 
            law.journal.toLowerCase().includes(q) || 
            law.authors.toLowerCase().includes(q);
        return matchesCat && matchesQuery;
    });
};

const DocumentEditor: React.FC = () => {
  const navigate = useNavigate();
  // Theme & Language State
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [currentLang, setCurrentLang] = useState<'en' | 'es' | 'fr' | 'de'>('en');
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);

  // Navigation State
  const [currentView, setCurrentView] = useState<'editor' | 'documents' | 'library'>('editor');
  const [sidebarMode, setSidebarMode] = useState<'main' | 'documents'>('main');
  
  // Editor State
  const [content, setContent] = useState<string>('');
  const [currentDocId, setCurrentDocId] = useState<string | null>(null);
  const [title, setTitle] = useState('Untitled');
  const [wordCount, setWordCount] = useState(0);
  const [isAutocompleteOn, setIsAutocompleteOn] = useState(true);
  const [isChatOpen, setIsChatOpen] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving' | 'idle'>('idle');

  // Formatting Menu State
  const [textMenuOpen, setTextMenuOpen] = useState(false);
  const [exportMenuOpen, setExportMenuOpen] = useState(false);

  // Floating Selection Toolbar State
  const [selectionMenuPos, setSelectionMenuPos] = useState<{top: number, left: number} | null>(null);
  const [selectedWordCount, setSelectedWordCount] = useState(0);

  // Citation State
  const [isCitationModalOpen, setIsCitationModalOpen] = useState(false);
  const [citationSearchQuery, setCitationSearchQuery] = useState('');
  const [citationCategory, setCitationCategory] = useState<string>('All');
  const [savedRange, setSavedRange] = useState<Range | null>(null);
  const [citations, setCitations] = useState<any[]>([]);
  const [isCitationLoading, setIsCitationLoading] = useState(false);
  const [copiedCitationId, setCopiedCitationId] = useState<string | null>(null);
  
  // Advanced Filter State
  const [citationFilterYear, setCitationFilterYear] = useState<number | null>(null);
  const [citationSortBy, setCitationSortBy] = useState<string>('Relevance');
  const [yearPickerDecade, setYearPickerDecade] = useState<number>(2020);
  
  const [isYearMenuOpen, setIsYearMenuOpen] = useState(false);
  const [isSortMenuOpen, setIsSortMenuOpen] = useState(false);
  const citationTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  // Citation Interaction State (Card Hover)
  const [hoveredCitation, setHoveredCitation] = useState<any | null>(null);
  const [hoverCardPos, setHoverCardPos] = useState<{top: number, left: number} | null>(null);
  const hoverTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  
  // Citation Popover
  const [activeCitationElement, setActiveCitationElement] = useState<HTMLElement | null>(null);
  const [citationPopoverPos, setCitationPopoverPos] = useState<{top: number, left: number} | null>(null);

  // Math/Equation State
  const [mathModalOpen, setMathModalOpen] = useState(false);
  const [mathModalPosition, setMathModalPosition] = useState<{top: number, left: number} | null>(null);
  const [mathExpression, setMathExpression] = useState('');
  const [activeMathElement, setActiveMathElement] = useState<HTMLElement | null>(null);

  // Table State
  const [tableMenuOpen, setTableMenuOpen] = useState(false);
  const [tableSelection, setTableSelection] = useState({ rows: 0, cols: 0 });

  // Code Block State
  const [codeLangMenuOpen, setCodeLangMenuOpen] = useState(false);
  const [codeLangMenuPos, setCodeLangMenuPos] = useState<{top: number, left: number} | null>(null);
  const [activeCodeBlockElement, setActiveCodeBlockElement] = useState<HTMLElement | null>(null);

  // Image State
  const [activeImage, setActiveImage] = useState<HTMLImageElement | null>(null);
  const [resizerPos, setResizerPos] = useState({ top: 0, left: 0, width: 0, height: 0 });
  const [isResizing, setIsResizing] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const resizeStartRef = useRef<{ x: number, y: number, w: number, h: number } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // History State
  const historyStack = useRef<string[]>(['']);
  const [historyIndex, setHistoryIndex] = useState(0);
  const saveHistoryTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Autocomplete State
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const [suggestionPos, setSuggestionPos] = useState<{top: number, left: number} | null>(null);
  const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const requestVersionRef = useRef(0);
  
  // Document Management State
  const [documents, setDocuments] = useState([
    { 
        id: '1', 
        title: 'Legal Opinion: Section 43B(h) MSME Dues & Disallowance under Income Tax Act 1961', 
        updatedAt: '15 mins ago', 
        wordCount: 840, 
        snippet: 'Subject: Applicability of Section 43B(h) inserted by Finance Act 2023 on outstanding payments to Micro and Small Enterprises...',
        content: `<h2><strong>LEGAL OPINION & STATUTORY MEMORANDUM</strong></h2><p><strong>TO:</strong> Board of Directors / Chief Financial Officer</p><p><strong>FROM:</strong> CA Legal & Statutory Advisory Desk</p><p><strong>DATE:</strong> Assessment Year 2024-25</p><p><strong>SUBJECT:</strong> Applicability of Section 43B(h) of the Income-tax Act, 1961 read with Section 15 of MSMED Act, 2006 regarding disallowance of overdue supplier invoices.</p><hr><p><br></p><h3><strong>1. Statutory Framework</strong></h3><p>Section 43B(h) was inserted by the Finance Act, 2023 with effect from 1st April 2024 (AY 2024-25). It mandates that any sum payable by the assessee to a <strong>Micro or Small Enterprise</strong> beyond the time limit specified in Section 15 of the Micro, Small and Medium Enterprises Development Act, 2006 (MSMED Act) shall be allowed as a deduction <em>only in the previous year in which such sum is actually paid</em>.</p><p><br></p><h3><strong>2. Critical Timelines under Section 15 of MSMED Act</strong></h3><ul><li><strong>Written Agreement:</strong> Payment must be made within the agreed timeline, which cannot exceed <strong>45 days</strong> from the date of acceptance or deemed acceptance.</li><li><strong>No Written Agreement:</strong> Payment must be made within <strong>15 days</strong> (the appointed day).</li></ul><p><br></p><h3><strong>3. Landmark Rulings & CBDT Clarifications</strong></h3><p>Unlike other clauses of Section 43B, the proviso allowing deduction for payments made prior to the due date of filing return u/s 139(1) <em>does NOT apply to Clause (h)</em>. As clarified by CBDT Circular No. 01/2024, disallowance is mandatory if unpaid as of March 31st beyond the statutory threshold.</p>`
    },
    { 
        id: '2', 
        title: 'Objection Grounds: Reassessment Notice u/s 148A(b) for AY 2018-19', 
        updatedAt: '2 hours ago', 
        wordCount: 1120, 
        snippet: 'Before the Income Tax Officer, Ward 1(1). In the matter of objection against initiation of reassessment proceedings...',
        content: `<h2><strong>BEFORE THE ASSESSING OFFICER, WARD 1(1) / CIRCLE 1(1)</strong></h2><p><strong>IN THE MATTER OF:</strong> M/s Apex Infra Projects Pvt Ltd (PAN: AABCA1234F)</p><p><strong>PROCEEDINGS UNDER:</strong> Section 148A(b) of the Income Tax Act, 1961</p><p><strong>ASSESSMENT YEAR:</strong> 2018-19</p><hr><p><br></p><h3><strong>PRELIMINARY OBJECTIONS ON JURISDICTION & LIMITATION</strong></h3><p><strong>Ground 1: Barred by Limitation under Supreme Court Ruling in <em>Rajiv Bansal (2024)</em></strong></p><p>The impugned notice u/s 148A(b) issued for AY 2018-19 without prior sanction under Section 151 from the Specified Authority is bad in law and void ab initio.</p><p><br></p><p><strong>Ground 2: Absence of Tangible Material & Independent Application of Mind</strong></p><p>The Assessing Officer has merely acted on raw insight flags from the Insight Portal without conducting an independent inquiry as mandated by Section 148A(a). As held in <em>CIT v. Kelvinator of India Ltd [2010] 320 ITR 561 (SC)</em>, reassessment cannot be founded on a mere change of opinion.</p>` 
    },
    { 
        id: '3', 
        title: 'Statutory Audit Note: CARO 2020 Compliance & Verification of Working Capital Limits', 
        updatedAt: 'Yesterday', 
        wordCount: 650, 
        snippet: 'Audit Documentation pursuant to ICAI Standards on Auditing (SA 500/SA 700) and Clause (ii)(b) of CARO 2020 Order...',
        content: `<h2><strong>STATUTORY AUDIT MEMO: CARO 2020 REPORTING</strong></h2><p><strong>ENTITY:</strong> M/s Sunrise Manufacturing Limited (CIN: L29100MH2012PLC123456)</p><p><strong>FINANCIAL YEAR:</strong> 2023-24</p><p><strong>AUDIT ENGAGEMENT PARTNER:</strong> CA R. K. Sharma & Associates</p><hr><p><br></p><h3><strong>Clause (ii)(b): Working Capital Limits against Current Assets</strong></h3><p>Whether during any point of time of the year, the company has been sanctioned working capital limits in excess of five crore rupees, in aggregate, from banks or financial institutions on the basis of security of current assets; whether the quarterly returns or statements filed by the company with such banks or financial institutions are in agreement with the books of account of the Company.</p><p><br></p><h3><strong>Audit Findings & ICAI Reconciliation Guidance</strong></h3><p>The company was sanctioned a cash credit facility of ₹12.50 Crores by State Bank of India against hypothecation of book debts and inventory. On reconciliation with the audited trial balance as at Q3 and Q4, variances within allowable threshold (<1%) were observed, resulting in an unqualified reporting requirement under SA 700.</p>`
    },
  ]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeMenuDocId, setActiveMenuDocId] = useState<string | null>(null);

  const editorRef = useRef<HTMLDivElement>(null);
  const t = TRANSLATIONS[currentLang];

  const documentsRef = useRef(documents);
  const currentDocIdRef = useRef(currentDocId);

  useEffect(() => {
      documentsRef.current = documents;
      currentDocIdRef.current = currentDocId;
  }, [documents, currentDocId]);

  // AUTO-SAVE FUNCTIONALITY
  useEffect(() => {
    const saveToLocalStorage = () => {
        if (documentsRef.current.length > 0) {
            setSaveStatus('saving');
            localStorage.setItem('jenni-docs', JSON.stringify(documentsRef.current));
            if (currentDocIdRef.current) {
                localStorage.setItem('jenni-current-doc', currentDocIdRef.current);
            }
            setTimeout(() => setSaveStatus('saved'), 1000);
        }
    };

    // Save every 30 seconds
    const saveInterval = setInterval(saveToLocalStorage, 30000);

    // Save on tab close / navigation
    const handleBeforeUnload = () => {
        saveToLocalStorage();
    };

    window.addEventListener('beforeunload', handleBeforeUnload);

    return () => {
        clearInterval(saveInterval);
        window.removeEventListener('beforeunload', handleBeforeUnload);
    };
  }, []);

  // Handle text selection toolbar
  const handleSelectionChange = () => {
    const selection = window.getSelection();
    if (!selection || selection.isCollapsed || !editorRef.current) {
        setSelectionMenuPos(null);
        return;
    }

    const range = selection.getRangeAt(0);
    if (!editorRef.current.contains(range.commonAncestorContainer)) {
        setSelectionMenuPos(null);
        return;
    }

    const rect = range.getBoundingClientRect();
    const text = selection.toString().trim();
    if (text === '') {
        setSelectionMenuPos(null);
        return;
    }

    setSelectedWordCount(text.split(/\s+/).length);
    // Position menu above the selection
    setSelectionMenuPos({
        top: rect.top + window.scrollY - 60,
        left: rect.left + rect.width / 2
    });
  };

  useEffect(() => {
    document.addEventListener('selectionchange', handleSelectionChange);
    return () => document.removeEventListener('selectionchange', handleSelectionChange);
  }, []);

  useEffect(() => {
    const savedDocs = localStorage.getItem('jenni-docs');
    const savedCurrentId = localStorage.getItem('jenni-current-doc');

    if (savedDocs) {
        try {
            const parsedDocs = JSON.parse(savedDocs);
            setDocuments(parsedDocs);
            
            if (savedCurrentId) {
                const doc = parsedDocs.find((d: any) => d.id === savedCurrentId);
                if (doc) {
                    setCurrentDocId(doc.id);
                    setTitle(doc.title);
                    const docContent = doc.content || doc.snippet || '';
                    setContent(docContent);
                    setWordCount(doc.wordCount);
                    setCurrentView('editor');
                    historyStack.current = [docContent];
                    setHistoryIndex(0);
                    
                    setTimeout(() => {
                         if (editorRef.current) {
                             if (docContent.includes('<') && docContent.includes('>')) {
                                 editorRef.current.innerHTML = docContent;
                             } else {
                                 editorRef.current.innerText = docContent;
                             }
                             const blocks = editorRef.current.querySelectorAll('.code-block');
                             blocks.forEach(block => highlightCodeBlock(block as HTMLElement));
                        }
                    }, 100);
                }
            }
        } catch (e) {
            console.error("Failed to load saved docs", e);
        }
    }
  }, []);

  useEffect(() => {
      const handleFocusOut = (e: FocusEvent) => {
          const target = e.target as HTMLElement;
          if (target && target.classList.contains('code-content')) {
              const block = target.closest('.code-block') as HTMLElement;
              if (block) {
                  highlightCodeBlock(block);
              }
          }
      };
      
      document.addEventListener('focusout', handleFocusOut);
      return () => document.removeEventListener('focusout', handleFocusOut);
  }, []);

  const updateResizer = () => {
    if (activeImage) {
        const rect = activeImage.getBoundingClientRect();
        setResizerPos({
            top: rect.top,
            left: rect.left,
            width: rect.width,
            height: rect.height
        });
    }
  };

  useEffect(() => {
      if (activeImage) {
          window.addEventListener('scroll', updateResizer, true);
          window.addEventListener('resize', updateResizer);
          if (isDragging) {
              window.addEventListener('mousemove', updateResizer);
          }
      }
      return () => {
          window.removeEventListener('scroll', updateResizer, true);
          window.removeEventListener('resize', updateResizer);
          window.removeEventListener('mousemove', updateResizer);
      };
  }, [activeImage, isDragging]);

  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
        root.classList.add('dark');
    } else {
        root.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    if (!isCitationModalOpen) return;
    if (citationTimeoutRef.current) clearTimeout(citationTimeoutRef.current);

    if (!citationSearchQuery.trim()) {
        const defaultList = generateFallbackCitations('', citationFilterYear, citationCategory);
        setCitations(defaultList);
        setIsCitationLoading(false);
        return;
    }

    setIsCitationLoading(true);

    citationTimeoutRef.current = setTimeout(async () => {
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            let timeConstraint = "";
            if (citationFilterYear) {
                timeConstraint = ` published on or after ${citationFilterYear}`;
            }

            const prompt = `Find 4 authoritative Indian statutory legal or tax law sources, ITAT judgments, Supreme Court/High Court rulings, or ICAI auditing standards for Chartered Accountants about: "${citationSearchQuery}"${timeConstraint}. Format with accurate section references or court citation numbers. Category filter: ${citationCategory}.`;

            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: prompt,
                config: {
                    tools: [{ googleSearch: {} }],
                    responseMimeType: "application/json",
                    responseSchema: {
                        type: Type.ARRAY,
                        items: {
                            type: Type.OBJECT,
                            properties: {
                                title: { type: Type.STRING },
                                authors: { type: Type.STRING },
                                journal: { type: Type.STRING },
                                year: { type: Type.STRING }, 
                                snippet: { type: Type.STRING },
                                citedBy: { type: Type.STRING },
                                isOpenAccess: { type: Type.BOOLEAN },
                                type: { type: Type.STRING },
                                category: { type: Type.STRING }
                            }
                        }
                    },
                    maxOutputTokens: 4000, 
                }
            });
            
            let responseText = response.text || "[]";
            const jsonMatch = responseText.match(/\[[\s\S]*\]/);
            if (jsonMatch) {
                responseText = jsonMatch[0];
            } else {
                responseText = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
            }

            const results = JSON.parse(responseText);
            const processedResults = Array.isArray(results) ? results.map((r: any, idx: number) => ({
                ...r,
                id: r.id || `cit-${Date.now()}-${idx}`,
                type: r.type || 'Statute',
                category: r.category || citationCategory !== 'All' ? citationCategory : 'Income Tax'
            })) : [];
            
            if (processedResults.length > 0) {
                setCitations(processedResults);
            } else {
                setCitations(generateFallbackCitations(citationSearchQuery, citationFilterYear, citationCategory));
            }
        } catch (error) {
            const mockCitations = generateFallbackCitations(citationSearchQuery, citationFilterYear, citationCategory);
            setCitations(mockCitations);
        } finally {
            setIsCitationLoading(false);
        }
    }, 450);

    return () => {
        if (citationTimeoutRef.current) clearTimeout(citationTimeoutRef.current);
    };
  }, [citationSearchQuery, isCitationModalOpen, citationFilterYear, citationCategory]); 

  useEffect(() => {
    return () => {
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      if (saveHistoryTimeoutRef.current) clearTimeout(saveHistoryTimeoutRef.current);
      if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
    };
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
       setActiveMenuDocId(null);
       const target = e.target as HTMLElement;
       
       if (!target.closest('.lang-menu-trigger')) {
           setIsLangMenuOpen(false);
       }
       if (mathModalOpen && !target.closest('.math-modal') && !target.closest('.math-placeholder') && !target.closest('.math-rendered')) {
           setMathModalOpen(false);
       }
       if (codeLangMenuOpen && !target.closest('.code-lang-menu') && !target.closest('.lang-trigger')) {
           setCodeLangMenuOpen(false);
       }
       if (isCitationModalOpen && !target.closest('.citation-modal') && !target.closest('.cite-trigger')) {
           setIsCitationModalOpen(false);
       }
       if (tableMenuOpen && !target.closest('.relative-table-menu')) {
           setTableMenuOpen(false);
       }
       if (textMenuOpen && !target.closest('.text-menu-trigger')) {
           setTextMenuOpen(false);
       }
       if (exportMenuOpen && !target.closest('.export-menu-trigger')) {
           setExportMenuOpen(false);
       }
       if (isYearMenuOpen && !target.closest('.year-menu-trigger')) {
           setIsYearMenuOpen(false);
       }
       if (isSortMenuOpen && !target.closest('.sort-menu-trigger')) {
           setIsSortMenuOpen(false);
       }
       if (activeCitationElement && !target.closest('.citation-popover') && !target.closest('[data-type="citation"]')) {
           setActiveCitationElement(null);
           setCitationPopoverPos(null);
       }
       
       if (activeImage && !target.closest('.image-resizer') && target.tagName !== 'IMG') {
           setActiveImage(null);
       }

       if (editorRef.current && !editorRef.current.contains(target) && !target.closest('.suggestion-toolbar')) {
           const ghost = document.getElementById('ai-ghost-text');
           if (ghost) ghost.remove();
           setSuggestion(null);
           setSuggestionPos(null);
       }
    };
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, [mathModalOpen, codeLangMenuOpen, isCitationModalOpen, activeCitationElement, activeImage, tableMenuOpen, textMenuOpen, exportMenuOpen, isYearMenuOpen, isSortMenuOpen]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file && editorRef.current) {
          const reader = new FileReader();
          reader.onload = (e) => {
              const img = document.createElement('img');
              img.src = e.target?.result as string;
              img.className = "max-w-full rounded-lg my-4 shadow-sm hover:shadow-md transition-shadow select-none";
              img.style.width = "400px"; 
              img.style.cursor = "move";
              img.draggable = false; 
              img.contentEditable = "false";
              insertNodeAtCursor(img);
          };
          reader.readAsDataURL(file);
      }
      if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const insertNodeAtCursor = (node: Node) => {
      if (!editorRef.current) return;
      editorRef.current.focus();
      
      const selection = window.getSelection();
      let range;

      if (savedRange && editorRef.current.contains(savedRange.commonAncestorContainer)) {
          range = savedRange;
      } else if (selection && selection.rangeCount > 0 && editorRef.current.contains(selection.getRangeAt(0).commonAncestorContainer)) {
          range = selection.getRangeAt(0);
      } else {
          range = document.createRange();
          range.selectNodeContents(editorRef.current);
          range.collapse(false);
      }

      range.deleteContents();
      range.insertNode(node);
      
      const br = document.createElement('br');
      range.collapse(false);
      range.insertNode(br);
      range.collapse(false);
      
      selection?.removeAllRanges();
      selection?.addRange(range);
      
      handleInput({ currentTarget: editorRef.current } as any);
  };

  const insertTextAtCursor = (text: string) => {
      if (!editorRef.current) return;
      editorRef.current.focus();

      const selection = window.getSelection();
      let range;

      if (savedRange && editorRef.current.contains(savedRange.commonAncestorContainer)) {
          range = savedRange;
      } else if (selection && selection.rangeCount > 0 && editorRef.current.contains(selection.getRangeAt(0).commonAncestorContainer)) {
          range = selection.getRangeAt(0);
      } else {
          range = document.createRange();
          range.selectNodeContents(editorRef.current);
          range.collapse(false);
      }

      const textNode = document.createTextNode(text + ' ');
      range.deleteContents();
      range.insertNode(textNode);
      range.collapse(false);
      
      selection?.removeAllRanges();
      selection?.addRange(range);
      
      handleInput({ currentTarget: editorRef.current } as any);
  };

  const insertHtmlAtCursor = (html: string) => {
      if (!editorRef.current) return;
      editorRef.current.focus();

      const selection = window.getSelection();
      let range;

      if (savedRange && editorRef.current.contains(savedRange.commonAncestorContainer)) {
          range = savedRange;
      } else if (selection && selection.rangeCount > 0 && editorRef.current.contains(selection.getRangeAt(0).commonAncestorContainer)) {
          range = selection.getRangeAt(0);
      } else {
          range = document.createRange();
          range.selectNodeContents(editorRef.current);
          range.collapse(false);
      }

      range.deleteContents();
      const fragment = range.createContextualFragment(html + '&nbsp;'); 
      const lastChild = fragment.lastChild;
      range.insertNode(fragment);
      
      if (lastChild) {
          range.setStartAfter(lastChild);
          range.setEndAfter(lastChild);
      }
      
      selection?.removeAllRanges();
      selection?.addRange(range);
      
      handleInput({ currentTarget: editorRef.current } as any);
  };

  const startMove = (e: React.MouseEvent, img: HTMLImageElement) => {
      e.preventDefault();
      e.stopPropagation();
      setActiveImage(img);
      setIsDragging(true);

      const editor = editorRef.current;
      if (!editor) return;
      
      if (img.style.position !== 'absolute') {
          const imgRect = img.getBoundingClientRect();
          const editorRect = editor.getBoundingClientRect();
          
          img.style.position = 'absolute';
          img.style.left = (imgRect.left - editorRect.left + editor.scrollLeft) + 'px';
          img.style.top = (imgRect.top - editorRect.top + editor.scrollTop) + 'px';
          img.style.width = imgRect.width + 'px';
          img.style.zIndex = '10';
      }

      const startX = e.clientX;
      const startY = e.clientY;
      const startLeft = parseFloat(img.style.left || '0');
      const startTop = parseFloat(img.style.top || '0');

      const handleMouseMove = (moveEvent: MouseEvent) => {
          const dx = moveEvent.clientX - startX;
          const dy = moveEvent.clientY - startY;
          img.style.left = `${startLeft + dx}px`;
          img.style.top = `${startTop + dy}px`;
          updateResizer();
      };

      const handleMouseUp = () => {
          setIsDragging(false);
          document.removeEventListener('mousemove', handleMouseMove);
          document.removeEventListener('mouseup', handleMouseUp);
          if (editorRef.current) handleInput({ currentTarget: editorRef.current } as any);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
  };

  const startResize = (e: React.MouseEvent, corner: string) => {
      e.preventDefault();
      e.stopPropagation();
      if (!activeImage) return;

      setIsResizing(true);
      resizeStartRef.current = {
          x: e.clientX,
          y: e.clientY,
          w: activeImage.offsetWidth,
          h: activeImage.offsetHeight
      };

      const handleMouseMove = (moveEvent: MouseEvent) => {
          if (!activeImage || !resizeStartRef.current) return;
          const deltaX = moveEvent.clientX - resizeStartRef.current.x;
          let newWidth = resizeStartRef.current.w;
          if (corner.includes('right')) newWidth += deltaX;
          else newWidth -= deltaX;
          
          if (newWidth > 50 && newWidth < (editorRef.current?.offsetWidth || 800)) {
              activeImage.style.width = `${newWidth}px`;
              updateResizer();
          }
      };

      const handleMouseUp = () => {
          setIsResizing(false);
          document.removeEventListener('mousemove', handleMouseMove);
          document.removeEventListener('mouseup', handleMouseUp);
          if (editorRef.current) handleInput({ currentTarget: editorRef.current } as any);
      };

      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
  };

  const highlightCodeBlock = (block: HTMLElement) => {
      if (!window.Prism) return;
      const langLabel = block.querySelector('.lang-label')?.textContent;
      const contentDiv = block.querySelector('.code-content') as HTMLElement;
      
      if (langLabel && contentDiv) {
          const prismLang = PRISM_LANGUAGE_MAP[langLabel] || 'none';
          if (prismLang === 'none') return;
          const text = contentDiv.innerText.replace(/\u00A0/g, ' '); 
          
          const applyHighlight = () => {
               if (window.Prism.languages[prismLang]) {
                   const highlightedHtml = window.Prism.highlight(text, window.Prism.languages[prismLang], prismLang);
                   if (contentDiv.innerHTML !== highlightedHtml) {
                       contentDiv.innerHTML = highlightedHtml;
                       contentDiv.classList.add(`language-${prismLang}`);
                   }
               }
          };

          if (window.Prism.languages[prismLang]) applyHighlight();
          else if (window.Prism.plugins.autoloader) window.Prism.plugins.autoloader.loadLanguages([prismLang], applyHighlight);
      }
  };

  const addToHistory = (htmlContent: string) => {
      const currentStack = historyStack.current.slice(0, historyIndex + 1);
      if (currentStack.length > 0 && currentStack[currentStack.length - 1] === htmlContent) return;
      const newStack = [...currentStack, htmlContent];
      historyStack.current = newStack;
      setHistoryIndex(newStack.length - 1);
  };

  const handleInput = (e: React.FormEvent<HTMLDivElement>) => {
    const ghost = document.getElementById('ai-ghost-text');
    if (ghost) {
        ghost.remove();
        setSuggestion(null);
        setSuggestionPos(null);
    }
    requestVersionRef.current += 1;
    
    const html = e.currentTarget.innerHTML;
    const text = e.currentTarget.innerText;
    
    setContent(html);
    const words = text.trim().split(/\s+/);
    setWordCount(text.trim() === '' ? 0 : words.length);
    
    if (currentDocId) {
        setDocuments(prev => prev.map(doc => 
            doc.id === currentDocId 
            ? { ...doc, wordCount: text.trim() === '' ? 0 : words.length, snippet: text.slice(0, 100) + '...', content: html } 
            : doc
        ));
    }
    if (saveHistoryTimeoutRef.current) clearTimeout(saveHistoryTimeoutRef.current);
    saveHistoryTimeoutRef.current = setTimeout(() => addToHistory(html), 700);
    if (isAutocompleteOn) {
        if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
        typingTimeoutRef.current = setTimeout(() => triggerSuggestion(), 2000);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (suggestion && (e.key === 'Tab' || e.key === 'ArrowRight')) {
        e.preventDefault();
        acceptSuggestion();
    }
    if ((e.key === 'Backspace' || e.key === 'Delete') && activeImage) {
        activeImage.remove();
        setActiveImage(null);
        handleInput({ currentTarget: editorRef.current } as any);
    }

    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
        const anchorNode = selection.anchorNode;
        const element = anchorNode?.nodeType === 1 ? anchorNode as HTMLElement : anchorNode?.parentElement;
        const codeContent = element?.closest('.code-content');
        if (codeContent && e.shiftKey && e.key === 'Enter') {
            e.preventDefault();
            const codeBlock = codeContent.closest('.code-block');
            if (codeBlock) {
                const p = document.createElement('p');
                p.innerHTML = '<br>';
                codeBlock.after(p);
                const range = document.createRange();
                range.setStart(p, 0);
                range.setEnd(p, 0);
                selection.removeAllRanges();
                selection.addRange(range);
            }
        }
    }
  };

  const changeCodeLanguage = (lang: string) => {
    if (activeCodeBlockElement) {
        const langLabel = activeCodeBlockElement.querySelector('.lang-label');
        if (langLabel) langLabel.textContent = lang;
        highlightCodeBlock(activeCodeBlockElement);
        const contentDiv = activeCodeBlockElement.querySelector('.code-content') as HTMLElement;
        if (contentDiv) setTimeout(() => contentDiv.focus(), 0);
        setCodeLangMenuOpen(false);
        setActiveCodeBlockElement(null);
        if (editorRef.current) handleInput({ currentTarget: editorRef.current } as any);
    }
  };

  const copyCodeContent = (block: HTMLElement) => {
      const content = block.querySelector('.code-content') as HTMLElement;
      if (content) navigator.clipboard.writeText(content.innerText);
  };

  const handleEditorMouseDown = (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'IMG') startMove(e, target as HTMLImageElement);
  };

  const handleEditorClick = (e: React.MouseEvent) => {
    const target = e.target as HTMLElement;
    if (target.dataset.type === 'math-placeholder' || target.closest('[data-type="math-rendered"]')) {
        const el = target.dataset.type === 'math-placeholder' ? target : target.closest('[data-type="math-rendered"]') as HTMLElement;
        setActiveMathElement(el);
        const rect = el.getBoundingClientRect();
        setMathModalPosition({ top: rect.bottom + 8 + window.scrollY, left: rect.left + window.scrollX });
        setMathExpression(el.dataset.tex || '');
        setMathModalOpen(true);
        e.stopPropagation();
        return;
    }

    const langTrigger = target.closest('.lang-trigger');
    if (langTrigger) {
        const block = langTrigger.closest('.code-block') as HTMLElement;
        setActiveCodeBlockElement(block);
        const rect = langTrigger.getBoundingClientRect();
        setCodeLangMenuPos({ top: rect.bottom + 4 + window.scrollY, left: rect.left + window.scrollX });
        setCodeLangMenuOpen(true);
        e.stopPropagation();
        return;
    }

    const copyBtn = target.closest('.copy-btn');
    if (copyBtn) {
        const block = copyBtn.closest('.code-block') as HTMLElement;
        if (block) copyCodeContent(block);
        e.stopPropagation();
        return;
    }

    const codeBlock = target.closest('.code-block');
    if (codeBlock && !target.closest('.code-content')) {
         const content = codeBlock.querySelector('.code-content') as HTMLElement;
         if (content) content.focus();
    }
  };

  const handleEditorMouseOver = (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      const citationEl = target.closest('[data-type="citation"]') as HTMLElement;
      if (citationEl) {
          if (hoverTimeoutRef.current) clearTimeout(hoverTimeoutRef.current);
          try {
              const jsonData = citationEl.getAttribute('data-json');
              if (jsonData) {
                  const data = JSON.parse(jsonData);
                  const rect = citationEl.getBoundingClientRect();
                  setHoverCardPos({ top: rect.bottom + 10 + window.scrollY, left: Math.max(10, rect.left + window.scrollX - 20) });
                  setHoveredCitation({ ...data, element: citationEl });
              }
          } catch (err) {}
      }
  };

  const handleEditorMouseOut = (e: React.MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest('[data-type="citation"]')) {
          hoverTimeoutRef.current = setTimeout(() => setHoveredCitation(null), 300);
      }
  };

  const applyTextFormat = (format: string) => {
    if (!editorRef.current) return;
    editorRef.current.focus();
    switch (format) {
        case 'text': document.execCommand('formatBlock', false, 'p'); break;
        case 'h1': document.execCommand('formatBlock', false, 'h1'); break;
        case 'h2': document.execCommand('formatBlock', false, 'h2'); break;
        case 'h3': document.execCommand('formatBlock', false, 'h3'); break;
        case 'bullet': document.execCommand('insertUnorderedList'); break;
        case 'number': document.execCommand('insertOrderedList'); break;
        case 'quote': document.execCommand('formatBlock', false, 'blockquote'); break;
        case 'code': insertCodeBlock(); break;
        case 'table': insertTable(3, 3); break;
        case 'bold': document.execCommand('bold'); break;
        case 'italic': document.execCommand('italic'); break;
        case 'underline': document.execCommand('underline'); break;
        case 'strikethrough': document.execCommand('strikeThrough'); break;
    }
    setTextMenuOpen(false);
    handleInput({ currentTarget: editorRef.current } as any);
  };

  const handleUndo = () => {
    if (historyIndex > 0) {
        const newIndex = historyIndex - 1;
        const prevContent = historyStack.current[newIndex];
        setHistoryIndex(newIndex);
        if (editorRef.current) {
            editorRef.current.innerHTML = prevContent; 
            setContent(prevContent);
            const range = document.createRange();
            const sel = window.getSelection();
            range.selectNodeContents(editorRef.current);
            range.collapse(false);
            sel?.removeAllRanges();
            sel?.addRange(range);
            editorRef.current.focus();
        }
    }
  };

  const handleRedo = () => {
    if (historyIndex < historyStack.current.length - 1) {
        const newIndex = historyIndex + 1;
        const nextContent = historyStack.current[newIndex];
        setHistoryIndex(newIndex);
        if (editorRef.current) {
            editorRef.current.innerHTML = nextContent; 
            setContent(nextContent);
            const range = document.createRange();
            const sel = window.getSelection();
            range.selectNodeContents(editorRef.current);
            range.collapse(false);
            sel?.removeAllRanges();
            sel?.addRange(range);
            editorRef.current.focus();
        }
    }
  };

  const handleExportFormat = (format: string) => {
      if (!editorRef.current) return;
      const textContent = editorRef.current.innerText;
      let blob: Blob | null = null;
      let filename = `${title.replace(/\s+/g, '_')}`;
      let extension = 'html';

      switch (format) {
          case 'html': {
              const htmlContent = `<!DOCTYPE html><html><body><h1>${title}</h1>${editorRef.current.innerHTML}</body></html>`;
              blob = new Blob([htmlContent], { type: 'text/html' });
              break;
          }
          case 'md': blob = new Blob([textContent], { type: 'text/markdown' }); extension = 'md'; break;
          case 'pdf': {
              const ghost = document.getElementById('ai-ghost-text');
              if (ghost) ghost.remove();
              
              const opt = {
                  margin: [0.5, 0.5],
                  filename: `${filename}.pdf`,
                  image: { type: 'jpeg', quality: 0.98 },
                  html2canvas: { scale: 2, useCORS: true },
                  jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
              };
              
              html2pdf().set(opt).from(editorRef.current).save();
              setExportMenuOpen(false);
              return;
          }
      }
      if (blob) {
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `${filename}.${extension}`;
          a.click();
          URL.revokeObjectURL(url);
      }
      setExportMenuOpen(false);
  };

  const showSuggestion = (textToInsert: string) => {
        if (!editorRef.current) return;
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            const range = selection.getRangeAt(0);
            if (!editorRef.current.contains(range.commonAncestorContainer)) return;
            const span = document.createElement('span');
            span.id = 'ai-ghost-text';
            span.contentEditable = 'false'; 
            span.className = 'text-slate-400 pointer-events-none select-none inline';
            span.innerText = textToInsert;
            range.insertNode(span);
            range.setStartBefore(span);
            range.setEndBefore(span);
            selection.removeAllRanges();
            selection.addRange(range);
            const rect = span.getBoundingClientRect();
            setSuggestionPos({ top: rect.bottom + 8, left: rect.left });
            setSuggestion(textToInsert);
        }
  };

  const triggerSuggestion = async () => {
    if (!editorRef.current) return;
    const selection = window.getSelection();
    if (!selection || !selection.anchorNode) return;
    const anchorNode = selection.anchorNode;
    const anchorElement = anchorNode.nodeType === 3 ? anchorNode.parentElement : anchorNode as HTMLElement;
    if (!editorRef.current.contains(anchorElement)) return;
    const isInsideCitation = !!anchorElement?.closest('blockquote') || !!anchorElement?.closest('[data-type="citation"]');
    if (isInsideCitation) return;
    
    const codeBlock = anchorElement?.closest('.code-block');
    const isCode = !!codeBlock;
    let contextText = '';
    let prompt = '';

    if (isCode) {
        const codeContent = codeBlock.querySelector('.code-content');
        contextText = codeContent ? (codeContent as HTMLElement).innerText : '';
        const langLabel = codeBlock.querySelector('.lang-label')?.textContent || 'code';
        prompt = `Complete the following ${langLabel} code snippet: "${contextText}"`;
    } else {
        contextText = editorRef.current.innerText;
        prompt = `You are CA Legal Forms Assistant, an elite legal & tax laws drafting copilot for Chartered Accountants. Complete the drafting of this legal opinion, statutory note, audit observation, or notice reply with rigorous legal phrasing, statutory cross-references, and clear rationale based on the existing text: "${contextText}"`;
    }

    if (!contextText.trim()) return; 
    const currentVersion = requestVersionRef.current;
    
    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({ model: 'gemini-2.5-flash', contents: prompt });
        const textToInsert = response.text;
        if (currentVersion !== requestVersionRef.current || !textToInsert) return;
        const currentSelection = window.getSelection();
        if (!editorRef.current.contains(currentSelection?.anchorNode?.parentElement as HTMLElement)) return;
        showSuggestion(textToInsert);
    } catch (error) {
        if (currentVersion !== requestVersionRef.current) return;
        showSuggestion(" subject to statutory compliance under applicable law.");
    }
  };

  const acceptSuggestion = () => {
    const ghost = document.getElementById('ai-ghost-text');
    if (ghost && editorRef.current) {
        const text = ghost.innerText;
        ghost.remove();
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
            const range = selection.getRangeAt(0);
            const textNode = document.createTextNode(text);
            range.insertNode(textNode);
            range.setStartAfter(textNode);
            range.setEndAfter(textNode);
            selection.removeAllRanges();
            selection.addRange(range);
        }
        handleInput({ currentTarget: editorRef.current } as any);
        setSuggestion(null);
        setSuggestionPos(null);
    }
  };

  const tryAgainSuggestion = async () => {
    const ghost = document.getElementById('ai-ghost-text');
    if (ghost) {
         ghost.innerText = "...";
         try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const response = await ai.models.generateContent({ model: 'gemini-3-flash-preview', contents: `Alternative completion for: "${content}"` });
            const newText = response.text;
            if (!newText) return;
            ghost.innerText = newText;
            setSuggestion(newText);
         } catch (error) {}
    }
  };

  const handleTitleChange = (newTitle: string) => {
    setTitle(newTitle);
    if (currentDocId) setDocuments(prev => prev.map(doc => doc.id === currentDocId ? { ...doc, title: newTitle } : doc));
  };

  const handleNewDocument = () => {
    const newDoc = { id: Date.now().toString(), title: t.untitled, updatedAt: 'Just now', wordCount: 0, snippet: '', content: '' };
    setDocuments([newDoc, ...documents]);
    openDocument(newDoc);
  };

  const openDocument = (doc: any) => {
    setCurrentDocId(doc.id);
    setTitle(doc.title);
    const docContent = doc.content || doc.snippet || '';
    if (editorRef.current) {
         if (docContent.includes('<') && docContent.includes('>')) editorRef.current.innerHTML = docContent;
         else editorRef.current.innerText = docContent;
    }
    setContent(docContent);
    setWordCount(doc.wordCount);
    setCurrentView('editor');
    historyStack.current = [docContent];
    setHistoryIndex(0);
  };

  const deleteDocument = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    setDocuments(prev => prev.filter(d => d.id !== id));
    if (currentDocId === id) handleNewDocument(); 
    setActiveMenuDocId(null);
  };

  const renameDocument = (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    const doc = documents.find(d => d.id === id);
    if (!doc) return;
    const newTitle = window.prompt(t.rename + ":", doc.title);
    if (newTitle && newTitle.trim() !== "") {
        setDocuments(prev => prev.map(d => d.id === id ? { ...d, title: newTitle } : d));
        if (currentDocId === id) setTitle(newTitle);
    }
    setActiveMenuDocId(null);
  };

  const insertPlaceholder = (type: string) => {
    if (!editorRef.current) return;
    if (type === 'Math') { insertMathPlaceholder(); return; }
    if (type === 'Code') { insertCodeBlock(); return; }
    if (type === 'Image') { fileInputRef.current?.click(); return; }
    if (type === 'Table') { setTableMenuOpen(true); return; }
  };

  const insertTable = (rows: number, cols: number) => {
    if (!editorRef.current) return;
    const tableContainer = document.createElement('div');
    tableContainer.className = "my-6 overflow-x-auto select-none";
    tableContainer.contentEditable = "false"; 
    const table = document.createElement('table');
    table.className = "w-full border-collapse border border-slate-200";
    const tbody = document.createElement('tbody');
    for (let r = 0; r < rows; r++) {
        const tr = document.createElement('tr');
        for (let c = 0; c < cols; c++) {
            const td = document.createElement('td');
            td.className = "border border-slate-200 p-2 min-w-[50px] relative bg-white";
            const cellDiv = document.createElement('div');
            cellDiv.contentEditable = "true";
            cellDiv.className = "outline-none w-full h-full min-h-[20px] text-slate-700";
            td.appendChild(cellDiv);
            tr.appendChild(td);
        }
        tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    tableContainer.appendChild(table);
    insertNodeAtCursor(tableContainer);
    setTableMenuOpen(false);
  };

  const insertCodeBlock = () => {
      if (!editorRef.current) return;
      const div = document.createElement('div');
      div.className = 'code-block group relative my-6 rounded-md bg-slate-50 border border-slate-200 text-sm font-mono shadow-sm';
      div.contentEditable = 'false';
      div.dataset.type = 'code-block';
      div.innerHTML = `
        <div class="flex justify-between items-center px-3 py-2 border-b border-slate-200 bg-slate-100 rounded-t-md select-none">
            <button class="lang-trigger flex items-center gap-1.5 text-xs font-medium text-slate-500 hover:text-slate-700 transition-colors">
                <span class="lang-label">Plaintext</span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m6 9 6 6 6-6"/></svg>
            </button>
            <button class="copy-btn text-slate-400 hover:text-slate-600 transition-colors p-1 rounded" title="Copy code">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="14" height="14" x="8" y="8" rx="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
            </button>
        </div>
        <div class="code-content p-3 outline-none text-slate-800 bg-slate-50 overflow-x-auto min-h-[3rem] cursor-text whitespace-pre-wrap" contenteditable="true" spellcheck="false"><br></div>
      `;
      insertNodeAtCursor(div);
  };

  const insertMathPlaceholder = () => {
    if (!editorRef.current) return;
    const div = document.createElement('div');
    div.className = 'math-placeholder py-3 bg-[#f8fafc] hover:bg-[#f1f5f9] text-[#94a3b8] hover:text-[#64748b] text-center rounded cursor-pointer my-4 select-none font-medium text-sm transition-colors border border-transparent hover:border-slate-200';
    div.contentEditable = 'false';
    div.innerText = 'Add a TeX equation';
    div.dataset.type = 'math-placeholder';
    insertNodeAtCursor(div);
  };

  const renderMath = () => {
    if (!activeMathElement || !window.katex) return;
    try {
        const span = document.createElement('div');
        span.className = 'math-rendered text-center my-4 cursor-pointer p-2 hover:bg-slate-50 rounded transition-colors select-none';
        span.contentEditable = 'false';
        span.dataset.type = 'math-rendered';
        span.dataset.tex = mathExpression;
        span.innerHTML = window.katex.renderToString(mathExpression, { throwOnError: false, displayMode: true });
        activeMathElement.replaceWith(span);
        setMathModalOpen(false);
        setActiveMathElement(null);
        handleInput({ currentTarget: editorRef.current } as any);
    } catch (e) {}
  };

  const openCitationModal = (e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    const selection = window.getSelection();
    let queryText = '';
    if (selection && selection.rangeCount > 0) {
        setSavedRange(selection.getRangeAt(0).cloneRange());
        const text = selection.toString().trim();
        if (text) {
          queryText = text;
          setCitationSearchQuery(text);
        }
    }
    setCitations(generateFallbackCitations(queryText || citationSearchQuery, citationFilterYear, citationCategory));
    setIsCitationModalOpen(true);
  };

  const handleCite = (citation: any) => {
      let citeLabel = ` (${citation.title.split(':')[0].trim()}, ${citation.year})`;
      if (citation.title.includes(' v. ') || citation.title.includes(' v ')) {
         const casePart = citation.title.split('[')[0].trim();
         citeLabel = ` (${casePart}, ${citation.year})`;
      }
      
      const citationDataStr = JSON.stringify(citation).replace(/'/g, "&apos;").replace(/"/g, "&quot;");
      const html = `<span class="text-[#6366f1] hover:text-[#4338ca] dark:text-[#818cf8] dark:hover:text-[#a5b4fc] cursor-pointer select-none transition-colors px-1 py-0.5 rounded font-medium bg-[#6366f1]/10 dark:bg-[#6366f1]/20" contenteditable="false" data-type="citation" data-json='${citationDataStr}'>${citeLabel}</span>`;
      
      insertHtmlAtCursor(html);
      setIsCitationModalOpen(false);
  };

  const handleInsertClause = (citation: any) => {
      const clauseHtml = citation.fullClause || `<blockquote class="border-l-4 border-indigo-500 pl-4 py-2 my-4 italic bg-indigo-50/60 dark:bg-indigo-950/40 text-slate-800 dark:text-slate-200 rounded-r-lg"><strong>Statutory Citation: ${citation.title}</strong><br>${citation.snippet} <span class="text-xs text-indigo-600 dark:text-indigo-400 block mt-1">Ref: ${citation.journal} (${citation.year})</span></blockquote><p><br></p>`;
      insertHtmlAtCursor(clauseHtml);
      setIsCitationModalOpen(false);
  };

  const handleCopyCitationText = (citation: any) => {
      const text = `${citation.title} | ${citation.journal} (${citation.year}). Reference: ${citation.snippet}`;
      navigator.clipboard.writeText(text);
      setCopiedCitationId(citation.id);
      setTimeout(() => setCopiedCitationId(null), 2000);
  };

  const toggleSidebarToDocuments = () => { setSidebarMode('documents'); };
  const filteredDocuments = documents.filter(doc => doc.title.toLowerCase().includes(searchQuery.toLowerCase()));

  return (
    <div className={`flex h-screen bg-white text-slate-900 font-sans overflow-hidden transition-colors duration-300 dark:bg-slate-950 dark:text-slate-100`}>
      <style>{`
        .editor-content::selection {
          background-color: #dbeafe !important;
          color: inherit !important;
        }
      `}</style>
      
      {/* Sidebar */}
      <aside className="w-[260px] flex-shrink-0 border-r border-slate-100/60 dark:border-slate-800/60 flex flex-col justify-between py-6 bg-[#fafafa] dark:bg-[#0f1115] text-[13px] z-20 transition-all duration-300">
        {sidebarMode === 'main' && (
            <>
                <div className="px-4">
                    <div className="flex items-center gap-2.5 px-3 mb-8 cursor-pointer select-none">
                        <div className="w-5 h-5 flex items-center justify-center font-serif italic font-bold text-base text-slate-800 dark:text-slate-100">§</div>
                        <span className="font-semibold text-slate-800 dark:text-slate-100 tracking-tight text-[15px]">CA Legal Forms Assistant</span>
                    </div>
                    <div className="space-y-0.5 mt-4">
                        <div className="text-[10px] font-semibold text-slate-400 dark:text-slate-500 uppercase tracking-widest mb-3 px-3">Workspace</div>
                        <button onClick={handleNewDocument} className="w-full flex items-center gap-3 px-3 py-2 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 rounded-md font-medium transition-colors">
                          <PlusCircle size={16} strokeWidth={2} />{t.new}
                        </button>
                        <button onClick={toggleSidebarToDocuments} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md font-medium transition-colors ${sidebarMode === 'documents' ? 'bg-black/5 dark:bg-white/10 text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400 hover:bg-black/5 dark:hover:bg-white/5 hover:text-slate-800 dark:hover:text-slate-200'}`}>
                          <FileText size={16} strokeWidth={2} />{t.documents}
                        </button>
                        <button onClick={() => setIsChatOpen(!isChatOpen)} className={`w-full flex items-center gap-3 px-3 py-2 rounded-md font-medium transition-colors ${isChatOpen ? 'bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400' : 'text-slate-500 dark:text-slate-400 hover:bg-black/5 dark:hover:bg-white/5 hover:text-slate-800 dark:hover:text-slate-200'}`}>
                          <MessageSquare size={16} strokeWidth={2} />{t.aiChat}
                        </button>
                    </div>
                </div>
                <div className="px-4">
                    <div className="flex items-center px-3 pt-4">
                        <div className="flex gap-0.5 bg-black/5 dark:bg-white/5 rounded-lg p-0.5">
                            <button onClick={() => setTheme('light')} className={`p-1.5 rounded-md transition-colors ${theme === 'light' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}><Monitor size={14} strokeWidth={2.5} /></button>
                            <button onClick={() => setTheme('dark')} className={`p-1.5 rounded-md transition-colors ${theme === 'dark' ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm' : 'text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'}`}><Moon size={14} strokeWidth={2.5} /></button>
                        </div>
                    </div>
                </div>
            </>
        )}

        {sidebarMode === 'documents' && (
            <div className="flex flex-col h-full">
                <div className="px-5 pb-4 flex items-center gap-2">
                   <button onClick={() => setSidebarMode('main')} className="p-1 -ml-1 hover:bg-black/5 dark:hover:bg-white/10 rounded-md transition-colors text-slate-500 dark:text-slate-400">
                     <ChevronLeft size={16} strokeWidth={2.5} />
                   </button>
                   <span className="font-semibold text-slate-800 dark:text-slate-100 tracking-tight text-[15px]">{t.documents}</span>
                </div>
                <div className="px-4 pb-4">
                  <div className="relative">
                      <Search size={14} className="absolute left-2.5 top-2.5 text-slate-400" />
                      <input 
                        type="text" 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder="Search docs..."
                        className="w-full bg-black/5 dark:bg-white/5 border border-transparent focus:border-indigo-500/30 rounded-md pl-8 pr-3 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder:text-slate-500 outline-none transition-all"
                      />
                  </div>
                </div>
                <div className="flex-1 overflow-y-auto custom-scrollbar px-2 space-y-0.5">
                  {filteredDocuments.map(doc => (
                      <button 
                         key={doc.id}
                         onClick={() => { openDocument(doc); }}
                         className={`w-full text-left px-3 py-2.5 rounded-md transition-colors flex flex-col gap-1 ${currentDocId === doc.id ? 'bg-indigo-50 dark:bg-indigo-500/10' : 'hover:bg-black/5 dark:hover:bg-white/5'}`}
                      >
                         <span className={`text-[13px] font-medium truncate w-full ${currentDocId === doc.id ? 'text-indigo-700 dark:text-indigo-400' : 'text-slate-700 dark:text-slate-300'}`}>{doc.title}</span>
                         <div className="flex items-center gap-2 text-[10px] text-slate-400 dark:text-slate-500">
                           <span>{doc.updatedAt}</span>
                           <span>•</span>
                           <span>{doc.wordCount} words</span>
                         </div>
                      </button>
                  ))}
                  {filteredDocuments.length === 0 && (
                      <div className="text-center py-8 text-xs text-slate-500">No documents found</div>
                  )}
                </div>
            </div>
        )}
      </aside>

      <div className="flex-1 flex overflow-hidden">
          {currentView === 'editor' && (
            <main className="flex-1 flex flex-col relative min-w-0 bg-white dark:bg-slate-900">
                <header className="h-16 flex items-center justify-between px-8 bg-white dark:bg-slate-900 z-10">
                    <input type="text" value={title} onChange={(e) => handleTitleChange(e.target.value)} className="font-medium text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-800 focus:bg-white dark:focus:bg-slate-800 focus:outline-none focus:ring-1 focus:ring-[#6366f1] rounded px-2 py-1 -ml-2 transition-all truncate max-w-[300px] bg-transparent" />
                    <div className="flex items-center gap-3">
                        <div className="relative export-menu-trigger">
                            <button onClick={() => handleExportFormat('pdf')} className={`flex items-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white px-2.5 py-1.5 rounded-lg text-xs font-bold transition-colors hover:bg-slate-50 dark:hover:bg-slate-800`}><Download size={14} /> {t.export}</button>
                        </div>
                    </div>
                </header>

                <div 
                    className="flex-1 overflow-y-auto relative custom-scrollbar cursor-text" 
                    onClick={() => editorRef.current?.focus()}
                >
                    <div className="max-w-[850px] mx-auto pt-16 px-12 pb-32">
                        <input type="text" value={title} onChange={(e) => handleTitleChange(e.target.value)} onClick={(e) => e.stopPropagation()} className="w-full text-5xl font-bold text-slate-900 dark:text-slate-100 placeholder:text-slate-300 outline-none bg-transparent mb-4 cursor-text" placeholder={t.untitled} />
                        <div ref={editorRef} contentEditable suppressContentEditableWarning={true} onInput={handleInput} onKeyDown={handleKeyDown} onClick={handleEditorClick} onMouseDown={handleEditorMouseDown} onMouseOver={handleEditorMouseOver} onMouseOut={handleEditorMouseOut} className="editor-content outline-none min-h-[500px] text-lg text-slate-700 dark:text-slate-300 leading-relaxed empty:before:content-[attr(data-placeholder)] empty:before:text-slate-300 dark:empty:before:text-slate-600 cursor-text" data-placeholder="Start writing or type '++' for AI..." />
                    </div>
                </div>

                {/* FLOATING SELECTION TOOLBAR */}
                {selectionMenuPos && (
                  <div 
                    className="fixed z-[60] bg-white dark:bg-slate-800 rounded-xl shadow-[0_10px_40px_rgba(0,0,0,0.15)] border border-slate-200 dark:border-slate-700 p-1 flex items-center animate-in fade-in zoom-in-95 duration-150 transform -translate-x-1/2"
                    style={{ top: selectionMenuPos.top, left: selectionMenuPos.left }}
                    onClick={(e) => e.stopPropagation()}
                  >
                    {/* Primary Tools */}
                    <div className="flex items-center gap-0.5 px-1">
                      <button 
                        onClick={openCitationModal}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-slate-700 dark:text-slate-200 font-semibold text-[13px] hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      >
                        <span className="font-serif font-bold text-sm text-slate-500">@</span>
                        <span>Cite</span>
                      </button>
                      <button 
                        onClick={() => setIsChatOpen(true)}
                        className="flex items-center gap-1.5 px-3 py-1.5 text-slate-700 dark:text-slate-200 font-semibold text-[13px] hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      >
                        <MessageSquare size={14} className="text-slate-500" />
                        <span>Chat</span>
                      </button>
                      <button className="flex items-center gap-1.5 px-3 py-1.5 text-slate-700 dark:text-slate-200 font-semibold text-[13px] hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors">
                        <Sparkles size={14} className="text-slate-500" />
                        <span>AI Edit</span>
                      </button>
                      <button 
                        onClick={() => setTextMenuOpen(!textMenuOpen)}
                        className="flex items-center gap-2 px-3 py-1.5 text-slate-700 dark:text-slate-200 font-semibold text-[13px] hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors"
                      >
                        <span className="font-serif font-bold text-sm text-slate-500">T</span>
                        <span>Text</span>
                        <ChevronDown size={14} className="text-slate-400" />
                      </button>
                    </div>

                    {/* Divider */}
                    <div className="h-6 w-px bg-slate-100 dark:bg-slate-700 mx-1"></div>

                    {/* Color & Formatting */}
                    <div className="flex items-center gap-0.5 px-1">
                      <button className="flex items-center gap-1 p-2 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors">
                        <div className="w-4 h-4 rounded-full border border-slate-200 dark:border-slate-600 bg-white"></div>
                        <ChevronDown size={12} className="text-slate-400" />
                      </button>
                      <button onClick={() => applyTextFormat('bold')} className="p-2 text-slate-900 dark:text-slate-100 font-bold hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors text-[14px] w-8 h-8 flex items-center justify-center">B</button>
                      <button onClick={() => applyTextFormat('italic')} className="p-2 text-slate-900 dark:text-slate-100 italic font-serif hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors text-[14px] w-8 h-8 flex items-center justify-center">I</button>
                      <button onClick={() => applyTextFormat('underline')} className="p-2 text-slate-900 dark:text-slate-100 underline hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors text-[14px] w-8 h-8 flex items-center justify-center">U</button>
                      <button onClick={() => applyTextFormat('strikethrough')} className="p-2 text-slate-900 dark:text-slate-100 line-through hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors text-[14px] w-8 h-8 flex items-center justify-center">S</button>
                      <button onClick={() => applyTextFormat('code')} className="p-2 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors"><Code size={16}/></button>
                      <button className="p-2 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-700 rounded-lg transition-colors"><LinkIcon size={16}/></button>
                    </div>

                    {/* Selection Word Count */}
                    <div className="pl-3 pr-4 flex items-center">
                      <span className="text-xs font-medium text-slate-400 whitespace-nowrap">{selectedWordCount} {t.words}</span>
                    </div>
                  </div>
                )}

                <div className="h-12 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 flex items-center justify-between px-4 absolute bottom-0 left-0 right-0 z-20">
                    <div className="flex items-center w-1/4">
                        {/* AUTO-SAVE STATUS INDICATOR */}
                        <div className="flex items-center gap-2 px-2 text-[11px] font-medium text-slate-400 animate-in fade-in duration-500">
                            {saveStatus === 'saving' ? (
                                <>
                                    <div className="w-1.5 h-1.5 rounded-full bg-blue-400 animate-pulse"></div>
                                    <span>{t.saving}</span>
                                </>
                            ) : saveStatus === 'saved' ? (
                                <>
                                    <Check size={12} className="text-emerald-500" />
                                    <span>{t.saved}</span>
                                </>
                            ) : null}
                        </div>
                    </div>
                    <div className="flex items-center gap-2 justify-center w-2/4">
                        <div className="flex items-center gap-2 mr-2 cursor-pointer group" onClick={() => setIsAutocompleteOn(!isAutocompleteOn)}>
                            <div className={`relative inline-flex h-4 w-8 items-center rounded-full transition-colors duration-200 ${isAutocompleteOn ? 'bg-[#554de0]' : 'bg-slate-300'}`}><span className={`inline-block h-3 w-3 transform rounded-full bg-white transition duration-200 ${isAutocompleteOn ? 'translate-x-4' : 'translate-x-0.5'}`}/></div>
                            <span className="text-xs font-medium text-slate-700 dark:text-slate-300 select-none">{t.autocomplete}</span>
                        </div>
                        <button onClick={openCitationModal} className="flex items-center gap-1.5 px-2 py-1 rounded hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><AtSign size={14} className="text-slate-700 dark:text-slate-300" /><span className="text-xs font-medium text-slate-700 dark:text-slate-300">{t.cite}</span></button>

                    </div>
                    <div className="text-xs text-slate-400 font-medium w-1/4 text-right">{wordCount} {t.words}</div>
                </div>
            </main>
          )}

          {currentView === 'library' && (
             <main className="flex-1 flex flex-col bg-slate-50 dark:bg-slate-900 overflow-y-auto p-8 custom-scrollbar">
                <div className="max-w-4xl mx-auto w-full">
                    <div className="flex items-center justify-between mb-8 pb-4 border-b border-slate-200 dark:border-slate-800">
                        <div>
                            <div className="flex items-center gap-2 mb-1">
                                <span className="px-2 py-0.5 text-xs font-semibold uppercase tracking-wider bg-indigo-100 dark:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 rounded">ICAI & Statutory Repository</span>
                            </div>
                            <h1 className="text-2xl font-bold text-slate-900 dark:text-white">Statutory & Precedent Library</h1>
                            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Instant reference to primary Indian Tax, Corporate, GST statutes and ICAI Auditing Standards.</p>
                        </div>
                        <button 
                            onClick={() => setCurrentView('editor')} 
                            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors"
                        >
                            Return to Editor
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                        {[
                            {
                                act: "Income Tax Act, 1961",
                                code: "Sec 43B(h), 148A, 68, 56(2)(x)",
                                desc: "Comprehensive clauses on deductions on actual payment, reassessment timelines, unexplained cash credits & angel tax.",
                                count: "298 Sections Indexed",
                                sample: `<p><strong>Statutory Reference: Section 43B(h) of Income-tax Act, 1961</strong><br>Any sum payable by the assessee to a Micro or Small Enterprise beyond the time limit specified in Section 15 of the MSMED Act, 2006 shall be allowed as a deduction only in the previous year in which such sum is actually paid.</p>`
                            },
                            {
                                act: "Central Goods & Services Tax Act, 2017",
                                code: "Sec 16(2)(aa), 17(5), 73/74",
                                desc: "Input Tax Credit eligibility conditions, blocked credits under 17(5), and adjudication notices for non-fraud vs fraud.",
                                count: "174 Sections + 162 Rules",
                                sample: `<p><strong>Statutory Reference: Section 16(2)(aa) of CGST Act, 2017</strong><br>ITC can be availed by a registered recipient only if details of invoice have been furnished by the supplier in GSTR-1 and communicated to the recipient in Form GSTR-2B.</p>`
                            },
                            {
                                act: "Companies Act, 2013 & CARO 2020",
                                code: "Sec 135, 143(12), 185/186",
                                desc: "CSR expenditure compliances, reporting of suspected fraud by statutory auditors, and loan to directors restrictions.",
                                count: "470 Sections + CARO Guidance",
                                sample: `<p><strong>Statutory Reference: Section 143(12) of Companies Act, 2013</strong><br>Auditor must report to Central Government (Form ADT-4) within 60 days if there is reason to believe an offence involving fraud of ₹1 Crore or above is being committed against the company.</p>`
                            },
                            {
                                act: "ICAI Standards on Auditing (SAs)",
                                code: "SA 240, SA 500, SA 570, SA 700",
                                desc: "Auditor's responsibilities relating to fraud, audit evidence sufficiency, going concern evaluations, and modified opinions.",
                                count: "38 Standards on Auditing",
                                sample: `<p><strong>Auditing Guidance: ICAI SA 570 (Revised) - Going Concern</strong><br>The auditor shall evaluate whether sufficient appropriate audit evidence has been obtained regarding, and conclude on, the appropriateness of management's use of the going concern basis of accounting.</p>`
                            },
                        ].map((item, idx) => (
                            <div key={idx} className="bg-white dark:bg-slate-800 p-5 rounded-xl border border-slate-200 dark:border-slate-700 hover:border-indigo-300 dark:hover:border-indigo-600 transition-all shadow-xs">
                                <div className="flex items-start justify-between">
                                    <div>
                                        <h3 className="font-semibold text-slate-900 dark:text-white text-base">{item.act}</h3>
                                        <span className="inline-block text-xs font-mono text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded mt-1">{item.code}</span>
                                    </div>
                                    <span className="text-[11px] text-slate-400 dark:text-slate-500 font-medium">{item.count}</span>
                                </div>
                                <p className="text-xs text-slate-600 dark:text-slate-300 mt-2.5 leading-relaxed">{item.desc}</p>
                                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-700/60 flex items-center justify-between">
                                    <button 
                                        onClick={() => {
                                            insertHtmlAtCursor(item.sample);
                                            setCurrentView('editor');
                                        }}
                                        className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center gap-1"
                                    >
                                        + Insert Clause into Draft
                                    </button>
                                    <button 
                                        onClick={() => {
                                            setIsChatOpen(true);
                                        }}
                                        className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                                    >
                                        Consult Copilot →
                                    </button>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
             </main>
          )}

          {isChatOpen && (
              <ChatPanel 
                onClose={() => setIsChatOpen(false)} 
                documentContent={content} 
                translations={t} 
                onInsertHtml={insertHtmlAtCursor}
                onInsertText={insertTextAtCursor}
              />
          )}
      </div>

      {hoveredCitation && hoverCardPos && (
          <div 
            className="fixed z-50 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl rounded-xl p-4 w-72 md:w-80 animate-in fade-in zoom-in-95 duration-150 pointer-events-none"
            style={{ top: hoverCardPos.top, left: hoverCardPos.left }}
          >
            <div className="flex items-start justify-between gap-2 mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300">
                  {hoveredCitation.type || 'Statute'}
                </span>
                <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  {hoveredCitation.year}
                </span>
            </div>
            <h4 className="text-sm font-bold text-slate-900 dark:text-white leading-snug mb-1">
                {hoveredCitation.title}
            </h4>
            <p className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mb-2">
                {hoveredCitation.journal} {hoveredCitation.authors ? `• ${hoveredCitation.authors}` : ''}
            </p>
            <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-2 rounded-lg border border-slate-100 dark:border-slate-800">
                <span className="line-clamp-3">{hoveredCitation.snippet}</span>
            </div>
          </div>
      )}

      {/* STATUTORY & LEGAL CITATIONS SEARCH POPUP MODAL */}
      {isCitationModalOpen && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 bg-black/60 backdrop-blur-xs animate-in fade-in duration-150"
          onClick={() => setIsCitationModalOpen(false)}
        >
          <div 
            className="citation-modal w-full max-w-4xl max-h-[88vh] bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col overflow-hidden animate-in zoom-in-95 duration-150"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-800/50">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-indigo-600 dark:bg-indigo-500 text-white flex items-center justify-center font-bold text-lg shadow-sm">
                  §
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                      Search Legal & Financial Statutes & Precedents
                    </h2>
                    <span className="text-[11px] font-semibold uppercase tracking-wider bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 px-2 py-0.5 rounded">
                      CA Legal Forms Assistant Knowledge Base
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    Instant statutory citations for Income Tax, GST, Companies Act, ITAT, High Court & Supreme Court rulings
                  </p>
                </div>
              </div>
              <button 
                onClick={() => setIsCitationModalOpen(false)}
                className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                title="Close (Esc)"
              >
                <X size={18} />
              </button>
            </div>

            {/* Search Input & Filter Tabs */}
            <div className="p-6 pb-3 border-b border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 space-y-3">
              {/* Main Search Input */}
              <div className="relative">
                <Search size={18} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <input 
                  type="text"
                  autoFocus
                  value={citationSearchQuery}
                  onChange={(e) => setCitationSearchQuery(e.target.value)}
                  placeholder="Search statutes, sections, case laws, keywords (e.g., 43B(h), 148A, Kelvinator, ITC 16(2), CARO 2020, Checkmate)..."
                  className="w-full pl-10 pr-24 py-2.5 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-xl text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all shadow-inner"
                />
                {citationSearchQuery && (
                  <button 
                    onClick={() => setCitationSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 bg-slate-200 dark:bg-slate-700 rounded-md px-1.5 py-0.5 cursor-pointer"
                  >
                    Clear
                  </button>
                )}
              </div>

              {/* Category Filter Tabs */}
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 custom-scrollbar text-xs font-medium">
                {[
                  { id: 'All', label: 'All Acts & Rulings' },
                  { id: 'Income Tax', label: 'Income Tax (Direct)' },
                  { id: 'GST', label: 'GST & Indirect Tax' },
                  { id: 'Corporate & CARO', label: 'Companies Act & CARO' },
                  { id: 'Case Laws', label: 'Supreme Court & ITAT' },
                  { id: 'ICAI Auditing', label: 'ICAI Standards (SAs)' },
                  { id: 'FEMA & Banking', label: 'FEMA & RBI Master' },
                ].map((tab) => (
                  <button
                    key={tab.id}
                    onClick={() => setCitationCategory(tab.id)}
                    className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all font-medium cursor-pointer ${
                      citationCategory === tab.id
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              {/* Secondary Status & Year row */}
              <div className="flex items-center justify-between pt-1 text-xs text-slate-500 dark:text-slate-400">
                <div className="flex items-center gap-3">
                  <span className="font-semibold text-slate-700 dark:text-slate-300">
                    {citations.length} Authorities Found
                  </span>
                  <span className="text-slate-300 dark:text-slate-700">|</span>
                  <div className="flex items-center gap-1">
                    <span>Filter Timeline:</span>
                    <select
                      value={citationFilterYear || ''}
                      onChange={(e) => setCitationFilterYear(e.target.value ? Number(e.target.value) : null)}
                      className="bg-transparent border border-slate-200 dark:border-slate-700 rounded px-1.5 py-0.5 text-xs text-slate-700 dark:text-slate-300 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                    >
                      <option value="" className="bg-white dark:bg-slate-900">All Recent Years</option>
                      <option value="2024" className="bg-white dark:bg-slate-900">2024 (Finance Act 2024)</option>
                      <option value="2023" className="bg-white dark:bg-slate-900">2023 (Finance Act 2023)</option>
                      <option value="2022" className="bg-white dark:bg-slate-900">2022</option>
                      <option value="2020" className="bg-white dark:bg-slate-900">2020 (CARO 2020)</option>
                    </select>
                  </div>
                </div>

                <div className="hidden sm:flex items-center gap-1 text-[11px] text-slate-400">
                  <span>Authoritative Grounding for CA Opinions & Submissions</span>
                </div>
              </div>
            </div>

            {/* Citations Results List */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4 custom-scrollbar bg-slate-50/40 dark:bg-slate-950/40 min-h-[260px] max-h-[50vh]">
              {isCitationLoading ? (
                <div className="py-16 flex flex-col items-center justify-center text-center">
                  <Loader2 size={32} className="text-indigo-600 animate-spin mb-3" />
                  <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-200">
                    Querying Official Statutory Records & Case Law Repositories...
                  </h4>
                  <p className="text-xs text-slate-400 mt-1 max-w-sm">
                    Cross-referencing CBDT circulars, Supreme Court rulings, ITAT orders & ICAI standards
                  </p>
                </div>
              ) : citations.length === 0 ? (
                <div className="py-16 text-center">
                  <BookOpen size={36} className="mx-auto text-slate-300 dark:text-slate-600 mb-3" />
                  <h4 className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    No matching statutes or citations found
                  </h4>
                  <p className="text-xs text-slate-400 mt-1">
                    Try searching for section numbers like "43B", "148A", "16(2)", or landmark cases like "Kelvinator", "Checkmate".
                  </p>
                  <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                    {['Section 43B(h)', 'Section 148A', 'Checkmate Services', 'CARO 2020', 'Section 16(2)(aa)'].map((suggest) => (
                      <button
                        key={suggest}
                        onClick={() => setCitationSearchQuery(suggest)}
                        className="px-2.5 py-1 text-xs bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 rounded-lg hover:bg-indigo-100 transition-colors cursor-pointer"
                      >
                        {suggest}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                citations.map((cit) => (
                  <div 
                    key={cit.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-300 dark:hover:border-indigo-600 rounded-xl p-4.5 shadow-xs transition-all flex flex-col justify-between group"
                  >
                    <div>
                      {/* Badge Top Row */}
                      <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                            cit.type === 'Statute' 
                              ? 'bg-blue-100 dark:bg-blue-950/70 text-blue-700 dark:text-blue-300'
                              : cit.type === 'Case Law'
                              ? 'bg-amber-100 dark:bg-amber-950/70 text-amber-700 dark:text-amber-300'
                              : 'bg-purple-100 dark:bg-purple-950/70 text-purple-700 dark:text-purple-300'
                          }`}>
                            {cit.type || 'Statute'}
                          </span>
                          <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                            {cit.year}
                          </span>
                          <span className="text-xs text-slate-400 dark:text-slate-500">•</span>
                          <span className="text-xs font-medium text-slate-500 dark:text-slate-400 truncate max-w-[280px]">
                            {cit.journal}
                          </span>
                        </div>
                        {cit.citedBy && (
                          <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/50 px-2 py-0.5 rounded">
                            {cit.citedBy}
                          </span>
                        )}
                      </div>

                      {/* Main Title */}
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                        {cit.title}
                      </h3>
                      <p className="text-xs font-medium text-slate-500 dark:text-slate-400 mt-0.5">
                        Authority / Bench: {cit.authors}
                      </p>

                      {/* Snippet / Ratio */}
                      <p className="text-xs text-slate-600 dark:text-slate-300 mt-2 leading-relaxed bg-slate-50 dark:bg-slate-800/50 p-2.5 rounded-lg border border-slate-100 dark:border-slate-800">
                        {cit.snippet}
                      </p>
                    </div>

                    {/* Action Bar */}
                    <div className="mt-3.5 pt-3 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleCite(cit)}
                          className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold shadow-xs flex items-center gap-1.5 transition-colors cursor-pointer"
                          title="Insert inline parenthetical citation at cursor"
                        >
                          <AtSign size={13} />
                          <span>+ Insert Inline Citation</span>
                        </button>
                        <button
                          onClick={() => handleInsertClause(cit)}
                          className="px-3 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                          title="Insert full statutory quote block into document"
                        >
                          <Plus size={13} />
                          <span>+ Insert Full Clause</span>
                        </button>
                      </div>

                      <button
                        onClick={() => handleCopyCitationText(cit)}
                        className="px-2.5 py-1.5 text-xs text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 flex items-center gap-1 transition-colors cursor-pointer"
                      >
                        {copiedCitationId === cit.id ? (
                          <>
                            <Check size={13} className="text-emerald-500" />
                            <span className="text-emerald-600 dark:text-emerald-400 font-medium">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy size={13} />
                            <span>Copy Citation</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Modal Footer */}
            <div className="px-6 py-3 border-t border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-900 flex items-center justify-between text-xs">
              <span className="text-slate-500 dark:text-slate-400 flex items-center gap-1.5">
                <Bookmark size={13} className="text-indigo-500" />
                Citations adhere to ICAI & Supreme Court legal drafting format.
              </span>
              <button
                onClick={() => setIsCitationModalOpen(false)}
                className="px-4 py-1.5 bg-slate-200 dark:bg-slate-800 hover:bg-slate-300 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 rounded-lg font-medium transition-colors cursor-pointer"
              >
                Done / Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentEditor;
