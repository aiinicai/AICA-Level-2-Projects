import React, { useState, useRef, useEffect } from 'react';
import { 
  Sparkles, ChevronLeft, Plus, FileText, X, ExternalLink,
  MessageSquare, Send, File, Image as ImageIcon, Scale, BookOpen, ShieldCheck
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import ReactMarkdown from 'react-markdown';
import { marked } from 'marked';

interface ChatPanelProps {
  onClose: () => void;
  documentContent: string;
  translations: any;
  onInsertHtml?: (html: string) => void;
  onInsertText?: (text: string) => void;
}

const ChatPanel: React.FC<ChatPanelProps> = ({ onClose, documentContent, translations, onInsertHtml, onInsertText }) => {
  const [input, setInput] = useState('');
  
  const [messages, setMessages] = useState<Array<{role: 'user' | 'ai', content: React.ReactNode, textContent?: string}>>([]);
  
  const [isThinking, setIsThinking] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Context State
  const [activeContexts, setActiveContexts] = useState({
    document: true,
    acts: true,
    itat: true
  });

  const toggleContext = (key: 'document' | 'acts' | 'itat') => {
      setActiveContexts(prev => ({
          ...prev,
          [key]: !prev[key]
      }));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isThinking]);

  const quickQueries = [
    "Draft reply grounds for Sec 148A(b) notice regarding unexplained cash credits u/s 68",
    "Explain Sec 43B(h) 45-day payment timeline and Form 3CD Clause 22 reporting",
    "Analyze GST Sec 16(4) ITC retrospective relief under Finance (No. 2) Act 2024",
    "Draft CARO 2020 audit comment on internal controls & working capital limits"
  ];

  const handleSend = async (overrideInput?: string) => {
    const textToSend = overrideInput || input;
    if (!textToSend.trim()) return;
    
    const userMessage = textToSend;
    
    setMessages(prev => [...prev, { 
        role: 'user', 
        content: (
            <span>{userMessage}</span>
        ),
        textContent: userMessage
    }]);

    setInput('');
    setIsThinking(true);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        let contextInstruction = "";
        if (activeContexts.document) {
            contextInstruction += `\nCURRENT OPINION / DRAFT CONTEXT:\n"${documentContent.slice(0, 6000)}"\n`;
        }
        
        const systemPrompt = `You are CA Legal Forms Assistant, an authoritative and elite legal & statutory laws copilot engineered exclusively for Chartered Accountants (CA), statutory auditors, and tax practitioners.

You have deep, precise expertise across:
1. Income Tax Act, 1961 & Rules (including assessment notices u/s 142(1), 143(2), 148/148A, penalties u/s 270A/271AAC, disallowances u/s 40(a)(ia), 43B, 43B(h), transfer pricing, and capital gains).
2. GST Acts (CGST, SGST, IGST) including ITC conditions u/s 16, SCNs u/s 73/74, refunds, and recent amendments under Finance Act 2024.
3. Companies Act, 2013 & MCA Regulations (CARO 2020 reporting, Section 185/186 loan compliances, Schedule III presentation).
4. ICAI Standards on Auditing (SAs) & Guidance Notes (SA 700, 705, 706, SA 500, SA 240).
5. Landmark Precedents from Supreme Court of India, High Courts, and Income Tax Appellate Tribunal (ITAT) benches.

Guidelines:
- Maintain an authoritative, legally rigorous, and precise professional tone suitable for a Chartered Accountant drafting submissions to the Assessing Officer (AO), CIT(Appeals), or ITAT.
- When answering questions, cite exact Sections, Clauses, sub-sections, CBDT/CBIC Circular numbers, and relevant Case Law citations (e.g. *Rajiv Bansal (SC 2024)*, *Checkmate Services (SC)*, *Mohit Minerals (SC)*).
- Format responses cleanly with bold headings, bulleted objection grounds, statutory excerpts, and actionable draft clauses that can be directly inserted into formal tax submissions.
${contextInstruction}
`;

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: [
                { role: 'user', parts: [{ text: systemPrompt + "\n\nCA Practitioner Inquiry: " + userMessage }] }
            ]
        });

        const text = response.text;
        
        setMessages(prev => [...prev, {
            role: 'ai',
            content: (
                <div className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed space-y-3 px-1">
                    <ReactMarkdown 
                        components={{
                            p: ({node, ...props}) => <p className="mb-2 last:mb-0" {...props} />,
                            ul: ({node, ...props}) => <ul className="space-y-2 list-none" {...props} />,
                            li: ({node, ...props}) => <li className="flex gap-2" {...props}><span className="text-indigo-600 dark:text-indigo-400 font-bold mt-0.5">•</span><span>{props.children}</span></li>,
                            strong: ({node, ...props}) => <strong className="font-bold text-slate-900 dark:text-white" {...props} />,
                            a: ({node, ...props}) => <a className="text-indigo-700 dark:text-indigo-400 hover:underline cursor-pointer" target="_blank" rel="noreferrer" {...props} />,
                            blockquote: ({node, ...props}) => <blockquote className="border-l-2 border-indigo-600 dark:border-indigo-500 pl-3 py-1 my-2 bg-slate-50 dark:bg-slate-800 text-slate-600 dark:text-slate-400 italic" {...props} />,
                        }}
                    >
                        {text || ''}
                    </ReactMarkdown>
                </div>
            ),
            textContent: text
        }]);
    } catch (error) {
        console.error(error);
        setMessages(prev => [...prev, {
            role: 'ai',
            content: "Sorry, I encountered an error while consulting statutory databases.",
            textContent: "Error"
        }]);
    } finally {
        setIsThinking(false);
    }
  };

  const handleCopy = (text: string) => {
      navigator.clipboard.writeText(text);
  };

  const handleInsert = (text: string) => {
      if (onInsertHtml) {
          const html = marked.parse(text, { async: false }) as string;
          onInsertHtml(html);
      } else if (onInsertText) {
          onInsertText(text);
      }
  };

  return (
    <div className="flex flex-col w-[340px] border-l border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900 h-full z-20 font-sans">
        
        {/* Header */}
        <div className="flex justify-between items-center px-5 py-3.5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/50">
            <div className="flex items-center gap-2">
                <ChevronLeft 
                    size={16} 
                    className="text-slate-400 cursor-pointer hover:text-slate-600 dark:hover:text-slate-300" 
                    onClick={onClose}
                />
                <span className="font-bold text-slate-800 dark:text-slate-200 text-xs flex items-center gap-1.5">
                  <Scale size={14} className="text-indigo-700 dark:text-indigo-400" />
                  CA Legal Forms Assistant
                </span>
            </div>
            <div className="flex gap-2.5 text-slate-400">
                <Plus size={15} className="cursor-pointer hover:text-slate-600 dark:hover:text-slate-300" onClick={() => setMessages([])} title="New Session"/>
            </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-5">
            
            {messages.length === 0 && (
                 <div className="flex flex-col gap-3 mt-2">
                    <div className="flex gap-2 items-center text-xs text-indigo-700 dark:text-indigo-400 font-bold px-1">
                        <Sparkles size={14} fill="currentColor" /> CA Legal Forms Assistant
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed px-1 bg-indigo-50/60 dark:bg-indigo-900/30 p-3 rounded-xl border border-indigo-100/80 dark:border-indigo-800/50">
                        {translations?.chatIntro || "Welcome to CA Legal Forms Assistant. I assist with direct tax statutes, GST rulings, ITAT case law research, and statutory notice drafting."}
                    </div>

                    <div className="space-y-2 mt-2">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-1">Quick CA Legal Queries:</p>
                      {quickQueries.map((query, qIdx) => (
                        <button
                          key={qIdx}
                          onClick={() => handleSend(query)}
                          className="w-full text-left p-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-indigo-900/40 hover:border-indigo-200 dark:hover:border-indigo-800 text-[11px] text-slate-700 dark:text-slate-300 leading-snug transition-all shadow-2xs"
                        >
                          {query}
                        </button>
                      ))}
                    </div>
                </div>
            )}

            {messages.map((msg, idx) => (
                <div key={idx} className={`flex flex-col gap-2.5 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                    
                    {msg.role === 'user' ? (
                        <div className="bg-indigo-50 dark:bg-indigo-900/60 text-indigo-950 dark:text-indigo-100 px-3.5 py-2.5 rounded-2xl rounded-tr-sm text-xs leading-relaxed max-w-[92%] shadow-2xs font-medium border border-indigo-100 dark:border-indigo-800/60">
                            {msg.content}
                        </div>
                    ) : (
                        <div className="flex flex-col gap-2.5 w-full">
                            <div className="flex gap-2 items-center text-xs text-indigo-700 dark:text-indigo-400 font-bold px-1">
                                <Sparkles size={14} fill="currentColor" /> CA Legal Forms Assistant
                            </div>
                            <div className="bg-slate-50/70 dark:bg-slate-800/70 p-3 rounded-xl border border-slate-100 dark:border-slate-700 text-slate-700 dark:text-slate-300 text-xs">
                              {msg.content}
                            </div>
                            
                            {/* Action Buttons for AI Message */}
                            <div className="flex gap-2 mt-0.5 px-1">
                                <button 
                                    onClick={() => msg.textContent && handleInsert(msg.textContent)}
                                    className="flex items-center gap-1 text-[10px] font-bold text-indigo-700 dark:text-indigo-400 hover:text-indigo-900 dark:hover:text-indigo-300 transition-colors border border-indigo-200 dark:border-indigo-800 bg-white dark:bg-slate-800 rounded px-2 py-1 shadow-2xs"
                                >
                                    <Plus size={10} strokeWidth={3}/> Insert into draft
                                </button>
                                <button 
                                    onClick={() => msg.textContent && handleCopy(msg.textContent)}
                                    className="flex items-center gap-1 text-[10px] font-bold text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-300 transition-colors border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 rounded px-2 py-1"
                                >
                                    <File size={10}/> Copy
                                </button>
                            </div>
                        </div>
                    )}
                </div>
            ))}

            {isThinking && (
                 <div className="mt-4 pt-2 px-1 flex items-center gap-2 text-[10px] text-slate-400 font-medium">
                     <div className="w-2.5 h-2.5 rounded-full border-2 border-indigo-600 border-t-transparent animate-spin"></div>
                     Consulting Direct Tax, GST & ITAT law databases...
                </div>
            )}
            
            <div ref={messagesEndRef} />
        </div>

        {/* Input Area */}
        <div className="p-3.5 border-t border-slate-100 dark:border-slate-800 bg-white dark:bg-slate-900">
            <div className="flex items-center gap-1.5 mb-2.5 overflow-x-auto pb-1 no-scrollbar">
                <button 
                    onClick={() => toggleContext('document')}
                    className={`flex items-center gap-1 px-2 py-0.5 border rounded-full text-[10px] font-medium whitespace-nowrap transition-colors ${activeContexts.document ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-900/40 dark:border-indigo-800 dark:text-indigo-400 font-semibold' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                >
                    <FileText size={10} /> 
                    Current Draft 
                    {activeContexts.document && <X size={9} className="ml-1 text-indigo-400 hover:text-red-500 cursor-pointer" onClick={(e) => { e.stopPropagation(); toggleContext('document'); }} />}
                </button>
                
                <button 
                    onClick={() => toggleContext('acts')}
                    className={`flex items-center gap-1 px-2 py-0.5 border rounded-full text-[10px] font-medium whitespace-nowrap transition-colors ${activeContexts.acts ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-900/40 dark:border-indigo-800 dark:text-indigo-400 font-semibold' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                >
                    <Scale size={10} /> 
                    Tax Acts & Codes
                </button>
                
                <button 
                    onClick={() => toggleContext('itat')}
                    className={`flex items-center gap-1 px-2 py-0.5 border rounded-full text-[10px] font-medium whitespace-nowrap transition-colors ${activeContexts.itat ? 'bg-indigo-50 border-indigo-200 text-indigo-700 dark:bg-indigo-900/40 dark:border-indigo-800 dark:text-indigo-400 font-semibold' : 'bg-slate-50 dark:bg-slate-800 border-transparent text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-700'}`}
                >
                    <BookOpen size={10} /> 
                    ITAT Rulings
                </button>
            </div>
            
            <div className="relative">
                <textarea 
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyDown={(e) => {
                        if(e.key === 'Enter' && !e.shiftKey) {
                            e.preventDefault();
                            handleSend();
                        }
                    }}
                    className="w-full h-[80px] resize-none border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 text-xs focus:outline-none focus:border-indigo-600 dark:focus:border-indigo-500 focus:ring-1 focus:ring-indigo-600 dark:focus:ring-indigo-500 transition-all pr-10 placeholder:text-slate-400 bg-slate-50/50 dark:bg-slate-800/50 text-slate-900 dark:text-slate-100"
                    placeholder="Ask statutory legal questions or enter section..."
                ></textarea>
                
                <button 
                    onClick={() => handleSend()}
                    disabled={!input.trim() && !isThinking}
                    className="absolute bottom-2 right-2 w-7 h-7 bg-indigo-700 dark:bg-indigo-600 text-white rounded-lg hover:bg-indigo-800 dark:hover:bg-indigo-500 transition-colors flex items-center justify-center shadow-md disabled:opacity-50 disabled:cursor-not-allowed z-10"
                >
                    <Send size={13} className="ml-0.5" />
                </button>
            </div>
        </div>
    </div>
  );
};

export default ChatPanel;
