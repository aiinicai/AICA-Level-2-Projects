from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class Ward(Base):
    __tablename__ = "wards"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    ward_type: Mapped[str | None] = mapped_column(String(50))  # general/icu/maternity/pediatric/...

    rooms: Mapped[list["Room"]] = relationship(back_populates="ward")


class Room(Base):
    __tablename__ = "rooms"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ward_id: Mapped[int] = mapped_column(ForeignKey("wards.id"), nullable=False)
    room_number: Mapped[str] = mapped_column(String(20), nullable=False)

    ward: Mapped["Ward"] = relationship(back_populates="rooms")
    beds: Mapped[list["Bed"]] = relationship(back_populates="room")


class Bed(Base):
    """Bed status: available/occupied/reserved/cleaning/maintenance (spec section 6)."""

    __tablename__ = "beds"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    room_id: Mapped[int] = mapped_column(ForeignKey("rooms.id"), nullable=False)
    bed_number: Mapped[str] = mapped_column(String(20), nullable=False)
    bed_category: Mapped[str] = mapped_column(String(30), default="general")  # general/semi-private/private/icu
    daily_charge: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(20), default="available")
    # available / occupied / reserved / cleaning / maintenance

    room: Mapped["Room"] = relationship(back_populates="beds")


class Admission(Base):
    __tablename__ = "admissions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admission_number: Mapped[str] = mapped_column(String(30), unique=True, nullable=False)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    admission_source: Mapped[str] = mapped_column(String(20), default="opd")
    # opd / emergency / referral / direct
    attending_doctor_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), nullable=False)
    provisional_diagnosis: Mapped[str | None] = mapped_column(String(500))
    bed_id: Mapped[int] = mapped_column(ForeignKey("beds.id"), nullable=False)
    admission_datetime: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    deposit_amount: Mapped[float] = mapped_column(Float, default=0.0)
    consent_obtained: Mapped[bool] = mapped_column(default=False)
    status: Mapped[str] = mapped_column(String(20), default="admitted")  # admitted / discharged / dama / deceased
    discharge_datetime: Mapped[datetime | None] = mapped_column(DateTime)
    discharge_summary: Mapped[str | None] = mapped_column(String(2000))
    follow_up_advice: Mapped[str | None] = mapped_column(String(1000))
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))

    bed_transfers: Mapped[list["BedTransfer"]] = relationship(back_populates="admission")


class BedTransfer(Base):
    __tablename__ = "bed_transfers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admission_id: Mapped[int] = mapped_column(ForeignKey("admissions.id"), nullable=False)
    from_bed_id: Mapped[int | None] = mapped_column(ForeignKey("beds.id"))
    to_bed_id: Mapped[int] = mapped_column(ForeignKey("beds.id"), nullable=False)
    reason: Mapped[str | None] = mapped_column(String(255))
    transferred_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    transferred_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))

    admission: Mapped["Admission"] = relationship(back_populates="bed_transfers")


class NursingNote(Base):
    """Daily rounds / nursing notes / vitals chart entries for an inpatient (spec section 6)."""

    __tablename__ = "nursing_notes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admission_id: Mapped[int] = mapped_column(ForeignKey("admissions.id"), nullable=False)
    note_type: Mapped[str] = mapped_column(String(20), default="nursing")  # nursing / doctor_round / vitals
    note_text: Mapped[str | None] = mapped_column(String(2000))
    recorded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class MedicationAdministration(Base):
    """Medication administration record (MAR) — what was actually given, when, by whom."""

    __tablename__ = "medication_administrations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admission_id: Mapped[int] = mapped_column(ForeignKey("admissions.id"), nullable=False)
    medicine_name: Mapped[str] = mapped_column(String(150), nullable=False)
    dose: Mapped[str | None] = mapped_column(String(50))
    route: Mapped[str | None] = mapped_column(String(30))
    administered_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    administered_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    notes: Mapped[str | None] = mapped_column(String(255))


class DietOrder(Base):
    __tablename__ = "diet_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    admission_id: Mapped[int] = mapped_column(ForeignKey("admissions.id"), nullable=False)
    diet_type: Mapped[str] = mapped_column(String(50), nullable=False)  # normal/diabetic/liquid/NPO/...
    instructions: Mapped[str | None] = mapped_column(String(500))
    ordered_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    ordered_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    is_active: Mapped[bool] = mapped_column(default=True)
