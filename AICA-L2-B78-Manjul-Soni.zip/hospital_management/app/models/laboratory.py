from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class LabTest(Base):
    """Test catalog: individual tests and panels (spec section 8)."""

    __tablename__ = "lab_tests"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    department: Mapped[str | None] = mapped_column(String(100))
    specimen_type: Mapped[str | None] = mapped_column(String(50))
    normal_range: Mapped[str | None] = mapped_column(String(150))
    unit: Mapped[str | None] = mapped_column(String(30))
    result_type: Mapped[str] = mapped_column(String(20), default="numeric")
    # numeric / text / positive_negative / selectable
    price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    turnaround_hours: Mapped[int | None] = mapped_column(Integer)
    is_active: Mapped[bool] = mapped_column(default=True)


class LabOrder(Base):
    __tablename__ = "lab_orders"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    visit_id: Mapped[int | None] = mapped_column(ForeignKey("visits.id"))
    ordered_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    sample_barcode: Mapped[str | None] = mapped_column(String(50))
    ordered_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    items: Mapped[list["LabOrderItem"]] = relationship(back_populates="order")


class LabOrderItem(Base):
    __tablename__ = "lab_order_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_id: Mapped[int] = mapped_column(ForeignKey("lab_orders.id"), nullable=False)
    test_id: Mapped[int] = mapped_column(ForeignKey("lab_tests.id"), nullable=False)
    status: Mapped[str] = mapped_column(String(20), default="ordered")
    # ordered / sample_collected / received / processing / resulted / verified / reported
    collected_at: Mapped[datetime | None] = mapped_column(DateTime)
    received_at: Mapped[datetime | None] = mapped_column(DateTime)

    order: Mapped["LabOrder"] = relationship(back_populates="items")
    result: Mapped["LabResult"] = relationship(back_populates="order_item", uselist=False)


class LabResult(Base):
    __tablename__ = "lab_results"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    order_item_id: Mapped[int] = mapped_column(ForeignKey("lab_order_items.id"), unique=True, nullable=False)
    result_value: Mapped[str | None] = mapped_column(String(255))
    is_abnormal: Mapped[bool] = mapped_column(default=False)
    entered_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    entered_at: Mapped[datetime | None] = mapped_column(DateTime)
    verified_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    verified_at: Mapped[datetime | None] = mapped_column(DateTime)
    revision_of_id: Mapped[int | None] = mapped_column(ForeignKey("lab_results.id"))

    order_item: Mapped["LabOrderItem"] = relationship(back_populates="result")
