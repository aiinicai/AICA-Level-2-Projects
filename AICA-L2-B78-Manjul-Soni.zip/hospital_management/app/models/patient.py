from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Date, DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class Patient(Base):
    """Master patient index. UHID is generated once and never changes (spec 3)."""

    __tablename__ = "patients"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    uhid: Mapped[str] = mapped_column(String(20), unique=True, nullable=False, index=True)

    full_name: Mapped[str] = mapped_column(String(150), nullable=False, index=True)
    gender: Mapped[str] = mapped_column(String(10), nullable=False)
    date_of_birth: Mapped[date | None] = mapped_column(Date)
    age_years: Mapped[int | None] = mapped_column(Integer)

    mobile_number: Mapped[str] = mapped_column(String(20), nullable=False, index=True)
    alternate_number: Mapped[str | None] = mapped_column(String(20))
    email: Mapped[str | None] = mapped_column(String(150))

    address: Mapped[str | None] = mapped_column(String(255))
    city: Mapped[str | None] = mapped_column(String(100))
    state: Mapped[str | None] = mapped_column(String(100))
    pin_code: Mapped[str | None] = mapped_column(String(10))

    blood_group: Mapped[str | None] = mapped_column(String(5))
    marital_status: Mapped[str | None] = mapped_column(String(20))
    occupation: Mapped[str | None] = mapped_column(String(100))
    nationality: Mapped[str | None] = mapped_column(String(50))

    emergency_contact_name: Mapped[str | None] = mapped_column(String(150))
    emergency_contact_relation: Mapped[str | None] = mapped_column(String(50))
    emergency_contact_number: Mapped[str | None] = mapped_column(String(20))
    emergency_contact_email: Mapped[str | None] = mapped_column(String(150))

    govt_id_type: Mapped[str | None] = mapped_column(String(50))
    govt_id_number: Mapped[str | None] = mapped_column(String(50))
    insurance_id: Mapped[str | None] = mapped_column(String(50))

    photo_path: Mapped[str | None] = mapped_column(String(500))

    is_merged_into_id: Mapped[int | None] = mapped_column(ForeignKey("patients.id"), nullable=True)
    # administrator-only merge trail (spec 3): non-null means this record was merged away

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))

    allergies: Mapped[list["PatientAllergy"]] = relationship(back_populates="patient")
    relatives: Mapped[list["PatientRelative"]] = relationship(back_populates="patient")


class PatientRelative(Base):
    """Master of a patient's relatives/next-of-kin contacts — a patient can
    have more than one (spouse, child, guardian, ...), each with their own
    name, mobile number, and email.
    """

    __tablename__ = "patient_relatives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    relation: Mapped[str | None] = mapped_column(String(50))
    mobile_number: Mapped[str | None] = mapped_column(String(20))
    email: Mapped[str | None] = mapped_column(String(150))
    is_primary_contact: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    patient: Mapped["Patient"] = relationship(back_populates="relatives")


class PatientAllergy(Base):
    __tablename__ = "patient_allergies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    allergen: Mapped[str] = mapped_column(String(150), nullable=False)
    reaction: Mapped[str | None] = mapped_column(String(255))
    severity: Mapped[str | None] = mapped_column(String(20))  # mild/moderate/severe
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    patient: Mapped["Patient"] = relationship(back_populates="allergies")


class PatientDocument(Base):
    """Uploaded/scanned file linked to a patient record (spec 13: never store by filename alone)."""

    __tablename__ = "documents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    document_type: Mapped[str] = mapped_column(String(50), nullable=False)  # lab_report, radiology, consent, other
    description: Mapped[str | None] = mapped_column(String(255))
    file_path: Mapped[str] = mapped_column(String(500), nullable=False)
    uploaded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    uploaded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
