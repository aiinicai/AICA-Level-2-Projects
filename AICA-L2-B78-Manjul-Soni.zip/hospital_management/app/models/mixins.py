"""Common audit-trail columns shared by important records (spec section 17)."""
from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Integer, String, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column


class AuditMixin:
    """created_at / updated_at / created_by / status on every important record.

    Records are never hard-deleted: financial and clinical rows are marked
    cancelled/voided with a reason instead (spec 17, 20).
    """

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at: Mapped[datetime] = mapped_column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False
    )
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="active", nullable=False)
    # e.g. active / cancelled / voided / amended
    void_reason: Mapped[str | None] = mapped_column(String(255), nullable=True)
