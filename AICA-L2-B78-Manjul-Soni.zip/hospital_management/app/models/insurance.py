from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class Insurer(Base):
    """TPA / insurance company / corporate tie-up master (spec section 10)."""

    __tablename__ = "insurers"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    insurer_type: Mapped[str] = mapped_column(String(20), default="insurance")  # insurance / corporate / tpa
    contact_person: Mapped[str | None] = mapped_column(String(150))
    phone: Mapped[str | None] = mapped_column(String(20))
    credit_limit: Mapped[float] = mapped_column(Float, default=0.0)
    is_active: Mapped[bool] = mapped_column(default=True)


class InsuranceClaim(Base):
    """Links a credit/insurance invoice to an insurer for tracking approval and settlement."""

    __tablename__ = "insurance_claims"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    invoice_id: Mapped[int] = mapped_column(ForeignKey("invoices.id"), nullable=False)
    insurer_id: Mapped[int] = mapped_column(ForeignKey("insurers.id"), nullable=False)
    policy_or_employee_id: Mapped[str | None] = mapped_column(String(100))
    pre_authorization_number: Mapped[str | None] = mapped_column(String(100))
    claim_amount: Mapped[float] = mapped_column(Float, default=0.0)
    approved_amount: Mapped[float] = mapped_column(Float, default=0.0)
    status: Mapped[str] = mapped_column(String(20), default="submitted")
    # submitted / approved / partially_approved / rejected / settled
    submitted_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    settled_at: Mapped[datetime | None] = mapped_column(DateTime)
    notes: Mapped[str | None] = mapped_column(String(500))
