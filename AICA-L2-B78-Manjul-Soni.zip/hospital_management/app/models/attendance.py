from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class AttendanceLog(Base):
    """Staff attendance record (spec Phase 4: biometric attendance).

    This build has no biometric hardware to talk to, so `method` defaults
    to "manual" (a clock-in/clock-out button in the app). The row shape is
    biometric-ready: a fingerprint/face device's SDK would call the same
    `attendance_service.clock_in()/clock_out()` functions with
    method="biometric" and its own `device_reference` instead of a person
    clicking a button — no schema change needed to plug one in later.
    """

    __tablename__ = "attendance_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    clock_in_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    clock_out_at: Mapped[datetime | None] = mapped_column(DateTime)
    method: Mapped[str] = mapped_column(String(20), default="manual")  # manual / biometric
    device_reference: Mapped[str | None] = mapped_column(String(100))
    notes: Mapped[str | None] = mapped_column(String(255))

    user: Mapped["User"] = relationship("User")
