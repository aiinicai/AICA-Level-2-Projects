"""Import every model module so Base.metadata knows all tables (see database.base.init_db)."""
from app.models.user import Role, User, Permission, AuditLog  # noqa: F401
from app.models.patient import Patient, PatientAllergy, PatientDocument, PatientRelative  # noqa: F401
from app.models.clinical import (  # noqa: F401
    Department,
    Doctor,
    DoctorSchedule,
    Appointment,
    Visit,
    Vitals,
    ClinicalNote,
    Prescription,
    PrescriptionItem,
)
from app.models.billing import Service, Invoice, InvoiceItem, Payment  # noqa: F401
from app.models.appsettings import ApplicationSetting  # noqa: F401
from app.models.inventory import (  # noqa: F401
    Vendor,
    PurchaseOrder,
    PurchaseOrderItem,
    Purchase,
    StockTransaction,
)
from app.models.pharmacy import Medicine, MedicineBatch, PharmacySale, PharmacySaleItem  # noqa: F401
from app.models.laboratory import LabTest, LabOrder, LabOrderItem, LabResult  # noqa: F401
from app.models.ipd import (  # noqa: F401
    Ward,
    Room,
    Bed,
    Admission,
    BedTransfer,
    NursingNote,
    MedicationAdministration,
    DietOrder,
)
from app.models.ot import ProcedureCatalog, OTBooking, OTConsumable  # noqa: F401
from app.models.insurance import Insurer, InsuranceClaim  # noqa: F401
from app.models.attendance import AttendanceLog  # noqa: F401
from app.models.communication import CommunicationLog  # noqa: F401
