from __future__ import annotations

from datetime import date, datetime, time

from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String, Time
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class Department(Base):
    __tablename__ = "departments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)


class Doctor(Base):
    __tablename__ = "doctors"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    user_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    full_name: Mapped[str] = mapped_column(String(150), nullable=False)
    department_id: Mapped[int] = mapped_column(ForeignKey("departments.id"), nullable=False)
    specialization: Mapped[str | None] = mapped_column(String(150))
    registration_number: Mapped[str | None] = mapped_column(String(50))
    consultation_fee: Mapped[float] = mapped_column(Float, default=0.0, nullable=False)
    room_number: Mapped[str | None] = mapped_column(String(20))
    is_active: Mapped[bool] = mapped_column(default=True)

    schedules: Mapped[list["DoctorSchedule"]] = relationship(back_populates="doctor")


class DoctorSchedule(Base):
    """Working hours per weekday, breaks and max appointments per slot (spec 4)."""

    __tablename__ = "doctor_schedules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), nullable=False)
    weekday: Mapped[int] = mapped_column(Integer, nullable=False)  # 0=Monday .. 6=Sunday
    start_time: Mapped[time] = mapped_column(Time, nullable=False)
    end_time: Mapped[time] = mapped_column(Time, nullable=False)
    slot_minutes: Mapped[int] = mapped_column(Integer, default=15)
    max_patients_per_slot: Mapped[int] = mapped_column(Integer, default=1)
    is_working_day: Mapped[bool] = mapped_column(default=True)

    doctor: Mapped["Doctor"] = relationship(back_populates="schedules")


class Appointment(Base):
    __tablename__ = "appointments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    token_number: Mapped[int] = mapped_column(Integer, nullable=False)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), nullable=False)
    appointment_date: Mapped[date] = mapped_column(Date, nullable=False)
    appointment_time: Mapped[time | None] = mapped_column(Time)
    appointment_type: Mapped[str] = mapped_column(String(20), default="walk_in")
    # walk_in / scheduled / referral / follow_up
    status: Mapped[str] = mapped_column(String(20), default="booked")
    # booked / checked_in / in_consultation / completed / cancelled / no_show
    notes: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class Visit(Base):
    """One OPD visit: registration -> vitals -> consultation -> billing."""

    __tablename__ = "visits"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), nullable=False)
    appointment_id: Mapped[int | None] = mapped_column(ForeignKey("appointments.id"))
    visit_date: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    visit_type: Mapped[str] = mapped_column(String(20), default="opd")  # opd / emergency / ipd
    status: Mapped[str] = mapped_column(String(20), default="open")  # open / closed / cancelled
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))


class Vitals(Base):
    __tablename__ = "vitals"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    visit_id: Mapped[int] = mapped_column(ForeignKey("visits.id"), nullable=False)
    height_cm: Mapped[float | None] = mapped_column(Float)
    weight_kg: Mapped[float | None] = mapped_column(Float)
    temperature_c: Mapped[float | None] = mapped_column(Float)
    pulse_bpm: Mapped[int | None] = mapped_column(Integer)
    bp_systolic: Mapped[int | None] = mapped_column(Integer)
    bp_diastolic: Mapped[int | None] = mapped_column(Integer)
    spo2_percent: Mapped[float | None] = mapped_column(Float)
    bmi: Mapped[float | None] = mapped_column(Float)
    recorded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    recorded_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class ClinicalNote(Base):
    """The consultation record. Finalized notes become read-only; amendments are traceable (spec 5)."""

    __tablename__ = "clinical_notes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    visit_id: Mapped[int] = mapped_column(ForeignKey("visits.id"), nullable=False)
    chief_complaints: Mapped[str | None] = mapped_column(String(1000))
    history_of_present_illness: Mapped[str | None] = mapped_column(String(2000))
    past_history: Mapped[str | None] = mapped_column(String(1000))
    examination_findings: Mapped[str | None] = mapped_column(String(2000))
    diagnosis: Mapped[str | None] = mapped_column(String(500))
    icd10_code: Mapped[str | None] = mapped_column(String(20))
    advice: Mapped[str | None] = mapped_column(String(1000))
    follow_up_date: Mapped[date | None] = mapped_column(Date)
    is_finalized: Mapped[bool] = mapped_column(default=False)
    finalized_at: Mapped[datetime | None] = mapped_column(DateTime)
    amended_from_id: Mapped[int | None] = mapped_column(ForeignKey("clinical_notes.id"))
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class Prescription(Base):
    __tablename__ = "prescriptions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    visit_id: Mapped[int] = mapped_column(ForeignKey("visits.id"), nullable=False)
    doctor_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), nullable=False)
    is_finalized: Mapped[bool] = mapped_column(default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    items: Mapped[list["PrescriptionItem"]] = relationship(back_populates="prescription")


class PrescriptionItem(Base):
    __tablename__ = "prescription_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    prescription_id: Mapped[int] = mapped_column(ForeignKey("prescriptions.id"), nullable=False)
    medicine_name: Mapped[str] = mapped_column(String(150), nullable=False)
    dosage: Mapped[str | None] = mapped_column(String(50))
    frequency: Mapped[str | None] = mapped_column(String(50))
    route: Mapped[str | None] = mapped_column(String(30))
    duration_days: Mapped[int | None] = mapped_column(Integer)
    quantity: Mapped[int | None] = mapped_column(Integer)
    food_instruction: Mapped[str | None] = mapped_column(String(20))  # before_food / after_food
    notes: Mapped[str | None] = mapped_column(String(255))

    prescription: Mapped["Prescription"] = relationship(back_populates="items")
