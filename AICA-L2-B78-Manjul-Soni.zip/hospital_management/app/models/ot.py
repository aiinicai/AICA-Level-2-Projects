from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class ProcedureCatalog(Base):
    """Operation theatre / procedure service catalog (spec section 12)."""

    __tablename__ = "procedure_catalog"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    department: Mapped[str | None] = mapped_column(String(100))
    estimated_duration_minutes: Mapped[int | None] = mapped_column(Integer)
    price: Mapped[float] = mapped_column(Float, default=0.0)
    is_active: Mapped[bool] = mapped_column(default=True)


class OTBooking(Base):
    __tablename__ = "ot_bookings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    admission_id: Mapped[int | None] = mapped_column(ForeignKey("admissions.id"))
    procedure_id: Mapped[int] = mapped_column(ForeignKey("procedure_catalog.id"), nullable=False)
    surgeon_id: Mapped[int] = mapped_column(ForeignKey("doctors.id"), nullable=False)
    anesthetist_id: Mapped[int | None] = mapped_column(ForeignKey("doctors.id"))
    nursing_team: Mapped[str | None] = mapped_column(String(255))
    equipment_consumables: Mapped[str | None] = mapped_column(String(500))
    scheduled_at: Mapped[datetime] = mapped_column(DateTime, nullable=False)
    theatre_room: Mapped[str | None] = mapped_column(String(20))
    status: Mapped[str] = mapped_column(String(20), default="scheduled")
    # scheduled / pre_op_ready / in_progress / completed / cancelled
    pre_op_checklist_complete: Mapped[bool] = mapped_column(default=False)
    consent_obtained: Mapped[bool] = mapped_column(default=False)
    procedure_notes: Mapped[str | None] = mapped_column(String(2000))
    post_op_recovery_notes: Mapped[str | None] = mapped_column(String(2000))
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)


class OTConsumable(Base):
    """Consumables/items used during a procedure, posted to the patient's bill (spec section 12)."""

    __tablename__ = "ot_consumables"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    ot_booking_id: Mapped[int] = mapped_column(ForeignKey("ot_bookings.id"), nullable=False)
    description: Mapped[str] = mapped_column(String(255), nullable=False)
    quantity: Mapped[float] = mapped_column(Float, default=1.0)
    unit_price: Mapped[float] = mapped_column(Float, default=0.0)
