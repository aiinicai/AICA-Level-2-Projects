from __future__ import annotations

from datetime import date, datetime

from sqlalchemy import Date, DateTime, Float, ForeignKey, Integer, String
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database.base import Base


class Medicine(Base):
    """Medicine master (spec section 9)."""

    __tablename__ = "medicines"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    generic_name: Mapped[str] = mapped_column(String(150), nullable=False)
    brand_name: Mapped[str | None] = mapped_column(String(150))
    composition: Mapped[str | None] = mapped_column(String(255))
    manufacturer: Mapped[str | None] = mapped_column(String(150))
    dosage_form: Mapped[str | None] = mapped_column(String(50))  # tablet/syrup/injection/...
    strength: Mapped[str | None] = mapped_column(String(50))
    tax_percent: Mapped[float] = mapped_column(Float, default=0.0)
    mrp: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    sale_price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    reorder_level: Mapped[int] = mapped_column(Integer, default=10)
    storage_location: Mapped[str | None] = mapped_column(String(100))
    is_controlled_drug: Mapped[bool] = mapped_column(default=False)
    is_active: Mapped[bool] = mapped_column(default=True)

    batches: Mapped[list["MedicineBatch"]] = relationship(back_populates="medicine")


class MedicineBatch(Base):
    """Batch-wise stock. FEFO (first-expiry, first-out) issue relies on `expiry_date`."""

    __tablename__ = "medicine_batches"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    medicine_id: Mapped[int] = mapped_column(ForeignKey("medicines.id"), nullable=False)
    batch_number: Mapped[str] = mapped_column(String(50), nullable=False)
    expiry_date: Mapped[date] = mapped_column(Date, nullable=False)
    purchase_price: Mapped[float] = mapped_column(Float, nullable=False, default=0.0)
    quantity_in_stock: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    vendor_id: Mapped[int | None] = mapped_column(ForeignKey("vendors.id"))
    received_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    medicine: Mapped["Medicine"] = relationship(back_populates="batches")


class PharmacySale(Base):
    __tablename__ = "pharmacy_sales"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    prescription_id: Mapped[int | None] = mapped_column(ForeignKey("prescriptions.id"))
    patient_id: Mapped[int] = mapped_column(ForeignKey("patients.id"), nullable=False)
    invoice_id: Mapped[int | None] = mapped_column(ForeignKey("invoices.id"))
    is_return: Mapped[bool] = mapped_column(default=False)
    dispensed_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)

    items: Mapped[list["PharmacySaleItem"]] = relationship(back_populates="sale")


class PharmacySaleItem(Base):
    __tablename__ = "pharmacy_sale_items"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    sale_id: Mapped[int] = mapped_column(ForeignKey("pharmacy_sales.id"), nullable=False)
    medicine_id: Mapped[int] = mapped_column(ForeignKey("medicines.id"), nullable=False)
    batch_id: Mapped[int | None] = mapped_column(ForeignKey("medicine_batches.id"))
    quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    unit_price: Mapped[float] = mapped_column(Float, nullable=False)
    substitution_note: Mapped[str | None] = mapped_column(String(255))
    # explicit pharmacist note required when substituting the prescribed medicine (spec 9)

    sale: Mapped["PharmacySale"] = relationship(back_populates="items")
