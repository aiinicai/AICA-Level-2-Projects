from __future__ import annotations

from datetime import datetime

from sqlalchemy import DateTime, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column

from app.database.base import Base


class CommunicationLog(Base):
    """Every SMS / WhatsApp / email notification the app has tried to send
    (spec Phase 4: SMS/WhatsApp/email notifications).

    Real delivery needs a paid provider account (Twilio/Gupshup/etc. for
    SMS and WhatsApp, an SMTP account for email). This build sends real
    email when SMTP is configured in Settings -> Notifications; SMS and
    WhatsApp have no provider wired in, so they are recorded here with
    status="simulated" — the integration point (`communication_service.
    send_notification`) is ready to call a real API once credentials are
    added, without changing any calling code.
    """

    __tablename__ = "communication_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    patient_id: Mapped[int | None] = mapped_column(ForeignKey("patients.id"))
    channel: Mapped[str] = mapped_column(String(20), nullable=False)  # sms / whatsapp / email
    recipient: Mapped[str] = mapped_column(String(150), nullable=False)
    subject: Mapped[str | None] = mapped_column(String(150))
    message: Mapped[str] = mapped_column(Text, nullable=False)
    template_key: Mapped[str | None] = mapped_column(String(50))
    status: Mapped[str] = mapped_column(String(20), default="queued")
    # queued / sent / simulated / failed
    error_message: Mapped[str | None] = mapped_column(String(255))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, nullable=False)
    sent_at: Mapped[datetime | None] = mapped_column(DateTime)
