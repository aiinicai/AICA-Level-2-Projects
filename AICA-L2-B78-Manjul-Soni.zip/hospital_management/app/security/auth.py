"""
Authentication and RBAC helpers.

Passwords are hashed with bcrypt (never stored in plain text, spec 20).
`current_session` holds the logged-in user for the lifetime of the app
process, and is what the UI's role-based menu filtering reads from.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

import bcrypt
from sqlalchemy import select

from app.database.base import session_scope
from app.models.user import AuditLog, Role, User


def hash_password(plain_password: str) -> str:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain_password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(plain_password.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


@dataclass
class SessionUser:
    id: int
    username: str
    full_name: str
    role_name: str
    login_at: _dt.datetime


class AuthError(Exception):
    pass


def login(username: str, password: str) -> SessionUser:
    """Validate credentials, write an audit log entry, and return the session user.

    Raises AuthError with a user-safe message on any failure so the UI can
    show a friendly prompt without leaking whether the username exists.
    """
    with session_scope() as session:
        user = session.execute(select(User).where(User.username == username)).scalar_one_or_none()
        if user is None or not user.is_active or not verify_password(password, user.password_hash):
            session.add(AuditLog(user_id=user.id if user else None, action="login_failed",
                                  details=f"username={username}"))
            raise AuthError("Invalid username or password.")

        role = session.get(Role, user.role_id)
        user.last_login_at = _dt.datetime.utcnow()
        session.add(AuditLog(user_id=user.id, action="login_success"))

        return SessionUser(
            id=user.id,
            username=user.username,
            full_name=user.full_name,
            role_name=role.name if role else "unknown",
            login_at=user.last_login_at,
        )


def logout(user_id: int) -> None:
    with session_scope() as session:
        session.add(AuditLog(user_id=user_id, action="logout"))


def ensure_seed_data() -> None:
    """Create the default roles and an initial administrator account if the
    users table is empty. Lets a fresh install boot straight to a usable login.
    """
    from app.config.settings import ROLES

    with session_scope() as session:
        existing_roles = {r.name: r for r in session.execute(select(Role)).scalars().all()}
        for role_name in ROLES:
            if role_name not in existing_roles:
                role = Role(name=role_name)
                session.add(role)
                session.flush()
                existing_roles[role_name] = role

        any_user = session.execute(select(User)).first()
        if any_user is None:
            admin_role = existing_roles["administrator"]
            session.add(
                User(
                    username="admin",
                    password_hash=hash_password("Admin@123"),
                    full_name="System Administrator",
                    role_id=admin_role.id,
                    must_change_password=True,
                )
            )
