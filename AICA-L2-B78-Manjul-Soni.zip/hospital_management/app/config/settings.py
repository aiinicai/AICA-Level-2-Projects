"""
Central configuration for the Hospital Management System.

Keeps all paths, constants and tunables in one place so nothing
important is hard-coded inside business logic or UI code.
"""
from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Base directories
# ---------------------------------------------------------------------------
# APP_ROOT = .../hospital_management
APP_ROOT = Path(__file__).resolve().parent.parent.parent

DATA_DIR = APP_ROOT / "data"
DOCUMENTS_DIR = APP_ROOT / "documents"
LOGS_DIR = APP_ROOT / "logs"
BACKUPS_DIR = APP_ROOT / "backups"

for _d in (DATA_DIR, DOCUMENTS_DIR, LOGS_DIR, BACKUPS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Database
# ---------------------------------------------------------------------------
DATABASE_FILE = DATA_DIR / "hms.db"
DATABASE_URL = os.environ.get("HMS_DATABASE_URL", f"sqlite:///{DATABASE_FILE}")

# ---------------------------------------------------------------------------
# Application constants
# ---------------------------------------------------------------------------
APP_NAME = "AICA-L2 HMS"
APP_FULL_NAME = "AICA-L2 HMS — Hospital Management System"
APP_VERSION = "0.1.0-mvp"
APP_LOGO_PATH = APP_ROOT / "app" / "ui" / "themes" / "logo.png"

HOSPITAL_NAME = os.environ.get("HMS_HOSPITAL_NAME", "My Hospital / Clinic")
HOSPITAL_ADDRESS = os.environ.get("HMS_HOSPITAL_ADDRESS", "Address line, City, State, PIN")
HOSPITAL_GSTIN = os.environ.get("HMS_HOSPITAL_GSTIN", "")

# Tax is configurable, never hard-coded into billing calculations.
DEFAULT_TAX_PERCENT = float(os.environ.get("HMS_DEFAULT_TAX_PERCENT", "0"))

# UHID / invoice / admission number formatting
UHID_PREFIX = "UHID"
INVOICE_PREFIX = "INV"
ADMISSION_PREFIX = "ADM"

# Session
SESSION_IDLE_TIMEOUT_MINUTES = int(os.environ.get("HMS_IDLE_TIMEOUT_MIN", "10"))

# Backup retention policy (section 21 of spec)
BACKUP_RETENTION = {
    "daily": 7,
    "weekly": 4,
    "monthly": 12,
}

ROLES = [
    "administrator",
    "receptionist",
    "doctor",
    "nurse",
    "pharmacist",
    "lab_technician",
    "accountant",
    "store_manager",
    "ward_boy",
    "housekeeping",
    "intern",
]
