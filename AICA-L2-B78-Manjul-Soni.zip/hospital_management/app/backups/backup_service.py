"""
Local backup and restore (spec section 21).

A backup is a dated zip containing the SQLite database file, the uploaded
documents folder, and application settings. Retention trims old backups to
the policy in app.config.settings.BACKUP_RETENTION.
"""
from __future__ import annotations

import datetime as _dt
import shutil
import zipfile
from pathlib import Path

from app.config import settings


def create_backup(created_by_id: int | None = None) -> Path:
    timestamp = _dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = settings.BACKUPS_DIR / f"hms_backup_{timestamp}.zip"

    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as archive:
        if settings.DATABASE_FILE.exists():
            archive.write(settings.DATABASE_FILE, arcname=f"data/{settings.DATABASE_FILE.name}")
        for path in settings.DOCUMENTS_DIR.rglob("*"):
            if path.is_file():
                archive.write(path, arcname=f"documents/{path.relative_to(settings.DOCUMENTS_DIR)}")

    _apply_retention()

    # Imported lazily to avoid a hard dependency for callers that only need
    # backups before the database (and therefore audit_service) is ready.
    from app.services.audit_service import record_audit_event
    from app.services.sync_service import sync_backup_if_enabled

    synced_path = sync_backup_if_enabled(backup_path)
    details = str(backup_path) + (f" (synced to {synced_path})" if synced_path else "")
    record_audit_event(action="backup_created", user_id=created_by_id, details=details)
    return backup_path


def _apply_retention() -> None:
    """Keep last N daily backups per app.config.settings.BACKUP_RETENTION['daily'].

    Weekly/monthly tiers are left as a documented extension point: a real
    deployment would tag backups by cadence when they are created and prune
    each tier independently.
    """
    backups = sorted(settings.BACKUPS_DIR.glob("hms_backup_*.zip"), reverse=True)
    keep = settings.BACKUP_RETENTION.get("daily", 7)
    for stale in backups[keep:]:
        stale.unlink(missing_ok=True)


def restore_backup(backup_zip_path: str, restored_by_id: int | None = None) -> Path:
    """Restore the database and documents from a backup zip.

    A safety backup of the CURRENT state is taken first so a bad restore
    can itself be undone (spec 21). Callers must ensure this is only
    reachable to administrators.
    """
    safety_backup = create_backup(created_by_id=restored_by_id)

    with zipfile.ZipFile(backup_zip_path, "r") as archive:
        archive.extractall(settings.APP_ROOT.parent / "_restore_tmp")

    restore_tmp = settings.APP_ROOT.parent / "_restore_tmp"
    restored_db = restore_tmp / "data" / settings.DATABASE_FILE.name
    if restored_db.exists():
        shutil.copy2(restored_db, settings.DATABASE_FILE)

    restored_docs = restore_tmp / "documents"
    if restored_docs.exists():
        for path in restored_docs.rglob("*"):
            if path.is_file():
                target = settings.DOCUMENTS_DIR / path.relative_to(restored_docs)
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(path, target)

    shutil.rmtree(restore_tmp, ignore_errors=True)

    from app.services.audit_service import record_audit_event
    record_audit_event(action="backup_restored", user_id=restored_by_id, details=str(backup_zip_path))
    return safety_backup
