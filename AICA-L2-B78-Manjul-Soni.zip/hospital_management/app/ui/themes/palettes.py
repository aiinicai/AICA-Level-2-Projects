"""
Six named colour themes, each with a light and a dark variant.

`heritage` is the house theme requested for AICA-L2 HMS: beige as the
dominant surface (~40% of the screen), golden borders, leaf-green used
sparingly (~15%, on primary actions and active states) as text-box
white, and the logo's teal worked into headers/branding. The remaining
five themes are alternate colour combinations a hospital could switch to,
each also carrying its own light/dark pair.

Every palette exposes the same token names so `qss.py` can build one
stylesheet template from any of them. Status colours (success/warning/
danger/neutral) stay close to spec section 18's green/yellow/red/grey
convention across every theme so meaning doesn't shift when the theme does.
"""
from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Palette:
    name: str
    mode: str  # "light" or "dark"
    background: str        # ~40% dominant surface (window background)
    surface: str            # cards/group boxes
    textbox: str             # input field background
    border: str               # borders/frames (the "golden border" role)
    accent: str                # primary buttons / active nav (the "leaf green" role)
    accent_text: str             # text colour drawn on top of `accent`
    brand: str                     # logo colour, used on header bar / titles
    text_primary: str
    text_secondary: str
    sidebar_bg: str
    sidebar_active: str
    success: str = "#3C9A5F"
    warning: str = "#E0A93C"
    danger: str = "#D64545"
    neutral: str = "#9AA0A6"


THEMES: dict[str, dict[str, Palette]] = {
    "heritage": {
        "light": Palette(
            name="Heritage", mode="light",
            background="#F3ECD8",   # beige, ~40% of the UI
            surface="#F8F4E8",
            textbox="#FFFFFF",       # white text boxes, as requested
            border="#C9A227",         # golden borders
            accent="#4C7A3F",          # leaf green, used sparingly (buttons/active tab)
            accent_text="#FFFFFF",
            brand="#0D575E",            # the logo's teal
            text_primary="#2B2B22",
            text_secondary="#6B6B55",
            sidebar_bg="#EFE6CC",
            sidebar_active="#4C7A3F",
        ),
        "dark": Palette(
            name="Heritage", mode="dark",
            background="#2A2416",
            surface="#332C1B",
            textbox="#3D3521",
            border="#E0B84B",
            accent="#6FAE5C",
            accent_text="#12200F",
            brand="#3FB9B2",
            text_primary="#F1E9D2",
            text_secondary="#C8BE9C",
            sidebar_bg="#221D11",
            sidebar_active="#6FAE5C",
        ),
    },
    "ocean_teal": {
        "light": Palette(
            name="Ocean Teal", mode="light",
            background="#EAF6F6", surface="#FFFFFF", textbox="#FFFFFF",
            border="#2E8B95", accent="#2E8B95", accent_text="#FFFFFF",
            brand="#0D575E", text_primary="#173538", text_secondary="#4C6C6E",
            sidebar_bg="#DCEFEF", sidebar_active="#2E8B95",
        ),
        "dark": Palette(
            name="Ocean Teal", mode="dark",
            background="#0E2A2E", surface="#123638", textbox="#153E40",
            border="#4FC3C7", accent="#4FC3C7", accent_text="#062023",
            brand="#7BDBDD", text_primary="#DFF4F4", text_secondary="#9FC9CA",
            sidebar_bg="#0A2124", sidebar_active="#4FC3C7",
        ),
    },
    "slate_clinical": {
        "light": Palette(
            name="Slate Clinical", mode="light",
            background="#F0F2F5", surface="#FFFFFF", textbox="#FFFFFF",
            border="#7C8798", accent="#3D6EFF", accent_text="#FFFFFF",
            brand="#22314F", text_primary="#202634", text_secondary="#5B6472",
            sidebar_bg="#E3E7ED", sidebar_active="#3D6EFF",
        ),
        "dark": Palette(
            name="Slate Clinical", mode="dark",
            background="#1B1F27", surface="#232833", textbox="#2A303C",
            border="#93A0B4", accent="#6D93FF", accent_text="#0D1420",
            brand="#9FB2D8", text_primary="#E7EAF0", text_secondary="#AAB3C2",
            sidebar_bg="#161A21", sidebar_active="#6D93FF",
        ),
    },
    "coral_care": {
        "light": Palette(
            name="Coral Care", mode="light",
            background="#FFF3EE", surface="#FFFFFF", textbox="#FFFFFF",
            border="#E08E6B", accent="#2F9E7A", accent_text="#FFFFFF",
            brand="#0D575E", text_primary="#3A2A22", text_secondary="#8A6A5C",
            sidebar_bg="#FBE4D8", sidebar_active="#2F9E7A",
        ),
        "dark": Palette(
            name="Coral Care", mode="dark",
            background="#2B1D17", surface="#382519", textbox="#402B1C",
            border="#F0A57C", accent="#57C9A2", accent_text="#0E2019",
            brand="#5FD0CB", text_primary="#F5E4DB", text_secondary="#D2B4A4",
            sidebar_bg="#22160F", sidebar_active="#57C9A2",
        ),
    },
    "emerald_care": {
        "light": Palette(
            name="Emerald Care", mode="light",
            background="#EAF7EE", surface="#FFFFFF", textbox="#FFFFFF",
            border="#2F9E5C", accent="#C9A227", accent_text="#3A2E05",
            brand="#0D575E", text_primary="#1C2B21", text_secondary="#547560",
            sidebar_bg="#DCF0E2", sidebar_active="#2F9E5C",
        ),
        "dark": Palette(
            name="Emerald Care", mode="dark",
            background="#0F231A", surface="#163123", textbox="#1B3B2A",
            border="#4FBE7E", accent="#E0B84B", accent_text="#2E2405",
            brand="#3FB9B2", text_primary="#DFF3E6", text_secondary="#A9CBB4",
            sidebar_bg="#0B1B14", sidebar_active="#4FBE7E",
        ),
    },
    "royal_indigo": {
        "light": Palette(
            name="Royal Indigo", mode="light",
            background="#EFF0FA", surface="#FFFFFF", textbox="#FFFFFF",
            border="#5B4E9E", accent="#5B4E9E", accent_text="#FFFFFF",
            brand="#E0A93C", text_primary="#241F3D", text_secondary="#5E5580",
            sidebar_bg="#E1E0F3", sidebar_active="#5B4E9E",
        ),
        "dark": Palette(
            name="Royal Indigo", mode="dark",
            background="#1A1730", surface="#221D3D", textbox="#2A2449",
            border="#9C8FE0", accent="#9C8FE0", accent_text="#140F29",
            brand="#F0C05C", text_primary="#E9E6F7", text_secondary="#B4AAD6",
            sidebar_bg="#141227", sidebar_active="#9C8FE0",
        ),
    },
}

THEME_NAMES = list(THEMES.keys())
DEFAULT_THEME = "heritage"
DEFAULT_MODE = "light"


def get_palette(theme_name: str, mode: str) -> Palette:
    theme = THEMES.get(theme_name, THEMES[DEFAULT_THEME])
    return theme.get(mode, theme[DEFAULT_MODE])
