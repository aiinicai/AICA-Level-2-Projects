"""
Applies a palette to the running QApplication and persists the user's
choice (theme name + light/dark mode) in the application_settings table so
it survives a restart.
"""
from __future__ import annotations

from app.config import settings as app_settings
from app.services.settings_service import get_setting, set_setting
from app.ui.themes.palettes import DEFAULT_MODE, DEFAULT_THEME, THEME_NAMES, get_palette
from app.ui.themes.qss import build_stylesheet

THEME_SETTING_KEY = "ui_theme_name"
MODE_SETTING_KEY = "ui_theme_mode"


def load_theme_choice() -> tuple[str, str]:
    theme_name = get_setting(THEME_SETTING_KEY, DEFAULT_THEME)
    mode = get_setting(MODE_SETTING_KEY, DEFAULT_MODE)
    if theme_name not in THEME_NAMES:
        theme_name = DEFAULT_THEME
    if mode not in ("light", "dark"):
        mode = DEFAULT_MODE
    return theme_name, mode


def save_theme_choice(theme_name: str, mode: str) -> None:
    set_setting(THEME_SETTING_KEY, theme_name)
    set_setting(MODE_SETTING_KEY, mode)


def apply_theme(qt_app, theme_name: str, mode: str) -> None:
    palette = get_palette(theme_name, mode)
    qt_app.setStyleSheet(build_stylesheet(palette))


def apply_saved_theme(qt_app) -> tuple[str, str]:
    theme_name, mode = load_theme_choice()
    apply_theme(qt_app, theme_name, mode)
    return theme_name, mode
