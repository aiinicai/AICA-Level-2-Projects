"""Builds a Qt stylesheet string from a Palette (see palettes.py)."""
from __future__ import annotations

from app.ui.themes.palettes import Palette


def build_stylesheet(p: Palette) -> str:
    return f"""
    QWidget {{
        background-color: {p.background};
        color: {p.text_primary};
        font-size: 13px;
    }}

    QMainWindow {{
        background-color: {p.background};
    }}

    QGroupBox {{
        background-color: {p.surface};
        border: 1px solid {p.border};
        border-radius: 8px;
        margin-top: 14px;
        padding: 10px;
        font-weight: 600;
    }}
    QGroupBox::title {{
        subcontrol-origin: margin;
        left: 10px;
        padding: 0 6px;
        color: {p.brand};
    }}

    QLabel {{
        background: transparent;
        color: {p.text_primary};
    }}

    QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit, QTextEdit, QPlainTextEdit {{
        background-color: {p.textbox};
        border: 1px solid {p.border};
        border-radius: 5px;
        padding: 4px 6px;
        color: {p.text_primary};
        selection-background-color: {p.accent};
        selection-color: {p.accent_text};
    }}
    QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus,
    QDateEdit:focus, QTextEdit:focus, QPlainTextEdit:focus {{
        border: 2px solid {p.accent};
    }}

    QPushButton {{
        background-color: {p.accent};
        color: {p.accent_text};
        border: 1px solid {p.border};
        border-radius: 6px;
        padding: 6px 14px;
        font-weight: 600;
    }}
    QPushButton:hover {{
        background-color: {p.brand};
        color: {p.accent_text};
    }}
    QPushButton:pressed {{
        background-color: {p.border};
    }}
    QPushButton:disabled {{
        background-color: {p.neutral};
        color: {p.surface};
        border: 1px solid {p.neutral};
    }}

    QListWidget, QTableWidget, QTreeWidget {{
        background-color: {p.textbox};
        border: 1px solid {p.border};
        border-radius: 6px;
        alternate-background-color: {p.surface};
    }}
    QHeaderView::section {{
        background-color: {p.surface};
        color: {p.brand};
        border: 1px solid {p.border};
        padding: 4px;
        font-weight: 600;
    }}

    QListWidget#Sidebar {{
        background-color: {p.sidebar_bg};
        border: none;
        border-right: 2px solid {p.border};
        font-weight: 600;
        padding-top: 8px;
    }}
    QListWidget#Sidebar::item {{
        padding: 10px 14px;
        border-radius: 0px;
    }}
    QListWidget#Sidebar::item:selected {{
        background-color: {p.sidebar_active};
        color: {p.accent_text};
        border-left: 4px solid {p.brand};
    }}

    QStatusBar {{
        background-color: {p.surface};
        border-top: 1px solid {p.border};
        color: {p.text_secondary};
    }}

    QTabBar::tab {{
        background: {p.surface};
        border: 1px solid {p.border};
        padding: 6px 12px;
        border-top-left-radius: 6px;
        border-top-right-radius: 6px;
    }}
    QTabBar::tab:selected {{
        background: {p.accent};
        color: {p.accent_text};
    }}

    QScrollBar:vertical {{
        background: {p.background};
        width: 12px;
    }}
    QScrollBar::handle:vertical {{
        background: {p.border};
        border-radius: 5px;
        min-height: 24px;
    }}

    /* Status colour helpers — set dynamically via setProperty("status", ...) */
    QLabel[status="success"] {{ color: {p.success}; font-weight: 600; }}
    QLabel[status="warning"] {{ color: {p.warning}; font-weight: 600; }}
    QLabel[status="danger"]  {{ color: {p.danger}; font-weight: 600; }}
    QLabel[status="neutral"] {{ color: {p.neutral}; font-weight: 600; }}
    """
