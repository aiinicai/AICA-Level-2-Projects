from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.appointment_service import doctor_queue_for_date, get_doctor_by_user_id, list_doctors
from app.services.clinical_service import (
    complete_visit,
    create_prescription,
    finalize_clinical_note,
    finalize_prescription,
    get_visit_for_appointment,
    list_notes_for_visit,
    list_prescriptions_for_visit,
    record_vitals,
    save_clinical_note,
)
from app.services.patient_service import get_patient
from app.services.pdf_service import generate_prescription_pdf
from app.ui.label_utils import add_choice_items, humanize


class ConsultationScreen(QWidget):
    """OPD consultation: vitals, clinical notes, and prescriptions against a
    checked-in visit (spec section 5).

    Before this screen existed, `clinical_service.py` had a complete,
    tested service layer (vitals, notes, prescriptions, finalize/amend) with
    no UI anywhere calling it — a doctor had no way to actually use it. A
    patient must first be checked in from the Appointments screen ("Check
    in (start visit)"), which opens the Visit this screen charts against.
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._visit_id = None
        self._patient_id = None
        self._doctor_id = None
        self._prescription_lines: list[dict] = []
        self._prescription_ids_by_row: dict[int, int] = {}
        self._selected_prescription_id = None
        self._last_prescription_id = None
        self._build_ui()
        self._init_doctor_selection()
        self._refresh_queue()

    def _build_ui(self) -> None:
        outer = QHBoxLayout(self)
        splitter = QSplitter()
        outer.addWidget(splitter)

        splitter.addWidget(self._build_queue_panel())
        splitter.addWidget(self._build_charting_panel())

    def _build_queue_panel(self) -> QWidget:
        box = QGroupBox("Checked-in patients")
        layout = QVBoxLayout(box)

        self.doctor_combo = QComboBox()
        for doctor in list_doctors():
            self.doctor_combo.addItem(doctor.full_name, userData=doctor.id)
        self.doctor_combo.currentIndexChanged.connect(self._refresh_queue)
        layout.addWidget(QLabel("Doctor"))
        layout.addWidget(self.doctor_combo)

        self.queue_date = QDateEdit(calendarPopup=True)
        self.queue_date.setDate(_dt.date.today())
        self.queue_date.dateChanged.connect(self._refresh_queue)
        layout.addWidget(QLabel("Date"))
        layout.addWidget(self.queue_date)

        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_queue)
        layout.addWidget(refresh_button)

        self.queue_list = QListWidget()
        self.queue_list.itemClicked.connect(self._select_queue_entry)
        self.queue_list.itemActivated.connect(self._select_queue_entry)
        layout.addWidget(self.queue_list)

        self.selected_label = QLabel("No patient selected — check in from Appointments first.")
        self.selected_label.setWordWrap(True)
        layout.addWidget(self.selected_label)

        return box

    def _init_doctor_selection(self) -> None:
        """A doctor's own login (linked when their account was created in
        Settings -> Staff / users) defaults straight to their own queue and
        locks the doctor picker; anyone else (administrator) can pick any
        doctor's queue.
        """
        if self.session_user.role_name != "doctor":
            return
        own_doctor = get_doctor_by_user_id(self.session_user.id)
        if own_doctor is None:
            return
        index = self.doctor_combo.findData(own_doctor.id)
        if index >= 0:
            self.doctor_combo.setCurrentIndex(index)
        self.doctor_combo.setEnabled(False)

    def _build_charting_panel(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        tabs = QTabWidget()
        layout.addWidget(tabs)

        tabs.addTab(self._build_vitals_tab(), "Vitals")
        tabs.addTab(self._build_note_tab(), "Clinical note")
        tabs.addTab(self._build_prescription_tab(), "Prescription")

        complete_button = QPushButton("Complete visit")
        complete_button.clicked.connect(self._complete_visit)
        layout.addWidget(complete_button)

        return box

    # -- Vitals -----------------------------------------------------------
    def _build_vitals_tab(self) -> QWidget:
        box = QWidget()
        form = QFormLayout(box)

        self.vit_height = QDoubleSpinBox()
        self.vit_height.setMaximum(300)
        self.vit_weight = QDoubleSpinBox()
        self.vit_weight.setMaximum(500)
        self.vit_temp = QDoubleSpinBox()
        self.vit_temp.setRange(30, 45)
        self.vit_temp.setValue(37.0)
        self.vit_pulse = QSpinBox()
        self.vit_pulse.setRange(0, 300)
        self.vit_bp_sys = QSpinBox()
        self.vit_bp_sys.setRange(0, 300)
        self.vit_bp_dia = QSpinBox()
        self.vit_bp_dia.setRange(0, 200)
        self.vit_spo2 = QDoubleSpinBox()
        self.vit_spo2.setRange(0, 100)
        self.vit_spo2.setValue(98)

        form.addRow("Height (cm)", self.vit_height)
        form.addRow("Weight (kg)", self.vit_weight)
        form.addRow("Temperature (C)", self.vit_temp)
        form.addRow("Pulse (bpm)", self.vit_pulse)
        form.addRow("BP systolic", self.vit_bp_sys)
        form.addRow("BP diastolic", self.vit_bp_dia)
        form.addRow("SpO2 (%)", self.vit_spo2)

        save_button = QPushButton("Save vitals")
        save_button.clicked.connect(self._save_vitals)
        form.addRow(save_button)

        return box

    def _save_vitals(self) -> None:
        if not self._require_visit():
            return
        record_vitals(
            visit_id=self._visit_id, recorded_by_id=self.session_user.id,
            height_cm=self.vit_height.value() or None, weight_kg=self.vit_weight.value() or None,
            temperature_c=self.vit_temp.value() or None, pulse_bpm=self.vit_pulse.value() or None,
            bp_systolic=self.vit_bp_sys.value() or None, bp_diastolic=self.vit_bp_dia.value() or None,
            spo2_percent=self.vit_spo2.value() or None,
        )
        QMessageBox.information(self, "Vitals saved", "Vitals recorded for this visit.")

    # -- Clinical note ------------------------------------------------------
    def _build_note_tab(self) -> QWidget:
        box = QWidget()
        form = QFormLayout(box)

        self.note_chief_complaints = QPlainTextEdit()
        self.note_history = QPlainTextEdit()
        self.note_past_history = QPlainTextEdit()
        self.note_examination = QPlainTextEdit()
        self.note_diagnosis = QLineEdit()
        self.note_icd10 = QLineEdit()
        self.note_icd10.setPlaceholderText("ICD-10 code (optional)")
        self.note_advice = QPlainTextEdit()
        self.note_follow_up = QDateEdit(calendarPopup=True)
        self.note_follow_up.setDate(_dt.date.today())
        self.note_follow_up.setSpecialValueText(" ")

        for widget in (self.note_chief_complaints, self.note_history, self.note_past_history, self.note_examination, self.note_advice):
            widget.setMaximumHeight(60)

        form.addRow("Chief complaints", self.note_chief_complaints)
        form.addRow("History of present illness", self.note_history)
        form.addRow("Past history", self.note_past_history)
        form.addRow("Examination findings", self.note_examination)
        form.addRow("Diagnosis", self.note_diagnosis)
        form.addRow("ICD-10 code", self.note_icd10)
        form.addRow("Advice", self.note_advice)
        form.addRow("Follow-up date", self.note_follow_up)

        save_button = QPushButton("Save note (draft)")
        save_button.clicked.connect(self._save_note)
        form.addRow(save_button)

        self.notes_list = QListWidget()
        self.notes_list.setMaximumHeight(90)
        form.addRow(QLabel("Notes on this visit:"))
        form.addRow(self.notes_list)

        return box

    def _save_note(self) -> None:
        if not self._require_visit():
            return
        note = save_clinical_note(
            visit_id=self._visit_id, created_by_id=self.session_user.id,
            chief_complaints=self.note_chief_complaints.toPlainText() or None,
            history_of_present_illness=self.note_history.toPlainText() or None,
            past_history=self.note_past_history.toPlainText() or None,
            examination_findings=self.note_examination.toPlainText() or None,
            diagnosis=self.note_diagnosis.text() or None,
            icd10_code=self.note_icd10.text() or None,
            advice=self.note_advice.toPlainText() or None,
            follow_up_date=self.note_follow_up.date().toPython(),
        )
        finalize_clinical_note(note.id)
        self._refresh_notes()
        QMessageBox.information(self, "Note saved", "Clinical note saved and finalized for this visit.")

    def _refresh_notes(self) -> None:
        self.notes_list.clear()
        if self._visit_id is None:
            return
        for note in list_notes_for_visit(self._visit_id):
            self.notes_list.addItem(f"{note.created_at:%Y-%m-%d %H:%M} — {note.diagnosis or 'no diagnosis recorded'}")

    # -- Prescription -------------------------------------------------------
    def _build_prescription_tab(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        form = QFormLayout()

        self.rx_medicine_name = QLineEdit()
        self.rx_dosage = QLineEdit()
        self.rx_dosage.setPlaceholderText("e.g. 500mg")
        self.rx_frequency = QLineEdit()
        self.rx_frequency.setPlaceholderText("e.g. 1-0-1")
        self.rx_route = QLineEdit()
        self.rx_route.setPlaceholderText("e.g. oral")
        self.rx_duration = QSpinBox()
        self.rx_duration.setRange(0, 365)
        self.rx_quantity = QSpinBox()
        self.rx_quantity.setRange(0, 10000)
        self.rx_food = QComboBox()
        add_choice_items(self.rx_food, ["before_food", "after_food"])

        form.addRow("Medicine name*", self.rx_medicine_name)
        form.addRow("Dosage", self.rx_dosage)
        form.addRow("Frequency", self.rx_frequency)
        form.addRow("Route", self.rx_route)
        form.addRow("Duration (days)", self.rx_duration)
        form.addRow("Quantity", self.rx_quantity)
        form.addRow("Food instruction", self.rx_food)

        add_line_button = QPushButton("Add to prescription")
        add_line_button.clicked.connect(self._add_prescription_line)
        form.addRow(add_line_button)
        layout.addLayout(form)

        self.rx_line_list = QListWidget()
        self.rx_line_list.setMaximumHeight(80)
        layout.addWidget(self.rx_line_list)

        save_rx_button = QPushButton("Save && finalize prescription")
        save_rx_button.clicked.connect(self._save_prescription)
        layout.addWidget(save_rx_button)

        self.prescriptions_list = QListWidget()
        self.prescriptions_list.itemClicked.connect(self._select_prescription)
        self.prescriptions_list.itemActivated.connect(self._select_prescription)
        layout.addWidget(QLabel("Prescriptions on this visit (click one, then print):"))
        layout.addWidget(self.prescriptions_list)

        print_rx_button = QPushButton("Print prescription (PDF)...")
        print_rx_button.clicked.connect(self._print_prescription_pdf)
        layout.addWidget(print_rx_button)

        return box

    def _add_prescription_line(self) -> None:
        if not self.rx_medicine_name.text().strip():
            QMessageBox.warning(self, "Add to prescription", "Medicine name is required.")
            return
        line = {
            "medicine_name": self.rx_medicine_name.text().strip(),
            "dosage": self.rx_dosage.text() or None,
            "frequency": self.rx_frequency.text() or None,
            "route": self.rx_route.text() or None,
            "duration_days": self.rx_duration.value() or None,
            "quantity": self.rx_quantity.value() or None,
            "food_instruction": self.rx_food.currentData(),
        }
        self._prescription_lines.append(line)
        self.rx_line_list.addItem(
            f"{line['medicine_name']} {line['dosage'] or ''} {line['frequency'] or ''}".strip()
        )
        self.rx_medicine_name.clear()
        self.rx_dosage.clear()
        self.rx_frequency.clear()
        self.rx_route.clear()
        self.rx_duration.setValue(0)
        self.rx_quantity.setValue(0)

    def _save_prescription(self) -> None:
        if not self._require_visit():
            return
        if not self._prescription_lines:
            QMessageBox.warning(self, "Save prescription", "Add at least one medicine line first.")
            return
        prescription = create_prescription(
            visit_id=self._visit_id, doctor_id=self._doctor_id, items=self._prescription_lines,
        )
        finalize_prescription(prescription.id)
        self._last_prescription_id = prescription.id
        self._prescription_lines = []
        self.rx_line_list.clear()
        self._refresh_prescriptions()
        QMessageBox.information(self, "Prescription saved", "Prescription saved and finalized.")

    def _refresh_prescriptions(self) -> None:
        self.prescriptions_list.clear()
        self._prescription_ids_by_row = {}
        if self._visit_id is None:
            return
        for row, prescription in enumerate(list_prescriptions_for_visit(self._visit_id)):
            items_text = "; ".join(item.medicine_name for item in prescription.items)
            self.prescriptions_list.addItem(f"{prescription.created_at:%Y-%m-%d %H:%M} — {items_text}")
            self._prescription_ids_by_row[row] = prescription.id

    def _select_prescription(self, item) -> None:
        row = self.prescriptions_list.row(item)
        self._selected_prescription_id = self._prescription_ids_by_row.get(row)

    def _print_prescription_pdf(self) -> None:
        """Save a finalized prescription as a printable PDF (spec 5/17) —
        before this, prescriptions existed only as data the pharmacist read
        off-screen; nothing the patient could take to an outside pharmacy.
        Prints whichever prescription is selected in the list above, or the
        one just saved if none has been explicitly clicked yet.
        """
        prescription_id = self._selected_prescription_id or self._last_prescription_id
        if prescription_id is None:
            QMessageBox.warning(
                self, "Print prescription",
                "Save a prescription first, or click one in the list above to select it.",
            )
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save prescription as PDF", f"prescription_{prescription_id}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        try:
            generate_prescription_pdf(prescription_id, path)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Print prescription", f"Could not generate the PDF:\n{exc}")
            return
        QMessageBox.information(self, "Prescription saved", f"Prescription PDF saved to:\n{path}")

    # -- Queue / visit selection -------------------------------------------
    def _refresh_queue(self) -> None:
        doctor_id = self.doctor_combo.currentData()
        self.queue_list.clear()
        self._queue_by_row = []
        if doctor_id is None:
            return
        for appt in doctor_queue_for_date(doctor_id, self.queue_date.date().toPython()):
            if appt.status not in ("in_consultation", "checked_in"):
                continue
            self._queue_by_row.append(appt)
            self.queue_list.addItem(f"Token {appt.token_number} — patient #{appt.patient_id} — {humanize(appt.status)}")

    def _select_queue_entry(self, item) -> None:
        row = self.queue_list.row(item)
        appt = self._queue_by_row[row]
        visit = get_visit_for_appointment(appt.id)
        if visit is None:
            QMessageBox.warning(
                self, "No open visit",
                "This appointment has no open visit — check the patient in from the "
                "Appointments screen first (\"Check in (start visit)\").",
            )
            return
        self._visit_id = visit.id
        self._patient_id = appt.patient_id
        self._doctor_id = appt.doctor_id
        patient = get_patient(self._patient_id)
        patient_text = f"{patient.uhid} — {patient.full_name}" if patient else f"patient #{self._patient_id}"
        self.selected_label.setText(f"Charting for {patient_text} (visit #{self._visit_id})")
        self._refresh_notes()
        self._refresh_prescriptions()
        self._prescription_lines = []
        self._selected_prescription_id = None
        self._last_prescription_id = None
        self.rx_line_list.clear()

    def _require_visit(self) -> bool:
        if self._visit_id is None:
            QMessageBox.warning(self, "No patient selected", "Select a checked-in patient from the queue first.")
            return False
        return True

    def _complete_visit(self) -> None:
        if not self._require_visit():
            return
        complete_visit(self._visit_id)
        QMessageBox.information(self, "Visit completed", "Visit closed and appointment marked completed.")
        self._visit_id = None
        self._patient_id = None
        self._doctor_id = None
        self.selected_label.setText("No patient selected — check in from Appointments first.")
        self.notes_list.clear()
        self.prescriptions_list.clear()
        self._selected_prescription_id = None
        self._last_prescription_id = None
        self._refresh_queue()
