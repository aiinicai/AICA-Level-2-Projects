from __future__ import annotations

import shutil
from pathlib import Path

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.backups.backup_service import create_backup, restore_backup
from app.config import settings as app_settings
from app.security.auth import SessionUser
from app.services.appointment_service import add_department, add_doctor, list_departments, list_doctors
from app.services.audit_service import search_audit_log
from app.services.communication_service import (
    SmtpConfig,
    get_smtp_config,
    list_communications,
    save_smtp_config,
    send_notification,
)
from app.services.excel_export_service import export_doctors_xlsx, export_medicines_xlsx
from app.services.hospital_settings_service import HospitalProfile, get_hospital_profile, save_hospital_profile
from app.services.sync_service import configure_sync, get_sync_folder, is_sync_enabled
from app.services.user_service import (
    DuplicateUsernameError,
    UserInput,
    create_user,
    list_users,
    reset_password,
    set_active,
    unlinked_doctors,
)
from app.config.settings import ROLES
from app.ui.label_utils import humanize
from app.ui.themes.palettes import THEME_NAMES, THEMES
from app.ui.themes.theme_manager import apply_theme, load_theme_choice, save_theme_choice


class SettingsScreen(QWidget):
    """Theme picker, hospital/company master, department/doctor setup, and
    the audit log viewer (administrator, spec section 2 configuration).
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._build_ui()
        self._reload_departments()
        self._reload_doctors()
        self._load_hospital_profile()
        self._load_smtp_config()
        self._load_sync_config()
        self._refresh_communication_log()
        self._refresh_users()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_hospital_tab(), "Hospital / company details")
        tabs.addTab(self._build_theme_tab(), "Appearance")
        tabs.addTab(self._build_admin_tab(), "Departments && doctors")
        tabs.addTab(self._build_users_tab(), "Staff / users")
        tabs.addTab(self._build_notifications_tab(), "Notifications")
        tabs.addTab(self._build_backup_tab(), "Backup && cloud sync")
        tabs.addTab(self._build_audit_tab(), "Audit log")

    def _build_hospital_tab(self) -> QWidget:
        """Company/hospital master (spec section 2) shown large on the Dashboard."""
        box = QGroupBox("Hospital / company master")
        form = QFormLayout(box)

        self.hospital_name = QLineEdit()
        self.hospital_tagline = QLineEdit()
        self.hospital_address = QLineEdit()
        self.hospital_phone = QLineEdit()
        self.hospital_email = QLineEdit()
        self.hospital_gstin = QLineEdit()
        self.hospital_registration = QLineEdit()

        form.addRow("Hospital / company name*", self.hospital_name)
        form.addRow("Tagline", self.hospital_tagline)
        form.addRow("Address", self.hospital_address)
        form.addRow("Phone", self.hospital_phone)
        form.addRow("Email", self.hospital_email)
        form.addRow("GSTIN", self.hospital_gstin)
        form.addRow("Registration number", self.hospital_registration)

        save_button = QPushButton("Save hospital details")
        save_button.clicked.connect(self._save_hospital_profile)
        form.addRow(save_button)

        hint = QLabel("Shown large on the Dashboard alongside the AICA-L2 HMS logo.")
        hint.setStyleSheet("color: grey;")
        form.addRow(hint)

        return box

    def _load_hospital_profile(self) -> None:
        profile = get_hospital_profile()
        self.hospital_name.setText(profile.name)
        self.hospital_tagline.setText(profile.tagline)
        self.hospital_address.setText(profile.address)
        self.hospital_phone.setText(profile.phone)
        self.hospital_email.setText(profile.email)
        self.hospital_gstin.setText(profile.gstin)
        self.hospital_registration.setText(profile.registration_number)

    def _save_hospital_profile(self) -> None:
        if not self.hospital_name.text().strip():
            QMessageBox.warning(self, "Save hospital details", "Hospital/company name is required.")
            return
        save_hospital_profile(HospitalProfile(
            name=self.hospital_name.text().strip(),
            tagline=self.hospital_tagline.text().strip(),
            address=self.hospital_address.text().strip(),
            phone=self.hospital_phone.text().strip(),
            email=self.hospital_email.text().strip(),
            gstin=self.hospital_gstin.text().strip(),
            registration_number=self.hospital_registration.text().strip(),
        ))
        QMessageBox.information(self, "Saved", "Hospital details saved. The Dashboard will show them on next visit.")

    def _build_theme_tab(self) -> QWidget:
        box = QGroupBox("Colour theme")
        form = QFormLayout(box)

        self.theme_combo = QComboBox()
        for key in THEME_NAMES:
            self.theme_combo.addItem(THEMES[key]["light"].name, userData=key)

        self.mode_combo = QComboBox()
        self.mode_combo.addItems(["Light", "Dark"])

        current_theme, current_mode = load_theme_choice()
        index = self.theme_combo.findData(current_theme)
        if index >= 0:
            self.theme_combo.setCurrentIndex(index)
        self.mode_combo.setCurrentText(current_mode.capitalize())

        form.addRow("Theme", self.theme_combo)
        form.addRow("Mode", self.mode_combo)

        apply_button = QPushButton("Apply theme")
        apply_button.clicked.connect(self._apply_theme)
        form.addRow(apply_button)

        hint = QLabel("6 themes available, each with a light and a dark mode.")
        hint.setStyleSheet("color: grey;")
        form.addRow(hint)

        return box

    def _apply_theme(self) -> None:
        theme_key = self.theme_combo.currentData()
        mode = self.mode_combo.currentText().lower()
        from PySide6.QtWidgets import QApplication

        apply_theme(QApplication.instance(), theme_key, mode)
        save_theme_choice(theme_key, mode)
        QMessageBox.information(self, "Theme applied", f"{self.theme_combo.currentText()} ({mode}) applied and saved.")

    def _build_admin_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        dept_box = QGroupBox("Departments")
        dept_form = QFormLayout(dept_box)
        self.new_department_name = QLineEdit()
        add_dept_button = QPushButton("Add department")
        add_dept_button.clicked.connect(self._add_department)
        dept_form.addRow("Name*", self.new_department_name)
        dept_form.addRow(add_dept_button)
        self.department_list = QListWidget()
        dept_form.addRow(self.department_list)

        doctor_box = QGroupBox("Doctors")
        doctor_form = QFormLayout(doctor_box)
        self.new_doctor_name = QLineEdit()
        self.new_doctor_department = QComboBox()
        self.new_doctor_specialization = QLineEdit()
        self.new_doctor_fee = QDoubleSpinBox()
        self.new_doctor_fee.setMaximum(1_000_000)
        add_doctor_button = QPushButton("Add doctor")
        add_doctor_button.clicked.connect(self._add_doctor)

        doctor_form.addRow("Full name*", self.new_doctor_name)
        doctor_form.addRow("Department*", self.new_doctor_department)
        doctor_form.addRow("Specialization", self.new_doctor_specialization)
        doctor_form.addRow("Consultation fee", self.new_doctor_fee)
        doctor_form.addRow(add_doctor_button)
        self.doctor_list = QListWidget()
        doctor_form.addRow(self.doctor_list)

        export_doctors_button = QPushButton("Bulk export doctors to Excel...")
        export_doctors_button.clicked.connect(self._export_doctors)
        doctor_form.addRow(export_doctors_button)

        export_medicines_button = QPushButton("Bulk export medicines to Excel...")
        export_medicines_button.clicked.connect(self._export_medicines)
        doctor_form.addRow(export_medicines_button)

        layout.addWidget(dept_box)
        layout.addWidget(doctor_box)
        return box

    def _export_doctors(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export doctors", "doctors_master.xlsx", "Excel Files (*.xlsx)")
        if not path:
            return
        export_doctors_xlsx(path)
        QMessageBox.information(self, "Export complete", f"Doctor master exported to {path}")

    def _export_medicines(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export medicines", "medicines_master.xlsx", "Excel Files (*.xlsx)")
        if not path:
            return
        export_medicines_xlsx(path)
        QMessageBox.information(self, "Export complete", f"Medicine master exported to {path}")

    def _reload_departments(self) -> None:
        self.department_list.clear()
        self.new_doctor_department.clear()
        for department in list_departments():
            self.department_list.addItem(department.name)
            self.new_doctor_department.addItem(department.name, userData=department.id)

    def _reload_doctors(self) -> None:
        self.doctor_list.clear()
        for doctor in list_doctors():
            self.doctor_list.addItem(f"{doctor.full_name} — {doctor.specialization or ''}")

    def _add_department(self) -> None:
        name = self.new_department_name.text().strip()
        if not name:
            QMessageBox.warning(self, "Add department", "Department name is required.")
            return
        try:
            add_department(name)
        except ValueError as exc:
            QMessageBox.critical(self, "Add department", str(exc))
            return
        self.new_department_name.clear()
        self._reload_departments()

    def _add_doctor(self) -> None:
        department_id = self.new_doctor_department.currentData()
        if not self.new_doctor_name.text().strip() or department_id is None:
            QMessageBox.warning(self, "Add doctor", "Doctor name and department are required.")
            return
        add_doctor(
            full_name=self.new_doctor_name.text().strip(),
            department_id=department_id,
            specialization=self.new_doctor_specialization.text() or None,
            consultation_fee=self.new_doctor_fee.value(),
        )
        self.new_doctor_name.clear()
        self.new_doctor_specialization.clear()
        self._reload_doctors()

    def _build_users_tab(self) -> QWidget:
        """Create/manage staff login accounts (spec section 2).

        Before this tab existed, the only login in the whole app was the
        single seeded "admin" account — there was no way to create a
        receptionist, doctor, nurse, pharmacist, lab technician, accountant,
        or store manager account, so the RBAC system (7 roles) was
        unreachable beyond that one login. Administrator-only, like the
        rest of this screen.
        """
        box = QWidget()
        layout = QHBoxLayout(box)

        add_box = QGroupBox("Create staff account")
        form = QFormLayout(add_box)

        self.new_user_username = QLineEdit()
        self.new_user_full_name = QLineEdit()
        self.new_user_role = QComboBox()
        for role_name in ROLES:
            self.new_user_role.addItem(humanize(role_name), userData=role_name)
        self.new_user_role.currentIndexChanged.connect(self._on_new_user_role_changed)
        self.new_user_doctor_link = QComboBox()
        self.new_user_doctor_link.setEnabled(False)
        self.new_user_password = QLineEdit()
        self.new_user_password.setEchoMode(QLineEdit.Password)
        self.new_user_password.setPlaceholderText("At least 6 characters")

        form.addRow("Username*", self.new_user_username)
        form.addRow("Full name*", self.new_user_full_name)
        form.addRow("Role*", self.new_user_role)
        form.addRow("Linked doctor profile", self.new_user_doctor_link)
        form.addRow("Temporary password*", self.new_user_password)

        create_button = QPushButton("Create staff account")
        create_button.clicked.connect(self._create_user)
        form.addRow(create_button)

        hint = QLabel(
            "The new account is flagged to change its password on first login. "
            "\"Linked doctor profile\" only applies when the role is Doctor — it lets the "
            "Consultation screen know which doctor's queue this login should see."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: grey; font-size: 10px;")
        form.addRow(hint)

        list_box = QGroupBox("Staff accounts")
        list_layout = QVBoxLayout(list_box)

        self.user_list = QListWidget()
        self.user_list.itemClicked.connect(self._select_user_row)
        self.user_list.itemActivated.connect(self._select_user_row)
        list_layout.addWidget(self.user_list)

        button_row = QHBoxLayout()
        deactivate_button = QPushButton("Deactivate")
        deactivate_button.clicked.connect(lambda: self._set_selected_user_active(False))
        activate_button = QPushButton("Reactivate")
        activate_button.clicked.connect(lambda: self._set_selected_user_active(True))
        button_row.addWidget(deactivate_button)
        button_row.addWidget(activate_button)
        list_layout.addLayout(button_row)

        reset_row = QHBoxLayout()
        self.reset_password_input = QLineEdit()
        self.reset_password_input.setPlaceholderText("New temporary password")
        self.reset_password_input.setEchoMode(QLineEdit.Password)
        reset_button = QPushButton("Reset password")
        reset_button.clicked.connect(self._reset_selected_user_password)
        reset_row.addWidget(self.reset_password_input)
        reset_row.addWidget(reset_button)
        list_layout.addLayout(reset_row)

        layout.addWidget(add_box)
        layout.addWidget(list_box)
        return box

    def _on_new_user_role_changed(self) -> None:
        is_doctor_role = self.new_user_role.currentData() == "doctor"
        self.new_user_doctor_link.setEnabled(is_doctor_role)
        if is_doctor_role:
            self.new_user_doctor_link.clear()
            self.new_user_doctor_link.addItem("(none)", userData=None)
            for doctor in unlinked_doctors():
                self.new_user_doctor_link.addItem(doctor.full_name, userData=doctor.id)

    def _create_user(self) -> None:
        if not self.new_user_username.text().strip() or not self.new_user_full_name.text().strip():
            QMessageBox.warning(self, "Create staff account", "Username and full name are required.")
            return
        if len(self.new_user_password.text()) < 6:
            QMessageBox.warning(self, "Create staff account", "Password must be at least 6 characters.")
            return
        try:
            create_user(UserInput(
                username=self.new_user_username.text().strip(),
                full_name=self.new_user_full_name.text().strip(),
                role_name=self.new_user_role.currentData(),
                password=self.new_user_password.text(),
                linked_doctor_id=self.new_user_doctor_link.currentData(),
            ))
        except (ValueError, DuplicateUsernameError) as exc:
            QMessageBox.critical(self, "Create staff account", str(exc))
            return
        self.new_user_username.clear()
        self.new_user_full_name.clear()
        self.new_user_password.clear()
        self._on_new_user_role_changed()
        self._refresh_users()
        QMessageBox.information(self, "Staff account created", "The account can log in immediately.")

    def _refresh_users(self) -> None:
        self.user_list.clear()
        self._users_by_row = []
        for user in list_users():
            self._users_by_row.append(user)
            status = "active" if user["is_active"] else "DEACTIVATED"
            last_login = user["last_login_at"].strftime("%Y-%m-%d %H:%M") if user["last_login_at"] else "never"
            self.user_list.addItem(
                f"{user['username']} — {user['full_name']} — {humanize(user['role_name'])} — "
                f"[{status}] — last login: {last_login}"
            )
        self._selected_user_id = None

    def _select_user_row(self, item) -> None:
        row = self.user_list.row(item)
        self._selected_user_id = self._users_by_row[row]["id"]

    def _set_selected_user_active(self, is_active: bool) -> None:
        if self._selected_user_id is None:
            QMessageBox.warning(self, "Staff accounts", "Select an account from the list first.")
            return
        if self._selected_user_id == self.session_user.id and not is_active:
            QMessageBox.warning(self, "Staff accounts", "You cannot deactivate your own account.")
            return
        set_active(self._selected_user_id, is_active)
        self._refresh_users()

    def _reset_selected_user_password(self) -> None:
        if self._selected_user_id is None:
            QMessageBox.warning(self, "Reset password", "Select an account from the list first.")
            return
        new_password = self.reset_password_input.text()
        if len(new_password) < 6:
            QMessageBox.warning(self, "Reset password", "Password must be at least 6 characters.")
            return
        reset_password(self._selected_user_id, new_password)
        self.reset_password_input.clear()
        QMessageBox.information(self, "Password reset", "The account must change its password on next login.")

    def _build_notifications_tab(self) -> QWidget:
        """SMS / WhatsApp / email notifications (spec Phase 4).

        Email can really be sent once an SMTP account is configured here.
        SMS and WhatsApp need a paid provider (Twilio, Gupshup, ...) that
        this offline capstone build has no credentials for, so those two
        channels are logged as "simulated" instead of actually delivered —
        the Communication log below shows every attempt either way.
        """
        box = QWidget()
        layout = QVBoxLayout(box)

        smtp_box = QGroupBox("Email (SMTP) — real sending once configured")
        smtp_form = QFormLayout(smtp_box)

        self.smtp_host = QLineEdit()
        self.smtp_host.setPlaceholderText("smtp.example.com")
        self.smtp_port = QSpinBox()
        self.smtp_port.setRange(1, 65535)
        self.smtp_port.setValue(587)
        self.smtp_username = QLineEdit()
        self.smtp_password = QLineEdit()
        self.smtp_password.setEchoMode(QLineEdit.Password)
        self.smtp_from_address = QLineEdit()
        self.smtp_use_tls = QCheckBox("Use STARTTLS")
        self.smtp_use_tls.setChecked(True)

        smtp_form.addRow("SMTP host", self.smtp_host)
        smtp_form.addRow("Port", self.smtp_port)
        smtp_form.addRow("Username", self.smtp_username)
        smtp_form.addRow("Password", self.smtp_password)
        smtp_form.addRow("From address", self.smtp_from_address)
        smtp_form.addRow(self.smtp_use_tls)

        save_smtp_button = QPushButton("Save email settings")
        save_smtp_button.clicked.connect(self._save_smtp_config)
        smtp_form.addRow(save_smtp_button)

        self.test_email_address = QLineEdit()
        self.test_email_address.setPlaceholderText("Send a test email to...")
        test_button = QPushButton("Send test email")
        test_button.clicked.connect(self._send_test_email)
        smtp_form.addRow(self.test_email_address)
        smtp_form.addRow(test_button)

        hint = QLabel(
            "Leave the SMTP host blank to keep email in simulate-only mode "
            "(recorded to the log below, nothing actually sent)."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: grey; font-size: 10px;")
        smtp_form.addRow(hint)

        layout.addWidget(smtp_box)

        log_box = QGroupBox("Communication log")
        log_layout = QVBoxLayout(log_box)
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_communication_log)
        log_layout.addWidget(refresh_button)
        self.communication_list = QListWidget()
        log_layout.addWidget(self.communication_list)
        layout.addWidget(log_box)

        return box

    def _load_smtp_config(self) -> None:
        config = get_smtp_config()
        self.smtp_host.setText(config.host)
        self.smtp_port.setValue(config.port)
        self.smtp_username.setText(config.username)
        self.smtp_password.setText(config.password)
        self.smtp_from_address.setText(config.from_address)
        self.smtp_use_tls.setChecked(config.use_tls)

    def _save_smtp_config(self) -> None:
        save_smtp_config(SmtpConfig(
            host=self.smtp_host.text().strip(),
            port=self.smtp_port.value(),
            username=self.smtp_username.text().strip(),
            password=self.smtp_password.text(),
            from_address=self.smtp_from_address.text().strip(),
            use_tls=self.smtp_use_tls.isChecked(),
        ))
        QMessageBox.information(self, "Saved", "Email (SMTP) settings saved.")

    def _send_test_email(self) -> None:
        address = self.test_email_address.text().strip()
        if not address:
            QMessageBox.warning(self, "Send test email", "Enter an address to send the test email to.")
            return
        log_entry = send_notification(
            "email", address, "This is a test message from AICA-L2 HMS.", subject="AICA-L2 HMS test email",
        )
        self._refresh_communication_log()
        if log_entry.status == "sent":
            QMessageBox.information(self, "Test email", f"Sent to {address}.")
        elif log_entry.status == "simulated":
            QMessageBox.information(
                self, "Test email",
                "SMTP is not configured, so this was recorded as simulated rather than actually sent.",
            )
        else:
            QMessageBox.critical(self, "Test email failed", log_entry.error_message or "Unknown error.")

    def _refresh_communication_log(self) -> None:
        self.communication_list.clear()
        for entry in list_communications(limit=100):
            self.communication_list.addItem(
                f"{entry.created_at:%Y-%m-%d %H:%M} — {entry.channel} — {entry.recipient} — "
                f"[{entry.status}] {entry.subject or entry.message[:60]}"
            )

    def _build_backup_tab(self) -> QWidget:
        """Manual backup/restore (spec section 21) plus an optional cloud
        sync folder (spec Phase 4): point this at a local folder a
        Dropbox/Google Drive/OneDrive client already watches, and every new
        backup is copied there so that client uploads it — this offline
        app has no cloud account of its own to push to directly.
        """
        box = QWidget()
        layout = QVBoxLayout(box)

        backup_box = QGroupBox("Backup && restore")
        backup_form = QFormLayout(backup_box)

        backup_now_button = QPushButton("Create backup now")
        backup_now_button.clicked.connect(self._create_backup_now)
        backup_form.addRow(backup_now_button)

        restore_button = QPushButton("Restore from backup file...")
        restore_button.clicked.connect(self._restore_backup)
        backup_form.addRow(restore_button)

        backups_hint = QLabel(f"Backups folder: {app_settings.BACKUPS_DIR}")
        backups_hint.setWordWrap(True)
        backups_hint.setStyleSheet("color: grey; font-size: 10px;")
        backup_form.addRow(backups_hint)

        layout.addWidget(backup_box)

        sync_box = QGroupBox("Cloud sync folder")
        sync_form = QFormLayout(sync_box)

        self.sync_folder = QLineEdit()
        self.sync_folder.setPlaceholderText(r"e.g. C:\Users\you\Dropbox\AICA-L2 HMS backups")
        browse_button = QPushButton("Browse...")
        browse_button.clicked.connect(self._browse_sync_folder)
        folder_row = QHBoxLayout()
        folder_row.addWidget(self.sync_folder)
        folder_row.addWidget(browse_button)
        sync_form.addRow("Sync folder", folder_row)

        self.sync_enabled = QCheckBox("Copy every new backup into this folder automatically")
        sync_form.addRow(self.sync_enabled)

        save_sync_button = QPushButton("Save cloud sync settings")
        save_sync_button.clicked.connect(self._save_sync_config)
        sync_form.addRow(save_sync_button)

        sync_hint = QLabel(
            "This app has no cloud account of its own. Point the folder above at a "
            "Dropbox / Google Drive / OneDrive folder already syncing on this computer, "
            "and that client uploads each new backup for you."
        )
        sync_hint.setWordWrap(True)
        sync_hint.setStyleSheet("color: grey; font-size: 10px;")
        sync_form.addRow(sync_hint)

        layout.addWidget(sync_box)

        return box

    def _create_backup_now(self) -> None:
        """Create a backup, then let the user pick exactly where their copy
        goes, instead of silently leaving it only inside the app's own
        internal backups folder. Earlier this method just showed the
        internal path in a message box; if the user didn't read that full
        path carefully (easy to miss on a long Windows path) they'd go
        looking in whatever folder they had in mind — e.g. a Desktop folder
        — and find nothing there, because nothing was ever copied there.
        """
        backup_path = create_backup(created_by_id=self.session_user.id)
        if not backup_path.exists():
            QMessageBox.critical(
                self, "Backup failed",
                f"The backup process reported success but the file is missing:\n{backup_path}\n"
                "Please check disk space and folder permissions and try again.",
            )
            return

        default_dir = str(Path.home() / "Desktop")
        if not Path(default_dir).exists():
            default_dir = str(Path.home())
        suggested_path = str(Path(default_dir) / backup_path.name)

        chosen_path, _ = QFileDialog.getSaveFileName(
            self, "Save backup copy to...", suggested_path, "Backup zip (*.zip)",
        )
        if not chosen_path:
            QMessageBox.information(
                self, "Backup created",
                f"Backup created and kept in the app's internal backups folder:\n{backup_path}\n\n"
                "You chose not to save a copy elsewhere just now — you can still find this exact "
                "file at the path above, or run \"Create backup now\" again to pick a folder.",
            )
            return

        try:
            shutil.copy2(backup_path, chosen_path)
        except OSError as exc:
            QMessageBox.critical(
                self, "Could not copy backup",
                f"The backup file was created at:\n{backup_path}\n\n"
                f"but could not be copied to:\n{chosen_path}\n\nReason: {exc}",
            )
            return

        if not Path(chosen_path).exists():
            QMessageBox.critical(
                self, "Backup copy missing",
                f"Copied without error, but the file is not showing up at:\n{chosen_path}\n"
                "This can happen if that folder is a cloud-synced folder still uploading, or "
                "if antivirus software removed it. The original backup is safe at:\n{backup_path}",
            )
            return

        QMessageBox.information(
            self, "Backup created",
            f"Backup saved to:\n{chosen_path}\n\n(a copy is also always kept at {backup_path})",
        )

    def _restore_backup(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Select backup file", "", "Backup zip (*.zip)")
        if not path:
            return
        confirm = QMessageBox.question(
            self, "Restore backup",
            "This replaces the current database and documents with the selected backup "
            "(a safety backup of the current state is taken first). Continue?",
        )
        if confirm != QMessageBox.Yes:
            return
        safety_backup = restore_backup(path, restored_by_id=self.session_user.id)
        QMessageBox.information(
            self, "Restore complete",
            f"Restored from {path}.\nA safety backup of the previous state was saved to:\n{safety_backup}\n"
            "Restart the app for the restored data to fully take effect.",
        )

    def _load_sync_config(self) -> None:
        self.sync_folder.setText(get_sync_folder())
        self.sync_enabled.setChecked(is_sync_enabled())

    def _browse_sync_folder(self) -> None:
        folder = QFileDialog.getExistingDirectory(self, "Select cloud sync folder")
        if folder:
            self.sync_folder.setText(folder)

    def _save_sync_config(self) -> None:
        configure_sync(self.sync_folder.text().strip(), self.sync_enabled.isChecked())
        QMessageBox.information(self, "Saved", "Cloud sync settings saved.")

    def _build_audit_tab(self) -> QWidget:
        """Login/logout, record changes, bill cancellation, discount/refund,
        stock adjustment, backup/restore — the audit trail spec section 20
        requires (administrator-only, since this whole screen is admin-only
        in the sidebar menu).
        """
        box = QGroupBox("Audit trail")
        form = QFormLayout(box)

        self.audit_start = QDateEdit(calendarPopup=True)
        self.audit_start.setDate(self.audit_start.date().addMonths(-1))
        self.audit_end = QDateEdit(calendarPopup=True)
        self.audit_filter = QLineEdit()
        self.audit_filter.setPlaceholderText("Filter by action text (e.g. 'discount', 'voided', 'login')")

        form.addRow("From", self.audit_start)
        form.addRow("To", self.audit_end)
        form.addRow("Action contains", self.audit_filter)

        search_button = QPushButton("Search audit log")
        search_button.clicked.connect(self._search_audit_log)
        form.addRow(search_button)

        self.audit_list = QListWidget()
        form.addRow(self.audit_list)

        return box

    def _search_audit_log(self) -> None:
        results = search_audit_log(
            start_date=self.audit_start.date().toPython(),
            end_date=self.audit_end.date().toPython(),
            action_contains=self.audit_filter.text() or None,
        )
        self.audit_list.clear()
        if not results:
            self.audit_list.addItem("No matching audit events.")
            return
        for entry in results:
            self.audit_list.addItem(
                f"{entry['when']} — {entry['username']} — {entry['action']}"
                + (f" — {entry['details']}" if entry["details"] else "")
            )
