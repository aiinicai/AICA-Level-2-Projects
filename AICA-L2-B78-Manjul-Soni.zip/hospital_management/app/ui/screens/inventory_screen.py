from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.medicine_service import list_medicines
from app.services.purchase_service import (
    POLine,
    ReceiveLine,
    VendorInput,
    add_vendor,
    create_purchase_order,
    list_purchase_orders,
    list_vendors,
    receive_goods,
    stock_movement_ledger,
)


class InventoryScreen(QWidget):
    """Vendors, purchase orders, goods receipt, and the stock ledger (spec section 11)."""

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._po_lines: list[POLine] = []
        self._build_ui()
        self._reload_vendors()
        self._reload_medicines()
        self._refresh_pos()
        self._refresh_ledger()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_vendor_tab(), "Vendors")
        tabs.addTab(self._build_po_tab(), "Purchase orders")
        tabs.addTab(self._build_receive_tab(), "Goods receipt")
        tabs.addTab(self._build_ledger_tab(), "Stock ledger")

    def _build_vendor_tab(self) -> QWidget:
        box = QGroupBox("Add vendor")
        form = QFormLayout(box)
        self.vendor_name = QLineEdit()
        self.vendor_contact = QLineEdit()
        self.vendor_phone = QLineEdit()
        self.vendor_gstin = QLineEdit()

        form.addRow("Name*", self.vendor_name)
        form.addRow("Contact person", self.vendor_contact)
        form.addRow("Phone", self.vendor_phone)
        form.addRow("GSTIN", self.vendor_gstin)

        add_button = QPushButton("Add vendor")
        add_button.clicked.connect(self._add_vendor)
        form.addRow(add_button)

        self.vendor_list = QListWidget()
        form.addRow(self.vendor_list)
        return box

    def _build_po_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        left = QGroupBox("Create purchase order")
        form = QFormLayout(left)
        self.po_vendor_combo = QComboBox()
        self.po_medicine_combo = QComboBox()
        self.po_quantity = QSpinBox()
        self.po_quantity.setMaximum(1_000_000)
        self.po_unit_price = QDoubleSpinBox()
        self.po_unit_price.setMaximum(1_000_000)

        add_line_button = QPushButton("Add line")
        add_line_button.clicked.connect(self._add_po_line)

        form.addRow("Vendor", self.po_vendor_combo)
        form.addRow("Medicine", self.po_medicine_combo)
        form.addRow("Quantity", self.po_quantity)
        form.addRow("Unit price", self.po_unit_price)
        form.addRow(add_line_button)

        self.po_line_list = QListWidget()
        form.addRow(self.po_line_list)

        create_button = QPushButton("Create purchase order")
        create_button.clicked.connect(self._create_po)
        form.addRow(create_button)

        right = QGroupBox("Purchase orders")
        right_layout = QVBoxLayout(right)
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_pos)
        right_layout.addWidget(refresh_button)
        self.po_list = QListWidget()
        right_layout.addWidget(self.po_list)

        layout.addWidget(left)
        layout.addWidget(right)
        return box

    def _build_receive_tab(self) -> QWidget:
        box = QGroupBox("Receive goods (single line quick-entry)")
        form = QFormLayout(box)

        self.receive_po_combo = QComboBox()
        self.receive_medicine_combo = QComboBox()
        self.receive_batch_number = QLineEdit()
        self.receive_expiry = QDateEdit(calendarPopup=True)
        self.receive_expiry.setDate(_dt.date.today().replace(year=_dt.date.today().year + 1))
        self.receive_quantity = QSpinBox()
        self.receive_quantity.setMaximum(1_000_000)
        self.receive_unit_price = QDoubleSpinBox()
        self.receive_unit_price.setMaximum(1_000_000)
        self.receive_invoice_number = QLineEdit()

        form.addRow("Purchase order (optional)", self.receive_po_combo)
        form.addRow("Medicine*", self.receive_medicine_combo)
        form.addRow("Batch number*", self.receive_batch_number)
        form.addRow("Expiry date*", self.receive_expiry)
        form.addRow("Quantity*", self.receive_quantity)
        form.addRow("Unit price", self.receive_unit_price)
        form.addRow("Vendor invoice number", self.receive_invoice_number)

        receive_button = QPushButton("Receive goods")
        receive_button.clicked.connect(self._receive_goods)
        form.addRow(receive_button)

        return box

    def _build_ledger_tab(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        refresh_button = QPushButton("Refresh ledger")
        refresh_button.clicked.connect(self._refresh_ledger)
        layout.addWidget(refresh_button)
        self.ledger_list = QListWidget()
        layout.addWidget(self.ledger_list)
        return box

    # -- data loading -----------------------------------------------------
    def _reload_vendors(self) -> None:
        self.vendor_list.clear()
        self.po_vendor_combo.clear()
        for vendor in list_vendors():
            self.vendor_list.addItem(f"{vendor.name} — {vendor.contact_person or ''} {vendor.phone or ''}")
            self.po_vendor_combo.addItem(vendor.name, userData=vendor.id)

    def _reload_medicines(self) -> None:
        self.po_medicine_combo.clear()
        self.receive_medicine_combo.clear()
        for medicine in list_medicines():
            label = f"{medicine.generic_name} {medicine.strength or ''}".strip()
            self.po_medicine_combo.addItem(label, userData=medicine.id)
            self.receive_medicine_combo.addItem(label, userData=medicine.id)

    def _add_vendor(self) -> None:
        if not self.vendor_name.text().strip():
            QMessageBox.warning(self, "Add vendor", "Vendor name is required.")
            return
        add_vendor(VendorInput(
            name=self.vendor_name.text().strip(),
            contact_person=self.vendor_contact.text() or None,
            phone=self.vendor_phone.text() or None,
            gstin=self.vendor_gstin.text() or None,
        ))
        self.vendor_name.clear()
        self.vendor_contact.clear()
        self.vendor_phone.clear()
        self.vendor_gstin.clear()
        self._reload_vendors()

    def _add_po_line(self) -> None:
        medicine_id = self.po_medicine_combo.currentData()
        if medicine_id is None:
            QMessageBox.warning(self, "Add line", "No medicine available — add one in Pharmacy first.")
            return
        line = POLine(medicine_id=medicine_id, quantity_ordered=self.po_quantity.value(),
                       unit_price=self.po_unit_price.value())
        self._po_lines.append(line)
        self.po_line_list.addItem(
            f"{self.po_medicine_combo.currentText()} x{line.quantity_ordered} @ {line.unit_price}"
        )

    def _create_po(self) -> None:
        vendor_id = self.po_vendor_combo.currentData()
        if vendor_id is None:
            QMessageBox.warning(self, "Create PO", "Add a vendor first.")
            return
        if not self._po_lines:
            QMessageBox.warning(self, "Create PO", "Add at least one line.")
            return
        po = create_purchase_order(vendor_id=vendor_id, lines=self._po_lines, created_by_id=self.session_user.id)
        QMessageBox.information(self, "Purchase order created", f"PO number: {po.po_number}")
        self._po_lines = []
        self.po_line_list.clear()
        self._refresh_pos()

    def _refresh_pos(self) -> None:
        self.po_list.clear()
        self.receive_po_combo.clear()
        self.receive_po_combo.addItem("(none)", userData=None)
        for po in list_purchase_orders():
            self.po_list.addItem(f"{po.po_number} — vendor #{po.vendor_id} — {po.status}")
            self.receive_po_combo.addItem(po.po_number, userData=po.id)

    def _receive_goods(self) -> None:
        medicine_id = self.receive_medicine_combo.currentData()
        vendor_id = self.po_vendor_combo.currentData()
        if medicine_id is None:
            QMessageBox.warning(self, "Receive goods", "Select a medicine.")
            return
        if vendor_id is None:
            QMessageBox.warning(self, "Receive goods", "Select a vendor in the Purchase orders tab first.")
            return
        if not self.receive_batch_number.text().strip():
            QMessageBox.warning(self, "Receive goods", "Batch number is required.")
            return
        po_id = self.receive_po_combo.currentData()
        line = ReceiveLine(
            po_item_id=-1,  # no specific PO line tracked in this quick-entry form
            medicine_id=medicine_id,
            batch_number=self.receive_batch_number.text().strip(),
            expiry_date=self.receive_expiry.date().toPython(),
            quantity=self.receive_quantity.value(),
            unit_price=self.receive_unit_price.value(),
        )
        receive_goods(
            purchase_order_id=po_id, vendor_id=vendor_id, lines=[line],
            invoice_number=self.receive_invoice_number.text() or None,
            received_by_id=self.session_user.id,
        )
        self.receive_batch_number.clear()
        self.receive_invoice_number.clear()
        self._refresh_pos()
        self._refresh_ledger()
        QMessageBox.information(self, "Goods received", "Stock updated and logged in the ledger.")

    def _refresh_ledger(self) -> None:
        self.ledger_list.clear()
        for entry in stock_movement_ledger():
            self.ledger_list.addItem(
                f"{entry.created_at:%Y-%m-%d %H:%M} — medicine #{entry.medicine_id} — "
                f"{entry.transaction_type} — {entry.quantity_change:+d}"
            )
