from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateEdit,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.document_service import attach_document, list_documents
from app.services.barcode_service import generate_barcode_image
from app.services.excel_export_service import export_patients_xlsx
from app.services.patient_service import (
    PatientInput,
    add_relative,
    find_possible_duplicates,
    list_relatives,
    register_patient,
    search_patients,
)
from app.ui.label_utils import add_choice_items


class PatientScreen(QWidget):
    """Registration form on the left, fast global search + results on the right (spec 3, 18)."""

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._selected_patient_id = None
        self._selected_patient_uhid = None
        self._build_ui()

    def _build_ui(self) -> None:
        outer = QHBoxLayout(self)
        splitter = QSplitter()
        outer.addWidget(splitter)

        splitter.addWidget(self._build_registration_form())
        splitter.addWidget(self._build_search_panel())
        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.addWidget(self._build_documents_panel())
        right_layout.addWidget(self._build_relatives_panel())
        splitter.addWidget(right)

    def _build_registration_form(self) -> QWidget:
        box = QGroupBox("Register new patient")
        form = QFormLayout(box)

        self.full_name = QLineEdit()
        self.gender = QComboBox()
        self.gender.addItems(["Female", "Male", "Other"])
        self.dob = QDateEdit(calendarPopup=True)
        self.dob.setDate(_dt.date.today())
        self.mobile = QLineEdit()
        self.email = QLineEdit()
        self.blood_group = QComboBox()
        self.blood_group.addItems(["", "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"])
        self.address = QLineEdit()
        self.emergency_name = QLineEdit()
        self.emergency_number = QLineEdit()
        self.emergency_email = QLineEdit()

        form.addRow("Full name*", self.full_name)
        form.addRow("Gender*", self.gender)
        form.addRow("Date of birth", self.dob)
        form.addRow("Mobile number*", self.mobile)
        form.addRow("Email", self.email)
        form.addRow("Blood group", self.blood_group)
        form.addRow("Address", self.address)
        form.addRow("Emergency contact name", self.emergency_name)
        form.addRow("Emergency contact number", self.emergency_number)
        form.addRow("Emergency contact email", self.emergency_email)

        check_button = QPushButton("Check duplicates")
        check_button.clicked.connect(self._check_duplicates)
        save_button = QPushButton("Register patient")
        save_button.clicked.connect(self._register)

        form.addRow(check_button)
        form.addRow(save_button)

        self.duplicate_list = QListWidget()
        self.duplicate_list.setMaximumHeight(100)
        form.addRow(QLabel("Possible duplicates:"))
        form.addRow(self.duplicate_list)

        return box

    def _build_search_panel(self) -> QWidget:
        box = QGroupBox("Find patient")
        layout = QVBoxLayout(box)

        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by UHID, name or mobile number")
        self.search_input.textChanged.connect(self._search)
        layout.addWidget(self.search_input)

        self.results_list = QListWidget()
        self.results_list.itemClicked.connect(self._select_result)
        self.results_list.itemActivated.connect(self._select_result)
        layout.addWidget(self.results_list)

        export_button = QPushButton("Bulk export patients to Excel...")
        export_button.clicked.connect(self._export_patients)
        layout.addWidget(export_button)

        return box

    def _export_patients(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Export patients", "patients_master.xlsx", "Excel Files (*.xlsx)"
        )
        if not path:
            return
        export_patients_xlsx(path)
        QMessageBox.information(self, "Export complete", f"Patient master exported to {path}")

    def _build_documents_panel(self) -> QWidget:
        """Attach and view scanned/uploaded files for the currently selected
        patient (spec 13: every file gets a database record, never a bare
        filename on disk).
        """
        box = QGroupBox("Patient documents")
        layout = QVBoxLayout(box)

        self.selected_patient_label = QLabel("Select a patient from search results")
        layout.addWidget(self.selected_patient_label)

        self.document_type = QComboBox()
        add_choice_items(self.document_type, ["lab_report", "radiology", "consent", "insurance", "other"])
        layout.addWidget(self.document_type)

        attach_button = QPushButton("Attach file...")
        attach_button.clicked.connect(self._attach_document)
        layout.addWidget(attach_button)

        self.document_list = QListWidget()
        layout.addWidget(self.document_list)

        barcode_button = QPushButton("Print UHID barcode...")
        barcode_button.clicked.connect(self._print_uhid_barcode)
        layout.addWidget(barcode_button)

        return box

    def _print_uhid_barcode(self) -> None:
        """Generate a Code128 barcode of the patient's UHID (spec Phase 4:
        barcode scanners) so it can be printed onto a wristband/ID card and
        later scanned back into the Patients/Pharmacy search fields, which
        already accept scanner input since a scanner just types + Enter.
        """
        if self._selected_patient_id is None or not self._selected_patient_uhid:
            QMessageBox.warning(self, "Print barcode", "Select a patient from search results first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save barcode image", f"{self._selected_patient_uhid}_barcode.png", "PNG Files (*.png)"
        )
        if not path:
            return
        saved_path = generate_barcode_image(self._selected_patient_uhid, path)
        QMessageBox.information(self, "Barcode saved", f"UHID barcode saved to {saved_path}")

    def _build_relatives_panel(self) -> QWidget:
        """Master of a patient's relatives / next-of-kin contacts (spec 3):
        name, mobile number and email for each relative — a patient can have
        more than one (spouse, child, guardian, ...).
        """
        box = QGroupBox("Relatives / next-of-kin contacts")
        layout = QVBoxLayout(box)

        form = QFormLayout()
        self.relative_name = QLineEdit()
        self.relative_relation = QLineEdit()
        self.relative_relation.setPlaceholderText("e.g. Spouse, Son, Guardian")
        self.relative_mobile = QLineEdit()
        self.relative_email = QLineEdit()
        self.relative_is_primary = QCheckBox("Primary contact")
        form.addRow("Full name", self.relative_name)
        form.addRow("Relation", self.relative_relation)
        form.addRow("Mobile number", self.relative_mobile)
        form.addRow("Email", self.relative_email)
        form.addRow(self.relative_is_primary)
        layout.addLayout(form)

        add_relative_button = QPushButton("Add relative")
        add_relative_button.clicked.connect(self._add_relative)
        layout.addWidget(add_relative_button)

        self.relative_list = QListWidget()
        layout.addWidget(self.relative_list)

        return box

    def _add_relative(self) -> None:
        if self._selected_patient_id is None:
            QMessageBox.warning(self, "Add relative", "Select a patient from search results first.")
            return
        if not self.relative_name.text().strip():
            QMessageBox.warning(self, "Add relative", "Relative's name is required.")
            return
        add_relative(
            patient_id=self._selected_patient_id,
            full_name=self.relative_name.text(),
            relation=self.relative_relation.text() or None,
            mobile_number=self.relative_mobile.text() or None,
            email=self.relative_email.text() or None,
            is_primary_contact=self.relative_is_primary.isChecked(),
        )
        self.relative_name.clear()
        self.relative_relation.clear()
        self.relative_mobile.clear()
        self.relative_email.clear()
        self.relative_is_primary.setChecked(False)
        self._refresh_relatives()

    def _refresh_relatives(self) -> None:
        self.relative_list.clear()
        if self._selected_patient_id is None:
            return
        for relative in list_relatives(self._selected_patient_id):
            tag = "Primary" if relative.is_primary_contact else (relative.relation or "Relative")
            details = " | ".join(bit for bit in (relative.mobile_number, relative.email) if bit)
            self.relative_list.addItem(f"[{tag}] {relative.full_name} — {details}")

    def _select_result(self, item) -> None:
        self._selected_patient_id = item.data(1)
        self._selected_patient_uhid = item.data(2)
        self.selected_patient_label.setText(item.text())
        self._refresh_documents()
        self._refresh_relatives()

    def _attach_document(self) -> None:
        if self._selected_patient_id is None:
            QMessageBox.warning(self, "Attach document", "Select a patient from search results first.")
            return
        file_path, _ = QFileDialog.getOpenFileName(self, "Select file to attach")
        if not file_path:
            return
        attach_document(
            patient_id=self._selected_patient_id,
            source_file_path=file_path,
            document_type=self.document_type.currentData(),
            uploaded_by_id=self.session_user.id,
        )
        self._refresh_documents()

    def _refresh_documents(self) -> None:
        self.document_list.clear()
        if self._selected_patient_id is None:
            return
        for document in list_documents(self._selected_patient_id):
            self.document_list.addItem(
                f"[{document.document_type}] {document.uploaded_at:%Y-%m-%d %H:%M} — {document.file_path}"
            )

    def _check_duplicates(self) -> None:
        dob = self.dob.date().toPython()
        matches = find_possible_duplicates(self.mobile.text().strip(), self.full_name.text().strip(), dob)
        self.duplicate_list.clear()
        if not matches:
            self.duplicate_list.addItem("No likely duplicates found.")
            return
        for patient in matches:
            self.duplicate_list.addItem(f"{patient.uhid} — {patient.full_name} — {patient.mobile_number}")

    def _register(self) -> None:
        if not self.full_name.text().strip() or not self.mobile.text().strip():
            QMessageBox.warning(self, "Missing information", "Full name and mobile number are required.")
            return
        data = PatientInput(
            full_name=self.full_name.text(),
            gender=self.gender.currentText(),
            mobile_number=self.mobile.text(),
            email=self.email.text() or None,
            date_of_birth=self.dob.date().toPython(),
            blood_group=self.blood_group.currentText() or None,
            address=self.address.text() or None,
            emergency_contact_name=self.emergency_name.text() or None,
            emergency_contact_number=self.emergency_number.text() or None,
            emergency_contact_email=self.emergency_email.text() or None,
        )
        patient = register_patient(data, created_by_id=self.session_user.id)
        QMessageBox.information(self, "Patient registered", f"UHID: {patient.uhid}")
        self.full_name.clear()
        self.mobile.clear()
        self.email.clear()
        self.address.clear()
        self.emergency_name.clear()
        self.emergency_number.clear()
        self.emergency_email.clear()
        self.duplicate_list.clear()

    def _search(self, term: str) -> None:
        self.results_list.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            self.results_list.addItem(
                f"{patient.uhid} — {patient.full_name} — {patient.gender}, "
                f"{patient.age_years or '?'}y — {patient.mobile_number}"
            )
            self.results_list.item(self.results_list.count() - 1).setData(1, patient.id)
            self.results_list.item(self.results_list.count() - 1).setData(2, patient.uhid)
