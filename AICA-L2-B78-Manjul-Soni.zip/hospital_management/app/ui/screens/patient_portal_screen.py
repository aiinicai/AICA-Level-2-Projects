from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon
from PySide6.QtWidgets import (
    QDialog,
    QFormLayout,
    QGroupBox,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.config import settings
from app.services.portal_service import authenticate_patient, get_portal_data


class PatientPortalWindow(QDialog):
    """Patient self-service portal (spec Phase 4).

    A real online patient portal needs a hosted web/mobile app and an
    internet connection this offline desktop app doesn't have. This gives
    patients the same self-service value from the same computer instead:
    log in with UHID + the mobile number on file (no staff username or
    password involved) to see upcoming appointments, prescriptions,
    invoices/dues, and verified lab reports, read-only.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"{settings.APP_NAME} — Patient portal")
        self.setMinimumSize(480, 520)
        if settings.APP_LOGO_PATH.exists():
            self.setWindowIcon(QIcon(str(settings.APP_LOGO_PATH)))
        self._patient = None
        self._build_ui()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        self.stack = QStackedWidget()
        outer.addWidget(self.stack)
        self.stack.addWidget(self._build_login_page())
        self.stack.addWidget(self._build_data_page())

    def _build_login_page(self) -> QWidget:
        box = QGroupBox("Patient portal login")
        form = QFormLayout(box)

        title = QLabel("Enter your UHID and the mobile number registered with the hospital.")
        title.setWordWrap(True)
        form.addRow(title)

        self.login_uhid = QLineEdit()
        self.login_uhid.setPlaceholderText("e.g. UHID26000001")
        self.login_mobile = QLineEdit()
        self.login_mobile.setPlaceholderText("Registered mobile number")

        form.addRow("UHID", self.login_uhid)
        form.addRow("Mobile number", self.login_mobile)

        login_button = QPushButton("View my records")
        login_button.clicked.connect(self._attempt_login)
        form.addRow(login_button)

        return box

    def _attempt_login(self) -> None:
        uhid = self.login_uhid.text().strip()
        mobile = self.login_mobile.text().strip()
        if not uhid or not mobile:
            QMessageBox.warning(self, "Patient portal", "Enter both your UHID and mobile number.")
            return
        patient = authenticate_patient(uhid, mobile)
        if patient is None:
            QMessageBox.critical(self, "Patient portal", "No matching patient found for that UHID and mobile number.")
            return
        self._patient = patient
        self._load_data()
        self.stack.setCurrentIndex(1)

    def _build_data_page(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)

        self.patient_header = QLabel("—")
        self.patient_header.setStyleSheet("font-size: 16px; font-weight: 700;")
        layout.addWidget(self.patient_header)

        tabs = QTabWidget()
        layout.addWidget(tabs)

        self.appointments_list = QListWidget()
        tabs.addTab(self.appointments_list, "Upcoming appointments")

        self.prescriptions_list = QListWidget()
        tabs.addTab(self.prescriptions_list, "Prescriptions")

        self.invoices_list = QListWidget()
        tabs.addTab(self.invoices_list, "Invoices / dues")

        self.lab_results_list = QListWidget()
        tabs.addTab(self.lab_results_list, "Lab reports")

        logout_button = QPushButton("Log out")
        logout_button.clicked.connect(self._logout)
        layout.addWidget(logout_button)

        return box

    def _load_data(self) -> None:
        patient = self._patient
        self.patient_header.setText(f"{patient.full_name} — {patient.uhid}")
        data = get_portal_data(patient.id)

        self.appointments_list.clear()
        if not data["appointments"]:
            self.appointments_list.addItem("No upcoming appointments.")
        for row in data["appointments"]:
            time_text = row["time"].strftime("%H:%M") if row["time"] else ""
            self.appointments_list.addItem(
                f"{row['date']} {time_text} — {row['doctor']} — {row['status'].replace('_', ' ').capitalize()}"
            )

        self.prescriptions_list.clear()
        if not data["prescriptions"]:
            self.prescriptions_list.addItem("No prescriptions on file.")
        for row in data["prescriptions"]:
            self.prescriptions_list.addItem(f"{row['date']:%Y-%m-%d} — " + "; ".join(row["items"]))

        self.invoices_list.clear()
        if not data["invoices"]:
            self.invoices_list.addItem("No invoices on file.")
        for row in data["invoices"]:
            self.invoices_list.addItem(
                f"{row['invoice_number']} — {row['date']:%Y-%m-%d} — total {row['total']:.2f}, "
                f"paid {row['paid']:.2f}, due {row['due']:.2f} [{row['status']}]"
            )

        self.lab_results_list.clear()
        if not data["lab_results"]:
            self.lab_results_list.addItem("No verified lab reports yet.")
        for row in data["lab_results"]:
            flag = " (abnormal)" if row["is_abnormal"] else ""
            date_text = row["date"].strftime("%Y-%m-%d") if row["date"] else ""
            self.lab_results_list.addItem(f"{date_text} — {row['test']}: {row['value']}{flag}")

    def _logout(self) -> None:
        self._patient = None
        self.login_uhid.clear()
        self.login_mobile.clear()
        self.stack.setCurrentIndex(0)
