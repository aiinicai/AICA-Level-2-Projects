from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.appointment_service import (
    book_appointment,
    cancel_appointment,
    doctor_queue_for_date,
    list_departments,
    list_doctors,
    mark_no_show,
    reschedule_appointment,
    start_visit,
)
from app.services.communication_service import send_notification
from app.services.patient_service import get_patient, search_patients
from app.ui.label_utils import add_choice_items, humanize


class AppointmentScreen(QWidget):
    """Book a walk-in/scheduled appointment and view the doctor's token queue (spec 4)."""

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._patient_id = None
        self._selected_appointment = None
        self._build_ui()
        self._reload_doctors()

    def _build_ui(self) -> None:
        outer = QHBoxLayout(self)

        booking_box = QGroupBox("Book appointment")
        form = QFormLayout(booking_box)

        self.patient_search = QLineEdit()
        self.patient_search.setPlaceholderText("Search patient by UHID / name / mobile")
        self.patient_search.textChanged.connect(self._search_patient)
        self.patient_results = QListWidget()
        self.patient_results.setMaximumHeight(80)
        self.patient_results.itemClicked.connect(self._select_patient)
        self.patient_results.itemActivated.connect(self._select_patient)
        self.selected_patient_label = QLabel("No patient selected.")
        self.selected_patient_label.setStyleSheet("color: grey;")

        self.doctor_combo = QComboBox()
        self.appointment_type = QComboBox()
        add_choice_items(self.appointment_type, ["walk_in", "scheduled", "referral", "follow_up"])
        self.appointment_date = QDateEdit(calendarPopup=True)
        self.appointment_date.setDate(_dt.date.today())

        form.addRow("Patient", self.patient_search)
        form.addRow(self.patient_results)
        form.addRow(self.selected_patient_label)
        form.addRow("Doctor", self.doctor_combo)
        form.addRow("Type", self.appointment_type)
        form.addRow("Date", self.appointment_date)

        book_button = QPushButton("Book appointment")
        book_button.clicked.connect(self._book)
        form.addRow(book_button)

        outer.addWidget(booking_box)

        queue_box = QGroupBox("Doctor queue for selected date")
        queue_layout = QVBoxLayout(queue_box)
        refresh_button = QPushButton("Refresh queue")
        refresh_button.clicked.connect(self._refresh_queue)
        queue_layout.addWidget(refresh_button)
        self.queue_list = QListWidget()
        self.queue_list.itemClicked.connect(self._select_queue_appointment)
        self.queue_list.itemActivated.connect(self._select_queue_appointment)
        queue_layout.addWidget(self.queue_list)

        action_form = QFormLayout()
        checkin_button = QPushButton("Check in (start visit)")
        checkin_button.clicked.connect(self._check_in)
        action_form.addRow(checkin_button)

        cancel_button = QPushButton("Cancel appointment")
        cancel_button.clicked.connect(self._cancel_selected)
        no_show_button = QPushButton("Mark no-show")
        no_show_button.clicked.connect(self._mark_no_show_selected)
        cancel_row = QHBoxLayout()
        cancel_row.addWidget(cancel_button)
        cancel_row.addWidget(no_show_button)
        action_form.addRow(cancel_row)

        self.reschedule_date = QDateEdit(calendarPopup=True)
        self.reschedule_date.setDate(_dt.date.today())
        reschedule_button = QPushButton("Reschedule selected to this date")
        reschedule_button.clicked.connect(self._reschedule_selected)
        action_form.addRow("New date", self.reschedule_date)
        action_form.addRow(reschedule_button)

        queue_layout.addLayout(action_form)

        outer.addWidget(queue_box)

    def _reload_doctors(self) -> None:
        self.doctor_combo.clear()
        for doctor in list_doctors():
            self.doctor_combo.addItem(f"{doctor.full_name}", userData=doctor.id)

    def _search_patient(self, term: str) -> None:
        self.patient_results.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            item_text = f"{patient.uhid} — {patient.full_name} — {patient.mobile_number}"
            self.patient_results.addItem(item_text)
            self.patient_results.item(self.patient_results.count() - 1).setData(1, patient.id)

    def _select_patient(self, item) -> None:
        self._patient_id = item.data(1)
        self.selected_patient_label.setText(f"Selected: {item.text()}")
        self.selected_patient_label.setStyleSheet("color: green; font-weight: bold;")

    def _book(self) -> None:
        if self._patient_id is None:
            QMessageBox.warning(self, "Book appointment", "Please select a patient first.")
            return
        doctor_id = self.doctor_combo.currentData()
        if doctor_id is None:
            QMessageBox.warning(self, "Book appointment", "No doctor available. Add doctors first.")
            return
        appt = book_appointment(
            patient_id=self._patient_id,
            doctor_id=doctor_id,
            appointment_date=self.appointment_date.date().toPython(),
            appointment_type=self.appointment_type.currentData(),
            created_by_id=self.session_user.id,
        )
        self._send_confirmation(appt)
        QMessageBox.information(self, "Appointment booked", f"Token number: {appt.token_number}")
        self._refresh_queue()

    def _send_confirmation(self, appt) -> None:
        """Best-effort SMS/email confirmation (spec Phase 4: SMS/WhatsApp/
        email notifications). Never lets a notification problem undo a
        successful booking — failures are recorded in the communication
        log (Settings -> Notifications), not raised here.
        """
        try:
            patient = get_patient(self._patient_id)
            if not patient:
                return
            message = (
                f"Dear {patient.full_name}, your appointment (token {appt.token_number}) "
                f"is confirmed for {appt.appointment_date}."
            )
            if patient.mobile_number:
                send_notification("sms", patient.mobile_number, message, patient_id=patient.id,
                                   template_key="appointment_confirmation")
            if patient.email:
                send_notification("email", patient.email, message, subject="Appointment confirmed",
                                   patient_id=patient.id, template_key="appointment_confirmation")
        except Exception:  # noqa: BLE001 — never break a successful booking over a notification issue
            pass

    def _refresh_queue(self) -> None:
        doctor_id = self.doctor_combo.currentData()
        if doctor_id is None:
            return
        self.queue_list.clear()
        self._queue_by_row = []
        for appt in doctor_queue_for_date(doctor_id, self.appointment_date.date().toPython()):
            self._queue_by_row.append(appt)
            self.queue_list.addItem(
                f"Token {appt.token_number} — patient #{appt.patient_id} — {humanize(appt.status)}"
            )
        self._selected_appointment = None

    def _select_queue_appointment(self, item) -> None:
        row = self.queue_list.row(item)
        self._selected_appointment = self._queue_by_row[row]

    def _check_in(self) -> None:
        if self._selected_appointment is None:
            QMessageBox.warning(self, "Check in", "Select an appointment from the queue first.")
            return
        try:
            visit = start_visit(self._selected_appointment, created_by_id=self.session_user.id)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Check in", str(exc))
            return
        QMessageBox.information(
            self, "Checked in",
            f"Visit #{visit.id} opened. Use the Consultation screen (doctor role / administrator) "
            "to record vitals, notes, and a prescription against this visit.",
        )
        self._refresh_queue()

    def _cancel_selected(self) -> None:
        if self._selected_appointment is None:
            QMessageBox.warning(self, "Cancel appointment", "Select an appointment from the queue first.")
            return
        cancel_appointment(self._selected_appointment.id)
        self._refresh_queue()

    def _mark_no_show_selected(self) -> None:
        if self._selected_appointment is None:
            QMessageBox.warning(self, "Mark no-show", "Select an appointment from the queue first.")
            return
        mark_no_show(self._selected_appointment.id)
        self._refresh_queue()

    def _reschedule_selected(self) -> None:
        if self._selected_appointment is None:
            QMessageBox.warning(self, "Reschedule", "Select an appointment from the queue first.")
            return
        reschedule_appointment(self._selected_appointment.id, self.reschedule_date.date().toPython())
        QMessageBox.information(self, "Rescheduled", "Appointment rescheduled and given a new token.")
        self._refresh_queue()
