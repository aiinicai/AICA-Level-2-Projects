from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDateTimeEdit,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.appointment_service import list_doctors
from app.services.ot_service import (
    PreOpIncompleteError,
    ProcedureInput,
    add_consumable,
    add_procedure,
    complete_procedure,
    generate_procedure_invoice,
    list_bookings,
    list_procedures,
    mark_preop_ready,
    schedule_booking,
    start_procedure,
)
from app.services.patient_service import search_patients
from app.services.pdf_service import generate_invoice_pdf


class OTScreen(QWidget):
    """Procedure catalog, OT scheduling, and the pre-op -> in-progress ->
    post-op -> billing workflow (spec section 12).
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._patient_id = None
        self._selected_booking_id = None
        self._last_invoice_id = None
        self._build_ui()
        self._reload_procedures()
        self._reload_doctors()
        self._refresh_bookings()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_catalog_tab(), "Procedure catalog")
        tabs.addTab(self._build_schedule_tab(), "Schedule booking")
        tabs.addTab(self._build_manage_tab(), "Manage booking")

    def _build_catalog_tab(self) -> QWidget:
        box = QGroupBox("Add procedure to catalog")
        form = QFormLayout(box)
        self.new_procedure_name = QLineEdit()
        self.new_procedure_department = QLineEdit()
        self.new_procedure_duration = QSpinBox()
        self.new_procedure_duration.setMaximum(1000)
        self.new_procedure_price = QDoubleSpinBox()
        self.new_procedure_price.setMaximum(1_000_000)

        form.addRow("Name*", self.new_procedure_name)
        form.addRow("Department", self.new_procedure_department)
        form.addRow("Estimated duration (min)", self.new_procedure_duration)
        form.addRow("Price", self.new_procedure_price)

        add_button = QPushButton("Add procedure")
        add_button.clicked.connect(self._add_procedure)
        form.addRow(add_button)

        return box

    def _build_schedule_tab(self) -> QWidget:
        box = QGroupBox("Schedule OT booking")
        form = QFormLayout(box)

        self.patient_search = QLineEdit()
        self.patient_search.setPlaceholderText("Search patient")
        self.patient_search.textChanged.connect(self._search_patient)
        self.patient_results = QListWidget()
        self.patient_results.setMaximumHeight(70)
        self.patient_results.itemClicked.connect(self._select_patient)
        self.patient_results.itemActivated.connect(self._select_patient)
        self.selected_patient_label = QLabel("No patient selected.")
        self.selected_patient_label.setStyleSheet("color: grey;")

        self.procedure_combo = QComboBox()
        self.surgeon_combo = QComboBox()
        self.anesthetist_combo = QComboBox()
        self.scheduled_at = QDateTimeEdit(_dt.datetime.now())
        self.scheduled_at.setCalendarPopup(True)
        self.nursing_team = QLineEdit()
        self.theatre_room = QLineEdit()

        form.addRow("Patient", self.patient_search)
        form.addRow(self.patient_results)
        form.addRow(self.selected_patient_label)
        form.addRow("Procedure", self.procedure_combo)
        form.addRow("Surgeon", self.surgeon_combo)
        form.addRow("Anesthetist", self.anesthetist_combo)
        form.addRow("Scheduled at", self.scheduled_at)
        form.addRow("Nursing team", self.nursing_team)
        form.addRow("Theatre room", self.theatre_room)

        schedule_button = QPushButton("Schedule")
        schedule_button.clicked.connect(self._schedule)
        form.addRow(schedule_button)

        return box

    def _build_manage_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        list_box = QGroupBox("Bookings")
        list_layout = QVBoxLayout(list_box)
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_bookings)
        list_layout.addWidget(refresh_button)
        self.booking_list = QListWidget()
        self.booking_list.itemClicked.connect(self._select_booking)
        self.booking_list.itemActivated.connect(self._select_booking)
        list_layout.addWidget(self.booking_list)

        action_box = QGroupBox("Pre-op / procedure / consumables")
        action_form = QFormLayout(action_box)

        self.preop_checklist = QCheckBox("Pre-operative checklist complete")
        self.preop_consent = QCheckBox("Consent obtained")
        mark_preop_button = QPushButton("Save pre-op status")
        mark_preop_button.clicked.connect(self._mark_preop)
        action_form.addRow(self.preop_checklist)
        action_form.addRow(self.preop_consent)
        action_form.addRow(mark_preop_button)

        start_button = QPushButton("Start procedure")
        start_button.clicked.connect(self._start)
        action_form.addRow(start_button)

        self.procedure_notes = QPlainTextEdit()
        self.procedure_notes.setPlaceholderText("Procedure notes")
        self.recovery_notes = QPlainTextEdit()
        self.recovery_notes.setPlaceholderText("Post-op recovery notes")
        complete_button = QPushButton("Complete procedure")
        complete_button.clicked.connect(self._complete)
        action_form.addRow(self.procedure_notes)
        action_form.addRow(self.recovery_notes)
        action_form.addRow(complete_button)

        self.consumable_desc = QLineEdit()
        self.consumable_qty = QDoubleSpinBox()
        self.consumable_qty.setValue(1)
        self.consumable_qty.setMaximum(100000)
        self.consumable_price = QDoubleSpinBox()
        self.consumable_price.setMaximum(1_000_000)
        add_consumable_button = QPushButton("Add consumable")
        add_consumable_button.clicked.connect(self._add_consumable)
        action_form.addRow("Consumable description", self.consumable_desc)
        action_form.addRow("Quantity", self.consumable_qty)
        action_form.addRow("Unit price", self.consumable_price)
        action_form.addRow(add_consumable_button)

        invoice_button = QPushButton("Generate procedure invoice")
        invoice_button.clicked.connect(self._generate_invoice)
        action_form.addRow(invoice_button)

        print_invoice_button = QPushButton("Print last procedure invoice (PDF)...")
        print_invoice_button.clicked.connect(self._print_invoice_pdf)
        action_form.addRow(print_invoice_button)

        layout.addWidget(list_box)
        layout.addWidget(action_box)
        return box

    # -- data loading -------------------------------------------------------
    def _reload_procedures(self) -> None:
        self.procedure_combo.clear()
        for procedure in list_procedures():
            self.procedure_combo.addItem(f"{procedure.name} ({procedure.price:.2f})", userData=procedure.id)

    def _reload_doctors(self) -> None:
        self.surgeon_combo.clear()
        self.anesthetist_combo.addItem("(none)", userData=None)
        for doctor in list_doctors():
            self.surgeon_combo.addItem(doctor.full_name, userData=doctor.id)
            self.anesthetist_combo.addItem(doctor.full_name, userData=doctor.id)

    def _search_patient(self, term: str) -> None:
        self.patient_results.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            self.patient_results.addItem(f"{patient.uhid} — {patient.full_name}")
            self.patient_results.item(self.patient_results.count() - 1).setData(1, patient.id)

    def _select_patient(self, item) -> None:
        self._patient_id = item.data(1)
        self.selected_patient_label.setText(f"Selected: {item.text()}")
        self.selected_patient_label.setStyleSheet("color: green; font-weight: bold;")

    def _add_procedure(self) -> None:
        if not self.new_procedure_name.text().strip():
            QMessageBox.warning(self, "Add procedure", "Procedure name is required.")
            return
        add_procedure(ProcedureInput(
            name=self.new_procedure_name.text().strip(),
            department=self.new_procedure_department.text() or None,
            estimated_duration_minutes=self.new_procedure_duration.value() or None,
            price=self.new_procedure_price.value(),
        ))
        self.new_procedure_name.clear()
        self._reload_procedures()
        QMessageBox.information(self, "Procedure added", "Added to the catalog.")

    def _schedule(self) -> None:
        if self._patient_id is None:
            QMessageBox.warning(self, "Schedule booking", "Select a patient first.")
            return
        procedure_id = self.procedure_combo.currentData()
        surgeon_id = self.surgeon_combo.currentData()
        if procedure_id is None or surgeon_id is None:
            QMessageBox.warning(self, "Schedule booking", "Add a procedure and a doctor first.")
            return
        booking = schedule_booking(
            patient_id=self._patient_id, procedure_id=procedure_id, surgeon_id=surgeon_id,
            scheduled_at=self.scheduled_at.dateTime().toPython(),
            anesthetist_id=self.anesthetist_combo.currentData(),
            nursing_team=self.nursing_team.text() or None,
            theatre_room=self.theatre_room.text() or None,
            created_by_id=self.session_user.id,
        )
        QMessageBox.information(self, "Booking scheduled", f"Booking #{booking.id} scheduled.")
        self._refresh_bookings()

    def _refresh_bookings(self) -> None:
        self.booking_list.clear()
        for booking in list_bookings():
            item_text = f"#{booking.id} — patient #{booking.patient_id} — {booking.status} — {booking.scheduled_at:%Y-%m-%d %H:%M}"
            self.booking_list.addItem(item_text)
            self.booking_list.item(self.booking_list.count() - 1).setData(1, booking.id)

    def _select_booking(self, item) -> None:
        self._selected_booking_id = item.data(1)

    def _mark_preop(self) -> None:
        if self._selected_booking_id is None:
            QMessageBox.warning(self, "Pre-op", "Select a booking first.")
            return
        mark_preop_ready(self._selected_booking_id, self.preop_checklist.isChecked(), self.preop_consent.isChecked())
        self._refresh_bookings()

    def _start(self) -> None:
        if self._selected_booking_id is None:
            QMessageBox.warning(self, "Start procedure", "Select a booking first.")
            return
        try:
            start_procedure(self._selected_booking_id)
        except PreOpIncompleteError as exc:
            QMessageBox.critical(self, "Start procedure", str(exc))
            return
        self._refresh_bookings()

    def _complete(self) -> None:
        if self._selected_booking_id is None:
            QMessageBox.warning(self, "Complete procedure", "Select a booking first.")
            return
        notes = self.procedure_notes.toPlainText().strip()
        if not notes:
            QMessageBox.warning(self, "Complete procedure", "Procedure notes are required.")
            return
        complete_procedure(self._selected_booking_id, notes, self.recovery_notes.toPlainText() or None)
        self.procedure_notes.clear()
        self.recovery_notes.clear()
        self._refresh_bookings()

    def _add_consumable(self) -> None:
        if self._selected_booking_id is None:
            QMessageBox.warning(self, "Add consumable", "Select a booking first.")
            return
        if not self.consumable_desc.text().strip():
            return
        add_consumable(self._selected_booking_id, self.consumable_desc.text().strip(),
                        self.consumable_qty.value(), self.consumable_price.value())
        self.consumable_desc.clear()

    def _generate_invoice(self) -> None:
        if self._selected_booking_id is None:
            QMessageBox.warning(self, "Generate invoice", "Select a booking first.")
            return
        invoice = generate_procedure_invoice(self._selected_booking_id, created_by_id=self.session_user.id)
        self._last_invoice_id = invoice.id
        QMessageBox.information(self, "Invoice generated", f"{invoice.invoice_number} — {invoice.total_amount:.2f}")

    def _print_invoice_pdf(self) -> None:
        """Save the last-generated OT procedure invoice as a PDF (spec 17)
        — before this it was only ever a QMessageBox summary."""
        if not self._last_invoice_id:
            QMessageBox.warning(self, "Print invoice", "Generate a procedure invoice first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save invoice as PDF", f"ot_invoice_{self._last_invoice_id}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        try:
            generate_invoice_pdf(self._last_invoice_id, path)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Print invoice", f"Could not generate the PDF:\n{exc}")
            return
        QMessageBox.information(self, "Invoice saved", f"Invoice PDF saved to:\n{path}")
