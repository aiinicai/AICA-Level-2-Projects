from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.ui.label_utils import add_choice_items
from app.services.lab_service import (
    LabTestInput,
    add_test,
    collect_sample,
    enter_result,
    list_tests,
    pending_report_items,
    place_order,
    receive_sample,
    verify_result,
)
from app.services.patient_service import search_patients


class LaboratoryScreen(QWidget):
    """Test catalog, ordering, and the sample -> result -> verify workflow (spec section 8)."""

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._patient_id = None
        self._build_ui()
        self._reload_tests()
        self._refresh_pending()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_order_tab(), "Order tests")
        tabs.addTab(self._build_pending_tab(), "Pending reports / results")
        tabs.addTab(self._build_catalog_tab(), "Test catalog")

    def _build_order_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        left = QGroupBox("Place order")
        form = QFormLayout(left)

        self.patient_search = QLineEdit()
        self.patient_search.setPlaceholderText("Search patient")
        self.patient_search.textChanged.connect(self._search_patient)
        self.patient_results = QListWidget()
        self.patient_results.setMaximumHeight(70)
        self.patient_results.itemClicked.connect(self._select_patient)
        self.patient_results.itemActivated.connect(self._select_patient)
        self.selected_patient_label = QLabel("No patient selected.")
        self.selected_patient_label.setStyleSheet("color: grey;")

        self.test_checklist = QListWidget()
        self.test_checklist.setSelectionMode(QListWidget.MultiSelection)

        order_button = QPushButton("Place order for selected tests")
        order_button.clicked.connect(self._place_order)

        form.addRow("Patient", self.patient_search)
        form.addRow(self.patient_results)
        form.addRow(self.selected_patient_label)
        form.addRow("Tests (multi-select)", self.test_checklist)
        form.addRow(order_button)

        layout.addWidget(left)
        return box

    def _build_pending_tab(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)

        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_pending)
        layout.addWidget(refresh_button)

        self.pending_list = QListWidget()
        self.pending_list.itemClicked.connect(self._select_pending_item)
        self.pending_list.itemActivated.connect(self._select_pending_item)
        layout.addWidget(self.pending_list)

        action_row = QHBoxLayout()
        collect_button = QPushButton("Mark sample collected")
        collect_button.clicked.connect(self._collect)
        received_button = QPushButton("Mark received in lab")
        received_button.clicked.connect(self._receive)
        action_row.addWidget(collect_button)
        action_row.addWidget(received_button)
        layout.addLayout(action_row)

        result_form = QFormLayout()
        self.result_value = QLineEdit()
        self.result_abnormal = QCheckBox("Abnormal")
        enter_button = QPushButton("Enter result")
        enter_button.clicked.connect(self._enter_result)
        verify_button = QPushButton("Verify result")
        verify_button.clicked.connect(self._verify)

        result_form.addRow("Result value", self.result_value)
        result_form.addRow(self.result_abnormal)
        result_form.addRow(enter_button)
        result_form.addRow(verify_button)
        layout.addLayout(result_form)

        return box

    def _build_catalog_tab(self) -> QWidget:
        box = QGroupBox("Add test to catalog")
        form = QFormLayout(box)

        self.new_test_name = QLineEdit()
        self.new_test_department = QLineEdit()
        self.new_test_specimen = QLineEdit()
        self.new_test_normal_range = QLineEdit()
        self.new_test_unit = QLineEdit()
        self.new_test_result_type = QComboBox()
        add_choice_items(self.new_test_result_type, ["numeric", "text", "positive_negative", "selectable"])
        self.new_test_price = QDoubleSpinBox()
        self.new_test_price.setMaximum(1_000_000)

        form.addRow("Name*", self.new_test_name)
        form.addRow("Department", self.new_test_department)
        form.addRow("Specimen type", self.new_test_specimen)
        form.addRow("Normal range", self.new_test_normal_range)
        form.addRow("Unit", self.new_test_unit)
        form.addRow("Result type", self.new_test_result_type)
        form.addRow("Price", self.new_test_price)

        add_button = QPushButton("Add test")
        add_button.clicked.connect(self._add_test)
        form.addRow(add_button)

        return box

    def _reload_tests(self) -> None:
        self.test_checklist.clear()
        for test in list_tests():
            item = QListWidgetItem(f"{test.name} — {test.price:.2f}")
            item.setData(1, test.id)
            self.test_checklist.addItem(item)

    def _search_patient(self, term: str) -> None:
        self.patient_results.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            self.patient_results.addItem(f"{patient.uhid} — {patient.full_name}")
            self.patient_results.item(self.patient_results.count() - 1).setData(1, patient.id)

    def _select_patient(self, item) -> None:
        self._patient_id = item.data(1)
        self.selected_patient_label.setText(f"Selected: {item.text()}")
        self.selected_patient_label.setStyleSheet("color: green; font-weight: bold;")

    def _place_order(self) -> None:
        if self._patient_id is None:
            QMessageBox.warning(self, "Place order", "Select a patient first.")
            return
        test_ids = [item.data(1) for item in self.test_checklist.selectedItems()]
        if not test_ids:
            QMessageBox.warning(self, "Place order", "Select at least one test.")
            return
        order = place_order(patient_id=self._patient_id, test_ids=test_ids, ordered_by_id=self.session_user.id)
        QMessageBox.information(self, "Order placed", f"Sample barcode: {order.sample_barcode}")
        self._refresh_pending()

    def _refresh_pending(self) -> None:
        self.pending_list.clear()
        for entry in pending_report_items():
            item = QListWidgetItem(
                f"[{entry['status']}] {entry['test_name']} — patient #{entry['patient_id']} — "
                f"{entry['sample_barcode']}"
            )
            item.setData(1, entry["order_item_id"])
            self.pending_list.addItem(item)

    def _selected_order_item_id(self):
        item = self.pending_list.currentItem()
        return item.data(1) if item else None

    def _select_pending_item(self, item) -> None:
        pass  # selection is read via currentItem() in the action handlers

    def _collect(self) -> None:
        order_item_id = self._selected_order_item_id()
        if order_item_id is None:
            QMessageBox.warning(self, "Sample collection", "Select an order in the list first.")
            return
        collect_sample(order_item_id)
        self._refresh_pending()

    def _receive(self) -> None:
        order_item_id = self._selected_order_item_id()
        if order_item_id is None:
            QMessageBox.warning(self, "Sample received", "Select an order in the list first.")
            return
        receive_sample(order_item_id)
        self._refresh_pending()

    def _enter_result(self) -> None:
        order_item_id = self._selected_order_item_id()
        if order_item_id is None:
            QMessageBox.warning(self, "Enter result", "Select an order in the list first.")
            return
        if not self.result_value.text().strip():
            QMessageBox.warning(self, "Enter result", "Enter a result value.")
            return
        enter_result(
            order_item_id, self.result_value.text().strip(),
            is_abnormal=self.result_abnormal.isChecked(), entered_by_id=self.session_user.id,
        )
        self.result_value.clear()
        self.result_abnormal.setChecked(False)
        self._refresh_pending()

    def _verify(self) -> None:
        order_item_id = self._selected_order_item_id()
        if order_item_id is None:
            QMessageBox.warning(self, "Verify result", "Select an order in the list first.")
            return
        try:
            verify_result(order_item_id, verified_by_id=self.session_user.id)
        except ValueError as exc:
            QMessageBox.critical(self, "Verify result", str(exc))
            return
        self._refresh_pending()

    def _add_test(self) -> None:
        if not self.new_test_name.text().strip():
            QMessageBox.warning(self, "Add test", "Test name is required.")
            return
        add_test(LabTestInput(
            name=self.new_test_name.text().strip(),
            department=self.new_test_department.text() or None,
            specimen_type=self.new_test_specimen.text() or None,
            normal_range=self.new_test_normal_range.text() or None,
            unit=self.new_test_unit.text() or None,
            result_type=self.new_test_result_type.currentData(),
            price=self.new_test_price.value(),
        ))
        self.new_test_name.clear()
        self._reload_tests()
        QMessageBox.information(self, "Test added", "Added to the catalog.")
