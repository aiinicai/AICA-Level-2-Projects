from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.barcode_service import generate_barcode_image
from app.services.medicine_service import (
    MedicineInput,
    add_batch,
    add_medicine,
    expiring_batches,
    list_medicines,
    low_stock_medicines,
    stock_for_medicine,
    total_stock,
)
from app.services.patient_service import search_patients
from app.services.pdf_service import generate_invoice_pdf
from app.services.pharmacy_service import DispenseLine, dispense
from app.services.medicine_service import InsufficientStockError


class PharmacyScreen(QWidget):
    """Dispensing, medicine master, and stock alerts (spec section 9)."""

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._patient_id = None
        self._last_batch_number = None
        self._last_dispense_invoice_id = None
        self._dispense_lines: list[DispenseLine] = []
        self._build_ui()
        self._reload_medicines()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_dispense_tab(), "Dispense")
        tabs.addTab(self._build_medicine_tab(), "Medicine master && batches")
        tabs.addTab(self._build_alerts_tab(), "Stock alerts")

    # -- Dispense tab --------------------------------------------------
    def _build_dispense_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        left = QGroupBox("New sale")
        form = QFormLayout(left)

        self.patient_search = QLineEdit()
        self.patient_search.setPlaceholderText("Search patient")
        self.patient_search.textChanged.connect(self._search_patient)
        self.patient_results = QListWidget()
        self.patient_results.setMaximumHeight(70)
        # Both signals are wired: itemClicked for mouse, itemActivated for
        # keyboard (Enter/Return after arrowing to a row) — only wiring one
        # meant keyboard-only selection silently did nothing.
        self.patient_results.itemClicked.connect(self._select_patient)
        self.patient_results.itemActivated.connect(self._select_patient)
        self.selected_patient_label = QLabel("No patient selected.")
        self.selected_patient_label.setStyleSheet("color: grey;")

        self.medicine_combo = QComboBox()
        self.quantity = QSpinBox()
        self.quantity.setMinimum(1)
        self.unit_price = QDoubleSpinBox()
        self.unit_price.setMaximum(1_000_000)
        self.substitution_note = QLineEdit()
        self.substitution_note.setPlaceholderText("Substitution note (optional)")

        add_line_button = QPushButton("Add to sale")
        add_line_button.clicked.connect(self._add_line)

        form.addRow("Patient", self.patient_search)
        form.addRow(self.patient_results)
        form.addRow(self.selected_patient_label)
        form.addRow("Medicine", self.medicine_combo)
        form.addRow("Quantity", self.quantity)
        form.addRow("Unit price", self.unit_price)
        form.addRow("Substitution note", self.substitution_note)
        form.addRow(add_line_button)

        self.line_list = QListWidget()
        form.addRow(self.line_list)

        dispense_button = QPushButton("Dispense && bill")
        dispense_button.clicked.connect(self._dispense)
        form.addRow(dispense_button)

        print_bill_button = QPushButton("Print last bill (PDF)...")
        print_bill_button.clicked.connect(self._print_dispense_bill)
        form.addRow(print_bill_button)

        layout.addWidget(left)
        return box

    # -- Medicine master tab --------------------------------------------
    def _build_medicine_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        med_box = QGroupBox("Add medicine")
        med_form = QFormLayout(med_box)
        self.new_generic_name = QLineEdit()
        self.new_dosage_form = QLineEdit()
        self.new_strength = QLineEdit()
        self.new_mrp = QDoubleSpinBox()
        self.new_mrp.setMaximum(1_000_000)
        self.new_sale_price = QDoubleSpinBox()
        self.new_sale_price.setMaximum(1_000_000)
        self.new_tax = QDoubleSpinBox()
        self.new_tax.setMaximum(100)
        self.new_reorder = QSpinBox()
        self.new_reorder.setMaximum(100000)
        self.new_reorder.setValue(10)

        med_form.addRow("Generic name*", self.new_generic_name)
        med_form.addRow("Dosage form", self.new_dosage_form)
        med_form.addRow("Strength", self.new_strength)
        med_form.addRow("MRP", self.new_mrp)
        med_form.addRow("Sale price", self.new_sale_price)
        med_form.addRow("Tax %", self.new_tax)
        med_form.addRow("Reorder level", self.new_reorder)

        add_med_button = QPushButton("Add medicine")
        add_med_button.clicked.connect(self._add_medicine)
        med_form.addRow(add_med_button)

        batch_box = QGroupBox("Receive batch")
        batch_form = QFormLayout(batch_box)
        self.batch_medicine_combo = QComboBox()
        self.batch_number = QLineEdit()
        self.batch_expiry = QDateEdit(calendarPopup=True)
        self.batch_expiry.setDate(_dt.date.today().replace(year=_dt.date.today().year + 1))
        self.batch_quantity = QSpinBox()
        self.batch_quantity.setMaximum(1_000_000)
        self.batch_purchase_price = QDoubleSpinBox()
        self.batch_purchase_price.setMaximum(1_000_000)

        batch_form.addRow("Medicine", self.batch_medicine_combo)
        batch_form.addRow("Batch number*", self.batch_number)
        batch_form.addRow("Expiry date*", self.batch_expiry)
        batch_form.addRow("Quantity*", self.batch_quantity)
        batch_form.addRow("Purchase price", self.batch_purchase_price)

        add_batch_button = QPushButton("Receive batch")
        add_batch_button.clicked.connect(self._add_batch)
        batch_form.addRow(add_batch_button)

        self.batch_stock_list = QListWidget()
        batch_form.addRow(self.batch_stock_list)

        barcode_button = QPushButton("Print last batch's barcode...")
        barcode_button.clicked.connect(self._print_batch_barcode)
        batch_form.addRow(barcode_button)

        layout.addWidget(med_box)
        layout.addWidget(batch_box)
        return box

    def _print_batch_barcode(self) -> None:
        """Generate a Code128 barcode for the most recently received batch
        number (spec Phase 4: barcode scanners) — print it onto the shelf/
        bin label, and a scanner reads it straight back into the "Batch
        number*" field above since a scanner is just a fast typist.
        """
        if not self._last_batch_number:
            QMessageBox.warning(self, "Print barcode", "Receive a batch first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save barcode image", f"{self._last_batch_number}_barcode.png", "PNG Files (*.png)"
        )
        if not path:
            return
        saved_path = generate_barcode_image(self._last_batch_number, path)
        QMessageBox.information(self, "Barcode saved", f"Batch barcode saved to {saved_path}")

    # -- Alerts tab ------------------------------------------------------
    def _build_alerts_tab(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)

        refresh_button = QPushButton("Refresh alerts")
        refresh_button.clicked.connect(self._refresh_alerts)
        layout.addWidget(refresh_button)

        layout.addWidget(QGroupBox_label("Low stock (at/under reorder level)"))
        self.low_stock_list = QListWidget()
        layout.addWidget(self.low_stock_list)

        layout.addWidget(QGroupBox_label("Expiring within 90 days"))
        self.expiry_list = QListWidget()
        layout.addWidget(self.expiry_list)

        return box

    # -- data / behaviour --------------------------------------------------
    def _reload_medicines(self) -> None:
        self.medicine_combo.clear()
        self.batch_medicine_combo.clear()
        for medicine in list_medicines():
            label = f"{medicine.generic_name} {medicine.strength or ''}".strip()
            self.medicine_combo.addItem(label, userData=medicine.id)
            self.batch_medicine_combo.addItem(label, userData=medicine.id)

    def _search_patient(self, term: str) -> None:
        self.patient_results.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            self.patient_results.addItem(f"{patient.uhid} — {patient.full_name}")
            self.patient_results.item(self.patient_results.count() - 1).setData(1, patient.id)

    def _select_patient(self, item) -> None:
        self._patient_id = item.data(1)
        self.selected_patient_label.setText(f"Selected: {item.text()}")
        self.selected_patient_label.setStyleSheet("color: green; font-weight: bold;")

    def _add_line(self) -> None:
        medicine_id = self.medicine_combo.currentData()
        if medicine_id is None:
            QMessageBox.warning(self, "Add to sale", "Add a medicine first (Medicine master tab).")
            return
        available = total_stock(medicine_id)
        if available < self.quantity.value():
            QMessageBox.warning(self, "Add to sale", f"Only {available} unit(s) in stock.")
            return
        line = DispenseLine(
            medicine_id=medicine_id,
            quantity=self.quantity.value(),
            unit_price=self.unit_price.value(),
            substitution_note=self.substitution_note.text() or None,
        )
        self._dispense_lines.append(line)
        self.line_list.addItem(
            f"{self.medicine_combo.currentText()} x{line.quantity} @ {line.unit_price}"
            + (f" [substituted: {line.substitution_note}]" if line.substitution_note else "")
        )
        self.quantity.setValue(1)
        self.unit_price.setValue(0)
        self.substitution_note.clear()

    def _dispense(self) -> None:
        if self._patient_id is None:
            QMessageBox.warning(self, "Dispense", "Select a patient first.")
            return
        if not self._dispense_lines:
            QMessageBox.warning(self, "Dispense", "Add at least one medicine.")
            return
        try:
            result = dispense(
                patient_id=self._patient_id,
                lines=self._dispense_lines,
                dispensed_by_id=self.session_user.id,
            )
        except InsufficientStockError as exc:
            QMessageBox.critical(self, "Dispense", str(exc))
            return
        QMessageBox.information(
            self, "Dispensed",
            f"Invoice {result.invoice_number} — total {result.total_amount:.2f}",
        )
        self._last_dispense_invoice_id = result.invoice_id
        self._dispense_lines = []
        self.line_list.clear()
        self._reload_medicines()

    def _print_dispense_bill(self) -> None:
        """Save the most recently dispensed sale's invoice as a PDF bill
        (spec 17) — before this, dispensing only ever showed a summary
        dialog with the invoice number and total, nothing printable.
        """
        if not self._last_dispense_invoice_id:
            QMessageBox.warning(self, "Print bill", "Dispense a sale first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save bill as PDF", f"pharmacy_bill_{self._last_dispense_invoice_id}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        try:
            generate_invoice_pdf(self._last_dispense_invoice_id, path)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Print bill", f"Could not generate the PDF:\n{exc}")
            return
        QMessageBox.information(self, "Bill saved", f"Bill PDF saved to:\n{path}")

    def _add_medicine(self) -> None:
        if not self.new_generic_name.text().strip():
            QMessageBox.warning(self, "Add medicine", "Generic name is required.")
            return
        add_medicine(MedicineInput(
            generic_name=self.new_generic_name.text().strip(),
            dosage_form=self.new_dosage_form.text() or None,
            strength=self.new_strength.text() or None,
            mrp=self.new_mrp.value(),
            sale_price=self.new_sale_price.value(),
            tax_percent=self.new_tax.value(),
            reorder_level=self.new_reorder.value(),
        ))
        self.new_generic_name.clear()
        self.new_dosage_form.clear()
        self.new_strength.clear()
        self._reload_medicines()
        QMessageBox.information(self, "Medicine added", "Medicine added to the master list.")

    def _add_batch(self) -> None:
        medicine_id = self.batch_medicine_combo.currentData()
        if medicine_id is None or not self.batch_number.text().strip():
            QMessageBox.warning(self, "Receive batch", "Select a medicine and enter a batch number.")
            return
        self._last_batch_number = self.batch_number.text().strip()
        add_batch(
            medicine_id=medicine_id,
            batch_number=self._last_batch_number,
            expiry_date=self.batch_expiry.date().toPython(),
            quantity=self.batch_quantity.value(),
            purchase_price=self.batch_purchase_price.value(),
            created_by_id=self.session_user.id,
        )
        self.batch_number.clear()
        self._refresh_batch_stock()
        QMessageBox.information(self, "Batch received", "Stock updated.")

    def _refresh_batch_stock(self) -> None:
        medicine_id = self.batch_medicine_combo.currentData()
        self.batch_stock_list.clear()
        if medicine_id is None:
            return
        for batch in stock_for_medicine(medicine_id):
            self.batch_stock_list.addItem(
                f"Batch {batch.batch_number} — qty {batch.quantity_in_stock} — expires {batch.expiry_date}"
            )

    def _refresh_alerts(self) -> None:
        self.low_stock_list.clear()
        for entry in low_stock_medicines():
            self.low_stock_list.addItem(
                f"{entry['medicine'].generic_name}: {entry['current_stock']} in stock "
                f"(reorder level {entry['reorder_level']})"
            )
        self.expiry_list.clear()
        for entry in expiring_batches():
            self.expiry_list.addItem(
                f"{entry['medicine_name']} — batch {entry['batch_number']} — "
                f"{entry['quantity']} units — expires in {entry['days_to_expiry']} day(s)"
            )


def QGroupBox_label(text: str) -> QGroupBox:
    """Small helper: a zero-content QGroupBox used purely as a section caption."""
    box = QGroupBox(text)
    box.setFlat(True)
    box.setMaximumHeight(24)
    return box
