from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.ui.label_utils import add_choice_items
from app.services.admission_service import (
    BedNotAvailableError,
    DischargeBlockedError,
    admit_patient,
    discharge_patient,
    list_active_admissions,
    transfer_bed,
)
from app.services.appointment_service import list_doctors
from app.services.ipd_billing_service import generate_bed_charge_invoice
from app.services.pdf_service import generate_invoice_pdf
from app.services.nursing_service import (
    add_nursing_note,
    current_diet_order,
    list_medication_administrations,
    list_nursing_notes,
    record_medication_administration,
    set_diet_order,
)
from app.services.patient_service import search_patients
from app.services.ward_service import (
    add_bed,
    add_room,
    add_ward,
    available_beds,
    list_beds,
    list_rooms,
    list_wards,
    occupancy_summary,
    set_bed_status,
)


class IPDScreen(QWidget):
    """Ward/bed setup, admissions, bed transfers, nursing charting, and
    discharge with final billing (spec section 6).
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._patient_id = None
        self._selected_admission_id = None
        self._last_ipd_invoice_id = None
        self._build_ui()
        self._reload_wards()
        self._reload_doctors()
        self._refresh_beds()
        self._refresh_admissions()
        self._refresh_occupancy()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_ward_setup_tab(), "Wards, rooms && beds")
        tabs.addTab(self._build_admission_tab(), "Admission")
        tabs.addTab(self._build_active_tab(), "Active admissions / transfer / discharge")
        tabs.addTab(self._build_nursing_tab(), "Nursing chart")

    # -- Ward / bed setup --------------------------------------------------
    def _build_ward_setup_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        ward_box = QGroupBox("Wards && rooms")
        ward_form = QFormLayout(ward_box)
        self.new_ward_name = QLineEdit()
        self.new_ward_type = QComboBox()
        add_choice_items(self.new_ward_type, ["general", "icu", "maternity", "pediatric", "isolation"])
        add_ward_button = QPushButton("Add ward")
        add_ward_button.clicked.connect(self._add_ward)
        ward_form.addRow("Ward name*", self.new_ward_name)
        ward_form.addRow("Type", self.new_ward_type)
        ward_form.addRow(add_ward_button)

        self.room_ward_combo = QComboBox()
        self.new_room_number = QLineEdit()
        add_room_button = QPushButton("Add room")
        add_room_button.clicked.connect(self._add_room)
        ward_form.addRow("Ward", self.room_ward_combo)
        ward_form.addRow("Room number*", self.new_room_number)
        ward_form.addRow(add_room_button)

        bed_box = QGroupBox("Beds")
        bed_form = QFormLayout(bed_box)
        self.bed_room_combo = QComboBox()
        self.new_bed_number = QLineEdit()
        self.new_bed_category = QComboBox()
        add_choice_items(self.new_bed_category, ["general", "semi-private", "private", "icu"])
        self.new_bed_daily_charge = QDoubleSpinBox()
        self.new_bed_daily_charge.setMaximum(1_000_000)
        add_bed_button = QPushButton("Add bed")
        add_bed_button.clicked.connect(self._add_bed)

        bed_form.addRow("Room", self.bed_room_combo)
        bed_form.addRow("Bed number*", self.new_bed_number)
        bed_form.addRow("Category", self.new_bed_category)
        bed_form.addRow("Daily charge", self.new_bed_daily_charge)
        bed_form.addRow(add_bed_button)

        self.occupancy_label = QLabel("Occupancy: —")
        bed_form.addRow(self.occupancy_label)
        self.bed_list = QListWidget()
        bed_form.addRow(self.bed_list)

        layout.addWidget(ward_box)
        layout.addWidget(bed_box)
        return box

    # -- Admission ----------------------------------------------------------
    def _build_admission_tab(self) -> QWidget:
        box = QGroupBox("Admit patient")
        form = QFormLayout(box)

        self.patient_search = QLineEdit()
        self.patient_search.setPlaceholderText("Search patient")
        self.patient_search.textChanged.connect(self._search_patient)
        self.patient_results = QListWidget()
        self.patient_results.setMaximumHeight(70)
        self.patient_results.itemClicked.connect(self._select_patient)
        self.patient_results.itemActivated.connect(self._select_patient)
        self.selected_patient_label = QLabel("No patient selected.")
        self.selected_patient_label.setStyleSheet("color: grey;")

        self.admission_doctor_combo = QComboBox()
        self.admission_source = QComboBox()
        add_choice_items(self.admission_source, ["opd", "emergency", "referral", "direct"])
        self.admission_bed_combo = QComboBox()
        self.admission_diagnosis = QLineEdit()
        self.admission_deposit = QDoubleSpinBox()
        self.admission_deposit.setMaximum(1_000_000)
        self.admission_consent = QCheckBox("Admission consent obtained")

        form.addRow("Patient", self.patient_search)
        form.addRow(self.patient_results)
        form.addRow(self.selected_patient_label)
        form.addRow("Attending doctor", self.admission_doctor_combo)
        form.addRow("Admission source", self.admission_source)
        form.addRow("Available bed", self.admission_bed_combo)
        form.addRow("Provisional diagnosis", self.admission_diagnosis)
        form.addRow("Deposit collected", self.admission_deposit)
        form.addRow(self.admission_consent)

        admit_button = QPushButton("Admit patient")
        admit_button.clicked.connect(self._admit)
        form.addRow(admit_button)

        return box

    # -- Active admissions / transfer / discharge ----------------------------
    def _build_active_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        list_box = QGroupBox("Active admissions")
        list_layout = QVBoxLayout(list_box)
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_admissions)
        list_layout.addWidget(refresh_button)
        self.admission_list = QListWidget()
        self.admission_list.itemClicked.connect(self._select_admission)
        self.admission_list.itemActivated.connect(self._select_admission)
        list_layout.addWidget(self.admission_list)

        action_box = QGroupBox("Transfer / discharge")
        action_form = QFormLayout(action_box)

        self.transfer_bed_combo = QComboBox()
        self.transfer_reason = QLineEdit()
        transfer_button = QPushButton("Transfer bed")
        transfer_button.clicked.connect(self._transfer)
        action_form.addRow("New bed", self.transfer_bed_combo)
        action_form.addRow("Reason", self.transfer_reason)
        action_form.addRow(transfer_button)

        bill_button = QPushButton("Generate interim bill (bed charges so far)")
        bill_button.clicked.connect(self._generate_interim_bill)
        action_form.addRow(bill_button)

        print_bill_button = QPushButton("Print last IPD bill (PDF)...")
        print_bill_button.clicked.connect(self._print_ipd_bill)
        action_form.addRow(print_bill_button)

        self.discharge_summary = QPlainTextEdit()
        self.discharge_summary.setPlaceholderText("Discharge summary*")
        self.discharge_advice = QLineEdit()
        self.discharge_advice.setPlaceholderText("Follow-up advice")
        self.discharge_override = QCheckBox("Override pending-dues check (supervisor use only)")

        discharge_button = QPushButton("Discharge patient (final bill + release bed)")
        discharge_button.clicked.connect(self._discharge)

        action_form.addRow(QLabel("Discharge"))
        action_form.addRow(self.discharge_summary)
        action_form.addRow(self.discharge_advice)
        action_form.addRow(self.discharge_override)
        action_form.addRow(discharge_button)

        layout.addWidget(list_box)
        layout.addWidget(action_box)
        return box

    # -- Nursing chart --------------------------------------------------------
    def _build_nursing_tab(self) -> QWidget:
        box = QWidget()
        layout = QVBoxLayout(box)
        layout.addWidget(QLabel("Select an admission in the previous tab, then chart here."))

        row = QHBoxLayout()

        notes_box = QGroupBox("Nursing / round notes")
        notes_form = QFormLayout(notes_box)
        self.note_type = QComboBox()
        add_choice_items(self.note_type, ["nursing", "doctor_round", "vitals"])
        self.note_text = QPlainTextEdit()
        add_note_button = QPushButton("Add note")
        add_note_button.clicked.connect(self._add_note)
        notes_form.addRow("Type", self.note_type)
        notes_form.addRow(self.note_text)
        notes_form.addRow(add_note_button)
        self.notes_list = QListWidget()
        notes_form.addRow(self.notes_list)

        mar_box = QGroupBox("Medication administration record")
        mar_form = QFormLayout(mar_box)
        self.mar_medicine = QLineEdit()
        self.mar_dose = QLineEdit()
        self.mar_route = QLineEdit()
        add_mar_button = QPushButton("Record administration")
        add_mar_button.clicked.connect(self._add_mar)
        mar_form.addRow("Medicine", self.mar_medicine)
        mar_form.addRow("Dose", self.mar_dose)
        mar_form.addRow("Route", self.mar_route)
        mar_form.addRow(add_mar_button)
        self.mar_list = QListWidget()
        mar_form.addRow(self.mar_list)

        diet_box = QGroupBox("Diet order")
        diet_form = QFormLayout(diet_box)
        self.diet_type = QComboBox()
        add_choice_items(self.diet_type, ["normal", "diabetic", "liquid", "soft", "NPO", "renal"])
        self.diet_instructions = QLineEdit()
        set_diet_button = QPushButton("Set diet order")
        set_diet_button.clicked.connect(self._set_diet)
        self.current_diet_label = QLabel("Current: —")
        diet_form.addRow("Diet type", self.diet_type)
        diet_form.addRow("Instructions", self.diet_instructions)
        diet_form.addRow(set_diet_button)
        diet_form.addRow(self.current_diet_label)

        row.addWidget(notes_box)
        row.addWidget(mar_box)
        row.addWidget(diet_box)
        layout.addLayout(row)
        return box

    # -- data loading ----------------------------------------------------------
    def _reload_wards(self) -> None:
        self.room_ward_combo.clear()
        for ward in list_wards():
            self.room_ward_combo.addItem(ward.name, userData=ward.id)

    def _reload_doctors(self) -> None:
        self.admission_doctor_combo.clear()
        for doctor in list_doctors():
            self.admission_doctor_combo.addItem(doctor.full_name, userData=doctor.id)

    def _refresh_beds(self) -> None:
        self.bed_room_combo.clear()
        for ward in list_wards():
            for room in list_rooms(ward.id):
                self.bed_room_combo.addItem(f"{ward.name} / {room.room_number}", userData=room.id)

        self.admission_bed_combo.clear()
        self.transfer_bed_combo.clear()
        for bed in available_beds():
            self.admission_bed_combo.addItem(f"Bed {bed.bed_number} ({bed.bed_category})", userData=bed.id)
            self.transfer_bed_combo.addItem(f"Bed {bed.bed_number} ({bed.bed_category})", userData=bed.id)

        self.bed_list.clear()
        for bed in list_beds():
            self.bed_list.addItem(f"Bed {bed.bed_number} — {bed.bed_category} — {bed.status}")

    def _refresh_occupancy(self) -> None:
        summary = occupancy_summary()
        self.occupancy_label.setText(
            f"Occupancy: {summary.occupied}/{summary.total_beds} occupied, "
            f"{summary.available} available, {summary.cleaning} cleaning, "
            f"{summary.reserved} reserved, {summary.maintenance} maintenance"
        )

    def _search_patient(self, term: str) -> None:
        self.patient_results.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            self.patient_results.addItem(f"{patient.uhid} — {patient.full_name}")
            self.patient_results.item(self.patient_results.count() - 1).setData(1, patient.id)

    def _select_patient(self, item) -> None:
        self._patient_id = item.data(1)
        self.selected_patient_label.setText(f"Selected: {item.text()}")
        self.selected_patient_label.setStyleSheet("color: green; font-weight: bold;")

    def _add_ward(self) -> None:
        if not self.new_ward_name.text().strip():
            QMessageBox.warning(self, "Add ward", "Ward name is required.")
            return
        add_ward(self.new_ward_name.text().strip(), self.new_ward_type.currentData())
        self.new_ward_name.clear()
        self._reload_wards()
        self._refresh_beds()

    def _add_room(self) -> None:
        ward_id = self.room_ward_combo.currentData()
        if ward_id is None or not self.new_room_number.text().strip():
            QMessageBox.warning(self, "Add room", "Select a ward and enter a room number.")
            return
        add_room(ward_id, self.new_room_number.text().strip())
        self.new_room_number.clear()
        self._refresh_beds()

    def _add_bed(self) -> None:
        room_id = self.bed_room_combo.currentData()
        if room_id is None or not self.new_bed_number.text().strip():
            QMessageBox.warning(self, "Add bed", "Select a room and enter a bed number.")
            return
        add_bed(room_id, self.new_bed_number.text().strip(), self.new_bed_category.currentData(),
                self.new_bed_daily_charge.value())
        self.new_bed_number.clear()
        self._refresh_beds()
        self._refresh_occupancy()

    def _admit(self) -> None:
        if self._patient_id is None:
            QMessageBox.warning(self, "Admit patient", "Select a patient first.")
            return
        doctor_id = self.admission_doctor_combo.currentData()
        bed_id = self.admission_bed_combo.currentData()
        if doctor_id is None or bed_id is None:
            QMessageBox.warning(self, "Admit patient", "An attending doctor and an available bed are required.")
            return
        try:
            admission = admit_patient(
                patient_id=self._patient_id, attending_doctor_id=doctor_id, bed_id=bed_id,
                admission_source=self.admission_source.currentData(),
                provisional_diagnosis=self.admission_diagnosis.text() or None,
                deposit_amount=self.admission_deposit.value(),
                consent_obtained=self.admission_consent.isChecked(),
                created_by_id=self.session_user.id,
            )
        except BedNotAvailableError as exc:
            QMessageBox.critical(self, "Admit patient", str(exc))
            return
        QMessageBox.information(self, "Patient admitted", f"Admission number: {admission.admission_number}")
        self.admission_diagnosis.clear()
        self._refresh_beds()
        self._refresh_admissions()
        self._refresh_occupancy()

    def _refresh_admissions(self) -> None:
        self.admission_list.clear()
        for admission in list_active_admissions():
            item_text = f"{admission.admission_number} — patient #{admission.patient_id} — bed #{admission.bed_id}"
            self.admission_list.addItem(item_text)
            self.admission_list.item(self.admission_list.count() - 1).setData(1, admission.id)

    def _select_admission(self, item) -> None:
        self._selected_admission_id = item.data(1)
        self._refresh_notes()
        self._refresh_mar()
        self._refresh_diet()

    def _transfer(self) -> None:
        if self._selected_admission_id is None:
            QMessageBox.warning(self, "Transfer bed", "Select an active admission first.")
            return
        new_bed_id = self.transfer_bed_combo.currentData()
        if new_bed_id is None:
            QMessageBox.warning(self, "Transfer bed", "No available bed to transfer to.")
            return
        try:
            transfer_bed(self._selected_admission_id, new_bed_id, reason=self.transfer_reason.text() or None,
                          transferred_by_id=self.session_user.id)
        except BedNotAvailableError as exc:
            QMessageBox.critical(self, "Transfer bed", str(exc))
            return
        self.transfer_reason.clear()
        self._refresh_beds()
        self._refresh_admissions()
        self._refresh_occupancy()
        QMessageBox.information(self, "Transferred", "Bed transfer recorded.")

    def _generate_interim_bill(self) -> None:
        if self._selected_admission_id is None:
            QMessageBox.warning(self, "Interim bill", "Select an active admission first.")
            return
        invoice = generate_bed_charge_invoice(
            self._selected_admission_id, invoice_type="ipd_interim", created_by_id=self.session_user.id,
        )
        self._last_ipd_invoice_id = invoice.id
        QMessageBox.information(self, "Interim bill generated", f"Invoice {invoice.invoice_number} — {invoice.total_amount:.2f}")

    def _discharge(self) -> None:
        if self._selected_admission_id is None:
            QMessageBox.warning(self, "Discharge", "Select an active admission first.")
            return
        summary = self.discharge_summary.toPlainText().strip()
        if not summary:
            QMessageBox.warning(self, "Discharge", "A discharge summary is required.")
            return
        try:
            final_invoice = generate_bed_charge_invoice(
                self._selected_admission_id, invoice_type="ipd_final", created_by_id=self.session_user.id,
            )
            self._last_ipd_invoice_id = final_invoice.id
            discharge_patient(
                self._selected_admission_id, discharge_summary=summary,
                follow_up_advice=self.discharge_advice.text() or None,
                override_pending_dues=self.discharge_override.isChecked(),
            )
        except DischargeBlockedError as exc:
            QMessageBox.critical(self, "Discharge blocked", str(exc))
            return
        QMessageBox.information(self, "Discharged", "Patient discharged and bed released for cleaning.")
        self.discharge_summary.clear()
        self.discharge_advice.clear()
        self._refresh_beds()
        self._refresh_admissions()
        self._refresh_occupancy()

    def _print_ipd_bill(self) -> None:
        """Save the most recent interim or final IPD bill as a PDF (spec
        17) — before this, both bills only ever showed a QMessageBox with
        the invoice number and total, nothing printable for the patient."""
        if not self._last_ipd_invoice_id:
            QMessageBox.warning(self, "Print bill", "Generate an interim bill or discharge a patient first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save IPD bill as PDF", f"ipd_bill_{self._last_ipd_invoice_id}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        try:
            generate_invoice_pdf(self._last_ipd_invoice_id, path)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Print bill", f"Could not generate the PDF:\n{exc}")
            return
        QMessageBox.information(self, "Bill saved", f"IPD bill PDF saved to:\n{path}")

    def _add_note(self) -> None:
        if self._selected_admission_id is None:
            QMessageBox.warning(self, "Add note", "Select an active admission first.")
            return
        text = self.note_text.toPlainText().strip()
        if not text:
            return
        add_nursing_note(self._selected_admission_id, text, self.note_type.currentData(), self.session_user.id)
        self.note_text.clear()
        self._refresh_notes()

    def _refresh_notes(self) -> None:
        self.notes_list.clear()
        if self._selected_admission_id is None:
            return
        for note in list_nursing_notes(self._selected_admission_id):
            self.notes_list.addItem(f"[{note.note_type}] {note.recorded_at:%Y-%m-%d %H:%M} — {note.note_text}")

    def _add_mar(self) -> None:
        if self._selected_admission_id is None:
            QMessageBox.warning(self, "Record administration", "Select an active admission first.")
            return
        if not self.mar_medicine.text().strip():
            return
        record_medication_administration(
            self._selected_admission_id, self.mar_medicine.text().strip(),
            dose=self.mar_dose.text() or None, route=self.mar_route.text() or None,
            administered_by_id=self.session_user.id,
        )
        self.mar_medicine.clear()
        self.mar_dose.clear()
        self.mar_route.clear()
        self._refresh_mar()

    def _refresh_mar(self) -> None:
        self.mar_list.clear()
        if self._selected_admission_id is None:
            return
        for entry in list_medication_administrations(self._selected_admission_id):
            self.mar_list.addItem(f"{entry.administered_at:%Y-%m-%d %H:%M} — {entry.medicine_name} {entry.dose or ''}")

    def _set_diet(self) -> None:
        if self._selected_admission_id is None:
            QMessageBox.warning(self, "Diet order", "Select an active admission first.")
            return
        set_diet_order(self._selected_admission_id, self.diet_type.currentData(),
                        instructions=self.diet_instructions.text() or None, ordered_by_id=self.session_user.id)
        self._refresh_diet()

    def _refresh_diet(self) -> None:
        if self._selected_admission_id is None:
            self.current_diet_label.setText("Current: —")
            return
        diet = current_diet_order(self._selected_admission_id)
        self.current_diet_label.setText(f"Current: {diet.diet_type}" if diet else "Current: none set")
