from __future__ import annotations

from PySide6.QtWidgets import (
    QGroupBox,
    QLabel,
    QListWidget,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.attendance_service import (
    AlreadyClockedInError,
    NotClockedInError,
    clock_in,
    clock_out,
    current_status,
    list_attendance,
)


class AttendanceScreen(QWidget):
    """Staff clock in/out (spec Phase 4: biometric attendance).

    No fingerprint/face-recognition hardware is available in this build,
    so attendance is manual for now — a Clock in / Clock out button. The
    underlying attendance_service functions are written so a biometric
    device's SDK could call them directly on a successful scan later
    (method="biometric") without any change here.
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._build_ui()
        self._refresh_status()
        self._refresh_history()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        box = QGroupBox(f"Attendance — {self.session_user.full_name}")
        box_layout = QVBoxLayout(box)

        self.status_label = QLabel("—")
        self.status_label.setStyleSheet("font-size: 14px; font-weight: 600;")
        box_layout.addWidget(self.status_label)

        clock_in_button = QPushButton("Clock in")
        clock_in_button.clicked.connect(self._clock_in)
        box_layout.addWidget(clock_in_button)

        clock_out_button = QPushButton("Clock out")
        clock_out_button.clicked.connect(self._clock_out)
        box_layout.addWidget(clock_out_button)

        hint = QLabel(
            "Manual clock in/out (no biometric device connected in this build — "
            "the same functions are ready for a fingerprint/face-scan integration later)."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color: grey; font-size: 10px;")
        box_layout.addWidget(hint)

        layout.addWidget(box)

        history_box = QGroupBox("Recent attendance")
        history_layout = QVBoxLayout(history_box)
        refresh_button = QPushButton("Refresh")
        refresh_button.clicked.connect(self._refresh_history)
        history_layout.addWidget(refresh_button)
        self.history_list = QListWidget()
        history_layout.addWidget(self.history_list)
        layout.addWidget(history_box)

    def _refresh_status(self) -> None:
        open_entry = current_status(self.session_user.id)
        if open_entry:
            self.status_label.setText(f"Clocked in since {open_entry.clock_in_at:%Y-%m-%d %H:%M}")
        else:
            self.status_label.setText("Not clocked in")

    def _clock_in(self) -> None:
        try:
            clock_in(self.session_user.id)
        except AlreadyClockedInError as exc:
            QMessageBox.warning(self, "Clock in", str(exc))
            return
        self._refresh_status()
        self._refresh_history()

    def _clock_out(self) -> None:
        try:
            clock_out(self.session_user.id)
        except NotClockedInError as exc:
            QMessageBox.warning(self, "Clock out", str(exc))
            return
        self._refresh_status()
        self._refresh_history()

    def _refresh_history(self) -> None:
        self.history_list.clear()
        for entry in list_attendance(self.session_user.id, limit=30):
            out_text = entry.clock_out_at.strftime("%H:%M") if entry.clock_out_at else "still in"
            self.history_list.addItem(
                f"{entry.clock_in_at:%Y-%m-%d %H:%M} → {out_text} ({entry.method})"
            )

    def showEvent(self, event):  # noqa: N802 (Qt override)
        self._refresh_status()
        self._refresh_history()
        super().showEvent(event)
