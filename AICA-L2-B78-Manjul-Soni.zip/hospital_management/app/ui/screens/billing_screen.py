from __future__ import annotations

from PySide6.QtWidgets import (
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QListWidget,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTabWidget,
    QVBoxLayout,
    QWidget,
)

from app.config import settings
from app.security.auth import SessionUser
from app.services.billing_service import InvoiceLine, create_invoice, record_payment
from app.services.communication_service import send_notification
from app.services.insurance_service import InsurerInput, add_insurer, file_claim, list_claims, list_insurers, update_claim_status
from app.services.pdf_service import generate_invoice_pdf
from app.ui.label_utils import add_choice_items, humanize
from app.services.patient_service import get_patient, search_patients


class BillingScreen(QWidget):
    """OPD billing (line items, invoice, payment) plus insurance/corporate
    claim tracking (spec section 10).
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._patient_id = None
        self._current_invoice_id = None
        self._lines: list[InvoiceLine] = []
        self._build_ui()
        self._reload_insurers()
        self._refresh_claims()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        tabs = QTabWidget()
        outer.addWidget(tabs)
        tabs.addTab(self._build_billing_tab(), "Invoice && payment")
        tabs.addTab(self._build_insurance_tab(), "Insurance / corporate")

    def _build_billing_tab(self) -> QWidget:
        box = QWidget()
        outer = QHBoxLayout(box)

        left = QGroupBox("New invoice")
        form = QFormLayout(left)

        self.patient_search = QLineEdit()
        self.patient_search.setPlaceholderText("Search patient")
        self.patient_search.textChanged.connect(self._search_patient)
        self.patient_results = QListWidget()
        self.patient_results.setMaximumHeight(80)
        self.patient_results.itemClicked.connect(self._select_patient)
        self.patient_results.itemActivated.connect(self._select_patient)
        self.selected_patient_label = QLabel("No patient selected.")
        self.selected_patient_label.setStyleSheet("color: grey;")

        self.description = QLineEdit()
        self.quantity = QSpinBox()
        self.quantity.setMinimum(1)
        self.quantity.setValue(1)
        self.unit_price = QDoubleSpinBox()
        self.unit_price.setMaximum(1_000_000)
        self.tax_percent = QDoubleSpinBox()
        self.tax_percent.setMaximum(100)
        self.tax_percent.setValue(settings.DEFAULT_TAX_PERCENT)

        add_line_button = QPushButton("Add line item")
        add_line_button.clicked.connect(self._add_line)

        form.addRow("Patient", self.patient_search)
        form.addRow(self.patient_results)
        form.addRow(self.selected_patient_label)
        form.addRow("Description", self.description)
        form.addRow("Quantity", self.quantity)
        form.addRow("Unit price", self.unit_price)
        form.addRow("Tax %", self.tax_percent)
        form.addRow(add_line_button)

        self.line_list = QListWidget()
        form.addRow(self.line_list)

        generate_button = QPushButton("Generate invoice")
        generate_button.clicked.connect(self._generate_invoice)
        form.addRow(generate_button)

        outer.addWidget(left)

        right = QGroupBox("Payment")
        payment_form = QFormLayout(right)
        self.payment_amount = QDoubleSpinBox()
        self.payment_amount.setMaximum(1_000_000)
        self.payment_method = QComboBox()
        add_choice_items(self.payment_method, ["cash", "card", "upi", "bank_transfer", "cheque", "credit", "insurance"])
        self.payment_reference = QLineEdit()

        pay_button = QPushButton("Record payment")
        pay_button.clicked.connect(self._record_payment)

        payment_form.addRow("Amount", self.payment_amount)
        payment_form.addRow("Method", self.payment_method)
        payment_form.addRow("Reference (card/UPI/cheque no.)", self.payment_reference)
        payment_form.addRow(pay_button)

        print_invoice_button = QPushButton("Print invoice (PDF)...")
        print_invoice_button.clicked.connect(self._print_invoice_pdf)
        payment_form.addRow(print_invoice_button)

        outer.addWidget(right)
        return box

    def _build_insurance_tab(self) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout(box)

        insurer_box = QGroupBox("Insurers / corporates / TPAs")
        insurer_form = QFormLayout(insurer_box)
        self.insurer_name = QLineEdit()
        self.insurer_type = QComboBox()
        add_choice_items(self.insurer_type, ["insurance", "corporate", "tpa"])
        self.insurer_contact = QLineEdit()
        self.insurer_credit_limit = QDoubleSpinBox()
        self.insurer_credit_limit.setMaximum(10_000_000)

        insurer_form.addRow("Name*", self.insurer_name)
        insurer_form.addRow("Type", self.insurer_type)
        insurer_form.addRow("Contact person", self.insurer_contact)
        insurer_form.addRow("Credit limit", self.insurer_credit_limit)

        add_insurer_button = QPushButton("Add insurer")
        add_insurer_button.clicked.connect(self._add_insurer)
        insurer_form.addRow(add_insurer_button)

        self.insurer_list = QListWidget()
        insurer_form.addRow(self.insurer_list)

        claim_box = QGroupBox("File / update claim")
        claim_form = QFormLayout(claim_box)
        self.claim_invoice_id = QSpinBox()
        self.claim_invoice_id.setMaximum(10_000_000)
        self.claim_insurer_combo = QComboBox()
        self.claim_policy_id = QLineEdit()
        self.claim_preauth = QLineEdit()
        self.claim_amount = QDoubleSpinBox()
        self.claim_amount.setMaximum(10_000_000)

        claim_form.addRow("Invoice ID*", self.claim_invoice_id)
        claim_form.addRow("Insurer", self.claim_insurer_combo)
        claim_form.addRow("Policy / employee ID", self.claim_policy_id)
        claim_form.addRow("Pre-authorization number", self.claim_preauth)
        claim_form.addRow("Claim amount*", self.claim_amount)

        file_claim_button = QPushButton("File claim")
        file_claim_button.clicked.connect(self._file_claim)
        claim_form.addRow(file_claim_button)

        self.claim_status_combo = QComboBox()
        add_choice_items(self.claim_status_combo, ["submitted", "approved", "partially_approved", "rejected", "settled"])
        self.claim_approved_amount = QDoubleSpinBox()
        self.claim_approved_amount.setMaximum(10_000_000)
        update_status_button = QPushButton("Update selected claim's status")
        update_status_button.clicked.connect(self._update_claim_status)
        claim_form.addRow("New status", self.claim_status_combo)
        claim_form.addRow("Approved amount", self.claim_approved_amount)
        claim_form.addRow(update_status_button)

        self.claim_list = QListWidget()
        self.claim_list.itemClicked.connect(self._select_claim)
        self.claim_list.itemActivated.connect(self._select_claim)
        claim_form.addRow(self.claim_list)

        layout.addWidget(insurer_box)
        layout.addWidget(claim_box)
        return box

    def _reload_insurers(self) -> None:
        self.insurer_list.clear()
        self.claim_insurer_combo.clear()
        for insurer in list_insurers():
            self.insurer_list.addItem(f"{insurer.name} ({humanize(insurer.insurer_type)})")
            self.claim_insurer_combo.addItem(insurer.name, userData=insurer.id)

    def _add_insurer(self) -> None:
        if not self.insurer_name.text().strip():
            QMessageBox.warning(self, "Add insurer", "Insurer name is required.")
            return
        add_insurer(InsurerInput(
            name=self.insurer_name.text().strip(),
            insurer_type=self.insurer_type.currentData(),
            contact_person=self.insurer_contact.text() or None,
            credit_limit=self.insurer_credit_limit.value(),
        ))
        self.insurer_name.clear()
        self.insurer_contact.clear()
        self._reload_insurers()

    def _file_claim(self) -> None:
        insurer_id = self.claim_insurer_combo.currentData()
        if insurer_id is None or self.claim_invoice_id.value() == 0 or self.claim_amount.value() <= 0:
            QMessageBox.warning(self, "File claim", "Invoice ID, insurer, and a positive claim amount are required.")
            return
        file_claim(
            invoice_id=self.claim_invoice_id.value(), insurer_id=insurer_id,
            claim_amount=self.claim_amount.value(),
            policy_or_employee_id=self.claim_policy_id.text() or None,
            pre_authorization_number=self.claim_preauth.text() or None,
        )
        self.claim_policy_id.clear()
        self.claim_preauth.clear()
        self._refresh_claims()
        QMessageBox.information(self, "Claim filed", "Insurance claim recorded.")

    def _refresh_claims(self) -> None:
        self.claim_list.clear()
        for claim in list_claims():
            item_text = (
                f"#{claim.id} — invoice #{claim.invoice_id} — {humanize(claim.status)} — "
                f"claimed {claim.claim_amount:.2f}, approved {claim.approved_amount:.2f}"
            )
            self.claim_list.addItem(item_text)
            self.claim_list.item(self.claim_list.count() - 1).setData(1, claim.id)

    def _select_claim(self, item) -> None:
        self._selected_claim_id = item.data(1)

    def _update_claim_status(self) -> None:
        claim_id = getattr(self, "_selected_claim_id", None)
        if claim_id is None:
            QMessageBox.warning(self, "Update claim", "Select a claim from the list first.")
            return
        update_claim_status(
            claim_id, self.claim_status_combo.currentData(),
            approved_amount=self.claim_approved_amount.value() or None,
            received_by_id=self.session_user.id,
        )
        self._refresh_claims()
        if self.claim_status_combo.currentData() == "settled":
            QMessageBox.information(
                self, "Claim settled",
                "The insurer's payment has been recorded against the invoice automatically.",
            )

    def _search_patient(self, term: str) -> None:
        self.patient_results.clear()
        if not term.strip():
            return
        for patient in search_patients(term):
            self.patient_results.addItem(f"{patient.uhid} — {patient.full_name}")
            self.patient_results.item(self.patient_results.count() - 1).setData(1, patient.id)

    def _select_patient(self, item) -> None:
        self._patient_id = item.data(1)
        self.selected_patient_label.setText(f"Selected: {item.text()}")
        self.selected_patient_label.setStyleSheet("color: green; font-weight: bold;")

    def _add_line(self) -> None:
        if not self.description.text().strip():
            QMessageBox.warning(self, "Add line item", "Description is required.")
            return
        line = InvoiceLine(
            description=self.description.text().strip(),
            quantity=self.quantity.value(),
            unit_price=self.unit_price.value(),
            tax_percent=self.tax_percent.value(),
        )
        self._lines.append(line)
        self.line_list.addItem(
            f"{line.description} x{line.quantity} @ {line.unit_price} (+{line.tax_percent}% tax)"
        )
        self.description.clear()
        self.quantity.setValue(1)
        self.unit_price.setValue(0)

    def _generate_invoice(self) -> None:
        if self._patient_id is None:
            QMessageBox.warning(self, "Generate invoice", "Select a patient first.")
            return
        if not self._lines:
            QMessageBox.warning(self, "Generate invoice", "Add at least one line item.")
            return
        invoice = create_invoice(
            patient_id=self._patient_id,
            invoice_type="opd",
            lines=self._lines,
            created_by_id=self.session_user.id,
        )
        self._current_invoice_id = invoice.id
        self._send_invoice_notification(invoice)
        QMessageBox.information(
            self, "Invoice generated",
            f"Invoice {invoice.invoice_number} — total due: {invoice.total_amount:.2f}",
        )
        self._lines = []
        self.line_list.clear()

    def _send_invoice_notification(self, invoice) -> None:
        """Best-effort SMS/email notice of a new invoice (spec Phase 4).
        Never lets a notification problem undo a successful billing
        transaction — failures land in the communication log
        (Settings -> Notifications), not here.
        """
        try:
            patient = get_patient(self._patient_id)
            if not patient:
                return
            message = (
                f"Dear {patient.full_name}, invoice {invoice.invoice_number} for "
                f"{invoice.total_amount:.2f} has been generated. Amount due: {invoice.due_amount:.2f}."
            )
            if patient.mobile_number:
                send_notification("sms", patient.mobile_number, message, patient_id=patient.id,
                                   template_key="invoice_generated")
            if patient.email:
                send_notification("email", patient.email, message, subject="Invoice generated",
                                   patient_id=patient.id, template_key="invoice_generated")
        except Exception:  # noqa: BLE001
            pass

    def _record_payment(self) -> None:
        if self._current_invoice_id is None:
            QMessageBox.warning(self, "Record payment", "Generate an invoice first.")
            return
        try:
            payment = record_payment(
                invoice_id=self._current_invoice_id,
                amount=self.payment_amount.value(),
                payment_method=self.payment_method.currentData(),
                reference_number=self.payment_reference.text() or None,
                received_by_id=self.session_user.id,
            )
        except ValueError as exc:
            QMessageBox.critical(self, "Record payment", str(exc))
            return
        QMessageBox.information(self, "Payment recorded", f"Amount received: {payment.amount:.2f}")
        self.payment_amount.setValue(0)
        self.payment_reference.clear()

    def _print_invoice_pdf(self) -> None:
        """Save the current invoice as a proper PDF bill (spec 17) — before
        this, "printing" an invoice just meant a QMessageBox summarizing the
        total, nothing the patient could actually take away or file.
        """
        if self._current_invoice_id is None:
            QMessageBox.warning(self, "Print invoice", "Generate an invoice first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save invoice as PDF", f"invoice_{self._current_invoice_id}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        try:
            generate_invoice_pdf(self._current_invoice_id, path)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Print invoice", f"Could not generate the PDF:\n{exc}")
            return
        QMessageBox.information(self, "Invoice saved", f"Invoice PDF saved to:\n{path}")
