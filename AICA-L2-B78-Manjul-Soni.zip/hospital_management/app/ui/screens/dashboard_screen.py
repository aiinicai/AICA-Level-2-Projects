from __future__ import annotations

import datetime as _dt

from PySide6.QtCore import Qt
from PySide6.QtGui import QPixmap
from PySide6.QtWidgets import (
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QVBoxLayout,
    QWidget,
)

from app.config import settings
from app.security.auth import SessionUser
from app.services.hospital_settings_service import get_hospital_profile
from app.services.report_service import daily_summary
from app.services.ward_service import occupancy_summary


class _StatTile(QFrame):
    def __init__(self, title: str, value_text: str):
        super().__init__()
        self.setFrameShape(QFrame.StyledPanel)
        layout = QVBoxLayout(self)
        value_label = QLabel(value_text)
        value_label.setStyleSheet("font-size: 26px; font-weight: 700;")
        title_label = QLabel(title)
        title_label.setStyleSheet("color: grey; font-size: 12px;")
        layout.addWidget(value_label)
        layout.addWidget(title_label)
        self._value_label = value_label

    def set_value(self, value_text: str) -> None:
        self._value_label.setText(value_text)


class DashboardScreen(QWidget):
    """First screen after login: big logo + hospital identity (spec 18's
    'dashboard as first screen'), plus at-a-glance daily numbers.
    """

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._build_ui()
        self._refresh_stats()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(24, 24, 24, 24)
        outer.setSpacing(18)

        header = QHBoxLayout()
        if settings.APP_LOGO_PATH.exists():
            logo_label = QLabel()
            pixmap = QPixmap(str(settings.APP_LOGO_PATH)).scaledToHeight(96, Qt.SmoothTransformation)
            logo_label.setPixmap(pixmap)
            header.addWidget(logo_label)

        identity_layout = QVBoxLayout()
        self.hospital_name_label = QLabel()
        self.hospital_name_label.setStyleSheet("font-size: 30px; font-weight: 800;")
        self.hospital_tagline_label = QLabel()
        self.hospital_tagline_label.setStyleSheet("font-size: 14px; color: grey;")
        self.hospital_contact_label = QLabel()
        self.hospital_contact_label.setStyleSheet("font-size: 12px; color: grey;")
        identity_layout.addWidget(self.hospital_name_label)
        identity_layout.addWidget(self.hospital_tagline_label)
        identity_layout.addWidget(self.hospital_contact_label)
        identity_layout.addStretch()
        header.addLayout(identity_layout)
        header.addStretch()
        outer.addLayout(header)

        welcome = QLabel(f"Welcome, {self.session_user.full_name} ({self.session_user.role_name.replace('_', ' ').title()})")
        welcome.setStyleSheet("font-size: 16px; font-weight: 600;")
        outer.addWidget(welcome)

        grid = QGridLayout()
        grid.setSpacing(14)
        self.tile_registrations = _StatTile("New registrations today", "—")
        self.tile_visits = _StatTile("OPD visits today", "—")
        self.tile_appointments = _StatTile("Appointments today", "—")
        self.tile_collection = _StatTile("Collection today", "—")
        self.tile_occupancy = _StatTile("Beds occupied", "—")
        self.tile_dues = _StatTile("Outstanding dues", "—")

        grid.addWidget(self.tile_registrations, 0, 0)
        grid.addWidget(self.tile_visits, 0, 1)
        grid.addWidget(self.tile_appointments, 0, 2)
        grid.addWidget(self.tile_collection, 1, 0)
        grid.addWidget(self.tile_occupancy, 1, 1)
        grid.addWidget(self.tile_dues, 1, 2)
        outer.addLayout(grid)

        outer.addStretch()

    def _refresh_stats(self) -> None:
        profile = get_hospital_profile()
        self.hospital_name_label.setText(profile.name)
        self.hospital_tagline_label.setText(profile.tagline)
        contact_bits = [bit for bit in (profile.address, profile.phone, profile.email) if bit]
        self.hospital_contact_label.setText(" | ".join(contact_bits))

        summary = daily_summary(_dt.date.today())
        self.tile_registrations.set_value(str(summary["new_registrations"]))
        self.tile_visits.set_value(str(summary["opd_visits"]))
        self.tile_appointments.set_value(str(summary["appointments_booked"]))
        self.tile_collection.set_value(f"{summary['total_collection']:.2f}")
        self.tile_dues.set_value(f"{summary['outstanding_dues_all_time']:.2f}")

        occ = occupancy_summary()
        self.tile_occupancy.set_value(f"{occ.occupied}/{occ.total_beds}")

    def showEvent(self, event):  # noqa: N802 (Qt override)
        # Re-read hospital details + today's numbers every time the user
        # switches back to this screen, so a Settings edit shows up promptly.
        self._refresh_stats()
        super().showEvent(event)
