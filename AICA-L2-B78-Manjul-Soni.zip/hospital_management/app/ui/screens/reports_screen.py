from __future__ import annotations

import datetime as _dt

from PySide6.QtWidgets import (
    QComboBox,
    QDateEdit,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QLabel,
    QListWidget,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.security.auth import SessionUser
from app.services.advanced_reports_service import (
    discount_refund_report,
    doctor_wise_revenue,
    inventory_snapshot,
    outstanding_receivables,
    pharmacy_sales_summary,
    service_wise_income,
)
from app.services.excel_export_service import export_revenue_xlsx
from app.services.pdf_service import generate_report_pdf
from app.services.report_service import daily_summary, export_daily_summary_csv


class ReportsScreen(QWidget):
    """Daily operational report (Phase 1) plus the advanced financial and
    inventory reports added in Phase 2 (spec section 14).
    """

    ADVANCED_REPORTS = [
        "Service-wise income",
        "Doctor-wise revenue",
        "Outstanding receivables",
        "Discount / refund / cancellation",
        "Pharmacy sales summary",
        "Low stock & near-expiry",
    ]

    def __init__(self, session_user: SessionUser):
        super().__init__()
        self.session_user = session_user
        self._last_summary: dict | None = None
        self._last_advanced_rows: list[list[str]] = []
        self._last_advanced_headers: list[str] = []
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)

        daily_box = QGroupBox("Daily summary report")
        form = QFormLayout(daily_box)

        self.report_date = QDateEdit(calendarPopup=True)
        self.report_date.setDate(_dt.date.today())
        form.addRow("Date", self.report_date)

        view_button = QPushButton("Show summary")
        view_button.clicked.connect(self._show_summary)
        form.addRow(view_button)

        export_button = QPushButton("Export as CSV")
        export_button.clicked.connect(self._export_csv)
        form.addRow(export_button)

        export_pdf_button = QPushButton("Export as PDF")
        export_pdf_button.clicked.connect(self._export_summary_pdf)
        form.addRow(export_pdf_button)

        self.summary_box = QGroupBox("Result")
        self.summary_layout = QFormLayout(self.summary_box)
        form.addRow(self.summary_box)

        layout.addWidget(daily_box)

        adv_box = QGroupBox("Advanced reports")
        adv_form = QFormLayout(adv_box)

        self.advanced_report_combo = QComboBox()
        self.advanced_report_combo.addItems(self.ADVANCED_REPORTS)
        self.range_start = QDateEdit(calendarPopup=True)
        self.range_start.setDate(_dt.date.today().replace(day=1))
        self.range_end = QDateEdit(calendarPopup=True)
        self.range_end.setDate(_dt.date.today())

        adv_form.addRow("Report", self.advanced_report_combo)
        adv_form.addRow("From", self.range_start)
        adv_form.addRow("To", self.range_end)

        run_button = QPushButton("Run report")
        run_button.clicked.connect(self._run_advanced_report)
        adv_form.addRow(run_button)

        self.advanced_result_list = QListWidget()
        adv_form.addRow(self.advanced_result_list)

        export_advanced_pdf_button = QPushButton("Export this report as PDF")
        export_advanced_pdf_button.clicked.connect(self._export_advanced_pdf)
        adv_form.addRow(export_advanced_pdf_button)

        export_revenue_button = QPushButton("Bulk export revenue (invoices/payments) to Excel...")
        export_revenue_button.clicked.connect(self._export_revenue)
        adv_form.addRow(export_revenue_button)

        layout.addWidget(adv_box)

    def _clear_summary(self) -> None:
        while self.summary_layout.rowCount():
            self.summary_layout.removeRow(0)

    def _show_summary(self) -> None:
        summary = daily_summary(self.report_date.date().toPython())
        self._last_summary = summary
        self._clear_summary()
        for key, value in summary.items():
            self.summary_layout.addRow(QLabel(key.replace("_", " ").title()), QLabel(str(value)))

    def _export_csv(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export report", "daily_summary.csv", "CSV Files (*.csv)")
        if not path:
            return
        export_daily_summary_csv(self.report_date.date().toPython(), path)
        QMessageBox.information(self, "Export complete", f"Report saved to {path}")

    def _export_summary_pdf(self) -> None:
        if self._last_summary is None:
            self._show_summary()
        report_date = self.report_date.date().toPython()
        path, _ = QFileDialog.getSaveFileName(
            self, "Export report as PDF", f"daily_summary_{report_date.isoformat()}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        rows = [[key.replace("_", " ").title(), str(value)] for key, value in self._last_summary.items()]
        generate_report_pdf(
            "Daily Summary Report", ["Metric", "Value"], rows, path,
            subtitle=f"For {report_date.strftime('%d-%b-%Y')}",
        )
        QMessageBox.information(self, "Export complete", f"Report saved to {path}")

    def _run_advanced_report(self) -> None:
        report_name = self.advanced_report_combo.currentText()
        start = self.range_start.date().toPython()
        end = self.range_end.date().toPython()
        self.advanced_result_list.clear()
        headers: list[str] = []
        rows: list[list[str]] = []

        if report_name == "Service-wise income":
            headers = ["Description", "Total", "Line items"]
            for row in service_wise_income(start, end):
                self.advanced_result_list.addItem(
                    f"{row['description']}: {row['total']:.2f} ({row['count']} line item(s))"
                )
                rows.append([row["description"], f"{row['total']:.2f}", str(row["count"])])
        elif report_name == "Doctor-wise revenue":
            headers = ["Doctor", "Revenue"]
            for row in doctor_wise_revenue(start, end):
                self.advanced_result_list.addItem(f"{row['doctor']}: {row['revenue']:.2f}")
                rows.append([row["doctor"], f"{row['revenue']:.2f}"])
        elif report_name == "Outstanding receivables":
            headers = ["Invoice number", "Patient ID", "Due amount"]
            for row in outstanding_receivables():
                self.advanced_result_list.addItem(
                    f"{row['invoice_number']} — patient #{row['patient_id']} — due {row['due_amount']:.2f}"
                )
                rows.append([row["invoice_number"], str(row["patient_id"]), f"{row['due_amount']:.2f}"])
        elif report_name == "Discount / refund / cancellation":
            headers = ["Metric", "Value"]
            summary = discount_refund_report(start, end)
            for key, value in summary.items():
                self.advanced_result_list.addItem(f"{key.replace('_', ' ').title()}: {value}")
                rows.append([key.replace("_", " ").title(), str(value)])
        elif report_name == "Pharmacy sales summary":
            headers = ["Medicine", "Qty sold", "Total sales"]
            for row in pharmacy_sales_summary(start, end):
                self.advanced_result_list.addItem(
                    f"{row['medicine']}: {row['quantity_sold']} unit(s), {row['total_sales']:.2f}"
                )
                rows.append([row["medicine"], str(row["quantity_sold"]), f"{row['total_sales']:.2f}"])
        elif report_name == "Low stock & near-expiry":
            headers = ["Type", "Item", "Detail"]
            snapshot = inventory_snapshot()
            for entry in snapshot["low_stock"]:
                self.advanced_result_list.addItem(
                    f"LOW STOCK — {entry['medicine'].generic_name}: {entry['current_stock']} "
                    f"(reorder level {entry['reorder_level']})"
                )
                rows.append([
                    "LOW STOCK", entry["medicine"].generic_name,
                    f"{entry['current_stock']} in stock (reorder level {entry['reorder_level']})",
                ])
            for entry in snapshot["near_expiry"]:
                self.advanced_result_list.addItem(
                    f"NEAR EXPIRY — {entry['medicine_name']} batch {entry['batch_number']}: "
                    f"{entry['quantity']} unit(s), {entry['days_to_expiry']} day(s) left"
                )
                rows.append([
                    "NEAR EXPIRY", f"{entry['medicine_name']} (batch {entry['batch_number']})",
                    f"{entry['quantity']} unit(s), {entry['days_to_expiry']} day(s) left",
                ])

        if self.advanced_result_list.count() == 0:
            self.advanced_result_list.addItem("No data for the selected range.")

        self._last_advanced_headers = headers
        self._last_advanced_rows = rows

    def _export_advanced_pdf(self) -> None:
        if not self._last_advanced_headers:
            self._run_advanced_report()
        report_name = self.advanced_report_combo.currentText()
        start = self.range_start.date().toPython()
        end = self.range_end.date().toPython()
        safe_name = report_name.lower().replace(" ", "_").replace("/", "-")
        path, _ = QFileDialog.getSaveFileName(
            self, "Export report as PDF", f"{safe_name}.pdf", "PDF Files (*.pdf)",
        )
        if not path:
            return
        generate_report_pdf(
            report_name, self._last_advanced_headers, self._last_advanced_rows, path,
            subtitle=f"{start.strftime('%d-%b-%Y')} to {end.strftime('%d-%b-%Y')}",
        )
        QMessageBox.information(self, "Export complete", f"Report saved to {path}")

    def _export_revenue(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export revenue", "revenue_export.xlsx", "Excel Files (*.xlsx)")
        if not path:
            return
        start = self.range_start.date().toPython()
        end = self.range_end.date().toPython()
        export_revenue_xlsx(path, start, end)
        QMessageBox.information(self, "Export complete", f"Revenue report exported to {path}")
