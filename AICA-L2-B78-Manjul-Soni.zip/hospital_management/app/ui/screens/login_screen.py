from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from app.config import settings
from app.security.auth import AuthError, SessionUser, login
from app.ui.screens.patient_portal_screen import PatientPortalWindow


class LoginScreen(QWidget):
    """First screen shown on launch. On success, opens the main dashboard window."""

    def __init__(self, on_success):
        super().__init__()
        self.on_success = on_success
        self.setWindowTitle(f"{settings.APP_NAME} — Login")
        self.setFixedSize(380, 390)
        self._portal_window = None
        if settings.APP_LOGO_PATH.exists():
            self.setWindowIcon(QIcon(str(settings.APP_LOGO_PATH)))
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(12)

        icon_path = settings.APP_ROOT / "app" / "ui" / "themes" / "icon.png"
        if icon_path.exists():
            logo_label = QLabel()
            pixmap = QPixmap(str(icon_path)).scaled(
                72, 72, Qt.KeepAspectRatio, Qt.SmoothTransformation
            )
            logo_label.setPixmap(pixmap)
            logo_label.setAlignment(Qt.AlignCenter)
            layout.addWidget(logo_label)

        title = QLabel(settings.APP_NAME)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 20px; font-weight: 700;")
        layout.addWidget(title)

        subtitle = QLabel("Hospital Management System")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("font-size: 11px; color: grey;")
        layout.addWidget(subtitle)

        self.username_input = QLineEdit()
        self.username_input.setPlaceholderText("Username")
        layout.addWidget(self.username_input)

        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Password")
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.returnPressed.connect(self._attempt_login)
        layout.addWidget(self.password_input)

        login_button = QPushButton("Login")
        login_button.clicked.connect(self._attempt_login)
        layout.addWidget(login_button)

        hint = QLabel("Default administrator: admin / Admin@123\n(change the password after first login)")
        hint.setAlignment(Qt.AlignCenter)
        hint.setStyleSheet("color: grey; font-size: 10px;")
        layout.addWidget(hint)

        portal_button = QPushButton("Patient portal (view my records)")
        portal_button.clicked.connect(self._open_patient_portal)
        layout.addWidget(portal_button)

    def _open_patient_portal(self) -> None:
        self._portal_window = PatientPortalWindow(self)
        self._portal_window.exec()

    def _attempt_login(self) -> None:
        username = self.username_input.text().strip()
        password = self.password_input.text()
        if not username or not password:
            QMessageBox.warning(self, "Login", "Please enter both username and password.")
            return
        try:
            session_user: SessionUser = login(username, password)
        except AuthError as exc:
            QMessageBox.critical(self, "Login failed", str(exc))
            self.password_input.clear()
            return
        self.on_success(session_user)
