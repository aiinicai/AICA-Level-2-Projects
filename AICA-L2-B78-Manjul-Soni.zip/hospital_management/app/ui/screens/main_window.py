from __future__ import annotations

from PySide6.QtCore import QTimer
from PySide6.QtGui import QIcon, QKeySequence, QShortcut
from PySide6.QtWidgets import (
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QStackedWidget,
    QStatusBar,
    QWidget,
    QHBoxLayout,
    QVBoxLayout,
)

from app.config import settings
from app.security.auth import SessionUser, logout
from app.ui.screens.patient_screen import PatientScreen
from app.ui.screens.appointment_screen import AppointmentScreen
from app.ui.screens.billing_screen import BillingScreen
from app.ui.screens.reports_screen import ReportsScreen
from app.ui.screens.pharmacy_screen import PharmacyScreen
from app.ui.screens.laboratory_screen import LaboratoryScreen
from app.ui.screens.inventory_screen import InventoryScreen
from app.ui.screens.settings_screen import SettingsScreen
from app.ui.screens.ipd_screen import IPDScreen
from app.ui.screens.ot_screen import OTScreen
from app.ui.screens.dashboard_screen import DashboardScreen
from app.ui.screens.attendance_screen import AttendanceScreen
from app.ui.screens.consultation_screen import ConsultationScreen

# Menu items visible per role. Administrator sees everything; other roles
# see the subset relevant to their day-to-day work (spec section 2).
# Every role gets "Attendance" (Phase 4: clock in/out) since it applies to
# all staff, not just one department. "Consultation" (vitals/notes/
# prescriptions against a checked-in visit) goes to doctor + administrator.
ROLE_MENU = {
    "administrator": [
        "Dashboard", "Patients", "Appointments", "Consultation", "Billing", "Pharmacy",
        "Laboratory", "Inventory", "IPD", "Operation Theatre", "Reports",
        "Attendance", "Settings",
    ],
    "receptionist": ["Dashboard", "Patients", "Appointments", "Billing", "Attendance"],
    "doctor": [
        "Dashboard", "Patients", "Appointments", "Consultation", "Laboratory",
        "IPD", "Operation Theatre", "Attendance",
    ],
    "nurse": ["Dashboard", "Patients", "IPD", "Attendance"],
    "pharmacist": ["Dashboard", "Patients", "Pharmacy", "Attendance"],
    "lab_technician": ["Dashboard", "Patients", "Laboratory", "Attendance"],
    "accountant": ["Dashboard", "Billing", "Reports", "Attendance"],
    "store_manager": ["Dashboard", "Inventory", "Reports", "Attendance"],
    "ward_boy": ["Dashboard", "IPD", "Attendance"],
    "housekeeping": ["Dashboard", "IPD", "Attendance"],
    "intern": ["Dashboard", "Patients", "Appointments", "Attendance"],
}

# The "main save action" per screen, invoked by Ctrl+S (spec: standard
# Windows keyboard shortcuts should work wherever applicable). Screens not
# listed here simply do nothing on Ctrl+S.
PRIMARY_ACTION_BY_SCREEN = {
    "Patients": "_register",
    "Appointments": "_book",
    "Billing": "_generate_invoice",
    "Pharmacy": "_dispense",
    "Laboratory": "_place_order",
    "Inventory": "_create_po",
    "IPD": "_admit",
    "Operation Theatre": "_schedule",
    "Settings": "_save_hospital_profile",
}

# Attribute name of the "quick find / open" search box per screen, focused
# by Ctrl+O.
SEARCH_FIELD_BY_SCREEN = {
    "Patients": "search_input",
    "Appointments": "patient_search",
    "Billing": "patient_search",
    "Pharmacy": "patient_search",
    "Laboratory": "patient_search",
    "IPD": "patient_search",
    "Operation Theatre": "patient_search",
}


class MainWindow(QMainWindow):
    """Left sidebar for modules, top status bar, dashboard as first screen (spec 18)."""

    def __init__(self, session_user: SessionUser, on_logout):
        super().__init__()
        self.session_user = session_user
        self.on_logout = on_logout
        self.setWindowTitle(f"{settings.APP_NAME} — {settings.HOSPITAL_NAME}")
        self.resize(1100, 700)
        if settings.APP_LOGO_PATH.exists():
            self.setWindowIcon(QIcon(str(settings.APP_LOGO_PATH)))

        self._build_ui()
        self._start_idle_timer()
        self._setup_keyboard_shortcuts()

    def _build_ui(self) -> None:
        central = QWidget()
        outer = QHBoxLayout(central)

        sidebar_container = QWidget()
        sidebar_container.setFixedWidth(180)
        sidebar_layout = QVBoxLayout(sidebar_container)
        sidebar_layout.setContentsMargins(0, 0, 0, 0)
        sidebar_layout.setSpacing(0)

        self.sidebar = QListWidget()
        self.sidebar.setObjectName("Sidebar")
        sidebar_layout.addWidget(self.sidebar)

        # Log out was previously only reachable by closing the window
        # outright (closeEvent) or waiting for the idle timeout — there was
        # no button anywhere for a staff member to end their own session
        # deliberately, e.g. to hand the workstation to the next shift.
        logout_button = QPushButton("Log out")
        logout_button.setObjectName("SidebarLogoutButton")
        logout_button.clicked.connect(self._confirm_logout)
        sidebar_layout.addWidget(logout_button)

        outer.addWidget(sidebar_container)

        self.stack = QStackedWidget()
        outer.addWidget(self.stack)

        self.screens_by_name = {
            "Dashboard": DashboardScreen(self.session_user),
            "Patients": PatientScreen(self.session_user),
            "Appointments": AppointmentScreen(self.session_user),
            "Consultation": ConsultationScreen(self.session_user),
            "Billing": BillingScreen(self.session_user),
            "Pharmacy": PharmacyScreen(self.session_user),
            "Laboratory": LaboratoryScreen(self.session_user),
            "Inventory": InventoryScreen(self.session_user),
            "IPD": IPDScreen(self.session_user),
            "Operation Theatre": OTScreen(self.session_user),
            "Reports": ReportsScreen(self.session_user),
            "Attendance": AttendanceScreen(self.session_user),
            "Settings": SettingsScreen(self.session_user),
        }

        allowed = ROLE_MENU.get(self.session_user.role_name, ["Dashboard"])
        for name in allowed:
            self.sidebar.addItem(QListWidgetItem(name))
            self.stack.addWidget(self.screens_by_name[name])

        self.sidebar.currentRowChanged.connect(self.stack.setCurrentIndex)
        self.sidebar.setCurrentRow(0)

        self.setCentralWidget(central)

        status = QStatusBar()
        status.showMessage(
            f"{self.session_user.username} | {self.session_user.role_name} | logged in"
        )
        self.setStatusBar(status)

    def _setup_keyboard_shortcuts(self) -> None:
        """Standard Windows shortcuts, wired app-wide (spec):
        Ctrl+O = open/find (focuses the current screen's search box),
        Ctrl+S = save (runs the current screen's primary save action),
        Ctrl+PageDown / Ctrl+PageUp and Alt+Down / Alt+Up = move to the
        next / previous sidebar module.
        """
        QShortcut(QKeySequence.Open, self, activated=self._shortcut_open)
        QShortcut(QKeySequence.Save, self, activated=self._shortcut_save)
        QShortcut(QKeySequence("Ctrl+PgDown"), self, activated=self._shortcut_next_module)
        QShortcut(QKeySequence("Ctrl+PgUp"), self, activated=self._shortcut_previous_module)
        QShortcut(QKeySequence("Alt+Down"), self, activated=self._shortcut_next_module)
        QShortcut(QKeySequence("Alt+Up"), self, activated=self._shortcut_previous_module)

    def _current_screen_name(self) -> str | None:
        item = self.sidebar.currentItem()
        return item.text() if item else None

    def _shortcut_open(self) -> None:
        screen_name = self._current_screen_name()
        field_name = SEARCH_FIELD_BY_SCREEN.get(screen_name)
        if not field_name:
            return
        screen = self.screens_by_name.get(screen_name)
        field = getattr(screen, field_name, None)
        if field is not None:
            field.setFocus()
            field.selectAll()

    def _shortcut_save(self) -> None:
        screen_name = self._current_screen_name()
        method_name = PRIMARY_ACTION_BY_SCREEN.get(screen_name)
        if not method_name:
            return
        screen = self.screens_by_name.get(screen_name)
        action = getattr(screen, method_name, None)
        if callable(action):
            action()

    def _shortcut_next_module(self) -> None:
        row = self.sidebar.currentRow()
        if row < self.sidebar.count() - 1:
            self.sidebar.setCurrentRow(row + 1)

    def _shortcut_previous_module(self) -> None:
        row = self.sidebar.currentRow()
        if row > 0:
            self.sidebar.setCurrentRow(row - 1)

    def _confirm_logout(self) -> None:
        confirm = QMessageBox.question(
            self, "Log out",
            f"Log out of {self.session_user.username} ({self.session_user.role_name})?",
        )
        if confirm == QMessageBox.Yes:
            logout(self.session_user.id)
            self.on_logout()

    def _start_idle_timer(self) -> None:
        # Auto-logout after inactivity (spec 20). A production build would
        # reset this on every real user input event app-wide.
        self._idle_timer = QTimer(self)
        self._idle_timer.setInterval(settings.SESSION_IDLE_TIMEOUT_MINUTES * 60 * 1000)
        self._idle_timer.timeout.connect(self._handle_idle_timeout)
        self._idle_timer.start()

    def _handle_idle_timeout(self) -> None:
        logout(self.session_user.id)
        self.on_logout()

    def closeEvent(self, event):  # noqa: N802 (Qt override)
        logout(self.session_user.id)
        super().closeEvent(event)
