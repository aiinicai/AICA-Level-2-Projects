"""
Small helper so internal snake_case values (walk_in, bank_transfer,
positive_negative...) never leak into the UI as literal text. The raw
value is still what gets saved to the database — only the on-screen label
changes.
"""
from __future__ import annotations

from PySide6.QtWidgets import QComboBox


def humanize(value: str) -> str:
    """'walk_in' -> 'Walk in', 'bank_transfer' -> 'Bank transfer'."""
    return value.replace("_", " ").replace("-", " ").strip().capitalize()


def add_choice_items(combo: QComboBox, values: list[str]) -> None:
    """Populate a combo box with humanized labels while keeping the raw
    value retrievable via `combo.currentData()`.
    """
    for value in values:
        combo.addItem(humanize(value), userData=value)
