"""
Application entry point.

Run with:  python -m app.main   (from the hospital_management/ directory)
"""
from __future__ import annotations

import sys

from PySide6.QtGui import QIcon
from PySide6.QtWidgets import QApplication

from app.config import settings
from app.database.base import init_db
from app.security.auth import ensure_seed_data
from app.services.seed_service import ensure_demo_department_and_doctor
from app.ui.screens.login_screen import LoginScreen
from app.ui.screens.main_window import MainWindow
from app.ui.themes.theme_manager import apply_saved_theme


class Application:
    """Owns the login -> dashboard transition so logging out returns to login."""

    def __init__(self):
        self.qt_app = QApplication(sys.argv)
        self.qt_app.setApplicationName(settings.APP_NAME)
        if settings.APP_LOGO_PATH.exists():
            self.qt_app.setWindowIcon(QIcon(str(settings.APP_LOGO_PATH)))
        apply_saved_theme(self.qt_app)  # defaults to the Heritage light theme on first run
        self.main_window: MainWindow | None = None
        self.login_screen: LoginScreen | None = None
        self._show_login()

    def _show_login(self) -> None:
        self.login_screen = LoginScreen(on_success=self._show_dashboard)
        self.login_screen.show()

    def _show_dashboard(self, session_user) -> None:
        if self.login_screen:
            self.login_screen.close()
        self.main_window = MainWindow(session_user, on_logout=self._handle_logout)
        self.main_window.show()

    def _handle_logout(self) -> None:
        if self.main_window:
            self.main_window.close()
            self.main_window = None
        self._show_login()

    def run(self) -> int:
        return self.qt_app.exec()


def main() -> int:
    init_db()
    ensure_seed_data()
    ensure_demo_department_and_doctor()
    return Application().run()


if __name__ == "__main__":
    sys.exit(main())
