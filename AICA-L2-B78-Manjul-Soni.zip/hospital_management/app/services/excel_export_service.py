"""
Bulk export of master data and reports to Excel (spec: "export saving
facilities to excel ... for Bulk export of masters of patients, doctors,
revenues, etc.").

Every export is a plain tabular dump (no formulas needed), built with
openpyxl: bold header row, autofilter, a professional font, and sensible
column widths.
"""
from __future__ import annotations

import datetime as _dt

from openpyxl import Workbook
from openpyxl.styles import Font
from openpyxl.utils import get_column_letter
from sqlalchemy import select

from app.database.base import session_scope
from app.models.billing import Invoice, Payment
from app.models.clinical import Department, Doctor
from app.models.patient import Patient
from app.services.advanced_reports_service import doctor_wise_revenue, service_wise_income
from app.services.medicine_service import list_medicines, total_stock

_HEADER_FONT = Font(name="Arial", bold=True, color="FFFFFF")
_BODY_FONT = Font(name="Arial")
_HEADER_FILL = "2E5B3F"  # leaf-green, matches the app's Heritage theme


def _write_sheet(worksheet, headers: list[str], rows: list[list]) -> None:
    from openpyxl.styles import PatternFill

    worksheet.append(headers)
    for cell in worksheet[1]:
        cell.font = _HEADER_FONT
        cell.fill = PatternFill(start_color=_HEADER_FILL, end_color=_HEADER_FILL, fill_type="solid")

    for row in rows:
        worksheet.append(row)
        for cell in worksheet[worksheet.max_row]:
            cell.font = _BODY_FONT

    worksheet.auto_filter.ref = worksheet.dimensions
    worksheet.freeze_panes = "A2"

    for index, header in enumerate(headers, start=1):
        longest = max([len(str(header))] + [len(str(row[index - 1])) for row in rows] if rows else [len(str(header))])
        worksheet.column_dimensions[get_column_letter(index)].width = min(max(longest + 2, 12), 45)


def export_patients_xlsx(file_path: str) -> str:
    """Bulk export of the patient master (spec 3), including email and the
    primary relative/next-of-kin contact.
    """
    with session_scope() as session:
        patients = session.execute(select(Patient).order_by(Patient.full_name)).scalars().all()
        session.expunge_all()

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Patients"

    headers = [
        "UHID", "Full name", "Gender", "Date of birth", "Age", "Mobile number", "Email",
        "Alternate number", "Address", "City", "State", "PIN code", "Blood group",
        "Emergency contact name", "Emergency contact number", "Emergency contact email",
        "Registered on",
    ]
    rows = [
        [
            patient.uhid, patient.full_name, patient.gender,
            patient.date_of_birth.isoformat() if patient.date_of_birth else "",
            patient.age_years or "", patient.mobile_number, patient.email or "",
            patient.alternate_number or "", patient.address or "", patient.city or "",
            patient.state or "", patient.pin_code or "", patient.blood_group or "",
            patient.emergency_contact_name or "", patient.emergency_contact_number or "",
            patient.emergency_contact_email or "",
            patient.created_at.strftime("%Y-%m-%d %H:%M") if patient.created_at else "",
        ]
        for patient in patients
    ]
    _write_sheet(sheet, headers, rows)
    workbook.save(file_path)
    return file_path


def export_doctors_xlsx(file_path: str) -> str:
    """Bulk export of the doctor master (spec 4)."""
    with session_scope() as session:
        doctors = session.execute(select(Doctor).order_by(Doctor.full_name)).scalars().all()
        departments_by_id = {
            department.id: department.name
            for department in session.execute(select(Department)).scalars().all()
        }
        session.expunge_all()

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Doctors"

    headers = [
        "Full name", "Department", "Specialization", "Registration number",
        "Consultation fee", "Room number", "Active",
    ]
    rows = [
        [
            doctor.full_name, departments_by_id.get(doctor.department_id, ""),
            doctor.specialization or "", doctor.registration_number or "",
            doctor.consultation_fee, doctor.room_number or "",
            "Yes" if doctor.is_active else "No",
        ]
        for doctor in doctors
    ]
    _write_sheet(sheet, headers, rows)
    workbook.save(file_path)
    return file_path


def export_revenue_xlsx(file_path: str, start_date: _dt.date, end_date: _dt.date) -> str:
    """Bulk export of revenue for a date range: invoice-level detail plus
    service-wise and doctor-wise summaries on separate tabs (spec 14).
    """
    start = _dt.datetime.combine(start_date, _dt.time.min)
    end = _dt.datetime.combine(end_date, _dt.time.max)

    with session_scope() as session:
        invoices = session.execute(
            select(Invoice).where(Invoice.created_at.between(start, end)).order_by(Invoice.created_at)
        ).scalars().all()
        session.expunge_all()

        payments = session.execute(
            select(Payment).where(Payment.received_at.between(start, end)).order_by(Payment.received_at)
        ).scalars().all()
        session.expunge_all()

    workbook = Workbook()

    invoice_sheet = workbook.active
    invoice_sheet.title = "Invoices"
    invoice_headers = [
        "Invoice number", "Type", "Patient ID", "Subtotal", "Discount", "Tax",
        "Total", "Paid", "Due", "Status", "Created on",
    ]
    invoice_rows = [
        [
            invoice.invoice_number, invoice.invoice_type, invoice.patient_id,
            invoice.subtotal, invoice.discount_amount, invoice.tax_amount,
            invoice.total_amount, invoice.paid_amount, invoice.due_amount,
            invoice.status, invoice.created_at.strftime("%Y-%m-%d %H:%M") if invoice.created_at else "",
        ]
        for invoice in invoices
    ]
    _write_sheet(invoice_sheet, invoice_headers, invoice_rows)

    payment_sheet = workbook.create_sheet("Payments")
    payment_headers = ["Invoice ID", "Amount", "Mode", "Is refund", "Received on"]
    payment_rows = [
        [
            payment.invoice_id, payment.amount, payment.payment_method or "",
            "Yes" if payment.is_refund else "No",
            payment.received_at.strftime("%Y-%m-%d %H:%M") if payment.received_at else "",
        ]
        for payment in payments
    ]
    _write_sheet(payment_sheet, payment_headers, payment_rows)

    service_sheet = workbook.create_sheet("Service-wise income")
    service_headers = ["Description", "Total", "Line items"]
    service_rows = [
        [row["description"], row["total"], row["count"]]
        for row in service_wise_income(start_date, end_date)
    ]
    _write_sheet(service_sheet, service_headers, service_rows)

    doctor_sheet = workbook.create_sheet("Doctor-wise revenue")
    doctor_headers = ["Doctor", "Revenue"]
    doctor_rows = [[row["doctor"], row["revenue"]] for row in doctor_wise_revenue(start_date, end_date)]
    _write_sheet(doctor_sheet, doctor_headers, doctor_rows)

    workbook.save(file_path)
    return file_path


def export_medicines_xlsx(file_path: str) -> str:
    """Bulk export of the medicine/inventory master (spec 11)."""
    medicines = list_medicines(active_only=False)

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Medicines"

    headers = [
        "Generic name", "Brand name", "Manufacturer", "Dosage form", "Strength",
        "MRP", "Sale price", "Reorder level", "Current stock", "Controlled drug", "Active",
    ]
    rows = [
        [
            medicine.generic_name, medicine.brand_name or "", medicine.manufacturer or "",
            medicine.dosage_form or "", medicine.strength or "", medicine.mrp, medicine.sale_price,
            medicine.reorder_level, total_stock(medicine.id),
            "Yes" if medicine.is_controlled_drug else "No",
            "Yes" if medicine.is_active else "No",
        ]
        for medicine in medicines
    ]
    _write_sheet(sheet, headers, rows)
    workbook.save(file_path)
    return file_path
