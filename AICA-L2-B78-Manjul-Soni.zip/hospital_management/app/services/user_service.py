"""
Staff account management (spec section 2: users/roles/permissions).

Before this module existed, the only way into the app was the single
seeded "admin" account — there was no way for an administrator to create
a receptionist, doctor, nurse, pharmacist, lab technician, accountant, or
store manager login. This closes that gap: create/deactivate/reactivate
accounts and reset passwords, all administrator-only.
"""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.clinical import Doctor
from app.models.user import Role, User
from app.security.auth import hash_password


class DuplicateUsernameError(Exception):
    pass


@dataclass
class UserInput:
    username: str
    full_name: str
    role_name: str
    password: str
    linked_doctor_id: int | None = None  # for role="doctor": which Doctor profile this login is


def create_user(data: UserInput) -> User:
    if not data.username.strip():
        raise ValueError("Username is required.")
    if len(data.password) < 6:
        raise ValueError("Password must be at least 6 characters.")

    with session_scope() as session:
        existing = session.execute(
            select(User).where(User.username == data.username.strip())
        ).scalar_one_or_none()
        if existing is not None:
            raise DuplicateUsernameError(f"Username '{data.username}' is already taken.")

        role = session.execute(select(Role).where(Role.name == data.role_name)).scalar_one_or_none()
        if role is None:
            raise ValueError(f"Role '{data.role_name}' does not exist.")

        user = User(
            username=data.username.strip(),
            password_hash=hash_password(data.password),
            full_name=data.full_name.strip(),
            role_id=role.id,
            is_active=True,
            must_change_password=True,
        )
        session.add(user)
        session.flush()

        if data.role_name == "doctor" and data.linked_doctor_id:
            doctor = session.get(Doctor, data.linked_doctor_id)
            if doctor is not None:
                doctor.user_id = user.id

        session.refresh(user)
        session.expunge(user)
        return user


def list_users() -> list[dict]:
    """Returns plain dicts (not ORM rows) since the caller needs the role
    name alongside the user, and this list is read-only display data."""
    with session_scope() as session:
        rows = session.execute(select(User).order_by(User.username)).scalars().all()
        roles_by_id = {role.id: role.name for role in session.execute(select(Role)).scalars().all()}
        return [
            {
                "id": u.id, "username": u.username, "full_name": u.full_name,
                "role_name": roles_by_id.get(u.role_id, "?"), "is_active": u.is_active,
                "last_login_at": u.last_login_at,
            }
            for u in rows
        ]


def set_active(user_id: int, is_active: bool) -> None:
    with session_scope() as session:
        user = session.get(User, user_id)
        if user is None:
            raise ValueError("User not found.")
        user.is_active = is_active


def reset_password(user_id: int, new_password: str) -> None:
    if len(new_password) < 6:
        raise ValueError("Password must be at least 6 characters.")
    with session_scope() as session:
        user = session.get(User, user_id)
        if user is None:
            raise ValueError("User not found.")
        user.password_hash = hash_password(new_password)
        user.must_change_password = True


def unlinked_doctors() -> list[Doctor]:
    """Doctor profiles with no login account yet — offered when creating a
    user with role="doctor" so the new login can be tied to the right
    doctor record."""
    with session_scope() as session:
        rows = session.execute(
            select(Doctor).where(Doctor.user_id.is_(None), Doctor.is_active.is_(True)).order_by(Doctor.full_name)
        ).scalars().all()
        session.expunge_all()
        return rows
