"""
Patient registration, duplicate-check and search (spec section 3).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field

from sqlalchemy import or_, select

from app.database.base import session_scope
from app.models.patient import Patient, PatientRelative
from app.services.id_generator import generate_uhid


@dataclass
class PatientInput:
    full_name: str
    gender: str
    mobile_number: str
    email: str | None = None
    date_of_birth: _dt.date | None = None
    alternate_number: str | None = None
    address: str | None = None
    city: str | None = None
    state: str | None = None
    pin_code: str | None = None
    blood_group: str | None = None
    marital_status: str | None = None
    occupation: str | None = None
    nationality: str | None = None
    emergency_contact_name: str | None = None
    emergency_contact_relation: str | None = None
    emergency_contact_number: str | None = None
    emergency_contact_email: str | None = None
    govt_id_type: str | None = None
    govt_id_number: str | None = None
    insurance_id: str | None = None
    photo_path: str | None = None


def find_possible_duplicates(mobile_number: str, full_name: str, date_of_birth: _dt.date | None,
                              govt_id_number: str | None = None, limit: int = 20) -> list[Patient]:
    """Search likely-duplicate patients before a new registration is saved."""
    with session_scope() as session:
        conditions = [Patient.mobile_number == mobile_number]
        if govt_id_number:
            conditions.append(Patient.govt_id_number == govt_id_number)
        if date_of_birth:
            conditions.append(Patient.date_of_birth == date_of_birth)
        conditions.append(Patient.full_name.ilike(f"%{full_name.strip()}%"))

        rows = (
            session.execute(select(Patient).where(or_(*conditions)).limit(limit))
            .scalars()
            .all()
        )
        session.expunge_all()
        return rows


def register_patient(data: PatientInput, created_by_id: int | None = None) -> Patient:
    age_years = None
    if data.date_of_birth:
        today = _dt.date.today()
        age_years = today.year - data.date_of_birth.year - (
            (today.month, today.day) < (data.date_of_birth.month, data.date_of_birth.day)
        )

    with session_scope() as session:
        uhid = generate_uhid(session)
        patient = Patient(
            uhid=uhid,
            full_name=data.full_name.strip(),
            gender=data.gender,
            date_of_birth=data.date_of_birth,
            age_years=age_years,
            mobile_number=data.mobile_number.strip(),
            email=data.email,
            alternate_number=data.alternate_number,
            address=data.address,
            city=data.city,
            state=data.state,
            pin_code=data.pin_code,
            blood_group=data.blood_group,
            marital_status=data.marital_status,
            occupation=data.occupation,
            nationality=data.nationality,
            emergency_contact_name=data.emergency_contact_name,
            emergency_contact_relation=data.emergency_contact_relation,
            emergency_contact_number=data.emergency_contact_number,
            emergency_contact_email=data.emergency_contact_email,
            govt_id_type=data.govt_id_type,
            govt_id_number=data.govt_id_number,
            insurance_id=data.insurance_id,
            photo_path=data.photo_path,
            created_by_id=created_by_id,
        )
        session.add(patient)
        session.flush()
        session.refresh(patient)
        session.expunge(patient)
        return patient


def search_patients(term: str, limit: int = 50) -> list[Patient]:
    """Fast global patient search by UHID, name or mobile number."""
    with session_scope() as session:
        like_term = f"%{term.strip()}%"
        rows = (
            session.execute(
                select(Patient)
                .where(
                    or_(
                        Patient.uhid.ilike(like_term),
                        Patient.full_name.ilike(like_term),
                        Patient.mobile_number.ilike(like_term),
                    )
                )
                .order_by(Patient.full_name)
                .limit(limit)
            )
            .scalars()
            .all()
        )
        session.expunge_all()
        return rows


def get_patient(patient_id: int) -> Patient | None:
    with session_scope() as session:
        patient = session.get(Patient, patient_id)
        if patient:
            session.expunge(patient)
        return patient


def add_relative(patient_id: int, full_name: str, relation: str | None = None,
                  mobile_number: str | None = None, email: str | None = None,
                  is_primary_contact: bool = False) -> PatientRelative:
    """Record a relative/next-of-kin contact for a patient (name, mobile, email).
    A patient can have more than one — spouse, child, guardian, etc.
    """
    if not full_name.strip():
        raise ValueError("Relative's name is required.")
    with session_scope() as session:
        relative = PatientRelative(
            patient_id=patient_id, full_name=full_name.strip(), relation=relation,
            mobile_number=mobile_number, email=email, is_primary_contact=is_primary_contact,
        )
        session.add(relative)
        session.flush()
        session.refresh(relative)
        session.expunge(relative)
        return relative


def list_relatives(patient_id: int) -> list[PatientRelative]:
    with session_scope() as session:
        rows = session.execute(
            select(PatientRelative).where(PatientRelative.patient_id == patient_id)
            .order_by(PatientRelative.is_primary_contact.desc(), PatientRelative.full_name)
        ).scalars().all()
        session.expunge_all()
        return rows
