"""
Inpatient interim/final billing: per-day bed charges plus any ad-hoc
procedure/consumable lines, generated as an `ipd_interim` or `ipd_final`
invoice through the same atomic billing_service used everywhere else.
"""
from __future__ import annotations

from app.database.base import session_scope
from app.models.ipd import Admission, Bed
from app.services.admission_service import admission_days
from app.services.billing_service import InvoiceLine, create_invoice


def generate_bed_charge_invoice(admission_id: int, invoice_type: str = "ipd_interim",
                                 extra_lines: list[InvoiceLine] | None = None,
                                 created_by_id: int | None = None):
    """Bill the bed days accrued so far (interim) or at discharge (final),
    plus any extra lines (procedures, consumables, pharmacy-during-stay).
    """
    if invoice_type not in ("ipd_interim", "ipd_final"):
        raise ValueError("invoice_type must be 'ipd_interim' or 'ipd_final'.")

    with session_scope() as session:
        admission = session.get(Admission, admission_id)
        if admission is None:
            raise ValueError("Admission not found.")
        bed = session.get(Bed, admission.bed_id)
        days = admission_days(admission)
        daily_charge = bed.daily_charge if bed else 0.0
        patient_id = admission.patient_id

    lines = [InvoiceLine(description=f"Bed charge ({days} day(s) @ {daily_charge:.2f})",
                          quantity=days, unit_price=daily_charge)]
    if extra_lines:
        lines.extend(extra_lines)

    return create_invoice(
        patient_id=patient_id, invoice_type=invoice_type, lines=lines,
        created_by_id=created_by_id,
    )
