"""
Ward/room/bed master setup and the occupancy dashboard (spec section 6).
"""
from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.ipd import Bed, Room, Ward


def add_ward(name: str, ward_type: str | None = None) -> Ward:
    with session_scope() as session:
        ward = Ward(name=name, ward_type=ward_type)
        session.add(ward)
        session.flush()
        session.refresh(ward)
        session.expunge(ward)
        return ward


def list_wards() -> list[Ward]:
    with session_scope() as session:
        rows = session.execute(select(Ward).order_by(Ward.name)).scalars().all()
        session.expunge_all()
        return rows


def add_room(ward_id: int, room_number: str) -> Room:
    with session_scope() as session:
        room = Room(ward_id=ward_id, room_number=room_number)
        session.add(room)
        session.flush()
        session.refresh(room)
        session.expunge(room)
        return room


def list_rooms(ward_id: int | None = None) -> list[Room]:
    with session_scope() as session:
        stmt = select(Room)
        if ward_id:
            stmt = stmt.where(Room.ward_id == ward_id)
        rows = session.execute(stmt.order_by(Room.room_number)).scalars().all()
        session.expunge_all()
        return rows


def add_bed(room_id: int, bed_number: str, bed_category: str = "general", daily_charge: float = 0.0) -> Bed:
    with session_scope() as session:
        bed = Bed(room_id=room_id, bed_number=bed_number, bed_category=bed_category, daily_charge=daily_charge)
        session.add(bed)
        session.flush()
        session.refresh(bed)
        session.expunge(bed)
        return bed


def list_beds(status: str | None = None) -> list[Bed]:
    with session_scope() as session:
        stmt = select(Bed)
        if status:
            stmt = stmt.where(Bed.status == status)
        rows = session.execute(stmt.order_by(Bed.bed_number)).scalars().all()
        session.expunge_all()
        return rows


def available_beds() -> list[Bed]:
    return list_beds(status="available")


@dataclass
class OccupancySummary:
    total_beds: int
    available: int
    occupied: int
    reserved: int
    cleaning: int
    maintenance: int


def occupancy_summary() -> OccupancySummary:
    with session_scope() as session:
        beds = session.execute(select(Bed)).scalars().all()
        counts = {"available": 0, "occupied": 0, "reserved": 0, "cleaning": 0, "maintenance": 0}
        for bed in beds:
            counts[bed.status] = counts.get(bed.status, 0) + 1
        return OccupancySummary(total_beds=len(beds), **counts)


def set_bed_status(bed_id: int, status: str) -> None:
    valid = {"available", "occupied", "reserved", "cleaning", "maintenance"}
    if status not in valid:
        raise ValueError(f"Invalid bed status '{status}'. Must be one of {valid}.")
    with session_scope() as session:
        bed = session.get(Bed, bed_id)
        if bed is None:
            raise ValueError("Bed not found.")
        bed.status = status
