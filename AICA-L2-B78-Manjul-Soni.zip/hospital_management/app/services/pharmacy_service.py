"""
Dispensing against a doctor's prescription (spec section 9): pulls medicines
straight from the prescription, allows partial dispensing, supports an
explicit substitution note, deducts stock FEFO, and generates the pharmacy
bill — all inside one transaction so a bill is never created without the
matching stock movement (or vice versa).
"""
from __future__ import annotations

from dataclasses import dataclass, field

from app.database.base import session_scope
from app.models.billing import Invoice
from app.models.pharmacy import Medicine, PharmacySale, PharmacySaleItem
from app.services.id_generator import generate_invoice_number
from app.services.medicine_service import InsufficientStockError, fefo_deduct


@dataclass
class DispenseLine:
    medicine_id: int
    quantity: int
    unit_price: float
    substitution_note: str | None = None


@dataclass
class DispenseResult:
    sale_id: int
    invoice_id: int
    invoice_number: str
    total_amount: float


def dispense(
    patient_id: int,
    lines: list[DispenseLine],
    prescription_id: int | None = None,
    dispensed_by_id: int | None = None,
) -> DispenseResult:
    """Create a pharmacy sale + matching invoice, deducting stock FEFO.

    Raises InsufficientStockError (and rolls back everything, including any
    stock already deducted for earlier lines in the same call) if any line
    can't be fully covered by on-hand batches.
    """
    if not lines:
        raise ValueError("At least one medicine line is required to dispense.")

    with session_scope() as session:
        sale = PharmacySale(prescription_id=prescription_id, patient_id=patient_id,
                             dispensed_by_id=dispensed_by_id)
        session.add(sale)
        session.flush()

        invoice = Invoice(
            invoice_number=generate_invoice_number(session),
            invoice_type="pharmacy",
            patient_id=patient_id,
            created_by_id=dispensed_by_id,
        )
        session.add(invoice)
        session.flush()

        subtotal = 0.0
        tax_amount = 0.0

        for line in lines:
            medicine = session.get(Medicine, line.medicine_id)
            if medicine is None:
                raise ValueError(f"Medicine #{line.medicine_id} not found.")

            # Raises InsufficientStockError inside this same transaction,
            # so session_scope() rolls back the whole dispense on failure.
            fefo_deduct(
                session, line.medicine_id, line.quantity,
                reference_type="pharmacy_sale", reference_id=sale.id,
                created_by_id=dispensed_by_id,
            )

            session.add(
                PharmacySaleItem(
                    sale_id=sale.id,
                    medicine_id=line.medicine_id,
                    quantity=line.quantity,
                    unit_price=line.unit_price,
                    substitution_note=line.substitution_note,
                )
            )

            line_subtotal = line.quantity * line.unit_price
            line_tax = line_subtotal * (medicine.tax_percent / 100.0)
            subtotal += line_subtotal
            tax_amount += line_tax

            from app.models.billing import InvoiceItem

            session.add(
                InvoiceItem(
                    invoice_id=invoice.id,
                    description=f"{medicine.generic_name} ({medicine.brand_name or medicine.dosage_form or ''}) x{line.quantity}",
                    quantity=line.quantity,
                    unit_price=line.unit_price,
                    tax_percent=medicine.tax_percent,
                    line_total=round(line_subtotal + line_tax, 2),
                )
            )

        invoice.subtotal = round(subtotal, 2)
        invoice.tax_amount = round(tax_amount, 2)
        invoice.total_amount = round(subtotal + tax_amount, 2)
        invoice.due_amount = invoice.total_amount

        sale.invoice_id = invoice.id

        session.flush()
        result = DispenseResult(
            sale_id=sale.id, invoice_id=invoice.id,
            invoice_number=invoice.invoice_number, total_amount=invoice.total_amount,
        )
        return result
