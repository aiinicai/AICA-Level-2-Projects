"""
PDF generation (spec 17: printouts) for invoices/bills, prescriptions, and
tabular reports.

Before this module existed, "printing" anything just meant a QMessageBox
summarizing the numbers — nothing the patient could actually take away or
file. This uses reportlab (already vendored in the environment) to produce
real, formatted PDF documents saved wherever the user picks in a save
dialog. Kept deliberately simple (no external template engine, no images
beyond the hospital's own logo if present) so it has no fragile
dependencies beyond reportlab itself.
"""
from __future__ import annotations

import datetime as _dt
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

from app.database.base import session_scope
from app.models.billing import Invoice
from app.models.clinical import Doctor, Prescription, Visit
from app.models.patient import Patient
from app.services.hospital_settings_service import get_hospital_profile

_STYLES = getSampleStyleSheet()
_TITLE_STYLE = ParagraphStyle(
    "HMSTitle", parent=_STYLES["Heading1"], fontSize=16, spaceAfter=2, textColor=colors.HexColor("#1f5c4d"),
)
_SUBTITLE_STYLE = ParagraphStyle("HMSSubtitle", parent=_STYLES["Normal"], fontSize=9, textColor=colors.grey)
_HEADING_STYLE = ParagraphStyle("HMSHeading", parent=_STYLES["Heading2"], fontSize=12, spaceBefore=10, spaceAfter=4)
_NORMAL_STYLE = _STYLES["Normal"]
_CELL_STYLE = ParagraphStyle("HMSCell", parent=_STYLES["Normal"], fontSize=9, leading=11)


def _cell(text: str) -> Paragraph:
    """Wrap a table cell's text in a Paragraph so long content (a doctor's
    name + specialization + registration number, a long address, ...) wraps
    within the column instead of silently overflowing into whatever cell
    sits next to it (reportlab's default Table behaviour for plain strings)."""
    return Paragraph(text, _CELL_STYLE)


def _hospital_header() -> list:
    profile = get_hospital_profile()
    flow = [Paragraph(profile.name or "Hospital", _TITLE_STYLE)]
    if profile.tagline:
        flow.append(Paragraph(profile.tagline, _SUBTITLE_STYLE))
    address_bits = [b for b in (profile.address, profile.phone, profile.email) if b]
    if address_bits:
        flow.append(Paragraph(" | ".join(address_bits), _SUBTITLE_STYLE))
    reg_bits = [b for b in (
        (f"GSTIN: {profile.gstin}" if profile.gstin else None),
        (f"Reg. No: {profile.registration_number}" if profile.registration_number else None),
    ) if b]
    if reg_bits:
        flow.append(Paragraph(" | ".join(reg_bits), _SUBTITLE_STYLE))
    flow.append(Spacer(1, 8))
    return flow


def _ensure_parent(output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    return path


def generate_invoice_pdf(invoice_id: int, output_path: str | Path) -> Path:
    """Render an invoice/bill (spec 10/17) as a printable PDF: hospital
    header, patient details, itemized lines with tax, totals, and payment
    history so far.
    """
    with session_scope() as session:
        invoice = session.get(Invoice, invoice_id)
        if invoice is None:
            raise ValueError(f"Invoice #{invoice_id} not found.")
        patient = session.get(Patient, invoice.patient_id)
        items = list(invoice.items)
        payments = list(invoice.payments)
        # Pull every field needed while the session is still open, since
        # this function returns a plain Path, not an ORM object — nothing
        # here is read back from a detached instance after this block.
        data = {
            "invoice_number": invoice.invoice_number,
            "invoice_type": invoice.invoice_type,
            "created_at": invoice.created_at,
            "subtotal": invoice.subtotal,
            "discount_amount": invoice.discount_amount,
            "discount_reason": invoice.discount_reason,
            "tax_amount": invoice.tax_amount,
            "total_amount": invoice.total_amount,
            "paid_amount": invoice.paid_amount,
            "due_amount": invoice.due_amount,
            "status": invoice.status,
            "items": [
                (it.description, it.quantity, it.unit_price, it.tax_percent, it.line_total) for it in items
            ],
            "payments": [
                (p.received_at, p.payment_method, p.amount, p.is_refund) for p in payments
            ],
            "patient_name": patient.full_name if patient else "—",
            "patient_uhid": patient.uhid if patient else "—",
            "patient_mobile": patient.mobile_number if patient else "—",
            "patient_address": patient.address if patient else None,
        }

    output_path = _ensure_parent(output_path)
    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4,
        topMargin=15 * mm, bottomMargin=15 * mm, leftMargin=18 * mm, rightMargin=18 * mm,
    )
    flow: list = _hospital_header()
    flow.append(Paragraph(f"INVOICE — {data['invoice_number']}", _HEADING_STYLE))

    header_table = Table([
        ["Patient", _cell(data["patient_name"]), "Invoice date", data["created_at"].strftime("%d-%b-%Y %H:%M")],
        ["UHID", _cell(data["patient_uhid"]), "Invoice type", data["invoice_type"].upper()],
        ["Mobile", _cell(data["patient_mobile"]), "Status", data["status"].upper()],
    ], colWidths=[28 * mm, 62 * mm, 28 * mm, 62 * mm])
    header_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    flow.append(header_table)
    flow.append(Spacer(1, 10))

    line_rows = [["Description", "Qty", "Unit price", "Tax %", "Line total"]]
    for description, qty, unit_price, tax_percent, line_total in data["items"]:
        line_rows.append([
            _cell(description), f"{qty:g}", f"{unit_price:,.2f}", f"{tax_percent:g}%", f"{line_total:,.2f}",
        ])
    items_table = Table(line_rows, colWidths=[80 * mm, 18 * mm, 30 * mm, 18 * mm, 34 * mm])
    items_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8e3d0")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (-1, -1), "RIGHT"),
        ("ALIGN", (0, 0), (0, -1), "LEFT"),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
    ]))
    flow.append(items_table)
    flow.append(Spacer(1, 8))

    totals_rows = [["Subtotal", f"{data['subtotal']:,.2f}"]]
    if data["discount_amount"]:
        label = "Discount"
        if data["discount_reason"]:
            label += f" ({data['discount_reason']})"
        totals_rows.append([label, f"-{data['discount_amount']:,.2f}"])
    totals_rows.append(["Tax", f"{data['tax_amount']:,.2f}"])
    totals_rows.append(["Total amount", f"{data['total_amount']:,.2f}"])
    totals_rows.append(["Paid", f"{data['paid_amount']:,.2f}"])
    totals_rows.append(["Balance due", f"{data['due_amount']:,.2f}"])

    totals_table = Table(totals_rows, colWidths=[130 * mm, 50 * mm])
    totals_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("LINEABOVE", (0, -1), (-1, -1), 0.6, colors.black),
        ("TOPPADDING", (0, 0), (-1, -1), 2),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
    ]))
    flow.append(totals_table)

    if data["payments"]:
        flow.append(Spacer(1, 10))
        flow.append(Paragraph("Payment history", _HEADING_STYLE))
        pay_rows = [["Date", "Method", "Amount", "Type"]]
        for received_at, method, amount, is_refund in data["payments"]:
            pay_rows.append([
                received_at.strftime("%d-%b-%Y %H:%M"), method.upper(),
                f"{amount:,.2f}", "REFUND" if is_refund else "PAYMENT",
            ])
        pay_table = Table(pay_rows, colWidths=[45 * mm, 45 * mm, 45 * mm, 45 * mm])
        pay_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8e3d0")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ]))
        flow.append(pay_table)

    flow.append(Spacer(1, 16))
    flow.append(Paragraph(
        f"Generated {_dt.datetime.now().strftime('%d-%b-%Y %H:%M')} — this is a system-generated document.",
        _SUBTITLE_STYLE,
    ))

    doc.build(flow)
    return output_path


def generate_prescription_pdf(prescription_id: int, output_path: str | Path) -> Path:
    """Render a doctor's prescription (spec 5) as a printable PDF."""
    with session_scope() as session:
        prescription = session.get(Prescription, prescription_id)
        if prescription is None:
            raise ValueError(f"Prescription #{prescription_id} not found.")
        visit = session.get(Visit, prescription.visit_id)
        doctor = session.get(Doctor, prescription.doctor_id)
        patient = session.get(Patient, visit.patient_id) if visit else None
        items = list(prescription.items)
        data = {
            "created_at": prescription.created_at,
            "is_finalized": prescription.is_finalized,
            "doctor_name": doctor.full_name if doctor else "—",
            "doctor_reg": doctor.registration_number if doctor else None,
            "doctor_spec": doctor.specialization if doctor else None,
            "patient_name": patient.full_name if patient else "—",
            "patient_uhid": patient.uhid if patient else "—",
            "patient_age": patient.age_years if patient else None,
            "patient_gender": patient.gender if patient else None,
            "items": [
                (it.medicine_name, it.dosage, it.frequency, it.route, it.duration_days,
                 it.quantity, it.food_instruction, it.notes)
                for it in items
            ],
        }

    output_path = _ensure_parent(output_path)
    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4,
        topMargin=15 * mm, bottomMargin=15 * mm, leftMargin=18 * mm, rightMargin=18 * mm,
    )
    flow: list = _hospital_header()
    flow.append(Paragraph("PRESCRIPTION (Rx)", _HEADING_STYLE))

    doctor_line = data["doctor_name"]
    if data["doctor_spec"]:
        doctor_line += f" ({data['doctor_spec']})"
    if data["doctor_reg"]:
        doctor_line += f" — Reg. No: {data['doctor_reg']}"

    patient_bits = [f"UHID: {data['patient_uhid']}"]
    if data["patient_age"] is not None:
        patient_bits.append(f"Age: {data['patient_age']}")
    if data["patient_gender"]:
        patient_bits.append(f"Gender: {data['patient_gender'].title()}")

    info_table = Table([
        ["Patient", _cell(data["patient_name"]), "Date", data["created_at"].strftime("%d-%b-%Y %H:%M")],
        ["Doctor", _cell(doctor_line), "Status", "Finalized" if data["is_finalized"] else "Draft"],
        [" ", _cell(" | ".join(patient_bits)), "", ""],
    ], colWidths=[22 * mm, 98 * mm, 22 * mm, 38 * mm])
    info_table.setStyle(TableStyle([
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
        ("FONTNAME", (2, 0), (2, -1), "Helvetica-Bold"),
        ("SPAN", (1, 2), (3, 2)),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    flow.append(info_table)
    flow.append(Spacer(1, 12))
    flow.append(Paragraph("Rx", ParagraphStyle("Rx", parent=_STYLES["Heading2"], fontSize=18)))
    flow.append(Spacer(1, 4))

    rows = [["#", "Medicine", "Dosage", "Frequency", "Route", "Days", "Qty", "Instruction"]]
    for i, (name, dosage, freq, route, days, qty, food, notes) in enumerate(data["items"], start=1):
        instruction = (food or "").replace("_", " ").title()
        if notes:
            instruction = f"{instruction} — {notes}" if instruction else notes
        rows.append([
            str(i), _cell(name), dosage or "-", freq or "-", route or "-",
            str(days) if days is not None else "-", str(qty) if qty is not None else "-",
            _cell(instruction or "-"),
        ])
    rx_table = Table(rows, colWidths=[8 * mm, 40 * mm, 20 * mm, 22 * mm, 18 * mm, 14 * mm, 12 * mm, 46 * mm])
    rx_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8e3d0")),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8.5),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
    ]))
    flow.append(rx_table)

    flow.append(Spacer(1, 24))
    flow.append(Paragraph(
        f"Generated {_dt.datetime.now().strftime('%d-%b-%Y %H:%M')} — this is a system-generated document, "
        "not a substitute for the doctor's original signature where required by law.",
        _SUBTITLE_STYLE,
    ))

    doc.build(flow)
    return output_path


def generate_report_pdf(
    title: str,
    headers: list[str],
    rows: list[list[str]],
    output_path: str | Path,
    subtitle: str | None = None,
) -> Path:
    """Render any tabular report (daily summary, advanced reports, ...) as a
    generic PDF — used by the Reports screen so every report the app can
    already show on-screen can also be exported as a document, not just CSV/
    Excel.
    """
    output_path = _ensure_parent(output_path)
    doc = SimpleDocTemplate(
        str(output_path), pagesize=A4,
        topMargin=15 * mm, bottomMargin=15 * mm, leftMargin=18 * mm, rightMargin=18 * mm,
    )
    flow: list = _hospital_header()
    flow.append(Paragraph(title, _HEADING_STYLE))
    if subtitle:
        flow.append(Paragraph(subtitle, _SUBTITLE_STYLE))
        flow.append(Spacer(1, 8))

    if not rows:
        flow.append(Paragraph("No data for the selected range.", _NORMAL_STYLE))
    else:
        table_rows = [list(headers)] + [[_cell(str(cell)) for cell in row] for row in rows]
        col_width = (A4[0] - 36 * mm) / max(len(headers), 1)
        table = Table(table_rows, colWidths=[col_width] * len(headers), repeatRows=1)
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e8e3d0")),
            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
            ("FONTSIZE", (0, 0), (-1, -1), 8.5),
            ("GRID", (0, 0), (-1, -1), 0.4, colors.grey),
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ]))
        flow.append(table)

    flow.append(Spacer(1, 16))
    flow.append(Paragraph(
        f"Generated {_dt.datetime.now().strftime('%d-%b-%Y %H:%M')} — this is a system-generated document.",
        _SUBTITLE_STYLE,
    ))

    doc.build(flow)
    return output_path
