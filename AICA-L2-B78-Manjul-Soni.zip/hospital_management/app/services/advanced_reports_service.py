"""
Advanced financial and inventory reports (spec section 14, Phase 2 scope):
service-wise income, doctor-wise revenue, outstanding receivables, discount/
refund summary, pharmacy sales, and low-stock/expiry snapshots. Kept in its
own module so report_service.py (the Phase 1 daily summary) stays small.
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import func, select

from app.database.base import session_scope
from app.models.billing import Invoice, InvoiceItem, Payment
from app.models.clinical import Doctor, Visit
from app.models.pharmacy import PharmacySale, PharmacySaleItem, Medicine
from app.services.medicine_service import expiring_batches, low_stock_medicines


def service_wise_income(start_date: _dt.date, end_date: _dt.date) -> list[dict]:
    start = _dt.datetime.combine(start_date, _dt.time.min)
    end = _dt.datetime.combine(end_date, _dt.time.max)
    with session_scope() as session:
        rows = session.execute(
            select(InvoiceItem.description, func.sum(InvoiceItem.line_total), func.count(InvoiceItem.id))
            .join(Invoice, Invoice.id == InvoiceItem.invoice_id)
            .where(Invoice.created_at.between(start, end), Invoice.status == "active")
            .group_by(InvoiceItem.description)
            .order_by(func.sum(InvoiceItem.line_total).desc())
        ).all()
        return [{"description": desc, "total": round(total, 2), "count": count} for desc, total, count in rows]


def doctor_wise_revenue(start_date: _dt.date, end_date: _dt.date) -> list[dict]:
    start = _dt.datetime.combine(start_date, _dt.time.min)
    end = _dt.datetime.combine(end_date, _dt.time.max)
    with session_scope() as session:
        rows = session.execute(
            select(Doctor.full_name, func.sum(Invoice.total_amount))
            .join(Visit, Visit.doctor_id == Doctor.id)
            .join(Invoice, Invoice.visit_id == Visit.id)
            .where(Invoice.created_at.between(start, end), Invoice.status == "active")
            .group_by(Doctor.full_name)
            .order_by(func.sum(Invoice.total_amount).desc())
        ).all()
        return [{"doctor": name, "revenue": round(total, 2)} for name, total in rows]


def outstanding_receivables() -> list[dict]:
    with session_scope() as session:
        rows = session.execute(
            select(Invoice.invoice_number, Invoice.patient_id, Invoice.due_amount)
            .where(Invoice.status == "active", Invoice.due_amount > 0)
            .order_by(Invoice.due_amount.desc())
        ).all()
        return [
            {"invoice_number": num, "patient_id": pid, "due_amount": round(due, 2)}
            for num, pid, due in rows
        ]


def discount_refund_report(start_date: _dt.date, end_date: _dt.date) -> dict:
    start = _dt.datetime.combine(start_date, _dt.time.min)
    end = _dt.datetime.combine(end_date, _dt.time.max)
    with session_scope() as session:
        total_discount = session.execute(
            select(func.coalesce(func.sum(Invoice.discount_amount), 0.0)).where(
                Invoice.created_at.between(start, end)
            )
        ).scalar_one()
        total_refunds = session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0.0)).where(
                Payment.received_at.between(start, end), Payment.is_refund.is_(True)
            )
        ).scalar_one()
        cancelled_invoices = session.execute(
            select(func.count()).select_from(Invoice).where(
                Invoice.created_at.between(start, end), Invoice.status == "voided"
            )
        ).scalar_one()
        return {
            "total_discount": round(total_discount, 2),
            "total_refunds": round(total_refunds, 2),
            "cancelled_invoices": cancelled_invoices,
        }


def pharmacy_sales_summary(start_date: _dt.date, end_date: _dt.date) -> list[dict]:
    start = _dt.datetime.combine(start_date, _dt.time.min)
    end = _dt.datetime.combine(end_date, _dt.time.max)
    with session_scope() as session:
        rows = session.execute(
            select(Medicine.generic_name, func.sum(PharmacySaleItem.quantity),
                   func.sum(PharmacySaleItem.quantity * PharmacySaleItem.unit_price))
            .join(PharmacySaleItem, PharmacySaleItem.medicine_id == Medicine.id)
            .join(PharmacySale, PharmacySale.id == PharmacySaleItem.sale_id)
            .where(PharmacySale.created_at.between(start, end), PharmacySale.is_return.is_(False))
            .group_by(Medicine.generic_name)
            .order_by(func.sum(PharmacySaleItem.quantity * PharmacySaleItem.unit_price).desc())
        ).all()
        return [
            {"medicine": name, "quantity_sold": qty, "total_sales": round(total, 2)}
            for name, qty, total in rows
        ]


def inventory_snapshot() -> dict:
    return {
        "low_stock": low_stock_medicines(),
        "near_expiry": expiring_batches(),
    }
