"""
Document attachment (spec section 13): every uploaded file gets a database
record — patient, document type, date, uploader, and physical path — never
just a bare filename on disk.
"""
from __future__ import annotations

import datetime as _dt
import shutil
import uuid
from pathlib import Path

from sqlalchemy import select

from app.config import settings
from app.database.base import session_scope
from app.models.patient import PatientDocument


def attach_document(patient_id: int, source_file_path: str, document_type: str,
                     description: str | None = None, uploaded_by_id: int | None = None) -> PatientDocument:
    source = Path(source_file_path)
    if not source.exists():
        raise FileNotFoundError(f"File not found: {source_file_path}")

    patient_dir = settings.DOCUMENTS_DIR / str(patient_id)
    patient_dir.mkdir(parents=True, exist_ok=True)

    stored_name = f"{_dt.datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:8]}{source.suffix}"
    destination = patient_dir / stored_name
    shutil.copy2(source, destination)

    with session_scope() as session:
        document = PatientDocument(
            patient_id=patient_id,
            document_type=document_type,
            description=description,
            file_path=str(destination),
            uploaded_by_id=uploaded_by_id,
        )
        session.add(document)
        session.flush()
        session.refresh(document)
        session.expunge(document)
        return document


def list_documents(patient_id: int) -> list[PatientDocument]:
    with session_scope() as session:
        rows = (
            session.execute(
                select(PatientDocument)
                .where(PatientDocument.patient_id == patient_id)
                .order_by(PatientDocument.uploaded_at.desc())
            )
            .scalars()
            .all()
        )
        session.expunge_all()
        return rows
