"""
Human-readable, sequential ID generation for UHID / invoice / admission numbers.

Internal primary keys stay numeric (patient.id, invoice.id); these are the
visible, prefixed numbers shown on printouts (spec 17).
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import func, select

from app.config import settings


def _next_sequence(session, model, number_column, prefix: str) -> str:
    year = _dt.datetime.now().strftime("%y")
    like_pattern = f"{prefix}{year}%"
    count = session.execute(
        select(func.count()).select_from(model).where(number_column.like(like_pattern))
    ).scalar_one()
    return f"{prefix}{year}{count + 1:06d}"


def generate_uhid(session) -> str:
    from app.models.patient import Patient

    return _next_sequence(session, Patient, Patient.uhid, settings.UHID_PREFIX)


def generate_invoice_number(session) -> str:
    from app.models.billing import Invoice

    return _next_sequence(session, Invoice, Invoice.invoice_number, settings.INVOICE_PREFIX)
