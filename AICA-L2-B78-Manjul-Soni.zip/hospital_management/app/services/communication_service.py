"""
SMS / WhatsApp / email notifications (spec Phase 4).

Real SMS and WhatsApp delivery needs a paid provider account (e.g. Twilio,
Gupshup, Meta Cloud API) which this offline capstone build has no
credentials for, so those two channels are recorded to the communication
log with status="simulated" rather than actually sent. Email is different:
SMTP is a protocol anyone can point at their own mail account, so real
sending is implemented — configure a host/port/username/password/from
address in Settings -> Notifications and it sends for real; leave it
unconfigured and email is simulated exactly like SMS/WhatsApp.

Every send — real or simulated — is recorded in CommunicationLog so there
is always an audit trail of what the app tried to tell a patient and when.
"""
from __future__ import annotations

import datetime as _dt
import smtplib
from dataclasses import dataclass
from email.mime.text import MIMEText

from sqlalchemy import select

from app.database.base import session_scope
from app.models.communication import CommunicationLog
from app.services.settings_service import get_setting, set_setting

_SMTP_FIELDS = ("smtp_host", "smtp_port", "smtp_username", "smtp_password", "smtp_from_address", "smtp_use_tls")


@dataclass
class SmtpConfig:
    host: str = ""
    port: int = 587
    username: str = ""
    password: str = ""
    from_address: str = ""
    use_tls: bool = True

    @property
    def is_configured(self) -> bool:
        return bool(self.host and self.from_address)


def get_smtp_config() -> SmtpConfig:
    return SmtpConfig(
        host=get_setting("smtp_host", "") or "",
        port=int(get_setting("smtp_port", "587") or "587"),
        username=get_setting("smtp_username", "") or "",
        password=get_setting("smtp_password", "") or "",
        from_address=get_setting("smtp_from_address", "") or "",
        use_tls=(get_setting("smtp_use_tls", "true") or "true") == "true",
    )


def save_smtp_config(config: SmtpConfig) -> None:
    set_setting("smtp_host", config.host)
    set_setting("smtp_port", str(config.port))
    set_setting("smtp_username", config.username)
    set_setting("smtp_password", config.password)
    set_setting("smtp_from_address", config.from_address)
    set_setting("smtp_use_tls", "true" if config.use_tls else "false")


def _send_email_via_smtp(config: SmtpConfig, to_address: str, subject: str, message: str) -> None:
    mime_message = MIMEText(message)
    mime_message["Subject"] = subject
    mime_message["From"] = config.from_address
    mime_message["To"] = to_address

    with smtplib.SMTP(config.host, config.port, timeout=15) as server:
        if config.use_tls:
            server.starttls()
        if config.username:
            server.login(config.username, config.password)
        server.sendmail(config.from_address, [to_address], mime_message.as_string())


def send_notification(channel: str, recipient: str, message: str, subject: str | None = None,
                       patient_id: int | None = None, template_key: str | None = None) -> CommunicationLog:
    """Send (or simulate) a notification and always log it.

    channel: "email" | "sms" | "whatsapp"
    Never raises for a failed/simulated send — callers (appointment
    booking, invoice generation, discharge, ...) should be able to fire
    this best-effort without a notification failure breaking the actual
    business transaction it is attached to.
    """
    status = "simulated"
    error_message = None
    sent_at = None

    if channel == "email":
        config = get_smtp_config()
        if config.is_configured:
            try:
                _send_email_via_smtp(config, recipient, subject or "Notification", message)
                status = "sent"
                sent_at = _dt.datetime.utcnow()
            except Exception as exc:  # noqa: BLE001 — log and move on, never break the caller
                status = "failed"
                error_message = str(exc)
        # else: no SMTP configured -> stays "simulated"
    # sms / whatsapp: no provider wired in this build -> stays "simulated"

    with session_scope() as session:
        log_entry = CommunicationLog(
            patient_id=patient_id, channel=channel, recipient=recipient, subject=subject,
            message=message, template_key=template_key, status=status,
            error_message=error_message, sent_at=sent_at,
        )
        session.add(log_entry)
        session.flush()
        session.refresh(log_entry)
        session.expunge(log_entry)
        return log_entry


def list_communications(patient_id: int | None = None, limit: int = 200) -> list[CommunicationLog]:
    with session_scope() as session:
        stmt = select(CommunicationLog).order_by(CommunicationLog.created_at.desc()).limit(limit)
        if patient_id is not None:
            stmt = stmt.where(CommunicationLog.patient_id == patient_id)
        rows = session.execute(stmt).scalars().all()
        session.expunge_all()
        return rows
