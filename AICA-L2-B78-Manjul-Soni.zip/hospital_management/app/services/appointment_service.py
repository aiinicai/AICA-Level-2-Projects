"""
Doctor/department setup, appointment booking with token numbers, and the
OPD queue (spec section 4).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import func, select

from app.database.base import session_scope
from app.models.clinical import Appointment, Department, Doctor, Visit


def list_departments() -> list[Department]:
    with session_scope() as session:
        rows = session.execute(select(Department).order_by(Department.name)).scalars().all()
        session.expunge_all()
        return rows


def add_department(name: str) -> Department:
    """Administrator screen: configure departments (spec section 2)."""
    with session_scope() as session:
        existing = session.execute(select(Department).where(Department.name == name)).scalar_one_or_none()
        if existing:
            raise ValueError(f"Department '{name}' already exists.")
        department = Department(name=name)
        session.add(department)
        session.flush()
        session.refresh(department)
        session.expunge(department)
        return department


def add_doctor(full_name: str, department_id: int, specialization: str | None = None,
                registration_number: str | None = None, consultation_fee: float = 0.0,
                room_number: str | None = None) -> Doctor:
    """Administrator screen: doctor/department setup (spec section 4)."""
    with session_scope() as session:
        doctor = Doctor(
            full_name=full_name,
            department_id=department_id,
            specialization=specialization,
            registration_number=registration_number,
            consultation_fee=consultation_fee,
            room_number=room_number,
        )
        session.add(doctor)
        session.flush()
        session.refresh(doctor)
        session.expunge(doctor)
        return doctor


def list_doctors(department_id: int | None = None) -> list[Doctor]:
    with session_scope() as session:
        stmt = select(Doctor).where(Doctor.is_active.is_(True))
        if department_id:
            stmt = stmt.where(Doctor.department_id == department_id)
        rows = session.execute(stmt.order_by(Doctor.full_name)).scalars().all()
        session.expunge_all()
        return rows


def get_doctor_by_user_id(user_id: int) -> Doctor | None:
    """Resolve a logged-in doctor's own Doctor profile, if their login was
    linked to one when the account was created (Settings -> Staff / users).
    Used so the Consultation screen can default a doctor straight to their
    own queue instead of asking them to pick themselves from a list.
    """
    with session_scope() as session:
        doctor = session.execute(select(Doctor).where(Doctor.user_id == user_id)).scalar_one_or_none()
        if doctor:
            session.expunge(doctor)
        return doctor


def _next_token(session, doctor_id: int, appointment_date: _dt.date) -> int:
    count = session.execute(
        select(func.count())
        .select_from(Appointment)
        .where(Appointment.doctor_id == doctor_id, Appointment.appointment_date == appointment_date)
    ).scalar_one()
    return count + 1


def book_appointment(
    patient_id: int,
    doctor_id: int,
    appointment_date: _dt.date,
    appointment_time: _dt.time | None = None,
    appointment_type: str = "walk_in",
    created_by_id: int | None = None,
) -> Appointment:
    with session_scope() as session:
        token = _next_token(session, doctor_id, appointment_date)
        appt = Appointment(
            token_number=token,
            patient_id=patient_id,
            doctor_id=doctor_id,
            appointment_date=appointment_date,
            appointment_time=appointment_time,
            appointment_type=appointment_type,
            status="booked",
            created_by_id=created_by_id,
        )
        session.add(appt)
        session.flush()
        session.refresh(appt)
        session.expunge(appt)
        return appt


def reschedule_appointment(appointment_id: int, new_date: _dt.date, new_time: _dt.time | None = None) -> None:
    with session_scope() as session:
        appt = session.get(Appointment, appointment_id)
        if appt is None:
            raise ValueError("Appointment not found.")
        appt.token_number = _next_token(session, appt.doctor_id, new_date)
        appt.appointment_date = new_date
        appt.appointment_time = new_time
        appt.status = "booked"


def cancel_appointment(appointment_id: int) -> None:
    with session_scope() as session:
        appt = session.get(Appointment, appointment_id)
        if appt is None:
            raise ValueError("Appointment not found.")
        appt.status = "cancelled"


def mark_no_show(appointment_id: int) -> None:
    with session_scope() as session:
        appt = session.get(Appointment, appointment_id)
        if appt is None:
            raise ValueError("Appointment not found.")
        appt.status = "no_show"


def doctor_queue_for_date(doctor_id: int, appointment_date: _dt.date) -> list[Appointment]:
    with session_scope() as session:
        rows = (
            session.execute(
                select(Appointment)
                .where(Appointment.doctor_id == doctor_id, Appointment.appointment_date == appointment_date)
                .order_by(Appointment.token_number)
            )
            .scalars()
            .all()
        )
        session.expunge_all()
        return rows


def start_visit(appointment: Appointment, created_by_id: int | None = None) -> Visit:
    """Check an appointment into an open OPD visit (registration -> queue -> consultation)."""
    with session_scope() as session:
        visit = Visit(
            patient_id=appointment.patient_id,
            doctor_id=appointment.doctor_id,
            appointment_id=appointment.id,
            visit_type="opd",
            status="open",
            created_by_id=created_by_id,
        )
        session.add(visit)
        appt = session.get(Appointment, appointment.id)
        if appt:
            appt.status = "in_consultation"
        session.flush()
        session.refresh(visit)
        session.expunge(visit)
        return visit
