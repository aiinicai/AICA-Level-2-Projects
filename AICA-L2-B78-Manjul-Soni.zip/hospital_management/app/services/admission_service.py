"""
Admission, bed transfer, and discharge workflow (spec section 6).

The bed is released only after the discharge workflow completes, and
discharge itself is refused while mandatory billing is still outstanding —
unless a supervisor explicitly overrides it (spec 24: "prevent discharge
with pending mandatory billing/clinical tasks, based on hospital policy").
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import func, select

from app.database.base import session_scope
from app.models.billing import Invoice
from app.models.ipd import Admission, Bed, BedTransfer


def _next_admission_number(session) -> str:
    year = _dt.datetime.now().strftime("%y")
    count = session.execute(
        select(func.count()).select_from(Admission).where(Admission.admission_number.like(f"ADM{year}%"))
    ).scalar_one()
    return f"ADM{year}{count + 1:06d}"


class BedNotAvailableError(Exception):
    pass


def admit_patient(
    patient_id: int,
    attending_doctor_id: int,
    bed_id: int,
    admission_source: str = "opd",
    provisional_diagnosis: str | None = None,
    deposit_amount: float = 0.0,
    consent_obtained: bool = False,
    created_by_id: int | None = None,
) -> Admission:
    with session_scope() as session:
        bed = session.get(Bed, bed_id)
        if bed is None:
            raise ValueError("Bed not found.")
        if bed.status != "available":
            raise BedNotAvailableError(f"Bed {bed.bed_number} is not available (status: {bed.status}).")

        admission = Admission(
            admission_number=_next_admission_number(session),
            patient_id=patient_id,
            admission_source=admission_source,
            attending_doctor_id=attending_doctor_id,
            provisional_diagnosis=provisional_diagnosis,
            bed_id=bed_id,
            deposit_amount=deposit_amount,
            consent_obtained=consent_obtained,
            created_by_id=created_by_id,
        )
        session.add(admission)
        bed.status = "occupied"

        session.flush()
        session.refresh(admission)
        session.expunge(admission)
        return admission


def transfer_bed(admission_id: int, new_bed_id: int, reason: str | None = None,
                  transferred_by_id: int | None = None) -> BedTransfer:
    with session_scope() as session:
        admission = session.get(Admission, admission_id)
        if admission is None:
            raise ValueError("Admission not found.")
        if admission.status != "admitted":
            raise ValueError("Cannot transfer a bed for a patient who is not currently admitted.")

        new_bed = session.get(Bed, new_bed_id)
        if new_bed is None:
            raise ValueError("Target bed not found.")
        if new_bed.status != "available":
            raise BedNotAvailableError(f"Bed {new_bed.bed_number} is not available (status: {new_bed.status}).")

        old_bed = session.get(Bed, admission.bed_id)
        transfer = BedTransfer(
            admission_id=admission_id, from_bed_id=admission.bed_id, to_bed_id=new_bed_id,
            reason=reason, transferred_by_id=transferred_by_id,
        )
        session.add(transfer)

        if old_bed is not None:
            old_bed.status = "cleaning"
        new_bed.status = "occupied"
        admission.bed_id = new_bed_id

        session.flush()
        session.refresh(transfer)
        session.expunge(transfer)
        return transfer


class DischargeBlockedError(Exception):
    def __init__(self, outstanding_due: float):
        self.outstanding_due = outstanding_due
        super().__init__(
            f"Cannot discharge: outstanding dues of {outstanding_due:.2f} on this admission's "
            "invoices. Settle the bill first, or discharge with an explicit override."
        )


def admission_days(admission: Admission, as_of: _dt.datetime | None = None) -> int:
    end = as_of or _dt.datetime.utcnow()
    delta = end - admission.admission_datetime
    return max(1, delta.days + (1 if delta.seconds > 0 else 0))


def discharge_patient(
    admission_id: int,
    discharge_summary: str,
    follow_up_advice: str | None = None,
    status: str = "discharged",
    override_pending_dues: bool = False,
) -> Admission:
    """Discharge: releases the bed only once complete. Refuses if the
    admission's invoices still have dues, unless explicitly overridden by an
    authorized user (spec 24 discharge/billing check).
    """
    if not discharge_summary:
        raise ValueError("A discharge summary is required.")

    with session_scope() as session:
        admission = session.get(Admission, admission_id)
        if admission is None:
            raise ValueError("Admission not found.")
        if admission.status != "admitted":
            raise ValueError("Patient is not currently admitted.")

        if not override_pending_dues:
            total_due = session.execute(
                select(func.coalesce(func.sum(Invoice.due_amount), 0.0)).where(
                    Invoice.patient_id == admission.patient_id, Invoice.status == "active",
                    Invoice.invoice_type.in_(("ipd_interim", "ipd_final")),
                )
            ).scalar_one()
            if total_due > 0:
                raise DischargeBlockedError(outstanding_due=total_due)

        admission.status = status
        admission.discharge_datetime = _dt.datetime.utcnow()
        admission.discharge_summary = discharge_summary
        admission.follow_up_advice = follow_up_advice

        bed = session.get(Bed, admission.bed_id)
        if bed is not None:
            bed.status = "cleaning"  # released for housekeeping, not immediately "available"

        session.flush()
        session.refresh(admission)
        session.expunge(admission)
        return admission


def list_active_admissions() -> list[Admission]:
    with session_scope() as session:
        rows = session.execute(select(Admission).where(Admission.status == "admitted")).scalars().all()
        session.expunge_all()
        return rows
