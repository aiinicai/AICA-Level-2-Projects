"""
Vendor master, purchase orders, and goods receipt (spec section 11).

Receiving goods against a PO creates a new medicine batch (so FEFO and
expiry tracking pick it up immediately) and a matching stock_transactions
entry — atomically, so a receipt can't update stock without leaving a
purchase-history record or vice versa.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.inventory import (
    Purchase,
    PurchaseOrder,
    PurchaseOrderItem,
    StockTransaction,
    Vendor,
)
from app.models.pharmacy import MedicineBatch


@dataclass
class VendorInput:
    name: str
    contact_person: str | None = None
    phone: str | None = None
    email: str | None = None
    address: str | None = None
    gstin: str | None = None


def add_vendor(data: VendorInput) -> Vendor:
    with session_scope() as session:
        vendor = Vendor(**data.__dict__)
        session.add(vendor)
        session.flush()
        session.refresh(vendor)
        session.expunge(vendor)
        return vendor


def list_vendors(active_only: bool = True) -> list[Vendor]:
    with session_scope() as session:
        stmt = select(Vendor)
        if active_only:
            stmt = stmt.where(Vendor.is_active.is_(True))
        rows = session.execute(stmt.order_by(Vendor.name)).scalars().all()
        session.expunge_all()
        return rows


@dataclass
class POLine:
    medicine_id: int
    quantity_ordered: int
    unit_price: float


def _next_po_number(session) -> str:
    from sqlalchemy import func

    year = _dt.datetime.now().strftime("%y")
    count = session.execute(
        select(func.count()).select_from(PurchaseOrder).where(PurchaseOrder.po_number.like(f"PO{year}%"))
    ).scalar_one()
    return f"PO{year}{count + 1:05d}"


def create_purchase_order(vendor_id: int, lines: list[POLine], created_by_id: int | None = None) -> PurchaseOrder:
    if not lines:
        raise ValueError("A purchase order needs at least one line item.")
    with session_scope() as session:
        po = PurchaseOrder(po_number=_next_po_number(session), vendor_id=vendor_id, created_by_id=created_by_id)
        session.add(po)
        session.flush()
        created_items = [
            PurchaseOrderItem(
                purchase_order_id=po.id,
                medicine_id=line.medicine_id,
                quantity_ordered=line.quantity_ordered,
                unit_price=line.unit_price,
            )
            for line in lines
        ]
        session.add_all(created_items)
        session.flush()
        # Force-load .items while the session is open (see lab_service.place_order
        # for the same pattern) so callers can read po.items after this returns.
        _ = po.items  # noqa: B018
        session.expunge(po)
        for item in created_items:
            session.expunge(item)
        return po


def list_purchase_orders(status: str | None = None) -> list[PurchaseOrder]:
    with session_scope() as session:
        stmt = select(PurchaseOrder)
        if status:
            stmt = stmt.where(PurchaseOrder.status == status)
        rows = session.execute(stmt.order_by(PurchaseOrder.created_at.desc())).scalars().all()
        session.expunge_all()
        return rows


@dataclass
class ReceiveLine:
    po_item_id: int
    medicine_id: int
    batch_number: str
    expiry_date: _dt.date
    quantity: int
    unit_price: float


def receive_goods(purchase_order_id: int, vendor_id: int, lines: list[ReceiveLine],
                   invoice_number: str | None = None, received_by_id: int | None = None) -> Purchase:
    """Goods receipt entry: creates batches + stock ledger rows, and marks the
    PO's line items received (fully or partially).
    """
    if not lines:
        raise ValueError("At least one line item is required to receive goods.")

    with session_scope() as session:
        purchase = Purchase(
            purchase_order_id=purchase_order_id, vendor_id=vendor_id,
            invoice_number=invoice_number, received_by_id=received_by_id,
        )
        session.add(purchase)
        session.flush()

        for line in lines:
            batch = MedicineBatch(
                medicine_id=line.medicine_id,
                batch_number=line.batch_number,
                expiry_date=line.expiry_date,
                quantity_in_stock=line.quantity,
                purchase_price=line.unit_price,
                vendor_id=vendor_id,
            )
            session.add(batch)
            session.flush()

            session.add(
                StockTransaction(
                    medicine_id=line.medicine_id,
                    batch_id=batch.id,
                    transaction_type="receipt",
                    quantity_change=line.quantity,
                    reference_type="purchase",
                    reference_id=purchase.id,
                    created_by_id=received_by_id,
                )
            )

            po_item = session.get(PurchaseOrderItem, line.po_item_id)
            if po_item is not None:
                po_item.quantity_received += line.quantity

        po = session.get(PurchaseOrder, purchase_order_id)
        if po is not None:
            all_received = all(item.quantity_received >= item.quantity_ordered for item in po.items)
            po.status = "closed" if all_received else "partially_received"

        session.flush()
        session.refresh(purchase)
        session.expunge(purchase)
        return purchase


def stock_movement_ledger(medicine_id: int | None = None, limit: int = 200) -> list[StockTransaction]:
    with session_scope() as session:
        stmt = select(StockTransaction).order_by(StockTransaction.created_at.desc()).limit(limit)
        if medicine_id:
            stmt = stmt.where(StockTransaction.medicine_id == medicine_id)
        rows = session.execute(stmt).scalars().all()
        session.expunge_all()
        return rows
