"""
Hospital/company master details (spec section 2: administrator configures
hospital details, receipt formats, etc.). Persisted in the same
application_settings key-value table as the UI theme, so it survives
restarts without a schema change.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.config import settings
from app.services.settings_service import get_setting, set_setting

_PREFIX = "hospital_"

_FIELDS = ("name", "tagline", "address", "phone", "email", "gstin", "registration_number")


@dataclass
class HospitalProfile:
    name: str
    tagline: str = ""
    address: str = ""
    phone: str = ""
    email: str = ""
    gstin: str = ""
    registration_number: str = ""


def get_hospital_profile() -> HospitalProfile:
    return HospitalProfile(
        name=get_setting(f"{_PREFIX}name", settings.HOSPITAL_NAME) or settings.HOSPITAL_NAME,
        tagline=get_setting(f"{_PREFIX}tagline", "") or "",
        address=get_setting(f"{_PREFIX}address", settings.HOSPITAL_ADDRESS) or settings.HOSPITAL_ADDRESS,
        phone=get_setting(f"{_PREFIX}phone", "") or "",
        email=get_setting(f"{_PREFIX}email", "") or "",
        gstin=get_setting(f"{_PREFIX}gstin", settings.HOSPITAL_GSTIN) or settings.HOSPITAL_GSTIN,
        registration_number=get_setting(f"{_PREFIX}registration_number", "") or "",
    )


def save_hospital_profile(profile: HospitalProfile) -> None:
    for field in _FIELDS:
        set_setting(f"{_PREFIX}{field}", getattr(profile, field) or "")
