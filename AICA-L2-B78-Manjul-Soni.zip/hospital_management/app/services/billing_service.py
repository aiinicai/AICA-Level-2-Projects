"""
Invoice generation and payment collection (spec section 10).

All billing/payment writes happen inside a single `session_scope()` so a
half-completed transaction can never be persisted (spec 24: atomic saves).
"""
from __future__ import annotations

from dataclasses import dataclass

from app.config import settings
from app.database.base import session_scope
from app.models.billing import Invoice, InvoiceItem, Payment
from app.services.audit_service import record_audit_event
from app.services.id_generator import generate_invoice_number


@dataclass
class InvoiceLine:
    description: str
    quantity: float
    unit_price: float
    tax_percent: float = 0.0
    service_id: int | None = None


def create_invoice(
    patient_id: int,
    invoice_type: str,
    lines: list[InvoiceLine],
    visit_id: int | None = None,
    discount_amount: float = 0.0,
    discount_reason: str | None = None,
    discount_approved_by_id: int | None = None,
    created_by_id: int | None = None,
) -> Invoice:
    if not lines:
        raise ValueError("An invoice needs at least one line item.")
    if discount_amount and not discount_reason:
        raise ValueError("A discount requires a reason and approval (spec 10 financial controls).")

    with session_scope() as session:
        subtotal = 0.0
        tax_amount = 0.0
        invoice = Invoice(
            invoice_number=generate_invoice_number(session),
            invoice_type=invoice_type,
            patient_id=patient_id,
            visit_id=visit_id,
            discount_amount=discount_amount,
            discount_reason=discount_reason,
            discount_approved_by_id=discount_approved_by_id,
            created_by_id=created_by_id,
        )
        session.add(invoice)
        session.flush()

        for line in lines:
            line_subtotal = line.quantity * line.unit_price
            line_tax = line_subtotal * (line.tax_percent / 100.0)
            subtotal += line_subtotal
            tax_amount += line_tax
            session.add(
                InvoiceItem(
                    invoice_id=invoice.id,
                    service_id=line.service_id,
                    description=line.description,
                    quantity=line.quantity,
                    unit_price=line.unit_price,
                    tax_percent=line.tax_percent,
                    line_total=round(line_subtotal + line_tax, 2),
                )
            )

        invoice.subtotal = round(subtotal, 2)
        invoice.tax_amount = round(tax_amount, 2)
        invoice.total_amount = round(subtotal + tax_amount - discount_amount, 2)
        invoice.due_amount = invoice.total_amount

        session.flush()
        session.refresh(invoice)
        session.expunge(invoice)

        if discount_amount:
            record_audit_event(
                action="discount_applied", user_id=discount_approved_by_id,
                entity_type="invoice", entity_id=invoice.id,
                details=f"amount={discount_amount}, reason={discount_reason}",
            )
        return invoice


def record_payment(invoice_id: int, amount: float, payment_method: str,
                    reference_number: str | None = None, received_by_id: int | None = None) -> Payment:
    if amount <= 0:
        raise ValueError("Payment amount must be positive.")

    with session_scope() as session:
        invoice = session.get(Invoice, invoice_id)
        if invoice is None:
            raise ValueError("Invoice not found.")
        if invoice.status != "active":
            raise ValueError("Cannot collect payment against a cancelled/voided invoice.")

        payment = Payment(
            invoice_id=invoice_id,
            amount=amount,
            payment_method=payment_method,
            reference_number=reference_number,
            received_by_id=received_by_id,
        )
        session.add(payment)

        invoice.paid_amount = round(invoice.paid_amount + amount, 2)
        invoice.due_amount = round(invoice.total_amount - invoice.paid_amount, 2)

        session.flush()
        session.refresh(payment)
        session.expunge(payment)
        return payment


def void_invoice(invoice_id: int, reason: str, voided_by_id: int | None = None) -> None:
    if not reason:
        raise ValueError("A void reason is required — invoices are never hard-deleted (spec 17).")
    with session_scope() as session:
        invoice = session.get(Invoice, invoice_id)
        if invoice is None:
            raise ValueError("Invoice not found.")
        invoice.status = "voided"
        invoice.void_reason = reason

    record_audit_event(
        action="invoice_voided", user_id=voided_by_id, entity_type="invoice", entity_id=invoice_id,
        details=f"reason={reason}",
    )
