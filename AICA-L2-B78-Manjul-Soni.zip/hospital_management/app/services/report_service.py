"""
Daily operational + financial report (spec section 14, Phase 1 scope).

Every report accepts a date and returns a plain dict so it can be shown in
the UI, exported to CSV, or handed to a PDF renderer without duplicating
the underlying query logic.
"""
from __future__ import annotations

import csv
import datetime as _dt

from sqlalchemy import func, select

from app.database.base import session_scope
from app.models.billing import Invoice, Payment
from app.models.clinical import Appointment, Visit
from app.models.patient import Patient


def daily_summary(report_date: _dt.date) -> dict:
    start = _dt.datetime.combine(report_date, _dt.time.min)
    end = _dt.datetime.combine(report_date, _dt.time.max)

    with session_scope() as session:
        new_registrations = session.execute(
            select(func.count()).select_from(Patient).where(
                Patient.created_at.between(start, end)
            )
        ).scalar_one()

        opd_visits = session.execute(
            select(func.count()).select_from(Visit).where(Visit.visit_date.between(start, end))
        ).scalar_one()

        appointments_booked = session.execute(
            select(func.count()).select_from(Appointment).where(Appointment.appointment_date == report_date)
        ).scalar_one()

        no_shows = session.execute(
            select(func.count()).select_from(Appointment).where(
                Appointment.appointment_date == report_date, Appointment.status == "no_show"
            )
        ).scalar_one()

        invoices_generated = session.execute(
            select(func.count()).select_from(Invoice).where(Invoice.created_at.between(start, end))
        ).scalar_one()

        total_collection = session.execute(
            select(func.coalesce(func.sum(Payment.amount), 0.0)).where(
                Payment.received_at.between(start, end), Payment.is_refund.is_(False)
            )
        ).scalar_one()

        outstanding_dues = session.execute(
            select(func.coalesce(func.sum(Invoice.due_amount), 0.0)).where(Invoice.status == "active")
        ).scalar_one()

        return {
            "report_date": report_date.isoformat(),
            "new_registrations": new_registrations,
            "opd_visits": opd_visits,
            "appointments_booked": appointments_booked,
            "no_shows": no_shows,
            "invoices_generated": invoices_generated,
            "total_collection": round(total_collection, 2),
            "outstanding_dues_all_time": round(outstanding_dues, 2),
        }


def export_daily_summary_csv(report_date: _dt.date, file_path: str) -> None:
    summary = daily_summary(report_date)
    with open(file_path, "w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["Metric", "Value"])
        for key, value in summary.items():
            writer.writerow([key, value])
