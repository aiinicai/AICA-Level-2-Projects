"""
Patient self-service portal (spec Phase 4).

This is an offline desktop app with no internet-facing server, so a real
web/mobile patient portal is out of scope — instead this gives patients a
read-only, self-service view of their own records from the same computer,
gated by their UHID + registered mobile number (not a staff username/
password, and not the main RBAC login). It shows upcoming appointments,
prescriptions, invoices/dues, and verified lab reports: precisely the
"patient portal" self-service data a real online portal would expose,
minus needing a live internet connection or a hosting account.
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import select

from app.database.base import session_scope
from app.models.billing import Invoice
from app.models.clinical import Appointment, ClinicalNote, Doctor, Prescription, PrescriptionItem, Visit
from app.models.laboratory import LabOrder, LabOrderItem, LabResult, LabTest
from app.models.patient import Patient


def authenticate_patient(uhid: str, mobile_number: str) -> Patient | None:
    with session_scope() as session:
        patient = session.execute(
            select(Patient).where(
                Patient.uhid == uhid.strip(), Patient.mobile_number == mobile_number.strip()
            )
        ).scalar_one_or_none()
        if patient:
            session.expunge(patient)
        return patient


def get_portal_data(patient_id: int) -> dict:
    with session_scope() as session:
        today = _dt.date.today()

        appointments = session.execute(
            select(Appointment).where(
                Appointment.patient_id == patient_id, Appointment.appointment_date >= today
            ).order_by(Appointment.appointment_date)
        ).scalars().all()
        appointment_rows = []
        for appt in appointments:
            doctor = session.get(Doctor, appt.doctor_id)
            appointment_rows.append({
                "date": appt.appointment_date, "time": appt.appointment_time,
                "doctor": doctor.full_name if doctor else "—", "status": appt.status,
                "type": appt.appointment_type,
            })

        visit_ids = [row[0] for row in session.execute(
            select(Visit.id).where(Visit.patient_id == patient_id)
        ).all()]

        prescription_rows = []
        if visit_ids:
            prescriptions = session.execute(
                select(Prescription).where(
                    Prescription.visit_id.in_(visit_ids), Prescription.is_finalized.is_(True)
                ).order_by(Prescription.created_at.desc())
            ).scalars().all()
            for prescription in prescriptions:
                items = session.execute(
                    select(PrescriptionItem).where(PrescriptionItem.prescription_id == prescription.id)
                ).scalars().all()
                prescription_rows.append({
                    "date": prescription.created_at,
                    "items": [
                        f"{item.medicine_name} — {item.dosage or ''} {item.frequency or ''} "
                        f"({item.duration_days or '?'} day(s))".strip()
                        for item in items
                    ],
                })

        invoices = session.execute(
            select(Invoice).where(Invoice.patient_id == patient_id).order_by(Invoice.created_at.desc())
        ).scalars().all()
        invoice_rows = [
            {
                "invoice_number": invoice.invoice_number, "type": invoice.invoice_type,
                "total": invoice.total_amount, "paid": invoice.paid_amount, "due": invoice.due_amount,
                "status": invoice.status, "date": invoice.created_at,
            }
            for invoice in invoices
        ]

        lab_orders = session.execute(
            select(LabOrder).where(LabOrder.patient_id == patient_id)
        ).scalars().all()
        lab_rows = []
        for order in lab_orders:
            for item in order.items:
                if item.status != "verified" and item.status != "reported":
                    continue
                test = session.get(LabTest, item.test_id)
                result = session.execute(
                    select(LabResult).where(LabResult.order_item_id == item.id)
                ).scalar_one_or_none()
                if result and result.result_value is not None:
                    lab_rows.append({
                        "test": test.name if test else "—", "value": result.result_value,
                        "is_abnormal": result.is_abnormal, "date": result.verified_at or result.entered_at,
                    })

        return {
            "appointments": appointment_rows,
            "prescriptions": prescription_rows,
            "invoices": invoice_rows,
            "lab_results": lab_rows,
        }
