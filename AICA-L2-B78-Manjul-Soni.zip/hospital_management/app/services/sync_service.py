"""
Cloud sync (spec Phase 4).

This offline desktop app has no cloud account of its own to push to. The
practical way an offline-first app gets "cloud sync" without a hosted
backend is to write its backups into a folder that a cloud client already
syncs — Dropbox, Google Drive, OneDrive — so that client uploads it. This
module lets the administrator point at such a folder (Settings ->
Backup & cloud sync) and copies every new backup zip there right after it
is created; the actual upload-to-cloud step is then handled by whichever
sync client is watching that folder, same as it would for any other file
the user drops in.
"""
from __future__ import annotations

import shutil
from pathlib import Path

from app.services.settings_service import get_setting, set_setting

_SYNC_FOLDER_KEY = "cloud_sync_folder"
_SYNC_ENABLED_KEY = "cloud_sync_enabled"


def get_sync_folder() -> str:
    return get_setting(_SYNC_FOLDER_KEY, "") or ""


def is_sync_enabled() -> bool:
    return (get_setting(_SYNC_ENABLED_KEY, "false") or "false") == "true"


def configure_sync(folder_path: str, enabled: bool) -> None:
    set_setting(_SYNC_FOLDER_KEY, folder_path)
    set_setting(_SYNC_ENABLED_KEY, "true" if enabled else "false")


def sync_backup_if_enabled(backup_path: Path) -> str | None:
    """Copy a just-created backup into the configured cloud-sync folder.

    Returns the destination path if a copy was made, else None (sync
    disabled, no folder configured, or the folder doesn't exist).
    """
    if not is_sync_enabled():
        return None
    folder = get_sync_folder()
    if not folder:
        return None
    destination_dir = Path(folder)
    if not destination_dir.exists():
        return None
    destination = destination_dir / backup_path.name
    shutil.copy2(backup_path, destination)
    return str(destination)
