"""
Insurer/corporate/TPA master and claim tracking against a credit invoice
(spec section 10: "credit/corporate/insurance bill, if applicable").
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.billing import Invoice
from app.models.insurance import InsuranceClaim, Insurer


@dataclass
class InsurerInput:
    name: str
    insurer_type: str = "insurance"
    contact_person: str | None = None
    phone: str | None = None
    credit_limit: float = 0.0


def add_insurer(data: InsurerInput) -> Insurer:
    with session_scope() as session:
        insurer = Insurer(**data.__dict__)
        session.add(insurer)
        session.flush()
        session.refresh(insurer)
        session.expunge(insurer)
        return insurer


def list_insurers(active_only: bool = True) -> list[Insurer]:
    with session_scope() as session:
        stmt = select(Insurer)
        if active_only:
            stmt = stmt.where(Insurer.is_active.is_(True))
        rows = session.execute(stmt.order_by(Insurer.name)).scalars().all()
        session.expunge_all()
        return rows


def file_claim(invoice_id: int, insurer_id: int, claim_amount: float,
               policy_or_employee_id: str | None = None,
               pre_authorization_number: str | None = None) -> InsuranceClaim:
    if claim_amount <= 0:
        raise ValueError("Claim amount must be positive.")
    with session_scope() as session:
        claim = InsuranceClaim(
            invoice_id=invoice_id, insurer_id=insurer_id, claim_amount=claim_amount,
            policy_or_employee_id=policy_or_employee_id, pre_authorization_number=pre_authorization_number,
        )
        session.add(claim)
        session.flush()
        session.refresh(claim)
        session.expunge(claim)
        return claim


def update_claim_status(claim_id: int, status: str, approved_amount: float | None = None,
                          notes: str | None = None, received_by_id: int | None = None) -> None:
    """Update a claim's status. Moving a claim to "settled" also records the
    insurer's payment against the linked invoice — before this, settling a
    claim only updated the claim row and the invoice's due_amount stayed at
    its full original value forever, even though the insurer had paid.

    The settlement is applied exactly once (guarded by the claim's previous
    status) and capped to whatever the invoice still shows as due, so
    re-settling an already-settled claim, or a claim amount that's larger
    than the outstanding due (e.g. the patient already paid part of it),
    can't push the invoice into a negative balance.
    """
    valid = {"submitted", "approved", "partially_approved", "rejected", "settled"}
    if status not in valid:
        raise ValueError(f"Invalid claim status '{status}'. Must be one of {valid}.")

    settlement_amount = None
    invoice_id = None

    with session_scope() as session:
        claim = session.get(InsuranceClaim, claim_id)
        if claim is None:
            raise ValueError("Claim not found.")
        already_settled = claim.status == "settled"
        claim.status = status
        if approved_amount is not None:
            claim.approved_amount = approved_amount
        if notes:
            claim.notes = notes
        if status == "settled":
            claim.settled_at = _dt.datetime.utcnow()
            if not already_settled:
                amount = claim.approved_amount if claim.approved_amount > 0 else claim.claim_amount
                invoice = session.get(Invoice, claim.invoice_id)
                if invoice is not None and invoice.status == "active" and invoice.due_amount > 0:
                    settlement_amount = round(min(amount, invoice.due_amount), 2)
                    invoice_id = claim.invoice_id

    if settlement_amount and invoice_id:
        from app.services.billing_service import record_payment

        record_payment(
            invoice_id, settlement_amount, payment_method="insurance",
            reference_number=f"Insurance claim #{claim_id} settlement", received_by_id=received_by_id,
        )


def list_claims(status: str | None = None) -> list[InsuranceClaim]:
    with session_scope() as session:
        stmt = select(InsuranceClaim)
        if status:
            stmt = stmt.where(InsuranceClaim.status == status)
        rows = session.execute(stmt.order_by(InsuranceClaim.submitted_at.desc())).scalars().all()
        session.expunge_all()
        return rows
