"""
Laboratory workflow: catalog -> order -> sample collection -> received ->
result entry -> verification -> report (spec section 8).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.laboratory import LabOrder, LabOrderItem, LabResult, LabTest


@dataclass
class LabTestInput:
    name: str
    department: str | None = None
    specimen_type: str | None = None
    normal_range: str | None = None
    unit: str | None = None
    result_type: str = "numeric"
    price: float = 0.0
    turnaround_hours: int | None = None


def add_test(data: LabTestInput) -> LabTest:
    with session_scope() as session:
        test = LabTest(**data.__dict__)
        session.add(test)
        session.flush()
        session.refresh(test)
        session.expunge(test)
        return test


def list_tests(active_only: bool = True) -> list[LabTest]:
    with session_scope() as session:
        stmt = select(LabTest)
        if active_only:
            stmt = stmt.where(LabTest.is_active.is_(True))
        rows = session.execute(stmt.order_by(LabTest.name)).scalars().all()
        session.expunge_all()
        return rows


def place_order(patient_id: int, test_ids: list[int], visit_id: int | None = None,
                 ordered_by_id: int | None = None) -> LabOrder:
    if not test_ids:
        raise ValueError("Select at least one test to order.")
    with session_scope() as session:
        order = LabOrder(
            patient_id=patient_id, visit_id=visit_id, ordered_by_id=ordered_by_id,
            sample_barcode=f"SPC{_dt.datetime.now().strftime('%y%m%d%H%M%S')}",
        )
        session.add(order)
        session.flush()
        created_items = [LabOrderItem(order_id=order.id, test_id=test_id, status="ordered") for test_id in test_ids]
        session.add_all(created_items)
        session.flush()
        # Force-load .items while the session is open so the caller can read
        # it after this function returns a detached instance.
        _ = order.items  # noqa: B018
        session.expunge(order)
        for item in created_items:
            session.expunge(item)
        return order


def collect_sample(order_item_id: int) -> None:
    with session_scope() as session:
        item = session.get(LabOrderItem, order_item_id)
        if item is None:
            raise ValueError("Lab order item not found.")
        item.status = "sample_collected"
        item.collected_at = _dt.datetime.utcnow()


def receive_sample(order_item_id: int) -> None:
    with session_scope() as session:
        item = session.get(LabOrderItem, order_item_id)
        if item is None:
            raise ValueError("Lab order item not found.")
        item.status = "received"
        item.received_at = _dt.datetime.utcnow()


def enter_result(order_item_id: int, result_value: str, is_abnormal: bool = False,
                  entered_by_id: int | None = None) -> LabResult:
    with session_scope() as session:
        item = session.get(LabOrderItem, order_item_id)
        if item is None:
            raise ValueError("Lab order item not found.")
        result = LabResult(
            order_item_id=order_item_id, result_value=result_value, is_abnormal=is_abnormal,
            entered_by_id=entered_by_id, entered_at=_dt.datetime.utcnow(),
        )
        session.add(result)
        item.status = "resulted"
        session.flush()
        session.refresh(result)
        session.expunge(result)
        return result


def verify_result(order_item_id: int, verified_by_id: int | None = None) -> None:
    with session_scope() as session:
        item = session.get(LabOrderItem, order_item_id)
        if item is None:
            raise ValueError("Lab order item not found.")
        result = session.execute(
            select(LabResult).where(LabResult.order_item_id == order_item_id)
        ).scalar_one_or_none()
        if result is None:
            raise ValueError("Enter a result before verifying it.")
        result.verified_by_id = verified_by_id
        result.verified_at = _dt.datetime.utcnow()
        item.status = "verified"


def pending_report_items() -> list[dict]:
    """Order items not yet verified — the pending-report dashboard (spec 8)."""
    with session_scope() as session:
        rows = (
            session.execute(
                select(LabOrderItem).where(LabOrderItem.status != "verified")
            )
            .scalars()
            .all()
        )
        results = []
        for item in rows:
            test = session.get(LabTest, item.test_id)
            order = session.get(LabOrder, item.order_id)
            results.append({
                "order_item_id": item.id,
                "test_name": test.name if test else "?",
                "status": item.status,
                "patient_id": order.patient_id if order else None,
                "sample_barcode": order.sample_barcode if order else None,
            })
        return results
