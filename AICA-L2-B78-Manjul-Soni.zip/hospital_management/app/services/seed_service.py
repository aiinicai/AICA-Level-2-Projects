"""
Optional demo data: one department and one doctor, so a fresh install has
something to book appointments against. Real deployments would replace this
with the administrator's department/doctor setup screen (spec 4).
"""
from __future__ import annotations

from sqlalchemy import select

from app.database.base import session_scope
from app.models.clinical import Department, Doctor


def ensure_demo_department_and_doctor() -> None:
    with session_scope() as session:
        dept = session.execute(select(Department).where(Department.name == "General Medicine")).scalar_one_or_none()
        if dept is None:
            dept = Department(name="General Medicine")
            session.add(dept)
            session.flush()

        any_doctor = session.execute(select(Doctor)).first()
        if any_doctor is None:
            session.add(
                Doctor(
                    full_name="Dr. Demo Physician",
                    department_id=dept.id,
                    specialization="General Medicine",
                    consultation_fee=300.0,
                )
            )
