"""
Staff attendance (spec Phase 4: biometric attendance).

No biometric hardware is available in this build, so attendance is
recorded through a Clock in / Clock out button (method="manual"). The
functions below are the integration point a fingerprint/face-recognition
device's SDK would call instead — it would just call `clock_in(user_id,
method="biometric", device_reference=...)` on a successful scan, so no
other code needs to change when real hardware is added later.
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import select

from app.database.base import session_scope
from app.models.attendance import AttendanceLog


class AlreadyClockedInError(Exception):
    pass


class NotClockedInError(Exception):
    pass


def clock_in(user_id: int, method: str = "manual", device_reference: str | None = None) -> AttendanceLog:
    with session_scope() as session:
        open_entry = session.execute(
            select(AttendanceLog).where(
                AttendanceLog.user_id == user_id, AttendanceLog.clock_out_at.is_(None)
            )
        ).scalar_one_or_none()
        if open_entry is not None:
            raise AlreadyClockedInError("Already clocked in — clock out first.")

        entry = AttendanceLog(user_id=user_id, method=method, device_reference=device_reference)
        session.add(entry)
        session.flush()
        session.refresh(entry)
        session.expunge(entry)
        return entry


def clock_out(user_id: int, notes: str | None = None) -> AttendanceLog:
    with session_scope() as session:
        open_entry = session.execute(
            select(AttendanceLog).where(
                AttendanceLog.user_id == user_id, AttendanceLog.clock_out_at.is_(None)
            )
        ).scalar_one_or_none()
        if open_entry is None:
            raise NotClockedInError("Not currently clocked in.")
        open_entry.clock_out_at = _dt.datetime.utcnow()
        if notes:
            open_entry.notes = notes
        session.flush()
        session.refresh(open_entry)
        session.expunge(open_entry)
        return open_entry


def current_status(user_id: int) -> AttendanceLog | None:
    """Return the open (not-yet-clocked-out) entry for a user, if any."""
    with session_scope() as session:
        entry = session.execute(
            select(AttendanceLog).where(
                AttendanceLog.user_id == user_id, AttendanceLog.clock_out_at.is_(None)
            )
        ).scalar_one_or_none()
        if entry:
            session.expunge(entry)
        return entry


def list_attendance(user_id: int | None = None, start: _dt.date | None = None,
                     end: _dt.date | None = None, limit: int = 200) -> list[AttendanceLog]:
    with session_scope() as session:
        stmt = select(AttendanceLog).order_by(AttendanceLog.clock_in_at.desc()).limit(limit)
        if user_id is not None:
            stmt = stmt.where(AttendanceLog.user_id == user_id)
        if start:
            stmt = stmt.where(AttendanceLog.clock_in_at >= _dt.datetime.combine(start, _dt.time.min))
        if end:
            stmt = stmt.where(AttendanceLog.clock_in_at <= _dt.datetime.combine(end, _dt.time.max))
        rows = session.execute(stmt).scalars().all()
        session.expunge_all()
        return rows
