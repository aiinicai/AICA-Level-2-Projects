"""
Medicine master + batch-wise stock, FEFO issue, and expiry/low-stock alerts
(spec section 9).
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.inventory import StockTransaction
from app.models.pharmacy import Medicine, MedicineBatch
from app.services.audit_service import record_audit_event


@dataclass
class MedicineInput:
    generic_name: str
    brand_name: str | None = None
    composition: str | None = None
    manufacturer: str | None = None
    dosage_form: str | None = None
    strength: str | None = None
    tax_percent: float = 0.0
    mrp: float = 0.0
    sale_price: float = 0.0
    reorder_level: int = 10
    storage_location: str | None = None
    is_controlled_drug: bool = False


def add_medicine(data: MedicineInput) -> Medicine:
    with session_scope() as session:
        medicine = Medicine(**data.__dict__)
        session.add(medicine)
        session.flush()
        session.refresh(medicine)
        session.expunge(medicine)
        return medicine


def list_medicines(active_only: bool = True) -> list[Medicine]:
    with session_scope() as session:
        stmt = select(Medicine)
        if active_only:
            stmt = stmt.where(Medicine.is_active.is_(True))
        rows = session.execute(stmt.order_by(Medicine.generic_name)).scalars().all()
        session.expunge_all()
        return rows


def add_batch(medicine_id: int, batch_number: str, expiry_date: _dt.date, quantity: int,
              purchase_price: float = 0.0, vendor_id: int | None = None,
              record_stock_transaction: bool = True, created_by_id: int | None = None) -> MedicineBatch:
    with session_scope() as session:
        batch = MedicineBatch(
            medicine_id=medicine_id,
            batch_number=batch_number,
            expiry_date=expiry_date,
            quantity_in_stock=quantity,
            purchase_price=purchase_price,
            vendor_id=vendor_id,
        )
        session.add(batch)
        session.flush()
        if record_stock_transaction:
            session.add(
                StockTransaction(
                    medicine_id=medicine_id,
                    batch_id=batch.id,
                    transaction_type="receipt",
                    quantity_change=quantity,
                    reference_type="manual_batch_entry",
                    created_by_id=created_by_id,
                )
            )
        session.refresh(batch)
        session.expunge(batch)
        return batch


def stock_for_medicine(medicine_id: int) -> list[MedicineBatch]:
    """Batches with stock, ordered nearest-expiry-first (the order FEFO issues in)."""
    with session_scope() as session:
        rows = (
            session.execute(
                select(MedicineBatch)
                .where(MedicineBatch.medicine_id == medicine_id, MedicineBatch.quantity_in_stock > 0)
                .order_by(MedicineBatch.expiry_date)
            )
            .scalars()
            .all()
        )
        session.expunge_all()
        return rows


def total_stock(medicine_id: int) -> int:
    return sum(b.quantity_in_stock for b in stock_for_medicine(medicine_id))


def low_stock_medicines() -> list[dict]:
    """Medicines whose total stock across batches is at/under their reorder level."""
    results = []
    for medicine in list_medicines():
        qty = total_stock(medicine.id)
        if qty <= medicine.reorder_level:
            results.append({"medicine": medicine, "current_stock": qty, "reorder_level": medicine.reorder_level})
    return results


def expiring_batches(within_days: int = 90) -> list[dict]:
    """Batches expiring within `within_days`, nearest first (near-expiry alert, spec 9)."""
    cutoff = _dt.date.today() + _dt.timedelta(days=within_days)
    with session_scope() as session:
        rows = (
            session.execute(
                select(MedicineBatch)
                .where(MedicineBatch.quantity_in_stock > 0, MedicineBatch.expiry_date <= cutoff)
                .order_by(MedicineBatch.expiry_date)
            )
            .scalars()
            .all()
        )
        results = []
        for batch in rows:
            medicine = session.get(Medicine, batch.medicine_id)
            results.append({
                "medicine_name": medicine.generic_name if medicine else "?",
                "batch_number": batch.batch_number,
                "expiry_date": batch.expiry_date.isoformat(),
                "quantity": batch.quantity_in_stock,
                "days_to_expiry": (batch.expiry_date - _dt.date.today()).days,
            })
        return results


class InsufficientStockError(Exception):
    pass


def adjust_batch_stock(batch_id: int, quantity_delta: int, reason: str,
                        transaction_type: str = "adjustment", adjusted_by_id: int | None = None) -> None:
    """Manual stock correction (damage, expired write-off, physical count fix).

    Requires a reason and is always logged to both the stock ledger and the
    audit trail — spec 9 (adjustment needs a reason) and spec 20 (stock
    adjustment must be auditable).
    """
    if not reason:
        raise ValueError("A reason is required for any manual stock adjustment.")
    if quantity_delta == 0:
        raise ValueError("Adjustment quantity must be non-zero.")

    with session_scope() as session:
        batch = session.get(MedicineBatch, batch_id)
        if batch is None:
            raise ValueError("Batch not found.")
        new_quantity = batch.quantity_in_stock + quantity_delta
        if new_quantity < 0:
            raise ValueError("Adjustment would take stock negative; not allowed without authorization override.")
        batch.quantity_in_stock = new_quantity
        session.add(
            StockTransaction(
                medicine_id=batch.medicine_id,
                batch_id=batch.id,
                transaction_type=transaction_type,
                quantity_change=quantity_delta,
                reason=reason,
                created_by_id=adjusted_by_id,
            )
        )

    record_audit_event(
        action="stock_adjustment", user_id=adjusted_by_id, entity_type="medicine_batch", entity_id=batch_id,
        details=f"delta={quantity_delta}, reason={reason}",
    )


def fefo_deduct(session, medicine_id: int, quantity: int, reference_type: str,
                 reference_id: int | None = None, created_by_id: int | None = None) -> list[tuple[int, int]]:
    """Deduct `quantity` units using First-Expiry-First-Out across batches.

    Must be called with a session already inside a transaction (billing and
    stock movement have to succeed or fail together, spec 24). Returns a
    list of (batch_id, quantity_taken) for traceability.
    """
    remaining = quantity
    taken: list[tuple[int, int]] = []

    # SQLite has no row-level locking; the single-writer session_scope()
    # transaction around this call is what keeps the deduction atomic on
    # the single-computer deployment this MVP targets.
    batches = (
        session.execute(
            select(MedicineBatch)
            .where(MedicineBatch.medicine_id == medicine_id, MedicineBatch.quantity_in_stock > 0)
            .order_by(MedicineBatch.expiry_date)
        )
        .scalars()
        .all()
    )

    for batch in batches:
        if remaining <= 0:
            break
        take = min(batch.quantity_in_stock, remaining)
        batch.quantity_in_stock -= take
        remaining -= take
        taken.append((batch.id, take))
        session.add(
            StockTransaction(
                medicine_id=medicine_id,
                batch_id=batch.id,
                transaction_type="dispense",
                quantity_change=-take,
                reference_type=reference_type,
                reference_id=reference_id,
                created_by_id=created_by_id,
            )
        )

    if remaining > 0:
        raise InsufficientStockError(
            f"Not enough stock for medicine #{medicine_id}: short by {remaining} unit(s)."
        )
    return taken
