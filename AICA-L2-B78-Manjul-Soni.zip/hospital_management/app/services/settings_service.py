"""Read/write access to the application_settings key-value table."""
from __future__ import annotations

from sqlalchemy import select

from app.database.base import session_scope
from app.models.appsettings import ApplicationSetting


def get_setting(key: str, default: str | None = None) -> str | None:
    with session_scope() as session:
        row = session.execute(
            select(ApplicationSetting).where(ApplicationSetting.key == key)
        ).scalar_one_or_none()
        return row.value if row else default


def set_setting(key: str, value: str) -> None:
    with session_scope() as session:
        row = session.execute(
            select(ApplicationSetting).where(ApplicationSetting.key == key)
        ).scalar_one_or_none()
        if row:
            row.value = value
        else:
            session.add(ApplicationSetting(key=key, value=value))
