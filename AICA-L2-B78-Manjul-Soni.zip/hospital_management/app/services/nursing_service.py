"""
Inpatient charting: nursing notes/doctor rounds, medication administration
record (MAR), and diet orders (spec section 6).
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import select

from app.database.base import session_scope
from app.models.ipd import DietOrder, MedicationAdministration, NursingNote


def add_nursing_note(admission_id: int, note_text: str, note_type: str = "nursing",
                      recorded_by_id: int | None = None) -> NursingNote:
    with session_scope() as session:
        note = NursingNote(
            admission_id=admission_id, note_type=note_type, note_text=note_text, recorded_by_id=recorded_by_id,
        )
        session.add(note)
        session.flush()
        session.refresh(note)
        session.expunge(note)
        return note


def list_nursing_notes(admission_id: int) -> list[NursingNote]:
    with session_scope() as session:
        rows = session.execute(
            select(NursingNote).where(NursingNote.admission_id == admission_id)
            .order_by(NursingNote.recorded_at.desc())
        ).scalars().all()
        session.expunge_all()
        return rows


def record_medication_administration(admission_id: int, medicine_name: str, dose: str | None = None,
                                        route: str | None = None, administered_by_id: int | None = None,
                                        notes: str | None = None) -> MedicationAdministration:
    with session_scope() as session:
        mar = MedicationAdministration(
            admission_id=admission_id, medicine_name=medicine_name, dose=dose, route=route,
            administered_by_id=administered_by_id, notes=notes,
        )
        session.add(mar)
        session.flush()
        session.refresh(mar)
        session.expunge(mar)
        return mar


def list_medication_administrations(admission_id: int) -> list[MedicationAdministration]:
    with session_scope() as session:
        rows = session.execute(
            select(MedicationAdministration).where(MedicationAdministration.admission_id == admission_id)
            .order_by(MedicationAdministration.administered_at.desc())
        ).scalars().all()
        session.expunge_all()
        return rows


def set_diet_order(admission_id: int, diet_type: str, instructions: str | None = None,
                     ordered_by_id: int | None = None) -> DietOrder:
    """New diet order supersedes any previous active one for this admission."""
    with session_scope() as session:
        existing = session.execute(
            select(DietOrder).where(DietOrder.admission_id == admission_id, DietOrder.is_active.is_(True))
        ).scalars().all()
        for order in existing:
            order.is_active = False

        diet = DietOrder(
            admission_id=admission_id, diet_type=diet_type, instructions=instructions, ordered_by_id=ordered_by_id,
        )
        session.add(diet)
        session.flush()
        session.refresh(diet)
        session.expunge(diet)
        return diet


def current_diet_order(admission_id: int) -> DietOrder | None:
    with session_scope() as session:
        order = session.execute(
            select(DietOrder).where(DietOrder.admission_id == admission_id, DietOrder.is_active.is_(True))
        ).scalar_one_or_none()
        if order:
            session.expunge(order)
        return order
