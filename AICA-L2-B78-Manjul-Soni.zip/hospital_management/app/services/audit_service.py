"""
Read-side access to the audit trail (spec section 20): login/logout,
record changes, bill cancellation, discount/refund, stock adjustment,
backup/restore actions. Writing happens at the point of action (see
app.security.auth for login/logout; other modules can call
`record_audit_event` directly for anything not already logged elsewhere).
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import select

from app.database.base import session_scope
from app.models.user import AuditLog, User


def record_audit_event(action: str, user_id: int | None = None, entity_type: str | None = None,
                         entity_id: int | None = None, details: str | None = None) -> None:
    with session_scope() as session:
        session.add(AuditLog(
            user_id=user_id, action=action, entity_type=entity_type, entity_id=entity_id, details=details,
        ))


def search_audit_log(start_date: _dt.date | None = None, end_date: _dt.date | None = None,
                      action_contains: str | None = None, username: str | None = None,
                      limit: int = 500) -> list[dict]:
    with session_scope() as session:
        stmt = select(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit)
        if start_date:
            stmt = stmt.where(AuditLog.created_at >= _dt.datetime.combine(start_date, _dt.time.min))
        if end_date:
            stmt = stmt.where(AuditLog.created_at <= _dt.datetime.combine(end_date, _dt.time.max))
        if action_contains:
            stmt = stmt.where(AuditLog.action.ilike(f"%{action_contains}%"))

        rows = session.execute(stmt).scalars().all()
        results = []
        for row in rows:
            user = session.get(User, row.user_id) if row.user_id else None
            if username and (user is None or username.lower() not in user.username.lower()):
                continue
            results.append({
                "id": row.id,
                "when": row.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                "username": user.username if user else "(system)",
                "action": row.action,
                "entity_type": row.entity_type,
                "entity_id": row.entity_id,
                "details": row.details,
            })
        return results
