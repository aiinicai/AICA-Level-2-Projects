"""
Consultation notes, vitals and prescriptions (spec section 5).

Finalizing a clinical note or prescription makes it read-only; any later
change must go through `amend_clinical_note`, which creates a new linked
row rather than silently editing history.
"""
from __future__ import annotations

import datetime as _dt

from sqlalchemy import select

from app.database.base import session_scope
from app.models.clinical import Appointment, ClinicalNote, Prescription, PrescriptionItem, Visit, Vitals


def record_vitals(visit_id: int, recorded_by_id: int | None = None, **fields) -> Vitals:
    bmi = None
    height_cm = fields.get("height_cm")
    weight_kg = fields.get("weight_kg")
    if height_cm and weight_kg:
        height_m = height_cm / 100.0
        bmi = round(weight_kg / (height_m ** 2), 1)

    with session_scope() as session:
        vitals = Vitals(visit_id=visit_id, recorded_by_id=recorded_by_id, bmi=bmi, **fields)
        session.add(vitals)
        session.flush()
        session.refresh(vitals)
        session.expunge(vitals)
        return vitals


def save_clinical_note(visit_id: int, created_by_id: int | None = None, **fields) -> ClinicalNote:
    """Create or update a draft (not-yet-finalized) note for this visit."""
    with session_scope() as session:
        note = ClinicalNote(visit_id=visit_id, created_by_id=created_by_id, **fields)
        session.add(note)
        session.flush()
        session.refresh(note)
        session.expunge(note)
        return note


def finalize_clinical_note(note_id: int) -> None:
    with session_scope() as session:
        note = session.get(ClinicalNote, note_id)
        if note is None:
            raise ValueError("Clinical note not found.")
        if note.is_finalized:
            raise ValueError("Note is already finalized.")
        note.is_finalized = True
        note.finalized_at = _dt.datetime.utcnow()


def amend_clinical_note(note_id: int, created_by_id: int | None = None, **new_fields) -> ClinicalNote:
    """Create a new note version linked to the finalized one it amends (spec 5: traceable amendments)."""
    with session_scope() as session:
        original = session.get(ClinicalNote, note_id)
        if original is None:
            raise ValueError("Original clinical note not found.")
        if not original.is_finalized:
            raise ValueError("Only a finalized note can be amended.")

        amendment = ClinicalNote(
            visit_id=original.visit_id,
            amended_from_id=original.id,
            created_by_id=created_by_id,
            **new_fields,
        )
        session.add(amendment)
        session.flush()
        session.refresh(amendment)
        session.expunge(amendment)
        return amendment


def create_prescription(visit_id: int, doctor_id: int, items: list[dict]) -> Prescription:
    """Create a prescription with its line items and return it with `.items`
    already populated, so callers can read it after the session closes
    without triggering a lazy-load on a detached instance.
    """
    with session_scope() as session:
        prescription = Prescription(visit_id=visit_id, doctor_id=doctor_id)
        session.add(prescription)
        session.flush()
        created_items = [PrescriptionItem(prescription_id=prescription.id, **item) for item in items]
        session.add_all(created_items)
        session.flush()
        # Force-load the relationship while the session is still open, then
        # detach prescription and its items together.
        _ = prescription.items  # noqa: B018 (triggers the load intentionally)
        session.expunge(prescription)
        for created_item in created_items:
            session.expunge(created_item)
        return prescription


def finalize_prescription(prescription_id: int) -> None:
    with session_scope() as session:
        prescription = session.get(Prescription, prescription_id)
        if prescription is None:
            raise ValueError("Prescription not found.")
        prescription.is_finalized = True


def complete_visit(visit_id: int) -> None:
    """Close out an OPD visit once the consultation is done: closes the
    Visit and marks its Appointment "completed" so it drops out of the
    doctor's open queue (spec 4/5 — a booked appointment otherwise has no
    way to reach a terminal state once seen).
    """
    with session_scope() as session:
        visit = session.get(Visit, visit_id)
        if visit is None:
            raise ValueError("Visit not found.")
        visit.status = "closed"
        if visit.appointment_id:
            appointment = session.get(Appointment, visit.appointment_id)
            if appointment is not None:
                appointment.status = "completed"


def get_visit_for_appointment(appointment_id: int) -> Visit | None:
    """Find the (open) Visit created by checking an appointment in — the
    Consultation screen uses this to go from a queue entry to the visit it
    should chart against.
    """
    with session_scope() as session:
        visit = session.execute(
            select(Visit).where(Visit.appointment_id == appointment_id).order_by(Visit.id.desc())
        ).scalars().first()
        if visit:
            session.expunge(visit)
        return visit


def list_notes_for_visit(visit_id: int) -> list[ClinicalNote]:
    with session_scope() as session:
        rows = session.execute(
            select(ClinicalNote).where(ClinicalNote.visit_id == visit_id).order_by(ClinicalNote.id.desc())
        ).scalars().all()
        session.expunge_all()
        return rows


def list_prescriptions_for_visit(visit_id: int) -> list[Prescription]:
    with session_scope() as session:
        rows = session.execute(
            select(Prescription).where(Prescription.visit_id == visit_id).order_by(Prescription.id.desc())
        ).scalars().all()
        for prescription in rows:
            _ = prescription.items  # force-load before expunge
        session.expunge_all()
        return rows
