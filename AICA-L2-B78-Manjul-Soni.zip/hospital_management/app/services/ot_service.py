"""
Operation theatre scheduling and procedure workflow (spec section 12):
catalog -> booking -> pre-op checklist/consent -> in-progress -> procedure
notes -> post-op recovery notes -> consumables posted to the bill.
"""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass

from sqlalchemy import select

from app.database.base import session_scope
from app.models.ot import OTBooking, OTConsumable, ProcedureCatalog
from app.services.billing_service import InvoiceLine, create_invoice


@dataclass
class ProcedureInput:
    name: str
    department: str | None = None
    estimated_duration_minutes: int | None = None
    price: float = 0.0


def add_procedure(data: ProcedureInput) -> ProcedureCatalog:
    with session_scope() as session:
        procedure = ProcedureCatalog(**data.__dict__)
        session.add(procedure)
        session.flush()
        session.refresh(procedure)
        session.expunge(procedure)
        return procedure


def list_procedures(active_only: bool = True) -> list[ProcedureCatalog]:
    with session_scope() as session:
        stmt = select(ProcedureCatalog)
        if active_only:
            stmt = stmt.where(ProcedureCatalog.is_active.is_(True))
        rows = session.execute(stmt.order_by(ProcedureCatalog.name)).scalars().all()
        session.expunge_all()
        return rows


def schedule_booking(patient_id: int, procedure_id: int, surgeon_id: int, scheduled_at: _dt.datetime,
                      admission_id: int | None = None, anesthetist_id: int | None = None,
                      nursing_team: str | None = None, theatre_room: str | None = None,
                      created_by_id: int | None = None) -> OTBooking:
    with session_scope() as session:
        booking = OTBooking(
            patient_id=patient_id, admission_id=admission_id, procedure_id=procedure_id,
            surgeon_id=surgeon_id, anesthetist_id=anesthetist_id, nursing_team=nursing_team,
            theatre_room=theatre_room, scheduled_at=scheduled_at, created_by_id=created_by_id,
        )
        session.add(booking)
        session.flush()
        session.refresh(booking)
        session.expunge(booking)
        return booking


def list_bookings(status: str | None = None) -> list[OTBooking]:
    with session_scope() as session:
        stmt = select(OTBooking)
        if status:
            stmt = stmt.where(OTBooking.status == status)
        rows = session.execute(stmt.order_by(OTBooking.scheduled_at)).scalars().all()
        session.expunge_all()
        return rows


def mark_preop_ready(booking_id: int, checklist_complete: bool, consent_obtained: bool) -> None:
    with session_scope() as session:
        booking = session.get(OTBooking, booking_id)
        if booking is None:
            raise ValueError("OT booking not found.")
        booking.pre_op_checklist_complete = checklist_complete
        booking.consent_obtained = consent_obtained
        if checklist_complete and consent_obtained:
            booking.status = "pre_op_ready"


class PreOpIncompleteError(Exception):
    pass


def start_procedure(booking_id: int) -> None:
    with session_scope() as session:
        booking = session.get(OTBooking, booking_id)
        if booking is None:
            raise ValueError("OT booking not found.")
        if not (booking.pre_op_checklist_complete and booking.consent_obtained):
            raise PreOpIncompleteError(
                "Pre-operative checklist and consent must both be complete before starting."
            )
        booking.status = "in_progress"


def complete_procedure(booking_id: int, procedure_notes: str, post_op_recovery_notes: str | None = None) -> None:
    with session_scope() as session:
        booking = session.get(OTBooking, booking_id)
        if booking is None:
            raise ValueError("OT booking not found.")
        booking.status = "completed"
        booking.procedure_notes = procedure_notes
        booking.post_op_recovery_notes = post_op_recovery_notes


def add_consumable(booking_id: int, description: str, quantity: float, unit_price: float) -> OTConsumable:
    with session_scope() as session:
        consumable = OTConsumable(
            ot_booking_id=booking_id, description=description, quantity=quantity, unit_price=unit_price,
        )
        session.add(consumable)
        session.flush()
        session.refresh(consumable)
        session.expunge(consumable)
        return consumable


def generate_procedure_invoice(booking_id: int, created_by_id: int | None = None):
    """Bill the base procedure price plus every consumable line posted for this booking."""
    with session_scope() as session:
        booking = session.get(OTBooking, booking_id)
        if booking is None:
            raise ValueError("OT booking not found.")
        procedure = session.get(ProcedureCatalog, booking.procedure_id)
        consumables = session.execute(
            select(OTConsumable).where(OTConsumable.ot_booking_id == booking_id)
        ).scalars().all()
        patient_id = booking.patient_id
        lines = [InvoiceLine(description=f"Procedure: {procedure.name}", quantity=1, unit_price=procedure.price)]
        for item in consumables:
            lines.append(InvoiceLine(description=item.description, quantity=item.quantity, unit_price=item.unit_price))

    return create_invoice(patient_id=patient_id, invoice_type="opd", lines=lines, created_by_id=created_by_id)
