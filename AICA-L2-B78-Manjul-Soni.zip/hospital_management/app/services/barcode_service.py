"""
Barcode generation and scan-friendly lookups (spec Phase 4: barcode
scanners).

A barcode scanner is just a keyboard-wedge device: it "types" the barcode's
digits/text into whatever field has focus and finishes with an Enter/Tab
keystroke. That means the existing UHID/batch text search fields already
work with a real scanner without any extra code — this module's job is to
(a) generate a printable Code128 barcode image for a patient's UHID or a
medicine batch number, and (b) provide a normalised lookup so a scanned
value resolves to the right record even with incidental whitespace.
"""
from __future__ import annotations

from pathlib import Path

import barcode
from barcode.writer import ImageWriter


def generate_barcode_image(value: str, output_path: str) -> str:
    """Render `value` as a Code128 barcode PNG at output_path (without
    extension collisions — python-barcode appends .png itself).
    """
    output = Path(output_path)
    stem = str(output.with_suffix(""))
    code = barcode.get("code128", value, writer=ImageWriter())
    saved_path = code.save(stem)
    return saved_path


def normalize_scan(raw_value: str) -> str:
    """Strip whitespace/newlines a scanner may append after its Enter keystroke."""
    return raw_value.strip()
