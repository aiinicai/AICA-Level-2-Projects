"""
SQLAlchemy engine/session setup.

Defaults to a single local SQLite database file for a one-computer
deployment. Spec Phase 4 asks for an optional "multi-user network mode":
point HMS_DATABASE_URL (see app.config.settings) at a database file on a
shared network drive instead, and every computer on the LAN running this
app talks to the same data. SQLite itself supports concurrent readers plus
one writer at a time over a network share; WAL journal mode plus a busy
timeout (set below) is what makes that usable with a handful of concurrent
users instead of every other write getting "database is locked". Beyond
roughly 5-10 concurrent users, or if writes start timing out, that's the
signal to graduate to a real client-server database (Postgres/MySQL) —
this module is the only place that would need to change, since everything
above it talks through session_scope().

Foreign keys are explicitly enabled (SQLite defaults them to OFF).
"""
from __future__ import annotations

from contextlib import contextmanager

from sqlalchemy import create_engine, event
from sqlalchemy.orm import declarative_base, sessionmaker

from app.config import settings

engine = create_engine(
    settings.DATABASE_URL,
    connect_args={"check_same_thread": False, "timeout": 30},
    future=True,
)


@event.listens_for(engine, "connect")
def _set_sqlite_pragma(dbapi_connection, connection_record):  # noqa: ANN001
    """Enable foreign key enforcement and WAL mode (better concurrent
    read/write behaviour — see module docstring on network/multi-user mode)
    on every new SQLite connection.
    """
    cursor = dbapi_connection.cursor()
    cursor.execute("PRAGMA foreign_keys=ON")
    cursor.execute("PRAGMA journal_mode=WAL")
    cursor.execute("PRAGMA busy_timeout=30000")
    cursor.close()


SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)
Base = declarative_base()


@contextmanager
def session_scope():
    """Provide a transactional scope for a series of operations.

    Commits on success, rolls back on any exception (used for billing,
    payments, stock movement and discharge transactions per spec 17/24).
    """
    session = SessionLocal()
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


def init_db() -> None:
    """Create all tables if they do not already exist."""
    from app import models  # noqa: F401  (ensures models are registered)

    Base.metadata.create_all(bind=engine)
