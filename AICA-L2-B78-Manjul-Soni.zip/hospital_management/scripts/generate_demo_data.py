"""
One-shot demo/mock data generator for AICA-L2 HMS.

Populates a fresh database with a realistic Indian-hospital dataset so the
software can be handed over "ready-made" instead of empty: patients, doctors,
staff logins across every role, wards/rooms/beds, appointments in every
lifecycle state, OPD consultations with vitals/notes/prescriptions, pharmacy
stock (including deliberately low/expiring batches so the alert screens have
something to show), IPD admissions with nursing charts, lab orders, OT
bookings, billing + insurance claims, vendor purchase orders, attendance, and
communication logs.

Every record is created THROUGH THE APP'S OWN SERVICE FUNCTIONS (the same
ones the UI screens call) rather than raw ORM inserts, so it exercises real
validation, ID generation, and stock/ledger side effects exactly as if a
human had typed it in — the data is not just present in tables, it is
internally consistent (invoice totals match line items, bed status matches
admissions, stock matches the transaction ledger, etc.).

Run from the hospital_management/ directory:
    python -m scripts.generate_demo_data

Safe to re-run: it wipes and recreates the SQLite database file first, so
you always get a clean, fully-populated dataset rather than duplicates piling
up on top of old demo data.
"""
from __future__ import annotations

import datetime as _dt
import random
import sys
from pathlib import Path

# Allow running as `python -m scripts.generate_demo_data` or
# `python scripts/generate_demo_data.py` from the project root.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

random.seed(42)

from app.config import settings  # noqa: E402

# ---------------------------------------------------------------------------
# Fresh database: delete any existing one so this script always produces a
# clean, fully-known dataset (and the credential list below is guaranteed
# accurate) rather than appending on top of whatever was there before.
# ---------------------------------------------------------------------------
if settings.DATABASE_FILE.exists():
    settings.DATABASE_FILE.unlink()
for _wal in (settings.DATABASE_FILE.with_suffix(".db-wal"), settings.DATABASE_FILE.with_suffix(".db-shm")):
    if _wal.exists():
        _wal.unlink()

from sqlalchemy import select  # noqa: E402

from app.database.base import init_db, session_scope  # noqa: E402
from app.security.auth import ensure_seed_data  # noqa: E402
from app.models.user import User  # noqa: E402

init_db()
ensure_seed_data()

from app.services.appointment_service import (  # noqa: E402
    add_department, add_doctor, list_departments, list_doctors,
    book_appointment, start_visit, cancel_appointment, mark_no_show,
)
from app.services.user_service import UserInput, create_user  # noqa: E402
from app.services.patient_service import PatientInput, register_patient, add_relative  # noqa: E402
from app.services.clinical_service import (  # noqa: E402
    record_vitals, save_clinical_note, finalize_clinical_note,
    create_prescription, finalize_prescription, complete_visit,
)
from app.services.ward_service import add_ward, add_room, add_bed, list_beds, set_bed_status  # noqa: E402
from app.services.admission_service import admit_patient, discharge_patient  # noqa: E402
from app.services.nursing_service import (  # noqa: E402
    add_nursing_note, record_medication_administration, set_diet_order,
)
from app.services.medicine_service import MedicineInput, add_medicine, add_batch  # noqa: E402
from app.services.pharmacy_service import DispenseLine, dispense  # noqa: E402
from app.services.purchase_service import (  # noqa: E402
    VendorInput, add_vendor, POLine, create_purchase_order, ReceiveLine, receive_goods,
)
from app.services.lab_service import (  # noqa: E402
    LabTestInput, add_test, place_order, collect_sample, receive_sample, enter_result, verify_result,
)
from app.services.ot_service import ProcedureInput, add_procedure, schedule_booking, mark_preop_ready  # noqa: E402
from app.services.billing_service import InvoiceLine, create_invoice, record_payment  # noqa: E402
from app.services.insurance_service import InsurerInput, add_insurer, file_claim, update_claim_status  # noqa: E402
from app.services.attendance_service import clock_in, clock_out  # noqa: E402
from app.services.communication_service import send_notification  # noqa: E402

print("=" * 70)
print("AICA-L2 HMS — generating demo dataset (Indian names, all departments)")
print("=" * 70)

# ---------------------------------------------------------------------------
# Name pools (Indian, mixed pan-India + Gujarat-region names)
# ---------------------------------------------------------------------------
MALE_FIRST = [
    "Rajesh", "Suresh", "Amit", "Vikram", "Sanjay", "Anil", "Rohit", "Manoj",
    "Deepak", "Ashok", "Ramesh", "Vijay", "Naveen", "Arjun", "Ravi", "Karan",
    "Nikhil", "Sameer", "Gaurav", "Rahul", "Ajay", "Pradeep", "Dinesh", "Yogesh",
    "Sunil", "Harish", "Mahesh", "Vinod", "Sandeep", "Kunal", "Aditya", "Varun",
    "Siddharth", "Abhishek", "Mohit", "Bhavesh", "Jignesh", "Kalpesh", "Nirav",
    "Chirag", "Paresh", "Hitesh", "Mitul", "Rakesh", "Kishore", "Girish",
]
FEMALE_FIRST = [
    "Priya", "Sunita", "Anita", "Pooja", "Kavita", "Neha", "Meera", "Rekha",
    "Shreya", "Divya", "Anjali", "Swati", "Nisha", "Ritu", "Shalini", "Deepika",
    "Kiran", "Sarita", "Manisha", "Vandana", "Preeti", "Jyoti", "Seema", "Geeta",
    "Bhavna", "Komal", "Aarti", "Sneha", "Payal", "Radha", "Lakshmi", "Sushma",
    "Usha", "Ila", "Hetal", "Falguni", "Nirmala", "Kamla", "Rupal", "Trupti",
    "Bhumika", "Jagruti", "Darshana", "Mamta", "Sonal", "Alpa",
]
SURNAMES = [
    "Sharma", "Verma", "Gupta", "Patel", "Shah", "Mehta", "Joshi", "Desai",
    "Trivedi", "Pandya", "Iyer", "Nair", "Reddy", "Rao", "Naidu", "Kulkarni",
    "Deshpande", "Chopra", "Malhotra", "Kapoor", "Singh", "Yadav", "Mishra",
    "Tiwari", "Pathak", "Bhatt", "Thakkar", "Modi", "Parekh", "Soni", "Agarwal",
    "Bansal", "Jain", "Chauhan", "Rathod", "Solanki", "Vora", "Doshi", "Shukla",
    "Panchal",
]
CITIES_GJ = [
    ("Ahmedabad", "Gujarat", "380001"), ("Surat", "Gujarat", "395001"),
    ("Vadodara", "Gujarat", "390001"), ("Rajkot", "Gujarat", "360001"),
    ("Gandhinagar", "Gujarat", "382010"), ("Bhavnagar", "Gujarat", "364001"),
    ("Mumbai", "Maharashtra", "400001"), ("Pune", "Maharashtra", "411001"),
    ("Delhi", "Delhi", "110001"), ("Jaipur", "Rajasthan", "302001"),
]
RELATIONS = ["Spouse", "Father", "Mother", "Son", "Daughter", "Sibling", "Guardian"]
BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"]
OCCUPATIONS = [
    "Business", "Government Service", "Private Service", "Farmer", "Teacher",
    "Homemaker", "Student", "Self-employed", "Retired", "Driver",
]

used_names: set[str] = set()


def indian_name(gender: str) -> str:
    pool = MALE_FIRST if gender == "male" else FEMALE_FIRST
    while True:
        name = f"{random.choice(pool)} {random.choice(SURNAMES)}"
        if name not in used_names:
            used_names.add(name)
            return name


def random_mobile() -> str:
    return "9" + "".join(str(random.randint(0, 9)) for _ in range(9))


def random_dob(min_age: int, max_age: int) -> _dt.date:
    age = random.randint(min_age, max_age)
    today = _dt.date.today()
    return today.replace(year=today.year - age) - _dt.timedelta(days=random.randint(0, 364))


credentials: list[dict] = []  # collected for the final "who can log in" report


def make_login(username: str, full_name: str, role_name: str, password: str,
               linked_doctor_id: int | None = None) -> User:
    user = create_user(UserInput(
        username=username, full_name=full_name, role_name=role_name,
        password=password, linked_doctor_id=linked_doctor_id,
    ))
    credentials.append({
        "username": username, "password": password, "role": role_name,
        "full_name": full_name,
    })
    return user


# ---------------------------------------------------------------------------
# 1. Departments
# ---------------------------------------------------------------------------
print("\n[1/13] Departments...")
DEPARTMENTS = [
    "General Medicine", "Cardiology", "Orthopedics", "Pediatrics",
    "Gynecology & Obstetrics", "ENT (Otolaryngology)", "Dermatology",
    "General Surgery", "Neurology", "Psychiatry", "Nephrology", "Urology",
    "Ophthalmology", "Dental", "Emergency Medicine",
]
dept_by_name = {}
for name in DEPARTMENTS:
    dept_by_name[name] = add_department(name)
print(f"  {len(dept_by_name)} departments created.")

# ---------------------------------------------------------------------------
# 2. Doctors (15) + their logins
# ---------------------------------------------------------------------------
print("\n[2/13] Doctors + doctor logins...")
DOCTOR_SPECS = [
    ("General Medicine", "General Physician"),
    ("Cardiology", "Cardiologist"),
    ("Orthopedics", "Orthopedic Surgeon"),
    ("Pediatrics", "Pediatrician"),
    ("Gynecology & Obstetrics", "Gynecologist"),
    ("ENT (Otolaryngology)", "ENT Surgeon"),
    ("Dermatology", "Dermatologist"),
    ("General Surgery", "General Surgeon"),
    ("Neurology", "Neurologist"),
    ("Psychiatry", "Psychiatrist"),
    ("Nephrology", "Nephrologist"),
    ("Urology", "Urologist"),
    ("Ophthalmology", "Ophthalmologist"),
    ("Dental", "Dental Surgeon"),
    ("Emergency Medicine", "Emergency Medicine Specialist"),
]
doctors = []
for i, (dept_name, spec) in enumerate(DOCTOR_SPECS):
    gender = "male" if i % 3 != 0 else "female"
    full = indian_name(gender)
    doctor = add_doctor(
        full_name=f"Dr. {full}",
        department_id=dept_by_name[dept_name].id,
        specialization=spec,
        registration_number=f"GMC-{2008 + i}-{10000 + i * 37}",
        consultation_fee=float(random.choice([300, 400, 500, 600, 700, 800])),
        room_number=f"OPD-{i + 1:02d}",
    )
    doctors.append(doctor)
    username = f"dr.{full.split()[0].lower()}{i+1}"
    make_login(username, f"Dr. {full}", "doctor", "Doctor@123", linked_doctor_id=doctor.id)
print(f"  {len(doctors)} doctors created, each with a login (password: Doctor@123).")

# ---------------------------------------------------------------------------
# 3. Support staff (30 across nurse/ward_boy/housekeeping/receptionist/
#    intern/pharmacist/lab_technician/accountant/store_manager)
# ---------------------------------------------------------------------------
print("\n[3/13] Staff logins (nurses, ward boys, cleaners, receptionists, interns, ...)...")
STAFF_PLAN = (
    [("nurse", "Nurse@123")] * 8
    + [("ward_boy", "Ward@123")] * 4
    + [("housekeeping", "Clean@123")] * 4
    + [("receptionist", "Front@123")] * 6
    + [("intern", "Intern@123")] * 3
    + [("pharmacist", "Pharma@123")] * 2
    + [("lab_technician", "Lab@123")] * 2
    + [("accountant", "Accounts@123")] * 1
)
assert len(STAFF_PLAN) == 30, len(STAFF_PLAN)
role_seq: dict[str, int] = {}
for role_name, password in STAFF_PLAN:
    role_seq[role_name] = role_seq.get(role_name, 0) + 1
    gender = "female" if role_name in ("nurse", "receptionist", "housekeeping") and random.random() < 0.7 else (
        "male" if role_name in ("ward_boy",) else random.choice(["male", "female"])
    )
    full = indian_name(gender)
    username = f"{role_name.replace('_', '')}{role_seq[role_name]}"
    make_login(username, full, role_name, password)
print(f"  {len(STAFF_PLAN)} staff logins created across {len(set(r for r, _ in STAFF_PLAN))} roles.")

# One store_manager (rounding out 15 doctors + 30 staff + 1 admin nicely,
# and inventory screens need at least one to feel populated).
sm_name = indian_name("male")
make_login("storemgr1", sm_name, "store_manager", "Store@123")

print(f"  Total staff logins (excluding admin): {len(credentials)}")

# ---------------------------------------------------------------------------
# 4. Wards / rooms / beds
# ---------------------------------------------------------------------------
print("\n[4/13] Wards, rooms, beds...")
WARD_PLAN = [
    ("General Ward", "general", 4, 4, 500.0),
    ("ICU", "icu", 2, 2, 3500.0),
    ("Maternity Ward", "maternity", 3, 3, 1200.0),
    ("Pediatric Ward", "pediatric", 2, 3, 900.0),
    ("Private Ward", "private", 4, 1, 2500.0),
]
all_beds = []
for ward_name, ward_type, n_rooms, beds_per_room, daily_charge in WARD_PLAN:
    ward = add_ward(ward_name, ward_type)
    for r in range(1, n_rooms + 1):
        room = add_room(ward.id, f"{ward_name[:1]}{r:02d}")
        for b in range(1, beds_per_room + 1):
            category = "icu" if ward_type == "icu" else ("private" if ward_type == "private" else "general")
            bed = add_bed(room.id, f"{room.room_number}-B{b}", bed_category=category, daily_charge=daily_charge)
            all_beds.append(bed)
print(f"  {len(WARD_PLAN)} wards, {len(all_beds)} beds created.")

# ---------------------------------------------------------------------------
# 5. Patients (50) with full demographic fields
# ---------------------------------------------------------------------------
print("\n[5/13] Patients (50)...")
patients = []
for i in range(50):
    gender = random.choice(["male", "female"])
    full = indian_name(gender)
    city, state, pin = random.choice(CITIES_GJ)
    dob = random_dob(1, 85)
    patient = register_patient(PatientInput(
        full_name=full,
        gender=gender,
        mobile_number=random_mobile(),
        email=f"{full.split()[0].lower()}.{full.split()[1].lower()}{i}@example.com",
        date_of_birth=dob,
        alternate_number=random_mobile(),
        address=f"{random.randint(1, 200)}, {random.choice(['Satellite', 'Vastrapur', 'Navrangpura', 'Bopal', 'Maninagar', 'Paldi', 'Chandkheda'])} Society",
        city=city, state=state, pin_code=pin,
        blood_group=random.choice(BLOOD_GROUPS),
        marital_status=random.choice(["Single", "Married", "Widowed"]) if dob.year < _dt.date.today().year - 18 else "Single",
        occupation=random.choice(OCCUPATIONS),
        nationality="Indian",
        emergency_contact_name=indian_name(random.choice(["male", "female"])),
        emergency_contact_relation=random.choice(RELATIONS),
        emergency_contact_number=random_mobile(),
        govt_id_type="Aadhaar",
        govt_id_number="".join(str(random.randint(0, 9)) for _ in range(12)),
        insurance_id=f"INS{random.randint(100000, 999999)}" if random.random() < 0.3 else None,
    ))
    patients.append(patient)
    if random.random() < 0.4:
        add_relative(patient.id, indian_name(random.choice(["male", "female"])),
                     relation=random.choice(RELATIONS), mobile_number=random_mobile())
print(f"  {len(patients)} patients registered (UHIDs {patients[0].uhid}..{patients[-1].uhid}).")

# ---------------------------------------------------------------------------
# 6. Appointments across every lifecycle state + OPD consultations
# ---------------------------------------------------------------------------
print("\n[6/13] Appointments (booked/checked-in/completed/cancelled/no-show)...")
today = _dt.date.today()
COMMON_DIAGNOSES = [
    ("Viral fever", "Rest, hydration, antipyretics", "R50.9"),
    ("Hypertension - routine follow-up", "Continue medication, low-salt diet", "I10"),
    ("Type 2 Diabetes Mellitus", "Diet control, continue metformin", "E11.9"),
    ("Acute gastritis", "Antacids, avoid spicy food", "K29.7"),
    ("Upper respiratory tract infection", "Antibiotics, steam inhalation", "J06.9"),
    ("Migraine", "Analgesics, avoid triggers", "G43.9"),
    ("Lower back pain", "Physiotherapy, analgesics", "M54.5"),
]
RX_MEDICINES = [
    ("Paracetamol", "650mg", "1-0-1", "Oral", 5),
    ("Azithromycin", "500mg", "1-0-0", "Oral", 3),
    ("Pantoprazole", "40mg", "1-0-0", "Oral", 10),
    ("Metformin", "500mg", "1-0-1", "Oral", 30),
    ("Amlodipine", "5mg", "1-0-0", "Oral", 30),
    ("Cetirizine", "10mg", "0-0-1", "Oral", 5),
]

visits_completed = []
appointments_booked = []
appt_counter = 0
for patient in patients[:40]:
    doctor = random.choice(doctors)
    offset_days = random.randint(-10, 5)
    appt_date = today + _dt.timedelta(days=offset_days)
    appt_type = random.choice(["walk_in", "scheduled", "follow_up"])
    appt = book_appointment(patient.id, doctor.id, appt_date, appointment_type=appt_type)
    appt_counter += 1
    roll = random.random()

    if offset_days > 0:
        # Future appointment: stays "booked", except a few we cancel/no-show early.
        if roll < 0.1:
            cancel_appointment(appt.id)
        appointments_booked.append(appt)
        continue

    if roll < 0.1:
        cancel_appointment(appt.id)
        continue
    if roll < 0.18:
        mark_no_show(appt.id)
        continue

    # Otherwise: check in and run the full OPD flow.
    visit = start_visit(appt, created_by_id=None)
    record_vitals(
        visit.id,
        height_cm=round(random.uniform(150, 185), 1),
        weight_kg=round(random.uniform(45, 95), 1),
        temperature_c=round(random.uniform(97.0, 100.5), 1),
        pulse_bpm=random.randint(65, 100),
        bp_systolic=random.randint(110, 150),
        bp_diastolic=random.randint(70, 95),
        spo2_percent=round(random.uniform(95, 100), 1),
    )

    if roll < 0.85:  # most checked-in visits go all the way to completed
        diagnosis, advice, icd = random.choice(COMMON_DIAGNOSES)
        note = save_clinical_note(
            visit.id,
            chief_complaints=f"{diagnosis.split(' - ')[0]} for {random.randint(1, 7)} days",
            history_of_present_illness="Gradual onset, no similar past episodes reported.",
            diagnosis=diagnosis, icd10_code=icd, advice=advice,
        )
        finalize_clinical_note(note.id)

        rx_items = []
        for med_name, strength, freq, route, days in random.sample(RX_MEDICINES, k=random.randint(1, 3)):
            rx_items.append({
                "medicine_name": med_name, "dosage": strength, "frequency": freq,
                "route": route, "duration_days": days, "quantity": days * 2,
                "food_instruction": random.choice(["before_food", "after_food"]),
            })
        prescription = create_prescription(visit.id, doctor.id, rx_items)
        finalize_prescription(prescription.id)
        complete_visit(visit.id)
        visits_completed.append({"visit": visit, "patient": patient, "doctor": doctor, "prescription": prescription})
    # else: left "checked_in"/"in_consultation" mid-flow on purpose, to show a live queue.

print(f"  {appt_counter} appointments booked; {len(visits_completed)} completed full OPD flow with notes+prescriptions.")

# ---------------------------------------------------------------------------
# 7. Pharmacy: medicine master, batches (some low-stock, one expiring soon)
# ---------------------------------------------------------------------------
print("\n[7/13] Pharmacy medicines + batches (including low-stock and near-expiry)...")
MEDICINE_CATALOG = [
    ("Paracetamol", "Dolo 650", "tablet", "650mg", "Micro Labs", 2.5, 1.8, 30),
    ("Azithromycin", "Azithral 500", "tablet", "500mg", "Alembic", 12.0, 9.5, 20),
    ("Pantoprazole", "Pan 40", "tablet", "40mg", "Alkem", 8.0, 6.2, 40),
    ("Metformin", "Glycomet 500", "tablet", "500mg", "USV", 3.0, 2.1, 50),
    ("Amlodipine", "Amlokind 5", "tablet", "5mg", "Mankind", 4.5, 3.3, 30),
    ("Cetirizine", "Cetrizet", "tablet", "10mg", "Dr. Reddy's", 1.8, 1.2, 40),
    ("Amoxicillin + Clavulanate", "Augmentin 625", "tablet", "625mg", "GSK", 18.0, 14.5, 20),
    ("Ibuprofen", "Brufen 400", "tablet", "400mg", "Abbott", 3.5, 2.6, 30),
    ("Cough Syrup", "Ascoril LS", "syrup", "100ml", "Glenmark", 95.0, 78.0, 15),
    ("Vitamin D3", "Calcirol", "sachet", "60000 IU", "Cadila", 40.0, 32.0, 20),
    ("Insulin Glargine", "Lantus", "injection", "100IU/ml", "Sanofi", 550.0, 480.0, 10),
    ("Normal Saline", "IV Fluid NS", "injection", "500ml", "Fresenius Kabi", 45.0, 38.0, 25),
    ("Ondansetron", "Emeset 4", "tablet", "4mg", "Cipla", 6.0, 4.5, 20),
    ("Diclofenac Gel", "Voveran Gel", "ointment", "30g", "Novartis", 55.0, 42.0, 15),
    ("Omeprazole", "Omez 20", "capsule", "20mg", "Dr. Reddy's", 5.0, 3.8, 40),
    ("ORS Powder", "Electral", "sachet", "21.8g", "FDC", 12.0, 9.0, 30),
    ("Losartan", "Losar 50", "tablet", "50mg", "Unichem", 5.5, 4.1, 30),
    ("Salbutamol Inhaler", "Asthalin Inhaler", "inhaler", "100mcg", "Cipla", 140.0, 115.0, 15),
    ("Ranitidine", "Rantac 150", "tablet", "150mg", "J.B. Chemicals", 2.8, 2.0, 40),
    ("Amoxicillin", "Mox 500", "capsule", "500mg", "Ranbaxy", 4.0, 3.0, 30),
]
medicines = []
for idx, (generic, brand, form, strength, mfr, mrp, sale, reorder) in enumerate(MEDICINE_CATALOG):
    medicine = add_medicine(MedicineInput(
        generic_name=generic, brand_name=brand, composition=generic, manufacturer=mfr,
        dosage_form=form, strength=strength, tax_percent=12.0, mrp=mrp, sale_price=sale,
        reorder_level=reorder, storage_location=f"Rack-{(idx % 5) + 1}",
    ))
    medicines.append(medicine)
    is_low_stock_demo = idx < 4       # first 4 medicines: stock kept BELOW reorder level
    is_near_expiry_demo = idx == 4    # 5th medicine: batch expiring within 20 days
    if is_low_stock_demo:
        qty = max(1, reorder - random.randint(2, 5))
        expiry = today + _dt.timedelta(days=random.randint(200, 500))
    elif is_near_expiry_demo:
        qty = reorder + random.randint(20, 60)
        expiry = today + _dt.timedelta(days=random.randint(10, 20))
    else:
        qty = reorder + random.randint(20, 150)
        expiry = today + _dt.timedelta(days=random.randint(200, 720))
    add_batch(medicine.id, batch_number=f"B{2026}{idx+1:03d}", expiry_date=expiry,
              quantity=qty, purchase_price=mrp * 0.75)
print(f"  {len(medicines)} medicines seeded (4 deliberately low-stock, 1 expiring within 20 days).")

# ---------------------------------------------------------------------------
# 8. Dispense against a few finalized prescriptions
# ---------------------------------------------------------------------------
print("\n[8/13] Pharmacy dispensing against prescriptions...")
dispensed_count = 0
for entry in visits_completed[:15]:
    prescription = entry["prescription"]
    lines = []
    for med in random.sample(medicines[5:], k=min(2, len(medicines) - 5)):
        lines.append(DispenseLine(medicine_id=med.id, quantity=random.randint(5, 10), unit_price=med.sale_price))
    try:
        dispense(entry["patient"].id, lines, prescription_id=prescription.id)
        dispensed_count += 1
    except Exception:
        pass  # insufficient stock on a demo-only low-stock medicine is fine to skip
print(f"  {dispensed_count} pharmacy sales dispensed.")

# ---------------------------------------------------------------------------
# 9. Vendors + purchase orders + goods receipt (inventory/procurement)
# ---------------------------------------------------------------------------
print("\n[9/13] Vendors + purchase orders...")
vendors = [
    add_vendor(VendorInput(name="Zydus Wellness Distributors", contact_person="Rakesh Patel",
                            phone=random_mobile(), gstin="24AAAAA0000A1Z5")),
    add_vendor(VendorInput(name="Sun Pharma Regional Supply", contact_person="Bhavesh Shah",
                            phone=random_mobile(), gstin="24BBBBB1111B1Z6")),
    add_vendor(VendorInput(name="Apollo Pharmacy Wholesale", contact_person="Kiran Desai",
                            phone=random_mobile(), gstin="24CCCCC2222C1Z7")),
]
po = create_purchase_order(vendors[0].id, [
    POLine(medicine_id=medicines[0].id, quantity_ordered=100, unit_price=medicines[0].mrp * 0.75),
    POLine(medicine_id=medicines[1].id, quantity_ordered=80, unit_price=medicines[1].mrp * 0.75),
])
receive_goods(po.id, vendors[0].id, [
    ReceiveLine(po_item_id=po.items[0].id, medicine_id=medicines[0].id, batch_number="B2026-PO-01",
                expiry_date=today + _dt.timedelta(days=365), quantity=100, unit_price=medicines[0].mrp * 0.75),
    ReceiveLine(po_item_id=po.items[1].id, medicine_id=medicines[1].id, batch_number="B2026-PO-02",
                expiry_date=today + _dt.timedelta(days=365), quantity=80, unit_price=medicines[1].mrp * 0.75),
], invoice_number="SUP-INV-0001")
print(f"  {len(vendors)} vendors, 1 purchase order raised and received (also tops up the first 2 low-stock medicines' ledger).")

# ---------------------------------------------------------------------------
# 10. Laboratory: tests + orders across pending/in-progress/verified
# ---------------------------------------------------------------------------
print("\n[10/13] Laboratory tests + orders...")
LAB_TESTS = [
    ("Complete Blood Count (CBC)", "Hematology", "Blood", "4.0-11.0 x10^9/L", "10^9/L", 250.0),
    ("Fasting Blood Sugar", "Biochemistry", "Blood", "70-100 mg/dL", "mg/dL", 150.0),
    ("Lipid Profile", "Biochemistry", "Blood", "See report", "mg/dL", 600.0),
    ("Liver Function Test (LFT)", "Biochemistry", "Blood", "See report", "U/L", 700.0),
    ("Kidney Function Test (KFT)", "Biochemistry", "Blood", "See report", "mg/dL", 650.0),
    ("Urine Routine", "Pathology", "Urine", "See report", "-", 120.0),
    ("Thyroid Profile (T3/T4/TSH)", "Biochemistry", "Blood", "See report", "-", 550.0),
    ("HbA1c", "Biochemistry", "Blood", "4.0-5.6 %", "%", 450.0),
    ("Chest X-Ray", "Radiology", "-", "See report", "-", 400.0),
    ("ECG", "Cardiology", "-", "See report", "-", 300.0),
]
tests = [add_test(LabTestInput(name=n, department=d, specimen_type=s, normal_range=r, unit=u, price=p,
                                turnaround_hours=random.choice([4, 6, 24])))
         for n, d, s, r, u, p in LAB_TESTS]

lab_orders_made = 0
for entry in visits_completed[:20]:
    picked = random.sample(tests, k=random.randint(1, 3))
    order = place_order(entry["patient"].id, [t.id for t in picked], visit_id=entry["visit"].id)
    lab_orders_made += 1
    stage = random.choice(["ordered", "collected", "received", "resulted", "verified"])
    for item in order.items:
        if stage in ("collected", "received", "resulted", "verified"):
            collect_sample(item.id)
        if stage in ("received", "resulted", "verified"):
            receive_sample(item.id)
        if stage in ("resulted", "verified"):
            enter_result(item.id, result_value=str(round(random.uniform(60, 140), 1)),
                         is_abnormal=random.random() < 0.2)
        if stage == "verified":
            verify_result(item.id)
print(f"  {len(tests)} lab tests in catalog, {lab_orders_made} lab orders placed across every workflow stage.")

# ---------------------------------------------------------------------------
# 11. IPD admissions + nursing chart + discharge
# ---------------------------------------------------------------------------
print("\n[11/13] IPD admissions + nursing charts...")
ipd_patients = patients[40:48]
admissions = []
for i, patient in enumerate(ipd_patients):
    bed = all_beds[i]
    doctor = random.choice(doctors)
    admission = admit_patient(
        patient.id, doctor.id, bed.id, admission_source=random.choice(["opd", "emergency", "referral"]),
        provisional_diagnosis=random.choice([d for d, _, _ in COMMON_DIAGNOSES]),
        deposit_amount=float(random.choice([5000, 10000, 15000])), consent_obtained=True,
    )
    admissions.append(admission)
    for _ in range(random.randint(2, 4)):
        add_nursing_note(admission.id, note_text=random.choice([
            "Patient stable, vitals within normal limits.",
            "Mild fever noted at 4pm round, tepid sponging done.",
            "Patient ambulatory, tolerating oral diet well.",
            "IV line site checked, no signs of phlebitis.",
        ]), note_type=random.choice(["nursing", "doctor_round", "vitals"]))
    record_medication_administration(admission.id, medicine_name=random.choice(
        [m.brand_name for m in medicines]), dose="1 tablet", route="Oral")
    set_diet_order(admission.id, diet_type=random.choice(["normal", "diabetic", "liquid"]),
                    instructions="As per dietician's chart")

# Discharge the first 3 admitted patients so both active and discharged states exist.
for admission in admissions[:3]:
    discharge_patient(admission.id, discharge_summary="Patient improved symptomatically, advised follow-up in OPD after 1 week.",
                       follow_up_advice="Continue oral medication, review after 7 days.")
print(f"  {len(admissions)} admissions created ({len(admissions) - 3} still active, 3 discharged).")

# ---------------------------------------------------------------------------
# 12. OT bookings
# ---------------------------------------------------------------------------
print("\n[12/13] Operation theatre bookings...")
PROCEDURES = [
    ("Appendectomy", "General Surgery", 60, 15000.0),
    ("Cataract Surgery", "Ophthalmology", 45, 20000.0),
    ("Cesarean Section", "Gynecology & Obstetrics", 50, 25000.0),
    ("Tonsillectomy", "ENT (Otolaryngology)", 40, 12000.0),
    ("Fracture Fixation (ORIF)", "Orthopedics", 90, 30000.0),
]
procedures = [add_procedure(ProcedureInput(name=n, department=d, estimated_duration_minutes=m, price=p))
              for n, d, m, p in PROCEDURES]
for i in range(3):
    patient = random.choice(ipd_patients)
    procedure = procedures[i]
    surgeon = random.choice(doctors)
    booking = schedule_booking(patient.id, procedure.id, surgeon.id,
                                scheduled_at=_dt.datetime.combine(today + _dt.timedelta(days=i + 1), _dt.time(9, 0)),
                                theatre_room=f"OT-{i+1}")
    if i == 0:
        mark_preop_ready(booking.id, checklist_complete=True, consent_obtained=True)
print(f"  {len(procedures)} procedures in catalog, 3 OT bookings scheduled.")

# ---------------------------------------------------------------------------
# 13. Billing + insurance claims, attendance, communications
# ---------------------------------------------------------------------------
print("\n[13/13] Billing, insurance claims, attendance, communications...")
insurers = [
    add_insurer(InsurerInput(name="Star Health Insurance", insurer_type="insurance",
                              contact_person="Regional Desk", phone=random_mobile(), credit_limit=500000)),
    add_insurer(InsurerInput(name="ICICI Lombard General Insurance", insurer_type="insurance",
                              contact_person="Claims Desk", phone=random_mobile(), credit_limit=500000)),
    add_insurer(InsurerInput(name="Reliance Corporate Health Tie-up", insurer_type="corporate",
                              contact_person="HR Desk", phone=random_mobile(), credit_limit=200000)),
]

invoices_made = 0
claims_made = 0
# First 6 completed visits are reserved as guaranteed insurance/corporate
# demo cases (regardless of whether that patient happened to roll an
# insurance_id at registration) so the claims workflow always has real data
# to show, instead of depending on random chance producing an insured
# patient among the completed visits.
INSURANCE_DEMO_COUNT = min(6, len(visits_completed))
for i, entry in enumerate(visits_completed):
    doctor = entry["doctor"]
    invoice = create_invoice(
        entry["patient"].id, invoice_type="opd",
        lines=[InvoiceLine(description=f"Consultation - {doctor.full_name}", quantity=1,
                            unit_price=doctor.consultation_fee, tax_percent=0.0)],
        visit_id=entry["visit"].id,
    )
    invoices_made += 1

    if i < INSURANCE_DEMO_COUNT:
        if not entry["patient"].insurance_id:
            with session_scope() as session:
                from app.models.patient import Patient
                db_patient = session.get(Patient, entry["patient"].id)
                db_patient.insurance_id = f"INS{random.randint(100000, 999999)}"
                session.flush()
        insurer = random.choice(insurers)
        claim = file_claim(invoice.id, insurer.id, claim_amount=invoice.total_amount,
                            policy_or_employee_id=entry["patient"].insurance_id or f"INS{random.randint(100000, 999999)}")
        claims_made += 1
        if i % 2 == 0:
            update_claim_status(claim.id, "approved", approved_amount=invoice.total_amount)
            update_claim_status(claim.id, "settled", approved_amount=invoice.total_amount)
        else:
            update_claim_status(claim.id, "submitted")
        continue

    roll = random.random()
    if roll < 0.6:
        record_payment(invoice.id, invoice.total_amount, payment_method=random.choice(["cash", "card", "upi"]))
    elif roll < 0.85:
        record_payment(invoice.id, round(invoice.total_amount * 0.5, 2), payment_method="cash")
    # else: left fully unpaid on purpose, to show an outstanding-dues case.
print(f"  {invoices_made} OPD invoices generated, {claims_made} insurance claims filed (some settled, some pending).")

# Attendance: clock every staff login in, and clock most of them back out.
with session_scope() as session:
    all_users = session.execute(select(User)).scalars().all()
    user_ids = [(u.id, u.username) for u in all_users if u.username != "admin"]
for uid, uname in user_ids:
    entry = clock_in(uid, method="manual")
    if random.random() < 0.7:
        clock_out(uid, notes="End of shift.")
print(f"  Attendance clock-in recorded for {len(user_ids)} staff logins.")

# Communications: a few simulated notification sends (no real SMTP configured
# in this demo dataset, so these land as "simulated" in the log by design).
for entry in visits_completed[:5]:
    send_notification("sms", entry["patient"].mobile_number,
                       f"Your appointment with {entry['doctor'].full_name} is confirmed.",
                       patient_id=entry["patient"].id, template_key="appointment_confirmation")
print("  5 sample notification log entries created (simulated — no live SMS/email account in this build).")

# ---------------------------------------------------------------------------
# Final report: write every login credential to a plain-text file
# ---------------------------------------------------------------------------
print("\n" + "=" * 70)
cred_lines = [
    "AICA-L2 HMS — Demo user logins (generated by scripts/generate_demo_data.py)",
    "=" * 70,
    "",
    "Every account below can log in from the app's Login screen.",
    "All accounts are flagged 'must change password' on first login, same as",
    "any account an administrator creates from Settings -> Staff / users.",
    "",
    f"{'Username':<20} {'Password':<16} {'Role':<16} Full name",
    "-" * 90,
    f"{'admin':<20} {'Admin@123':<16} {'administrator':<16} System Administrator",
]
for c in credentials:
    cred_lines.append(f"{c['username']:<20} {c['password']:<16} {c['role']:<16} {c['full_name']}")

cred_text = "\n".join(cred_lines) + "\n"
out_path = Path(__file__).resolve().parent.parent / "DEMO_USER_LOGINS.txt"
out_path.write_text(cred_text, encoding="utf-8")
print(cred_text)
print(f"Credential list also written to: {out_path}")
print("=" * 70)
print("Demo data generation complete.")
