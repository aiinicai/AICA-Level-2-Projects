"""Small shared helpers: decimal-safe money handling and simple Excel writing.

All money inside the engine is held as integer *fils* (1 AED = 100 fils), so
additions are exact and there is no floating-point drift. Conversion to AED
floats happens only at the presentation edge.
"""
from __future__ import annotations

import hashlib
import re
from decimal import ROUND_HALF_UP, Decimal, InvalidOperation
from pathlib import Path

import pandas as pd
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter


def fils(value) -> int:
    """AED amount (number or string) -> integer fils, rounded half-up."""
    return int((Decimal(str(value)) * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP))


def aed(value_fils) -> float:
    """Integer fils -> AED float for display."""
    return float(Decimal(int(value_fils)) / 100)


def is_blank(raw) -> bool:
    if raw is None:
        return True
    try:
        if pd.isna(raw):
            return True
    except (TypeError, ValueError):
        pass
    return str(raw).strip() == "" or str(raw).strip().lower() in ("nan", "none", "nat")


def parse_amount(raw):
    """Parse an Excel cell into fils.

    Returns ``(fils, problem)`` where problem is ``None``, ``"blank"`` (treated as
    zero) or ``"invalid"`` (not numeric; fils is ``None``).
    """
    if is_blank(raw):
        return 0, "blank"
    text = str(raw).strip().replace(",", "").replace(" ", "")
    if text.startswith("(") and text.endswith(")"):
        text = "-" + text[1:-1]
    try:
        number = Decimal(text)
    except InvalidOperation:
        return None, "invalid"
    if not number.is_finite():
        return None, "invalid"
    return int((number * 100).quantize(Decimal(1), rounding=ROUND_HALF_UP)), None


def standardise_code(raw) -> str:
    """Account/entity codes: trimmed, upper-case, Excel's trailing '.0' removed."""
    if is_blank(raw):
        return ""
    text = str(raw).strip().upper()
    if re.fullmatch(r"\d+\.0+", text):
        text = text.split(".")[0]
    return re.sub(r"\s+", "", text)


def to_aed_frame(df: pd.DataFrame) -> pd.DataFrame:
    """Replace every ``*_Fils`` column with a ``*_AED`` float column (same position)."""
    out = df.copy()
    for col in [c for c in out.columns if c.endswith("_Fils")]:
        values = pd.to_numeric(out[col], errors="coerce")
        out[col] = (values / 100).round(2)
        out = out.rename(columns={col: col[:-5] + "_AED"})
    return out


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def save_simple_xlsx(path: Path, sheets: dict[str, pd.DataFrame]) -> None:
    """Write plain tables with a bold header, frozen top row, filter and widths."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        for name, frame in sheets.items():
            frame.to_excel(writer, sheet_name=name[:31], index=False)
            ws = writer.sheets[name[:31]]
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F3864")
            ws.freeze_panes = "A2"
            if len(frame.columns):
                ws.auto_filter.ref = ws.dimensions
            for idx, col in enumerate(frame.columns, start=1):
                longest = max([len(str(col))] + [len(str(v)) for v in frame[col].head(200)])
                ws.column_dimensions[get_column_letter(idx)].width = min(max(12, longest + 2), 60)
