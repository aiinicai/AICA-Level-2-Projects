"""Entry point for the packaged FinancialConsolidation.exe (PyInstaller).

Starts the Streamlit app on 127.0.0.1 only and opens the browser. Not used when running from source.
"""
from __future__ import annotations

import os
import sys
import threading
import webbrowser
from pathlib import Path

# Imported so PyInstaller bundles the application modules (app.py loads them at run time).
import config, consolidation_engine, db, financial_statements, journals, master_data  # noqa: E401,F401
import reconciliation, reporting, sample_data_generator, utils, validation  # noqa: E401,F401
import tkinter  # noqa: F401

PORT = 8501


def pick_folder() -> None:
    from tkinter import Tk, filedialog
    root = Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    print(filedialog.askdirectory(title="Select the folder with the 21 trial balance files"))


def main() -> None:
    if len(sys.argv) > 1 and sys.argv[1] == "--pick-folder":
        pick_folder()
        return
    exe_dir = Path(sys.executable).resolve().parent
    os.chdir(exe_dir)  # so .streamlit/config.toml next to the exe is used
    bundle = Path(getattr(sys, "_MEIPASS", exe_dir))
    app_path = bundle / "app.py"
    # make sure demo data/templates exist next to the exe
    if not (config.SAMPLE_DIR / "HO.xlsx").exists():
        sample_data_generator.create_templates()
        sample_data_generator.generate_sample_data()
        sample_data_generator.generate_error_sample()
    os.environ["STREAMLIT_GLOBAL_DEVELOPMENT_MODE"] = "false"
    os.environ["STREAMLIT_BROWSER_GATHER_USAGE_STATS"] = "false"
    os.environ["STREAMLIT_SERVER_HEADLESS"] = "true"
    threading.Timer(5, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}")).start()
    print(f"Financial Consolidation running at http://127.0.0.1:{PORT} - close this window to stop.")
    from streamlit.web import cli as stcli
    sys.argv = ["streamlit", "run", str(app_path), "--global.developmentMode=false", f"--server.port={PORT}",
                "--server.address=127.0.0.1", "--server.headless=true", "--browser.gatherUsageStats=false"]
    sys.exit(stcli.main())


if __name__ == "__main__":
    main()
