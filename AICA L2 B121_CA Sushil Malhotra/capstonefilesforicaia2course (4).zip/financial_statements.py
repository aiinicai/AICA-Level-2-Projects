"""Statement of Profit or Loss, Statement of Financial Position and branch analysis.

Statements are built only from accounts that carry an approved mapping to a
statement line. Nothing is invented: unmapped balances stay out and are flagged.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import pandas as pd

import config
from utils import aed


def net_by_line(frame: pd.DataFrame, net_col: str = "Net_Fils") -> dict[str, int]:
    """Debit-minus-credit total per statement line. ``frame`` needs an FS_Line column."""
    if frame.empty:
        return {}
    mapped = frame[frame["FS_Line"].notna() & (frame["FS_Line"] != "")]
    return {k: int(v) for k, v in mapped.groupby("FS_Line")[net_col].sum().items()}


@dataclass
class Statements:
    pl: pd.DataFrame
    bs: pd.DataFrame
    figures: dict
    warnings: list = field(default_factory=list)


def _row(label, fils_value, kind="line"):
    return {"Line": label, "Amount_Fils": int(fils_value), "Row_Type": kind}


def compute_statements(net: dict[str, int], unmapped_net_fils: int = 0) -> Statements:
    """``net`` = debit-minus-credit per statement line (fils)."""
    g = lambda line: net.get(line, 0)  # noqa: E731
    # Profit or loss: credit-nature lines positive, debit-nature lines negative.
    revenue, returns = -g("Revenue"), -g("Sales returns")
    net_revenue = revenue + returns
    cos = -g("Cost of sales")
    gross = net_revenue + cos
    other_income = -g("Other income")
    opex = {line: -g(line) for line in config.OPEX_LINES}
    operating = gross + other_income + sum(opex.values())
    finance = -g("Finance costs")
    pbt = operating + finance
    tax = -g("Income tax expense")
    profit = pbt + tax

    pl_rows = [_row("Revenue", revenue), _row("Sales returns", returns), _row("Net revenue", net_revenue, "subtotal"),
               _row("Cost of sales", cos), _row("Gross profit", gross, "total"), _row("Other income", other_income)]
    pl_rows += [_row(line, opex[line]) for line in config.OPEX_LINES]
    pl_rows += [_row("Operating profit", operating, "total"), _row("Finance costs", finance),
                _row("Profit before tax", pbt, "total"), _row("Income tax expense", tax), _row("Profit for the period", profit, "total")]

    # Financial position: assets = debit-positive, liabilities/equity = credit-positive.
    ppe, accdep = g("Property, plant and equipment"), g("Accumulated depreciation")
    assets = {"Inventory": g("Inventory"), "Trade receivables": g("Trade receivables"), "Other receivables": g("Other receivables"),
              "Interbranch receivables": g("Interbranch receivables"), "Cash and bank": g("Cash and bank")}
    total_assets = ppe + accdep + sum(assets.values())
    liab = {"Trade payables": -g("Trade payables"), "Accrued expenses": -g("Accrued expenses"), "Other liabilities": -g("Other liabilities"),
            "Interbranch payables": -g("Interbranch payables"), "Borrowings": -g("Borrowings")}
    total_liab = sum(liab.values())
    capital, retained = -g("Capital"), -g("Retained earnings")
    total_equity = capital + retained + profit
    bs_rows = [_row("Property, plant and equipment", ppe), _row("Accumulated depreciation", accdep),
               _row("Net property, plant and equipment", ppe + accdep, "subtotal")]
    bs_rows += [_row(k, v) for k, v in assets.items()] + [_row("Total assets", total_assets, "total")]
    bs_rows += [_row(k, v) for k, v in liab.items()] + [_row("Total liabilities", total_liab, "total")]
    bs_rows += [_row("Capital", capital), _row("Retained earnings", retained), _row("Current-period profit", profit),
                _row("Total equity", total_equity, "total"), _row("Total liabilities and equity", total_liab + total_equity, "total")]

    difference = total_assets - (total_liab + total_equity)
    warnings = []
    if difference != 0:
        warnings.append(f"Statement of Financial Position does not balance: difference AED {aed(difference):,.2f}.")
    if unmapped_net_fils:
        warnings.append(f"Balances of AED {aed(abs(unmapped_net_fils)):,.2f} (net) sit on unmapped accounts and are excluded from the statements.")
    if capital == 0 and retained == 0:
        warnings.append("No capital or retained-earnings balance found: opening balances may be missing.")
    if g("Interbranch receivables") + g("Interbranch payables") != 0:
        warnings.append("Interbranch balances do not net to zero: unreconciled or uneliminated interbranch balances remain.")

    figures = {
        "revenue": revenue, "sales_returns": returns, "net_revenue": net_revenue, "cost_of_sales": cos, "gross_profit": gross,
        "gross_margin": (gross / net_revenue) if net_revenue > 0 else None,
        "operating_expenses": -sum(opex.values()), "operating_profit": operating, "finance_costs": finance,
        "profit_before_tax": pbt, "tax": tax, "profit": profit, "total_assets": total_assets,
        "total_liabilities": total_liab, "total_equity": total_equity, "bs_difference": difference,
    }
    pl, bs = pd.DataFrame(pl_rows), pd.DataFrame(bs_rows)
    return Statements(pl=pl, bs=bs, figures=figures, warnings=warnings)


def statements_frame(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    out["Amount_AED"] = (out["Amount_Fils"] / 100).round(2)
    return out.drop(columns="Amount_Fils")


# ---------------------------------------------------------------------------- branch analysis
ACCOUNTING_COLS = ["Gross_Revenue_AED", "Sales_Returns_AED", "Net_Revenue_AED", "Cost_of_Sales_AED", "Gross_Profit_AED",
                   "Operating_Expenses_AED", "Operating_Profit_AED", "Profit_Before_Tax_AED", "Total_Assets_AED",
                   "Total_Liabilities_AED"]
RATIO_COLS = ["Gross_Margin_Pct", "Operating_Margin_Pct"]


def branch_analysis(tb_lines: pd.DataFrame) -> pd.DataFrame:
    """One row per location from the original (pre-adjustment) location trial balances.

    ``tb_lines`` needs Entity_Code, FS_Line and Net_Fils. Accounting figures are in AED;
    the ``*_Pct`` columns are calculated management ratios (blank when the denominator is not positive).
    """
    rows = []
    for loc in config.ALL_LOCATIONS:
        sub = tb_lines[tb_lines["Entity_Code"] == loc]
        if sub.empty:
            continue
        s = compute_statements(net_by_line(sub))
        f = s.figures
        flags = []
        if f["gross_profit"] < 0:
            flags.append("Negative gross profit")
        if f["operating_profit"] < 0:
            flags.append("Operating loss")
        if f["net_revenue"] <= 0:
            flags.append("No revenue - margins not calculated")
        rows.append({
            "Location": loc, "Location_Name": config.LOCATION_NAMES[loc],
            "Gross_Revenue_AED": aed(f["revenue"]), "Sales_Returns_AED": aed(-f["sales_returns"]),
            "Net_Revenue_AED": aed(f["net_revenue"]), "Cost_of_Sales_AED": aed(-f["cost_of_sales"]),
            "Gross_Profit_AED": aed(f["gross_profit"]), "Operating_Expenses_AED": aed(f["operating_expenses"]),
            "Operating_Profit_AED": aed(f["operating_profit"]), "Profit_Before_Tax_AED": aed(f["profit_before_tax"]),
            "Total_Assets_AED": aed(f["total_assets"]), "Total_Liabilities_AED": aed(f["total_liabilities"]),
            "Gross_Margin_Pct": round(f["gross_margin"] * 100, 2) if f["gross_margin"] is not None else None,
            "Operating_Margin_Pct": round(f["operating_profit"] / f["net_revenue"] * 100, 2) if f["net_revenue"] > 0 else None,
            "Flags": "; ".join(flags),
        })
    return pd.DataFrame(rows)


def compare_two(df: pd.DataFrame, a: str, b: str) -> pd.DataFrame:
    """Side-by-side comparison of two locations."""
    metrics = ACCOUNTING_COLS + RATIO_COLS
    ra, rb = df[df["Location"] == a].iloc[0], df[df["Location"] == b].iloc[0]
    out = pd.DataFrame({"Metric": metrics, a: [ra[m] for m in metrics], b: [rb[m] for m in metrics]})
    out["Difference"] = out[a].astype(float) - out[b].astype(float)
    out["Type"] = ["Accounting figure (AED)"] * len(ACCOUNTING_COLS) + ["Calculated ratio (%)"] * len(RATIO_COLS)
    return out


def vs_average(df: pd.DataFrame) -> pd.DataFrame:
    """Each branch against the average branch (BR01-BR20, Head Office excluded)."""
    branches = df[df["Location"].isin(config.BRANCHES)].copy()
    metrics = ACCOUNTING_COLS + RATIO_COLS
    average = branches[metrics].astype(float).mean()
    out = branches[["Location"]].copy()
    for m in metrics:
        out[f"{m}_vs_Avg"] = (branches[m].astype(float) - average[m]).round(2)
    return out.reset_index(drop=True)


def vs_combined(df: pd.DataFrame) -> pd.DataFrame:
    """Each location's share of the combined company result (accounting figures only)."""
    total = df[ACCOUNTING_COLS].astype(float).sum()
    out = df[["Location"]].copy()
    for m in ACCOUNTING_COLS:
        out[f"{m}_Share_Pct"] = (df[m].astype(float) / total[m] * 100).round(2) if total[m] else None
    return out.reset_index(drop=True)
