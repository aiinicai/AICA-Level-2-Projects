"""Deterministic generator for FICTITIOUS demonstration data and the Excel templates.

Run:  python sample_data_generator.py            (writes ./sample_data and ./templates)
      python sample_data_generator.py --errors   (also writes ./sample_data_with_errors)

The same seed always produces identical files. No real client data is used.
"""
from __future__ import annotations

import argparse
import random
import shutil
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook

import config
from utils import save_simple_xlsx

SEED = 20251231
YEAR = config.DEFAULT_YEAR
PERIOD = config.period_label(YEAR)

COA_COLUMNS = ["Account_Code", "Account_Description", "Reporting_Category", "Financial_Statement",
               "Normal_Balance", "Active_Status"]
TB_COLUMNS = ["Entity_Code", "Account_Code", "Account_Description", "Debit", "Credit", "Currency",
              "Financial_Period"]
JOURNAL_COLUMNS = ["Journal_ID", "Journal_Date", "Financial_Period", "Debit_Account", "Credit_Account",
                   "Amount", "Currency", "Description", "Related_Location", "Counterparty_Location",
                   "Approval_Status", "Approved_By", "Approval_Date", "Supporting_Reference"]

# code, description, reporting category, FS (BS/PL), normal balance, approved FS line
BASE_ACCOUNTS = [
    ("1000", "Cash on Hand", "Current assets", "BS", "Debit", "Cash and bank"),
    ("1010", "Bank - Operating Account", "Current assets", "BS", "Debit", "Cash and bank"),
    ("1100", "Trade Receivables", "Current assets", "BS", "Debit", "Trade receivables"),
    ("1150", "Prepayments and Deposits", "Current assets", "BS", "Debit", "Other receivables"),
    ("1160", "Staff Advances", "Current assets", "BS", "Debit", "Other receivables"),
    ("1200", "Inventory - Trading Goods", "Current assets", "BS", "Debit", "Inventory"),
    ("1500", "Furniture and Fixtures", "Non-current assets", "BS", "Debit", "Property, plant and equipment"),
    ("1510", "Motor Vehicles", "Non-current assets", "BS", "Debit", "Property, plant and equipment"),
    ("1520", "Equipment", "Non-current assets", "BS", "Debit", "Property, plant and equipment"),
    ("1590", "Accumulated Depreciation", "Non-current assets", "BS", "Credit", "Accumulated depreciation"),
    ("2000", "Trade Payables", "Current liabilities", "BS", "Credit", "Trade payables"),
    ("2100", "Accrued Expenses", "Current liabilities", "BS", "Credit", "Accrued expenses"),
    ("2200", "VAT Payable", "Current liabilities", "BS", "Credit", "Other liabilities"),
    ("2210", "Corporate Tax Payable", "Current liabilities", "BS", "Credit", "Other liabilities"),
    ("2300", "Bank Loan", "Non-current liabilities", "BS", "Credit", "Borrowings"),
    ("3000", "Share Capital", "Equity", "BS", "Credit", "Capital"),
    ("3100", "Retained Earnings", "Equity", "BS", "Credit", "Retained earnings"),
    ("4000", "Sales Revenue", "Revenue", "PL", "Credit", "Revenue"),
    ("4100", "Sales Returns", "Revenue", "PL", "Debit", "Sales returns"),
    ("4900", "Other Income", "Other income", "PL", "Credit", "Other income"),
    ("5000", "Cost of Sales", "Cost of sales", "PL", "Debit", "Cost of sales"),
    ("6000", "Salaries and Wages", "Operating expenses", "PL", "Debit", "Employee expenses"),
    ("6010", "Staff Benefits and Visa Costs", "Operating expenses", "PL", "Debit", "Employee expenses"),
    ("6100", "Rent", "Operating expenses", "PL", "Debit", "Rent and occupancy expenses"),
    ("6110", "Utilities", "Operating expenses", "PL", "Debit", "Rent and occupancy expenses"),
    ("6200", "Office and Administration", "Operating expenses", "PL", "Debit", "Administrative expenses"),
    ("6210", "Professional Fees", "Operating expenses", "PL", "Debit", "Administrative expenses"),
    ("6300", "Marketing and Advertising", "Operating expenses", "PL", "Debit", "Selling and distribution expenses"),
    ("6310", "Delivery and Freight Out", "Operating expenses", "PL", "Debit", "Selling and distribution expenses"),
    ("6400", "Depreciation Expense", "Operating expenses", "PL", "Debit", "Depreciation and amortisation"),
    ("6500", "Other Operating Expenses", "Operating expenses", "PL", "Debit", "Other operating expenses"),
    ("6600", "Telephone (Legacy Account)", "Operating expenses", "PL", "Debit", "Other operating expenses"),
    ("7000", "Interest Expense", "Finance costs", "PL", "Debit", "Finance costs"),
    ("8000", "Corporate Tax Expense", "Tax", "PL", "Debit", "Income tax expense"),
]


def ib_index(loc: str) -> int:
    return 0 if loc == config.HEAD_OFFICE else int(loc[2:])


def ib_receivable_code(counterparty: str) -> str:
    return f"14{ib_index(counterparty):02d}"


def ib_payable_code(counterparty: str) -> str:
    return f"24{ib_index(counterparty):02d}"


def build_master_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Chart of accounts, approved account mapping and interbranch account mapping."""
    coa_rows, map_rows = [], []
    for code, desc, cat, fs, normal, line in BASE_ACCOUNTS:
        active = "Inactive" if code == "6600" else "Active"
        coa_rows.append((code, desc, cat, fs, normal, active))
        map_rows.append((code, line, "Approved"))
    ib_rows = []
    for loc in config.ALL_LOCATIONS:
        rc, pc = ib_receivable_code(loc), ib_payable_code(loc)
        coa_rows.append((rc, f"Interbranch Receivable - {loc}", "Interbranch", "BS", "Debit", "Active"))
        coa_rows.append((pc, f"Interbranch Payable - {loc}", "Interbranch", "BS", "Credit", "Active"))
        map_rows.append((rc, "Interbranch receivables", "Approved"))
        map_rows.append((pc, "Interbranch payables", "Approved"))
        ib_rows.append((rc, "Receivable", loc))
        ib_rows.append((pc, "Payable", loc))
    coa = pd.DataFrame(coa_rows, columns=COA_COLUMNS)
    mapping = pd.DataFrame(map_rows, columns=["Account_Code", "FS_Line", "Mapping_Status"])
    ib = pd.DataFrame(ib_rows, columns=["Account_Code", "Direction", "Counterparty_Location"])
    return coa, mapping, ib


def _c(amount: float) -> int:
    """AED -> fils."""
    return int(round(amount * 100))


# Interbranch positions: (location holding the receivable, counterparty holding the payable,
#                         receivable amount AED, payable amount AED)
def interbranch_positions() -> list[tuple[str, str, int, int]]:
    rng = random.Random(f"{SEED}-ib")
    special = {"BR01": (500_000, 480_000),   # AED 20,000 difference (partially matched)
               "BR05": (120_000, 0),         # counterparty has not recorded anything (unmatched)
               "BR07": (250_000, 150_000)}   # large difference requiring investigation
    positions = []
    for br in config.BRANCHES:
        if br in special:
            rec, pay = special[br]
        else:
            rec = pay = rng.randrange(400, 2000) * 1000
        positions.append((config.HEAD_OFFICE, br, rec, pay))
    positions.append(("BR03", "BR04", 300_000, 300_000))  # branch-to-branch, matched
    return positions


def build_location_lines(loc: str, positions) -> dict[str, int]:
    """Net balances in fils (debit positive, credit negative) for one location, before equity."""
    rng = random.Random(f"{SEED}-{loc}")
    is_ho = loc == config.HEAD_OFFICE
    revenue = rng.uniform(5.0e6, 8.0e6) if is_ho else rng.uniform(3.0e6, 11.0e6)
    returns = revenue * rng.uniform(0.01, 0.03)
    net_rev = revenue - returns
    cos_ratio = rng.uniform(0.68, 0.78)
    if loc == "BR13":
        cos_ratio = 1.04  # deliberately loss-making gross margin, to show the exception flag
    cos = net_rev * cos_ratio
    ppe_cost = rng.uniform(0.8e6, 2.5e6) * (2 if is_ho else 1)
    lines = {
        "4000": -_c(revenue), "4100": _c(returns), "5000": _c(cos),
        "4900": -_c(revenue * rng.uniform(0.002, 0.01)),
        "6000": _c(net_rev * rng.uniform(0.05, 0.08)), "6010": _c(net_rev * rng.uniform(0.008, 0.015)),
        "6100": _c(net_rev * rng.uniform(0.02, 0.04)), "6110": _c(net_rev * rng.uniform(0.005, 0.01)),
        "6200": _c(net_rev * rng.uniform(0.008, 0.02)), "6210": _c(net_rev * (0.02 if is_ho else 0.002)),
        "6300": _c(net_rev * rng.uniform(0.01, 0.025)), "6310": _c(net_rev * rng.uniform(0.01, 0.02)),
        "6400": _c(ppe_cost * rng.uniform(0.08, 0.11)), "6500": _c(net_rev * rng.uniform(0.004, 0.012)),
        "1000": _c(rng.uniform(5_000, 40_000)), "1010": _c(rng.uniform(0.4e6, 1.8e6)),
        "1100": _c(revenue * rng.uniform(0.08, 0.14)), "1150": _c(rng.uniform(60_000, 220_000)),
        "1160": _c(rng.uniform(5_000, 30_000)), "1200": _c(cos * rng.uniform(0.10, 0.16)),
        "1500": _c(ppe_cost * 0.4), "1510": _c(ppe_cost * 0.3), "1520": _c(ppe_cost * 0.3),
        "1590": -_c(ppe_cost * rng.uniform(0.35, 0.55)),
        "2000": -_c(cos * rng.uniform(0.07, 0.12)), "2100": -_c(net_rev * rng.uniform(0.01, 0.025)),
        "2200": -_c(net_rev * rng.uniform(0.004, 0.01)),
    }
    if is_ho:
        lines["2300"] = -_c(3_000_000)
        lines["7000"] = _c(3_000_000 * 0.055)
        lines["3000"] = -_c(5_000_000)
    elif rng.random() < 0.25:
        lines["2300"] = -_c(500_000)
        lines["7000"] = _c(500_000 * 0.06)
    for holder, other, rec, pay in positions:
        if holder == loc and rec:
            lines[ib_receivable_code(other)] = lines.get(ib_receivable_code(other), 0) + _c(rec)
        if other == loc and pay:
            lines[ib_payable_code(holder)] = lines.get(ib_payable_code(holder), 0) - _c(pay)
    return lines


def profit_before_tax_fils(lines: dict[str, int]) -> int:
    return -sum(v for k, v in lines.items() if k[0] in "45678" and k != "8000")


def build_all_trial_balances() -> dict[str, pd.DataFrame]:
    positions = interbranch_positions()
    coa, _, _ = build_master_data()
    names = dict(zip(coa["Account_Code"], coa["Account_Description"]))
    all_lines = {loc: build_location_lines(loc, positions) for loc in config.ALL_LOCATIONS}

    # Corporate tax is computed on the combined entity and booked in the Head Office.
    pbt = sum(profit_before_tax_fils(v) for v in all_lines.values())
    tax = max(0, int(round((pbt / 100 - config.TAX_FREE_THRESHOLD) * config.TAX_RATE * 100)))
    all_lines[config.HEAD_OFFICE]["8000"] = tax
    all_lines[config.HEAD_OFFICE]["2210"] = -tax

    frames = {}
    for loc, lines in all_lines.items():
        lines["3100"] = -sum(lines.values())  # opening retained earnings: balances the fictitious ledger
        rows = []
        for code in sorted(lines):
            net = lines[code]
            if net == 0:
                continue
            rows.append((loc, code, names[code], max(net, 0) / 100, max(-net, 0) / 100, config.CURRENCY, PERIOD))
        frames[loc] = pd.DataFrame(rows, columns=TB_COLUMNS)
    return frames


def build_journals() -> pd.DataFrame:
    rows = []

    def add(jid, dr, cr, amount, desc, rel, cpty, status, ref):
        approved = status == "Approved"
        rows.append((jid, f"{YEAR}-12-31", PERIOD, dr, cr, amount, config.CURRENCY, desc, rel, cpty, status,
                     "Finance Controller" if approved else "", f"{YEAR + 1}-01-15" if approved else "", ref))

    for k, (holder, other, rec, pay) in enumerate(interbranch_positions(), start=1):
        agreed = min(rec, pay)
        if agreed == 0:
            continue  # nothing agreed: leave for investigation, no journal proposed
        status = "Pending" if other == "BR07" else "Approved"
        add(f"JE-IB-{k:03d}", ib_payable_code(holder), ib_receivable_code(other), agreed,
            f"Eliminate agreed interbranch balance {holder}/{other}", holder, other, status,
            f"IBREC-{PERIOD}-{holder}-{other}")
    add("JA-001", "6110", "2100", 45_000, "Accrue December utilities not yet invoiced", "HO", "", "Approved", "ACCR-DEC-UTIL")
    add("JA-002", "6100", "", 12_000, "Year-end rent accrual (line 1)", "HO", "", "Approved", "ACCR-DEC-RENT")
    add("JA-002", "6200", "", 8_000, "Year-end admin accrual (line 2)", "HO", "", "Approved", "ACCR-DEC-RENT")
    add("JA-002", "", "2100", 20_000, "Year-end accruals (credit line)", "HO", "", "Approved", "ACCR-DEC-RENT")
    add("JA-003", "6400", "1590", 25_000, "Proposed depreciation true-up", "HO", "", "Pending", "DEP-REVIEW-01")
    add("JE-PL-001", "4900", "6200", 30_000, "Eliminate internal recharge income/expense", "HO", "BR02", "Approved", "RECHARGE-2025")
    return pd.DataFrame(rows, columns=JOURNAL_COLUMNS)


def create_templates(template_dir: Path = config.TEMPLATE_DIR) -> None:
    template_dir = Path(template_dir)
    tb = pd.DataFrame([["BR01", "1000", "Cash on Hand", 1000.00, 0.00, "AED", PERIOD],
                       ["BR01", "3100", "Retained Earnings", 0.00, 1000.00, "AED", PERIOD]], columns=TB_COLUMNS)
    save_simple_xlsx(template_dir / "trial_balance_template.xlsx", {
        "Trial_Balance": tb,
        "Instructions": pd.DataFrame({"Instructions": [
            "One file per location, named HO.xlsx or BR01.xlsx ... BR20.xlsx.",
            "Debit and Credit are separate, non-negative columns. Delete the two example rows.",
            "Currency must be AED. Financial_Period must match the period selected in the application.",
            "Every Account_Code must exist in Chart_of_Accounts.xlsx and Account_Mapping.xlsx."]})})
    coa = pd.DataFrame([["1000", "Cash on Hand", "Current assets", "BS", "Debit", "Active"]], columns=COA_COLUMNS)
    save_simple_xlsx(template_dir / "chart_of_accounts_template.xlsx", {
        "Chart_of_Accounts": coa,
        "Account_Mapping": pd.DataFrame([["1000", "Cash and bank", "Approved"]],
                                        columns=["Account_Code", "FS_Line", "Mapping_Status"]),
        "Interbranch_Accounts": pd.DataFrame([["1401", "Receivable", "BR01"]],
                                             columns=["Account_Code", "Direction", "Counterparty_Location"]),
        "Valid_FS_Lines": pd.DataFrame({"FS_Line": config.VALID_FS_LINES})})
    example = pd.DataFrame([["JA-100", f"{YEAR}-12-31", PERIOD, "6110", "2100", 1000.00, "AED", "Example accrual",
                             "HO", "", "Pending", "", "", "REF-001"]], columns=JOURNAL_COLUMNS)
    save_simple_xlsx(template_dir / "elimination_journal_template.xlsx", {
        "Journals": example,
        "Instructions": pd.DataFrame({"Instructions": [
            "Only rows with Approval_Status = Approved, Approved_By and Approval_Date are applied.",
            "Multi-line journals: repeat the Journal_ID; leave Credit_Account (or Debit_Account) blank on a line.",
            "Fill Counterparty_Location to mark an interbranch elimination.",
            "Each Journal_ID must balance (total debits = total credits)."]})})


def generate_sample_data(out_dir: Path = config.SAMPLE_DIR) -> Path:
    out_dir = Path(out_dir)
    if out_dir.exists():
        for f in out_dir.glob("*.xlsx"):
            f.unlink()
    out_dir.mkdir(parents=True, exist_ok=True)
    for loc, frame in build_all_trial_balances().items():
        save_simple_xlsx(out_dir / f"{loc}.xlsx", {"Trial_Balance": frame})
    coa, mapping, ib = build_master_data()
    save_simple_xlsx(out_dir / config.COA_FILE, {"Chart_of_Accounts": coa})
    save_simple_xlsx(out_dir / config.MAPPING_FILE, {"Account_Mapping": mapping, "Interbranch_Accounts": ib})
    save_simple_xlsx(out_dir / config.JOURNAL_FILE, {"Journals": build_journals()})
    return out_dir


def _edit(path: Path, fn) -> None:
    frame = pd.read_excel(path, dtype=str)
    save_simple_xlsx(path, {"Trial_Balance": fn(frame)})


def generate_error_sample(out_dir: Path = config.ERROR_SAMPLE_DIR) -> Path:
    """Copy of the sample set with deliberate faults, for demonstrating the controls."""
    out_dir = Path(out_dir)
    generate_sample_data(out_dir)

    def unbalance(df):
        df.loc[df.index[0], "Debit"] = str(float(df.loc[df.index[0], "Debit"]) + 1500)
        return df

    def unmapped(df):
        extra = df.iloc[[0]].copy()
        extra[["Account_Code", "Account_Description", "Debit", "Credit"]] = ["6999", "Consultancy Misc", "2000", "0"]
        retained = df["Account_Code"] == "3100"
        df.loc[retained, "Credit"] = str(float(df.loc[retained, "Credit"].iloc[0]) + 2000)
        return pd.concat([df, extra], ignore_index=True)

    def blank_code(df):
        df.loc[df.index[2], "Account_Code"] = ""
        return df

    def duplicate_row(df):
        return pd.concat([df, df.iloc[[3]]], ignore_index=True)

    def bad_amount(df):
        df.loc[df.index[1], "Debit"] = "N/A"
        return df

    def negative(df):
        df.loc[df.index[4], "Debit"] = "-500"
        return df

    _edit(out_dir / "BR07.xlsx", unbalance)
    _edit(out_dir / "BR11.xlsx", unmapped)
    _edit(out_dir / "BR18.xlsx", blank_code)
    _edit(out_dir / "BR09.xlsx", duplicate_row)
    _edit(out_dir / "BR12.xlsx", bad_amount)
    _edit(out_dir / "BR02.xlsx", negative)
    (out_dir / "BR14.xlsx").unlink()                                   # missing location
    shutil.copy(out_dir / "BR16.xlsx", out_dir / "BR16_copy.xlsx")     # duplicate location
    (out_dir / "BR19.xlsx").write_bytes(b"this is not an excel workbook")  # corrupt file
    return out_dir


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate fictitious sample data and templates")
    parser.add_argument("--errors", action="store_true", help="also create sample_data_with_errors")
    args = parser.parse_args()
    create_templates()
    print(f"Templates written to {config.TEMPLATE_DIR}")
    print(f"Sample data written to {generate_sample_data()}")
    if args.errors:
        print(f"Error-injected sample data written to {generate_error_sample()}")


if __name__ == "__main__":
    main()
