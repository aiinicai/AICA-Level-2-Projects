"""Streamlit user interface. Runs locally only; all calculations live in the other modules."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

import config
import financial_statements as fs
from consolidation_engine import FinalisationBlocked, run_pipeline, trace_account
from db import Database
from reporting import ReportExportError, build_reconciliation_workbook, build_workbook
from utils import aed, to_aed_frame

log = config.setup_logging()
st.set_page_config(page_title="Financial Consolidation", page_icon="ðŸ“Š", layout="wide")
db = Database()

# ------------------------------------------------------------------ look and feel (no external fonts/CDNs: works offline)
PALETTE = ["#4F46E5", "#0EA5A4", "#F59E0B", "#E11D48", "#7C3AED", "#10B981", "#0284C7", "#EA580C"]
px.defaults.color_discrete_sequence = PALETTE
px.defaults.template = "plotly_white"

st.markdown("""
<style>
html, body, [class*="css"] { font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif; }
.stApp { background: linear-gradient(180deg, #F4F6FF 0%, #FFFFFF 280px); }
[data-testid="stSidebar"] { background: linear-gradient(180deg, #0B1F4B 0%, #3B2FB5 100%); }
[data-testid="stSidebar"] * { color: #F1F5FF !important; }
[data-testid="stSidebar"] [role="radiogroup"] label { padding: 7px 10px; border-radius: 10px; margin-bottom: 2px; }
[data-testid="stSidebar"] [role="radiogroup"] label:hover { background: rgba(255,255,255,0.14); }
.hero { background: linear-gradient(120deg, #0B1F4B 0%, #4F46E5 55%, #0EA5A4 100%); color: #fff; padding: 26px 30px;
        border-radius: 18px; margin-bottom: 18px; box-shadow: 0 8px 24px rgba(79,70,229,0.28); }
.hero h1 { color: #fff; margin: 0; font-size: 2rem; font-weight: 700; letter-spacing: .2px; }
.hero p { color: #DCE6FF; margin: 6px 0 0 0; font-size: 1rem; }
.pill { display: inline-block; padding: 5px 14px; border-radius: 999px; font-weight: 600; font-size: .85rem; margin-bottom: 14px; }
.pill.ok { background: #D1FAE5; color: #065F46; } .pill.warn { background: #FEF3C7; color: #92400E; }
.pill.bad { background: #FFE4E6; color: #9F1239; }
.kpi { background: #fff; border-radius: 16px; padding: 16px 18px; border-top: 5px solid var(--c); margin-bottom: 12px;
       box-shadow: 0 4px 14px rgba(15,23,42,0.08); }
.kpi .l { font-size: .78rem; text-transform: uppercase; letter-spacing: .6px; color: #64748B; font-weight: 600; }
.kpi .v { font-size: 1.65rem; font-weight: 700; color: var(--c); margin-top: 2px; }
.kpi .s { font-size: .78rem; color: #94A3B8; }
[data-testid="stMetric"] { background: #fff; border-radius: 14px; padding: 12px 16px; border-left: 5px solid #4F46E5;
                           box-shadow: 0 3px 12px rgba(15,23,42,0.07); }
.stButton > button, .stDownloadButton > button { border-radius: 12px; font-weight: 600; border: none; padding: .55rem 1.1rem;
        background: linear-gradient(120deg, #4F46E5, #7C3AED); color: #fff; box-shadow: 0 4px 12px rgba(79,70,229,0.3); }
.stButton > button:hover, .stDownloadButton > button:hover { filter: brightness(1.1); color: #fff; }
.stButton > button:disabled { background: #CBD5E1; box-shadow: none; color: #fff; }
[data-testid="stDataFrame"] { border-radius: 12px; overflow: hidden; box-shadow: 0 3px 12px rgba(15,23,42,0.07); }
h3, h4 { color: #0B1F4B; }
</style>
""", unsafe_allow_html=True)


def page_header(title: str, subtitle: str = "") -> None:
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


def kpi(col, label: str, value: str, colour: str = "#4F46E5", sub: str = "") -> None:
    col.markdown(f'<div class="kpi" style="--c:{colour}"><div class="l">{label}</div><div class="v">{value}</div>'
                 f'<div class="s">{sub}&nbsp;</div></div>', unsafe_allow_html=True)

PAGES = ["1. Home", "2. Input Data", "3. Validation", "4. Reconciliation", "5. Adjustments and Eliminations",
         "6. Financial Reports", "7. Dashboard", "8. Export"]


# ------------------------------------------------------------------ helpers
def money_config(df: pd.DataFrame) -> dict:
    cfg = {}
    for col in df.columns:
        if col.endswith("_AED"):
            cfg[col] = st.column_config.NumberColumn(col[:-4].replace("_", " ") + " (AED)", format="%.2f")
        elif col.endswith("_Pct"):
            cfg[col] = st.column_config.NumberColumn(col.replace("_", " "), format="%.2f%%")
    return cfg


def show(df: pd.DataFrame, height: int | str = "auto") -> None:
    out = to_aed_frame(df).reset_index(drop=True)
    formats = {c: "{:,.2f}" for c in out.columns if c.endswith("_AED") or c.endswith("_Pct")}
    labels = {c: st.column_config.Column(c[:-4].replace("_", " ") + (" (AED)" if c.endswith("_AED") else " %")) for c in formats}
    st.dataframe(out.style.format(formats, na_rep=""), width="stretch", hide_index=True, column_config=labels, height=height)


def severity_style(df: pd.DataFrame):
    colours = {"Critical": "background-color:#f8cbad", "Warning": "background-color:#ffe699", "Info": "background-color:#ddebf7"}
    return df.style.map(lambda v: colours.get(v, ""), subset=["Severity"])


def result():
    return st.session_state.get("result")


def need_result() -> bool:
    if result() is None:
        st.info("No data loaded yet. Go to **2. Input Data** and load a folder first.")
        return False
    return True


def status_banner(res) -> None:
    if res.finalised:
        text, css = f"FINAL - reports approved for {res.period}", "ok"
    elif res.critical_count:
        text, css = f"PRELIMINARY - {res.critical_count} critical error(s) block final reports", "bad"
    else:
        text, css = "PRELIMINARY - no critical errors; generate the statements to approve", "warn"
    st.markdown(f'<span class="pill {css}">{text}</span>', unsafe_allow_html=True)


def browse_folder() -> str | None:
    """Native Windows folder dialog (tkinter, local only) run in a separate process."""
    code = ("import tkinter as tk\nfrom tkinter import filedialog\nr=tk.Tk(); r.withdraw(); r.attributes('-topmost', True)\n"
            "print(filedialog.askdirectory(title='Select the folder with the 21 trial balance files'))")
    try:
        command = [sys.executable, "--pick-folder"] if getattr(sys, "frozen", False) else [sys.executable, "-c", code]
        out = subprocess.run(command, capture_output=True, text=True, timeout=120)
        return out.stdout.strip() or None
    except Exception:
        return None


def load(folder: str, year: int, manual_map: dict | None = None) -> None:
    try:
        res = run_pipeline(folder, year, manual_map, db.get_reviews())
    except FileNotFoundError as exc:
        st.error(str(exc))
        return
    except Exception as exc:  # unexpected - keep the app alive and log without data
        log.exception("Pipeline failure")
        st.error(f"The folder could not be processed: {type(exc).__name__}. See logs/app.log.")
        return
    db.save_run(res)
    st.session_state["result"] = res
    st.session_state["manual_map"] = manual_map or {}


# ------------------------------------------------------------------ pages
def page_home() -> None:
    page_header(config.COMPANY_NAME, "Combined financial statements - Head Office and 20 branches")
    res = result()
    st.subheader(f"Combined financial statements - Head Office and 20 branches ({res.period if res else config.period_label(config.DEFAULT_YEAR)})")
    st.markdown("""
**How to use this application**
1. **Input Data** - pick the folder with `HO.xlsx`, `BR01.xlsx` ... `BR20.xlsx` plus the chart of accounts, account mapping and journal files, then press *Load and validate*.
2. **Validation** - clear every critical error (warnings can be reviewed).
3. **Reconciliation** - review interbranch differences. Nothing is written off automatically.
4. **Adjustments and Eliminations** - only *approved* balanced journals reach the final reports.
5. **Financial Reports** - press **Generate Consolidated Financial Statements** once no critical errors remain.
6. **Dashboard** and **Export** - analyse and download the Excel workbook.

*All processing happens on this laptop. No data is sent anywhere.* Offline use is not a substitute for laptop security, disk encryption and careful handling of exported reports.
""")
    if res:
        status_banner(res)
    st.markdown("**Recent runs (local SQLite database)**")
    runs = db.list_runs(8)
    if runs.empty:
        st.caption("No runs yet.")
    else:
        st.dataframe(runs, width="stretch", hide_index=True)


def page_input() -> None:
    page_header("Input Data", "Choose the folder with your 21 trial balances and load it")
    st.session_state.setdefault("folder", str(config.SAMPLE_DIR))
    col1, col2 = st.columns([4, 1])
    folder = col1.text_input("Folder containing the trial balance files", key="folder")
    col2.write("")
    col2.write("")
    if col2.button("Browse..."):
        picked = browse_folder()
        if picked:
            st.session_state["folder"] = picked
            st.rerun()
    year = st.number_input("Financial year (ending)", min_value=2000, max_value=2100, value=config.DEFAULT_YEAR, step=1,
                           help=f"Files must carry Financial_Period = {config.period_label(int(config.DEFAULT_YEAR))} style labels. "
                                f"Financial year starts in month {config.FY_START_MONTH} (change in config.py).")
    if st.button("Load and validate files", type="primary"):
        with st.spinner("Reading and validating files..."):
            load(folder, int(year), st.session_state.get("manual_map"))
    res = result()
    if not res:
        st.caption("Tip: the folder `sample_data` contains fictitious data; `sample_data_with_errors` demonstrates the controls.")
        return
    st.success(f"Loaded {res.period} from {res.folder}")
    st.markdown("#### Files detected and assigned locations")
    show(res.files)
    unresolved = res.files[res.files["Location"].isin(["UNIDENTIFIED", "MULTIPLE"])]
    if not unresolved.empty:
        st.warning("Some files could not be assigned to a location. Choose the location and re-validate.")
        edited = st.data_editor(unresolved[["File_Name"]].assign(Location=""), hide_index=True, width="stretch",
                                column_config={"Location": st.column_config.SelectboxColumn(options=config.ALL_LOCATIONS)}, key="mapper")
        if st.button("Apply manual mapping and re-validate"):
            mapping = {r.File_Name: r.Location for r in edited.itertuples() if r.Location}
            load(folder, int(year), mapping)
            st.rerun()
    st.markdown("#### Trial balance status by location")
    show(res.location_totals)
    with st.expander("Trace a consolidated balance to its source records"):
        code = st.selectbox("Account", res.combined_before["Account_Code"].tolist())
        show(trace_account(res.tb, code))


def page_validation() -> None:
    page_header("Validation", "Every control result in one place - critical errors block final reports")
    if not need_result():
        return
    res = result()
    status_banner(res)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Critical errors", res.critical_count)
    c2.metric("Open warnings", res.open_warning_count)
    c3.metric("Unmapped accounts", len(res.unmapped))
    c4.metric("Locations out of balance", int((res.location_totals["Status"] == "Out of balance").sum()))
    sev = st.multiselect("Severity", ["Critical", "Warning", "Info"], default=["Critical", "Warning"])
    issues = to_aed_frame(res.issues)
    view = issues[issues["Severity"].isin(sev)].drop(columns=["Issue_Key"])
    if view.empty:
        st.success("No issues in the selected severities.")
    else:
        st.dataframe(severity_style(view), width="stretch", hide_index=True, column_config=money_config(view))
    st.markdown("#### Review warnings")
    warnings = res.issues[(res.issues["Severity"] == "Warning") & (res.issues["Resolution_Status"] == "Open")]
    if warnings.empty:
        st.caption("No open warnings.")
    else:
        labels = {r.Issue_Key: f"{r.Location} | {r.Validation_Rule} | {r.Error_Description[:90]}" for r in warnings.itertuples()}
        chosen = st.multiselect("Warnings you have reviewed", list(labels), format_func=labels.get)
        who = st.text_input("Reviewed by", value="Finance reviewer")
        note = st.text_input("Review note")
        if st.button("Mark selected warnings as reviewed") and chosen:
            db.set_reviews(chosen, who, note)
            res.apply_reviews(db.get_reviews())
            st.rerun()
    st.caption("Critical errors cannot be marked as reviewed: correct the source file and reload.")
    st.markdown("#### Unmapped account report")
    if res.unmapped.empty:
        st.success("All accounts are mapped.")
    else:
        show(res.unmapped)


def page_recon() -> None:
    page_header("Interbranch Reconciliation", "Receivables against payables - differences are shown, never adjusted")
    if not need_result():
        return
    res = result()
    recon = res.recon
    if recon.empty:
        st.info("No interbranch balances found.")
        return
    counts = recon["Status"].value_counts()
    cols = st.columns(4)
    for col, label in zip(cols, ["Matched", "Partially matched", "Unmatched", "Difference requiring investigation"]):
        col.metric(label, int(counts.get(label, 0)))
    pick = st.multiselect("Show status", sorted(recon["Status"].unique()), default=[s for s in recon["Status"].unique() if s != "Matched"])
    show(recon[recon["Status"].isin(pick)] if pick else recon)
    st.caption("Differences are shown for investigation only; they are never written off, adjusted or eliminated automatically.")
    if st.button("Create Excel reconciliation report"):
        try:
            path = build_reconciliation_workbook(res)
            st.success(f"Saved {path}")
            st.download_button("Download reconciliation report", path.read_bytes(), file_name=path.name)
        except ReportExportError as exc:
            st.error(str(exc))


def page_journals() -> None:
    page_header("Adjustments and Eliminations", "Only approved, balanced journals reach the final reports")
    if not need_result():
        return
    reg = result().journals.register
    if reg.empty:
        st.info("No journals loaded.")
        return
    c1, c2 = st.columns(2)
    applied = reg["Application_Status"] == "Applied"
    c1.metric("Approved and applied", int(applied.sum()))
    c2.metric("Not applied (unapproved or rejected)", int((~applied).sum()))
    kind = st.radio("Show", ["All", "Applied", "Not applied"], horizontal=True)
    view = reg if kind == "All" else reg[applied] if kind == "Applied" else reg[~applied]
    show(view)
    st.markdown("#### Audit trail")
    show(result().audit_trail)


def page_reports() -> None:
    page_header("Financial Reports", "Trial balance, profit or loss, financial position and branch analysis")
    if not need_result():
        return
    res = result()
    status_banner(res)
    blocked = not res.can_finalise
    if st.button("Generate Consolidated Financial Statements", type="primary", disabled=blocked, width="stretch"):
        try:
            res.finalise()
            if res.run_id:
                db.mark_final(res.run_id)
            st.rerun()
        except FinalisationBlocked as exc:
            st.error(str(exc))
    if blocked:
        st.error("Final statements are blocked until all critical errors on the Validation page are resolved.")
    scopes = {"Final combined result (after approved journals)": None, "Combined HO + branches (before adjustments)": config.ALL_LOCATIONS,
              "Head Office": [config.HEAD_OFFICE], "All branches combined": config.BRANCHES}
    scopes.update({f"{loc} - {config.LOCATION_NAMES[loc]}": [loc] for loc in config.BRANCHES})
    choice = st.selectbox("Report scope", list(scopes))
    scope = scopes[choice]
    statements = res.statements if scope is None else res.scope_statements(scope)
    for w in statements.warnings:
        st.warning(w)
    if scope is None:
        st.markdown("#### Consolidated trial balance (before and after approved journals)")
        show(res.adjusted[["Account_Code", "Account_Description", "FS_Line", "Original_Net_Fils", "Adjustment_Net_Fils",
                           "Elimination_Net_Fils", "Final_Debit_Fils", "Final_Credit_Fils"]], height=320)
    left, right = st.columns(2)
    with left:
        st.markdown("#### Statement of Profit or Loss")
        show(fs.statements_frame(statements.pl))
    with right:
        st.markdown("#### Statement of Financial Position")
        show(fs.statements_frame(statements.bs))
    st.markdown("#### Branch-wise analysis")
    st.caption("Accounting figures are in AED. Columns ending 'Pct' are calculated management ratios, shown only when the denominator is positive.")
    show(res.branch)
    with st.expander("Compare branches"):
        mode = st.radio("Comparison", ["Branch vs branch", "Each branch vs average branch", "All locations vs combined company"], horizontal=True)
        if mode == "Branch vs branch":
            a, b = st.columns(2)
            la, lb = a.selectbox("First", config.ALL_LOCATIONS, index=1), b.selectbox("Second", config.ALL_LOCATIONS, index=2)
            st.dataframe(fs.compare_two(res.branch, la, lb), width="stretch", hide_index=True)
        elif mode.startswith("Each"):
            st.dataframe(fs.vs_average(res.branch), width="stretch", hide_index=True)
        else:
            st.dataframe(fs.vs_combined(res.branch), width="stretch", hide_index=True)


def page_dashboard() -> None:
    page_header("Dashboard", "Key indicators and interactive charts")
    if not need_result():
        return
    res = result()
    status_banner(res)
    f1, f2 = st.columns([3, 1])
    chosen = f1.multiselect("Locations", config.ALL_LOCATIONS, default=config.ALL_LOCATIONS)
    f2.selectbox("Financial period", [res.period], disabled=True, help="One period is processed per run.")
    if not chosen:
        st.info("Select at least one location.")
        return
    stm = res.statements if set(chosen) == set(config.ALL_LOCATIONS) else res.scope_statements(chosen)
    f = stm.figures
    st.caption("All locations selected = final combined result after approved journals; otherwise original location balances.")
    k = st.columns(4)
    kpi(k[0], "Total revenue (net)", f"{aed(f['net_revenue']):,.0f}", "#4F46E5", "AED")
    kpi(k[1], "Gross profit", f"{aed(f['gross_profit']):,.0f}", "#0EA5A4", "AED")
    kpi(k[2], "Gross profit margin", "n/a" if f["gross_margin"] is None else f"{f['gross_margin'] * 100:.1f}%", "#7C3AED", "calculated ratio")
    kpi(k[3], "Operating profit", f"{aed(f['operating_profit']):,.0f}", "#10B981", "AED")
    k = st.columns(4)
    kpi(k[0], "Profit before tax", f"{aed(f['profit_before_tax']):,.0f}", "#0284C7", "AED")
    kpi(k[1], "Total assets", f"{aed(f['total_assets']):,.0f}", "#F59E0B", "AED")
    kpi(k[2], "Total liabilities", f"{aed(f['total_liabilities']):,.0f}", "#EA580C", "AED")
    kpi(k[3], "Total equity", f"{aed(f['total_equity']):,.0f}", "#4F46E5", "AED")
    k = st.columns(3)
    kpi(k[0], "Branches processed", str(int(res.tb[res.tb["Entity_Code"].isin(config.BRANCHES)]["Entity_Code"].nunique())), "#0EA5A4", "of 20")
    kpi(k[1], "Unresolved validation errors", str(res.critical_count), "#E11D48" if res.critical_count else "#10B981", "critical")
    kpi(k[2], "Unreconciled interbranch balances", str(res.unreconciled_count), "#F59E0B" if res.unreconciled_count else "#10B981", "pairs")
    br = res.branch[res.branch["Location"].isin(chosen)]
    if br.empty:
        return
    c1, c2 = st.columns(2)
    c1.plotly_chart(px.bar(br, x="Location", y="Net_Revenue_AED", title="Branch-wise net revenue (AED)", color_discrete_sequence=["#4F46E5"]),
                    width="stretch")
    prof = br.melt(id_vars="Location", value_vars=["Gross_Profit_AED", "Operating_Profit_AED", "Profit_Before_Tax_AED"], var_name="Measure", value_name="AED")
    c2.plotly_chart(px.bar(prof, x="Location", y="AED", color="Measure", barmode="group", title="Branch-wise profitability (AED)"), width="stretch")
    c3, c4 = st.columns(2)
    rv = br.melt(id_vars="Location", value_vars=["Net_Revenue_AED", "Operating_Expenses_AED"], var_name="Measure", value_name="AED")
    c3.plotly_chart(px.bar(rv, x="Location", y="AED", color="Measure", barmode="group", title="Revenue versus operating expenses (AED)"), width="stretch")
    gm = px.bar(br, x="Location", y="Gross_Margin_Pct", title="Gross profit margin (calculated ratio, %)", color_discrete_sequence=["#7C3AED"])
    average = br["Gross_Margin_Pct"].mean()
    if pd.notna(average):
        gm.add_hline(y=average, line_dash="dash", annotation_text=f"average {average:.1f}%")
    c4.plotly_chart(gm, width="stretch")
    summary = pd.DataFrame({"Item": ["Net revenue", "Gross profit", "Operating profit", "Profit before tax", "Total assets", "Total liabilities", "Total equity"],
                            "AED": [aed(f[x]) for x in ("net_revenue", "gross_profit", "operating_profit", "profit_before_tax", "total_assets", "total_liabilities", "total_equity")]})
    st.plotly_chart(go.Figure(go.Bar(x=summary["Item"], y=summary["AED"], marker_color=PALETTE)).update_layout(title="Financial statement summary (AED)"),
                    width="stretch")
    flagged = br[br["Flags"] != ""][["Location", "Flags"]]
    if not flagged.empty:
        st.warning("Unusual results flagged (figures unchanged):")
        st.dataframe(flagged, hide_index=True)


def page_export() -> None:
    page_header("Export", "Download the Excel reporting workbook")
    if not need_result():
        return
    res = result()
    status_banner(res)
    if not res.finalised:
        st.error("Generate the final statements on the Financial Reports page first.")
    elif st.button("Create Excel workbook", type="primary"):
        try:
            path = build_workbook(res)
            st.session_state["export_path"] = str(path)
            db.log_event(f"Workbook exported for {res.period}")
            st.success(f"Saved to {path}")
        except (ReportExportError, FinalisationBlocked) as exc:
            st.error(str(exc))
    exported = st.session_state.get("export_path")
    if exported and Path(exported).exists():
        st.download_button("Download " + Path(exported).name, Path(exported).read_bytes(), file_name=Path(exported).name,
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    st.info("Exported reports contain confidential financial information. Store them on an encrypted disk and share them carefully.")
    st.markdown("#### Blank templates")
    for template in sorted(config.TEMPLATE_DIR.glob("*.xlsx")):
        st.download_button(f"Download {template.name}", template.read_bytes(), file_name=template.name, key=template.name)


with st.sidebar:
    st.header("Navigation")
    page = st.radio("Page", PAGES, label_visibility="collapsed")
    st.caption("Offline - data never leaves this computer.")

{"1. Home": page_home, "2. Input Data": page_input, "3. Validation": page_validation, "4. Reconciliation": page_recon,
 "5. Adjustments and Eliminations": page_journals, "6. Financial Reports": page_reports, "7. Dashboard": page_dashboard,
 "8. Export": page_export}[page]()

