"""Consolidation engine: combines location trial balances, applies approved journals and
keeps every balance traceable to its source records.

The original trial balances are never altered, and no balance is ever forced to balance.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

import config
import financial_statements as fs
import reconciliation
from journals import JournalResult, elimination_summary, load_journals
from master_data import approved_mapping, load_master_data
from utils import aed
from validation import (CRITICAL, INFO, WARNING, issues_frame, make_issue, unmapped_report, usable_trial_balance,
                        validate_against_master, validate_folder)

log = logging.getLogger("consolidation")


class FinalisationBlocked(Exception):
    """Raised when final reports are requested while critical errors remain."""


@dataclass
class ConsolidationResult:
    folder: Path
    year: int
    period: str
    files: pd.DataFrame
    tb: pd.DataFrame                      # source records with FS_Line attached
    issues: pd.DataFrame
    coa: pd.DataFrame
    mapping: pd.DataFrame
    ib_map: pd.DataFrame
    journals: JournalResult
    location_totals: pd.DataFrame
    combined_before: pd.DataFrame
    adjusted: pd.DataFrame
    audit_trail: pd.DataFrame
    location_matrix: pd.DataFrame
    unmapped: pd.DataFrame
    recon: pd.DataFrame
    statements: fs.Statements
    statements_before: fs.Statements
    branch: pd.DataFrame
    finalised: bool = False
    run_id: int | None = None
    notes: list = field(default_factory=list)

    # ---- status
    @property
    def critical_count(self) -> int:
        return int((self.issues["Severity"] == CRITICAL).sum())

    @property
    def open_warning_count(self) -> int:
        i = self.issues
        return int(((i["Severity"] == WARNING) & (i["Resolution_Status"] == "Open")).sum())

    @property
    def unreconciled_count(self) -> int:
        return reconciliation.unreconciled_count(self.recon)

    @property
    def can_finalise(self) -> bool:
        return self.critical_count == 0

    def finalise(self) -> None:
        """Approve the reports. Refused while any critical error is unresolved."""
        if not self.can_finalise:
            raise FinalisationBlocked(f"{self.critical_count} critical validation error(s) must be resolved before final "
                                      "financial statements can be generated.")
        self.finalised = True
        log.info("Reports finalised: period=%s warnings_open=%s", self.period, self.open_warning_count)

    def require_final(self) -> None:
        if not self.finalised:
            raise FinalisationBlocked("Final reports have not been generated/approved yet.")

    def apply_reviews(self, reviews: dict[str, str]) -> None:
        """Mark warnings as reviewed (critical errors can never be marked reviewed)."""
        mask = (self.issues["Severity"] != CRITICAL) & self.issues["Issue_Key"].isin(reviews)
        self.issues.loc[mask, "Resolution_Status"] = "Reviewed"

    def scope_statements(self, locations: list[str]) -> fs.Statements:
        """Statements for any set of locations from the original (pre-adjustment) trial balances."""
        sub = self.tb[self.tb["Entity_Code"].isin(locations)]
        return fs.compute_statements(fs.net_by_line(sub), int(sub.loc[sub["FS_Line"].isna() | (sub["FS_Line"] == ""), "Net_Fils"].sum()))


# ---------------------------------------------------------------------------- core calculations
def attach_mapping(tb: pd.DataFrame, coa: pd.DataFrame, mapping: pd.DataFrame) -> pd.DataFrame:
    out = tb.merge(approved_mapping(mapping), on="Account_Code", how="left")
    out["Net_Fils"] = out["Debit_Fils"] - out["Credit_Fils"]
    out["FS_Line"] = out["FS_Line"].fillna("")
    return out


def location_totals(tb: pd.DataFrame, files: pd.DataFrame | None = None) -> pd.DataFrame:
    """Total debits and credits by location and whether each balances."""
    cols = ["Location", "Debit_Fils", "Credit_Fils", "Difference_Fils", "Status"]
    rows = []
    for loc in config.ALL_LOCATIONS:
        sub = tb[tb["Entity_Code"] == loc]
        if sub.empty:
            rows.append((loc, 0, 0, 0, "No data"))
            continue
        d, c = int(sub["Debit_Fils"].sum()), int(sub["Credit_Fils"].sum())
        rows.append((loc, d, c, d - c, "Balanced" if abs(d - c) <= config.BALANCE_TOLERANCE_FILS else "Out of balance"))
    return pd.DataFrame(rows, columns=cols)


def build_combined_tb(tb: pd.DataFrame, coa: pd.DataFrame) -> pd.DataFrame:
    """Combined trial balance before adjustments: standardised codes aggregated across locations."""
    cols = ["Account_Code", "Account_Description", "Reporting_Category", "Financial_Statement", "FS_Line",
            "Debit_Fils", "Credit_Fils", "Net_Fils", "Locations"]
    if tb.empty:
        return pd.DataFrame(columns=cols)
    grouped = tb.groupby("Account_Code", as_index=False).agg(
        Debit_Fils=("Debit_Fils", "sum"), Credit_Fils=("Credit_Fils", "sum"), Net_Fils=("Net_Fils", "sum"),
        Locations=("Entity_Code", "nunique"), FS_Line=("FS_Line", "first"), Source_Description=("Account_Description", "first"))
    grouped = grouped.merge(coa[["Account_Code", "Account_Description", "Reporting_Category", "Financial_Statement"]],
                            on="Account_Code", how="left")
    grouped["Account_Description"] = grouped["Account_Description"].fillna(grouped["Source_Description"])
    for col in ("Reporting_Category", "Financial_Statement"):
        grouped[col] = grouped[col].fillna("")
    return grouped[cols].sort_values("Account_Code").reset_index(drop=True)


def apply_journals(combined: pd.DataFrame, journals: JournalResult, coa: pd.DataFrame) -> pd.DataFrame:
    """Final adjusted trial balance: original + approved adjustments + approved eliminations."""
    applied = journals.applied_lines.copy()
    applied["Net"] = applied["Debit_Fils"] - applied["Credit_Fils"]
    adj = applied[applied["Journal_Type"] == "Adjustment"].groupby("Account_Code")["Net"].sum()
    eli = applied[applied["Journal_Type"] == "Elimination"].groupby("Account_Code")["Net"].sum()
    base = combined[["Account_Code", "Account_Description", "Reporting_Category", "Financial_Statement", "FS_Line", "Net_Fils"]]
    # accounts used only by journals still need a row
    extra = sorted((set(adj.index) | set(eli.index)) - set(base["Account_Code"]))
    if extra:
        add = coa[coa["Account_Code"].isin(extra)][["Account_Code", "Account_Description", "Reporting_Category", "Financial_Statement"]].copy()
        add["FS_Line"], add["Net_Fils"] = "", 0
        base = pd.concat([base, add], ignore_index=True)
    out = base.rename(columns={"Net_Fils": "Original_Net_Fils"}).copy()
    out["Adjustment_Net_Fils"] = out["Account_Code"].map(adj).fillna(0).astype("int64")
    out["Elimination_Net_Fils"] = out["Account_Code"].map(eli).fillna(0).astype("int64")
    out["Final_Net_Fils"] = out["Original_Net_Fils"] + out["Adjustment_Net_Fils"] + out["Elimination_Net_Fils"]
    out["Final_Debit_Fils"] = out["Final_Net_Fils"].clip(lower=0)
    out["Final_Credit_Fils"] = (-out["Final_Net_Fils"]).clip(lower=0)
    # fill FS_Line for journal-only accounts from the mapping where possible
    return out.sort_values("Account_Code").reset_index(drop=True)


def build_audit_trail(adjusted: pd.DataFrame, journals: JournalResult) -> pd.DataFrame:
    """One row per journal line: original, adjustment, elimination, final balance, reference, approval."""
    cols = ["Account_Code", "Account_Description", "Journal_ID", "Journal_Type", "Original_Balance_Fils", "Adjustment_Amount_Fils",
            "Elimination_Amount_Fils", "Final_Balance_Fils", "Proposed_Line_Amount_Fils", "Approval_Status",
            "Application_Status", "Supporting_Reference"]
    if journals.lines.empty:
        return pd.DataFrame(columns=cols)
    lines = journals.lines.copy()
    lines["Line"] = lines["Debit_Fils"] - lines["Credit_Fils"]
    merged = lines.merge(adjusted[["Account_Code", "Account_Description", "Original_Net_Fils", "Final_Net_Fils"]],
                         on="Account_Code", how="left")
    applied = merged["Application_Status"] == "Applied"
    merged["Adjustment_Amount_Fils"] = merged["Line"].where(applied & (merged["Journal_Type"] == "Adjustment"), 0)
    merged["Elimination_Amount_Fils"] = merged["Line"].where(applied & (merged["Journal_Type"] == "Elimination"), 0)
    merged = merged.rename(columns={"Original_Net_Fils": "Original_Balance_Fils", "Final_Net_Fils": "Final_Balance_Fils",
                                    "Line": "Proposed_Line_Amount_Fils"})
    return merged[cols].sort_values(["Journal_ID", "Account_Code"]).reset_index(drop=True)


def build_location_matrix(tb: pd.DataFrame) -> pd.DataFrame:
    """Account x location net balances, preserving location-level detail."""
    if tb.empty:
        return pd.DataFrame()
    pivot = tb.pivot_table(index=["Account_Code"], columns="Entity_Code", values="Net_Fils", aggfunc="sum", fill_value=0)
    pivot = pivot.reindex(columns=[c for c in config.ALL_LOCATIONS if c in pivot.columns])
    pivot["Total"] = pivot.sum(axis=1)
    return pivot.reset_index()


def trace_account(tb: pd.DataFrame, account_code: str) -> pd.DataFrame:
    """Source records (file, Excel row, location) behind a consolidated balance."""
    sub = tb[tb["Account_Code"] == account_code]
    return sub[["Account_Code", "Entity_Code", "Source_File", "Source_Row", "Debit_Fils", "Credit_Fils"]].reset_index(drop=True)


def source_file_summary(tbfiles) -> pd.DataFrame:
    rows = []
    for t in tbfiles:
        d = int(t.df["Debit_Fils"].sum()) if t.df is not None else 0
        c = int(t.df["Credit_Fils"].sum()) if t.df is not None else 0
        critical = sum(1 for i in t.issues if i["Severity"] == CRITICAL)
        rows.append((t.file_name, t.location, t.rows, d, c, d - c, "Read OK" if t.readable else "Not readable",
                     critical, t.sha256[:16]))
    return pd.DataFrame(rows, columns=["File_Name", "Location", "Rows", "Debit_Fils", "Credit_Fils", "Difference_Fils",
                                       "Read_Status", "Critical_Issues", "File_Fingerprint"])


# ---------------------------------------------------------------------------- pipeline
def run_pipeline(folder, year: int = config.DEFAULT_YEAR, manual_map: dict | None = None,
                 reviews: dict | None = None) -> ConsolidationResult:
    """Import, validate, consolidate, adjust, reconcile and prepare statements (preliminary)."""
    folder = Path(folder).expanduser().resolve()
    if not folder.is_dir():
        raise FileNotFoundError(f"Folder not found: {folder}")
    period = config.period_label(year)

    coa, mapping, ib_map, issues = load_master_data(folder)
    tbfiles, file_issues = validate_folder(folder, year, manual_map)
    issues += file_issues
    raw_tb = usable_trial_balance(tbfiles)
    issues += validate_against_master(raw_tb, coa, mapping, ib_map)

    tb = attach_mapping(raw_tb, coa, mapping) if not raw_tb.empty else raw_tb.assign(Net_Fils=0, FS_Line="")
    unmapped = unmapped_report(raw_tb, coa, mapping)

    journals = load_journals(folder, year, coa)
    issues += journals.issues

    combined = build_combined_tb(tb, coa)
    adjusted = apply_journals(combined, journals, coa)
    fs_map = dict(zip(*[approved_mapping(mapping)[c] for c in ("Account_Code", "FS_Line")]))
    adjusted["FS_Line"] = adjusted["FS_Line"].where(adjusted["FS_Line"] != "", adjusted["Account_Code"].map(fs_map)).fillna("")
    final_check = int(adjusted["Final_Net_Fils"].sum()) if not adjusted.empty else 0
    if final_check != 0:
        issues.append(make_issue("(consolidated)", "ALL", "Final trial balance does not balance",
                                 f"Adjusted trial balance differs by {aed(final_check):,.2f}.", CRITICAL,
                                 "Resolve location trial balance differences; balances are never forced.", abs(final_check)))

    # interbranch
    recon = reconciliation.reconcile(tb, ib_map, elimination_summary(journals.register))
    ib_codes = set(ib_map["Account_Code"])
    residual = int(adjusted.loc[adjusted["Account_Code"].isin(ib_codes), "Final_Net_Fils"].sum()) if not adjusted.empty else 0
    n_unrec = reconciliation.unreconciled_count(recon)
    if n_unrec:
        issues.append(make_issue("(interbranch)", "ALL", "Interbranch reconciliation", f"{n_unrec} interbranch pair(s) are not fully matched.",
                                 WARNING, "Review the Reconciliation page; differences are not adjusted automatically."))
    if residual != 0:
        issues.append(make_issue("(interbranch)", "ALL", "Interbranch not fully eliminated",
                                 f"Net interbranch balances of AED {aed(residual):,.2f} remain after approved eliminations.", WARNING,
                                 "Investigate differences and approve eliminations only for agreed amounts.", abs(residual)))

    unmapped_net = int(tb.loc[tb["FS_Line"] == "", "Net_Fils"].sum()) if not tb.empty else 0
    final_lines = adjusted.copy()
    final_lines["Net_Fils"] = final_lines["Final_Net_Fils"]
    statements = fs.compute_statements(fs.net_by_line(final_lines), unmapped_net)
    before_lines = adjusted.assign(Net_Fils=adjusted["Original_Net_Fils"])
    statements_before = fs.compute_statements(fs.net_by_line(before_lines), unmapped_net)

    issues_df = issues_frame(issues)
    result = ConsolidationResult(
        folder=folder, year=year, period=period, files=source_file_summary(tbfiles), tb=tb, issues=issues_df, coa=coa,
        mapping=mapping, ib_map=ib_map, journals=journals, location_totals=location_totals(tb), combined_before=combined,
        adjusted=adjusted, audit_trail=build_audit_trail(adjusted, journals), location_matrix=build_location_matrix(tb),
        unmapped=unmapped, recon=recon, statements=statements, statements_before=statements_before,
        branch=fs.branch_analysis(tb) if not tb.empty else pd.DataFrame())
    if reviews:
        result.apply_reviews(reviews)
    log.info("Pipeline run: period=%s files=%d critical=%d warnings=%d", period, len(tbfiles), result.critical_count,
             int((result.issues["Severity"] == WARNING).sum()))
    return result
