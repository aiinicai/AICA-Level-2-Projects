"""Interbranch reconciliation. Differences are reported, never written off or adjusted."""
from __future__ import annotations

import pandas as pd

import config

MATCHED = "Matched"
PARTIAL = "Partially matched"
UNMATCHED = "Unmatched"
INVESTIGATE = "Difference requiring investigation"

RECON_COLUMNS = ["Location", "Counterparty", "Receivable_Fils", "Payable_Fils", "Difference_Fils", "Difference_Pct",
                 "Status", "Supporting_Reference", "Approved_Elimination_Fils", "Journal_IDs"]


def classify(receivable: int, payable: int, tolerance: int = config.RECON_MATCH_TOLERANCE_FILS,
             threshold: float = config.RECON_PARTIAL_THRESHOLD) -> str:
    difference = receivable - payable
    if abs(difference) <= tolerance:
        return MATCHED
    if receivable == 0 or payable == 0:
        return UNMATCHED
    if abs(difference) / max(abs(receivable), abs(payable)) <= threshold:
        return PARTIAL
    return INVESTIGATE


def interbranch_positions(tb: pd.DataFrame, ib_map: pd.DataFrame) -> pd.DataFrame:
    """Per holding location and counterparty: net receivable and payable balances (fils)."""
    cols = ["Entity_Code", "Counterparty", "Direction", "Amount_Fils"]
    if tb.empty or ib_map.empty:
        return pd.DataFrame(columns=cols)
    joined = tb.merge(ib_map, on="Account_Code", how="inner")
    if joined.empty:
        return pd.DataFrame(columns=cols)
    joined["Net"] = joined["Debit_Fils"] - joined["Credit_Fils"]
    grouped = joined.groupby(["Entity_Code", "Counterparty_Location", "Direction"], as_index=False)["Net"].sum()
    grouped["Amount_Fils"] = grouped.apply(lambda r: r["Net"] if r["Direction"] == "Receivable" else -r["Net"], axis=1)
    return grouped.rename(columns={"Counterparty_Location": "Counterparty"})[cols]


def reconcile(tb: pd.DataFrame, ib_map: pd.DataFrame, eliminations: pd.DataFrame | None = None) -> pd.DataFrame:
    """Compare each receivable with the counterparty's reciprocal payable."""
    pos = interbranch_positions(tb, ib_map)
    receivables = {(r.Entity_Code, r.Counterparty): int(r.Amount_Fils) for r in pos[pos["Direction"] == "Receivable"].itertuples()}
    # payable held by Counterparty-of-record... stored as (payable holder, creditor) -> normalise to (creditor, holder)
    payables = {(r.Counterparty, r.Entity_Code): int(r.Amount_Fils) for r in pos[pos["Direction"] == "Payable"].itertuples()}
    elim = eliminations if eliminations is not None else pd.DataFrame(columns=["Journal_ID", "Related_Location", "Counterparty_Location",
                                                                              "Amount_Fils", "Supporting_Reference", "Application_Status"])
    rows = []
    for key in sorted(set(receivables) | set(payables)):
        rec, pay = receivables.get(key, 0), payables.get(key, 0)
        if rec == 0 and pay == 0:
            continue
        loc, cpty = key
        pair = elim[((elim["Related_Location"] == loc) & (elim["Counterparty_Location"] == cpty)) |
                    ((elim["Related_Location"] == cpty) & (elim["Counterparty_Location"] == loc))]
        applied = pair[pair["Application_Status"] == "Applied"]
        diff = rec - pay
        pct = abs(diff) / max(abs(rec), abs(pay)) * 100 if max(abs(rec), abs(pay)) else 0.0
        rows.append((loc, cpty, rec, pay, diff, round(pct, 2), classify(rec, pay),
                     "; ".join(x for x in pair["Supporting_Reference"].astype(str) if x), int(applied["Amount_Fils"].sum()),
                     ", ".join(pair["Journal_ID"].astype(str))))
    return pd.DataFrame(rows, columns=RECON_COLUMNS)


def unreconciled_count(recon: pd.DataFrame) -> int:
    return int((recon["Status"] != MATCHED).sum()) if not recon.empty else 0
