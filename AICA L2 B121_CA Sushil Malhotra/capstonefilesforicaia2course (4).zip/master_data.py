"""Chart of accounts, approved account mapping and interbranch account mapping."""
from __future__ import annotations

from pathlib import Path

import pandas as pd

import config
from validation import CRITICAL, WARNING, FileReadError, make_issue, read_table
from utils import standardise_code

COA_COLUMNS = ["Account_Code", "Account_Description", "Reporting_Category", "Financial_Statement",
               "Normal_Balance", "Active_Status"]
MAP_COLUMNS = ["Account_Code", "FS_Line", "Mapping_Status"]
IB_COLUMNS = ["Account_Code", "Direction", "Counterparty_Location"]


def _load(folder: Path, file_name: str, sheet: str, columns: list[str], issues: list[dict]) -> pd.DataFrame:
    path = Path(folder) / file_name
    try:
        df = read_table(path, sheet)
    except FileReadError as exc:
        issues.append(make_issue(file_name, "ALL", "Master data file", f"{file_name} cannot be read ({exc}).", CRITICAL,
                                 f"Place a valid {file_name} in the input folder."))
        return pd.DataFrame(columns=columns)
    df.columns = [str(c).strip() for c in df.columns]
    missing = [c for c in columns if c not in df.columns]
    if missing:
        issues.append(make_issue(file_name, "ALL", "Master data columns", f"Sheet '{sheet}' is missing column(s): {', '.join(missing)}.",
                                 CRITICAL, "Use the chart_of_accounts_template.xlsx layout."))
        return pd.DataFrame(columns=columns)
    df = df[columns].dropna(how="all").fillna("").astype(str)
    df["Account_Code"] = df["Account_Code"].map(standardise_code)
    for col in columns[1:]:
        df[col] = df[col].str.strip()
    return df.reset_index(drop=True)


def load_master_data(folder: Path) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, list[dict]]:
    """Returns (coa, approved-or-not mapping, interbranch mapping, issues)."""
    issues: list[dict] = []
    coa = _load(folder, config.COA_FILE, "Chart_of_Accounts", COA_COLUMNS, issues)
    mapping = _load(folder, config.MAPPING_FILE, "Account_Mapping", MAP_COLUMNS, issues)
    ib = _load(folder, config.MAPPING_FILE, "Interbranch_Accounts", IB_COLUMNS, issues)

    for code, grp in coa[coa.duplicated("Account_Code", keep=False)].groupby("Account_Code"):
        issues.append(make_issue(config.COA_FILE, "ALL", "Duplicate chart account", f"Account {code} appears {len(grp)} times in the chart of accounts.",
                                 CRITICAL, "Keep one row per account code."))
    bad = coa[~coa["Normal_Balance"].isin(["Debit", "Credit"]) | ~coa["Financial_Statement"].isin(["BS", "PL"])]
    for _, row in bad.iterrows():
        issues.append(make_issue(config.COA_FILE, "ALL", "Chart of accounts values",
                                 f"Account {row['Account_Code']}: Normal_Balance must be Debit/Credit and Financial_Statement BS/PL.",
                                 CRITICAL, "Correct the chart of accounts."))

    for code, grp in mapping[mapping.duplicated("Account_Code", keep=False)].groupby("Account_Code"):
        issues.append(make_issue(config.MAPPING_FILE, "ALL", "Duplicate account mapping", f"Account {code} is mapped {len(grp)} times.",
                                 CRITICAL, "Keep one mapping row per account."))
    fs_of = dict(zip(coa["Account_Code"], coa["Financial_Statement"]))
    for _, row in mapping.iterrows():
        if row["FS_Line"] not in config.VALID_FS_LINES:
            issues.append(make_issue(config.MAPPING_FILE, "ALL", "Invalid statement line",
                                     f"Account {row['Account_Code']} is mapped to unknown line '{row['FS_Line']}'.", CRITICAL,
                                     "Map to one of the lines listed in config.py (Valid_FS_Lines sheet in the template)."))
        elif row["Account_Code"] in fs_of and fs_of[row["Account_Code"]] != config.FS_LINE_STATEMENT[row["FS_Line"]]:
            issues.append(make_issue(config.MAPPING_FILE, "ALL", "Mapping conflicts with chart",
                                     f"Account {row['Account_Code']} is a {fs_of[row['Account_Code']]} account but is mapped to '{row['FS_Line']}'.",
                                     CRITICAL, "Correct the mapping or the chart of accounts."))
        if row["Mapping_Status"].lower() != "approved":
            issues.append(make_issue(config.MAPPING_FILE, "ALL", "Mapping not approved",
                                     f"Mapping for account {row['Account_Code']} has status '{row['Mapping_Status']}' and is ignored.", WARNING,
                                     "Approve the mapping (Mapping_Status = Approved)."))
    for _, row in ib.iterrows():
        if row["Counterparty_Location"] not in config.ALL_LOCATIONS or row["Direction"] not in ("Receivable", "Payable"):
            issues.append(make_issue(config.MAPPING_FILE, "ALL", "Interbranch mapping values",
                                     f"Account {row['Account_Code']}: invalid direction or counterparty '{row['Counterparty_Location']}'.",
                                     CRITICAL, "Direction must be Receivable/Payable and counterparty a configured location."))
    return coa, mapping, ib, issues


def approved_mapping(mapping: pd.DataFrame) -> pd.DataFrame:
    """Only approved, valid rows are ever used in statements."""
    ok = mapping["Mapping_Status"].str.lower().eq("approved") & mapping["FS_Line"].isin(config.VALID_FS_LINES)
    return mapping[ok].drop_duplicates("Account_Code", keep=False)[["Account_Code", "FS_Line"]]
