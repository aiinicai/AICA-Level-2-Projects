# Financial Consolidation - Head Office + 20 Branches (ABC Trading LLC, fictitious)

A local Windows application that reads 21 Excel trial balances (HO, BR01-BR20), validates them, combines them,
applies **approved** adjustment/elimination journals, reconciles interbranch balances, prepares the Statement of
Profit or Loss and Statement of Financial Position, and exports an Excel workbook. Data is held in a local
**SQLite** file (`data/consolidation.db`). All data in this package is **fictitious**.

## 1. Architecture and assumptions

| File | Purpose |
|---|---|
| `app.py` | Streamlit interface (8 pages). No accounting logic. |
| `validation.py` | Reads and validates each trial balance file; cross-file controls (missing/duplicate locations); unmapped-account report. |
| `master_data.py` | Loads/validates Chart of Accounts, Account Mapping, Interbranch account mapping. |
| `journals.py` | Validates journals; decides which may affect final reports. |
| `consolidation_engine.py` | Aggregation, adjusted trial balance, audit trail, traceability, the end-to-end pipeline, finalisation gate. |
| `reconciliation.py` | Interbranch matching and classification. |
| `financial_statements.py` | P&L, Statement of Financial Position, branch analysis and comparisons. |
| `reporting.py` | Formatted Excel workbook (`ABC_Consolidated_Financial_Statements.xlsx`, 12 required sheets + `Location_TB_Matrix`). |
| `db.py` | SQLite storage: run history, validation issues, consolidated balances, journals, warning reviews. |
| `sample_data_generator.py` | Deterministic fictitious data and the Excel templates. |
| `config.py` / `utils.py` | Settings (company, year, tolerances, statement lines) and decimal-safe helpers. |
| `.streamlit/config.toml` | Telemetry off, server bound to `127.0.0.1`. |

Accounting assumptions (change in `config.py` where noted):
* One legal entity with a Head Office and branches: output is **combined financial statements**, not IFRS 10 consolidation. Subsidiary consolidation could later be added by extending the location list and journals.
* AED only. Foreign-currency files are rejected, not translated.
* Money is stored as integer **fils** (1/100 AED) so sums are exact. Trial balances must balance exactly (`BALANCE_TOLERANCE_FILS`).
* Financial year defaults to 1 Jan-31 Dec (`FY_START_MONTH`); the year is chosen in the app. Files must carry `Financial_Period` such as `FY2025`.
* Accounts reach the statements **only** through `Account_Mapping.xlsx` with `Mapping_Status = Approved`. Descriptions are never used to guess a mapping.
* Interbranch status: *Matched* (difference 0); *Partially matched* (both sides recorded, difference <= 5% of the larger, `RECON_PARTIAL_THRESHOLD`); *Difference requiring investigation* (> 5%); *Unmatched* (one side zero). Differences are never adjusted.
* A journal with a `Counterparty_Location` is an **Elimination**; otherwise an **Adjustment**. Eliminations touching profit or loss accounts are excluded unless `ALLOW_PL_ELIMINATIONS = True`.
* Gross profit margin = gross profit / net revenue, shown only when net revenue > 0. Branch analysis uses the original location trial balances (before journals); the combined result in the statements is after approved journals.
* Accounting figures and calculated ratios are labelled separately (`Pct` columns / brown headers in Excel).

## 2. Severity and blocking rules
* **Critical** (blocks "Generate Consolidated Financial Statements"): unreadable file, missing/duplicate/unidentified location, missing columns, blank account code, non-numeric or negative amount, unbalanced trial balance, unexpected period/currency, unmapped account, missing counterparty mapping, approved-but-defective journal, unbalanced final trial balance.
* **Warning** (can be marked *Reviewed*, does not block): duplicate account record, unapproved journal, interbranch differences, P&L elimination not configured, inactive account with balance.

## 3. Install and run (Windows, step by step)

1. Install Python 3.11 or newer from <https://www.python.org/downloads/>. Tick **"Add python.exe to PATH"**.
2. Copy the `financial_consolidation` folder anywhere (for example `C:\financial_consolidation`).
3. **Double-click `install_dependencies.bat`** (internet needed, once). It creates the virtual environment `.venv`, installs the packages in `requirements.txt` and generates the sample data and templates.
   *Manual equivalent:*
   ```bat
   py -3 -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   python sample_data_generator.py --errors
   ```
4. (Optional) **Double-click `run_tests.bat`** to run the automated tests.
5. **Double-click `run_app.bat`**. The browser opens at <http://127.0.0.1:8501>. Keep the black window open; close it to stop the app.
6. `generate_sample_data.bat` re-creates the fictitious files at any time (same seed = identical data).

## 4. Using the application
1. **Input Data** - folder defaults to `sample_data`; press *Browse...* to choose another. Press **Load and validate files**. Files without a recognisable location can be assigned manually.
2. **Validation** - review critical errors and warnings; mark reviewed warnings (stored in SQLite). Fix critical errors in Excel and reload.
3. **Reconciliation** - review interbranch differences; create the Excel reconciliation report.
4. **Adjustments and Eliminations** - approved vs not applied journals, and the audit trail.
5. **Financial Reports** - press **Generate Consolidated Financial Statements** (disabled while critical errors exist). Choose scope: final combined, HO, all branches, any single branch.
6. **Dashboard** - KPIs and Plotly charts, filter by location.
7. **Export** - *Create Excel workbook* writes `output/ABC_Consolidated_Financial_Statements.xlsx` (never into the source folder) and offers a download.

Folder contents expected: `HO.xlsx`, `BR01.xlsx`..`BR20.xlsx` (columns `Entity_Code, Account_Code, Account_Description, Debit, Credit, Currency, Financial_Period`; the last three and `Entity_Code` are optional but flagged), `Chart_of_Accounts.xlsx`, `Account_Mapping.xlsx` (sheets `Account_Mapping`, `Interbranch_Accounts`), `Elimination_Journals.xlsx`. Blank templates are in `templates/`.

## 5. What the sample data contains (for the demo)
* `sample_data` - 21 balanced trial balances, no critical errors. Deliberate talking points: HO/BR01 interbranch AED 500,000 vs 480,000 (AED 20,000 difference, partially matched); BR05 unmatched; BR07 AED 250,000 vs 150,000 (investigate); BR13 negative gross profit (flagged, unchanged); one unapproved elimination (BR07) and one unapproved adjustment; one approved elimination touching P&L that is correctly *not* applied; a multi-line approved journal.
* `sample_data_with_errors` - faults for showing the controls: unbalanced BR07, unmapped account BR11, blank code BR18, duplicate row BR09, text amount BR12, negative amount BR02, missing BR14, duplicate file BR16, corrupt BR19. "Generate" stays disabled.

## 6. Offline demonstration (15-minute script)
1. (Connected) run `install_dependencies.bat`. 2. Sample data is generated by that step. 3. Start `run_app.bat`.
4. **Disconnect Wi-Fi/Ethernet.** 5. Input Data -> Load and validate; show Validation (0 critical, 5 warnings), Reconciliation, Adjustments.
6. Financial Reports -> Generate; Dashboard; Export -> open the workbook. 7. Load `sample_data_with_errors` to show blocking.
Say that using ChatGPT/Claude to **write or debug code** is a separate activity from **running** the app; never paste real confidential accounting data into any AI chat.

## 7. Confidentiality - what is and is not claimed
* The code contains no network calls, APIs, keys, CDN/remote fonts or telemetry (Streamlit usage stats disabled; the server listens on `127.0.0.1` only). `tests/test_offline.py` blocks sockets and runs the full workflow, and scans the source for network imports.
* Not tested here: packages' internal behaviour beyond the above, and the Streamlit browser front-end's own bundled assets. Dependencies are installed in advance; nothing is installed at run time.
* **Offline is not the same as secure.** Use a password-protected, disk-encrypted (BitLocker) laptop with restricted user access; handle exported reports and `data/consolidation.db` as confidential; logs (`logs/app.log`) contain only counts, rule names and file names, not balances.

## 8. Troubleshooting
| Problem | Fix |
|---|---|
| "Python was not found" | Reinstall Python and tick *Add to PATH*; reopen the window. |
| `pip` fails | Connect to the internet and run `install_dependencies.bat` again; check proxy/firewall. |
| Browser shows nothing | Wait 10 s and refresh <http://127.0.0.1:8501>; make sure the black window is still open. |
| Port 8501 busy | Close the other copy, or add `--server.port 8502` in `run_app.bat`. |
| "Cannot write ... open in Excel" | Close the workbook in Excel, export again. |
| Folder *Browse...* does nothing | Paste the folder path into the text box. |
| Unmapped account | Add it to `Chart_of_Accounts.xlsx` and `Account_Mapping.xlsx` (Approved) and reload. |
| Location not detected | Name the file `BR07.xlsx` etc., add `Entity_Code`, or assign it manually on Input Data. |

## 9. Tests
`run_tests.bat` (or `.venv\Scripts\python -m pytest -v`). Covers all 18 required scenarios; see `tests/`. Results are only valid for the run you perform.
