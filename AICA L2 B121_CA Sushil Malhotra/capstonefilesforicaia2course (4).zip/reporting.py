"""Excel output workbook. Reports are written to a separate output folder and never over the source files."""
from __future__ import annotations

import logging
from datetime import datetime
from pathlib import Path

import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

import config
import financial_statements as fs
from consolidation_engine import ConsolidationResult
from utils import aed, to_aed_frame

log = logging.getLogger("consolidation")

AED_FMT = '#,##0.00;[Red](#,##0.00);"-"'
PCT_FMT = '0.00"%"'
HEADER_FILL = PatternFill("solid", fgColor="1F3864")
RATIO_FILL = PatternFill("solid", fgColor="7F6000")
RED, AMBER, GREEN, GREY = (PatternFill("solid", fgColor=c) for c in ("F8CBAD", "FFE699", "C6E0B4", "EDEDED"))
THIN = Side(style="thin", color="808080")


class ReportExportError(Exception):
    """The workbook could not be written (for example it is open in Excel)."""


def _title(ws, result: ConsolidationResult, title: str) -> int:
    ws["A1"] = config.COMPANY_NAME
    ws["A1"].font = Font(bold=True, size=14, color="1F3864")
    ws["A2"] = title
    ws["A2"].font = Font(bold=True, size=12)
    start, end = config.period_dates(result.year)
    ws["A3"] = f"Reporting period: {result.period} ({start:%d %b %Y} to {end:%d %b %Y}) | Currency: {config.CURRENCY} | Generated {datetime.now():%Y-%m-%d %H:%M}"
    ws["A3"].font = Font(italic=True, color="595959")
    return 5


def _table(ws, df: pd.DataFrame, row: int, money=(), pct=(), ratio_cols=(), totals: list[str] | None = None,
           flag_col: str | None = None, filter_: bool = True) -> int:
    """Write a DataFrame with header, formats, optional totals row. Returns the next free row."""
    for c, name in enumerate(df.columns, start=1):
        cell = ws.cell(row=row, column=c, value=name.replace("_", " "))
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = RATIO_FILL if name in ratio_cols else HEADER_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    first = row + 1
    for r, values in enumerate(df.itertuples(index=False), start=first):
        for c, value in enumerate(values, start=1):
            if value is pd.NA or (isinstance(value, float) and pd.isna(value)):
                value = None
            elif hasattr(value, "item"):
                value = value.item()
            cell = ws.cell(row=r, column=c, value=value)
            col = df.columns[c - 1]
            if col in money:
                cell.number_format = AED_FMT
            elif col in pct:
                cell.number_format = PCT_FMT
        if flag_col and flag_col in df.columns:
            text = str(values[list(df.columns).index(flag_col)])
            fill = None
            if text in ("Critical", "Out of balance", "Unmatched", "Rejected", "Difference requiring investigation", "Not readable") or text.startswith("Negative"):
                fill = RED
            elif text in ("Warning", "Partially matched", "Not applied - not approved") or text.startswith("Operating loss"):
                fill = AMBER
            elif text in ("Matched", "Balanced", "Applied", "Read OK"):
                fill = GREEN
            if fill:
                ws.cell(row=r, column=list(df.columns).index(flag_col) + 1).fill = fill
    last = first + len(df) - 1
    if filter_ and len(df):
        ws.auto_filter.ref = f"A{row}:{get_column_letter(len(df.columns))}{last}"
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    nxt = last + 1
    if totals and len(df):
        ws.cell(row=nxt, column=1, value="Total").font = Font(bold=True)
        for name in totals:
            c = list(df.columns).index(name) + 1
            cell = ws.cell(row=nxt, column=c, value=round(float(df[name].sum()), 2))
            cell.number_format = AED_FMT
            cell.font = Font(bold=True)
            cell.border = Border(top=THIN, bottom=Side(style="double", color="808080"))
        nxt += 1
    for c, name in enumerate(df.columns, start=1):
        sample = [len(str(name))] + [len(f"{v:,.2f}") if isinstance(v, float) else len(str(v)) for v in df[name].head(100)]
        ws.column_dimensions[get_column_letter(c)].width = min(max(12, max(sample) + 2), 55)
    return nxt + 1


def _statement(ws, df: pd.DataFrame, row: int) -> int:
    ws.cell(row=row, column=1, value="Line").font = Font(bold=True, color="FFFFFF")
    ws.cell(row=row, column=2, value="Amount (AED)").font = Font(bold=True, color="FFFFFF")
    for c in (1, 2):
        ws.cell(row=row, column=c).fill = HEADER_FILL
    for r, rec in enumerate(df.itertuples(index=False), start=row + 1):
        label = ws.cell(row=r, column=1, value=rec.Line)
        amount = ws.cell(row=r, column=2, value=rec.Amount_AED)
        amount.number_format = AED_FMT
        if rec.Row_Type != "line":
            for cell in (label, amount):
                cell.font = Font(bold=True)
                cell.border = Border(top=THIN, bottom=THIN if rec.Row_Type == "total" else None)
        else:
            label.alignment = Alignment(indent=1)
    ws.column_dimensions["A"].width = 44
    ws.column_dimensions["B"].width = 20
    ws.freeze_panes = ws.cell(row=row + 1, column=1)
    return row + len(df) + 2


def _display_issues(issues: pd.DataFrame) -> pd.DataFrame:
    return to_aed_frame(issues.drop(columns=["Issue_Key"]))


def build_workbook(result: ConsolidationResult, path: Path | None = None) -> Path:
    """Create ABC_Consolidated_Financial_Statements.xlsx. Only allowed after the reports were finalised."""
    result.require_final()
    path = Path(path) if path else config.OUTPUT_DIR / config.OUTPUT_WORKBOOK_NAME
    path = path.resolve()
    if path.parent == result.folder or path.suffix.lower() != ".xlsx":
        raise ReportExportError("Reports must be saved as .xlsx in an output folder that is different from the source data folder.")
    wb = Workbook()
    wb.remove(wb.active)
    st = result.statements

    # 1 Executive summary
    ws = wb.create_sheet("Executive_Summary")
    r = _title(ws, result, "Executive Summary - Combined Financial Statements (Head Office and Branches)")
    f = st.figures
    kpis = [("Net revenue", aed(f["net_revenue"])), ("Gross profit", aed(f["gross_profit"])),
            ("Gross profit margin (calculated ratio)", None if f["gross_margin"] is None else round(f["gross_margin"] * 100, 2)),
            ("Operating profit", aed(f["operating_profit"])), ("Profit before tax", aed(f["profit_before_tax"])),
            ("Profit for the period", aed(f["profit"])), ("Total assets", aed(f["total_assets"])),
            ("Total liabilities", aed(f["total_liabilities"])), ("Total equity", aed(f["total_equity"]))]
    ws.cell(row=r, column=1, value="Key figures (accounting, AED)").font = Font(bold=True)
    for i, (label, value) in enumerate(kpis, start=r + 1):
        ws.cell(row=i, column=1, value=label)
        cell = ws.cell(row=i, column=2, value=value)
        cell.number_format = PCT_FMT if "margin" in label else AED_FMT
    r = r + len(kpis) + 2
    ws.cell(row=r, column=1, value="Control summary").font = Font(bold=True)
    checks = [
        ("Locations processed", f"{result.tb['Entity_Code'].nunique()} of {len(config.ALL_LOCATIONS)}", True),
        ("Unresolved critical validation errors", result.critical_count, result.critical_count == 0),
        ("Open warnings (not yet reviewed)", result.open_warning_count, result.open_warning_count == 0),
        ("Every location trial balance balances", "Yes" if (result.location_totals["Status"] == "Balanced").all() else "No",
         bool((result.location_totals["Status"] == "Balanced").all())),
        ("Final adjusted trial balance balances", "Yes" if int(result.adjusted["Final_Net_Fils"].sum()) == 0 else "No",
         int(result.adjusted["Final_Net_Fils"].sum()) == 0),
        ("Statement of financial position balances", "Yes" if f["bs_difference"] == 0 else "No", f["bs_difference"] == 0),
        ("Unreconciled interbranch pairs", result.unreconciled_count, result.unreconciled_count == 0),
        ("Unmapped accounts", len(result.unmapped), result.unmapped.empty),
        ("Approved journals applied", int((result.journals.register["Application_Status"] == "Applied").sum()) if not result.journals.register.empty else 0, True),
        ("Journals not applied (unapproved or rejected)", int((result.journals.register["Application_Status"] != "Applied").sum()) if not result.journals.register.empty else 0,
         result.journals.register.empty or bool((result.journals.register["Application_Status"] == "Applied").all())),
    ]
    for i, (label, value, ok) in enumerate(checks, start=r + 1):
        ws.cell(row=i, column=1, value=label)
        cell = ws.cell(row=i, column=2, value=value)
        cell.fill = GREEN if ok else AMBER
    r += len(checks) + 2
    ws.cell(row=r, column=1, value="Statement warnings").font = Font(bold=True)
    for i, text in enumerate(st.warnings or ["None"], start=r + 1):
        ws.cell(row=i, column=1, value=text)
    ws.column_dimensions["A"].width = 52
    ws.column_dimensions["B"].width = 22

    # 2 Consolidated TB
    ws = wb.create_sheet("Consolidated_TB")
    r = _title(ws, result, "Consolidated Trial Balance - before and after approved adjustments and eliminations")
    tb = to_aed_frame(result.adjusted[["Account_Code", "Account_Description", "Reporting_Category", "FS_Line", "Original_Net_Fils",
                                       "Adjustment_Net_Fils", "Elimination_Net_Fils", "Final_Debit_Fils", "Final_Credit_Fils"]])
    _table(ws, tb, r, money=[c for c in tb.columns if c.endswith("_AED")], totals=["Original_Net_AED", "Adjustment_Net_AED",
           "Elimination_Net_AED", "Final_Debit_AED", "Final_Credit_AED"])

    # 3-4 statements
    ws = wb.create_sheet("Profit_and_Loss")
    r = _title(ws, result, "Statement of Profit or Loss")
    _statement(ws, fs.statements_frame(st.pl), r)
    ws = wb.create_sheet("Balance_Sheet")
    r = _title(ws, result, "Statement of Financial Position")
    nxt = _statement(ws, fs.statements_frame(st.bs), r)
    ws.cell(row=nxt, column=1, value="Check: total assets less total liabilities and equity")
    cell = ws.cell(row=nxt, column=2, value=aed(f["bs_difference"]))
    cell.number_format = AED_FMT
    cell.fill = GREEN if f["bs_difference"] == 0 else RED

    # 5 branch analysis
    ws = wb.create_sheet("Branch_Analysis")
    r = _title(ws, result, "Branch-wise analysis (original location trial balances, before consolidation journals)")
    ws.cell(row=r, column=1, value="Blue headers = accounting figures (AED). Brown headers = calculated management ratios.").font = Font(italic=True)
    if not result.branch.empty:
        _table(ws, result.branch, r + 1, money=fs.ACCOUNTING_COLS, pct=fs.RATIO_COLS, ratio_cols=fs.RATIO_COLS, totals=fs.ACCOUNTING_COLS)
        for row in ws.iter_rows(min_row=r + 2, max_row=r + 1 + len(result.branch)):
            if row[-1].value:
                row[-1].fill = RED

    # 6 interbranch
    ws = wb.create_sheet("Interbranch_Reconciliation")
    r = _title(ws, result, "Interbranch Reconciliation (differences are reported, not adjusted)")
    _write_recon(ws, result, r)

    # 7-8 journals
    reg = result.journals.register
    adj = reg[reg["Journal_Type"] == "Adjustment"] if not reg.empty else reg
    eli = reg[reg["Journal_Type"] == "Elimination"] if not reg.empty else reg
    for name, frame, title in (("Adjustments", adj, "Adjustment Journal Register"), ("Eliminations", eli, "Elimination Journal Register")):
        ws = wb.create_sheet(name)
        r = _title(ws, result, title + " - only approved, balanced journals are applied")
        frame = to_aed_frame(frame) if not frame.empty else frame
        _table(ws, frame, r, money=["Amount_AED"], flag_col="Application_Status")

    # 9-10 issues
    ws = wb.create_sheet("Validation_Errors")
    r = _title(ws, result, "Data Validation Report")
    _table(ws, _display_issues(result.issues), r, money=["Amount_AED"], flag_col="Severity")
    ws = wb.create_sheet("Unmapped_Accounts")
    r = _title(ws, result, "Unmapped Account Report")
    um = to_aed_frame(result.unmapped)
    _table(ws, um, r, money=["Debit_AED", "Credit_AED"])
    if um.empty:
        ws.cell(row=r + 2, column=1, value="No unmapped accounts.")

    # 11 audit trail
    ws = wb.create_sheet("Audit_Trail")
    r = _title(ws, result, "Audit Trail - original balance, adjustment, elimination, final balance")
    at = to_aed_frame(result.audit_trail)
    _table(ws, at, r, money=[c for c in at.columns if c.endswith("_AED")], flag_col="Application_Status")

    # 12 source summary
    ws = wb.create_sheet("Source_File_Summary")
    r = _title(ws, result, "Source File Summary (source files are never modified)")
    sf = to_aed_frame(result.files)
    _table(ws, sf, r, money=["Debit_AED", "Credit_AED", "Difference_AED"], flag_col="Read_Status", totals=["Debit_AED", "Credit_AED"])

    # extra: location detail
    ws = wb.create_sheet("Location_TB_Matrix")
    r = _title(ws, result, "Net balance by account and location (debit positive, credit negative)")
    mat = result.location_matrix.copy()
    for c in mat.columns[1:]:
        mat[c] = (mat[c] / 100).round(2)
    _table(ws, mat, r, money=list(mat.columns[1:]))

    _save(wb, path)
    log.info("Excel workbook written: %s", path.name)
    return path


def _write_recon(ws, result: ConsolidationResult, row: int) -> None:
    rec = to_aed_frame(result.recon)
    _table(ws, rec, row, money=["Receivable_AED", "Payable_AED", "Difference_AED", "Approved_Elimination_AED"], pct=["Difference_Pct"],
           flag_col="Status", totals=["Receivable_AED", "Payable_AED", "Difference_AED"])


def _save(wb: Workbook, path: Path) -> None:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        wb.save(path)
    except PermissionError as exc:
        raise ReportExportError(f"Cannot write {path.name}. Close the file if it is open in Excel and try again.") from exc
    except OSError as exc:
        raise ReportExportError(f"The workbook could not be saved: {exc.strerror or exc}") from exc


def build_reconciliation_workbook(result: ConsolidationResult, path: Path | None = None) -> Path:
    path = (Path(path) if path else config.OUTPUT_DIR / config.RECON_WORKBOOK_NAME).resolve()
    if path.parent == result.folder:
        raise ReportExportError("Choose an output folder different from the source data folder.")
    wb = Workbook()
    ws = wb.active
    ws.title = "Interbranch_Reconciliation"
    _write_recon(ws, result, _title(ws, result, "Interbranch Reconciliation Report"))
    _save(wb, path)
    return path
