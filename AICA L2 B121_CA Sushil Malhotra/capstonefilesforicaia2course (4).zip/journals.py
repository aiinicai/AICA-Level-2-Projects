"""Approved elimination / adjustment journals.

Only journals that are approved, balanced and valid reach the final reports.
The original trial balances are never modified.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

import config
from utils import is_blank, parse_amount, standardise_code
from validation import CRITICAL, WARNING, FileReadError, make_issue, read_table

JOURNAL_COLUMNS = ["Journal_ID", "Journal_Date", "Financial_Period", "Debit_Account", "Credit_Account", "Amount",
                   "Currency", "Description", "Related_Location", "Counterparty_Location", "Approval_Status",
                   "Approved_By", "Approval_Date", "Supporting_Reference"]
REGISTER_COLUMNS = ["Journal_ID", "Journal_Type", "Journal_Date", "Financial_Period", "Debit_Account", "Credit_Account",
                    "Amount_Fils", "Currency", "Description", "Related_Location", "Counterparty_Location",
                    "Approval_Status", "Approved_By", "Approval_Date", "Supporting_Reference", "Application_Status", "Reason"]
LINE_COLUMNS = ["Journal_ID", "Journal_Type", "Account_Code", "Debit_Fils", "Credit_Fils", "Approval_Status",
                "Application_Status", "Supporting_Reference", "Related_Location", "Counterparty_Location"]
APPLIED, NOT_APPROVED, REJECTED = "Applied", "Not applied - not approved", "Rejected"


@dataclass
class JournalResult:
    register: pd.DataFrame = field(default_factory=lambda: pd.DataFrame(columns=REGISTER_COLUMNS))
    lines: pd.DataFrame = field(default_factory=lambda: pd.DataFrame(columns=LINE_COLUMNS))
    issues: list = field(default_factory=list)

    @property
    def applied_lines(self) -> pd.DataFrame:
        return self.lines[self.lines["Application_Status"] == APPLIED]


def process_journals(frame: pd.DataFrame | None, year: int, coa: pd.DataFrame, fs_by_account: dict[str, str] | None = None,
                     source: str = config.JOURNAL_FILE) -> JournalResult:
    """Validate journal rows and decide which journals may affect the final reports."""
    result = JournalResult()
    if frame is None or frame.empty:
        return result
    period = config.period_label(year)
    aliases = config.period_aliases(year)
    known = set(coa["Account_Code"])
    inactive = set(coa.loc[coa["Active_Status"].str.lower() != "active", "Account_Code"])
    fs_by_account = fs_by_account or dict(zip(coa["Account_Code"], coa["Financial_Statement"]))
    frame = frame.copy()
    frame.columns = [str(c).strip() for c in frame.columns]
    missing = [c for c in JOURNAL_COLUMNS if c not in frame.columns]
    if missing:
        result.issues.append(make_issue(source, "ALL", "Journal columns", f"Missing column(s): {', '.join(missing)}.", CRITICAL,
                                        "Use elimination_journal_template.xlsx."))
        return result

    register_rows, line_rows = [], []
    frame = frame.dropna(how="all")
    for jid_raw, grp in frame.groupby(frame["Journal_ID"].map(lambda v: "" if is_blank(v) else str(v).strip()), sort=False):
        if jid_raw == "":
            result.issues.append(make_issue(source, "ALL", "Journal without ID", f"{len(grp)} journal row(s) have no Journal_ID and were ignored.",
                                            CRITICAL, "Give every journal row a Journal_ID."))
            continue
        jid = jid_raw
        defects: list[str] = []
        posting, total_dr, total_cr = [], 0, 0
        for _, row in grp.iterrows():
            amount, problem = parse_amount(row["Amount"])
            dr, cr = standardise_code(row["Debit_Account"]), standardise_code(row["Credit_Account"])
            if problem or amount is None or amount <= 0:
                defects.append("amount missing, non-numeric or not positive")
                amount = 0
            if not dr and not cr:
                defects.append("line has no account")
            for code in (dr, cr):
                if code and code not in known:
                    defects.append(f"account {code} not in chart of accounts")
            if dr:
                total_dr += amount
                posting.append((dr, amount, 0))
            if cr:
                total_cr += amount
                posting.append((cr, 0, amount))
            if not is_blank(row["Currency"]) and standardise_code(row["Currency"]) != config.CURRENCY:
                defects.append("currency is not AED")
            fin_period = "" if is_blank(row["Financial_Period"]) else str(row["Financial_Period"]).strip().upper()
            if fin_period not in aliases:
                defects.append(f"period '{row['Financial_Period']}' does not match {period}")
        if total_dr != total_cr:
            defects.append(f"journal does not balance (debits {total_dr / 100:,.2f}, credits {total_cr / 100:,.2f})")

        statuses = {str(s).strip().lower() for s in grp["Approval_Status"]}
        approved_flag = statuses == {"approved"}
        if len(statuses) > 1 and "approved" in statuses:
            defects.append("lines carry different approval statuses")
            approved_flag = False
        approver_ok = all(not is_blank(v) for v in grp["Approved_By"]) and all(not is_blank(v) for v in grp["Approval_Date"])
        counter = {standardise_code(v) for v in grp["Counterparty_Location"] if not is_blank(v)}
        related = {standardise_code(v) for v in grp["Related_Location"] if not is_blank(v)}
        jtype = "Elimination" if counter else "Adjustment"
        if counter and (not counter <= set(config.ALL_LOCATIONS) or not related <= set(config.ALL_LOCATIONS) or not related):
            defects.append("missing or invalid related/counterparty location for an elimination")

        touches_pl = any(fs_by_account.get(code) == "PL" for code, _, _ in posting)
        reason = ""
        if approved_flag and not approver_ok:
            status, reason = NOT_APPROVED, "Marked Approved but Approved_By or Approval_Date is blank"
            result.issues.append(make_issue(source, "ALL", "Journal approval incomplete", f"{jid}: status Approved without approver/date; not applied.",
                                            WARNING, "Complete Approved_By and Approval_Date."))
        elif not approved_flag:
            status, reason = NOT_APPROVED, "Approval_Status is not Approved"
            result.issues.append(make_issue(source, "ALL", "Unapproved journal", f"{jid}: not approved ({', '.join(sorted(statuses)) or 'blank'}); excluded from reports.",
                                            WARNING, "Approve the journal if it should affect the final reports."))
            if defects:
                result.issues.append(make_issue(source, "ALL", "Journal defect", f"{jid}: {'; '.join(sorted(set(defects)))}.", WARNING,
                                                "Correct the journal before it is approved."))
        elif defects:
            status, reason = REJECTED, "; ".join(sorted(set(defects)))
            result.issues.append(make_issue(source, "ALL", "Approved journal rejected", f"{jid}: {reason}.", CRITICAL,
                                            "Correct the approved journal; it cannot be applied as it stands."))
        elif jtype == "Elimination" and touches_pl and not config.ALLOW_PL_ELIMINATIONS:
            status, reason = REJECTED, "Elimination affects profit or loss and is not explicitly configured"
            result.issues.append(make_issue(source, "ALL", "Profit or loss elimination not configured",
                                            f"{jid}: elimination touches profit or loss accounts; excluded.", WARNING,
                                            "Set ALLOW_PL_ELIMINATIONS in config.py only after the treatment is approved."))
        else:
            status = APPLIED
            if any(code in inactive for code, _, _ in posting):
                result.issues.append(make_issue(source, "ALL", "Inactive account in journal", f"{jid}: uses an inactive account.", WARNING,
                                                "Confirm the account should be used."))

        first = grp.iloc[0]
        register_rows.append((jid, jtype, str(first["Journal_Date"]).strip(), str(first["Financial_Period"]).strip(),
                              "; ".join(sorted({standardise_code(v) for v in grp["Debit_Account"] if not is_blank(v)})),
                              "; ".join(sorted({standardise_code(v) for v in grp["Credit_Account"] if not is_blank(v)})),
                              total_dr, config.CURRENCY, "; ".join(dict.fromkeys(str(v) for v in grp["Description"] if not is_blank(v))),
                              ", ".join(sorted(related)), ", ".join(sorted(counter)), "/".join(sorted(statuses)),
                              "" if is_blank(first["Approved_By"]) else str(first["Approved_By"]).strip(),
                              "" if is_blank(first["Approval_Date"]) else str(first["Approval_Date"]).strip(),
                              "" if is_blank(first["Supporting_Reference"]) else str(first["Supporting_Reference"]).strip(), status, reason))
        ref = register_rows[-1][14]
        for code, d, c in posting:
            line_rows.append((jid, jtype, code, d, c, register_rows[-1][11], status, ref,
                              ", ".join(sorted(related)), ", ".join(sorted(counter))))
    result.register = pd.DataFrame(register_rows, columns=REGISTER_COLUMNS)
    result.lines = pd.DataFrame(line_rows, columns=LINE_COLUMNS)
    return result


def load_journals(folder: Path, year: int, coa: pd.DataFrame) -> JournalResult:
    """Load Elimination_Journals.xlsx; a missing file is a warning (no adjustments)."""
    path = Path(folder) / config.JOURNAL_FILE
    if not path.exists():
        res = JournalResult()
        res.issues.append(make_issue(config.JOURNAL_FILE, "ALL", "Journal file missing",
                                     "No Elimination_Journals.xlsx found; no adjustments or eliminations applied.", WARNING,
                                     "Add the approved journal file if adjustments are required."))
        return res
    try:
        frame = read_table(path, "Journals")
    except FileReadError as exc:
        res = JournalResult()
        res.issues.append(make_issue(config.JOURNAL_FILE, "ALL", "Journal file", f"Journal file cannot be read ({exc}).", CRITICAL,
                                     "Re-save the journal workbook as .xlsx."))
        return res
    return process_journals(frame, year, coa)


def elimination_summary(register: pd.DataFrame) -> pd.DataFrame:
    """One row per elimination journal, used to attach references/amounts to interbranch pairs."""
    cols = ["Journal_ID", "Related_Location", "Counterparty_Location", "Amount_Fils", "Supporting_Reference", "Application_Status"]
    if register.empty:
        return pd.DataFrame(columns=cols)
    elim = register[register["Journal_Type"] == "Elimination"]
    return elim[cols].reset_index(drop=True)
