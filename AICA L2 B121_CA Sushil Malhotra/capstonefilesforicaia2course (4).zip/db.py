"""Local SQLite database (standard-library ``sqlite3``): run history, validation issues,
consolidated balances, journals and warning reviews. The file lives in ./data and never leaves the laptop.
"""
from __future__ import annotations

import logging
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path

import pandas as pd

import config
from utils import to_aed_frame

log = logging.getLogger("consolidation")

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (
    run_id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at TEXT NOT NULL, period TEXT NOT NULL, folder TEXT NOT NULL,
    locations_loaded INTEGER, critical_errors INTEGER, open_warnings INTEGER, unreconciled_pairs INTEGER,
    finalised INTEGER DEFAULT 0, finalised_at TEXT);
CREATE TABLE IF NOT EXISTS issue_reviews (
    issue_key TEXT PRIMARY KEY, reviewed_by TEXT, note TEXT, reviewed_at TEXT);
CREATE TABLE IF NOT EXISTS app_events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT, event TEXT);
"""
RUN_TABLES = {
    "run_source_files": "files", "run_validation_issues": "issues", "run_consolidated_tb": "adjusted",
    "run_interbranch": "recon", "run_journal_register": None, "run_branch_analysis": "branch",
}


class Database:
    def __init__(self, path: Path = config.DB_PATH):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as conn:
            conn.executescript(SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.path)
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    def save_run(self, result) -> int:
        """Store a snapshot of the run. Returns the new run_id."""
        now = datetime.now().isoformat(timespec="seconds")
        with closing(self._connect()) as conn, conn:
            cur = conn.execute(
                "INSERT INTO runs (created_at, period, folder, locations_loaded, critical_errors, open_warnings, unreconciled_pairs) "
                "VALUES (?,?,?,?,?,?,?)",
                (now, result.period, str(result.folder), int(result.tb["Entity_Code"].nunique()) if not result.tb.empty else 0,
                 result.critical_count, result.open_warning_count, result.unreconciled_count))
            run_id = int(cur.lastrowid)
            frames = {
                "run_source_files": result.files, "run_validation_issues": result.issues, "run_consolidated_tb": result.adjusted,
                "run_interbranch": result.recon, "run_journal_register": result.journals.register, "run_branch_analysis": result.branch,
            }
            for table, frame in frames.items():
                if frame is not None and not frame.empty:
                    frame.assign(run_id=run_id).to_sql(table, conn, if_exists="append", index=False)
        result.run_id = run_id
        log.info("Run %s saved to local database", run_id)
        return run_id

    def mark_final(self, run_id: int) -> None:
        with closing(self._connect()) as conn, conn:
            conn.execute("UPDATE runs SET finalised=1, finalised_at=? WHERE run_id=?",
                         (datetime.now().isoformat(timespec="seconds"), run_id))

    def list_runs(self, limit: int = 20) -> pd.DataFrame:
        with closing(self._connect()) as conn:
            return pd.read_sql_query("SELECT * FROM runs ORDER BY run_id DESC LIMIT ?", conn, params=(limit,))

    def get_reviews(self) -> dict[str, str]:
        with closing(self._connect()) as conn:
            return dict(conn.execute("SELECT issue_key, note FROM issue_reviews").fetchall())

    def set_reviews(self, keys: list[str], reviewer: str, note: str) -> None:
        now = datetime.now().isoformat(timespec="seconds")
        with closing(self._connect()) as conn, conn:
            conn.executemany("INSERT OR REPLACE INTO issue_reviews VALUES (?,?,?,?)", [(k, reviewer, note, now) for k in keys])

    def clear_reviews(self) -> None:
        with closing(self._connect()) as conn, conn:
            conn.execute("DELETE FROM issue_reviews")

    def log_event(self, event: str) -> None:
        with closing(self._connect()) as conn, conn:
            conn.execute("INSERT INTO app_events (created_at, event) VALUES (?,?)", (datetime.now().isoformat(timespec="seconds"), event))

    def read_run_table(self, table: str, run_id: int) -> pd.DataFrame:
        if table not in RUN_TABLES:
            raise ValueError("unknown table")
        with closing(self._connect()) as conn:
            return pd.read_sql_query(f"SELECT * FROM {table} WHERE run_id = ?", conn, params=(run_id,))
