"""Central configuration for the Financial Consolidation application.

Everything that an accountant may want to change (company name, financial year,
tolerances, statement line structure) lives here, not in the calculation code.
"""
from __future__ import annotations

import logging
import sys
from datetime import date
from logging.handlers import RotatingFileHandler
from pathlib import Path

# --------------------------------------------------------------------------- paths
# When packaged as an .exe, data folders live next to the executable, not inside the bundle.
BASE_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parent
SAMPLE_DIR = BASE_DIR / "sample_data"
ERROR_SAMPLE_DIR = BASE_DIR / "sample_data_with_errors"
TEMPLATE_DIR = BASE_DIR / "templates"
OUTPUT_DIR = BASE_DIR / "output"
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
DB_PATH = DATA_DIR / "consolidation.db"

# --------------------------------------------------------------------------- company
COMPANY_NAME = "ABC Trading LLC (Fictitious)"
CURRENCY = "AED"
DEFAULT_YEAR = 2025
FY_START_MONTH = 1  # 1 = January. Change to e.g. 4 for an April-March year.
OUTPUT_WORKBOOK_NAME = "ABC_Consolidated_Financial_Statements.xlsx"
RECON_WORKBOOK_NAME = "ABC_Interbranch_Reconciliation.xlsx"


def period_label(year: int) -> str:
    """Financial_Period label expected inside the Excel files, e.g. ``FY2025``."""
    return f"FY{int(year)}"


def period_dates(year: int, start_month: int = FY_START_MONTH) -> tuple[date, date]:
    """First and last day of the financial year that *ends* in ``year``."""
    if start_month == 1:
        return date(year, 1, 1), date(year, 12, 31)
    start = date(year - 1, start_month, 1)
    end_month_first = date(year, start_month, 1)
    end = date.fromordinal(end_month_first.toordinal() - 1)
    return start, end


def period_aliases(year: int, start_month: int = FY_START_MONTH) -> set[str]:
    """Spellings of the reporting period that are accepted in input files."""
    _, end = period_dates(year, start_month)
    return {
        period_label(year).upper(),
        f"FY {year}",
        str(year),
        f"{end.year}-{end.month:02d}",
        end.isoformat(),
        end.strftime("%d-%b-%Y").upper(),
        end.strftime("%b-%Y").upper(),
    }


# --------------------------------------------------------------------------- locations
HEAD_OFFICE = "HO"
BRANCHES = [f"BR{i:02d}" for i in range(1, 21)]
ALL_LOCATIONS = [HEAD_OFFICE] + BRANCHES
_CITIES = ["Dubai", "Abu Dhabi", "Sharjah", "Ajman", "Ras Al Khaimah", "Fujairah", "Umm Al Quwain", "Al Ain"]
LOCATION_NAMES = {HEAD_OFFICE: "Head Office - Dubai"}
for _i, _b in enumerate(BRANCHES):
    LOCATION_NAMES[_b] = f"Branch {_b[2:]} - {_CITIES[_i % len(_CITIES)]}"

# Files in the input folder that are master data, not trial balances.
RESERVED_FILES = {"chart_of_accounts.xlsx", "account_mapping.xlsx", "elimination_journals.xlsx"}
COA_FILE = "Chart_of_Accounts.xlsx"
MAPPING_FILE = "Account_Mapping.xlsx"
JOURNAL_FILE = "Elimination_Journals.xlsx"
MAX_FILE_MB = 25
ALLOWED_EXTENSIONS = {".xlsx", ".xlsm"}

# --------------------------------------------------------------------------- rules
BALANCE_TOLERANCE_FILS = 0           # trial balances must balance exactly (1 fils = 0.01 AED)
RECON_MATCH_TOLERANCE_FILS = 0       # interbranch pair counts as "Matched" within this difference
RECON_PARTIAL_THRESHOLD = 0.05       # difference up to 5% of the larger balance = "Partially matched"
ALLOW_PL_ELIMINATIONS = False        # eliminations touching profit or loss need explicit configuration
TAX_RATE = 0.09                      # used only by the sample data generator
TAX_FREE_THRESHOLD = 375_000         # used only by the sample data generator

# --------------------------------------------------------------------------- statement structure
# Every approved account mapping must point to one of these lines.
PL_LINES = [
    "Revenue", "Sales returns", "Cost of sales", "Other income",
    "Employee expenses", "Rent and occupancy expenses", "Administrative expenses",
    "Selling and distribution expenses", "Depreciation and amortisation",
    "Other operating expenses", "Finance costs", "Income tax expense",
]
BS_LINES = [
    "Property, plant and equipment", "Accumulated depreciation", "Inventory",
    "Trade receivables", "Other receivables", "Interbranch receivables", "Cash and bank",
    "Trade payables", "Accrued expenses", "Other liabilities", "Interbranch payables",
    "Borrowings", "Capital", "Retained earnings",
]
VALID_FS_LINES = PL_LINES + BS_LINES
FS_LINE_STATEMENT = {**{ln: "PL" for ln in PL_LINES}, **{ln: "BS" for ln in BS_LINES}}
OPEX_LINES = [
    "Employee expenses", "Rent and occupancy expenses", "Administrative expenses",
    "Selling and distribution expenses", "Depreciation and amortisation", "Other operating expenses",
]

# --------------------------------------------------------------------------- logging
def setup_logging() -> logging.Logger:
    """Local rotating log file. Only counts, file names and rule names are logged -
    never account balances or descriptions."""
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    logger = logging.getLogger("consolidation")
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        handler = RotatingFileHandler(LOG_DIR / "app.log", maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
        logger.addHandler(handler)
        logger.propagate = False
    return logger
