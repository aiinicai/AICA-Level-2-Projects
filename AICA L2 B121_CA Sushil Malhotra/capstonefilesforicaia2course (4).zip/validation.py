"""Import and validation of location trial balances and master data.

Nothing here changes a balance. Problems are reported as *issues*; critical issues
block finalisation, warnings can be reviewed.
"""
from __future__ import annotations

import hashlib
import logging
import re
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

import config
from utils import file_sha256, is_blank, parse_amount, standardise_code

log = logging.getLogger("consolidation")

CRITICAL, WARNING, INFO = "Critical", "Warning", "Info"
REQUIRED_COLS = ["Account_Code", "Account_Description", "Debit", "Credit"]
OPTIONAL_COLS = ["Entity_Code", "Currency", "Financial_Period"]
ISSUE_COLUMNS = ["Issue_Key", "File_Name", "Location", "Validation_Rule", "Error_Description", "Amount_Fils",
                 "Severity", "Recommended_Action", "Resolution_Status"]
TB_COLUMNS = ["Entity_Code", "Account_Code", "Account_Description", "Debit_Fils", "Credit_Fils", "Currency",
              "Financial_Period", "Source_File", "Source_Row"]


class FileReadError(Exception):
    """Workbook missing, corrupt or too large."""


def make_issue(file: str, location: str, rule: str, description: str, severity: str, action: str,
               amount_fils: int | None = None) -> dict:
    key = hashlib.sha1(f"{file}|{location}|{rule}|{description}".encode()).hexdigest()[:12]
    return {"Issue_Key": key, "File_Name": file, "Location": location, "Validation_Rule": rule,
            "Error_Description": description, "Amount_Fils": amount_fils, "Severity": severity,
            "Recommended_Action": action, "Resolution_Status": "Open"}


def issues_frame(issues: list[dict]) -> pd.DataFrame:
    frame = pd.DataFrame(issues, columns=ISSUE_COLUMNS)
    frame["Amount_Fils"] = pd.to_numeric(frame["Amount_Fils"], errors="coerce").astype("Int64")
    rank = frame["Severity"].map({CRITICAL: 0, WARNING: 1, INFO: 2})
    return (frame.assign(_rank=rank).sort_values(["_rank", "Location", "Validation_Rule"], kind="stable")
            .drop(columns="_rank").reset_index(drop=True))


def _canon_columns(df: pd.DataFrame) -> pd.DataFrame:
    lookup = {c.lower(): c for c in REQUIRED_COLS + OPTIONAL_COLS}
    renamed = {col: lookup.get(re.sub(r"[\s\-]+", "_", str(col).strip()).lower(), str(col).strip()) for col in df.columns}
    return df.rename(columns=renamed)


def read_table(path: Path, preferred_sheet: str | None = None) -> pd.DataFrame:
    """Read the first (or preferred) worksheet as text. Raises FileReadError."""
    path = Path(path)
    if not path.is_file():
        raise FileReadError("file not found")
    if path.suffix.lower() not in config.ALLOWED_EXTENSIONS:
        raise FileReadError(f"unsupported file type {path.suffix}")
    if path.stat().st_size > config.MAX_FILE_MB * 1024 * 1024:
        raise FileReadError(f"file larger than {config.MAX_FILE_MB} MB")
    try:
        with pd.ExcelFile(path, engine="openpyxl") as book:
            sheet = preferred_sheet if preferred_sheet in book.sheet_names else book.sheet_names[0]
            # keep_default_na=False: text such as "N/A" must stay visible as an invalid amount, not become blank
            return pd.read_excel(book, sheet_name=sheet, dtype=str, keep_default_na=False, na_values=[""])
    except Exception as exc:  # corrupt zip, wrong format, password protected ...
        raise FileReadError(f"{type(exc).__name__}: {str(exc)[:120]}") from exc


def discover_files(folder: Path) -> list[Path]:
    """Excel files in the folder that look like trial balances (master data excluded)."""
    folder = Path(folder)
    if not folder.is_dir():
        raise FileNotFoundError(f"Folder not found: {folder}")
    return sorted(p for p in folder.iterdir()
                  if p.is_file() and p.suffix.lower() in config.ALLOWED_EXTENSIONS
                  and not p.name.startswith("~$") and p.name.lower() not in config.RESERVED_FILES)


@dataclass
class TBFile:
    file_name: str
    path: Path
    location: str = "UNIDENTIFIED"
    df: pd.DataFrame | None = None
    issues: list = field(default_factory=list)
    readable: bool = True
    sha256: str = ""
    rows: int = 0


def _rows_text(rows: list[int], limit: int = 10) -> str:
    shown = ", ".join(str(r) for r in rows[:limit])
    return shown + (f" (+{len(rows) - limit} more)" if len(rows) > limit else "")


def read_trial_balance(path: Path, expected_period: str, year: int, manual_map: dict | None = None) -> TBFile:
    """Read and validate one location file."""
    path = Path(path)
    tb = TBFile(file_name=path.name, path=path)
    name = path.name
    stem = standardise_code(path.stem)
    manual_map = manual_map or {}

    def add(rule, desc, sev, action, amount=None):
        tb.issues.append(make_issue(name, tb.location, rule, desc, sev, action, amount))

    try:
        tb.sha256 = file_sha256(path)
        raw = _canon_columns(read_table(path, "Trial_Balance"))
    except (FileReadError, OSError) as exc:
        tb.readable = False
        tb.location = stem if stem in config.ALL_LOCATIONS else manual_map.get(name, "UNIDENTIFIED")
        add("File cannot be read", f"The workbook could not be opened ({exc}).", CRITICAL,
            "Re-save the file as a normal .xlsx workbook (not password protected) and reload.")
        return tb

    # ---- location identification
    entity_values = set()
    if "Entity_Code" in raw.columns:
        entity_values = {standardise_code(v) for v in raw["Entity_Code"] if not is_blank(v)}
    if len(entity_values) > 1:
        tb.location = "MULTIPLE"
        add("Location identification", f"File contains several Entity_Code values: {sorted(entity_values)}.", CRITICAL,
            "Split the file so each workbook holds exactly one reporting location.")
    elif len(entity_values) == 1:
        tb.location = next(iter(entity_values))
        if tb.location not in config.ALL_LOCATIONS:
            add("Location identification", f"Entity_Code '{tb.location}' is not a configured location.", CRITICAL,
                "Use HO or BR01-BR20 in Entity_Code.")
        elif stem in config.ALL_LOCATIONS and stem != tb.location:
            add("Location identification", f"File name suggests {stem} but Entity_Code says {tb.location}.", CRITICAL,
                "Correct the file name or the Entity_Code column.")
    elif stem in config.ALL_LOCATIONS:
        tb.location = stem
        add("Location identification", "No Entity_Code column values; location taken from the file name.", INFO,
            "No action needed, or add the Entity_Code column.")
    elif name in manual_map and manual_map[name] in config.ALL_LOCATIONS:
        tb.location = manual_map[name]
        add("Location identification", f"Location {tb.location} assigned manually by the user.", INFO,
            "No action needed.")
    else:
        add("Location identification", "The reporting location could not be identified from the file.", CRITICAL,
            "Rename the file to the location code or assign the location manually on the Input Data page.")

    # ---- columns
    missing = [c for c in REQUIRED_COLS if c not in raw.columns]
    if missing:
        add("Mandatory columns", f"Missing column(s): {', '.join(missing)}.", CRITICAL,
            "Use the trial_balance_template.xlsx column names exactly.")
        tb.readable = False
        return tb
    raw = raw.dropna(how="all").reset_index(drop=True)
    tb.rows = len(raw)
    if raw.empty:
        add("Empty file", "The file contains no rows.", CRITICAL, "Populate the trial balance and reload.")
        return tb

    # ---- row-level checks
    problems: dict[str, list[int]] = {"blank_code": [], "invalid_amount": [], "negative": [], "both_sides": [], "both_blank": []}
    negative_total = 0
    records = []
    for idx, row in raw.iterrows():
        excel_row = idx + 2
        code = standardise_code(row["Account_Code"])
        debit, d_problem = parse_amount(row["Debit"])
        credit, c_problem = parse_amount(row["Credit"])
        if d_problem == "invalid" or c_problem == "invalid":
            problems["invalid_amount"].append(excel_row)
            debit = 0 if debit is None else debit
            credit = 0 if credit is None else credit
        elif d_problem == "blank" and c_problem == "blank":
            problems["both_blank"].append(excel_row)
        if debit < 0 or credit < 0:
            problems["negative"].append(excel_row)
            negative_total += abs(min(debit, 0)) + abs(min(credit, 0))
        if debit > 0 and credit > 0:
            problems["both_sides"].append(excel_row)
        if not code:
            problems["blank_code"].append(excel_row)
            code = "(BLANK)"
        currency = standardise_code(row["Currency"]) if "Currency" in raw.columns else config.CURRENCY
        period = str(row["Financial_Period"]).strip() if "Financial_Period" in raw.columns and not is_blank(row["Financial_Period"]) else ""
        records.append((tb.location, code, "" if is_blank(row["Account_Description"]) else str(row["Account_Description"]).strip(),
                        debit, credit, currency or config.CURRENCY, period or expected_period, name, excel_row))
    df = pd.DataFrame(records, columns=TB_COLUMNS)

    if problems["blank_code"]:
        add("Blank account code", f"Blank Account_Code in Excel row(s): {_rows_text(problems['blank_code'])}.", CRITICAL,
            "Enter the correct account code for every row.")
    if problems["invalid_amount"]:
        add("Invalid amount", f"Non-numeric Debit/Credit in Excel row(s): {_rows_text(problems['invalid_amount'])}.", CRITICAL,
            "Replace text such as 'N/A' with a number (or 0).")
    if problems["negative"]:
        add("Negative amount", f"Negative Debit/Credit in Excel row(s): {_rows_text(problems['negative'])}.", CRITICAL,
            "Debit and Credit must be non-negative; post a negative balance in the opposite column.", negative_total)
    if problems["both_sides"]:
        add("Debit and credit on one row", f"Both Debit and Credit populated in Excel row(s): {_rows_text(problems['both_sides'])}.",
            WARNING, "Confirm the row is intended; normally one side is zero.")
    if problems["both_blank"]:
        add("Missing amounts", f"Both Debit and Credit are blank in Excel row(s): {_rows_text(problems['both_blank'])}.", WARNING,
            "Enter 0 for a nil balance or remove the row.")

    # duplicates
    dup = df[df["Account_Code"] != "(BLANK)"]
    duplicated = dup[dup.duplicated("Account_Code", keep=False)]
    for code, grp in duplicated.groupby("Account_Code"):
        add("Duplicate account record", f"Account {code} appears {len(grp)} times (Excel rows {_rows_text(list(grp['Source_Row']))}). "
            "Balances will be added together.", WARNING, "Confirm the duplicate is intended or merge the rows.",
            int(grp["Debit_Fils"].sum() + grp["Credit_Fils"].sum()))

    # currency / period
    if "Currency" not in raw.columns:
        add("Currency", "No Currency column; AED assumed.", WARNING, "Add the Currency column to the template.")
    else:
        bad = sorted({c for c in df["Currency"] if c != config.CURRENCY})
        if bad:
            add("Unexpected currency", f"Currency other than {config.CURRENCY}: {bad}.", CRITICAL,
                "Convert to AED before loading; foreign currency translation is not supported.")
    aliases = config.period_aliases(year)
    if "Financial_Period" not in raw.columns:
        add("Financial period", f"No Financial_Period column; {expected_period} assumed.", WARNING,
            "Add the Financial_Period column to the template.")
    else:
        bad = sorted({p for p in df["Financial_Period"] if p.upper()[:11] not in aliases and p.upper() not in aliases})
        if bad:
            add("Unexpected financial period", f"Period(s) {bad} do not match the selected period {expected_period}.", CRITICAL,
                "Load the correct file or change the reporting period.")

    # trial balance agreement
    total_dr, total_cr = int(df["Debit_Fils"].sum()), int(df["Credit_Fils"].sum())
    if abs(total_dr - total_cr) > config.BALANCE_TOLERANCE_FILS:
        add("Trial balance does not balance", f"Total debits {total_dr / 100:,.2f} and total credits {total_cr / 100:,.2f} differ.",
            CRITICAL, "Correct the source ledger; the application never forces a trial balance to balance.", abs(total_dr - total_cr))
    tb.df = df
    return tb


def validate_folder(folder: Path, year: int, manual_map: dict | None = None) -> tuple[list[TBFile], list[dict]]:
    """Read every trial balance in the folder and run the cross-file controls."""
    period = config.period_label(year)
    files = discover_files(folder)
    tbfiles = [read_trial_balance(p, period, year, manual_map) for p in files]
    issues = [i for t in tbfiles for i in t.issues]

    by_location: dict[str, list[TBFile]] = {}
    for t in tbfiles:
        if t.location in config.ALL_LOCATIONS:
            by_location.setdefault(t.location, []).append(t)
    for loc, group in by_location.items():
        if len(group) > 1:
            names = ", ".join(t.file_name for t in group)
            for t in group:
                issues.append(make_issue(t.file_name, loc, "Duplicate location submission",
                                         f"Location {loc} is submitted in several files: {names}.", CRITICAL,
                                         "Keep exactly one file per location; remove or rename the others."))
    for loc in config.ALL_LOCATIONS:
        if loc not in by_location:
            issues.append(make_issue("(none)", loc, "Missing location file", f"No trial balance file found for {loc}.", CRITICAL,
                                     f"Add {loc}.xlsx to the input folder."))
    return tbfiles, issues


def usable_trial_balance(tbfiles: list[TBFile]) -> pd.DataFrame:
    """Combined long table of rows from readable files with a unique, valid location."""
    counts: dict[str, int] = {}
    for t in tbfiles:
        counts[t.location] = counts.get(t.location, 0) + 1
    frames = [t.df for t in tbfiles if t.df is not None and t.location in config.ALL_LOCATIONS and counts[t.location] == 1]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=TB_COLUMNS)


def unmapped_report(tb: pd.DataFrame, coa: pd.DataFrame, mapping: pd.DataFrame) -> pd.DataFrame:
    """Accounts in the trial balances without an approved mapping or chart-of-accounts entry."""
    cols = ["Account_Code", "Account_Description", "Reason", "Locations", "Source_Files", "Debit_Fils", "Credit_Fils"]
    if tb.empty:
        return pd.DataFrame(columns=cols)
    approved = set(mapping.loc[mapping["Mapping_Status"].str.strip().str.lower() == "approved", "Account_Code"])
    in_coa = set(coa["Account_Code"])
    rows = []
    for code, grp in tb[tb["Account_Code"] != "(BLANK)"].groupby("Account_Code"):
        reasons = []
        if code not in in_coa:
            reasons.append("Not in chart of accounts")
        if code not in approved:
            reasons.append("No approved mapping to a statement line")
        if reasons:
            rows.append((code, grp["Account_Description"].iloc[0], "; ".join(reasons),
                         ", ".join(sorted(grp["Entity_Code"].unique())), ", ".join(sorted(grp["Source_File"].unique())),
                         int(grp["Debit_Fils"].sum()), int(grp["Credit_Fils"].sum())))
    return pd.DataFrame(rows, columns=cols)


def validate_against_master(tb: pd.DataFrame, coa: pd.DataFrame, mapping: pd.DataFrame, ib_map: pd.DataFrame) -> list[dict]:
    """Unmapped / inactive / interbranch-mapping controls."""
    issues = []
    if tb.empty:
        return issues
    unmapped = unmapped_report(tb, coa, mapping)
    for _, row in unmapped.iterrows():
        for (file, loc), grp in tb[tb["Account_Code"] == row["Account_Code"]].groupby(["Source_File", "Entity_Code"]):
            amount = abs(int(grp["Debit_Fils"].sum() - grp["Credit_Fils"].sum()))
            issues.append(make_issue(file, loc, "Unmapped account", f"Account {row['Account_Code']} ({row['Account_Description']}): {row['Reason']}.",
                                     CRITICAL, "Add the account to Chart_of_Accounts.xlsx and Account_Mapping.xlsx (approved), then reload.", amount))
    inactive = set(coa.loc[coa["Active_Status"].str.strip().str.lower() != "active", "Account_Code"])
    for (file, loc, code), grp in tb[tb["Account_Code"].isin(inactive)].groupby(["Source_File", "Entity_Code", "Account_Code"]):
        net = int(grp["Debit_Fils"].sum() - grp["Credit_Fils"].sum())
        if net != 0:
            issues.append(make_issue(file, loc, "Inactive account with balance", f"Inactive account {code} carries a balance.", WARNING,
                                     "Reclassify the balance to an active account or reactivate the account.", abs(net)))
    ib_accounts = set(coa.loc[coa["Reporting_Category"].str.strip().str.lower() == "interbranch", "Account_Code"])
    mapped = set(ib_map["Account_Code"])
    for (file, loc, code), grp in tb[tb["Account_Code"].isin(ib_accounts - mapped)].groupby(["Source_File", "Entity_Code", "Account_Code"]):
        issues.append(make_issue(file, loc, "Missing counterparty mapping", f"Interbranch account {code} has no counterparty location mapping.",
                                 CRITICAL, "Add the account to the Interbranch_Accounts sheet of Account_Mapping.xlsx."))
    ib_lookup = dict(zip(ib_map["Account_Code"], ib_map["Counterparty_Location"]))
    for (file, loc, code), grp in tb[tb["Account_Code"].isin(mapped)].groupby(["Source_File", "Entity_Code", "Account_Code"]):
        net = int(grp["Debit_Fils"].sum() - grp["Credit_Fils"].sum())
        if ib_lookup.get(code) == loc and net != 0:
            issues.append(make_issue(file, loc, "Interbranch self-balance", f"{loc} carries interbranch account {code} against itself.", WARNING,
                                     "Check the counterparty on this interbranch posting.", abs(net)))
    return issues
