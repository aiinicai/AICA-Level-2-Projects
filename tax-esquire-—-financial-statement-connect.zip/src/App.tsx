import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { AuthModal } from './components/AuthModal';
import { CompanyModal } from './components/CompanyModal';
import { TrialBalanceEditor } from './components/TrialBalanceEditor';
import { FinancialStatementViewer } from './components/FinancialStatementViewer';
import { DocumentPackGenerator } from './components/DocumentPackGenerator';
import { AIMcaRefreshPanel } from './components/AIMcaRefreshPanel';
import {
  CompanyProfile,
  FinancialStatementsFull,
  FixedAssetRow,
  ShareholderDetail,
  TrialBalanceRow,
  UserSession
} from './types';
import {
  INITIAL_COMPANY_PROFILE,
  INITIAL_FIXED_ASSETS,
  INITIAL_SHAREHOLDERS,
  INITIAL_TRIAL_BALANCE_CY,
  INITIAL_TRIAL_BALANCE_PY
} from './data/sampleCompanyData';
import { calculateFinancialStatements } from './utils/financialCalculations';
import {
  generateAOC4Docx,
  generateAuditorsReportDocx,
  generateDirectorsReportDocx,
  generateMGT7Docx,
  generateScheduleIIIDocx
} from './services/docxGenerator';
import { Award, BookOpen, Building2, CheckCircle2, FileSpreadsheet, Lock, ShieldCheck, Sparkles, TrendingUp } from 'lucide-react';

export default function App() {
  // Authentication State
  const [currentUser, setCurrentUser] = useState<UserSession | null>(() => {
    const saved = localStorage.getItem('tax_fin_connect_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {}
    }
    // Default authenticated for instant seamless preview
    return {
      email: 'capoonamguptaiicpa@gmail.com',
      name: 'CA Poonam Gupta',
      firmName: 'Gupta Poonam & Associates, Chartered Accountants',
      frn: '033858C',
      membershipNo: '303889',
      role: 'CA_PRINCIPAL',
      token: 'session_active'
    };
  });

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [companyModalOpen, setCompanyModalOpen] = useState(false);

  // Active View Navigation
  const [activeView, setActiveView] = useState<'TRIAL_BALANCE' | 'FINANCIAL_STATEMENTS' | 'DOCUMENTS' | 'AI_REFRESH'>(
    'FINANCIAL_STATEMENTS'
  );

  // Client Companies
  const [companies, setCompanies] = useState<CompanyProfile[]>([INITIAL_COMPANY_PROFILE]);
  const [activeCompany, setActiveCompany] = useState<CompanyProfile>(INITIAL_COMPANY_PROFILE);

  // Trial Balance & Statement States
  const [trialBalanceCY, setTrialBalanceCY] = useState<TrialBalanceRow[]>(INITIAL_TRIAL_BALANCE_CY);
  const [trialBalancePY, setTrialBalancePY] = useState<TrialBalanceRow[]>(INITIAL_TRIAL_BALANCE_PY);
  const [shareholders, setShareholders] = useState<ShareholderDetail[]>(INITIAL_SHAREHOLDERS);
  const [fixedAssets, setFixedAssets] = useState<FixedAssetRow[]>(INITIAL_FIXED_ASSETS);

  // Full Financial Statement Calculation State
  const [financials, setFinancials] = useState<FinancialStatementsFull>(() => {
    const calc = calculateFinancialStatements(
      INITIAL_COMPANY_PROFILE,
      INITIAL_TRIAL_BALANCE_CY,
      INITIAL_TRIAL_BALANCE_PY,
      INITIAL_SHAREHOLDERS,
      INITIAL_FIXED_ASSETS
    );
    return {
      company: INITIAL_COMPANY_PROFILE,
      trialBalanceCY: INITIAL_TRIAL_BALANCE_CY,
      trialBalancePY: INITIAL_TRIAL_BALANCE_PY,
      balanceSheet: calc.balanceSheet,
      profitAndLoss: calc.profitAndLoss,
      notes: calc.notes,
      lastCalculatedAt: new Date().toISOString()
    };
  });

  const [isCalculating, setIsCalculating] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  // Save user session
  const handleLoginSuccess = (user: UserSession) => {
    setCurrentUser(user);
    localStorage.setItem('tax_fin_connect_user', JSON.stringify(user));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('tax_fin_connect_user');
  };

  // Re-calculate financial statements locally & optionally validate on server
  const recalculateStatements = async (
    comp = activeCompany,
    tbCY = trialBalanceCY,
    tbPY = trialBalancePY,
    sh = shareholders,
    fa = fixedAssets
  ) => {
    setIsCalculating(true);
    try {
      // Local immediate computation
      const localResult = calculateFinancialStatements(comp, tbCY, tbPY, sh, fa);

      const full: FinancialStatementsFull = {
        company: comp,
        trialBalanceCY: tbCY,
        trialBalancePY: tbPY,
        balanceSheet: localResult.balanceSheet,
        profitAndLoss: localResult.profitAndLoss,
        notes: localResult.notes,
        lastCalculatedAt: new Date().toISOString()
      };

      setFinancials(full);

      // Server-side synchronization & persistence
      setIsSaving(true);
      fetch(`/api/companies/${comp.id}/data`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          company: comp,
          trialBalanceCY: tbCY,
          trialBalancePY: tbPY,
          shareholders: sh,
          fixedAssets: fa
        })
      }).catch((e) => console.warn('Background sync:', e));
    } finally {
      setIsCalculating(false);
      setTimeout(() => setIsSaving(false), 500);
    }
  };

  // Handle Trial Balance Updates
  const handleUpdateCY = (rows: TrialBalanceRow[]) => {
    setTrialBalanceCY(rows);
    recalculateStatements(activeCompany, rows, trialBalancePY, shareholders, fixedAssets);
  };

  const handleUpdatePY = (rows: TrialBalanceRow[]) => {
    setTrialBalancePY(rows);
    recalculateStatements(activeCompany, trialBalanceCY, rows, shareholders, fixedAssets);
  };

  // Company Selection
  const handleSelectCompany = (id: string) => {
    const selected = companies.find((c) => c.id === id);
    if (selected) {
      setActiveCompany(selected);
      recalculateStatements(selected, trialBalanceCY, trialBalancePY, shareholders, fixedAssets);
    }
  };

  const handleSaveCompany = (savedComp: CompanyProfile) => {
    const exists = companies.some((c) => c.id === savedComp.id);
    let updatedList: CompanyProfile[];
    if (exists) {
      updatedList = companies.map((c) => (c.id === savedComp.id ? savedComp : c));
    } else {
      updatedList = [...companies, savedComp];
    }
    setCompanies(updatedList);
    setActiveCompany(savedComp);
    recalculateStatements(savedComp, trialBalanceCY, trialBalancePY, shareholders, fixedAssets);
  };

  // Document Downloads
  const handleDownloadDocx = async (type: 'SCHEDULE_III' | 'AOC_4' | 'MGT_7' | 'AUDITOR_REPORT' | 'DIRECTORS_REPORT' | 'ALL') => {
    setIsDownloading(true);
    try {
      if (type === 'SCHEDULE_III') {
        const blob = await generateScheduleIIIDocx(financials);
        downloadBlob(blob, `${activeCompany.name.replace(/\s+/g, '_')}_Schedule_III_FY2023-24.docx`);
      } else if (type === 'AOC_4') {
        const blob = await generateAOC4Docx(financials);
        downloadBlob(blob, `${activeCompany.name.replace(/\s+/g, '_')}_Form_AOC-4_Draft.docx`);
      } else if (type === 'MGT_7') {
        const blob = await generateMGT7Docx(financials);
        downloadBlob(blob, `${activeCompany.name.replace(/\s+/g, '_')}_Form_MGT-7_Draft.docx`);
      } else if (type === 'AUDITOR_REPORT') {
        const blob = await generateAuditorsReportDocx(financials);
        downloadBlob(blob, `${activeCompany.name.replace(/\s+/g, '_')}_Auditors_Report.docx`);
      } else if (type === 'DIRECTORS_REPORT') {
        const blob = await generateDirectorsReportDocx(financials);
        downloadBlob(blob, `${activeCompany.name.replace(/\s+/g, '_')}_Directors_Report.docx`);
      } else if (type === 'ALL') {
        setActiveView('DOCUMENTS');
      }
    } catch (err) {
      console.error('Download error:', err);
      alert('Failed to generate document file.');
    } finally {
      setIsDownloading(false);
    }
  };

  const downloadBlob = (blob: Blob, filename: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#082e27] text-[#f0f0f0] flex flex-col selection:bg-[#c9a227]/30 selection:text-[#f7e089]">
      {/* Top Navbar */}
      <Navbar
        currentUser={currentUser}
        companies={companies}
        activeCompany={activeCompany}
        onSelectCompany={handleSelectCompany}
        onNewCompany={() => {
          setActiveCompany({
            ...INITIAL_COMPANY_PROFILE,
            id: `comp_${Date.now()}`,
            name: 'NEW CLIENT PRIVATE LIMITED',
            cin: 'U74999DL2024PTC123456'
          });
          setCompanyModalOpen(true);
        }}
        onEditCompany={() => setCompanyModalOpen(true)}
        onOpenAIRefresh={() => setActiveView('AI_REFRESH')}
        onLogout={handleLogout}
        onLoginClick={() => setAuthModalOpen(true)}
        activeView={activeView}
        onNavigate={setActiveView}
        isSaving={isSaving}
      />

      {/* Main App Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {!currentUser ? (
          /* Gated Professional Login Welcome Screen */
          <div className="max-w-xl mx-auto my-12 bg-[#0b3d33]/90 border border-[#c9a227]/40 rounded-2xl shadow-2xl overflow-hidden backdrop-blur">
            <div className="bg-gradient-to-br from-[#125246] to-[#082e27] p-8 text-center text-white border-b border-[#c9a227]/30">
              <div className="w-16 h-16 rounded-2xl bg-[#082e27] border-2 border-[#c9a227] flex items-center justify-center mx-auto mb-4 shadow-inner">
                <span className="font-display text-3xl font-bold text-[#c9a227]">TFC</span>
              </div>
              <h2 className="font-display text-2xl font-bold tracking-wide text-white">TAX FIN CONNECT</h2>
              <p className="text-xs text-[#f7e089] mt-1 font-medium">Financial Statement Connect • Schedule III Portal</p>
              <p className="text-xs text-stone-300 mt-2">
                Designed for Chartered Accountants in India for Companies Act 2013 Division I Compliance & MCA V3 Filing.
              </p>
            </div>

            <div className="p-8 space-y-6 bg-[#082e27]/70">
              <div className="space-y-3">
                <div className="flex items-center space-x-3 text-xs text-stone-200">
                  <CheckCircle2 className="w-4 h-4 text-[#34d399] flex-shrink-0" />
                  <span>Auto-classify Trial Balance to Schedule III Heads with keyword matching.</span>
                </div>
                <div className="flex items-center space-x-3 text-xs text-stone-200">
                  <CheckCircle2 className="w-4 h-4 text-[#34d399] flex-shrink-0" />
                  <span>Comparative Balance Sheet, Statement of Profit & Loss, and Notes 1 to 16.</span>
                </div>
                <div className="flex items-center space-x-3 text-xs text-stone-200">
                  <CheckCircle2 className="w-4 h-4 text-[#34d399] flex-shrink-0" />
                  <span>One-click export of Form AOC-4, Form MGT-7, Auditor & Director reports in Word (.docx).</span>
                </div>
                <div className="flex items-center space-x-3 text-xs text-stone-200">
                  <CheckCircle2 className="w-4 h-4 text-[#34d399] flex-shrink-0" />
                  <span>AI Format Refresh for MCA Amendments and Rule 11(g) Audit Trail validation.</span>
                </div>
              </div>

              <button
                onClick={() => setAuthModalOpen(true)}
                className="w-full py-3 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] font-bold text-sm rounded-xl shadow-lg flex items-center justify-center space-x-2 transition cursor-pointer"
              >
                <Lock className="w-4 h-4 text-[#082e27]" />
                <span>Enter Chartered Accountant Workspace</span>
              </button>
            </div>
          </div>
        ) : (
          /* Authenticated CA Workflow */
          <div className="space-y-6">
            {activeView === 'TRIAL_BALANCE' && (
              <TrialBalanceEditor
                currentYearRows={trialBalanceCY}
                previousYearRows={trialBalancePY}
                onUpdateCY={handleUpdateCY}
                onUpdatePY={handleUpdatePY}
                onCalculate={() => {
                  recalculateStatements();
                  setActiveView('FINANCIAL_STATEMENTS');
                }}
                currentYearLabel={activeCompany.currentYearLabel}
                previousYearLabel={activeCompany.previousYearLabel}
                isCalculating={isCalculating}
              />
            )}

            {activeView === 'FINANCIAL_STATEMENTS' && (
              <FinancialStatementViewer
                data={financials}
                onDownloadDocx={handleDownloadDocx}
                onOpenAIRefresh={() => setActiveView('AI_REFRESH')}
                isDownloading={isDownloading}
              />
            )}

            {activeView === 'DOCUMENTS' && <DocumentPackGenerator data={financials} />}

            {activeView === 'AI_REFRESH' && <AIMcaRefreshPanel onClose={() => setActiveView('FINANCIAL_STATEMENTS')} />}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-[#051e19] text-stone-400 text-xs py-4 border-t border-[#c9a227]/20 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center space-x-2">
            <span className="font-display font-bold text-[#c9a227]">TAX FIN CONNECT</span>
            <span className="text-stone-300">— Financial Statement Connect</span>
            <span className="text-[10px] text-[#f7e089]/70 font-mono">| Schedule III Division I (AS)</span>
          </div>
          <div className="text-[11px] text-stone-400">
            Gupta Poonam & Associates, Chartered Accountants • FRN 033858C
          </div>
        </div>
      </footer>

      {/* Modals */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      <CompanyModal
        isOpen={companyModalOpen}
        onClose={() => setCompanyModalOpen(false)}
        onSave={handleSaveCompany}
        initialData={activeCompany}
      />
    </div>
  );
}
