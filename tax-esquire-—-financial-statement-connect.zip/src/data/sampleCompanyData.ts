import { CompanyProfile, FixedAssetRow, NotesToAccountsBreakdown, ShareholderDetail, TrialBalanceRow } from '../types';

export const INITIAL_COMPANY_PROFILE: CompanyProfile = {
  id: 'comp-sample-2024',
  name: 'BHARAT APEX ENTERPRISES PRIVATE LIMITED',
  cin: 'U51909DL2021PTC378942',
  registeredOffice: 'Unit No. 402, 4th Floor, Corporate Park Tower, Okhla Industrial Area Phase-III, New Delhi, South Delhi, Delhi 110020, India',
  incorporationDate: '15-04-2021',
  financialYearCurrent: '2023-24',
  asAtCurrentDate: '31st March 2024',
  asAtPreviousDate: '31st March 2023',
  currentYearLabel: 'As at 31st March 2024',
  previousYearLabel: 'As at 31st March 2023',
  authorisedShares: 10000,
  authorisedShareValue: 100000,
  issuedShares: 10000,
  issuedShareValue: 100000,
  faceValuePerShare: 10,
  principalBusinessActivity: 'Wholesale and retail trade of apparel, consumer merchandise and allied services',
  nicCode: '47711',
  turnoverPercentage: 90,
  signatories: {
    director1Name: 'RAJESH SHARMA',
    director1DIN: '08451234',
    director1Designation: 'Director',
    director2Name: 'ANITA VERMA',
    director2DIN: '09123456',
    director2Designation: 'Director',
    auditorFirmName: 'R. K. AGRAWAL & ASSOCIATES',
    auditorFirmRegNo: '012345N',
    auditorPartnerName: 'ROHIT AGRAWAL',
    auditorDesignation: 'Partner',
    auditorMembershipNo: '512345',
    auditorUDIN: '24512345BKFWZS9999',
    auditorAddress: 'Suite 501, Barakhamba Road, Connaught Place, New Delhi 110001',
    auditorEmail: 'contact@rkagrawalassociates.in',
    auditorPhone: '+91 9811001122',
    placeOfSigning: 'New Delhi',
    dateOfSigning: '02-09-2024',
    agmDate: '30-09-2024',
    boardMeetingDate: '02-09-2024'
  }
};

export const INITIAL_TRIAL_BALANCE_CY: TrialBalanceRow[] = [
  { id: 'tb-1', ledgerName: 'Equity Share Capital (10,000 shares of Rs 10)', debit: 0, credit: 100000, category: 'SHARE_CAPITAL', noteNumber: 2 },
  { id: 'tb-2', ledgerName: 'Reserves & Surplus (Opening P&L Balance)', debit: 1078803, credit: 0, category: 'RESERVES_AND_SURPLUS', noteNumber: 3 },
  { id: 'tb-3', ledgerName: 'Unsecured Loan from Directors', debit: 0, credit: 2191259, category: 'LONG_TERM_BORROWINGS', noteNumber: 4 },
  { id: 'tb-4', ledgerName: 'Audit Fee Payable', debit: 0, credit: 25000, category: 'OTHER_CURRENT_LIABILITIES', noteNumber: 6 },
  { id: 'tb-5', ledgerName: 'Computer (Gross Block & Depr WDV)', debit: 5034, credit: 0, category: 'TANGIBLE_ASSETS', noteNumber: 8 },
  { id: 'tb-6', ledgerName: 'Airconditioner (Gross Block & Depr WDV)', debit: 17976, credit: 0, category: 'TANGIBLE_ASSETS', noteNumber: 8 },
  { id: 'tb-7', ledgerName: 'Deferred Tax Asset (Opening Rs. 3,107 + CY Add)', debit: 4650, credit: 0, category: 'DEFERRED_TAX_ASSETS_NET' },
  { id: 'tb-8', ledgerName: 'Closing Inventories / Stock in Trade', debit: 516784, credit: 0, category: 'INVENTORIES', noteNumber: 12 },
  { id: 'tb-9', ledgerName: 'Bank Balance - Current Accounts', debit: 123714, credit: 0, category: 'CASH_AND_BANK_BALANCES', noteNumber: 7 },
  { id: 'tb-10', ledgerName: 'Cash on Hand', debit: 15642, credit: 0, category: 'CASH_AND_BANK_BALANCES', noteNumber: 7 },
  { id: 'tb-11', ledgerName: 'Balances with Statutory Authorities (GST Input)', debit: 106221, credit: 0, category: 'OTHER_CURRENT_ASSETS', noteNumber: 9 },
  { id: 'tb-12', ledgerName: 'Advances to Creditors', debit: 151705, credit: 0, category: 'OTHER_CURRENT_ASSETS', noteNumber: 9 },
  { id: 'tb-13', ledgerName: 'Revenue from Operations (Tax Invoices)', debit: 0, credit: 14325, category: 'REVENUE_FROM_OPERATIONS', noteNumber: 10 },
  { id: 'tb-14', ledgerName: 'Other Income - UPI Activation Charges', debit: 0, credit: 4146, category: 'OTHER_INCOME', noteNumber: 11 },
  { id: 'tb-15', ledgerName: 'Cost of Traded Goods (Opening Stock less Closing)', debit: 80628, credit: 0, category: 'COST_OF_TRADED_GOODS', noteNumber: 12 },
  { id: 'tb-16', ledgerName: 'Statutory Audit Fee', debit: 25000, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-17', ledgerName: 'Accounting Charges', debit: 39160, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-18', ledgerName: 'Insurance Expenses', debit: 8934, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-19', ledgerName: 'Advertisement & Publicity', debit: 5028, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-20', ledgerName: 'Rent Expenses', debit: 135000, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-21', ledgerName: 'Telephone & Internet Expenses', debit: 5988, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-22', ledgerName: 'Other Miscellaneous Expenses', debit: 1059, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-23', ledgerName: 'Bank Charges (Finance Cost)', debit: 124, credit: 0, category: 'FINANCE_COSTS', noteNumber: 15 },
  { id: 'tb-24', ledgerName: 'Depreciation as per Companies Act', debit: 14823, credit: 0, category: 'DEPRECIATION_AND_AMORTISATION', noteNumber: 8 },
  { id: 'tb-25', ledgerName: 'Deferred Tax Transfer to P&L (Credit)', debit: 0, credit: 1543, category: 'TAX_EXPENSE_DEFERRED' }
];

export const INITIAL_TRIAL_BALANCE_PY: TrialBalanceRow[] = [
  { id: 'tb-py-1', ledgerName: 'Equity Share Capital', debit: 0, credit: 100000, category: 'SHARE_CAPITAL', noteNumber: 2 },
  { id: 'tb-py-2', ledgerName: 'Reserves & Surplus (Accumulated Loss)', debit: 1078804, credit: 0, category: 'RESERVES_AND_SURPLUS', noteNumber: 3 },
  { id: 'tb-py-3', ledgerName: 'Unsecured Loan from Directors', debit: 0, credit: 2073509, category: 'LONG_TERM_BORROWINGS', noteNumber: 4 },
  { id: 'tb-py-4', ledgerName: 'Sundry Creditors (Due to others)', debit: 0, credit: 14160, category: 'TRADE_PAYABLES', noteNumber: 5 },
  { id: 'tb-py-5', ledgerName: 'Other Current Liabilities (Audit Fee + TDS)', debit: 0, credit: 26125, category: 'OTHER_CURRENT_LIABILITIES', noteNumber: 6 },
  { id: 'tb-py-6', ledgerName: 'Fixed Assets Tangible Net (Computer & AC)', debit: 37833, credit: 0, category: 'TANGIBLE_ASSETS', noteNumber: 8 },
  { id: 'tb-py-7', ledgerName: 'Deferred Tax Asset Net', debit: 3107, credit: 0, category: 'DEFERRED_TAX_ASSETS_NET' },
  { id: 'tb-py-8', ledgerName: 'Inventories (Closing Stock)', debit: 597412, credit: 0, category: 'INVENTORIES', noteNumber: 12 },
  { id: 'tb-py-9', ledgerName: 'Cash and Bank Balances', debit: 196292, credit: 0, category: 'CASH_AND_BANK_BALANCES', noteNumber: 7 },
  { id: 'tb-py-10', ledgerName: 'Other Current Assets (Statutory & Advances)', debit: 300347, credit: 0, category: 'OTHER_CURRENT_ASSETS', noteNumber: 9 },
  { id: 'tb-py-11', ledgerName: 'Revenue from Operations', debit: 0, credit: 263690, category: 'REVENUE_FROM_OPERATIONS', noteNumber: 10 },
  { id: 'tb-py-12', ledgerName: 'Other Income', debit: 0, credit: 14530, category: 'OTHER_INCOME', noteNumber: 11 },
  { id: 'tb-py-13', ledgerName: 'Cost of Traded Goods (Opening + Purchases - Closing)', debit: 551659, credit: 0, category: 'COST_OF_TRADED_GOODS', noteNumber: 12 },
  { id: 'tb-py-14', ledgerName: 'Direct Cost (Packing & Printing)', debit: 17700, credit: 0, category: 'DIRECT_COST', noteNumber: 13 },
  { id: 'tb-py-15', ledgerName: 'Administration and Other Expenses', debit: 411507, credit: 0, category: 'ADMINISTRATION_AND_OTHER_EXPENSES', noteNumber: 14 },
  { id: 'tb-py-16', ledgerName: 'Finance Costs (Bank charges)', debit: 236, credit: 0, category: 'FINANCE_COSTS', noteNumber: 15 },
  { id: 'tb-py-17', ledgerName: 'Depreciation and Amortization', debit: 31578, credit: 0, category: 'DEPRECIATION_AND_AMORTISATION', noteNumber: 8 },
  { id: 'tb-py-18', ledgerName: 'Deferred Tax Credit', debit: 0, credit: 3026, category: 'TAX_EXPENSE_DEFERRED' }
];

export const INITIAL_SHAREHOLDERS: ShareholderDetail[] = [
  {
    id: 'sh-1',
    name: 'RAJESH SHARMA',
    address: 'B-42, Defence Colony, New Delhi 110024, Delhi, India',
    status: 'Individual',
    occupation: 'Business',
    nationality: 'Indian',
    dateBecomingMember: '15/04/2021',
    classOfShare: 'Equity',
    sharesHeldCY: 5000,
    sharesHeldPY: 5000,
    faceValue: 10,
    holdingPercentageCY: 50,
    holdingPercentagePY: 50
  },
  {
    id: 'sh-2',
    name: 'ANITA VERMA',
    address: 'C-18, Greater Kailash-I, New Delhi 110048, Delhi, India',
    status: 'Individual',
    occupation: 'Business',
    nationality: 'Indian',
    dateBecomingMember: '15/04/2021',
    classOfShare: 'Equity',
    sharesHeldCY: 5000,
    sharesHeldPY: 5000,
    faceValue: 10,
    holdingPercentageCY: 50,
    holdingPercentagePY: 50
  }
];

export const INITIAL_FIXED_ASSETS: FixedAssetRow[] = [
  {
    id: 'fa-1',
    particulars: 'Computer',
    rate: 63.16,
    method: 'WDV',
    openingWDV: 0,
    additions: 13600,
    deletions: 0,
    totalCost: 13600,
    depreciationForYear: 8566,
    closingWDV: 5034,
    pyClosingWDV: 0
  },
  {
    id: 'fa-2',
    particulars: 'Airconditioner',
    rate: 25.89,
    method: 'WDV',
    openingWDV: 0,
    additions: 24233,
    deletions: 0,
    totalCost: 24233,
    depreciationForYear: 6257,
    closingWDV: 17976,
    pyClosingWDV: 37833
  }
];
