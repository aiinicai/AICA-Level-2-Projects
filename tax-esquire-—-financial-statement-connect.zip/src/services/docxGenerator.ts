import {
  AlignmentType,
  BorderStyle,
  Document,
  HeadingLevel,
  HeightRule,
  Packer,
  Paragraph,
  ShadingType,
  Table,
  TableCell,
  TableRow,
  TextRun,
  WidthType
} from 'docx';
import {
  BalanceSheetData,
  CompanyProfile,
  FinancialStatementsFull,
  NotesToAccountsBreakdown,
  ProfitAndLossData
} from '../types';
import { formatINR } from '../utils/financialCalculations';

// Emerald & Gold Theme Palette for documents
const COLOR_PRIMARY = '0B3D33'; // Deep Emerald
const COLOR_GOLD = 'C9A227'; // Gold
const COLOR_BG_LIGHT = 'F4F8F6';
const COLOR_BORDER = 'CCCCCC';

function createHeaderCell(text: string, widthPercent: number, align: (typeof AlignmentType)[keyof typeof AlignmentType] = AlignmentType.CENTER): TableCell {
  return new TableCell({
    width: { size: widthPercent, type: WidthType.PERCENTAGE },
    shading: { type: ShadingType.CLEAR, fill: COLOR_PRIMARY },
    margins: { top: 120, bottom: 120, left: 140, right: 140 },
    children: [
      new Paragraph({
        alignment: align,
        children: [
          new TextRun({
            text,
            bold: true,
            color: 'FFFFFF',
            size: 20,
            font: 'Georgia'
          })
        ]
      })
    ]
  });
}

function createDataCell(
  text: string,
  widthPercent: number,
  align: (typeof AlignmentType)[keyof typeof AlignmentType] = AlignmentType.LEFT,
  bold = false,
  italic = false,
  isHeaderSub = false
): TableCell {
  return new TableCell({
    width: { size: widthPercent, type: WidthType.PERCENTAGE },
    shading: isHeaderSub ? { type: ShadingType.CLEAR, fill: 'EAEFEF' } : undefined,
    margins: { top: 80, bottom: 80, left: 120, right: 120 },
    children: [
      new Paragraph({
        alignment: align,
        children: [
          new TextRun({
            text,
            bold,
            italics: italic,
            size: bold ? 20 : 18,
            font: 'Calibri'
          })
        ]
      })
    ]
  });
}

export async function generateScheduleIIIDocx(
  inputOrCompany: FinancialStatementsFull | CompanyProfile,
  bsArg?: BalanceSheetData,
  plArg?: ProfitAndLossData,
  notesArg?: NotesToAccountsBreakdown
): Promise<Blob> {
  const isFull = 'company' in inputOrCompany && 'balanceSheet' in inputOrCompany;
  const company = isFull ? (inputOrCompany as FinancialStatementsFull).company : (inputOrCompany as CompanyProfile);
  const bs = isFull ? (inputOrCompany as FinancialStatementsFull).balanceSheet : bsArg!;
  const pl = isFull ? (inputOrCompany as FinancialStatementsFull).profitAndLoss : plArg!;
  const notes = isFull ? (inputOrCompany as FinancialStatementsFull).notes : notesArg!;

  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `${company.name} - Audited Financial Statements FY ${company.financialYearCurrent}`,
    description: 'Companies Act 2013 Schedule III Division I Financial Statements',
    sections: [
      {
        properties: {
          page: {
            margin: { top: 720, bottom: 720, left: 720, right: 720 }
          }
        },
        children: [
          // Company Title Header
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: company.name,
                bold: true,
                size: 28,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 100 },
            children: [
              new TextRun({
                text: company.registeredOffice,
                size: 16,
                font: 'Calibri'
              }),
              new TextRun({
                text: `\nCIN: ${company.cin}`,
                bold: true,
                size: 16,
                color: '555555',
                font: 'Calibri'
              })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 120, after: 200 },
            children: [
              new TextRun({
                text: `Balance Sheet as at ${company.asAtCurrentDate}`,
                bold: true,
                size: 22,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              })
            ]
          }),

          // Balance Sheet Table
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              // Header Row
              new TableRow({
                children: [
                  createHeaderCell('PARTICULARS', 55, AlignmentType.LEFT),
                  createHeaderCell('Notes', 11, AlignmentType.CENTER),
                  createHeaderCell(`As at\n${company.asAtCurrentDate}\n₹`, 17, AlignmentType.RIGHT),
                  createHeaderCell(`As at\n${company.asAtPreviousDate}\n₹`, 17, AlignmentType.RIGHT)
                ]
              }),

              // I. EQUITY AND LIABILITIES
              new TableRow({
                children: [
                  createDataCell('I. EQUITY AND LIABILITIES', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell('', 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell('', 17, AlignmentType.RIGHT, true, false, true)
                ]
              }),
              // 1. Shareholders' Funds
              new TableRow({
                children: [
                  createDataCell("1. Shareholders' funds", 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (a) Share capital', 55),
                  createDataCell('2', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.equityAndLiabilities.shareholdersFunds.shareCapital.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.equityAndLiabilities.shareholdersFunds.shareCapital.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (b) Reserves and surplus', 55),
                  createDataCell('3', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.equityAndLiabilities.shareholdersFunds.reservesAndSurplus.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.equityAndLiabilities.shareholdersFunds.reservesAndSurplus.py), 17, AlignmentType.RIGHT)
                ]
              }),

              // 2. Non-Current Liabilities
              new TableRow({
                children: [
                  createDataCell('2. Non-current liabilities', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (a) Long-term borrowings', 55),
                  createDataCell('4', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.equityAndLiabilities.nonCurrentLiabilities.longTermBorrowings.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.equityAndLiabilities.nonCurrentLiabilities.longTermBorrowings.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (b) Deferred tax liability (net)', 55),
                  createDataCell('', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.equityAndLiabilities.nonCurrentLiabilities.deferredTaxLiabilityNet.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.equityAndLiabilities.nonCurrentLiabilities.deferredTaxLiabilityNet.py), 17, AlignmentType.RIGHT)
                ]
              }),

              // 3. Current Liabilities
              new TableRow({
                children: [
                  createDataCell('3. Current liabilities', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (a) Trade Payables', 55),
                  createDataCell('5', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.equityAndLiabilities.currentLiabilities.tradePayables.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.equityAndLiabilities.currentLiabilities.tradePayables.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (b) Other current liabilities', 55),
                  createDataCell('6', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.equityAndLiabilities.currentLiabilities.otherCurrentLiabilities.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.equityAndLiabilities.currentLiabilities.otherCurrentLiabilities.py), 17, AlignmentType.RIGHT)
                ]
              }),

              // Total Equity & Liabilities
              new TableRow({
                children: [
                  createDataCell('TOTAL EQUITY AND LIABILITIES', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell(formatINR(bs.equityAndLiabilities.totalEquityAndLiabilities.cy), 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell(formatINR(bs.equityAndLiabilities.totalEquityAndLiabilities.py), 17, AlignmentType.RIGHT, true, false, true)
                ]
              }),

              // II. ASSETS
              new TableRow({
                children: [
                  createDataCell('II. ASSETS', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell('', 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell('', 17, AlignmentType.RIGHT, true, false, true)
                ]
              }),
              // 1. Non-Current Assets
              new TableRow({
                children: [
                  createDataCell('1. Non-current assets', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (a) Fixed assets (Net) - Tangible assets', 55),
                  createDataCell('8', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.assets.nonCurrentAssets.fixedAssetsTangible.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.assets.nonCurrentAssets.fixedAssetsTangible.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (b) Deferred tax assets (net)', 55),
                  createDataCell('', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.assets.nonCurrentAssets.deferredTaxAssetsNet.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.assets.nonCurrentAssets.deferredTaxAssetsNet.py), 17, AlignmentType.RIGHT)
                ]
              }),

              // 2. Current Assets
              new TableRow({
                children: [
                  createDataCell('2. Current assets', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (a) Inventories', 55),
                  createDataCell('12', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.assets.currentAssets.inventories.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.assets.currentAssets.inventories.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (b) Trade receivables', 55),
                  createDataCell('', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.assets.currentAssets.tradeReceivables.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.assets.currentAssets.tradeReceivables.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (c) Cash and bank balances', 55),
                  createDataCell('7', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.assets.currentAssets.cashAndBankBalances.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.assets.currentAssets.cashAndBankBalances.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (d) Other current assets', 55),
                  createDataCell('9', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(bs.assets.currentAssets.otherCurrentAssets.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(bs.assets.currentAssets.otherCurrentAssets.py), 17, AlignmentType.RIGHT)
                ]
              }),

              // Total Assets
              new TableRow({
                children: [
                  createDataCell('TOTAL ASSETS', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell(formatINR(bs.assets.totalAssets.cy), 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell(formatINR(bs.assets.totalAssets.py), 17, AlignmentType.RIGHT, true, false, true)
                ]
              })
            ]
          }),

          // Notes reference note
          new Paragraph({
            spacing: { before: 100, after: 150 },
            children: [
              new TextRun({
                text: 'The accompanying notes 1 to 16 form an integral part of the Balance Sheet.',
                italics: true,
                size: 16
              })
            ]
          }),
          new Paragraph({
            spacing: { after: 150 },
            children: [
              new TextRun({
                text: 'This is the Balance Sheet referred to in our report of even date.',
                italics: true,
                size: 16
              })
            ]
          }),

          // Closing Signatory Block for Balance Sheet
          createSignatoryBlock(company),

          // --- PAGE BREAK FOR STATEMENT OF PROFIT & LOSS ---
          new Paragraph({ pageBreakBefore: true }),

          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: company.name,
                bold: true,
                size: 28,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { after: 100 },
            children: [
              new TextRun({
                text: company.registeredOffice,
                size: 16,
                font: 'Calibri'
              }),
              new TextRun({
                text: `\nCIN: ${company.cin}`,
                bold: true,
                size: 16,
                color: '555555',
                font: 'Calibri'
              })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 120, after: 200 },
            children: [
              new TextRun({
                text: `Statement of Profit & Loss for the year ended ${company.asAtCurrentDate}`,
                bold: true,
                size: 22,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              })
            ]
          }),

          // Profit and Loss Table
          new Table({
            width: { size: 100, type: WidthType.PERCENTAGE },
            rows: [
              new TableRow({
                children: [
                  createHeaderCell('PARTICULARS', 55, AlignmentType.LEFT),
                  createHeaderCell('Notes', 11, AlignmentType.CENTER),
                  createHeaderCell(`Year ended\n${company.asAtCurrentDate}\n₹`, 17, AlignmentType.RIGHT),
                  createHeaderCell(`Year ended\n${company.asAtPreviousDate}\n₹`, 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('I. Revenue from Operations', 55),
                  createDataCell('10', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.income.revenueFromOperations.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.income.revenueFromOperations.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('II. Other Income', 55),
                  createDataCell('11', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.income.otherIncome.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.income.otherIncome.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('III. Total Revenue (I + II)', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell(formatINR(pl.income.totalRevenue.cy, true), 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell(formatINR(pl.income.totalRevenue.py), 17, AlignmentType.RIGHT, true, false, true)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('IV. EXPENDITURE', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    Cost of Traded Goods', 55),
                  createDataCell('12', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.expenses.costOfTradedGoods.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.expenses.costOfTradedGoods.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    Direct Cost', 55),
                  createDataCell('13', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.expenses.directCost.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.expenses.directCost.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    Administration and Others Expenses', 55),
                  createDataCell('14', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.expenses.adminAndOtherExpenses.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.expenses.adminAndOtherExpenses.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    Finance Costs', 55),
                  createDataCell('15', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.expenses.financeCosts.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.expenses.financeCosts.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    Depreciation and Amortization Expenses', 55),
                  createDataCell('8', 11, AlignmentType.CENTER),
                  createDataCell(formatINR(pl.expenses.depreciationAndAmortisation.cy, true), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.expenses.depreciationAndAmortisation.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('Total Expenses', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell(formatINR(pl.expenses.totalExpenses.cy, true), 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell(formatINR(pl.expenses.totalExpenses.py), 17, AlignmentType.RIGHT, true, false, true)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('V. Profit Before tax (III - IV)', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell(formatINR(pl.profitBeforeTax.cy, true), 17, AlignmentType.RIGHT, true),
                  createDataCell(formatINR(pl.profitBeforeTax.py), 17, AlignmentType.RIGHT, true)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('VI. Prior Period Expenses', 55),
                  createDataCell('', 11),
                  createDataCell('-', 17, AlignmentType.RIGHT),
                  createDataCell('-', 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('VII. Profit before tax (V - VI)', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell(formatINR(pl.profitBeforeTaxNet.cy, true), 17, AlignmentType.RIGHT, true),
                  createDataCell(formatINR(pl.profitBeforeTaxNet.py), 17, AlignmentType.RIGHT, true)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('VIII. Tax expense:', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (1) Current tax', 55),
                  createDataCell('', 11),
                  createDataCell('-', 17, AlignmentType.RIGHT),
                  createDataCell('-', 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (2) Deferred tax charge / (credit)', 55),
                  createDataCell('', 11),
                  createDataCell(formatINR(pl.taxExpense.deferredTax.cy), 17, AlignmentType.RIGHT),
                  createDataCell(formatINR(pl.taxExpense.deferredTax.py), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('IX. Profit (Loss) for the period (VII - VIII)', 55, AlignmentType.LEFT, true, false, true),
                  createDataCell('', 11, AlignmentType.CENTER, true, false, true),
                  createDataCell(formatINR(pl.profitAfterTax.cy, true), 17, AlignmentType.RIGHT, true, false, true),
                  createDataCell(formatINR(pl.profitAfterTax.py), 17, AlignmentType.RIGHT, true, false, true)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('X. Earnings per equity share (Face Value Rs. 10 each)', 55, AlignmentType.LEFT, true),
                  createDataCell('', 11),
                  createDataCell('', 17),
                  createDataCell('', 17)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (1) Basic (₹)', 55),
                  createDataCell('', 11),
                  createDataCell(pl.eps.basic.cy.toFixed(2), 17, AlignmentType.RIGHT),
                  createDataCell(pl.eps.basic.py.toFixed(2), 17, AlignmentType.RIGHT)
                ]
              }),
              new TableRow({
                children: [
                  createDataCell('    (2) Diluted (₹)', 55),
                  createDataCell('', 11),
                  createDataCell(pl.eps.diluted.cy.toFixed(2), 17, AlignmentType.RIGHT),
                  createDataCell(pl.eps.diluted.py.toFixed(2), 17, AlignmentType.RIGHT)
                ]
              })
            ]
          }),

          new Paragraph({
            spacing: { before: 100, after: 150 },
            children: [
              new TextRun({
                text: 'The accompanying notes 1 to 16 form an integral part of the Profit and Loss Account.',
                italics: true,
                size: 16
              })
            ]
          }),
          new Paragraph({
            spacing: { after: 150 },
            children: [
              new TextRun({
                text: 'This is the Profit and Loss Account referred to in our report of even date.',
                italics: true,
                size: 16
              })
            ]
          }),

          createSignatoryBlock(company),

          // --- PAGE BREAK FOR SCHEDULE NOTES ---
          new Paragraph({ pageBreakBefore: true }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: `${company.name}\nNotes to Financial Statements for the year ended ${company.asAtCurrentDate}`,
                bold: true,
                size: 24,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              })
            ]
          }),

          // Note 1: Policies
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({
                text: 'NOTE "1" - SIGNIFICANT ACCOUNTING POLICIES AND NOTES ON ACCOUNT',
                bold: true,
                size: 20,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              })
            ]
          }),
          new Paragraph({
            spacing: { after: 80 },
            children: [
              new TextRun({ text: '1.1 Corporate Information: ', bold: true, size: 18 }),
              new TextRun({ text: `The company was incorporated on ${company.incorporationDate} under the Companies Act. Principal activity: ${company.principalBusinessActivity}.`, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 80 },
            children: [
              new TextRun({ text: '1.2 Basis of preparation of Financial Statements: ', bold: true, size: 18 }),
              new TextRun({ text: 'The Financial Statements have been prepared in accordance with generally accepted accounting principles in India (Indian GAAP) to comply in all material respects with the Accounting Standards notified under section 133 of the Companies Act 2013 read together with paragraph 7 of Companies (Accounts) Rules 2014.', size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 80 },
            children: [
              new TextRun({ text: '1.3 Tangible Fixed Assets & Depreciation: ', bold: true, size: 18 }),
              new TextRun({ text: `Tangible Fixed Assets are stated at historical cost less accumulated depreciation. ${notes.note1_Policies.depreciationMethod}.`, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 80 },
            children: [
              new TextRun({ text: '1.4 Valuation of Inventories: ', bold: true, size: 18 }),
              new TextRun({ text: notes.note1_Policies.inventoryMethod, size: 18 })
            ]
          }),

          // Note 2: Share Capital
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'NOTE "2" - SHARE CAPITAL', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Particulars', `As at ${company.asAtCurrentDate} (₹)`, `As at ${company.asAtPreviousDate} (₹)`],
            [`Authorised: ${company.authorisedShares} Equity Shares of Rs. ${company.faceValuePerShare}/- each`, formatINR(company.authorisedShareValue), formatINR(company.authorisedShareValue)],
            [`Issued: ${company.issuedShares} Equity Shares of Rs. ${company.faceValuePerShare}/- each`, formatINR(company.issuedShareValue), formatINR(company.issuedShareValue)],
            [`Subscribed and fully paid: ${company.issuedShares} Equity Shares of Rs. ${company.faceValuePerShare}/- each`, formatINR(company.issuedShareValue), formatINR(company.issuedShareValue)]
          ]),

          // Note 2.2: Shareholding details
          new Paragraph({
            spacing: { before: 140, after: 80 },
            children: [
              new TextRun({ text: '2.2 Shares held by each shareholder holding more than 5% shares:', bold: true, size: 18 })
            ]
          }),
          createTableFromRows([
            ['Name of Shareholder', `% of holding (${company.asAtCurrentDate})`, `No. of shares (${company.asAtCurrentDate})`, `% of holding (${company.asAtPreviousDate})`, `No. of shares (${company.asAtPreviousDate})`],
            ...notes.note2_ShareCapital.shareholders.map((sh) => [
              sh.name,
              `${sh.holdingPercentageCY}%`,
              formatINR(sh.sharesHeldCY),
              `${sh.holdingPercentagePY}%`,
              formatINR(sh.sharesHeldPY)
            ])
          ]),

          // Note 3: Reserves and Surplus
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'NOTE "3" - RESERVES AND SURPLUS', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Particulars', `As at ${company.asAtCurrentDate} (₹)`, `As at ${company.asAtPreviousDate} (₹)`],
            ['Profit & Loss Account - Balance Brought Forward from Previous Year', formatINR(notes.note3_ReservesSurplus.openingBalance), formatINR(notes.note3_ReservesSurplus.pyOpeningBalance)],
            ['Add: Current Year Profit / (Loss) attributable to Shareholders', formatINR(notes.note3_ReservesSurplus.currentYearProfit), formatINR(notes.note3_ReservesSurplus.pyCurrentYearProfit)],
            ['Total Closing Reserves and Surplus', formatINR(notes.note3_ReservesSurplus.closingBalance), formatINR(notes.note3_ReservesSurplus.pyClosingBalance)]
          ]),

          // Note 4: Long-Term Borrowings
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'NOTE "4" - LONG TERM BORROWINGS', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Particulars', `As at ${company.asAtCurrentDate} (₹)`, `As at ${company.asAtPreviousDate} (₹)`],
            ['Unsecured Long Term Borrowings - Loan from directors', formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsCY), formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsPY)],
            ['Secured Long Term Borrowings', '-', '-'],
            ['Total Long-Term Borrowings', formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsCY), formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsPY)]
          ]),

          // Note 8: Depreciation on Fixed Assets Schedule
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'NOTE "8" - DEPRECIATION ON FIXED ASSETS (As per Companies Act, 2013)', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Particulars', 'Rate', 'WDV as on 01.04.23', 'Addition', 'Deletion', 'Total Cost', 'Depreciation for Year', 'WDV as on 31.03.24'],
            ...notes.note8_FixedAssets.assets.map((a) => [
              a.particulars,
              `${a.rate}%`,
              formatINR(a.openingWDV),
              formatINR(a.additions),
              formatINR(a.deletions),
              formatINR(a.totalCost),
              formatINR(a.depreciationForYear),
              formatINR(a.closingWDV)
            ]),
            ['Total Current Year', '-', '-', formatINR(37833), '-', formatINR(37833), formatINR(notes.note8_FixedAssets.totalCYDepreciation), formatINR(notes.note8_FixedAssets.totalCYClosingWDV)],
            ['Total Previous Year', '-', '-', formatINR(69411), '-', formatINR(69411), formatINR(notes.note8_FixedAssets.totalPYDepreciation), formatINR(notes.note8_FixedAssets.totalPYClosingWDV)]
          ]),

          // Note 14 & 14.1 Admin expenses
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'NOTE "14" - ADMINISTRATIVE AND OTHER EXPENSES', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Particulars', `For the year ended ${company.asAtCurrentDate} (₹)`, `For the year ended ${company.asAtPreviousDate} (₹)`],
            ...notes.note14_AdminExpenses.items.map((i) => [i.label, formatINR(i.cy), formatINR(i.py)]),
            ['Total Administrative and Other Expenses', formatINR(notes.note14_AdminExpenses.totalCY), formatINR(notes.note14_AdminExpenses.totalPY)],
            ['14.1 Payment to Auditor (Statutory Audit Fee)', formatINR(notes.note14_AdminExpenses.statutoryAuditFeeCY), formatINR(notes.note14_AdminExpenses.statutoryAuditFeePY)]
          ])
        ]
      }
    ]
  });

  return await Packer.toBlob(doc);
}

function createTableFromRows(data: string[][]): Table {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: data.map((row, rIdx) => {
      const isHeader = rIdx === 0;
      const isTotal = rIdx === data.length - 1 || rIdx === data.length - 2;
      return new TableRow({
        children: row.map((cellText, cIdx) => {
          const colWidth = Math.floor(100 / row.length);
          if (isHeader) {
            return createHeaderCell(cellText, colWidth, cIdx === 0 ? AlignmentType.LEFT : AlignmentType.RIGHT);
          }
          return createDataCell(
            cellText,
            colWidth,
            cIdx === 0 ? AlignmentType.LEFT : AlignmentType.RIGHT,
            isTotal,
            false,
            isTotal
          );
        })
      });
    })
  });
}

function createSignatoryBlock(company: CompanyProfile): Table {
  const sig = company.signatories;
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      bottom: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      left: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      right: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideHorizontal: { style: BorderStyle.NONE, size: 0, color: 'auto' },
      insideVertical: { style: BorderStyle.NONE, size: 0, color: 'auto' }
    },
    rows: [
      // Board heading
      new TableRow({
        children: [
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: 'For and on behalf of the Board', bold: true, size: 18, font: 'Georgia' })
                ]
              })
            ]
          }),
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({ text: `For ${sig.auditorFirmName}`, bold: true, size: 18, font: 'Georgia' }),
                  new TextRun({ text: '\nChartered Accountants', size: 16, font: 'Georgia' }),
                  new TextRun({ text: `\nFirm's Registration No. ${sig.auditorFirmRegNo}`, size: 16, font: 'Calibri' })
                ]
              })
            ]
          })
        ]
      }),
      // Space for signatures
      new TableRow({
        height: { value: 600, rule: HeightRule.EXACT },
        children: [
          new TableCell({ width: { size: 50, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: '' })] }),
          new TableCell({ width: { size: 50, type: WidthType.PERCENTAGE }, children: [new Paragraph({ text: '' })] })
        ]
      }),
      // Director 1 & Auditor info
      new TableRow({
        children: [
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: 'Sd/-\n', size: 16 }),
                  new TextRun({ text: `${sig.director1Name}\n`, bold: true, size: 18 }),
                  new TextRun({ text: `(${sig.director1Designation})\n`, size: 16 }),
                  new TextRun({ text: `DIN- ${sig.director1DIN}\n\n`, size: 16 }),
                  new TextRun({ text: 'Sd/-\n', size: 16 }),
                  new TextRun({ text: `${sig.director2Name}\n`, bold: true, size: 18 }),
                  new TextRun({ text: `(${sig.director2Designation})\n`, size: 16 }),
                  new TextRun({ text: `DIN- ${sig.director2DIN}`, size: 16 })
                ]
              })
            ]
          }),
          new TableCell({
            width: { size: 50, type: WidthType.PERCENTAGE },
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({ text: 'Sd/-\n', size: 16 }),
                  new TextRun({ text: `${sig.auditorPartnerName}\n`, bold: true, size: 18 }),
                  new TextRun({ text: 'Chartered Accountant\n', size: 16 }),
                  new TextRun({ text: `${sig.auditorDesignation}\n`, size: 16 }),
                  new TextRun({ text: `Membership No. ${sig.auditorMembershipNo}\n`, size: 16 }),
                  new TextRun({ text: `UDIN: ${sig.auditorUDIN}\n\n`, bold: true, size: 16, color: COLOR_PRIMARY }),
                  new TextRun({ text: `Place: ${sig.placeOfSigning}\nDate: ${sig.dateOfSigning}`, size: 16 })
                ]
              })
            ]
          })
        ]
      })
    ]
  });
}

// Generate Form AOC-4 Draft
export async function generateAOC4DraftDocx(
  inputOrCompany: FinancialStatementsFull | CompanyProfile,
  bsArg?: BalanceSheetData,
  plArg?: ProfitAndLossData
): Promise<Blob> {
  const isFull = 'company' in inputOrCompany && 'balanceSheet' in inputOrCompany;
  const company = isFull ? (inputOrCompany as FinancialStatementsFull).company : (inputOrCompany as CompanyProfile);
  const bs = isFull ? (inputOrCompany as FinancialStatementsFull).balanceSheet : bsArg!;
  const pl = isFull ? (inputOrCompany as FinancialStatementsFull).profitAndLoss : plArg!;

  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `Form AOC-4 Draft - ${company.name}`,
    sections: [
      {
        properties: {
          page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } }
        },
        children: [
          // Statutory Draft Banner
          new Paragraph({
            alignment: AlignmentType.CENTER,
            shading: { type: ShadingType.CLEAR, fill: 'FFEAEA' },
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: '⚠️ DRAFT — INTERNAL REVIEW COPY\nRequires CA Certification and re-entry on MCA V3 Portal before statutory filing.',
                bold: true,
                size: 20,
                color: '990000',
                font: 'Georgia'
              })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: 'FORM NO. AOC-4',
                bold: true,
                size: 26,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              }),
              new TextRun({
                text: '\n[Pursuant to Section 137 of the Companies Act, 2013 and rule 12(1) of the Companies (Accounts) Rules, 2014]',
                italics: true,
                size: 16,
                font: 'Calibri'
              }),
              new TextRun({
                text: '\nForm for filing financial statement and other documents with the Registrar',
                bold: true,
                size: 18,
                font: 'Georgia'
              })
            ]
          }),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'PART A - GENERAL INFORMATION OF THE COMPANY', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Field Description', 'Company Information / Value'],
            ['Corporate Identity Number (CIN)', company.cin],
            ['Name of the Company', company.name],
            ['Registered Office Address', company.registeredOffice],
            ['Date of Incorporation', company.incorporationDate],
            ['Type of Company', 'Private Limited Company / Non-Govt Indian Company'],
            ['Financial Year Reported', `01/04/${Number(company.financialYearCurrent.split('-')[0])} to 31/03/20${company.financialYearCurrent.split('-')[1]}`],
            ['Date of Board Meeting where Financials Approved', company.signatories.boardMeetingDate],
            ['Date of Annual General Meeting (AGM)', company.signatories.agmDate],
            ['Whether AGM held', 'Yes'],
            ['Authorised Share Capital (INR)', formatINR(company.authorisedShareValue)],
            ['Paid Up Share Capital (INR)', formatINR(company.issuedShareValue)]
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'PART B - FINANCIAL HIGHLIGHTS & BALANCE SHEET SUMMARY', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Financial Parameter', `Current Year (${company.asAtCurrentDate}) ₹`, `Previous Year (${company.asAtPreviousDate}) ₹`],
            ['Gross Turnover / Revenue from Operations', formatINR(pl.income.revenueFromOperations.cy), formatINR(pl.income.revenueFromOperations.py)],
            ['Other Income', formatINR(pl.income.otherIncome.cy), formatINR(pl.income.otherIncome.py)],
            ['Total Expenses', formatINR(pl.expenses.totalExpenses.cy), formatINR(pl.expenses.totalExpenses.py)],
            ['Profit / (Loss) Before Tax', formatINR(pl.profitBeforeTaxNet.cy), formatINR(pl.profitBeforeTaxNet.py)],
            ['Profit / (Loss) After Tax', formatINR(pl.profitAfterTax.cy), formatINR(pl.profitAfterTax.py)],
            ['Paid-Up Equity Capital', formatINR(bs.equityAndLiabilities.shareholdersFunds.shareCapital.cy), formatINR(bs.equityAndLiabilities.shareholdersFunds.shareCapital.py)],
            ['Reserves and Surplus', formatINR(bs.equityAndLiabilities.shareholdersFunds.reservesAndSurplus.cy), formatINR(bs.equityAndLiabilities.shareholdersFunds.reservesAndSurplus.py)],
            ['Total Assets', formatINR(bs.assets.totalAssets.cy), formatINR(bs.assets.totalAssets.py)],
            ['Earnings Per Share (Basic/Diluted)', `₹ ${pl.eps.basic.cy.toFixed(2)}`, `₹ ${pl.eps.basic.py.toFixed(2)}`]
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'PART C - STATUTORY AUDITOR PARTICULARS & UDIN', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Auditor Field', 'Detail'],
            ['Statutory Audit Firm Name', company.signatories.auditorFirmName],
            ['Firm Registration Number (FRN)', company.signatories.auditorFirmRegNo],
            ['Signing Partner / Proprietor', company.signatories.auditorPartnerName],
            ['ICAI Membership Number', company.signatories.auditorMembershipNo],
            ['Unique Document Identification Number (UDIN)', company.signatories.auditorUDIN],
            ['Auditor Report Date & Place', `${company.signatories.dateOfSigning} at ${company.signatories.placeOfSigning}`]
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'PART D - ATTACHMENTS CHECKLIST FOR MCA V3', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Attachment Name', 'Mandatory / Optional', 'Status in Pack'],
            ['1. Audited Financial Statements (Balance Sheet & P&L with Notes 1-16)', 'Mandatory', 'Attached & Verified'],
            ['2. Independent Statutory Auditor\'s Report with CARO (if applicable)', 'Mandatory', 'Attached & Verified'],
            ["3. Board of Directors' Report with Section 134 disclosures", 'Mandatory', 'Attached & Verified'],
            ['4. Notice of Annual General Meeting (AGM) & Proxy Form', 'Mandatory', 'Attached & Verified'],
            ['5. Extract of Annual Return in Form MGT-9', 'Mandatory', 'Attached & Verified'],
            ['6. Certified True Copy of Board Resolution approving Financials', 'Mandatory', 'Attached & Verified']
          ])
        ]
      }
    ]
  });
  return await Packer.toBlob(doc);
}

// Generate Form MGT-7 / MGT-9 Draft
export async function generateMGT7DraftDocx(
  inputOrCompany: FinancialStatementsFull | CompanyProfile,
  notesArg?: NotesToAccountsBreakdown
): Promise<Blob> {
  const isFull = 'company' in inputOrCompany && 'balanceSheet' in inputOrCompany;
  const company = isFull ? (inputOrCompany as FinancialStatementsFull).company : (inputOrCompany as CompanyProfile);
  const notes = isFull ? (inputOrCompany as FinancialStatementsFull).notes : notesArg!;

  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `Form MGT-9 / MGT-7 Draft - ${company.name}`,
    sections: [
      {
        properties: {
          page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } }
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            shading: { type: ShadingType.CLEAR, fill: 'FFEAEA' },
            spacing: { after: 180 },
            children: [
              new TextRun({
                text: '⚠️ DRAFT — INTERNAL REVIEW COPY\nRequires CA Certification and re-entry on MCA V3 before statutory filing.',
                bold: true,
                size: 20,
                color: '990000',
                font: 'Georgia'
              })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({
                text: 'FORM NO. MGT-9\nEXTRACT OF ANNUAL RETURN',
                bold: true,
                size: 26,
                color: COLOR_PRIMARY,
                font: 'Georgia'
              }),
              new TextRun({
                text: `\nAs on financial year ended on ${company.asAtCurrentDate}`,
                bold: true,
                size: 18,
                font: 'Calibri'
              }),
              new TextRun({
                text: '\n[Pursuant to Section 92(3) of the Companies Act, 2013 and rule 12(1) of the Companies (Management & Administration) Rules, 2014]',
                italics: true,
                size: 16,
                font: 'Calibri'
              })
            ]
          }),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'I. REGISTRATION & OTHER DETAILS', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['1. CIN', company.cin],
            ['2. Registration Date', company.incorporationDate],
            ['3. Name of the Company', company.name],
            ['4. Category / Sub-category', 'Company limited by Shares / Non-govt. Indian Company'],
            ['5. Registered office & contact details', company.registeredOffice],
            ['6. Whether listed company', 'NO'],
            ['7. Registrar & Transfer Agent details', 'N.A.']
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'II. PRINCIPAL BUSINESS ACTIVITIES OF THE COMPANY', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['S.No', 'Name and Description of main products / services', 'NIC Code of product/service', '% to total turnover'],
            ['1', company.principalBusinessActivity, company.nicCode, `${company.turnoverPercentage}%`]
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'III. SHARE HOLDING PATTERN (Category-wise Equity Shares)', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Category of Shareholders', `Beginning of Year (${company.asAtPreviousDate})`, `% of Total`, `End of Year (${company.asAtCurrentDate})`, `% of Total`, '% Change'],
            ['A. Promoters (Indian Individuals)', '10,000', '100%', '10,000', '100%', 'NIL'],
            ['B. Public Shareholding (Institutions & Others)', 'NIL', '0%', 'NIL', '0%', 'NIL'],
            ['C. Shares held by Custodian for GDRs/ADRs', 'NIL', '0%', 'NIL', '0%', 'NIL'],
            ['Grand Total (A+B+C)', '10,000', '100%', '10,000', '100%', 'NIL']
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'IV. PROMOTER SHAREHOLDING BREAKUP', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['S.No', 'Shareholder Name', 'Shares (Beginning)', '% of Total', 'Shares (End of Year)', '% of Total', '% Change'],
            ...notes.note2_ShareCapital.shareholders.map((sh, idx) => [
              `${idx + 1}`,
              sh.name,
              formatINR(sh.sharesHeldPY),
              `${sh.holdingPercentagePY}%`,
              formatINR(sh.sharesHeldCY),
              `${sh.holdingPercentageCY}%`,
              'NIL'
            ])
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'V. INDEBTEDNESS SUMMARY', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Indebtedness Detail', 'Secured Loans (₹)', 'Unsecured Loans (₹)', 'Total Indebtedness (₹)'],
            ['Indebtedness at beginning of FY', '-', formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsPY), formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsPY)],
            ['Net Addition / (Reduction) during Year', '-', formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsCY - notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsPY), formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsCY - notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsPY)],
            ['Indebtedness at end of FY', '-', formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsCY), formatINR(notes.note4_LongTermBorrowings.unsecuredLoanFromDirectorsCY)]
          ]),
          new Paragraph({
            spacing: { before: 200, after: 100 },
            children: [
              new TextRun({ text: 'VI. REMUNERATION & PENALTIES', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Description', 'Details / Remuneration Paid'],
            ['Remuneration to Managing Director / Whole-time Directors', 'NIL (No remuneration paid during the year)'],
            ['Remuneration to Key Managerial Personnel (CEO/CS/CFO)', 'N.A. / NIL'],
            ['Penalties / Punishments / Compounding of Offences', 'NIL (No penalties or compounding of offences)']
          ])
        ]
      }
    ]
  });
  return await Packer.toBlob(doc);
}

// Generate Auditor's Report Document
export async function generateAuditorsReportDocx(
  inputOrCompany: FinancialStatementsFull | CompanyProfile
): Promise<Blob> {
  const isFull = 'company' in inputOrCompany && 'balanceSheet' in inputOrCompany;
  const company = isFull ? (inputOrCompany as FinancialStatementsFull).company : (inputOrCompany as CompanyProfile);
  const sig = company.signatories;
  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `Independent Auditor's Report - ${company.name}`,
    sections: [
      {
        properties: {
          page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } }
        },
        children: [
          // Auditor Firm Letterhead
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: sig.auditorFirmName, bold: true, size: 26, color: COLOR_PRIMARY, font: 'Georgia' }),
              new TextRun({ text: '\nCHARTERED ACCOUNTANTS', bold: true, size: 18, color: COLOR_GOLD, font: 'Georgia' }),
              new TextRun({ text: `\n${sig.auditorAddress}`, size: 16, font: 'Calibri' }),
              new TextRun({ text: `\nEmail: ${sig.auditorEmail} | Ph: ${sig.auditorPhone}`, size: 16, font: 'Calibri' })
            ]
          }),
          new Paragraph({
            spacing: { before: 180, after: 120 },
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: 'INDEPENDENT AUDITOR\'S REPORT', bold: true, size: 24, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: `To the Members of\n${company.name}`, bold: true, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: 'Report on the Financial Statements\n', bold: true, size: 18 }),
              new TextRun({ text: `We have audited the accompanying financial statements of ${company.name} ("the Company"), which comprise the Balance Sheet as at March 31, 2024, and the Statement of Profit and Loss for the year then ended, and a summary of significant accounting policies and other explanatory information.`, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: 'Management\'s Responsibility for the Financial Statements\n', bold: true, size: 18 }),
              new TextRun({ text: 'The Company\'s Board of Directors is responsible for the matters stated in Section 134(5) of the Companies Act, 2013 ("the Act") with respect to the preparation of these financial statements that give a true and fair view of the financial position and financial performance of the Company in accordance with the accounting principles generally accepted in India, including the Accounting Standards specified under Section 133 of the Act.', size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: 'Auditor\'s Responsibility\n', bold: true, size: 18 }),
              new TextRun({ text: 'Our responsibility is to express an opinion on these financial statements based on our audit. We conducted our audit in accordance with the Standards on Auditing specified under Section 143(10) of the Act. Those Standards require that we comply with ethical requirements and plan and perform the audit to obtain reasonable assurance about whether the financial statements are free from material misstatement.', size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: 'Opinion\n', bold: true, size: 18 }),
              new TextRun({ text: 'In our opinion and to the best of our information and according to the explanations given to us, the aforesaid financial statements give the information required by the Act in the manner so required and give a true and fair view in conformity with the accounting principles generally accepted in India, of the state of affairs of the Company as at March 31, 2024, and its loss for the year ended on that date.', size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: 'Report on Other Legal and Regulatory Requirements\n', bold: true, size: 18 }),
              new TextRun({ text: '1. Requirements of the Companies (Auditor\'s Report) Order, 2016 / 2020 ("the Order") issued by the Central Government of India in terms of sub-section (11) of Section 143 of the Act, are not applicable to the Company as it is a Small Company.\n2. As required by Section 143(3) of the Act, we report that we have sought and obtained all information, proper books of account have been kept, and the Balance Sheet and Statement of Profit and Loss are in agreement with the books of account.', size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { before: 200 },
            children: [
              new TextRun({ text: `For ${sig.auditorFirmName}\n`, bold: true, size: 18 }),
              new TextRun({ text: 'Chartered Accountants\n', size: 16 }),
              new TextRun({ text: `Firm's Registration No. ${sig.auditorFirmRegNo}\n\n\n`, size: 16 }),
              new TextRun({ text: 'Sd/-\n', size: 16 }),
              new TextRun({ text: `${sig.auditorPartnerName}\n`, bold: true, size: 18 }),
              new TextRun({ text: 'Chartered Accountant\n', size: 16 }),
              new TextRun({ text: `${sig.auditorDesignation}\n`, size: 16 }),
              new TextRun({ text: `Membership No. ${sig.auditorMembershipNo}\n`, size: 16 }),
              new TextRun({ text: `UDIN: ${sig.auditorUDIN}\n\n`, bold: true, size: 16, color: COLOR_PRIMARY }),
              new TextRun({ text: `Place: ${sig.placeOfSigning}\nDate: ${sig.dateOfSigning}`, size: 16 })
            ]
          })
        ]
      }
    ]
  });
  return await Packer.toBlob(doc);
}

// Generate Directors' Report Document
export async function generateDirectorsReportDocx(
  inputOrCompany: FinancialStatementsFull | CompanyProfile,
  plArg?: ProfitAndLossData
): Promise<Blob> {
  const isFull = 'company' in inputOrCompany && 'balanceSheet' in inputOrCompany;
  const company = isFull ? (inputOrCompany as FinancialStatementsFull).company : (inputOrCompany as CompanyProfile);
  const pl = isFull ? (inputOrCompany as FinancialStatementsFull).profitAndLoss : plArg!;
  const sig = company.signatories;
  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `Directors' Report - ${company.name}`,
    sections: [
      {
        properties: {
          page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } }
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: company.name, bold: true, size: 26, color: COLOR_PRIMARY, font: 'Georgia' }),
              new TextRun({ text: `\n${company.registeredOffice}`, size: 16, font: 'Calibri' }),
              new TextRun({ text: `\nCIN: ${company.cin}`, bold: true, size: 16, color: '555555' })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 160 },
            children: [
              new TextRun({ text: "DIRECTORS' REPORT", bold: true, size: 24, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: `To the Members,\n${company.name}\nYour Directors are pleased to present the Annual Report of your Company together with the Audited Statement of Accounts and the Auditors' Report for the financial year ended ${company.asAtCurrentDate}.`, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { before: 120, after: 80 },
            children: [
              new TextRun({ text: '1. FINANCIAL RESULTS', bold: true, size: 20, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['Particulars', `FY ${company.financialYearCurrent} (₹)`, `Previous Year (₹)`],
            ['Turnover including Other Income', formatINR(pl.income.totalRevenue.cy), formatINR(pl.income.totalRevenue.py)],
            ['Total Expenses', formatINR(pl.expenses.totalExpenses.cy), formatINR(pl.expenses.totalExpenses.py)],
            ['Profit / (Loss) Before Tax', formatINR(pl.profitBeforeTaxNet.cy), formatINR(pl.profitBeforeTaxNet.py)],
            ['Less: Current Taxes', 'NIL', 'NIL'],
            ['Less: Deferred Tax Charge / (Credit)', formatINR(pl.taxExpense.deferredTax.cy), formatINR(pl.taxExpense.deferredTax.py)],
            ['Profit / (Loss) After Tax', formatINR(pl.profitAfterTax.cy), formatINR(pl.profitAfterTax.py)]
          ]),
          new Paragraph({
            spacing: { before: 140, after: 80 },
            children: [
              new TextRun({ text: '2. OPERATIONS AND BUSINESS & 3. DIVIDEND', bold: true, size: 18 }),
              new TextRun({ text: `\nThe Company is engaged in ${company.principalBusinessActivity}. There has been no change in business during the year. In view of business growth, the Directors do not propose any dividend for the year.`, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { before: 140, after: 80 },
            children: [
              new TextRun({ text: "4. DIRECTORS' RESPONSIBILITY STATEMENT (Section 134(5))", bold: true, size: 18 }),
              new TextRun({ text: '\nPursuant to Section 134(5) of the Companies Act, 2013, the Directors confirm that applicable accounting standards have been followed, accounting policies applied consistently, proper care taken for maintenance of accounting records, accounts prepared on a going concern basis, and proper compliance systems devised and operating effectively.', size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { before: 200 },
            children: [
              new TextRun({ text: `For and on behalf of the Board of Directors of\n${company.name}\n\n\n`, bold: true, size: 18 }),
              new TextRun({ text: 'Sd/-                                                             Sd/-\n', size: 16 }),
              new TextRun({ text: `${sig.director1Name}                                        ${sig.director2Name}\n`, bold: true, size: 18 }),
              new TextRun({ text: `(${sig.director1Designation})                                                     (${sig.director2Designation})\n`, size: 16 }),
              new TextRun({ text: `DIN: ${sig.director1DIN}                                                 DIN: ${sig.director2DIN}\n\n`, size: 16 }),
              new TextRun({ text: `Place: ${sig.placeOfSigning}\nDate: ${sig.dateOfSigning}`, size: 16 })
            ]
          })
        ]
      }
    ]
  });
  return await Packer.toBlob(doc);
}

// Generate Notice of AGM & Board Resolution
export async function generateAGMAndResolutionDocx(company: CompanyProfile): Promise<Blob> {
  const sig = company.signatories;
  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `AGM Notice & Board Resolution - ${company.name}`,
    sections: [
      {
        properties: {
          page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } }
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: company.name, bold: true, size: 26, color: COLOR_PRIMARY, font: 'Georgia' }),
              new TextRun({ text: `\n${company.registeredOffice}`, size: 16 }),
              new TextRun({ text: `\nCIN: ${company.cin}`, bold: true, size: 16, color: '555555' })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 160 },
            children: [
              new TextRun({ text: 'NOTICE OF ANNUAL GENERAL MEETING', bold: true, size: 22, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: `Notice is hereby given that the 3rd Annual General Meeting of the members of ${company.name} will be held on Monday, ${sig.agmDate} at 11:00 A.M. at its Registered Office to transact the following business:`, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { after: 80 },
            children: [
              new TextRun({ text: 'ORDINARY BUSINESS:\n', bold: true, size: 18 }),
              new TextRun({ text: `1. To receive, consider and adopt the Audited Balance Sheet as at 31st March 2024 and Profit & Loss Account for the year ended along with the reports of Directors and Auditors.\n2. To ratify ${sig.auditorFirmName}, Chartered Accountants (FRN: ${sig.auditorFirmRegNo}) as Statutory Auditors to hold office till the next AGM.`, size: 18 })
            ]
          }),
          new Paragraph({ pageBreakBefore: true }),
          // Board Resolution
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: company.name, bold: true, size: 26, color: COLOR_PRIMARY, font: 'Georgia' }),
              new TextRun({ text: `\n${company.registeredOffice}\nCIN: ${company.cin}`, size: 16 })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 160 },
            children: [
              new TextRun({ text: 'CERTIFIED TRUE COPY OF RESOLUTION PASSED AT BOARD MEETING', bold: true, size: 22, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          new Paragraph({
            spacing: { after: 100 },
            children: [
              new TextRun({ text: `HELD ON ${sig.boardMeetingDate} AT REGISTERED OFFICE:\n\n`, bold: true, size: 18 }),
              new TextRun({ text: `"RESOLVED THAT ${sig.director1Name}, Director, be and is hereby appointed as authorised signatory of the company to sign and submit all legal and business documents, financial statements, and MCA e-filings on behalf of ${company.name}."`, italics: true, size: 18 })
            ]
          }),
          new Paragraph({
            spacing: { before: 200 },
            children: [
              new TextRun({ text: `For ${company.name}\n\n\n`, bold: true, size: 18 }),
              new TextRun({ text: 'Sd/-                                              Sd/-\n', size: 16 }),
              new TextRun({ text: `${sig.director1Name}                          ${sig.director2Name}\n`, bold: true, size: 18 }),
              new TextRun({ text: `(Director) DIN: ${sig.director1DIN}            (Director) DIN: ${sig.director2DIN}`, size: 16 })
            ]
          })
        ]
      }
    ]
  });
  return await Packer.toBlob(doc);
}

// Generate List of Shareholders
export async function generateShareholdersListDocx(company: CompanyProfile, notes: NotesToAccountsBreakdown): Promise<Blob> {
  const doc = new Document({
    creator: 'Tax Esquire — Financial Statement Connect',
    title: `List of Shareholders - ${company.name}`,
    sections: [
      {
        properties: {
          page: { margin: { top: 720, bottom: 720, left: 720, right: 720 } }
        },
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: company.name, bold: true, size: 26, color: COLOR_PRIMARY, font: 'Georgia' }),
              new TextRun({ text: `\n${company.registeredOffice}\nCIN: ${company.cin}`, size: 16 })
            ]
          }),
          new Paragraph({
            alignment: AlignmentType.CENTER,
            spacing: { before: 140, after: 160 },
            children: [
              new TextRun({ text: `LIST OF SHAREHOLDERS AS ON ${company.asAtCurrentDate.toUpperCase()}`, bold: true, size: 22, color: COLOR_PRIMARY, font: 'Georgia' })
            ]
          }),
          createTableFromRows([
            ['S.No', 'Name of Shareholder', 'Address', 'Status', 'Occupation', 'Nationality', 'Date Member', 'Class', 'No. of Shares', 'Amount / Share', 'Total Amount (₹)'],
            ...notes.note2_ShareCapital.shareholders.map((sh, idx) => [
              `${idx + 1}`,
              sh.name,
              sh.address,
              sh.status,
              sh.occupation,
              sh.nationality,
              sh.dateBecomingMember,
              sh.classOfShare,
              formatINR(sh.sharesHeldCY),
              `₹ ${sh.faceValue}`,
              formatINR(sh.sharesHeldCY * sh.faceValue)
            ])
          ])
        ]
      }
    ]
  });
  return await Packer.toBlob(doc);
}

// Export aliases for compatibility
export const generateAOC4Docx = generateAOC4DraftDocx;
export const generateMGT7Docx = generateMGT7DraftDocx;

// Helper to trigger file download in browser
export function downloadBlobFile(blob: Blob, filename: string) {
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.style.display = 'none';
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  window.URL.revokeObjectURL(url);
  document.body.removeChild(a);
}
