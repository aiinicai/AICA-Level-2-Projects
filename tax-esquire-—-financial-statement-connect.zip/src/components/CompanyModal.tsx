import React, { useState } from 'react';
import { Building2, Check, FileText, KeyRound, UserCheck, X } from 'lucide-react';
import { CompanyProfile } from '../types';

interface CompanyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (company: CompanyProfile) => void;
  initialData?: CompanyProfile | null;
}

export const CompanyModal: React.FC<CompanyModalProps> = ({ isOpen, onClose, onSave, initialData }) => {
  const [activeTab, setActiveTab] = useState<'CORPORATE' | 'SIGNATORIES' | 'CAPITAL'>('CORPORATE');

  const [formData, setFormData] = useState<CompanyProfile>(
    initialData || {
      id: `comp_${Date.now()}`,
      name: '',
      cin: '',
      registeredOffice: '',
      incorporationDate: '15-04-2021',
      financialYearCurrent: '2023-24',
      asAtCurrentDate: '31st March 2024',
      asAtPreviousDate: '31st March 2023',
      currentYearLabel: 'As at 31st March 2024',
      previousYearLabel: 'As at 31st March 2023',
      authorisedShares: 10000,
      authorisedShareValue: 100000,
      issuedShares: 10000,
      issuedShareValue: 100000,
      faceValuePerShare: 10,
      principalBusinessActivity: 'Wholesale and retail trade of consumer goods, garments and merchandise',
      nicCode: '47711',
      turnoverPercentage: 90,
      signatories: {
        director1Name: 'RAJESH SHARMA',
        director1DIN: '08451234',
        director1Designation: 'Director',
        director2Name: 'ANITA VERMA',
        director2DIN: '09123456',
        director2Designation: 'Director',
        auditorFirmName: 'R. K. AGRAWAL & ASSOCIATES',
        auditorFirmRegNo: '012345N',
        auditorPartnerName: 'ROHIT AGRAWAL',
        auditorDesignation: 'Partner',
        auditorMembershipNo: '512345',
        auditorUDIN: '24512345BKFWZS9999',
        auditorAddress: 'Suite 501, Barakhamba Road, Connaught Place, New Delhi 110001',
        auditorEmail: 'contact@rkagrawalassociates.in',
        auditorPhone: '+91 9811001122',
        placeOfSigning: 'New Delhi',
        dateOfSigning: '02-09-2024',
        agmDate: '30-09-2024',
        boardMeetingDate: '02-09-2024'
      }
    }
  );

  if (!isOpen) return null;

  const handleTextChange = (field: keyof CompanyProfile, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSigChange = (field: keyof typeof formData.signatories, value: string) => {
    setFormData((prev) => ({
      ...prev,
      signatories: {
        ...prev.signatories,
        [field]: value
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-[#0b3d33] border border-[#c9a227]/40 rounded-xl max-w-3xl w-full overflow-hidden shadow-2xl relative text-white max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="bg-[#082e27] text-white p-5 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-lg bg-[#125246] border border-[#c9a227] flex items-center justify-center">
              <Building2 className="w-5 h-5 text-[#f7e089]" />
            </div>
            <div>
              <h2 className="font-display text-lg font-bold text-white">
                {initialData ? 'Edit Client Company & Signatories' : 'Register New Client Company'}
              </h2>
              <p className="text-xs text-stone-300">Schedule III Entity & MCA V3 Master Profile</p>
            </div>
          </div>
          <button onClick={onClose} aria-label="Close" className="text-stone-400 hover:text-white p-1 rounded-lg cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="bg-[#082e27]/80 border-b border-white/10 px-6 py-2 flex space-x-3">
          <button
            type="button"
            onClick={() => setActiveTab('CORPORATE')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeTab === 'CORPORATE' ? 'bg-[#c9a227] text-[#082e27] shadow-sm font-bold' : 'text-stone-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Company & CIN</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('SIGNATORIES')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeTab === 'SIGNATORIES' ? 'bg-[#c9a227] text-[#082e27] shadow-sm font-bold' : 'text-stone-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Directors & Statutory Auditor</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('CAPITAL')}
            className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer ${
              activeTab === 'CAPITAL' ? 'bg-[#c9a227] text-[#082e27] shadow-sm font-bold' : 'text-stone-300 hover:bg-white/10 hover:text-white'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Share Capital & NIC</span>
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'CORPORATE' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-stone-200 mb-1">Company Legal Name</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => handleTextChange('name', e.target.value)}
                  placeholder="e.g. 1857 REVOLTEAM PRIVATE LIMITED"
                  className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2.5 text-xs text-white font-semibold focus:border-[#c9a227] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">CIN (21 Characters)</label>
                  <input
                    type="text"
                    required
                    value={formData.cin}
                    onChange={(e) => handleTextChange('cin', e.target.value)}
                    placeholder="e.g. U55209UP2021PTC144449"
                    className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2.5 text-xs font-mono font-medium text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Date of Incorporation</label>
                  <input
                    type="text"
                    value={formData.incorporationDate}
                    onChange={(e) => handleTextChange('incorporationDate', e.target.value)}
                    placeholder="e.g. 30-03-2021"
                    className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2.5 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-stone-200 mb-1">Registered Office Address</label>
                <textarea
                  rows={2}
                  value={formData.registeredOffice}
                  onChange={(e) => handleTextChange('registeredOffice', e.target.value)}
                  placeholder="e.g. SHOP NO - A143,144, SHRI AMRIT PLAZA, AMRIT PURAM, JAGAT FARM, GREATER NOIDA, GAUTAM BUDDHA NAGAR, UP 201308 IN"
                  className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2.5 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Current Financial Year</label>
                  <input
                    type="text"
                    value={formData.financialYearCurrent}
                    onChange={(e) => handleTextChange('financialYearCurrent', e.target.value)}
                    placeholder="e.g. 2023-24"
                    className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Current Balance Date</label>
                  <input
                    type="text"
                    value={formData.asAtCurrentDate}
                    onChange={(e) => handleTextChange('asAtCurrentDate', e.target.value)}
                    placeholder="31st March 2024"
                    className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Previous Balance Date</label>
                  <input
                    type="text"
                    value={formData.asAtPreviousDate}
                    onChange={(e) => handleTextChange('asAtPreviousDate', e.target.value)}
                    placeholder="31st March 2023"
                    className="w-full bg-[#051e19] border border-white/10 rounded-lg p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'SIGNATORIES' && (
            <div className="space-y-4">
              <div className="bg-[#082e27] border border-white/10 rounded-lg p-3">
                <h3 className="text-xs font-bold text-[#f7e089] mb-2 uppercase tracking-wide">Board of Directors (Signatories)</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Director 1 Name</label>
                    <input
                      type="text"
                      value={formData.signatories.director1Name}
                      onChange={(e) => handleSigChange('director1Name', e.target.value)}
                      placeholder="e.g. PRASHANT KUMAR"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white font-medium focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Director 1 DIN (8 Digits)</label>
                    <input
                      type="text"
                      value={formData.signatories.director1DIN}
                      onChange={(e) => handleSigChange('director1DIN', e.target.value)}
                      placeholder="e.g. 09128387"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Director 2 Name</label>
                    <input
                      type="text"
                      value={formData.signatories.director2Name}
                      onChange={(e) => handleSigChange('director2Name', e.target.value)}
                      placeholder="e.g. SHWETA SENGAR"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white font-medium focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Director 2 DIN (8 Digits)</label>
                    <input
                      type="text"
                      value={formData.signatories.director2DIN}
                      onChange={(e) => handleSigChange('director2DIN', e.target.value)}
                      placeholder="e.g. 09168862"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                </div>
              </div>

              <div className="bg-[#125246]/40 border border-[#c9a227]/30 rounded-lg p-3">
                <h3 className="text-xs font-bold text-[#f7e089] mb-2 uppercase tracking-wide">Statutory Auditor & UDIN Certification</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Auditor Firm Name</label>
                    <input
                      type="text"
                      value={formData.signatories.auditorFirmName}
                      onChange={(e) => handleSigChange('auditorFirmName', e.target.value)}
                      placeholder="GUPTA POONAM AND ASSOCIATES"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white font-medium focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Firm Reg. No. (FRN)</label>
                    <input
                      type="text"
                      value={formData.signatories.auditorFirmRegNo}
                      onChange={(e) => handleSigChange('auditorFirmRegNo', e.target.value)}
                      placeholder="033858C"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Signing Partner / Proprietor</label>
                    <input
                      type="text"
                      value={formData.signatories.auditorPartnerName}
                      onChange={(e) => handleSigChange('auditorPartnerName', e.target.value)}
                      placeholder="POONAM GUPTA"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">ICAI Membership No.</label>
                    <input
                      type="text"
                      value={formData.signatories.auditorMembershipNo}
                      onChange={(e) => handleSigChange('auditorMembershipNo', e.target.value)}
                      placeholder="303889"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">UDIN (18 Digits)</label>
                    <input
                      type="text"
                      value={formData.signatories.auditorUDIN}
                      onChange={(e) => handleSigChange('auditorUDIN', e.target.value)}
                      placeholder="24303889BKFWZS7361"
                      className="w-full bg-[#051e19] border border-[#c9a227]/40 rounded p-2 text-xs font-mono font-bold text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Place of Signing</label>
                    <input
                      type="text"
                      value={formData.signatories.placeOfSigning}
                      onChange={(e) => handleSigChange('placeOfSigning', e.target.value)}
                      placeholder="Greater Noida"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-stone-300 mb-1">Date of Signing</label>
                    <input
                      type="text"
                      value={formData.signatories.dateOfSigning}
                      onChange={(e) => handleSigChange('dateOfSigning', e.target.value)}
                      placeholder="02-09-2024"
                      className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'CAPITAL' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Authorised Shares Count</label>
                  <input
                    type="number"
                    value={formData.authorisedShares}
                    onChange={(e) => handleTextChange('authorisedShares', Number(e.target.value))}
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Face Value / Share (₹)</label>
                  <input
                    type="number"
                    value={formData.faceValuePerShare}
                    onChange={(e) => handleTextChange('faceValuePerShare', Number(e.target.value))}
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Authorised Value (₹)</label>
                  <input
                    type="number"
                    value={formData.authorisedShareValue}
                    onChange={(e) => handleTextChange('authorisedShareValue', Number(e.target.value))}
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Issued & Paid-Up Shares Count</label>
                  <input
                    type="number"
                    value={formData.issuedShares}
                    onChange={(e) => handleTextChange('issuedShares', Number(e.target.value))}
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">Issued & Paid-Up Value (₹)</label>
                  <input
                    type="number"
                    value={formData.issuedShareValue}
                    onChange={(e) => handleTextChange('issuedShareValue', Number(e.target.value))}
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-stone-200 mb-1">Principal Business Activity</label>
                  <input
                    type="text"
                    value={formData.principalBusinessActivity}
                    onChange={(e) => handleTextChange('principalBusinessActivity', e.target.value)}
                    placeholder="e.g. Retail trade of Apparels and related goods"
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs text-white focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-stone-200 mb-1">NIC Code</label>
                  <input
                    type="text"
                    value={formData.nicCode}
                    onChange={(e) => handleTextChange('nicCode', e.target.value)}
                    placeholder="47820"
                    className="w-full bg-[#051e19] border border-white/10 rounded p-2 text-xs font-mono text-[#f7e089] focus:border-[#c9a227] focus:outline-none"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-white/10 flex justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-white/20 rounded-md text-xs font-semibold text-stone-300 hover:bg-white/10 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] font-bold text-xs rounded-md shadow-md flex items-center space-x-1.5 cursor-pointer"
            >
              <Check className="w-4 h-4 text-[#082e27]" />
              <span>Save Company Master</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
