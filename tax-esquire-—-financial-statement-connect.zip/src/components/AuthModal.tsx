import React, { useState } from 'react';
import { Award, CheckCircle2, Lock, ShieldCheck, Sparkles, UserCheck, X } from 'lucide-react';
import { UserSession } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onLoginSuccess: (user: UserSession) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onLoginSuccess }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('capoonamguptaiicpa@gmail.com');
  const [password, setPassword] = useState('taxfinconnect2024');
  const [name, setName] = useState('CA Poonam Gupta');
  const [firmName, setFirmName] = useState('Gupta Poonam & Associates, Chartered Accountants');
  const [frn, setFrn] = useState('033858C');
  const [membershipNo, setMembershipNo] = useState('303889');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');

    try {
      const endpoint = isRegistering ? '/api/auth/register' : '/api/auth/login';
      const body = isRegistering
        ? { email, password, name, firmName, frn, membershipNo }
        : { email, password };

      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Authentication failed');
      }

      onLoginSuccess(data.user);
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to authenticate');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemoLogin = (type: 'poonam' | 'partner') => {
    if (type === 'poonam') {
      setEmail('capoonamguptaiicpa@gmail.com');
      setPassword('taxfinconnect2024');
      setName('CA Poonam Gupta');
      setFirmName('Gupta Poonam & Associates');
      setFrn('033858C');
      setMembershipNo('303889');
    } else {
      setEmail('admin@taxfinconnect.in');
      setPassword('admin123');
      setName('Tax Fin Connect Senior Partner');
      setFirmName('Tax Fin Connect Legal & Chartered Advisory');
      setFrn('089921N');
      setMembershipNo('512990');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
      <div className="bg-stone-900 border border-[#c9a227]/40 rounded-xl max-w-md w-full overflow-hidden shadow-2xl relative text-white">
        {/* Header Ribbon */}
        <div className="bg-gradient-to-r from-[#0b3d33] via-[#14594c] to-[#072720] p-6 border-b border-[#c9a227]/30 text-center relative">
          <div className="mx-auto w-14 h-14 rounded-full bg-stone-900/80 border-2 border-[#c9a227] flex items-center justify-center mb-3 shadow-inner">
            <span className="font-display text-2xl font-bold text-[#c9a227]">TFC</span>
          </div>
          <h2 className="font-display text-xl font-bold text-white tracking-wide">
            TAX FIN CONNECT
          </h2>
          <p className="text-xs text-[#f7e089] mt-0.5">Chartered Accountant & Statutory Filing Portal</p>
          <p className="text-[11px] text-stone-300 font-light mt-1">
            ICAI UDIN & Schedule III Division I Compliance Suite
          </p>

          <button
            onClick={onClose}
            aria-label="Close"
            className="absolute top-4 right-4 text-stone-400 hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {/* Preset One-Click Fillers */}
          <div className="mb-5 bg-[#0b3d33]/40 border border-[#c9a227]/30 rounded-lg p-3">
            <div className="text-[11px] font-semibold text-[#f7e089] uppercase tracking-wider flex items-center justify-between mb-2">
              <span className="flex items-center space-x-1">
                <Sparkles className="w-3.5 h-3.5 text-[#c9a227]" />
                <span>Quick CA Login Profile</span>
              </span>
              <span className="text-[10px] text-stone-400 font-normal">Click to fill</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => handleQuickDemoLogin('poonam')}
                className="text-left bg-stone-800/80 hover:bg-stone-700/80 border border-[#c9a227]/30 hover:border-[#c9a227] p-2 rounded text-xs transition"
              >
                <div className="font-semibold text-[#f7e089] flex items-center space-x-1">
                  <Award className="w-3 h-3 text-[#c9a227]" />
                  <span>CA Poonam Gupta</span>
                </div>
                <div className="text-[10px] text-stone-300">FRN: 033858C</div>
              </button>

              <button
                type="button"
                onClick={() => handleQuickDemoLogin('partner')}
                className="text-left bg-stone-800/80 hover:bg-stone-700/80 border border-stone-700 hover:border-[#c9a227] p-2 rounded text-xs transition"
              >
                <div className="font-semibold text-stone-200 flex items-center space-x-1">
                  <UserCheck className="w-3 h-3 text-[#c9a227]" />
                  <span>Tax Fin Connect Partner</span>
                </div>
                <div className="text-[10px] text-stone-400">FRN: 089921N</div>
              </button>
            </div>
          </div>

          {errorMsg && (
            <div className="mb-4 bg-rose-950/80 border border-rose-600 text-rose-200 text-xs p-2.5 rounded">
              {errorMsg}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-3.5">
            {isRegistering && (
              <>
                <div>
                  <label className="block text-xs text-stone-300 mb-1">CA Member Full Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-stone-800 border border-stone-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#c9a227]"
                    placeholder="e.g. CA Poonam Gupta"
                  />
                </div>

                <div>
                  <label className="block text-xs text-stone-300 mb-1">Chartered Accountancy Firm Name</label>
                  <input
                    type="text"
                    required
                    value={firmName}
                    onChange={(e) => setFirmName(e.target.value)}
                    className="w-full bg-stone-800 border border-stone-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#c9a227]"
                    placeholder="e.g. Gupta Poonam & Associates, Chartered Accountants"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-stone-300 mb-1">Firm Reg. No. (FRN)</label>
                    <input
                      type="text"
                      required
                      value={frn}
                      onChange={(e) => setFrn(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#c9a227]"
                      placeholder="e.g. 033858C"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-stone-300 mb-1">Membership No.</label>
                    <input
                      type="text"
                      required
                      value={membershipNo}
                      onChange={(e) => setMembershipNo(e.target.value)}
                      className="w-full bg-stone-800 border border-stone-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#c9a227]"
                      placeholder="e.g. 303889"
                    />
                  </div>
                </div>
              </>
            )}

            <div>
              <label className="block text-xs text-stone-300 mb-1">Email ID</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-stone-800 border border-stone-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#c9a227]"
                placeholder="capoonamguptaiicpa@gmail.com"
              />
            </div>

            <div>
              <label className="block text-xs text-stone-300 mb-1">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-stone-800 border border-stone-700 rounded px-3 py-2 text-xs text-white focus:outline-none focus:border-[#c9a227]"
                placeholder="••••••••"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 bg-gradient-to-r from-[#c9a227] to-[#e5be49] hover:from-[#d8b030] hover:to-[#f0c850] text-[#072720] font-bold text-xs rounded transition shadow-md flex items-center justify-center space-x-2 mt-4 cursor-pointer disabled:opacity-50"
            >
              <ShieldCheck className="w-4 h-4 text-[#072720]" />
              <span>{isLoading ? 'Authenticating...' : isRegistering ? 'Create CA Account & Access' : 'Authenticate & Enter Portal'}</span>
            </button>
          </form>

          <div className="mt-4 pt-4 border-t border-stone-800 text-center">
            <button
              type="button"
              onClick={() => {
                setIsRegistering(!isRegistering);
                setErrorMsg('');
              }}
              className="text-xs text-[#f7e089] hover:underline"
            >
              {isRegistering
                ? 'Already registered? Log in with existing CA profile'
                : 'Need a new CA firm workspace? Register here'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
