import React, { useState } from 'react';
import {
  AlertTriangle,
  Award,
  BookOpen,
  Building,
  CheckCircle2,
  Download,
  FileCheck,
  FileSpreadsheet,
  FileText,
  Layers,
  Printer,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  TrendingUp,
  UserCheck
} from 'lucide-react';
import { FinancialStatementsFull } from '../types';

interface FinancialStatementViewerProps {
  data: FinancialStatementsFull;
  onDownloadDocx: (type: 'SCHEDULE_III' | 'AOC_4' | 'MGT_7' | 'AUDITOR_REPORT' | 'DIRECTORS_REPORT' | 'ALL') => void;
  onOpenAIRefresh: () => void;
  isDownloading?: boolean;
}

const formatINR = (val: number | undefined | null) => {
  if (val === undefined || val === null || isNaN(val)) return '0.00';
  return val.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

export const FinancialStatementViewer: React.FC<FinancialStatementViewerProps> = ({
  data,
  onDownloadDocx,
  onOpenAIRefresh,
  isDownloading
}) => {
  const [activeTab, setActiveTab] = useState<'BS' | 'PL' | 'NOTES' | 'SIGNATORIES' | 'AUDIT_TRAIL'>('BS');
  const [selectedNote, setSelectedNote] = useState<number | null>(null);

  const { company, balanceSheet, profitAndLoss, notes } = data;
  const isTallied = balanceSheet?.isTalliedCY ?? true;
  const differenceCY = balanceSheet?.differenceCY ?? 0;

  // Build the 16 standard Schedule III Notes
  const notesList = [
    {
      noteNumber: 1,
      title: 'Corporate Information & Significant Accounting Policies',
      category: 'Accounting Standards',
      totalCY: 0,
      totalPY: 0,
      isTextOnly: true,
      textNote: `1. Corporate Information:
${company.name} is a private limited company incorporated on ${company.incorporationDate} under the Companies Act, 2013 having CIN ${company.cin}. The company is engaged in ${company.principalBusinessActivity}.

2. Basis of Preparation:
The financial statements have been prepared under historical cost convention on an accrual basis, in accordance with the Generally Accepted Accounting Principles in India (Indian GAAP) and comply in all material aspects with the Accounting Standards notified under Section 133 of the Companies Act, 2013 and Schedule III Division I.

3. Property, Plant & Equipment (Fixed Assets):
Property, Plant and Equipment are stated at cost less accumulated depreciation. Cost includes all expenditures directly attributable to the acquisition. Depreciation is provided on ${notes?.note1_Policies?.depreciationMethod || 'Written Down Value (WDV) method'} as per useful life prescribed under Schedule II of the Companies Act, 2013.

4. Revenue Recognition:
Revenue from sale of products is recognized when significant risks and rewards of ownership are transferred to the customer. Revenue is recognized net of trade discounts and GST.

5. Inventories:
Inventories of stock-in-trade are valued at ${notes?.note1_Policies?.inventoryMethod || 'lower of cost and net realizable value on FIFO basis'}.

6. Auditor Remuneration (included in Note 14):
Statutory Audit Fee: Current Year ₹${formatINR(notes?.note1_Policies?.auditorFeesCY || 25000)} (Previous Year ₹${formatINR(notes?.note1_Policies?.auditorFeesPY || 25000)}).`
    },
    {
      noteNumber: 2,
      title: 'Share Capital',
      category: 'Shareholders Funds',
      totalCY: notes?.note2_ShareCapital?.subscribedPaidUp?.value ?? company.issuedShareValue,
      totalPY: notes?.note2_ShareCapital?.subscribedPaidUp?.value ?? company.issuedShareValue,
      subItems: [
        {
          particulars: `Authorised: ${notes?.note2_ShareCapital?.authorised?.shares?.toLocaleString('en-IN') || '10,000'} Equity Shares of ₹10/- each`,
          currentYearValue: notes?.note2_ShareCapital?.authorised?.value ?? company.authorisedShareValue,
          previousYearValue: notes?.note2_ShareCapital?.authorised?.value ?? company.authorisedShareValue
        },
        {
          particulars: `Issued, Subscribed & Fully Paid Up: ${notes?.note2_ShareCapital?.issued?.shares?.toLocaleString('en-IN') || '10,000'} Equity Shares of ₹10/- each`,
          currentYearValue: notes?.note2_ShareCapital?.subscribedPaidUp?.value ?? company.issuedShareValue,
          previousYearValue: notes?.note2_ShareCapital?.subscribedPaidUp?.value ?? company.issuedShareValue
        }
      ]
    },
    {
      noteNumber: 3,
      title: 'Reserves and Surplus',
      category: 'Shareholders Funds',
      totalCY: notes?.note3_ReservesSurplus?.closingBalance ?? 0,
      totalPY: notes?.note3_ReservesSurplus?.pyClosingBalance ?? 0,
      subItems: [
        {
          particulars: 'Surplus / (Deficit) in Statement of Profit & Loss - Opening Balance',
          currentYearValue: notes?.note3_ReservesSurplus?.openingBalance ?? 0,
          previousYearValue: notes?.note3_ReservesSurplus?.pyOpeningBalance ?? 0
        },
        {
          particulars: 'Add: Profit / (Loss) for the current financial year',
          currentYearValue: notes?.note3_ReservesSurplus?.currentYearProfit ?? 0,
          previousYearValue: notes?.note3_ReservesSurplus?.pyCurrentYearProfit ?? 0
        }
      ]
    },
    {
      noteNumber: 4,
      title: 'Long-Term Borrowings',
      category: 'Non-Current Liabilities',
      totalCY: notes?.note4_LongTermBorrowings?.unsecuredLoanFromDirectorsCY ?? balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.cy ?? 0,
      totalPY: notes?.note4_LongTermBorrowings?.unsecuredLoanFromDirectorsPY ?? balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.py ?? 0,
      subItems: [
        {
          particulars: 'Unsecured Loans from Directors (Non-interest bearing)',
          currentYearValue: notes?.note4_LongTermBorrowings?.unsecuredLoanFromDirectorsCY ?? balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.cy ?? 0,
          previousYearValue: notes?.note4_LongTermBorrowings?.unsecuredLoanFromDirectorsPY ?? balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.py ?? 0
        }
      ]
    },
    {
      noteNumber: 5,
      title: 'Trade Payables',
      category: 'Current Liabilities',
      totalCY: notes?.note5_TradePayables?.dueToOthersCY ?? balanceSheet?.equityAndLiabilities?.currentLiabilities?.tradePayables?.cy ?? 0,
      totalPY: notes?.note5_TradePayables?.dueToOthersPY ?? balanceSheet?.equityAndLiabilities?.currentLiabilities?.tradePayables?.py ?? 0,
      subItems: [
        {
          particulars: 'Total outstanding dues of Micro and Small Enterprises (MSME)',
          currentYearValue: notes?.note5_TradePayables?.dueToMSMECY ?? 0,
          previousYearValue: notes?.note5_TradePayables?.dueToMSMEPY ?? 0
        },
        {
          particulars: 'Total outstanding dues of creditors other than Micro and Small Enterprises',
          currentYearValue: notes?.note5_TradePayables?.dueToOthersCY ?? balanceSheet?.equityAndLiabilities?.currentLiabilities?.tradePayables?.cy ?? 0,
          previousYearValue: notes?.note5_TradePayables?.dueToOthersPY ?? balanceSheet?.equityAndLiabilities?.currentLiabilities?.tradePayables?.py ?? 0
        }
      ]
    },
    {
      noteNumber: 6,
      title: 'Other Current Liabilities',
      category: 'Current Liabilities',
      totalCY: notes?.note6_OtherCurrentLiabilities?.totalCY ?? balanceSheet?.equityAndLiabilities?.currentLiabilities?.otherCurrentLiabilities?.cy ?? 0,
      totalPY: notes?.note6_OtherCurrentLiabilities?.totalPY ?? balanceSheet?.equityAndLiabilities?.currentLiabilities?.otherCurrentLiabilities?.py ?? 0,
      subItems: notes?.note6_OtherCurrentLiabilities?.items?.map((it) => ({
        particulars: it.label,
        currentYearValue: it.cy,
        previousYearValue: it.py
      })) || [
        {
          particulars: 'Audit Fee Payable',
          currentYearValue: notes?.note6_OtherCurrentLiabilities?.totalCY ?? 25000,
          previousYearValue: notes?.note6_OtherCurrentLiabilities?.totalPY ?? 26125
        }
      ]
    },
    {
      noteNumber: 7,
      title: 'Cash and Bank Balances',
      category: 'Current Assets',
      totalCY: notes?.note7_CashAndBank?.totalCY ?? balanceSheet?.assets?.currentAssets?.cashAndBankBalances?.cy ?? 0,
      totalPY: notes?.note7_CashAndBank?.totalPY ?? balanceSheet?.assets?.currentAssets?.cashAndBankBalances?.py ?? 0,
      subItems: [
        {
          particulars: 'Balances with Banks in Current Accounts',
          currentYearValue: notes?.note7_CashAndBank?.currentAccountsCY ?? 0,
          previousYearValue: notes?.note7_CashAndBank?.currentAccountsPY ?? 0
        },
        {
          particulars: 'Cash in Hand (as certified by management)',
          currentYearValue: notes?.note7_CashAndBank?.cashInHandCY ?? 0,
          previousYearValue: notes?.note7_CashAndBank?.cashInHandPY ?? 0
        }
      ]
    },
    {
      noteNumber: 8,
      title: 'Property, Plant & Equipment / Fixed Assets',
      category: 'Non-Current Assets',
      totalCY: notes?.note8_FixedAssets?.totalCYClosingWDV ?? balanceSheet?.assets?.nonCurrentAssets?.fixedAssetsTangible?.cy ?? 0,
      totalPY: notes?.note8_FixedAssets?.totalPYClosingWDV ?? balanceSheet?.assets?.nonCurrentAssets?.fixedAssetsTangible?.py ?? 0,
      subItems: notes?.note8_FixedAssets?.assets?.map((fa) => ({
        particulars: `${fa.assetName} (Gross ₹${formatINR(fa.grossBlock)} - Depr ₹${formatINR(fa.depreciationCY)})`,
        currentYearValue: fa.netBlockCY,
        previousYearValue: fa.netBlockPY
      })) || [
        {
          particulars: 'Tangible Fixed Assets Net Block (Computer & Airconditioner)',
          currentYearValue: balanceSheet?.assets?.nonCurrentAssets?.fixedAssetsTangible?.cy ?? 0,
          previousYearValue: balanceSheet?.assets?.nonCurrentAssets?.fixedAssetsTangible?.py ?? 0
        }
      ]
    },
    {
      noteNumber: 9,
      title: 'Other Current Assets',
      category: 'Current Assets',
      totalCY: notes?.note9_OtherCurrentAssets?.totalCY ?? balanceSheet?.assets?.currentAssets?.otherCurrentAssets?.cy ?? 0,
      totalPY: notes?.note9_OtherCurrentAssets?.totalPY ?? balanceSheet?.assets?.currentAssets?.otherCurrentAssets?.py ?? 0,
      subItems: notes?.note9_OtherCurrentAssets?.items?.map((it) => ({
        particulars: it.label,
        currentYearValue: it.cy,
        previousYearValue: it.py
      })) || [
        {
          particulars: 'Balances with Statutory Authorities (GST Input Credit)',
          currentYearValue: 106221,
          previousYearValue: 200347
        },
        {
          particulars: 'Advances to Creditors & Suppliers',
          currentYearValue: 151705,
          previousYearValue: 100000
        }
      ]
    },
    {
      noteNumber: 10,
      title: 'Revenue from Operations',
      category: 'Income',
      totalCY: notes?.note10_RevenueFromOperations?.totalCY ?? profitAndLoss?.income?.revenueFromOperations?.cy ?? 0,
      totalPY: notes?.note10_RevenueFromOperations?.totalPY ?? profitAndLoss?.income?.revenueFromOperations?.py ?? 0,
      subItems: [
        {
          particulars: 'Sale of Products / Tax Invoices (Net of Returns & Taxes)',
          currentYearValue: notes?.note10_RevenueFromOperations?.totalCY ?? profitAndLoss?.income?.revenueFromOperations?.cy ?? 0,
          previousYearValue: notes?.note10_RevenueFromOperations?.totalPY ?? profitAndLoss?.income?.revenueFromOperations?.py ?? 0
        }
      ]
    },
    {
      noteNumber: 11,
      title: 'Other Income',
      category: 'Income',
      totalCY: notes?.note11_OtherIncome?.totalCY ?? profitAndLoss?.income?.otherIncome?.cy ?? 0,
      totalPY: notes?.note11_OtherIncome?.totalPY ?? profitAndLoss?.income?.otherIncome?.py ?? 0,
      subItems: notes?.note11_OtherIncome?.items?.map((it) => ({
        particulars: it.label,
        currentYearValue: it.cy,
        previousYearValue: it.py
      })) || [
        {
          particulars: 'UPI Activation & Miscellaneous Non-Operating Income',
          currentYearValue: profitAndLoss?.income?.otherIncome?.cy ?? 0,
          previousYearValue: profitAndLoss?.income?.otherIncome?.py ?? 0
        }
      ]
    },
    {
      noteNumber: 12,
      title: 'Cost of Traded Goods / Changes in Inventories',
      category: 'Expenses',
      totalCY: notes?.note12_CostOfTradedGoods?.totalCY ?? profitAndLoss?.expenses?.costOfTradedGoods?.cy ?? 0,
      totalPY: notes?.note12_CostOfTradedGoods?.totalPY ?? profitAndLoss?.expenses?.costOfTradedGoods?.py ?? 0,
      subItems: [
        {
          particulars: 'Opening Stock of Traded Goods',
          currentYearValue: notes?.note12_CostOfTradedGoods?.openingStockCY ?? 597412,
          previousYearValue: notes?.note12_CostOfTradedGoods?.openingStockPY ?? 650000
        },
        {
          particulars: 'Add: Purchases during the year',
          currentYearValue: notes?.note12_CostOfTradedGoods?.purchasesCY ?? 0,
          previousYearValue: notes?.note12_CostOfTradedGoods?.purchasesPY ?? 499071
        },
        {
          particulars: 'Less: Closing Stock of Traded Goods (Inventories)',
          currentYearValue: -(notes?.note12_CostOfTradedGoods?.closingStockCY ?? 516784),
          previousYearValue: -(notes?.note12_CostOfTradedGoods?.closingStockPY ?? 597412)
        }
      ]
    },
    {
      noteNumber: 13,
      title: 'Direct Cost / Production & Operating Expenses',
      category: 'Expenses',
      totalCY: notes?.note13_DirectCosts?.totalCY ?? profitAndLoss?.expenses?.directCost?.cy ?? 0,
      totalPY: notes?.note13_DirectCosts?.totalPY ?? profitAndLoss?.expenses?.directCost?.py ?? 0,
      subItems: notes?.note13_DirectCosts?.items?.map((it) => ({
        particulars: it.label,
        currentYearValue: it.cy,
        previousYearValue: it.py
      })) || [
        {
          particulars: 'Direct Operational Expenses',
          currentYearValue: profitAndLoss?.expenses?.directCost?.cy ?? 0,
          previousYearValue: profitAndLoss?.expenses?.directCost?.py ?? 17700
        }
      ]
    },
    {
      noteNumber: 14,
      title: 'Administration and Other Expenses',
      category: 'Expenses',
      totalCY: notes?.note14_AdminExpenses?.totalCY ?? profitAndLoss?.expenses?.adminAndOtherExpenses?.cy ?? 0,
      totalPY: notes?.note14_AdminExpenses?.totalPY ?? profitAndLoss?.expenses?.adminAndOtherExpenses?.py ?? 0,
      subItems: notes?.note14_AdminExpenses?.items?.map((it) => ({
        particulars: it.label,
        currentYearValue: it.cy,
        previousYearValue: it.py
      })) || [
        {
          particulars: 'Statutory Audit Fee (Note 14.1)',
          currentYearValue: notes?.note14_AdminExpenses?.statutoryAuditFeeCY ?? 25000,
          previousYearValue: notes?.note14_AdminExpenses?.statutoryAuditFeePY ?? 25000
        },
        {
          particulars: 'Rent Expenses',
          currentYearValue: 135000,
          previousYearValue: 180000
        },
        {
          particulars: 'Accounting & Consultancy Charges',
          currentYearValue: 39160,
          previousYearValue: 50000
        },
        {
          particulars: 'Insurance Expenses',
          currentYearValue: 8934,
          previousYearValue: 12000
        },
        {
          particulars: 'Telephone, Internet & Utility Charges',
          currentYearValue: 5988,
          previousYearValue: 8000
        },
        {
          particulars: 'Advertisement & Business Promotion',
          currentYearValue: 5028,
          previousYearValue: 10000
        },
        {
          particulars: 'Other Miscellaneous Operational Expenses',
          currentYearValue: 1059,
          previousYearValue: 126507
        }
      ]
    },
    {
      noteNumber: 15,
      title: 'Finance Costs',
      category: 'Expenses',
      totalCY: notes?.note15_FinanceCosts?.totalCY ?? profitAndLoss?.expenses?.financeCosts?.cy ?? 0,
      totalPY: notes?.note15_FinanceCosts?.totalPY ?? profitAndLoss?.expenses?.financeCosts?.py ?? 0,
      subItems: [
        {
          particulars: 'Bank Charges & Commission',
          currentYearValue: notes?.note15_FinanceCosts?.bankChargesCY ?? profitAndLoss?.expenses?.financeCosts?.cy ?? 0,
          previousYearValue: notes?.note15_FinanceCosts?.bankChargesPY ?? profitAndLoss?.expenses?.financeCosts?.py ?? 0
        }
      ]
    },
    {
      noteNumber: 16,
      title: 'Additional Regulatory Information & Statutory Ratios',
      category: 'Disclosures',
      totalCY: 0,
      totalPY: 0,
      isTextOnly: true,
      textNote: `1. Title deeds of Immovable Property: The company does not own any immovable property during the current and previous year.
2. Revaluation of Property, Plant & Equipment: The company has not revalued its Property, Plant and Equipment.
3. Loans or Advances granted to Promoters, Directors, KMPs: No loans or advances have been granted to promoters, directors or related parties.
4. Capital Work-in-Progress (CWIP) / Intangible assets under development: NIL.
5. Benami Property: No proceedings have been initiated or are pending against the company for holding any Benami property.
6. Borrowings from Banks and Financial Institutions: No borrowings on security of current assets; no quarterly returns were required.
7. Wilful Defaulter: The company has not been declared a Wilful Defaulter by any bank or financial institution.
8. Relationship with Struck off Companies: The company has no transactions with companies struck off under section 248.
9. Registration of charges or satisfaction with ROC: No pending charges or satisfaction to be registered beyond statutory period.
10. Compliance with approved Schemes of Arrangements: Not applicable.
11. Ratios:
    - Current Ratio: ${(balanceSheet?.assets?.currentAssets?.total?.cy && balanceSheet?.equityAndLiabilities?.currentLiabilities?.total?.cy ? (balanceSheet.assets.currentAssets.total.cy / balanceSheet.equityAndLiabilities.currentLiabilities.total.cy).toFixed(2) : '32.55')}
    - Debt-Equity Ratio: ${(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.cy && balanceSheet?.equityAndLiabilities?.shareholdersFunds?.total?.cy ? (balanceSheet.equityAndLiabilities.nonCurrentLiabilities.longTermBorrowings.cy / Math.abs(balanceSheet.equityAndLiabilities.shareholdersFunds.total.cy)).toFixed(2) : '2.14')}
    - Return on Equity: ${(profitAndLoss?.profitAfterTax?.cy && balanceSheet?.equityAndLiabilities?.shareholdersFunds?.total?.cy ? ((profitAndLoss.profitAfterTax.cy / balanceSheet.equityAndLiabilities.shareholdersFunds.total.cy) * 100).toFixed(2) : '-28.50')}%
12. Audit Trail (Rule 11(g)): The company has used accounting software with audit trail (edit log) feature throughout the year without tampering.`
    }
  ];

  return (
    <div className="space-y-4">
      {/* Tally Discrepancy Banner */}
      {!isTallied && (
        <div className="bg-rose-950/70 border-2 border-rose-500/80 p-4 rounded-xl shadow-lg flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-rose-900/50 flex items-center justify-center flex-shrink-0 border border-rose-500/50">
              <AlertTriangle className="w-6 h-6 text-rose-400" />
            </div>
            <div>
              <h4 className="font-bold text-rose-200 text-sm">Schedule III Balance Sheet Discrepancy Alert</h4>
              <p className="text-xs text-rose-300">
                Total Equity & Liabilities (₹{formatINR(balanceSheet?.equityAndLiabilities?.totalEquityAndLiabilities?.cy)}) does not match
                Total Assets (₹{formatINR(balanceSheet?.assets?.totalAssets?.cy)}).
                Difference: <strong className="font-mono text-white">₹{formatINR(differenceCY)}</strong>.
              </p>
            </div>
          </div>
          <span className="bg-rose-600 text-white text-xs px-3 py-1.5 rounded-lg font-bold">Action Required</span>
        </div>
      )}

      {/* Main Header & Download Toolbar */}
      <div className="bg-[#0b3d33]/50 backdrop-blur border border-white/10 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="font-display text-xl font-bold text-white tracking-wide">{company.name}</h2>
              <span className="text-[11px] bg-[#c9a227]/20 text-[#f7e089] font-bold px-2 py-0.5 rounded border border-[#c9a227]/40 font-mono">
                CIN: {company.cin}
              </span>
            </div>
            <p className="text-xs text-stone-400 mt-1">
              Registered Office: {company.registeredOffice}
            </p>
            <p className="text-xs text-stone-300 mt-0.5 font-medium">
              Financial Statements as at <span className="font-bold text-[#f7e089]">{company.asAtCurrentDate}</span> (with comparative figures for {company.asAtPreviousDate})
            </p>
          </div>

          {/* Quick Export Actions */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => onDownloadDocx('SCHEDULE_III')}
              disabled={isDownloading}
              className="px-3.5 py-2 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] text-xs font-bold rounded-lg shadow-sm flex items-center space-x-1.5 transition cursor-pointer disabled:opacity-50"
            >
              <Download className="w-3.5 h-3.5 text-[#082e27]" />
              <span>Download Schedule III (.docx)</span>
            </button>

            <button
              onClick={() => onDownloadDocx('AOC_4')}
              disabled={isDownloading}
              className="px-3 py-2 bg-white/5 hover:bg-white/10 text-stone-200 text-xs font-semibold rounded-lg border border-white/10 hover:border-[#c9a227]/50 flex items-center space-x-1 transition cursor-pointer disabled:opacity-50"
            >
              <FileCheck className="w-3.5 h-3.5 text-[#c9a227]" />
              <span>Form AOC-4 Draft</span>
            </button>

            <button
              onClick={() => onDownloadDocx('MGT_7')}
              disabled={isDownloading}
              className="px-3 py-2 bg-white/5 hover:bg-white/10 text-stone-200 text-xs font-semibold rounded-lg border border-white/10 hover:border-[#c9a227]/50 flex items-center space-x-1 transition cursor-pointer disabled:opacity-50"
            >
              <FileText className="w-3.5 h-3.5 text-stone-300" />
              <span>Form MGT-7 Draft</span>
            </button>

            <button
              onClick={() => onDownloadDocx('ALL')}
              disabled={isDownloading}
              className="px-3.5 py-2 bg-gradient-to-r from-[#c9a227] via-[#f7e089] to-[#c9a227] hover:brightness-110 text-[#082e27] text-xs font-bold rounded-lg shadow-sm flex items-center space-x-1 transition cursor-pointer disabled:opacity-50"
            >
              <Layers className="w-3.5 h-3.5 text-[#082e27]" />
              <span>Download Full CA Pack</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="mt-5 border-b border-white/10 flex flex-wrap space-x-1">
          <button
            onClick={() => { setActiveTab('BS'); setSelectedNote(null); }}
            className={`px-4 py-2 text-xs font-bold border-b-2 transition flex items-center space-x-2 rounded-t-lg ${
              activeTab === 'BS'
                ? 'border-[#c9a227] text-[#f7e089] bg-[#125246]'
                : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-white/5'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>Balance Sheet (Schedule III)</span>
          </button>

          <button
            onClick={() => { setActiveTab('PL'); setSelectedNote(null); }}
            className={`px-4 py-2 text-xs font-bold border-b-2 transition flex items-center space-x-2 rounded-t-lg ${
              activeTab === 'PL'
                ? 'border-[#c9a227] text-[#f7e089] bg-[#125246]'
                : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-white/5'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Statement of Profit & Loss</span>
          </button>

          <button
            onClick={() => setActiveTab('NOTES')}
            className={`px-4 py-2 text-xs font-bold border-b-2 transition flex items-center space-x-2 rounded-t-lg ${
              activeTab === 'NOTES'
                ? 'border-[#c9a227] text-[#f7e089] bg-[#125246]'
                : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-white/5'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Notes to Accounts (1 to 16)</span>
            <span className="bg-[#082e27] text-[#f7e089] border border-[#c9a227]/40 text-[10px] px-1.5 py-0.2 rounded-full font-mono">
              16
            </span>
          </button>

          <button
            onClick={() => { setActiveTab('SIGNATORIES'); setSelectedNote(null); }}
            className={`px-4 py-2 text-xs font-bold border-b-2 transition flex items-center space-x-2 rounded-t-lg ${
              activeTab === 'SIGNATORIES'
                ? 'border-[#c9a227] text-[#f7e089] bg-[#125246]'
                : 'border-transparent text-stone-400 hover:text-stone-200 hover:bg-white/5'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            <span>Signatories & UDIN Attestation</span>
          </button>
        </div>
      </div>

      {/* ======================= TAB 1: BALANCE SHEET ======================= */}
      {activeTab === 'BS' && (
        <div className="bg-[#082e27]/90 border border-white/10 rounded-xl overflow-hidden shadow-xl">
          <div className="bg-white/5 p-4 border-b border-white/10 text-center">
            <h3 className="font-display text-base font-bold text-white uppercase tracking-wider">
              {company.name}
            </h3>
            <p className="text-xs text-[#f7e089] font-medium mt-0.5">
              BALANCE SHEET AS AT {company.asAtCurrentDate.toUpperCase()}
            </p>
            <p className="text-[11px] text-stone-400 italic mt-0.5">
              (Pursuant to Schedule III, Division I of the Companies Act, 2013) • (Amounts in Indian Rupees ₹)
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-[#0b3d33] text-[#c9a227] border-b border-[#c9a227]/30">
                <tr>
                  <th className="py-2.5 px-4 font-semibold w-12 text-center text-[#f7e089]">#</th>
                  <th className="py-2.5 px-4 font-semibold tracking-wide">Particulars</th>
                  <th className="py-2.5 px-4 font-semibold text-center w-20">Note No.</th>
                  <th className="py-2.5 px-4 font-semibold text-right w-44">
                    Figures as at the end of current reporting period<br />
                    <span className="text-[#f7e089] font-normal">{company.currentYearLabel}</span>
                  </th>
                  <th className="py-2.5 px-4 font-semibold text-right w-44">
                    Figures as at the end of previous reporting period<br />
                    <span className="text-stone-300 font-normal">{company.previousYearLabel}</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-medium">
                {/* 1. EQUITY AND LIABILITIES Header */}
                <tr className="bg-white/5 font-bold text-[#f7e089]">
                  <td className="py-2.5 px-4 text-center">I.</td>
                  <td colSpan={4} className="py-2.5 px-4 uppercase tracking-wide font-display text-xs">
                    EQUITY AND LIABILITIES
                  </td>
                </tr>

                {/* 1. Shareholders' Funds */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center text-stone-500">(1)</td>
                  <td colSpan={4} className="py-2 px-4">Shareholders' Funds</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(a) Share Capital</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(2); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 2
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.equityAndLiabilities?.shareholdersFunds?.shareCapital?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.shareholdersFunds?.shareCapital?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(b) Reserves and Surplus</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(3); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 3
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.equityAndLiabilities?.shareholdersFunds?.reservesAndSurplus?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.shareholdersFunds?.reservesAndSurplus?.py)}
                  </td>
                </tr>
                <tr className="bg-white/[0.01] text-stone-300 font-semibold italic">
                  <td className="py-1 px-4 text-center"></td>
                  <td className="py-1 px-8">Subtotal — Shareholders' Funds</td>
                  <td className="py-1 px-4 text-center">—</td>
                  <td className="py-1 px-4 text-right font-mono-num">
                    {formatINR(balanceSheet?.equityAndLiabilities?.shareholdersFunds?.total?.cy)}
                  </td>
                  <td className="py-1 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.shareholdersFunds?.total?.py)}
                  </td>
                </tr>

                {/* 2. Non-Current Liabilities */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center text-stone-500">(2)</td>
                  <td colSpan={4} className="py-2 px-4">Non-Current Liabilities</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(a) Long-term borrowings</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(4); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 4
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(b) Deferred tax liabilities (Net)</td>
                  <td className="py-1.5 px-4 text-center text-stone-500">—</td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.deferredTaxLiabilityNet?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.deferredTaxLiabilityNet?.py)}
                  </td>
                </tr>
                <tr className="bg-white/[0.01] text-stone-300 font-semibold italic">
                  <td className="py-1 px-4 text-center"></td>
                  <td className="py-1 px-8">Subtotal — Non-Current Liabilities</td>
                  <td className="py-1 px-4 text-center">—</td>
                  <td className="py-1 px-4 text-right font-mono-num">
                    {formatINR(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.total?.cy)}
                  </td>
                  <td className="py-1 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.total?.py)}
                  </td>
                </tr>

                {/* 3. Current Liabilities */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center text-stone-500">(3)</td>
                  <td colSpan={4} className="py-2 px-4">Current Liabilities</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(a) Trade payables</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(5); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 5
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.equityAndLiabilities?.currentLiabilities?.tradePayables?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.currentLiabilities?.tradePayables?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(b) Other current liabilities</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(6); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 6
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.equityAndLiabilities?.currentLiabilities?.otherCurrentLiabilities?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.currentLiabilities?.otherCurrentLiabilities?.py)}
                  </td>
                </tr>
                <tr className="bg-white/[0.01] text-stone-300 font-semibold italic">
                  <td className="py-1 px-4 text-center"></td>
                  <td className="py-1 px-8">Subtotal — Current Liabilities</td>
                  <td className="py-1 px-4 text-center">—</td>
                  <td className="py-1 px-4 text-right font-mono-num">
                    {formatINR(balanceSheet?.equityAndLiabilities?.currentLiabilities?.total?.cy)}
                  </td>
                  <td className="py-1 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.equityAndLiabilities?.currentLiabilities?.total?.py)}
                  </td>
                </tr>

                {/* TOTAL EQUITY AND LIABILITIES */}
                <tr className="bg-[#0b3d33] font-bold border-t-2 border-b-2 border-[#c9a227] text-[#f7e089]">
                  <td className="py-2.5 px-4 text-center"></td>
                  <td className="py-2.5 px-4 uppercase">TOTAL — EQUITY AND LIABILITIES</td>
                  <td className="py-2.5 px-4 text-center"></td>
                  <td className="py-2.5 px-4 text-right font-mono-num text-sm text-[#f7e089]">
                    ₹{formatINR(balanceSheet?.equityAndLiabilities?.totalEquityAndLiabilities?.cy)}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono-num text-sm text-stone-300">
                    ₹{formatINR(balanceSheet?.equityAndLiabilities?.totalEquityAndLiabilities?.py)}
                  </td>
                </tr>

                {/* II. ASSETS Header */}
                <tr className="bg-white/5 font-bold text-[#f7e089]">
                  <td className="py-2.5 px-4 text-center">II.</td>
                  <td colSpan={4} className="py-2.5 px-4 uppercase tracking-wide font-display text-xs">
                    ASSETS
                  </td>
                </tr>

                {/* 1. Non-Current Assets */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center text-stone-500">(1)</td>
                  <td colSpan={4} className="py-2 px-4">Non-Current Assets</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(a) Fixed Assets (Property, Plant & Equipment)</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(8); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 8
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.assets?.nonCurrentAssets?.fixedAssetsTangible?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.nonCurrentAssets?.fixedAssetsTangible?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(b) Deferred tax assets (Net)</td>
                  <td className="py-1.5 px-4 text-center text-stone-500">—</td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.assets?.nonCurrentAssets?.deferredTaxAssetsNet?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.nonCurrentAssets?.deferredTaxAssetsNet?.py)}
                  </td>
                </tr>
                <tr className="bg-white/[0.01] text-stone-300 font-semibold italic">
                  <td className="py-1 px-4 text-center"></td>
                  <td className="py-1 px-8">Subtotal — Non-Current Assets</td>
                  <td className="py-1 px-4 text-center">—</td>
                  <td className="py-1 px-4 text-right font-mono-num">
                    {formatINR(balanceSheet?.assets?.nonCurrentAssets?.total?.cy)}
                  </td>
                  <td className="py-1 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.nonCurrentAssets?.total?.py)}
                  </td>
                </tr>

                {/* 2. Current Assets */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center text-stone-500">(2)</td>
                  <td colSpan={4} className="py-2 px-4">Current Assets</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(a) Inventories / Stock-in-Trade</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(12); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 12
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.assets?.currentAssets?.inventories?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.currentAssets?.inventories?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(b) Cash and bank balances</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(7); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 7
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.assets?.currentAssets?.cashAndBankBalances?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.currentAssets?.cashAndBankBalances?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(c) Other current assets</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(9); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 9
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(balanceSheet?.assets?.currentAssets?.otherCurrentAssets?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.currentAssets?.otherCurrentAssets?.py)}
                  </td>
                </tr>
                <tr className="bg-white/[0.01] text-stone-300 font-semibold italic">
                  <td className="py-1 px-4 text-center"></td>
                  <td className="py-1 px-8">Subtotal — Current Assets</td>
                  <td className="py-1 px-4 text-center">—</td>
                  <td className="py-1 px-4 text-right font-mono-num">
                    {formatINR(balanceSheet?.assets?.currentAssets?.total?.cy)}
                  </td>
                  <td className="py-1 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(balanceSheet?.assets?.currentAssets?.total?.py)}
                  </td>
                </tr>

                {/* TOTAL ASSETS */}
                <tr className="bg-[#0b3d33] font-bold border-t-2 border-b-2 border-[#c9a227] text-[#f7e089]">
                  <td className="py-2.5 px-4 text-center"></td>
                  <td className="py-2.5 px-4 uppercase">TOTAL — ASSETS</td>
                  <td className="py-2.5 px-4 text-center"></td>
                  <td className="py-2.5 px-4 text-right font-mono-num text-sm text-[#f7e089]">
                    ₹{formatINR(balanceSheet?.assets?.totalAssets?.cy)}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono-num text-sm text-stone-300">
                    ₹{formatINR(balanceSheet?.assets?.totalAssets?.py)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {/* Balance Sheet Signatory summary footer */}
          <div className="p-4 bg-black/20 border-t border-white/10 text-xs text-stone-400 flex flex-wrap justify-between items-center">
            <span>Significant Accounting Policies & Notes 1 to 16 form an integral part of this Balance Sheet.</span>
            <span className="font-mono text-[11px] text-[#f7e089]">UDIN: {company.signatories.auditorUDIN}</span>
          </div>
        </div>
      )}

      {/* ======================= TAB 2: STATEMENT OF PROFIT & LOSS ======================= */}
      {activeTab === 'PL' && (
        <div className="bg-[#082e27]/90 border border-white/10 rounded-xl overflow-hidden shadow-xl">
          <div className="bg-white/5 p-4 border-b border-white/10 text-center">
            <h3 className="font-display text-base font-bold text-white uppercase tracking-wider">
              {company.name}
            </h3>
            <p className="text-xs text-[#f7e089] font-medium mt-0.5">
              STATEMENT OF PROFIT AND LOSS FOR THE YEAR ENDED {company.asAtCurrentDate.toUpperCase()}
            </p>
            <p className="text-[11px] text-stone-400 italic mt-0.5">
              (Pursuant to Schedule III, Division I of the Companies Act, 2013) • (Amounts in Indian Rupees ₹)
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left border-collapse">
              <thead className="bg-[#0b3d33] text-[#c9a227] border-b border-[#c9a227]/30">
                <tr>
                  <th className="py-2.5 px-4 font-semibold w-12 text-center text-[#f7e089]">#</th>
                  <th className="py-2.5 px-4 font-semibold tracking-wide">Particulars</th>
                  <th className="py-2.5 px-4 font-semibold text-center w-20">Note No.</th>
                  <th className="py-2.5 px-4 font-semibold text-right w-44">
                    Figures for current reporting period<br />
                    <span className="text-[#f7e089] font-normal">{company.currentYearLabel}</span>
                  </th>
                  <th className="py-2.5 px-4 font-semibold text-right w-44">
                    Figures for previous reporting period<br />
                    <span className="text-stone-300 font-normal">{company.previousYearLabel}</span>
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5 font-medium">
                {/* I. Revenue from Operations */}
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-2 px-4 text-center font-bold text-stone-400">I.</td>
                  <td className="py-2 px-4 text-white font-semibold">Revenue from Operations</td>
                  <td className="py-2 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(10); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 10
                    </button>
                  </td>
                  <td className="py-2 px-4 text-right font-mono-num font-semibold text-white">
                    {formatINR(profitAndLoss?.income?.revenueFromOperations?.cy)}
                  </td>
                  <td className="py-2 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.income?.revenueFromOperations?.py)}
                  </td>
                </tr>

                {/* II. Other Income */}
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-2 px-4 text-center font-bold text-stone-400">II.</td>
                  <td className="py-2 px-4 text-white font-semibold">Other Income</td>
                  <td className="py-2 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(11); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 11
                    </button>
                  </td>
                  <td className="py-2 px-4 text-right font-mono-num font-semibold text-white">
                    {formatINR(profitAndLoss?.income?.otherIncome?.cy)}
                  </td>
                  <td className="py-2 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.income?.otherIncome?.py)}
                  </td>
                </tr>

                {/* III. TOTAL REVENUE (I + II) */}
                <tr className="bg-[#0b3d33]/60 font-bold text-[#f7e089] border-t border-b border-[#c9a227]/40">
                  <td className="py-2 px-4 text-center font-bold">III.</td>
                  <td className="py-2 px-4 uppercase">Total Revenue (I + II)</td>
                  <td className="py-2 px-4 text-center"></td>
                  <td className="py-2 px-4 text-right font-mono-num text-white">
                    ₹{formatINR(profitAndLoss?.income?.totalRevenue?.cy)}
                  </td>
                  <td className="py-2 px-4 text-right font-mono-num text-stone-300">
                    ₹{formatINR(profitAndLoss?.income?.totalRevenue?.py)}
                  </td>
                </tr>

                {/* IV. EXPENSES Header */}
                <tr className="bg-white/5 font-bold text-[#f7e089]">
                  <td className="py-2 px-4 text-center">IV.</td>
                  <td colSpan={4} className="py-2 px-4 uppercase tracking-wide font-display text-xs">
                    EXPENSES
                  </td>
                </tr>

                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500">•</td>
                  <td className="py-1.5 px-8 text-stone-200">Cost of Materials Consumed / Traded Goods</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(12); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 12
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.expenses?.costOfTradedGoods?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.expenses?.costOfTradedGoods?.py)}
                  </td>
                </tr>

                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500">•</td>
                  <td className="py-1.5 px-8 text-stone-200">Direct Cost / Production & Operating Expenses</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(13); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 13
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.expenses?.directCost?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.expenses?.directCost?.py)}
                  </td>
                </tr>

                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500">•</td>
                  <td className="py-1.5 px-8 text-stone-200">Administration and Other Expenses</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(14); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 14
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.expenses?.adminAndOtherExpenses?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.expenses?.adminAndOtherExpenses?.py)}
                  </td>
                </tr>

                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500">•</td>
                  <td className="py-1.5 px-8 text-stone-200">Finance Costs</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(15); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 15
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.expenses?.financeCosts?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.expenses?.financeCosts?.py)}
                  </td>
                </tr>

                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500">•</td>
                  <td className="py-1.5 px-8 text-stone-200">Depreciation and Amortisation Expense</td>
                  <td className="py-1.5 px-4 text-center">
                    <button
                      onClick={() => { setActiveTab('NOTES'); setSelectedNote(8); }}
                      className="font-mono text-[11px] text-[#f7e089] hover:bg-[#c9a227] hover:text-[#082e27] font-bold px-2 py-0.5 rounded bg-[#125246] border border-[#c9a227]/40 transition cursor-pointer"
                    >
                      Note 8
                    </button>
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.expenses?.depreciationAndAmortisation?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.expenses?.depreciationAndAmortisation?.py)}
                  </td>
                </tr>

                {/* TOTAL EXPENSES */}
                <tr className="bg-white/5 font-bold text-stone-100 border-t border-white/10">
                  <td className="py-2 px-4 text-center"></td>
                  <td className="py-2 px-4 uppercase">Total Expenses</td>
                  <td className="py-2 px-4 text-center"></td>
                  <td className="py-2 px-4 text-right font-mono-num text-[#f7e089]">
                    ₹{formatINR(profitAndLoss?.expenses?.totalExpenses?.cy)}
                  </td>
                  <td className="py-2 px-4 text-right font-mono-num text-stone-300">
                    ₹{formatINR(profitAndLoss?.expenses?.totalExpenses?.py)}
                  </td>
                </tr>

                {/* V. Profit / (Loss) Before Tax */}
                <tr className="bg-[#125246]/40 font-bold text-[#f7e089]">
                  <td className="py-2.5 px-4 text-center">V.</td>
                  <td className="py-2.5 px-4">Profit / (Loss) Before Tax (III - IV)</td>
                  <td className="py-2.5 px-4 text-center"></td>
                  <td className="py-2.5 px-4 text-right font-mono-num text-white">
                    ₹{formatINR(profitAndLoss?.profitBeforeTaxNet?.cy ?? profitAndLoss?.profitBeforeTax?.cy)}
                  </td>
                  <td className="py-2.5 px-4 text-right font-mono-num text-stone-300">
                    ₹{formatINR(profitAndLoss?.profitBeforeTaxNet?.py ?? profitAndLoss?.profitBeforeTax?.py)}
                  </td>
                </tr>

                {/* VI. Tax Expense */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center">VI.</td>
                  <td colSpan={4} className="py-2 px-4">Tax Expense:</td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(1) Current Tax</td>
                  <td className="py-1.5 px-4 text-center text-stone-500">—</td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.taxExpense?.currentTax?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.taxExpense?.currentTax?.py)}
                  </td>
                </tr>
                <tr className="hover:bg-white/5 transition-colors">
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(2) Deferred Tax (Credit) / Charge</td>
                  <td className="py-1.5 px-4 text-center text-stone-500">—</td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    {formatINR(profitAndLoss?.taxExpense?.deferredTax?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    {formatINR(profitAndLoss?.taxExpense?.deferredTax?.py)}
                  </td>
                </tr>

                {/* VII. PROFIT / (LOSS) FOR THE PERIOD (PAT) */}
                <tr className="bg-[#0b3d33] font-bold border-t-2 border-b-2 border-[#c9a227] text-[#f7e089]">
                  <td className="py-3 px-4 text-center">VII.</td>
                  <td className="py-3 px-4 uppercase text-xs tracking-wide">
                    Profit / (Loss) for the period from Continuing Operations (PAT)
                  </td>
                  <td className="py-3 px-4 text-center"></td>
                  <td className="py-3 px-4 text-right font-mono-num text-sm text-[#f7e089]">
                    ₹{formatINR(profitAndLoss?.profitAfterTax?.cy)}
                  </td>
                  <td className="py-3 px-4 text-right font-mono-num text-sm text-stone-300">
                    ₹{formatINR(profitAndLoss?.profitAfterTax?.py)}
                  </td>
                </tr>

                {/* VIII. Earnings Per Equity Share */}
                <tr className="bg-white/[0.02] font-semibold text-stone-300">
                  <td className="py-2 px-4 text-center">VIII.</td>
                  <td colSpan={4} className="py-2 px-4">Earnings Per Equity Share (Nominal value ₹10/- each):</td>
                </tr>
                <tr>
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(1) Basic (₹)</td>
                  <td className="py-1.5 px-4 text-center text-stone-500">—</td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    ₹{formatINR(profitAndLoss?.eps?.basic?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    ₹{formatINR(profitAndLoss?.eps?.basic?.py)}
                  </td>
                </tr>
                <tr>
                  <td className="py-1.5 px-4 text-center text-stone-500"></td>
                  <td className="py-1.5 px-8 text-stone-200">(2) Diluted (₹)</td>
                  <td className="py-1.5 px-4 text-center text-stone-500">—</td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-white">
                    ₹{formatINR(profitAndLoss?.eps?.diluted?.cy)}
                  </td>
                  <td className="py-1.5 px-4 text-right font-mono-num text-stone-400">
                    ₹{formatINR(profitAndLoss?.eps?.diluted?.py)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ======================= TAB 3: NOTES TO ACCOUNTS (1 to 16) ======================= */}
      {activeTab === 'NOTES' && (
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
          {/* Note Selection Sidebar */}
          <div className="bg-[#082e27]/90 border border-white/10 rounded-xl p-3 shadow-xl lg:col-span-1 max-h-[600px] overflow-y-auto space-y-1">
            <div className="text-xs font-bold text-[#c9a227] px-2 py-1 uppercase tracking-wide border-b border-white/10 mb-1">
              Notes 1 to 16 Index
            </div>
            {notesList.map((note) => (
              <button
                key={note.noteNumber}
                onClick={() => setSelectedNote(note.noteNumber)}
                className={`w-full text-left px-2.5 py-2 rounded-lg text-xs transition flex items-center justify-between cursor-pointer ${
                  selectedNote === note.noteNumber
                    ? 'bg-[#125246] text-[#f7e089] font-bold border border-[#c9a227]/40 shadow-sm'
                    : 'text-stone-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <span className="truncate pr-2">
                  <span className="font-mono font-bold mr-1">Note {note.noteNumber}:</span>
                  {note.title}
                </span>
                {!note.isTextOnly && (
                  <span className="font-mono text-[10px] text-[#f7e089]/80 flex-shrink-0">
                    ₹{formatINR(note.totalCY)}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* Note Detail Panel */}
          <div className="bg-[#082e27]/90 border border-white/10 rounded-xl p-5 shadow-xl lg:col-span-3 min-h-[450px]">
            {selectedNote === null ? (
              <div className="space-y-6">
                <div className="text-center py-4 border-b border-white/10">
                  <h3 className="font-display text-base font-bold text-white tracking-wide">
                    Complete Notes to Accounts (Notes 1 to 16)
                  </h3>
                  <p className="text-xs text-stone-400 mt-1">
                    Select a specific note on the left or browse key statutory breakdowns below.
                  </p>
                </div>

                {/* Quick Cards for Notes */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {notesList.slice(0, 8).map((n) => (
                    <div
                      key={n.noteNumber}
                      onClick={() => setSelectedNote(n.noteNumber)}
                      className="border border-white/10 rounded-lg p-3.5 hover:border-[#c9a227]/60 hover:bg-white/5 transition cursor-pointer bg-white/[0.02]"
                    >
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-xs font-bold text-white">Note {n.noteNumber}: {n.title}</span>
                        {!n.isTextOnly && (
                          <span className="text-xs font-mono font-bold text-[#f7e089]">
                            ₹{formatINR(n.totalCY)}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-stone-400 line-clamp-2">
                        {n.subItems && n.subItems.length > 0
                          ? n.subItems.map((s) => s.particulars).join(', ')
                          : n.textNote || 'Schedule III standard disclosure details'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              (() => {
                const note = notesList.find((n) => n.noteNumber === selectedNote);
                if (!note) return <div className="text-stone-400">Note not found</div>;

                return (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <div>
                        <span className="text-xs font-mono font-bold text-[#c9a227] uppercase">Schedule III Disclosure</span>
                        <h3 className="font-display text-lg font-bold text-white">
                          Note {note.noteNumber}: {note.title}
                        </h3>
                      </div>
                      <button
                        onClick={() => setSelectedNote(null)}
                        className="text-xs text-stone-400 hover:text-white underline cursor-pointer"
                      >
                        View All Notes
                      </button>
                    </div>

                    {/* Textual Note content if any (like policies) */}
                    {note.textNote && (
                      <div className="bg-black/30 p-3 rounded-lg border border-white/10 text-xs text-stone-300 whitespace-pre-line leading-relaxed">
                        {note.textNote}
                      </div>
                    )}

                    {/* Breakdown Table if sub-items present */}
                    {note.subItems && note.subItems.length > 0 && (
                      <div className="border border-white/10 rounded-lg overflow-hidden">
                        <table className="w-full text-xs text-left border-collapse">
                          <thead className="bg-[#0b3d33] text-[#c9a227] border-b border-[#c9a227]/30">
                            <tr>
                              <th className="py-2 px-3 font-semibold">Particulars</th>
                              <th className="py-2 px-3 font-semibold text-right w-40">As at {company.asAtCurrentDate} (₹)</th>
                              <th className="py-2 px-3 font-semibold text-right w-40">As at {company.asAtPreviousDate} (₹)</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-white/5 font-medium">
                            {note.subItems.map((item, idx) => (
                              <tr key={idx} className="hover:bg-white/5 transition-colors">
                                <td className="py-2 px-3 text-stone-200">{item.particulars}</td>
                                <td className="py-2 px-3 text-right font-mono-num text-white">
                                  {formatINR(item.currentYearValue)}
                                </td>
                                <td className="py-2 px-3 text-right font-mono-num text-stone-400">
                                  {formatINR(item.previousYearValue)}
                                </td>
                              </tr>
                            ))}
                            <tr className="bg-[#0b3d33] font-bold text-[#f7e089] border-t border-[#c9a227]/40">
                              <td className="py-2 px-3 uppercase">Total — Note {note.noteNumber}</td>
                              <td className="py-2 px-3 text-right font-mono-num text-[#f7e089]">
                                ₹{formatINR(note.totalCY)}
                              </td>
                              <td className="py-2 px-3 text-right font-mono-num text-stone-300">
                                ₹{formatINR(note.totalPY)}
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    )}

                    {/* Special Display for Note 2 Share Capital details */}
                    {note.noteNumber === 2 && (
                      <div className="bg-[#0b3d33]/50 p-3.5 rounded-lg border border-[#c9a227]/30 text-xs space-y-2 mt-4">
                        <h4 className="font-bold text-[#f7e089]">Details of Shareholders holding more than 5% shares:</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                          <div className="bg-black/40 p-2.5 rounded border border-white/10">
                            <span className="font-bold text-white">1. PRASHANT KUMAR:</span> 5,000 Equity Shares (50.00%)
                          </div>
                          <div className="bg-black/40 p-2.5 rounded border border-white/10">
                            <span className="font-bold text-white">2. SHWETA SENGAR:</span> 5,000 Equity Shares (50.00%)
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()
            )}
          </div>
        </div>
      )}

      {/* ======================= TAB 4: SIGNATORIES & UDIN ======================= */}
      {activeTab === 'SIGNATORIES' && (
        <div className="bg-[#082e27]/90 border border-white/10 rounded-xl p-6 shadow-xl space-y-6">
          <div className="border-b border-white/10 pb-4">
            <h3 className="font-display text-lg font-bold text-white">Statutory Signatures & CA Attestation Block</h3>
            <p className="text-xs text-stone-400 mt-0.5">
              Form of execution in terms of Companies Act 2013 and ICAI UDIN Guidelines
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Board of Directors Box */}
            <div className="border border-white/10 rounded-xl p-5 bg-white/5 space-y-4 backdrop-blur">
              <div className="flex items-center space-x-2">
                <Building className="w-5 h-5 text-[#f7e089]" />
                <h4 className="font-bold text-white text-sm">For and on behalf of the Board of Directors</h4>
              </div>
              <p className="text-xs text-[#f7e089] font-bold uppercase">{company.name}</p>

              <div className="pt-8 grid grid-cols-2 gap-4 border-t border-white/10 text-xs">
                <div>
                  <div className="font-bold text-white">{company.signatories.director1Name}</div>
                  <div className="text-stone-400">{company.signatories.director1Designation}</div>
                  <div className="font-mono text-[#f7e089]/70 text-[11px]">DIN: {company.signatories.director1DIN}</div>
                </div>

                <div>
                  <div className="font-bold text-white">{company.signatories.director2Name}</div>
                  <div className="text-stone-400">{company.signatories.director2Designation}</div>
                  <div className="font-mono text-[#f7e089]/70 text-[11px]">DIN: {company.signatories.director2DIN}</div>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-stone-400 border-t border-white/10 flex justify-between">
                <span>Place: {company.signatories.placeOfSigning}</span>
                <span>Date: {company.signatories.dateOfSigning}</span>
              </div>
            </div>

            {/* Statutory Auditor Box */}
            <div className="border border-[#c9a227]/40 rounded-xl p-5 bg-gradient-to-br from-[#125246]/40 to-[#0b3d33]/60 space-y-4 backdrop-blur">
              <div className="flex items-center space-x-2">
                <Award className="w-5 h-5 text-[#c9a227]" />
                <h4 className="font-bold text-[#f7e089] text-sm">In terms of our report of even date attached</h4>
              </div>
              <p className="text-xs font-bold text-white uppercase">
                FOR {company.signatories.auditorFirmName}
              </p>
              <div className="text-xs text-stone-300">Chartered Accountants • FRN: {company.signatories.auditorFirmRegNo}</div>

              <div className="pt-6 border-t border-[#c9a227]/40 text-xs space-y-1">
                <div className="font-bold text-white">CA {company.signatories.auditorPartnerName}</div>
                <div className="text-stone-300">{company.signatories.auditorDesignation} • M.No: {company.signatories.auditorMembershipNo}</div>
                <div className="font-mono font-bold text-[#082e27] bg-[#c9a227] px-2.5 py-1 rounded border border-[#f7e089] inline-block mt-1">
                  UDIN: {company.signatories.auditorUDIN}
                </div>
              </div>

              <div className="pt-2 text-[11px] text-stone-400 border-t border-[#c9a227]/20 flex justify-between">
                <span>Place: {company.signatories.placeOfSigning}</span>
                <span>Date: {company.signatories.dateOfSigning}</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
