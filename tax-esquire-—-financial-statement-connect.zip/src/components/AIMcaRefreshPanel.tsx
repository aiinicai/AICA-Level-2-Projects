import React, { useState } from 'react';
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  ExternalLink,
  FileCheck,
  FileSpreadsheet,
  FileText,
  HelpCircle,
  RefreshCw,
  Search,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { AIMcaCheckResult } from '../types';

interface AIMcaRefreshPanelProps {
  onClose?: () => void;
}

export const AIMcaRefreshPanel: React.FC<AIMcaRefreshPanelProps> = ({ onClose }) => {
  const [selectedTopic, setSelectedTopic] = useState<string>('SCHEDULE_III');
  const [customQuery, setCustomQuery] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [result, setResult] = useState<AIMcaCheckResult | null>(null);

  const topics = [
    {
      id: 'SCHEDULE_III',
      title: 'Schedule III (Division I - AS)',
      desc: 'Mandatory ratios, Trade Payables MSME ageing, CWIP ageing, and Pass-through funds.',
      icon: FileSpreadsheet
    },
    {
      id: 'AOC_4',
      title: 'Form AOC-4 (MCA V3 Portal)',
      desc: 'Attachment validations, Rule 3(1) Accounting Software Audit Trail, and filing deadlines.',
      icon: FileCheck
    },
    {
      id: 'MGT_7',
      title: 'Form MGT-7 / MGT-7A (Annual Return)',
      desc: 'Section 92 disclosures, Shareholding pattern, and Rule 9B Dematerialisation mandates.',
      icon: FileText
    },
    {
      id: 'CARO_2020',
      title: 'CARO 2020 Applicability Check',
      desc: '21 reporting clauses & Private company exemption thresholds (₹1 Cr capital, ₹10 Cr revenue).',
      icon: ShieldCheck
    },
    {
      id: 'AUDIT_RULES_11',
      title: 'Rule 11 Audit Trail (Edit Log)',
      desc: 'Statutory auditor reporting duties on software edit logs and intermediary funding.',
      icon: BookOpen
    }
  ];

  const handleRunAICheck = async (topicId?: string) => {
    const topicToUse = topicId || selectedTopic;
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/mca-amendment-check', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topicType: topicToUse,
          customQuery: customQuery.trim() || undefined
        })
      });

      const data = await res.json();
      if (data.success && data.result) {
        setResult(data.result);
      } else {
        throw new Error(data.error || 'Failed to check MCA amendments');
      }
    } catch (err: any) {
      setResult({
        topicTitle: topicToUse,
        timestamp: new Date().toISOString(),
        analysis: `Error during query: ${err.message}. Please verify at official portal mca.gov.in.`,
        disclaimer: 'Research aid only — verify against mca.gov.in.'
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#0b3d33]/60 backdrop-blur rounded-xl p-6 text-white shadow-lg border border-[#c9a227]/40">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <Sparkles className="w-5 h-5 text-[#c9a227]" />
              <h2 className="font-display text-xl font-bold tracking-wide text-white">
                AI Format Refresh & MCA Regulatory Intelligence
              </h2>
            </div>
            <p className="text-xs text-stone-300 mt-1 max-w-2xl">
              Real-time server-side MCA statutory checks powered by Gemini. Inspect recent circulars,
              Schedule III disclosure rules, Audit Trail guidelines, and e-Form attachments.
            </p>
          </div>

          {/* Mandatory Disclaimer Badge */}
          <div className="bg-[#082e27] border border-[#c9a227]/60 px-3.5 py-2 rounded-lg text-right">
            <span className="text-[10px] font-mono text-[#f7e089] block font-bold uppercase tracking-wider">
              Statutory Notice
            </span>
            <span className="text-xs text-stone-300 font-serif italic">
              Research aid only — verify against mca.gov.in.
            </span>
          </div>
        </div>
      </div>

      {/* Topic Selector Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {topics.map((t) => {
          const Icon = t.icon;
          const isSelected = selectedTopic === t.id;

          return (
            <button
              key={t.id}
              type="button"
              onClick={() => {
                setSelectedTopic(t.id);
                handleRunAICheck(t.id);
              }}
              className={`p-4 rounded-xl text-left border transition cursor-pointer flex flex-col justify-between ${
                isSelected
                  ? 'bg-[#125246]/60 border-[#c9a227] ring-1 ring-[#c9a227]'
                  : 'bg-[#082e27]/90 border-white/10 hover:border-[#c9a227]/60'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-2">
                  <div className="w-8 h-8 rounded-lg bg-[#125246] flex items-center justify-center border border-white/10">
                    <Icon className="w-4 h-4 text-[#c9a227]" />
                  </div>
                  {isSelected && (
                    <span className="bg-[#c9a227] text-[#082e27] text-[10px] font-bold px-2 py-0.5 rounded">Active</span>
                  )}
                </div>
                <h4 className="font-bold text-xs text-white">{t.title}</h4>
                <p className="text-[11px] text-stone-300 mt-1 leading-snug">{t.desc}</p>
              </div>

              <span className="text-[11px] font-semibold text-[#f7e089] mt-3 flex items-center space-x-1">
                <span>Run Inspection</span>
                <span>→</span>
              </span>
            </button>
          );
        })}
      </div>

      {/* Custom Query Box */}
      <div className="bg-[#082e27]/90 border border-white/10 rounded-xl p-4 shadow-xl flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute left-3 top-3 text-stone-400" />
          <input
            type="text"
            value={customQuery}
            onChange={(e) => setCustomQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleRunAICheck()}
            placeholder="Ask specific MCA question (e.g., 'What are the 11 ratios required in Schedule III?')..."
            className="w-full pl-9 pr-3 py-2 bg-[#051e19] border border-white/10 rounded-lg text-xs text-white placeholder-stone-500 focus:border-[#c9a227] focus:outline-none"
          />
        </div>

        <button
          onClick={() => handleRunAICheck()}
          disabled={isLoading}
          className="w-full sm:w-auto px-5 py-2 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] font-bold text-xs rounded-lg shadow-sm flex items-center justify-center space-x-1.5 cursor-pointer disabled:opacity-50"
        >
          <Sparkles className={`w-3.5 h-3.5 text-[#082e27] ${isLoading ? 'animate-spin' : ''}`} />
          <span>{isLoading ? 'Researching MCA...' : 'Run MCA AI Audit Check'}</span>
        </button>
      </div>

      {/* Results Display Area */}
      {result && (
        <div className="bg-[#082e27]/90 border border-white/10 rounded-xl p-6 shadow-xl space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-3 gap-2">
            <div>
              <span className="text-[10px] font-mono font-bold text-[#f7e089] uppercase tracking-wider">
                Tax Esquire Regulatory Briefing
              </span>
              <h3 className="font-display text-lg font-bold text-white">
                {result.topicTitle} Compliance Standards
              </h3>
            </div>
            <div className="text-[11px] text-stone-400 font-mono">
              Timestamp: {new Date(result.timestamp).toLocaleTimeString('en-IN')}
            </div>
          </div>

          <div className="bg-[#051e19] p-5 rounded-lg border border-white/10 text-xs text-stone-200 leading-relaxed font-sans whitespace-pre-line">
            {result.analysis}
          </div>

          {/* Prominent Footer Disclaimer */}
          <div className="pt-3 border-t border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
            <div className="flex items-center space-x-2 text-amber-300 font-medium">
              <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <span>{result.disclaimer}</span>
            </div>

            <a
              href="https://www.mca.gov.in"
              target="_blank"
              rel="noreferrer"
              className="text-[#f7e089] hover:underline font-semibold flex items-center space-x-1"
            >
              <span>Visit Official MCA V3 Portal</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>
      )}
    </div>
  );
};
