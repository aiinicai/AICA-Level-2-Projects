import React from 'react';
import { Building2, CheckCircle2, FileSpreadsheet, Lock, LogOut, RefreshCw, ShieldCheck, Sparkles, User } from 'lucide-react';
import { CompanyProfile, UserSession } from '../types';

interface NavbarProps {
  currentUser: UserSession | null;
  companies: CompanyProfile[];
  activeCompany: CompanyProfile | null;
  onSelectCompany: (companyId: string) => void;
  onNewCompany: () => void;
  onEditCompany: () => void;
  onOpenAIRefresh: () => void;
  onLogout: () => void;
  onLoginClick: () => void;
  activeView: 'TRIAL_BALANCE' | 'FINANCIAL_STATEMENTS' | 'DOCUMENTS' | 'AI_REFRESH';
  onNavigate: (view: 'TRIAL_BALANCE' | 'FINANCIAL_STATEMENTS' | 'DOCUMENTS' | 'AI_REFRESH') => void;
  isSaving?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentUser,
  companies,
  activeCompany,
  onSelectCompany,
  onNewCompany,
  onEditCompany,
  onOpenAIRefresh,
  onLogout,
  onLoginClick,
  activeView,
  onNavigate,
  isSaving
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#0b3d33] text-white border-b border-[#c9a227]/30 shadow-md">
      {/* Top Gold Thin Accent Bar */}
      <div className="h-1 bg-gradient-to-r from-[#c9a227] via-[#f7e089] to-[#c9a227]" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('FINANCIAL_STATEMENTS')}>
              {/* Serif TFC Logo Mark */}
              <div className="w-11 h-11 rounded-lg bg-gradient-to-br from-[#14594c] to-[#072720] border border-[#c9a227] flex items-center justify-center shadow-inner relative group">
                <span className="font-display text-lg font-bold text-[#c9a227] tracking-wider">TFC</span>
                <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-[#c9a227] rounded-full flex items-center justify-center">
                  <ShieldCheck className="w-2.5 h-2.5 text-[#0b3d33]" />
                </div>
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="font-display text-lg font-bold tracking-wide text-white">TAX FIN CONNECT</h1>
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded bg-[#c9a227]/20 text-[#f7e089] border border-[#c9a227]/40">
                    CA Edition
                  </span>
                </div>
                <p className="text-xs text-stone-300 font-light tracking-wide">Financial Statement Connect • Schedule III</p>
              </div>
            </div>

            {/* Active Company Selector */}
            {currentUser && activeCompany && (
              <div className="hidden lg:flex items-center ml-4 pl-4 border-l border-white/10 space-x-2">
                <Building2 className="w-4 h-4 text-[#c9a227]" />
                <select
                  value={activeCompany.id}
                  onChange={(e) => onSelectCompany(e.target.value)}
                  aria-label="Select Client Company"
                  className="bg-[#072720]/80 border border-[#c9a227]/40 text-stone-100 text-xs rounded-md px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-[#c9a227] max-w-[260px] truncate font-medium cursor-pointer"
                >
                  {companies.map((c) => (
                    <option key={c.id} value={c.id} className="bg-stone-900 text-white">
                      {c.name} ({c.financialYearCurrent})
                    </option>
                  ))}
                </select>
                <button
                  onClick={onEditCompany}
                  title="Edit Company Details & Signatories"
                  className="text-[11px] text-[#f7e089] hover:underline hover:text-white px-1 py-0.5 font-medium"
                >
                  Edit CIN/Info
                </button>
                <button
                  onClick={onNewCompany}
                  title="Add new client company"
                  className="text-[11px] bg-[#c9a227]/20 hover:bg-[#c9a227]/30 text-[#f7e089] border border-[#c9a227]/50 px-2 py-0.5 rounded"
                >
                  + Add Client
                </button>
              </div>
            )}
          </div>

          {/* Navigation Links */}
          {currentUser && (
            <nav className="hidden md:flex items-center space-x-1 lg:space-x-2">
              <button
                onClick={() => onNavigate('TRIAL_BALANCE')}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center space-x-1.5 ${
                  activeView === 'TRIAL_BALANCE'
                    ? 'bg-[#c9a227] text-[#072720] shadow-sm font-semibold'
                    : 'text-stone-200 hover:bg-white/10 hover:text-white'
                }`}
              >
                <FileSpreadsheet className="w-3.5 h-3.5" />
                <span>Trial Balance</span>
              </button>

              <button
                onClick={() => onNavigate('FINANCIAL_STATEMENTS')}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center space-x-1.5 ${
                  activeView === 'FINANCIAL_STATEMENTS'
                    ? 'bg-[#c9a227] text-[#072720] shadow-sm font-semibold'
                    : 'text-stone-200 hover:bg-white/10 hover:text-white'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Schedule III Statements</span>
              </button>

              <button
                onClick={() => onNavigate('DOCUMENTS')}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center space-x-1.5 ${
                  activeView === 'DOCUMENTS'
                    ? 'bg-[#c9a227] text-[#072720] shadow-sm font-semibold'
                    : 'text-stone-200 hover:bg-white/10 hover:text-white'
                }`}
              >
                <span>Word (.docx) Pack</span>
                <span className="bg-[#072720] text-[#f7e089] text-[10px] px-1.5 py-0.2 rounded font-mono">7 Files</span>
              </button>

              <button
                onClick={onOpenAIRefresh}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-colors flex items-center space-x-1.5 ${
                  activeView === 'AI_REFRESH'
                    ? 'bg-[#c9a227] text-[#072720] shadow-sm font-semibold'
                    : 'bg-emerald-900/60 text-[#f7e089] border border-[#c9a227]/40 hover:bg-[#c9a227]/20'
                }`}
              >
                <Sparkles className="w-3.5 h-3.5 text-[#c9a227]" />
                <span>AI MCA Refresh</span>
              </button>
            </nav>
          )}

          {/* User Profile / Login status */}
          <div className="flex items-center space-x-3">
            {isSaving && (
              <span className="hidden sm:flex items-center text-xs text-amber-300 space-x-1">
                <RefreshCw className="w-3 h-3 animate-spin" />
                <span>Saving...</span>
              </span>
            )}

            {currentUser ? (
              <div className="flex items-center space-x-3">
                <div className="text-right hidden sm:block">
                  <div className="text-xs font-semibold text-white flex items-center justify-end space-x-1">
                    <span>{currentUser.name}</span>
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  </div>
                  <div className="text-[10px] text-stone-300 truncate max-w-[180px]">
                    {currentUser.firmName} • FRN {currentUser.frn}
                  </div>
                </div>
                <button
                  onClick={onLogout}
                  title="Sign out from CA Portal"
                  className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-stone-300 hover:text-white transition"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button
                onClick={onLoginClick}
                className="px-4 py-1.5 rounded-md bg-[#c9a227] hover:bg-[#d8b030] text-[#072720] font-semibold text-xs transition shadow flex items-center space-x-1.5"
              >
                <Lock className="w-3.5 h-3.5" />
                <span>CA Portal Login</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
