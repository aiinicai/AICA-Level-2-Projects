import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  ClipboardPaste,
  Download,
  FileSpreadsheet,
  HelpCircle,
  Plus,
  RefreshCw,
  Search,
  Sparkles,
  Trash2,
  Upload
} from 'lucide-react';
import { ScheduleIIICategory, TrialBalanceRow } from '../types';
import { getCategoryMetadata, SCHEDULE_III_CATEGORIES, suggestCategoryForLedger } from '../utils/scheduleIIICategories';
import { INITIAL_TRIAL_BALANCE_CY, INITIAL_TRIAL_BALANCE_PY } from '../data/sampleCompanyData';

interface TrialBalanceEditorProps {
  currentYearRows: TrialBalanceRow[];
  previousYearRows: TrialBalanceRow[];
  onUpdateCY: (rows: TrialBalanceRow[]) => void;
  onUpdatePY: (rows: TrialBalanceRow[]) => void;
  onCalculate: () => void;
  onAIClassify?: (ledgerName: string, rowIndex: number) => void;
  currentYearLabel?: string;
  previousYearLabel?: string;
  isCalculating?: boolean;
}

export const TrialBalanceEditor: React.FC<TrialBalanceEditorProps> = ({
  currentYearRows,
  previousYearRows,
  onUpdateCY,
  onUpdatePY,
  onCalculate,
  currentYearLabel = 'Current FY (2023-24)',
  previousYearLabel = 'Previous FY (2022-23)',
  isCalculating = false
}) => {
  const [activeYearTab, setActiveYearTab] = useState<'CY' | 'PY'>('CY');
  const [searchFilter, setSearchFilter] = useState('');
  const [pasteModalOpen, setPasteModalOpen] = useState(false);
  const [pastedRawText, setPastedRawText] = useState('');
  const [aiClassifyingRow, setAiClassifyingRow] = useState<string | null>(null);

  const activeRows = activeYearTab === 'CY' ? currentYearRows : previousYearRows;
  const updateActiveRows = (newRows: TrialBalanceRow[]) => {
    if (activeYearTab === 'CY') {
      onUpdateCY(newRows);
    } else {
      onUpdatePY(newRows);
    }
  };

  // Calculate Debits, Credits & Balance
  const totalDebit = activeRows.reduce((acc, row) => acc + (Number(row.debit) || 0), 0);
  const totalCredit = activeRows.reduce((acc, row) => acc + (Number(row.credit) || 0), 0);
  const diff = Math.abs(totalDebit - totalCredit);
  const isTallied = diff < 1;

  // Handle Ledger Name change with auto-suggest
  const handleLedgerNameChange = (id: string, name: string) => {
    const updated = activeRows.map((r) => {
      if (r.id === id) {
        // If not manually locked/overridden, suggest Schedule III category
        const suggestedCat = suggestCategoryForLedger(name);
        const catMeta = getCategoryMetadata(suggestedCat);
        return {
          ...r,
          ledgerName: name,
          category: r.category && r.category !== ScheduleIIICategory.ADMINISTRATION_AND_OTHER_EXPENSES ? r.category : suggestedCat,
          noteNumber: catMeta?.defaultNoteNumber
        };
      }
      return r;
    });
    updateActiveRows(updated);
  };

  const handleDebitChange = (id: string, val: string) => {
    const num = val === '' ? 0 : parseFloat(val);
    const updated = activeRows.map((r) => (r.id === id ? { ...r, debit: isNaN(num) ? 0 : num } : r));
    updateActiveRows(updated);
  };

  const handleCreditChange = (id: string, val: string) => {
    const num = val === '' ? 0 : parseFloat(val);
    const updated = activeRows.map((r) => (r.id === id ? { ...r, credit: isNaN(num) ? 0 : num } : r));
    updateActiveRows(updated);
  };

  const handleCategoryChange = (id: string, cat: ScheduleIIICategory) => {
    const catDef = SCHEDULE_III_CATEGORIES[cat];
    const updated = activeRows.map((r) => (r.id === id ? { ...r, category: cat, noteNumber: catDef?.noteNumber } : r));
    updateActiveRows(updated);
  };

  const handleAddRow = () => {
    const newRow: TrialBalanceRow = {
      id: `tb_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      ledgerName: '',
      debit: 0,
      credit: 0,
      category: ScheduleIIICategory.ADMINISTRATION_AND_OTHER_EXPENSES,
      noteNumber: 14
    };
    updateActiveRows([...activeRows, newRow]);
  };

  const handleDeleteRow = (id: string) => {
    updateActiveRows(activeRows.filter((r) => r.id !== id));
  };

  const handleResetTo1857Seed = () => {
    if (confirm('Load attached 1857 Revolteam Pvt Ltd Trial Balance data (both CY 2024 & PY 2023)?')) {
      onUpdateCY(INITIAL_TRIAL_BALANCE_CY);
      onUpdatePY(INITIAL_TRIAL_BALANCE_PY);
    }
  };

  // AI assistant to classify ambiguous ledger
  const handleAIClassifyLedger = async (row: TrialBalanceRow) => {
    if (!row.ledgerName) return;
    setAiClassifyingRow(row.id);
    try {
      const res = await fetch('/api/gemini/classify-ledger', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ledgerName: row.ledgerName })
      });
      const data = await res.json();
      if (data.success && data.classification?.category) {
        handleCategoryChange(row.id, data.classification.category as ScheduleIIICategory);
      }
    } catch (err) {
      console.error('AI Classification error:', err);
    } finally {
      setAiClassifyingRow(null);
    }
  };

  // Bulk Paste parser (Tab / Comma separated)
  const handleProcessBulkPaste = () => {
    if (!pastedRawText.trim()) return;
    const lines = pastedRawText.trim().split('\n');
    const parsedRows: TrialBalanceRow[] = [];

    lines.forEach((line, idx) => {
      // Split by tab or comma
      const parts = line.includes('\t') ? line.split('\t') : line.split(',');
      if (parts.length >= 2) {
        const rawName = parts[0].trim();
        let debit = 0;
        let credit = 0;

        if (parts.length === 2) {
          const val = parseFloat(parts[1].replace(/[^0-9.-]+/g, '')) || 0;
          if (val > 0) debit = val;
          else credit = Math.abs(val);
        } else if (parts.length >= 3) {
          debit = parseFloat(parts[1].replace(/[^0-9.-]+/g, '')) || 0;
          credit = parseFloat(parts[2].replace(/[^0-9.-]+/g, '')) || 0;
        }

        if (rawName) {
          const suggestedCat = suggestCategoryForLedger(rawName);
          const catMeta = getCategoryMetadata(suggestedCat);
          parsedRows.push({
            id: `tb_paste_${Date.now()}_${idx}`,
            ledgerName: rawName,
            debit,
            credit,
            category: suggestedCat,
            noteNumber: catMeta?.defaultNoteNumber
          });
        }
      }
    });

    if (parsedRows.length > 0) {
      updateActiveRows([...activeRows, ...parsedRows]);
      setPastedRawText('');
      setPasteModalOpen(false);
    }
  };

  // Filtered rows for fast search
  const displayedRows = activeRows.filter(
    (r) =>
      r.ledgerName.toLowerCase().includes(searchFilter.toLowerCase()) ||
      r.category.toLowerCase().includes(searchFilter.toLowerCase())
  );

  return (
    <div className="space-y-4">
      {/* Top Header Card */}
      <div className="bg-[#0b3d33]/50 backdrop-blur border border-white/10 rounded-xl p-5 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-display text-lg font-bold text-white tracking-wide">Trial Balance Entry & Auto-Classification</span>
              <span className="text-xs bg-[#c9a227]/20 text-[#f7e089] font-semibold px-2 py-0.5 rounded border border-[#c9a227]/40 font-mono">
                Division I (AS)
              </span>
            </div>
            <p className="text-xs text-stone-300 mt-1">
              Enter ledger accounts. System matches keywords to Schedule III heads with manual CA override.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Year Switcher */}
            <div className="bg-[#082e27] p-1 rounded-lg flex space-x-1 border border-white/10">
              <button
                onClick={() => setActiveYearTab('CY')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition cursor-pointer ${
                  activeYearTab === 'CY' ? 'bg-[#c9a227] text-[#082e27] shadow-sm' : 'text-stone-300 hover:text-white'
                }`}
              >
                {currentYearLabel}
              </button>
              <button
                onClick={() => setActiveYearTab('PY')}
                className={`px-3 py-1.5 text-xs font-bold rounded-md transition cursor-pointer ${
                  activeYearTab === 'PY' ? 'bg-[#c9a227] text-[#082e27] shadow-sm' : 'text-stone-300 hover:text-white'
                }`}
              >
                {previousYearLabel}
              </button>
            </div>

            <button
              onClick={() => setPasteModalOpen(true)}
              className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-stone-200 text-xs font-semibold rounded-lg border border-white/10 hover:border-[#c9a227]/50 flex items-center space-x-1 transition cursor-pointer"
            >
              <ClipboardPaste className="w-3.5 h-3.5 text-stone-300" />
              <span>Bulk Paste Excel</span>
            </button>

            <button
              onClick={handleResetTo1857Seed}
              className="px-3 py-1.5 bg-[#125246]/60 hover:bg-[#125246] text-[#f7e089] text-xs font-semibold rounded-lg border border-[#c9a227]/40 flex items-center space-x-1 transition cursor-pointer"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#f7e089]" />
              <span>Preload 1857 Revolteam TB</span>
            </button>

            <button
              onClick={onCalculate}
              disabled={isCalculating}
              className="px-4 py-2 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] text-xs font-bold rounded-lg shadow-sm flex items-center space-x-1.5 transition cursor-pointer disabled:opacity-50"
            >
              <Sparkles className="w-3.5 h-3.5 text-[#082e27]" />
              <span>{isCalculating ? 'Computing...' : 'Calculate Financials'}</span>
              <ArrowRight className="w-3.5 h-3.5 text-[#082e27]" />
            </button>
          </div>
        </div>

        {/* Tally Summary Bar */}
        <div className="mt-4 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1.5">
              <span className="text-stone-400 font-medium">Total Debits:</span>
              <span className="font-mono-num font-bold text-white">
                ₹{totalDebit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="text-stone-400 font-medium">Total Credits:</span>
              <span className="font-mono-num font-bold text-white">
                ₹{totalCredit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="text-stone-400 font-medium">Difference:</span>
              <span
                className={`font-mono-num font-bold ${
                  isTallied ? 'text-[#34d399]' : 'text-rose-400'
                }`}
              >
                ₹{diff.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            {isTallied ? (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full badge-green font-semibold text-[11px]">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#34d399]" />
                <span>Trial Balance Tallied</span>
              </span>
            ) : (
              <span className="inline-flex items-center space-x-1 px-2.5 py-1 rounded-full bg-amber-950/70 text-[#f7e089] font-semibold text-[11px] border border-amber-500/50">
                <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                <span>Difference of ₹{diff.toFixed(2)} — Suspense adjustment required</span>
              </span>
            )}

            {/* Quick Search */}
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2 text-stone-400" />
              <input
                type="text"
                placeholder="Filter ledgers..."
                value={searchFilter}
                onChange={(e) => setSearchFilter(e.target.value)}
                className="pl-8 pr-3 py-1 bg-[#082e27] border border-white/10 text-stone-100 placeholder-stone-500 rounded text-xs focus:outline-none focus:border-[#c9a227] w-40 sm:w-48"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Trial Balance Table */}
      <div className="bg-[#082e27]/90 border border-white/10 rounded-xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#0b3d33] text-[#c9a227] border-b border-[#c9a227]/30 sticky top-0 z-10">
              <tr>
                <th className="py-3 px-3 w-10 text-center font-semibold text-[#f7e089]">#</th>
                <th className="py-3 px-3 font-semibold tracking-wide min-w-[240px]">Ledger Account Name</th>
                <th className="py-3 px-3 font-semibold text-right w-36">Debit (₹)</th>
                <th className="py-3 px-3 font-semibold text-right w-36">Credit (₹)</th>
                <th className="py-3 px-3 font-semibold min-w-[300px]">Schedule III Category (Classification)</th>
                <th className="py-3 px-3 text-center w-16">Note</th>
                <th className="py-3 px-3 text-center w-24">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5 font-medium">
              {displayedRows.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-stone-400">
                    No ledger entries found. Click "+ Add Row" or "Preload 1857 Revolteam TB" to begin.
                  </td>
                </tr>
              ) : (
                displayedRows.map((row, idx) => {
                  const catDef = SCHEDULE_III_CATEGORIES[row.category];
                  const isAIClassifying = aiClassifyingRow === row.id;

                  return (
                    <tr key={row.id} className="hover:bg-white/5 transition-colors">
                      <td className="py-2 px-3 text-center text-stone-500 font-mono text-[11px]">{idx + 1}</td>

                      {/* Ledger Name input with auto suggest */}
                      <td className="py-2 px-3">
                        <input
                          type="text"
                          value={row.ledgerName}
                          onChange={(e) => handleLedgerNameChange(row.id, e.target.value)}
                          placeholder="e.g. Sundry Debtors / Rent Expense"
                          className="w-full px-2 py-1.5 border border-white/10 rounded font-medium text-white placeholder-stone-600 focus:outline-none focus:border-[#c9a227] bg-[#051e19]/60 focus:bg-[#051e19]"
                        />
                      </td>

                      {/* Debit Input */}
                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.01"
                          value={row.debit === 0 ? '' : row.debit}
                          onChange={(e) => handleDebitChange(row.id, e.target.value)}
                          placeholder="0.00"
                          className="w-full text-right px-2 py-1.5 border border-white/10 rounded font-mono-num font-medium text-white placeholder-stone-600 focus:outline-none focus:border-[#c9a227] bg-[#051e19]/60 focus:bg-[#051e19]"
                        />
                      </td>

                      {/* Credit Input */}
                      <td className="py-2 px-3 text-right">
                        <input
                          type="number"
                          step="0.01"
                          value={row.credit === 0 ? '' : row.credit}
                          onChange={(e) => handleCreditChange(row.id, e.target.value)}
                          placeholder="0.00"
                          className="w-full text-right px-2 py-1.5 border border-white/10 rounded font-mono-num font-medium text-white placeholder-stone-600 focus:outline-none focus:border-[#c9a227] bg-[#051e19]/60 focus:bg-[#051e19]"
                        />
                      </td>

                      {/* Schedule III Category Selector */}
                      <td className="py-2 px-3">
                        <div className="flex items-center space-x-1.5">
                          <select
                            value={row.category}
                            onChange={(e) => handleCategoryChange(row.id, e.target.value as ScheduleIIICategory)}
                            aria-label={`Schedule III Category for ${row.ledgerName || `row ${idx + 1}`}`}
                            className="w-full px-2 py-1.5 border border-white/10 rounded text-[11px] font-semibold text-stone-200 bg-[#051e19] focus:outline-none focus:border-[#c9a227] cursor-pointer"
                          >
                            <optgroup label="EQUITY & LIABILITIES (Balance Sheet)" className="bg-stone-900 text-white">
                              <option value={ScheduleIIICategory.SHARE_CAPITAL}>1. Share Capital (Note 1)</option>
                              <option value={ScheduleIIICategory.RESERVES_AND_SURPLUS}>2. Reserves and Surplus (Note 2)</option>
                              <option value={ScheduleIIICategory.LONG_TERM_BORROWINGS}>3. Long-Term Borrowings (Note 3)</option>
                              <option value={ScheduleIIICategory.DEFERRED_TAX_LIABILITY_NET}>4. Deferred Tax Liability Net</option>
                              <option value={ScheduleIIICategory.OTHER_LONG_TERM_LIABILITIES}>5. Other Long-Term Liabilities</option>
                              <option value={ScheduleIIICategory.SHORT_TERM_BORROWINGS}>6. Short-Term Borrowings</option>
                              <option value={ScheduleIIICategory.TRADE_PAYABLES}>7. Trade Payables (Note 4)</option>
                              <option value={ScheduleIIICategory.OTHER_CURRENT_LIABILITIES}>8. Other Current Liabilities (Note 5)</option>
                              <option value={ScheduleIIICategory.SHORT_TERM_PROVISIONS}>9. Short-Term Provisions</option>
                            </optgroup>

                            <optgroup label="ASSETS (Balance Sheet)" className="bg-stone-900 text-white">
                              <option value={ScheduleIIICategory.TANGIBLE_ASSETS}>10. Property, Plant & Equipment (Note 6)</option>
                              <option value={ScheduleIIICategory.INTANGIBLE_ASSETS}>11. Intangible Assets</option>
                              <option value={ScheduleIIICategory.NON_CURRENT_INVESTMENTS}>12. Non-Current Investments</option>
                              <option value={ScheduleIIICategory.DEFERRED_TAX_ASSETS_NET}>13. Deferred Tax Assets Net (Note 7)</option>
                              <option value={ScheduleIIICategory.LONG_TERM_LOANS_AND_ADVANCES}>14. Long-Term Loans & Advances</option>
                              <option value={ScheduleIIICategory.OTHER_NON_CURRENT_ASSETS}>15. Other Non-Current Assets</option>
                              <option value={ScheduleIIICategory.CURRENT_INVESTMENTS}>16. Current Investments</option>
                              <option value={ScheduleIIICategory.INVENTORIES}>17. Inventories (Note 8)</option>
                              <option value={ScheduleIIICategory.TRADE_RECEIVABLES}>18. Trade Receivables (Note 9)</option>
                              <option value={ScheduleIIICategory.CASH_AND_BANK_BALANCES}>19. Cash and Cash Equivalents (Note 10)</option>
                              <option value={ScheduleIIICategory.SHORT_TERM_LOANS_AND_ADVANCES}>20. Short-Term Loans & Advances (Note 11)</option>
                              <option value={ScheduleIIICategory.OTHER_CURRENT_ASSETS}>21. Other Current Assets (Note 12)</option>
                            </optgroup>

                            <optgroup label="STATEMENT OF PROFIT & LOSS" className="bg-stone-900 text-white">
                              <option value={ScheduleIIICategory.REVENUE_FROM_OPERATIONS}>22. Revenue From Operations (Note 10)</option>
                              <option value={ScheduleIIICategory.OTHER_INCOME}>23. Other Income (Note 11)</option>
                              <option value={ScheduleIIICategory.COST_OF_TRADED_GOODS}>24. Purchase of Traded Goods (Note 12)</option>
                              <option value={ScheduleIIICategory.DIRECT_COST}>25. Direct Cost / Production (Note 13)</option>
                              <option value={ScheduleIIICategory.ADMINISTRATION_AND_OTHER_EXPENSES}>26. Administration & Other Expenses (Note 14)</option>
                              <option value={ScheduleIIICategory.FINANCE_COSTS}>27. Finance Costs (Note 15)</option>
                              <option value={ScheduleIIICategory.DEPRECIATION_AND_AMORTISATION}>28. Depreciation & Amortisation (Note 8)</option>
                              <option value={ScheduleIIICategory.TAX_EXPENSE_CURRENT}>29. Current Tax Expense</option>
                              <option value={ScheduleIIICategory.TAX_EXPENSE_DEFERRED}>30. Deferred Tax Expense</option>
                              <option value={ScheduleIIICategory.PRIOR_PERIOD_EXPENSES}>31. Prior Period Expenses</option>
                            </optgroup>
                          </select>

                          {/* AI classify button */}
                          <button
                            type="button"
                            onClick={() => handleAIClassifyLedger(row)}
                            disabled={isAIClassifying || !row.ledgerName}
                            title="Classify using AI"
                            className="p-1.5 rounded bg-[#c9a227]/20 hover:bg-[#c9a227]/40 text-[#f7e089] border border-[#c9a227]/40 transition cursor-pointer disabled:opacity-30"
                          >
                            <Sparkles className={`w-3.5 h-3.5 ${isAIClassifying ? 'animate-spin' : ''}`} />
                          </button>
                        </div>
                      </td>

                      {/* Note Number Reference */}
                      <td className="py-2 px-3 text-center">
                        <span className="font-mono text-[11px] px-1.5 py-0.5 rounded bg-[#125246] text-[#f7e089] font-bold border border-[#c9a227]/30">
                          {catDef?.defaultNoteNumber ? `N-${catDef.defaultNoteNumber}` : '—'}
                        </span>
                      </td>

                      {/* Actions */}
                      <td className="py-2 px-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleDeleteRow(row.id)}
                          title="Delete row"
                          className="p-1 text-stone-400 hover:text-rose-400 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer with Add Row */}
        <div className="p-3 bg-[#051e19] border-t border-white/10 flex items-center justify-between">
          <button
            type="button"
            onClick={handleAddRow}
            className="px-3 py-1.5 bg-[#125246] hover:bg-[#196b5c] text-[#f7e089] border border-[#c9a227]/40 rounded-lg text-xs font-bold flex items-center space-x-1 shadow-sm transition cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5 text-[#c9a227]" />
            <span>Add Ledger Row</span>
          </button>

          <span className="text-stone-400 text-xs font-medium">
            Total {activeRows.length} ledgers in {activeYearTab === 'CY' ? 'Current Year' : 'Previous Year'}
          </span>
        </div>
      </div>

      {/* Bulk Paste Modal */}
      {pasteModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
          <div className="bg-[#0b3d33] border border-[#c9a227]/40 rounded-xl max-w-2xl w-full p-6 shadow-2xl space-y-4 text-white">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center space-x-2">
                <FileSpreadsheet className="w-5 h-5 text-[#c9a227]" />
                <h3 className="font-display text-base font-bold text-white">Bulk Paste from Excel / Tally</h3>
              </div>
              <button onClick={() => setPasteModalOpen(false)} className="text-stone-400 hover:text-white cursor-pointer">
                ✕
              </button>
            </div>

            <p className="text-xs text-stone-300">
              Copy columns from Excel or Tally (Columns: <code className="bg-[#082e27] text-[#f7e089] px-1.5 py-0.5 rounded border border-white/10">Ledger Name</code>,{' '}
              <code className="bg-[#082e27] text-[#f7e089] px-1.5 py-0.5 rounded border border-white/10">Debit</code>, <code className="bg-[#082e27] text-[#f7e089] px-1.5 py-0.5 rounded border border-white/10">Credit</code>)
              and paste below. The system will automatically classify each ledger to Schedule III heads.
            </p>

            <textarea
              rows={8}
              value={pastedRawText}
              onChange={(e) => setPastedRawText(e.target.value)}
              placeholder="Capital Account&#9;0&#9;100000&#10;Sundry Debtors&#9;54000&#9;0&#10;Rent Expenses&#9;120000&#9;0"
              className="w-full font-mono text-xs p-3 bg-[#082e27] border border-white/10 rounded-lg text-stone-100 placeholder-stone-600 focus:border-[#c9a227] focus:outline-none"
            />

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setPasteModalOpen(false)}
                className="px-4 py-2 border border-white/20 rounded-lg text-xs font-semibold text-stone-300 hover:bg-white/10 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleProcessBulkPaste}
                className="px-5 py-2 bg-[#c9a227] text-[#082e27] rounded-lg text-xs font-bold hover:bg-[#d8b030] shadow cursor-pointer"
              >
                Import & Auto-Classify
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
