import React, { useState } from 'react';
import {
  AlertCircle,
  Award,
  CheckCircle2,
  Download,
  Eye,
  FileCheck,
  FileSpreadsheet,
  FileText,
  Layers,
  Printer,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  Users
} from 'lucide-react';
import { FinancialStatementsFull } from '../types';
import {
  generateAOC4Docx,
  generateAuditorsReportDocx,
  generateDirectorsReportDocx,
  generateMGT7Docx,
  generateScheduleIIIDocx
} from '../services/docxGenerator';

interface DocumentPackGeneratorProps {
  data: FinancialStatementsFull;
}

export const DocumentPackGenerator: React.FC<DocumentPackGeneratorProps> = ({ data }) => {
  const [selectedDoc, setSelectedDoc] = useState<string>('SCHEDULE_III');
  const [isGenerating, setIsGenerating] = useState<string | null>(null);

  const { company, balanceSheet, profitAndLoss, notes } = data;

  const downloadFile = async (docType: string, filename: string, generator: () => Promise<Blob>) => {
    setIsGenerating(docType);
    try {
      const blob = await generator();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error generating document:', err);
      alert('Failed to generate document. Please try again.');
    } finally {
      setIsGenerating(null);
    }
  };

  const handleDownloadAll = async () => {
    setIsGenerating('ALL');
    try {
      await downloadFile('SCHEDULE_III', `${company.name.replace(/\s+/g, '_')}_Schedule_III_FY2023-24.docx`, () => generateScheduleIIIDocx(data));
      await new Promise(r => setTimeout(r, 600));
      await downloadFile('AOC_4', `${company.name.replace(/\s+/g, '_')}_Form_AOC-4_Draft.docx`, () => generateAOC4Docx(data));
      await new Promise(r => setTimeout(r, 600));
      await downloadFile('MGT_7', `${company.name.replace(/\s+/g, '_')}_Form_MGT-7_Draft.docx`, () => generateMGT7Docx(data));
      await new Promise(r => setTimeout(r, 600));
      await downloadFile('AUDITOR', `${company.name.replace(/\s+/g, '_')}_Auditors_Report.docx`, () => generateAuditorsReportDocx(data));
      await new Promise(r => setTimeout(r, 600));
      await downloadFile('DIRECTOR', `${company.name.replace(/\s+/g, '_')}_Directors_Report.docx`, () => generateDirectorsReportDocx(data));
    } finally {
      setIsGenerating(null);
    }
  };

  const documentsList = [
    {
      id: 'SCHEDULE_III',
      title: 'Schedule III Financial Statements',
      subtitle: 'Balance Sheet, Statement of Profit & Loss, Notes 1-16 & Signatures',
      icon: FileSpreadsheet,
      badge: 'Primary Statutory File',
      actionLabel: 'Download Word (.docx)',
      generator: () => generateScheduleIIIDocx(data),
      filename: `${company.name.replace(/\s+/g, '_')}_Schedule_III_FY2023-24.docx`
    },
    {
      id: 'AOC_4',
      title: 'Form AOC-4 Statutory Draft',
      subtitle: 'MCA V3 Financial Statement Filing Draft with DRAFT watermark',
      icon: FileCheck,
      badge: 'MCA V3 Ready',
      isDraft: true,
      actionLabel: 'Download AOC-4 (.docx)',
      generator: () => generateAOC4Docx(data),
      filename: `${company.name.replace(/\s+/g, '_')}_Form_AOC-4_Draft.docx`
    },
    {
      id: 'MGT_7',
      title: 'Form MGT-7 / MGT-9 Annual Return Extract',
      subtitle: 'Section 92 Annual Return with Shareholding, Meetings & Indebtedness',
      icon: FileText,
      badge: 'Section 92 Draft',
      isDraft: true,
      actionLabel: 'Download MGT-7 (.docx)',
      generator: () => generateMGT7Docx(data),
      filename: `${company.name.replace(/\s+/g, '_')}_Form_MGT-7_Draft.docx`
    },
    {
      id: 'AUDITOR_REPORT',
      title: "Independent Statutory Auditor's Report",
      subtitle: 'SA 700 / Section 143(3), CARO 2020 & Rule 11(g) Audit Trail Report',
      icon: Award,
      badge: 'UDIN Required',
      actionLabel: "Download Auditor's Report",
      generator: () => generateAuditorsReportDocx(data),
      filename: `${company.name.replace(/\s+/g, '_')}_Auditors_Report.docx`
    },
    {
      id: 'DIRECTORS_REPORT',
      title: "Board of Directors' Report",
      subtitle: "Section 134(5) Responsibility Statement, AOC-2, POSH & MGT-9 Extract",
      icon: Users,
      badge: 'Board Certified',
      actionLabel: "Download Directors' Report",
      generator: () => generateDirectorsReportDocx(data),
      filename: `${company.name.replace(/\s+/g, '_')}_Directors_Report.docx`
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header Overview Card */}
      <div className="bg-[#0b3d33]/60 backdrop-blur rounded-xl p-6 text-white shadow-lg border border-[#c9a227]/40 relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-display text-xl font-bold tracking-wide text-white">
                Statutory Document Generation Suite
              </span>
              <span className="bg-[#c9a227]/20 text-[#f7e089] border border-[#c9a227]/50 text-xs px-2.5 py-0.5 rounded-full font-semibold">
                MCA V3 & ICAI
              </span>
            </div>
            <p className="text-xs text-stone-300 mt-1 max-w-2xl">
              Export professionally formatted Microsoft Word (.docx) documents complete with comparative two-column tables,
              Schedule III Notes 1 to 16, and legal MCA disclosures for <strong className="text-[#f7e089]">{company.name}</strong>.
            </p>
          </div>

          <button
            onClick={handleDownloadAll}
            disabled={isGenerating !== null}
            className="px-5 py-2.5 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] font-bold text-xs rounded-lg shadow-md flex items-center space-x-2 cursor-pointer disabled:opacity-50 transition"
          >
            <Layers className="w-4 h-4 text-[#082e27]" />
            <span>{isGenerating === 'ALL' ? 'Compiling All Files...' : 'Download Full CA Package (5 Files)'}</span>
          </button>
        </div>
      </div>

      {/* Mandatory Statutory Notice */}
      <div className="bg-amber-950/60 border border-amber-500/40 rounded-xl p-4 text-xs text-[#f7e089] flex items-start space-x-3 backdrop-blur">
        <ShieldAlert className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <p className="font-bold text-amber-300">Statutory Watermark & Filing Notice</p>
          <p className="text-stone-300">
            AOC-4 and MGT-7 documents generated here are labeled:
            <span className="font-semibold block my-1 p-1 bg-amber-900/60 rounded font-mono text-[11px] text-[#f7e089] border border-amber-700/50">
              "DRAFT — internal review copy, requires CA certification and re-entry on MCA V3 before statutory filing."
            </span>
            Please ensure digital signatures (DSC) and UDIN verification are affixed prior to portal upload.
          </p>
        </div>
      </div>

      {/* Grid of Documents */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {documentsList.map((doc) => {
          const Icon = doc.icon;
          const isCurrentLoading = isGenerating === doc.id;

          return (
            <div
              key={doc.id}
              className={`bg-[#082e27]/90 border rounded-xl p-5 shadow-xl transition flex flex-col justify-between ${
                selectedDoc === doc.id ? 'border-[#c9a227] ring-1 ring-[#c9a227]' : 'border-white/10 hover:border-white/20'
              }`}
            >
              <div>
                <div className="flex items-start justify-between mb-3">
                  <div className="w-10 h-10 rounded-lg bg-[#125246] flex items-center justify-center border border-white/10">
                    <Icon className="w-5 h-5 text-[#c9a227]" />
                  </div>
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                      doc.isDraft
                        ? 'bg-amber-950/70 text-[#f7e089] border border-amber-500/40'
                        : 'badge-green'
                    }`}
                  >
                    {doc.badge}
                  </span>
                </div>

                <h3 className="font-display text-sm font-bold text-white mb-1">{doc.title}</h3>
                <p className="text-xs text-stone-300 leading-relaxed">{doc.subtitle}</p>
              </div>

              <div className="mt-5 pt-4 border-t border-white/10 flex items-center space-x-2">
                <button
                  onClick={() => setSelectedDoc(doc.id)}
                  className="flex-1 px-3 py-1.5 bg-white/5 hover:bg-white/10 text-stone-200 text-xs font-semibold rounded-lg border border-white/10 transition flex items-center justify-center space-x-1 cursor-pointer"
                >
                  <Eye className="w-3.5 h-3.5 text-stone-300" />
                  <span>Preview</span>
                </button>

                <button
                  onClick={() => downloadFile(doc.id, doc.filename, doc.generator)}
                  disabled={isCurrentLoading}
                  className="flex-1 px-3 py-1.5 bg-[#c9a227] hover:bg-[#d8b030] text-[#082e27] text-xs font-bold rounded-lg shadow-xs transition flex items-center justify-center space-x-1 disabled:opacity-50 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-[#082e27]" />
                  <span>{isCurrentLoading ? 'Exporting...' : 'Export'}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Selected Document Interactive Previewer */}
      <div className="bg-[#082e27]/90 border border-white/10 rounded-xl p-6 shadow-xl">
        <div className="flex items-center justify-between border-b border-white/10 pb-4 mb-4">
          <div className="flex items-center space-x-2">
            <Eye className="w-5 h-5 text-[#c9a227]" />
            <h3 className="font-display text-base font-bold text-white">
              Live Document Content Preview — {documentsList.find((d) => d.id === selectedDoc)?.title}
            </h3>
          </div>
          <span className="text-xs text-stone-400 font-mono">Word (.docx) Structure</span>
        </div>

        {selectedDoc === 'SCHEDULE_III' && (
          <div className="space-y-4 text-xs text-stone-300 font-sans max-h-[500px] overflow-y-auto p-4 bg-[#051e19] rounded-lg border border-white/10">
            <div className="text-center font-display space-y-1 pb-4 border-b border-white/10">
              <h4 className="font-bold text-sm uppercase text-[#f7e089]">{company.name}</h4>
              <p className="text-stone-400">CIN: {company.cin}</p>
              <p className="font-semibold text-white">BALANCE SHEET & STATEMENT OF PROFIT AND LOSS</p>
              <p className="italic text-stone-400">For the financial year ended {company.asAtCurrentDate}</p>
            </div>

            <div className="space-y-2">
              <div className="font-bold text-stone-200 uppercase">Part I: Schedule III Balance Sheet Summary</div>
              <div className="grid grid-cols-2 gap-4 bg-[#082e27] p-3 rounded-lg border border-white/10">
                <div>
                  <span className="text-stone-400">Total Equity & Liabilities:</span>{' '}
                  <strong className="font-mono text-[#f7e089]">
                    ₹{(balanceSheet?.equityAndLiabilities?.totalEquityAndLiabilities?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </strong>
                </div>
                <div>
                  <span className="text-stone-400">Total Assets:</span>{' '}
                  <strong className="font-mono text-[#f7e089]">
                    ₹{(balanceSheet?.assets?.totalAssets?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </strong>
                </div>
              </div>

              <div className="font-bold text-stone-200 uppercase pt-2">Part II: Statement of Profit & Loss Summary</div>
              <div className="grid grid-cols-3 gap-2 bg-[#082e27] p-3 rounded-lg border border-white/10">
                <div>
                  <span className="text-stone-400">Total Revenue:</span>{' '}
                  <div className="font-mono font-bold text-white">₹{(profitAndLoss?.income?.totalRevenue?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div>
                  <span className="text-stone-400">Total Expenses:</span>{' '}
                  <div className="font-mono font-bold text-white">₹{(profitAndLoss?.expenses?.totalExpenses?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div>
                  <span className="text-stone-400">Profit After Tax (PAT):</span>{' '}
                  <div className="font-mono font-bold text-[#34d399]">
                    ₹{(profitAndLoss?.profitAfterTax?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>

              <div className="font-bold text-stone-200 uppercase pt-2">Part III: Notes to Accounts (Notes 1 to 16)</div>
              <p className="text-stone-400">
                Includes Note 1 (Share capital reconciliation & 5%+ shareholding), Note 6 (Fixed Assets schedule), Note 14 (Administration expenses with 14.1 Audit fee ₹10,000), Note 15 (Accounting policies), and Note 16 (Statutory disclosures).
              </p>
            </div>
          </div>
        )}

        {selectedDoc === 'AOC_4' && (
          <div className="space-y-4 text-xs text-stone-300 font-sans max-h-[500px] overflow-y-auto p-4 bg-[#051e19] rounded-lg border border-white/10">
            <div className="bg-amber-950/70 border border-amber-500/40 p-2.5 rounded text-[#f7e089] font-bold text-center">
              DRAFT — internal review copy, requires CA certification and re-entry on MCA V3 before statutory filing.
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-sm text-[#f7e089]">FORM AOC-4 (MCA V3 e-Form Summary)</h4>
              <p><strong className="text-white">CIN:</strong> {company.cin}</p>
              <p><strong className="text-white">Name of Company:</strong> {company.name}</p>
              <p><strong className="text-white">Financial Year Reported:</strong> {company.financialYearCurrent}</p>
              <p><strong className="text-white">Date of AGM:</strong> {company.signatories.agmDate}</p>
              <p><strong className="text-white">Rule 3(1) Accounting Software Audit Trail:</strong> Complied throughout FY without disabling/tampering.</p>
              <p><strong className="text-white">Auditor FRN / Member No:</strong> {company.signatories.auditorFirmRegNo} / {company.signatories.auditorMembershipNo}</p>
              <p><strong className="text-white">UDIN:</strong> {company.signatories.auditorUDIN}</p>
            </div>
          </div>
        )}

        {selectedDoc === 'MGT_7' && (
          <div className="space-y-4 text-xs text-stone-300 font-sans max-h-[500px] overflow-y-auto p-4 bg-[#051e19] rounded-lg border border-white/10">
            <div className="bg-amber-950/70 border border-amber-500/40 p-2.5 rounded text-[#f7e089] font-bold text-center">
              DRAFT — internal review copy, requires CA certification and re-entry on MCA V3 before statutory filing.
            </div>
            <div className="space-y-2">
              <h4 className="font-bold text-sm text-[#f7e089]">FORM MGT-7 / EXTRACT OF ANNUAL RETURN (Section 92(3))</h4>
              <p><strong className="text-white">Paid-up Capital:</strong> ₹{(company.issuedShareValue || 100000).toLocaleString('en-IN')} (10,000 Equity Shares of ₹10/- each)</p>
              <p><strong className="text-white">Promoter Shareholding:</strong> 100% ({company.signatories.director1Name || 'Director 1'} 50%, {company.signatories.director2Name || 'Director 2'} 50%)</p>
              <p><strong className="text-white">Total Indebtedness (Secured + Unsecured):</strong> ₹{(balanceSheet?.equityAndLiabilities?.nonCurrentLiabilities?.longTermBorrowings?.cy ?? 0).toLocaleString('en-IN')}</p>
              <p><strong className="text-white">Board Meetings Held:</strong> 4 Meetings during FY 2023-24</p>
            </div>
          </div>
        )}

        {selectedDoc === 'AUDITOR_REPORT' && (
          <div className="space-y-4 text-xs text-stone-300 font-sans max-h-[500px] overflow-y-auto p-4 bg-[#051e19] rounded-lg border border-white/10">
            <div className="text-center font-display space-y-1 pb-3 border-b border-white/10">
              <h4 className="font-bold text-sm text-[#f7e089]">INDEPENDENT AUDITOR'S REPORT</h4>
              <p className="text-stone-400">To the Members of {company.name}</p>
            </div>
            <p><strong className="text-white">Opinion:</strong> We have audited the accompanying Schedule III financial statements of {company.name}, which comprise the Balance Sheet as at 31st March 2024, and the Statement of Profit and Loss for the year then ended.</p>
            <p><strong className="text-white">Basis for Opinion:</strong> Conducted in accordance with Standards on Auditing (SAs) specified under Section 143(10) of the Act.</p>
            <p><strong className="text-white">CARO 2020:</strong> Private company threshold exemption evaluated; clean reporting.</p>
            <p><strong className="text-white">Rule 11(g) Audit Trail:</strong> Accounting software maintained an edit log throughout the financial year without tampering.</p>
          </div>
        )}

        {selectedDoc === 'DIRECTORS_REPORT' && (
          <div className="space-y-4 text-xs text-stone-300 font-sans max-h-[500px] overflow-y-auto p-4 bg-[#051e19] rounded-lg border border-white/10">
            <div className="text-center font-display space-y-1 pb-3 border-b border-white/10">
              <h4 className="font-bold text-sm text-[#f7e089]">BOARD OF DIRECTORS' REPORT</h4>
              <p className="text-stone-400">Pursuant to Section 134(3) of the Companies Act, 2013</p>
            </div>
            <p><strong className="text-white">1. Financial Highlights:</strong> Total Revenue ₹{(profitAndLoss?.income?.totalRevenue?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}, Net Profit ₹{(profitAndLoss?.profitAfterTax?.cy ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}.</p>
            <p><strong className="text-white">2. State of Company Affairs:</strong> Operations in retail trade progressed steadily.</p>
            <p><strong className="text-white">3. Section 134(5) Directors' Responsibility Statement:</strong> Affirmations regarding accounting standards, prudent policies, adequate internal financial controls, and going concern.</p>
            <p><strong className="text-white">4. POSH Act 2013:</strong> No complaints received during the year.</p>
          </div>
        )}
      </div>
    </div>
  );
};
