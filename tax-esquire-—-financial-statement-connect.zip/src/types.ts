export enum ScheduleIIICategory {
  // Equity and Liabilities - Shareholders' Funds
  SHARE_CAPITAL = 'SHARE_CAPITAL',
  RESERVES_AND_SURPLUS = 'RESERVES_AND_SURPLUS',
  MONEY_RECEIVED_AGAINST_SHARE_WARRANTS = 'MONEY_RECEIVED_AGAINST_SHARE_WARRANTS',
  // Non-Current Liabilities
  LONG_TERM_BORROWINGS = 'LONG_TERM_BORROWINGS',
  DEFERRED_TAX_LIABILITY_NET = 'DEFERRED_TAX_LIABILITY_NET',
  OTHER_LONG_TERM_LIABILITIES = 'OTHER_LONG_TERM_LIABILITIES',
  LONG_TERM_PROVISIONS = 'LONG_TERM_PROVISIONS',
  // Current Liabilities
  SHORT_TERM_BORROWINGS = 'SHORT_TERM_BORROWINGS',
  TRADE_PAYABLES = 'TRADE_PAYABLES',
  OTHER_CURRENT_LIABILITIES = 'OTHER_CURRENT_LIABILITIES',
  SHORT_TERM_PROVISIONS = 'SHORT_TERM_PROVISIONS',
  // Assets - Non-Current Assets
  TANGIBLE_ASSETS = 'TANGIBLE_ASSETS',
  INTANGIBLE_ASSETS = 'INTANGIBLE_ASSETS',
  CAPITAL_WORK_IN_PROGRESS = 'CAPITAL_WORK_IN_PROGRESS',
  INTANGIBLE_ASSETS_UNDER_DEV = 'INTANGIBLE_ASSETS_UNDER_DEV',
  NON_CURRENT_INVESTMENTS = 'NON_CURRENT_INVESTMENTS',
  DEFERRED_TAX_ASSETS_NET = 'DEFERRED_TAX_ASSETS_NET',
  LONG_TERM_LOANS_AND_ADVANCES = 'LONG_TERM_LOANS_AND_ADVANCES',
  OTHER_NON_CURRENT_ASSETS = 'OTHER_NON_CURRENT_ASSETS',
  // Assets - Current Assets
  CURRENT_INVESTMENTS = 'CURRENT_INVESTMENTS',
  INVENTORIES = 'INVENTORIES',
  TRADE_RECEIVABLES = 'TRADE_RECEIVABLES',
  CASH_AND_BANK_BALANCES = 'CASH_AND_BANK_BALANCES',
  SHORT_TERM_LOANS_AND_ADVANCES = 'SHORT_TERM_LOANS_AND_ADVANCES',
  OTHER_CURRENT_ASSETS = 'OTHER_CURRENT_ASSETS',
  // Profit & Loss - Revenue
  REVENUE_FROM_OPERATIONS = 'REVENUE_FROM_OPERATIONS',
  OTHER_INCOME = 'OTHER_INCOME',
  // Profit & Loss - Expenses
  COST_OF_TRADED_GOODS = 'COST_OF_TRADED_GOODS',
  DIRECT_COST = 'DIRECT_COST',
  ADMINISTRATION_AND_OTHER_EXPENSES = 'ADMINISTRATION_AND_OTHER_EXPENSES',
  FINANCE_COSTS = 'FINANCE_COSTS',
  DEPRECIATION_AND_AMORTISATION = 'DEPRECIATION_AND_AMORTISATION',
  TAX_EXPENSE_CURRENT = 'TAX_EXPENSE_CURRENT',
  TAX_EXPENSE_DEFERRED = 'TAX_EXPENSE_DEFERRED',
  PRIOR_PERIOD_EXPENSES = 'PRIOR_PERIOD_EXPENSES'
}

export type ScheduleIIICategoryType = ScheduleIIICategory | `${ScheduleIIICategory}`;

export interface CategoryMetadata {
  id: ScheduleIIICategoryType;
  label: string;
  statement: 'BALANCE_SHEET' | 'PROFIT_AND_LOSS';
  section:
    | 'SHAREHOLDERS_FUNDS'
    | 'NON_CURRENT_LIABILITIES'
    | 'CURRENT_LIABILITIES'
    | 'NON_CURRENT_ASSETS'
    | 'CURRENT_ASSETS'
    | 'REVENUE'
    | 'EXPENSES'
    | 'TAX';
  defaultNoteNumber?: number;
  normalBalance: 'DEBIT' | 'CREDIT';
  keywords: string[];
}

export interface TrialBalanceRow {
  id: string;
  ledgerName: string;
  debit: number;
  credit: number;
  category: ScheduleIIICategoryType;
  suggestedCategory?: ScheduleIIICategoryType;
  noteNumber?: number;
  isOverridden?: boolean;
  notes?: string;
}

export interface ShareholderDetail {
  id: string;
  name: string;
  address: string;
  status: string; // Individual / Body Corporate
  occupation: string;
  nationality: string;
  dateBecomingMember: string;
  classOfShare: string;
  sharesHeldCY: number;
  sharesHeldPY: number;
  faceValue: number;
  holdingPercentageCY: number;
  holdingPercentagePY: number;
}

export interface FixedAssetRow {
  id: string;
  particulars: string;
  rate: number; // e.g. 63.16%
  method: 'WDV' | 'SLM';
  openingWDV: number;
  additions: number;
  deletions: number;
  totalCost: number;
  depreciationForYear: number;
  closingWDV: number;
  pyClosingWDV: number;
}

export interface CompanySignatories {
  director1Name: string;
  director1DIN: string;
  director1Designation: string;
  director2Name: string;
  director2DIN: string;
  director2Designation: string;
  auditorFirmName: string;
  auditorFirmRegNo: string;
  auditorPartnerName: string;
  auditorDesignation: string; // e.g. "Proprietor" / "Partner"
  auditorMembershipNo: string;
  auditorUDIN: string;
  auditorAddress: string;
  auditorEmail: string;
  auditorPhone: string;
  placeOfSigning: string;
  dateOfSigning: string;
  agmDate: string;
  boardMeetingDate: string;
}

export interface CompanyProfile {
  id: string;
  name: string;
  cin: string;
  registeredOffice: string;
  incorporationDate: string;
  financialYearCurrent: string; // e.g. "2023-24"
  asAtCurrentDate: string; // e.g. "31st March 2024"
  asAtPreviousDate: string; // e.g. "31st March 2023"
  currentYearLabel: string; // e.g. "31st March 2024"
  previousYearLabel: string; // e.g. "31st March 2023"
  authorisedShares: number;
  authorisedShareValue: number;
  issuedShares: number;
  issuedShareValue: number;
  faceValuePerShare: number;
  principalBusinessActivity: string;
  nicCode: string;
  turnoverPercentage: number;
  signatories: CompanySignatories;
}

export interface BalanceSheetData {
  equityAndLiabilities: {
    shareholdersFunds: {
      shareCapital: { cy: number; py: number; note: number };
      reservesAndSurplus: { cy: number; py: number; note: number };
      total: { cy: number; py: number };
    };
    nonCurrentLiabilities: {
      longTermBorrowings: { cy: number; py: number; note: number };
      deferredTaxLiabilityNet: { cy: number; py: number; note?: number };
      otherLongTermLiabilities: { cy: number; py: number; note?: number };
      longTermProvisions: { cy: number; py: number; note?: number };
      total: { cy: number; py: number };
    };
    currentLiabilities: {
      shortTermBorrowings: { cy: number; py: number; note?: number };
      tradePayables: { cy: number; py: number; note: number };
      otherCurrentLiabilities: { cy: number; py: number; note: number };
      shortTermProvisions: { cy: number; py: number; note?: number };
      total: { cy: number; py: number };
    };
    totalEquityAndLiabilities: { cy: number; py: number };
  };
  assets: {
    nonCurrentAssets: {
      fixedAssetsTangible: { cy: number; py: number; note: number };
      fixedAssetsIntangible: { cy: number; py: number; note?: number };
      capitalWorkInProgress: { cy: number; py: number; note?: number };
      nonCurrentInvestments: { cy: number; py: number; note?: number };
      deferredTaxAssetsNet: { cy: number; py: number; note?: number };
      longTermLoansAndAdvances: { cy: number; py: number; note?: number };
      otherNonCurrentAssets: { cy: number; py: number; note?: number };
      total: { cy: number; py: number };
    };
    currentAssets: {
      currentInvestments: { cy: number; py: number; note?: number };
      inventories: { cy: number; py: number; note: number };
      tradeReceivables: { cy: number; py: number; note?: number };
      cashAndBankBalances: { cy: number; py: number; note: number };
      shortTermLoansAndAdvances: { cy: number; py: number; note?: number };
      otherCurrentAssets: { cy: number; py: number; note: number };
      total: { cy: number; py: number };
    };
    totalAssets: { cy: number; py: number };
  };
  isTalliedCY: boolean;
  differenceCY: number;
  isTalliedPY: boolean;
  differencePY: number;
}

export interface ProfitAndLossData {
  income: {
    revenueFromOperations: { cy: number; py: number; note: number };
    otherIncome: { cy: number; py: number; note: number };
    totalRevenue: { cy: number; py: number };
  };
  expenses: {
    costOfTradedGoods: { cy: number; py: number; note: number };
    directCost: { cy: number; py: number; note: number };
    adminAndOtherExpenses: { cy: number; py: number; note: number };
    financeCosts: { cy: number; py: number; note: number };
    depreciationAndAmortisation: { cy: number; py: number; note: number };
    totalExpenses: { cy: number; py: number };
  };
  profitBeforeTax: { cy: number; py: number };
  priorPeriodExpenses: { cy: number; py: number };
  profitBeforeTaxNet: { cy: number; py: number };
  taxExpense: {
    currentTax: { cy: number; py: number };
    deferredTax: { cy: number; py: number };
    matCredit: { cy: number; py: number };
    totalTax: { cy: number; py: number };
  };
  profitAfterTax: { cy: number; py: number };
  eps: {
    basic: { cy: number; py: number };
    diluted: { cy: number; py: number };
    weightedAverageSharesCY: number;
    weightedAverageSharesPY: number;
  };
}

export interface NotesToAccountsBreakdown {
  note1_Policies: {
    companyName: string;
    incorporationDate: string;
    depreciationMethod: string;
    inventoryMethod: string;
    auditorFeesCY: number;
    auditorFeesPY: number;
  };
  note2_ShareCapital: {
    authorised: { shares: number; value: number };
    issued: { shares: number; value: number };
    subscribedPaidUp: { shares: number; value: number };
    reconciliationCY: { opening: number; issued: number; buyback: number; closing: number };
    reconciliationPY: { opening: number; issued: number; buyback: number; closing: number };
    shareholders: ShareholderDetail[];
  };
  note3_ReservesSurplus: {
    openingBalance: number;
    currentYearProfit: number;
    closingBalance: number;
    pyOpeningBalance: number;
    pyCurrentYearProfit: number;
    pyClosingBalance: number;
  };
  note4_LongTermBorrowings: {
    unsecuredLoanFromDirectorsCY: number;
    unsecuredLoanFromDirectorsPY: number;
    securedLoansCY: number;
    securedLoansPY: number;
    otherBorrowingsCY: number;
    otherBorrowingsPY: number;
  };
  note5_TradePayables: {
    dueToMSMECY: number;
    dueToMSMEPY: number;
    dueToOthersCY: number;
    dueToOthersPY: number;
    dueToGroupCompaniesCY: number;
    dueToGroupCompaniesPY: number;
  };
  note6_OtherCurrentLiabilities: {
    items: { label: string; cy: number; py: number }[];
    totalCY: number;
    totalPY: number;
  };
  note7_CashAndBank: {
    currentAccountsCY: number;
    currentAccountsPY: number;
    cashInHandCY: number;
    cashInHandPY: number;
    totalCY: number;
    totalPY: number;
  };
  note8_FixedAssets: {
    assets: FixedAssetRow[];
    totalCYDepreciation: number;
    totalCYClosingWDV: number;
    totalPYDepreciation: number;
    totalPYClosingWDV: number;
  };
  note9_OtherCurrentAssets: {
    items: { label: string; cy: number; py: number }[];
    totalCY: number;
    totalPY: number;
  };
  note10_RevenueFromOperations: {
    taxInvoiceCY: number;
    taxInvoicePY: number;
    servicesCY: number;
    servicesPY: number;
    totalCY: number;
    totalPY: number;
  };
  note11_OtherIncome: {
    items: { label: string; cy: number; py: number }[];
    totalCY: number;
    totalPY: number;
  };
  note12_CostOfTradedGoods: {
    openingStockCY: number;
    openingStockPY: number;
    purchasesCY: number;
    purchasesPY: number;
    closingStockCY: number;
    closingStockPY: number;
    totalCY: number;
    totalPY: number;
  };
  note13_DirectCosts: {
    items: { label: string; cy: number; py: number }[];
    totalCY: number;
    totalPY: number;
  };
  note14_AdminExpenses: {
    items: { label: string; cy: number; py: number }[];
    statutoryAuditFeeCY: number;
    statutoryAuditFeePY: number;
    totalCY: number;
    totalPY: number;
  };
  note15_FinanceCosts: {
    bankChargesCY: number;
    bankChargesPY: number;
    interestCY: number;
    interestPY: number;
    totalCY: number;
    totalPY: number;
  };
  deferredTaxCalculation: {
    companyActDepreciation: number;
    itActDepreciation: number;
    timingDifference: number;
    taxRatePercentage: number;
    currentYearDeferredTaxAsset: number;
    openingDeferredTaxAsset: number;
    transferToProfitLoss: number;
  };
}

export interface FinancialStatementsFull {
  company: CompanyProfile;
  trialBalanceCY: TrialBalanceRow[];
  trialBalancePY: TrialBalanceRow[];
  balanceSheet: BalanceSheetData;
  profitAndLoss: ProfitAndLossData;
  notes: NotesToAccountsBreakdown;
  lastCalculatedAt: string;
}

export interface UserSession {
  email: string;
  name: string;
  firmName: string;
  frn: string;
  membershipNo: string;
  role: 'CA_PRINCIPAL' | 'SENIOR_AUDITOR' | 'ARTICLE_ASSISTANT';
  token: string;
}

export interface MCARefreshTopic {
  id: string;
  title: string;
  formType: 'SCHEDULE_III' | 'AOC_4' | 'MGT_7' | 'CARO_2020' | 'DIRECTORS_REPORT' | 'AUDIT_RULES_11';
  summary: string;
}

export interface MCARefreshResult {
  topicId: string;
  topicTitle: string;
  timestamp: string;
  summaryOfAmendments: string;
  applicabilityChecklist: string[];
  mandatoryDisclosures: string[];
  mcaNotifications: { circularNo: string; subject: string; effectiveDate: string }[];
  verificationDisclaimer: string;
}

export interface AIMcaCheckResult {
  topicTitle: string;
  timestamp: string;
  analysis: string;
  disclaimer: string;
}
