import { CategoryMetadata, ScheduleIIICategory, ScheduleIIICategoryType } from '../types';

export const SCHEDULE_III_CATEGORIES: CategoryMetadata[] = [
  // --- Equity and Liabilities ---
  {
    id: 'SHARE_CAPITAL',
    label: 'Shareholders\' Funds: Share Capital',
    statement: 'BALANCE_SHEET',
    section: 'SHAREHOLDERS_FUNDS',
    defaultNoteNumber: 2,
    normalBalance: 'CREDIT',
    keywords: ['share capital', 'equity share', 'preference share', 'subscribed capital', 'paid up capital', 'authorised capital']
  },
  {
    id: 'RESERVES_AND_SURPLUS',
    label: 'Shareholders\' Funds: Reserves and Surplus',
    statement: 'BALANCE_SHEET',
    section: 'SHAREHOLDERS_FUNDS',
    defaultNoteNumber: 3,
    normalBalance: 'CREDIT',
    keywords: ['reserves', 'surplus', 'profit and loss', 'p&l', 'retained earnings', 'general reserve', 'securities premium', 'capital reserve']
  },
  {
    id: 'LONG_TERM_BORROWINGS',
    label: 'Non-Current Liabilities: Long-Term Borrowings',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_LIABILITIES',
    defaultNoteNumber: 4,
    normalBalance: 'CREDIT',
    keywords: ['loan from director', 'term loan', 'unsecured loan', 'secured loan', 'long term borrowing', 'debentures', 'bank loan long term', 'directors loan', 'borrowing']
  },
  {
    id: 'DEFERRED_TAX_LIABILITY_NET',
    label: 'Non-Current Liabilities: Deferred Tax Liability (Net)',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_LIABILITIES',
    normalBalance: 'CREDIT',
    keywords: ['deferred tax liability', 'dtl']
  },
  {
    id: 'OTHER_LONG_TERM_LIABILITIES',
    label: 'Non-Current Liabilities: Other Long-Term Liabilities',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_LIABILITIES',
    normalBalance: 'CREDIT',
    keywords: ['long term security deposit', 'retention money payable', 'other non current liability']
  },
  {
    id: 'LONG_TERM_PROVISIONS',
    label: 'Non-Current Liabilities: Long-Term Provisions',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_LIABILITIES',
    normalBalance: 'CREDIT',
    keywords: ['provision for gratuity', 'provision for leave encashment', 'long term provision']
  },
  {
    id: 'SHORT_TERM_BORROWINGS',
    label: 'Current Liabilities: Short-Term Borrowings',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_LIABILITIES',
    normalBalance: 'CREDIT',
    keywords: ['cash credit', 'overdraft', 'od account', 'short term loan', 'working capital loan']
  },
  {
    id: 'TRADE_PAYABLES',
    label: 'Current Liabilities: Trade Payables',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_LIABILITIES',
    defaultNoteNumber: 5,
    normalBalance: 'CREDIT',
    keywords: ['sundry creditor', 'sundry creditors', 'trade payable', 'trade payables', 'due to micro', 'due to others', 'vendor balance', 'creditors for goods']
  },
  {
    id: 'OTHER_CURRENT_LIABILITIES',
    label: 'Current Liabilities: Other Current Liabilities',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_LIABILITIES',
    defaultNoteNumber: 6,
    normalBalance: 'CREDIT',
    keywords: [
      'audit fee payable', 'audit fees payable', 'tds payable', 'gst payable', 'salary payable',
      'rent payable', 'expenses payable', 'outstanding expenses', 'advance from customers',
      'razorpay balance', 'rozarpay', 'stale cheque', 'other liability', 'duties & taxes'
    ]
  },
  {
    id: 'SHORT_TERM_PROVISIONS',
    label: 'Current Liabilities: Short-Term Provisions',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_LIABILITIES',
    normalBalance: 'CREDIT',
    keywords: ['provision for tax', 'provision for taxation', 'short term provision', 'proposed dividend', 'provision for warranty']
  },

  // --- Assets ---
  {
    id: 'TANGIBLE_ASSETS',
    label: 'Non-Current Assets: Tangible Assets (Net)',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_ASSETS',
    defaultNoteNumber: 8,
    normalBalance: 'DEBIT',
    keywords: ['computer', 'laptop', 'airconditioner', 'air conditioner', 'plant and machinery', 'furniture', 'fixtures', 'vehicle', 'office equipment', 'tangible asset', 'fixed asset', 'property plant equipment']
  },
  {
    id: 'INTANGIBLE_ASSETS',
    label: 'Non-Current Assets: Intangible Assets',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['software', 'computer software', 'patent', 'trademark', 'copyright', 'goodwill', 'intangible asset']
  },
  {
    id: 'NON_CURRENT_INVESTMENTS',
    label: 'Non-Current Assets: Non-Current Investments',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['investment in shares', 'long term investment', 'mutual fund non current', 'government securities']
  },
  {
    id: 'DEFERRED_TAX_ASSETS_NET',
    label: 'Non-Current Assets: Deferred Tax Assets (Net)',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['deferred tax asset', 'deferred tax assets', 'dta', 'deferred tax asset net']
  },
  {
    id: 'LONG_TERM_LOANS_AND_ADVANCES',
    label: 'Non-Current Assets: Long-Term Loans & Advances',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['security deposit', 'electricity deposit', 'rent deposit', 'long term advance']
  },
  {
    id: 'OTHER_NON_CURRENT_ASSETS',
    label: 'Non-Current Assets: Other Non-Current Assets',
    statement: 'BALANCE_SHEET',
    section: 'NON_CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['other non current asset', 'unrealized capital asset']
  },
  {
    id: 'CURRENT_INVESTMENTS',
    label: 'Current Assets: Current Investments',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['current investment', 'liquid fund', 'treasury bill']
  },
  {
    id: 'INVENTORIES',
    label: 'Current Assets: Inventories (Stock)',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    defaultNoteNumber: 12,
    normalBalance: 'DEBIT',
    keywords: ['closing stock', 'inventory', 'inventories', 'stock in trade', 'raw material', 'finished goods', 'work in progress', 'stock']
  },
  {
    id: 'TRADE_RECEIVABLES',
    label: 'Current Assets: Trade Receivables',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['sundry debtor', 'sundry debtors', 'trade receivable', 'trade receivables', 'book debts', 'customer receivables', 'debtors for sales']
  },
  {
    id: 'CASH_AND_BANK_BALANCES',
    label: 'Current Assets: Cash and Bank Balances',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    defaultNoteNumber: 7,
    normalBalance: 'DEBIT',
    keywords: ['cash in hand', 'cash on hand', 'current account', 'bank account', 'hdfc', 'icici', 'sbi', 'axis', 'bank balance', 'petty cash', 'cheques in hand']
  },
  {
    id: 'SHORT_TERM_LOANS_AND_ADVANCES',
    label: 'Current Assets: Short-Term Loans & Advances',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: ['staff advance', 'salary advance', 'short term advance', 'loan to employees']
  },
  {
    id: 'OTHER_CURRENT_ASSETS',
    label: 'Current Assets: Other Current Assets',
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    defaultNoteNumber: 9,
    normalBalance: 'DEBIT',
    keywords: ['balances with statutory authorities', 'gst input', 'input tax credit', 'tds receivable', 'advances to creditors', 'prepaid expenses', 'gst electronic ledger', 'statutory balance', 'advance tax', 'tcs receivable']
  },

  // --- Statement of Profit & Loss ---
  {
    id: 'REVENUE_FROM_OPERATIONS',
    label: 'Revenue: Revenue from Operations',
    statement: 'PROFIT_AND_LOSS',
    section: 'REVENUE',
    defaultNoteNumber: 10,
    normalBalance: 'CREDIT',
    keywords: ['sales', 'tax invoice', 'revenue from operation', 'turnover', 'gross revenue', 'service income', 'export sales', 'sale of products', 'domestic sales']
  },
  {
    id: 'OTHER_INCOME',
    label: 'Revenue: Other Income',
    statement: 'PROFIT_AND_LOSS',
    section: 'REVENUE',
    defaultNoteNumber: 11,
    normalBalance: 'CREDIT',
    keywords: ['other income', 'upi activation', 'interest income', 'discount received', 'dividend income', 'forex gain', 'miscellaneous income', 'interest on fdr', 'commission received']
  },
  {
    id: 'COST_OF_TRADED_GOODS',
    label: 'Expenses: Cost of Traded Goods',
    statement: 'PROFIT_AND_LOSS',
    section: 'EXPENSES',
    defaultNoteNumber: 12,
    normalBalance: 'DEBIT',
    keywords: ['cost of traded goods', 'purchases', 'purchase of stock', 'opening stock', 'cost of goods sold', 'purchase of traded goods', 'raw materials consumed']
  },
  {
    id: 'DIRECT_COST',
    label: 'Expenses: Direct Cost',
    statement: 'PROFIT_AND_LOSS',
    section: 'EXPENSES',
    defaultNoteNumber: 13,
    normalBalance: 'DEBIT',
    keywords: ['direct cost', 'packing & printing exp', 'packing and printing', 'freight inward', 'custom duty', 'direct wages', 'manufacturing expenses', 'job work charges']
  },
  {
    id: 'ADMINISTRATION_AND_OTHER_EXPENSES',
    label: 'Expenses: Administration & Other Expenses',
    statement: 'PROFIT_AND_LOSS',
    section: 'EXPENSES',
    defaultNoteNumber: 14,
    normalBalance: 'DEBIT',
    keywords: [
      'audit fee', 'audit fees', 'business promotion', 'accounting charges', 'insurance',
      'local conveyance', 'office expence', 'office expense', 'advertisement & publicity',
      'power & fuel', 'electricity', 'rent expenses', 'rent', 'telephone & internet exp',
      'telephone', 'commission on sales', 'other misc expenses', 'miscellaneous expenses',
      'legal fees', 'travelling expenses', 'repairs and maintenance', 'printing and stationery',
      'postage', 'consultancy fees', 'software subscription', 'statutory audit fee'
    ]
  },
  {
    id: 'FINANCE_COSTS',
    label: 'Expenses: Finance Costs',
    statement: 'PROFIT_AND_LOSS',
    section: 'EXPENSES',
    defaultNoteNumber: 15,
    normalBalance: 'DEBIT',
    keywords: ['finance cost', 'bank charges', 'bank interest', 'interest on term loan', 'loan processing charges', 'interest expense', 'finance charges']
  },
  {
    id: 'DEPRECIATION_AND_AMORTISATION',
    label: 'Expenses: Depreciation & Amortisation',
    statement: 'PROFIT_AND_LOSS',
    section: 'EXPENSES',
    defaultNoteNumber: 8,
    normalBalance: 'DEBIT',
    keywords: ['depreciation', 'amortisation', 'depreciation and amortization', 'depreciation expense']
  },
  {
    id: 'TAX_EXPENSE_CURRENT',
    label: 'Tax: Current Tax Expense',
    statement: 'PROFIT_AND_LOSS',
    section: 'TAX',
    normalBalance: 'DEBIT',
    keywords: ['current tax', 'income tax expense', 'tax provision']
  },
  {
    id: 'TAX_EXPENSE_DEFERRED',
    label: 'Tax: Deferred Tax (Charge / Credit)',
    statement: 'PROFIT_AND_LOSS',
    section: 'TAX',
    normalBalance: 'DEBIT',
    keywords: ['deferred tax charge', 'deferred tax credit', 'deferred tax expense']
  },
  {
    id: 'PRIOR_PERIOD_EXPENSES',
    label: 'Expenses: Prior Period Expenses / Items',
    statement: 'PROFIT_AND_LOSS',
    section: 'EXPENSES',
    normalBalance: 'DEBIT',
    keywords: ['prior period expense', 'prior period adjustments', 'exceptional items', 'extraordinary items']
  }
];

export function suggestCategoryForLedger(ledgerName: string): ScheduleIIICategoryType {
  const normalized = ledgerName.toLowerCase().trim();

  // 1. Direct high-priority exact/keyword matches
  if (/sundry\s+debtor/i.test(normalized)) return 'TRADE_RECEIVABLES';
  if (/sundry\s+creditor/i.test(normalized)) return 'TRADE_PAYABLES';
  if (/share\s+capital|equity\s+share/i.test(normalized)) return 'SHARE_CAPITAL';
  if (/reserves|retained\s+earnings|profit\s+(and|&)\s+loss/i.test(normalized)) return 'RESERVES_AND_SURPLUS';
  if (/loan\s+from\s+director|unsecured\s+loan|director\s+loan/i.test(normalized)) return 'LONG_TERM_BORROWINGS';
  if (/deferred\s+tax\s+asset/i.test(normalized)) return 'DEFERRED_TAX_ASSETS_NET';
  if (/deferred\s+tax\s+liab/i.test(normalized)) return 'DEFERRED_TAX_LIABILITY_NET';
  if (/deferred\s+tax\s*(charge|credit|exp)/i.test(normalized)) return 'TAX_EXPENSE_DEFERRED';
  if (/current\s+tax|income\s+tax/i.test(normalized)) return 'TAX_EXPENSE_CURRENT';
  if (/computer|laptop|airconditioner|air\s*conditioner|furniture|vehicle|equipment|tangible/i.test(normalized)) return 'TANGIBLE_ASSETS';
  if (/software|trademark|patent|intangible/i.test(normalized)) return 'INTANGIBLE_ASSETS';
  if (/closing\s+stock|inventor/i.test(normalized)) return 'INVENTORIES';
  if (/cash\s+(in|on)\s+hand|current\s+acc|bank\s+balance|petty\s+cash|hdfc|icici|sbi/i.test(normalized)) return 'CASH_AND_BANK_BALANCES';
  if (/statutory\s+authorit|tds\s+receiv|advances\s+to\s+creditor|gst\s+input|input\s+tax/i.test(normalized)) return 'OTHER_CURRENT_ASSETS';
  if (/audit\s+fee\s+payable|tds\s+payable|gst\s+payable|salary\s+payable|rent\s+payable|rozarpay|razorpay|expenses\s+payable/i.test(normalized)) return 'OTHER_CURRENT_LIABILITIES';
  if (/tax\s+invoice|revenue\s+from\s+operat|sales\s+account|turnover/i.test(normalized)) return 'REVENUE_FROM_OPERATIONS';
  if (/upi\s+activat|other\s+income|interest\s+income|discount\s+received/i.test(normalized)) return 'OTHER_INCOME';
  if (/cost\s+of\s+trade|purchase|opening\s+stock|goods\s+sold/i.test(normalized)) return 'COST_OF_TRADED_GOODS';
  if (/packing|printing\s+exp|direct\s+cost|freight\s+in/i.test(normalized)) return 'DIRECT_COST';
  if (/bank\s+charge|finance\s+cost|interest\s+on\s+loan/i.test(normalized)) return 'FINANCE_COSTS';
  if (/depreciation|amortisation/i.test(normalized)) return 'DEPRECIATION_AND_AMORTISATION';

  // 2. Search category keyword definitions
  for (const cat of SCHEDULE_III_CATEGORIES) {
    for (const kw of cat.keywords) {
      if (normalized.includes(kw.toLowerCase())) {
        return cat.id;
      }
    }
  }

  // 3. Heuristic fallback based on common words
  if (/exp|fee|charge|rent|repair|conveyance|promotion|advert|insurance|salary/i.test(normalized)) {
    return 'ADMINISTRATION_AND_OTHER_EXPENSES';
  }
  if (/payable|provision/i.test(normalized)) {
    return 'OTHER_CURRENT_LIABILITIES';
  }
  if (/receiv|deposit|advance/i.test(normalized)) {
    return 'OTHER_CURRENT_ASSETS';
  }

  return 'ADMINISTRATION_AND_OTHER_EXPENSES';
}

export function getCategoryMetadata(id: ScheduleIIICategoryType): CategoryMetadata {
  const found = SCHEDULE_III_CATEGORIES.find((c) => c.id === id);
  if (found) return found;
  return {
    id,
    label: id.replace(/_/g, ' '),
    statement: 'BALANCE_SHEET',
    section: 'CURRENT_ASSETS',
    normalBalance: 'DEBIT',
    keywords: []
  };
}
