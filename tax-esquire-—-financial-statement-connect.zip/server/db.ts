import fs from 'fs';
import path from 'path';
import { CompanyProfile, FixedAssetRow, FinancialStatementsFull, ShareholderDetail, TrialBalanceRow } from '../src/types';
import {
  INITIAL_COMPANY_PROFILE,
  INITIAL_FIXED_ASSETS,
  INITIAL_SHAREHOLDERS,
  INITIAL_TRIAL_BALANCE_CY,
  INITIAL_TRIAL_BALANCE_PY
} from '../src/data/sampleCompanyData';
import { calculateFinancialStatements } from '../src/utils/financialCalculations';

const DATA_DIR = path.join(process.cwd(), 'data');
const COMPANIES_FILE = path.join(DATA_DIR, 'companies.json');
const USERS_FILE = path.join(DATA_DIR, 'users.json');

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

export interface StoredCompanyRecord {
  profile: CompanyProfile;
  tbCY: TrialBalanceRow[];
  tbPY: TrialBalanceRow[];
  shareholders: ShareholderDetail[];
  fixedAssets: FixedAssetRow[];
  lastUpdated: string;
}

export function initDatabase() {
  ensureDataDir();

  // Initialize companies if not present
  if (!fs.existsSync(COMPANIES_FILE)) {
    const calc = calculateFinancialStatements(
      INITIAL_COMPANY_PROFILE,
      INITIAL_TRIAL_BALANCE_CY,
      INITIAL_TRIAL_BALANCE_PY,
      INITIAL_SHAREHOLDERS,
      INITIAL_FIXED_ASSETS
    );

    const initialData: Record<string, StoredCompanyRecord> = {
      [INITIAL_COMPANY_PROFILE.id]: {
        profile: INITIAL_COMPANY_PROFILE,
        tbCY: INITIAL_TRIAL_BALANCE_CY,
        tbPY: INITIAL_TRIAL_BALANCE_PY,
        shareholders: INITIAL_SHAREHOLDERS,
        fixedAssets: INITIAL_FIXED_ASSETS,
        lastUpdated: new Date().toISOString()
      }
    };

    fs.writeFileSync(COMPANIES_FILE, JSON.stringify(initialData, null, 2), 'utf-8');
  }

  // Initialize users if not present
  if (!fs.existsSync(USERS_FILE)) {
    const defaultUsers = [
      {
        id: 'user-1',
        email: 'capoonamguptaiicpa@gmail.com',
        name: 'CA Poonam Gupta',
        passwordHash: 'taxfinconnect2024',
        firmName: 'Gupta Poonam & Associates',
        frn: '033858C',
        membershipNo: '303889',
        role: 'CA_PRINCIPAL'
      },
      {
        id: 'user-2',
        email: 'admin@taxfinconnect.in',
        name: 'Tax Fin Connect Senior Partner',
        passwordHash: 'admin123',
        firmName: 'Tax Fin Connect Legal & Chartered Advisory',
        frn: '089921N',
        membershipNo: '512990',
        role: 'CA_PRINCIPAL'
      }
    ];
    fs.writeFileSync(USERS_FILE, JSON.stringify(defaultUsers, null, 2), 'utf-8');
  }
}

export function getAllCompanies(): CompanyProfile[] {
  ensureDataDir();
  try {
    const raw = fs.readFileSync(COMPANIES_FILE, 'utf-8');
    const data: Record<string, StoredCompanyRecord> = JSON.parse(raw);
    return Object.values(data).map((r) => r.profile);
  } catch {
    return [INITIAL_COMPANY_PROFILE];
  }
}

export function getCompanyFullData(id: string): FinancialStatementsFull | null {
  ensureDataDir();
  try {
    const raw = fs.readFileSync(COMPANIES_FILE, 'utf-8');
    const data: Record<string, StoredCompanyRecord> = JSON.parse(raw);
    const record = data[id];
    if (!record) return null;

    const calc = calculateFinancialStatements(
      record.profile,
      record.tbCY,
      record.tbPY,
      record.shareholders,
      record.fixedAssets
    );

    return {
      company: record.profile,
      trialBalanceCY: record.tbCY,
      trialBalancePY: record.tbPY,
      balanceSheet: calc.balanceSheet,
      profitAndLoss: calc.profitAndLoss,
      notes: calc.notes,
      lastCalculatedAt: record.lastUpdated || new Date().toISOString()
    };
  } catch (err) {
    console.error('Error reading company data:', err);
    return null;
  }
}

export function saveCompanyData(
  id: string,
  profile: CompanyProfile,
  tbCY: TrialBalanceRow[],
  tbPY: TrialBalanceRow[],
  shareholders: ShareholderDetail[],
  fixedAssets: FixedAssetRow[]
): boolean {
  ensureDataDir();
  try {
    let data: Record<string, StoredCompanyRecord> = {};
    if (fs.existsSync(COMPANIES_FILE)) {
      data = JSON.parse(fs.readFileSync(COMPANIES_FILE, 'utf-8'));
    }
    data[id] = {
      profile,
      tbCY,
      tbPY,
      shareholders,
      fixedAssets,
      lastUpdated: new Date().toISOString()
    };
    fs.writeFileSync(COMPANIES_FILE, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error saving company data:', err);
    return false;
  }
}

export function createNewCompany(profile: CompanyProfile): boolean {
  ensureDataDir();
  try {
    let data: Record<string, StoredCompanyRecord> = {};
    if (fs.existsSync(COMPANIES_FILE)) {
      data = JSON.parse(fs.readFileSync(COMPANIES_FILE, 'utf-8'));
    }
    data[profile.id] = {
      profile,
      tbCY: [],
      tbPY: [],
      shareholders: [],
      fixedAssets: [],
      lastUpdated: new Date().toISOString()
    };
    fs.writeFileSync(COMPANIES_FILE, JSON.stringify(data, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error creating company:', err);
    return false;
  }
}

export function getUsers(): any[] {
  ensureDataDir();
  try {
    if (fs.existsSync(USERS_FILE)) {
      return JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
    }
  } catch {}
  return [];
}

export function saveUser(user: any): boolean {
  ensureDataDir();
  try {
    const users = getUsers();
    users.push(user);
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), 'utf-8');
    return true;
  } catch {
    return false;
  }
}
