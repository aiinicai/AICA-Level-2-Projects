AuditLens AI – Progressive Web App (PWA) Bundle
=================================================

Contents:
- index.html                 : Main PWA application entry point
- manifest.webmanifest       : Web App Manifest (name, icons, standalone display)
- sw.js & workbox-*.js       : Service Worker for offline caching & precaching
- offline.html               : Offline CGST Rule 46 & GST State Codes fallback
- AuditLens_AI_Standalone.html : Single-file zero-server standalone HTML edition
- pwa-*.png, apple-touch-icon.png, icon.svg : App icons
- assets/                    : Compiled JS and CSS bundles

How to run and install locally:
1. Extract this ZIP into a folder.
2. Serve the folder over localhost or HTTPS (required by browsers for Service Workers):
   npx serve .
3. Open http://localhost:3000 in Chrome, Edge, or Safari and click "Install" in the address bar.