/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-afac4cd2'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "pwa-maskable-512x512.png",
    "revision": "ad2429ee74de55ef97d1aec3459d0e7e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "0865d61add86629f7b376d87b6e10b2e"
  }, {
    "url": "pwa-192x192.png",
    "revision": "bd091e4075a30c89bbd4047774d40c4e"
  }, {
    "url": "offline.html",
    "revision": "ce801730ee88847c1fdd376540722ab5"
  }, {
    "url": "index.html",
    "revision": "6cf70357d90b86220bce494b77912be9"
  }, {
    "url": "icon.svg",
    "revision": "0eabebaa0ee0eda626f06efdf97c20dd"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "db0b12581507fdba4b79ba15d877ae45"
  }, {
    "url": "AuditLens_AI_Standalone.html",
    "revision": "64e0af65802078d22f8a1bc054760072"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-DxZHJLan.css",
    "revision": null
  }, {
    "url": "assets/index-C_-vz-XL.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "db0b12581507fdba4b79ba15d877ae45"
  }, {
    "url": "icon.svg",
    "revision": "0eabebaa0ee0eda626f06efdf97c20dd"
  }, {
    "url": "offline.html",
    "revision": "ce801730ee88847c1fdd376540722ab5"
  }, {
    "url": "pwa-192x192.png",
    "revision": "bd091e4075a30c89bbd4047774d40c4e"
  }, {
    "url": "pwa-512x512.png",
    "revision": "0865d61add86629f7b376d87b6e10b2e"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "ad2429ee74de55ef97d1aec3459d0e7e"
  }, {
    "url": "manifest.webmanifest",
    "revision": "66cfe03213940e37265bcfafbc59f5c6"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/index.html"), {
    denylist: [/^\/api\//]
  }));
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
