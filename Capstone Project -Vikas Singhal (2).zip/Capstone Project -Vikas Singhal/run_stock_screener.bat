@echo off
REM ==========================================================================
REM  Indian Stock Screener - one-click installer + launcher (Windows)
REM  * finds Python 3.10+ (install from https://www.python.org/downloads/ and
REM    tick "Add python.exe to PATH" if it is missing)
REM  * creates a private virtual environment in the .venv folder
REM  * installs / upgrades all required packages (first run only)
REM  * starts stock_screener.py
REM  Use "run_stock_screener.bat --reinstall" to force a fresh package install.
REM ==========================================================================
setlocal EnableExtensions
cd /d "%~dp0"
title Indian Stock Screener

set "APP=stock_screener.py"
set "VENV=%~dp0.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "MARK=%VENV%\.deps_installed_v3"
set "PACKAGES=PyQt6 pyqtgraph yfinance pandas pypdf pdfplumber cryptography"

if not exist "%~dp0%APP%" (
    echo [ERROR] %APP% was not found next to this .bat file.
    pause
    exit /b 1
)

REM ---- 1. locate a usable Python ------------------------------------------
set "PY="
py -3 -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul && set "PY=py -3"
if not defined PY (
    python -c "import sys; sys.exit(0 if sys.version_info >= (3,10) else 1)" >nul 2>nul && set "PY=python"
)
if not defined PY (
    echo [ERROR] Python 3.10 or newer was not found.
    echo         Install it from https://www.python.org/downloads/
    echo         and tick "Add python.exe to PATH" during setup, then run this file again.
    pause
    exit /b 1
)

REM ---- 2. virtual environment ------------------------------------------------
if /i "%~1"=="--reinstall" (
    echo Forcing a fresh package install...
    if exist "%MARK%" del /q "%MARK%"
)
if not exist "%VPY%" (
    echo Creating virtual environment in .venv ...
    %PY% -m venv "%VENV%"
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
)

REM ---- 3. dependencies (first run only) ----------------------------------------
if exist "%MARK%" (
    "%VPY%" -c "import PyQt6.QtWidgets, pyqtgraph, yfinance, pandas, pypdf, pdfplumber, cryptography; assert hasattr(yfinance, 'Search') and hasattr(pdfplumber.page.Page, 'extract_text_lines')" >nul 2>nul
    if errorlevel 1 del /q "%MARK%"
)
if not exist "%MARK%" (
    echo Installing dependencies: %PACKAGES%
    echo This can take a few minutes the first time...
    "%VPY%" -m pip install --upgrade pip
    "%VPY%" -m pip install --upgrade PyQt6 pyqtgraph "yfinance>=0.2.65" pandas pypdf "pdfplumber>=0.11.0" cryptography
    if errorlevel 1 (
        echo.
        echo [ERROR] Package installation failed. Check your internet connection and run this file again.
        pause
        exit /b 1
    )
    echo installed> "%MARK%"
)

REM ---- 4. run -------------------------------------------------------------------
echo Starting Indian Stock Screener...
"%VPY%" "%~dp0%APP%"
if errorlevel 1 (
    echo.
    echo [ERROR] The application exited with an error - see the messages above.
    pause
    exit /b 1
)
endlocal
