#!/usr/bin/env python3
"""
Indian Stock Screener (Nifty 500) - single-file desktop app.

Run:      python stock_screener.py
Install:  pip install PyQt6 pyqtgraph yfinance pandas pypdf pdfplumber cryptography
          (or just double-click run_stock_screener.bat, which installs everything)

Sections
  1. CONFIG      - paths, URLs, colours, stylesheet
  2. DATA        - Nifty 500 list, Yahoo downloads, disk cache, background QThread
  3. INDICATORS  - SMA, RSI, per-stock metrics, master table
  4. SCORING     - 0-100 score, strengths and red flags in plain English
  5. DATABASE    - SQLite watchlist, trades (buy/sell), execution log
  5b. PORTFOLIO MATH - average-cost positions, realized P&L, XIRR
  5c. PDF IMPORT - read trades / holdings from broker PDFs (no Qt)
  6. UI          - widgets, tabs, main window
       Tabs: Dashboard | Screener | Stock | Portfolio Import | Watchlist & Portfolio | Portfolio Dashboard

Educational tool only - not investment advice.
"""
from __future__ import annotations

import importlib
import io
import json
import logging
import csv
import difflib
import math
import os
import re
import site
import sqlite3
import subprocess
import sys
import time
import urllib.request
import datetime as dt
from concurrent.futures import ThreadPoolExecutor, as_completed
from contextlib import closing
from pathlib import Path

os.environ.setdefault("PYQTGRAPH_QT_LIB", "PyQt6")

import pandas as pd
import yfinance as yf
from PyQt6.QtCore import (QDate, QEventLoop, QPointF, QRectF, QStringListModel, Qt, QThread,
                          QTimer, pyqtSignal)
from PyQt6.QtGui import QBrush, QColor, QPainter, QPicture
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QCheckBox, QComboBox,
                             QCompleter, QDateEdit, QDoubleSpinBox, QFileDialog,
                             QFrame, QGridLayout, QGroupBox, QHBoxLayout,
                             QHeaderView, QInputDialog, QLabel, QLineEdit, QMainWindow,
                             QMessageBox, QProgressBar, QProgressDialog, QPushButton, QSpinBox,
                             QSplitter, QTableWidget, QTableWidgetItem,
                             QTabWidget, QTextBrowser, QVBoxLayout, QWidget)
import pyqtgraph as pg

logging.getLogger("yfinance").setLevel(logging.CRITICAL)   # hide 'symbol may be delisted' spam


# =============================================================================
# 1. CONFIG
# =============================================================================
APP_DIR = Path(__file__).resolve().parent
CACHE_DIR = APP_DIR / "cache"
DB_PATH = APP_DIR / "portfolio.db"
BACKUP_DIR = APP_DIR / "backups"      # CSV copies of the trades taken before a portfolio override

NIFTY500_URL = "https://archives.nseindia.com/content/indices/ind_nifty500list.csv"
INDICES = {"Nifty 50": "^NSEI", "Sensex": "^BSESN", "Bank Nifty": "^NSEBANK"}

PRICE_PERIOD = "2y"        # enough history for a 200-day average plus 1-year return
BATCH_SIZE = 40            # tickers per yf.download call
FUND_WORKERS = 8           # parallel fundamentals requests
FUND_TTL_DAYS = 7          # refetch fundamentals older than this
AUTO_REFRESH_HOURS = 24    # refresh in the background if cache is older than this
FINANCIAL_SECTOR = "Financial Services"   # debt/equity is not meaningful here

BG, PANEL, BORDER = "#0f1419", "#161c24", "#2a3441"
FG, MUTED = "#e6e9ee", "#8b97a7"
UP, DOWN, ACCENT, AMBER = "#26a69a", "#ef5350", "#4c9aff", "#f5a623"

STYLESHEET = f"""
QWidget {{ background:{BG}; color:{FG}; font-size:13px; }}
QMainWindow, QTabWidget::pane {{ background:{BG}; border:1px solid {BORDER}; }}
QTabBar::tab {{ background:{PANEL}; padding:8px 18px; border:1px solid {BORDER};
               border-bottom:none; margin-right:2px; color:{MUTED}; }}
QTabBar::tab:selected {{ background:{BG}; color:{FG}; border-top:2px solid {ACCENT}; }}
QGroupBox {{ border:1px solid {BORDER}; border-radius:6px; margin-top:12px; padding:8px; }}
QGroupBox::title {{ subcontrol-origin:margin; left:10px; padding:0 4px; color:{MUTED}; }}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QDateEdit {{
    background:{PANEL}; border:1px solid {BORDER}; border-radius:4px; padding:4px 6px; }}
QLineEdit:focus, QComboBox:focus {{ border:1px solid {ACCENT}; }}
QComboBox QAbstractItemView {{ background:{PANEL}; selection-background-color:{ACCENT}; }}
QPushButton {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:4px; padding:6px 12px; }}
QPushButton:hover {{ border-color:{ACCENT}; }}
QPushButton:disabled {{ color:{MUTED}; }}
QPushButton#primary {{ background:{ACCENT}; color:#0b0f14; border:none; font-weight:bold; }}
QTableWidget {{ background:{BG}; alternate-background-color:{PANEL}; gridline-color:{BORDER};
               border:1px solid {BORDER}; selection-background-color:#24425f; }}
QHeaderView::section {{ background:{PANEL}; color:{MUTED}; border:none;
                       border-right:1px solid {BORDER}; border-bottom:1px solid {BORDER}; padding:5px; }}
QTextBrowser {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:4px; }}
QProgressBar {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:4px;
               text-align:center; min-width:220px; }}
QProgressBar::chunk {{ background:{ACCENT}; }}
QStatusBar {{ background:{PANEL}; color:{MUTED}; }}
QFrame#card {{ background:{PANEL}; border:1px solid {BORDER}; border-radius:8px; }}
QLabel {{ background:transparent; }}
QScrollBar:vertical {{ background:{BG}; width:10px; }}
QScrollBar::handle:vertical {{ background:{BORDER}; border-radius:4px; min-height:24px; }}
QScrollBar:horizontal {{ background:{BG}; height:10px; }}
QScrollBar::handle:horizontal {{ background:{BORDER}; border-radius:4px; min-width:24px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width:0; height:0; }}
"""


# =============================================================================
# 2. DATA  (download, cache, background thread)
# =============================================================================
def num(x) -> float:
    """Convert anything to a finite float, else NaN."""
    try:
        v = float(x)
        return v if math.isfinite(v) else math.nan
    except (TypeError, ValueError):
        return math.nan


def atomic_write(path: Path, data: bytes) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_bytes(data)
    os.replace(tmp, path)


def http_get(url: str, timeout: int = 25) -> bytes:
    # NSE rejects requests without a browser-like User-Agent.
    req = urllib.request.Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/120 Safari/537.36",
        "Accept": "text/csv,*/*"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.read()


def parse_universe(raw: bytes) -> pd.DataFrame:
    df = pd.read_csv(io.BytesIO(raw))
    df.columns = [c.strip() for c in df.columns]
    df = df.rename(columns={"Company Name": "Name", "Industry": "Sector"})
    df = df[["Symbol", "Name", "Sector"]].dropna(subset=["Symbol"])
    df["Symbol"] = df["Symbol"].astype(str).str.strip().str.upper()
    df = df[~df["Symbol"].str.startswith("DUMMY")]      # NSE placeholder rows (e.g. DUMMYHEG)
    return df.drop_duplicates("Symbol").reset_index(drop=True)


def download_universe() -> pd.DataFrame:
    """Fetch the Nifty 500 list; fall back to the cached copy if offline."""
    path = CACHE_DIR / "nifty500.csv"
    try:
        raw = http_get(NIFTY500_URL)
        df = parse_universe(raw)
        if len(df) > 100:
            atomic_write(path, raw)
            return df
    except Exception:
        pass
    if path.exists():
        return parse_universe(path.read_bytes())
    raise RuntimeError("Could not download the Nifty 500 list and no cached copy exists.")


def clean_ohlcv(df: pd.DataFrame) -> pd.DataFrame | None:
    cols = ["Open", "High", "Low", "Close", "Volume"]
    if df is None or df.empty or not set(cols) <= set(df.columns):
        return None
    df = df[cols].dropna(subset=["Close", "Open", "High", "Low"])
    if len(df) < 2:
        return None
    if getattr(df.index, "tz", None) is not None:
        df.index = df.index.tz_localize(None)
    df.index = pd.to_datetime(df.index).normalize()
    return df[~df.index.duplicated(keep="last")]


def split_download(raw: pd.DataFrame, tickers: list[str]) -> dict[str, pd.DataFrame]:
    """Turn a (possibly multi-index) yf.download frame into {ticker: OHLCV}."""
    out: dict[str, pd.DataFrame] = {}
    if raw is None or raw.empty:
        return out
    if isinstance(raw.columns, pd.MultiIndex):
        if {"Close", "Open"} & set(raw.columns.get_level_values(0)):
            raw = raw.swaplevel(axis=1)          # (Price, Ticker) -> (Ticker, Price)
        available = set(raw.columns.get_level_values(0))
        for t in tickers:
            if t in available:
                d = clean_ohlcv(raw[t])
                if d is not None:
                    out[t] = d
    elif len(tickers) == 1:
        d = clean_ohlcv(raw)
        if d is not None:
            out[tickers[0]] = d
    return out


def extract_fundamentals(info: dict) -> dict:
    """Pick the fields we need from Yahoo's .info and normalise units."""
    price = num(info.get("currentPrice") or info.get("regularMarketPrice")
                or info.get("previousClose"))
    rate = num(info.get("dividendRate"))
    if not math.isnan(rate) and not math.isnan(price) and price > 0:
        div = rate / price * 100
    else:
        tad = num(info.get("trailingAnnualDividendYield"))
        div = tad * 100 if not math.isnan(tad) else 0.0     # no dividend -> 0
    de, roe, growth = num(info.get("debtToEquity")), num(info.get("returnOnEquity")), num(info.get("revenueGrowth"))
    margin, eg, mcap = num(info.get("profitMargins")), num(info.get("earningsGrowth")), num(info.get("marketCap"))
    return {
        "pe": num(info.get("trailingPE")),
        "pb": num(info.get("priceToBook")),
        "roe": roe * 100,                  # Yahoo gives a fraction
        "de": de / 100,                    # Yahoo gives a percentage (45 == 0.45x)
        "growth": growth * 100,
        "margin": margin * 100,
        "eg": eg * 100,
        "div": div,
        "mcap": mcap / 1e7,                # rupees -> crore
        "eps": num(info.get("trailingEps")),
        "fetched": time.time(),
    }


def fetch_fundamental(symbol: str) -> dict | None:
    for attempt in range(2):
        try:
            info = yf.Ticker(symbol + ".NS").info
            if info and len(info) > 5:
                return extract_fundamentals(info)
        except Exception as exc:
            if "404" in str(exc) or "Not Found" in str(exc):
                return None            # unknown to Yahoo - retrying won't help
        time.sleep(1.2)
    return None


# ---- disk cache -------------------------------------------------------------
def load_cache() -> dict | None:
    """Return cached universe/prices/fundamentals or None if nothing usable."""
    try:
        uni_path, px_path = CACHE_DIR / "nifty500.csv", CACHE_DIR / "prices.pkl"
        if not (uni_path.exists() and px_path.exists()):
            return None
        blob = pd.read_pickle(px_path)
        funds = {}
        fpath = CACHE_DIR / "fundamentals.json"
        if fpath.exists():
            funds = json.loads(fpath.read_text(encoding="utf-8"))
        return {"universe": parse_universe(uni_path.read_bytes()),
                "prices": blob["prices"], "indices": blob["indices"],
                "fundamentals": funds, "updated": blob["updated"]}
    except Exception:
        return None


def save_cache(payload: dict) -> None:
    CACHE_DIR.mkdir(exist_ok=True)
    tmp = CACHE_DIR / "prices.pkl.tmp"
    pd.to_pickle({"prices": payload["prices"], "indices": payload["indices"],
                  "updated": payload["updated"]}, tmp)
    os.replace(tmp, CACHE_DIR / "prices.pkl")
    atomic_write(CACHE_DIR / "fundamentals.json",
                 json.dumps(payload["fundamentals"]).encode("utf-8"))


class DataWorker(QThread):
    """Downloads everything off the UI thread and reports progress."""
    progress = pyqtSignal(int, str)
    done = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(self, fundamentals: dict, old_prices: dict, force_fund: bool = False):
        super().__init__()
        self.fundamentals = dict(fundamentals)
        self.prices = dict(old_prices)       # keep old data for tickers that fail
        self.force_fund = force_fund

    def run(self):
        try:
            payload = self._run()
            if payload is not None:
                self.done.emit(payload)
        except Exception as exc:  # noqa: BLE001 - surface any error to the UI
            self.failed.emit(f"{type(exc).__name__}: {exc}")

    def _run(self):
        CACHE_DIR.mkdir(exist_ok=True)
        self.progress.emit(1, "Loading Nifty 500 list...")
        universe = download_universe()
        symbols = universe["Symbol"].tolist()

        # --- prices (batched) ---
        batches = [symbols[i:i + BATCH_SIZE] for i in range(0, len(symbols), BATCH_SIZE)]
        got = 0
        for i, batch in enumerate(batches):
            if self.isInterruptionRequested():
                return None
            self.progress.emit(3 + int(42 * i / len(batches)),
                               f"Downloading prices... batch {i + 1}/{len(batches)}")
            tickers = [s + ".NS" for s in batch]
            try:
                raw = yf.download(tickers, period=PRICE_PERIOD, interval="1d", group_by="ticker",
                                  auto_adjust=True, threads=True, progress=False)
                data = split_download(raw, tickers)
            except Exception:
                data = {}
            for t, d in data.items():
                self.prices[t[:-3]] = d
                got += 1
        if got == 0 and not self.prices:
            raise RuntimeError("No price data could be downloaded. Check your internet connection.")

        # --- indices ---
        self.progress.emit(46, "Downloading index data...")
        indices = {}
        for name, tk in INDICES.items():
            try:
                h = yf.Ticker(tk).history(period="3mo", auto_adjust=False)
                d = clean_ohlcv(h)
                if d is not None:
                    indices[name] = d
            except Exception:
                pass

        # --- fundamentals (parallel, incremental) ---
        now = time.time()
        todo = [s for s in symbols if self.force_fund or s not in self.fundamentals
                or now - self.fundamentals[s].get("fetched", 0) > FUND_TTL_DAYS * 86400]
        total, finished = len(todo), 0
        if todo:
            ex = ThreadPoolExecutor(max_workers=FUND_WORKERS)
            futs = {ex.submit(fetch_fundamental, s): s for s in todo}
            try:
                for fut in as_completed(futs):
                    if self.isInterruptionRequested():
                        ex.shutdown(wait=False, cancel_futures=True)
                        return None
                    finished += 1
                    res = fut.result()
                    if res:
                        self.fundamentals[futs[fut]] = res
                    self.progress.emit(48 + int(50 * finished / total),
                                       f"Downloading fundamentals... {finished}/{total}")
            finally:
                ex.shutdown(wait=False, cancel_futures=True)

        self.progress.emit(99, "Saving cache...")
        payload = {"universe": universe, "prices": self.prices, "indices": indices,
                   "fundamentals": self.fundamentals, "updated": time.time()}
        if not indices:   # keep the previous index data if this fetch failed
            old = load_cache()
            payload["indices"] = old["indices"] if old else {}
        save_cache(payload)
        self.progress.emit(100, "Done")
        return payload


# =============================================================================
# 3. INDICATORS
# =============================================================================
def sma(close: pd.Series, window: int) -> pd.Series:
    return close.rolling(window, min_periods=window).mean()


def rsi(close: pd.Series, period: int = 14) -> pd.Series:
    """Wilder's RSI."""
    delta = close.diff()
    gain, loss = delta.clip(lower=0), -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, adjust=False, min_periods=period).mean()
    out = 100 - 100 / (1 + avg_gain / avg_loss)
    return out.where(avg_loss != 0, 100.0)


def price_metrics(df: pd.DataFrame) -> dict:
    close = df["Close"]
    price = float(close.iloc[-1])
    last_date = close.index[-1]
    cutoff = last_date - pd.Timedelta(days=365)
    pos = close.index.searchsorted(cutoff)
    ret1y = math.nan
    # require history that really reaches back about a year
    if pos < len(close) - 1 and (close.index[pos] - cutoff).days <= 10:
        ret1y = (price / float(close.iloc[pos]) - 1) * 100
    r, s50, s200 = rsi(close).iloc[-1], sma(close, 50).iloc[-1], sma(close, 200).iloc[-1]
    return {"price": price, "chg": (price / float(close.iloc[-2]) - 1) * 100,
            "rsi": num(r), "sma50": num(s50), "sma200": num(s200), "ret1y": ret1y}


def build_master(universe: pd.DataFrame, prices: dict, funds: dict) -> pd.DataFrame:
    """One row per stock: price metrics + fundamentals + score."""
    rows = []
    for u in universe.itertuples(index=False):
        df = prices.get(u.Symbol)
        if df is None or len(df) < 2:
            continue
        f = funds.get(u.Symbol, {})
        row = {"symbol": u.Symbol, "name": u.Name, "sector": u.Sector, **price_metrics(df)}
        for k in ("mcap", "pe", "pb", "roe", "de", "growth", "margin", "eg", "div", "eps"):
            row[k] = num(f.get(k))
        row["score"] = score_stock(row)[0]
        rows.append(row)
    cols = ["symbol", "name", "sector", "price", "chg", "mcap", "pe", "pb", "roe", "de",
            "growth", "margin", "eg", "div", "eps", "rsi", "ret1y", "sma50", "sma200", "score"]
    df = pd.DataFrame(rows, columns=cols)
    return df.set_index("symbol", drop=False)


# =============================================================================
# 4. SCORING
# =============================================================================
def _scale(x, bad: float, good: float) -> float | None:
    """Map x linearly to 0..1 where `bad`->0 and `good`->1 (works in either direction)."""
    if x is None or pd.isna(x):
        return None
    return max(0.0, min(1.0, (x - bad) / (good - bad)))


def _mean(vals: list) -> float | None:
    vals = [v for v in vals if v is not None]
    return sum(vals) / len(vals) if vals else None


def score_stock(m) -> tuple[float, list[str], list[str]]:
    """Return (score 0-100, strengths, red flags). `m` is a dict or Series."""
    g = lambda k: (None if pd.isna(m.get(k)) else float(m.get(k)))      # noqa: E731
    pe, pb, roe, de = g("pe"), g("pb"), g("roe"), g("de")
    growth, margin, eg, div = g("growth"), g("margin"), g("eg"), g("div")
    rsi_v, ret1y, price = g("rsi"), g("ret1y"), g("price")
    s50, s200, mcap = g("sma50"), g("sma200"), g("mcap")
    eps = g("eps")
    is_fin = m.get("sector") == FINANCIAL_SECTOR

    # ---- score: weighted blend of five areas; missing data is skipped, not punished
    value = _mean([_scale(pe, 50, 10) if pe and pe > 0 else None, _scale(pb, 8, 1), _scale(div, 0, 4)])
    quality = _mean([_scale(roe, 0, 25), _scale(margin, 0, 20)])
    growth_c = _mean([_scale(growth, -10, 25), _scale(eg, -20, 30)])
    safety = None if is_fin else _scale(de, 2.0, 0.0)
    ratio = price / s200 if price and s200 else None
    rsi_c = None if rsi_v is None else max(0.0, 1 - abs(rsi_v - 60) / 40)
    momentum = _mean([_scale(ratio, 0.85, 1.25), _scale(ret1y, -10, 50), rsi_c])
    parts = [(value, 20), (quality, 25), (growth_c, 20), (safety, 15), (momentum, 20)]
    avail = [(c, w) for c, w in parts if c is not None]
    if len(avail) >= 2:
        score = round(100 * sum(c * w for c, w in avail) / sum(w for _, w in avail), 0)
    else:
        score = math.nan

    # ---- plain-English strengths and red flags
    good, bad = [], []
    if roe is not None and roe >= 18:
        good.append(f"High return on equity ({roe:.0f}%): it earns strong profits on shareholders' money.")
    if margin is not None and margin >= 15:
        good.append(f"Healthy profit margin ({margin:.0f}% of sales kept as profit).")
    if growth is not None and growth >= 15:
        good.append(f"Sales are growing fast ({growth:.0f}% year on year).")
    if de is not None and not is_fin and de <= 0.3:
        good.append(f"Very little debt (debt/equity {de:.2f}).")
    if pe is not None and 0 < pe <= 15:
        good.append(f"Looks cheaply valued: P/E of {pe:.1f}.")
    if div is not None and div >= 2.5:
        good.append(f"Pays a solid dividend ({div:.1f}% yield).")
    if price and s50 and s200 and price > s200 and s50 > s200:
        good.append("In an uptrend: price is above the 200-day average and the 50-day is above the 200-day.")
    if ret1y is not None and ret1y >= 25:
        good.append(f"Strong 1-year return ({ret1y:.0f}%).")
    if mcap is not None and mcap >= 50000:
        good.append("Large, established company (market cap above ₹50,000 crore).")

    if (pe is not None and pe <= 0) or (eps is not None and eps < 0):
        bad.append("Losing money: there is no meaningful P/E because earnings are negative.")
    elif pe is not None and pe > 50:
        bad.append(f"Expensive: P/E of {pe:.0f} is very high, so the company must keep growing fast to justify it.")
    if roe is not None and roe < 8:
        bad.append(f"Low return on equity ({roe:.0f}%): weak use of shareholders' money.")
    if margin is not None and margin < 5:
        bad.append(f"Thin profit margin ({margin:.1f}%): little cushion if costs rise.")
    if de is not None and not is_fin and de > 1.5:
        bad.append(f"Heavy debt (debt/equity {de:.1f}): interest costs can hurt in a downturn.")
    if growth is not None and growth < 0:
        bad.append(f"Sales are shrinking ({growth:.0f}% year on year).")
    if price and s200 and price < s200:
        bad.append("In a downtrend: price is below the 200-day average.")
    if rsi_v is not None and rsi_v >= 75:
        bad.append(f"Overbought: RSI of {rsi_v:.0f} suggests the recent rally may be stretched.")
    if rsi_v is not None and rsi_v <= 30:
        bad.append(f"Oversold: RSI of {rsi_v:.0f} shows heavy selling - could be a bargain or a falling knife.")
    if ret1y is not None and ret1y <= -20:
        bad.append(f"Down {abs(ret1y):.0f}% over the last year.")
    if mcap is not None and mcap < 2000:
        bad.append("Small company (market cap under ₹2,000 crore): prices can swing sharply and trading may be thin.")
    if all(x is None for x in (pe, roe, growth, margin)):
        bad.append("Yahoo has few fundamentals for this stock, so the score relies mostly on price trend.")
    return score, good, bad


# =============================================================================
# 5. DATABASE (SQLite: watchlist + trades)
# =============================================================================
class Database:
    def __init__(self, path: Path = DB_PATH):
        self.path = path
        self._exec("""CREATE TABLE IF NOT EXISTS watchlist(
                        symbol TEXT PRIMARY KEY, added TEXT NOT NULL)""")
        self._exec("""CREATE TABLE IF NOT EXISTS trades(
                        id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL,
                        qty REAL NOT NULL, price REAL NOT NULL, trade_date TEXT NOT NULL)""")
        # --- upgrade older databases: BUY/SELL side, broker trade reference, where the row came from
        cols = {r[1] for r in self._exec("PRAGMA table_info(trades)", fetch=True)}
        for name, ddl in (("side", "TEXT NOT NULL DEFAULT 'BUY'"), ("ref", "TEXT"), ("source", "TEXT"), ("reported_avg", "REAL")):
            if name not in cols:
                self._exec(f"ALTER TABLE trades ADD COLUMN {name} {ddl}")
        self._exec("""CREATE TABLE IF NOT EXISTS exec_log(
                        id INTEGER PRIMARY KEY AUTOINCREMENT, ts TEXT NOT NULL, action TEXT NOT NULL,
                        symbol TEXT, detail TEXT, status TEXT NOT NULL, source TEXT)""")
        # prices for holdings that are not in the Nifty 500 download (from the PDF or Yahoo)
        self._exec("""CREATE TABLE IF NOT EXISTS price_extra(
                        symbol TEXT PRIMARY KEY, price REAL, prev_close REAL, sector TEXT,
                        updated TEXT NOT NULL, from_yahoo INTEGER NOT NULL DEFAULT 0)""")

    def _exec(self, sql: str, args: tuple = (), fetch: bool = False):
        with closing(sqlite3.connect(self.path)) as con:
            cur = con.execute(sql, args)
            rows = cur.fetchall() if fetch else None
            con.commit()
            return rows

    # ---- watchlist
    def watchlist(self) -> list[str]:
        return [r[0] for r in self._exec("SELECT symbol FROM watchlist ORDER BY added", fetch=True)]

    def add_watch(self, sym: str):
        self._exec("INSERT OR IGNORE INTO watchlist VALUES(?,?)", (sym, dt.datetime.now().isoformat()))

    def remove_watch(self, sym: str):
        self._exec("DELETE FROM watchlist WHERE symbol=?", (sym,))

    # ---- trades
    def trades(self, con=None) -> list[tuple]:
        sql = ("SELECT id,symbol,qty,price,trade_date,side,reported_avg,source FROM trades "
               "ORDER BY trade_date DESC, id DESC")
        return con.execute(sql).fetchall() if con is not None else self._exec(sql, fetch=True)

    def add_trade(self, sym: str, qty: float, price: float, date: str,
                  side: str = "BUY", ref: str | None = None, source: str = "manual"):
        self._exec("INSERT INTO trades(symbol,qty,price,trade_date,side,ref,source) VALUES(?,?,?,?,?,?,?)",
                   (sym, qty, price, date, side, ref or None, source))

    def add_broker_trade(self, sym, qty, price, date, side, ref, source) -> bool:
        with closing(sqlite3.connect(self.path)) as con, con:
            con.execute("BEGIN IMMEDIATE")
            if con.execute("SELECT 1 FROM trades WHERE ref=?", (ref,)).fetchone():
                return False
            cur = con.execute(
                "INSERT INTO trades(symbol,qty,price,trade_date,side,ref,source) VALUES(?,?,?,?,?,?,?)",
                (sym, qty, price, date, side, ref, source))
            running = 0.0
            new_sale_applied = False
            for tid, ticker, amount, _, _, direction, *_ in position_order(self.trades(con)):
                if ticker != sym:
                    continue
                if direction == "SELL" and amount > running + 1e-9:
                    if tid == cur.lastrowid:
                        raise ValueError(f"Sell quantity exceeds the {fmt_qty(running)} shares held on {date}.")
                    if new_sale_applied:
                        raise ValueError("Applying this sale would leave too few shares for another recorded sale.")
                if tid == cur.lastrowid and direction == "SELL":
                    new_sale_applied = True
                running = max(0.0, running + (amount if direction == "BUY" else -amount))
            return True

    def trade_exists(self, sym: str, qty: float, price: float, date: str, side: str, ref: str | None) -> bool:
        if ref:
            if self._exec("SELECT 1 FROM trades WHERE ref=? AND symbol=? AND side=?", (ref, sym, side), fetch=True):
                return True
        return bool(self._exec(
            "SELECT 1 FROM trades WHERE symbol=? AND side=? AND trade_date=? "
            "AND ABS(qty-?)<0.0001 AND ABS(price-?)<0.005",
            (sym, side, date, qty, price), fetch=True))

    def delete_trade(self, trade_id: int):
        self._exec("DELETE FROM trades WHERE id=?", (trade_id,))

    def replace_portfolio(self, holdings: list[dict], backup_dir: Path) -> tuple[int, int, Path | None]:
        """Delete every trade and insert one BUY per holding. Old trades are saved to a CSV first.

        holdings: dicts with symbol, qty, avg, date ('YYYY-MM-DD').  Returns (deleted, inserted, backup path).
        """
        backup = None
        with closing(sqlite3.connect(self.path)) as con, con:
            con.execute("BEGIN IMMEDIATE")
            old = con.execute("SELECT id,symbol,qty,price,trade_date,side,ref,source,reported_avg "
                              "FROM trades ORDER BY id").fetchall()
            if old:
                backup_dir.mkdir(exist_ok=True)
                backup = backup_dir / f"trades_before_override_{dt.datetime.now():%Y%m%d_%H%M%S_%f}.csv"
                pd.DataFrame(old, columns=["id", "symbol", "qty", "price", "trade_date", "side",
                                           "ref", "source", "reported_avg"]).to_csv(backup, index=False)
            con.execute("DELETE FROM trades")
            con.executemany(
                "INSERT INTO trades(symbol,qty,price,trade_date,side,source,reported_avg) "
                "VALUES(?,?,?,?,'BUY','holdings PDF',?)",
                [(h["symbol"], h["qty"], h.get("invested", h["qty"] * h["avg"]) / h["qty"],
                  h["date"], h["avg"]) for h in holdings])
        return len(old), len(holdings), backup

    # ---- execution log
    def log_many(self, entries: list[tuple]):
        """entries: (action, symbol, detail, status, source)."""
        now = dt.datetime.now().isoformat(timespec="seconds")
        with closing(sqlite3.connect(self.path)) as con:
            con.executemany("INSERT INTO exec_log(ts,action,symbol,detail,status,source) VALUES(?,?,?,?,?,?)",
                            [(now, *e) for e in entries])
            con.commit()

    def log_rows(self, limit: int = 1500) -> list[tuple]:
        return self._exec("SELECT ts,action,symbol,detail,status,source FROM exec_log "
                          "ORDER BY id DESC LIMIT ?", (limit,), fetch=True)

    def clear_log(self):
        self._exec("DELETE FROM exec_log")

    # ---- prices for stocks outside the Nifty 500 download
    def extra_prices(self) -> dict[str, dict]:
        rows = self._exec("SELECT symbol,price,prev_close,sector,updated,from_yahoo FROM price_extra", fetch=True)
        return {s: {"price": p if p is not None else math.nan, "prev": pc if pc is not None else math.nan,
                    "sector": sec or "", "updated": u, "yahoo": bool(y)} for s, p, pc, sec, u, y in rows}

    def set_extra_price(self, sym: str, price: float, prev: float, sector: str, from_yahoo: bool):
        self._exec("INSERT OR REPLACE INTO price_extra VALUES(?,?,?,?,?,?)",
                   (sym, None if pd.isna(price) else price, None if pd.isna(prev) else prev, sector or "",
                    dt.datetime.now().isoformat(timespec="seconds"), int(from_yahoo)))


# =============================================================================
# 5b. PORTFOLIO MATH  (positions with average-cost method, XIRR)
# =============================================================================
def fmt_qty(q) -> str:
    if q is None or pd.isna(q):
        return "–"
    return f"{q:,.0f}" if abs(q - round(q)) < 1e-9 else f"{q:,.2f}"


def position_order(trades):
    return sorted(trades, key=lambda t: (not (len(t) > 7 and t[7] == "holdings PDF"),
                                         t[4], str(t[5]).upper() == "SELL", t[0]))


def compute_positions(trades: list[tuple]) -> tuple[dict, float]:
    """trades: (id, symbol, qty, price, date, side). Average-cost method.

    Returns ({symbol: {qty, cost, avg, realized, first_date}}, total_realized_pnl).
    Sells larger than the held quantity are capped at the held quantity.
    """
    order = position_order(trades)
    pos: dict[str, dict] = {}
    for _tid, sym, qty, price, date, side, *meta in order:
        p = pos.setdefault(sym, {"qty": 0.0, "cost": 0.0, "realized": 0.0, "first_date": date})
        p["reported_avg"] = meta[0] if meta and p["qty"] <= 1e-9 else None
        if str(side).upper() == "SELL":
            sold = min(qty, p["qty"])
            if sold > 0:
                avg = p["cost"] / p["qty"]
                p["realized"] += sold * (price - avg)
                p["cost"] -= sold * avg
                p["qty"] -= sold
            if p["qty"] < 1e-9:
                p["qty"], p["cost"], p["first_date"] = 0.0, 0.0, None
        else:
            if p["qty"] < 1e-9:
                p["first_date"] = date
            p["qty"] += qty
            p["cost"] += qty * price
    for p in pos.values():
        p["avg"] = p["reported_avg"] or (p["cost"] / p["qty"] if p["qty"] > 1e-9 else math.nan)
    return pos, sum(p["realized"] for p in pos.values())


def xirr(flows: list[tuple[dt.date, float]], min_days: int = 30) -> float:
    """Annualised return (%) for dated cash flows; NaN if it cannot be computed sensibly."""
    flows = [(d, a) for d, a in flows if d is not None and a and not math.isnan(a)]
    if len(flows) < 2 or not (any(a > 0 for _, a in flows) and any(a < 0 for _, a in flows)):
        return math.nan
    d0 = min(d for d, _ in flows)
    if (max(d for d, _ in flows) - d0).days < min_days:
        return math.nan

    def npv(rate):
        return sum(a / (1 + rate) ** ((d - d0).days / 365.0) for d, a in flows)

    lo, hi = -0.99, 10.0
    try:
        f_lo, f_hi = npv(lo), npv(hi)
        if f_lo * f_hi > 0:
            return math.nan
        for _ in range(200):
            mid = (lo + hi) / 2
            f_mid = npv(mid)
            if f_lo * f_mid <= 0:
                hi = mid
            else:
                lo, f_lo = mid, f_mid
        return (lo + hi) / 2 * 100
    except (OverflowError, ZeroDivisionError):
        return math.nan


# =============================================================================
# 5c. PDF IMPORT  (pure functions - no Qt - so they are easy to test)
# =============================================================================
MONTHS = "jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec"
DATE_PATTERNS = [
    re.compile(r"\b\d{4}[-/]\d{1,2}[-/]\d{1,2}\b"),
    re.compile(r"\b\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\b"),
    re.compile(r"\b\d{1,2}\.\d{1,2}\.\d{4}\b"),
    re.compile(rf"\b\d{{1,2}}[-\s/]*(?:{MONTHS})[a-z]*[-\s,/.]*\d{{2,4}}\b", re.I),
]
TIME_RE = re.compile(r"\b\d{1,2}:\d{2}(?::\d{2})?(?:\s*[AaPp][Mm])?\b")
ISIN_RE = re.compile(r"\bIN[EF][0-9A-Z]{9}\b")
NUM_RE = re.compile(r"^\(?[-+]?(?:\d[\d,]*\.?\d*|\.\d+)\)?%?$")
SIDE_WORDS = {"BUY": "BUY", "B": "BUY", "BOUGHT": "BUY", "SELL": "SELL", "S": "SELL", "SOLD": "SELL"}
DROP_TOKENS = {"NSE", "BSE", "EQ", "CNC", "MIS", "NRML", "NSE-EQ", "BSE-EQ", "TRUE", "FALSE", "NA", "N/A", "NIL"}
JUNK_LINE = re.compile(r"^\W*(?:total|grand\s*total|sub[\s-]*total|net|page|statement|clients?|summary|disclaimer|"
                       r"notes?|dp|depository|holdings?|as\s+on|as\s+of|portfolio|equity|mutual|isin|name|"
                       r"ucc|pan|sr|sl|s\.?\s*no|particulars|scrip|symbol)\b", re.I)


class PdfError(Exception):
    pass


class PdfPasswordNeeded(PdfError):
    pass


def parse_date(text) -> dt.date | None:
    s = str(text or "").strip()
    if not s:
        return None
    s = re.sub(r"\bsept\b", "sep", s, flags=re.I)
    fmts = ["%Y-%m-%d", "%d-%m-%Y", "%d-%m-%y"]
    if re.search(r"[A-Za-z]", s):
        s = re.sub(r"[\s/.,]+", "-", s)
        s = re.sub(r"(?<=\d)(?=[A-Za-z])|(?<=[A-Za-z])(?=\d)", "-", s)
        s = re.sub(r"-+", "-", s).strip("-")
        fmts = ["%d-%b-%Y", "%d-%B-%Y", "%d-%b-%y", "%d-%B-%y"]
    else:
        s = re.sub(r"[/.]", "-", s)
    for f in fmts:
        try:
            d = dt.datetime.strptime(s, f).date()
        except ValueError:
            continue
        if 1990 <= d.year <= dt.date.today().year + 1:
            return d
    return None


def strip_dates(line: str) -> tuple[str, list[dt.date]]:
    found: list[dt.date] = []
    for pat in DATE_PATTERNS:
        def repl(m):
            d = parse_date(m.group(0))
            if d is None:
                return m.group(0)
            found.append(d)
            return " "
        line = pat.sub(repl, line)
    return line, found


def parse_num(tok) -> float | None:
    """float for numbers, NaN for '-' placeholders, None if the token is not numeric."""
    t = str(tok).strip()
    for junk in ("₹", "Rs.", "Rs", "INR"):
        t = t.replace(junk, "")
    t = t.strip()
    if t in ("-", "–", "—"):
        return math.nan
    if not NUM_RE.match(t):
        return None
    neg = t.startswith("-") or (t.startswith("(") and t.endswith(")"))
    try:
        v = float(re.sub(r"[()%+\-,]", "", t))
    except ValueError:
        return None
    return -v if neg else v


# ---- header recognition ------------------------------------------------------
FIELD_PATTERNS = [
    ("ref", r"trade\s*(?:no|id|number)\.?|order\s*(?:no|id|number)\.?|exchange\s*order\s*id|trade\s*id"),
    ("sr", r"sr\.?\s*no\.?|s\.?\s*no\.?|sl\.?\s*no\.?|serial(?:\s*no\.?)?|#"),
    ("isin", r"isin(?:\s*code)?"),
    ("date", r"trade\s*date|order\s*date|txn\s*date|transaction\s*date|executed\s*(?:at|on)|date"),
    ("side", r"buy\s*/\s*sell|b\s*/\s*s|trade\s*type|transaction\s*type|order\s*type|txn\s*type|side|action"),
    ("avg", r"avg\.?\s*(?:buy\s*)?(?:cost|price|rate)|average\s*(?:buy\s*)?(?:cost|price|rate)|buy\s*avg\.?|"
            r"avg\.?\s*buy|cost\s*price|buy\s*price|acquisition\s*(?:cost|price)|purchase\s*price|avg\.?"),
    ("ltp", r"ltp|closing\s*price|close\s*price|market\s*price|current\s*price|cmp|last\s*price|"
            r"prev(?:ious)?\.?\s*close|closing\s*rate"),
    ("invested", r"invested(?:\s*value|\s*amount)?|buy\s*value|total\s*cost|cost\s*value|purchase\s*value|"
                 r"investment|acquisition\s*value|value\s*at\s*cost|buy\s*amount"),
    ("cur", r"cur\.?\s*val(?:ue)?|current\s*value|market\s*value|mkt\.?\s*value|present\s*value|closing\s*value|"
            r"value\s*at\s*market|value\s*as\s*on"),
    ("pnl", r"(?:unreali[sz]ed\s*)?(?:p\s*&\s*l|p\s*/\s*l|pnl|profit(?:\s*(?:and|&)\s*loss)?|gain|returns?)|unreali[sz]ed"),
    ("price", r"gross\s*rate|net\s*rate|trade\s*price|exec(?:uted)?\s*price|traded\s*price"),
    ("qty", r"qty\.?|quantity|units|shares|no\.?\s*of\s*shares|balance|holding"),
    ("value", r"net\s*total|net\s*amount|trade\s*value|amount|consideration|turnover"),
    ("other", r"net\s*chg\.?|day\s*chg\.?|net\s*change|day\s*change|chg\.?|change|pct|percent\w*|%|"
              r"brokerage|charges|tax\w*|stt|settlement|exposure"),
    ("textcol", r"sector|industry|exchange|segment|series|status|category|account|folio|dp\s*id"),
    ("value", r"total|value"),
    ("price", r"price|rate"),
    ("name", r"symbol|scrip|security|instrument|stock|company|name|script|asset|underlying"),
]
_seen: dict[str, int] = {}
_parts = []
for _f, _p in FIELD_PATTERNS:
    _seen[_f] = _seen.get(_f, 0) + 1
    _parts.append(f"(?P<{_f}{_seen[_f]}>{_p})")
HEADER_RE = re.compile(r"(?<![a-z])(?:" + "|".join(_parts) + r")(?![a-z])", re.I)
NON_NUMERIC_FIELDS = {"name", "date", "side", "isin", "textcol"}


def header_fields(text: str) -> list[str]:
    """Ordered canonical field names found in a header string."""
    text = re.sub(r"\s+", " ", text.replace("\n", " "))
    out = []
    for m in HEADER_RE.finditer(text):
        out.append(re.sub(r"\d+$", "", m.lastgroup))
    return out


def header_fields_by_cell(line: str) -> list[str] | None:
    """Layout-mode text separates columns with 2+ spaces: map each header cell to one field.

    Returns None when a cell is not recognised (the caller then falls back to header_fields)."""
    cells = [c for c in re.split(r"\s{2,}|\t", line.strip()) if c]
    if len(cells) < 3:
        return None
    out = []
    for c in cells:
        hf = header_fields(c)
        if not hf:
            return None
        out.append(hf[0])
    return out


def looks_like_header(fields: list[str], numeric_tokens: int) -> bool:
    return numeric_tokens == 0 and "qty" in fields and len(set(fields) - {"sr"}) >= 2


# ---- symbol resolution -------------------------------------------------------
_SERIES_RE = re.compile(r"(?:[-\s](?:EQ|BE|BZ|SM|ST|T0|N1|XT|BL))$|\.(?:NS|BO|BSE|NSE)$|^(?:NSE|BSE)[:\-\s]")


def strip_series(s: str) -> str:
    s = s.strip().upper()
    prev = None
    while prev != s:
        prev, s = s, _SERIES_RE.sub("", s).strip()
    return s


def norm_name(s: str) -> str:
    s = s.lower().replace("&", " and ")
    s = re.sub(r"\b(limited|ltd|the|inc|corporation|corp|company|co)\b", " ", s)
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", s)).strip()


class SymbolResolver:
    """Maps whatever the PDF calls a stock (symbol, name, 'TCS-EQ'...) to an NSE symbol."""

    def __init__(self, universe: pd.DataFrame | None = None):
        universe = universe if universe is not None else pd.DataFrame(columns=["Symbol", "Name"])
        self.symbols = set(universe["Symbol"].astype(str))
        self.by_name = {norm_name(n): s for s, n in zip(universe["Symbol"], universe["Name"])}
        self.names = list(self.by_name)

    def resolve(self, candidates: list[str]) -> tuple[str, bool]:
        runs = [c.strip() for c in candidates if c and c.strip()]
        for run in runs:
            s = strip_series(run)
            for v in (s, s.replace(" ", "")):
                if v in self.symbols:
                    return v, True
        for run in runs:
            n = norm_name(run)
            if n in self.by_name:
                return self.by_name[n], True
        for run in runs:
            for tok in run.split():
                s = strip_series(tok)
                if len(s) >= 2 and s in self.symbols:
                    return s, True
        for run in runs:
            n = norm_name(run)
            if len(n) >= 5:
                pre = [k for k in self.names if k.startswith(n)]
                if len(pre) == 1:
                    return self.by_name[pre[0]], True
                m = difflib.get_close_matches(n, self.names, n=1, cutoff=0.88)
                if m:
                    return self.by_name[m[0]], True
        for run in runs[:1]:
            tok = strip_series(run.split()[0]) if run.split() else ""
            if re.fullmatch(r"[A-Z][A-Z0-9&\-]{1,19}", tok) and run.split()[0].isupper():
                return tok, False
        return "", False


# ---- PDF text extraction -----------------------------------------------------
def _needs_password(exc: Exception) -> bool:
    msg = f"{type(exc).__name__} {exc}".lower()
    return "password" in msg or "encrypt" in msg or "decrypt" in msg


def extract_variants(path: str, password: str | None = None) -> list[tuple[str, list[str], list]]:
    """Return [(extractor name, text lines, tables)] using every extractor that works."""
    variants: list[tuple[str, list[str], list]] = []
    password_problem = False
    try:
        import pdfplumber                                   # optional, best quality
        lines, tables = [], []
        with pdfplumber.open(path, password=password or "") as pdf:
            for page in pdf.pages:
                lines += (page.extract_text() or "").splitlines()
                for tb in page.extract_tables() or []:
                    tables.append(tb)
        variants.append(("pdfplumber", lines, tables))
    except ImportError:
        pass
    except Exception as exc:                                # noqa: BLE001
        password_problem = password_problem or _needs_password(exc)
    try:
        from pypdf import PdfReader
        reader = PdfReader(path)
        if reader.is_encrypted and not reader.decrypt(password or ""):
            raise PdfPasswordNeeded("encrypted")
        for label, kw in (("pypdf-layout", {"extraction_mode": "layout"}), ("pypdf", {})):
            lines = []
            for page in reader.pages:
                try:
                    lines += (page.extract_text(**kw) or "").splitlines()
                except TypeError:
                    break
            if lines:
                variants.append((label, lines, []))
    except PdfPasswordNeeded:
        password_problem = True
    except ImportError:
        if not variants:
            raise PdfError("No PDF library found. Run:  pip install pypdf pdfplumber")
    except Exception as exc:                                # noqa: BLE001
        password_problem = password_problem or _needs_password(exc)
        if not variants:
            raise PdfError(f"Could not read this PDF: {exc}")
    if not variants:
        if password_problem:
            raise PdfPasswordNeeded("password required or wrong")
        raise PdfError("No readable text found. Scanned/image-only PDFs are not supported.")
    return variants


def find_doc_date(lines: list[str]) -> dt.date | None:
    key = re.compile(r"trade\s*date|contract\s*note|date\s*[:\-]|as\s+(?:on|of)|statement\s*date|settlement\s*date", re.I)
    for ln in lines[:80]:
        if key.search(ln):
            _, ds = strip_dates(ln)
            if ds:
                return ds[0]
    for ln in lines[:40]:
        _, ds = strip_dates(ln)
        if ds:
            return ds[0]
    return None


# ---- raw rows -> clean records -------------------------------------------------
def _is_id(tok: str) -> bool:
    return bool(re.fullmatch(r"\d{10,}", tok.strip()))


def infer_holding_numbers(nums: list[float]) -> dict:
    """Header-less holdings row: find qty / avg cost by checking the arithmetic between columns."""
    n = len(nums)
    ok = lambda a, b: abs(a - b) <= max(0.5, 0.006 * abs(b))                       # noqa: E731
    for i in range(n):
        for j in range(n):
            for k in range(n):
                if len({i, j, k}) == 3 and nums[i] > 0 and nums[j] > 0 and nums[k] > 0 and ok(nums[i] * nums[j], nums[k]):
                    ltp = nums[j + 1] if j + 1 < n and j + 1 != k else math.nan
                    return {"qty": nums[i], "avg": nums[j], "invested": nums[k], "ltp": ltp}
    for i in range(n):
        for j in range(n):
            for m in range(n):
                for k in range(n):
                    if len({i, j, m, k}) == 4 and nums[i] > 0 and nums[j] > 0 and nums[m] > 0 and nums[k] != 0 \
                            and ok(nums[i] * (nums[m] - nums[j]), nums[k]):
                        return {"qty": nums[i], "avg": nums[j], "ltp": nums[m]}
    out = {"qty": nums[0] if n else math.nan, "avg": nums[1] if n > 1 else math.nan}
    if n > 2:
        out["ltp"] = nums[2]
    return out


def raw_from_line(line: str, mode: str, fields: list[str] | None) -> dict | None:
    """Turn one text line into a raw row dict (names, side, date, numeric fields) or None."""
    text, dates = strip_dates(line)
    text = TIME_RE.sub(" ", text)
    isin_m = ISIN_RE.search(text)
    text = ISIN_RE.sub(" ", text)
    side = None
    names_runs: list[list[str]] = [[]]
    nums_all: list[tuple[str, float]] = []
    for tok in text.split():
        v = parse_num(tok)
        if v is not None:
            nums_all.append((tok, v))
            if names_runs[-1]:
                names_runs.append([])
            continue
        up = tok.upper().strip(",;|")
        if mode == "trades" and up in SIDE_WORDS and side is None:
            side = SIDE_WORDS[up]
            if names_runs[-1]:
                names_runs.append([])
            continue
        if up in DROP_TOKENS or not up or up in {"|", "/"}:
            continue
        names_runs[-1].append(tok.strip("|"))
    runs = [" ".join(r) for r in names_runs if r]
    if not runs or not any(ch.isalpha() for ch in runs[0]):
        return None
    joined_all = " ".join(runs)
    if JUNK_LINE.match(joined_all) or len(joined_all.split()) > 9:
        return None

    raw: dict = {"names": [runs[0], joined_all], "side": side, "date": dates[0] if dates else None,
                 "isin": isin_m.group(0) if isin_m else "", "guessed": False}
    ids = [t for t, _ in nums_all if _is_id(t)]
    if ids:
        raw["ref"] = ids[0]
    num_fields = [f for f in (fields or []) if f not in NON_NUMERIC_FIELDS]
    used = False
    if num_fields:
        vals = [v for _, v in nums_all]
        noid = [v for t, v in nums_all if not _is_id(t)]
        nf_noref = [f for f in num_fields if f != "ref"]
        if len(vals) == len(num_fields):
            pairs = list(zip(num_fields, vals))
            used = True
        elif len(noid) == len(nf_noref):
            pairs = list(zip(nf_noref, noid))
            used = True
        if used:
            for f, v in pairs:
                if f not in raw or (isinstance(raw[f], float) and math.isnan(raw[f])):
                    raw[f] = v
    if not used:
        noid = [v for t, v in nums_all if not _is_id(t) and not math.isnan(v)]
        if mode == "holdings":
            if len(noid) < 2:
                return None
            raw.update(infer_holding_numbers(noid))
        else:
            if len(noid) < 2:
                return None
            raw["qty"], raw["price"] = noid[0], noid[1]
        raw["guessed"] = True
    return raw


def _clean(v):
    return None if v is None or (isinstance(v, float) and math.isnan(v)) else v


def finalize_trade(raw: dict, doc_date: dt.date | None) -> dict | None:
    qty, price = _clean(raw.get("qty")), _clean(raw.get("price"))
    if price is None:
        price = _clean(raw.get("avg"))
    value = _clean(raw.get("value"))
    if (price is None or price == 0) and value and qty:
        price = abs(value) / abs(qty)
    if not qty or not price:
        return None
    notes = []
    side = raw.get("side")
    if qty < 0:
        side = side or "SELL"
    if side is None:
        side = "BUY"
        notes.append("side not found, assumed BUY")
    date = raw.get("date") or doc_date
    if raw.get("date") is None:
        notes.append("date taken from document header" if doc_date else "no date found, today used")
    if raw.get("guessed"):
        notes.append("columns guessed, please verify")
    return {"side": side, "qty": abs(qty), "price": abs(price), "date": date or dt.date.today(),
            "ref": str(raw.get("ref") or ""), "names": raw["names"], "isin": raw.get("isin", ""), "note": "; ".join(notes)}


def finalize_holding(raw: dict, doc_date: dt.date | None) -> dict | None:
    qty = _clean(raw.get("qty"))
    if not qty or qty <= 0:
        return None
    avg, ltp = _clean(raw.get("avg")), _clean(raw.get("ltp"))
    inv, cur = _clean(raw.get("invested")), _clean(raw.get("cur"))
    if not avg and inv:
        avg = inv / qty
    if not ltp and cur:
        ltp = cur / qty
    if not avg and ltp and _clean(raw.get("pnl")) is not None:
        avg = ltp - raw["pnl"] / qty
    if not avg or avg <= 0:
        return None
    notes = ["columns guessed, please verify"] if raw.get("guessed") else []
    return {"qty": qty, "avg": abs(avg), "ltp": ltp if ltp and ltp > 0 else math.nan,
            "date": raw.get("date") or doc_date or dt.date.today(), "names": raw["names"],
            "isin": raw.get("isin", ""), "note": "; ".join(notes)}


def records_from_lines(lines: list[str], mode: str, doc_date) -> list[dict]:
    fields: list[str] | None = None
    out = []
    fin = finalize_trade if mode == "trades" else finalize_holding
    for line in lines:
        line = line.strip()
        if not line:
            continue
        stripped, _ = strip_dates(line)
        n_numeric = sum(1 for t in stripped.split() if parse_num(t) is not None)
        hf = header_fields(line)
        if looks_like_header(hf, n_numeric):
            by_cell = header_fields_by_cell(line)
            fields = by_cell if by_cell and looks_like_header(by_cell, 0) else hf
            continue
        raw = raw_from_line(line, mode, fields)
        if raw:
            rec = fin(raw, doc_date)
            if rec:
                out.append(rec)
    return out


def records_from_tables(tables: list, mode: str, doc_date) -> list[dict]:
    """pdfplumber tables: header row maps columns, data rows are read cell by cell."""
    out = []
    fin = finalize_trade if mode == "trades" else finalize_holding
    colmap: dict[int, str] = {}
    ncols = 0
    for table in tables:
        for row in table:
            cells = [re.sub(r"\s+", " ", str(c or "")).strip() for c in row]
            if not any(cells):
                continue
            fields_by_col = {}
            for i, c in enumerate(cells):
                hf = header_fields(c) if c else []
                if hf:
                    fields_by_col[i] = hf[0]
            if "qty" in fields_by_col.values() and len(set(fields_by_col.values()) - {"sr"}) >= 2 \
                    and all(parse_num(c) is None for c in cells if c):
                colmap, ncols = fields_by_col, len(cells)
                continue
            if not colmap or len(cells) != ncols:
                continue
            raw: dict = {"side": None, "date": None, "isin": "", "guessed": False}
            texts = []
            for i, c in enumerate(cells):
                f = colmap.get(i)
                if not c or f is None:
                    continue
                if f == "name":
                    texts.append(c)
                elif f == "side":
                    raw["side"] = SIDE_WORDS.get(c.upper().strip())
                elif f == "date":
                    raw["date"] = strip_dates(c)[1][0] if strip_dates(c)[1] else parse_date(c)
                elif f == "isin":
                    raw["isin"] = c
                elif f == "ref":
                    raw["ref"] = c
                elif f not in NON_NUMERIC_FIELDS and f != "sr":
                    v = parse_num(c)
                    if v is not None and (f not in raw or math.isnan(raw[f])):
                        raw[f] = v
            if not texts or JUNK_LINE.match(texts[0]):
                continue
            raw["names"] = [texts[0], " ".join(texts)]
            rec = fin(raw, doc_date)
            if rec:
                out.append(rec)
    return out


def merge_holdings(rows: list[dict]) -> list[dict]:
    """Same symbol on several lines/pages -> one row with weighted-average cost."""
    merged: dict[str, dict] = {}
    for r in rows:
        key = r["symbol"] or f"?{len(merged)}"
        if key in merged and r["symbol"]:
            m = merged[key]
            q = m["qty"] + r["qty"]
            prior_avg = m["avg"]
            m["avg"] = (m["qty"] * m["avg"] + r["qty"] * r["avg"]) / q
            if "invested" in m or "invested" in r:
                m["invested"] = m.get("invested", m["qty"] * prior_avg) + r.get("invested", r["qty"] * r["avg"])
            m["qty"] = q
            if pd.isna(m["ltp"]):
                m["ltp"] = r["ltp"]
            m["note"] = "; ".join(x for x in (m["note"], "merged duplicate lines") if x)
        else:
            merged[key] = dict(r)
    return list(merged.values())


def bonanza_records(path, mode, password):
    """Read report columns by their PDF coordinates so empty cells stay empty."""
    import pdfplumber

    holdings = mode == "holdings"
    named_report = Path(path).name.lower().startswith("portfolio" if holdings else "cn_")
    recognized = False
    records = []
    doc_date = None
    note_number = None
    try:
        with pdfplumber.open(path, password=password or "") as pdf:
            for page in pdf.pages:
                lines = page.extract_text_lines()
                active = False
                boundary = None
                for line in lines:
                    text = line["text"]
                    if holdings:
                        date_match = re.search(r"Run Date\s*:\s*([\d/\-]+)", text, re.I)
                        if date_match:
                            doc_date = parse_date(date_match[1]) or doc_date
                        header = re.search(r"Net\s+Qty\s+Net\s+Value\s+Avg\b", text, re.I)
                        if header:
                            recognized = active = True
                            header_words = pdfplumber.utils.extract_words(line["chars"])
                            start = next(i for i, word in enumerate(header_words)
                                         if word["text"].lower().startswith("net"))
                            boundaries = [word["x1"] for word in header_words[start:] if
                                          re.sub(r"\s+", "", word["text"].lower()) in ("netqty", "netvalue", "avg")]
                            if len(boundaries) != 3:
                                # Text layers with explicit spaces split the two Net headings.
                                boundaries = []
                                for i in range(start, len(header_words)):
                                    if header_words[i]["text"].lower() == "net":
                                        boundaries.append(header_words[i + 1]["x1"])
                                boundaries.append(next(word["x1"] for word in header_words[start:]
                                                       if word["text"].lower() == "avg"))
                            continue
                        if not active:
                            continue
                        code = re.match(r"^([A-Z0-9&./-]+)\s", text, re.I)
                        if not code:
                            continue
                    else:
                        date_match = re.search(r"Trade\s+Date\s*:?\s*([\d/\-]+)", text, re.I)
                        if date_match:
                            doc_date = parse_date(date_match[1]) or doc_date
                        ref_match = re.search(r"Contract\s+Note\s+No\.?\s*:\s*([\w/-]+)", text, re.I)
                        if ref_match:
                            note_number = ref_match[1]
                        if text.lower() == "equity segment summary":
                            recognized = active = True
                            continue
                        if active and re.search(r"Net Quantity\s*\(", text, re.I):
                            boundary = line["chars"][-1]["x1"]
                            continue
                        if re.search(r"annexure|indicates trades|applicable only|^exch\s+order", text, re.I):
                            active = False
                        code = re.match(r"^((?:IN)[A-Z0-9]{10})\s", text)
                        if not active or not code:
                            continue
                    words = page.crop((0, line["top"] - 1, page.width, line["bottom"] + 1)).extract_words()
                    if len(words) < 3:
                        continue
                    if holdings:
                        # The three values are right aligned just beyond their header labels.
                        limits = [(edge - 5, edge + 18) for edge in boundaries]
                        numeric = [next((parse_num(w["text"]) for w in words if lo < w["x1"] < hi), None)
                                   for lo, hi in limits]
                        if any(v is None or not math.isfinite(v) or v <= 0 for v in numeric):
                            continue
                        qty, invested, avg = numeric
                        name = " ".join(w["text"] for w in words[1:] if w["x0"] < page.width * .21)
                        if name and doc_date:
                            records.append(dict(names=[name], broker_code=code[1], qty=qty, invested=invested, avg=avg,
                                                ltp=math.nan, date=doc_date, note=""))
                        continue
                    if not doc_date or not note_number:
                        raise PdfError("The Equity Segment Summary is missing its contract number or trade date.")
                    if boundary is None or abs(words[-2]["x1"] - boundary) >= 5 or words[-1]["x0"] <= boundary:
                        raise PdfError(f"Could not read the Net Obligation columns for {code[1]}.")
                    qty, value = [parse_num(w["text"]) for w in words[-2:]]
                    if any(v is None or not math.isfinite(v) for v in (qty, value)):
                        raise PdfError(f"Invalid Net Obligation for {code[1]}.")
                    if qty == 0:
                        continue
                    if value == 0 or (qty > 0) != (value > 0):
                        raise PdfError(f"Net Obligation quantity and value disagree for {code[1]}.")
                    name = " ".join(w["text"] for w in words[1:-2] if w["x0"] < page.width * .21)
                    records.append(dict(names=[name], isin=code[1], side="BUY" if qty > 0 else "SELL",
                                        qty=abs(qty), price=abs(value / qty), date=doc_date,
                                        ref=f"BONANZA:{note_number}:{doc_date}:{code[1]}", note=""))
    except Exception as exc:
        if _needs_password(exc):
            raise PdfPasswordNeeded(str(exc)) from exc
        raise
    if named_report or recognized:
        return records, doc_date
    return None


class BrokerSymbolResolver:
    def __init__(self, resolver):
        self.by_isin = {}
        self.candidates = list(resolver.by_name.items())
        directories = (
            "content/equities/EQUITY_L.csv",
            "emerge/corporates/content/SME_EQUITY_L.csv",
            "content/equities/eq_etfseclist.csv",
        )
        with ThreadPoolExecutor(max_workers=len(directories)) as pool:
            for rows in pool.map(self.read_directory, directories):
                for sym, name, isin in rows:
                    self.candidates.append((norm_name(name), sym))
                    if isin:
                        self.by_isin[isin] = sym
        self.symbols = {sym for _, sym in self.candidates}

    @staticmethod
    def read_directory(path):
        cache = CACHE_DIR / Path(path).name
        try:
            if not cache.exists() or time.time() - cache.stat().st_mtime > 7 * 86400:
                request = urllib.request.Request(f"https://archives.nseindia.com/{path}",
                                                 headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(request, timeout=7) as response:
                    data = response.read()
                if b"SYMBOL" in data[:100].upper() and b"ISIN" in data[:200].upper():
                    cache.parent.mkdir(parents=True, exist_ok=True)
                    atomic_write(cache, data)
        except OSError:
            pass
        rows = []
        try:
            with cache.open(encoding="utf-8-sig") as stream:
                for row in csv.DictReader(stream, skipinitialspace=True):
                    fields = {re.sub(r"[^A-Z]", "", k.upper()): v.strip() for k, v in row.items() if k and v}
                    sym = fields.get("SYMBOL")
                    name = fields.get("NAMEOFCOMPANY") or fields.get("SECURITYNAME")
                    if sym and name:
                        rows.append((sym, name, fields.get("ISINNUMBER")))
        except (OSError, UnicodeError, csv.Error):
            pass
        return rows

    def resolve(self, rec):
        aliases = {"INE466L01038": "360ONE", "INE931S01010": "ADANIENSOL",
                   "INE296A01032": "BAJFINANCE", "INE118H01025": "BSE",
                   "INE758T01015": "ETERNAL", "INE338I01027": "MOTILALOFS",
                   "INF204KB14I2": "NIFTYBEES"}
        isin = rec.get("isin")
        name = rec["names"][0]
        normalized = norm_name(name)
        abbreviated = re.sub(r"\s+(?:l|li|lim|limi|limit|limite)$", "", normalized)
        compact = lambda value: value.replace(" ", "")
        broker_code = strip_series(rec.get("broker_code", ""))
        symbol = self.by_isin.get(isin) or aliases.get(isin)
        if not symbol and broker_code in self.symbols:
            symbol = broker_code
        if symbol:
            return symbol
        # The broker truncates long descriptions. Require a unique name or prefix.
        exact = {sym for n, sym in self.candidates if compact(n) == compact(normalized)}
        prefixes = {sym for n, sym in self.candidates if len(compact(abbreviated)) >= 8
                    and compact(n).startswith(compact(abbreviated))}
        for matches in (exact, prefixes):
            if len(matches) == 1:
                return next(iter(matches))
        quotes = {}
        for query in dict.fromkeys(filter(None, (isin, name))):
            try:
                results = yf.Search(query, max_results=8, news_count=0, timeout=6).quotes
            except Exception:
                continue
            for quote in results:
                ticker = str(quote.get("symbol", ""))
                if ticker.endswith((".NS", ".BO")):
                    sym = ticker.removesuffix(".NS")
                    label = quote.get("longname") or quote.get("shortname") or ticker
                    quotes[sym] = label
                    if isin and query == isin:
                        continue
                    n = norm_name(label)
                    if compact(n) == compact(abbreviated) or (
                            len(compact(abbreviated)) >= 8 and compact(n).startswith(compact(abbreviated))):
                        exact.add(sym)
            if query == isin and len(quotes) == 1:
                return next(iter(quotes))
        if len(exact) == 1:
            return next(iter(exact))
        key = os.environ.get("OPENAI_API_KEY")
        if key:
            names = sorted(set(self.candidates))
            closest = difflib.get_close_matches(normalized, sorted({n for n, _ in names}), n=8, cutoff=0.55)
            for n, sym in names:
                if n in closest:
                    quotes.setdefault(sym, n)
        if key and quotes:
            payload = {"model": "gpt-4o-mini", "messages": [
                {"role": "system", "content": "Match an Indian broker's security description to the supplied tickers. Reply with exactly one supplied ticker, or UNKNOWN if uncertain."},
                {"role": "user", "content": json.dumps({"security": name, "candidates": quotes})}]}
            request = urllib.request.Request("https://api.openai.com/v1/chat/completions",
                                             data=json.dumps(payload).encode(),
                                             headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
            try:
                with urllib.request.urlopen(request, timeout=10) as response:
                    answer = json.load(response)["choices"][0]["message"]["content"].strip()
                if answer in quotes:
                    return answer
            except (OSError, ValueError, KeyError, IndexError, AttributeError):
                pass
        return ""


def parse_pdf(path: str, mode: str, resolver: SymbolResolver, password: str | None = None) -> dict:
    """mode: 'trades' or 'holdings'.  Returns {'rows': [...], 'doc_date': date|None, 'extractor': str}."""
    broker = bonanza_records(path, mode, password)
    if broker is not None:
        rows, doc_date = broker
        if rows:
            broker_resolver = BrokerSymbolResolver(resolver)
            with ThreadPoolExecutor(max_workers=8) as pool:
                for row, symbol in zip(rows, pool.map(broker_resolver.resolve, rows)):
                    row.update(symbol=symbol, note=row["names"][0])
        return {"rows": rows, "doc_date": doc_date, "extractor": "Bonanza report"}
    variants = extract_variants(path, password)
    best_key, label, recs, doc_date = (-1, -1), "", [], None
    for lab, lines, tables in variants:
        dd = find_doc_date(lines)
        found = records_from_tables(tables, mode, dd) if tables else []
        if not found:
            found = records_from_lines(lines, mode, dd)
        # prefer the reader that understood the most rows without having to guess columns
        key = (sum(1 for r in found if "guessed" not in r["note"]), len(found))
        if key > best_key:
            best_key, label, recs, doc_date = key, lab, found, dd
    rows = []
    for rec in recs:
        sym, known = resolver.resolve(rec["names"])
        if not sym and len(rec["names"][0].split()) > 4:
            continue                      # a sentence from the PDF, not a stock name
        rec = dict(rec, symbol=sym, known=known)
        if not sym:
            rec["note"] = "; ".join(x for x in (rec["note"], "symbol not recognised") if x)
        rows.append(rec)
    if mode == "holdings":
        rows = merge_holdings(rows)
    return {"rows": rows, "doc_date": doc_date, "extractor": label}


def install_pdf_reader():
    """Install the reader using the interpreter that launched the screener."""
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--no-input", "pdfplumber>=0.11.0"],
        capture_output=True, text=True, errors="replace", timeout=180,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    if result.returncode:
        message = (result.stderr or result.stdout).strip()
        raise PdfError(message[-1400:] or "pip could not install pdfplumber.")
    user_site = site.getusersitepackages()
    if site.ENABLE_USER_SITE and user_site not in sys.path and Path(user_site).is_dir():
        site.addsitedir(user_site)
    importlib.invalidate_caches()
    try:
        importlib.import_module("pdfplumber")
    except ImportError as exc:
        raise PdfError("The reader was installed. Restart the screener and try the PDF again.") from exc


class PdfTaskWorker(QThread):
    def __init__(self, task, *args):
        super().__init__()
        self.task = task
        self.args = args
        self.result = None
        self.error = None

    def run(self):
        try:
            self.result = self.task(*self.args)
        except Exception as exc:
            self.error = exc


# =============================================================================
# 6. UI
# =============================================================================
class AppState:
    """Shared data that every tab reads."""

    def __init__(self):
        self.db = Database()
        self.universe = pd.DataFrame(columns=["Symbol", "Name", "Sector"])
        self.prices: dict = {}
        self.indices: dict = {}
        self.fundamentals: dict = {}
        self.updated: float | None = None
        self.master = build_master(self.universe, {}, {})
        self.portfolio_metrics = self.master.copy()
        self.portfolio_history = {}
        self.extra: dict[str, dict] = self.db.extra_prices()     # holdings outside the Nifty 500 download
        self.cap_class: dict[str, str] = {}

    def load(self, payload: dict):
        self.universe, self.prices = payload["universe"], payload["prices"]
        self.indices, self.fundamentals = payload["indices"], payload["fundamentals"]
        self.updated = payload["updated"]
        self.master = build_master(self.universe, self.prices, self.fundamentals)
        # SEBI-style buckets by market-cap rank inside the Nifty 500: top 100 large, next 150 mid, rest small
        ranked = self.master["mcap"].dropna().sort_values(ascending=False).index.tolist() if len(self.master) else []
        self.cap_class = {s: ("Large cap" if i < 100 else "Mid cap" if i < 250 else "Small cap")
                          for i, s in enumerate(ranked)}

    def reload_extra(self):
        self.extra = self.db.extra_prices()

    def last_price(self, sym: str) -> float:
        quote = self.extra.get(sym, {})
        if quote.get("yahoo") and not pd.isna(quote["price"]):
            return quote["price"]
        df = self.prices.get(sym)
        return float(df["Close"].iloc[-1]) if df is not None and len(df) else math.nan

    def prev_close(self, sym: str) -> float:
        quote = self.extra.get(sym, {})
        if quote.get("yahoo") and not pd.isna(quote["prev"]):
            return quote["prev"]
        df = self.prices.get(sym)
        return float(df["Close"].iloc[-2]) if df is not None and len(df) >= 2 else math.nan

    def sector_of(self, sym: str) -> str:
        if sym in self.master.index:
            return str(self.master.at[sym, "sector"] or "Unclassified")
        return self.extra.get(sym, {}).get("sector") or "Unclassified"

    def name_of(self, sym: str) -> str:
        for frame in (self.master, self.portfolio_metrics):
            if sym in frame.index:
                return str(frame.at[sym, "name"])
        return sym

    def cap_of(self, sym: str) -> str:
        return self.cap_class.get(sym, "Unclassified")

    def symbols(self) -> list[str]:
        return sorted(self.master.index.tolist()) if len(self.master) else []


# ---- small helpers ----------------------------------------------------------
def fmt(x, d: int = 2, suffix: str = "", comma: bool = False) -> str:
    if x is None or pd.isna(x):
        return "–"
    return f"{x:,.{d}f}{suffix}" if comma else f"{x:.{d}f}{suffix}"


def color_for(x) -> str | None:
    if x is None or pd.isna(x) or x == 0:
        return None
    return UP if x > 0 else DOWN


def score_color(s) -> str:
    return MUTED if pd.isna(s) else UP if s >= 70 else AMBER if s >= 50 else DOWN


class NumItem(QTableWidgetItem):
    """Table item that sorts by number, with blanks last when sorting descending."""

    def __init__(self, text: str, value=None, color: str | None = None):
        super().__init__(text)
        self.value = -math.inf if value is None or pd.isna(value) else float(value)
        self.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        if color:
            self.setForeground(QBrush(QColor(color)))

    def __lt__(self, other):
        if isinstance(other, NumItem):
            return self.value < other.value
        return super().__lt__(other)


def make_table(sortable: bool = True) -> QTableWidget:
    t = QTableWidget()
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setAlternatingRowColors(True)
    t.verticalHeader().setVisible(False)
    t.verticalHeader().setDefaultSectionSize(26)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
    t.horizontalHeader().setStretchLastSection(True)
    t.setSortingEnabled(sortable)
    return t


COMMA_KEYS = {"price", "mcap", "avg", "ltp", "invested", "value"}


def populate(table: QTableWidget, df: pd.DataFrame, spec: list[tuple]):
    """spec rows: (header, key, kind, decimals); kind in text/num/pct/score."""
    table.setSortingEnabled(False)
    table.clear()
    table.setColumnCount(len(spec))
    table.setHorizontalHeaderLabels([s[0] for s in spec])
    table.setRowCount(len(df))
    for r, rec in enumerate(df.to_dict("records")):
        for c, (_, key, kind, d) in enumerate(spec):
            v = rec.get(key)
            if kind == "text":
                item = QTableWidgetItem("" if v is None else str(v))
            elif kind == "pct":
                item = NumItem(fmt(v, d, "%"), v, color_for(v))
            elif kind == "score":
                item = NumItem(fmt(v, 0), v, score_color(v))
            elif kind == "cnum":                      # number coloured green/red
                item = NumItem(fmt(v, d, comma=True), v, color_for(v))
            elif kind == "pct0":                      # percentage without colour
                item = NumItem(fmt(v, d, "%"), v)
            elif key == "qty":
                item = NumItem(fmt_qty(v), v)
            else:
                item = NumItem(fmt(v, d, comma=(d == 0 or key in COMMA_KEYS)), v)
            table.setItem(r, c, item)
    table.setSortingEnabled(True)


def make_completer(edit: QLineEdit) -> QStringListModel:
    model = QStringListModel([])
    comp = QCompleter(model, edit)
    comp.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
    comp.setFilterMode(Qt.MatchFlag.MatchContains)
    edit.setCompleter(comp)
    return model


def clean_symbol(text: str) -> str:
    return text.strip().upper().replace(".NS", "")


# ---- Dashboard --------------------------------------------------------------
GL_SPEC = [("Symbol", "symbol", "text", 0), ("Name", "name", "text", 0),
           ("Price (₹)", "price", "num", 2), ("1D %", "chg", "pct", 2)]


class DashboardTab(QWidget):
    openStock = pyqtSignal(str)

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        lay = QVBoxLayout(self)
        cards = QHBoxLayout()
        self.cards: dict[str, tuple[QLabel, QLabel]] = {}
        for name in INDICES:
            frame = QFrame()
            frame.setObjectName("card")
            fl = QVBoxLayout(frame)
            title = QLabel(name)
            title.setStyleSheet(f"color:{MUTED}; font-size:13px;")
            val = QLabel("–")
            val.setStyleSheet("font-size:26px; font-weight:bold;")
            chg = QLabel("–")
            chg.setStyleSheet("font-size:15px;")
            for w in (title, val, chg):
                fl.addWidget(w)
            self.cards[name] = (val, chg)
            cards.addWidget(frame)
        lay.addLayout(cards)

        tables = QHBoxLayout()
        self.gain_table, self.lose_table = make_table(False), make_table(False)
        for title, tbl in (("Top 10 gainers (1 day)", self.gain_table),
                           ("Top 10 losers (1 day)", self.lose_table)):
            box = QGroupBox(title)
            bl = QVBoxLayout(box)
            bl.addWidget(tbl)
            tables.addWidget(box)
            tbl.cellDoubleClicked.connect(lambda r, c, t=tbl: self.openStock.emit(t.item(r, 0).text()))
        lay.addLayout(tables, 1)
        self.note = QLabel("Double-click a stock to open it.")
        self.note.setStyleSheet(f"color:{MUTED};")
        lay.addWidget(self.note)

    def refresh(self):
        for name, (val, chg) in self.cards.items():
            df = self.state.indices.get(name)
            if df is None or len(df) < 2:
                val.setText("–")
                chg.setText("no data")
                continue
            last, prev = float(df["Close"].iloc[-1]), float(df["Close"].iloc[-2])
            pct = (last / prev - 1) * 100
            col = UP if pct >= 0 else DOWN
            val.setText(f"{last:,.2f}")
            chg.setText(f"{'▲' if pct >= 0 else '▼'} {last - prev:+,.2f}  ({pct:+.2f}%)")
            chg.setStyleSheet(f"font-size:15px; color:{col};")
        m = self.state.master.dropna(subset=["chg"])
        populate(self.gain_table, m.nlargest(10, "chg"), GL_SPEC)
        populate(self.lose_table, m.nsmallest(10, "chg"), GL_SPEC)
        self.gain_table.sortByColumn(3, Qt.SortOrder.DescendingOrder)
        self.lose_table.sortByColumn(3, Qt.SortOrder.AscendingOrder)


# ---- Screener ---------------------------------------------------------------
FILTERS = [("P/E", "pe"), ("ROE %", "roe"), ("Debt/Equity", "de"), ("Sales growth %", "growth"),
           ("Dividend yield %", "div"), ("Market cap (₹ Cr)", "mcap"), ("RSI (14)", "rsi"),
           ("1-year return %", "ret1y")]

PRESETS = {   # key -> (min, max); None = no limit
    "Value": {"pe": (1, 18), "roe": (10, None), "div": (1, None)},
    "Quality": {"roe": (18, None), "de": (None, 0.5), "growth": (8, None)},
    "Growth": {"growth": (15, None), "roe": (12, None)},
    "Momentum": {"ret1y": (20, None), "rsi": (55, 75)},
}

SCREENER_SPEC = [("Symbol", "symbol", "text", 0), ("Name", "name", "text", 0),
                 ("Sector", "sector", "text", 0), ("Price (₹)", "price", "num", 2),
                 ("1D %", "chg", "pct", 2), ("Mkt Cap (₹ Cr)", "mcap", "num", 0),
                 ("P/E", "pe", "num", 1), ("ROE %", "roe", "num", 1), ("D/E", "de", "num", 2),
                 ("Sales Gr %", "growth", "num", 1), ("Div Yld %", "div", "num", 2),
                 ("RSI", "rsi", "num", 1), ("1Y %", "ret1y", "pct", 1), ("Score", "score", "score", 0)]


class ScreenerTab(QWidget):
    openStock = pyqtSignal(str)
    message = pyqtSignal(str)

    def __init__(self, state: AppState, portfolio_only: bool = False):
        super().__init__()
        self.state = state
        self.portfolio_only = portfolio_only
        self.result = pd.DataFrame()
        root = QHBoxLayout(self)

        side = QWidget()
        side.setFixedWidth(330)
        sl = QVBoxLayout(side)
        sl.setContentsMargins(0, 0, 8, 0)
        pbox = QGroupBox("Presets")
        pl = QHBoxLayout(pbox)
        for name in PRESETS:
            b = QPushButton(name)
            b.clicked.connect(lambda _, n=name: self.apply_preset(n))
            pl.addWidget(b)
        sl.addWidget(pbox)

        fbox = QGroupBox("Filters (leave blank for no limit)")
        grid = QGridLayout(fbox)
        grid.addWidget(QLabel(""), 0, 0)
        for col, text in ((1, "Min"), (2, "Max")):
            h = QLabel(text)
            h.setStyleSheet(f"color:{MUTED};")
            grid.addWidget(h, 0, col)
        self.edits: dict[str, tuple[QLineEdit, QLineEdit]] = {}
        for i, (label, key) in enumerate(FILTERS, start=1):
            lo, hi = QLineEdit(), QLineEdit()
            for e in (lo, hi):
                e.setPlaceholderText("any")
                e.returnPressed.connect(self.run)
            grid.addWidget(QLabel(label), i, 0)
            grid.addWidget(lo, i, 1)
            grid.addWidget(hi, i, 2)
            self.edits[key] = (lo, hi)
        grid.addWidget(QLabel("Sector"), len(FILTERS) + 1, 0)
        self.sector = QComboBox()
        self.sector.addItem("All sectors")
        grid.addWidget(self.sector, len(FILTERS) + 1, 1, 1, 2)
        sl.addWidget(fbox)

        row = QHBoxLayout()
        run = QPushButton("Run screen")
        run.setObjectName("primary")
        run.clicked.connect(self.run)
        reset = QPushButton("Reset")
        reset.clicked.connect(self.reset)
        row.addWidget(run)
        row.addWidget(reset)
        sl.addLayout(row)
        export = QPushButton("Export CSV...")
        export.clicked.connect(self.export_csv)
        sl.addWidget(export)
        self.count = QLabel("")
        self.count.setStyleSheet(f"color:{MUTED};")
        self.count.setWordWrap(True)
        sl.addWidget(self.count)
        hint = QLabel("D/E is ignored for banks and financial firms, where it isn't meaningful.\n"
                      "Double-click a row to open the stock.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{MUTED}; font-size:11px;")
        sl.addWidget(hint)
        sl.addStretch(1)
        root.addWidget(side)

        self.table = make_table()
        self.table.cellDoubleClicked.connect(lambda r, c: self.openStock.emit(self.table.item(r, 0).text()))
        root.addWidget(self.table, 1)
        self.sector.currentIndexChanged.connect(self.run)

    def stock_data(self):
        if not self.portfolio_only:
            return self.state.master
        positions, _ = compute_positions(self.state.db.trades())
        symbols = [sym for sym, pos in positions.items() if pos["qty"] > 1e-9]
        frame = self.state.master.reindex(symbols)
        for sym in symbols:
            if sym in self.state.portfolio_metrics.index:
                frame.loc[sym] = self.state.portfolio_metrics.loc[sym]
            if pd.isna(frame.at[sym, "symbol"]):
                frame.loc[sym, ["symbol", "name", "sector"]] = [
                    sym, self.state.name_of(sym), self.state.sector_of(sym)]
            frame.at[sym, "price"] = self.state.last_price(sym)
            quote = self.state.extra.get(sym, {})
            if quote.get("yahoo") and quote["prev"] > 0:
                frame.at[sym, "chg"] = (quote["price"] / quote["prev"] - 1) * 100
        return frame

    def refresh(self):
        current = self.sector.currentText()
        self.sector.blockSignals(True)
        self.sector.clear()
        self.sector.addItem("All sectors")
        df = self.stock_data()
        if len(df):
            self.sector.addItems(sorted(df["sector"].dropna().unique()))
        i = self.sector.findText(current)
        self.sector.setCurrentIndex(max(i, 0))
        self.sector.blockSignals(False)
        self.run()

    def apply_preset(self, name: str):
        self.reset(run=False)
        for key, (lo, hi) in PRESETS[name].items():
            self.edits[key][0].setText("" if lo is None else str(lo))
            self.edits[key][1].setText("" if hi is None else str(hi))
        self.run()

    def reset(self, run: bool = True):
        for lo, hi in self.edits.values():
            lo.clear()
            hi.clear()
        self.sector.blockSignals(True)
        self.sector.setCurrentIndex(0)
        self.sector.blockSignals(False)
        if run:
            self.run()

    @staticmethod
    def _parse(text: str):
        t = text.strip().replace(",", "")
        return float(t) if t else None

    def run(self, *_):
        df = self.stock_data()
        if df.empty:
            self.result = df
            populate(self.table, df, SCREENER_SPEC)
            self.count.setText("No stocks to screen")
            return
        mask = pd.Series(True, index=df.index)
        try:
            for key, (lo_e, hi_e) in self.edits.items():
                lo, hi = self._parse(lo_e.text()), self._parse(hi_e.text())
                if lo is None and hi is None:
                    continue
                ok = pd.Series(True, index=df.index)
                if lo is not None:
                    ok &= df[key] >= lo
                if hi is not None:
                    ok &= df[key] <= hi
                if key == "de":    # debt/equity doesn't apply to financial companies
                    ok |= (df["sector"] == FINANCIAL_SECTOR) & df[key].isna()
                mask &= ok
        except ValueError:
            self.message.emit("Filters must be numbers.")
            return
        if self.sector.currentIndex() > 0:
            mask &= df["sector"] == self.sector.currentText()
        self.result = df[mask].sort_values("score", ascending=False, na_position="last")
        populate(self.table, self.result, SCREENER_SPEC)
        self.table.sortByColumn(len(SCREENER_SPEC) - 1, Qt.SortOrder.DescendingOrder)
        self.count.setText(f"{len(self.result)} of {len(df)} stocks match")

    def export_csv(self):
        if self.result.empty:
            QMessageBox.information(self, "Export", "There are no results to export.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export results", "screener_results.csv", "CSV (*.csv)")
        if not path:
            return
        names = {key: head for head, key, _, _ in SCREENER_SPEC}
        out = self.result[list(names)].rename(columns=names)
        out.to_csv(path, index=False)
        self.message.emit(f"Exported {len(out)} rows to {path}")


# ---- Stock tab (chart + analysis) ------------------------------------------
class DateAxis(pg.AxisItem):
    """Bottom axis that shows dates for bar-index x values (no weekend gaps)."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.dates: list = []

    def tickStrings(self, values, scale, spacing):
        out = []
        for v in values:
            i = int(round(v))
            out.append(self.dates[i].strftime("%d %b %y") if 0 <= i < len(self.dates) else "")
        return out


class CandlestickItem(pg.GraphicsObject):
    def __init__(self, df: pd.DataFrame):
        super().__init__()
        self.picture = QPicture()
        self.rect = QRectF()
        self.set_data(df)

    def set_data(self, df: pd.DataFrame):
        opens, highs = df["Open"].tolist(), df["High"].tolist()
        lows, closes = df["Low"].tolist(), df["Close"].tolist()
        self.picture = QPicture()
        p = QPainter(self.picture)
        w = 0.35
        for i, (o, h, l, c) in enumerate(zip(opens, highs, lows, closes)):
            col = UP if c >= o else DOWN
            p.setPen(pg.mkPen(col))
            p.setBrush(pg.mkBrush(col))
            p.drawLine(QPointF(i, l), QPointF(i, h))
            p.drawRect(QRectF(i - w, o, 2 * w, c - o))
        p.end()
        lo, hi = min(lows), max(highs)
        self.prepareGeometryChange()
        self.rect = QRectF(-1, lo, len(closes) + 1, max(hi - lo, 1e-6))
        self.update()

    def paint(self, painter, *args):
        painter.drawPicture(0, 0, self.picture)

    def boundingRect(self):
        return self.rect


class StockTab(QWidget):
    watchChanged = pyqtSignal()

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        self.symbol: str | None = None
        self.df: pd.DataFrame | None = None
        root = QVBoxLayout(self)

        top = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText("Symbol, e.g. RELIANCE")
        self.search.setFixedWidth(220)
        self.search.returnPressed.connect(self.on_search)
        self.completer_model = make_completer(self.search)
        go = QPushButton("Open")
        go.setObjectName("primary")
        go.clicked.connect(self.on_search)
        self.watch_btn = QPushButton("☆ Add to watchlist")
        self.watch_btn.clicked.connect(self.toggle_watch)
        self.title = QLabel("Select a stock from the Screener or type a symbol.")
        self.title.setStyleSheet("font-size:16px; font-weight:bold;")
        for w in (self.search, go, self.watch_btn):
            top.addWidget(w)
        top.addWidget(self.title, 1)
        root.addLayout(top)

        split = QSplitter(Qt.Orientation.Horizontal)
        pg.setConfigOptions(antialias=True, background=BG, foreground=FG)
        self.glw = pg.GraphicsLayoutWidget()
        self.date_axis = DateAxis(orientation="bottom")
        self.p1 = self.glw.addPlot(row=0, col=0, axisItems={"bottom": self.date_axis})
        self.p2 = self.glw.addPlot(row=1, col=0)
        self.glw.ci.layout.setRowStretchFactor(0, 3)
        self.glw.ci.layout.setRowStretchFactor(1, 1)
        self.p2.setXLink(self.p1)
        for p in (self.p1, self.p2):
            p.showGrid(x=True, y=True, alpha=0.15)
            p.setMouseEnabled(x=True, y=False)
        self.p2.getAxis("bottom").setStyle(showValues=False)
        self.p1.getViewBox().sigXRangeChanged.connect(self._rescale_y)
        split.addWidget(self.glw)

        right = QWidget()
        rl = QVBoxLayout(right)
        rl.setContentsMargins(8, 0, 0, 0)
        self.score_lbl = QLabel("–")
        self.score_lbl.setStyleSheet("font-size:40px; font-weight:bold;")
        self.score_sub = QLabel("Score (0-100)")
        self.score_sub.setStyleSheet(f"color:{MUTED};")
        sbox = QHBoxLayout()
        sbox.addWidget(self.score_lbl)
        sbox.addWidget(self.score_sub, 1)
        rl.addLayout(sbox)
        self.fund = make_table(False)
        self.fund.setColumnCount(2)
        self.fund.horizontalHeader().setVisible(False)
        self.fund.setMaximumHeight(330)
        rl.addWidget(self.fund)
        self.notes = QTextBrowser()
        rl.addWidget(self.notes, 1)
        right.setMinimumWidth(340)
        split.addWidget(right)
        split.setStretchFactor(0, 4)
        split.setStretchFactor(1, 1)
        split.setSizes([900, 380])
        root.addWidget(split, 1)

    def refresh_symbols(self):
        self.completer_model.setStringList(self.state.symbols())
        if self.symbol and self.symbol in self.state.prices:
            self.load(self.symbol)

    def on_search(self):
        self.load(clean_symbol(self.search.text()))

    def toggle_watch(self):
        if not self.symbol:
            return
        if self.symbol in self.state.db.watchlist():
            self.state.db.remove_watch(self.symbol)
        else:
            self.state.db.add_watch(self.symbol)
        self._update_watch_btn()
        self.watchChanged.emit()

    def _update_watch_btn(self):
        on = bool(self.symbol) and self.symbol in self.state.db.watchlist()
        self.watch_btn.setText("★ In watchlist" if on else "☆ Add to watchlist")

    def load(self, sym: str):
        if sym in self.state.master.index:
            history, row = self.state.prices[sym], self.state.master.loc[sym]
        elif sym in self.state.portfolio_metrics.index:
            history, row = self.state.portfolio_history[sym], self.state.portfolio_metrics.loc[sym]
        else:
            QMessageBox.information(self, "Stock data unavailable", f"Market history for {sym} is unavailable.")
            return
        self.symbol = sym
        self.search.setText(sym)
        self.df = history
        self._update_watch_btn()
        col = color_for(row["chg"]) or FG
        self.title.setText(f"{row['name']} ({sym}) · ₹{row['price']:,.2f} "
                           f"<span style='color:{col}'>{row['chg']:+.2f}%</span> · {row['sector']}")
        self.title.setTextFormat(Qt.TextFormat.RichText)
        self._draw_chart()
        self._fill_analysis(row)

    def _draw_chart(self):
        df = self.df
        n = len(df)
        close = df["Close"]
        self.date_axis.dates = list(df.index)
        self.p1.clear()
        self.p2.clear()
        self.p1.addLegend(offset=(10, 10))
        self.p1.addItem(CandlestickItem(df))
        x = list(range(n))
        self.p1.plot(x, sma(close, 50).to_numpy(), pen=pg.mkPen(AMBER, width=1.6),
                     name="50-day avg", connect="finite")
        self.p1.plot(x, sma(close, 200).to_numpy(), pen=pg.mkPen("#b388ff", width=1.6),
                     name="200-day avg", connect="finite")
        self.p2.plot(x, rsi(close).to_numpy(), pen=pg.mkPen(ACCENT, width=1.4), connect="finite")
        for level in (30, 70):
            self.p2.addItem(pg.InfiniteLine(pos=level, angle=0, pen=pg.mkPen(MUTED, style=Qt.PenStyle.DashLine)))
        self.p2.setYRange(0, 100, padding=0)
        self.p2.setLabel("left", "RSI 14")
        self.p1.setLabel("left", "Price (₹)")
        self.p1.setXRange(max(0, n - 250), n + 3, padding=0)
        self._rescale_y()

    def _rescale_y(self, *_):
        if self.df is None:
            return
        x0, x1 = self.p1.getViewBox().viewRange()[0]
        n = len(self.df)
        lo, hi = max(0, int(x0)), min(n, int(x1) + 2)
        if hi <= lo:
            return
        seg = self.df.iloc[lo:hi]
        mn, mx = float(seg["Low"].min()), float(seg["High"].max())
        pad = (mx - mn) * 0.06 or 1
        self.p1.setYRange(mn - pad, mx + pad, padding=0)

    def _fill_analysis(self, row: pd.Series):
        score, good, bad = score_stock(row)
        self.score_lbl.setText(fmt(score, 0))
        self.score_lbl.setStyleSheet(f"font-size:40px; font-weight:bold; color:{score_color(score)};")
        verdict = ("Strong" if score >= 70 else "Mixed" if score >= 50 else "Weak") if not pd.isna(score) else "n/a"
        self.score_sub.setText(f"{verdict} overall · value, quality, growth, safety and trend")
        close = self.df["Close"]
        year = close.iloc[-252:]
        items = [("Price", fmt(row["price"], 2, " ₹", True)), ("Market cap", fmt(row["mcap"], 0, " Cr", True)),
                 ("P/E", fmt(row["pe"], 1)), ("P/B", fmt(row["pb"], 2)), ("ROE", fmt(row["roe"], 1, "%")),
                 ("Debt/Equity", "n/a (financial)" if row["sector"] == FINANCIAL_SECTOR else fmt(row["de"], 2)),
                 ("Sales growth (YoY)", fmt(row["growth"], 1, "%")), ("Earnings growth", fmt(row["eg"], 1, "%")),
                 ("Profit margin", fmt(row["margin"], 1, "%")), ("Dividend yield", fmt(row["div"], 2, "%")),
                 ("RSI (14)", fmt(row["rsi"], 1)), ("50-day avg", fmt(row["sma50"], 2)),
                 ("200-day avg", fmt(row["sma200"], 2)), ("1-year return", fmt(row["ret1y"], 1, "%")),
                 ("52-wk high / low", f"{year.max():,.1f} / {year.min():,.1f}")]
        self.fund.setRowCount(len(items))
        for r, (k, v) in enumerate(items):
            self.fund.setItem(r, 0, QTableWidgetItem(k))
            it = QTableWidgetItem(v)
            it.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            self.fund.setItem(r, 1, it)

        def block(title, color, mark, lines, empty):
            body = "".join(f"<p style='margin:3px 0'>{mark} {t}</p>" for t in lines) or \
                   f"<p style='color:{MUTED}'>{empty}</p>"
            return f"<h3 style='color:{color}; margin-bottom:2px'>{title}</h3>{body}"

        html = (block("Strengths", UP, "✔", good, "Nothing stands out as a clear strength.")
                + block("Red flags", DOWN, "⚠", bad, "No major red flags found.")
                + f"<p style='color:{MUTED}; font-size:11px'>Automated read of Yahoo Finance data. "
                  "Not investment advice.</p>")
        self.notes.setHtml(html)


# ---- Watchlist & portfolio --------------------------------------------------
WATCH_SPEC = [("Symbol", "symbol", "text", 0), ("Name", "name", "text", 0),
              ("Price (₹)", "price", "num", 2), ("1D %", "chg", "pct", 2), ("Score", "score", "score", 0)]
POS_COLS = ["Symbol", "Qty", "Avg cost", "Invested", "Price", "Value", "P&L", "P&L %"]


class PortfolioTab(QWidget):
    openStock = pyqtSignal(str)
    watchChanged = pyqtSignal()
    portfolioChanged = pyqtSignal()

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        root = QHBoxLayout(self)
        split = QSplitter(Qt.Orientation.Horizontal)
        root.addWidget(split)

        # --- watchlist
        wbox = QGroupBox("Watchlist")
        wl = QVBoxLayout(wbox)
        row = QHBoxLayout()
        self.w_edit = QLineEdit()
        self.w_edit.setPlaceholderText("Symbol, e.g. TCS")
        self.w_edit.returnPressed.connect(self.add_watch)
        self.w_model = make_completer(self.w_edit)
        add = QPushButton("Add")
        add.clicked.connect(self.add_watch)
        rem = QPushButton("Remove selected")
        rem.clicked.connect(self.remove_watch)
        for w in (self.w_edit, add, rem):
            row.addWidget(w)
        wl.addLayout(row)
        self.w_table = make_table()
        self.w_table.cellDoubleClicked.connect(lambda r, c: self.openStock.emit(self.w_table.item(r, 0).text()))
        wl.addWidget(self.w_table)
        split.addWidget(wbox)

        # --- portfolio
        pbox = QGroupBox("Portfolio (positions & trades)")
        pl = QVBoxLayout(pbox)
        form = QHBoxLayout()
        self.t_sym = QLineEdit()
        self.t_sym.setPlaceholderText("Symbol")
        self.t_sym.setFixedWidth(120)
        self.t_model = make_completer(self.t_sym)
        self.t_sym.editingFinished.connect(self.autofill_price)
        self.t_qty = QSpinBox()
        self.t_qty.setRange(1, 100_000_000)
        self.t_qty.setPrefix("Qty ")
        self.t_price = QDoubleSpinBox()
        self.t_price.setRange(0, 10_000_000)
        self.t_price.setDecimals(2)
        self.t_price.setPrefix("₹ ")
        self.t_date = QDateEdit(QDate.currentDate())
        self.t_date.setCalendarPopup(True)
        self.t_date.setDisplayFormat("dd MMM yyyy")
        add_t = QPushButton("Add buy trade")
        add_t.setObjectName("primary")
        add_t.clicked.connect(self.add_trade)
        for w in (self.t_sym, self.t_qty, self.t_price, self.t_date, add_t):
            form.addWidget(w)
        pl.addLayout(form)
        self.summary = QLabel("")
        self.summary.setStyleSheet("font-size:15px;")
        pl.addWidget(self.summary)
        self.pos_table = make_table()
        self.pos_table.cellDoubleClicked.connect(lambda r, c: self.openStock.emit(self.pos_table.item(r, 0).text()))
        pl.addWidget(self.pos_table, 2)
        pl.addWidget(QLabel("Trades"))
        self.trade_table = make_table(False)
        pl.addWidget(self.trade_table, 1)
        del_t = QPushButton("Delete selected trade")
        del_t.clicked.connect(self.delete_trade)
        pl.addWidget(del_t, 0, Qt.AlignmentFlag.AlignRight)
        split.addWidget(pbox)
        split.setSizes([480, 820])

    def refresh(self):
        syms = self.state.symbols()
        self.w_model.setStringList(syms)
        self.t_model.setStringList(syms)
        self.refresh_watch()
        self.refresh_portfolio()

    # watchlist
    def refresh_watch(self):
        wl = self.state.db.watchlist()
        m = self.state.master
        rows = m.loc[[s for s in wl if s in m.index]] if len(m) else pd.DataFrame(columns=m.columns)
        populate(self.w_table, rows, WATCH_SPEC)

    def add_watch(self):
        sym = clean_symbol(self.w_edit.text())
        if sym not in self.state.master.index:
            QMessageBox.information(self, "Not found", f"'{sym}' is not in the Nifty 500 dataset.")
            return
        self.state.db.add_watch(sym)
        self.w_edit.clear()
        self.refresh_watch()
        self.watchChanged.emit()

    def remove_watch(self):
        for idx in {i.row() for i in self.w_table.selectedIndexes()}:
            self.state.db.remove_watch(self.w_table.item(idx, 0).text())
        self.refresh_watch()
        self.watchChanged.emit()

    # portfolio
    def autofill_price(self):
        sym = clean_symbol(self.t_sym.text())
        p = self.state.last_price(sym)
        if self.t_price.value() == 0 and not math.isnan(p):
            self.t_price.setValue(p)

    def add_trade(self):
        sym = clean_symbol(self.t_sym.text())
        if sym not in self.state.master.index:
            QMessageBox.information(self, "Not found", f"'{sym}' is not in the Nifty 500 dataset.")
            return
        if self.t_price.value() <= 0:
            QMessageBox.information(self, "Price", "Enter the buy price.")
            return
        self.state.db.add_trade(sym, self.t_qty.value(), self.t_price.value(),
                                self.t_date.date().toString("yyyy-MM-dd"))
        self.t_sym.clear()
        self.t_price.setValue(0)
        self.refresh_portfolio()
        self.portfolioChanged.emit()

    def delete_trade(self):
        rows = {i.row() for i in self.trade_table.selectedIndexes()}
        for r in rows:
            self.state.db.delete_trade(int(self.trade_table.item(r, 0).data(Qt.ItemDataRole.UserRole)))
        self.refresh_portfolio()
        self.portfolioChanged.emit()

    def refresh_portfolio(self):
        trades = self.state.db.trades()
        # trades table
        self.trade_table.clear()
        self.trade_table.setColumnCount(5)
        self.trade_table.setHorizontalHeaderLabels(["Symbol", "Qty", "Price", "Date", "Side"])
        self.trade_table.setRowCount(len(trades))
        for r, (tid, sym, qty, price, date, side, *_) in enumerate(trades):
            first = QTableWidgetItem(sym)
            first.setData(Qt.ItemDataRole.UserRole, tid)
            self.trade_table.setItem(r, 0, first)
            self.trade_table.setItem(r, 1, NumItem(fmt_qty(qty), qty))
            self.trade_table.setItem(r, 2, NumItem(f"{price:,.2f}", price))
            self.trade_table.setItem(r, 3, QTableWidgetItem(date))
            side_item = QTableWidgetItem(side)
            side_item.setForeground(QBrush(QColor(DOWN if side == "SELL" else UP)))
            self.trade_table.setItem(r, 4, side_item)
        # positions (average-cost method; sells reduce the position and book realized P&L)
        pos, realized = compute_positions(trades)
        rows, tot_inv, tot_inv_priced, tot_val = [], 0.0, 0.0, 0.0
        for sym, p in sorted(pos.items()):
            if p["qty"] <= 1e-9:
                continue
            qty, cost = p["qty"], p["cost"]
            cur = self.state.last_price(sym)
            val = qty * cur if not math.isnan(cur) else math.nan
            pnl = val - cost
            rows.append((sym, qty, cost / qty, cost, cur, val, pnl, pnl / cost * 100 if cost else math.nan))
            tot_inv += cost
            if not math.isnan(val):
                tot_val += val
                tot_inv_priced += cost
        self.pos_table.setSortingEnabled(False)
        self.pos_table.clear()
        self.pos_table.setColumnCount(len(POS_COLS))
        self.pos_table.setHorizontalHeaderLabels(POS_COLS)
        self.pos_table.setRowCount(len(rows))
        for r, (sym, qty, avg, inv, cur, val, pnl, pct) in enumerate(rows):
            self.pos_table.setItem(r, 0, QTableWidgetItem(sym))
            for c, (v, d, colored) in enumerate([(qty, 0, False), (avg, 2, False), (inv, 2, False),
                                                 (cur, 2, False), (val, 2, False), (pnl, 2, True),
                                                 (pct, 2, True)], start=1):
                text = fmt_qty(v) if c == 1 else fmt(v, d, "%" if c == 7 else "", comma=True)
                self.pos_table.setItem(r, c, NumItem(text, v, color_for(v) if colored else None))
        self.pos_table.setSortingEnabled(True)
        pnl_t = tot_val - tot_inv_priced
        col = color_for(pnl_t) or FG
        pct_t = pnl_t / tot_inv_priced * 100 if tot_inv_priced else 0
        real_txt = ""
        if abs(realized) > 0.005:
            real_txt = (f" &nbsp;·&nbsp; Realized <b style='color:{color_for(realized) or FG}'>"
                        f"₹{realized:+,.0f}</b>")
        self.summary.setText(
            f"Invested <b>₹{tot_inv:,.0f}</b> &nbsp;·&nbsp; Current value <b>₹{tot_val:,.0f}</b> &nbsp;·&nbsp; "
            f"P&amp;L <b style='color:{col}'>₹{pnl_t:+,.0f} ({pct_t:+.2f}%)</b>{real_txt}")


# ---- Background price fetch for holdings outside the Nifty 500 ----------------
def fetch_yahoo_quote(sym: str, include_analysis: bool = False) -> dict | None:
    tickers = (sym,) if sym.endswith(".BO") else (sym + ".NS", sym + ".BO")
    for ticker in tickers:
        try:
            tk = yf.Ticker(ticker)
            h = tk.history(period=PRICE_PERIOD if include_analysis else "7d", auto_adjust=False, timeout=8)
            h = h.dropna(subset=["Close"])
            if h.empty:
                continue
            price = float(h["Close"].iloc[-1])
            prev = float(h["Close"].iloc[-2]) if len(h) > 1 else math.nan
            info = {}
            if include_analysis:
                try:
                    info = tk.info or {}
                except Exception:
                    pass
            return {"price": price, "prev": prev, "sector": str(info.get("sector") or ""),
                    "name": str(info.get("longName") or info.get("shortName") or sym),
                    "history": clean_ohlcv(h) if include_analysis else None,
                    "funds": extract_fundamentals(info) if info else {}}
        except Exception:
            continue
    return None


class ExtraPriceWorker(QThread):
    batch = pyqtSignal(dict)

    def __init__(self, symbols: list[str], with_analysis: set[str]):
        super().__init__()
        self.symbols = symbols
        self.with_analysis = with_analysis

    def run(self):
        with ThreadPoolExecutor(max_workers=6) as pool:
            for start in range(0, len(self.symbols), 12):
                if self.isInterruptionRequested():
                    break
                jobs = {pool.submit(fetch_yahoo_quote, sym, sym in self.with_analysis): sym
                        for sym in self.symbols[start:start + 12]}
                out = {}
                for job in as_completed(jobs):
                    quote = job.result()
                    if quote:
                        out[jobs[job]] = quote
                self.batch.emit(out)


# ---- Import tab: PDF -> trades / holdings, with execution log ---------------------
LOG_COLORS = {"OK": UP, "ERROR": DOWN, "WARN": AMBER, "SKIPPED": AMBER, "INFO": MUTED}
SYMBOL_OK = re.compile(r"^[A-Z0-9][A-Z0-9&\-]{0,19}(?:\.BO)?$")


def _flags(editable: bool = True, checkable: bool = False):
    f = Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable
    if editable:
        f |= Qt.ItemFlag.ItemIsEditable
    if checkable:
        f |= Qt.ItemFlag.ItemIsUserCheckable
    return f


class ImportTab(QWidget):
    portfolioChanged = pyqtSignal()
    clearRequested = pyqtSignal()
    previewPricesRequested = pyqtSignal()

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        self._busy = False
        self.doc_date: dt.date | None = None
        self.trade_file = ""
        self.hold_file = ""
        root = QVBoxLayout(self)
        split = QSplitter(Qt.Orientation.Vertical)
        top = QWidget()
        tl = QHBoxLayout(top)
        tl.setContentsMargins(0, 0, 0, 0)
        tl.addWidget(self._build_trades_box(), 1)
        tl.addWidget(self._build_holdings_box(), 1)
        split.addWidget(top)
        split.addWidget(self._build_log_box())
        split.setSizes([520, 280])
        root.addWidget(split)
        self.refresh_log()

    # ------------------------------------------------------------------ UI builders
    def _preview_table(self, headers: list[str]) -> QTableWidget:
        t = make_table(False)
        t.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked | QAbstractItemView.EditTrigger.EditKeyPressed)
        t.setColumnCount(len(headers))
        t.setHorizontalHeaderLabels(headers)
        return t

    def _build_trades_box(self) -> QGroupBox:
        box = QGroupBox("1 · Import trades or a Bonanza contract note")
        v = QVBoxLayout(box)
        row = QHBoxLayout()
        up = QPushButton("📄 Upload trades PDF…")
        up.clicked.connect(self.pick_trades)
        self.tr_file = QLabel("No file selected")
        self.tr_file.setStyleSheet(f"color:{MUTED};")
        self.tr_update = QPushButton("Update trades")
        self.tr_update.setObjectName("primary")
        self.tr_update.setEnabled(False)
        self.tr_update.clicked.connect(self.update_trades)
        row.addWidget(up)
        row.addWidget(self.tr_file, 1)
        row.addWidget(self.tr_update)
        v.addLayout(row)
        self.tr_dupes = QCheckBox("Skip trades that are already in the portfolio")
        self.tr_dupes.setChecked(True)
        v.addWidget(self.tr_dupes)
        hint = QLabel("Bonanza contract notes use only the Equity Segment Summary’s Net Obligation. "
                      "Review the side, quantity and value before updating.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{MUTED};")
        v.addWidget(hint)
        self.tr_table = self._preview_table(["Symbol", "Side", "Qty", "Price (₹)", "Date", "Status", "Net value (₹)"])
        self.tr_table.itemChanged.connect(self._on_trade_item_changed)
        v.addWidget(self.tr_table, 1)
        self.tr_summary = QLabel("")
        v.addWidget(self.tr_summary)
        return box

    def _build_holdings_box(self) -> QGroupBox:
        box = QGroupBox("2 · Override portfolio from a holdings PDF")
        v = QVBoxLayout(box)
        row = QHBoxLayout()
        up = QPushButton("📄 Upload holdings PDF…")
        up.clicked.connect(self.pick_holdings)
        self.hd_file = QLabel("No file selected")
        self.hd_file.setStyleSheet(f"color:{MUTED};")
        self.hd_update = QPushButton("Update Portfolio")
        self.hd_update.setObjectName("primary")
        self.hd_update.setEnabled(False)
        self.hd_update.clicked.connect(self.update_holdings)
        clear = QPushButton("Clear all portfolio")
        clear.clicked.connect(self.clearRequested.emit)
        row.addWidget(clear)
        row.addWidget(up)
        row.addWidget(self.hd_file, 1)
        row.addWidget(self.hd_update)
        v.addLayout(row)
        warn = QLabel("⚠ Replaces ALL existing trades with the holdings in the PDF "
                      "(a CSV backup of the old trades is saved first).")
        warn.setWordWrap(True)
        warn.setStyleSheet(f"color:{AMBER};")
        v.addWidget(warn)
        hint = QLabel("Reads Net Qty, Net Value and Avg from portfolio reports. LTP comes from Yahoo Finance. "
                      "Double-click a cell to correct it, untick rows to leave them out.")
        hint.setWordWrap(True)
        hint.setStyleSheet(f"color:{MUTED};")
        v.addWidget(hint)
        self.hd_table = self._preview_table(["Symbol", "Qty", "Avg cost (₹)", "LTP (₹)", "Invested (₹)", "Status"])
        self.hd_table.itemChanged.connect(self._on_hold_item_changed)
        v.addWidget(self.hd_table, 1)
        self.hd_summary = QLabel("")
        v.addWidget(self.hd_summary)
        return box

    def _build_log_box(self) -> QGroupBox:
        box = QGroupBox("Execution log")
        v = QVBoxLayout(box)
        row = QHBoxLayout()
        self.log_count = QLabel("")
        self.log_count.setStyleSheet(f"color:{MUTED};")
        clear = QPushButton("Clear log")
        clear.clicked.connect(self.clear_log)
        export = QPushButton("Export CSV…")
        export.clicked.connect(self.export_log)
        row.addWidget(self.log_count, 1)
        row.addWidget(export)
        row.addWidget(clear)
        v.addLayout(row)
        self.log_table = make_table(False)
        self.log_table.setColumnCount(5)
        self.log_table.setHorizontalHeaderLabels(["Time", "Action", "Symbol", "Details", "Status"])
        v.addWidget(self.log_table, 1)
        return box

    # ------------------------------------------------------------------ logging
    def _log(self, entries: list[tuple]):
        """entries: (action, symbol, detail, status, source)."""
        self.state.db.log_many(entries)
        self.refresh_log()

    def refresh_log(self):
        rows = self.state.db.log_rows()
        t = self.log_table
        t.setRowCount(len(rows))
        for r, (ts, action, sym, detail, status, _src) in enumerate(rows):
            vals = [ts.replace("T", " "), action, sym or "", detail or "", status]
            for c, text in enumerate(vals):
                it = QTableWidgetItem(text)
                if c == 4:
                    it.setForeground(QBrush(QColor(LOG_COLORS.get(status, FG))))
                t.setItem(r, c, it)
        t.resizeColumnsToContents()
        self.log_count.setText(f"{len(rows)} log entries (newest first)")

    def clear_log(self):
        self.state.db.clear_log()
        self.refresh_log()

    def export_log(self):
        path, _ = QFileDialog.getSaveFileName(self, "Export execution log", "execution_log.csv", "CSV (*.csv)")
        if path:
            pd.DataFrame(self.state.db.log_rows(100000),
                         columns=["time", "action", "symbol", "details", "status", "source"]).to_csv(path, index=False)
            self.log_count.setText(f"Log exported to {path}")

    # ------------------------------------------------------------------ PDF loading
    def _run_pdf_task(self, message, task, *args):
        progress = QProgressDialog(message, "", 0, 0, self)
        progress.setCancelButton(None)
        progress.setWindowFlag(Qt.WindowType.WindowCloseButtonHint, False)
        progress.setWindowModality(Qt.WindowModality.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.show()
        loop = QEventLoop()
        worker = PdfTaskWorker(task, *args)
        worker.finished.connect(loop.quit)
        worker.start()
        loop.exec()
        worker.wait()
        progress.close()
        if worker.error is not None:
            raise worker.error
        return worker.result

    def _parse(self, mode: str, path: str) -> dict | None:
        resolver = SymbolResolver(self.state.universe)
        pw = None
        name = Path(path).name
        repair_attempted = False
        while True:
            try:
                return self._run_pdf_task("Reading PDF and matching security symbols…",
                                          parse_pdf, path, mode, resolver, pw)
            except ModuleNotFoundError as exc:
                if exc.name != "pdfplumber" or repair_attempted:
                    QMessageBox.warning(self, "Could not read PDF", str(exc))
                    return None
                repair_attempted = True
                answer = QMessageBox.question(
                    self, "Install PDF reader?",
                    "The screener needs pdfplumber to read this PDF. Install it now and retry the import?",
                    QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.Yes,
                )
                if answer != QMessageBox.StandardButton.Yes:
                    return None
                try:
                    self._run_pdf_task("Installing the PDF reader…", install_pdf_reader)
                except (PdfError, OSError, subprocess.TimeoutExpired) as error:
                    self._log([("PARSE", "", f"PDF reader installation failed: {error}", "ERROR", mode)])
                    QMessageBox.warning(
                        self, "Could not install PDF reader",
                        f"{error}\n\nIf this Python environment cannot install packages, "
                        "close the app and open it with run_stock_screener.bat.",
                    )
                    return None
            except PdfPasswordNeeded:
                pw, ok = QInputDialog.getText(self, "Password-protected PDF",
                                              f"{name} is protected.\nEnter its password (often your PAN in capitals):",
                                              QLineEdit.EchoMode.Password)
                if not ok:
                    self._log([("PARSE", "", f"{name}: password not provided", "ERROR", mode)])
                    return None
                continue
            except Exception as exc:                        # noqa: BLE001
                self._log([("PARSE", "", f"{name}: {exc}", "ERROR", mode)])
                QMessageBox.warning(self, "Could not read PDF", str(exc))
                return None

    def pick_trades(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select trades PDF", "", "PDF files (*.pdf)")
        if not path:
            return
        res = self._parse("trades", path)
        if res is None:
            return
        self.trade_file = Path(path).name
        self.tr_file.setText(self.trade_file)
        rows = res["rows"]
        self._fill_trades(rows)
        self.tr_update.setEnabled(bool(rows))
        status = "OK" if rows else "WARN"
        self._log([("PARSE", "", f"{self.trade_file}: {len(rows)} trade rows found "
                                 f"(reader: {res['extractor']})", status, "trades PDF")])
        if not rows:
            QMessageBox.information(self, "No trades found",
                                    "No trade rows could be recognised in this PDF.\n\nIt needs columns such as "
                                    "Symbol, Buy/Sell, Qty and Price. Scanned (image) PDFs are not supported.")

    def pick_holdings(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select holdings PDF", "", "PDF files (*.pdf)")
        if not path:
            return
        res = self._parse("holdings", path)
        if res is None:
            return
        self.hold_file = Path(path).name
        self.hd_file.setText(self.hold_file)
        self.doc_date = res["doc_date"]
        rows = res["rows"]
        self._fill_holdings(rows)
        self.hd_update.setEnabled(bool(rows))
        self.previewPricesRequested.emit()
        self._log([("PARSE", "", f"{self.hold_file}: {len(rows)} holdings found (reader: {res['extractor']})",
                    "OK" if rows else "WARN", "holdings PDF")])
        if not rows:
            QMessageBox.information(self, "No holdings found",
                                    "No holdings could be recognised in this PDF.\n\nIt needs columns such as "
                                    "Symbol/Name, Qty and Avg cost. Scanned (image) PDFs are not supported.")

    # ------------------------------------------------------------------ trades preview
    def _fill_trades(self, rows: list[dict]):
        t = self.tr_table
        self._busy = True
        t.setRowCount(len(rows))
        for r, rec in enumerate(rows):
            sym = QTableWidgetItem(rec["symbol"])
            sym.setFlags(_flags(True, True))
            sym.setCheckState(Qt.CheckState.Checked)
            sym.setData(Qt.ItemDataRole.UserRole, {"ref": rec.get("ref", ""), "note": rec.get("note", "")})
            sym.setToolTip(rec.get("note", ""))
            t.setItem(r, 0, sym)
            for c, text in ((1, rec["side"]), (2, f"{rec['qty']:.15g}"),
                            (3, f"{rec['price']:.15g}"), (4, rec["date"].isoformat())):
                t.setItem(r, c, QTableWidgetItem(text))
            st = QTableWidgetItem("")
            st.setFlags(_flags(False))
            t.setItem(r, 5, st)
            total = QTableWidgetItem("")
            total.setFlags(_flags(False))
            t.setItem(r, 6, total)
        for r in range(t.rowCount()):
            self._revalidate_trade_row(r, initial=True)
        t.resizeColumnsToContents()
        self._busy = False
        self._update_trade_summary()

    def _trade_values(self, r: int):
        t = self.tr_table
        sym = clean_symbol(t.item(r, 0).text())
        side = t.item(r, 1).text().strip().upper()
        qty, price = parse_num(t.item(r, 2).text()), parse_num(t.item(r, 3).text())
        date = parse_date(t.item(r, 4).text())
        return sym, side, qty, price, date

    def _check_trade_row(self, r: int) -> tuple[bool, str, str]:
        sym, side, qty, price, date = self._trade_values(r)
        if not SYMBOL_OK.match(sym):
            return False, "Symbol missing / invalid - edit it", DOWN
        if side not in ("BUY", "SELL"):
            return False, "Side must be BUY or SELL", DOWN
        if qty is None or math.isnan(qty) or qty <= 0:
            return False, "Qty must be a positive number", DOWN
        if price is None or math.isnan(price) or price <= 0:
            return False, "Price must be a positive number", DOWN
        if date is None:
            return False, "Date must look like 2026-11-28", DOWN
        meta = self.tr_table.item(r, 0).data(Qt.ItemDataRole.UserRole) or {}
        note = meta.get("note", "")
        if sym not in self.state.master.index:
            return True, "Outside Nifty 500 - price via Yahoo" + (f"; {note}" if note else ""), AMBER
        return True, "Ready" + (f" ({note})" if note else ""), (AMBER if note else UP)

    def _set_status(self, table: QTableWidget, r: int, col: int, text: str, color: str):
        was = self._busy
        self._busy = True
        it = table.item(r, col)
        it.setText(text)
        it.setForeground(QBrush(QColor(color)))
        self._busy = was

    def _revalidate_trade_row(self, r: int, initial: bool = False):
        ok, text, color = self._check_trade_row(r)
        self._set_status(self.tr_table, r, 5, text, color)
        _, side, qty, price, _ = self._trade_values(r)
        was = self._busy
        self._busy = True
        self.tr_table.item(r, 6).setText(f"{qty * price * (-1 if side == 'SELL' else 1):,.2f}"
                                          if qty is not None and price is not None else "")
        self._busy = was
        if initial and not ok:
            was = self._busy
            self._busy = True
            self.tr_table.item(r, 0).setCheckState(Qt.CheckState.Unchecked)
            self._busy = was

    def _on_trade_item_changed(self, item):
        if self._busy:
            return
        if item.column() < 5:
            self._revalidate_trade_row(item.row())
        self._update_trade_summary()

    def _update_trade_summary(self):
        t = self.tr_table
        n = t.rowCount()
        sel = sum(1 for r in range(n) if t.item(r, 0).checkState() == Qt.CheckState.Checked)
        bad = sum(1 for r in range(n) if not self._check_trade_row(r)[0])
        self.tr_summary.setText(f"{n} rows read · {sel} selected · {bad} need attention" if n else "")

    # ------------------------------------------------------------------ holdings preview
    def _fill_holdings(self, rows: list[dict]):
        t = self.hd_table
        self._busy = True
        t.setRowCount(len(rows))
        for r, rec in enumerate(rows):
            sym = QTableWidgetItem(rec["symbol"])
            sym.setFlags(_flags(True, True))
            sym.setCheckState(Qt.CheckState.Checked)
            sym.setData(Qt.ItemDataRole.UserRole, {"note": rec.get("note", ""),
                                                   "date": rec["date"].isoformat()})
            t.setItem(r, 0, sym)
            sym.setToolTip(rec.get("note", ""))
            sym.setData(Qt.ItemDataRole.UserRole, {
                **sym.data(Qt.ItemDataRole.UserRole), "invested": rec.get("invested"),
                "original_qty": rec["qty"], "original_avg": rec["avg"]})
            market_price = self.state.last_price(rec["symbol"])
            ltp = "" if pd.isna(market_price) else f"{market_price:.2f}"
            for c, text in ((1, f"{rec['qty']:.15g}"), (2, f"{rec['avg']:.15g}"), (3, ltp)):
                item = QTableWidgetItem(text)
                if c == 3:
                    item.setFlags(_flags(False))
                t.setItem(r, c, item)
            inv = QTableWidgetItem("")
            inv.setFlags(_flags(False))
            inv.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            t.setItem(r, 4, inv)
            st = QTableWidgetItem("")
            st.setFlags(_flags(False))
            t.setItem(r, 5, st)
        for r in range(t.rowCount()):
            self._revalidate_hold_row(r, initial=True)
        t.resizeColumnsToContents()
        self._busy = False
        self._update_hold_summary()

    def _hold_values(self, r: int):
        t = self.hd_table
        sym = clean_symbol(t.item(r, 0).text())
        qty, avg = parse_num(t.item(r, 1).text()), parse_num(t.item(r, 2).text())
        ltp = parse_num(t.item(r, 3).text()) if t.item(r, 3).text().strip() else math.nan
        return sym, qty, avg, ltp

    def _hold_invested(self, r: int, qty: float, avg: float) -> float:
        meta = self.hd_table.item(r, 0).data(Qt.ItemDataRole.UserRole) or {}
        if meta.get("invested") is not None and qty == meta["original_qty"] and avg == meta["original_avg"]:
            return meta["invested"]
        return qty * avg

    def refresh_preview_prices(self):
        table = self.hd_table
        was = self._busy
        self._busy = True
        try:
            for r in range(table.rowCount()):
                price = self.state.last_price(clean_symbol(table.item(r, 0).text()))
                table.item(r, 3).setText("" if pd.isna(price) else f"{price:.2f}")
        finally:
            self._busy = was

    def _check_hold_row(self, r: int) -> tuple[bool, str, str]:
        sym, qty, avg, _ltp = self._hold_values(r)
        if not SYMBOL_OK.match(sym):
            return False, "Symbol missing / invalid - edit it", DOWN
        if qty is None or math.isnan(qty) or qty <= 0:
            return False, "Qty must be a positive number", DOWN
        if avg is None or math.isnan(avg) or avg <= 0:
            return False, "Avg cost must be a positive number", DOWN
        note = (self.hd_table.item(r, 0).data(Qt.ItemDataRole.UserRole) or {}).get("note", "")
        if sym not in self.state.master.index:
            return True, "Outside Nifty 500 - price via Yahoo" + (f"; {note}" if note else ""), AMBER
        return True, "Ready" + (f" ({note})" if note else ""), (AMBER if note else UP)

    def _revalidate_hold_row(self, r: int, initial: bool = False):
        ok, text, color = self._check_hold_row(r)
        self._set_status(self.hd_table, r, 5, text, color)
        sym, qty, avg, _ = self._hold_values(r)
        inv = self.hd_table.item(r, 4)
        was = self._busy
        self._busy = True
        inv.setText(f"{self._hold_invested(r, qty, avg):,.2f}" if ok else "–")
        if initial and not ok:
            self.hd_table.item(r, 0).setCheckState(Qt.CheckState.Unchecked)
        self._busy = was

    def _on_hold_item_changed(self, item):
        if self._busy:
            return
        if item.column() == 0:
            self.refresh_preview_prices()
            if self.hd_update.isEnabled():
                self.previewPricesRequested.emit()
        if item.column() not in (4, 5):
            self._revalidate_hold_row(item.row())
        self._update_hold_summary()

    def _update_hold_summary(self):
        t = self.hd_table
        n = t.rowCount()
        sel = [r for r in range(n) if t.item(r, 0).checkState() == Qt.CheckState.Checked and self._check_hold_row(r)[0]]
        total = sum(self._hold_invested(r, *self._hold_values(r)[1:3]) for r in sel)
        bad = sum(1 for r in range(n) if not self._check_hold_row(r)[0])
        self.hd_summary.setText(f"{n} rows read · {len(sel)} selected (invested ₹{total:,.0f}) · {bad} need attention"
                                if n else "")

    # ------------------------------------------------------------------ actions
    def update_trades(self):
        t = self.tr_table
        src = f"trades PDF: {self.trade_file}"
        logs: list[tuple] = []
        todo = []
        for r in range(t.rowCount()):
            if t.item(r, 0).checkState() != Qt.CheckState.Checked:
                continue
            ok, text, _ = self._check_trade_row(r)
            sym, side, qty, price, date = self._trade_values(r)
            if not ok:
                logs.append(("ADD TRADE", sym, text, "ERROR", src))
                self._set_status(t, r, 5, "✘ " + text, DOWN)
                continue
            ref = (t.item(r, 0).data(Qt.ItemDataRole.UserRole) or {}).get("ref") or ""
            todo.append((date, 0 if side == "BUY" else 1, r, sym, side, qty, price, ref))
        if not todo and not logs:
            QMessageBox.information(self, "Nothing to add", "No valid, ticked rows to add.")
            return
        todo.sort(key=lambda x: (x[0], x[1], x[2]))
        pos, _ = compute_positions(self.state.db.trades())
        held = {s: p["qty"] for s, p in pos.items()}
        added = skipped = 0
        snapshots = [t[4] for t in self.state.db.trades() if t[7] == "holdings PDF"]
        if snapshots and any(ref.startswith("BONANZA:") and date.isoformat() <= max(snapshots)
                             for date, _, _, _, _, _, _, ref in todo):
            answer = QMessageBox.question(
                self, "Apply note dated before the portfolio snapshot?",
                "The snapshot may already include these trades. Apply the note only if these obligations "
                "still need to be added to the opening holdings.",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return
        for date, _o, r, sym, side, qty, price, ref in todo:
            d = date.isoformat()
            detail = f"{side} {fmt_qty(qty)} @ ₹{price:,.2f} on {d}"
            broker_note = ref.startswith("BONANZA:")
            if not broker_note and self.tr_dupes.isChecked() and self.state.db.trade_exists(sym, qty, price, d, side, ref):
                logs.append(("ADD TRADE", sym, detail + " - duplicate, not added", "SKIPPED", src))
                self._set_status(t, r, 5, "Skipped (already in portfolio)", AMBER)
                skipped += 1
                continue
            if not broker_note and side == "SELL":
                if qty > held.get(sym, 0.0) + 1e-9:
                    msg = f"sell qty {fmt_qty(qty)} is more than the {fmt_qty(held.get(sym, 0.0))} held"
                    logs.append(("ADD TRADE", sym, detail + " - " + msg, "ERROR", src))
                    self._set_status(t, r, 5, "✘ " + msg, DOWN)
                    continue
            try:
                if broker_note:
                    if not self.state.db.add_broker_trade(sym, qty, price, d, side, ref, src):
                        logs.append(("ADD TRADE", sym, detail + " - duplicate", "SKIPPED", src))
                        self._set_status(t, r, 5, "Skipped (already in portfolio)", AMBER)
                        skipped += 1
                        continue
                else:
                    self.state.db.add_trade(sym, qty, price, d, side, ref, src)
                held[sym] = held.get(sym, 0.0) + (qty if side == "BUY" else -qty)
            except Exception as exc:                        # noqa: BLE001
                logs.append(("ADD TRADE", sym, f"{detail} - database error: {exc}", "ERROR", src))
                self._set_status(t, r, 5, f"✘ {exc}", DOWN)
                continue
            added += 1
            extra = "" if sym in self.state.master.index else " (outside Nifty 500)"
            logs.append(("ADD TRADE", sym, detail + extra, "OK", src))
            self._set_status(t, r, 5, "✔ Added", UP)
        errors = sum(1 for e in logs if e[3] == "ERROR")
        logs.append(("SUMMARY", "", f"{self.trade_file}: {added} added, {skipped} skipped, {errors} failed",
                     "OK" if added and not errors else "WARN", src))
        self._log(logs)
        self.tr_update.setEnabled(bool(errors))
        if added:
            self.portfolioChanged.emit()
        QMessageBox.information(self, "Trades updated",
                                f"{added} trade(s) added, {skipped} skipped, {errors} failed.\n"
                                "See the execution log for details.")

    def update_holdings(self):
        t = self.hd_table
        src = f"holdings PDF: {self.hold_file}"
        rows, logs = [], []
        for r in range(t.rowCount()):
            if t.item(r, 0).checkState() != Qt.CheckState.Checked:
                continue
            ok, text, _ = self._check_hold_row(r)
            sym, qty, avg, ltp = self._hold_values(r)
            if not ok:
                logs.append(("OVERRIDE", sym, text + " - row left out", "ERROR", src))
                continue
            meta = t.item(r, 0).data(Qt.ItemDataRole.UserRole) or {}
            rows.append({"symbol": sym, "qty": qty, "avg": avg, "ltp": ltp, "note": "",
                         "invested": self._hold_invested(r, qty, avg),
                         "date": meta.get("date") or dt.date.today().isoformat()})
        if not rows:
            QMessageBox.information(self, "Nothing to update", "No valid, ticked holdings to apply.")
            return
        if logs:
            self._log(logs)
            QMessageBox.warning(self, "Review selected holdings", "Correct or untick every selected row with an error.")
            return
        rows = merge_holdings(rows)
        old_n = len(self.state.db.trades())
        ans = QMessageBox.question(
            self, "Override portfolio?",
            f"This will DELETE all {old_n} existing trade(s) and replace the portfolio with "
            f"{len(rows)} holding(s) from the PDF.\n\nYour old trades are saved to a CSV backup first.\n\nContinue?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No, QMessageBox.StandardButton.No)
        if ans != QMessageBox.StandardButton.Yes:
            self._log([("OVERRIDE", "", "Cancelled by user", "INFO", src)])
            return
        try:
            deleted, inserted, backup = self.state.db.replace_portfolio(rows, BACKUP_DIR)
        except Exception as exc:                            # noqa: BLE001
            self._log([("OVERRIDE", "", f"Database error: {exc}", "ERROR", src)])
            QMessageBox.warning(self, "Update failed", str(exc))
            return
        if backup:
            logs.append(("OVERRIDE", "", f"Old trades backed up to {backup}", "INFO", src))
        for h in rows:
            outside = h["symbol"] not in self.state.master.index
            logs.append(("OVERRIDE", h["symbol"],
                         f"Holding set: {fmt_qty(h['qty'])} @ avg ₹{h['avg']:,.2f}"
                         + (" (outside Nifty 500)" if outside else ""), "OK", src))
        logs.append(("SUMMARY", "", f"Portfolio overridden: {deleted} old trade(s) removed, {inserted} holding(s) loaded",
                     "OK", src))
        self.state.reload_extra()
        self._log(logs)
        self.hd_update.setEnabled(False)
        for r in range(t.rowCount()):
            if t.item(r, 0).checkState() == Qt.CheckState.Checked:
                self._set_status(t, r, 5, "✔ Loaded into portfolio", UP)
        self.portfolioChanged.emit()
        QMessageBox.information(self, "Portfolio updated",
                                f"Portfolio replaced: {inserted} holding(s) loaded, {deleted} old trade(s) removed."
                                + (f"\nBackup: {backup}" if backup else ""))


# ---- Portfolio dashboard ----------------------------------------------------------
HOLD_COLS = ["symbol", "name", "sector", "cap", "qty", "avg", "ltp", "prev", "invested", "inv_priced", "value",
             "prev_value", "pnl", "pnl_pct", "day_pnl", "day_pct", "weight", "first_date"]


def build_holdings(state: AppState) -> tuple[pd.DataFrame, dict, list]:
    """Open positions with live values. Returns (holdings frame, positions dict, raw trades)."""
    trades = state.db.trades()
    pos, _realized = compute_positions(trades)
    rows = []
    for sym, p in sorted(pos.items()):
        if p["qty"] <= 1e-9:
            continue
        qty, cost = p["qty"], p["cost"]
        ltp, prev = state.last_price(sym), state.prev_close(sym)
        has_px = not math.isnan(ltp)
        value = qty * ltp if has_px else math.nan
        prev_value = qty * prev if has_px and not math.isnan(prev) else math.nan
        rows.append({
            "symbol": sym, "name": state.name_of(sym), "sector": state.sector_of(sym), "cap": state.cap_of(sym),
            "qty": qty, "avg": p["avg"], "ltp": ltp, "prev": prev, "invested": cost,
            "inv_priced": cost if has_px else 0.0, "value": value, "prev_value": prev_value,
            "pnl": value - cost if has_px else math.nan,
            "pnl_pct": (value / cost - 1) * 100 if has_px and cost else math.nan,
            "day_pnl": value - prev_value if not math.isnan(prev_value) else math.nan,
            "day_pct": (ltp / prev - 1) * 100 if not math.isnan(prev_value) and prev else math.nan,
            "weight": math.nan, "first_date": p["first_date"]})
    df = pd.DataFrame(rows, columns=HOLD_COLS)
    total = df["value"].sum()
    if total:
        df["weight"] = df["value"] / total * 100
    return df, pos, trades


def draw_hbars(plot: pg.PlotWidget, labels: list[str], values: list[float], colors: list[str], unit: str):
    """Horizontal bar chart on a pyqtgraph plot; first label is drawn at the top."""
    plot.clear()
    n = len(labels)
    axis = plot.getAxis("left")
    if n == 0:
        axis.setTicks([[]])
        return
    ys = [n - 1 - i for i in range(n)]
    plot.addItem(pg.BarGraphItem(x0=[min(0, v) for v in values], y=ys, height=0.62,
                                 width=[abs(v) for v in values], brushes=[pg.mkBrush(c) for c in colors],
                                 pens=[pg.mkPen(None)] * n))
    plot.addItem(pg.InfiniteLine(pos=0, angle=90, pen=pg.mkPen(MUTED, width=1)))
    short = [(lbl if len(lbl) <= 24 else lbl[:23] + "…") for lbl in labels]
    axis.setTicks([[(ys[i], short[i]) for i in range(n)]])
    plot.setYRange(-0.7, n - 0.3, padding=0)
    plot.setLabel("bottom", unit)
    plot.enableAutoRange(axis="x")


class PortfolioDashboardTab(QWidget):
    openStock = pyqtSignal(str)
    clearRequested = pyqtSignal()
    pricesRequested = pyqtSignal()

    BASIS = {"Total P&L %": "pnl_pct", "Total P&L ₹": "pnl", "Day change %": "day_pct", "Day P&L ₹": "day_pnl"}
    PERIODS = {"1M": 30, "3M": 91, "6M": 182, "1Y": 365, "Max": None}
    HOLD_SPEC = [("Symbol", "symbol", "text", 0), ("Name", "name", "text", 0), ("Sector", "sector", "text", 0),
                 ("Qty", "qty", "num", 0), ("Avg cost", "avg", "num", 2), ("LTP", "ltp", "num", 2),
                 ("Invested", "invested", "num", 2), ("Current value", "value", "num", 2),
                 ("Day %", "day_pct", "pct", 2), ("Day P&L", "day_pnl", "cnum", 2),
                 ("P&L", "pnl", "cnum", 2), ("P&L %", "pnl_pct", "pct", 2), ("Weight %", "weight", "pct0", 1)]
    GL_SPEC = [("Symbol", "symbol", "text", 0), ("Name", "name", "text", 0), ("Qty", "qty", "num", 0),
               ("Avg cost", "avg", "num", 2), ("LTP", "ltp", "num", 2), ("Invested", "invested", "num", 2),
               ("Value", "value", "num", 2), ("P&L", "pnl", "cnum", 2), ("P&L %", "pnl_pct", "pct", 2),
               ("Day %", "day_pct", "pct", 2), ("Day P&L", "day_pnl", "cnum", 2)]
    SECTOR_SPEC = [("Sector", "sector", "text", 0), ("Stocks", "stocks", "num", 0), ("Invested", "invested", "num", 2),
                   ("Current value", "value", "num", 2), ("P&L", "pnl", "cnum", 2), ("P&L %", "pnl_pct", "pct", 2),
                   ("Day P&L", "day_pnl", "cnum", 2), ("Day %", "day_pct", "pct", 2),
                   ("Weight %", "weight", "pct0", 1)]

    def __init__(self, state: AppState):
        super().__init__()
        self.state = state
        self.all = pd.DataFrame(columns=HOLD_COLS)
        self.view = self.all
        self.pos: dict = {}
        self.trades: list = []
        self._loading = False
        pg.setConfigOptions(antialias=True, background=BG, foreground=FG)
        root = QVBoxLayout(self)

        # --- summary cards
        cards = QHBoxLayout()
        self.cards: dict[str, tuple[QLabel, QLabel]] = {}
        for key, title in (("inv", "Invested"), ("val", "Current value"), ("pnl", "Total P&L"),
                           ("day", "Day's P&L"), ("real", "Realized P&L"), ("xirr", "XIRR (annualised)")):
            frame = QFrame()
            frame.setObjectName("card")
            fl = QVBoxLayout(frame)
            t = QLabel(title)
            t.setStyleSheet(f"color:{MUTED}; font-size:12px;")
            v = QLabel("–")
            v.setStyleSheet("font-size:22px; font-weight:bold;")
            s = QLabel("")
            s.setStyleSheet(f"color:{MUTED}; font-size:12px;")
            for w in (t, v, s):
                fl.addWidget(w)
            self.cards[key] = (v, s)
            cards.addWidget(frame)
        root.addLayout(cards)

        # --- filters
        bar = QHBoxLayout()
        self.f_sector = QComboBox()
        self.f_sector.addItem("All sectors")
        self.f_cap = QComboBox()
        self.f_cap.addItems(["All market caps", "Large cap", "Mid cap", "Small cap", "Unclassified"])
        self.f_pnl = QComboBox()
        self.f_pnl.addItems(["All holdings", "In profit", "In loss"])
        self.f_day = QComboBox()
        self.f_day.addItems(["Any day move", "Up today", "Down today"])
        self.f_search = QLineEdit()
        self.f_search.setPlaceholderText("Search symbol / name")
        self.f_search.setFixedWidth(190)
        reset = QPushButton("Reset")
        reset.clicked.connect(self.reset_filters)
        export = QPushButton("Export CSV…")
        export.clicked.connect(self.export_csv)
        for w in (self.f_sector, self.f_cap, self.f_pnl, self.f_day):
            w.currentIndexChanged.connect(self.apply_filters)
            bar.addWidget(w)
        self.f_search.textChanged.connect(self.apply_filters)
        bar.addWidget(self.f_search)
        bar.addWidget(reset)
        bar.addStretch(1)
        bar.addWidget(export)
        clear = QPushButton("Clear all portfolio")
        clear.clicked.connect(self.clearRequested.emit)
        refresh_prices = QPushButton("Refresh prices")
        refresh_prices.clicked.connect(self.pricesRequested.emit)
        actions = QHBoxLayout()
        actions.addStretch(1)
        actions.addWidget(refresh_prices)
        actions.addWidget(clear)
        root.addLayout(bar)
        root.addLayout(actions)

        # --- inner tabs
        self.inner = QTabWidget()
        root.addWidget(self.inner, 1)
        self.inner.addTab(self._build_overview(), "Overview")

        self.hold_table = make_table()
        self.hold_table.cellDoubleClicked.connect(lambda r, c: self._open(self.hold_table, r))
        self.inner.addTab(self.hold_table, "Holdings")

        self.inner.addTab(self._build_gainers(), "Top 10 Gainers & Losers")

        sec = QWidget()
        sl = QVBoxLayout(sec)
        self.sector_table = make_table()
        sl.addWidget(self.sector_table, 1)
        self.sector_note = QLabel("")
        self.sector_note.setStyleSheet(f"color:{MUTED};")
        sl.addWidget(self.sector_note)
        self.inner.addTab(sec, "Sector-wise status")
        self.analysis = ScreenerTab(state, portfolio_only=True)
        self.analysis.openStock.connect(self.openStock.emit)
        self.inner.addTab(self.analysis, "Analysis")

        self.note = QLabel("Yahoo Finance quotes reflect the latest available market data. Double-click a holding to open its analysis.")
        self.note.setStyleSheet(f"color:{MUTED};")
        root.addWidget(self.note)

    # ------------------------------------------------------------------ builders
    def _plot(self, left: bool = True, axis_items: dict | None = None) -> pg.PlotWidget:
        p = pg.PlotWidget(axisItems=axis_items) if axis_items else pg.PlotWidget()
        p.setBackground(BG)
        p.showGrid(x=True, y=False, alpha=0.15)
        p.setMenuEnabled(False)
        p.hideButtons()
        return p

    def _build_overview(self) -> QWidget:
        w = QWidget()
        g = QGridLayout(w)
        self.pl_alloc = self._plot()
        self.pl_alloc.setMouseEnabled(False, False)
        self.pl_alloc.getAxis("left").setWidth(170)
        self.pl_sector_pnl = self._plot()
        self.pl_sector_pnl.setMouseEnabled(False, False)
        self.pl_sector_pnl.getAxis("left").setWidth(170)
        self.pl_top = self._plot()
        self.pl_top.setMouseEnabled(False, False)
        self.pl_top.getAxis("left").setWidth(110)
        self.perf_axis = DateAxis(orientation="bottom")
        self.pl_perf = self._plot(axis_items={"bottom": self.perf_axis})
        self.pl_perf.showGrid(x=False, y=True, alpha=0.15)

        def box(title: str, widget: QWidget, extra: QWidget | None = None) -> QGroupBox:
            b = QGroupBox(title)
            bl = QVBoxLayout(b)
            if extra is not None:
                bl.addWidget(extra)
            bl.addWidget(widget, 1)
            return b

        self.period = QComboBox()
        self.period.addItems(list(self.PERIODS))
        self.period.setCurrentText("6M")
        self.period.currentIndexChanged.connect(self.draw_perf)
        prow = QWidget()
        pl = QHBoxLayout(prow)
        pl.setContentsMargins(0, 0, 0, 0)
        self.perf_lbl = QLabel("")
        self.perf_lbl.setStyleSheet(f"color:{MUTED};")
        pl.addWidget(QLabel("Period"))
        pl.addWidget(self.period)
        pl.addWidget(self.perf_lbl, 1)
        g.addWidget(box("Sector allocation (% of current value)", self.pl_alloc), 0, 0)
        g.addWidget(box("Sector P&L (₹)", self.pl_sector_pnl), 0, 1)
        g.addWidget(box("Value of today's holdings over time", self.pl_perf, prow), 1, 0)
        g.addWidget(box("Top 10 holdings (% of portfolio)", self.pl_top), 1, 1)
        return w

    def _build_gainers(self) -> QWidget:
        w = QWidget()
        v = QVBoxLayout(w)
        row = QHBoxLayout()
        row.addWidget(QLabel("Rank by"))
        self.basis = QComboBox()
        self.basis.addItems(list(self.BASIS))
        self.basis.currentIndexChanged.connect(self.draw_gainers)
        row.addWidget(self.basis)
        row.addStretch(1)
        v.addLayout(row)
        tables = QHBoxLayout()
        self.gain_table, self.lose_table = make_table(False), make_table(False)
        for title, tbl in (("Top 10 gainers", self.gain_table), ("Top 10 losers", self.lose_table)):
            b = QGroupBox(title)
            bl = QVBoxLayout(b)
            bl.addWidget(tbl)
            tables.addWidget(b)
            tbl.cellDoubleClicked.connect(lambda r, c, t=tbl: self._open(t, r))
        v.addLayout(tables, 1)
        return w

    def _open(self, table: QTableWidget, row: int):
        it = table.item(row, 0)
        if it is not None:
            self.openStock.emit(it.text())

    # ------------------------------------------------------------------ data
    def refresh(self):
        self.all, self.pos, self.trades = build_holdings(self.state)
        self.analysis.refresh()
        current = self.f_sector.currentText()
        self._loading = True
        self.f_sector.clear()
        self.f_sector.addItem("All sectors")
        self.f_sector.addItems(sorted(self.all["sector"].dropna().unique().tolist()))
        idx = self.f_sector.findText(current)
        self.f_sector.setCurrentIndex(idx if idx >= 0 else 0)
        self._loading = False
        self.apply_filters()

    def reset_filters(self):
        self._loading = True
        for c in (self.f_sector, self.f_cap, self.f_pnl, self.f_day):
            c.setCurrentIndex(0)
        self.f_search.clear()
        self._loading = False
        self.apply_filters()

    def filters_active(self) -> bool:
        return bool(self.f_sector.currentIndex() or self.f_cap.currentIndex() or self.f_pnl.currentIndex()
                    or self.f_day.currentIndex() or self.f_search.text().strip())

    def apply_filters(self, *_):
        if self._loading:
            return
        d = self.all
        if self.f_sector.currentIndex() > 0:
            d = d[d["sector"] == self.f_sector.currentText()]
        if self.f_cap.currentIndex() > 0:
            d = d[d["cap"] == self.f_cap.currentText()]
        if self.f_pnl.currentIndex() == 1:
            d = d[d["pnl"] > 0]
        elif self.f_pnl.currentIndex() == 2:
            d = d[d["pnl"] < 0]
        if self.f_day.currentIndex() == 1:
            d = d[d["day_pct"] > 0]
        elif self.f_day.currentIndex() == 2:
            d = d[d["day_pct"] < 0]
        q = self.f_search.text().strip().lower()
        if q:
            d = d[d["symbol"].str.lower().str.contains(q, regex=False) | d["name"].str.lower().str.contains(q, regex=False)]
        d = d.copy()
        tot = d["value"].sum()
        d["weight"] = d["value"] / tot * 100 if tot else math.nan      # weight within the filtered set
        self.view = d
        self.draw_cards()
        self.draw_overview()
        populate(self.hold_table, d, self.HOLD_SPEC)
        self.hold_table.sortByColumn(7, Qt.SortOrder.DescendingOrder)
        self.draw_gainers()
        self.draw_sectors()
        self.draw_perf()

    # ------------------------------------------------------------------ drawing
    def _set_card(self, key: str, main: str, sub: str, value=None):
        v, s = self.cards[key]
        v.setText(main)
        col = color_for(value) if value is not None else None
        v.setStyleSheet(f"font-size:22px; font-weight:bold;{f' color:{col};' if col else ''}")
        s.setText(sub)

    def draw_cards(self):
        d = self.view
        if d.empty:
            msg = "No holdings yet" if self.all.empty else "No holdings match the filters"
            for key in self.cards:
                self._set_card(key, "–", msg if key == "inv" else "")
            realized = sum(p["realized"] for p in self.pos.values()) if not self.filters_active() else math.nan
            if not math.isnan(realized) and abs(realized) > 0.005:
                self._set_card("real", f"₹{realized:+,.0f}", "all closed trades", realized)
            return
        inv, val = d["invested"].sum(), d["value"].sum()
        pnl, inv_p = d["pnl"].sum(), d["inv_priced"].sum()
        pnl_pct = pnl / inv_p * 100 if inv_p else math.nan
        day, prev_v = d["day_pnl"].sum(), d["prev_value"].sum()
        day_pct = day / prev_v * 100 if prev_v else math.nan
        missing = int(d["value"].isna().sum())
        self._set_card("inv", f"₹{inv:,.0f}", f"{len(d)} holdings" + (f" · {missing} without price" if missing else ""))
        self._set_card("val", f"₹{val:,.0f}", "current market value")
        self._set_card("pnl", f"₹{pnl:+,.0f}", f"{pnl_pct:+.2f}% on invested" if not math.isnan(pnl_pct) else "", pnl)
        self._set_card("day", f"₹{day:+,.0f}", f"{day_pct:+.2f}% today" if not math.isnan(day_pct) else "no day data", day)
        # realized P&L: every symbol when unfiltered, otherwise only the filtered holdings
        syms = None if not self.filters_active() else set(d["symbol"])
        realized = sum(p["realized"] for s, p in self.pos.items() if syms is None or s in syms)
        self._set_card("real", f"₹{realized:+,.0f}", "all closed trades" if syms is None else "filtered holdings",
                       realized if abs(realized) > 0.005 else None)
        priced = set(d.loc[d["value"].notna(), "symbol"])
        scope = set(self.pos) if syms is None else syms
        flows = []
        for _tid, sym, qty, price, date, side, *_ in self.trades:
            if sym in scope and (sym in priced or self.pos.get(sym, {}).get("qty", 0) <= 1e-9):
                flows.append((parse_date(date), qty * price if side == "SELL" else -qty * price))
        flows.append((dt.date.today(), val))
        # XIRR is only meaningful when most of the money has been invested for a while. Holdings loaded from a
        # holdings PDF carry the import date, so skip XIRR when over 20% of the cost is younger than 30 days.
        buys = [(d0, -a) for d0, a in flows[:-1] if a < 0 and d0 is not None]
        total_buy = sum(a for _, a in buys)
        fresh = sum(a for d0, a in buys if (dt.date.today() - d0).days < 30) / total_buy if total_buy else 1
        x = xirr(flows) if fresh <= 0.2 else math.nan
        self._set_card("xirr", f"{x:+.1f}%" if not math.isnan(x) else "–",
                       "since first trade" if not math.isnan(x) else "needs older trade history (not for fresh imports)",
                       x if not math.isnan(x) else None)

    def _sector_frame(self) -> pd.DataFrame:
        d = self.view
        if d.empty:
            return pd.DataFrame(columns=[s[1] for s in self.SECTOR_SPEC])
        g = d.groupby("sector").agg(stocks=("symbol", "count"), invested=("invested", "sum"), value=("value", "sum"),
                                    pnl=("pnl", "sum"), inv_priced=("inv_priced", "sum"),
                                    day_pnl=("day_pnl", "sum"), prev_value=("prev_value", "sum")).reset_index()
        g["pnl_pct"] = (g["pnl"] / g["inv_priced"].where(g["inv_priced"] != 0) * 100)
        g["day_pct"] = (g["day_pnl"] / g["prev_value"].where(g["prev_value"] != 0) * 100)
        tot = g["value"].sum()
        g["weight"] = g["value"] / tot * 100 if tot else math.nan
        return g

    def draw_overview(self):
        g = self._sector_frame().sort_values("value", ascending=False)
        draw_hbars(self.pl_alloc, g["sector"].tolist(), g["weight"].fillna(0).tolist(), [ACCENT] * len(g), "% of value")
        g2 = g.sort_values("pnl", ascending=False)
        draw_hbars(self.pl_sector_pnl, g2["sector"].tolist(), g2["pnl"].fillna(0).tolist(),
                   [UP if v >= 0 else DOWN for v in g2["pnl"].fillna(0)], "P&L ₹")
        top = self.view.dropna(subset=["weight"]).nlargest(10, "weight")
        draw_hbars(self.pl_top, top["symbol"].tolist(), top["weight"].tolist(), [AMBER] * len(top), "% of value")

    def draw_sectors(self):
        g = self._sector_frame()
        populate(self.sector_table, g, self.SECTOR_SPEC)
        self.sector_table.sortByColumn(3, Qt.SortOrder.DescendingOrder)
        if len(g) and g["pnl_pct"].notna().any():
            best, worst = g.loc[g["pnl_pct"].idxmax()], g.loc[g["pnl_pct"].idxmin()]
            self.sector_note.setText(f"Best sector: {best['sector']} ({best['pnl_pct']:+.2f}%)  ·  "
                                     f"Weakest sector: {worst['sector']} ({worst['pnl_pct']:+.2f}%)")
        else:
            self.sector_note.setText("")

    def draw_gainers(self, *_):
        col = self.BASIS[self.basis.currentText()]
        d = self.view.dropna(subset=[col])
        if d.empty:
            gain = lose = d
        else:
            gain = d[d[col] > 0].nlargest(10, col)
            lose = d[d[col] < 0].nsmallest(10, col)
        keys = [s[1] for s in self.GL_SPEC]
        for tbl, frame, order in ((self.gain_table, gain, Qt.SortOrder.DescendingOrder),
                                  (self.lose_table, lose, Qt.SortOrder.AscendingOrder)):
            populate(tbl, frame, self.GL_SPEC)
            tbl.sortByColumn(keys.index(col), order)

    def draw_perf(self, *_):
        d = self.view
        days = self.PERIODS[self.period.currentText()]
        plot = self.pl_perf
        plot.clear()
        price_history = {**self.state.portfolio_history, **self.state.prices}
        syms = [s for s in d["symbol"] if s in price_history]
        if not syms:
            self.perf_lbl.setText("No price history for these holdings.")
            return
        closes = pd.concat({s: price_history[s]["Close"] for s in syms}, axis=1).sort_index()
        closes = closes.ffill().bfill()
        if days:
            closes = closes[closes.index >= closes.index[-1] - pd.Timedelta(days=days)]
        if len(closes) < 2:
            self.perf_lbl.setText("Not enough price history.")
            return
        qty = d.set_index("symbol")["qty"].reindex(closes.columns)
        value = (closes * qty).sum(axis=1)
        invested = float(d.loc[d["symbol"].isin(syms), "invested"].sum())
        self.perf_axis.dates = list(value.index)
        xs = list(range(len(value)))
        plot.plot(xs, value.tolist(), pen=pg.mkPen(ACCENT, width=2))
        plot.addItem(pg.InfiniteLine(pos=invested, angle=0, pen=pg.mkPen(AMBER, style=Qt.PenStyle.DashLine),
                                     label="invested", labelOpts={"color": AMBER, "position": 0.08}))
        chg = (value.iloc[-1] / value.iloc[0] - 1) * 100
        skipped = len(d) - len(syms)
        self.perf_lbl.setText(f"{chg:+.2f}% over the period (today's quantities)"
                              + (f" · {skipped} holding(s) without history left out" if skipped else ""))
        plot.enableAutoRange()

    def export_csv(self):
        if self.view.empty:
            QMessageBox.information(self, "Nothing to export", "There are no holdings to export.")
            return
        path, _ = QFileDialog.getSaveFileName(self, "Export holdings", "portfolio_holdings.csv", "CSV (*.csv)")
        if path:
            cols = ["symbol", "name", "sector", "cap", "qty", "avg", "ltp", "invested", "value", "day_pct",
                    "day_pnl", "pnl", "pnl_pct", "weight"]
            self.view[cols].round(2).to_csv(path, index=False)
            self.note.setText(f"Exported {len(self.view)} holdings to {path}")


# ---- Main window ------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Indian Stock Screener · Nifty 500")
        self.resize(1400, 860)
        self.state = AppState()
        self.worker: DataWorker | None = None
        self.extra_worker: ExtraPriceWorker | None = None
        self.pending_quotes = False
        self.pending_force_quotes = False
        self.closing = False

        central = QWidget()
        lay = QVBoxLayout(central)
        head = QHBoxLayout()
        title = QLabel("Nifty 500 Screener")
        title.setStyleSheet("font-size:18px; font-weight:bold;")
        self.age = QLabel("")
        self.age.setStyleSheet(f"color:{MUTED};")
        self.btn_refresh = QPushButton("⟳ Refresh data")
        self.btn_refresh.clicked.connect(lambda: self.start_refresh(False))
        self.btn_full = QPushButton("Refresh incl. fundamentals")
        self.btn_full.setToolTip("Re-download fundamentals for every stock (slow, a few minutes).")
        self.btn_full.clicked.connect(lambda: self.start_refresh(True))
        head.addWidget(title)
        head.addStretch(1)
        head.addWidget(self.age)
        head.addWidget(self.btn_refresh)
        head.addWidget(self.btn_full)
        lay.addLayout(head)

        self.tabs = QTabWidget()
        self.dashboard = DashboardTab(self.state)
        self.screener = ScreenerTab(self.state)
        self.stock = StockTab(self.state)
        self.importer = ImportTab(self.state)
        self.portfolio = PortfolioTab(self.state)
        self.pdash = PortfolioDashboardTab(self.state)
        for w, name in ((self.dashboard, "Dashboard"), (self.screener, "Screener"),
                        (self.stock, "Stock"), (self.importer, "Portfolio Import"),
                        (self.portfolio, "Watchlist && Portfolio"), (self.pdash, "Portfolio Dashboard")):
            self.tabs.addTab(w, name)
        lay.addWidget(self.tabs, 1)
        self.setCentralWidget(central)

        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.statusBar().addPermanentWidget(self.progress)
        self.status_lbl = QLabel("")
        self.statusBar().addWidget(self.status_lbl)

        for w in (self.dashboard, self.screener, self.portfolio, self.pdash):
            w.openStock.connect(self.open_stock)
        self.importer.portfolioChanged.connect(self.on_portfolio_changed)
        self.importer.clearRequested.connect(self.clear_portfolio)
        self.importer.previewPricesRequested.connect(self.refresh_extra)
        self.pdash.clearRequested.connect(self.clear_portfolio)
        self.pdash.pricesRequested.connect(lambda: self.refresh_extra(force=True))
        self.pdash.analysis.message.connect(self.status_lbl.setText)
        self.portfolio.portfolioChanged.connect(self.on_portfolio_changed)
        self.screener.message.connect(self.status_lbl.setText)
        self.stock.watchChanged.connect(self.portfolio.refresh_watch)
        self.portfolio.watchChanged.connect(self.stock._update_watch_btn)

        QTimer.singleShot(0, self.startup)
        self.age_timer = QTimer(self)
        self.age_timer.timeout.connect(self.update_age)
        self.age_timer.start(60_000)
        self.quote_timer = QTimer(self)
        self.quote_timer.timeout.connect(self.refresh_extra)
        self.quote_timer.start(300_000)

    # -- data lifecycle
    def startup(self):
        cached = load_cache()
        if cached:
            self.apply(cached)
            hours = (time.time() - cached["updated"]) / 3600
            if hours > AUTO_REFRESH_HOURS:
                self.status_lbl.setText("Cache is old - refreshing in the background...")
                self.start_refresh(False)
        else:
            self.status_lbl.setText("First launch: downloading data. This takes a few minutes, "
                                    "later launches are instant.")
            self.start_refresh(False)
        self.portfolio.refresh()
        self.pdash.refresh()
        self.refresh_extra()

    def clear_portfolio(self):
        if not self.state.db.trades():
            QMessageBox.information(self, "Clear all portfolio", "The portfolio is already empty.")
            return
        answer = QMessageBox.question(
            self, "Clear all portfolio?",
            "Remove every holding and trade? A CSV backup will be saved first.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            deleted, _, backup = self.state.db.replace_portfolio([], BACKUP_DIR)
        except Exception as exc:
            QMessageBox.warning(self, "Could not clear portfolio", str(exc))
            return
        self.on_portfolio_changed()
        QMessageBox.information(self, "Portfolio cleared", f"Removed {deleted} trades.\nBackup: {backup}")

    def on_portfolio_changed(self):
        """Trades were added / replaced: refresh every tab that shows the portfolio."""
        self.state.reload_extra()
        self.portfolio.refresh_portfolio()
        self.pdash.refresh()
        self.refresh_extra()

    def refresh_extra(self, force: bool = False):
        if self.closing:
            return
        if self.extra_worker is not None:
            self.pending_quotes = True
            self.pending_force_quotes |= force
            return
        pos, _ = compute_positions(self.state.db.trades())
        symbols = {sym for sym, position in pos.items() if position["qty"] > 1e-9}
        if self.importer.hd_update.isEnabled():
            symbols.update(clean_symbol(self.importer.hd_table.item(r, 0).text())
                           for r in range(self.importer.hd_table.rowCount()))
        now, todo, with_analysis = dt.datetime.now(), [], set()
        for sym in sorted(symbols):
            if not SYMBOL_OK.fullmatch(sym):
                continue
            need_analysis = sym not in self.state.master.index and sym not in self.state.portfolio_metrics.index
            quote = self.state.extra.get(sym, {})
            fresh = quote.get("yahoo") and (now - dt.datetime.fromisoformat(quote["updated"])).total_seconds() < 300
            if force or not fresh:
                todo.append(sym)
                if need_analysis or (force and sym not in self.state.master.index):
                    with_analysis.add(sym)
        if not todo:
            self.importer.refresh_preview_prices()
            return
        self.status_lbl.setText(f"Fetching market prices for {len(todo)} securities…")
        self.extra_worker = ExtraPriceWorker(todo, with_analysis)
        self.extra_worker.batch.connect(self.on_extra_done)
        self.extra_worker.finished.connect(self.on_quotes_finished)
        self.extra_worker.start()

    def on_quotes_finished(self):
        self.extra_worker.deleteLater()
        self.extra_worker = None
        if self.pending_quotes and not self.closing:
            force = self.pending_force_quotes
            self.pending_quotes = self.pending_force_quotes = False
            self.refresh_extra(force)

    def on_extra_done(self, res: dict):
        for sym, q in res.items():
            sector = q["sector"] or self.state.extra.get(sym, {}).get("sector", "")
            self.state.db.set_extra_price(sym, q["price"], q["prev"], sector, True)
            if q["history"] is not None:
                universe = pd.DataFrame([{"Symbol": sym, "Name": q["name"], "Sector": sector or "Unclassified"}])
                self.state.portfolio_metrics = pd.concat([
                    self.state.portfolio_metrics.drop(index=sym, errors="ignore"),
                    build_master(universe, {sym: q["history"]}, {sym: q["funds"]})])
                self.state.portfolio_history[sym] = q["history"]
        self.state.reload_extra()
        self.importer.refresh_preview_prices()
        self.portfolio.refresh_portfolio()
        self.pdash.refresh()
        self.status_lbl.setText(f"Market prices updated for {len(res)} securities in the latest batch."
                                if res else "Market prices were unavailable for the latest batch.")

    def apply(self, payload: dict):
        self.state.load(payload)
        self.dashboard.refresh()
        self.screener.refresh()
        self.stock.refresh_symbols()
        self.portfolio.refresh()
        self.pdash.refresh()
        self.refresh_extra()
        self.update_age()

    def update_age(self):
        if not self.state.updated:
            self.age.setText("No data yet")
            return
        mins = int((time.time() - self.state.updated) / 60)
        ago = f"{mins} min ago" if mins < 90 else f"{mins // 60} h ago" if mins < 2880 else f"{mins // 1440} days ago"
        when = dt.datetime.fromtimestamp(self.state.updated).strftime("%d %b %Y %H:%M")
        self.age.setText(f"Data: {when} ({ago}) · {len(self.state.master)} stocks")

    def start_refresh(self, force_fund: bool):
        if self.worker and self.worker.isRunning():
            return
        self.progress.setValue(0)
        self.progress.setVisible(True)
        self.btn_refresh.setEnabled(False)
        self.btn_full.setEnabled(False)
        self.worker = DataWorker(self.state.fundamentals, self.state.prices, force_fund)
        self.worker.progress.connect(self.on_progress)
        self.worker.done.connect(self.on_done)
        self.worker.failed.connect(self.on_failed)
        self.worker.finished.connect(self.on_finished)
        self.worker.start()

    def on_progress(self, pct: int, text: str):
        self.progress.setValue(pct)
        self.progress.setFormat(f"{pct}%")
        self.status_lbl.setText(text)

    def on_done(self, payload: dict):
        self.apply(payload)
        self.status_lbl.setText("Data updated.")

    def on_failed(self, msg: str):
        self.status_lbl.setText("Download failed.")
        QMessageBox.warning(self, "Download failed",
                            f"{msg}\n\nCached data (if any) is still being shown.")

    def on_finished(self):
        self.progress.setVisible(False)
        self.btn_refresh.setEnabled(True)
        self.btn_full.setEnabled(True)

    def open_stock(self, sym: str):
        self.tabs.setCurrentWidget(self.stock)
        self.stock.load(sym)

    def closeEvent(self, event):
        self.closing = True
        if self.extra_worker and self.extra_worker.isRunning():
            self.extra_worker.requestInterruption()
            if not self.extra_worker.wait(500):
                event.ignore()
                self.extra_worker.finished.connect(self.close)
                return
        if self.worker and self.worker.isRunning():
            self.worker.requestInterruption()
            if not self.worker.wait(4000):
                self.worker.terminate()
                self.worker.wait(1000)
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    app.setStyleSheet(STYLESHEET)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
