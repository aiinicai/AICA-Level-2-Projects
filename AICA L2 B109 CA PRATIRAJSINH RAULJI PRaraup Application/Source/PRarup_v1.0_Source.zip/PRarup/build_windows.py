"""Run on Windows after installing requirements-dev.txt."""
import os
import subprocess
import sys
from pathlib import Path
if sys.platform != "win32":
    raise SystemExit("Build on Windows for a Windows executable.")
root = Path(__file__).resolve().parent
onefile = "--onefile" in sys.argv
build_name = "PRarup_v1.0" if onefile else "PRarup"
# Isolate DLL discovery from unrelated tools installed on the build machine.
# Qt uses the Windows ICU forwarder; a third-party ICU on PATH can break startup.
build_env = os.environ.copy()
windows = Path(os.environ.get("SystemRoot", "C:/Windows"))
python_dir = Path(sys.executable).parent
build_env["PATH"] = os.pathsep.join(map(str, [windows / "System32", windows, python_dir, python_dir / "Scripts"]))
subprocess.run([sys.executable, "-m", "PyInstaller", "--noconfirm", "--clean", "--windowed", "--onefile" if onefile else "--onedir", "--name", build_name, "--icon", str(root / "assets/icons/prarup.ico"), "--add-data", str(root / "assets") + ";assets", "--add-data", str(root / "schemas") + ";schemas", "--add-data", str(root / "templates") + ";templates", str(root / "main.py")], cwd=root, env=build_env, check=True)
