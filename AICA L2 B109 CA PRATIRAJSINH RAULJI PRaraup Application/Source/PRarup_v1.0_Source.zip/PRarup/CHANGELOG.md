# Changelog

## 1.0.0 — 2026-11-13
- Three print styles, real A4 preview/printing, justified serif typography, page footers, stamp space and clean/review copy modes.
- Clients with questionnaire prefill; all-document history, duplication and archive/restore; favorites.
- Custom template editor, typed JSON questionnaires, immutable versions, imports/exports, disable and restore.
- Consistent workspace recovery packages, validation before restore and pre-restore recovery preservation.
- Optional salted-password interface locking, single-instance guard and backward-compatible schema migration.
- Ten new document types; sixteen available workflows total.
- 60 automated tests, packaged workflow/office checks, single-file Windows EXE and PDF manuals.

## 0.3.0 — 2026-11-13
- Six functional document types with schema-based forms, review and editable generation.
- Partnership repeating groups (2–50), 100% share validation and optional provisions.
- Search/category library and Dashboard new-document entry point.
- Draft saving, reopening, regeneration with replacement confirmation and stale-preview prevention.
- Editable Word export and independent native Qt PDF export.
- Versioned schema/clauses/layout, legal review metadata, 20 regression tests and packaged workflow check.

## 0.1.0 — 2026-11-13
Foundation: bilingual branding, splash, navigable sidebar, database dashboard, persisted themes, SQLite schema version 1, startup integrity check, daily online backup, local logs and Windows build script.
