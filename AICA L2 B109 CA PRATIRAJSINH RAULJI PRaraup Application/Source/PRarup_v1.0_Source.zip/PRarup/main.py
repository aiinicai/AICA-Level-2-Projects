from prarup.core.application import run
if __name__ == "__main__":
    raise SystemExit(run())
