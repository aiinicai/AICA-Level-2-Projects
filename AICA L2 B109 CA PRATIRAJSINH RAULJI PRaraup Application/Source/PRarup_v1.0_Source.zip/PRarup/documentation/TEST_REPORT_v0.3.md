# PRarup 0.3.0 verification
Date: 2026-11-13. Windows 11 x64, Python 3.15.2, PyQt6 6.12.0, SQLAlchemy 2.1.8, docxtpl 0.20.2, python-docx 1.2.0, Jinja2 3.1.6, pytest 9.2.0, pytest-qt 4.5.0.

20 automated tests passed after final source changes. Coverage includes foundation regressions; all six templates generating DOCX/PDF; unresolved template token checks; optional interest/remuneration/arbitration/fixed-term branches; five-partner totals; currency/words; validation of invalid dates, nonfinite amounts, GSTIN; safe literal user inputs; save/reopen/manual edits and stale-preview prevention; repeat/conditional UI; library filters and selection.

An opt-in application --workflow-check exercised each document's questionnaire, review, draft preparation, save, reopen, Word and PDF export against an isolated temporary database. The same check is used for the frozen Windows EXE. A normal application launch smoke test is also performed. User records are never used for these checks.

Source UI screenshots were inspected for library, details tabs and editable draft. All nine pages of the six refined sample PDF exports were rendered using bundled Poppler and visually inspected. Word exports were reopened with python-docx and checked structurally. The bundled render_docx.py was attempted but failed because soffice.exe is not bundled/available. Word pagination and visual layout therefore remain unverified. No claim is made that Word/PDF layouts are identical.

Legal templates: all six remain Pending Legal Review. Official reference URLs are recorded in schema metadata; research includes source discovery and CBIC registration reference access. Some India Code PDF retrievals timed out. No legal verification date is asserted; state stamp rates or filing compliance are not certified.

Not verified: separate clean Windows installation, Windows 10, Python 3.12, digitally signed distribution, screen-reader use, large-document performance, 50-partner visual layout, formal legal approval. No client CRUD, template import UI, backup restore UI or complete original milestone 4–6 completion is claimed.

## Frozen build result
The rebuilt windowed Windows EXE passed --workflow-check for all six document types without PYTHONPATH. Twelve nonempty Word/PDF outputs were created in an isolated workspace, all six saved drafts reopened correctly, and a subsequent normal --smoke-test launch exited successfully.
