# Milestone 1 verification

Date: 2026-11-13
Host: Windows, Python 3.15.2, PyQt6 6.12.0, SQLAlchemy 2.1.8, pytest 9.2.0, pytest-qt 4.5.0.

Seven automated tests passed: actual dashboard counts/history; persisted settings on reopen; transaction rollback; consistent backup integrity and schema; rejection of newer schemas; Qt navigation/theme/collapse; refreshed dashboard records.

Windows GUI startup with --smoke-test exited successfully. Offscreen Qt tests and a rendered dashboard preview were used for verification. Visual inspection caught and corrected a Hindi shaping issue caused by splitting a combining sequence across rich-text spans. The full Devanagari word is now kept together.

Not verified: Python 3.12 environment, clean-machine installation, packaged EXE, screen-reader behavior, multi-monitor DPI switching, non-Windows systems. PyInstaller was not installed/run. No executable or installer is delivered. Legal research, templates, DOCX/PDF exports and later milestone acceptance tests are not part of this foundation.

Dependencies were downloaded into a temporary workspace directory for verification, excluded from the delivery archive. Install requirements before launch. Source compilation and all seven tests were rerun after the branding correction.

## Windows EXE follow-up
PyInstaller 6.22.3 subsequently built a Windows x64 portable application. Its direct EXE smoke test passed startup, database integrity, default theme persistence and clean exit. See WINDOWS_BUILD.md for build fixes and limitations. A clean-machine test remains outstanding.
