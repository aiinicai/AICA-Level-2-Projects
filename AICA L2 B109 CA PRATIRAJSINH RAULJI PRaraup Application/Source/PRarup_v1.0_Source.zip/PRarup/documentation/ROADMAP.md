# Remaining after 1.0
The Client, History, Templates, Favorites, workspace recovery and screen-lock interfaces now function. This release has 16 available, tested drafting workflows.

Remaining: formal legal review of all templates; state-specific stamp/registration/filing checks; the rest of the original larger document catalogue; arbitrary rich-layout DOCX import; encrypted storage; signed installer; clean-machine/platform, hardware-printer, accessibility and volume testing. The JSON questionnaire editor is advanced rather than visual. No claim is made that all original six milestones and their entire catalogue are finished.
