# Research and design references
Searched on 2026-11-13 at the user's request. Original PRarup clauses and layouts are used; no complete commercial template was copied or purchased. External template websites were used to examine presentation and document-automation conventions, not to certify Indian law.

## Presentation references
- Wonder.Legal India Partnership Deed: https://www.wonder.legal/in/modele/partnership-deed
- Wonder.Legal questionnaire/preview: https://www.wonder.legal/in/creation-modele/partnership-deed
- LawDepot India addendum: https://www.lawdepot.com/in/business/addendum/ (JavaScript-only page in text browsing)
- Rocket Lawyer partnership workflow: https://www.rocketlawyer.com/business-and-contracts/business-operations/business-partnerships/document/partnership-agreement (foreign jurisdiction; presentation reference only)

## Government model and legal references
- NGDRS model Partnership Deed: https://ngdrs.gov.in/NGDRS_Website/templates/madhya_pradesh/Partnership_deed_template_v1.pdf
- Goa Registration model: https://www.registration.goa.gov.in/wp-content/uploads/2020/12/FORMAT-OF-DRAFT-PARTNERSHIP-DEEDFinal.pdf
- Goa government commercial-contract forms: https://www.goa.gov.in/wp-content/uploads/2017/09/Commercial-Contract-Templates-new.pdf
- India Code Indian Partnership Act: https://www.indiacode.nic.in/bitstream/123456789/2394/1/A1932-9.pdf
- India Code LLP Act: https://www.indiacode.nic.in/bitstream/123456789/2023/1/A2009-06.pdf
- MCA Form 3 FAQ: https://www.mca.gov.in/content/dam/mca/pdf/Revised-Filing-Steps-and-FAQs-of-Form-3-LLP-20230607.pdf
- MCA Form 4 instructions: https://www.mca.gov.in/content/dam/mca-aem-forms/instructionkits/Instruction%20Kit_LLP_Form_No_%204.pdf
- CBIC registration reference: https://cbic-gst.gov.in/gst-registration-rules.html
- GST portal registration guide: https://tutorial.gst.gov.in/userguide/registration/Apply_for_Registration_Normal_Taxpayer.htm

Several government PDF fetches timed out; the MCA Form 3 PDF open returned 403. Search indexing and reference discovery do not establish full legal review. Every template keeps last_legal_verification=null and Pending Legal Review. Rates, filings and eligibility must be independently verified for the selected state and transaction. Generic declarations and limited authorizations are not represented as prescribed statutory forms.
