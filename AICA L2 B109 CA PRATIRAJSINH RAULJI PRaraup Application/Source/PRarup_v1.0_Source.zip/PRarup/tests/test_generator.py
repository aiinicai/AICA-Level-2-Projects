import json
from pathlib import Path
import pytest
from PyQt6.QtCore import QDate
from docx import Document
from prarup.services.template_service import TemplateService
from prarup.services.document_engine import DocumentEngine, inr, amount_words
from prarup.services.validation_service import validate, ValidationError
from prarup.services.export_service import export_docx, export_pdf
from prarup.repositories.documents import DocumentRepository
from prarup.ui.document_wizard import DocumentWizard
from prarup.ui.document_library import DocumentLibrary


def sample(template):
    def fields(items):
        data = {}
        for f in items:
            key, kind = f['id'], f['type']
            if kind == 'repeat':
                data[key] = [fields(f['fields']) for _ in range(2)]
                for i, row in enumerate(data[key]):
                    row['name'] = 'Partner ' + str(i+1)
                    row['share'] = '50'
                    row['capital'] = '125000.50'
            elif kind == 'date':
                data[key] = '2027-01-01' if key in ('valid_until','end_date') else '2026-11-13'
            elif kind == 'choice':
                data[key] = f['options'][0]
            elif kind == 'bool':
                data[key] = False
            elif kind == 'number':
                data[key] = str(f.get('default', 5))
            elif kind == 'currency':
                data[key] = '15000.50'
            elif kind == 'percent':
                data[key] = '10'
            else:
                data[key] = {'gstin':'24ABCDE1234F1Z5','cin':'U12345GJ2020PTC123456','firm_name':'Sample & Partners','office':'Office 12, Example Road, Vadodara, Gujarat'}.get(key,'Sample '+f['label'])
        return data
    return {k:v for s in template['sections'] for k,v in fields(s['fields']).items()}

@pytest.mark.parametrize('key', ['partnership','rent','noc','authority','gst_authorization','board'])
def test_template_generation_and_exports(key, tmp_path, qapp):
    templates = TemplateService()
    template = templates.get(key)
    text = DocumentEngine(templates).generate(template, sample(template))
    assert len(text) > 500
    assert '{{' not in text and '{%' not in text
    word = tmp_path / (key+'.docx')
    pdf = tmp_path / (key+'.pdf')
    export_docx(text, word)
    export_pdf(text, pdf)
    document = Document(word)
    assert document.paragraphs[0].text in text
    assert 'Pending Legal Review' in document.paragraphs[1].text
    assert all(x not in '\n'.join(p.text for p in document.paragraphs) for x in ('{{ title }}','{{ review_notice }}'))
    assert pdf.read_bytes().startswith(b'%PDF-')
    assert pdf.stat().st_size > 1000


def test_partnership_cross_validation_and_conditions():
    templates = TemplateService(); template = templates.get('partnership')
    data = sample(template)
    data['partners'][0]['share']='49.99'
    with pytest.raises(ValidationError, match='100%'):
        validate(template,data)
    data['partners'][0]['share']='50'
    data['interest_enabled']=True
    data['interest_rate']=''
    with pytest.raises(ValidationError, match='required'):
        validate(template,data)
    data.update(interest_rate='10', duration='Fixed term', end_date='2027-01-01', remuneration_enabled=True, remuneration='Partner 1 INR 10000 monthly; Partner 2 INR 10000 monthly.', dispute='Arbitration', arbitration_seat='Vadodara')
    text=DocumentEngine(templates).generate(template,data)
    assert '10% per annum' in text and 'sole arbitrator' in text
    assert 'ends on 01 January 2027' in text


def test_five_partners_and_currency():
    templates=TemplateService(); t=templates.get('partnership'); data=sample(t)
    data['partners']=[dict(data['partners'][0],name='Partner '+str(i),share='20') for i in range(5)]
    text=DocumentEngine(templates).generate(t,data)
    assert 'Partner 4' in text
    assert '6,25,002.50' in text
    assert amount_words('100000.25')=='Rupees One Lakh and Twenty Five Paise Only'
    assert inr('12345678.90')=='1,23,45,678.90'


def test_no_user_template_execution():
    templates=TemplateService();t=templates.get('noc');data=sample(t)
    data['owner']='{{ 7*7 }} <unsafe & text>'
    text=DocumentEngine(templates).generate(t,data)
    assert '{{ 7*7 }} <unsafe & text>' in text


def test_invalid_dates_amounts_and_ids():
    templates=TemplateService();t=templates.get('rent');data=sample(t)
    data.update(start_date='2027-02-01',end_date='2027-01-01',rent='NaN')
    with pytest.raises(ValidationError):validate(t,data)
    t=templates.get('gst_authorization');data=sample(t);data['gstin']='invalid'
    with pytest.raises(ValidationError, match='GSTIN'):validate(t,data)


def test_save_reopen_regenerate_and_manual_edits(qtbot, store, tmp_path):
    (tmp_path/'documents').mkdir(exist_ok=True)
    templates=TemplateService();t=templates.get('partnership')
    payload={'values':sample(t),'text':''}
    wizard=DocumentWizard(t,templates,store,tmp_path,payload=payload)
    qtbot.addWidget(wizard)
    wizard.advance();assert wizard.pages.currentIndex()==1
    wizard.advance();assert wizard.pages.currentIndex()==2
    assert 'Sample & Partners' in wizard.editor.toPlainText()
    wizard.editor.append('Manual addition from professional review.')
    assert wizard.save_draft()
    saved=DocumentRepository(store).get(wizard.document_id)
    assert 'Manual addition' in saved['text']
    reopened=DocumentWizard(t,templates,store,tmp_path,document_id=wizard.document_id,payload=saved)
    qtbot.addWidget(reopened)
    assert reopened.pages.currentIndex()==2
    assert 'Manual addition' in reopened.editor.toPlainText()
    assert reopened.values()['firm_name']=='Sample & Partners'
    # Changed form values must not be saved together with a stale generated document.
    reopened.forms[0].controls['firm_name'].setText('Updated firm')
    assert reopened.save_draft()
    assert DocumentRepository(store).get(wizard.document_id)['text']==''
    assert store.stats()['Drafts']==1


def test_repeat_and_conditional_ui(qtbot):
    from prarup.widgets.schema_form import FieldsForm
    t=TemplateService().get('partnership')
    form=FieldsForm(t['sections'][1]['fields'])
    qtbot.addWidget(form)
    group=form.controls['partners']
    for _ in range(3):group.add_button.click()
    assert len(group.values())==5
    group.remove_button.click();assert len(group.values())==4
    conditions=FieldsForm(t['sections'][2]['fields'])
    qtbot.addWidget(conditions)
    assert conditions.rows['interest_rate'][1].isHidden()
    conditions.controls['interest_enabled'].setChecked(True)
    assert not conditions.rows['interest_rate'][1].isHidden()


def test_library_filter_and_selection(qtbot):
    library=DocumentLibrary(TemplateService());qtbot.addWidget(library)
    library.search.setText('Partnership Deed')
    assert sum(not card.isHidden() for _,card in library.cards)==1
    library.search.setText('no-such-document')
    assert not library.empty.isHidden()
    library.search.clear()
    with qtbot.waitSignal(library.selected) as signal:
        library.cards[0][1].findChildren(__import__('PyQt6.QtWidgets',fromlist=['QPushButton']).QPushButton)[0].click()
    assert signal.args[0] in library.templates.templates
