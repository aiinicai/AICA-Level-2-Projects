import sqlite3
import pytest
from sqlalchemy import text
from prarup.models.entities import Client, Document
from prarup.database.store import Store
from prarup.ui.main_window import MainWindow

def test_counts_and_recent(store):
    assert store.stats() == {"Clients": 0, "Documents": 0, "Drafts": 0}
    with store.sessions.begin() as session:
        session.add(Client(name="Test client"))
        session.add(Document(title="Test draft"))
        session.add(Document(title="Exported record", status="exported"))
    assert store.stats() == {"Clients": 1, "Documents": 2, "Drafts": 1}
    assert len(store.recent()) == 2

def test_settings_reopen(store, tmp_path):
    store.set_setting("theme", "Dark")
    other = Store(tmp_path)
    assert other.setting("theme") == "Dark"
    other.close()

def test_rollback(store):
    with pytest.raises(RuntimeError):
        with store.sessions.begin() as session:
            session.add(Client(name="Rollback"))
            raise RuntimeError("abort")
    assert store.stats()["Clients"] == 0

def test_backup_integrity(store, tmp_path):
    backup = store.backup(tmp_path / "manual")
    with sqlite3.connect(backup) as db:
        assert db.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        assert db.execute("PRAGMA user_version").fetchone()[0] == 2
    assert store.backup(tmp_path / "manual") == backup

def test_future_schema_refused(tmp_path):
    with sqlite3.connect(tmp_path / "prarup.db") as db:
        db.execute("PRAGMA user_version=99")
    with pytest.raises(RuntimeError, match="newer"):
        Store(tmp_path)

def test_navigation_themes_and_collapse(qtbot, store, tmp_path):
    window = MainWindow(store, tmp_path)
    qtbot.addWidget(window)
    window.show()
    for i, button in enumerate(window.buttons):
        button.click()
        assert window.pages.currentIndex() == i
        assert button.isChecked()
    settings = window.pages.widget(4)
    settings.theme.setCurrentText("Dark")
    assert store.setting("theme") == "Dark"
    window.toggle_sidebar()
    assert window.sidebar.width() == 84
    window.toggle_sidebar()
    assert window.sidebar.width() == 245
    window.navigate(0)
    assert "0" in window.dashboard.labels["Clients"].text()

def test_dashboard_reflects_changes(qtbot, store, tmp_path):
    window = MainWindow(store, tmp_path)
    qtbot.addWidget(window)
    with store.sessions.begin() as session:
        session.add(Document(title="Real record"))
    window.navigate(0)
    assert window.dashboard.labels["Documents"].text().startswith("1")
    assert "Real record" in window.dashboard.recent_list.item(0).text()
