import copy
import hashlib
import json
import sqlite3
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import pytest
from docx import Document as WordDocument
from pypdf import PdfReader
from prarup.database.store import Store
from prarup.services.client_service import ClientService
from prarup.services.template_service import TemplateService
from prarup.services.backup_service import BackupService
from prarup.services.locking import password_record,verify_password
from prarup.services.document_engine import DocumentEngine
from prarup.services.validation_service import ValidationError,validate
from prarup.services.export_service import export_pdf,export_docx,PrintDocument,STYLES
from prarup.repositories.documents import DocumentRepository
from prarup.core.verification import verification_values


def test_v1_database_migration(tmp_path):
    with sqlite3.connect(tmp_path/'prarup.db') as db:
        db.executescript("CREATE TABLE clients (id INTEGER PRIMARY KEY, name TEXT NOT NULL); CREATE TABLE documents (id INTEGER PRIMARY KEY,title TEXT NOT NULL,status TEXT NOT NULL,updated_at TEXT NOT NULL,payload TEXT NOT NULL); CREATE TABLE settings (key TEXT PRIMARY KEY,value TEXT NOT NULL); PRAGMA user_version=1;")
        db.execute("INSERT INTO clients VALUES (1,'Existing office client')")
        db.execute("INSERT INTO documents VALUES (1,'Existing draft','draft','2026-11-13','{}')")
    store=Store(tmp_path)
    assert ClientService(store).get(1)['name']=='Existing office client'
    assert store.stats()['Documents']==1
    with sqlite3.connect(store.path) as db:assert db.execute('PRAGMA user_version').fetchone()[0]==2
    assert list((tmp_path/'backups').glob('*.db'))
    store.close()


def test_client_prefill_update_and_safe_delete(store):
    clients=ClientService(store);templates=TemplateService();t=templates.get('partnership')
    key=clients.save({'name':'Test client','business_name':'Office Test Partners','address':'Test office','pan':'ABCDE1234F','people':[{'name':'First','address':'A','capital':'100','share':'50'},{'name':'Second','address':'B','capital':'100','share':'50'}]})
    assert clients.search('Office Test')[0]['id']==key
    values=clients.prefill(t,clients.get(key));assert values['firm_name']=='Office Test Partners' and len(values['partners'])==2
    repo=DocumentRepository(store);draft=repo.save(t,values,'Existing text',client_id=key)
    assert len(repo.search(client_id=key))==1
    clients.save(dict(clients.get(key),name='Changed client'),key)
    assert clients.get(key)['name']=='Changed client'
    clients.delete(key)
    assert repo.get(draft)['client_id'] is None
    assert repo.get(draft)['text']=='Existing text'
    assert clients.search()==[]


def test_client_validation(store):
    clients=ClientService(store)
    with pytest.raises(ValueError):clients.save({'name':''})
    with pytest.raises(ValueError,match='PAN'):clients.save({'name':'X','pan':'invalid'})


def test_history_duplicate_archive(store):
    service=TemplateService();t=service.get('noc');repo=DocumentRepository(store)
    key=repo.save(t,verification_values(t),'My draft')
    copy_key=repo.duplicate(key);assert key!=copy_key and len(repo.search())==2
    repo.archive(key);assert len(repo.search())==1 and len(repo.search(archived=True))==1
    repo.archive(key,False);assert len(repo.search())==2
    assert repo.search('%')==[]


def custom_definition(service):
    item=service.new_definition()
    return item,'OFFICE AUTHORIZATION\n\nI, {{ signer }}, authorize the following purpose:\n\n{{ purpose }}'


def test_template_versions_enable_restore_and_old_draft(tmp_path):
    service=TemplateService(tmp_path);item,text=custom_definition(service)
    key=service.save_version(item,text)
    assert key in service.templates
    second=dict(item,version='1.1',name='Revised office document')
    service.save_version(second,text+'\n\nRevised conditions.')
    assert service.get(key)['version']=='1.1'
    assert service.get(key,'1.0',True)['version']=='1.0'
    with pytest.raises(ValueError,match='already exists'):service.save_version(second,text)
    service.set_enabled(key,False);assert key not in service.templates
    assert service.get(key,'1.0',True)['name']==item['name']
    service.restore_version(key,'1.0');service.set_enabled(key,True)
    assert service.get(key)['version']=='1.0'


def test_builtin_duplicate_and_render(tmp_path):
    service=TemplateService(tmp_path);item,text=service.duplicate('partnership')
    key=service.save_version(item,text)
    values=verification_values(service.get(key))
    result=DocumentEngine(service).generate(service.get(key),values)
    assert 'PARTNERSHIP DEED' in result


@pytest.mark.parametrize('text',['{{ signer.__class__ }}','{{ signer * 100000000 }}','{{ range(1000) }}','{% include "other" %}','{{ missing_field }}'])
def test_unsafe_custom_templates_rejected(tmp_path,text):
    service=TemplateService(tmp_path);item,_=custom_definition(service)
    with pytest.raises(ValueError):service.validate_package(item,text)


def test_docx_import_supported_scope(tmp_path):
    path=tmp_path/'office.docx';doc=WordDocument();doc.add_paragraph('AUTHORITY LETTER');doc.add_paragraph('I, {{ client_name }}, authorize {{ person }}.');doc.save(path)
    service=TemplateService(tmp_path);item,clause=service.import_docx(path)
    assert {f['id'] for f in item['sections'][0]['fields']}=={'client_name','person'}
    service.save_version(item,clause)
    assert 'Test User' in DocumentEngine(service).generate(service.get(item['id']),{'client_name':'Test User','person':'Representative'})
    doc.add_table(1,1);doc.save(path)
    with pytest.raises(ValueError,match='paragraph'):service.import_docx(path)


def test_workspace_backup_restore_preserves_recovery(store,tmp_path):
    clients=ClientService(store);clients.save({'name':'Before backup'})
    service=TemplateService(tmp_path);item,text=custom_definition(service);key=service.save_version(item,text)
    backup=tmp_path/'saved.zip';BackupService(store,tmp_path).create(backup)
    clients.save({'name':'After backup'})
    service.save_version(dict(item,version='1.1'),text+' Revised.')
    recovery=BackupService(store,tmp_path).restore(backup)
    assert recovery.exists()
    assert [x['name'] for x in clients.search()]==['Before backup']
    assert TemplateService(tmp_path).get(key)['version']=='1.0'
    assert list(tmp_path.glob('templates-before-restore-*'))


def test_tampered_backup_rejected_without_changes(store,tmp_path):
    ClientService(store).save({'name':'Preserve'})
    path=tmp_path/'bad.zip'
    with ZipFile(path,'w') as z:
        z.writestr('prarup.db',b'bad');z.writestr('manifest.json',json.dumps({'format':1,'files':{'prarup.db':'bad-digest'}}))
    with pytest.raises(ValueError,match='checksum'):BackupService(store,tmp_path).restore(path)
    assert store.stats()['Clients']==1


def test_traversal_backup_rejected(store,tmp_path):
    path=tmp_path/'traversal.zip';content=b'x'
    with ZipFile(path,'w') as z:
        z.writestr('../outside',content);z.writestr('manifest.json',json.dumps({'format':1,'files':{'../outside':hashlib.sha256(content).hexdigest()}}))
    with pytest.raises(ValueError,match='Unsafe'):BackupService(store,tmp_path).restore(path)


def test_password_hashes():
    first=password_record('test-password-123');second=password_record('test-password-123')
    assert first!=second and 'test-password' not in first
    assert verify_password('test-password-123',first)
    assert not verify_password('wrong-password',first)
    with pytest.raises(ValueError):password_record('short')


@pytest.mark.parametrize('key',list(TemplateService().templates))
def test_expanded_library_generates_and_prints(key,tmp_path,qapp):
    service=TemplateService();template=service.get(key);values=verification_values(template)
    text=DocumentEngine(service).generate(template,values)
    assert '{{' not in text and '{%' not in text
    word=tmp_path/(key+'.docx');pdf=tmp_path/(key+'.pdf')
    export_docx(text,word);export_pdf(text,pdf)
    reader=PdfReader(pdf)
    assert len(reader.pages)>=1
    extracted=''.join(p.extract_text() for p in reader.pages)
    assert 'Page 1 of' in extracted
    assert 'Pending Legal Review' in extracted
    doc=WordDocument(word)
    assert doc.styles['Normal'].font.name=='Georgia'
    assert doc.sections[0].page_width.cm==pytest.approx(21,abs=.01)


@pytest.mark.parametrize('style',list(STYLES))
def test_clean_print_styles(style,tmp_path,qapp):
    text='DOCUMENT TITLE\n\n1. The main clause\nThis is a printable paragraph.\n\nName: Test Signer\nSignature: ____________________'
    options={'style':style,'review_copy':False}
    word=tmp_path/'clean.docx';pdf=tmp_path/'clean.pdf'
    export_docx(text,word,options);export_pdf(text,pdf,options)
    assert 'Pending Legal Review' not in ''.join(p.text for p in WordDocument(word).paragraphs)
    assert 'Pending Legal Review' not in ''.join(p.extract_text() for p in PdfReader(pdf).pages)
    model=PrintDocument(text,options);assert not model.image(0).isNull()


def test_llp_eligibility_validation():
    service=TemplateService();t=service.get('llp');data=verification_values(t)
    for p in data['partners']:p['designated']=False
    with pytest.raises(ValidationError,match='designated'):validate(t,data)


def test_favorites_persist(qtbot,store):
    from prarup.ui.document_library import DocumentLibrary
    from PyQt6.QtWidgets import QPushButton
    library=DocumentLibrary(TemplateService(),store);qtbot.addWidget(library)
    key,card=library.cards[0][0]['id'],library.cards[0][1]
    buttons=card.findChildren(QPushButton);buttons[1].click()
    assert key in json.loads(store.setting('favorites'))
    library.only_favorites.setChecked(True)
    assert sum(not card.isHidden() for _,card in library.cards)==1


def test_client_prefill_wizard_controls(qtbot,store,tmp_path,monkeypatch):
    from prarup.ui.document_wizard import DocumentWizard
    from PyQt6.QtWidgets import QMessageBox
    key=ClientService(store).save({'name':'Office Person','business_name':'Office Firm','address':'Office Address'})
    service=TemplateService();t=service.get('partnership')
    wizard=DocumentWizard(t,service,store,tmp_path);qtbot.addWidget(wizard)
    wizard.client.setCurrentIndex(wizard.client.findData(key))
    monkeypatch.setattr(QMessageBox,'question',lambda *a,**kw:QMessageBox.StandardButton.Yes)
    wizard.prefill_client()
    assert wizard.values()['firm_name']=='Office Firm'
    assert wizard.save_draft()
    assert DocumentRepository(store).get(wizard.document_id)['client_id']==key


def test_supported_fifty_partners():
    service=TemplateService();t=service.get('partnership');data=verification_values(t)
    data['partners']=[dict(data['partners'][0],name='Verification Partner '+str(i+1),share='2') for i in range(50)]
    assert 'Verification Partner 50' in DocumentEngine(service).generate(t,data)
    data['partners'].append(dict(data['partners'][0],name='Extra'))
    with pytest.raises(ValidationError):validate(t,data)


def test_custom_loop_bounds(tmp_path):
    service=TemplateService(tmp_path);item,_=custom_definition(service)
    with pytest.raises(ValueError,match='Loops'):service.validate_package(item,'{% for c in signer %}{{ c }}{% endfor %}')
