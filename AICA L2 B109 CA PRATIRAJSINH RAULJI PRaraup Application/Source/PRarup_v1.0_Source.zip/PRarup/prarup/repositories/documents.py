import json
from datetime import datetime, timezone
from sqlalchemy import select, or_
from prarup.models.entities import Document

class DocumentRepository:
    def __init__(self, store):
        self.store = store

    def save(self, template, values, text, document_id=None, client_id=None, options=None):
        with self.store.sessions.begin() as session:
            row = session.get(Document, document_id) if document_id else None
            if document_id and row is None:
                raise ValueError("This draft no longer exists. Reopen it from the dashboard.")
            if row is None:
                row = Document()
                session.add(row)
            name = values.get("firm_name") or values.get("business_name") or values.get("company") or values.get("tenant") or values.get("principal") or "Untitled"
            row.client_id = client_id
            row.title = f"{template['name']} — {name}"[:240]
            row.status = "draft"
            row.updated_at = datetime.now(timezone.utc).isoformat()
            row.payload = json.dumps({"format": 1, "template_id": template["id"], "template_version": template["version"], "values": values, "text": text, "client_id":client_id, "options":options or {}}, ensure_ascii=False)
            session.flush()
            return row.id

    def get(self, document_id):
        with self.store.sessions() as session:
            row = session.get(Document, document_id)
            if row is None:
                raise ValueError("The selected draft could not be found.")
            data = json.loads(row.payload)
            if data.get("format") != 1:
                raise ValueError("This record is not a supported editable draft.")
            return data


    def search(self, query="", client_id=None, archived=False):
        with self.store.sessions() as session:
            statement=select(Document).where(Document.status == "archived" if archived else Document.status != "archived")
            if query:
                statement=statement.where(Document.title.contains(query, autoescape=True))
            if client_id is not None:statement=statement.where(Document.client_id==client_id)
            return list(session.scalars(statement.order_by(Document.updated_at.desc())))

    def archive(self, document_id, archived=True):
        with self.store.sessions.begin() as session:
            row=session.get(Document,document_id)
            if row is None:raise ValueError("Draft not found.")
            row.status="archived" if archived else "draft"

    def duplicate(self, document_id):
        data=self.get(document_id)
        return self.save({"id":data["template_id"],"version":data["template_version"],"name":"Copy"},data["values"],data["text"],client_id=data.get("client_id"),options=data.get("options"))
