import sqlite3
from datetime import datetime, timezone
from sqlalchemy import create_engine, event, text, select, func
from sqlalchemy.orm import sessionmaker
from prarup.models.entities import Base, Client, Document, Setting

class Store:
    def __init__(self, root):
        self.path = root / "prarup.db"
        self.engine = create_engine("sqlite:///" + str(self.path))
        @event.listens_for(self.engine, "connect")
        def configure(connection, _):
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA busy_timeout=5000")
        self.sessions = sessionmaker(self.engine)
        with self.engine.begin() as connection:
            version = connection.exec_driver_sql("PRAGMA user_version").scalar()
            if version > 2:
                raise RuntimeError("This database requires a newer PRarup version.")
            existing = {row[0] for row in connection.exec_driver_sql("SELECT name FROM sqlite_master WHERE type='table'")}
            if version == 1 and "clients" in existing:
                # Preserve an online snapshot before additive schema migration.
                self.backup(root / "backups", unique=True)
                columns = {row[1] for row in connection.exec_driver_sql("PRAGMA table_info(clients)")}
                if "profile" not in columns:
                    connection.exec_driver_sql("ALTER TABLE clients ADD COLUMN profile TEXT NOT NULL DEFAULT '{}'")
                columns = {row[1] for row in connection.exec_driver_sql("PRAGMA table_info(documents)")}
                if "client_id" not in columns:
                    connection.exec_driver_sql("ALTER TABLE documents ADD COLUMN client_id INTEGER REFERENCES clients(id) ON DELETE SET NULL")
            Base.metadata.create_all(connection)
            connection.exec_driver_sql("PRAGMA user_version=2")
            if connection.exec_driver_sql("PRAGMA quick_check").scalar() != "ok":
                raise RuntimeError("Database integrity check failed. Restore a backup before continuing.")
        self.backup(root / "backups")

    def backup(self, directory, unique=False):
        directory.mkdir(parents=True, exist_ok=True)
        target = directory / ("prarup-" + datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f" if unique else "%Y%m%d") + ".db")
        if not target.exists():
            with sqlite3.connect(self.path) as source, sqlite3.connect(target) as destination:
                source.backup(destination)
        return target

    def stats(self):
        with self.sessions() as session:
            return {"Clients": session.scalar(select(func.count()).select_from(Client)),
                    "Documents": session.scalar(select(func.count()).select_from(Document)),
                    "Drafts": session.scalar(select(func.count()).select_from(Document).where(Document.status == "draft"))}

    def recent(self):
        with self.sessions() as session:
            return list(session.scalars(select(Document).where(Document.status != "archived").order_by(Document.updated_at.desc()).limit(10)))

    def setting(self, key, default=""):
        with self.sessions() as session:
            item = session.get(Setting, key)
            return item.value if item else default

    def set_setting(self, key, value):
        with self.sessions.begin() as session:
            session.merge(Setting(key=key, value=value))

    def close(self):
        self.engine.dispose()
