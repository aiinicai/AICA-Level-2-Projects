import logging
import sys
from logging.handlers import RotatingFileHandler
from PyQt6.QtCore import QTimer, Qt, QLockFile
from PyQt6.QtGui import QPixmap, QPainter, QColor, QFont
from PyQt6.QtWidgets import QApplication, QMessageBox, QSplashScreen, QInputDialog, QLineEdit
from prarup.config.paths import data_directory
from prarup.database.store import Store
from prarup.ui.main_window import MainWindow

def run():
    app = QApplication(sys.argv)
    app.setApplicationName("PRarup")
    app.setOrganizationName("Pratirajsinh Raulji and Co.")
    app.setFont(QFont("Nirmala UI", 10))
    try:
        root = data_directory()
        handler = RotatingFileHandler(root / "logs" / "prarup.log", maxBytes=1000000, backupCount=3, encoding="utf-8")
        logging.basicConfig(level=logging.INFO, handlers=[handler], format="%(asctime)s %(levelname)s %(message)s")
        canvas = QPixmap(560, 280)
        canvas.fill(QColor("#10243a"))
        painter = QPainter(canvas)
        painter.setPen(QColor("#d4ac66"))
        painter.setFont(QFont("Nirmala UI", 32, QFont.Weight.Bold))
        painter.drawText(canvas.rect().adjusted(25, 20, -25, -80), Qt.AlignmentFlag.AlignCenter, "PRarup | प्रारूप")
        painter.setFont(QFont("Nirmala UI", 12))
        painter.setPen(QColor("#f5f2eb"))
        painter.drawText(35, 210, "Pratirajsinh Raulji and Co. • Starting local workspace")
        painter.end()
        splash = QSplashScreen(canvas)
        splash.show()
        app.processEvents()
        workspace_lock=QLockFile(str(root/'workspace.lock'))
        workspace_lock.setStaleLockTime(0)
        if not workspace_lock.tryLock(0):
            splash.close()
            QMessageBox.information(None,'PRarup is already open','Close the other PRarup window before opening this workspace.');return 1
        store = Store(root)
        if "--workflow-check" in sys.argv:
            from prarup.core.verification import run_workflow_check
            try:
                return run_workflow_check(store, root)
            finally:
                store.close()
                splash.close()
        record=store.setting('lock_password')
        if record:
            from prarup.services.locking import verify_password
            while True:
                password,ok=QInputDialog.getText(None,'Unlock PRarup','Screen-lock password',QLineEdit.EchoMode.Password)
                if not ok:return 0
                if verify_password(password,record):break
                QMessageBox.warning(None,'Incorrect password','The password did not match.')
        window = MainWindow(store, root)
        app.aboutToQuit.connect(store.close)
        def show():
            window.show()
            splash.finish(window)
        QTimer.singleShot(400, show)
        if "--smoke-test" in sys.argv:
            QTimer.singleShot(1200, app.quit)
        return app.exec()
    except Exception as error:
        logging.exception("Startup failed")
        QMessageBox.critical(None, "PRarup could not start", f"{error}\nCheck dependencies and data-directory permissions.")
        return 1
