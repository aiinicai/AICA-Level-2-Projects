"""Opt-in packaged workflow check; never runs during normal application use."""
import json
from pathlib import Path
from prarup.services.template_service import TemplateService
from prarup.services.document_engine import DocumentEngine
from prarup.services.export_service import export_docx, export_pdf
from prarup.repositories.documents import DocumentRepository
from prarup.ui.document_wizard import DocumentWizard

def verification_values(template):
    def collect(fields):
        data = {}
        for field in fields:
            key, kind = field["id"], field["type"]
            if kind == "repeat":
                data[key] = [dict(collect(field["fields"]), name="Verification partner " + str(i+1), share="50", capital="100000") for i in range(2)]
            elif kind == "date":
                data[key] = "2027-11-13" if key in ("valid_until", "end_date","due_date") else "2026-11-13"
            elif kind == "choice":
                data[key] = field["options"][0]
            elif kind == "bool":
                data[key] = field.get("must_be_true",False)
            elif kind in ("currency", "percent", "number"):
                data[key] = str(field.get("default", 10))
            else:
                data[key] = {"gstin":"24ABCDE1234F1Z5", "cin":"U12345GJ2020PTC123456", "llpin":"AAA-1234"}.get(key, "Verification " + field["label"])
        return data
    result={key: value for section in template["sections"] for key, value in collect(section["fields"]).items()}
    if template['id']=='llp':
        for i,p in enumerate(result['partners']):p.update(designated=True,resident=i==0,dpin='')
    return result

def run_workflow_check(store, root):
    templates = TemplateService(root)
    results = {}
    for template in templates.templates.values():
        values = verification_values(template)
        dialog = DocumentWizard(template, templates, store, root, payload={"values": values})
        dialog.advance()
        assert dialog.pages.currentIndex() == 1
        dialog.advance()
        assert dialog.pages.currentIndex() == 2
        assert dialog.save_draft()
        payload = DocumentRepository(store).get(dialog.document_id)
        assert payload["text"]
        reopened = DocumentWizard(template, templates, store, root, document_id=dialog.document_id, payload=payload)
        assert reopened.pages.currentIndex() == 2
        assert reopened.editor.toPlainText() == dialog.editor.toPlainText()
        for extension, exporter in [("docx", export_docx), ("pdf", export_pdf)]:
            path = root / "documents" / (template["id"] + "." + extension)
            exporter(payload["text"], path)
            assert path.stat().st_size > 1000
        results[template["id"]] = "form → review → draft → save → reopen → DOCX/PDF passed"
        dialog.deleteLater()
        reopened.deleteLater()
    # Exercise the office modules in the packaged runtime against this isolated workspace.
    from prarup.services.client_service import ClientService
    from prarup.services.backup_service import BackupService
    from prarup.services.locking import password_record,verify_password
    clients=ClientService(store)
    client_id=clients.save({'name':'Workflow verification client','business_name':'Verification office','address':'Verification address'})
    assert clients.prefill(templates.get('partnership'),clients.get(client_id))['firm_name']=='Verification office'
    custom,clauses=templates.duplicate('noc')
    key=templates.save_version(custom,clauses)
    templates.save_version(dict(custom,version='1.1'),clauses+'\n\nVerification revision.')
    assert templates.get(key,'1.0',True)['version']=='1.0'
    templates.restore_version(key,'1.0');templates.set_enabled(key,False)
    assert key not in templates.templates
    backup=root/'backups'/'workflow-workspace.zip'
    BackupService(store,root).create(backup)
    clients.save({'name':'Temporary verification client'})
    recovery=BackupService(store,root).restore(backup)
    assert recovery.exists() and len(clients.search())==1
    repository=DocumentRepository(store)
    first=repository.search()[0].id
    repository.archive(first);assert repository.search(archived=True)
    repository.archive(first,False)
    record=password_record('verification-password')
    assert verify_password('verification-password',record) and not verify_password('wrong',record)
    results['office_modules']='client create/prefill, template versions, disable/restore, workspace backup/restore, document archiving and password hashing passed'
    (root / "workflow-check.json").write_text(json.dumps(results, indent=2), encoding="utf-8")
    return 0
