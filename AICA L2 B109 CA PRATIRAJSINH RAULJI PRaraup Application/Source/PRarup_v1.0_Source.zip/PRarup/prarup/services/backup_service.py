import hashlib
import json
import os
import sqlite3
import tempfile
from contextlib import closing
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
from zipfile import ZipFile,ZIP_DEFLATED

class BackupService:
    def __init__(self,store,root):self.store,self.root=store,root
    def create(self,path):
        snapshot=self.store.backup(self.root/"backups",unique=True)
        manifest={"format":1,"created":datetime.now(timezone.utc).isoformat(),"files":{}}
        files=[("prarup.db",snapshot)]
        folder=self.root/"user_templates"
        if folder.exists():files += [("user_templates/"+str(p.relative_to(folder)).replace("\\","/"),p) for p in folder.rglob('*') if p.is_file()]
        temporary=Path(str(path)+".tmp")
        try:
            with ZipFile(temporary,'w',ZIP_DEFLATED) as archive:
                for name,source in files:
                    data=source.read_bytes();archive.writestr(name,data);manifest["files"][name]=hashlib.sha256(data).hexdigest()
                archive.writestr('manifest.json',json.dumps(manifest))
            os.replace(temporary,path)
        finally:temporary.unlink(missing_ok=True)
        return Path(path)
    def restore(self,path):
        # Validate all bytes before touching live data. Keep a complete pre-restore recovery package.
        with ZipFile(path) as archive:
            infos=archive.infolist()
            if len(infos)>2000 or sum(i.file_size for i in infos)>250*1024*1024:raise ValueError("Backup exceeds the supported size limits.")
            if len({i.filename for i in infos})!=len(infos):raise ValueError("Duplicate backup entries.")
            manifest=json.loads(archive.read('manifest.json'))
            if manifest.get('format')!=1:raise ValueError("Unsupported backup format.")
            if set(archive.namelist())!=set(manifest['files'])|{'manifest.json'}:raise ValueError("Backup manifest does not match its contents.")
            content={}
            for name,digest in manifest['files'].items():
                pure=PurePosixPath(name)
                if pure.is_absolute() or '..' in pure.parts or ':' in name or '\\' in name or not (name=='prarup.db' or name.startswith('user_templates/')):raise ValueError("Unsafe backup path.")
                data=archive.read(name)
                if hashlib.sha256(data).hexdigest()!=digest:raise ValueError("Backup checksum mismatch.")
                content[name]=data
        if 'prarup.db' not in content:raise ValueError("Backup database is missing.")
        with tempfile.TemporaryDirectory(dir=self.root) as temp:
            stage=Path(temp);candidate=stage/'prarup.db';candidate.write_bytes(content['prarup.db'])
            with closing(sqlite3.connect(candidate)) as db:
                if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise ValueError("Backup database is damaged.")
                if db.execute('PRAGMA user_version').fetchone()[0] not in (1,2):raise ValueError("Unsupported database schema.")
                tables={x[0] for x in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
                if not {'clients','documents','settings'}<=tables:raise ValueError("This is not a PRarup database.")
                required={'clients':{'id','name'},'documents':{'id','title','status','updated_at','payload'},'settings':{'key','value'}}
                for table,columns in required.items():
                    present={row[1] for row in db.execute('PRAGMA table_info('+table+')')}
                    if not columns<=present:raise ValueError('Backup database schema is incomplete.')
                if db.execute('PRAGMA user_version').fetchone()[0]==2:
                    if 'profile' not in {row[1] for row in db.execute('PRAGMA table_info(clients)')} or 'client_id' not in {row[1] for row in db.execute('PRAGMA table_info(documents)')}:raise ValueError('Backup database schema version does not match its columns.')
            # Validate template packages before restore using the normal package validator.
            for name,data in content.items():
                if name.startswith('user_templates/'):
                    target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            from prarup.services.template_service import TemplateService
            TemplateService(stage,strict=True)
            recovery=self.root/'backups'/('before-restore-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')+'.zip')
            self.create(recovery)
            self.store.engine.dispose()
            with closing(sqlite3.connect(candidate)) as source,closing(sqlite3.connect(self.store.path)) as destination:source.backup(destination)
            # Preserve the previous custom library as a separate recovery directory.
            current=self.root/'user_templates'
            if current.exists():current.rename(self.root/('templates-before-restore-'+datetime.now().strftime('%Y%m%d-%H%M%S-%f')))
            staged=stage/'user_templates'
            if staged.exists():staged.rename(current)
            # Reinitialize in place, migrating an older compatible restored schema.
            self.store.__init__(self.root)
            return recovery
