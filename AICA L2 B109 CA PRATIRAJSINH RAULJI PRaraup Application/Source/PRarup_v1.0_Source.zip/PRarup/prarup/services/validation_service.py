from datetime import date
from decimal import Decimal, InvalidOperation
import re

class ValidationError(ValueError):
    pass

def active(field, values):
    return all(values.get(key) == value for key, value in field.get("condition", {}).items())

def validate(template, values):
    errors = []
    def check(fields, data, prefix=""):
        result = {}
        for field in fields:
            key = field["id"]
            if not active(field, data):
                continue
            label = prefix + field["label"]
            value = data.get(key, field.get("default", ""))
            kind = field["type"]
            if kind == "repeat":
                if not isinstance(value, list) or not field.get("min", 0) <= len(value) <= field.get("max", 50):
                    errors.append(f"{label}: supply {field.get('min', 0)}–{field.get('max', 50)} entries.")
                    continue
                result[key] = [check(field["fields"], row, f"{label} {i+1} / ") for i, row in enumerate(value)]
                continue
            if kind == "bool":
                if field.get('must_be_true') and value is not True:
                    errors.append(f"{label}: confirmation is required.")
                result[key] = value is True
                continue
            value = str(value).strip()
            if not value:
                if field.get("required", True):
                    errors.append(f"{label}: required.")
                result[key] = ""
                continue
            if len(value) > (20000 if kind == "multiline" else 500):
                errors.append(f"{label}: text is too long.")
            if any(ord(c) < 32 and c not in "\n\t\r" for c in value):
                errors.append(f"{label}: contains unsupported control characters.")
            if kind in ("currency", "percent", "number"):
                try:
                    number = Decimal(value)
                    if not number.is_finite():
                        raise InvalidOperation()
                    low = Decimal(str(field.get("min", 0)))
                    high = Decimal(str(field.get("max", 100 if kind == "percent" else 999999999999)))
                    if not low <= number <= high:
                        raise InvalidOperation()
                    if kind == "number" and number != number.to_integral_value():
                        raise InvalidOperation()
                    if kind in ("currency", "percent") and number != number.quantize(Decimal("0.01")):
                        raise InvalidOperation()
                    value = format(number, "f")
                except (InvalidOperation, ValueError):
                    errors.append(f"{label}: enter a valid value within the permitted range (up to two decimals).")
            if kind == "date":
                try:
                    date.fromisoformat(value)
                except ValueError:
                    errors.append(f"{label}: invalid date.")
            if kind == "choice" and value not in field["options"]:
                errors.append(f"{label}: select one of the available choices.")
            result[key] = value
        return result
    fields = [f for s in template["sections"] for f in s["fields"]]
    normalized = check(fields, values)
    if "partners" in normalized and all("share" in p for p in normalized["partners"]):
        partners = normalized.get("partners", [])
        try:
            if sum(Decimal(p.get("share") or "0") for p in partners) != Decimal("100"):
                errors.append("Partners: profit and loss shares must total exactly 100%.")
        except InvalidOperation:
            pass
        names = [p.get("name", "").casefold() for p in partners]
        if len(set(names)) != len(names):
            errors.append("Partners: names must be distinct; check for duplicate entries.")
    if template['id']=='llp':
        designated=[p for p in normalized.get('partners',[]) if p.get('designated')]
        if len(designated)<2:errors.append('LLP: at least two designated partners are required.')
        if not any(p.get('resident') for p in designated):errors.append('LLP: confirm at least one eligible resident designated partner.')
        if normalized.get('llpin') and not re.fullmatch(r'[A-Z]{3}-[0-9]{4}',normalized['llpin']):errors.append('LLPIN: expected format AAA-1234.')
    for start, end in [("start_date", "end_date"), ("commencement", "end_date"), ("agreement_date", "valid_until"), ("agreement_date","due_date"), ("original_date","effective_date")]:
        if normalized.get(start) and normalized.get(end) and normalized[start] > normalized[end]:
            errors.append(f"{end.replace('_', ' ').title()} must not precede {start.replace('_', ' ')}.")
    if normalized.get("gstin") and not re.fullmatch(r"[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]", normalized["gstin"]):
        errors.append("GSTIN: expected a 15-character GSTIN in uppercase. Check it against the official record.")
    if normalized.get("cin") and not re.fullmatch(r"[LU][0-9]{5}[A-Z]{2}[0-9]{4}[A-Z]{3}[0-9]{6}", normalized["cin"]):
        errors.append("CIN: expected a 21-character company CIN in uppercase.")
    if errors:
        raise ValidationError("\n".join(errors))
    return normalized
