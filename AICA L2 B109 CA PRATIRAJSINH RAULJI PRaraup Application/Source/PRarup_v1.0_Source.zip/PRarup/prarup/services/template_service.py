import copy
import json
import os
import re
import uuid
from pathlib import Path
from zipfile import ZipFile
from jinja2 import Environment,meta,nodes
from docx import Document
from prarup.config.paths import resource_path

class TemplateService:
    def __init__(self,root=None,strict=False):
        self.root=Path(root) if root else None
        self.folder=self.root/'user_templates' if self.root else None
        self.errors=[]
        self.reload(strict)

    def reload(self,strict=False):
        self.errors=[]
        self.all_templates={};self.templates={}
        paths=sorted(resource_path('schemas').glob('*.json'),key=lambda p:(p.stem!='partnership',p.stem))
        for path in paths:
            item=json.loads(path.read_text(encoding='utf-8'))
            matches=list(resource_path('templates').glob(f"*/{item['id']}-{item['version']}.j2"))
            if len(matches)!=1:raise ValueError('Missing clause file for '+item['name'])
            item['_clause_path']=str(matches[0]);item['_custom']=False
            self.all_templates[item['id']]=item
        state={}
        if self.folder and (self.folder/'state.json').exists():state=json.loads((self.folder/'state.json').read_text())
        if self.folder and self.folder.exists():
            for directory in self.folder.iterdir():
                if not directory.is_dir():continue
                try:
                    active=json.loads((directory/'active.json').read_text())
                    if not re.fullmatch(r'custom_[a-z0-9_]{1,70}',directory.name):raise ValueError('Invalid custom template ID.')
                    version=self.safe_version(active['version'])
                    item=json.loads((directory/'versions'/(version+'.json')).read_text(encoding='utf-8'))
                    clause=directory/'versions'/(version+'.j2')
                    self.validate_package(item,clause.read_text(encoding='utf-8'))
                    if item['id']!=directory.name:raise ValueError('Template ID does not match its directory.')
                    item['_clause_path']=str(clause);item['_custom']=True
                    item['enabled']=active.get('enabled',True)
                    self.all_templates[item['id']]=item
                except Exception as error:
                    if strict:raise ValueError('Invalid custom template: '+str(error)) from error
                    self.errors.append(directory.name+': '+str(error))
        for key,item in self.all_templates.items():
            if state.get(key,{}).get('enabled',item.get('enabled',True)):
                self.templates[key]=item

    def safe_version(self,version):
        if not re.fullmatch(r'\d+(?:\.\d+){0,2}',str(version)):raise ValueError('Version must be numeric, such as 1.0.')
        return str(version)

    def get(self,template_id,version=None,include_disabled=False):
        source=self.all_templates if include_disabled else self.templates
        if template_id not in source:raise ValueError('This document template is disabled or unavailable.')
        item=source[template_id]
        if version and version!=item['version']:
            if not item.get('_custom'):raise ValueError('The original template version is unavailable.')
            path=self.folder/template_id/'versions'/(self.safe_version(version)+'.json')
            item=json.loads(path.read_text(encoding='utf-8'))
            item['_clause_path']=str(path.with_suffix('.j2'));item['_custom']=True
            self.validate_package(item,path.with_suffix('.j2').read_text(encoding='utf-8'))
        return item

    def clause_path(self,item):return Path(item['_clause_path'])

    def validate_package(self,item,clause):
        if not re.fullmatch(r'custom_[a-z0-9_]{1,70}',item.get('id','')):raise ValueError('Custom ID must start with custom_ and use lowercase letters, digits or underscores.')
        self.safe_version(item.get('version',''))
        for key in ('name','category','description'):
            if not isinstance(item.get(key),str) or not item[key].strip() or len(item[key])>500:raise ValueError('Missing or invalid '+key)
        identifiers=set();repeats=set();count=0
        def fields(items,depth=0):
            nonlocal count
            if depth>1:raise ValueError('Nested repeating groups are not supported.')
            local=set()
            for f in items:
                count+=1
                if count>100:raise ValueError('At most 100 field definitions are supported.')
                key=f.get('id','')
                if not re.fullmatch(r'[a-z][a-z0-9_]{0,60}',key) or key in local:raise ValueError('Invalid or duplicate field ID: '+key)
                local.add(key)
                if depth==0:
                    if key in identifiers:raise ValueError('Duplicate root field ID: '+key)
                    identifiers.add(key)
                if not isinstance(f.get('label'),str) or not f['label']:raise ValueError('Every field needs a label.')
                if f.get('type') not in ('text','multiline','date','currency','percent','number','choice','bool','repeat'):raise ValueError('Unsupported field type.')
                if f['type']=='choice' and (not f.get('options') or not all(isinstance(x,str) for x in f['options'])):raise ValueError('Dropdown options must be text.')
                if f['type']=='repeat':
                    if depth==0:repeats.add(key)
                    if not 0<=f.get('min',1)<=f.get('max',50)<=50:raise ValueError('Repeating groups support 0–50 entries.')
                    fields(f.get('fields',[]),depth+1)
        if not isinstance(item.get('sections'),list) or not item['sections']:raise ValueError('Questionnaire sections are required.')
        for s in item['sections']:
            if not s.get('title'):raise ValueError('Every section needs a title.')
            fields(s.get('fields',[]))
        if not clause.strip() or len(clause)>100000:raise ValueError('Clause text must contain 1–100000 characters.')
        environment=Environment()
        environment.filters.update(date=lambda x:x,inr=lambda x:x,words=lambda x:x)
        tree=environment.parse(clause)
        disallowed=(nodes.Call,nodes.Import,nodes.FromImport,nodes.Include,nodes.Extends,nodes.Macro,nodes.Assign,nodes.Mul,nodes.Pow,nodes.Add,nodes.Sub,nodes.Div,nodes.FloorDiv,nodes.Mod)
        if any(isinstance(n,disallowed) for n in tree.find_all(nodes.Node)):raise ValueError('Template supports placeholders, conditions, loops and approved filters only; executable expressions are disabled.')
        for n in tree.find_all(nodes.Getattr):
            if n.attr.startswith('_'):raise ValueError('Private attributes are not supported.')
        for n in tree.find_all(nodes.Filter):
            if n.name not in ('date','inr','words','default','upper','lower','title','join'):raise ValueError('Unsupported filter: '+n.name)
        def check_loops(node,depth=0):
            for child in node.iter_child_nodes():
                next_depth=depth
                if isinstance(child,nodes.For):
                    next_depth+=1
                    if next_depth>2 or not isinstance(child.iter,nodes.Name) or child.iter.name not in repeats:
                        raise ValueError('Loops may iterate only questionnaire repeating groups, with at most two nested loops.')
                check_loops(child,next_depth)
        check_loops(tree)
        unknown=meta.find_undeclared_variables(tree)-identifiers-{'total_capital'}
        if unknown:raise ValueError('Add questionnaire fields for: '+', '.join(sorted(unknown)))
        return True

    def clean_metadata(self,item):return {k:v for k,v in item.items() if not k.startswith('_')}

    def new_definition(self):
        return {'id':'custom_'+uuid.uuid4().hex[:10],'version':'1.0','name':'New office template','category':'Office templates','description':'Custom office document.','enabled':True,'legal_status':'Pending Legal Review','last_legal_verification':None,'sources':[],'execution_notes':'Review this office template before use.','warning':'Professional verification required.','sections':[{'title':'Details','fields':[{'id':'signer','label':'Name of signer','type':'text','required':True},{'id':'purpose','label':'Purpose','type':'multiline','required':True}]}]}

    def save_version(self,item,clause):
        if not self.folder:raise ValueError('No writable custom library directory.')
        item=self.clean_metadata(copy.deepcopy(item));self.validate_package(item,clause)
        # Editing never certifies a document. Retain review status.
        item.update(legal_status='Pending Legal Review',last_legal_verification=None)
        item.setdefault('sources',[]);item.setdefault('execution_notes','Professional review required.');item.setdefault('warning','Verify before execution.')
        directory=self.folder/item['id'];versions=directory/'versions';versions.mkdir(parents=True,exist_ok=True)
        version=self.safe_version(item['version'])
        metadata=versions/(version+'.json');body=versions/(version+'.j2')
        if metadata.exists() or body.exists():raise ValueError('This version already exists. Use a new version number.')
        body.write_text(clause,encoding='utf-8')
        metadata.write_text(json.dumps(item,ensure_ascii=False,indent=2),encoding='utf-8')
        self._write_json(directory/'active.json',{'version':version,'enabled':True})
        self.reload();return item['id']

    def _write_json(self,path,data):
        path.parent.mkdir(parents=True,exist_ok=True)
        temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(temporary,path)

    def set_enabled(self,key,enabled):
        state_path=self.folder/'state.json'
        state=json.loads(state_path.read_text()) if state_path.exists() else {}
        state[key]={'enabled':enabled};self._write_json(state_path,state);self.reload()

    def versions(self,key):
        item=self.all_templates[key]
        if not item.get('_custom'):return [item['version']]
        return sorted(p.stem for p in (self.folder/key/'versions').glob('*.json'))

    def restore_version(self,key,version):
        item=self.get(key,version,True)
        self.validate_package(item,self.clause_path(item).read_text(encoding='utf-8'))
        self._write_json(self.folder/key/'active.json',{'version':version,'enabled':True});self.reload()

    def duplicate(self,key):
        item=self.clean_metadata(self.all_templates[key]);clause=self.clause_path(self.all_templates[key]).read_text(encoding='utf-8')
        item.update(id='custom_'+uuid.uuid4().hex[:10],version='1.0',name=item['name']+' — Office copy')
        return item,clause

    def import_docx(self,path):
        path=Path(path)
        if path.stat().st_size>5*1024*1024:raise ValueError('Import supports DOCX files up to 5 MB.')
        with ZipFile(path) as archive:
            if sum(i.file_size for i in archive.infolist())>20*1024*1024:raise ValueError('The decompressed DOCX is too large.')
            if any('vbaProject' in x or x.startswith('word/media/') for x in archive.namelist()):raise ValueError('Import supports text-only DOCX without macros or pictures.')
            for name in archive.namelist():
                if name.endswith('.rels') and b'TargetMode="External"' in archive.read(name):raise ValueError('External links are not supported in imported templates.')
        doc=Document(path)
        if doc.tables:raise ValueError('Import supports paragraph-based DOCX only. Remove tables before importing.')
        clause='\n\n'.join(p.text for p in doc.paragraphs if p.text.strip())
        if '{%' in clause or '{#' in clause:raise ValueError('DOCX import supports simple {{ variable }} placeholders only.')
        variables=sorted(set(re.findall(r'{{\s*([a-z][a-z0-9_]*)\s*}}',clause)))
        if not variables:raise ValueError('Use placeholders such as {{ client_name }} in the DOCX.')
        item=self.new_definition();item['name']=path.stem;item['description']='Imported text-only DOCX, formatted using PRarup print styles.'
        item['sections'][0]['fields']=[{'id':key,'label':key.replace('_',' ').title(),'type':'text','required':True} for key in variables]
        return item,clause
