import json
import re
from sqlalchemy import select
from prarup.models.entities import Client,Document

class ClientService:
    def __init__(self,store):self.store=store
    def search(self,query=""):
        with self.store.sessions() as session:
            rows=list(session.scalars(select(Client).order_by(Client.name)))
            return [dict(id=row.id,name=row.name,**json.loads(row.profile or "{}")) for row in rows if query.casefold() in (row.name+row.profile).casefold()]
    def get(self,client_id):
        with self.store.sessions() as session:
            row=session.get(Client,client_id)
            if row is None:raise ValueError("Client not found.")
            return dict(id=row.id,name=row.name,**json.loads(row.profile or "{}"))
    def save(self,profile,client_id=None):
        data=dict(profile);data.pop("id",None);name=data.pop("name","").strip()
        if not name or len(name)>200:raise ValueError("Client name is required (up to 200 characters).")
        for key,value in data.items():
            if isinstance(value,str) and len(value)>20000:raise ValueError(key+" is too long.")
        if data.get("pan") and not re.fullmatch(r"[A-Z]{5}[0-9]{4}[A-Z]",data["pan"]):raise ValueError("PAN must have the standard ten-character uppercase format.")
        if data.get("gstin") and not re.fullmatch(r"[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z][1-9A-Z]Z[0-9A-Z]",data["gstin"]):raise ValueError("Check the 15-character uppercase GSTIN.")
        with self.store.sessions.begin() as session:
            row=session.get(Client,client_id) if client_id else Client()
            if row is None:raise ValueError("Client no longer exists.")
            session.add(row);row.name=name;row.profile=json.dumps(data,ensure_ascii=False);session.flush();return row.id
    def delete(self,client_id):
        # Drafts remain available; only their client association is removed.
        with self.store.sessions.begin() as session:
            row=session.get(Client,client_id)
            if row is None:raise ValueError("Client not found.")
            for document in session.scalars(select(Document).where(Document.client_id==client_id)):
                document.client_id=None
                payload=json.loads(document.payload)
                if "client_id" in payload:
                    payload["client_id"]=None;document.payload=json.dumps(payload,ensure_ascii=False)
            session.delete(row)
    def prefill(self,template,client):
        business=client.get("business_name") or client["name"]
        address=client.get("address","")
        mapping={"firm_name":business,"business_name":business,"company":business,"principal":business,"office":address,"business_address":address,"principal_address":address,"business":client.get("activities",""),"gstin":client.get("gstin",""),"cin":client.get("cin",""),"llpin":client.get("cin",""),"state":client.get("state") or "Gujarat"}
        if template["id"] in ("partnership","llp") and client.get("people"):
            mapping["partners"]=[p for p in client["people"] if p.get("role","Partner")=="Partner"]
        if client.get("signatory"):mapping["signer"]=client["signatory"]
        allowed={f["id"] for section in template["sections"] for f in section["fields"]}
        return {key:value for key,value in mapping.items() if key in allowed and value!=""}
