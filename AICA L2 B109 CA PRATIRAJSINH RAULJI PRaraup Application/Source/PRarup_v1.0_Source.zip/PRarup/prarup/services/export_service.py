"""Shared A4 typography for editable Word, native PDF, previews and printing."""
import os
import re
import tempfile
from pathlib import Path
from html import escape
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docxtpl import DocxTemplate
from jinja2.sandbox import SandboxedEnvironment
from PyQt6.QtCore import QSizeF, QRectF, Qt, QMarginsF
from PyQt6.QtGui import QTextDocument, QFont, QPdfWriter, QPageSize, QPageLayout, QPainter, QColor, QImage, QTextCursor, QTextBlockFormat, QTextCharFormat, QTextFormat
from prarup.config.paths import resource_path

REVIEW_NOTICE = "DRAFT — Pending Legal Review. Professional verification required before execution."
STYLES = {"Classic legal": ("Times New Roman",12,1.15), "Editorial serif": ("Georgia",11.5,1.20), "Contemporary": ("Calibri",11.5,1.20)}
DEFAULT_OPTIONS = {"style":"Editorial serif", "review_copy":True, "margin_mm":25, "stamp_space_mm":0, "firm_footer":True}

def layout_options(options=None):
    result = dict(DEFAULT_OPTIONS)
    result.update(options or {})
    if result["style"] not in STYLES:
        result["style"] = DEFAULT_OPTIONS["style"]
    result["margin_mm"] = max(18,min(35,float(result["margin_mm"])))
    result["stamp_space_mm"] = max(0,min(75,float(result["stamp_space_mm"])))
    return result

def blocks(text):
    for i, raw in enumerate(re.split(r"\n\s*\n",text.strip())):
        lines=raw.strip().splitlines()
        if not lines:continue
        if i==0:
            yield "title", " ".join(lines)
            continue
        first=lines[0].strip()
        heading = len(first)<100 and (first.isupper() or (re.match(r"^\d{1,2}\. [A-Za-z]",first) and ":" not in first))
        # Short standalone numbered partner names should not become clause headings.
        if heading and (len(lines)>1 or first.isupper()):
            yield "heading", first
            if len(lines)>1:
                rest="\n".join(lines[1:])
                yield ("signature" if "Signature:" in rest or "signature:" in rest else "body"),rest
        else:
            yield ("signature" if "Signature:" in raw or "signature:" in raw else "body"),raw.strip()

def document_html(text, options=None):
    opts=layout_options(options)
    font,size,spacing=STYLES[opts["style"]]
    out=[f'<html><head><style>body {{font-family:"{font}";font-size:{size}pt;color:#000}} p {{margin:0 0 9pt 0;line-height:{spacing*100}%;text-align:justify}} h1 {{font-size:17pt;text-align:center;margin:0 0 19pt 0;font-weight:700}} h2 {{font-size:{size}pt;margin:13pt 0 6pt 0;font-weight:700;text-align:left;page-break-after:avoid}}</style></head><body>']
    if opts["stamp_space_mm"]:
        out.append(f'<p style="font-size:1pt;margin:0;height:{opts["stamp_space_mm"]*2.83465}pt">'+'<br>'*int(opts["stamp_space_mm"]/3)+'</p>')
    for kind,value in blocks(text):
        safe=escape(value).replace("\n","<br>")
        if kind=="title":
            out.append('<h1>'+safe+'</h1>')
            if opts["review_copy"]:
                out.append('<p style="font-size:8pt;text-align:center;color:#666;margin-bottom:14pt">'+escape(REVIEW_NOTICE)+'</p>')
        elif kind=="heading":
            out.append('<h2>'+safe+'</h2>')
        elif kind=="signature":
            out.append('<table width="100%" cellspacing="0" cellpadding="0"><tr><td><p style="text-align:left;line-height:155%;margin-top:10pt;margin-bottom:12pt">'+safe+'</p></td></tr></table>')
        else:
            out.append('<p>'+safe+'</p>')
    out.append('</body></html>')
    return ''.join(out)

def atomic_export(path, writer):
    path=Path(path)
    if not path.parent.is_dir():raise ValueError("Choose an existing output folder.")
    handle,temporary=tempfile.mkstemp(prefix=".prarup-",suffix=path.suffix,dir=path.parent)
    os.close(handle)
    try:
        writer(Path(temporary))
        if Path(temporary).stat().st_size<100:raise ValueError("The export did not produce a valid document.")
        os.replace(temporary,path)
    finally:
        Path(temporary).unlink(missing_ok=True)

def export_docx(text,path,options=None):
    opts=layout_options(options)
    def write(temporary):
        parts=list(blocks(text))
        if not parts:raise ValueError("The draft is empty.")
        template=DocxTemplate(resource_path("templates/layout-1.0.docx"))
        template.render({"title":parts[0][1],"review_notice":REVIEW_NOTICE if opts["review_copy"] else ""},jinja_env=SandboxedEnvironment(),autoescape=True)
        template.save(temporary)
        doc=Document(temporary)
        font,size,spacing=STYLES[opts["style"]]
        section=doc.sections[0]
        section.page_width=Cm(21);section.page_height=Cm(29.7)
        section.top_margin=section.bottom_margin=section.left_margin=section.right_margin=Cm(opts["margin_mm"]/10)
        for name in ("Normal","Title","Heading 2"):
            style=doc.styles[name]
            style.font.name=font;style.font.color.rgb=RGBColor(0,0,0)
            style.font.size=Pt(17 if name=="Title" else size)
            style.font.bold=name!="Normal"
            style.paragraph_format.space_after=Pt(9 if name=="Normal" else 6)
            style.paragraph_format.space_before=Pt(12 if name=="Heading 2" else 0)
            style.paragraph_format.line_spacing=spacing
            style.paragraph_format.widow_control=True
            style.paragraph_format.keep_with_next=name in ("Title","Heading 2")
            fonts=style.element.get_or_add_rPr().rFonts
            for attr in ('asciiTheme','hAnsiTheme','eastAsiaTheme','cstheme'):
                fonts.attrib.pop(qn('w:'+attr),None)
            fonts.set(qn('w:eastAsia'),font)
            fonts.set(qn('w:cs'),'Nirmala UI')
            borders=style.element.find('.//'+qn('w:pBdr'))
            if borders is not None:borders.getparent().remove(borders)
        title=doc.paragraphs[0]
        title.alignment=WD_ALIGN_PARAGRAPH.CENTER
        title.paragraph_format.space_after=Pt(18)
        title.paragraph_format.space_before=Pt(opts["stamp_space_mm"]*2.83465)
        notice=doc.paragraphs[1]
        notice.alignment=WD_ALIGN_PARAGRAPH.CENTER
        for run in notice.runs:run.font.size=Pt(8);run.font.color.rgb=RGBColor(100,100,100)
        if not opts["review_copy"]:
            notice._element.getparent().remove(notice._element)
        for kind,value in parts[1:]:
            p=doc.add_paragraph(value,"Heading 2" if kind=="heading" else "Normal")
            p.alignment=WD_ALIGN_PARAGRAPH.JUSTIFY if kind=="body" else WD_ALIGN_PARAGRAPH.LEFT
            if kind=="signature":
                p.paragraph_format.keep_together=True
                p.paragraph_format.space_before=Pt(9)
                p.paragraph_format.space_after=Pt(12)
                p.paragraph_format.line_spacing=1.5
        # Apply explicit run fonts too; Word heading theme fonts can otherwise override a style.
        for paragraph in doc.paragraphs:
            for run in paragraph.runs:
                run.font.name=font
                if paragraph.style.name in ('Title','Heading 2'):
                    run.font.size=Pt(17 if paragraph.style.name=='Title' else size)
                    run.font.bold=True
                    run.font.color.rgb=RGBColor(0,0,0)
        doc.styles['Footer'].font.name='Calibri';doc.styles['Footer'].font.size=Pt(8)
        footer=section.footer.paragraphs[0]
        footer.clear()
        if opts["firm_footer"]:footer.add_run("Pratirajsinh Raulji and Co.   |   ")
        footer.add_run("Page ")
        for instruction in ("PAGE","NUMPAGES"):
            if instruction=="NUMPAGES":footer.add_run(" of ")
            field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),instruction);footer._p.append(field)
        footer.alignment=WD_ALIGN_PARAGRAPH.CENTER
        for run in footer.runs:run.font.size=Pt(8);run.font.color.rgb=RGBColor(100,100,100)
        doc.save(temporary)
    atomic_export(path,write)

class PrintDocument:
    """A paginated document at 96 dpi; shared by preview, PDF and Windows print."""
    def __init__(self,text,options=None):
        self.options=layout_options(options)
        self.width=210/25.4*96;self.height=297/25.4*96
        self.margin=self.options["margin_mm"]/25.4*96
        self.content_width=self.width-2*self.margin
        self.content_height=self.height-2*self.margin
        self.metrics=QImage(8,8,QImage.Format.Format_ARGB32)
        self.metrics.setDotsPerMeterX(round(96/0.0254));self.metrics.setDotsPerMeterY(round(96/0.0254))
        self.document=QTextDocument()
        self.document.documentLayout().setPaintDevice(self.metrics)
        font,size,_=STYLES[self.options["style"]]
        self.document.setDefaultFont(QFont(font,int(size)))
        self.document.setDocumentMargin(0)
        self.document.setPageSize(QSizeF(self.content_width,self.content_height))
        cursor=QTextCursor(self.document)
        first=True
        entries=list(blocks(text))
        if self.options['review_copy'] and entries:entries.insert(1,('notice',REVIEW_NOTICE))
        for kind,value in entries:
            bf=QTextBlockFormat();cf=QTextCharFormat()
            cf.setFontFamily(font);cf.setForeground(QColor('#000000'))
            cf.setFontPointSize(17 if kind=='title' else 8 if kind=='notice' else size)
            cf.setFontWeight(QFont.Weight.Bold if kind in ('title','heading') else QFont.Weight.Normal)
            bf.setAlignment(Qt.AlignmentFlag.AlignCenter if kind in ('title','notice') else Qt.AlignmentFlag.AlignLeft if kind in ('heading','signature') else Qt.AlignmentFlag.AlignJustify)
            bf.setLineHeight(150 if kind=='signature' else STYLES[self.options['style']][2]*100,QTextBlockFormat.LineHeightTypes.ProportionalHeight.value)
            bf.setTopMargin(12 if kind=='heading' else 8 if kind=='signature' else self.options['stamp_space_mm']/25.4*96 if kind=='title' else 0)
            bf.setBottomMargin(18 if kind=='title' else 14 if kind=='notice' else 6 if kind=='heading' else 9)
            if kind=='heading':bf.setHeadingLevel(2)
            if kind=='title':bf.setHeadingLevel(1)
            if first:cursor.setBlockFormat(bf);cursor.setCharFormat(cf);first=False
            else:cursor.insertBlock(bf,cf)
            cursor.insertText(value.replace('\n','\u2028'),cf)
        # Keep clause headings with at least two body lines, and keep short signature blocks together.
        for _ in range(3):
            changed=False;block=self.document.begin()
            while block.isValid():
                bf=block.blockFormat();rect=self.document.documentLayout().blockBoundingRect(block)
                if bf.pageBreakPolicy() & QTextFormat.PageBreakFlag.PageBreak_AlwaysBefore:
                    block=block.next();continue
                should_break=False
                if bf.headingLevel()==2 and block.next().isValid():
                    next_rect=self.document.documentLayout().blockBoundingRect(block.next())
                    should_break=int(rect.top()/self.content_height)!=int((next_rect.top()+size*96/72*2.3)/self.content_height)
                elif 'Signature:' in block.text() or 'signature:' in block.text():
                    should_break=rect.height()<self.content_height and int(rect.top()/self.content_height)!=int((rect.bottom()-1)/self.content_height)
                if should_break:
                    bf.setPageBreakPolicy(QTextFormat.PageBreakFlag.PageBreak_AlwaysBefore)
                    selection=QTextCursor(block);selection.setBlockFormat(bf);changed=True
                block=block.next()
            if not changed:break
        self.pages=self.document.pageCount()
        self.title=next(iter(blocks(text)),('title','Document'))[1]

    def draw_page(self,painter,page):
        painter.save()
        painter.setPen(QColor('#666666'))
        painter.setFont(QFont('Calibri',8))
        if page:
            painter.drawText(QRectF(self.margin,10/25.4*96,self.content_width,20),Qt.AlignmentFlag.AlignLeft,self.title)
        painter.save()
        painter.setClipRect(QRectF(self.margin,self.margin,self.content_width,self.content_height))
        painter.translate(self.margin,self.margin-page*self.content_height)
        self.document.drawContents(painter,QRectF(0,page*self.content_height,self.content_width,self.content_height))
        painter.restore()
        footer=("Pratirajsinh Raulji and Co.  |  " if self.options["firm_footer"] else "")+f"Page {page+1} of {self.pages}"
        painter.drawText(QRectF(self.margin,self.height-14/25.4*96,self.content_width,20),Qt.AlignmentFlag.AlignCenter,footer)
        painter.restore()

    def image(self,page,scale=1):
        image=QImage(round(self.width*scale),round(self.height*scale),QImage.Format.Format_ARGB32)
        image.fill(QColor('white'))
        painter=QPainter(image);painter.scale(scale,scale)
        self.draw_page(painter,page);painter.end()
        return image

    def print_to(self,device):
        painter=QPainter(device)
        if not painter.isActive():raise ValueError("Could not initialize the printer or PDF writer.")
        try:
            for page in range(self.pages):
                if page and not device.newPage():raise ValueError("Could not create the next page.")
                painter.save();painter.scale(device.logicalDpiX()/96,device.logicalDpiY()/96)
                self.draw_page(painter,page);painter.restore()
        finally:painter.end()

def export_pdf(text,path,options=None):
    def write(temporary):
        device=QPdfWriter(str(temporary));device.setResolution(144)
        device.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
        device.setPageMargins(QMarginsF(0,0,0,0),QPageLayout.Unit.Millimeter)
        PrintDocument(text,options).print_to(device)
    atomic_export(path,write)
