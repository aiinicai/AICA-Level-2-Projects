from datetime import date
from decimal import Decimal
from jinja2 import StrictUndefined
from jinja2.sandbox import SandboxedEnvironment
from prarup.services.validation_service import validate

_SMALL = ["Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]

def integer_words(n):
    if n < 20:
        return _SMALL[n]
    if n < 100:
        return _TENS[n//10] + (" " + integer_words(n%10) if n%10 else "")
    for value, name in [(10000000,"Crore"),(100000,"Lakh"),(1000,"Thousand"),(100,"Hundred")]:
        if n >= value:
            return integer_words(n//value) + " " + name + (" " + integer_words(n%value) if n%value else "")

def amount_words(value):
    amount = Decimal(str(value)).quantize(Decimal("0.01"))
    rupees = int(amount)
    paise = int((amount - rupees) * 100)
    return "Rupees " + integer_words(rupees) + (" and " + integer_words(paise) + " Paise" if paise else "") + " Only"

def inr(value):
    whole, fraction = format(Decimal(str(value)), ".2f").split(".")
    tail = whole[-3:]
    head = whole[:-3]
    chunks = []
    while head:
        chunks.insert(0, head[-2:])
        head = head[:-2]
    return ",".join(chunks + [tail]) + "." + fraction

class DocumentEngine:
    def __init__(self, templates):
        self.templates = templates
        self.environment = SandboxedEnvironment(undefined=StrictUndefined, autoescape=False)
        self.environment.filters.update(inr=inr, words=amount_words, date=lambda x: date.fromisoformat(x).strftime("%d %B %Y"))

    def generate(self, template, values):
        data = validate(template, values)
        if "partners" in data and all("capital" in p for p in data["partners"]):
            data["total_capital"] = sum(Decimal(p["capital"]) for p in data["partners"])
        chunks=[];length=0
        for chunk in self.environment.from_string(self.templates.clause_path(template).read_text(encoding="utf-8")).generate(**data):
            length+=len(chunk)
            if length>500000:raise ValueError('Generated document exceeds 500000 characters. Reduce repeating entries or long text.')
            chunks.append(chunk)
        text=''.join(chunks)
        # Only the template is interpreted: user input is never compiled as Jinja code.
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        return "\n\n".join(paragraphs)
