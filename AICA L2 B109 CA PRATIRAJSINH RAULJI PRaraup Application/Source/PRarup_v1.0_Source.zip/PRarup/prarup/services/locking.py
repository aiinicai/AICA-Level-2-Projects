import hashlib
import hmac
import json
import os

def password_record(password):
    if len(password)<8:raise ValueError("Use at least eight characters.")
    salt=os.urandom(16)
    digest=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,300000)
    return json.dumps({"salt":salt.hex(),"digest":digest.hex()})

def verify_password(password,record):
    data=json.loads(record)
    digest=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),bytes.fromhex(data['salt']),300000)
    return hmac.compare_digest(digest.hex(),data['digest'])
