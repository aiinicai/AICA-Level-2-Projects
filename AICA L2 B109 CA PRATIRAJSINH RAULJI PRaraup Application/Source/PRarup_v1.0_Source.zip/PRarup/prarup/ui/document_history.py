from PyQt6.QtCore import pyqtSignal,Qt
from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,QCheckBox,QTableWidget,QTableWidgetItem,QPushButton,QMessageBox
from prarup.repositories.documents import DocumentRepository
from prarup.services.client_service import ClientService

class DocumentHistory(QWidget):
    open_draft=pyqtSignal(int)
    def __init__(self,store):
        super().__init__();self.store=store;self.repository=DocumentRepository(store)
        box=QVBoxLayout(self);title=QLabel('Document history');title.setObjectName('heading');box.addWidget(title)
        row=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('Search all saved document titles…');self.search.textChanged.connect(self.refresh)
        self.client=QComboBox();self.client.currentIndexChanged.connect(self.refresh)
        self.archived=QCheckBox('Show archived');self.archived.toggled.connect(self.refresh)
        row.addWidget(self.search,1);row.addWidget(self.client);row.addWidget(self.archived);box.addLayout(row)
        self.table=QTableWidget(0,3);self.table.setHorizontalHeaderLabels(['Document','Status','Updated'])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows);self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection);self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True);self.table.cellDoubleClicked.connect(lambda *_:self.open());box.addWidget(self.table)
        actions=QHBoxLayout()
        for name,fn in [('Open draft',self.open),('Duplicate draft',self.duplicate),('Archive / restore',self.archive)]:
            button=QPushButton(name);button.clicked.connect(fn);actions.addWidget(button)
        box.addLayout(actions);self.refresh_clients()
    def refresh_clients(self,selected=None):
        current=selected if selected is not None else self.client.currentData()
        self.client.blockSignals(True);self.client.clear();self.client.addItem('All clients',None)
        for row in ClientService(self.store).search():self.client.addItem(row['name'],row['id'])
        index=self.client.findData(current);self.client.setCurrentIndex(max(index,0));self.client.blockSignals(False);self.refresh()
    def refresh(self,*_):
        if not hasattr(self,'table'):return
        rows=self.repository.search(self.search.text(),self.client.currentData(),self.archived.isChecked());self.table.setRowCount(len(rows))
        for i,row in enumerate(rows):
            for j,value in enumerate([row.title,row.status,row.updated_at[:19].replace('T',' ')]):
                item=QTableWidgetItem(value);item.setData(Qt.ItemDataRole.UserRole,row.id);self.table.setItem(i,j,item)
        self.table.resizeColumnsToContents()
    def selected_id(self):
        row=self.table.currentRow()
        return self.table.item(row,0).data(Qt.ItemDataRole.UserRole) if row>=0 else None
    def open(self):
        key=self.selected_id()
        if key:self.open_draft.emit(key)
    def duplicate(self):
        key=self.selected_id()
        if key:
            try:self.repository.duplicate(key);self.refresh()
            except Exception as error:QMessageBox.warning(self,'Cannot duplicate',str(error))
    def archive(self):
        key=self.selected_id()
        if key:
            try:self.repository.archive(key,not self.archived.isChecked());self.refresh()
            except Exception as error:QMessageBox.warning(self,'Cannot change status',str(error))
