from datetime import datetime
from PyQt6.QtCore import pyqtSignal,QUrl
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QWidget,QVBoxLayout,QLabel,QComboBox,QPushButton,QMessageBox,QFileDialog,QInputDialog,QLineEdit,QScrollArea
from prarup.services.backup_service import BackupService
from prarup.services.locking import password_record,verify_password
from prarup.services.export_service import STYLES

class Settings(QWidget):
    restored=pyqtSignal()
    def __init__(self,store,root,apply_theme):
        super().__init__();self.store,self.root=store,root
        box=QVBoxLayout(self);title=QLabel('Workspace settings');title.setObjectName('heading');box.addWidget(title)
        scroll=QScrollArea();scroll.setWidgetResizable(True);body=QWidget();layout=QVBoxLayout(body)
        layout.addWidget(QLabel('Application appearance'))
        self.theme=QComboBox();self.theme.addItems(['Light','Dark']);self.theme.setCurrentText(store.setting('theme','Light'));self.theme.currentTextChanged.connect(apply_theme);layout.addWidget(self.theme)
        layout.addWidget(QLabel('Default document typography'))
        self.style=QComboBox();self.style.addItems(list(STYLES));self.style.setCurrentText(store.setting('print_style','Editorial serif'));self.style.currentTextChanged.connect(lambda value:store.set_setting('print_style',value));layout.addWidget(self.style)
        layout.addWidget(QLabel('Default jurisdiction (editable in every questionnaire)'))
        self.state=QLineEdit(store.setting('default_state','Gujarat'));self.state.editingFinished.connect(lambda:store.set_setting('default_state',self.state.text().strip() or 'Gujarat'));layout.addWidget(self.state)
        info=QLabel(f'Local data: {root}\nDatabase, client records and backups are unencrypted. Protect your Windows account. Workspace backup includes the database and custom templates; exported Word/PDF files are separate.')
        info.setWordWrap(True);layout.addWidget(info)
        for title,fn in [('Open data folder',self.open_folder),("Create / locate today's database backup",self.daily_backup),('Create full workspace recovery ZIP',self.create_backup),('Restore workspace recovery ZIP',self.restore_backup),('Set / change screen-lock password',self.set_password),('Disable screen locking',self.disable_password)]:
            button=QPushButton(title);button.clicked.connect(fn);layout.addWidget(button)
        warning=QLabel('Screen locking hides the interface only. It does not encrypt files or prevent access by another Windows user with filesystem permissions. Use Ctrl+L or the Lock button after setting a password.')
        warning.setWordWrap(True);layout.addWidget(warning);layout.addStretch();scroll.setWidget(body);box.addWidget(scroll)
    def open_folder(self):
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.root))):QMessageBox.warning(self,'Cannot open folder',str(self.root))
    def daily_backup(self):
        try:QMessageBox.information(self,'Backup available',str(self.store.backup(self.root/'backups')))
        except Exception as error:QMessageBox.critical(self,'Backup failed',str(error))
    def create_backup(self):
        path,_=QFileDialog.getSaveFileName(self,'Save workspace recovery package',str(self.root/'backups'/('PRarup-'+datetime.now().strftime('%Y%m%d-%H%M%S')+'.zip')),'Workspace recovery (*.zip)')
        if path:
            try:BackupService(self.store,self.root).create(path);QMessageBox.information(self,'Recovery package saved',path)
            except Exception as error:QMessageBox.critical(self,'Backup failed',str(error))
    def restore_backup(self):
        path,_=QFileDialog.getOpenFileName(self,'Restore workspace recovery package',str(self.root/'backups'),'Workspace recovery (*.zip)')
        if not path:return
        if QMessageBox.question(self,'Restore workspace?','Replace the current database and custom template library with this backup? A complete pre-restore recovery package will be saved first. Existing exported Word/PDF files are not replaced.')!=QMessageBox.StandardButton.Yes:return
        try:
            recovery=BackupService(self.store,self.root).restore(path);self.restored.emit()
            QMessageBox.information(self,'Workspace restored','Recovery copy of the previous workspace:\n'+str(recovery))
        except Exception as error:QMessageBox.critical(self,'Restore failed',str(error))
    def check_current(self):
        record=self.store.setting('lock_password')
        if not record:return True
        password,ok=QInputDialog.getText(self,'Current password','Current screen-lock password',QLineEdit.EchoMode.Password)
        if not ok:return False
        if not verify_password(password,record):QMessageBox.warning(self,'Incorrect password','The current password did not match.');return False
        return True
    def set_password(self):
        if not self.check_current():return
        password,ok=QInputDialog.getText(self,'Screen-lock password','New password (at least 8 characters)',QLineEdit.EchoMode.Password)
        if not ok:return
        confirm,ok=QInputDialog.getText(self,'Confirm password','Repeat the new password',QLineEdit.EchoMode.Password)
        if not ok:return
        try:
            if password!=confirm:raise ValueError('The passwords do not match.')
            self.store.set_setting('lock_password',password_record(password));QMessageBox.information(self,'Screen locking enabled','Use Ctrl+L to lock the workspace.')
        except Exception as error:QMessageBox.warning(self,'Password not saved',str(error))
    def disable_password(self):
        if self.check_current():self.store.set_setting('lock_password','');QMessageBox.information(self,'Screen locking disabled','The screen-lock password has been removed.')
