import copy
import json
from PyQt6.QtCore import pyqtSignal,Qt
from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QListWidget,QListWidgetItem,QPushButton,QDialog,QTabWidget,QPlainTextEdit,QMessageBox,QFileDialog,QInputDialog

class TemplateEditor(QDialog):
    def __init__(self,service,item,clauses,parent=None):
        super().__init__(parent);self.service=service;self.saved=False
        self.setWindowTitle('Custom template editor');self.resize(950,780)
        box=QVBoxLayout(self)
        note=QLabel('Configure fields, categories, metadata and optional clauses. Use {{ variable }}, {% if condition %} and {% for item in group %}. Each saved version is immutable. Imported DOCX contributes text; PRarup applies its own print style.')
        note.setWordWrap(True);box.addWidget(note)
        tabs=QTabWidget();self.metadata=QPlainTextEdit(json.dumps(service.clean_metadata(item),ensure_ascii=False,indent=2));self.clauses=QPlainTextEdit(clauses)
        tabs.addTab(self.metadata,'Metadata and questionnaire JSON');tabs.addTab(self.clauses,'Document clauses');box.addWidget(tabs)
        row=QHBoxLayout()
        for title,action in [('Validate',self.validate),('Save new version',self.save)]:
            button=QPushButton(title);button.clicked.connect(action);row.addWidget(button)
        box.addLayout(row)
    def definition(self):return json.loads(self.metadata.toPlainText()),self.clauses.toPlainText()
    def validate(self):
        try:self.service.validate_package(*self.definition());QMessageBox.information(self,'Template valid','Questionnaire and template syntax are valid. Test the completed output before office use.')
        except Exception as error:QMessageBox.warning(self,'Template validation',str(error))
    def save(self):
        try:self.service.save_version(*self.definition());self.saved=True;self.accept()
        except Exception as error:QMessageBox.warning(self,'Cannot save version',str(error))

class TemplateManager(QWidget):
    changed=pyqtSignal()
    def __init__(self,service):
        super().__init__();self.service=service
        box=QVBoxLayout(self);title=QLabel('Template workshop');title.setObjectName('heading');box.addWidget(title)
        note=QLabel('Duplicate a built-in template to customize it. Custom JSON questionnaires can add categories, fields, repeating groups and conditional clauses. Text-only DOCX import supports {{ variable }} placeholders. Versions remain available for old drafts.')
        note.setWordWrap(True);box.addWidget(note)
        self.errors=QLabel();self.errors.setWordWrap(True);box.addWidget(self.errors)
        self.list=QListWidget();box.addWidget(self.list)
        row=QHBoxLayout()
        for label,fn in [('New template',self.new),('Duplicate',self.duplicate),('Edit / new version',self.edit),('Enable / disable',self.toggle)]:
            button=QPushButton(label);button.clicked.connect(fn);row.addWidget(button)
        box.addLayout(row);row=QHBoxLayout()
        for label,fn in [('Import DOCX',self.import_docx),('Import package',self.import_package),('Export package',self.export_package),('Restore version',self.restore)]:
            button=QPushButton(label);button.clicked.connect(fn);row.addWidget(button)
        box.addLayout(row);self.refresh()
    def refresh(self):
        self.service.reload();self.list.clear();self.errors.setText("\n".join(self.service.errors))
        for key,t in self.service.all_templates.items():
            item=QListWidgetItem(t['name']+' • v'+t['version']+' • '+('Enabled' if key in self.service.templates else 'Disabled')+(' • Custom' if t.get('_custom') else ' • Built-in'))
            item.setData(Qt.ItemDataRole.UserRole,key);self.list.addItem(item)
    def selected(self):
        item=self.list.currentItem();return item.data(Qt.ItemDataRole.UserRole) if item else None
    def editor(self,item,clause):
        if TemplateEditor(self.service,item,clause,self).exec():self.refresh();self.changed.emit()
    def new(self):self.editor(self.service.new_definition(),'OFFICE DOCUMENT\n\nI, {{ signer }}, record the following purpose:\n\n{{ purpose }}\n\nSignature: ____________________')
    def duplicate(self):
        key=self.selected()
        if key:self.editor(*self.service.duplicate(key))
    def edit(self):
        key=self.selected()
        if not key:return
        t=self.service.all_templates[key]
        if not t.get('_custom'):
            self.editor(*self.service.duplicate(key));return
        item=copy.deepcopy(t);parts=item['version'].split('.');parts[-1]=str(int(parts[-1])+1);item['version']='.'.join(parts)
        self.editor(item,self.service.clause_path(t).read_text(encoding='utf-8'))
    def toggle(self):
        key=self.selected()
        if key:self.service.set_enabled(key,key not in self.service.templates);self.refresh();self.changed.emit()
    def import_docx(self):
        path,_=QFileDialog.getOpenFileName(self,'Import text-only Word template','','Word (*.docx)')
        if path:
            try:self.editor(*self.service.import_docx(path))
            except Exception as error:QMessageBox.warning(self,'Import failed',str(error))
    def import_package(self):
        path,_=QFileDialog.getOpenFileName(self,'Import PRarup template package','','PRarup template (*.json)')
        if path:
            try:
                from pathlib import Path
                package=json.loads(Path(path).read_text(encoding='utf-8'))
                if package.get('format')!=1:raise ValueError('Unsupported template package.')
                item=package['metadata'];clause=package['clauses'];self.service.validate_package(item,clause);self.editor(item,clause)
            except Exception as error:QMessageBox.warning(self,'Import failed',str(error))
    def export_package(self):
        key=self.selected()
        if not key:return
        path,_=QFileDialog.getSaveFileName(self,'Export editable template package',key+'.json','PRarup template (*.json)')
        if path:
            try:
                from pathlib import Path
                item,clause=self.service.duplicate(key)
                if self.service.all_templates[key].get('_custom'):item=self.service.clean_metadata(self.service.all_templates[key])
                Path(path).write_text(json.dumps({'format':1,'metadata':item,'clauses':clause},ensure_ascii=False,indent=2),encoding='utf-8')
            except Exception as error:QMessageBox.warning(self,'Export failed',str(error))
    def restore(self):
        key=self.selected()
        if not key:return
        if not self.service.all_templates[key].get('_custom'):
            QMessageBox.information(self,'Built-in template','Built-in versions are read-only. Duplicate one to create custom versions.');return
        version,ok=QInputDialog.getItem(self,'Restore template version','Version',self.service.versions(key),0,False)
        if ok:
            try:self.service.restore_version(key,version);self.refresh();self.changed.emit()
            except Exception as error:QMessageBox.warning(self,'Restore failed',str(error))
