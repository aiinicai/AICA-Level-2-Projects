from PyQt6.QtCore import Qt, QMarginsF
from PyQt6.QtGui import QPixmap, QPageSize, QPageLayout
from PyQt6.QtWidgets import QDialog,QVBoxLayout,QHBoxLayout,QScrollArea,QWidget,QLabel,QPushButton,QMessageBox
from PyQt6.QtPrintSupport import QPrinter,QPrintDialog
from prarup.services.export_service import PrintDocument

class PrintPreview(QDialog):
    def __init__(self,text,options=None,parent=None):
        super().__init__(parent)
        self.text,self.options=text,options
        self.setWindowTitle("A4 print preview")
        self.resize(940,850)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint,True)
        box=QVBoxLayout(self)
        row=QHBoxLayout()
        model=PrintDocument(text,options)
        row.addWidget(QLabel(f"A4 • {model.pages} pages • Preview matches native PDF export"))
        print_button=QPushButton("Print…");print_button.clicked.connect(self.print_document)
        row.addWidget(print_button);box.addLayout(row)
        scroll=QScrollArea();scroll.setWidgetResizable(True)
        container=QWidget();pages=QVBoxLayout(container);pages.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        for page in range(model.pages):
            label=QLabel();label.setPixmap(QPixmap.fromImage(model.image(page)))
            label.setStyleSheet("border:1px solid #b8b8b8;background:white")
            pages.addWidget(label)
        scroll.setWidget(container);box.addWidget(scroll)

    def print_document(self):
        try:
            printer=QPrinter(QPrinter.PrinterMode.HighResolution)
            printer.setFullPage(True)
            printer.setPageSize(QPageSize(QPageSize.PageSizeId.A4))
            printer.setPageMargins(QMarginsF(0,0,0,0),QPageLayout.Unit.Millimeter)
            dialog=QPrintDialog(printer,self)
            if dialog.exec()==QDialog.DialogCode.Accepted:
                PrintDocument(self.text,self.options).print_to(printer)
        except Exception as error:QMessageBox.critical(self,"Printing failed",str(error))
