def stylesheet(dark=False):
    bg, card, ink, muted = ("#151e2c", "#202d40", "#f6f1e5", "#b4c0d1") if dark else ("#f5f2eb", "#ffffff", "#17283e", "#586778")
    return f"""
    QWidget {{ background: {bg}; color: {ink}; font-family: 'Nirmala UI', 'Segoe UI'; font-size: 14px; }}
    QFrame#sidebar {{ background: #10243a; }}
    QFrame#sidebar QLabel {{ background: transparent; color: #f8f2e3; }}
    QPushButton {{ background: {card}; border: 1px solid #8994a2; border-radius: 7px; padding: 10px 14px; text-align: left; }}
    QPushButton:hover {{ border: 1px solid #b48b43; }}
    QPushButton:focus {{ border: 2px solid #b48b43; }}
    QPushButton:checked {{ background: #b48b43; color: #10243a; }}
    QFrame#sidebar QPushButton {{ background: #19334f; color: #f8f2e3; border: none; }}
    QFrame#sidebar QPushButton:checked {{ background: #b48b43; color: #10243a; }}
    QLabel#heading {{ font-size: 30px; font-weight: 600; }}
    QLabel#muted {{ color: {muted}; }}
    QLabel#stat {{ background: {card}; border-radius: 10px; padding: 24px; font-size: 23px; }}
    QListWidget {{ background: {card}; border: 1px solid #8994a2; border-radius: 8px; padding: 12px; }}
    QFrame#templateCard {{ background: {card}; border: 1px solid #8994a2; border-radius: 8px; padding: 10px; }}
    QFrame#templateCard QLabel {{ background: transparent; border: none; padding: 0; }}
    QLineEdit, QPlainTextEdit, QTextEdit, QTextBrowser, QDateEdit, QSpinBox {{ background: {card}; color: {ink}; border: 1px solid #8994a2; border-radius: 4px; padding: 6px; }}
    QGroupBox {{ border: 1px solid #8994a2; margin-top: 16px; padding-top: 20px; }}
    QGroupBox::title {{ subcontrol-origin: margin; left: 8px; }}
    QComboBox {{ background: {card}; padding: 9px; border: 1px solid #8994a2; }}
    """
