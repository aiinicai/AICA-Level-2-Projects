import json
from PyQt6.QtCore import pyqtSignal
from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QComboBox,QScrollArea,QFrame,QPushButton,QCheckBox

class DocumentLibrary(QWidget):
    selected=pyqtSignal(str)
    def __init__(self,templates,store=None):
        super().__init__();self.templates,self.store=templates,store
        self.favorites=set(json.loads(store.setting('favorites','[]'))) if store else set()
        layout=QVBoxLayout(self);title=QLabel('Prepare a document');title.setObjectName('heading');layout.addWidget(title)
        intro=QLabel('Select a document → enter details → review → prepare → preview and print. Templates remain subject to professional legal review.');intro.setWordWrap(True);layout.addWidget(intro)
        filters=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText('Search deeds and documents…');self.search.setAccessibleName('Search document templates')
        self.category=QComboBox();self.only_favorites=QCheckBox('Favorites only')
        self.search.textChanged.connect(self.filter_cards);self.category.currentTextChanged.connect(self.filter_cards);self.only_favorites.toggled.connect(self.filter_cards)
        filters.addWidget(self.search,1);filters.addWidget(self.category);filters.addWidget(self.only_favorites);layout.addLayout(filters)
        scroll=QScrollArea();scroll.setWidgetResizable(True);container=QWidget();self.cards_layout=QVBoxLayout(container);scroll.setWidget(container);layout.addWidget(scroll)
        self.summary=QLabel();self.summary.setWordWrap(True);layout.addWidget(self.summary)
        self.cards=[];self.refresh()
    def refresh(self):
        self.templates.reload()
        self.favorites=set(json.loads(self.store.setting('favorites','[]'))) if self.store else self.favorites
        category=self.category.currentText();self.category.blockSignals(True);self.category.clear();self.category.addItems(['All categories']+sorted({t['category'] for t in self.templates.templates.values()}));self.category.setCurrentText(category if category else 'All categories');self.category.blockSignals(False)
        while self.cards_layout.count():
            item=self.cards_layout.takeAt(0)
            if item.widget():item.widget().deleteLater()
        self.cards=[]
        for item in self.templates.templates.values():
            card=QFrame();card.setObjectName('templateCard');box=QVBoxLayout(card)
            heading=QLabel(item['name']+'  •  '+item['category']);heading.setWordWrap(True);heading.setStyleSheet('font-size:18px;font-weight:600');box.addWidget(heading)
            description=QLabel(item['description']);description.setWordWrap(True);box.addWidget(description)
            review=QLabel(item['legal_status']+' • v'+item['version']);review.setObjectName('muted');box.addWidget(review)
            row=QHBoxLayout();button=QPushButton('Enter details →');button.setAccessibleName('Enter details for '+item['name']);button.clicked.connect(lambda checked=False,key=item['id']:self.selected.emit(key));row.addWidget(button,1)
            star=QPushButton('★ Favorite' if item['id'] in self.favorites else '☆ Favorite');star.setCheckable(True);star.setChecked(item['id'] in self.favorites);star.clicked.connect(lambda checked,key=item['id'],b=star:self.toggle_favorite(key,checked,b));row.addWidget(star);box.addLayout(row)
            self.cards_layout.addWidget(card);self.cards.append((item,card))
        self.empty=QLabel('No matching documents. Try another search or category.');self.cards_layout.addWidget(self.empty);self.cards_layout.addStretch()
        self.summary.setText(str(len(self.cards))+' available document drafts • Add office templates in Template workshop. Disabled templates stay out of this library.')
        self.filter_cards()
    def toggle_favorite(self,key,checked,button):
        if checked:self.favorites.add(key)
        else:self.favorites.discard(key)
        if self.store:self.store.set_setting('favorites',json.dumps(sorted(self.favorites)))
        button.setText('★ Favorite' if checked else '☆ Favorite');self.filter_cards()
    def filter_cards(self,*_):
        query=self.search.text().strip().casefold();count=0
        for item,card in self.cards:
            match=query in (item['name']+' '+item['description']+' '+item['category']).casefold() and (self.category.currentIndex()==0 or self.category.currentText()==item['category']) and (not self.only_favorites.isChecked() or item['id'] in self.favorites)
            card.setVisible(match);count+=match
        self.empty.setVisible(count==0)
