from PyQt6.QtCore import pyqtSignal,Qt
from PyQt6.QtWidgets import QWidget,QVBoxLayout,QHBoxLayout,QLabel,QLineEdit,QTableWidget,QTableWidgetItem,QPushButton,QDialog,QScrollArea,QMessageBox
from prarup.widgets.schema_form import FieldsForm
from prarup.services.client_service import ClientService

CLIENT_FIELDS=[
 {'id':'name','label':'Client name','type':'text'},
 {'id':'business_name','label':'Business legal name','type':'text','required':False},
 {'id':'entity_type','label':'Entity type','type':'choice','options':['Individual','Proprietorship','Partnership','LLP','Company','Other']},
 {'id':'address','label':'Address','type':'multiline','required':False},
 {'id':'state','label':'State','type':'text','default':'Gujarat'},
 {'id':'phone','label':'Phone','type':'text','required':False},
 {'id':'email','label':'Email','type':'text','required':False},
 {'id':'pan','label':'PAN (optional)','type':'text','required':False},
 {'id':'gstin','label':'GSTIN (optional)','type':'text','required':False},
 {'id':'cin','label':'CIN / LLPIN (optional)','type':'text','required':False},
 {'id':'activities','label':'Business activities','type':'multiline','required':False},
 {'id':'signatory','label':'Authorized signatory and capacity','type':'text','required':False},
 {'id':'people','label':'Partners / directors','type':'repeat','min':0,'max':50,'item_label':'Person','fields':[
  {'id':'name','label':'Full name','type':'text'},
  {'id':'address','label':'Address','type':'multiline','required':False},
  {'id':'role','label':'Role','type':'choice','options':['Partner','Director','Other']},
  {'id':'capital','label':'Cash capital contribution (INR)','type':'text','required':False,'condition':{'role':'Partner'}},
  {'id':'share','label':'Profit/loss share (%)','type':'text','required':False,'condition':{'role':'Partner'}},
  {'id':'identity','label':'Identity particulars (optional)','type':'text','required':False},
  {'id':'designated','label':'Designated partner (LLP)','type':'bool','required':False,'condition':{'role':'Partner'}}
 ]}
]
class ClientEditor(QDialog):
    def __init__(self,service,client=None,parent=None):
        super().__init__(parent);self.service=service;self.client=client or {};self.saved_id=None
        self.setWindowTitle('Client details');self.resize(800,730)
        box=QVBoxLayout(self);scroll=QScrollArea();scroll.setWidgetResizable(True)
        self.form=FieldsForm(CLIENT_FIELDS,self.client);scroll.setWidget(self.form);box.addWidget(scroll)
        save=QPushButton('Save client');save.clicked.connect(self.save);box.addWidget(save)
    def save(self):
        try:
            self.saved_id=self.service.save(self.form.values(),self.client.get('id'));self.accept()
        except Exception as error:QMessageBox.warning(self,'Check client details',str(error))

class ClientManager(QWidget):
    changed=pyqtSignal()
    history_requested=pyqtSignal(int)
    def __init__(self,store):
        super().__init__();self.service=ClientService(store)
        box=QVBoxLayout(self);title=QLabel('Clients');title.setObjectName('heading');box.addWidget(title)
        box.addWidget(QLabel('Save reusable office records and prefill document questionnaires.'))
        self.search=QLineEdit();self.search.setPlaceholderText('Search clients, business names or contact information…');self.search.textChanged.connect(self.refresh);box.addWidget(self.search)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(['Client','Business','Entity','Contact'])
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows);self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection);self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setStretchLastSection(True);self.table.cellDoubleClicked.connect(lambda *_:self.edit());box.addWidget(self.table)
        row=QHBoxLayout()
        for name,action in [('Add client',self.add),('Edit selected',self.edit),('Document history',self.history),('Delete selected',self.delete)]:
            button=QPushButton(name);button.clicked.connect(action);row.addWidget(button)
        box.addLayout(row);self.refresh()
    def refresh(self,*_):
        rows=self.service.search(self.search.text());self.table.setRowCount(len(rows))
        for i,client in enumerate(rows):
            for j,value in enumerate([client['name'],client.get('business_name',''),client.get('entity_type',''),client.get('email') or client.get('phone','')]):
                cell=QTableWidgetItem(value);cell.setData(Qt.ItemDataRole.UserRole,client['id']);self.table.setItem(i,j,cell)
        self.table.resizeColumnsToContents()
    def selected_id(self):
        row=self.table.currentRow()
        return self.table.item(row,0).data(Qt.ItemDataRole.UserRole) if row>=0 else None
    def add(self):
        if ClientEditor(self.service,parent=self).exec():self.refresh();self.changed.emit()
    def edit(self):
        key=self.selected_id()
        if key and ClientEditor(self.service,self.service.get(key),self).exec():self.refresh();self.changed.emit()
    def history(self):
        key=self.selected_id()
        if key:self.history_requested.emit(key)
    def delete(self):
        key=self.selected_id()
        if key and QMessageBox.question(self,'Delete client?','Remove this client record? Existing documents retain their text but lose their client association.')==QMessageBox.StandardButton.Yes:
            try:self.service.delete(key);self.refresh();self.changed.emit()
            except Exception as error:QMessageBox.critical(self,'Deletion failed',str(error))
