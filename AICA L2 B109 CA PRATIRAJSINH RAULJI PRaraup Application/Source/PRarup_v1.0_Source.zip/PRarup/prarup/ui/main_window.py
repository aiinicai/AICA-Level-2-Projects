import logging
import copy
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon, QKeySequence, QShortcut
from PyQt6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QFrame, QLabel, QPushButton, QStackedWidget, QMessageBox
from prarup.config.paths import asset_path
from prarup.ui.dashboard import Dashboard
from prarup.ui.settings import Settings
from prarup.ui.theme import stylesheet
from prarup.services.template_service import TemplateService
from prarup.ui.document_library import DocumentLibrary
from prarup.ui.document_wizard import DocumentWizard
from prarup.repositories.documents import DocumentRepository
from prarup.ui.client_manager import ClientManager
from prarup.ui.document_history import DocumentHistory
from prarup.ui.template_manager import TemplateManager
from prarup.services.locking import verify_password
from PyQt6.QtWidgets import QInputDialog,QLineEdit,QApplication

class MainWindow(QMainWindow):
    def __init__(self, store, root):
        super().__init__()
        self.store = store
        self.root = root
        self.templates = TemplateService(root)
        self.setWindowTitle("PRarup | प्रारूप — Pratirajsinh Raulji and Co.")
        self.setWindowIcon(QIcon(str(asset_path("logos/mark.svg"))))
        self.resize(1180, 760)
        self.setMinimumSize(760, 520)
        shell = QWidget()
        self.setCentralWidget(shell)
        layout = QHBoxLayout(shell)
        layout.setContentsMargins(0, 0, 0, 0)
        self.sidebar = QFrame()
        self.sidebar.setObjectName("sidebar")
        self.sidebar.setFixedWidth(245)
        nav = QVBoxLayout(self.sidebar)
        self.brand = QLabel('<span style="color:#d4ac66;font-size:30px;font-weight:700">PR</span><span style="font-size:30px">arup</span><br><span style="color:#d4ac66;font-size:23px">प्रारूप</span>')
        nav.addWidget(self.brand)
        self.collapse = QPushButton("☰  Collapse sidebar")
        self.collapse.setAccessibleName("Toggle sidebar")
        self.collapse.clicked.connect(self.toggle_sidebar)
        nav.addWidget(self.collapse)
        self.pages = QStackedWidget()
        self.dashboard = Dashboard(store)
        self.library = DocumentLibrary(self.templates,store)
        self.library.selected.connect(self.open_document)
        self.dashboard.new_document.connect(lambda: self.navigate(1))
        self.dashboard.open_draft.connect(self.reopen_document)
        pages = [("Dashboard", self.dashboard), ("Document library", self.library)]
        self.clients=ClientManager(store)
        self.history=DocumentHistory(store)
        self.workshop=TemplateManager(self.templates)
        self.settings=Settings(store,root,self.apply_theme)
        self.clients.changed.connect(self.refresh_workspace)
        self.clients.history_requested.connect(self.show_client_history)
        self.workshop.changed.connect(self.library.refresh)
        self.history.open_draft.connect(self.reopen_document)
        self.settings.restored.connect(self.refresh_workspace)
        pages += [('Clients',self.clients),('Templates',self.workshop),('Settings',self.settings),('History',self.history)]
        self.buttons = []
        for index, (name, page) in enumerate(pages):
            self.pages.addWidget(page)
            button = QPushButton(name)
            button.setCheckable(True)
            button.setToolTip(name)
            button.clicked.connect(lambda checked=False, i=index: self.navigate(i))
            nav.addWidget(button)
            self.buttons.append(button)
            shortcut = QShortcut(QKeySequence(f"Ctrl+{index+1}"), self)
            shortcut.activated.connect(lambda i=index: self.navigate(i))
        nav.addStretch()
        lock_button=QPushButton('Lock workspace');lock_button.clicked.connect(self.lock_workspace);nav.addWidget(lock_button)
        lock_shortcut=QShortcut(QKeySequence('Ctrl+L'),self);lock_shortcut.activated.connect(self.lock_workspace)
        find_shortcut=QShortcut(QKeySequence('Ctrl+F'),self);find_shortcut.activated.connect(self.search_library)
        self.offline = QLabel("OFFLINE WORKSPACE\nv1.0 • Office suite")
        nav.addWidget(self.offline)
        layout.addWidget(self.sidebar)
        layout.addWidget(self.pages, 1)
        self.statusBar().showMessage("Ready • Local storage • Gujarat default jurisdiction")
        self.apply_theme(store.setting("theme", "Light"))
        self.navigate(0)

    def navigate(self, index):
        if index == 0:
            self.dashboard.refresh()
        if index==1:self.library.refresh()
        if index==2:self.clients.refresh()
        if index==3:self.workshop.refresh()
        if index==5:self.history.refresh_clients()
        self.pages.setCurrentIndex(index)
        for i, button in enumerate(self.buttons):
            button.setChecked(i == index)

    def toggle_sidebar(self):
        collapsed = self.sidebar.width() > 100
        self.sidebar.setFixedWidth(84 if collapsed else 245)
        self.brand.setVisible(not collapsed)
        self.offline.setVisible(not collapsed)
        self.collapse.setText("☰" if collapsed else "☰  Collapse sidebar")
        for i, button in enumerate(self.buttons):
            button.setText(str(i+1) if collapsed else button.toolTip())

    def apply_theme(self, theme):
        try:
            self.store.set_setting("theme", theme)
            self.setStyleSheet(stylesheet(theme == "Dark"))
        except Exception:
            logging.exception("Could not persist appearance")
            QMessageBox.warning(self, "Settings error", "Could not save appearance. Check the data directory permissions.")


    def open_document(self, template_id, document_id=None, payload=None):
        try:
            template = copy.deepcopy(self.templates.get(template_id,version=(payload or {}).get('template_version'),include_disabled=bool(payload)))
            if not payload:
                for section in template['sections']:
                    for field in section['fields']:
                        if field['id']=='state':field['default']=self.store.setting('default_state','Gujarat')
            dialog = DocumentWizard(template, self.templates, self.store, self.root, self, document_id, payload)
            dialog.setStyleSheet(self.styleSheet())
            dialog.exec()
            self.dashboard.refresh()
        except Exception as error:
            logging.exception("Cannot open document questionnaire")
            QMessageBox.critical(self, "Cannot open document", str(error))

    def reopen_document(self, document_id):
        try:
            payload = DocumentRepository(self.store).get(document_id)
            self.templates.get(payload["template_id"],version=payload["template_version"],include_disabled=True)
            self.open_document(payload["template_id"], document_id, payload)
        except Exception as error:
            QMessageBox.warning(self, "Cannot reopen draft", str(error))


    def refresh_workspace(self):
        self.templates.reload();self.library.refresh();self.clients.refresh();self.history.refresh_clients();self.dashboard.refresh()

    def show_client_history(self,key):
        self.navigate(5);self.history.refresh_clients(key)

    def search_library(self):
        self.navigate(1);self.library.search.setFocus()

    def lock_workspace(self):
        record=self.store.setting('lock_password')
        if not record:
            QMessageBox.information(self,'Screen locking','Set a screen-lock password in Settings first.');return
        self.setEnabled(False)
        while True:
            password,ok=QInputDialog.getText(None,'PRarup locked','Screen-lock password',QLineEdit.EchoMode.Password)
            if not ok:
                QApplication.quit();return
            if verify_password(password,record):self.setEnabled(True);return
            QMessageBox.warning(None,'Incorrect password','The password did not match.')
