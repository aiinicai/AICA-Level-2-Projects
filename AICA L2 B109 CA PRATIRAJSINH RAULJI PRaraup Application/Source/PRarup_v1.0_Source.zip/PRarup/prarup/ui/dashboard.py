from PyQt6.QtCore import pyqtSignal, Qt
from PyQt6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QListWidget, QPushButton, QListWidgetItem

class Dashboard(QWidget):
    new_document = pyqtSignal()
    open_draft = pyqtSignal(int)
    def __init__(self, store):
        super().__init__()
        self.store = store
        layout = QVBoxLayout(self)
        title = QLabel("Your practice, in focus")
        title.setObjectName("heading")
        layout.addWidget(title)
        layout.addWidget(QLabel("Pratirajsinh Raulji and Co. • Local workspace"))
        row = QHBoxLayout()
        self.labels = {}
        for key in ("Clients", "Documents", "Drafts"):
            label = QLabel()
            label.setObjectName("stat")
            self.labels[key] = label
            row.addWidget(label)
        layout.addLayout(row)
        new_button = QPushButton("+ Prepare a new deed or document")
        new_button.clicked.connect(self.new_document.emit)
        layout.addWidget(new_button)
        layout.addWidget(QLabel("Saved drafts — select a document and click Open, or double-click"))
        self.recent_list = QListWidget()
        layout.addWidget(self.recent_list)
        self.recent_list.itemDoubleClicked.connect(self.open_item)
        open_button = QPushButton("Open selected draft")
        open_button.clicked.connect(lambda: self.open_item(self.recent_list.currentItem()))
        layout.addWidget(open_button)
        note = QLabel("Explore the expanded document library and choose a print style. Professional review required before execution.\nYour workspace is offline. No client information is sent to a server.")
        note.setWordWrap(True)
        note.setObjectName("muted")
        layout.addWidget(note)
        self.refresh()

    def refresh(self):
        for key, value in self.store.stats().items():
            self.labels[key].setText(f"{value}\n{key}")
        self.recent_list.clear()
        documents = self.store.recent()
        for document in documents:
            item = QListWidgetItem(f"{document.title}  •  {document.status}  •  {document.updated_at[:10]}")
            item.setData(Qt.ItemDataRole.UserRole, document.id)
            self.recent_list.addItem(item)
        if not documents:
            self.recent_list.addItem("No documents yet. Your saved documents will appear here.")


    def open_item(self, item):
        if item and item.data(Qt.ItemDataRole.UserRole) is not None:
            self.open_draft.emit(item.data(Qt.ItemDataRole.UserRole))
