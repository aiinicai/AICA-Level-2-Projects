import json
import logging
import re
from pathlib import Path
from PyQt6.QtCore import QUrl, Qt
from PyQt6.QtGui import QDesktopServices
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QStackedWidget, QWidget, QTabWidget, QScrollArea, QLabel, QPushButton, QTextEdit, QTextBrowser, QMessageBox, QFileDialog, QComboBox
from prarup.widgets.schema_form import FieldsForm
from prarup.services.validation_service import validate, ValidationError
from prarup.services.document_engine import DocumentEngine
from prarup.services.export_service import export_docx, export_pdf, document_html
from prarup.repositories.documents import DocumentRepository
from prarup.services.client_service import ClientService
from prarup.services.export_service import STYLES,layout_options
from prarup.ui.document_preview import PrintPreview

class DocumentWizard(QDialog):
    def __init__(self, template, templates, store, root, parent=None, document_id=None, payload=None):
        super().__init__(parent)
        self.template, self.root = template, root
        self.templates = templates
        self.repository = DocumentRepository(store)
        self.store=store
        self.client_service=ClientService(store)
        self.document_id = document_id
        self.rendered_values = None
        self.saved_snapshot = None
        self.setWindowTitle("PRarup — " + template["name"])
        self.resize(1040, 780)
        self.setMinimumSize(650, 500)
        self.setWindowFlag(Qt.WindowType.WindowMaximizeButtonHint, True)
        box = QVBoxLayout(self)
        self.step_label = QLabel()
        self.step_label.setObjectName("heading")
        box.addWidget(self.step_label)
        note = QLabel(template["legal_status"] + " • " + template["execution_notes"])
        note.setWordWrap(True)
        note.setObjectName("muted")
        box.addWidget(note)
        client_row=QHBoxLayout()
        client_row.addWidget(QLabel('Client record'))
        self.client=QComboBox();self.client.addItem('No linked client',None)
        for client in self.client_service.search():self.client.addItem(client['name'],client['id'])
        current=(payload or {}).get('client_id')
        if current is not None:self.client.setCurrentIndex(max(0,self.client.findData(current)))
        client_row.addWidget(self.client,1)
        prefill=QPushButton('Prefill from client');prefill.clicked.connect(self.prefill_client);client_row.addWidget(prefill)
        box.addLayout(client_row)
        options=(payload or {}).get('options') or {'style':store.setting('print_style','Editorial serif')}
        options=layout_options(options)
        print_row=QHBoxLayout()
        print_row.addWidget(QLabel('Print style'))
        self.print_style=QComboBox();self.print_style.addItems(list(STYLES));self.print_style.setCurrentText(options['style']);print_row.addWidget(self.print_style)
        self.copy_mode=QComboBox();self.copy_mode.addItems(['Review copy','Clean execution copy']);self.copy_mode.setToolTip('Clean copy omits the review notice; it does not certify legal approval.');self.copy_mode.setCurrentIndex(0 if options['review_copy'] else 1);print_row.addWidget(self.copy_mode)
        self.margin=QComboBox();self.margin.addItems(['20 mm margins','25 mm margins','30 mm margins']);self.margin.setCurrentIndex(min(range(3),key=lambda i:abs([20,25,30][i]-options['margin_mm'])));print_row.addWidget(self.margin)
        self.stamp=QComboBox();self.stamp.addItems(['No stamp space','45 mm stamp space','75 mm stamp space']);self.stamp.setCurrentIndex(min(range(3),key=lambda i:abs([0,45,75][i]-options['stamp_space_mm'])));print_row.addWidget(self.stamp)
        box.addLayout(print_row)
        self.pages = QStackedWidget()
        box.addWidget(self.pages, 1)
        tabs = QTabWidget()
        self.forms = []
        for section in template["sections"]:
            form = FieldsForm(section["fields"], (payload or {}).get("values", {}))
            self.forms.append(form)
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(form)
            tabs.addTab(scroll, section["title"])
        self.pages.addWidget(tabs)
        self.review = QTextBrowser()
        self.pages.addWidget(self.review)
        self.editor = QTextEdit()
        self.editor.setAcceptRichText(False)
        self.editor.setAccessibleName("Editable document draft")
        self.pages.addWidget(self.editor)
        self.message = QLabel("")
        self.message.setWordWrap(True)
        self.message.setObjectName("muted")
        box.addWidget(self.message)
        actions = QHBoxLayout()
        self.back_button = QPushButton("← Back")
        self.back_button.clicked.connect(self.back)
        actions.addWidget(self.back_button)
        self.save_button = QPushButton("Save draft")
        self.save_button.clicked.connect(self.save_draft)
        actions.addWidget(self.save_button)
        self.docx_button = QPushButton("Export Word")
        self.docx_button.clicked.connect(lambda: self.export("docx"))
        actions.addWidget(self.docx_button)
        self.pdf_button = QPushButton("Export PDF")
        self.pdf_button.clicked.connect(lambda: self.export("pdf"))
        actions.addWidget(self.pdf_button)
        self.preview_button=QPushButton('Preview / print');self.preview_button.clicked.connect(self.preview);actions.addWidget(self.preview_button)
        self.folder_button = QPushButton("Output folder")
        self.folder_button.clicked.connect(self.open_folder)
        actions.addWidget(self.folder_button)
        self.next_button = QPushButton("Review details →")
        self.next_button.clicked.connect(self.advance)
        actions.addWidget(self.next_button)
        box.addLayout(actions)
        if payload and payload.get("text"):
            self.editor.setPlainText(payload["text"])
            self.rendered_values = self.values()
            self.pages.setCurrentIndex(2)
        self.update_step()
        self.saved_snapshot = self.snapshot()

    def values(self):
        return {key: value for form in self.forms for key, value in form.values().items()}

    def snapshot(self):
        return json.dumps({"values": self.values(), "text": self.editor.toPlainText(), "client_id":self.client.currentData(), "options":self.print_options()}, sort_keys=True)

    def update_step(self):
        page = self.pages.currentIndex()
        self.step_label.setText(["1  Enter details", "2  Review details", "3  Edit and export draft"][page])
        self.back_button.setEnabled(page > 0)
        self.next_button.setVisible(page < 2)
        self.next_button.setText("Review details →" if page == 0 else "Prepare draft →")
        self.docx_button.setVisible(page == 2)
        self.pdf_button.setVisible(page == 2)
        self.preview_button.setVisible(page == 2)

    def render_review(self, values):
        lines = [self.template["name"], "", self.template["warning"], "", self.template["execution_notes"], ""]
        for section in self.template["sections"]:
            lines.append(section["title"].upper())
            for field in section["fields"]:
                if field["id"] not in values:
                    continue
                value = values[field["id"]]
                if isinstance(value, list):
                    for i, item in enumerate(value):
                        lines.append(f"Partner {i+1}")
                        for child in field["fields"]:
                            lines.append(f"  {child['label']}: {item.get(child['id'], '')}")
                else:
                    lines.append(f"{field['label']}: {value}")
            lines.append("")
        lines.extend(["Source references (template remains pending professional review):", *self.template["sources"]])
        self.review.setPlainText("\n".join(lines))

    def advance(self):
        try:
            data = validate(self.template, self.values())
            if self.pages.currentIndex() == 0:
                self.render_review(data)
                self.pages.setCurrentIndex(1)
            else:
                if self.editor.toPlainText() and self.rendered_values != self.values():
                    answer = QMessageBox.question(self, "Regenerate draft?", "Changed details require a new draft. This replaces the current draft text, including manual edits. Continue?")
                    if answer != QMessageBox.StandardButton.Yes:
                        return
                if not self.editor.toPlainText() or self.rendered_values != self.values():
                    text = DocumentEngine(self.templates).generate(self.template, self.values())
                    self.editor.setPlainText(text)
                    self.rendered_values = self.values()
                self.pages.setCurrentIndex(2)
            self.message.setText("")
            self.update_step()
        except ValidationError as error:
            self.message.setText(str(error))
            QMessageBox.warning(self, "Please check the details", str(error))
        except Exception as error:
            logging.exception("Document generation failed")
            QMessageBox.critical(self, "Could not prepare draft", str(error))

    def back(self):
        self.pages.setCurrentIndex(max(0, self.pages.currentIndex()-1))
        self.update_step()

    def save_draft(self):
        try:
            # Save incomplete questionnaires too. An old preview is discarded if its inputs changed.
            current = self.values()
            text = self.editor.toPlainText() if self.rendered_values == current else ""
            self.document_id = self.repository.save(self.template, current, text, self.document_id, self.client.currentData(),self.print_options())
            self.saved_snapshot = self.snapshot()
            self.message.setText(f"Draft saved locally (record {self.document_id}).")
            return True
        except Exception as error:
            logging.exception("Draft save failed")
            QMessageBox.critical(self, "Could not save draft", str(error))
            return False

    def export(self, extension):
        try:
            if self.rendered_values != self.values():
                raise ValueError("The details have changed. Use Review details and Prepare draft to regenerate before exporting.")
            text = self.editor.toPlainText().strip()
            if not text:
                raise ValueError("Prepare a draft before exporting.")
            if not self.save_draft():
                return
            base = self.template["id"] + "-" + str(self.document_id)
            filename, _ = QFileDialog.getSaveFileName(self, "Export " + extension.upper(), str(self.root / "documents" / (base + "." + extension)), extension.upper() + f" (*.{extension})")
            if not filename:
                return
            path = Path(filename)
            if path.suffix.lower() != "." + extension:
                path = path.with_suffix("." + extension)
                if path.exists() and QMessageBox.question(self, "Replace file?", f"Replace {path.name}?") != QMessageBox.StandardButton.Yes:
                    return
            (export_docx if extension == "docx" else export_pdf)(text, path,self.print_options())
            self.message.setText("Exported: " + str(path))
        except Exception as error:
            logging.exception("Export failed")
            QMessageBox.critical(self, "Export failed", str(error))

    def open_folder(self):
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(self.root / "documents"))):
            QMessageBox.warning(self, "Cannot open folder", str(self.root / "documents"))

    def reject(self):
        if self.snapshot() != self.saved_snapshot:
            answer = QMessageBox.question(self, "Unsaved changes", "Save this draft before closing?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel)
            if answer == QMessageBox.StandardButton.Cancel:
                return
            if answer == QMessageBox.StandardButton.Yes and not self.save_draft():
                return
        super().reject()


    def print_options(self):
        return {'style':self.print_style.currentText(),'review_copy':self.copy_mode.currentIndex()==0,'margin_mm':[20,25,30][self.margin.currentIndex()],'stamp_space_mm':[0,45,75][self.stamp.currentIndex()],'firm_footer':True}

    def prefill_client(self):
        key=self.client.currentData()
        if key is None:
            QMessageBox.information(self,'Select a client','Choose a saved client above, or create one in Clients.');return
        if QMessageBox.question(self,'Prefill questionnaire?','Replace matching questionnaire fields with the selected client record? Other entries will remain.')!=QMessageBox.StandardButton.Yes:return
        try:
            values=self.client_service.prefill(self.template,self.client_service.get(key))
            for form in self.forms:form.set_values(values)
            self.pages.setCurrentIndex(0);self.update_step();self.message.setText('Client details copied. Check dates, amounts and all partner details before generating.')
        except Exception as error:QMessageBox.warning(self,'Prefill failed',str(error))

    def preview(self):
        if self.rendered_values!=self.values():
            QMessageBox.warning(self,'Regenerate required','The questionnaire has changed. Review and prepare the draft again.');return
        try:PrintPreview(self.editor.toPlainText(),self.print_options(),self).exec()
        except Exception as error:QMessageBox.critical(self,'Preview failed',str(error))
