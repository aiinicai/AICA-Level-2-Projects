import os
from pathlib import Path

def data_directory():
    override = os.environ.get("PRARUP_DATA_DIR")
    root = Path(override) if override else Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local/share")) / "PRarup"
    root.mkdir(parents=True, exist_ok=True)
    for name in ("logs", "backups", "documents"):
        (root / name).mkdir(exist_ok=True)
    return root

def asset_path(relative):
    import sys
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
    return base / "assets" / relative


def resource_path(relative):
    import sys
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
    return base / relative
