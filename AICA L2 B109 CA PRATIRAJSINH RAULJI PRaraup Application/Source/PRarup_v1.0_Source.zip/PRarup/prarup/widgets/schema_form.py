from PyQt6.QtCore import QDate
from PyQt6.QtWidgets import QWidget, QFormLayout, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit, QDateEdit, QComboBox, QCheckBox, QPushButton, QGroupBox, QSpinBox
from prarup.services.validation_service import active

class FieldsForm(QWidget):
    def __init__(self, fields, values=None):
        super().__init__()
        self.fields = fields
        self.controls = {}
        self.rows = {}
        layout = QFormLayout(self)
        layout.setFieldGrowthPolicy(QFormLayout.FieldGrowthPolicy.AllNonFixedFieldsGrow)
        values = values or {}
        for field in fields:
            kind, key = field["type"], field["id"]
            value = values.get(key, field.get("default", ""))
            if kind == "repeat":
                control = RepeatingGroup(field, value if isinstance(value, list) else None)
            elif kind == "multiline":
                control = QPlainTextEdit()
                control.setPlainText(str(value))
                control.setMaximumHeight(100)
            elif kind == "date":
                control = QDateEdit()
                control.setCalendarPopup(True)
                control.setDisplayFormat("dd MMM yyyy")
                parsed = QDate.fromString(str(value), "yyyy-MM-dd")
                control.setDate(parsed if parsed.isValid() else QDate.currentDate())
            elif kind == "choice":
                control = QComboBox()
                control.addItems(field["options"])
                control.setCurrentText(str(value) if value else field["options"][0])
            elif kind == "bool":
                control = QCheckBox("Include this provision")
                control.setChecked(value is True)
            elif kind == "number":
                control = QSpinBox()
                control.setRange(field.get("min", 0), field.get("max", 1000000))
                control.setValue(int(value or control.minimum()))
            else:
                control = QLineEdit(str(value))
                control.setMaxLength(500)
                if kind in ("currency", "percent"):
                    control.setPlaceholderText("0.00" if kind == "currency" else "e.g. 50.00")
            control.setAccessibleName(field["label"])
            self.controls[key] = control
            wrap = QWidget()
            box = QVBoxLayout(wrap)
            box.setContentsMargins(0, 0, 0, 8)
            box.addWidget(control)
            if field.get("help"):
                help_label = QLabel(field["help"])
                help_label.setWordWrap(True)
                help_label.setObjectName("muted")
                box.addWidget(help_label)
            label = QLabel(field["label"] + (" *" if field.get("required", True) and kind != "bool" else ""))
            label.setWordWrap(True)
            label.setBuddy(control)
            layout.addRow(label, wrap)
            self.rows[key] = (label, wrap)
            if isinstance(control, QCheckBox):
                control.toggled.connect(self.update_conditions)
            if isinstance(control, QComboBox):
                control.currentTextChanged.connect(self.update_conditions)
        self.update_conditions()

    def values(self):
        result = {}
        for key, control in self.controls.items():
            if isinstance(control, RepeatingGroup):
                value = control.values()
            elif isinstance(control, QPlainTextEdit):
                value = control.toPlainText()
            elif isinstance(control, QDateEdit):
                value = control.date().toString("yyyy-MM-dd")
            elif isinstance(control, QComboBox):
                value = control.currentText()
            elif isinstance(control, QCheckBox):
                value = control.isChecked()
            elif isinstance(control, QSpinBox):
                value = str(control.value())
            else:
                value = control.text()
            result[key] = value
        return result

    def set_values(self,values):
        for key,value in values.items():
            control=self.controls.get(key)
            if control is None:continue
            if isinstance(control,RepeatingGroup):
                for group,_ in control.forms:group.setParent(None);group.deleteLater()
                control.forms=[]
                for row in value:control.add(row)
                while len(control.forms)<control.field.get('min',0):control.add({})
                control.update_buttons()
            elif isinstance(control,QPlainTextEdit):control.setPlainText(str(value))
            elif isinstance(control,QDateEdit):
                parsed=QDate.fromString(str(value),'yyyy-MM-dd')
                if parsed.isValid():control.setDate(parsed)
            elif isinstance(control,QComboBox):control.setCurrentText(str(value))
            elif isinstance(control,QCheckBox):control.setChecked(bool(value))
            elif isinstance(control,QSpinBox):control.setValue(int(value or 0))
            else:control.setText(str(value))
        self.update_conditions()

    def update_conditions(self, *_):
        values = self.values()
        for field in self.fields:
            visible = active(field, values)
            for widget in self.rows[field["id"]]:
                widget.setVisible(visible)

class RepeatingGroup(QWidget):
    def __init__(self, field, values=None):
        super().__init__()
        self.field = field
        self.forms = []
        self.layout = QVBoxLayout(self)
        self.holder = QVBoxLayout()
        self.layout.addLayout(self.holder)
        row = QHBoxLayout()
        self.add_button = QPushButton("+ Add " + field.get("item_label","partner"))
        self.remove_button = QPushButton("Remove last " + field.get("item_label","partner"))
        self.add_button.clicked.connect(lambda: self.add({}))
        self.remove_button.clicked.connect(self.remove)
        row.addWidget(self.add_button)
        row.addWidget(self.remove_button)
        self.layout.addLayout(row)
        initial = values if values else [{} for _ in range(field.get("min", 1))]
        for value in initial:
            self.add(value)

    def update_buttons(self):
        self.add_button.setEnabled(len(self.forms) < self.field.get("max", 50))
        self.remove_button.setEnabled(len(self.forms) > self.field.get("min", 1))

    def add(self, value):
        if len(self.forms) >= self.field.get("max", 50):
            return
        group = QGroupBox(f"{self.field.get('item_label','Partner')} {len(self.forms)+1}")
        box = QVBoxLayout(group)
        form = FieldsForm(self.field["fields"], value)
        box.addWidget(form)
        self.forms.append((group, form))
        self.holder.addWidget(group)
        self.update_buttons()

    def remove(self):
        if len(self.forms) > self.field.get("min", 1):
            group, _ = self.forms.pop()
            group.setParent(None)
            group.deleteLater()
        self.update_buttons()

    def values(self):
        return [form.values() for _, form in self.forms]
