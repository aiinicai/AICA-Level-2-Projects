; PRarup 1.0 per-user Windows installer. Build with Inno Setup 6.7+.
#ifndef DistributionRoot
  #define DistributionRoot "..\.."
#endif
#define ProductVersion "1.0.0"

[Setup]
AppId={{E9F8A270-9A13-4BB8-9966-37A96F0B7621}
AppName=PRarup
AppVersion={#ProductVersion}
AppVerName=PRarup 1.0
AppPublisher=Pratirajsinh Raulji and Co.
DefaultDirName={localappdata}\Programs\PRarup
DefaultGroupName=PRarup
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0.19041
OutputDir={#DistributionRoot}
OutputBaseFilename=PRarup_Setup_v1.0
SetupIconFile={#DistributionRoot}\PRarup\assets\icons\prarup.ico
UninstallDisplayIcon={app}\PRarup.exe
UninstallDisplayName=PRarup 1.0
WizardStyle=modern
Compression=lzma2/fast
SolidCompression=yes
SetupLogging=yes
CloseApplications=yes
RestartApplications=no
VersionInfoVersion=1.0.0.0
VersionInfoDescription=PRarup Windows Installer
VersionInfoProductName=PRarup
InfoBeforeFile={#DistributionRoot}\PRarup\installer\INSTALLATION_NOTES.txt

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Shortcuts:"

[Files]
Source: "{#DistributionRoot}\PRarup_v1.0.exe"; DestDir: "{app}"; DestName: "PRarup.exe"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup_User_Manual.pdf"; DestDir: "{app}\Documentation"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup_Developer_Guide.pdf"; DestDir: "{app}\Documentation"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup_Test_Report.md"; DestDir: "{app}\Documentation"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup_Sample_Deed.pdf"; DestDir: "{app}\Documentation"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup_v1.0_Source.zip"; DestDir: "{app}\Source"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup\README.md"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup\installer\THIRD_PARTY_NOTICES.txt"; DestDir: "{app}\Licenses"; Flags: ignoreversion
Source: "{#DistributionRoot}\PRarup\installer\licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\PRarup"; Filename: "{app}\PRarup.exe"; WorkingDir: "{app}"
Name: "{group}\PRarup User Manual"; Filename: "{app}\Documentation\PRarup_User_Manual.pdf"
Name: "{userdesktop}\PRarup"; Filename: "{app}\PRarup.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\PRarup.exe"; Description: "Launch PRarup"; Flags: nowait postinstall skipifsilent unchecked

; User data is deliberately outside {app}; no AppData database deletion action exists.
