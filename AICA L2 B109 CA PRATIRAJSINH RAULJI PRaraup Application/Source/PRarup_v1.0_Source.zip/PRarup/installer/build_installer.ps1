param([Parameter(Mandatory=$true)][string]$Compiler)
$ErrorActionPreference = 'Stop'
$distribution = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
& $Compiler ('/DDistributionRoot=' + $distribution) (Join-Path $PSScriptRoot 'PRarup.iss')
if ($LASTEXITCODE -ne 0) { throw 'Installer compilation failed.' }
