export type Role = 'EMPLOYEE' | 'ADMIN' | 'OWNER';

export type EmploymentStatus = 'active' | 'inactive' | 'trainee';

export interface BankDetails {
  accountNo: string;
  ifsc: string;
  bankName: string;
}

export interface ContactInfo {
  email: string;
  phone: string;
}

export interface Employee {
  id: string;
  empCode: string;
  name: string;
  designation: string;
  department: string;
  branch: string;
  dateOfJoining: string; // YYYY-MM-DD
  status: EmploymentStatus;
  baseSalary: number;
  conveyance: number;
  leaveAccrualRate: number; // default 2, driver 0
  bankDetails: BankDetails;
  contact: ContactInfo;
  photoUrl?: string;
  password?: string;
  passwordChanged?: boolean;
  role: Role;
}

export type AttendanceStatusCode = 'P' | 'A' | 'HD' | 'H'; // Present, Absent, Half-Day, Holiday

export interface AttendanceRecord {
  id: string;
  empId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatusCode;
  clientId: string;
  clientName: string;
  notes?: string;
  location?: string;
  checkInTime?: string;
  checkOutTime?: string;
  modifiedBy?: string;
  modifiedAt?: string;
}

export interface Client {
  id: string;
  name: string;
  code: string;
  location: string;
  contactPerson: string;
  status: 'active' | 'inactive';
}

export interface LeaveRecord {
  id: string;
  empId: string;
  month: string; // YYYY-MM e.g. "2026-02"
  previousBalance: number;
  accrued: number;
  taken: number;
  balance: number;
  salaryDeductedDays: number;
  salaryDeductedAmount: number;
  carryForward: number;
}

export interface AdvanceRecord {
  id: string;
  empId: string;
  date: string; // YYYY-MM-DD
  month: string; // YYYY-MM
  type: 'given' | 'recovery';
  amount: number; // positive number always
  notes: string;
  createdById?: string;
}

export interface PayrollOverride {
  salaryDeducted?: number;
  conveyance?: number;
  advance?: number;
  notes?: string;
}

export interface PayrollRow {
  empId: string;
  empCode: string;
  empName: string;
  designation: string;
  branch: string;
  bankDetails: BankDetails;
  baseSalary: number;
  leaveAccrued: number;
  leavesTaken: number;
  leavesBalance: number;
  salaryDeducted: number;
  carryForwardLeave: number;
  salary: number; // baseSalary - salaryDeducted
  conveyance: number;
  advance: number; // positive = added, negative = recovered
  totalSalary: number; // salary + conveyance + advance
  remainingAdvance: number;
  dailyAttendance: Record<number, AttendanceStatusCode>; // 1..31 -> P, A, HD, H
  manualOverrides?: PayrollOverride;
}

export interface PayrollMonth {
  month: string; // "2026-02"
  displayMonth: string; // "Feb-26"
  isFinalized: boolean;
  finalizedAt?: string;
  finalizedBy?: string;
  unlockedReason?: string;
  rows: PayrollRow[];
}

export interface Holiday {
  id: string;
  date: string; // YYYY-MM-DD
  name: string;
  isOptional?: boolean;
}

export interface AuditLog {
  id: string;
  timestamp: string;
  performedBy: string;
  action: string;
  entity: string;
  details: string;
}

export interface DailyAttendancePrompt {
  needsPrompt: boolean;
  date: string;
  employee: Employee;
}
