import { Employee, AttendanceRecord, Client, Holiday, AdvanceRecord, PayrollMonth, AuditLog } from '../types';

export async function loginUser(credentials: {
  email: string;
  password?: string;
  role: 'ADMIN' | 'EMPLOYEE';
  name?: string;
}): Promise<Employee> {
  const res = await fetch('/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(credentials),
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ error: 'Authentication failed' }));
    throw new Error(errorData.error || 'Authentication failed');
  }
  return res.json();
}

export async function changeUserPassword(empId: string, newPassword: string): Promise<Employee> {
  const res = await fetch('/api/auth/change-password', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ empId, newPassword }),
  });
  if (!res.ok) {
    const errorData = await res.json().catch(() => ({ error: 'Failed to update password' }));
    throw new Error(errorData.error || 'Failed to update password');
  }
  return res.json();
}

export async function fetchEmployees(): Promise<Employee[]> {
  const res = await fetch('/api/employees');
  if (!res.ok) throw new Error('Failed to fetch employees');
  return res.json();
}

export async function createEmployee(data: Partial<Employee>): Promise<Employee> {
  const res = await fetch('/api/employees', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to create employee');
  return res.json();
}

export async function updateEmployee(id: string, data: Partial<Employee>): Promise<Employee> {
  const res = await fetch(`/api/employees/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to update employee');
  return res.json();
}

export async function fetchAttendance(params?: { month?: string; date?: string; empId?: string }): Promise<AttendanceRecord[]> {
  const query = new URLSearchParams(params as Record<string, string>).toString();
  const res = await fetch(`/api/attendance?${query}`);
  if (!res.ok) throw new Error('Failed to fetch attendance');
  return res.json();
}

export async function markAttendance(data: Partial<AttendanceRecord>): Promise<AttendanceRecord> {
  const res = await fetch('/api/attendance', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to mark attendance');
  return res.json();
}

export async function bulkMarkAttendance(records: Partial<AttendanceRecord>[], performedBy: string): Promise<void> {
  const res = await fetch('/api/attendance/bulk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ records, performedBy }),
  });
  if (!res.ok) throw new Error('Failed to bulk mark attendance');
}

export async function fetchClients(): Promise<Client[]> {
  const res = await fetch('/api/clients');
  if (!res.ok) throw new Error('Failed to fetch clients');
  return res.json();
}

export async function createClient(data: Partial<Client>): Promise<Client> {
  const res = await fetch('/api/clients', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to create client');
  return res.json();
}

export async function fetchAdvances(): Promise<AdvanceRecord[]> {
  const res = await fetch('/api/advances');
  if (!res.ok) throw new Error('Failed to fetch advances');
  return res.json();
}

export async function createAdvance(data: Partial<AdvanceRecord>): Promise<AdvanceRecord> {
  const res = await fetch('/api/advances', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to record advance');
  return res.json();
}

export async function fetchHolidays(): Promise<Holiday[]> {
  const res = await fetch('/api/holidays');
  if (!res.ok) throw new Error('Failed to fetch holidays');
  return res.json();
}

export async function createHoliday(data: Partial<Holiday>): Promise<Holiday> {
  const res = await fetch('/api/holidays', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error('Failed to add holiday');
  return res.json();
}

export async function fetchPayroll(monthStr: string): Promise<PayrollMonth> {
  const res = await fetch(`/api/payroll/${monthStr}`);
  if (!res.ok) throw new Error('Failed to fetch payroll');
  return res.json();
}

export async function overridePayrollRow(monthStr: string, empId: string, overrides: Record<string, number | string>): Promise<PayrollMonth> {
  const res = await fetch(`/api/payroll/${monthStr}/override`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ empId, overrides }),
  });
  if (!res.ok) throw new Error('Failed to update payroll override');
  return res.json();
}

export async function finalizePayroll(monthStr: string, finalizedBy: string): Promise<PayrollMonth> {
  const res = await fetch(`/api/payroll/${monthStr}/finalize`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ finalizedBy }),
  });
  if (!res.ok) throw new Error('Failed to finalize payroll');
  return res.json();
}

export async function unlockPayroll(monthStr: string, unlockedBy: string, reason: string): Promise<PayrollMonth> {
  const res = await fetch(`/api/payroll/${monthStr}/unlock`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ unlockedBy, reason }),
  });
  if (!res.ok) throw new Error('Failed to unlock payroll');
  return res.json();
}

export async function fetchAuditLogs(): Promise<AuditLog[]> {
  const res = await fetch('/api/audit-logs');
  if (!res.ok) throw new Error('Failed to fetch audit logs');
  return res.json();
}
