/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Employee,
  AttendanceRecord,
  Client,
  Holiday,
  AdvanceRecord,
  PayrollMonth,
  AuditLog,
  AttendanceStatusCode,
} from './types';
import {
  fetchEmployees,
  createEmployee,
  updateEmployee,
  fetchAttendance,
  markAttendance,
  bulkMarkAttendance,
  fetchClients,
  createClient,
  fetchAdvances,
  createAdvance,
  fetchHolidays,
  createHoliday,
  fetchPayroll,
  overridePayrollRow,
  finalizePayroll,
  unlockPayroll,
  fetchAuditLogs,
} from './services/api';
import { INITIAL_EMPLOYEES, INITIAL_CLIENTS, INITIAL_HOLIDAYS } from './data/seedData';
import { Header } from './components/Header';
import { LoginModal } from './components/LoginModal';
import { DailyCheckInModal } from './components/DailyCheckInModal';
import { EmployeeDashboard } from './components/EmployeeDashboard';
import { AdminDashboard } from './components/AdminDashboard';
import { PayrollEngineView } from './components/PayrollEngineView';
import { EmployeeMasterView } from './components/EmployeeMasterView';
import { AttendanceManagementView } from './components/AttendanceManagementView';
import { LeaveAdvanceView } from './components/LeaveAdvanceView';
import { ClientManagementView } from './components/ClientManagementView';
import { ReportsView } from './components/ReportsView';
import { HolidayCalendarView } from './components/HolidayCalendarView';
import { ChangePasswordModal } from './components/ChangePasswordModal';

export default function App() {
  const [employees, setEmployees] = useState<Employee[]>(INITIAL_EMPLOYEES);
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem('erp_is_authenticated') === 'true';
  });
  const [currentUser, setCurrentUser] = useState<Employee>(() => {
    const savedUserJson = localStorage.getItem('erp_current_user');
    if (savedUserJson) {
      try {
        const parsed = JSON.parse(savedUserJson);
        if (parsed && parsed.id) return parsed;
      } catch (e) {}
    }
    const savedEmpId = localStorage.getItem('erp_logged_in_emp_id');
    if (savedEmpId) {
      const found = INITIAL_EMPLOYEES.find((e) => e.id === savedEmpId);
      if (found) return found;
    }
    return INITIAL_EMPLOYEES[0];
  });

  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>([]);
  const [clients, setClients] = useState<Client[]>(INITIAL_CLIENTS);
  const [advances, setAdvances] = useState<AdvanceRecord[]>([]);
  const [holidays, setHolidays] = useState<Holiday[]>(INITIAL_HOLIDAYS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [payrollMonth, setPayrollMonth] = useState<PayrollMonth | null>(null);

  const getLocalDateStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  };

  const getLocalMonthStr = () => {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  };

  const [selectedMonthStr, setSelectedMonthStr] = useState<string>(() => getLocalMonthStr());
  const [selectedBranch, setSelectedBranch] = useState<string>('All Branches');
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState<boolean>(false);
  const [isChangePasswordModalOpen, setIsChangePasswordModalOpen] = useState<boolean>(false);
  const [isFirstTimePasswordModal, setIsFirstTimePasswordModal] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);

  // Authentication Handlers
  const handleLogin = (user: Employee) => {
    setEmployees((prev) => {
      if (!prev.some((e) => e.id === user.id || (e.contact?.email && user.contact?.email && e.contact.email.toLowerCase() === user.contact.email.toLowerCase()))) {
        return [user, ...prev];
      }
      return prev.map((e) => e.id === user.id ? user : e);
    });

    setCurrentUser(user);
    setIsAuthenticated(true);
    localStorage.setItem('erp_is_authenticated', 'true');
    localStorage.setItem('erp_logged_in_emp_id', user.id);
    localStorage.setItem('erp_current_user', JSON.stringify(user));
    setActiveTab('dashboard');

    // Prompt user to change password on first-time login if not changed yet
    if (!user.passwordChanged) {
      setIsFirstTimePasswordModal(true);
      setIsChangePasswordModalOpen(true);
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('erp_is_authenticated');
    localStorage.removeItem('erp_logged_in_emp_id');
    localStorage.removeItem('erp_current_user');
  };

  const handlePasswordChanged = (updatedUser: Employee) => {
    setCurrentUser(updatedUser);
    setEmployees((prev) => prev.map((e) => (e.id === updatedUser.id ? updatedUser : e)));
    localStorage.setItem('erp_current_user', JSON.stringify(updatedUser));
    setIsFirstTimePasswordModal(false);
    setIsChangePasswordModalOpen(false);
  };

  // Ensure activeTab matches role permissions
  useEffect(() => {
    if (currentUser.role === 'EMPLOYEE') {
      const allowedEmployeeTabs = ['dashboard', 'attendance', 'leaves-advances', 'reports'];
      if (!allowedEmployeeTabs.includes(activeTab)) {
        setActiveTab('dashboard');
      }
    }
  }, [currentUser, activeTab]);

  // Load Initial Data from API & synchronize with local durable storage
  const loadData = async () => {
    try {
      setLoading(true);
      const [empList, attList, clientList, advList, holList, logsList] = await Promise.all([
        fetchEmployees().catch(() => {
          const cached = localStorage.getItem('erp_employees_backup');
          return cached ? JSON.parse(cached) : INITIAL_EMPLOYEES;
        }),
        fetchAttendance({ month: selectedMonthStr }).catch(() => []),
        fetchClients().catch(() => {
          const cached = localStorage.getItem('erp_clients_backup');
          return cached ? JSON.parse(cached) : INITIAL_CLIENTS;
        }),
        fetchAdvances().catch(() => {
          const cached = localStorage.getItem('erp_advances_backup');
          return cached ? JSON.parse(cached) : [];
        }),
        fetchHolidays().catch(() => INITIAL_HOLIDAYS),
        fetchAuditLogs().catch(() => []),
      ]);

      // Check if there are local backup employees that need syncing to server
      let finalEmpList = empList;
      try {
        const cachedEmployeesJson = localStorage.getItem('erp_employees_backup');
        if (cachedEmployeesJson) {
          const cachedEmps: Employee[] = JSON.parse(cachedEmployeesJson);
          if (Array.isArray(cachedEmps)) {
            for (const cEmp of cachedEmps) {
              const existsInServer = empList.some(
                (e: Employee) => e.id === cEmp.id || (e.contact?.email && cEmp.contact?.email && e.contact.email.toLowerCase() === cEmp.contact.email.toLowerCase())
              );
              if (!existsInServer && cEmp.id && cEmp.name) {
                // Recover to server
                await createEmployee(cEmp).catch(() => {});
                finalEmpList = [...finalEmpList, cEmp];
              }
            }
          }
        }
      } catch (e) {
        console.warn('Backup recovery check skipped:', e);
      }

      setEmployees(finalEmpList);
      setAttendanceRecords(attList);
      setClients(clientList);
      setAdvances(advList);
      setHolidays(holList);
      setAuditLogs(logsList);

      // Save durable backups to localStorage
      try {
        if (finalEmpList && finalEmpList.length > 0) {
          localStorage.setItem('erp_employees_backup', JSON.stringify(finalEmpList));
        }
        if (clientList && clientList.length > 0) {
          localStorage.setItem('erp_clients_backup', JSON.stringify(clientList));
        }
        if (advList) {
          localStorage.setItem('erp_advances_backup', JSON.stringify(advList));
        }
      } catch (e) {}

      // Keep current user updated with latest backend state
      const savedUserJson = localStorage.getItem('erp_current_user');
      let activeUser = currentUser;
      if (savedUserJson) {
        try {
          const parsed = JSON.parse(savedUserJson);
          if (parsed && parsed.id) activeUser = parsed;
        } catch (e) {}
      }

      const foundCurrent = finalEmpList.find(
        (e: Employee) => (activeUser.id && e.id === activeUser.id) ||
               (e.contact?.email && activeUser.contact?.email && e.contact.email.toLowerCase() === activeUser.contact.email.toLowerCase()) ||
               (e.empCode && activeUser.empCode && e.empCode.toLowerCase() === activeUser.empCode.toLowerCase())
      );

      if (foundCurrent) {
        setCurrentUser(foundCurrent);
        localStorage.setItem('erp_current_user', JSON.stringify(foundCurrent));
        localStorage.setItem('erp_logged_in_emp_id', foundCurrent.id);
      } else if (activeUser && activeUser.id) {
        setCurrentUser(activeUser);
      }

      // Load Payroll
      const payroll = await fetchPayroll(selectedMonthStr).catch(() => null);
      setPayrollMonth(payroll);
    } catch (err) {
      console.error('Error loading application data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();

    // Auto-refresh data when the user re-opens or focuses on the app
    const handleFocus = () => {
      console.log('[App] Window focused/opened. Refreshing latest data...');
      loadData();
    };

    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible') {
        console.log('[App] App became visible. Refreshing latest data...');
        loadData();
      }
    };

    window.addEventListener('focus', handleFocus);
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      window.removeEventListener('focus', handleFocus);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [selectedMonthStr]);


  // Check if today's check-in prompt is needed for logged-in employee
  useEffect(() => {
    if (currentUser.role === 'EMPLOYEE') {
      const todayStr = getLocalDateStr();
      const record = attendanceRecords.find((r) => r.empId === currentUser.id && r.date === todayStr);
      if (!record) {
        // Prompt modal if attendance not marked yet for today
        setIsCheckInModalOpen(true);
      } else {
        setIsCheckInModalOpen(false);
      }
    } else {
      setIsCheckInModalOpen(false);
    }
  }, [currentUser, attendanceRecords]);

  // Handlers
  const handleMarkDailyAttendance = async (data: {
    status: AttendanceStatusCode;
    clientId: string;
    clientName: string;
    notes: string;
    location: string;
  }) => {
    const todayStr = getLocalDateStr();
    const currentMonth = todayStr.slice(0, 7);

    try {
      const record = await markAttendance({
        empId: currentUser.id,
        date: todayStr,
        status: data.status,
        clientId: data.clientId,
        clientName: data.clientName,
        notes: data.notes,
        location: data.location,
        modifiedBy: currentUser.name,
      });

      // Immediate local state update for instant UI response
      setAttendanceRecords((prev) => {
        const filtered = prev.filter((r) => !(r.empId === currentUser.id && r.date === todayStr));
        return [record, ...filtered];
      });

      setIsCheckInModalOpen(false);

      if (selectedMonthStr !== currentMonth) {
        setSelectedMonthStr(currentMonth);
      }

      await loadData();
    } catch (err) {
      console.error('Error marking attendance:', err);
    }
  };

  const handleAdminMarkAttendance = async (data: Partial<AttendanceRecord>) => {
    await markAttendance(data);
    loadData();
  };

  const handleBulkMarkAttendance = async (records: Partial<AttendanceRecord>[]) => {
    await bulkMarkAttendance(records, currentUser.name);
    loadData();
  };

  const handleAddEmployee = async (data: Partial<Employee>) => {
    await createEmployee(data);
    loadData();
  };

  const handleUpdateEmployee = async (id: string, data: Partial<Employee>) => {
    await updateEmployee(id, data);
    loadData();
  };

  const handleAddClient = async (data: Partial<Client>) => {
    await createClient(data);
    loadData();
  };

  const handleAddAdvance = async (data: Partial<AdvanceRecord>) => {
    await createAdvance(data);
    loadData();
  };

  const handleAddHoliday = async (data: Partial<Holiday>) => {
    await createHoliday(data);
    loadData();
  };

  const handleOverridePayrollRow = async (empId: string, overrides: Record<string, number | string>) => {
    const updated = await overridePayrollRow(selectedMonthStr, empId, overrides);
    setPayrollMonth(updated);
  };

  const handleFinalizePayroll = async (finalizedBy: string) => {
    const updated = await finalizePayroll(selectedMonthStr, finalizedBy);
    setPayrollMonth(updated);
  };

  const handleUnlockPayroll = async (unlockedBy: string, reason: string) => {
    const updated = await unlockPayroll(selectedMonthStr, unlockedBy, reason);
    setPayrollMonth(updated);
  };

  if (!isAuthenticated) {
    return <LoginModal employees={employees} onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-100 text-slate-800 font-sans selection:bg-indigo-500 selection:text-white">
      {/* Header */}
      <Header
        currentUser={currentUser}
        allEmployees={employees}
        onSelectUser={(u) => setCurrentUser(u)}
        selectedBranch={selectedBranch}
        onSelectBranch={(b) => setSelectedBranch(b)}
        activeTab={activeTab}
        setActiveTab={(t) => setActiveTab(t)}
        unreadRemindersCount={0}
        onLogout={handleLogout}
        onChangePassword={() => {
          setIsFirstTimePasswordModal(false);
          setIsChangePasswordModalOpen(true);
        }}
      />

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {loading && (
          <div className="py-12 text-center text-xs text-slate-500 font-medium">
            Syncing data with server...
          </div>
        )}

        {!loading && (
          <>
            {/* Dashboard View */}
            {activeTab === 'dashboard' && (
              <>
                {currentUser.role === 'EMPLOYEE' ? (
                  <EmployeeDashboard
                    currentUser={currentUser}
                    attendanceRecords={attendanceRecords}
                    advances={advances}
                    payrollMonth={payrollMonth}
                    onOpenCheckIn={() => setIsCheckInModalOpen(true)}
                    selectedMonthStr={selectedMonthStr}
                  />
                ) : (
                  <AdminDashboard
                    employees={employees}
                    attendanceRecords={attendanceRecords}
                    payrollMonth={payrollMonth}
                    advances={advances}
                    onNavigate={(tab) => setActiveTab(tab)}
                    selectedMonthStr={selectedMonthStr}
                  />
                )}
              </>
            )}

            {/* Attendance Matrix View */}
            {activeTab === 'attendance' && (
              <AttendanceManagementView
                employees={employees}
                attendanceRecords={attendanceRecords}
                clients={clients}
                selectedMonthStr={selectedMonthStr}
                onMarkAttendance={handleAdminMarkAttendance}
                onBulkMarkAttendance={handleBulkMarkAttendance}
                currentUser={currentUser}
              />
            )}

            {/* Payroll Engine View */}
            {activeTab === 'payroll' && (
              <PayrollEngineView
                payrollMonth={payrollMonth}
                selectedMonthStr={selectedMonthStr}
                onChangeMonth={(m) => setSelectedMonthStr(m)}
                onRefreshPayroll={loadData}
                onOverrideRow={handleOverridePayrollRow}
                onFinalizePayroll={handleFinalizePayroll}
                onUnlockPayroll={handleUnlockPayroll}
                currentUser={currentUser}
                allEmployees={employees}
              />
            )}

            {/* Employee Master View */}
            {activeTab === 'employees' && (
              <EmployeeMasterView
                employees={employees}
                onAddEmployee={handleAddEmployee}
                onUpdateEmployee={handleUpdateEmployee}
                currentUser={currentUser}
              />
            )}

            {/* Leaves & Advances View */}
            {activeTab === 'leaves-advances' && (
              <LeaveAdvanceView
                employees={employees}
                advances={advances}
                onAddAdvance={handleAddAdvance}
                currentUser={currentUser}
                selectedMonthStr={selectedMonthStr}
              />
            )}

            {/* Client Management View */}
            {activeTab === 'clients' && (
              <ClientManagementView
                clients={clients}
                attendanceRecords={attendanceRecords}
                employees={employees}
                onAddClient={handleAddClient}
                selectedMonthStr={selectedMonthStr}
              />
            )}

            {/* Reports & Payslips View */}
            {activeTab === 'reports' && (
              <ReportsView
                employees={employees}
                attendanceRecords={attendanceRecords}
                clients={clients}
                advances={advances}
                payrollMonth={payrollMonth}
                selectedMonthStr={selectedMonthStr}
                currentUser={currentUser}
              />
            )}

            {/* Holidays & Audit Logs View */}
            {activeTab === 'audit-holidays' && (
              <HolidayCalendarView
                holidays={holidays}
                auditLogs={auditLogs}
                onAddHoliday={handleAddHoliday}
              />
            )}
          </>
        )}
      </main>

      {/* Daily Check-In Modal Prompt */}
      <DailyCheckInModal
        isOpen={isCheckInModalOpen}
        onClose={() => setIsCheckInModalOpen(false)}
        currentUser={currentUser}
        clients={clients}
        onSubmit={handleMarkDailyAttendance}
      />

      {/* Change / Set Password Modal */}
      <ChangePasswordModal
        isOpen={isChangePasswordModalOpen}
        onClose={() => {
          if (!isFirstTimePasswordModal) {
            setIsChangePasswordModalOpen(false);
          }
        }}
        currentUser={currentUser}
        isFirstTime={isFirstTimePasswordModal}
        onSuccess={handlePasswordChanged}
      />
    </div>
  );
}
