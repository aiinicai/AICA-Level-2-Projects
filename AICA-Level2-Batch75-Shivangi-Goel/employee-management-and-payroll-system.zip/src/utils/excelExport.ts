import * as XLSX from 'xlsx';
import { PayrollMonth, PayrollRow } from '../types';

/**
 * Generates an Excel workbook byte-for-byte compatible with the firm's payroll sheet layout.
 */
export function generatePayrollExcel(payroll: PayrollMonth, year: number, monthZeroIndexed: number): Uint8Array {
  const daysInMonth = new Date(year, monthZeroIndexed + 1, 0).getDate();
  
  // Headers row 1: Month title
  const monthTitle = payroll.displayMonth || `${new Date(year, monthZeroIndexed).toLocaleString('en-US', { month: 'short' })}-${year.toString().slice(-2)}`;
  
  // Build header row 2:
  const headers = [
    'Month',
    'Employee Name',
    'Total salary',
    'Leave accrued',
    'Leaves taken',
    'Leaves balance',
    'Salary deducted',
    'Carry forward',
    'Salary',
    'Conveyance',
    'Advance',
    'Total salary',
    'Remaining advance',
  ];

  // Add day columns 1..N
  for (let d = 1; d <= daysInMonth; d++) {
    headers.push(d.toString());
  }

  const rowsData: (string | number)[][] = [];

  // First row: Sheet header / Title info
  rowsData.push([`Monthly Payroll Sheet: ${monthTitle}`]);
  rowsData.push(headers);

  // Rows for employees
  payroll.rows.forEach((r) => {
    const row: (string | number)[] = [
      monthTitle,
      r.empName,
      r.baseSalary,
      r.leaveAccrued,
      r.leavesTaken,
      r.leavesBalance,
      r.salaryDeducted,
      r.carryForwardLeave,
      r.salary,
      r.conveyance,
      r.advance,
      r.totalSalary,
      r.remainingAdvance,
    ];

    // Daily attendance matrix
    for (let d = 1; d <= daysInMonth; d++) {
      const code = r.dailyAttendance[d] || 'P';
      row.push(code);
    }

    rowsData.push(row);
  });

  // Totals Row
  const totalsRow: (string | number)[] = [
    'TOTAL',
    `Count: ${payroll.rows.length}`,
    payroll.rows.reduce((sum, r) => sum + r.baseSalary, 0),
    payroll.rows.reduce((sum, r) => sum + r.leaveAccrued, 0),
    payroll.rows.reduce((sum, r) => sum + r.leavesTaken, 0),
    payroll.rows.reduce((sum, r) => sum + r.leavesBalance, 0),
    payroll.rows.reduce((sum, r) => sum + r.salaryDeducted, 0),
    payroll.rows.reduce((sum, r) => sum + r.carryForwardLeave, 0),
    payroll.rows.reduce((sum, r) => sum + r.salary, 0),
    payroll.rows.reduce((sum, r) => sum + r.conveyance, 0),
    payroll.rows.reduce((sum, r) => sum + r.advance, 0),
    payroll.rows.reduce((sum, r) => sum + r.totalSalary, 0),
    payroll.rows.reduce((sum, r) => sum + r.remainingAdvance, 0),
  ];
  rowsData.push(totalsRow);

  const worksheet = XLSX.utils.aoa_to_sheet(rowsData);

  // Column width configuration
  const colWidths = [
    { wch: 10 }, // Month
    { wch: 22 }, // Employee Name
    { wch: 14 }, // Total salary
    { wch: 12 }, // Leave accrued
    { wch: 12 }, // Leaves taken
    { wch: 12 }, // Leaves balance
    { wch: 14 }, // Salary deducted
    { wch: 12 }, // Carry forward
    { wch: 14 }, // Salary
    { wch: 12 }, // Conveyance
    { wch: 12 }, // Advance
    { wch: 14 }, // Total salary
    { wch: 16 }, // Remaining advance
  ];
  for (let d = 1; d <= daysInMonth; d++) {
    colWidths.push({ wch: 4 });
  }
  worksheet['!cols'] = colWidths;

  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, monthTitle);

  // Write file
  const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
  return new Uint8Array(wbout);
}

/**
 * Triggers a browser download of the generated Excel workbook.
 */
export function downloadPayrollExcel(payroll: PayrollMonth, year: number, monthZeroIndexed: number) {
  const buffer = generatePayrollExcel(payroll, year, monthZeroIndexed);
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `Payroll_${payroll.displayMonth || payroll.month}.xlsx`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
