import { Employee, AttendanceRecord, AdvanceRecord, LeaveRecord, PayrollRow, PayrollMonth, AttendanceStatusCode, Holiday } from '../types';

export interface ComputePayrollOptions {
  monthStr: string; // "YYYY-MM", e.g. "2026-02"
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  advanceRecords: AdvanceRecord[];
  previousLeaves: LeaveRecord[];
  previousAdvances: Record<string, number>; // empId -> remainingAdvance
  holidays: Holiday[];
  existingPayroll?: PayrollMonth | null;
}

export function computeMonthlyPayroll(options: ComputePayrollOptions): PayrollMonth {
  const { monthStr, employees, attendanceRecords, advanceRecords, previousLeaves, previousAdvances, holidays, existingPayroll } = options;
  
  const [yearStr, mStr] = monthStr.split('-');
  const year = parseInt(yearStr, 10);
  const monthNum = parseInt(mStr, 10); // 1..12
  const monthZeroIndex = monthNum - 1;
  const daysInMonth = new Date(year, monthZeroIndex + 1, 0).getDate();

  // Month Display Name e.g. "Feb-26"
  const dateObj = new Date(year, monthZeroIndex, 1);
  const monthAbbr = dateObj.toLocaleString('en-US', { month: 'short' });
  const yearShort = year.toString().slice(-2);
  const displayMonth = `${monthAbbr}-${yearShort}`;

  const rows: PayrollRow[] = employees.map((emp) => {
    // Check for existing manual overrides if updating an existing payroll
    const existingRow = existingPayroll?.rows.find((r) => r.empId === emp.id);
    const overrides = existingRow?.manualOverrides;

    // Filter attendance for this employee & month
    const empAttendance = attendanceRecords.filter((a) => {
      if (a.empId !== emp.id) return false;
      return a.date.startsWith(monthStr);
    });

    // Build daily attendance matrix 1..daysInMonth
    const dailyAttendance: Record<number, AttendanceStatusCode> = {};
    let leavesTaken = 0;

    for (let day = 1; day <= daysInMonth; day++) {
      const dayStr = day < 10 ? `0${day}` : `${day}`;
      const fullDateStr = `${monthStr}-${dayStr}`;
      const rec = empAttendance.find((a) => a.date === fullDateStr);

      let statusCode: AttendanceStatusCode = 'P';

      if (rec) {
        statusCode = rec.status;
      } else {
        // Auto-check Sunday or Firm Holiday
        const dObj = new Date(year, monthZeroIndex, day);
        const isSunday = dObj.getDay() === 0;
        const isHoliday = holidays.some((h) => h.date === fullDateStr);

        if (isSunday || isHoliday) {
          statusCode = 'H';
        } else {
          statusCode = 'P'; // Default Present
        }
      }

      dailyAttendance[day] = statusCode;

      if (statusCode === 'A') {
        leavesTaken += 1;
      } else if (statusCode === 'HD') {
        leavesTaken += 0.5;
      }
    }

    // Leave Calculations
    const prevLeaveRec = previousLeaves.find((l) => l.empId === emp.id);
    const previousLeaveBal = prevLeaveRec ? prevLeaveRec.balance : 0;
    const leaveAccrued = emp.leaveAccrualRate; // e.g. 2, driver 0

    const leavesBalance = previousLeaveBal + leaveAccrued - leavesTaken;

    // Deduction logic
    let salaryDeducted = 0;
    let excessLeaveDays = 0;

    if (leavesBalance < 0) {
      excessLeaveDays = Math.abs(leavesBalance);
      const perDayRate = emp.baseSalary / daysInMonth;
      salaryDeducted = Math.round(excessLeaveDays * perDayRate);
    }

    if (overrides?.salaryDeducted !== undefined) {
      salaryDeducted = overrides.salaryDeducted;
    }

    const carryForwardLeave = leavesBalance > 0 ? leavesBalance : 0;

    // Base salary & salary after leave deduction
    const baseSalary = emp.baseSalary;
    const salary = baseSalary - salaryDeducted;

    // Conveyance
    const conveyance = overrides?.conveyance !== undefined ? overrides.conveyance : emp.conveyance;

    // Advance calculation for this month
    const empAdvances = advanceRecords.filter((a) => a.empId === emp.id && a.month === monthStr);
    const advanceGiven = empAdvances
      .filter((a) => a.type === 'given')
      .reduce((sum, a) => sum + a.amount, 0);
    const advanceRecovery = empAdvances
      .filter((a) => a.type === 'recovery')
      .reduce((sum, a) => sum + a.amount, 0);

    // In payroll column: Given is +, Recovery is -
    let monthNetAdvance = advanceGiven - advanceRecovery;
    if (overrides?.advance !== undefined) {
      monthNetAdvance = overrides.advance;
    }

    const totalSalary = salary + conveyance + monthNetAdvance;

    // Remaining Advance
    const prevAdvBal = previousAdvances[emp.id] || 0;
    const remainingAdvance = prevAdvBal + advanceGiven - advanceRecovery;

    return {
      empId: emp.id,
      empCode: emp.empCode,
      empName: emp.name,
      designation: emp.designation,
      branch: emp.branch,
      bankDetails: emp.bankDetails,
      baseSalary,
      leaveAccrued,
      leavesTaken,
      leavesBalance,
      salaryDeducted,
      carryForwardLeave,
      salary,
      conveyance,
      advance: monthNetAdvance,
      totalSalary,
      remainingAdvance,
      dailyAttendance,
      manualOverrides: overrides,
    };
  });

  return {
    month: monthStr,
    displayMonth,
    isFinalized: existingPayroll?.isFinalized || false,
    finalizedAt: existingPayroll?.finalizedAt,
    finalizedBy: existingPayroll?.finalizedBy,
    unlockedReason: existingPayroll?.unlockedReason,
    rows,
  };
}
