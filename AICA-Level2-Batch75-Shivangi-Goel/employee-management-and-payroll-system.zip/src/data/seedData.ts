import { Employee, Client, Holiday, AdvanceRecord, AuditLog } from '../types';

export const INITIAL_EMPLOYEES: Employee[] = [
  {
    id: 'emp-admin-1',
    empCode: 'ADM001',
    name: 'CA Shivangi Goel',
    designation: 'Managing Partner / Admin',
    department: 'Management',
    branch: 'Delhi HQ',
    dateOfJoining: '2023-01-01',
    status: 'active',
    baseSalary: 0,
    conveyance: 0,
    leaveAccrualRate: 0,
    bankDetails: { accountNo: '', ifsc: '', bankName: 'HDFC Bank' },
    contact: { email: 'cashivangigoel18@gmail.com', phone: '' },
    role: 'ADMIN',
    passwordChanged: false,
  },
];

export const INITIAL_CLIENTS: Client[] = [
  {
    id: 'cli-ho',
    name: 'Head Office',
    code: 'HO',
    location: 'D-48, LGF, East of Kailash, New Delhi- 110065',
    contactPerson: 'Admin',
    status: 'active',
  },
];

export const INITIAL_HOLIDAYS: Holiday[] = [
  { id: 'hol-1', date: '2026-01-26', name: 'Republic Day' },
  { id: 'hol-2', date: '2026-03-04', name: 'Holi' },
  { id: 'hol-3', date: '2026-04-14', name: 'Ambedkar Jayanti' },
  { id: 'hol-4', date: '2026-08-15', name: 'Independence Day' },
  { id: 'hol-5', date: '2026-10-02', name: 'Gandhi Jayanti' },
  { id: 'hol-6', date: '2026-11-08', name: 'Diwali' },
  { id: 'hol-7', date: '2026-12-25', name: 'Christmas' },
];

export const INITIAL_ADVANCES: AdvanceRecord[] = [];

export const INITIAL_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'log-init',
    timestamp: new Date().toISOString(),
    performedBy: 'System',
    action: 'System Initialization',
    entity: 'Manoj Prakash Associates ERP',
    details: 'System initialized for live deployment with Manoj Prakash Associates.',
  },
];
