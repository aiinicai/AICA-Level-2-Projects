import { registerServiceWorker } from './registerServiceWorker.ts';

registerServiceWorker();
export {};
