import React, { useState } from 'react';
import { Employee } from '../types';
import { ShieldCheck, User, Lock, Mail, AlertCircle, ArrowRight, UserCheck, KeyRound } from 'lucide-react';
import { loginUser } from '../services/api';

interface LoginModalProps {
  employees: Employee[];
  onLogin: (employee: Employee) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ employees, onLogin }) => {
  const [loginType, setLoginType] = useState<'ADMIN' | 'EMPLOYEE'>('ADMIN');
  const [email, setEmail] = useState('');
  const [adminName, setAdminName] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const handleTypeSwitch = (type: 'ADMIN' | 'EMPLOYEE') => {
    setLoginType(type);
    setError(null);
    setPassword('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const cleanEmail = email.trim().toLowerCase();
    if (!cleanEmail) {
      setError('Please enter your Login Email ID.');
      return;
    }

    if (!password) {
      setError('Please enter your password.');
      return;
    }

    try {
      setSubmitting(true);
      const authenticatedUser = await loginUser({
        email: cleanEmail,
        password: password.trim(),
        role: loginType,
        name: loginType === 'ADMIN' && adminName.trim() ? adminName.trim() : undefined,
      });

      onLogin(authenticatedUser);
    } catch (err: any) {
      console.error('Login error:', err);
      setError(err.message || 'Unable to log in. Please verify your credentials.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-md bg-white border border-slate-200 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Top Header Branding */}
        <div className="bg-slate-900 text-white p-6 relative overflow-hidden">
          <div className="absolute -right-6 -bottom-6 w-32 h-32 bg-indigo-600/20 rounded-full blur-2xl pointer-events-none" />
          <div className="flex items-center space-x-3 mb-2">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-600 to-blue-700 flex items-center justify-center font-extrabold text-white text-base tracking-wider shadow-md border border-indigo-400/30">
              MPA
            </div>
            <div>
              <h1 className="text-base font-extrabold tracking-tight text-white uppercase">Manoj Prakash Associates</h1>
              <p className="text-xs text-slate-400">Chartered Accountants • Staff Attendance & Payroll</p>
            </div>
          </div>
          <p className="text-xs text-slate-300 mt-2">
            Secure Authentication Portal • Role-Based Workspace Access
          </p>
        </div>

        {/* Login Type Tab Switcher */}
        <div className="p-2 bg-slate-100 border-b border-slate-200 grid grid-cols-2 gap-1 text-xs">
          <button
            type="button"
            onClick={() => handleTypeSwitch('ADMIN')}
            className={`py-2.5 px-3 rounded-lg font-bold flex items-center justify-center space-x-2 transition-all ${
              loginType === 'ADMIN'
                ? 'bg-white text-indigo-700 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-indigo-600" />
            <span>Admin Login</span>
          </button>

          <button
            type="button"
            onClick={() => handleTypeSwitch('EMPLOYEE')}
            className={`py-2.5 px-3 rounded-lg font-bold flex items-center justify-center space-x-2 transition-all ${
              loginType === 'EMPLOYEE'
                ? 'bg-white text-emerald-700 shadow-sm border border-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <User className="w-4 h-4 text-emerald-600" />
            <span>Employee Login</span>
          </button>
        </div>

        {/* Form Area */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-start space-x-2 animate-in fade-in duration-150">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {/* Email ID / Employee Code Field */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-700">
                {loginType === 'ADMIN' ? 'Admin Email ID or Admin Code' : 'Employee Email ID or Employee Code (e.g. EMP002)'}
              </label>
              {loginType === 'EMPLOYEE' && (
                <span className="text-[10px] text-slate-500 italic">
                  (Assigned by Admin)
                </span>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Mail className="w-4 h-4" />
              </div>
              <input
                type="text"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={loginType === 'ADMIN' ? 'e.g. cashivangigoel18@gmail.com or ADM001' : 'e.g. EMP002 or employee@mpa.com'}
                className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          {/* Admin Name Field (Optional for first-time profile creation) */}
          {loginType === 'ADMIN' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Admin Full Name <span className="text-slate-400 font-normal">(Display Name)</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <UserCheck className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  placeholder="e.g. CA Shivangi Goel"
                  className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
                />
              </div>
            </div>
          )}

          {/* Password Field */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-700">
                Password
              </label>
              {loginType === 'EMPLOYEE' && (
                <span className="text-[10px] text-indigo-600 font-medium">
                  Default: welcome@123
                </span>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Enter your password"
                className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-300 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
              />
            </div>
          </div>

          {/* Access summary */}
          <div className="text-[11px] text-slate-500 pt-1">
            {loginType === 'ADMIN' ? (
              <p className="text-slate-600">
                • Full administrative control over Employee Master, Attendance, Leaves, Advances, Payroll & Reports.
              </p>
            ) : (
              <p className="text-slate-600">
                • Staff self-service for Daily Attendance check-in, Advances/Leaves balance, and Payslips.
              </p>
            )}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-md hover:shadow-lg transition-all flex items-center justify-center space-x-2"
          >
            <span>{submitting ? 'Authenticating...' : `Sign In as ${loginType === 'ADMIN' ? 'Admin' : 'Employee'}`}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
