import React from 'react';
import { Clock, MapPin, CheckCircle, AlertTriangle } from 'lucide-react';

interface AttendanceBannerProps {
  isMarkedToday: boolean;
  todayStatus?: string;
  clientName?: string;
  onOpenCheckIn: () => void;
}

export const AttendanceBanner: React.FC<AttendanceBannerProps> = ({
  isMarkedToday,
  todayStatus,
  clientName,
  onOpenCheckIn,
}) => {
  const formattedToday = new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  if (isMarkedToday) {
    return (
      <div className="bg-emerald-900/90 border border-emerald-700/80 rounded-2xl p-4 text-emerald-100 shadow-sm mb-6 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-800/80 flex items-center justify-center shrink-0">
            <CheckCircle className="w-5 h-5 text-emerald-300" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-sm text-white">Attendance Marked for Today ({formattedToday})</span>
              <span className="px-2 py-0.5 rounded-md bg-emerald-800 text-emerald-200 text-xs font-bold border border-emerald-700">
                Status: {todayStatus || 'Present'}
              </span>
            </div>
            <p className="text-xs text-emerald-200/90 mt-0.5 flex items-center space-x-1">
              <MapPin className="w-3.5 h-3.5 text-emerald-300" />
              <span>Checked in at client site: <strong className="text-white">{clientName || 'Office/HQ'}</strong></span>
            </p>
          </div>
        </div>

        <button
          onClick={onOpenCheckIn}
          className="px-3.5 py-1.5 bg-emerald-800 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold border border-emerald-600 transition-colors"
        >
          Update Check-In
        </button>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-amber-500 via-orange-500 to-rose-500 rounded-2xl p-4 text-white shadow-md mb-6 flex flex-wrap items-center justify-between gap-3 animate-pulse">
      <div className="flex items-center space-x-3">
        <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
          <AlertTriangle className="w-5 h-5 text-amber-100" />
        </div>
        <div>
          <h3 className="font-bold text-sm text-white">Daily Attendance Action Required ({formattedToday})</h3>
          <p className="text-xs text-amber-100 mt-0.5">
            You haven't declared your site location for today yet. Please mark attendance & select your client site.
          </p>
        </div>
      </div>

      <button
        onClick={onOpenCheckIn}
        className="px-4 py-2 bg-white text-slate-900 hover:bg-slate-100 rounded-xl text-xs font-bold shadow transition-transform hover:scale-105 flex items-center space-x-1.5"
      >
        <Clock className="w-4 h-4 text-amber-600" />
        <span>Mark Attendance Now</span>
      </button>
    </div>
  );
};
