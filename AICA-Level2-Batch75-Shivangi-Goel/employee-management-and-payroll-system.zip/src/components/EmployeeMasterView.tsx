import React, { useState } from 'react';
import { Employee, Role, EmploymentStatus } from '../types';
import { Users, UserPlus, Edit, Search, Building2, CreditCard, Mail, Phone, ShieldCheck } from 'lucide-react';

interface EmployeeMasterViewProps {
  employees: Employee[];
  onAddEmployee: (data: Partial<Employee>) => void;
  onUpdateEmployee: (id: string, data: Partial<Employee>) => void;
  currentUser: Employee;
}

export const EmployeeMasterView: React.FC<EmployeeMasterViewProps> = ({
  employees,
  onAddEmployee,
  onUpdateEmployee,
  currentUser,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedBranch, setSelectedBranch] = useState('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingEmp, setEditingEmp] = useState<Employee | null>(null);

  // Form State
  const [name, setName] = useState('');
  const [designation, setDesignation] = useState('');
  const [department, setDepartment] = useState('Audit & Assurance');
  const [branch, setBranch] = useState('Delhi HQ');
  const [dateOfJoining, setDateOfJoining] = useState('2024-01-01');
  const [status, setStatus] = useState<EmploymentStatus>('active');
  const [baseSalary, setBaseSalary] = useState<number>(35000);
  const [conveyance, setConveyance] = useState<number>(2000);
  const [leaveAccrualRate, setLeaveAccrualRate] = useState<number>(2);
  const [accountNo, setAccountNo] = useState('');
  const [ifsc, setIfsc] = useState('');
  const [bankName, setBankName] = useState('HDFC Bank');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('welcome@123');
  const [role, setRole] = useState<Role>('EMPLOYEE');

  const openAddModal = () => {
    setEditingEmp(null);
    setName('');
    setDesignation('Associate / Consultant');
    setDepartment('Audit & Assurance');
    setBranch('Delhi HQ');
    setDateOfJoining(new Date().toISOString().split('T')[0]);
    setStatus('active');
    setBaseSalary(35000);
    setConveyance(2000);
    setLeaveAccrualRate(2);
    setAccountNo('');
    setIfsc('');
    setBankName('HDFC Bank');
    setEmail('');
    setPhone('');
    setPassword('welcome@123');
    setRole('EMPLOYEE');
    setIsModalOpen(true);
  };

  const openEditModal = (emp: Employee) => {
    setEditingEmp(emp);
    setName(emp.name);
    setDesignation(emp.designation);
    setDepartment(emp.department);
    setBranch(emp.branch);
    setDateOfJoining(emp.dateOfJoining);
    setStatus(emp.status);
    setBaseSalary(emp.baseSalary);
    setConveyance(emp.conveyance);
    setLeaveAccrualRate(emp.leaveAccrualRate);
    setAccountNo(emp.bankDetails?.accountNo || '');
    setIfsc(emp.bankDetails?.ifsc || '');
    setBankName(emp.bankDetails?.bankName || 'HDFC Bank');
    setEmail(emp.contact?.email || '');
    setPhone(emp.contact?.phone || '');
    setPassword(emp.password || 'welcome@123');
    setRole(emp.role);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const payload: Partial<Employee> = {
      name,
      designation,
      department,
      branch,
      dateOfJoining,
      status,
      baseSalary: Number(baseSalary),
      conveyance: Number(conveyance),
      leaveAccrualRate: Number(leaveAccrualRate),
      bankDetails: { accountNo, ifsc, bankName },
      contact: { email, phone },
      password: password.trim() || 'welcome@123',
      role,
    };

    if (editingEmp) {
      onUpdateEmployee(editingEmp.id, payload);
    } else {
      onAddEmployee(payload);
    }
    setIsModalOpen(false);
  };

  const filtered = employees.filter((emp) => {
    if (!emp) return false;
    const empName = (emp.name || '').toLowerCase();
    const empCode = (emp.empCode || '').toLowerCase();
    const empDesig = (emp.designation || '').toLowerCase();
    const search = searchTerm.toLowerCase();

    const matchesSearch =
      empName.includes(search) ||
      empCode.includes(search) ||
      empDesig.includes(search);
    const matchesBranch = selectedBranch === 'All' || emp.branch === selectedBranch;
    return matchesSearch && matchesBranch;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
            <Users className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Employee Master Directory</h2>
            <p className="text-xs text-slate-400">
              Manage base salary, conveyance allowances, leave accrual rates, and bank details
            </p>
          </div>
        </div>

        <button
          onClick={openAddModal}
          className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs shadow transition-all flex items-center space-x-2"
        >
          <UserPlus className="w-4 h-4" />
          <span>Add New Employee</span>
        </button>
      </div>

      {/* Filter Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3.5 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search name, code, designation..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="text-slate-500 font-medium">Branch:</span>
          <select
            value={selectedBranch}
            onChange={(e) => setSelectedBranch(e.target.value)}
            className="p-1.5 bg-slate-50 border border-slate-300 rounded-lg text-xs focus:outline-none"
          >
            <option value="All">All Branches</option>
            <option value="Delhi HQ">Delhi HQ</option>
            <option value="Mumbai Branch">Mumbai Branch</option>
            <option value="Bangalore Branch">Bangalore Branch</option>
          </select>
        </div>
      </div>

      {/* Employee Grid / Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-slate-200 font-semibold border-b border-slate-800">
                <th className="p-3">Employee</th>
                <th className="p-3">Designation & Dept</th>
                <th className="p-3">Branch</th>
                <th className="p-3 text-right">Base Salary</th>
                <th className="p-3 text-right">Conveyance</th>
                <th className="p-3 text-center">Leave Accrual</th>
                <th className="p-3">Bank Details</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filtered.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-semibold text-slate-900">
                    <div className="flex items-center space-x-2.5">
                      <div className="w-8 h-8 rounded-full bg-indigo-100 text-indigo-800 font-bold flex items-center justify-center shrink-0">
                        {(emp.name || 'U').charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <div className="font-bold text-slate-900">{emp.name || 'Unnamed'}</div>
                        <div className="text-[10px] text-slate-400">{emp.empCode || 'EMP'}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-slate-700">
                    <div className="font-semibold">{emp.designation || 'Staff'}</div>
                    <div className="text-[10px] text-slate-400">{emp.department || 'General'}</div>
                  </td>
                  <td className="p-3 text-slate-700">
                    <span className="px-2 py-0.5 rounded bg-slate-100 border border-slate-200 text-[11px]">
                      {emp.branch || 'Delhi HQ'}
                    </span>
                  </td>
                  <td className="p-3 text-right font-bold text-slate-900">
                    ₹{(emp.baseSalary || 0).toLocaleString('en-IN')}
                  </td>
                  <td className="p-3 text-right font-semibold text-slate-700">
                    ₹{(emp.conveyance || 0).toLocaleString('en-IN')}
                  </td>
                  <td className="p-3 text-center">
                    <span className="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 font-bold border border-indigo-200">
                      {emp.leaveAccrualRate ?? 2} days/mo
                    </span>
                  </td>
                  <td className="p-3 text-slate-600 text-[11px]">
                    <div>{emp.bankDetails?.bankName || 'HDFC Bank'}</div>
                    <div className="font-mono text-slate-400">{emp.bankDetails?.accountNo || 'Not Provided'}</div>
                  </td>
                  <td className="p-3 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        emp.status === 'active'
                          ? 'bg-emerald-100 text-emerald-800'
                          : emp.status === 'trainee'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      {(emp.status || 'active').toUpperCase()}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => openEditModal(emp)}
                      className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                      title="Edit Master Data"
                    >
                      <Edit className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add/Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 overflow-y-auto">
          <form
            onSubmit={handleSubmit}
            className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full p-6 space-y-4 border border-slate-200 text-slate-800 my-8"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-slate-900 text-base">
                {editingEmp ? `Edit Master Record: ${editingEmp.name}` : 'Add New Employee'}
              </h3>
              <button type="button" onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Full Name</label>
                <input
                  required
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Designation</label>
                <input
                  required
                  type="text"
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Branch Office</label>
                <select
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                >
                  <option value="Delhi HQ">Delhi HQ</option>
                  <option value="Mumbai Branch">Mumbai Branch</option>
                  <option value="Bangalore Branch">Bangalore Branch</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Department</label>
                <input
                  type="text"
                  value={department}
                  onChange={(e) => setDepartment(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Base Monthly Salary (₹)</label>
                <input
                  required
                  type="number"
                  value={baseSalary}
                  onChange={(e) => setBaseSalary(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Fixed Monthly Conveyance (₹)</label>
                <input
                  type="number"
                  value={conveyance}
                  onChange={(e) => setConveyance(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Leave Accrual Rate (Days/Month)
                </label>
                <input
                  required
                  type="number"
                  step="0.5"
                  value={leaveAccrualRate}
                  onChange={(e) => setLeaveAccrualRate(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-bold"
                />
                <span className="text-[10px] text-slate-400">Default 2; set 0 for Driver</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Login Email ID <span className="text-indigo-600 font-normal">(Used for Employee Login)</span>
                </label>
                <input
                  required
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. employee@firm.com"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-medium"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Contact Phone</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. 9876543210"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Employment Status</label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as EmploymentStatus)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                >
                  <option value="active">Active</option>
                  <option value="trainee">Trainee</option>
                  <option value="inactive">Inactive</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Account Number</label>
                <input
                  type="text"
                  value={accountNo}
                  onChange={(e) => setAccountNo(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">IFSC Code</label>
                <input
                  type="text"
                  value={ifsc}
                  onChange={(e) => setIfsc(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono uppercase"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">System Role</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as Role)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                >
                  <option value="EMPLOYEE">Employee</option>
                  <option value="ADMIN">Admin / HR</option>
                  <option value="OWNER">Owner / Partner</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Login Password <span className="text-indigo-600 font-normal">(Default: welcome@123)</span>
                </label>
                <input
                  type="text"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="welcome@123"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-mono text-slate-800"
                />
              </div>
            </div>

            <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl text-[11px] text-indigo-900 flex items-start space-x-2">
              <span className="font-bold">ℹ️ Note:</span>
              <span>
                Staff members can log in using either their <strong>Registered Email</strong> or their system-generated <strong>Employee Code</strong> (e.g. EMP002). They will be prompted to change their password upon their first login.
              </span>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-4 border-t">
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-indigo-600 text-white rounded-lg text-xs font-bold hover:bg-indigo-700 shadow"
              >
                Save Record
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
