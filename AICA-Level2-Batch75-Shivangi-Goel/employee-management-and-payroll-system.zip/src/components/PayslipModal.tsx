import React from 'react';
import { PayrollRow, Employee } from '../types';
import { Printer, Download, Building, X, FileText, CheckCircle2 } from 'lucide-react';

interface PayslipModalProps {
  isOpen: boolean;
  onClose: () => void;
  payrollRow: PayrollRow;
  monthDisplay: string;
  employee: Employee;
}

export const PayslipModal: React.FC<PayslipModalProps> = ({
  isOpen,
  onClose,
  payrollRow,
  monthDisplay,
  employee,
}) => {
  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 overflow-y-auto print:p-0 print:bg-white print:static">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full border border-slate-200 overflow-hidden text-slate-800 my-6 print:shadow-none print:border-none">
        {/* Header Bar */}
        <div className="bg-slate-900 text-white p-4 flex items-center justify-between print:hidden">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-indigo-400" />
            <span className="font-bold text-sm">Monthly Salary Statement / Payslip</span>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center space-x-1.5 shadow"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button onClick={onClose} className="p-1 hover:bg-slate-800 rounded-lg text-slate-400">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Payslip Body */}
        <div className="p-8 space-y-6 text-xs" id="payslip-content">
          {/* Company Branding */}
          <div className="border-b-2 border-slate-800 pb-4 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-12 h-12 rounded-xl bg-slate-900 text-white font-bold flex items-center justify-center text-lg tracking-wider">
                MPA
              </div>
              <div>
                <h1 className="font-extrabold text-slate-900 text-base tracking-wide uppercase">
                  Manoj Prakash Associates
                </h1>
                <p className="text-[11px] text-slate-500 font-medium">
                  D-48, LGF, East of Kailash, New Delhi- 110065
                </p>
                <p className="text-[10px] text-slate-400">Branch Office: {employee.branch || 'Delhi HQ'}</p>
              </div>
            </div>

            <div className="text-right">
              <div className="text-sm font-extrabold text-slate-900 uppercase">Payslip</div>
              <div className="text-xs font-bold text-indigo-600">{monthDisplay}</div>
              <div className="text-[10px] text-slate-400 mt-1">Generated: {new Date().toLocaleDateString()}</div>
            </div>
          </div>

          {/* Employee & Bank Details Grid */}
          <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
            <div className="space-y-1">
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Employee Name:</span>{' '}
                <strong className="text-slate-900 text-xs">{payrollRow.empName}</strong>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Employee Code:</span>{' '}
                <span className="font-semibold text-slate-800">{payrollRow.empCode}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Designation:</span>{' '}
                <span className="text-slate-800">{payrollRow.designation}</span>
              </div>
            </div>

            <div className="space-y-1 text-right sm:text-left">
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Bank Name:</span>{' '}
                <span className="font-semibold text-slate-800">{payrollRow.bankDetails?.bankName}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">Account No:</span>{' '}
                <span className="font-mono text-slate-800">{payrollRow.bankDetails?.accountNo}</span>
              </div>
              <div>
                <span className="text-slate-400 text-[10px] uppercase font-bold">IFSC Code:</span>{' '}
                <span className="font-mono uppercase text-slate-800">{payrollRow.bankDetails?.ifsc}</span>
              </div>
            </div>
          </div>

          {/* Attendance Summary Bar */}
          <div className="grid grid-cols-4 gap-2 text-center bg-indigo-50/60 p-3 rounded-xl border border-indigo-100">
            <div>
              <div className="text-[10px] text-indigo-800 uppercase font-bold">Leave Accrued</div>
              <div className="font-extrabold text-indigo-900 text-sm">{payrollRow.leaveAccrued} Days</div>
            </div>

            <div>
              <div className="text-[10px] text-indigo-800 uppercase font-bold">Leaves Taken</div>
              <div className="font-extrabold text-rose-600 text-sm">{payrollRow.leavesTaken} Days</div>
            </div>

            <div>
              <div className="text-[10px] text-indigo-800 uppercase font-bold">Leave Balance</div>
              <div className="font-extrabold text-slate-900 text-sm">{payrollRow.leavesBalance} Days</div>
            </div>

            <div>
              <div className="text-[10px] text-indigo-800 uppercase font-bold">Remaining Advance</div>
              <div className="font-extrabold text-slate-900 text-sm">
                ₹{payrollRow.remainingAdvance.toLocaleString('en-IN')}
              </div>
            </div>
          </div>

          {/* Salary Breakup Table */}
          <div className="border border-slate-200 rounded-xl overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-900 text-white font-bold">
                  <th className="p-2.5">Earnings Description</th>
                  <th className="p-2.5 text-right">Amount (₹)</th>
                  <th className="p-2.5">Deductions Description</th>
                  <th className="p-2.5 text-right">Amount (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                <tr>
                  <td className="p-2.5 font-medium text-slate-800">Basic Monthly Salary</td>
                  <td className="p-2.5 text-right font-semibold">₹{payrollRow.baseSalary.toLocaleString('en-IN')}</td>
                  <td className="p-2.5 font-medium text-slate-800">Leave Loss-Of-Pay Deduction</td>
                  <td className="p-2.5 text-right font-semibold text-rose-600">
                    ₹{payrollRow.salaryDeducted.toLocaleString('en-IN')}
                  </td>
                </tr>

                <tr>
                  <td className="p-2.5 font-medium text-slate-800">Fixed Conveyance Allowance</td>
                  <td className="p-2.5 text-right font-semibold">₹{payrollRow.conveyance.toLocaleString('en-IN')}</td>
                  <td className="p-2.5 font-medium text-slate-800">Advance Recovery / Adjustment</td>
                  <td className="p-2.5 text-right font-semibold text-amber-600">
                    {payrollRow.advance < 0
                      ? `₹${Math.abs(payrollRow.advance).toLocaleString('en-IN')}`
                      : '₹0'}
                  </td>
                </tr>

                {payrollRow.advance > 0 && (
                  <tr>
                    <td className="p-2.5 font-medium text-slate-800">Salary Advance Granted (+)</td>
                    <td className="p-2.5 text-right font-semibold text-blue-600">
                      ₹{payrollRow.advance.toLocaleString('en-IN')}
                    </td>
                    <td className="p-2.5"></td>
                    <td className="p-2.5"></td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="bg-emerald-50 text-emerald-950 font-extrabold border-t-2 border-slate-800">
                  <td className="p-3 text-sm" colSpan={2}>
                    NET PAYABLE AMOUNT:
                  </td>
                  <td className="p-3 text-right text-base font-extrabold text-emerald-700" colSpan={2}>
                    ₹{payrollRow.totalSalary.toLocaleString('en-IN')}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Footer Signatures */}
          <div className="pt-8 flex items-end justify-between text-slate-400 text-[10px]">
            <div>
              <p>This is a computer-generated payslip and does not require a physical signature.</p>
              <p className="font-semibold text-slate-600 mt-0.5">Manoj Prakash Associates • Payroll & HR Management System</p>
            </div>

            <div className="text-right border-t border-slate-300 pt-2 min-w-[140px]">
              <span className="font-bold text-slate-700">Authorized Signatory</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
