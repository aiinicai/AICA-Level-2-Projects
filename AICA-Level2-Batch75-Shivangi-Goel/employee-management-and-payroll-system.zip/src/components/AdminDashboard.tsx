import React from 'react';
import { Employee, AttendanceRecord, PayrollMonth, AdvanceRecord } from '../types';
import {
  Users,
  CalendarCheck,
  FileSpreadsheet,
  AlertTriangle,
  Receipt,
  Building2,
  TrendingUp,
  UserCheck,
  CheckCircle2,
  ArrowRight,
} from 'lucide-react';

interface AdminDashboardProps {
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  payrollMonth: PayrollMonth | null;
  advances: AdvanceRecord[];
  onNavigate: (tab: string) => void;
  selectedMonthStr: string;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  employees,
  attendanceRecords,
  payrollMonth,
  advances,
  onNavigate,
  selectedMonthStr,
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const todayRecords = attendanceRecords.filter((r) => r.date === todayStr);

  const presentToday = todayRecords.filter((r) => r.status === 'P' || r.status === 'HD').length;
  const absentToday = todayRecords.filter((r) => r.status === 'A').length;
  const pendingCheckIn = Math.max(0, employees.length - todayRecords.length);

  // Leave Deficit Employees (negative balance)
  const leaveDeficitStaff = (payrollMonth?.rows || []).filter((r) => r.leavesBalance < 0);

  // Total unrecovered advances
  const totalAdvancesActive = employees.reduce((sum, emp) => {
    const empAdvs = advances.filter((a) => a.empId === emp.id);
    const given = empAdvs.filter((a) => a.type === 'given').reduce((s, a) => s + a.amount, 0);
    const recovered = empAdvs.filter((a) => a.type === 'recovery').reduce((s, a) => s + a.amount, 0);
    return sum + (given - recovered);
  }, 0);

  return (
    <div className="space-y-6">
      {/* Top Welcome Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-xl font-bold tracking-tight">Executive Management Console</h2>
            <span className="px-2.5 py-0.5 rounded-full bg-amber-950 text-amber-300 border border-amber-800 text-xs font-semibold">
              Delhi HQ & Branches
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Real-time daily site attendance, leave loss-of-pay monitoring, and Excel payroll run
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => onNavigate('payroll')}
            className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold rounded-xl text-xs shadow-lg transition-all flex items-center space-x-2"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Open Payroll Engine</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Employees */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Staff Count</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-100 text-indigo-700 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-slate-900">{employees.length} Active Staff</div>
          <div className="text-xs text-slate-400">Delhi HQ, Mumbai & Bangalore</div>
        </div>

        {/* Attendance Today */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Today's Attendance</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
              <UserCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-emerald-600">{presentToday} Deployed</div>
          <div className="text-xs text-slate-500 flex items-center space-x-2">
            <span className="text-rose-600 font-semibold">{absentToday} Absent</span>
            <span>•</span>
            <span className="text-amber-600 font-semibold">{pendingCheckIn} Pending</span>
          </div>
        </div>

        {/* Leave Deficit Alerts */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Leave Deficits</span>
            <div className="w-8 h-8 rounded-lg bg-rose-100 text-rose-700 flex items-center justify-center">
              <AlertTriangle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-rose-600">{leaveDeficitStaff.length} Employees</div>
          <div className="text-xs text-slate-400">Negative balance -&gt; Loss-of-Pay deduction</div>
        </div>

        {/* Outstanding Advances */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Active Advances</span>
            <div className="w-8 h-8 rounded-lg bg-purple-100 text-purple-700 flex items-center justify-center">
              <Receipt className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-extrabold text-purple-600">
            ₹{totalAdvancesActive.toLocaleString('en-IN')}
          </div>
          <div className="text-xs text-slate-400">Outstanding salary advances</div>
        </div>
      </div>

      {/* Quick Action Navigation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <button
          onClick={() => onNavigate('payroll')}
          className="bg-white border border-slate-200 hover:border-emerald-500 rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group space-y-2"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm group-hover:text-emerald-600">Monthly Payroll Run</h3>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-xs text-slate-500">
            Review monthly attendance grid, apply overrides, and export byte-for-byte formatted Excel sheet.
          </p>
        </button>

        <button
          onClick={() => onNavigate('attendance')}
          className="bg-white border border-slate-200 hover:border-indigo-500 rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group space-y-2"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
            <CalendarCheck className="w-5 h-5" />
          </div>
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm group-hover:text-indigo-600">Daily Site Attendance</h3>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-xs text-slate-500">
            Bulk-mark client deployments, review daily P/A/H logs, and audit site location check-ins.
          </p>
        </button>

        <button
          onClick={() => onNavigate('leaves-advances')}
          className="bg-white border border-slate-200 hover:border-purple-500 rounded-2xl p-5 text-left shadow-sm hover:shadow-md transition-all group space-y-2"
        >
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center font-bold">
            <Receipt className="w-5 h-5" />
          </div>
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-slate-900 text-sm group-hover:text-purple-600">Advances & Leave Ledger</h3>
            <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
          </div>
          <p className="text-xs text-slate-500">
            Record employee salary advances given/recovered and audit running leave carry-forwards.
          </p>
        </button>
      </div>

      {/* Leave Deficits Alert List */}
      {leaveDeficitStaff.length > 0 && (
        <div className="bg-rose-50 border border-rose-200 rounded-2xl p-5 space-y-3">
          <div className="flex items-center space-x-2 text-rose-900">
            <AlertTriangle className="w-5 h-5 text-rose-600" />
            <h3 className="font-bold text-sm">Leave Deficit Loss-Of-Pay Deductions ({selectedMonthStr})</h3>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {leaveDeficitStaff.map((r) => (
              <div key={r.empId} className="bg-white p-3.5 rounded-xl border border-rose-100 shadow-sm text-xs space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-slate-900">{r.empName}</span>
                  <span className="px-2 py-0.5 rounded bg-rose-100 text-rose-800 font-extrabold text-[10px]">
                    {r.leavesBalance} Days Deficit
                  </span>
                </div>
                <div className="text-slate-500 text-[11px]">
                  Salary Deducted: <strong className="text-rose-600">₹{r.salaryDeducted.toLocaleString('en-IN')}</strong>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
