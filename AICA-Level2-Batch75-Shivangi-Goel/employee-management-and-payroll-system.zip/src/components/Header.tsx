import React, { useState } from 'react';
import { Employee, Role } from '../types';
import {
  Users,
  CalendarCheck,
  FileSpreadsheet,
  Building2,
  Receipt,
  FileText,
  ShieldAlert,
  Bell,
  UserCheck,
  ChevronDown,
  Building,
  CheckCircle2,
  LogOut,
  KeyRound,
} from 'lucide-react';

interface HeaderProps {
  currentUser: Employee;
  allEmployees: Employee[];
  onSelectUser: (emp: Employee) => void;
  selectedBranch: string;
  onSelectBranch: (branch: string) => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unreadRemindersCount: number;
  onLogout: () => void;
  onChangePassword?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentUser,
  allEmployees,
  onSelectUser,
  selectedBranch,
  onSelectBranch,
  activeTab,
  setActiveTab,
  unreadRemindersCount,
  onLogout,
  onChangePassword,
}) => {
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const branches = ['All Branches', 'Delhi HQ', 'Mumbai Branch', 'Bangalore Branch'];

  const getRoleBadge = (role: Role) => {
    switch (role) {
      case 'OWNER':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/30';
      case 'ADMIN':
        return 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30';
      default:
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30';
    }
  };

  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: CalendarCheck, roles: ['EMPLOYEE', 'ADMIN', 'OWNER'] },
    { id: 'attendance', label: 'Daily Attendance', icon: UserCheck, roles: ['EMPLOYEE', 'ADMIN', 'OWNER'] },
    { id: 'payroll', label: 'Payroll Engine', icon: FileSpreadsheet, roles: ['ADMIN', 'OWNER'] },
    { id: 'employees', label: 'Employee Master', icon: Users, roles: ['ADMIN', 'OWNER'] },
    { id: 'leaves-advances', label: 'Leaves & Advances', icon: Receipt, roles: ['EMPLOYEE', 'ADMIN', 'OWNER'] },
    { id: 'clients', label: 'Client Sites', icon: Building2, roles: ['ADMIN', 'OWNER'] },
    { id: 'reports', label: 'Reports & Payslips', icon: FileText, roles: ['EMPLOYEE', 'ADMIN', 'OWNER'] },
    { id: 'audit-holidays', label: 'Holidays & Audit', icon: ShieldAlert, roles: ['ADMIN', 'OWNER'] },
  ];

  const visibleNav = navItems.filter((item) => item.roles.includes(currentUser.role));

  return (
    <header className="bg-slate-900 text-white shadow-md border-b border-slate-800 sticky top-0 z-40">
      {/* Top Navigation & Brand Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Company Title */}
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-blue-700 flex items-center justify-center font-extrabold text-white text-base tracking-wider shadow-sm border border-indigo-400/30">
            MPA
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h1 className="font-extrabold text-base text-white tracking-tight">Manoj Prakash Associates</h1>
              <span className="text-[10px] font-bold tracking-wider px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 uppercase">
                ERP
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Chartered Accountants • Attendance & Payroll Portal</p>
          </div>
        </div>

        {/* Right Action Controls: Branch Selector + User/Role Switcher */}
        <div className="flex items-center space-x-3">
          {/* Branch Filter */}
          <div className="flex items-center space-x-1.5 bg-slate-800/90 border border-slate-700/80 rounded-lg px-3 py-1.5 text-xs text-slate-200 shadow-inner">
            <Building2 className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
            <span className="text-slate-400 hidden sm:inline text-[11px] font-medium uppercase tracking-wider">Branch:</span>
            <select
              value={selectedBranch}
              onChange={(e) => onSelectBranch(e.target.value)}
              className="bg-transparent font-medium focus:outline-none cursor-pointer text-slate-200 text-xs"
            >
              {branches.map((b) => (
                <option key={b} value={b} className="bg-slate-900 text-slate-200">
                  {b}
                </option>
              ))}
            </select>
          </div>

          {/* User Profile Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowUserDropdown(!showUserDropdown)}
              className="flex items-center space-x-2.5 bg-slate-800 hover:bg-slate-700/80 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-medium text-slate-200 transition-all shadow-sm"
            >
              <div className="w-6 h-6 rounded-full bg-indigo-600 flex items-center justify-center text-white text-xs font-bold shrink-0">
                {(currentUser.name || 'U').charAt(0).toUpperCase()}
              </div>
              <div className="text-left hidden sm:block">
                <div className="font-semibold text-slate-100 leading-tight">{currentUser.name || 'User'}</div>
                <div className="text-[10px] text-slate-400">{currentUser.designation || 'Staff'}</div>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded border uppercase ${getRoleBadge(currentUser.role)}`}>
                {currentUser.role}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Dropdown Menu */}
            {showUserDropdown && (
              <div className="absolute right-0 mt-2 w-72 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl z-50 py-2 text-xs divide-y divide-slate-700/60">
                <div className="px-3.5 py-2.5 bg-slate-800/80">
                  <div className="font-bold text-white text-xs">{currentUser.name || 'User Profile'}</div>
                  <div className="text-[11px] text-indigo-300 font-mono truncate">{currentUser.contact?.email || 'N/A'}</div>
                  <div className="text-[10px] text-slate-400 mt-0.5">{currentUser.designation || 'Staff'} • {currentUser.branch || 'Delhi HQ'}</div>
                </div>

                <div className="p-1.5 space-y-1">
                  {onChangePassword && (
                    <button
                      onClick={() => {
                        setShowUserDropdown(false);
                        onChangePassword();
                      }}
                      className="w-full text-left px-3 py-2 text-slate-200 hover:bg-slate-700 rounded-lg flex items-center space-x-2 font-medium transition-colors"
                    >
                      <KeyRound className="w-4 h-4 text-indigo-400" />
                      <span>Change Password</span>
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setShowUserDropdown(false);
                      onLogout();
                    }}
                    className="w-full text-left px-3 py-2 text-rose-300 hover:bg-rose-500/10 rounded-lg flex items-center space-x-2 font-bold transition-colors"
                  >
                    <LogOut className="w-4 h-4 text-rose-400" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Logout Button directly in header */}
          <button
            onClick={onLogout}
            className="p-2 text-slate-400 hover:text-rose-300 hover:bg-slate-800 rounded-lg transition-colors border border-slate-700/60 hidden sm:flex items-center space-x-1 text-xs"
            title="Sign Out"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span className="hidden md:inline font-medium text-[11px]">Sign Out</span>
          </button>
        </div>
      </div>

      {/* Navigation Tabs Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 border-t border-slate-800">
        <nav className="flex space-x-1 overflow-x-auto py-2 scrollbar-none">
          {visibleNav.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center space-x-2 px-3.5 py-2 rounded-lg text-xs transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                    : 'text-slate-300 hover:text-white hover:bg-slate-800/80 font-medium'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};
