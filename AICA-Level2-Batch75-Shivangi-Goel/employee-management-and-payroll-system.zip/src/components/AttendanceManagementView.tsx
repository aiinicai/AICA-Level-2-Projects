import React, { useState } from 'react';
import { Employee, AttendanceRecord, Client, AttendanceStatusCode } from '../types';
import { UserCheck, Calendar, Filter, CheckSquare, RefreshCw, MapPin, Building2 } from 'lucide-react';

interface AttendanceManagementViewProps {
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  clients: Client[];
  selectedMonthStr: string;
  onMarkAttendance: (rec: Partial<AttendanceRecord>) => void;
  onBulkMarkAttendance: (recs: Partial<AttendanceRecord>[]) => void;
  currentUser: Employee;
}

export const AttendanceManagementView: React.FC<AttendanceManagementViewProps> = ({
  employees,
  attendanceRecords,
  clients,
  selectedMonthStr,
  onMarkAttendance,
  onBulkMarkAttendance,
  currentUser,
}) => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [filterBranch, setFilterBranch] = useState('All');
  const [selectedClientForBulk, setSelectedClientForBulk] = useState(clients[0]?.id || '');

  const [yearStr, mStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const monthZeroIdx = parseInt(mStr, 10) - 1;
  const daysInMonth = new Date(year, monthZeroIdx + 1, 0).getDate();

  const filteredEmployees = employees.filter((e) => {
    if (currentUser.role === 'EMPLOYEE') {
      return e.id === currentUser.id;
    }
    return filterBranch === 'All' || e.branch === filterBranch;
  });

  const handleBulkMarkPresent = () => {
    const client = clients.find((c) => c.id === selectedClientForBulk) || clients[0];
    const newRecords: Partial<AttendanceRecord>[] = filteredEmployees.map((emp) => ({
      empId: emp.id,
      date: selectedDate,
      status: 'P',
      clientId: client.id,
      clientName: client.name,
      notes: 'Bulk marked Present by Admin',
    }));
    onBulkMarkAttendance(newRecords);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
            <UserCheck className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Daily Attendance & Site Deployment Matrix</h2>
            <p className="text-xs text-slate-400">
              Review and correct daily attendance records across all client sites
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3">
          <div className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-1.5 text-xs text-slate-200 flex items-center space-x-2">
            <Calendar className="w-4 h-4 text-indigo-400" />
            <span className="text-slate-400">Date:</span>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="bg-transparent font-bold focus:outline-none cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Bulk Action Panel */}
      {currentUser.role !== 'EMPLOYEE' && (
        <div className="bg-indigo-50/80 border border-indigo-100 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center space-x-2 text-indigo-950 font-semibold">
            <CheckSquare className="w-4 h-4 text-indigo-600" />
            <span>Admin Quick Action for {selectedDate}:</span>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center space-x-1.5">
              <span className="text-slate-600 font-medium">Deploy to Site:</span>
              <select
                value={selectedClientForBulk}
                onChange={(e) => setSelectedClientForBulk(e.target.value)}
                className="bg-white border border-indigo-200 rounded-lg px-2.5 py-1.5 text-xs font-semibold focus:outline-none"
              >
                {clients.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleBulkMarkPresent}
              className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg shadow-sm transition-colors"
            >
              Bulk Mark All Present
            </button>
          </div>
        </div>
      )}

      {/* Monthly Attendance Grid Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
            Monthly Attendance Grid ({selectedMonthStr})
          </h3>

          <div className="flex items-center space-x-4 text-xs">
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block"></span>
              <span className="text-slate-600">P = Present</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded bg-amber-500 inline-block"></span>
              <span className="text-slate-600">HD = Half Day</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block"></span>
              <span className="text-slate-600">A = Absent</span>
            </div>
            <div className="flex items-center space-x-1">
              <span className="w-2.5 h-2.5 rounded bg-blue-500 inline-block"></span>
              <span className="text-slate-600">H = Holiday</span>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-slate-200 font-semibold border-b border-slate-800">
                <th className="p-3 sticky left-0 bg-slate-900 z-10 min-w-[150px]">Employee</th>
                <th className="p-3 min-w-[100px]">Branch</th>

                {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
                  const dayStr = day < 10 ? `0${day}` : `${day}`;
                  const fullDate = `${selectedMonthStr}-${dayStr}`;
                  const isToday = fullDate === new Date().toISOString().split('T')[0];
                  return (
                    <th
                      key={day}
                      className={`p-2 text-center min-w-[34px] text-[10px] border-r border-slate-800 ${
                        isToday ? 'bg-indigo-600 text-white font-extrabold' : ''
                      }`}
                    >
                      {day}
                    </th>
                  );
                })}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredEmployees.map((emp) => (
                <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-2.5 sticky left-0 bg-white z-10 font-bold text-slate-900 border-r border-slate-200">
                    {emp.name}
                    <div className="text-[10px] text-slate-400 font-normal">{emp.empCode}</div>
                  </td>
                  <td className="p-2.5 text-slate-600 font-medium">{emp.branch}</td>

                  {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
                    const dayStr = day < 10 ? `0${day}` : `${day}`;
                    const fullDateStr = `${selectedMonthStr}-${dayStr}`;
                    const rec = attendanceRecords.find((r) => r.empId === emp.id && r.date === fullDateStr);
                    const dObj = new Date(year, monthZeroIdx, day);
                    const isSunday = dObj.getDay() === 0;

                    let code: string = rec ? rec.status : isSunday ? 'H' : '-';

                    let badgeStyle = 'bg-slate-50 text-slate-400 border-slate-200 border-dashed';
                    if (code === 'P') badgeStyle = 'bg-emerald-100 text-emerald-800 border-emerald-300 font-bold';
                    if (code === 'A') badgeStyle = 'bg-rose-100 text-rose-800 border-rose-300 font-bold';
                    if (code === 'HD') badgeStyle = 'bg-amber-100 text-amber-800 border-amber-300 font-bold';
                    if (code === 'H') badgeStyle = 'bg-blue-100 text-blue-800 border-blue-300 font-bold';

                    return (
                      <td key={day} className="p-1 border-r border-slate-200 text-center">
                        <button
                          onClick={() => {
                            // Cycle - -> P -> HD -> A -> H
                            const nextMap: Record<string, AttendanceStatusCode> = {
                              '-': 'P',
                              P: 'HD',
                              HD: 'A',
                              A: 'H',
                              H: 'P',
                            };
                            const nextCode = nextMap[code] || 'P';
                            const client = clients[0] || { id: 'cli-ho', name: 'Head Office' };
                            onMarkAttendance({
                              empId: emp.id,
                              date: fullDateStr,
                              status: nextCode,
                              clientId: rec?.clientId || client.id,
                              clientName: rec?.clientName || client.name,
                              modifiedBy: currentUser.name,
                            });
                          }}
                          className={`w-6 h-6 leading-6 rounded border text-[10px] font-bold transition-transform hover:scale-110 ${badgeStyle}`}
                          title={`${emp.name} on ${fullDateStr}: ${code} (${rec?.clientName || 'Default'})`}
                        >
                          {code}
                        </button>
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
