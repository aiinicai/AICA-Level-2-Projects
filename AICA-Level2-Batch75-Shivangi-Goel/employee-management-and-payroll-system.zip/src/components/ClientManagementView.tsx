import React, { useState } from 'react';
import { Client, AttendanceRecord, Employee } from '../types';
import { Building2, Plus, MapPin, Users, Calendar, Search } from 'lucide-react';

interface ClientManagementViewProps {
  clients: Client[];
  attendanceRecords: AttendanceRecord[];
  employees: Employee[];
  onAddClient: (data: Partial<Client>) => void;
  selectedMonthStr: string;
}

export const ClientManagementView: React.FC<ClientManagementViewProps> = ({
  clients,
  attendanceRecords,
  employees,
  onAddClient,
  selectedMonthStr,
}) => {
  const [showModal, setShowModal] = useState(false);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [location, setLocation] = useState('');
  const [contactPerson, setContactPerson] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onAddClient({ name, code, location, contactPerson });
    setShowModal(false);
    setName('');
    setCode('');
    setLocation('');
    setContactPerson('');
  };

  // Compute Client Site Deployment Stats for the selected month
  const monthAttendance = attendanceRecords.filter((r) => r.date.startsWith(selectedMonthStr));

  const clientStats = clients.map((client) => {
    const siteRecords = monthAttendance.filter((r) => r.clientId === client.id && r.status !== 'A');
    const totalDaysSpent = siteRecords.length;
    const uniqueEmployees = new Set(siteRecords.map((r) => r.empId)).size;

    return { client, totalDaysSpent, uniqueEmployees };
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center text-blue-400 font-bold">
            <Building2 className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Client Sites & Deployment Directory</h2>
            <p className="text-xs text-slate-400">
              Manage client engagement locations and monitor monthly staff deployment days
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowModal(true)}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white font-bold rounded-xl text-xs shadow transition-all flex items-center space-x-2"
        >
          <Plus className="w-4 h-4" />
          <span>Add New Client Site</span>
        </button>
      </div>

      {/* Client List Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {clientStats.map(({ client, totalDaysSpent, uniqueEmployees }) => (
          <div
            key={client.id}
            className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm hover:shadow-md transition-shadow space-y-3"
          >
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">{client.name}</h3>
                <p className="text-xs text-slate-400 font-mono">{client.code}</p>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800">
                Active Site
              </span>
            </div>

            <div className="text-xs text-slate-600 space-y-1 pt-1 border-t border-slate-100">
              <div className="flex items-center space-x-2">
                <MapPin className="w-3.5 h-3.5 text-rose-500 shrink-0" />
                <span className="font-medium text-slate-700">{client.location}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                <span>Contact: {client.contactPerson || 'N/A'}</span>
              </div>
            </div>

            {/* Deployment metrics for selected month */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200/80 flex items-center justify-between text-xs mt-2">
              <div>
                <div className="text-[10px] uppercase font-bold text-slate-400">Staff Deployed</div>
                <div className="font-extrabold text-slate-900">{uniqueEmployees} Consultants</div>
              </div>

              <div className="text-right">
                <div className="text-[10px] uppercase font-bold text-slate-400">Site Person-Days</div>
                <div className="font-extrabold text-indigo-600">{totalDaysSpent} Days</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Client Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
          <form
            onSubmit={handleSubmit}
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200 text-slate-800"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-slate-900 text-base">Add New Client Site</h3>
              <button type="button" onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Client Name</label>
                <input
                  required
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Tata Consultancy Services"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Client Code</label>
                <input
                  type="text"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  placeholder="e.g. TCS-DEL"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg uppercase"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Location / Site Address</label>
                <input
                  required
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Cyber City, Gurugram"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Mr. Rajesh Kumar"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setShowModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-blue-600 text-white rounded-lg text-xs font-bold hover:bg-blue-700 shadow"
              >
                Save Client
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
