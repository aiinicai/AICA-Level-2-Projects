import React from 'react';
import { Employee, AttendanceRecord, AdvanceRecord, PayrollMonth } from '../types';
import { AttendanceBanner } from './AttendanceBanner';
import { CalendarCheck, MapPin, Receipt, FileText, CheckCircle2, Clock, AlertCircle } from 'lucide-react';

interface EmployeeDashboardProps {
  currentUser: Employee;
  attendanceRecords: AttendanceRecord[];
  advances: AdvanceRecord[];
  payrollMonth: PayrollMonth | null;
  onOpenCheckIn: () => void;
  selectedMonthStr: string;
}

export const EmployeeDashboard: React.FC<EmployeeDashboardProps> = ({
  currentUser,
  attendanceRecords,
  advances,
  payrollMonth,
  onOpenCheckIn,
  selectedMonthStr,
}) => {
  const d = new Date();
  const todayStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const todayRecord = attendanceRecords.find((r) => r.empId === currentUser.id && r.date === todayStr);

  const [yearStr, mStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const monthZeroIdx = parseInt(mStr, 10) - 1;
  const daysInMonth = new Date(year, monthZeroIdx + 1, 0).getDate();

  // Employee's row in payroll if computed
  const myPayrollRow = payrollMonth?.rows.find((r) => r.empId === currentUser.id);

  // Filter attendance for this employee & month
  const myMonthRecords = attendanceRecords.filter((r) => r.empId === currentUser.id && r.date.startsWith(selectedMonthStr));

  // Compute stats
  const totalPresent = myMonthRecords.filter((r) => r.status === 'P').length;
  const totalHalfDays = myMonthRecords.filter((r) => r.status === 'HD').length;
  const totalAbsent = myMonthRecords.filter((r) => r.status === 'A').length;
  const totalHolidays = myMonthRecords.filter((r) => r.status === 'H').length;

  return (
    <div className="space-y-6">
      {/* Attendance Prompt Banner */}
      <AttendanceBanner
        isMarkedToday={!!todayRecord}
        todayStatus={
          todayRecord?.status === 'P'
            ? 'Present'
            : todayRecord?.status === 'HD'
            ? 'Half-Day'
            : todayRecord?.status === 'A'
            ? 'Absent'
            : todayRecord?.status === 'H'
            ? 'Holiday'
            : undefined
        }
        clientName={todayRecord?.clientName}
        onOpenCheckIn={onOpenCheckIn}
      />

      {/* Top Welcome Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-600 to-blue-700 flex items-center justify-center font-bold text-xl text-white shadow-inner">
            {currentUser.name ? currentUser.name.charAt(0) : 'U'}
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold tracking-tight">Welcome, {currentUser.name}</h2>
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-950 text-indigo-300 border border-indigo-800 text-xs font-semibold">
                {currentUser.empCode}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1">
              {currentUser.designation || 'Staff'} • {currentUser.department || 'Operations'} ({currentUser.branch || 'Delhi HQ'})
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-xs bg-slate-800/80 p-3 rounded-xl border border-slate-700">
          <div>
            <div className="text-[10px] uppercase font-bold text-slate-400">Base Monthly Salary</div>
            <div className="text-base font-extrabold text-emerald-400">
              ₹{currentUser.baseSalary.toLocaleString('en-IN')}
            </div>
          </div>
        </div>
      </div>

      {/* Personal Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Days Present ({selectedMonthStr})</div>
          <div className="text-2xl font-extrabold text-emerald-600 mt-1">
            {totalPresent} <span className="text-xs font-medium text-slate-400">Days</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Half-Days: <strong>{totalHalfDays}</strong> | Absents: <strong>{totalAbsent}</strong>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Leave Accrual & Balance</div>
          <div className="text-2xl font-extrabold text-slate-900 mt-1">
            {myPayrollRow ? myPayrollRow.leavesBalance : 2} <span className="text-xs font-medium text-slate-400">Days</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-0.5">
            Accrual: <strong>{currentUser.leaveAccrualRate} days/mo</strong>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Advance Balance</div>
          <div className="text-2xl font-extrabold text-purple-600 mt-1">
            ₹{myPayrollRow ? myPayrollRow.remainingAdvance.toLocaleString('en-IN') : '0'}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">Outstanding Advance</div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
          <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">Estimated Net Pay</div>
          <div className="text-2xl font-extrabold text-indigo-600 mt-1">
            ₹{myPayrollRow ? myPayrollRow.totalSalary.toLocaleString('en-IN') : currentUser.baseSalary.toLocaleString('en-IN')}
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">For {selectedMonthStr}</div>
        </div>
      </div>

      {/* Monthly Attendance Calendar Matrix */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-3">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">My Attendance Record ({selectedMonthStr})</h3>
            <p className="text-xs text-slate-500">Live attendance log for Manoj Prakash Associates</p>
          </div>
          <div className="flex items-center space-x-3 text-xs">
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded bg-emerald-500 inline-block"></span><span className="text-slate-600">P = Present</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded bg-amber-500 inline-block"></span><span className="text-slate-600">HD = Half-Day</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded bg-rose-500 inline-block"></span><span className="text-slate-600">A = Absent</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded bg-blue-500 inline-block"></span><span className="text-slate-600">H = Holiday / Sun</span></span>
            <span className="flex items-center space-x-1"><span className="w-2.5 h-2.5 rounded bg-slate-300 inline-block"></span><span className="text-slate-500">- = Unmarked</span></span>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
            const dayStr = day < 10 ? `0${day}` : `${day}`;
            const dateStr = `${selectedMonthStr}-${dayStr}`;
            const rec = myMonthRecords.find((r) => r.date === dateStr);
            const dObj = new Date(year, monthZeroIdx, day);
            const isSunday = dObj.getDay() === 0;

            let code = rec ? rec.status : isSunday ? 'H' : '-';
            let bgClass = 'bg-slate-50 text-slate-400 border-slate-200 border-dashed';
            if (code === 'P') bgClass = 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold shadow-xs';
            if (code === 'A') bgClass = 'bg-rose-50 text-rose-800 border-rose-300 font-bold shadow-xs';
            if (code === 'HD') bgClass = 'bg-amber-50 text-amber-800 border-amber-300 font-bold shadow-xs';
            if (code === 'H') bgClass = 'bg-blue-50 text-blue-800 border-blue-300 font-bold shadow-xs';

            const isToday = dateStr === todayStr;

            return (
              <div
                key={day}
                className={`p-2.5 rounded-xl border text-center transition-transform hover:scale-105 ${bgClass} ${
                  isToday ? 'ring-2 ring-indigo-500 shadow-sm' : ''
                }`}
              >
                <div className="text-[10px] text-slate-500 font-mono font-bold flex items-center justify-between">
                  <span>{day}</span>
                  {isToday && (
                    <span className="text-[8px] bg-indigo-600 text-white px-1 py-0.2 rounded font-extrabold uppercase">
                      Today
                    </span>
                  )}
                </div>
                <div className="text-xs font-extrabold mt-1">{code}</div>
                {rec?.clientName && (
                  <div className="text-[9px] truncate text-slate-600 mt-1 font-medium" title={rec.clientName}>
                    {rec.clientName}
                  </div>
                )}
                {rec?.checkInTime && (
                  <div className="text-[8px] text-slate-400 font-mono">
                    {rec.checkInTime}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
