import React, { useState } from 'react';
import { Employee, AttendanceRecord, Client, AdvanceRecord, PayrollMonth, PayrollRow } from '../types';
import { PayslipModal } from './PayslipModal';
import {
  FileText,
  Building2,
  UserCheck,
  Receipt,
  Download,
  Search,
  Eye,
  Printer,
  TrendingUp,
  CreditCard,
  CheckCircle2,
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  Filter,
} from 'lucide-react';

interface ReportsViewProps {
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  clients: Client[];
  advances: AdvanceRecord[];
  payrollMonth: PayrollMonth | null;
  selectedMonthStr: string;
  currentUser: Employee;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  employees,
  attendanceRecords,
  clients,
  advances,
  payrollMonth,
  selectedMonthStr,
  currentUser,
}) => {
  const [activeReportTab, setActiveReportTab] = useState<'client-deployment' | 'payslips' | 'attendance-summary' | 'advances'>('client-deployment');
  const [selectedPayslipRow, setSelectedPayslipRow] = useState<PayrollRow | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedEmployeeFilter, setSelectedEmployeeFilter] = useState('ALL');

  // Filter visible employees based on role
  const visibleEmployees = employees.filter((e) =>
    currentUser.role === 'EMPLOYEE' ? e.id === currentUser.id : true
  );

  // Month days calculation
  const [yearStr, mStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const monthZeroIdx = parseInt(mStr, 10) - 1;
  const daysInMonth = new Date(year, monthZeroIdx + 1, 0).getDate();

  // 1. Client Deployment Calculations
  const monthAttendance = attendanceRecords.filter((r) => r.date.startsWith(selectedMonthStr));

  const rawClientDeploymentData = clients.map((client) => {
    const siteRecords = monthAttendance.filter(
      (r) =>
        r.clientId === client.id &&
        r.status !== 'A' &&
        (currentUser.role === 'EMPLOYEE' ? r.empId === currentUser.id : true)
    );
    const totalDays = siteRecords.length;

    // Group by visible employee
    const empBreakdown = visibleEmployees
      .map((emp) => {
        const empSiteRecs = siteRecords.filter((r) => r.empId === emp.id);
        return {
          emp,
          days: empSiteRecs.length,
          dates: empSiteRecs.map((r) => r.date.split('-')[2]), // day numbers
        };
      })
      .filter((item) => item.days > 0);

    return { client, totalDays, empBreakdown };
  });

  // For Employee login, strictly filter to only clients they have actually visited
  const clientDeploymentData = rawClientDeploymentData.filter((item) => {
    if (currentUser.role === 'EMPLOYEE') {
      return item.empBreakdown.length > 0 || item.totalDays > 0;
    }
    return true;
  });

  // 2. Attendance Summary Calculations
  const attendanceSummaryData = visibleEmployees
    .filter((emp) => {
      const matchSearch =
        (emp.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (emp.empCode || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (emp.designation || '').toLowerCase().includes(searchTerm.toLowerCase());
      const matchFilter = selectedEmployeeFilter === 'ALL' || emp.id === selectedEmployeeFilter;
      return matchSearch && matchFilter;
    })
    .map((emp) => {
      const empMonthRecs = monthAttendance.filter((r) => r.empId === emp.id);
      let presentCount = 0;
      let halfDayCount = 0;
      let absentCount = 0;
      let holidayCount = 0;

      // Calculate days across month
      for (let day = 1; day <= daysInMonth; day++) {
        const dayStr = day < 10 ? `0${day}` : `${day}`;
        const dateStr = `${selectedMonthStr}-${dayStr}`;
        const rec = empMonthRecs.find((r) => r.date === dateStr);
        const dObj = new Date(year, monthZeroIdx, day);
        const isSunday = dObj.getDay() === 0;

        if (rec) {
          if (rec.status === 'P') presentCount++;
          else if (rec.status === 'HD') halfDayCount++;
          else if (rec.status === 'A') absentCount++;
          else if (rec.status === 'H') holidayCount++;
        } else if (isSunday) {
          holidayCount++;
        }
      }

      const totalPayableDays = presentCount + halfDayCount * 0.5 + holidayCount;
      const attendancePercent = daysInMonth > 0 ? Math.min(100, Math.round((totalPayableDays / daysInMonth) * 100)) : 0;

      // Find top client visited
      const clientVisitCounts: Record<string, { name: string; count: number }> = {};
      empMonthRecs.forEach((r) => {
        if (r.status !== 'A' && r.clientName) {
          if (!clientVisitCounts[r.clientName]) {
            clientVisitCounts[r.clientName] = { name: r.clientName, count: 0 };
          }
          clientVisitCounts[r.clientName].count++;
        }
      });
      const topClient = Object.values(clientVisitCounts).sort((a, b) => b.count - a.count)[0]?.name || 'Head Office';

      return {
        emp,
        presentCount,
        halfDayCount,
        absentCount,
        holidayCount,
        totalPayableDays,
        attendancePercent,
        topClient,
      };
    });

  // 3. Advances Ledger Calculations
  const filteredAdvances = advances.filter((adv) => {
    if (currentUser.role === 'EMPLOYEE') {
      return adv.empId === currentUser.id;
    }
    if (selectedEmployeeFilter !== 'ALL') {
      return adv.empId === selectedEmployeeFilter;
    }
    return true;
  });

  const empAdvanceSummary = visibleEmployees
    .filter((emp) => {
      const matchSearch =
        (emp.name || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
        (emp.empCode || '').toLowerCase().includes(searchTerm.toLowerCase());
      const matchFilter = selectedEmployeeFilter === 'ALL' || emp.id === selectedEmployeeFilter;
      return matchSearch && matchFilter;
    })
    .map((emp) => {
      const empAdvs = advances.filter((a) => a.empId === emp.id);
      const totalGiven = empAdvs.filter((a) => a.type === 'given').reduce((sum, a) => sum + a.amount, 0);
      const totalRecovered = empAdvs.filter((a) => a.type === 'recovery').reduce((sum, a) => sum + a.amount, 0);
      const outstanding = totalGiven - totalRecovered;
      const monthGiven = empAdvs
        .filter((a) => a.type === 'given' && a.date.startsWith(selectedMonthStr))
        .reduce((sum, a) => sum + a.amount, 0);
      const monthRecovered = empAdvs
        .filter((a) => a.type === 'recovery' && a.date.startsWith(selectedMonthStr))
        .reduce((sum, a) => sum + a.amount, 0);

      return {
        emp,
        totalGiven,
        totalRecovered,
        outstanding,
        monthGiven,
        monthRecovered,
        txCount: empAdvs.length,
      };
    });

  const totalAllGiven = advances.filter((a) => a.type === 'given').reduce((sum, a) => sum + a.amount, 0);
  const totalAllRecovered = advances.filter((a) => a.type === 'recovery').reduce((sum, a) => sum + a.amount, 0);
  const totalAllOutstanding = totalAllGiven - totalAllRecovered;

  // Export Attendance Summary CSV
  const handleExportAttendanceCSV = () => {
    const headers = ['Emp Code', 'Employee Name', 'Designation', 'Branch', 'Days in Month', 'Present (P)', 'Half Days (HD)', 'Absents (A)', 'Holidays/Sundays (H)', 'Effective Payable Days', 'Attendance %', 'Primary Deployment'];
    const rows = attendanceSummaryData.map((d) => [
      d.emp.empCode,
      `"${d.emp.name}"`,
      `"${d.emp.designation}"`,
      `"${d.emp.branch}"`,
      daysInMonth,
      d.presentCount,
      d.halfDayCount,
      d.absentCount,
      d.holidayCount,
      d.totalPayableDays,
      `${d.attendancePercent}%`,
      `"${d.topClient}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `MPA_Attendance_Summary_${selectedMonthStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Export Advances Ledger CSV
  const handleExportAdvancesCSV = () => {
    const headers = ['Date', 'Emp Code', 'Employee Name', 'Transaction Type', 'Amount (INR)', 'Month Reference', 'Remarks / Voucher Notes'];
    const rows = filteredAdvances.map((adv) => {
      const emp = employees.find((e) => e.id === adv.empId);
      return [
        adv.date,
        emp?.empCode || '',
        `"${emp?.name || 'Unknown'}"`,
        adv.type === 'given' ? 'Advance Disbursed' : 'Salary Recovery',
        adv.amount,
        adv.month || '',
        `"${adv.notes || ''}"`,
      ];
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `MPA_Advances_Ledger_${selectedMonthStr}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Firm Intelligence & Audit Reports</h2>
            <p className="text-xs text-slate-400">
              Manoj Prakash Associates • Client site deployment breakdowns, employee payslips, attendance audit, and advance ledgers
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs">
          <span className="px-3 py-1.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-300 font-medium">
            Reporting Month: <strong className="text-white">{selectedMonthStr}</strong>
          </span>
        </div>
      </div>

      {/* Sub-Tabs Navigation */}
      <div className="flex space-x-2 bg-white p-1.5 rounded-2xl border border-slate-200 shadow-sm overflow-x-auto">
        {[
          { id: 'client-deployment', label: 'Client Deployment Report', icon: Building2 },
          { id: 'payslips', label: 'Monthly Payslips', icon: FileText },
          { id: 'attendance-summary', label: 'Attendance Summary', icon: UserCheck },
          { id: 'advances', label: 'Advances Ledger', icon: Receipt },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeReportTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveReportTab(tab.id as any)}
              className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. Client Site Deployment Report */}
      {activeReportTab === 'client-deployment' && (
        <div className="space-y-4">
          <div className="p-4 bg-indigo-50 border border-indigo-100 rounded-2xl text-xs text-indigo-900 flex flex-wrap items-center justify-between gap-3">
            <div>
              <strong className="font-bold text-slate-900">Client Site Deployment Analysis for {selectedMonthStr}:</strong>
              <p className="text-[11px] text-slate-600">
                Detailed breakdown of staff deployment days per client for billing & audit reference
              </p>
            </div>
          </div>

          <div className="space-y-4">
            {clientDeploymentData.length === 0 ? (
              <div className="bg-white border border-slate-200 rounded-2xl p-8 text-center space-y-2">
                <Building2 className="w-8 h-8 text-slate-300 mx-auto" />
                <h4 className="font-bold text-slate-700 text-sm">No Client Visits Recorded</h4>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  {currentUser.role === 'EMPLOYEE'
                    ? `You haven't visited any client sites in ${selectedMonthStr}. Client sites visited during your daily check-in will appear here.`
                    : `No client deployments have been recorded for ${selectedMonthStr}.`}
                </p>
              </div>
            ) : (
              clientDeploymentData.map(({ client, totalDays, empBreakdown }) => (
                <div key={client.id} className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-800 font-bold flex items-center justify-center text-xs">
                        {client.code || 'CLI'}
                      </div>
                      <div>
                        <h3 className="font-bold text-slate-900 text-sm">{client.name}</h3>
                        <p className="text-xs text-slate-400">{client.location}</p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="px-3 py-1 rounded-full bg-indigo-100 text-indigo-800 text-xs font-bold">
                        {totalDays} Total Person-Days
                      </span>
                    </div>
                  </div>

                  {empBreakdown.length > 0 ? (
                    <div className="overflow-x-auto">
                      <table className="w-full text-left text-xs">
                        <thead>
                          <tr className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-200">
                            <th className="p-2">Deployed Staff</th>
                            <th className="p-2">Designation</th>
                            <th className="p-2 text-center">Days at Site</th>
                            <th className="p-2">Dates Worked</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {empBreakdown.map(({ emp, days, dates }) => (
                            <tr key={emp.id} className="hover:bg-slate-50">
                              <td className="p-2 font-bold text-slate-800">{emp.name} ({emp.empCode})</td>
                              <td className="p-2 text-slate-600">{emp.designation}</td>
                              <td className="p-2 text-center font-extrabold text-indigo-600">{days} Days</td>
                              <td className="p-2 text-slate-500 font-mono text-[11px]">
                                Days: {dates.join(', ')}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  ) : (
                    <div className="text-xs text-slate-400 italic py-2">No staff deployed at this site during {selectedMonthStr}.</div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 2. Monthly Payslips View */}
      {activeReportTab === 'payslips' && (
        <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-3">
            <div>
              <h3 className="font-bold text-slate-900 text-sm">Monthly Payslip Directory ({payrollMonth?.displayMonth || selectedMonthStr})</h3>
              <p className="text-xs text-slate-400">Click view to inspect or print official monthly payslip</p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-900 text-slate-200 font-semibold">
                  <th className="p-3">Employee</th>
                  <th className="p-3">Designation</th>
                  <th className="p-3 text-right">Base Salary</th>
                  <th className="p-3 text-right">Conveyance</th>
                  <th className="p-3 text-right">Leave Deductions</th>
                  <th className="p-3 text-right">Advance Recovery</th>
                  <th className="p-3 text-right font-bold text-emerald-300">Net Payable</th>
                  <th className="p-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {(payrollMonth?.rows || [])
                  .filter((row) => (currentUser.role === 'EMPLOYEE' ? row.empId === currentUser.id : true))
                  .map((row) => (
                  <tr key={row.empId} className="hover:bg-slate-50">
                    <td className="p-3 font-bold text-slate-900">{row.empName} ({row.empCode})</td>
                    <td className="p-3 text-slate-600">{row.designation}</td>
                    <td className="p-3 text-right">₹{row.baseSalary.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-right text-slate-600">₹{row.conveyance.toLocaleString('en-IN')}</td>
                    <td className="p-3 text-right text-rose-600 font-semibold">
                      ₹{row.salaryDeducted.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3 text-right text-purple-600 font-semibold">
                      ₹{row.advanceDeduction.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3 text-right font-extrabold text-emerald-700">
                      ₹{row.totalSalary.toLocaleString('en-IN')}
                    </td>
                    <td className="p-3 text-center">
                      <button
                        onClick={() => setSelectedPayslipRow(row)}
                        className="px-3 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg transition-colors flex items-center space-x-1 mx-auto"
                      >
                        <Eye className="w-3.5 h-3.5" />
                        <span>View Payslip</span>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Attendance Summary Report */}
      {activeReportTab === 'attendance-summary' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
              <div className="relative flex-1 max-w-xs">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search staff by name or code..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              {currentUser.role !== 'EMPLOYEE' && (
                <select
                  value={selectedEmployeeFilter}
                  onChange={(e) => setSelectedEmployeeFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-700 font-medium focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Staff Members</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.empCode})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleExportAttendanceCSV}
                className="px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors border border-emerald-200"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export CSV</span>
              </button>
              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Report</span>
              </button>
            </div>
          </div>

          {/* Attendance Summary Table */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Staff Attendance Roll & Metrics ({selectedMonthStr})</h3>
                <p className="text-xs text-slate-400">Total Calendar Days: {daysInMonth} Days • P (Present), HD (Half Day = 0.5), A (Absent), H (Paid Holiday/Sun)</p>
              </div>
              <span className="text-xs bg-indigo-50 text-indigo-700 px-3 py-1 rounded-full font-bold">
                {attendanceSummaryData.length} Employee{attendanceSummaryData.length !== 1 ? 's' : ''} Listed
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-900 text-slate-200 font-semibold">
                    <th className="p-3">Employee</th>
                    <th className="p-3">Designation / Branch</th>
                    <th className="p-3 text-center bg-emerald-950/40 text-emerald-300">Present (P)</th>
                    <th className="p-3 text-center bg-amber-950/40 text-amber-300">Half Day (HD)</th>
                    <th className="p-3 text-center bg-rose-950/40 text-rose-300">Absent (A)</th>
                    <th className="p-3 text-center bg-blue-950/40 text-blue-300">Holidays/Sun (H)</th>
                    <th className="p-3 text-center font-bold text-indigo-300">Payable Days</th>
                    <th className="p-3 text-center">Attendance %</th>
                    <th className="p-3">Primary Client Site</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {attendanceSummaryData.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-slate-400">
                        No attendance summary records match the search criteria for {selectedMonthStr}.
                      </td>
                    </tr>
                  ) : (
                    attendanceSummaryData.map((item) => (
                      <tr key={item.emp.id} className="hover:bg-slate-50">
                        <td className="p-3 font-bold text-slate-900">
                          {item.emp.name}
                          <span className="block text-[11px] text-slate-400 font-mono font-normal">{item.emp.empCode}</span>
                        </td>
                        <td className="p-3 text-slate-600">
                          <div>{item.emp.designation}</div>
                          <div className="text-[11px] text-slate-400">{item.emp.branch}</div>
                        </td>
                        <td className="p-3 text-center font-extrabold text-emerald-700 bg-emerald-50/50">
                          {item.presentCount}
                        </td>
                        <td className="p-3 text-center font-bold text-amber-700 bg-amber-50/50">
                          {item.halfDayCount}
                        </td>
                        <td className="p-3 text-center font-bold text-rose-700 bg-rose-50/50">
                          {item.absentCount}
                        </td>
                        <td className="p-3 text-center font-bold text-blue-700 bg-blue-50/50">
                          {item.holidayCount}
                        </td>
                        <td className="p-3 text-center font-black text-indigo-700 text-sm">
                          {item.totalPayableDays} <span className="text-[10px] text-slate-400 font-normal">/ {daysInMonth}</span>
                        </td>
                        <td className="p-3 text-center">
                          <span
                            className={`px-2.5 py-1 rounded-full font-extrabold text-[11px] ${
                              item.attendancePercent >= 90
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.attendancePercent >= 75
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {item.attendancePercent}%
                          </span>
                        </td>
                        <td className="p-3 text-slate-700 font-medium">
                          <div className="flex items-center space-x-1.5">
                            <Building2 className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                            <span className="truncate max-w-[160px]" title={item.topClient}>{item.topClient}</span>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. Advances Ledger Report */}
      {activeReportTab === 'advances' && (
        <div className="space-y-4">
          {/* Summary Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>Total Advances Disbursed</span>
                <ArrowUpRight className="w-4 h-4 text-purple-600" />
              </div>
              <div className="text-2xl font-extrabold text-slate-900 mt-1">
                ₹{totalAllGiven.toLocaleString('en-IN')}
              </div>
              <div className="text-xs text-slate-400 mt-1">Cumulative principal issued to staff</div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>Total Salary Recoveries</span>
                <ArrowDownRight className="w-4 h-4 text-emerald-600" />
              </div>
              <div className="text-2xl font-extrabold text-emerald-600 mt-1">
                ₹{totalAllRecovered.toLocaleString('en-IN')}
              </div>
              <div className="text-xs text-slate-400 mt-1">Recovered via payroll deductions</div>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm space-y-1">
              <div className="flex items-center justify-between text-xs font-semibold text-slate-500 uppercase tracking-wider">
                <span>Net Outstanding Balance</span>
                <CreditCard className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-2xl font-extrabold text-indigo-600 mt-1">
                ₹{totalAllOutstanding.toLocaleString('en-IN')}
              </div>
              <div className="text-xs text-slate-400 mt-1">Active unrecovered employee advances</div>
            </div>
          </div>

          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
              <div className="relative flex-1 max-w-xs">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Filter advance ledger..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500"
                />
              </div>

              {currentUser.role !== 'EMPLOYEE' && (
                <select
                  value={selectedEmployeeFilter}
                  onChange={(e) => setSelectedEmployeeFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-700 font-medium focus:outline-none focus:border-indigo-500"
                >
                  <option value="ALL">All Staff Members</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.name} ({emp.empCode})
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={handleExportAdvancesCSV}
                className="px-3.5 py-2 bg-purple-50 hover:bg-purple-100 text-purple-700 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors border border-purple-200"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Ledger CSV</span>
              </button>
              <button
                onClick={() => window.print()}
                className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs flex items-center space-x-1.5 transition-colors"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Print Ledger</span>
              </button>
            </div>
          </div>

          {/* Employee Balance Summary Table */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-sm">Employee Advance Account Balances</h3>
                <p className="text-xs text-slate-400">Current loan & advance positions per staff member</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-900 text-slate-200 font-semibold">
                    <th className="p-3">Employee</th>
                    <th className="p-3">Designation</th>
                    <th className="p-3 text-right">Total Disbursed</th>
                    <th className="p-3 text-right text-emerald-300">Total Recovered</th>
                    <th className="p-3 text-right font-bold text-indigo-300">Outstanding Balance</th>
                    <th className="p-3 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {empAdvanceSummary.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-6 text-center text-slate-400">
                        No employees found matching filter.
                      </td>
                    </tr>
                  ) : (
                    empAdvanceSummary.map((item) => (
                      <tr key={item.emp.id} className="hover:bg-slate-50">
                        <td className="p-3 font-bold text-slate-900">
                          {item.emp.name} ({item.emp.empCode})
                        </td>
                        <td className="p-3 text-slate-600">{item.emp.designation}</td>
                        <td className="p-3 text-right font-semibold text-slate-800">
                          ₹{item.totalGiven.toLocaleString('en-IN')}
                        </td>
                        <td className="p-3 text-right font-semibold text-emerald-700">
                          ₹{item.totalRecovered.toLocaleString('en-IN')}
                        </td>
                        <td className="p-3 text-right font-extrabold text-purple-700 text-sm">
                          ₹{item.outstanding.toLocaleString('en-IN')}
                        </td>
                        <td className="p-3 text-center">
                          {item.outstanding <= 0 ? (
                            <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-[11px] font-bold">
                              Settled / Nil
                            </span>
                          ) : (
                            <span className="px-2.5 py-1 rounded-full bg-amber-100 text-amber-800 text-[11px] font-bold">
                              Active Balance
                            </span>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Detailed Transaction History */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-slate-900 text-sm">Advances & Recoveries Transaction Journal</h3>
              <span className="text-xs text-slate-400">{filteredAdvances.length} entries recorded</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-50 text-slate-600 font-semibold border-b">
                    <th className="p-3">Date</th>
                    <th className="p-3">Employee</th>
                    <th className="p-3">Transaction Type</th>
                    <th className="p-3 text-right">Amount (₹)</th>
                    <th className="p-3">Month Reference</th>
                    <th className="p-3">Notes / Voucher Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredAdvances.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-400">
                        No advance disbursement or recovery records logged yet.
                      </td>
                    </tr>
                  ) : (
                    filteredAdvances.map((adv) => {
                      const emp = employees.find((e) => e.id === adv.empId);
                      const isGiven = adv.type === 'given';
                      return (
                        <tr key={adv.id} className="hover:bg-slate-50">
                          <td className="p-3 font-mono text-slate-700">{adv.date}</td>
                          <td className="p-3 font-bold text-slate-900">
                            {emp ? `${emp.name} (${emp.empCode})` : 'Unknown Employee'}
                          </td>
                          <td className="p-3">
                            <span
                              className={`px-2 py-0.5 rounded-md text-[11px] font-bold inline-flex items-center space-x-1 ${
                                isGiven
                                  ? 'bg-purple-100 text-purple-800'
                                  : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {isGiven ? <ArrowUpRight className="w-3 h-3 mr-1" /> : <ArrowDownRight className="w-3 h-3 mr-1" />}
                              <span>{isGiven ? 'Advance Disbursed' : 'Salary Deduction'}</span>
                            </span>
                          </td>
                          <td className={`p-3 text-right font-extrabold ${isGiven ? 'text-purple-700' : 'text-emerald-700'}`}>
                            ₹{adv.amount.toLocaleString('en-IN')}
                          </td>
                          <td className="p-3 font-mono text-slate-500">{adv.month || '-'}</td>
                          <td className="p-3 text-slate-600 max-w-xs truncate" title={adv.notes}>
                            {adv.notes || '-'}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Payslip Modal Trigger */}
      {selectedPayslipRow && (
        <PayslipModal
          isOpen={!!selectedPayslipRow}
          onClose={() => setSelectedPayslipRow(null)}
          payrollRow={selectedPayslipRow}
          monthDisplay={payrollMonth?.displayMonth || selectedMonthStr}
          employee={employees.find((e) => e.id === selectedPayslipRow.empId) || employees[0]}
        />
      )}
    </div>
  );
};
