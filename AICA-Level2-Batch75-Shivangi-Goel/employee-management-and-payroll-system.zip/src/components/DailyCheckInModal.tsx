import React, { useState } from 'react';
import { Employee, Client, AttendanceStatusCode } from '../types';
import { MapPin, Building2, CheckCircle, Clock, AlertCircle, X, Shield } from 'lucide-react';

interface DailyCheckInModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: Employee;
  clients: Client[];
  onSubmit: (data: {
    status: AttendanceStatusCode;
    clientId: string;
    clientName: string;
    notes: string;
    location: string;
  }) => void;
}

export const DailyCheckInModal: React.FC<DailyCheckInModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  clients,
  onSubmit,
}) => {
  if (!isOpen) return null;

  const d = new Date();
  const todayStr = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const formattedToday = d.toLocaleDateString('en-US', {
    weekday: 'long',
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });

  const [status, setStatus] = useState<AttendanceStatusCode>('P');
  const [selectedClientId, setSelectedClientId] = useState<string>(clients[0]?.id || 'cli-ho');
  const [notes, setNotes] = useState<string>('');
  const [location, setLocation] = useState<string>('Delhi HQ - Manoj Prakash Associates');
  const [isCapturingGeo, setIsCapturingGeo] = useState<boolean>(false);
  const [geoCaptured, setGeoCaptured] = useState<boolean>(false);
  const [submitting, setSubmitting] = useState<boolean>(false);

  // Sync default selected client when clients prop updates
  React.useEffect(() => {
    if (clients.length > 0 && (!selectedClientId || !clients.some(c => c.id === selectedClientId))) {
      setSelectedClientId(clients[0].id);
    }
  }, [clients, selectedClientId]);

  const handleCaptureLocation = () => {
    setIsCapturingGeo(true);
    if ('geolocation' in navigator) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          setLocation(`Lat: ${pos.coords.latitude.toFixed(4)}, Lon: ${pos.coords.longitude.toFixed(4)} (GPS Verified)`);
          setIsCapturingGeo(false);
          setGeoCaptured(true);
        },
        () => {
          setLocation(`Office / Client Site (${currentUser.branch || 'Delhi HQ'} Verified)`);
          setIsCapturingGeo(false);
          setGeoCaptured(true);
        }
      );
    } else {
      setLocation(`Office / Client Site (${currentUser.branch || 'Delhi HQ'} Verified)`);
      setIsCapturingGeo(false);
      setGeoCaptured(true);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const client = clients.find((c) => c.id === selectedClientId) || clients[0];
    const cId = client ? client.id : 'cli-ho';
    const cName = client ? client.name : 'Head Office';

    onSubmit({
      status,
      clientId: status === 'P' || status === 'HD' ? cId : 'cli-ho',
      clientName: status === 'P' || status === 'HD' ? cName : (status === 'A' ? 'Absent' : 'Holiday'),
      notes,
      location,
    });
    setSubmitting(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden text-slate-800">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-blue-700 text-white p-5 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center font-bold">
              <Clock className="w-5 h-5 text-indigo-100" />
            </div>
            <div>
              <h2 className="font-bold text-lg text-white">Daily Attendance & Client Check-In</h2>
              <p className="text-xs text-indigo-100">{formattedToday}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-white/10 text-indigo-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-x-0 space-y-5">
          {/* Employee Brief */}
          <div className="p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-xl flex items-center justify-between text-xs text-indigo-900">
            <div>
              <span className="font-semibold text-slate-700">Logging in as: </span>
              <span className="font-bold text-indigo-900">{currentUser.name}</span> ({currentUser.empCode})
            </div>
            <span className="px-2 py-0.5 rounded bg-indigo-100 text-indigo-800 font-semibold text-[11px]">
              {currentUser.branch}
            </span>
          </div>

          {/* Attendance Status Picker */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Mark Attendance Status
            </label>
            <div className="grid grid-cols-4 gap-2">
              {[
                { code: 'P', label: 'Present', color: 'border-emerald-500 bg-emerald-50 text-emerald-800' },
                { code: 'HD', label: 'Half-Day', color: 'border-amber-500 bg-amber-50 text-amber-800' },
                { code: 'A', label: 'Absent', color: 'border-rose-500 bg-rose-50 text-rose-800' },
                { code: 'H', label: 'Holiday', color: 'border-blue-500 bg-blue-50 text-blue-800' },
              ].map((item) => {
                const isSelected = status === item.code;
                return (
                  <button
                    type="button"
                    key={item.code}
                    onClick={() => setStatus(item.code as AttendanceStatusCode)}
                    className={`py-2.5 px-2 rounded-xl text-xs font-bold border-2 transition-all flex flex-col items-center justify-center space-y-1 ${
                      isSelected ? item.color + ' ring-2 ring-indigo-500/20 shadow-sm' : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <span className="text-base font-extrabold">{item.code}</span>
                    <span className="text-[10px]">{item.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Client Site Selector (if Present or Half-Day) */}
          {status !== 'A' && status !== 'H' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                <span>Select Client / Working Site</span>
                <span className="text-[10px] text-indigo-600 font-medium">Required for Site Billing</span>
              </label>
              <div className="relative">
                <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                <select
                  value={selectedClientId}
                  onChange={(e) => setSelectedClientId(e.target.value)}
                  className="w-full pl-9 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
                  required
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} ({c.location})
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}

          {/* Geolocation Capture Button */}
          {status !== 'A' && status !== 'H' && (
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between text-xs">
              <div className="flex items-center space-x-2 text-slate-600">
                <MapPin className="w-4 h-4 text-rose-500 shrink-0" />
                <span className="truncate max-w-[220px] text-slate-700">{location}</span>
              </div>
              <button
                type="button"
                onClick={handleCaptureLocation}
                disabled={isCapturingGeo}
                className="px-2.5 py-1 bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold rounded-lg text-[11px] transition-colors"
              >
                {isCapturingGeo ? 'Capturing...' : geoCaptured ? 'Verified GPS' : 'Tag Location'}
              </button>
            </div>
          )}

          {/* Notes field */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
              Site Notes / Work Summary (Optional)
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Conducted internal inventory audit at client premises..."
              className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500"
            />
          </div>

          {/* Submit CTA */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 text-white font-bold rounded-xl shadow-lg hover:shadow-indigo-500/25 transition-all text-xs flex items-center justify-center space-x-2"
            >
              <CheckCircle className="w-4 h-4" />
              <span>Confirm Daily Attendance & Check-In</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
