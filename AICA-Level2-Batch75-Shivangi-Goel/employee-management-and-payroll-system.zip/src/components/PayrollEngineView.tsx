import React, { useState } from 'react';
import { PayrollMonth, PayrollRow, Employee } from '../types';
import { downloadPayrollExcel } from '../utils/excelExport';
import {
  FileSpreadsheet,
  Download,
  Lock,
  Unlock,
  RefreshCw,
  Edit3,
  CheckCircle2,
  AlertCircle,
  Search,
  Upload,
  Info,
  DollarSign,
  Plus,
} from 'lucide-react';

interface PayrollEngineViewProps {
  payrollMonth: PayrollMonth | null;
  selectedMonthStr: string; // "2026-02"
  onChangeMonth: (m: string) => void;
  onRefreshPayroll: () => void;
  onOverrideRow: (empId: string, overrides: Record<string, number | string>) => void;
  onFinalizePayroll: (finalizedBy: string) => void;
  onUnlockPayroll: (unlockedBy: string, reason: string) => void;
  currentUser: Employee;
  allEmployees: Employee[];
}

export const PayrollEngineView: React.FC<PayrollEngineViewProps> = ({
  payrollMonth,
  selectedMonthStr,
  onChangeMonth,
  onRefreshPayroll,
  onOverrideRow,
  onFinalizePayroll,
  onUnlockPayroll,
  currentUser,
  allEmployees,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [editingRow, setEditingRow] = useState<PayrollRow | null>(null);
  const [overrideSalaryDeducted, setOverrideSalaryDeducted] = useState<number>(0);
  const [overrideConveyance, setOverrideConveyance] = useState<number>(0);
  const [overrideAdvance, setOverrideAdvance] = useState<number>(0);

  const [showUnlockModal, setShowUnlockModal] = useState(false);
  const [unlockReason, setUnlockReason] = useState('');

  const [showImportModal, setShowImportModal] = useState(false);
  const [importNotice, setImportNotice] = useState('');

  const [yearStr, mStr] = selectedMonthStr.split('-');
  const year = parseInt(yearStr, 10);
  const monthZeroIdx = parseInt(mStr, 10) - 1;
  const daysInMonth = new Date(year, monthZeroIdx + 1, 0).getDate();

  const handleOpenEdit = (row: PayrollRow) => {
    setEditingRow(row);
    setOverrideSalaryDeducted(row.salaryDeducted);
    setOverrideConveyance(row.conveyance);
    setOverrideAdvance(row.advance);
  };

  const handleSaveOverrides = () => {
    if (!editingRow) return;
    onOverrideRow(editingRow.empId, {
      salaryDeducted: Number(overrideSalaryDeducted),
      conveyance: Number(overrideConveyance),
      advance: Number(overrideAdvance),
    });
    setEditingRow(null);
  };

  const handleDownloadExcel = () => {
    if (!payrollMonth) return;
    downloadPayrollExcel(payrollMonth, year, monthZeroIdx);
  };

  const handleUnlockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUnlockPayroll(currentUser.name, unlockReason);
    setShowUnlockModal(false);
    setUnlockReason('');
  };

  const filteredRows = (payrollMonth?.rows || []).filter(
    (r) =>
      r.empName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.empCode.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.branch.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Column Total Calculations
  const totals = (payrollMonth?.rows || []).reduce(
    (acc, r) => {
      acc.baseSalary += r.baseSalary;
      acc.leaveAccrued += r.leaveAccrued;
      acc.leavesTaken += r.leavesTaken;
      acc.leavesBalance += r.leavesBalance;
      acc.salaryDeducted += r.salaryDeducted;
      acc.carryForwardLeave += r.carryForwardLeave;
      acc.salary += r.salary;
      acc.conveyance += r.conveyance;
      acc.advance += r.advance;
      acc.totalSalary += r.totalSalary;
      acc.remainingAdvance += r.remainingAdvance;
      return acc;
    },
    {
      baseSalary: 0,
      leaveAccrued: 0,
      leavesTaken: 0,
      leavesBalance: 0,
      salaryDeducted: 0,
      carryForwardLeave: 0,
      salary: 0,
      conveyance: 0,
      advance: 0,
      totalSalary: 0,
      remainingAdvance: 0,
    }
  );

  return (
    <div className="space-y-6">
      {/* Top Controls Bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-5 text-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-4">
        {/* Title & Month Selector */}
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 font-bold">
            <FileSpreadsheet className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center space-x-3">
              <h2 className="text-lg font-bold text-slate-800 tracking-tight">Payroll Worksheet: {payrollMonth?.displayMonth || selectedMonthStr}</h2>
              <span
                className={`text-xs px-3 py-1 rounded-full font-bold uppercase tracking-wider ${
                  payrollMonth?.isFinalized
                    ? 'bg-rose-100 text-rose-700 border border-rose-200'
                    : 'bg-green-100 text-green-700 border border-green-200'
                }`}
              >
                {payrollMonth?.isFinalized ? 'LOCKED (FINALIZED)' : 'DRAFT'}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Exact column layout matching firm Excel format • Auto-computes leave deduction & advances
            </p>
          </div>
        </div>

        {/* Month Selector & Action Buttons */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Month Picker */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 flex items-center space-x-2 text-xs">
            <span className="text-slate-500 font-semibold text-[11px] uppercase tracking-wider">Select Month:</span>
            <input
              type="month"
              value={selectedMonthStr}
              onChange={(e) => onChangeMonth(e.target.value)}
              className="bg-transparent font-bold text-slate-800 focus:outline-none cursor-pointer"
            />
          </div>

          {/* Refresh */}
          <button
            onClick={onRefreshPayroll}
            className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold border border-slate-200 transition-colors flex items-center space-x-1.5 shadow-sm"
            title="Recalculate Sheet"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-500" />
            <span className="hidden sm:inline">Recalculate</span>
          </button>

          {/* Excel Download CTA */}
          <button
            onClick={handleDownloadExcel}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-lg text-xs shadow-sm transition-colors flex items-center space-x-2"
          >
            <Download className="w-4 h-4" />
            <span>Export Payroll Sheet (.xlsx)</span>
          </button>

          {/* Lock / Unlock button */}
          {payrollMonth?.isFinalized ? (
            <button
              onClick={() => setShowUnlockModal(true)}
              className="px-3.5 py-2 bg-white hover:bg-slate-50 text-rose-600 border border-rose-200 rounded-lg text-xs font-bold transition-colors flex items-center space-x-1.5 shadow-sm"
            >
              <Unlock className="w-3.5 h-3.5" />
              <span>Unlock Month</span>
            </button>
          ) : (
            <button
              onClick={() => onFinalizePayroll(currentUser.name)}
              className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-bold rounded-lg text-xs uppercase tracking-wider transition-colors flex items-center space-x-1.5 border border-indigo-200"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Finalize & Lock Month</span>
            </button>
          )}
        </div>

        {/* Lock Notice if Finalized */}
        {payrollMonth?.isFinalized && (
          <div className="w-full mt-2 p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800 flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Lock className="w-4 h-4 text-rose-600 shrink-0" />
              <span>
                This payroll month was finalized by <strong>{payrollMonth.finalizedBy}</strong> on{' '}
                {new Date(payrollMonth.finalizedAt || '').toLocaleString()}.
              </span>
            </div>
            <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider">Read-Only</span>
          </div>
        )}
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Total Staff</div>
          <div className="text-2xl font-bold mt-1 text-slate-800">{payrollMonth?.rows.length || 0}</div>
          <div className="text-xs text-slate-400 mt-1">Across active branches</div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Leaves Accrued</div>
          <div className="text-2xl font-bold mt-1 text-indigo-600">{totals.leaveAccrued.toFixed(1)}</div>
          <div className="text-xs text-slate-400 mt-1">@ 2.0 days/emp rate</div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Outstanding Advances</div>
          <div className="text-2xl font-bold mt-1 text-orange-600">₹{totals.remainingAdvance.toLocaleString('en-IN')}</div>
          <div className="text-xs text-slate-400 mt-1">Firm unrecovered balance</div>
        </div>

        <div className="bg-white p-4 rounded-lg border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Estimated Payout</div>
          <div className="text-2xl font-bold mt-1 text-slate-800">₹{totals.totalSalary.toLocaleString('en-IN')}</div>
          <div className="text-xs text-slate-400 mt-1">Net bank disbursement</div>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="flex items-center justify-between bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
        <div className="relative w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Search employee, code or branch..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <strong>{filteredRows.length}</strong> of {payrollMonth?.rows.length || 0} employees
        </div>
      </div>

      {/* Interactive Matrix Table */}
      <div className="bg-white border border-slate-200 rounded-xl shadow-sm overflow-hidden flex flex-col">
        <div className="overflow-x-auto h-full">
          <table className="w-full text-left border-collapse text-xs">
            <thead className="sticky top-0 bg-slate-100 z-20">
              <tr className="text-[10px] font-bold text-slate-600 uppercase border-b border-slate-200 bg-slate-100">
                <th className="p-3 border-r border-slate-200 min-w-[70px]">Month</th>
                <th className="p-3 sticky left-0 z-30 bg-slate-100 border-r border-slate-200 min-w-[160px] shadow-[1px_0_0_0_#e2e8f0]">
                  Employee Name
                </th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[100px]">Base Sal.</th>
                <th className="p-3 border-r border-slate-200 text-center min-w-[60px]">Accr.</th>
                <th className="p-3 border-r border-slate-200 text-center min-w-[60px]">Taken</th>
                <th className="p-3 border-r border-slate-200 text-center min-w-[60px]">Bal.</th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[95px] text-rose-600">Ded. (L)</th>
                <th className="p-3 border-r border-slate-200 text-center min-w-[60px]">C/F</th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[90px]">Salary</th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[90px]">Conveyance</th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[90px]">Advance</th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[110px] bg-slate-200/60 text-slate-900 font-bold">
                  Total Payable
                </th>
                <th className="p-3 border-r border-slate-200 text-right min-w-[110px]">Rem. Adv.</th>

                {/* Day 1..N columns */}
                {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => (
                  <th key={day} className="p-2 border-r border-slate-200 text-center min-w-[34px] text-[10px]">
                    {day < 10 ? `0${day}` : day}
                  </th>
                ))}

                {!payrollMonth?.isFinalized && <th className="p-3 text-center min-w-[60px]">Action</th>}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-xs">
              {filteredRows.map((r, idx) => {
                return (
                  <tr
                    key={r.empId}
                    className="border-b border-slate-100 hover:bg-slate-50 transition-colors"
                  >
                    {/* Month */}
                    <td className="p-3 border-r border-slate-200 font-medium text-slate-500 text-[11px]">
                      {payrollMonth?.displayMonth}
                    </td>

                    {/* Employee Name */}
                    <td className="p-3 sticky left-0 z-10 bg-white border-r border-slate-200 font-medium text-slate-800 shadow-[1px_0_0_0_#e2e8f0]">
                      <div>
                        {r.empName}
                        <div className="text-[10px] text-slate-400">{r.empCode}</div>
                      </div>
                    </td>

                    {/* Base Salary */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono text-slate-700">
                      ₹{r.baseSalary.toLocaleString('en-IN')}
                    </td>

                    {/* Leave Accrued */}
                    <td className="p-3 border-r border-slate-200 text-center text-slate-600 font-medium">
                      {r.leaveAccrued}
                    </td>

                    {/* Leaves Taken */}
                    <td className="p-3 border-r border-slate-200 text-center font-semibold text-rose-600">
                      {r.leavesTaken}
                    </td>

                    {/* Leaves Balance */}
                    <td
                      className={`p-3 border-r border-slate-200 text-center font-bold ${
                        r.leavesBalance < 0 ? 'text-rose-600 bg-rose-50/50' : 'text-slate-700'
                      }`}
                    >
                      {r.leavesBalance}
                    </td>

                    {/* Salary Deducted */}
                    <td className="p-3 border-r border-slate-200 text-right font-medium text-rose-600 font-mono">
                      {r.salaryDeducted > 0 ? `₹${r.salaryDeducted.toLocaleString('en-IN')}` : '₹0'}
                    </td>

                    {/* Carry Forward */}
                    <td className="p-3 border-r border-slate-200 text-center text-slate-600">
                      {r.carryForwardLeave}
                    </td>

                    {/* Salary */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono text-slate-700">
                      ₹{r.salary.toLocaleString('en-IN')}
                    </td>

                    {/* Conveyance */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono text-slate-700">
                      ₹{r.conveyance.toLocaleString('en-IN')}
                    </td>

                    {/* Advance */}
                    <td
                      className={`p-3 border-r border-slate-200 text-right font-mono font-medium ${
                        r.advance < 0 ? 'text-rose-500' : r.advance > 0 ? 'text-emerald-600' : 'text-slate-500'
                      }`}
                    >
                      {r.advance !== 0 ? `₹${r.advance.toLocaleString('en-IN')}` : '₹0'}
                    </td>

                    {/* Total Salary (Net Payable) */}
                    <td className="p-3 border-r border-slate-200 text-right font-bold text-slate-900 bg-slate-50 font-mono">
                      ₹{r.totalSalary.toLocaleString('en-IN')}
                    </td>

                    {/* Remaining Advance */}
                    <td className="p-3 border-r border-slate-200 text-right font-mono text-slate-700">
                      ₹{r.remainingAdvance.toLocaleString('en-IN')}
                    </td>

                    {/* Daily Attendance Matrix (1..N) */}
                    {Array.from({ length: daysInMonth }, (_, i) => i + 1).map((day) => {
                      const code = r.dailyAttendance[day] || 'P';
                      let colorClass = 'text-emerald-600 font-bold';
                      let bgClass = '';
                      if (code === 'A') colorClass = 'text-rose-500 font-bold';
                      if (code === 'HD') colorClass = 'text-amber-600 font-bold';
                      if (code === 'H') {
                        colorClass = 'text-indigo-600 font-bold';
                        bgClass = 'bg-blue-50/80';
                      }

                      return (
                        <td key={day} className={`p-2 border-r border-slate-200 text-center ${bgClass}`}>
                          <span className={`text-[11px] ${colorClass}`}>
                            {code}
                          </span>
                        </td>
                      );
                    })}

                    {/* Edit Override Action */}
                    {!payrollMonth?.isFinalized && (
                      <td className="p-2 text-center">
                        <button
                          onClick={() => handleOpenEdit(r)}
                          className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Override Row Amounts"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>
                      </td>
                    )}
                  </tr>
                );
              })}
            </tbody>

            {/* Sheet Totals Footer */}
            <tfoot>
              <tr className="bg-slate-100 text-slate-800 font-bold border-t-2 border-slate-300">
                <td className="p-3 border-r border-slate-300 text-xs uppercase">TOTAL</td>
                <td className="p-3 sticky left-0 z-20 bg-slate-100 border-r border-slate-300 shadow-[1px_0_0_0_#cbd5e1] font-bold text-xs">
                  {filteredRows.length} Staff
                </td>
                <td className="p-3 border-r border-slate-300 text-right font-mono">
                  ₹{totals.baseSalary.toLocaleString('en-IN')}
                </td>
                <td className="p-3 border-r border-slate-300 text-center">{totals.leaveAccrued}</td>
                <td className="p-3 border-r border-slate-300 text-center text-rose-600">{totals.leavesTaken}</td>
                <td className="p-3 border-r border-slate-300 text-center">{totals.leavesBalance}</td>
                <td className="p-3 border-r border-slate-300 text-right text-rose-600 font-mono">
                  ₹{totals.salaryDeducted.toLocaleString('en-IN')}
                </td>
                <td className="p-3 border-r border-slate-300 text-center">{totals.carryForwardLeave}</td>
                <td className="p-3 border-r border-slate-300 text-right font-mono">
                  ₹{totals.salary.toLocaleString('en-IN')}
                </td>
                <td className="p-3 border-r border-slate-300 text-right font-mono">
                  ₹{totals.conveyance.toLocaleString('en-IN')}
                </td>
                <td className="p-3 border-r border-slate-300 text-right font-mono">
                  ₹{totals.advance.toLocaleString('en-IN')}
                </td>
                <td className="p-3 border-r border-slate-300 text-right text-slate-900 bg-slate-200/80 font-extrabold text-sm font-mono">
                  ₹{totals.totalSalary.toLocaleString('en-IN')}
                </td>
                <td className="p-3 border-r border-slate-300 text-right font-mono">
                  ₹{totals.remainingAdvance.toLocaleString('en-IN')}
                </td>
                <td colSpan={daysInMonth + 1} className="p-3 text-center text-slate-400 font-normal text-xs">
                  End of Payroll Matrix
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>

      {/* Manual Override Modal */}
      {editingRow && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200">
            <div className="flex items-center justify-between border-b pb-3">
              <div>
                <h3 className="font-bold text-slate-900 text-base">Override Payroll Row</h3>
                <p className="text-xs text-slate-500">
                  {editingRow.empName} ({editingRow.empCode})
                </p>
              </div>
              <button onClick={() => setEditingRow(null)} className="text-slate-400 hover:text-slate-600">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Salary Deducted (₹)</label>
                <input
                  type="number"
                  value={overrideSalaryDeducted}
                  onChange={(e) => setOverrideSalaryDeducted(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[10px] text-slate-400">Calculated based on excess absence days</span>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Conveyance Allowance (₹)</label>
                <input
                  type="number"
                  value={overrideConveyance}
                  onChange={(e) => setOverrideConveyance(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">
                  Advance Adjustment (₹)
                </label>
                <input
                  type="number"
                  value={overrideAdvance}
                  onChange={(e) => setOverrideAdvance(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
                />
                <span className="text-[10px] text-slate-400">
                  Positive for advance given, negative for advance recovery
                </span>
              </div>
            </div>

            <div className="pt-2 flex items-center justify-end space-x-2">
              <button
                type="button"
                onClick={() => setEditingRow(null)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSaveOverrides}
                className="px-4 py-2 bg-indigo-600 text-white rounded-lg text-xs font-semibold hover:bg-indigo-700 shadow"
              >
                Apply Overrides
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unlock Reason Modal */}
      {showUnlockModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
          <form
            onSubmit={handleUnlockSubmit}
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200 text-slate-800"
          >
            <div className="flex items-center space-x-3 text-rose-600 border-b pb-3">
              <Unlock className="w-5 h-5" />
              <h3 className="font-bold text-base text-slate-900">Unlock Payroll Month</h3>
            </div>

            <p className="text-xs text-slate-600">
              Unlocking will allow changes to attendance and payroll calculations for{' '}
              <strong>{payrollMonth?.displayMonth}</strong>. An audit log entry will be created.
            </p>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Reason for Unlocking</label>
              <textarea
                required
                rows={3}
                value={unlockReason}
                onChange={(e) => setUnlockReason(e.target.value)}
                placeholder="e.g. Correcting late attendance entry for Driver..."
                className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowUnlockModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-rose-600 text-white rounded-lg text-xs font-semibold hover:bg-rose-700 shadow"
              >
                Confirm Unlock
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
