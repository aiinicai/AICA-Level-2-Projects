import React, { useState } from 'react';
import { Employee, AdvanceRecord, LeaveRecord } from '../types';
import { Receipt, Plus, DollarSign, ArrowUpRight, ArrowDownRight, History, CreditCard, AlertCircle } from 'lucide-react';

interface LeaveAdvanceViewProps {
  employees: Employee[];
  advances: AdvanceRecord[];
  onAddAdvance: (data: Partial<AdvanceRecord>) => void;
  currentUser: Employee;
  selectedMonthStr: string;
}

export const LeaveAdvanceView: React.FC<LeaveAdvanceViewProps> = ({
  employees,
  advances,
  onAddAdvance,
  currentUser,
  selectedMonthStr,
}) => {
  const [showAdvanceModal, setShowAdvanceModal] = useState(false);
  const [selectedEmpId, setSelectedEmpId] = useState(employees[0]?.id || '');
  const [type, setType] = useState<'given' | 'recovery'>('given');
  const [amount, setAmount] = useState<number>(3000);
  const [notes, setNotes] = useState('');
  const [advanceDate, setAdvanceDate] = useState(new Date().toISOString().split('T')[0]);

  const handleAdvanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const month = advanceDate.slice(0, 7);
    onAddAdvance({
      empId: selectedEmpId,
      date: advanceDate,
      month,
      type,
      amount: Number(amount),
      notes,
    });
    setShowAdvanceModal(false);
    setAmount(3000);
    setNotes('');
  };

  // Compute Outstanding Advances per employee
  const visibleEmployees = employees.filter((e) =>
    currentUser.role === 'EMPLOYEE' ? e.id === currentUser.id : true
  );

  const empAdvanceBalances = visibleEmployees.map((emp) => {
    const empAdvs = advances.filter((a) => a.empId === emp.id);
    const given = empAdvs.filter((a) => a.type === 'given').reduce((sum, a) => sum + a.amount, 0);
    const recovered = empAdvs.filter((a) => a.type === 'recovery').reduce((sum, a) => sum + a.amount, 0);
    const outstanding = given - recovered;
    return { emp, given, recovered, outstanding, records: empAdvs };
  });

  const totalOutstandingAll = empAdvanceBalances.reduce((sum, item) => sum + item.outstanding, 0);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 font-bold">
            <Receipt className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold">Leave Accruals & Employee Advances Ledger</h2>
            <p className="text-xs text-slate-400">
              Track running leave balances, issue salary advances, and monitor monthly recoveries
            </p>
          </div>
        </div>

        {currentUser.role !== 'EMPLOYEE' && (
          <button
            onClick={() => setShowAdvanceModal(true)}
            className="px-4 py-2 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs shadow transition-all flex items-center space-x-2"
          >
            <Plus className="w-4 h-4" />
            <span>Record Advance / Recovery</span>
          </button>
        )}
      </div>

      {/* Overview Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            {currentUser.role === 'EMPLOYEE' ? 'My Active Advance Balance' : 'Total Active Advances'}
          </div>
          <div className="text-xl font-extrabold text-slate-900 mt-1">₹{totalOutstandingAll.toLocaleString('en-IN')}</div>
          <div className="text-[11px] text-slate-400 mt-0.5">
            {currentUser.role === 'EMPLOYEE' ? 'Your unrecovered salary advance' : 'Firm-wide unrecovered balance'}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Default Leave Accrual</div>
          <div className="text-xl font-extrabold text-indigo-600 mt-1">2 Days / Month</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Configurable per employee (e.g. Driver = 0)</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Leave Loss-Of-Pay Rule</div>
          <div className="text-xl font-extrabold text-rose-600 mt-1">Daily Base Deduction</div>
          <div className="text-[11px] text-slate-400 mt-0.5">Applied when running balance goes negative</div>
        </div>
      </div>

      {/* Employee Advances Summary Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200">
          <h3 className="font-bold text-slate-800 text-xs uppercase tracking-wider">
            Employee Advance Balances & Ledger
          </h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-900 text-slate-200 font-semibold border-b border-slate-800">
                <th className="p-3">Employee</th>
                <th className="p-3 text-right">Total Advance Given (+)</th>
                <th className="p-3 text-right">Total Recovered (-)</th>
                <th className="p-3 text-right">Remaining Balance</th>
                <th className="p-3">Recent Notes / History</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {empAdvanceBalances.map(({ emp, given, recovered, outstanding, records }) => (
                <tr key={emp.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-3 font-bold text-slate-900">
                    {emp.name}
                    <div className="text-[10px] text-slate-400 font-normal">{emp.empCode} • {emp.branch}</div>
                  </td>

                  <td className="p-3 text-right font-semibold text-blue-600">
                    ₹{given.toLocaleString('en-IN')}
                  </td>

                  <td className="p-3 text-right font-semibold text-emerald-600">
                    ₹{recovered.toLocaleString('en-IN')}
                  </td>

                  <td className="p-3 text-right font-extrabold text-slate-900">
                    <span
                      className={`px-2.5 py-1 rounded-lg ${
                        outstanding > 0
                          ? 'bg-purple-100 text-purple-800 border border-purple-200'
                          : 'bg-slate-100 text-slate-600'
                      }`}
                    >
                      ₹{outstanding.toLocaleString('en-IN')}
                    </span>
                  </td>

                  <td className="p-3 text-slate-600">
                    {records.length > 0 ? (
                      <div className="space-y-1">
                        {records.slice(-2).map((r) => (
                          <div key={r.id} className="text-[11px] flex items-center space-x-2">
                            <span
                              className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                r.type === 'given' ? 'bg-blue-100 text-blue-800' : 'bg-emerald-100 text-emerald-800'
                              }`}
                            >
                              {r.type === 'given' ? '+ Given' : '- Recovered'}
                            </span>
                            <span className="font-semibold text-slate-800">₹{r.amount}</span>
                            <span className="text-slate-400">({r.date})</span>
                            <span className="text-slate-500 italic truncate max-w-[150px]">{r.notes}</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-slate-400 italic">No advances recorded</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal for Recording Advance */}
      {showAdvanceModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm p-4">
          <form
            onSubmit={handleAdvanceSubmit}
            className="bg-white rounded-2xl shadow-2xl max-w-md w-full p-6 space-y-4 border border-slate-200 text-slate-800"
          >
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="font-bold text-slate-900 text-base">Record Advance Transaction</h3>
              <button
                type="button"
                onClick={() => setShowAdvanceModal(false)}
                className="text-slate-400 hover:text-slate-600"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block font-semibold text-slate-700 mb-1">Select Employee</label>
                <select
                  value={selectedEmpId}
                  onChange={(e) => setSelectedEmpId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg text-xs font-semibold"
                >
                  {employees.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.name} ({e.empCode}) - {e.branch}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Transaction Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setType('given')}
                    className={`py-2 px-3 rounded-lg font-bold border transition-all text-xs ${
                      type === 'given'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-300'
                    }`}
                  >
                    + Advance Given
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('recovery')}
                    className={`py-2 px-3 rounded-lg font-bold border transition-all text-xs ${
                      type === 'recovery'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-sm'
                        : 'bg-slate-50 text-slate-700 border-slate-300'
                    }`}
                  >
                    - Advance Recovery
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Amount (₹)</label>
                <input
                  required
                  type="number"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg font-bold text-slate-900"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Date</label>
                <input
                  type="date"
                  value={advanceDate}
                  onChange={(e) => setAdvanceDate(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block font-semibold text-slate-700 mb-1">Notes / Purpose</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Travel allowance for outstation client audit..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t">
              <button
                type="button"
                onClick={() => setShowAdvanceModal(false)}
                className="px-4 py-2 border border-slate-300 text-slate-700 rounded-lg text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-purple-600 text-white rounded-lg text-xs font-bold hover:bg-purple-700 shadow"
              >
                Save Transaction
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
