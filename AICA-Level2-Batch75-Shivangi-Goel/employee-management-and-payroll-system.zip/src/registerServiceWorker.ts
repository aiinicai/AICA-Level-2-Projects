export function registerServiceWorker() {
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker
        .register('/sw.js')
        .then((registration) => {
          console.log('[PWA] ServiceWorker registered with scope:', registration.scope);

          // Force update check on register
          registration.update().catch(() => {});

          // Whenever new service worker is found
          registration.addEventListener('updatefound', () => {
            const installingWorker = registration.installing;
            if (installingWorker) {
              installingWorker.onstatechange = () => {
                if (installingWorker.state === 'installed' && navigator.serviceWorker.controller) {
                  console.log('[PWA] New version available! Activating immediately...');
                  installingWorker.postMessage({ type: 'SKIP_WAITING' });
                }
              };
            }
          });

          // Re-check for updates every time the user opens or focuses the tab
          const checkForUpdates = () => {
            registration.update().catch(() => {});
          };

          window.addEventListener('focus', checkForUpdates);
          document.addEventListener('visibilitychange', () => {
            if (document.visibilityState === 'visible') {
              checkForUpdates();
            }
          });
        })
        .catch((error) => {
          console.error('[PWA] ServiceWorker registration failed:', error);
        });

      // Reload page when new service worker takes over to apply latest changes seamlessly
      let refreshing = false;
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        if (!refreshing) {
          refreshing = true;
          console.log('[PWA] Service worker updated! Reloading for latest changes...');
          window.location.reload();
        }
      });
    });
  }
}

