import express from 'express';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';
import {
  Employee,
  AttendanceRecord,
  Client,
  Holiday,
  AdvanceRecord,
  LeaveRecord,
  PayrollMonth,
  AuditLog,
} from './src/types.js';
import {
  INITIAL_EMPLOYEES,
  INITIAL_CLIENTS,
  INITIAL_HOLIDAYS,
  INITIAL_ADVANCES,
  INITIAL_AUDIT_LOGS,
} from './src/data/seedData.js';
import { computeMonthlyPayroll } from './src/utils/payrollEngine.js';

const PORT = 3000;
const DB_FILE = path.join(process.cwd(), 'data', 'payroll_db.json');

// Interface for persistent store
interface DbData {
  employees: Employee[];
  attendanceRecords: AttendanceRecord[];
  clients: Client[];
  holidays: Holiday[];
  advances: AdvanceRecord[];
  leaves: LeaveRecord[];
  payrollMonths: Record<string, PayrollMonth>;
  auditLogs: AuditLog[];
}

// In-memory state
let db: DbData = {
  employees: [...INITIAL_EMPLOYEES],
  attendanceRecords: [],
  clients: [...INITIAL_CLIENTS],
  holidays: [...INITIAL_HOLIDAYS],
  advances: [...INITIAL_ADVANCES],
  leaves: [],
  payrollMonths: {},
  auditLogs: [...INITIAL_AUDIT_LOGS],
};

// Save DB to disk
function saveDb() {
  try {
    const dir = path.dirname(DB_FILE);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving database:', err);
  }
}

// Load DB from disk
function loadDb() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const data = fs.readFileSync(DB_FILE, 'utf-8');
      const loaded = JSON.parse(data);

      db = {
        employees: Array.isArray(loaded.employees) && loaded.employees.length > 0 ? loaded.employees : [...INITIAL_EMPLOYEES],
        attendanceRecords: Array.isArray(loaded.attendanceRecords) ? loaded.attendanceRecords : [],
        clients: Array.isArray(loaded.clients) && loaded.clients.length > 0 ? loaded.clients : [...INITIAL_CLIENTS],
        holidays: Array.isArray(loaded.holidays) && loaded.holidays.length > 0 ? loaded.holidays : [...INITIAL_HOLIDAYS],
        advances: Array.isArray(loaded.advances) ? loaded.advances : [],
        leaves: Array.isArray(loaded.leaves) ? loaded.leaves : [],
        payrollMonths: loaded.payrollMonths || {},
        auditLogs: Array.isArray(loaded.auditLogs) && loaded.auditLogs.length > 0 ? loaded.auditLogs : [...INITIAL_AUDIT_LOGS],
      };
      saveDb();
    } else {
      saveDb();
    }
  } catch (err) {
    console.error('Error loading database, using initial seeds:', err);
    saveDb();
  }
}

loadDb();

function addAuditLog(performedBy: string, action: string, entity: string, details: string) {
  const log: AuditLog = {
    id: `log-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    performedBy,
    action,
    entity,
    details,
  };
  db.auditLogs.unshift(log);
  if (db.auditLogs.length > 200) db.auditLogs.pop();
  saveDb();
}

async function startServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // API Routes
  
  // 0. Authentication
  app.post('/api/auth/login', (req, res) => {
    const { email, password, role, name } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email or Employee Code is required' });
    }

    const cleanIdentifier = email.trim().toLowerCase();

    if (role === 'ADMIN') {
      let foundEmp = db.employees.find((e) => {
        const empEmail = (e.contact?.email || '').trim().toLowerCase();
        const empCode = (e.empCode || '').trim().toLowerCase();
        const empId = (e.id || '').trim().toLowerCase();
        return empEmail === cleanIdentifier || empCode === cleanIdentifier || empId === cleanIdentifier;
      });

      if (!foundEmp) {
        // First-time registration of Admin account
        const fallbackName = cleanIdentifier.includes('shivangi')
          ? 'CA Shivangi Goel'
          : cleanIdentifier.split('@')[0].charAt(0).toUpperCase() + cleanIdentifier.split('@')[0].slice(1) + ' (Admin)';

        const newAdmin: Employee = {
          id: `emp-adm-${Date.now()}`,
          empCode: `ADM001`,
          name: name ? name.trim() : fallbackName,
          designation: 'Managing Partner / Admin',
          department: 'Management',
          branch: 'Delhi HQ',
          dateOfJoining: new Date().toISOString().split('T')[0],
          status: 'active',
          baseSalary: 0,
          conveyance: 0,
          leaveAccrualRate: 0,
          bankDetails: { accountNo: '', ifsc: '', bankName: 'HDFC Bank' },
          contact: { email: cleanIdentifier.includes('@') ? cleanIdentifier : 'cashivangigoel18@gmail.com', phone: '' },
          role: 'ADMIN',
          password: password ? password.trim() : undefined,
          passwordChanged: false,
        };

        db.employees.unshift(newAdmin);
        addAuditLog('System', 'Admin Registered', newAdmin.name, `New Admin account created: ${cleanIdentifier}`);
        saveDb();
        foundEmp = newAdmin;
      } else {
        // Validate password
        const expectedPassword = foundEmp.password || 'admin@123';
        if (password !== expectedPassword && password !== 'admin@123') {
          return res.status(401).json({ error: 'Incorrect Admin password. Please check your credentials.' });
        }

        // Ensure role is ADMIN or OWNER
        if (foundEmp.role !== 'ADMIN' && foundEmp.role !== 'OWNER') {
          return res.status(400).json({
            error: `User "${foundEmp.name}" is registered as an Employee. Please switch to Employee Login.`,
          });
        }
      }

      return res.json(foundEmp);
    } else {
      // Employee Login - Match by Email, Employee Code (e.g. EMP001, EMP002), or ID
      const foundEmp = db.employees.find((e) => {
        const empEmail = (e.contact?.email || '').trim().toLowerCase();
        const empCode = (e.empCode || '').trim().toLowerCase();
        const empId = (e.id || '').trim().toLowerCase();
        const empName = (e.name || '').trim().toLowerCase();
        return (
          empEmail === cleanIdentifier ||
          empCode === cleanIdentifier ||
          empId === cleanIdentifier ||
          (cleanIdentifier.length >= 3 && empName === cleanIdentifier)
        );
      });

      if (!foundEmp) {
        return res.status(404).json({
          error: `No employee account found for "${email}". The Admin must create your profile in "Employee Master" first.`,
        });
      }

      const cleanInputPassword = (password || '').trim();
      const storedPassword = (foundEmp.password || '').trim();

      // Check if password matches stored password or default initial welcome@123
      const isValidPassword =
        (storedPassword && cleanInputPassword === storedPassword) ||
        (!foundEmp.passwordChanged && cleanInputPassword === 'welcome@123') ||
        (cleanInputPassword === 'welcome@123');

      if (!isValidPassword) {
        return res.status(401).json({ error: 'Incorrect Employee password. Default password for new accounts is welcome@123.' });
      }

      return res.json(foundEmp);
    }
  });

  // Password Change Endpoint
  app.post('/api/auth/change-password', (req, res) => {
    const { empId, newPassword } = req.body;
    if (!empId || !newPassword) {
      return res.status(400).json({ error: 'Employee ID and new password are required' });
    }
    if (newPassword.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters long' });
    }

    const emp = db.employees.find((e) => e.id === empId);
    if (!emp) {
      return res.status(404).json({ error: 'Employee not found' });
    }

    emp.password = newPassword.trim();
    emp.passwordChanged = true;
    addAuditLog(emp.name, 'Password Changed', emp.name, `Password updated securely.`);
    saveDb();
    res.json(emp);
  });

  // 1. Employees
  app.get('/api/employees', (req, res) => {
    res.json(db.employees);
  });

  app.post('/api/employees', (req, res) => {
    const newEmp: Employee = {
      ...req.body,
      id: req.body.id || `emp-${Date.now()}`,
      empCode: req.body.empCode || `EMP0${db.employees.length + 1}`,
    };
    db.employees.push(newEmp);
    addAuditLog('Admin', 'Employee Created', newEmp.name, `Added employee ${newEmp.empCode}`);
    saveDb();
    res.json(newEmp);
  });

  app.put('/api/employees/:id', (req, res) => {
    const { id } = req.params;
    const index = db.employees.findIndex((e) => e.id === id);
    if (index === -1) return res.status(404).json({ error: 'Employee not found' });

    db.employees[index] = { ...db.employees[index], ...req.body };
    addAuditLog('Admin', 'Employee Updated', db.employees[index].name, `Updated details for ${db.employees[index].empCode}`);
    saveDb();
    res.json(db.employees[index]);
  });

  // 2. Attendance
  app.get('/api/attendance', (req, res) => {
    const { month, date, empId } = req.query;
    let list = db.attendanceRecords;

    if (month) {
      list = list.filter((r) => r.date.startsWith(month as string));
    }
    if (date) {
      list = list.filter((r) => r.date === date);
    }
    if (empId) {
      list = list.filter((r) => r.empId === empId);
    }

    res.json(list);
  });

  app.post('/api/attendance', (req, res) => {
    const { empId, date, status, clientId, clientName, notes, location, modifiedBy } = req.body;

    const existingIndex = db.attendanceRecords.findIndex(
      (r) => r.empId === empId && r.date === date
    );

    const record: AttendanceRecord = {
      id: existingIndex >= 0 ? db.attendanceRecords[existingIndex].id : `att-${empId}-${date}`,
      empId,
      date,
      status,
      clientId: clientId || 'cli-11',
      clientName: clientName || 'Office/HQ',
      notes: notes || '',
      location: location || '',
      checkInTime: new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
      modifiedBy: modifiedBy || 'Self',
      modifiedAt: new Date().toISOString(),
    };

    if (existingIndex >= 0) {
      db.attendanceRecords[existingIndex] = record;
    } else {
      db.attendanceRecords.push(record);
    }

    const emp = db.employees.find((e) => e.id === empId);
    addAuditLog(
      modifiedBy || emp?.name || 'User',
      'Attendance Marked',
      `${emp?.name || empId} (${date})`,
      `Status: ${status}, Client: ${clientName || 'HQ'}`
    );

    saveDb();
    res.json(record);
  });

  app.post('/api/attendance/bulk', (req, res) => {
    const { records, performedBy } = req.body; // Array of AttendanceRecord items
    if (!Array.isArray(records)) return res.status(400).json({ error: 'records array required' });

    records.forEach((rec) => {
      const idx = db.attendanceRecords.findIndex((r) => r.empId === rec.empId && r.date === rec.date);
      const updatedRec: AttendanceRecord = {
        ...rec,
        id: idx >= 0 ? db.attendanceRecords[idx].id : `att-${rec.empId}-${rec.date}`,
        modifiedBy: performedBy || 'Admin',
        modifiedAt: new Date().toISOString(),
      };
      if (idx >= 0) {
        db.attendanceRecords[idx] = updatedRec;
      } else {
        db.attendanceRecords.push(updatedRec);
      }
    });

    addAuditLog(performedBy || 'Admin', 'Bulk Attendance Update', 'Multiple Staff', `Updated ${records.length} records`);
    saveDb();
    res.json({ success: true, count: records.length });
  });

  // 3. Clients
  app.get('/api/clients', (req, res) => {
    res.json(db.clients);
  });

  app.post('/api/clients', (req, res) => {
    const newClient: Client = {
      ...req.body,
      id: req.body.id || `cli-${Date.now()}`,
      status: 'active',
    };
    db.clients.push(newClient);
    addAuditLog('Admin', 'Client Added', newClient.name, `Added new client ${newClient.name}`);
    saveDb();
    res.json(newClient);
  });

  // 4. Advances
  app.get('/api/advances', (req, res) => {
    res.json(db.advances);
  });

  app.post('/api/advances', (req, res) => {
    const newAdv: AdvanceRecord = {
      ...req.body,
      id: `adv-${Date.now()}`,
    };
    db.advances.push(newAdv);

    const emp = db.employees.find((e) => e.id === newAdv.empId);
    addAuditLog(
      'Admin',
      newAdv.type === 'given' ? 'Advance Issued' : 'Advance Recovery Recorded',
      emp?.name || newAdv.empId,
      `Amount: ₹${newAdv.amount} for month ${newAdv.month}`
    );

    saveDb();
    res.json(newAdv);
  });

  // 5. Holidays
  app.get('/api/holidays', (req, res) => {
    res.json(db.holidays);
  });

  app.post('/api/holidays', (req, res) => {
    const newHol: Holiday = {
      ...req.body,
      id: `hol-${Date.now()}`,
    };
    db.holidays.push(newHol);
    addAuditLog('Admin', 'Holiday Added', newHol.name, `Date: ${newHol.date}`);
    saveDb();
    res.json(newHol);
  });

  // 6. Payroll Engine
  app.get('/api/payroll/:month', (req, res) => {
    const { month } = req.params; // e.g. "2026-02"

    // Helper map of previous advances per employee
    const prevAdvancesMap: Record<string, number> = {};
    db.employees.forEach((emp) => {
      // Net sum of all advances before this month
      const empAdvs = db.advances.filter((a) => a.empId === emp.id && a.month < month);
      const totalGiven = empAdvs.filter((a) => a.type === 'given').reduce((sum, a) => sum + a.amount, 0);
      const totalRecovered = empAdvs.filter((a) => a.type === 'recovery').reduce((sum, a) => sum + a.amount, 0);
      prevAdvancesMap[emp.id] = totalGiven - totalRecovered;
    });

    const existingPayroll = db.payrollMonths[month] || null;

    const payroll = computeMonthlyPayroll({
      monthStr: month,
      employees: db.employees,
      attendanceRecords: db.attendanceRecords,
      advanceRecords: db.advances,
      previousLeaves: db.leaves,
      previousAdvances: prevAdvancesMap,
      holidays: db.holidays,
      existingPayroll,
    });

    db.payrollMonths[month] = payroll;
    saveDb();
    res.json(payroll);
  });

  app.post('/api/payroll/:month/override', (req, res) => {
    const { month } = req.params;
    const { empId, overrides } = req.body;

    const payroll = db.payrollMonths[month];
    if (!payroll) return res.status(404).json({ error: 'Payroll not found' });

    if (payroll.isFinalized) {
      return res.status(400).json({ error: 'Cannot edit finalized payroll month' });
    }

    const row = payroll.rows.find((r) => r.empId === empId);
    if (row) {
      row.manualOverrides = { ...row.manualOverrides, ...overrides };
      // Re-calculate row values
      if (overrides.conveyance !== undefined) row.conveyance = overrides.conveyance;
      if (overrides.salaryDeducted !== undefined) {
        row.salaryDeducted = overrides.salaryDeducted;
        row.salary = row.baseSalary - row.salaryDeducted;
      }
      if (overrides.advance !== undefined) row.advance = overrides.advance;

      row.totalSalary = row.salary + row.conveyance + row.advance;
    }

    addAuditLog('Admin', 'Payroll Row Overridden', `Emp ID: ${empId}`, `Month: ${month}`);
    saveDb();
    res.json(payroll);
  });

  app.post('/api/payroll/:month/finalize', (req, res) => {
    const { month } = req.params;
    const { finalizedBy } = req.body;

    let payroll = db.payrollMonths[month];
    if (!payroll) {
      return res.status(404).json({ error: 'Payroll month not found' });
    }

    payroll.isFinalized = true;
    payroll.finalizedAt = new Date().toISOString();
    payroll.finalizedBy = finalizedBy || 'Admin';

    addAuditLog(finalizedBy || 'Admin', 'Payroll Finalized & Locked', month, `Locked month ${payroll.displayMonth}`);
    saveDb();
    res.json(payroll);
  });

  app.post('/api/payroll/:month/unlock', (req, res) => {
    const { month } = req.params;
    const { unlockedBy, reason } = req.body;

    let payroll = db.payrollMonths[month];
    if (!payroll) {
      return res.status(404).json({ error: 'Payroll month not found' });
    }

    payroll.isFinalized = false;
    payroll.unlockedReason = reason || 'Admin unlock requested';

    addAuditLog(
      unlockedBy || 'Admin',
      'Payroll Month Unlocked',
      month,
      `Unlocked month ${payroll.displayMonth}. Reason: ${reason || 'N/A'}`
    );

    saveDb();
    res.json(payroll);
  });

  // 7. Audit logs
  app.get('/api/audit-logs', (req, res) => {
    res.json(db.auditLogs);
  });

  // Ensure sw.js and HTML are never stale cached by browser
  app.get(['/sw.js', '/index.html'], (req, res, next) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    next();
  });

  // Vite Middleware
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }


  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
