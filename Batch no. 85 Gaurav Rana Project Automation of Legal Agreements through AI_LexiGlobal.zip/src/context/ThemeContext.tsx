import React, { createContext, useContext, useState, useEffect } from 'react';
import { AppTheme } from '../types';

export interface ThemeOption {
  id: AppTheme;
  name: string;
  tagline: string;
  previewBg: string;
  previewCard: string;
  previewAccent: string;
  iconName: string;
}

export const THEME_OPTIONS: ThemeOption[] = [
  {
    id: 'dark',
    name: 'Obsidian Dark',
    tagline: 'Deep midnight obsidian with emerald & cyan bento glows',
    previewBg: '#09090b',
    previewCard: '#18181b',
    previewAccent: '#10b981',
    iconName: 'Moon'
  },
  {
    id: 'light',
    name: 'Executive Light',
    tagline: 'Crisp corporate slate for daylight drafting & legal review',
    previewBg: '#f8fafc',
    previewCard: '#ffffff',
    previewAccent: '#059669',
    iconName: 'Sun'
  },
  {
    id: 'parchment',
    name: 'Warm Parchment',
    tagline: 'Ivory heritage stationery with warm charcoal & brass tones',
    previewBg: '#f7f4ed',
    previewCard: '#fffefb',
    previewAccent: '#d97706',
    iconName: 'BookOpen'
  },
  {
    id: 'navy',
    name: 'Chambers Navy',
    tagline: 'Deep maritime sapphire with electric cyan & silver',
    previewBg: '#070d18',
    previewCard: '#0f1d33',
    previewAccent: '#38bdf8',
    iconName: 'Compass'
  }
];

interface ThemeContextType {
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  toggleDarkLight: () => void;
  isDark: boolean;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const STORAGE_KEY = 'lexiglobal_app_theme';

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<AppTheme>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved && (saved === 'dark' || saved === 'light' || saved === 'parchment' || saved === 'navy')) {
        return saved as AppTheme;
      }
    } catch {
      // ignore
    }
    return 'dark';
  });

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, theme);
    } catch {
      // ignore
    }

    const root = document.documentElement;
    root.setAttribute('data-theme', theme);
    
    // Manage html class for Tailwind or base styles
    if (theme === 'light' || theme === 'parchment') {
      root.classList.remove('dark');
      root.classList.add('light');
    } else {
      root.classList.remove('light');
      root.classList.add('dark');
    }
  }, [theme]);

  const setTheme = (newTheme: AppTheme) => {
    setThemeState(newTheme);
  };

  const toggleDarkLight = () => {
    setThemeState(prev => (prev === 'light' || prev === 'parchment' ? 'dark' : 'light'));
  };

  const isDark = theme === 'dark' || theme === 'navy';

  return (
    <ThemeContext.Provider value={{ theme, setTheme, toggleDarkLight, isDark }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
