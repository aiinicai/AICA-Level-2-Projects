import { JurisdictionConfig } from '../types';

export const GLOBAL_JURISDICTIONS: JurisdictionConfig[] = [
  {
    countryCode: 'US',
    countryName: 'United States',
    statesOrProvinces: ['Delaware', 'California', 'New York', 'Texas', 'Washington', 'Illinois', 'Florida', 'Massachusetts'],
    defaultGoverningLaw: 'Laws of the State of Delaware (excluding conflict of law rules)',
    arbitrationInstitutions: [
      { name: 'American Arbitration Association (AAA)', city: 'New York, NY', rules: 'AAA Commercial Arbitration Rules' },
      { name: 'JAMS ADR', city: 'San Francisco, CA', rules: 'JAMS Comprehensive Arbitration Rules' },
      { name: 'International Centre for Dispute Resolution (ICDR)', city: 'New York, NY', rules: 'ICDR International Rules' }
    ],
    eSignatureStatute: 'Electronic Signatures in Global and National Commerce Act (E-SIGN Act, 15 U.S.C. § 7001) & Uniform Electronic Transactions Act (UETA)',
    mandatoryClauses: [
      'Entire Agreement / Merger Clause',
      'Severability and Waiver',
      'Specific Consequential Damages Disclaimer (UCC Article 2 disclaimer in bold caps)',
      'Jurisdiction & Choice of Law Venue Specification'
    ],
    restrictedClauses: [
      'Overly broad employee non-compete agreements (strictly prohibited/unenforceable in California pursuant to Cal. Bus. & Prof. Code § 16600, scrutinized under FTC guidelines)',
      'Pre-dispute jury trial waivers in California state courts',
      'Unconscionable adhesive arbitration clauses with one-sided cost shifting'
    ],
    keyRegulations: [
      'Uniform Commercial Code (UCC) Article 2',
      'California Consumer Privacy Act (CCPA / CPRA)',
      'Defend Trade Secrets Act (DTSA, 18 U.S.C. § 1836)',
      'Foreign Corrupt Practices Act (FCPA, 15 U.S.C. § 78dd-1)'
    ],
    currency: 'USD',
    currencySymbol: '$',
    notes: 'Delaware Chancery Court provides highly specialized corporate jurisprudence. US commercial contracts require express express disclaimers of implied warranties of merchantability and fitness in conspicuous lettering.'
  },
  {
    countryCode: 'IN',
    countryName: 'India',
    statesOrProvinces: ['Maharashtra (Mumbai)', 'Delhi (NCR)', 'Karnataka (Bengaluru)', 'Tamil Nadu (Chennai)', 'Telangana (Hyderabad)', 'Gujarat'],
    defaultGoverningLaw: 'Laws of the Republic of India',
    arbitrationInstitutions: [
      { name: 'Mumbai Centre for International Arbitration (MCIA)', city: 'Mumbai', rules: 'MCIA Arbitration Rules 2016' },
      { name: 'Delhi International Arbitration Centre (DIAC)', city: 'New Delhi', rules: 'DIAC Rules 2018' },
      { name: 'Indian Council of Arbitration (ICA)', city: 'New Delhi', rules: 'ICA Maritime & Commercial Rules' }
    ],
    eSignatureStatute: 'Information Technology Act, 2000 (Section 10A & Section 65B for electronic record admissibility) + Indian Stamp Act 1899',
    mandatoryClauses: [
      'Stamp Duty and Registration Compliance Undertaking',
      'Section 28 Indian Contract Act 1872 Compliance (no absolute restraint on legal proceedings)',
      'Tax Deduction at Source (TDS) and GST Compliance Clause',
      'Digital Personal Data Protection Act (DPDPA) 2023 Processing Addendum'
    ],
    restrictedClauses: [
      'Post-termination employee non-compete agreements (strictly void ab initio under Section 27 of the Indian Contract Act 1872)',
      'Agreements in restraint of marriage or legal proceedings (Sections 26 & 28)',
      'Unstamped commercial agreements requiring impounding under Stamp Act prior to judicial enforcement'
    ],
    keyRegulations: [
      'Indian Contract Act, 1872',
      'Arbitration and Conciliation Act, 1996 (as amended 2019/2021)',
      'Digital Personal Data Protection Act (DPDPA), 2023',
      'Foreign Exchange Management Act (FEMA), 1999',
      'Central Goods and Services Tax (CGST) Act, 2017'
    ],
    currency: 'INR',
    currencySymbol: '₹',
    notes: 'Indian law treats post-employment non-competes as strictly void under Section 27. Ensure contracts specify proper stamp duty payment and GST number representations.'
  },
  {
    countryCode: 'GB',
    countryName: 'United Kingdom',
    statesOrProvinces: ['England & Wales', 'Scotland', 'Northern Ireland'],
    defaultGoverningLaw: 'Laws of England and Wales',
    arbitrationInstitutions: [
      { name: 'London Court of International Arbitration (LCIA)', city: 'London', rules: 'LCIA Arbitration Rules 2020' },
      { name: 'Chartered Institute of Arbitrators (CIArb)', city: 'London', rules: 'CIArb Commercial Arbitration Rules' }
    ],
    eSignatureStatute: 'Electronic Communications Act 2000 & UK eIDAS Regulation (SI 2019/89)',
    mandatoryClauses: [
      'Contracts (Rights of Third Parties) Act 1999 Exclusion Clause',
      'Unfair Contract Terms Act 1977 (UCTA) Reasonableness Test Protection',
      'UK GDPR / Data Protection Act 2018 Article 28 Controller-Processor Mandates',
      'Bribery Act 2010 Section 7 Corporate Adequate Procedures Clause'
    ],
    restrictedClauses: [
      'Penalty clauses under Cavendish Square Holding BV v Talal El Makdessi [2015] (liquidated damages must protect legitimate business interest)',
      'Exclusion of liability for death, personal injury caused by negligence, or fraudulent misrepresentation (void under UCTA s.2(1))'
    ],
    keyRegulations: [
      'UK General Data Protection Regulation (UK GDPR)',
      'Bribery Act 2010',
      'Unfair Contract Terms Act 1977 (UCTA)',
      'Supply of Goods and Services Act 1982'
    ],
    currency: 'GBP',
    currencySymbol: '£',
    notes: 'English common law is widely chosen for international trade for predictability. Always expressly exclude Third Party Rights under the 1999 Act unless intended.'
  },
  {
    countryCode: 'SG',
    countryName: 'Singapore',
    statesOrProvinces: ['Central Region', 'Jurong', 'Changi'],
    defaultGoverningLaw: 'Laws of the Republic of Singapore',
    arbitrationInstitutions: [
      { name: 'Singapore International Arbitration Centre (SIAC)', city: 'Singapore', rules: 'SIAC Rules 2024 / 7th Edition' },
      { name: 'Singapore Chamber of Maritime Arbitration (SCMA)', city: 'Singapore', rules: 'SCMA Rules 2022' }
    ],
    eSignatureStatute: 'Electronic Transactions Act 2010 (ETA Cap. 88)',
    mandatoryClauses: [
      'Contracts (Rights of Third Parties) Act (Cap. 53B) Exclusion',
      'Personal Data Protection Act (PDPA 2012) Compliance Provisions',
      'International Arbitration Act (IAA Cap. 143A) SIAC Arbitration Model Clause',
      'Goods and Services Tax (GST) Act Compliance'
    ],
    restrictedClauses: [
      'Unreasonable restrictive covenants exceeding legitimate proprietary interests under Man Financial (S) Pte Ltd v Wong Bark Chuan David',
      'Exclusions of liability that fail the Singapore Unfair Contract Terms Act (UCTA) reasonableness test'
    ],
    keyRegulations: [
      'Personal Data Protection Act 2012 (PDPA)',
      'Singapore International Arbitration Act (Cap 143A)',
      'Unfair Contract Terms Act (Cap 396)',
      'Companies Act (Cap 50)'
    ],
    currency: 'SGD',
    currencySymbol: 'S$',
    notes: 'Premier Asia-Pacific hub. SIAC arbitration seat with expedited procedures is standard for multi-jurisdictional Southeast Asian commercial agreements.'
  },
  {
    countryCode: 'AE',
    countryName: 'United Arab Emirates (UAE)',
    statesOrProvinces: ['Dubai International Financial Centre (DIFC)', 'Abu Dhabi Global Market (ADGM)', 'Onshore Dubai', 'Onshore Abu Dhabi'],
    defaultGoverningLaw: 'DIFC Contract Law (DIFC Law No. 6 of 2004) or ADGM Common Law',
    arbitrationInstitutions: [
      { name: 'Dubai International Arbitration Centre (DIAC)', city: 'Dubai', rules: 'DIAC Arbitration Rules 2022' },
      { name: 'ADGM Arbitration Centre', city: 'Abu Dhabi', rules: 'ADGM Arbitration Regulations 2015' }
    ],
    eSignatureStatute: 'Federal Decree-Law No. 46 of 2021 on Electronic Transactions and Trust Services & DIFC Electronic Transactions Law',
    mandatoryClauses: [
      'Clear specification of Free Zone (DIFC/ADGM Common Law) vs UAE Federal Onshore Civil Code',
      'UAE Federal Decree-Law No. 45 of 2021 (Personal Data Protection) Processing Provisions',
      'Corporate Tax Federal Decree-Law No. 47 of 2022 Representation',
      'Dual Language / Arabic Translation Precedence disclaimer for onshore filings'
    ],
    restrictedClauses: [
      'Uncapped compound interest exceeding UAE Central Bank / Commercial Code statutory ceilings in onshore disputes',
      'Arbitration agreements lacking specific corporate board authorization under UAE Civil Procedures Law'
    ],
    keyRegulations: [
      'UAE Civil Code (Federal Law No. 5 of 1985)',
      'UAE Commercial Transactions Law (Federal Decree-Law No. 50 of 2022)',
      'DIFC Law No. 6 of 2004 (Contract Law)',
      'Federal Decree-Law No. 45 of 2021 on Personal Data Protection'
    ],
    currency: 'AED',
    currencySymbol: 'AED ',
    notes: 'DIFC and ADGM offer English common law jurisdictions within UAE. Onshore UAE civil code applies good faith principles (Article 246) and allows courts to re-adjust liquidated damages.'
  },
  {
    countryCode: 'AU',
    countryName: 'Australia',
    statesOrProvinces: ['New South Wales (Sydney)', 'Victoria (Melbourne)', 'Queensland (Brisbane)', 'Western Australia (Perth)'],
    defaultGoverningLaw: 'Laws of New South Wales, Australia',
    arbitrationInstitutions: [
      { name: 'Australian Centre for International Commercial Arbitration (ACICA)', city: 'Sydney', rules: 'ACICA Arbitration Rules 2021' }
    ],
    eSignatureStatute: 'Electronic Transactions Act 1999 (Cth) & State Electronic Transactions Acts + Corporations Amendment (Meetings and Documents) Act 2022 (s.126/s.127 execution)',
    mandatoryClauses: [
      'Australian Consumer Law (ACL - Schedule 2 Competition and Consumer Act 2010) Non-Exclusion of Statutory Guarantees',
      'Privacy Act 1988 (Cth) and Australian Privacy Principles (APPs)',
      'Section 127 Corporations Act 2001 Formal Execution Clause',
      'Goods and Services Tax (GST - A New Tax System Act 1999) Clause'
    ],
    restrictedClauses: [
      'Unfair Contract Terms (UCT) in standard form consumer or small business contracts (Treasury Laws Amendment Act 2022 introduces heavy civil penalties)',
      'Attempting to exclude non-excludable statutory guarantees under ACL s.64'
    ],
    keyRegulations: [
      'Competition and Consumer Act 2010 (Schedule 2 ACL)',
      'Corporations Act 2001 (Cth)',
      'Privacy Act 1988 (Cth)',
      'International Arbitration Act 1974 (Cth)'
    ],
    currency: 'AUD',
    currencySymbol: 'A$',
    notes: 'Strict Unfair Contract Terms (UCT) regime now imposes severe statutory civil penalties for standard form contracts with unfair clauses.'
  },
  {
    countryCode: 'DE',
    countryName: 'Germany (European Union)',
    statesOrProvinces: ['Bavaria (Munich)', 'Hesse (Frankfurt)', 'North Rhine-Westphalia', 'Berlin', 'Baden-Württemberg'],
    defaultGoverningLaw: 'Laws of the Federal Republic of Germany (BGB / HGB)',
    arbitrationInstitutions: [
      { name: 'German Arbitration Institute (DIS)', city: 'Frankfurt / Berlin', rules: 'DIS Arbitration Rules 2018' },
      { name: 'International Chamber of Commerce (ICC)', city: 'Paris / Frankfurt', rules: 'ICC Arbitration Rules 2021' }
    ],
    eSignatureStatute: 'EU eIDAS Regulation (Regulation (EU) No 910/2014) & German Trust Services Act (Vertrauensdienstegesetz - VDG)',
    mandatoryClauses: [
      'General Terms and Conditions Control (AGB-Recht §§ 305-310 BGB) Compliance',
      'EU General Data Protection Regulation (GDPR / DSGVO Art. 28) Data Processing Agreement (DPA)',
      'Standard Limitation of Liability Clause (Exclusion of Simple Negligence only for Non-Essential Cardinal Duties)',
      'Exclusion of UN Convention on Contracts for the International Sale of Goods (CISG)'
    ],
    restrictedClauses: [
      'Blanket exclusion of liability for ordinary negligence violating § 307 BGB (AGB scrutiny is applied strictly even in B2B transactions)',
      'Unilateral modification rights without objectively justified grounds',
      'Unreasonable limitation of warranty periods below statutory limits under AGB rules'
    ],
    keyRegulations: [
      'Bürgerliches Gesetzbuch (BGB - German Civil Code)',
      'Handelsgesetzbuch (HGB - Commercial Code)',
      'EU GDPR (Regulation EU 2016/679)',
      'Gesetz gegen unlauteren Wettbewerb (UWG)'
    ],
    currency: 'EUR',
    currencySymbol: '€',
    notes: 'German standard terms (AGB) law heavily restricts limitation of liability in B2B standard contracts. Cardinal duties (Kardinalpflichten) cannot be disclaimed.'
  },
  {
    countryCode: 'CA',
    countryName: 'Canada',
    statesOrProvinces: ['Ontario (Toronto)', 'British Columbia (Vancouver)', 'Alberta (Calgary)', 'Quebec (Civil Law)'],
    defaultGoverningLaw: 'Laws of the Province of Ontario and the federal laws of Canada applicable therein',
    arbitrationInstitutions: [
      { name: 'VanIAC (Vancouver International Arbitration Centre)', city: 'Vancouver', rules: 'VanIAC Domestic & International Rules' },
      { name: 'ADR Institute of Canada (ADRIC)', city: 'Toronto', rules: 'ADRIC Arbitration Rules' }
    ],
    eSignatureStatute: 'Personal Information Protection and Electronic Documents Act (PIPEDA) & Ontario Electronic Commerce Act (ECA 2000)',
    mandatoryClauses: [
      'PIPEDA & Provincial Privacy Compliance Clause',
      'Harmonized Sales Tax (HST) / GST / QST Clause',
      'Bilingual Language Clause (Quebec Charter of the French Language Bill 96 waiver if English chosen)',
      'Good Faith Performance Undertaking (Bhasin v Hrynew [2014] SCC 71)'
    ],
    restrictedClauses: [
      'Unreasonable restrictive covenants in employment contexts under Shafron v KRG Insurance Brokers',
      'Exclusions of liability acting in bad faith contrary to Canadian supreme court common law doctrine of honest contractual performance'
    ],
    keyRegulations: [
      'Personal Information Protection and Electronic Documents Act (PIPEDA)',
      'Competition Act (R.S.C., 1985, c. C-34)',
      'Canada Business Corporations Act (CBCA)',
      'Quebec Civil Code (for Quebec transactions)'
    ],
    currency: 'CAD',
    currencySymbol: 'CA$',
    notes: 'Supreme Court of Canada in Bhasin v Hrynew established an organizing principle of good faith and duty of honest contractual performance in all commercial contracts.'
  },
  {
    countryCode: 'FR',
    countryName: 'France',
    statesOrProvinces: ['Île-de-France (Paris)', 'Auvergne-Rhône-Alpes', 'Provence-Alpes-Côte d\'Azur'],
    defaultGoverningLaw: 'Laws of the French Republic (Code Civil)',
    arbitrationInstitutions: [
      { name: 'International Chamber of Commerce (ICC)', city: 'Paris', rules: 'ICC Arbitration Rules 2021' },
      { name: 'Paris Arbitration Centre (CMAP)', city: 'Paris', rules: 'CMAP Rules' }
    ],
    eSignatureStatute: 'EU eIDAS Regulation (Regulation (EU) No 910/2014) & French Civil Code (Articles 1366 & 1367)',
    mandatoryClauses: [
      'Good Faith Undertaking (Article 1104 French Civil Code - public order, cannot be excluded)',
      'Hardship Clause (Article 1195 French Civil Code - Imprévision negotiation procedure)',
      'EU GDPR Article 28 Data Processing Provisions',
      'Toubon Law Compliance (French language requirement for public/employment matters)'
    ],
    restrictedClauses: [
      'Significant imbalance clauses (Déséquilibre significatif - Article 1171 Civil Code & Article L. 442-1 Commercial Code)',
      'Limitation of liability clauses depriving essential obligation of substance (Article 1170 Chronopost doctrine)'
    ],
    keyRegulations: [
      'French Civil Code (Code Civil des Français)',
      'French Commercial Code (Code de Commerce)',
      'EU GDPR',
      'Law No. 94-665 (Toubon Law)'
    ],
    currency: 'EUR',
    currencySymbol: '€',
    notes: 'Article 1104 (Good faith) is of public policy in France. Article 1195 allows court revision for economic hardship unless contract expressly waives hardship renegotiation.'
  },
  {
    countryCode: 'JP',
    countryName: 'Japan',
    statesOrProvinces: ['Tokyo', 'Osaka', 'Aichi (Nagoya)', 'Fukuoka'],
    defaultGoverningLaw: 'Laws of Japan (Minpō / Commercial Code)',
    arbitrationInstitutions: [
      { name: 'Japan Commercial Arbitration Association (JCAA)', city: 'Tokyo', rules: 'JCAA Commercial Arbitration Rules 2021' }
    ],
    eSignatureStatute: 'Electronic Signatures and Certification Services Act (Act No. 102 of 2000)',
    mandatoryClauses: [
      'Anti-Social Forces Exclusion Clause (Boryokudan Exclusion Clause - JCAA / Police Agency mandated)',
      'Act on the Protection of Personal Information (APPI) Data Protection Safeguards',
      'Consumption Tax Act (10% standard rate) Specification',
      'Good Faith Consultation Clause (Kyogi Clause)'
    ],
    restrictedClauses: [
      'Contractual terms violating the Subcontract Act (Shitauke-ho) regarding payment periods (>60 days) and unjust price reductions',
      'Unreasonable worker non-competes violating Article 22 of the Constitution of Japan'
    ],
    keyRegulations: [
      'Civil Code of Japan (Minpō - 2020 major obligations reform)',
      'Act on the Protection of Personal Information (APPI)',
      'Act against Delay in Payment of Subcontract Proceeds (Subcontract Act)',
      'Arbitration Act (Act No. 138 of 2003)'
    ],
    currency: 'JPY',
    currencySymbol: '¥',
    notes: 'Standard Japanese commercial contracts virtually always contain an Anti-Social Forces (antisocial group) exclusion clause and a mutual consultation clause.'
  },
  {
    countryCode: 'SA',
    countryName: 'Kingdom of Saudi Arabia (KSA)',
    statesOrProvinces: ['Riyadh Region', 'Makkah Region (Jeddah)', 'Eastern Province (Dammam / Khobar)'],
    defaultGoverningLaw: 'Laws of the Kingdom of Saudi Arabia and the Civil Transactions Law (Royal Decree M/191)',
    arbitrationInstitutions: [
      { name: 'Saudi Center for Commercial Arbitration (SCCA)', city: 'Riyadh', rules: 'SCCA Arbitration Rules 2023' }
    ],
    eSignatureStatute: 'Electronic Transactions Law (Royal Decree No. M/18 of 2007) & DGA Digital Trust Regulations',
    mandatoryClauses: [
      'KSA Civil Transactions Law (2023) Compliance Framework',
      'Saudi Personal Data Protection Law (PDPL - Royal Decree M/148) Compliance',
      'Value Added Tax (VAT 15%) & Zakat, Tax and Customs Authority (ZATCA) E-Invoicing Clause',
      'Saudization / Local Content Undertakings where government or quasi-public contracts are involved'
    ],
    restrictedClauses: [
      'Provisions granting conventional interest (Riba) or speculative uncertainty (Gharar)',
      'Disproportionate liquidated damages that do not reflect actual foreseeable direct harm under Civil Transactions Law Article 179'
    ],
    keyRegulations: [
      'Civil Transactions Law (Royal Decree No. M/191 of 1444H / June 2023)',
      'Saudi Personal Data Protection Law (PDPL)',
      'Saudi Arbitration Law (Royal Decree No. M/34 of 1433H)',
      'Government Tender and Procurement Law (GTPL)'
    ],
    currency: 'SAR',
    currencySymbol: 'SAR ',
    notes: 'The historic Civil Transactions Law (effective Dec 2023) codified contract law in KSA, providing unprecedented clarity on contract formation, liability, and force majeure.'
  }
];
