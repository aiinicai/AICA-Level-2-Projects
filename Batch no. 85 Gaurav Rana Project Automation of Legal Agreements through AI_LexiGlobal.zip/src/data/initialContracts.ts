import { ContractItem } from '../types';

export const INITIAL_CONTRACTS: ContractItem[] = [
  {
    id: 'cnt-2026-001',
    contractNumber: 'GL-2026-MSA-0881',
    title: 'Cloud Infrastructure & Core Engineering Master Services Agreement',
    contractType: 'Master Services Agreement (MSA)',
    category: 'commercial',
    country: 'United States',
    stateOrRegion: 'Delaware',
    governingLaw: 'Laws of the State of Delaware',
    disputeForum: 'American Arbitration Association (AAA), New York',
    arbitrationSeat: 'New York, NY',
    status: 'negotiation',
    primaryParty: {
      id: 'pty-01',
      role: 'primary_party',
      legalName: 'Apex Cloud Solutions Inc.',
      entityType: 'Corporation',
      registrationNumber: 'DE-7891234',
      registeredAddress: '1209 Orange Street, Wilmington, DE 19801, USA',
      country: 'United States',
      taxId: 'EIN-84-9912044',
      signatoryName: 'Marcus Vance',
      signatoryDesignation: 'Chief Technology Officer',
      signatoryEmail: 'm.vance@apexcloud.io',
      signatoryPhone: '+1 (302) 555-0199',
      signatureStatus: 'pending'
    },
    counterparty: {
      id: 'pty-02',
      role: 'counterparty',
      legalName: 'Global Fintech Ventures LLC',
      entityType: 'LLC',
      registrationNumber: 'NY-4481023',
      registeredAddress: '350 5th Ave, Suite 6200, New York, NY 10118, USA',
      country: 'United States',
      taxId: 'EIN-13-8829101',
      signatoryName: 'Elena Rostova',
      signatoryDesignation: 'General Counsel & VP Operations',
      signatoryEmail: 'e.rostova@globalfintech.com',
      signatoryPhone: '+1 (212) 555-4321',
      signatureStatus: 'pending'
    },
    commercials: {
      contractValue: 480000,
      currency: 'USD',
      pricingModel: 'milestone_based',
      paymentFrequency: 'monthly',
      paymentDueDays: 30,
      taxTreatment: 'Exclusive of applicable state sales/use tax',
      latePaymentInterestRate: 1.5,
      expensesReimbursable: true
    },
    riskLiability: {
      liabilityCapType: 'fees_paid_12_months',
      liabilityCapAmount: 480000,
      hasUncappedExceptions: true,
      uncappedExceptionsList: ['Gross Negligence', 'IP Infringement Indemnification', 'Breach of Confidentiality'],
      indemnificationScope: 'mutual',
      insuranceRequirement: true,
      insuranceCoverageAmount: 5000000,
      consequentialDamagesExcluded: true,
      liquidatedDamages: false
    },
    startDate: '2026-09-01',
    endDate: '2027-08-31',
    renewalNoticeDays: 60,
    autoRenew: true,
    riskBreakdown: {
      overallScore: 24,
      financialRisk: 22,
      legalRisk: 26,
      complianceRisk: 20,
      dataRisk: 25,
      operationalRisk: 18,
      keyRiskFactors: [
        'Confirmed limitation of liability super-cap at 2x ($960k) specifically for data incidents, with 1x ($480k) general cap',
        '24/7 Level-3 SLA response commitment requires maintaining senior tier on-call engineering rotations'
      ],
      positiveProtections: [
        'Comprehensive Section 1 Definitions bounding Deliverables, Work Product, Customer Data, and SLA parameters',
        '24/7 Level-3 Technical Support SLA with 99.9% availability guarantee and tiered service credits',
        'Controller/Processor Data Processing terms with 48h confirmed breach notice and DPDPA/GDPR compliance',
        'SOC 2 Type II / ISO 27001 Cybersecurity Vulnerability Assessment with AES-256 encryption',
        'Explicit 90-day Exit Management and Disentanglement Transition Assistance protocol',
        'Business Continuity & Disaster Recovery guaranteeing RTO <= 4 hours and RPO <= 1 hour',
        'Mutual IP indemnity with clear defense control and standard commercial carve-outs',
        'Delaware governing law with AAA institutional commercial arbitration in New York'
      ]
    },
    versions: [
      {
        versionNumber: 'v1.0',
        createdAt: '2026-08-20T10:30:00Z',
        createdBy: 'Marcus Vance (CTO)',
        content: `MASTER SERVICES AGREEMENT\n\n1. SCOPE: Apex Cloud Solutions Inc. agrees to deliver Cloud Architecture Engineering.\n2. FEES: $480,000 USD payable in monthly installments.\n3. LIABILITY: Capped at fees paid in preceding 12 months.\n4. INDEMNITY: Mutual indemnity for third-party IP claims.\n5. DATA BREACH: Notice within 72 hours of confirmed breach.`,
        changeLog: 'Initial standard company draft generated via AI intake wizard.',
        isAiGenerated: true,
        isLocked: false
      },
      {
        versionNumber: 'v1.1 (Redline)',
        createdAt: '2026-08-26T14:15:00Z',
        createdBy: 'Elena Rostova (Counterparty Counsel)',
        content: `MASTER SERVICES AGREEMENT\n\n1. SCOPE: Apex Cloud Solutions Inc. agrees to deliver Cloud Architecture Engineering.\n2. FEES: $480,000 USD payable net 60 days upon acceptance.\n3. LIABILITY: Capped at three times (3x) the total contract value ($1,440,000 USD).\n4. INDEMNITY: Uncapped unilateral indemnity by Service Provider for all regulatory fines and IP.\n5. DATA BREACH: Immediate notice within twelve (12) hours of any suspicion.`,
        changeLog: 'Counterparty redline: expanded liability cap to 3x, payment extended to Net 60, 12h breach notice.',
        isAiGenerated: false,
        isLocked: false
      },
      {
        versionNumber: 'v2.0 (Updated Legal Clauses & Full Protection)',
        createdAt: '2026-08-28T16:30:00Z',
        createdBy: 'Legal & Risk AI Assistant',
        content: `MASTER SERVICES AGREEMENT

This Master Services Agreement ("Agreement") is executed and entered into as of this Effective Date by and between:

PARTIES:
1. Apex Cloud Solutions Inc., a Delaware Corporation having its principal office at 1209 Orange Street, Wilmington, DE 19801, USA (Tax ID: EIN-84-9912044) (hereinafter referred to as "Service Provider"); and
2. Global Fintech Ventures LLC, a New York Limited Liability Company having its principal office at 350 5th Ave, Suite 6200, New York, NY 10118, USA (Tax ID: EIN-13-8829101) (hereinafter referred to as "Customer").

RECITALS:
WHEREAS, Customer desires to engage Service Provider to perform enterprise cloud infrastructure architecture, AI engineering, cybersecurity vulnerability assessment, and 24/7 mission-critical technical support services; and
WHEREAS, Service Provider possesses the specialized expertise, certifications (SOC 2 Type II / ISO 27001), personnel, and technological infrastructure necessary to provide such services;

NOW, THEREFORE, in consideration of the mutual covenants herein contained, the Parties agree as follows:

1. DEFINITIONS & INTERPRETATION
1.1 "Affiliate" means any entity that directly or indirectly controls, is controlled by, or is under common control with a Party.
1.2 "Business Day" means any day other than a Saturday, Sunday, or official bank holiday in Wilmington, Delaware or New York, NY.
1.3 "Confidential Information" means all non-public technical, commercial, financial, operational, code, architecture, and proprietary information disclosed by one Party to the other.
1.4 "Customer Data" means all electronic data, files, records, telemetry, and databases submitted to, processed by, or accessed by Service Provider on behalf of Customer.
1.5 "Deliverables" means all reports, software modules, architectural schematics, configurations, algorithms, scripts, documentation, and work product developed or provided by Service Provider under an applicable SOW.
1.6 "Personal Data" has the meaning ascribed under applicable Data Protection Legislation (including India DPDPA 2023, EU GDPR, and US state privacy statutes).
1.7 "Services" means the technology engineering, AI infrastructure, cybersecurity vulnerability assessments, and 24/7 technical support services set forth in executed SOWs.
1.8 "Service Level Agreement (SLA)" means the performance standards, availability thresholds, and response metrics set forth in Section 3 and Schedule A.
1.9 "Statement of Work (SOW)" means an executed document referencing this Agreement detailing specific scopes, deliverables, timelines, and milestone fee schedules.
1.10 "Work Product" means all custom inventions, code, designs, scripts, and Deliverables authored specifically for Customer under this Agreement.

2. STATEMENT OF WORK (SOW), DELIVERABLES & ACCEPTANCE TESTING
2.1 Scope of Engagement: Service Provider shall perform the services described as: Cloud Infrastructure Architecture, AI Engineering & Cybersecurity Vulnerability Assessment Services. Specific project phases shall be governed by executed SOWs.
2.2 Milestone Acceptance Testing: Customer shall have ten (10) business days from delivery to evaluate and test Deliverables against agreed specifications.
2.3 Rectification of Non-Conformity: If Customer provides written notice of non-conformity within the review period, Service Provider shall, at no additional charge, rectify such non-conformity within five (5) business days.
2.4 Deemed Acceptance: If Customer does not deliver written notice of rejection within ten (10) business days or deploys the Deliverable in production, the Deliverable shall be deemed accepted.
2.5 Change Control Procedure: Any scope changes, timeline modifications, or fee adjustments must be documented in a formal written Change Order signed by authorized representatives of both Parties.

3. SERVICE LEVEL AGREEMENT (SLA) & 24/7 TECHNICAL SUPPORT
3.1 Uptime Availability: Service Provider guarantees 99.9% Monthly Uptime Availability for all hosted cloud systems and infrastructure services (excluding scheduled maintenance with at least 48 hours advance written notice).
3.2 24/7 Level-3 Technical Support: Service Provider shall deliver continuous 24/7/365 Level-3 senior engineering support accessible via telephone, secure portal, and dedicated communication bridge.
3.3 Incident Severity Levels & Response SLA:
    - Severity 1 (Critical Outage / Core System Down): Initial response <= 15 minutes; Target resolution <= 2 hours.
    - Severity 2 (Major Impairment / High Degradation): Initial response <= 1 hour; Target resolution <= 6 hours.
    - Severity 3 (Moderate Issue / Workaround Exists): Initial response <= 4 hours; Target resolution <= 24 hours.
    - Severity 4 (Minor Query / Feature Request): Initial response <= 12 hours.
3.4 Service Credits for Downtime: If Monthly Uptime Availability falls below 99.9%, Customer shall receive Service Credits applied against the subsequent monthly invoice:
    - 99.0% to 99.89% Uptime: 10% credit of monthly service fee.
    - 95.0% to 98.99% Uptime: 25% credit of monthly service fee.
    - Below 95.0% Uptime: 50% credit of monthly service fee.
3.5 Chronic SLA Breach: Uptime below 95.0% in two (2) consecutive billing cycles shall constitute a material breach entitling Customer to terminate for cause with a pro-rata refund of unearned fees.

4. COMMERCIAL TERMS, FEES, INVOICING & TAXES
4.1 Total Contract Consideration: $480,000 USD, payable in twelve (12) monthly milestone installments of $40,000 USD upon delivery of monthly progress certifications.
4.2 Payment Terms: All undisputed invoices are due and payable Net thirty (30) days from the date of receipt of a valid tax invoice.
4.3 Late Payment Interest: Undisputed overdue amounts shall bear interest at 1.5% per month or the maximum statutory rate permitted by Delaware law.
4.4 Taxes: Fees are exclusive of applicable state sales/use taxes, which shall be itemized separately on each invoice.

5. INTELLECTUAL PROPERTY & PROPRIETARY RIGHTS
5.1 Work Product Assignment: Upon full payment of applicable milestone fees, all custom software, scripts, documentation, and Deliverables authored specifically for Customer ("Work Product") shall become the sole and exclusive property of Customer.
5.2 Pre-Existing Background IP: Service Provider retains sole and exclusive title to its pre-existing tools, proprietary frameworks, libraries, and background IP ("Background IP"). Service Provider grants Customer a perpetual, irrevocable, worldwide, royalty-free, non-exclusive license to use Background IP embedded in Deliverables.

6. CONFIDENTIALITY & NON-DISCLOSURE
6.1 Non-Disclosure Covenant: Each Party shall preserve the confidentiality of the other Party's Confidential Information with the same degree of care it uses for its own confidential materials (and not less than reasonable care), and shall not disclose such information to third parties without prior written consent.
6.2 Permitted Disclosures: Disclosures are permitted to officers, employees, legal advisors, and vetted subcontractors with a strict need to know under binding confidentiality obligations.
6.3 Survival: Confidentiality obligations survive for five (5) years post-termination, provided that trade secrets and source code remain protected perpetually.

7. DATA PROCESSING AGREEMENT (DPA) & PRIVACY COMPLIANCE
7.1 Roles of Parties: Customer acts as Data Controller / Data Fiduciary, and Service Provider acts as Data Processor.
7.2 Processing Instructions: Service Provider shall process Personal Data exclusively upon documented instructions of Customer and in strict compliance with applicable Data Protection Laws (including India DPDPA 2023, EU GDPR, and CCPA).
7.3 Security Breach Notification: Service Provider shall notify Customer in writing within forty-eight (48) hours of confirming any unauthorized access, loss, or security incident affecting Customer Personal Data.
7.4 Assistance with Data Subject Rights: Service Provider shall provide reasonable technical assistance to enable Customer to fulfill statutory data subject requests (access, correction, erasure).

8. INFORMATION SECURITY & CYBERSECURITY VULNERABILITY ASSESSMENT
8.1 Security Standards: Service Provider shall maintain an Information Security Management System certified under ISO/IEC 27001 and verified by annual SOC 2 Type II audits.
8.2 Technical Safeguards: Safeguards include AES-256 encryption for data at rest, TLS 1.3 encryption in transit, multi-factor authentication (MFA), role-based access control (RBAC), and 180-day secure log retention.
8.3 Vulnerability Assessments & Pen Testing: Service Provider shall conduct quarterly vulnerability assessments and annual third-party penetration tests, remediating Critical and High findings within fourteen (14) calendar days.

9. SUBSTANTIVE MUTUAL INDEMNIFICATION
9.1 Service Provider Indemnity: Service Provider shall defend, indemnify, and hold harmless Customer, its Affiliates, directors, officers, and employees from and against any third-party claims, damages, liabilities, judgments, and legal fees arising out of: (a) actual or alleged infringement of any patent, copyright, trademark, or trade secret by Services or Deliverables; (b) gross negligence or willful misconduct of Service Provider; or (c) material breach of data protection or confidentiality obligations.
9.2 Customer Indemnity: Customer shall defend and indemnify Service Provider against third-party claims arising from Customer Data infringing third-party intellectual property rights or unlawful instructions.
9.3 Indemnification Procedures: The indemnified Party must: (i) promptly provide written notice of the claim; (ii) grant the indemnifying Party sole control of defense and settlement; and (iii) provide reasonable cooperation.

10. REPRESENTATIONS & WARRANTIES
10.1 Mutual Authority: Each Party represents and warrants that it is duly incorporated, validly existing, and possesses full corporate power to execute and perform this Agreement.
10.2 Service Standards Warranty: Service Provider warrants that Services shall be performed in a professional, workmanlike manner conforming to the highest industry standards by qualified personnel.
10.3 Deliverables Warranty: Service Provider warrants that Deliverables shall conform to SOW specifications for ninety (90) days following acceptance.
10.4 Non-Infringement & Malware Warranty: Service Provider warrants that Deliverables do not infringe third-party IP and are free from computer viruses, malware, worms, trojans, backdoors, or malicious disabling code.

11. LIMITATION OF LIABILITY & DAMAGES DISCLAIMER
11.1 Consequential Damages Disclaimer: Neither Party shall be liable for indirect, incidental, special, consequential, or punitive damages, or lost profits.
11.2 Aggregate Liability Ceiling: Except for breaches of Section 5 (IP), Section 6 (Confidentiality), Section 9 (Indemnification), or gross negligence/willful misconduct, each Party's total aggregate liability shall not exceed the total fees paid or payable under this Agreement in the twelve (12) months preceding the claim ($480,000 USD).
11.3 Data Protection Super-Cap: Liability for direct damages arising out of a confirmed breach of Section 7 (Data Protection) shall be subject to an aggregate super-cap of two times (2x) the total contract fees ($960,000 USD).

12. INSURANCE REQUIREMENTS
12.1 Coverage Mandate: During the Term and for twelve (12) months thereafter, Service Provider shall maintain:
    - Commercial General Liability: $2,000,000 per occurrence / $4,000,000 aggregate.
    - Cyber Risk, Network Security & Privacy Liability: $5,000,000 aggregate.
    - Professional Liability / Errors & Omissions: $2,000,000 per claim.
    - Statutory Workers' Compensation as required by law.
12.2 Certificates of Insurance: Certificates naming Customer as Additional Insured shall be provided within ten (10) days of request.

13. TERM, RENEWAL & TERMINATION
13.1 Term: This Agreement commences on September 1, 2026 and continues until August 31, 2027, automatically renewing for successive one-year terms unless either Party gives sixty (60) days prior written notice.
13.2 Termination for Convenience: Either Party may terminate this Agreement or any SOW for convenience upon thirty (30) days prior written notice.
13.3 Termination for Cause: Either Party may terminate immediately upon written notice if the other Party commits a material breach and fails to cure such breach within thirty (30) days of written notice.

14. CONSEQUENCES OF TERMINATION & EXIT MANAGEMENT
14.1 Orderly Wind-Down: Upon termination, Service Provider shall immediately cease performance, and Customer shall pay for all undisputed Services properly performed up to the effective termination date.
14.2 Prepaid Fee Refund: Service Provider shall promptly refund all unearned prepaid fees on a pro-rata basis.
14.3 Disentanglement & Transition Assistance: Upon Customer's request, Service Provider shall provide transition and handover assistance for up to ninety (90) days at agreed commercial rates to ensure uninterrupted business continuity.

15. BUSINESS CONTINUITY & DISASTER RECOVERY (BCP/DR)
15.1 BCP/DR Commitments: Service Provider shall maintain and regularly test a formal BCP/DR Plan guaranteeing a Recovery Time Objective (RTO) of <= 4 hours and a Recovery Point Objective (RPO) of <= 1 hour, backed by automated daily multi-region geographic backups.

16. CUSTOMER DATA OWNERSHIP, PORTABILITY & CERTIFIED DELETION
16.1 Title in Customer Data: Customer retains 100% sole and exclusive title, ownership, and intellectual property rights in all Customer Data.
16.2 Data Return & Certified Erasure: Within thirty (30) days of termination, Service Provider shall provide Customer with full data export in standard machine-readable format (JSON/SQL/CSV) and permanently destroy all remaining copies with written certificate of destruction.

17. SUBCONTRACTING & THIRD-PARTY VENDORS
17.1 Prior Consent & Liability: Service Provider shall not subcontract core engineering without Customer's prior written consent, shall bind subcontractors to identical confidentiality/security terms, and remains 100% primarily liable for all subcontractor acts and omissions.

18. ASSIGNMENT & CORPORATE RESTRUCTURING
18.1 Assignment Restrictions: Neither Party may assign or transfer this Agreement without prior written consent, except to an Affiliate or in connection with a merger, acquisition, or sale of substantially all assets.

19. FORCE MAJEURE & EXCUSABLE DELAYS
19.1 Excusable Events: Neither Party is liable for delays caused by acts of God, war, terrorism, flood, fire, pandemic, or national power grid failures beyond reasonable control, excluding payment obligations.
19.2 Notice & Mitigation: Prompt written notice within five (5) business days is required. If disruption exceeds thirty (30) consecutive days, either Party may terminate without penalty.

20. BROAD COMPLIANCE WITH LAWS
20.1 Ongoing Compliance: Each Party shall comply with all applicable local, state, national, and international laws, regulations, and industry standards applicable to its business and performance under this Agreement.

21. ANTI-BRIBERY & ANTI-CORRUPTION COMPLIANCE
21.1 Zero Tolerance: Each Party warrants compliance with the US Foreign Corrupt Practices Act (FCPA), the UK Bribery Act 2010, and the Indian Prevention of Corruption Act, 1988, strictly prohibiting bribes, kickbacks, or facilitation payments.

22. TRADE SANCTIONS & EXPORT CONTROL COMPLIANCE
22.1 Sanctions Warranty: Each Party represents that neither it nor its officers are listed on US OFAC, BIS Entity List, EU, or UN sanctions lists, and covenants to comply with all applicable dual-use and export control laws.

23. AUDIT, INSPECTION & VERIFICATION RIGHTS
23.1 Audit Scope: Customer or its independent certified auditor under NDA may audit Service Provider's security controls, compliance logs, and billing records once per year upon ten (10) business days prior written notice during normal business hours.

24. FORMAL NOTICES & ELECTRONIC COMMUNICATION
24.1 Delivery Protocol: Formal notices must be in writing and delivered by tracked international courier (deemed received in 2 business days) or verified electronic mail to designated signatory addresses with delivery confirmation.

25. ENTIRE AGREEMENT, AMENDMENTS, WAIVER & SEVERABILITY
25.1 Integration: This Agreement, together with all SOWs, SLAs, DPAs, and schedules, constitutes the entire agreement between the Parties and supersedes all prior proposals, negotiations, and representations.
25.2 Amendments & Waivers: Amendments and waivers are valid only when executed in writing and signed by authorized signatories.
25.3 Severability: If any provision is held unenforceable, it shall be reformed to the minimum extent necessary, and all other terms shall remain in full force.

26. SURVIVAL & ORDER OF PRECEDENCE
26.1 Survival: Sections 1, 4, 5, 6, 7, 9, 10, 11, 14, 16, 25, 26, 28, and 29 survive contract termination.
26.2 Order of Precedence: In the event of conflict, the descending order of precedence is: (1) Data Processing Addendum (DPA); (2) Statement of Work (SOW); (3) Service Level Agreement (SLA); (4) Master Services Agreement; and (5) Purchase Orders (all pre-printed PO terms are void).

27. PUBLICITY & TRADEMARK RESTRICTIONS
27.1 Consent Required: Neither Party shall issue press releases, marketing case studies, or use the other Party's logo or trademarks without express prior written consent.

28. DISPUTE RESOLUTION & ARBITRATION
28.1 Executive Escalation & Arbitration: The Parties shall attempt good-faith executive negotiation for thirty (30) days. Any unresolved dispute shall be finally settled by binding institutional arbitration administered by the American Arbitration Association (AAA) under its Commercial Arbitration Rules. The seat of arbitration shall be New York, NY, conducted in English by a single arbitrator.

29. GOVERNING LAW & JURISDICTION
29.1 Governing Law: This Agreement shall be governed by and construed in accordance with the Laws of the State of Delaware, without regard to conflict of laws principles.

30. COUNTERPARTS & ELECTRONIC SIGNATURES
30.1 Electronic Execution: This Agreement may be executed in counterparts by digital or electronic signatures under the US E-SIGN Act and Delaware UETA, each of which shall be deemed an original and binding on the executing Party.

IN WITNESS WHEREOF, the Parties' duly authorized representatives have executed this Master Services Agreement as of the Effective Date:

FOR: Apex Cloud Solutions Inc.
Signatory: Marcus Vance
Title: Chief Technology Officer
Email: m.vance@apexcloud.io
Date: ________________________

FOR: Global Fintech Ventures LLC
Signatory: Elena Rostova
Title: General Counsel & VP Operations
Email: e.rostova@globalfintech.com
Date: ________________________`,
        changeLog: 'Updated agreement with all 26 comprehensive institutional clauses including 24/7 L3 support SLA, DPA, cybersecurity assessment, substantive indemnification, warranties, BCP/DR, and exit disentanglement.',
        isAiGenerated: true,
        isLocked: false
      }
    ],
    currentVersionIndex: 2,
    approvals: [
      { id: 'app-01', stepName: 'Business & Project Sponsor', roleRequired: 'business', assignedUserEmail: 'm.vance@apexcloud.io', status: 'approved', actionDate: '2026-08-21T09:00:00Z', comments: 'Commercial deliverables and milestone schedule verified.' },
      { id: 'app-02', stepName: 'Finance Review', roleRequired: 'finance', assignedUserEmail: 'cfo@apexcloud.io', status: 'pending', thresholdCondition: 'Value > $100k' },
      { id: 'app-03', stepName: 'Legal & Risk Approval', roleRequired: 'legal', assignedUserEmail: 'legal@apexcloud.io', status: 'pending', thresholdCondition: 'Liability Cap > 1x or 3x Redline' }
    ],
    vettingIssues: [
      {
        id: 'vet-01',
        clauseTitle: 'Limitation of Liability Cap & Super-Cap',
        originalText: 'LIABILITY: 1x annual fees ($480k) general cap, with 2x super-cap ($960k) for data incidents.',
        issue: 'Counterparty requested 3x general cap; resolved via compromise holding general liability to 1x ($480k) with a 2x ($960k) super-cap specifically for confirmed data breaches.',
        riskLevel: 'medium',
        legalPrinciple: 'Under UCC and Delaware commercial contract doctrine (6 Del. C. § 2-719), liability caps allocate operational downside while super-caps address privacy statutory exposure.',
        businessImpact: 'Protects company against catastrophic 3x general exposure while offering commercial comfort on cybersecurity.',
        companyPosition: 'favourable',
        suggestedWording: 'Except for gross negligence or intentional misconduct, each party\'s total aggregate liability shall not exceed the total fees paid in the twelve (12) months preceding the claim ($480,000 USD), provided that liability for confirmed data protection breaches under Section 7 shall not exceed two times (2x) the total fees ($960,000 USD).',
        negotiationPriority: 'high',
        lawyerReviewRequired: true,
        legalSourceCitation: {
          statute: '6 Del. C. § 2-719 & Restatement (Second) of Contracts § 356',
          jurisdiction: 'Delaware / US',
          confidence: 98,
          lastVerified: '2026-08-28'
        }
      },
      {
        id: 'vet-02',
        clauseTitle: 'Data Breach Notification Window',
        originalText: 'DATA BREACH: Service Provider shall notify Customer in writing within forty-eight (48) hours of confirming a security incident affecting Customer Personal Data.',
        issue: 'Counterparty requested 12h notification on any suspicion; successfully negotiated to 48 hours following confirmed security breach.',
        riskLevel: 'low',
        legalPrinciple: 'Market standards (and statutory GDPR / state breach statutes) establish 48 to 72 hours following confirmed security incident.',
        businessImpact: 'Allows sufficient time for forensic engineering verification without creating premature breach exposure.',
        companyPosition: 'favourable',
        suggestedWording: 'Service Provider shall notify Customer in writing within forty-eight (48) hours of confirming any unauthorized access, loss, or security incident affecting Customer Personal Data.',
        negotiationPriority: 'high',
        lawyerReviewRequired: false,
        legalSourceCitation: {
          statute: 'Delaware Computer Security Breach Act (6 Del. C. § 12B-101 et seq.)',
          jurisdiction: 'Delaware / US',
          confidence: 96,
          lastVerified: '2026-08-28'
        }
      }
    ],
    createdDate: '2026-08-20',
    lastModifiedDate: '2026-08-28',
    contractOwner: 'Marcus Vance',
    department: 'Engineering & Cloud Services',
    tags: ['Cloud', 'Enterprise', 'High-Value', 'US-Delaware', 'Active-Negotiation']
  },
  {
    id: 'cnt-2026-002',
    contractNumber: 'GL-2026-IND-0429',
    title: 'Enterprise AI Software Development & Technology Transfer Agreement',
    contractType: 'Software Development Agreement',
    category: 'commercial',
    country: 'India',
    stateOrRegion: 'Karnataka (Bengaluru)',
    governingLaw: 'Laws of India',
    disputeForum: 'Mumbai Centre for International Arbitration (MCIA)',
    arbitrationSeat: 'Bengaluru / Mumbai',
    status: 'sent_for_signature',
    primaryParty: {
      id: 'pty-11',
      role: 'primary_party',
      legalName: 'Cognitive Matrix Tech Pvt. Ltd.',
      entityType: 'Private Limited',
      registrationNumber: 'U72200KA2021PTC148992',
      registeredAddress: 'Tower B, Outer Ring Road, Bengaluru, Karnataka 560103, India',
      country: 'India',
      taxId: 'GSTIN: 29AABCC1234F1Z8',
      signatoryName: 'Ananya Sharma',
      signatoryDesignation: 'Director & Co-Founder',
      signatoryEmail: 'ananya@cognitivematrix.ai',
      signatoryPhone: '+91 98801 23456',
      signatureStatus: 'signed',
      signedAt: '2026-08-28T11:45:00Z',
      authMethod: 'aadhaar_esign',
      ipAddress: '103.22.18.94'
    },
    counterparty: {
      id: 'pty-12',
      role: 'counterparty',
      legalName: 'Bharat Financial Systems Limited',
      entityType: 'Public Limited',
      registrationNumber: 'L65191MH1998PLC114002',
      registeredAddress: 'Bandra-Kurla Complex (BKC), Mumbai, Maharashtra 400051, India',
      country: 'India',
      taxId: 'GSTIN: 27AAACR9981K1Z2',
      signatoryName: 'Rajesh Subramanian',
      signatoryDesignation: 'Chief Information Officer',
      signatoryEmail: 'r.subramanian@bharatfin.com',
      signatoryPhone: '+91 98200 65432',
      signatureStatus: 'pending'
    },
    commercials: {
      contractValue: 12500000,
      currency: 'INR',
      pricingModel: 'milestone_based',
      paymentFrequency: 'milestone_triggered',
      paymentDueDays: 15,
      taxTreatment: 'Subject to 18% GST and applicable TDS under Section 194J',
      latePaymentInterestRate: 18,
      expensesReimbursable: false
    },
    riskLiability: {
      liabilityCapType: 'fixed_amount',
      liabilityCapAmount: 12500000,
      hasUncappedExceptions: true,
      uncappedExceptionsList: ['Breach of Confidentiality', 'IP Infringement', 'DPDPA 2023 Violation'],
      indemnificationScope: 'mutual',
      insuranceRequirement: true,
      insuranceCoverageAmount: 25000000,
      consequentialDamagesExcluded: true,
      liquidatedDamages: true,
      liquidatedDamagesDetails: '0.5% per week of delay up to a maximum of 5% of milestone value'
    },
    startDate: '2026-09-15',
    endDate: '2027-09-14',
    renewalNoticeDays: 30,
    autoRenew: false,
    riskBreakdown: {
      overallScore: 24,
      financialRisk: 20,
      legalRisk: 28,
      complianceRisk: 22,
      dataRisk: 30,
      operationalRisk: 18,
      keyRiskFactors: [
        'Milestone-triggered liquidated damages of 0.5%/week capped at 5%',
        'Mandatory compliance with India DPDPA 2023 Data Processor obligations'
      ],
      positiveProtections: [
        'Section 27 Contract Act compliance (no void post-termination restrictions)',
        'Clear IP transfer contingent upon complete receipt of milestone fees',
        'MCIA expedited arbitration clause'
      ]
    },
    versions: [
      {
        versionNumber: 'v1.0 (Final Approved)',
        createdAt: '2026-08-27T16:00:00Z',
        createdBy: 'Legal Head (Adv. Rahul Iyer)',
        content: `SOFTWARE DEVELOPMENT & TECHNOLOGY TRANSFER AGREEMENT\n\nExecuted under the Indian Contract Act, 1872.\n1. PARTIES: Cognitive Matrix Tech Pvt Ltd and Bharat Financial Systems Ltd.\n2. VALUE: INR 1,25,00,000 + 18% GST.\n3. ARBITRATION: MCIA, Mumbai.\n4. E-SIGN: Executed digitally under Section 10A of the Information Technology Act, 2000.`,
        changeLog: 'Final negotiated draft approved by Legal and Finance.',
        isAiGenerated: false,
        isLocked: true
      }
    ],
    currentVersionIndex: 0,
    approvals: [
      { id: 'app-11', stepName: 'Department Head', roleRequired: 'business', assignedUserEmail: 'ananya@cognitivematrix.ai', status: 'approved', actionDate: '2026-08-27T10:00:00Z' },
      { id: 'app-12', stepName: 'Finance Head', roleRequired: 'finance', assignedUserEmail: 'finance@cognitivematrix.ai', status: 'approved', actionDate: '2026-08-27T14:30:00Z' },
      { id: 'app-13', stepName: 'General Counsel', roleRequired: 'legal', assignedUserEmail: 'legal@cognitivematrix.ai', status: 'approved', actionDate: '2026-08-27T17:10:00Z' }
    ],
    vettingIssues: [],
    createdDate: '2026-08-22',
    lastModifiedDate: '2026-08-28',
    contractOwner: 'Ananya Sharma',
    department: 'Product & Engineering',
    tags: ['India', 'DPDPA', 'Software-Dev', 'MCIA', 'High-Value']
  },
  {
    id: 'cnt-2026-003',
    contractNumber: 'GL-2026-UK-0104',
    title: 'Cross-Border SaaS Enterprise License & Data Processing Addendum',
    contractType: 'Software-as-a-Service (SaaS) Agreement',
    category: 'commercial',
    country: 'United Kingdom',
    stateOrRegion: 'England & Wales',
    governingLaw: 'Laws of England and Wales',
    disputeForum: 'London Court of International Arbitration (LCIA)',
    arbitrationSeat: 'London, UK',
    status: 'fully_executed',
    primaryParty: {
      id: 'pty-21',
      role: 'primary_party',
      legalName: 'Veritas Security Systems UK Ltd',
      entityType: 'Private Limited',
      registrationNumber: 'UK-09948210',
      registeredAddress: '10 Fenchurch Avenue, London EC3M 5BN, United Kingdom',
      country: 'United Kingdom',
      taxId: 'GB 992 4811 00',
      signatoryName: 'Sir Arthur Sterling',
      signatoryDesignation: 'Chief Executive Officer',
      signatoryEmail: 'a.sterling@veritassecurity.co.uk',
      signatoryPhone: '+44 20 7946 0991',
      signatureStatus: 'signed',
      signedAt: '2026-08-15T09:30:00Z',
      authMethod: 'digital_cert',
      ipAddress: '185.120.44.12'
    },
    counterparty: {
      id: 'pty-22',
      role: 'counterparty',
      legalName: 'Nordic Logistics Holdings AS',
      entityType: 'Corporation',
      registrationNumber: 'NO-991204882',
      registeredAddress: 'Stortingsgata 22, 0161 Oslo, Norway',
      country: 'Norway',
      taxId: 'MVA 991204882',
      signatoryName: 'Freja Lindqvist',
      signatoryDesignation: 'Chief Information Security Officer',
      signatoryEmail: 'f.lindqvist@nordiclogistics.no',
      signatoryPhone: '+47 22 88 00 00',
      signatureStatus: 'signed',
      signedAt: '2026-08-15T14:22:00Z',
      authMethod: 'email_otp',
      ipAddress: '84.212.19.80'
    },
    commercials: {
      contractValue: 185000,
      currency: 'GBP',
      pricingModel: 'subscription',
      paymentFrequency: 'annually',
      paymentDueDays: 30,
      taxTreatment: 'UK VAT Reverse Charge applied under cross-border B2B rules',
      latePaymentInterestRate: 4.0,
      expensesReimbursable: false
    },
    riskLiability: {
      liabilityCapType: 'fees_paid_12_months',
      liabilityCapAmount: 185000,
      hasUncappedExceptions: true,
      uncappedExceptionsList: ['Death/Personal Injury (UCTA 1977)', 'Fraudulent Misrepresentation', 'IP Indemnity'],
      indemnificationScope: 'mutual',
      insuranceRequirement: true,
      insuranceCoverageAmount: 10000000,
      consequentialDamagesExcluded: true,
      liquidatedDamages: false
    },
    startDate: '2026-08-15',
    endDate: '2027-08-14',
    renewalNoticeDays: 90,
    autoRenew: true,
    riskBreakdown: {
      overallScore: 12,
      financialRisk: 10,
      legalRisk: 14,
      complianceRisk: 8,
      dataRisk: 16,
      operationalRisk: 12,
      keyRiskFactors: [
        'Annual auto-renewal with 90 days notice window'
      ],
      positiveProtections: [
        'UK GDPR Art 28 DPA and EU-UK Data Bridge Transfer Clauses executed',
        'UCTA 1977 compliant liability structure',
        'Contracts (Rights of Third Parties) Act 1999 exclusion'
      ]
    },
    versions: [
      {
        versionNumber: 'v1.0 (Executed)',
        createdAt: '2026-08-15T08:00:00Z',
        createdBy: 'Sir Arthur Sterling (CEO)',
        content: `EXECUTED ENTERPRISE SAAS AGREEMENT & UK GDPR DPA\n\nGoverning Law: Laws of England and Wales.\nAnnual Subscription: £185,000 GBP.\nFully executed by digital signature certificates.`,
        changeLog: 'Fully signed and sealed by both CEOs.',
        isAiGenerated: false,
        isLocked: true
      }
    ],
    currentVersionIndex: 0,
    approvals: [
      { id: 'app-21', stepName: 'Commercial Director', roleRequired: 'business', assignedUserEmail: 'cd@veritassecurity.co.uk', status: 'approved', actionDate: '2026-08-14T11:00:00Z' },
      { id: 'app-22', stepName: 'Head of Legal & Compliance', roleRequired: 'legal', assignedUserEmail: 'legal@veritassecurity.co.uk', status: 'approved', actionDate: '2026-08-14T15:30:00Z' }
    ],
    vettingIssues: [],
    createdDate: '2026-08-10',
    lastModifiedDate: '2026-08-15',
    contractOwner: 'Sir Arthur Sterling',
    department: 'Cybersecurity Operations',
    tags: ['UK-GDPR', 'LCIA', 'Executed', 'SaaS', 'High-Trust'],
    executionMetadata: {
      signedPdfHash: 'sha256:8f43a9b1834c2ee571d803d2194a0b2713fce0891d4e082136e053a992bc44e1',
      certificateId: 'CERT-UK-2026-883921',
      completedAt: '2026-08-15T14:22:00Z',
      sentToEmails: ['a.sterling@veritassecurity.co.uk', 'f.lindqvist@nordiclogistics.no', 'audit@veritassecurity.co.uk']
    }
  },
  {
    id: 'cnt-2026-004',
    contractNumber: 'GL-2026-SG-0912',
    title: 'Southeast Asia Strategic Joint Venture & Intellectual Property Licensing',
    contractType: 'Joint Venture Agreement',
    category: 'corporate',
    country: 'Singapore',
    stateOrRegion: 'Central Region',
    governingLaw: 'Laws of the Republic of Singapore',
    disputeForum: 'Singapore International Arbitration Centre (SIAC)',
    arbitrationSeat: 'Singapore',
    status: 'expiring_soon',
    primaryParty: {
      id: 'pty-31',
      role: 'primary_party',
      legalName: 'SingaTech Ventures Pte. Ltd.',
      entityType: 'Private Limited',
      registrationNumber: 'UEN: 201938491K',
      registeredAddress: '1 Marina Boulevard, #28-00, Singapore 018989',
      country: 'Singapore',
      taxId: 'GST: M201938491K',
      signatoryName: 'Tan Wei Ming',
      signatoryDesignation: 'Managing Director',
      signatoryEmail: 'weiming.tan@singatech.sg',
      signatoryPhone: '+65 6789 0123',
      signatureStatus: 'signed',
      signedAt: '2025-09-20T10:00:00Z'
    },
    counterparty: {
      id: 'pty-32',
      role: 'counterparty',
      legalName: 'Nippon Clean Energy Corp',
      entityType: 'Corporation',
      registrationNumber: 'JP-9010001029384',
      registeredAddress: '1-1-2 Marunouchi, Chiyoda-ku, Tokyo 100-0005, Japan',
      country: 'Japan',
      taxId: 'JP 9010001029384',
      signatoryName: 'Kenji Takahashi',
      signatoryDesignation: 'Senior Executive VP',
      signatoryEmail: 'k.takahashi@nipponenergy.co.jp',
      signatoryPhone: '+81 3 5555 0100',
      signatureStatus: 'signed',
      signedAt: '2025-09-20T12:00:00Z'
    },
    commercials: {
      contractValue: 3500000,
      currency: 'SGD',
      pricingModel: 'revenue_share',
      paymentFrequency: 'quarterly',
      paymentDueDays: 30,
      taxTreatment: 'Withholding tax relief under Singapore-Japan DTAA Article 12',
      latePaymentInterestRate: 2.0,
      expensesReimbursable: true
    },
    riskLiability: {
      liabilityCapType: 'multiplier_annual_value',
      liabilityCapMultiplier: 2,
      hasUncappedExceptions: true,
      uncappedExceptionsList: ['IP Infringement', 'Trade Secret Disclosure', 'Breach of Exclusivity'],
      indemnificationScope: 'mutual',
      insuranceRequirement: true,
      insuranceCoverageAmount: 15000000,
      consequentialDamagesExcluded: true,
      liquidatedDamages: false
    },
    startDate: '2025-10-01',
    endDate: '2026-09-30',
    renewalNoticeDays: 60,
    autoRenew: false,
    riskBreakdown: {
      overallScore: 35,
      financialRisk: 38,
      legalRisk: 32,
      complianceRisk: 30,
      dataRisk: 28,
      operationalRisk: 46,
      keyRiskFactors: [
        'Contract expires in ~30 days (2026-09-30); renewal notice was due 60 days prior',
        'Cross-border IP license terminates upon expiry unless extended'
      ],
      positiveProtections: [
        'SIAC Arbitration clause with expedited tribunal provision',
        'Singapore-Japan Double Tax Avoidance Agreement (DTAA) tax optimization'
      ]
    },
    versions: [
      {
        versionNumber: 'v1.0 (Executed)',
        createdAt: '2025-09-20T08:00:00Z',
        createdBy: 'Tan Wei Ming (MD)',
        content: `STRATEGIC JOINT VENTURE & IP LICENSING AGREEMENT\n\nParties: SingaTech Ventures Pte Ltd (Singapore) & Nippon Clean Energy Corp (Japan).\nGoverning Law: Singapore Law. Arbitration: SIAC, Singapore.`,
        changeLog: 'Original executed Joint Venture Agreement.',
        isAiGenerated: false,
        isLocked: true
      }
    ],
    currentVersionIndex: 0,
    approvals: [
      { id: 'app-31', stepName: 'Board of Directors Approval', roleRequired: 'management', assignedUserEmail: 'board@singatech.sg', status: 'approved', actionDate: '2025-09-18T10:00:00Z' }
    ],
    vettingIssues: [],
    createdDate: '2025-09-15',
    lastModifiedDate: '2026-08-25',
    contractOwner: 'Tan Wei Ming',
    department: 'Strategic Investments',
    tags: ['Singapore', 'Japan', 'SIAC', 'Joint-Venture', 'Expiring-Soon']
  }
];
