import { DetailedClause } from '../types';

export const TEMPLATE_DETAILED_CLAUSES: Record<string, DetailedClause[]> = {
  'tmpl-msa': [
    {
      id: 'msa-sec-1',
      sectionNumber: 'Section 1',
      title: 'Definitions & Rules of Contractual Interpretation',
      category: 'operational',
      summary: 'Establishes precise, legally binding definitions for technical, operational, commercial, and risk terminology across all Statements of Work.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Standard common law and civil law interpretation principles. Capitalized terms control throughout all SOWs, exhibits, and task orders.',
      fullLegalText: `1.1 "Affiliate" means any entity that directly or indirectly controls, is controlled by, or is under common control with a Party, where "control" means the direct or indirect ownership of more than fifty percent (50%) of the voting capital or voting rights of such entity, or the power to direct the management and policies of such entity by contract or otherwise.

1.2 "Applicable Law" means all national, federal, state, provincial, and local laws, statutes, regulations, directives, regulatory guidance, and judicial decisions applicable to a Party's business operations and performance under this Agreement, including without limitation data privacy statutes, anti-bribery laws, and trade sanction regimes.

1.3 "Business Day" means any day other than a Saturday, Sunday, or official public bank holiday in the jurisdiction whose law governs this Agreement.

1.4 "Customer Data" means any and all electronic data, files, records, databases, customer personal information, and business documents submitted, uploaded, transmitted, or otherwise made available by or on behalf of Customer or its authorized users to Service Provider for processing, storage, or hosting.

1.5 "Deliverables" means all reports, software code, custom configurations, architecture schematics, technical documentation, designs, data transformations, and tangible or intangible work product specified to be delivered by Service Provider under an executed Statement of Work.

1.6 "Personal Data" has the meaning ascribed to "personal data", "personal information", or "personally identifiable information" under applicable Data Protection Legislation, including without limitation the European Union General Data Protection Regulation (GDPR) and the India Digital Personal Data Protection Act, 2023 (DPDPA).

1.7 "Services" means the technology engineering, architecture design, cloud deployment, cybersecurity vulnerability assessments, system integration, and Level-3 technical support services described in this Agreement and any executed Statements of Work.

1.8 "Work Product" means all inventions, designs, custom computer software programs, scripts, modules, documentation, and other copyrightable or patentable materials created, conceived, or reduced to practice by Service Provider, solely or jointly with others, specifically for Customer in the performance of Services under an SOW.`
    },
    {
      id: 'msa-sec-2',
      sectionNumber: 'Section 2',
      title: 'Statements of Work (SOW), Milestones & Acceptance Testing Protocol',
      category: 'operational',
      summary: 'Governs the formal execution of project statements of work, delivery timelines, rigorous acceptance testing windows, and change order mechanisms.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Prevents subjective scope creep by creating objective pass/fail acceptance criteria and formal written change orders.',
      fullLegalText: `2.1 SOW Execution: Services and Deliverables shall be authorized and performed solely pursuant to fully executed Statements of Work ("SOW") signed by authorized representatives of each Party. Each SOW shall incorporate the terms and conditions of this Agreement and specify: (a) scope of services; (b) milestone schedule and delivery dates; (c) project acceptance criteria; (d) staffing allocations; and (e) commercial fee structures and invoicing intervals.

2.2 Acceptance Testing Period: Customer shall have ten (10) consecutive Business Days following delivery of any milestone Deliverable ("Review Period") to evaluate, test, and verify whether the Deliverable materially conforms to the functional and technical specifications agreed in the applicable SOW.

2.3 Rectification of Non-Conformity: If Customer reasonably determines in good faith that a Deliverable fails to conform to the agreed SOW specifications in any material respect, Customer shall provide Service Provider with a detailed written notice of non-conformity specifying the exact deficiencies prior to the expiration of the Review Period. Upon receipt of such notice, Service Provider shall, at its sole cost and expense:
    (a) investigate, remediate, and rectify the identified defects within five (5) Business Days; and
    (b) resubmit the corrected Deliverable to Customer for a supplementary five (5) Business Day re-testing period.

2.4 Deemed Acceptance: If Customer does not provide written notice of rejection or deficiency within the ten (10) Business Day Review Period, or if Customer deploys the Deliverable in an active commercial or production operating environment, the Deliverable shall be deemed conclusively accepted by Customer.

2.5 Formal Change Control: Neither Party shall be obligated to implement any expansion, reduction, or modification to the scope of an SOW unless agreed in an executed written Change Order specifying the revised scope, schedule impact, and pricing adjustment.`
    },
    {
      id: 'msa-sec-3',
      sectionNumber: 'Section 3',
      title: 'Service Level Agreement (SLA), 99.9% Uptime & 24/7 Level-3 Support',
      category: 'operational',
      summary: 'Mandates 99.9% availability, strict incident response and resolution timelines across 4 severity tiers, financial service credits, and chronic outage termination rights.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Service credit mechanisms provide an exclusive financial remedy for routine downtime while preserving termination for persistent chronic outages.',
      fullLegalText: `3.1 Service Availability Commitment: Service Provider warrants and covenants that the hosted systems, cloud infrastructure, and core API services provided to Customer shall maintain a Monthly Uptime Availability of not less than ninety-nine and nine-tenths percent (99.9%), calculated on a 24-hours-per-day, 7-days-per-week basis, excluding Scheduled Maintenance.

3.2 Scheduled Maintenance: Service Provider may perform routine infrastructure updates and scheduled maintenance provided that Service Provider: (a) provides Customer with not less than forty-eight (48) hours prior written notice; and (b) conducts such maintenance during off-peak weekend windows (00:00 to 04:00 UTC).

3.3 Support Severity Matrix & Response Obligations: Service Provider shall maintain continuous 24/7/365 Level-3 senior engineering support accessible via telephone, secure ticketing portal, and dedicated incident management channels. Service Provider shall respond to and remediate technical incidents in accordance with the following binding timeframes:
    (a) Severity 1 (Critical Outage - Core Production Platform Down): Initial Response Time <= 15 minutes; Status Updates every 30 minutes; Target Resolution Time <= 2 hours.
    (b) Severity 2 (Major Impairment - High Business Impact / Workaround Complex): Initial Response Time <= 1 hour; Status Updates every 2 hours; Target Resolution Time <= 6 hours.
    (c) Severity 3 (Moderate Degradation - Standard Operational Issue): Initial Response Time <= 4 hours; Target Resolution Time <= 24 hours.
    (d) Severity 4 (Minor Query / Cosmetic Request): Initial Response Time <= 12 hours; Resolution in subsequent scheduled software release cycle.

3.4 Financial Service Credits: If Service Provider fails to meet the 99.9% Monthly Uptime Availability commitment, Customer shall be entitled to receive Service Credits against the subsequent monthly service fee:
    - 99.0% to 99.89% Availability: 10% credit of total monthly recurring fee.
    - 95.0% to 98.99% Availability: 25% credit of total monthly recurring fee.
    - Less than 95.0% Availability: 50% credit of total monthly recurring fee.

3.5 Chronic SLA Breach Termination: If Monthly Uptime Availability falls below ninety-five percent (95.0%) in any two (2) consecutive calendar months, or in any three (3) months within any rolling twelve-month period, Customer shall have the right to terminate this Agreement immediately for cause without penalty.`
    },
    {
      id: 'msa-sec-4',
      sectionNumber: 'Section 4',
      title: 'Commercial Terms, Invoicing Protocol, Taxes & Late Payment Interest',
      category: 'commercial',
      summary: 'Defines milestone invoicing rules, Net 30 day payment windows, good-faith dispute withholding, 1.5% late payment interest, and indirect/withholding tax treatment.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Compliant with US Prompt Payment standards, UK Late Payment of Commercial Debts Act, and Indian GST / TDS withholding mandates under Income Tax Act Section 194J.',
      fullLegalText: `4.1 Contract Consideration: Customer shall pay Service Provider the commercial fees and charges specified in each executed Statement of Work, subject to satisfactory achievement and formal acceptance of corresponding project milestones.

4.2 Payment Terms & Invoicing: Service Provider shall submit accurate, itemized tax invoices upon the successful completion and acceptance of each milestone. All undisputed amounts specified in an invoice shall be due and payable within thirty (30) calendar days from the date of Customer's receipt of a valid tax invoice.

4.3 Good Faith Invoice Disputes: If Customer disputes in good faith any portion of an invoice, Customer shall: (a) provide written notice to Service Provider within fifteen (15) Business Days of invoice receipt detailing the grounds for dispute; and (b) timely pay all undisputed portions of the invoice. The Parties shall negotiate in good faith to resolve the disputed amount within twenty (20) Business Days.

4.4 Late Payment Interest: Any undisputed invoice balance not paid when due shall accrue interest from the due date until paid in full at the rate of one and one-half percent (1.5%) per month, or the maximum legal rate permissible under Applicable Law, whichever is less.

4.5 Tax Obligations: All fees are exclusive of all applicable indirect, consumption, sales, value-added (VAT), goods and services taxes (GST), or customs duties. Customer shall be responsible for paying all such taxes properly assessed, excluding taxes based upon Service Provider's net income, capital, or corporate franchise. Where Applicable Law requires Customer to withhold income tax at source (TDS), Customer shall provide Service Provider with an official tax withholding certificate within thirty (30) days of deduction.`
    },
    {
      id: 'msa-sec-5',
      sectionNumber: 'Section 5',
      title: 'Intellectual Property Ownership, Work Product Assignment & Background IP',
      category: 'ip_data',
      summary: 'Grants Customer 100% exclusive title to custom Work Product upon creation while reserving Service Provider pre-existing tools under a perpetual, royalty-free license.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Contains express work-made-for-hire declarations, statutory copyright assignment, and moral rights waivers enforceable under US Copyright Act § 201 and Indian Copyright Act § 19.',
      fullLegalText: `5.1 Customer Ownership of Work Product: Customer shall be the sole and exclusive owner of all right, title, and interest worldwide in and to all Deliverables, software code, designs, algorithms, specifications, inventions, discoveries, and custom Work Product developed, authored, or reduced to practice by Service Provider in connection with this Agreement. To the maximum extent permitted by Applicable Law, all copyrightable aspects of Work Product shall be deemed "works made for hire" for Customer.

5.2 Complete Assignment: To the extent that any Work Product does not qualify as a work made for hire or title does not automatically vest in Customer, Service Provider hereby unconditionally, irrevocably, and perpetually assigns, transfers, and conveys to Customer, upon creation, all worldwide right, title, and interest in and to such Work Product, including all patents, copyrights, trade secrets, trademarks, and associated goodwill, together with all rights to sue for past, present, and future infringement thereof.

5.3 Pre-Existing Background IP: Service Provider retains sole and exclusive ownership of all pre-existing software, generic utilities, development tools, foundational algorithms, software libraries, and proprietary architectures developed by Service Provider prior to the Effective Date or independently outside the scope of this Agreement ("Background IP").

5.4 License to Background IP: To the extent that any Background IP is incorporated into, embedded within, or required for the full commercial exploitation of any Deliverable or Work Product, Service Provider hereby grants to Customer a perpetual, irrevocable, worldwide, royalty-free, fully paid-up, transferable, sublicensable, non-exclusive license to use, execute, reproduce, display, perform, modify, adapt, distribute, and commercially exploit such Background IP as part of or in connection with the Deliverable.`
    },
    {
      id: 'msa-sec-6',
      sectionNumber: 'Section 6',
      title: 'Confidentiality, Non-Disclosure & Perpetual Trade Secret Protection',
      category: 'ip_data',
      summary: 'Bilateral strict confidentiality standard, 5-year post-termination survival window, perpetual protection for trade secrets and source code, and injunctive relief.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Includes mandatory US Defend Trade Secrets Act (DTSA) 18 U.S.C. § 1833(b) whistleblower immunity notice and UK common law equitable breach of confidence protections.',
      fullLegalText: `6.1 Confidentiality Undertaking: Each Party ("Receiving Party") agrees that it shall hold in strict confidence, and not disclose, distribute, or disseminate to any third party, any proprietary, technical, operational, commercial, or financial information disclosed to it by the other Party ("Disclosing Party"), whether orally, visually, in writing, or in electronic format ("Confidential Information").

6.2 Standard of Care: The Receiving Party shall protect the Confidential Information of the Disclosing Party with the same degree of care it utilizes to protect its own confidential materials of a like nature, but in no event less than a reasonable standard of care, and shall restrict access strictly to its employees, officers, legal counsel, and vetted contractors who have a strict need to know for the purposes of this Agreement and who are bound by written confidentiality undertakings no less restrictive than those set forth herein.

6.3 Exclusions: Confidential Information shall not include information that: (a) is or becomes publicly available through no act or omission of the Receiving Party; (b) was already in the lawful possession of the Receiving Party prior to disclosure by the Disclosing Party, as demonstrated by contemporaneous written records; (c) is independently developed by the Receiving Party without reference to or reliance upon the Disclosing Party's Confidential Information; or (d) is rightfully received from a third party without breach of any confidentiality obligation.

6.4 Legally Compelled Disclosure: If the Receiving Party is ordered by a court of competent jurisdiction or administrative subpoena to disclose Confidential Information, it shall provide the Disclosing Party with immediate written notice (to the extent legally permissible) so that the Disclosing Party may seek a protective order, and shall disclose only that portion legally required.

6.5 Term of Confidentiality & Trade Secrets: The confidentiality covenants herein shall survive for a period of five (5) years following the termination or expiration of this Agreement; provided, however, that all Confidential Information constituting trade secrets, technical source code, or proprietary cryptographic keys under Applicable Law shall be maintained in strict confidence perpetually.`
    },
    {
      id: 'msa-sec-7',
      sectionNumber: 'Section 7',
      title: 'Data Processing Agreement (DPA) & Cross-Border Privacy Compliance',
      category: 'compliance',
      summary: 'Formal Controller-to-Processor DPA incorporating GDPR Article 28, India DPDPA 2023, California CCPA/CPRA, 24-48 hour breach notification, and certified deletion.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Directly satisfies statutory data fiduciary/processor rules under EU GDPR Art 28(3), India DPDPA 2023 Section 8, and Singapore PDPA 2012.',
      fullLegalText: `7.1 Roles of the Parties: With respect to any Personal Data processed under this Agreement, Customer acts as the Data Controller (or Data Fiduciary), and Service Provider acts as the Data Processor. Service Provider shall process Personal Data exclusively in accordance with Customer's documented instructions and solely to the extent necessary to perform the Services.

7.2 Statutory Compliance: Service Provider covenants that it shall strictly comply with all applicable Data Protection Legislation, including without limitation Regulation (EU) 2016/679 (GDPR), the UK Data Protection Act 2018, the California Consumer Privacy Act as amended (CCPA/CPRA), and the India Digital Personal Data Protection Act, 2023 (DPDPA).

7.3 Security Breach Notification Protocol: Service Provider shall notify Customer in writing without undue delay, and in any event within twenty-four (24) to forty-eight (48) hours, of confirming any unauthorized access, acquisition, disclosure, alteration, loss, or destruction of Customer Personal Data ("Security Incident"). The notification shall specify: (a) the nature of the breach; (b) the categories and approximate number of data subjects affected; (c) the anticipated consequences; and (d) the remedial actions undertaken.

7.4 Assistance with Regulatory Obligations & Data Subject Rights: Service Provider shall provide prompt and reasonable technical assistance to Customer to enable Customer to respond to statutory requests from data subjects exercising rights of access, correction, erasure, data portability, or objection, and shall assist Customer in conducting statutory Data Protection Impact Assessments (DPIA).`
    },
    {
      id: 'msa-sec-8',
      sectionNumber: 'Section 8',
      title: 'Cybersecurity Architecture, SOC 2 / ISO 27001 & Vulnerability Assessments',
      category: 'compliance',
      summary: 'Mandates ISO 27001 / SOC 2 Type II certifications, AES-256 / TLS 1.3 encryption, quarterly vulnerability assessments, and annual independent penetration tests.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Aligned with NIST Cybersecurity Framework 2.0, CERT-In cybersecurity directives, and ISO/IEC 27001:2022.',
      fullLegalText: `8.1 Information Security Architecture: Service Provider shall maintain a comprehensive, written Information Security Management System (ISMS) compliant with and certified under ISO/IEC 27001 standards, and shall undergo an independent American Institute of Certified Public Accountants (AICPA) SOC 2 Type II audit at least annually.

8.2 Encryption Standards: Service Provider shall implement industry-leading cryptographic safeguards, ensuring that all Customer Data is encrypted at rest using AES-256 bit encryption and in transit across public networks using Transport Layer Security (TLS 1.3 or higher).

8.3 Quarterly Vulnerability Scanning & Annual Penetration Testing: Service Provider shall perform automated vulnerability scanning across all infrastructure hosting Customer Data not less than once every calendar quarter, and shall engage an independent, CREST-accredited cybersecurity auditing firm to conduct rigorous penetration testing annually.

8.4 Vulnerability Remediation SLA: Service Provider shall remediate any identified cybersecurity vulnerabilities in accordance with the following mandatory remediation schedule:
    (a) Critical Severity Findings (CVSS Score 9.0 - 10.0): Remediation within seven (7) calendar days;
    (b) High Severity Findings (CVSS Score 7.0 - 8.9): Remediation within fourteen (14) calendar days;
    (c) Medium Severity Findings (CVSS Score 4.0 - 6.9): Remediation within thirty (30) calendar days.

8.5 Access Controls & Audit Logging: Service Provider shall enforce Multi-Factor Authentication (MFA) across all administrative access points, adhere strictly to Role-Based Access Control (RBAC) on a least-privilege basis, and retain immutable security audit logs for not less than one hundred eighty (180) days.`
    },
    {
      id: 'msa-sec-9',
      sectionNumber: 'Section 9',
      title: 'Substantive Mutual Indemnification & Procedural Defense Protocol',
      category: 'risk_liability',
      summary: 'Detailed indemnification covering IP infringement, data breaches, and gross negligence, with strict procedural defense control and settlement consent safeguards.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Enforceable under US and UK commercial standards. Restricts indemnitor from settling claims imposing monetary or injunctive burdens on the indemnitee without written consent.',
      fullLegalText: `9.1 Service Provider Indemnification: Service Provider shall defend, indemnify, and hold harmless Customer, its Affiliates, and their respective directors, officers, employees, agents, and permitted successors from and against any and all third-party claims, suits, actions, regulatory investigations, damages, liabilities, judgments, settlements, fines, penalties, costs, and reasonable legal expenses (including attorney's fees) arising out of or resulting from:
    (a) any actual or alleged infringement, misappropriation, or violation of any third party's patent, copyright, trademark, trade secret, or other intellectual property right by the Services or Deliverables;
    (b) any material breach of Section 7 (Data Protection) or Section 8 (Cybersecurity) resulting in a Security Incident; or
    (c) the gross negligence, willful misconduct, or intentional fraud of Service Provider or its personnel.

9.2 Customer Indemnification: Customer shall defend, indemnify, and hold harmless Service Provider and its Affiliates from and against any third-party claims arising out of: (a) Customer Data infringing third-party intellectual property or privacy rights; or (b) Customer's breach of Applicable Law.

9.3 Indemnification Procedures: The indemnified Party ("Indemnitee") shall: (i) provide prompt written notice of the claim to the indemnifying Party ("Indemnitor") within fifteen (15) Business Days of receiving formal notice thereof; (ii) grant the Indemnitor sole control of the defense and settlement negotiations; and (iii) provide reasonable cooperation at the Indemnitor's expense.

9.4 Settlement Limitations: The Indemnitor shall not enter into any settlement, compromise, or consent decree that: (a) imposes any financial liability or admission of fault on the Indemnitee; or (b) subjects the Indemnitee to injunctive or equitable restrictions, without the Indemnitee's prior written consent, which shall not be unreasonably withheld or delayed.`
    },
    {
      id: 'msa-sec-10',
      sectionNumber: 'Section 10',
      title: 'Representations, Warranties & Non-Infringement Covenants',
      category: 'risk_liability',
      summary: 'Mutual corporate authority representations, professional workmanlike standard, 90-day deliverable warranty, non-infringement, and software malware freedom.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'UCC § 2-316 disclaimer of implied warranties alongside express contractual warranties. Requires express non-infringement and anti-malware warranties.',
      fullLegalText: `10.1 Corporate Authority & Enforceability: Each Party represents and warrants to the other that: (a) it is a corporation or entity duly organized, validly existing, and in good standing under the laws of its jurisdiction of incorporation; (b) it possesses full corporate power and authority to enter into and perform this Agreement; and (c) the execution, delivery, and performance of this Agreement has been duly authorized and does not violate any other contractual commitment.

10.2 Professional Standards Warranty: Service Provider warrants and covenants that all Services performed hereunder shall be rendered in a professional, competent, and workmanlike manner, in strict accordance with the highest prevailing industry standards, by personnel possessing the necessary qualifications, skills, and certifications.

10.3 Deliverable Warranty: Service Provider warrants that for a period of ninety (90) calendar days following Customer's acceptance of any Deliverable ("Warranty Period"), the Deliverable shall function in all material respects in conformity with the specifications set forth in the applicable SOW. If any material non-conformity is identified within the Warranty Period, Service Provider shall promptly repair, replace, or correct the Deliverable at no additional charge.

10.4 Non-Infringement & Malware Freedom: Service Provider warrants that: (a) the Deliverables, Work Product, and Services do not and will not infringe, misappropriate, or violate any third-party intellectual property or proprietary rights; and (b) the software code delivered to Customer does not contain any computer virus, malware, trojan horse, worm, backdoor, time bomb, drop-dead device, or malicious disabling code designed to disrupt, disable, or harm Customer's systems.`
    },
    {
      id: 'msa-sec-11',
      sectionNumber: 'Section 11',
      title: 'Limitation of Liability, Super-Caps & Consequential Damages Disclaimer',
      category: 'risk_liability',
      summary: 'Mutual consequential damages waiver, aggregate liability ceiling equal to 12-month fees, 2x-3x super-cap for data privacy breaches, and uncapped carve-outs for IP and gross negligence.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Must comply with UK UCTA 1977 reasonableness, German AGB-Control § 307 BGB, and Delaware commercial liability jurisprudence.',
      fullLegalText: `11.1 Consequential Damages Waiver: To the maximum extent permitted by Applicable Law, neither Party, nor its Affiliates, directors, officers, or employees, shall be liable to the other Party for any indirect, incidental, special, exemplary, punitive, or consequential damages, or for any loss of profits, lost revenue, lost goodwill, business interruption, or loss of anticipated savings, whether arising in contract, tort (including negligence), strict liability, or otherwise, even if advised of the possibility of such damages.

11.2 General Aggregate Liability Ceiling: Except as expressly provided in Section 11.3 and Section 11.4, each Party's total aggregate liability arising out of or related to this Agreement, whether sounding in contract, tort, warranty, or statutory duty, shall be strictly capped at and shall not exceed the total fees actually paid or payable by Customer to Service Provider under this Agreement during the twelve (12) months immediately preceding the event giving rise to liability.

11.3 Enhanced Super-Cap for Data Incidents: For any claims arising from a material breach of Section 7 (Data Protection) or Section 8 (Cybersecurity) resulting in an unauthorized Security Incident, each Party's aggregate liability ceiling shall be expanded to a super-cap equal to two times (2x) the general liability ceiling specified in Section 11.2.

11.4 Uncapped Carve-Outs: The limitations and exclusions of liability set forth in Section 11.1 and Section 11.2 shall not apply to:
    (a) either Party's indemnification obligations under Section 9;
    (b) breach of Section 6 (Confidentiality), excluding routine operational data breaches;
    (c) infringement or misappropriation of either Party's intellectual property rights; or
    (d) damages caused by gross negligence, willful misconduct, intentional fraud, or death or bodily injury for which liability cannot be disclaimed under Applicable Law.`
    },
    {
      id: 'msa-sec-12',
      sectionNumber: 'Section 12',
      title: 'Comprehensive Corporate Insurance Mandates',
      category: 'risk_liability',
      summary: 'Requires Commercial General Liability ($2M), Cyber Risk & Privacy ($5M), Errors & Omissions ($2M), Workers Compensation, and 30-day cancellation notice.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'A-VII or better AM Best rating. Certificates of Insurance must name Customer as an Additional Insured on general and cyber policies.',
      fullLegalText: `12.1 Insurance Policies & Coverage Limits: Service Provider shall, at its own cost and expense, maintain in full force and effect during the Term and for a period of not less than two (2) years following the termination or expiration of this Agreement, comprehensive insurance policies issued by reputable insurers rated not less than "A- VII" by A.M. Best, comprising:
    (a) Commercial General Liability Insurance with minimum limits of $2,000,000 per occurrence and $4,000,000 in the aggregate, covering bodily injury, property damage, and contractual liability;
    (b) Cyber Risk, Network Security, and Privacy Liability Insurance with minimum limits of $5,000,000 per claim and aggregate, covering data breaches, regulatory fines, and forensics costs;
    (c) Professional Liability / Technology Errors and Omissions (E&O) Insurance with minimum limits of $2,000,000 per claim and aggregate; and
    (d) Statutory Workers' Compensation Insurance as required by Applicable Law, together with Employer's Liability coverage of not less than $1,000,000 per accident.

12.2 Additional Insured & Notice of Cancellation: Service Provider shall cause Customer to be designated as an Additional Insured on the Commercial General Liability and Cyber Liability policies. Service Provider shall furnish Certificates of Insurance upon execution and provides thirty (30) days prior written notice of cancellation or material reduction in coverage.`
    },
    {
      id: 'msa-sec-13',
      sectionNumber: 'Section 13',
      title: 'Term, Renewal & Multi-Tiered Termination Protocol',
      category: 'operational',
      summary: 'Initial 1-year term with automatic renewal, 30-day termination for convenience, immediate termination for material breach uncured within 30 days, or insolvency.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Provides objective cure periods and automatic termination triggers upon filing for bankruptcy or assignment for benefit of creditors.',
      fullLegalText: `13.1 Term of Agreement: This Agreement shall commence on the Effective Date and shall remain in full force and effect for an initial period of one (1) year ("Initial Term"), automatically renewing for successive one (1) year renewal terms unless either Party provides written notice of non-renewal not less than sixty (60) calendar days prior to the expiration of the then-current term.

13.2 Termination for Convenience: Customer may terminate this Agreement or any individual Statement of Work for convenience and without cause at any time by delivering not less than thirty (30) calendar days prior written notice to Service Provider.

13.3 Termination for Cause: Either Party may terminate this Agreement or any applicable SOW immediately upon delivery of written notice to the other Party:
    (a) if the other Party commits a material breach of this Agreement or an SOW and fails to cure such material breach within thirty (30) calendar days after receipt of written notice specifying the breach; or
    (b) immediately without a cure period if the other Party: (i) commits an incurable material breach; (ii) becomes insolvent, makes a general assignment for the benefit of creditors, or enters liquidation or bankruptcy proceedings; or (iii) repeatedly breaches Service Level commitments under Section 3.5.`
    },
    {
      id: 'msa-sec-14',
      sectionNumber: 'Section 14',
      title: 'Consequences of Termination, 90-Day Transition Assistance & Exit Management',
      category: 'operational',
      summary: 'Mandates orderly wind-down, pro-rata refund of unearned fees, 90-day transition assistance, machine-readable data return, and certified cryptographic destruction.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Prevents operational hostage situations upon termination. Crucial for financial institutions and mission-critical cloud deployments.',
      fullLegalText: `14.1 Orderly Wind-Down & Payment Reconciliation: Upon termination or expiration of this Agreement:
    (a) Service Provider shall immediately cease all work under affected SOWs in an orderly manner;
    (b) Customer shall pay Service Provider for all undisputed Services properly performed and accepted up to the effective termination date; and
    (c) Service Provider shall immediately refund to Customer, on a pro-rata basis, any unearned prepaid fees, deposits, or advance payments.

14.2 90-Day Disentanglement & Transition Assistance: Upon Customer's written request delivered prior to or within thirty (30) days following termination, Service Provider shall provide comprehensive transition assistance and knowledge transfer services for up to ninety (90) calendar days ("Transition Period") at Service Provider's then-current standard commercial rates to ensure uninterrupted business continuity and seamless migration of Services to Customer or a designated successor provider.

14.3 Customer Data Return & Certified Erasure: Within thirty (30) calendar days of termination, Service Provider shall: (a) provide Customer with a complete, secure export of all Customer Data in an unencrypted, industry-standard, machine-readable format (e.g. JSON, CSV, or standard SQL database dump); and (b) permanently erase and cryptographically shred all remaining copies of Customer Data across all active, standby, and backup servers, delivering a formal Certificate of Destruction signed by an executive officer within ten (10) Business Days thereafter.`
    },
    {
      id: 'msa-sec-15',
      sectionNumber: 'Section 15',
      title: 'Business Continuity & Disaster Recovery (BCP/DR)',
      category: 'operational',
      summary: 'Guarantees tested BCP/DR plans with Recovery Time Objective (RTO) <= 4 hours, Recovery Point Objective (RPO) <= 1 hour, and daily multi-region backups.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Fulfills institutional vendor risk management requirements (OCC, Fed, EBA, DORA, RBI outsourcing guidelines).',
      fullLegalText: `15.1 Disaster Recovery Standards: Service Provider covenants that it has implemented, and shall maintain and regularly test, a formal Business Continuity and Disaster Recovery Plan ("BCP/DR Plan") designed to ensure the rapid restoration of Services following any infrastructure disruption, power outage, natural disaster, cyber incident, or telecommunications failure.

15.2 Recovery Metrics (RTO & RPO): The BCP/DR Plan shall adhere to the following mandatory recovery metrics:
    (a) Recovery Time Objective (RTO): Restoration of core Services and operational availability within four (4) hours of a declared disaster event; and
    (b) Recovery Point Objective (RPO): Maximum data loss tolerance of not more than one (1) hour of transactional data, supported by continuous asynchronous replication and daily automated snapshots across geographically separated cloud availability zones.

15.3 Annual DR Simulation Audits: Service Provider shall conduct full disaster recovery simulation testing not less than once per calendar year and shall provide Customer, upon written request, with an executive summary of test results and corrective action plans.`
    },
    {
      id: 'msa-sec-16',
      sectionNumber: 'Section 16',
      title: 'Subcontracting Standards, Third-Party Flow-Down & Full Prime Liability',
      category: 'operational',
      summary: 'Requires prior written consent for subcontracting, mandatory flow-down of confidentiality and security covenants, and 100% prime contractor liability.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Essential for regulatory compliance under GDPR Art 28(2) and financial outsourcing frameworks.',
      fullLegalText: `16.1 Prior Consent Requirement: Service Provider shall not subcontract, delegate, or assign the performance of any material portion of the Services to any third-party subcontractor without the prior written consent of Customer.

16.2 Contractual Flow-Down Obligations: If Customer approves any subcontractor, Service Provider shall enter into a binding written agreement with such subcontractor containing confidentiality, data protection, intellectual property ownership, and cybersecurity obligations no less restrictive than those set forth in this Agreement.

16.3 Prime Contractor Liability: Service Provider shall remain at all times solely and primarily liable and responsible to Customer for the performance, acts, errors, defaults, and omissions of any and all subcontractors to the same extent as if performed directly by Service Provider's own employees.`
    },
    {
      id: 'msa-sec-17',
      sectionNumber: 'Section 17',
      title: 'Force Majeure, Excusable Delay & 30-Day Disruption Termination',
      category: 'boilerplate',
      summary: 'Excuses performance for extraordinary events beyond reasonable control, excluding payment obligations, requiring 5-day notice, and allowing termination after 30 days.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Strict common law doctrine of frustration vs. civil law force majeure. Expressly excludes routine cyber incidents, market inflation, or financial distress.',
      fullLegalText: `17.1 Excusable Events: Neither Party shall be liable or deemed in default for any failure or delay in performing its obligations under this Agreement (excluding Customer's obligation to pay undisputed fees) to the extent that such failure or delay arises directly from causes beyond its reasonable control and without its fault or negligence, including acts of God, war, armed hostility, declared national emergency, terrorism, riots, floods, earthquakes, pandemics, civil insurrections, or widespread national electrical power grid failures ("Force Majeure Event").

17.2 Notice & Mitigation Duties: The Party claiming relief under this Section shall: (a) notify the other Party in writing within five (5) Business Days of the commencement of the Force Majeure Event detailing the nature and expected duration; and (b) exercise commercially reasonable efforts to mitigate the effects and resume performance as promptly as practicable.

17.3 Disruption Termination Trigger: If a Force Majeure Event prevents or impairs either Party's material performance for more than thirty (30) consecutive calendar days, either Party shall have the right to terminate this Agreement immediately upon written notice without penalty or damages.`
    },
    {
      id: 'msa-sec-18',
      sectionNumber: 'Section 18',
      title: 'Anti-Bribery, Anti-Corruption & International Sanctions Compliance',
      category: 'compliance',
      summary: 'Strict zero-tolerance warranty for anti-corruption (FCPA, UKBA 2010, Indian PCA 1988) and compliance with US OFAC, BIS, and international trade sanctions.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Contains mandatory anti-corruption representations required for international institutional contracts and public entity compliance.',
      fullLegalText: `18.1 Anti-Corruption Laws: Each Party represents, warrants, and covenants that in connection with this Agreement, it and its directors, officers, employees, and agents have complied and shall strictly comply with all applicable anti-bribery and anti-corruption statutes, including without limitation the United States Foreign Corrupt Practices Act of 1977 (FCPA), the United Kingdom Bribery Act 2010, and the Indian Prevention of Corruption Act, 1988.

18.2 Prohibition on Improper Payments: Neither Party shall, directly or indirectly through intermediaries, offer, promise, give, request, accept, or agree to receive any bribe, rebate, kickback, improper gift, or unlawful pecuniary advantage to or from any public official, government entity, political candidate, or commercial party to obtain or retain business.

18.3 Trade Sanctions & Export Controls: Each Party represents and warrants that neither it nor any of its controlling shareholders or directors is designated on any sanctions or restricted party list maintained by the United States Government (including the OFAC Specially Designated Nationals List and BIS Entity List), the European Union, the United Kingdom, or the United Nations. Each Party covenants to strictly comply with all applicable dual-use and export control laws.`
    },
    {
      id: 'msa-sec-19',
      sectionNumber: 'Section 19',
      title: 'Annual Security & Compliance Audit Rights',
      category: 'compliance',
      summary: 'Grants Customer or independent certified auditors annual audit rights to inspect facilities, security logs, and compliance records upon 10 business days notice.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Subject to reasonable security procedures and strict non-disclosure obligations; limited to once per rolling twelve-month period unless following a confirmed breach.',
      fullLegalText: `19.1 Audit Rights: Upon not less than ten (10) Business Days prior written notice to Service Provider, Customer or its designated independent certified auditing firm (bound by customary professional confidentiality obligations) shall have the right, during normal business hours and without unreasonably disrupting Service Provider's business operations, to inspect, review, and audit Service Provider's facilities, IT operational logs, data security practices, disaster recovery controls, and invoice records directly relevant to the performance of Services.

19.2 Frequency: Audits conducted under Section 19.1 shall occur not more than once in any rolling twelve (12) month period; provided, however, that Customer shall have the right to conduct an immediate audit without limitation if Customer reasonably suspects or confirms a Security Incident or material regulatory breach.

19.3 Cost of Audit: Customer shall bear the costs of any audit, unless such audit reveals an overcharge exceeding five percent (5%) of invoiced amounts or a material deficiency in security safeguards, in which case Service Provider shall reimburse Customer for the reasonable actual cost of the audit within thirty (30) days.`
    },
    {
      id: 'msa-sec-20',
      sectionNumber: 'Section 20',
      title: 'Dispute Resolution, Executive Escalation & Binding Institutional Arbitration',
      category: 'dispute',
      summary: '30-day mandatory good-faith executive escalation, followed by final and binding institutional arbitration under designated rules (AAA / SIAC / ICC / LCIA).',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Governed by New York Convention on the Recognition and Enforcement of Foreign Arbitral Awards. Preserves right to seek interim injunctive relief in courts.',
      fullLegalText: `20.1 Executive Escalation: In the event of any controversy, claim, or dispute arising out of or relating to this Agreement, its interpretation, breach, or validity ("Dispute"), the Parties shall first endeavor to resolve the Dispute through good-faith consultations between their designated senior executive officers (e.g. Chief Executive Officer, Chief Operating Officer, or General Counsel) for a period of thirty (30) calendar days following written notice of the Dispute.

20.2 Binding Institutional Arbitration: If the Dispute is not resolved within the thirty (30) day executive escalation period, the Dispute shall be finally and exclusively settled by binding arbitration administered by the designated arbitration institution set forth in the Agreement (such as the American Arbitration Association (AAA) under its Commercial Arbitration Rules, the Singapore International Arbitration Centre (SIAC), or the International Chamber of Commerce (ICC)).

20.3 Arbitral Tribunal & Language: The tribunal shall consist of a single neutral arbitrator appointed in accordance with the applicable arbitral rules. The seat and legal venue of arbitration shall be the forum designated in the Agreement. All arbitral proceedings, submissions, and evidentiary hearings shall be conducted entirely in the English language.

20.4 Finality & Enforcement: The arbitral award shall be final, conclusive, and binding upon both Parties, and judgment upon the award may be entered and enforced in any court having jurisdiction thereof pursuant to the United Nations Convention on the Recognition and Enforcement of Foreign Arbitral Awards (the New York Convention).

20.5 Interim Equitable Relief: Nothing in this Section 20 shall preclude either Party from seeking preliminary or interim injunctive or equitable relief from a court of competent jurisdiction to prevent irreparable harm or preserve the status quo pending the constitution of the arbitral tribunal.`
    },
    {
      id: 'msa-sec-21',
      sectionNumber: 'Section 21',
      title: 'Governing Law, Severability, Survival & Entire Agreement Boilerplate',
      category: 'boilerplate',
      summary: 'Express choice of substantive law, four-corners merger clause, amendments in writing only, blue-pencil severability, and explicit enumeration of surviving covenants.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Excludes UN Convention on Contracts for the International Sale of Goods (CISG). Strictly enforces no-oral-modification doctrine.',
      fullLegalText: `21.1 Governing Law: This Agreement, and all claims or causes of action arising out of or relating to this Agreement, shall be governed by and construed in accordance with the substantive laws of the jurisdiction specified in the Agreement, without giving effect to any choice of law or conflict of laws principles that would cause the application of the laws of any other jurisdiction. The United Nations Convention on Contracts for the International Sale of Goods (CISG) is expressly excluded.

21.2 Entire Agreement & Merger Clause: This Agreement, together with all executed Statements of Work, Service Level Agreements, Data Processing Addenda, schedules, and exhibits attached hereto, constitutes the complete, final, and exclusive agreement between the Parties concerning the subject matter hereof, and supersedes and merges all prior or contemporaneous negotiations, representations, discussions, proposals, understandings, or warranties, whether oral or written.

21.3 Written Amendments Only: No modification, variation, amendment, or waiver of any provision of this Agreement shall be valid or enforceable unless set forth in a formal written amendment explicitly referencing this Agreement and duly signed by authorized executive officers of both Parties.

21.4 Severability: If any term, provision, or covenant of this Agreement is held to be invalid, illegal, or unenforceable by an arbitrator or court of competent jurisdiction, such provision shall be severed or reformed to the minimum extent necessary, and the remaining provisions shall continue in full force and effect.

21.5 Express Survival: Sections 1 (Definitions), 4 (Commercial Terms), 5 (Intellectual Property), 6 (Confidentiality), 7 (Data Protection), 9 (Indemnification), 10 (Warranties), 11 (Limitation of Liability), 14 (Exit Management), 20 (Dispute Resolution), and 21 (Boilerplate) shall survive the expiration or termination of this Agreement for any reason.

21.6 Counterparts & Electronic Signatures: This Agreement may be executed in any number of counterparts, each of which shall be deemed an original, and all of which together shall constitute one and the same instrument. The Parties consent to the execution and delivery of this Agreement by electronic, digital, or encrypted signature (including DocuSign, Adobe Sign, or cryptographic e-signatures) in accordance with the US E-SIGN Act, the Uniform Electronic Transactions Act (UETA), the Indian Information Technology Act, 2000, and Regulation (EU) No 910/2014 (eIDAS).`
    }
  ],

  'tmpl-saas': [
    {
      id: 'saas-sec-1',
      sectionNumber: 'Section 1',
      title: 'Grant of Subscription License & Authorized User Restrictions',
      category: 'operational',
      summary: 'Non-exclusive, worldwide subscription license to access the hosted cloud platform, user seat allocations, and strict prohibitions on reverse engineering or timesharing.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Defines the pure SaaS subscription model (services hosted in the cloud, no on-premises code delivery), avoiding copyright exhaustion or software sale characterization.',
      fullLegalText: `1.1 Subscription Grant: Subject to Customer's timely payment of all subscription fees and compliance with this Agreement, Vendor hereby grants to Customer a non-exclusive, non-transferable, non-sublicensable, worldwide right and subscription license during the Subscription Term to access and utilize the Cloud Software Platform ("Platform") solely for Customer's internal business operations in accordance with the published technical documentation.

1.2 Authorized Users: Customer may permit its designated employees, officers, independent consultants, and contractors ("Authorized Users") to access the Platform, provided that Customer: (a) issues unique, non-shared credentials for each user seat; (b) maintains accurate user rosters; and (c) ensures that all Authorized Users strictly adhere to the usage rules set forth herein.

1.3 Usage Restrictions: Customer shall not, and shall not permit any third party to:
    (a) copy, modify, adapt, translate, create derivative works of, or reverse engineer, decompile, disassemble, or attempt to derive the underlying source code, algorithms, or proprietary structures of the Platform;
    (b) rent, lease, lend, sell, resell, sublicense, distribute, or operate the Platform on a service bureau, timesharing, application service provider (ASP), or white-label basis;
    (c) bypass, disable, circumvent, or defeat any security controls, user authentication limits, digital watermarks, or usage metering mechanisms;
    (d) access the Platform in order to build a competitive product or service, or copy any features, functions, or graphics of the Platform; or
    (e) use the Platform to transmit, store, or process malicious code, trojans, worms, unlawful material, or information that infringes any third party's intellectual property or privacy rights.`
    },
    {
      id: 'saas-sec-2',
      sectionNumber: 'Section 2',
      title: 'Service Level Agreement (SLA), 99.9% Uptime & Service Credit Calculation',
      category: 'operational',
      summary: 'Guarantees 99.9% monthly platform availability, scheduled maintenance exclusions, 10% to 50% subscription fee credits, and termination for persistent degradation.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Monthly SLA credit is the sole and exclusive financial remedy for downtime, but preserves contract termination if uptime is below 95% for 2 consecutive months.',
      fullLegalText: `2.1 Availability Commitment: Vendor warrants that the Platform shall maintain an aggregate Monthly Uptime Availability of not less than ninety-nine and nine-tenths percent (99.9%), calculated as: [(Total Operational Minutes in Month - Unscheduled Downtime Minutes) / Total Operational Minutes in Month] * 100%.

2.2 Exclusions from Downtime: Unscheduled downtime shall not include downtime resulting from: (a) Scheduled Maintenance conducted between 00:00 and 04:00 UTC with at least forty-eight (48) hours advance notice; (b) Customer's equipment, local network failures, or unapproved integrations; or (c) widespread telecommunications backbone outages or Force Majeure Events.

2.3 Tiered Financial Service Credits: If Vendor fails to meet the 99.9% Monthly Uptime threshold, Customer shall receive financial Service Credits against the next subscription invoice:
    - 99.0% to 99.89% Uptime: 10% of monthly subscription fee;
    - 95.0% to 98.99% Uptime: 25% of monthly subscription fee;
    - Less than 95.0% Uptime: 50% of monthly subscription fee.

2.4 Persistent SLA Failure: If Monthly Uptime Availability falls below ninety-five percent (95.0%) for two (2) consecutive calendar months, Customer may terminate this Agreement immediately upon written notice and receive a pro-rata refund of all prepaid unearned subscription fees.`
    },
    {
      id: 'saas-sec-3',
      sectionNumber: 'Section 3',
      title: 'Customer Data Ownership, Hosting Architecture & DPA Compliance',
      category: 'ip_data',
      summary: 'Customer retains 100% ownership of Customer Data. Vendor processes strictly as Data Processor under GDPR Art 28 / DPDPA 2023 with 24-48h breach notification.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Complies with GDPR Article 28, UK GDPR, California CCPA/CPRA, and India DPDPA 2023. Vendor is designated as a pure service provider / data processor.',
      fullLegalText: `3.1 Exclusive Ownership of Customer Data: Customer retains sole, exclusive, and unencumbered title, copyright, ownership, and all intellectual property rights in and to all electronic data, files, customer profiles, logs, and database entries inputted, uploaded, or generated by Customer or its Authorized Users ("Customer Data"). Vendor acquires no right, title, or interest in Customer Data other than the limited right to host and process such data solely to provide the Platform services.

3.2 Data Privacy & Security Commitments: To the extent Customer Data includes Personal Data, Vendor acts strictly as a Data Processor. Vendor shall:
    (a) process Customer Data solely upon documented instructions of Customer;
    (b) enforce strict administrative, technical, and physical safeguards conforming to ISO/IEC 27001 and AICPA SOC 2 Type II standards;
    (c) maintain AES-256 bit encryption at rest and TLS 1.3 encryption in transit across all environments; and
    (d) maintain strict logical multi-tenant data isolation preventing co-mingling of Customer Data with data of any other vendor customer.

3.3 Security Incident Notification Protocol: In the event of any confirmed or suspected unauthorized access, breach, loss, or alteration of Customer Data, Vendor shall notify Customer in writing within twenty-four (24) to forty-eight (48) hours of becoming aware of the incident, provide forensic root-cause reports, and take immediate remedial action at Vendor's sole expense.`
    },
    {
      id: 'saas-sec-4',
      sectionNumber: 'Section 4',
      title: 'Subscription Fees, Tiered Overages & Automatic Renewal Protocols',
      category: 'commercial',
      summary: 'Annual/monthly subscription fee structures, Net 30 day payment windows, tiered usage overages, 5% max annual price increase cap, and 60-day non-renewal notice.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Enforces statutory e-commerce auto-renewal disclosure requirements (e.g. California ARL Cal. Bus. & Prof. Code § 17600 et seq.).',
      fullLegalText: `4.1 Subscription Consideration: Customer shall pay the recurring subscription fees set forth in the Order Form. Unless otherwise specified, subscription fees shall be invoiced annually in advance and are payable Net thirty (30) calendar days from receipt of a valid tax invoice.

4.2 Usage Tiers & Overage Reconciliation: If Customer's utilization of the Platform (such as API call volume, compute units, storage capacity, or active seat counts) exceeds the tier allowances specified in the Order Form, Vendor shall notify Customer and invoice such excess usage at the agreed contractual overage rates.

4.3 Automatic Renewal & Non-Renewal Notice: Upon expiration of the Initial Subscription Term, this Agreement shall automatically renew for successive one (1) year subscription periods, unless either Party provides written notice of non-renewal not less than sixty (60) calendar days prior to the expiration of the then-current subscription term.

4.4 Price Adjustments on Renewal: Vendor may adjust subscription fees effective upon commencement of a renewal term, provided that: (a) Vendor gives Customer written notice of the proposed fee adjustment not less than seventy-five (75) days prior to the renewal date; and (b) any such increase shall not exceed the lesser of five percent (5.0%) or the annual increase in the Consumer Price Index.`
    },
    {
      id: 'saas-sec-5',
      sectionNumber: 'Section 5',
      title: 'Vendor Intellectual Property, Feedback License & Restrictions',
      category: 'ip_data',
      summary: 'Vendor retains all proprietary rights, trademarks, and source code of the cloud platform. Customer grants non-exclusive feedback license.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Guarantees that SaaS customer receives no copyright or patent assignment in the vendor platform while ensuring customer retains all custom data.',
      fullLegalText: `5.1 Reservation of Rights: As between the Parties, Vendor and its third-party licensors own and retain all right, title, and interest (including all patents, patent applications, copyrights, trade secrets, trademarks, service marks, database rights, and domain names) in and to: (a) the Platform, underlying source code, APIs, algorithms, and documentation; (b) any software, modifications, enhancements, bug fixes, or custom features developed by Vendor; and (c) all aggregated and de-identified operational performance telemetry generated by the Platform.

5.2 Customer Feedback: If Customer or any Authorized User submits suggestions, ideas, enhancement requests, or feedback regarding the Platform ("Feedback"), Customer hereby grants to Vendor a worldwide, royalty-free, fully paid-up, perpetual, irrevocable license to use, incorporate, and commercially exploit such Feedback into the Platform without accounting, attribution, or compensation.`
    },
    {
      id: 'saas-sec-6',
      sectionNumber: 'Section 6',
      title: 'Vendor Intellectual Property Infringement Indemnification',
      category: 'risk_liability',
      summary: 'Vendor defends and indemnifies Customer against third-party IP claims, with obligation to procure license, modify platform, or refund unearned prepaid fees.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Standard market SaaS defense covenant protecting enterprise customers against patent troll claims and proprietary code copyright disputes.',
      fullLegalText: `6.1 IP Indemnity: Vendor shall defend, indemnify, and hold harmless Customer, its Affiliates, directors, officers, and employees from and against any and all third-party claims, lawsuits, liabilities, damages, judgments, and reasonable legal defense costs (including attorney's fees) arising out of or resulting from any allegation that Customer's authorized use of the Platform infringes or misappropriates any third party's valid patent, copyright, trademark, or trade secret.

6.2 Mitigation & Replacement Remedies: If the Platform becomes, or in Vendor's reasonable opinion is likely to become, the subject of an infringement claim, Vendor shall, at its sole election and expense:
    (a) procure for Customer the right to continue utilizing the Platform;
    (b) replace or modify the Platform so that it becomes non-infringing while providing substantially equivalent functionality; or
    (c) if neither (a) nor (b) is commercially feasible, terminate this Agreement and immediately refund to Customer all prepaid unearned subscription fees calculated on a pro-rata basis for the remaining balance of the subscription term.`
    },
    {
      id: 'saas-sec-7',
      sectionNumber: 'Section 7',
      title: 'Limitation of Liability & 2x Super-Cap for Data Privacy Breaches',
      category: 'risk_liability',
      summary: 'Consequential damages disclaimer, 12-month fees liability cap, 2x super-cap for data privacy breaches, and uncapped carve-outs for IP indemnity and gross negligence.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Provides appropriate balance between SaaS vendor risk profile and enterprise customer data protection liability exposure.',
      fullLegalText: `7.1 Consequential Damages Disclaimer: In no event shall either Party or its Affiliates be liable to the other Party for any lost profits, lost revenues, loss of data, loss of business opportunities, or any indirect, special, incidental, punitive, or consequential damages arising out of or related to this Agreement, regardless of the legal theory asserted.

7.2 Standard Liability Cap: Except as provided in Section 7.3 and Section 7.4, each Party's maximum aggregate cumulative liability arising out of or relating to this Agreement shall be limited strictly to the total subscription fees actually paid by Customer to Vendor in the twelve (12) months immediately preceding the incident giving rise to liability.

7.3 Enhanced Data Breach Super-Cap: For any liability arising from Vendor's breach of Section 3 (Data Ownership & Security) resulting in unauthorized disclosure or loss of Customer Personal Data, Vendor's aggregate liability ceiling shall be expanded to two times (2x) the standard liability cap specified in Section 7.2.

7.4 Carve-Outs: Nothing in this Section 7 shall limit or exclude either Party's liability for: (a) Vendor's indemnification obligations under Section 6; (b) Customer's breach of Section 1.3 (Usage Restrictions); (c) Customer's fee payment obligations; or (d) damages resulting from gross negligence, willful misconduct, or intentional fraud.`
    },
    {
      id: 'saas-sec-8',
      sectionNumber: 'Section 8',
      title: 'Post-Termination Data Retrieval, Portability & Certified Purge',
      category: 'operational',
      summary: 'Provides 30-day post-termination transition window for data extraction in CSV/JSON/SQL format followed by certified cryptographic deletion within 30 days.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Satisfies statutory requirements under GDPR Art 20 (right to data portability) and ensures orderly data egress without vendor lock-in.',
      fullLegalText: `8.1 30-Day Data Retrieval Window: For a period of thirty (30) calendar days following the effective date of termination or expiration of this Agreement ("Retrieval Window"), Vendor shall maintain Customer Data available on the Platform and permit Customer to extract and download all Customer Data at no additional charge in an industry-standard, unencrypted, machine-readable format (such as JSON, CSV, XML, or standard SQL database dump).

8.2 Certified Cryptographic Erasure: Upon expiration of the 30-day Retrieval Window, or immediately upon Customer's earlier written request, Vendor shall permanently overwrite, de-identify, and cryptographically erase all electronic copies of Customer Data across all production, staging, and backup environments in accordance with DoD 5220.22-M or NIST SP 800-88 Rev. 1 standards. Vendor shall furnish an officer-certified Certificate of Destruction to Customer within fifteen (15) Business Days thereafter.`
    },
    {
      id: 'saas-sec-9',
      sectionNumber: 'Section 9',
      title: 'Governing Law, Institutional Arbitration & Miscellaneous Provisions',
      category: 'boilerplate',
      summary: 'Choice of governing law, binding arbitration, severability, no-oral-modification, and valid electronic execution.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Excludes CISG. Authorizes electronic signing and standard severability.',
      fullLegalText: `9.1 Governing Law & Venue: This Agreement shall be governed by, and construed in accordance with, the laws of the jurisdiction specified in the Order Form, without regard to principles of conflicts of law. Any unresolved dispute arising under this Agreement shall be finally determined by binding commercial arbitration administered by the designated arbitration body under its expedited commercial rules.

9.2 Entire Agreement: This Agreement, together with all executed Order Forms, DPAs, and Service Level Agreements, represents the entire and integrated agreement between the Parties and supersedes all prior negotiations, proposals, purchase order terms, or representations.

9.3 Force Majeure & Severability: Neither Party shall be liable for failure to perform due to events beyond its reasonable control, excluding payment obligations. If any provision is deemed unenforceable, all other terms shall remain in full force and effect.`
    }
  ],

  'tmpl-nda-mutual': [
    {
      id: 'nda-sec-1',
      sectionNumber: 'Section 1',
      title: 'Comprehensive Definition of Confidential Information & Markings',
      category: 'ip_data',
      summary: 'Broad definition encompassing technical source code, financial models, customer lists, architecture blueprints, roadmaps, and commercial deal negotiations.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Encompasses both marked tangible materials and oral disclosures that a reasonable person would understand to be confidential.',
      fullLegalText: `1.1 Scope of Confidential Information: "Confidential Information" means any and all non-public, proprietary, commercial, operational, financial, or technical information, data, materials, or know-how disclosed by or on behalf of one Party ("Disclosing Party") to the other Party ("Receiving Party"), whether disclosed directly or indirectly, orally, visually, in writing, in electronic format, or by inspection of tangible objects, that is:
    (a) designated or marked as "Confidential", "Proprietary", or with similar legend at the time of disclosure; or
    (b) by its nature or the circumstances surrounding its disclosure, should reasonably be understood by a person of ordinary commercial prudence to be confidential.

1.2 Inclusions: Confidential Information includes, without limitation: (i) computer software, source code, object code, API endpoints, algorithms, system architecture, database schematics, cryptographic keys, and technical documentation; (ii) product roadmaps, inventions, patent applications, research data, and experimental prototypes; (iii) financial forecasts, pricing models, revenue figures, cost structures, investor presentations, and capitalization tables; (iv) customer rosters, prospective client pipelines, supplier contracts, and marketing strategies; and (v) the fact that the Parties are in commercial discussions and the terms of this Agreement.`
    },
    {
      id: 'nda-sec-2',
      sectionNumber: 'Section 2',
      title: 'Standard Legal Exclusions from Confidentiality Obligations',
      category: 'ip_data',
      summary: 'Standard 4-prong exclusions: public knowledge, prior possession, independent development, and rightful third-party receipt.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Burden of proof rests on the Receiving Party to substantiate the exclusion via contemporaneous written records.',
      fullLegalText: `2.1 Exclusions: Confidential Information shall not include, and the confidentiality covenants herein shall not apply to, any information that the Receiving Party can demonstrate by clear and convincing contemporaneous written records:
    (a) is or becomes publicly known and generally available to the public through no breach of this Agreement or wrongful act or omission of the Receiving Party or its Representatives;
    (b) was already in the lawful, unencumbered possession of the Receiving Party prior to disclosure by the Disclosing Party, without confidentiality restriction;
    (c) is independently developed by employees or contractors of the Receiving Party who had no access to, knowledge of, or reference to the Disclosing Party's Confidential Information; or
    (d) is rightfully received by the Receiving Party on an unrestricted basis from a third party who had the lawful right to disclose such information without breaching any confidentiality obligation to the Disclosing Party.`
    },
    {
      id: 'nda-sec-3',
      sectionNumber: 'Section 3',
      title: 'Non-Disclosure, Non-Use & Reasonable Standard of Care Obligations',
      category: 'ip_data',
      summary: 'Prohibits unauthorized disclosure, limits use strictly to the defined Purpose, mandates reasonable standard of care, and prohibits reverse engineering.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Prevents commercial exploitation of confidential disclosures and forbids disassembly of sample code, APIs, or physical prototypes.',
      fullLegalText: `3.1 Strict Duty of Confidentiality: The Receiving Party covenants that it shall: (a) protect and preserve the Disclosing Party's Confidential Information from unauthorized disclosure, publication, or dissemination with the same degree of care it utilizes to protect its own confidential materials of a like nature, but in no event less than a reasonable standard of care; and (b) not disclose, publish, or release Confidential Information to any third party without the express prior written authorization of the Disclosing Party.

3.2 Strict Limitation of Use: The Receiving Party shall use the Confidential Information solely and exclusively for the purpose of evaluating, negotiating, and structuring a prospective commercial collaboration, transaction, or business relationship between the Parties ("Purpose"), and for no other commercial, operational, or competitive purpose whatsoever.

3.3 Reverse Engineering Prohibition: The Receiving Party shall not decompile, disassemble, reverse engineer, decrypt, analyze the physical structure of, or attempt to derive the underlying source code, algorithms, chemical composition, or manufacturing specifications of any hardware, software, prototypes, samples, or materials provided by the Disclosing Party.`
    },
    {
      id: 'nda-sec-4',
      sectionNumber: 'Section 4',
      title: 'Authorized Disclosures to Representatives & Need-to-Know Standard',
      category: 'ip_data',
      summary: 'Limits disclosures to directors, employees, attorneys, and accountants with a strict need to know under written NDA obligations. Receiving Party remains liable.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Standard market practice requiring prime party liability for all acts of its professional advisors and representatives.',
      fullLegalText: `4.1 Permitted Disclosures to Representatives: The Receiving Party may disclose Confidential Information solely to those of its directors, officers, employees, legal counsel, accountants, and financial advisors (collectively, "Representatives") who:
    (a) have a strict "need to know" such information for the evaluation or furtherance of the Purpose;
    (b) are informed of the highly confidential nature of the information; and
    (c) are bound by written employment agreements or professional codes of conduct imposing confidentiality obligations at least as restrictive as those contained in this Agreement.

4.2 Responsibility for Representatives: The Receiving Party shall remain solely and primarily responsible and liable for any unauthorized disclosure, publication, or misuse of Confidential Information by any of its Representatives to the same extent as if performed directly by the Receiving Party.`
    },
    {
      id: 'nda-sec-5',
      sectionNumber: 'Section 5',
      title: 'Legally Compelled Disclosures & Prior Written Notice Protocol',
      category: 'ip_data',
      summary: 'Requires immediate written notice prior to disclosure under court subpoena, duty to assist with protective orders, and disclosure limited to legally required portion.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Prevents contempt of court while preserving the Disclosing Party\'s right to seek emergency protective orders or in camera inspection.',
      fullLegalText: `5.1 Compelled Disclosures: In the event that the Receiving Party or any of its Representatives becomes legally compelled by applicable law, regulation, valid court order, subpoena, or administrative summons to disclose any Confidential Information, the Receiving Party shall:
    (a) provide the Disclosing Party with immediate written notice (to the extent legally permissible) so that the Disclosing Party may seek an appropriate protective order, confidential treatment, or other protective remedy;
    (b) consult in good faith with the Disclosing Party regarding the scope of disclosure and provide reasonable cooperation at the Disclosing Party's expense; and
    (c) disclose only that portion of the Confidential Information that its legal counsel advises is strictly legally required to be disclosed, exercising all reasonable efforts to obtain reliable assurances that confidential treatment shall be accorded to such information.`
    },
    {
      id: 'nda-sec-6',
      sectionNumber: 'Section 6',
      title: 'Return or Certified Destruction of Materials & Archival Carve-Out',
      category: 'operational',
      summary: 'Mandates return or certified destruction within 14 days, with a standard carve-out for automated immutable disaster recovery backups kept under ongoing NDA.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Reflects modern enterprise IT reality where magnetic backup tapes cannot be selectively deleted, while maintaining permanent confidentiality.',
      fullLegalText: `6.1 Return or Destruction Obligation: Upon the written request of the Disclosing Party, or upon the expiration or termination of this Agreement, the Receiving Party shall, within fourteen (14) calendar days:
    (a) return to the Disclosing Party, or destroy and permanently erase, all documents, memoranda, notes, electronic records, files, disks, models, and prototypes containing or reflecting Confidential Information; and
    (b) provide a formal written Certificate of Destruction signed by an executive officer confirming full compliance with this Section.

6.2 Archival IT Backup Carve-Out: The Receiving Party may retain: (i) one (1) secure copy of Confidential Information in its legal department files solely for compliance and evidentiary defense purposes; and (ii) electronic copies created pursuant to routine automated disaster recovery server backups, provided that all such retained materials shall remain strictly subject to the confidentiality covenants of this Agreement until permanently purged in the ordinary course of business.`
    },
    {
      id: 'nda-sec-7',
      sectionNumber: 'Section 7',
      title: 'Post-Termination Survival (3-5 Years) & Perpetual Trade Secret Protection',
      category: 'ip_data',
      summary: 'Confidentiality covenants survive for 5 years from disclosure, provided that trade secrets and proprietary source code survive in perpetuity.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Perpetual trade secret survival is essential under the Uniform Trade Secrets Act (UTSA) and Defend Trade Secrets Act (DTSA).',
      fullLegalText: `7.1 Term of Agreement: This Agreement shall govern all Confidential Information disclosed by either Party for a period of two (2) years from the Effective Date ("Disclosure Term"), unless earlier terminated by either Party upon thirty (30) days prior written notice.

7.2 Survival of Confidentiality Obligations: The obligations of confidentiality, non-disclosure, and non-use set forth in this Agreement shall survive the expiration or termination of this Agreement for a period of five (5) years following the date of disclosure of the respective Confidential Information; provided, however, that all Confidential Information that constitutes a "trade secret" under Applicable Law, including technical source code, encryption keys, and core algorithmic formulations, shall remain strictly subject to the confidentiality and non-use covenants of this Agreement perpetually for so long as such information remains a trade secret under Applicable Law.`
    },
    {
      id: 'nda-sec-8',
      sectionNumber: 'Section 8',
      title: 'Injunctive Relief, Specific Performance & No Bond Mandate',
      category: 'risk_liability',
      summary: 'Mutual acknowledgment of irreparable harm upon breach, entitling Disclosing Party to seek immediate temporary and permanent injunctive relief without posting bond.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Standard equitable relief clause enforcing specific performance under common law and equity jurisprudence.',
      fullLegalText: `8.1 Irreparable Harm & Equitable Remedies: The Receiving Party acknowledges and agrees that: (a) any breach or threatened breach of the confidentiality covenants contained in this Agreement will cause immediate, irreparable, and substantial harm to the Disclosing Party; (b) monetary damages alone would be an inadequate, incomplete, and insufficient remedy for any such breach; and (c) the Disclosing Party shall be entitled to seek and obtain immediate injunctive relief, specific performance, temporary restraining orders, and other equitable remedies from any court of competent jurisdiction to restrain any breach or threatened breach, without the necessity of proving actual damages or posting any bond or other security.`
    },
    {
      id: 'nda-sec-9',
      sectionNumber: 'Section 9',
      title: 'Defend Trade Secrets Act (DTSA) Statutory Whistleblower Immunity Notice',
      category: 'compliance',
      summary: 'Mandatory statutory immunity notice under 18 U.S.C. § 1833(b) for confidential disclosures to government officials or in anti-retaliation lawsuits.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Mandatory under US Defend Trade Secrets Act of 2016. Failure to include this notice forfeits exemplary damages and attorney fees in federal trade secret lawsuits.',
      fullLegalText: `9.1 Statutory Whistleblower Immunity Notice (18 U.S.C. § 1833(b)): The Receiving Party is hereby notified that under the Defend Trade Secrets Act of 2016:
    (a) An individual shall not be held criminally or civilly liable under any federal or state trade secret law for the disclosure of a trade secret that: (i) is made in confidence to a federal, state, or local government official, either directly or indirectly, or to an attorney, solely for the purpose of reporting or investigating a suspected violation of law; or (ii) is made in a complaint or other document filed in a lawsuit or other proceeding, if such filing is made under seal.
    (b) An individual who files a lawsuit for retaliation by an employer for reporting a suspected violation of law may disclose the trade secret to the attorney of the individual and use the trade secret information in the court proceeding, if the individual files any document containing the trade secret under seal and does not disclose the trade secret, except pursuant to court order.`
    },
    {
      id: 'nda-sec-10',
      sectionNumber: 'Section 10',
      title: 'Governing Law, Jurisdiction & Dispute Resolution',
      category: 'boilerplate',
      summary: 'Express choice of substantive governing law, consent to personal jurisdiction, and attorney fee shifting for prevailing party in enforcement actions.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Includes prevailing party legal fee recovery to deter intentional breaches and bad-faith litigation.',
      fullLegalText: `10.1 Governing Law: This Agreement shall be governed by, and construed and enforced in accordance with, the substantive laws of the governing jurisdiction specified in the Agreement, without regard to conflict of laws rules.

10.2 Jurisdiction & Submission: Each Party irrevocably submits to the exclusive personal jurisdiction of the courts located in the designated forum for the resolution of any action, claim, or equitable enforcement proceeding arising under this Agreement.

10.3 Prevailing Party Attorney Fees: In the event of any litigation, arbitration, or legal proceeding brought by either Party to enforce or interpret any provision of this Agreement, the prevailing Party shall be entitled to recover from the non-prevailing Party all reasonable attorney's fees, court costs, and related legal expenses incurred.`
    }
  ],

  'tmpl-employment': [
    {
      id: 'emp-sec-1',
      sectionNumber: 'Section 1',
      title: 'Executive Appointment, Duties, Reporting Line & Fiduciary Covenants',
      category: 'operational',
      summary: 'Formal appointment to executive office, full-time commitment, fiduciary duties of loyalty and care, reporting to Board or CEO, and travel requirements.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Defines full-time dedication to company affairs while permitting passive personal investments and charitable activities.',
      fullLegalText: `1.1 Appointment & Office: Company hereby employs Executive, and Executive hereby accepts employment with Company, in the executive capacity specified in the Agreement. Executive shall perform all duties, exercise all powers, and assume all responsibilities customary to such executive office and as may be reasonably assigned from time to time by the Chief Executive Officer or Board of Directors.

1.2 Full-Time Commitment & Fiduciary Duty: Executive shall devote Executive's full professional time, undivided attention, energy, and best efforts to the business and affairs of Company, and shall faithfully and diligently advance Company's business interests. Executive owes Company a strict fiduciary duty of loyalty, care, and good faith, and covenants not to engage in any outside commercial activity or business enterprise that conflicts with Company's business without prior written approval of the Board.`
    },
    {
      id: 'emp-sec-2',
      sectionNumber: 'Section 2',
      title: 'Compensation Structure, Performance Bonuses & Equity Vesting',
      category: 'commercial',
      summary: 'Annual base salary, annual performance bonus metrics, equity incentive stock option vesting schedule, and payroll tax withholding.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Complies with US IRC § 409A deferred compensation rules, UK PAYE, and Indian Income Tax Act Section 192 TDS rules.',
      fullLegalText: `2.1 Base Remuneration: Company shall pay Executive an initial annual gross base salary set forth in the Agreement, payable in equal periodic installments in accordance with Company's customary executive payroll practices, subject to all statutory payroll tax deductions, withholdings, and contributions.

2.2 Annual Discretionary Performance Bonus: For each completed fiscal year of employment, Executive shall be eligible to earn an annual performance cash bonus with a target percentage established by the Board of Directors, contingent upon the achievement of corporate performance targets and individual management objectives.

2.3 Equity Incentive Grants: Subject to approval by the Board of Directors and the terms of Company's Equity Incentive Plan, Executive shall be granted stock options or restricted stock units (RSUs) subject to standard four-year vesting (twenty-five percent (25%) vesting after a one-year cliff, and the remainder vesting in equal monthly installments over the following thirty-six (36) months).`
    },
    {
      id: 'emp-sec-3',
      sectionNumber: 'Section 3',
      title: 'Executive Benefits, Health Insurance, Paid Time Off & Business Expenses',
      category: 'commercial',
      summary: 'Medical, dental, vision, life, and disability coverage; 401(k) retirement plan; annual paid time off (PTO); and prompt business expense reimbursement.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Meets statutory employee benefits standards (ERISA, ACA, statutory leaves under local labor codes).',
      fullLegalText: `3.1 Executive Benefit Plans: Executive and Executive's eligible dependents shall be entitled to participate in all employee benefit plans and programs established by Company for senior executive personnel, including comprehensive health, dental, vision, group life, and long-term disability insurance, and 401(k) / statutory retirement schemes.

3.2 Paid Annual Vacation (PTO): Executive shall be entitled to accrue paid time off (PTO) in accordance with Company's executive leave policy, not to be less than twenty (20) Business Days of paid annual leave per calendar year, taken at mutually convenient times.

3.3 Business Expense Reimbursement: Company shall promptly reimburse Executive for all reasonable, necessary, and documented business, travel, lodging, and entertainment expenses incurred by Executive in the discharge of Executive's duties, subject to Company's expense reimbursement policies and submission of receipts.`
    },
    {
      id: 'emp-sec-4',
      sectionNumber: 'Section 4',
      title: 'Proprietary Information & Inventions Assignment (PIIA)',
      category: 'ip_data',
      summary: 'Comprehensive work-made-for-hire assignment of all intellectual property, inventions, designs, and code created during employment, with full moral rights waiver.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Includes statutory carve-outs under California Labor Code § 2870, Illinois, and Delaware for inventions developed entirely on employee own time without company assets.',
      fullLegalText: `4.1 Work Product & Inventions Assignment: Executive agrees that all software code, inventions, discoveries, designs, algorithms, architectures, trade secrets, documentation, and works of authorship authored, conceived, or reduced to practice by Executive during the period of employment, solely or jointly with others, that: (a) relate directly to Company's actual or anticipated business; or (b) result from any work performed by Executive for Company or utilizing Company's facilities, assets, or Confidential Information ("Company Inventions"), shall belong solely, exclusively, and perpetually to Company.

4.2 Work Made for Hire & Complete Conveyance: All copyrightable aspects of Company Inventions shall be deemed "works made for hire" for Company. To the extent any title does not vest automatically, Executive hereby irrevocably, unconditionally, and perpetually assigns and transfers to Company all worldwide right, title, and interest in and to all Company Inventions, together with all patent, copyright, trademark, and trade secret rights.

4.3 Power of Attorney & Further Assurances: Executive agrees to execute and deliver all patent applications, assignments, and recordations requested by Company. Executive irrevocably designates Company as Executive's attorney-in-fact to execute such documents if Executive is unavailable or refuses to sign.`
    },
    {
      id: 'emp-sec-5',
      sectionNumber: 'Section 5',
      title: 'Post-Employment Restrictive Covenants & Non-Solicitation (12 Months)',
      category: 'risk_liability',
      summary: '12-month post-employment covenant restricting solicitation of company employees, consultants, and customers, tailored to statutory enforceability boundaries.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Non-solicitation of employees and customers enforced across US (non-compete carve-outs for CA AB 1076, UK 6-month limit, Indian Contract Act Sec 27 voiding post-term non-competes).',
      fullLegalText: `5.1 Non-Solicitation of Employees & Talent: Executive covenants and agrees that during the term of employment and for a period of twelve (12) consecutive months following the effective date of termination of employment for any reason, Executive shall not, directly or indirectly, solicit, recruit, induce, encourage, or attempt to hire any person who is then an employee, officer, or regular independent contractor of Company to leave Company's employment or terminate their engagement.

5.2 Non-Solicitation of Customers: During the term of employment and for twelve (12) months following termination, Executive shall not, directly or indirectly, solicit, divert, entice away, or attempt to capture any commercial business from any customer or prospective client of Company with whom Executive had material business dealings or about whom Executive obtained Confidential Information during the twenty-four (24) months prior to termination.

5.3 Scope & Blue-Pencil Severability: The Parties acknowledge that the geographic and temporal covenants herein are reasonable and necessary to protect Company's legitimate business interests and proprietary goodwill. If any covenant is held overbroad by a court of competent jurisdiction, the court shall reform and narrow the provision to the maximum enforceable duration.`
    },
    {
      id: 'emp-sec-6',
      sectionNumber: 'Section 6',
      title: 'Termination Framework: For Cause, Without Cause & Resignation',
      category: 'operational',
      summary: 'Defines termination for Cause (felony, fraud, embezzlement, gross insubordination) with 30-day cure where curable, termination without cause, and resignation notice.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Objective standards for Cause protect executives against arbitrary bad-faith forfeiture of earned incentives and severance.',
      fullLegalText: `6.1 Termination by Company for Cause: Company may terminate Executive's employment immediately for "Cause" upon written notice. "Cause" shall be defined strictly as:
    (a) Executive's conviction of, or plea of guilty or nolo contendere to, any felony or crime involving moral turpitude, fraud, embezzlement, or dishonesty;
    (b) willful misconduct, gross negligence, or intentional fraud causing material financial or reputational injury to Company;
    (c) material breach of Section 4 (Inventions Assignment) or Section 5 (Restrictive Covenants); or
    (d) habitual refusal or willful failure to perform the lawful written directives of the Board, which failure remains uncured for thirty (30) calendar days after written notice specifying the deficiency.

6.2 Termination Without Cause: Company may terminate Executive's employment without Cause at any time upon thirty (30) calendar days prior written notice.

6.3 Resignation by Executive: Executive may resign Executive's employment at any time upon sixty (60) calendar days prior written notice to Company, during which period Company may elect to place Executive on paid "Garden Leave".`
    },
    {
      id: 'emp-sec-7',
      sectionNumber: 'Section 7',
      title: 'Severance Benefits & Comprehensive General Release of Claims',
      category: 'commercial',
      summary: 'Severance pay equal to 6-12 months base salary, continuation of health insurance (COBRA), and pro-rata bonus, conditional upon a signed claims release.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Complies with US ADEA / OWBPA 21-day review and 7-day revocation requirements for employee claims release.',
      fullLegalText: `7.1 Severance Entitlement: In the event Company terminates Executive's employment without Cause, Executive shall be entitled to receive:
    (a) continuing payment of Executive's base salary for a period of six (6) months following the date of termination, paid in accordance with regular payroll cycles;
    (b) Company-subsidized continuation of health insurance coverage (COBRA or statutory equivalent) for Executive and eligible dependents for up to six (6) months; and
    (c) a pro-rata portion of Executive's target annual bonus for the fiscal year of termination based on actual days worked.

7.2 Separation Agreement & General Release Precondition: Executive's receipt of any severance benefits under Section 7.1 is expressly conditioned upon Executive's execution, delivery, and non-revocation of a comprehensive mutual separation agreement and general release of all employment-related claims in a form reasonably acceptable to Company, within forty-five (45) days of termination.`
    },
    {
      id: 'emp-sec-8',
      sectionNumber: 'Section 8',
      title: 'Governing Employment Law & Arbitration Protocol',
      category: 'boilerplate',
      summary: 'Governed by employment laws of place of performance, mandatory arbitration with employer-paid arbitration fees where mandated by statutory labor codes.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Compliant with US Ending Forced Arbitration of Sexual Assault and Sexual Harassment Act of 2021 (EFAA) and local mandatory labor tribunals.',
      fullLegalText: `8.1 Governing Law: This Agreement shall be governed by, and construed in accordance with, the employment and labor laws of the jurisdiction where Executive primarily performs services for Company.

8.2 Mutual Arbitration Agreement: To the maximum extent permitted by Applicable Law, any legal dispute, controversy, or claim arising out of or relating to Executive's employment, compensation, or termination shall be resolved exclusively through final and binding arbitration administered by the American Arbitration Association (AAA) or JAMS under its National Rules for the Resolution of Employment Disputes. Company shall bear all arbitral forum filing fees and arbitrator compensation.`
    }
  ],

  'tmpl-independent-contractor': [
    {
      id: 'ic-sec-1',
      sectionNumber: 'Section 1',
      title: 'Independent Contractor Status, Non-Employee Declaration & Tax Self-Sufficiency',
      category: 'operational',
      summary: 'Declares independent contractor status, contractor controls hours and methods, no employee benefits or worker misclassification, sole tax liability.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Passes IRS 20-factor test, California Dynamex ABC test, UK IR35 off-payroll rules, and Indian Income Tax Section 194J guidelines.',
      fullLegalText: `1.1 True Independent Contractor Status: The Parties expressly agree that Contractor is an independent contractor and not an employee, agent, partner, joint venturer, or legal representative of Client. Nothing in this Agreement shall be construed as creating an employer-employee relationship between Client and Contractor or any of Contractor's personnel.

1.2 Control of Methods & Schedule: Contractor shall exercise complete and sole discretion and independent professional judgment regarding the manner, means, methods, schedule, and location of performing the Services, subject only to Client's specification of deliverables, project deadlines, and quality standards. Contractor is not required to work exclusively for Client and is free to perform services for other commercial clients.

1.3 Exclusion from Employee Benefits: Contractor acknowledges and agrees that neither Contractor nor Contractor's personnel shall be eligible to participate in, or receive any benefits under, any of Client's employee benefit programs, including health insurance, paid vacation, sick leave, retirement plans, disability insurance, or workers' compensation.

1.4 Sole Tax Liability: Contractor assumes sole and exclusive legal liability and responsibility for the reporting, withholding, and payment of all self-employment taxes, federal, state, and local income taxes, social security contributions, goods and services taxes (GST), and statutory contributions assessed upon the fees paid under this Agreement.`
    },
    {
      id: 'ic-sec-2',
      sectionNumber: 'Section 2',
      title: 'Scope of Consultancy Services, Deliverables & Invoicing Protocol',
      category: 'commercial',
      summary: 'Clear milestone or hourly consulting scope, 10-day review period, Net 30 day payment terms, and separate expense reimbursement.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Ensures clear delineation of commercial invoices and formal deliverable sign-offs.',
      fullLegalText: `2.1 Scope & Statements of Work: Contractor shall perform the professional consulting and engineering services set forth in executed Statements of Work ("SOW"). Each SOW shall delineate the specific scope, technical requirements, delivery milestones, and consulting fees.

2.2 Acceptance Testing: Client shall have ten (10) Business Days from delivery to evaluate whether Deliverables conform to agreed specifications. If defects are identified, Contractor shall rectify non-conformities within five (5) Business Days at no extra fee.

2.3 Invoicing & Payment: Contractor shall submit itemized tax invoices upon milestone completion. Client shall pay all undisputed invoice amounts Net thirty (30) calendar days from receipt of a valid invoice.`
    },
    {
      id: 'ic-sec-3',
      sectionNumber: 'Section 3',
      title: 'Ownership of Deliverables, Immediate IP Assignment & Moral Rights Waiver',
      category: 'ip_data',
      summary: 'Client owns 100% of custom Deliverables upon creation. Contractor assigns all worldwide copyright, patent, and trade secret rights and waives moral rights.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Essential because independent contractors are NOT statutory employees; without an express written assignment, IP remains with the contractor under common law.',
      fullLegalText: `3.1 Exclusive Ownership: Client shall be the sole and exclusive owner of all right, title, and interest worldwide in and to all Deliverables, software code, designs, algorithms, specifications, reports, and documentation created or authored by Contractor in connection with the Services.

3.2 Present Assignment of Intellectual Property: Contractor hereby unconditionally and irrevocably assigns, transfers, and conveys to Client, upon creation, all worldwide right, title, and interest in and to all Deliverables and related intellectual property rights (including copyrights, patents, trademarks, and trade secrets).

3.3 Moral Rights Waiver: To the maximum extent permitted by Applicable Law, Contractor irrevocably waives all moral rights, droit moral, rights of attribution, integrity, or paternity in the Deliverables.`
    },
    {
      id: 'ic-sec-4',
      sectionNumber: 'Section 4',
      title: 'Contractor Indemnification for Tax & Worker Classification Claims',
      category: 'risk_liability',
      summary: 'Contractor indemnifies Client against any employee misclassification assessments, tax penalties, or benefit claims brought by tax or labor authorities.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Protects enterprise clients from joint employer liability and misclassification audits (e.g. EDD, IRS, HMRC IR35 assessments).',
      fullLegalText: `4.1 Worker Misclassification Indemnification: Contractor shall defend, indemnify, and hold harmless Client, its Affiliates, directors, officers, and employees from and against any and all claims, assessments, liabilities, taxes, penalties, interest, fines, and legal expenses arising out of or resulting from any determination by any governmental tax, labor, or regulatory authority that Contractor was an employee rather than an independent contractor, or asserting that Client is liable for withholding taxes, social security contributions, or employee benefits.`
    },
    {
      id: 'ic-sec-5',
      sectionNumber: 'Section 5',
      title: 'Termination for Convenience, Confidentiality & Governing Law',
      category: 'boilerplate',
      summary: 'Termination on 14 days written notice, perpetual trade secret protection, and commercial dispute resolution.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Freedom of contract to terminate on short notice reinforces independent contractor status over employment status.',
      fullLegalText: `5.1 Termination for Convenience: Either Party may terminate this Agreement or any SOW at any time, with or without cause, upon fourteen (14) calendar days prior written notice to the other Party. Client shall pay Contractor for all undisputed Services properly performed up to the date of termination.

5.2 Confidentiality: Contractor agrees to preserve Client's Confidential Information in strict confidence, use it solely for performing the Services, and return all materials upon termination.

5.3 Governing Law: This Agreement shall be governed by and construed in accordance with the substantive laws of Client's corporate home jurisdiction.`
    }
  ],

  'tmpl-ip-assignment': [
    {
      id: 'ip-sec-1',
      sectionNumber: 'Section 1',
      title: 'Comprehensive & Irrevocable Assignment of All Assigned IP',
      category: 'ip_data',
      summary: 'Absolute, worldwide, irrevocable transfer of all patents, copyrights, trademarks, software code, trade secrets, algorithms, and technical documentation.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Transfers complete legal and equitable title. Satisfies USPTO, EPO, UKIPO, and Indian Patent Office recordation requirements.',
      fullLegalText: `1.1 Irrevocable Assignment: For valuable consideration received, the sufficiency of which is hereby formally acknowledged, Assignor hereby unconditionally, irrevocably, perpetually, and without reservation transfers, conveys, and assigns to Assignee, its successors, and permitted assigns, all of Assignor's worldwide right, title, and interest in, to, and under the Assigned Intellectual Property ("Assigned IP").

1.2 Scope of Assigned IP: Assigned IP includes, without limitation:
    (a) all patents, patent applications, provisional filings, continuations, divisional applications, reissues, and foreign counterparts;
    (b) all copyrights, copyright registrations, moral rights, and works of authorship;
    (c) all trademarks, service marks, logos, trade dress, domain names, and associated commercial goodwill;
    (d) all trade secrets, proprietary algorithms, formulas, source code, object code, system architectures, database designs, technical data, research records, and know-how; and
    (e) all tangible and intangible embodiments of the foregoing in any medium.`
    },
    {
      id: 'ip-sec-2',
      sectionNumber: 'Section 2',
      title: 'Assignment of Past, Present & Future Claims & Causes of Action',
      category: 'ip_data',
      summary: 'Transfers all accrued rights to sue for past, present, and future infringement, and to recover all damages, royalties, and injunctive relief.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Critical patent law requirement: without an express transfer of past causes of action, the assignee cannot sue for infringements that occurred prior to the assignment date.',
      fullLegalText: `2.1 Transfer of Causes of Action: The assignment of the Assigned IP includes all accrued, existing, and future rights of Assignor to sue, bring actions, assert claims, and recover damages, profits, royalties, settlements, and civil remedies for any past, present, or future infringement, misappropriation, unfair competition, dilution, or violation of any of the Assigned IP by any third party, and Assignee is authorized to institute and prosecute such actions in its own name.`
    },
    {
      id: 'ip-sec-3',
      sectionNumber: 'Section 3',
      title: 'Irrevocable Waiver of Moral Rights & Authorship Claims',
      category: 'ip_data',
      summary: 'Assignor irrevocably waives all moral rights, droit moral, rights of integrity, attribution, and paternity to the fullest extent permitted by law.',
      standardBenchmark: 'Aggressive / Company-Favorable',
      isMandatory: true,
      jurisdictionNotes: 'Vital in civil law jurisdictions (France, Germany § 29 UrhG) and common law (UK CDPA 1988, Canada, India) where moral rights are retained by authors absent express waiver.',
      fullLegalText: `3.1 Waiver of Moral Rights: To the maximum extent permitted by Applicable Law, Assignor hereby unconditionally, irrevocably, and perpetually waives, discharges, and covenants never to assert against Assignee, its Affiliates, licensees, or customers, any and all "moral rights", "droit moral", rights of attribution, integrity, disclosure, retraction, or paternity, or any similar rights recognized under the laws of any jurisdiction worldwide with respect to the Assigned IP.`
    },
    {
      id: 'ip-sec-4',
      sectionNumber: 'Section 4',
      title: 'Further Assurances & Power of Attorney for Patent Office Filings',
      category: 'operational',
      summary: 'Assignor covenants to execute all patent filings, assignments, and declarations requested by Assignee, appointing Assignee as attorney-in-fact.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Prevents inventor hold-ups during international PCT patent prosecutions and national phase filings.',
      fullLegalText: `4.1 Further Assurances: Assignor covenants that it shall, upon Assignee's reasonable request and at Assignee's expense, execute and deliver all such further deeds, assignments, patent applications, oaths, declarations, and recordable instruments, and perform all such other acts as Assignee may reasonably require to record, perfect, prosecute, defend, and enforce Assignee's exclusive title to the Assigned IP worldwide.

4.2 Irrevocable Power of Attorney: Assignor hereby irrevocably designates and appoints Assignee and its duly authorized officers as Assignor's true and lawful agent and attorney-in-fact, with full power of substitution, to act for and on behalf of Assignor to execute, verify, and file any such applications and instruments if Assignee is unable, after reasonable inquiry, to secure Assignor's signature.`
    },
    {
      id: 'ip-sec-5',
      sectionNumber: 'Section 5',
      title: 'Assignor Warranties of Clear Title & Non-Infringement',
      category: 'risk_liability',
      summary: 'Assignor represents clear, unencumbered ownership, sole legal title, freedom from liens or security interests, and that Assigned IP does not infringe third-party rights.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Ensures clear chain of title and representations backing IP transfer.',
      fullLegalText: `5.1 Clear Title & Authority: Assignor represents and warrants that: (a) Assignor is the sole and exclusive legal and beneficial owner of the Assigned IP; (b) Assignor has full corporate power and authority to assign the Assigned IP free and clear of all liens, mortgages, pledges, security interests, claims, licenses, and encumbrances; and (c) to Assignor's knowledge, the Assigned IP does not infringe or misappropriate any intellectual property or proprietary rights of any third party.`
    }
  ],

  'tmpl-shareholders': [
    {
      id: 'sha-sec-1',
      sectionNumber: 'Section 1',
      title: 'Board of Directors Governance, Representation & Quorum Requirements',
      category: 'governance',
      summary: 'Establishes board composition, investor director appointment rights, founder representation, meeting frequency, and minimum quorum standards.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Aligned with Delaware General Corporation Law (DGCL), UK Companies Act 2006, and Indian Companies Act 2013.',
      fullLegalText: `1.1 Board Composition: The business and affairs of the Company shall be managed under the direction of a Board of Directors ("Board") comprising five (5) directors: (a) two (2) directors designated by the Founders; (b) one (1) director designated by the Lead Investor ("Investor Director"); (c) the Chief Executive Officer; and (d) one (1) independent director mutually approved by the Founders and the Investor Director.

1.2 Quorum & Meetings: A valid quorum for any meeting of the Board shall require the presence in person or by video conference of a majority of the directors, including at least one (1) Founder Director and the Investor Director. The Board shall meet not less than once every fiscal quarter.`
    },
    {
      id: 'sha-sec-2',
      sectionNumber: 'Section 2',
      title: 'Reserved Matters & Affirmative Investor Voting Thresholds',
      category: 'governance',
      summary: 'Enumerates critical corporate actions that require the prior written affirmative vote of the Investor Director (M&A, new share issuance, debt > $250k, liquidation).',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Protects institutional minority investors from dilution, unauthorized debt incurrence, or unilateral corporate restructuring.',
      fullLegalText: `2.1 Reserved Matters: Neither the Company nor the Board shall authorize, approve, or execute any of the following corporate actions without the prior affirmative written consent or affirmative vote of the Investor Director:
    (a) any merger, consolidation, restructuring, reorganization, dissolution, or sale of substantially all corporate assets;
    (b) the creation, authorization, or issuance of any new class of equity securities ranking senior to or on parity with the Investor shares;
    (c) any alteration or amendment to the Company's Certificate of Incorporation or Bylaws that adversely alters investor rights;
    (d) incurring corporate indebtedness or borrowing in excess of $250,000 in the aggregate;
    (e) any transaction with any Affiliate, director, officer, or shareholder, other than at verified arm's-length terms; or
    (f) any material change in the principal business of the Company.`
    },
    {
      id: 'sha-sec-3',
      sectionNumber: 'Section 3',
      title: 'Right of First Refusal (ROFR), Right of First Offer (ROFO) & Tag-Along',
      category: 'commercial',
      summary: 'Restricts share transfers, grants Company and non-selling shareholders ROFR on proposed sales, and gives minority investors pro-rata Tag-Along rights.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Standard venture capital minority protection mechanics preventing unwanted third-party shareholders and founder abandonment.',
      fullLegalText: `3.1 Right of First Refusal (ROFR): If any Founder or shareholder ("Selling Shareholder") proposes to sell or transfer any shares to a third party, the Selling Shareholder shall first deliver a written notice ("Transfer Notice") offering such shares to the Company and the other major shareholders on the identical price and commercial terms. The Company and shareholders shall have thirty (30) days to exercise their ROFR.

3.2 Tag-Along (Co-Sale) Rights: If the ROFR is not fully exercised and the Selling Shareholder proceeds with a sale to a third party, each non-selling major shareholder shall have the right ("Tag-Along Right") to participate in such sale on a pro-rata basis and on the identical terms and price per share.`
    },
    {
      id: 'sha-sec-4',
      sectionNumber: 'Section 4',
      title: 'Drag-Along Rights on Approved Corporate Exits (65% Threshold)',
      category: 'governance',
      summary: 'Enables Board and 65% majority shareholders to compel minority shareholders to participate in bona fide third-party acquisitions on identical terms.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Prevents minority shareholder holdouts from blocking legitimate, arm\'s-length corporate liquidity events or M&A transactions.',
      fullLegalText: `4.1 Drag-Along Trigger: If the Board of Directors and the holders of not less than sixty-five percent (65%) of the voting shares of the Company (including the Lead Investor) approve a bona fide arm's-length acquisition of the Company by a third party ("Approved Exit"), then all remaining shareholders shall be obligated to:
    (a) vote all shares in favor of such Approved Exit;
    (b) sell and transfer their shares on the identical price and terms; and
    (c) execute all customary merger agreements and share purchase documents.`
    },
    {
      id: 'sha-sec-5',
      sectionNumber: 'Section 5',
      title: 'Pre-Emptive Anti-Dilution Rights, Information Rights & Founder Vesting',
      category: 'governance',
      summary: 'Pro-rata pre-emptive rights on future equity issuances, monthly financial reports, audited annuals, and 4-year founder share reverse vesting.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Standard NVCA (National Venture Capital Association) institutional financing covenants.',
      fullLegalText: `5.1 Pre-Emptive Rights: Major Investors shall have a pro-rata pre-emptive right to purchase their percentage share of any new equity securities issued by the Company, excluding standard employee option pool issuances.

5.2 Information Rights: The Company shall deliver to Major Investors: (a) unaudited monthly financial statements within thirty (30) days of month-end; and (b) annual audited financial statements prepared by an independent accounting firm within ninety (90) days of fiscal year-end.

5.3 Founder Vesting Schedule: All Founder shares shall be subject to a four (4) year reverse vesting schedule with a one-year cliff (25% vesting after 12 months, and the remainder vesting in equal monthly installments over the following 36 months).`
    }
  ],

  'tmpl-commercial-lease': [
    {
      id: 'lease-sec-1',
      sectionNumber: 'Section 1',
      title: 'Demise of Premises, Floor Area Measurement & Permitted Commercial Use',
      category: 'real_estate' as any,
      summary: 'Exact description of leased premises, rentable square footage measurement, permitted commercial office use, and zoning restrictions.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Measured under BOMA / RICS international floor area measurement standards.',
      fullLegalText: `1.1 Demised Premises: Landlord hereby leases to Tenant, and Tenant hereby leases from Landlord, the commercial premises described in the Lease Schedule ("Demised Premises"), situated within the building property located at the Demised Address, comprising the agreed rentable square footage.

1.2 Permitted Commercial Use: Tenant shall use and occupy the Demised Premises solely for general executive commercial offices, technology engineering, and ancillary administrative uses ("Permitted Use"), and for no other purpose without Landlord's prior written consent.`
    },
    {
      id: 'lease-sec-2',
      sectionNumber: 'Section 2',
      title: 'Base Rent, Annual Escalation (3-5%) & Operating Expenses (Triple Net / CAM)',
      category: 'commercial',
      summary: 'Monthly base rent payable on the 1st of each month, fixed 5% annual escalation, and tenant pro-rata share of Common Area Maintenance (CAM), taxes, and insurance.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Standard Triple Net (NNN) commercial lease terms with audit rights on annual CAM reconciliations.',
      fullLegalText: `2.1 Base Rent: Tenant shall pay Landlord the monthly Base Rent specified in the Lease Schedule in advance on or before the first (1st) day of each calendar month.

2.2 Annual Escalation: On each anniversary of the Rent Commencement Date, the monthly Base Rent shall automatically escalate and increase by five percent (5.0%) over the Base Rent payable during the immediately preceding lease year.

2.3 Operating Expenses (CAM): In addition to Base Rent, Tenant shall pay Tenant's proportionate share of Common Area Maintenance (CAM) expenses, municipal property taxes, and building insurance premiums. Landlord shall provide an annual audited reconciliation of actual operating expenses within ninety (90) days of year-end.`
    },
    {
      id: 'lease-sec-3',
      sectionNumber: 'Section 3',
      title: 'Security Deposit, Replenishment Protocol & Return Conditions',
      category: 'commercial',
      summary: 'Deposit equivalent to 3-6 months rent, conditions for Landlord application upon default, 10-day replenishment obligation, and return within 30 days of surrender.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Statutory compliance with commercial tenancy deposit holdings and registration rules.',
      fullLegalText: `3.1 Security Deposit: Upon execution of this Lease, Tenant shall deposit with Landlord the Security Deposit amount specified in the Lease Schedule. The Security Deposit shall be held by Landlord as security for the faithful performance by Tenant of all covenants hereunder.

3.2 Application & Replenishment: If Tenant commits a monetary default, Landlord may apply all or any portion of the Security Deposit to cure the default. Upon written notice, Tenant shall replenish the Security Deposit to its full required amount within ten (10) Business Days.

3.3 Return Upon Surrender: Within thirty (30) calendar days following the expiration of the Lease Term and Tenant's complete physical surrender of the Premises in the condition required hereunder, Landlord shall return the unapplied balance of the Security Deposit to Tenant without interest.`
    },
    {
      id: 'lease-sec-4',
      sectionNumber: 'Section 4',
      title: 'Maintenance Obligations: Structural Infrastructure vs. Tenant Interior',
      category: 'operational',
      summary: 'Landlord maintains roof, foundations, exterior walls, and main MEP infrastructure; Tenant maintains interior premises, fixtures, and interior finishes.',
      standardBenchmark: 'Balanced / Neutral',
      isMandatory: true,
      jurisdictionNotes: 'Clear contractual division of repair obligations prevents commercial tenancy disputes regarding HVAC replacements and structural defects.',
      fullLegalText: `4.1 Landlord Structural Maintenance: Landlord shall, at Landlord's sole cost and expense, maintain, repair, and replace in good working order: (a) the foundations, exterior walls, roof, and structural elements of the Building; and (b) the main Building mechanical, electrical, plumbing, and life-safety systems up to the point of entry into the Demised Premises.

4.2 Tenant Interior Maintenance: Tenant shall, at Tenant's sole expense, keep and maintain the interior of the Demised Premises, non-structural partitions, lighting fixtures, interior plumbing connections, and cosmetic finishes in a clean, safe, and good state of repair.`
    },
    {
      id: 'lease-sec-5',
      sectionNumber: 'Section 5',
      title: 'Events of Default, Notice & Cure Windows, Eviction & Governing Law',
      category: 'risk_liability',
      summary: '5-day cure for monetary default, 15-day cure for non-monetary default, Landlord remedies, and real estate jurisdiction submission.',
      standardBenchmark: 'Market Standard',
      isMandatory: true,
      jurisdictionNotes: 'Must strictly comply with local real property and commercial tenancy eviction procedures.',
      fullLegalText: `5.1 Events of Default: An Event of Default shall occur if: (a) Tenant fails to pay any installment of Rent when due, and such failure continues for five (5) Business Days after written notice; or (b) Tenant fails to perform any non-monetary covenant hereunder and fails to cure such non-performance within fifteen (15) Business Days after written notice.

5.2 Landlord Remedies: Upon an Event of Default, Landlord may: (i) terminate this Lease and recover possession of the Premises through lawful judicial proceedings; (ii) accelerate all unpaid Rent due through the remainder of the Lease Term; and (iii) re-let the Premises.

5.3 Governing Law: This Lease shall be governed exclusively by the laws of the state, province, or country where the real property is physically located.`
    }
  ]
};
