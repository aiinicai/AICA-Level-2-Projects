import { DetailedClause } from '../types';
import { TEMPLATE_DETAILED_CLAUSES } from './detailedStandardClauses';

export interface ContractTemplateDefinition {
  id: string;
  name: string;
  category: 'commercial' | 'ip_confidentiality' | 'employment' | 'corporate' | 'real_estate' | 'procurement';
  description: string;
  typicalParties: { primary: string; counterparty: string };
  defaultClauses: string[];
  detailedClauses: DetailedClause[];
  mandatoryJurisdictionClauses: Record<string, string[]>;
  recommendedLiabilityCap: string;
  recommendedGoverningLaw: string;
  sampleDraft: string;
}

export const CONTRACT_TEMPLATES: ContractTemplateDefinition[] = [
  {
    id: 'tmpl-msa',
    name: 'Master Services Agreement (MSA)',
    category: 'commercial',
    description: 'Framework agreement establishing terms governing recurring services, deliverables, statements of work, commercial billing, warranties, and risk allocation.',
    typicalParties: { primary: 'Client / Customer', counterparty: 'Service Provider / Vendor' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-msa'] || [],
    defaultClauses: [
      'Detailed Definitions (Services, Deliverables, Work Product, Data, SLA)',
      'Statement of Work (SOW), Milestones & Acceptance Testing Protocol',
      'Service Level Agreement (SLA) & 24/7 Level-3 Technical Support (99.9% Uptime)',
      'Commercial Terms, Milestone Invoicing, Taxes & Late Payment Interest',
      'Intellectual Property Rights, Work Product Assignment & Background IP',
      'Confidentiality & Non-Disclosure (5-Year Survival / Trade Secrets Perpetual)',
      'Data Processing Agreement (DPA) & Privacy Compliance (DPDPA 2023 / GDPR)',
      'Information Security, SOC 2 / ISO 27001 & Cybersecurity Vulnerability Assessment',
      'Substantive Mutual Indemnification & Defense Procedures',
      'Representations & Warranties (Authority, Workmanlike Standard, Non-Infringement, No Malware)',
      'Limitation of Liability, Super-Cap for Data Incidents & Consequential Damages Disclaimer',
      'Insurance Requirements (CGL $2M, Cyber Risk $5M, E&O $2M, Workers Comp)',
      'Term, Renewal & Termination for Convenience / Cause',
      'Termination Consequences, Transition Assistance (90 Days) & Exit Management',
      'Business Continuity & Disaster Recovery (BCP/DR - RTO <= 4h, RPO <= 1h)',
      'Customer Data Ownership, Portability & Certified Deletion',
      'Subcontracting & Third-Party Vendor Management (Prior Consent & 100% Liability)',
      'Assignment & Corporate Restructuring Restrictions',
      'Force Majeure & Excusable Delays (5-Day Notice, 30-Day Termination)',
      'Broad Compliance with Laws & Regulatory Standards',
      'Anti-Bribery & Anti-Corruption (FCPA, UKBA, Indian PCA 1988)',
      'Trade Sanctions & Export Control Compliance (OFAC, BIS)',
      'Audit, Inspection & Security Verification Rights (10 Business Days Notice)',
      'Formal Notices & Electronic Communication Protocol',
      'Entire Agreement, Amendments, Waiver & Severability',
      'Survival of Core Protective Clauses & Order of Precedence',
      'Publicity, Marketing & Trademark Restrictions',
      'Dispute Resolution, Executive Escalation & Institutional Arbitration',
      'Governing Law & Jurisdiction',
      'Counterparts & Legally Binding Electronic Execution'
    ],
    mandatoryJurisdictionClauses: {
      US: ['UCC Disclaimer of Implied Warranties', 'Delaware Choice of Forum', 'Jury Trial Waiver', 'DTSA Trade Secrets Notice'],
      IN: ['Section 28 Indian Contract Act Compliance', 'Stamp Duty & GST Representation', 'DPDPA 2023 Processing', 'CERT-In Incident Reporting'],
      GB: ['Contracts (Rights of Third Parties) Act 1999 Exclusion', 'Bribery Act 2010 Adequate Procedures', 'UK GDPR Art 28 DPA'],
      SG: ['Contracts (Rights of Third Parties) Act Exclusion', 'SIAC Arbitration Seat', 'PDPA 2012 Undertaking'],
      AE: ['DIFC / ADGM Contract Law Selection', 'UAE Federal Data Decree Compliance', 'Dual Language Precedence'],
      DE: ['AGB-Control §§ 305-310 BGB Compliance', 'EU GDPR Article 28 DPA', 'Exclusion of CISG']
    },
    recommendedLiabilityCap: '100% to 200% of fees paid in preceding 12 months (with 2x super-cap for data privacy)',
    recommendedGoverningLaw: 'Delaware (US), England & Wales (UK), India, or Singapore (SIAC)',
    sampleDraft: `MASTER SERVICES AGREEMENT

This Master Services Agreement ("Agreement") is made and entered into as of the Effective Date by and between:

PARTIES:
1. {{PRIMARY_PARTY_NAME}}, a {{PRIMARY_ENTITY_TYPE}} incorporated under the laws of {{PRIMARY_COUNTRY}}, with registered office at {{PRIMARY_ADDRESS}} (Tax ID: {{PRIMARY_TAX_ID}}) ("Customer"); and
2. {{COUNTERPARTY_NAME}}, a {{COUNTERPARTY_ENTITY_TYPE}} incorporated under the laws of {{COUNTERPARTY_COUNTRY}}, with registered office at {{COUNTERPARTY_ADDRESS}} (Tax ID: {{COUNTERPARTY_TAX_ID}}) ("Service Provider").

RECITALS:
WHEREAS, Customer desires to engage Service Provider to perform professional engineering, cloud architecture, cybersecurity vulnerability assessment, and AI infrastructure services; and
WHEREAS, Service Provider possesses the technical expertise, infrastructure, and certifications necessary to perform such services;

NOW, THEREFORE, the Parties agree as follows:

1. DEFINITIONS & INTERPRETATION
1.1 "Services" means technology engineering, AI infrastructure, cybersecurity, and consulting services described in executed Statements of Work.
1.2 "Deliverables" means all reports, code, scripts, configurations, and technical artifacts provided to Customer.
1.3 "Work Product" means all custom inventions, software, and deliverables developed specifically for Customer under this Agreement.
1.4 "Customer Data" means all electronic data, records, and databases submitted by or on behalf of Customer.
1.5 "Personal Data" has the meaning ascribed under applicable Data Protection Legislation (including DPDPA 2023 and GDPR).
1.6 "Business Day" means any day other than a Saturday, Sunday, or official bank holiday in the governing jurisdiction.
1.7 "SLA" means the Service Level Agreement standards set forth in Section 3.

2. STATEMENT OF WORK (SOW) & ACCEPTANCE TESTING
2.1 Each SOW executed hereunder shall specify scope, milestones, fees, and technical specifications.
2.2 Customer shall have ten (10) business days from delivery to review and test Deliverables. Service Provider shall rectify any non-conformity within five (5) business days at no charge.
2.3 Any changes to scope or pricing must be documented in a written Change Order signed by both Parties.

3. SERVICE LEVEL AGREEMENT (SLA) & 24/7 TECHNICAL SUPPORT
3.1 Service Provider guarantees 99.9% Monthly Uptime Availability for all cloud and infrastructure services.
3.2 Service Provider provides continuous 24/7/365 Level-3 Technical Support:
    - Severity 1 (Critical Outage): 15-min response / 2-hr resolution.
    - Severity 2 (Major Impairment): 1-hr response / 6-hr resolution.
    - Severity 3 (Moderate Issue): 4-hr response / 24-hr resolution.
    - Severity 4 (Minor Query): 12-hr response.
3.3 Downtime below 99.9% earns Service Credits: 99.0%-99.89% = 10% monthly fee credit; 95.0%-98.99% = 25% credit; <95.0% = 50% credit.

4. COMMERCIAL TERMS & INVOICING
4.1 Total Contract Consideration: {{CONTRACT_VALUE}} {{CURRENCY}}.
4.2 Payment Terms: Net {{PAYMENT_DUE_DAYS}} days from receipt of a valid tax invoice. Undisputed late payments bear interest at 1.5% per month.

5. INTELLECTUAL PROPERTY RIGHTS
5.1 Customer owns 100% exclusive title and IP in all Work Product upon creation.
5.2 Service Provider retains ownership of Background IP, granting Customer a perpetual, worldwide, royalty-free license to use Background IP embedded in Deliverables.

6. CONFIDENTIALITY & NON-DISCLOSURE
6.1 Each Party shall maintain the other's Confidential Information in strict confidence for five (5) years, provided Trade Secrets survive indefinitely.

7. DATA PROTECTION (DPDPA / GDPR)
7.1 Customer is Data Controller/Fiduciary; Service Provider is Data Processor. Service Provider processes data strictly on instructions and notifies Customer of any security breach within 24-48 hours.

8. INFORMATION SECURITY & CYBERSECURITY
8.1 Service Provider maintains SOC 2 Type II / ISO 27001 certification, quarterly vulnerability assessments, annual penetration tests, and AES-256 encryption.

9. INDEMNIFICATION
9.1 Service Provider indemnifies Customer against third-party IP infringement, data breaches, and gross negligence claims, subject to standard defense control procedures.

10. REPRESENTATIONS & WARRANTIES
10.1 Service Provider warrants professional workmanlike services, 90-day deliverable warranty, non-infringement, and software free from viruses or malicious code.

11. LIMITATION OF LIABILITY
11.1 Consequential damages are excluded. Total liability is capped at {{LIABILITY_CAP_DETAILS}}, with uncapped carve-outs for IP indemnity, confidentiality breach, and gross negligence.

12. INSURANCE REQUIREMENTS
12.1 Service Provider maintains Commercial General Liability ($2M), Cyber Risk / Privacy Liability ($5M), and Errors & Omissions ($2M).

13. TERM & TERMINATION
13.1 Either Party may terminate for convenience upon thirty (30) days written notice, or immediately for material breach uncured after thirty (30) days.

14. TERMINATION CONSEQUENCES & EXIT MANAGEMENT
14.1 Service Provider provides up to ninety (90) days disentanglement assistance at agreed rates, refunds unearned prepaid fees, and exports Customer Data within 30 days.

15. BUSINESS CONTINUITY & DISASTER RECOVERY (BCP/DR)
15.1 Service Provider commits to RTO <= 4 hours, RPO <= 1 hour, and annual disaster recovery testing.

16. CUSTOMER DATA OWNERSHIP & CERTIFIED DELETION
16.1 Customer retains 100% exclusive ownership of all Customer Data. Service Provider provides export in standard format and certified cryptographic deletion upon termination.

17. SUBCONTRACTING & ASSIGNMENT
17.1 Subcontracting requires prior written consent; Service Provider remains 100% liable. Assignment requires prior consent, except in standard M&A transactions.

18. FORCE MAJEURE
18.1 Excusable events beyond reasonable control require 5-day notice; termination permitted if disruption exceeds 30 consecutive days.

19. COMPLIANCE, ANTI-BRIBERY & SANCTIONS
19.1 Both Parties warrant compliance with all applicable laws, FCPA, UK Bribery Act, Indian PCA 1988, and US OFAC / international export sanctions.

20. AUDIT RIGHTS
20.1 Customer or independent auditor may audit security and compliance once per year upon ten (10) business days written notice.

21. NOTICES, ENTIRE AGREEMENT, SEVERABILITY & SURVIVAL
21.1 Formal written notices via courier or email. This Agreement constitutes the entire agreement, amending only in writing. Standard severability and survival terms apply.

22. ORDER OF PRECEDENCE
22.1 Priority hierarchy: (1) DPA; (2) SOW; (3) SLA; (4) Master Services Agreement; (5) Purchase Orders.

23. PUBLICITY
23.1 Neither Party shall use the other's logo or issue press releases without prior written consent.

24. DISPUTE RESOLUTION & GOVERNING LAW
24.1 Governed by {{GOVERNING_LAW}}. Disputes resolved via 30-day executive escalation, followed by binding arbitration under {{DISPUTE_RESOLUTION_DETAILS}}.

25. ELECTRONIC EXECUTION & COUNTERPARTS
25.1 Validly executed in counterparts by digital or electronic signatures.

IN WITNESS WHEREOF, the Parties' authorized representatives execute this Agreement:

FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}}
Title: {{PRIMARY_DESIGNATION}}
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}}
Title: {{COUNTERPARTY_DESIGNATION}}
Date: ________________________`
  },
  {
    id: 'tmpl-saas',
    name: 'Software-as-a-Service (SaaS) Agreement',
    category: 'commercial',
    description: 'Enterprise subscription agreement covering cloud software provisioning, uptime SLA (99.9%), security standards, data hosting, user seats, and subscription renewals.',
    typicalParties: { primary: 'Subscriber / Enterprise Customer', counterparty: 'SaaS Provider / Vendor' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-saas'] || [],
    defaultClauses: [
      'Grant of Subscription License & Authorized User Access',
      'Service Level Agreement (SLA) & Uptime Credit Mechanism (99.9%)',
      'Customer Data Ownership & Data Privacy Protection',
      'Security Measures & Annual SOC 2 Type II Audit Compliance',
      'Subscription Fees, Tiered Overages & Auto-Renewal Terms',
      'Vendor Representations, Warranties & IP Indemnification',
      'Liability Cap (12 Months Subscription Fees)',
      'Data Portability, Export & Post-Termination Data Deletion',
      'Audit Rights & Governing Law'
    ],
    mandatoryJurisdictionClauses: {
      US: ['CCPA Service Provider Addendum', 'Consequential Damages Waiver'],
      IN: ['DPDPA 2023 Compliance', 'GST E-Invoicing Representation'],
      GB: ['UK GDPR International Data Transfer Addendum', 'UCTA Reasonableness'],
      SG: ['PDPA Cross-Border Transfer Requirements', 'SIAC Expedited Rules'],
      AE: ['DIFC Data Protection Law No. 5 of 2020 Compliance'],
      DE: ['EU GDPR Standard Contractual Clauses (SCCs)']
    },
    recommendedLiabilityCap: 'Total subscription fees paid in the 12 months prior to claim',
    recommendedGoverningLaw: 'Delaware (US), England & Wales (UK), Singapore, or California (US)',
    sampleDraft: `ENTERPRISE SOFTWARE-AS-A-SERVICE (SAAS) SUBSCRIPTION AGREEMENT

This Enterprise SaaS Subscription Agreement ("Agreement") is entered into as of the Effective Date by and between:

PRIMARY PARTY: {{PRIMARY_PARTY_NAME}}, a corporation duly organized and existing under the laws of {{JURISDICTION}}, having its registered office at {{PRIMARY_ADDRESS}} ("Customer"); and

COUNTERPARTY: {{COUNTERPARTY_NAME}}, a company duly organized and existing under the laws of {{JURISDICTION}}, having its registered office at {{COUNTERPARTY_ADDRESS}} ("Vendor").

RECITALS
WHEREAS, Vendor develops, hosts, operates, and licenses access to proprietary cloud-based enterprise software applications; and
WHEREAS, Customer desires to obtain a subscription license to access and utilize Vendor's cloud software platform, and Vendor desires to provide such access subject to the terms and conditions set forth herein.

NOW, THEREFORE, the Parties agree as follows:

1. SUBSCRIPTION GRANT & AUTHORIZED USER RESTRICTIONS
1.1 Subscription License: Vendor hereby grants to Customer during the Subscription Term a non-exclusive, non-transferable, non-sublicensable, worldwide subscription license to access and utilize the Cloud Software Platform ("Platform") solely for Customer's internal business operations in accordance with published technical documentation.
1.2 Authorized Users: Customer may provision user accounts for its designated employees, officers, and vetted contractors ("Authorized Users"). Customer shall ensure credentials are kept confidential and not shared among multiple individuals.
1.3 Restrictions on Use: Customer shall not, directly or indirectly: (a) reverse engineer, decompile, disassemble, or attempt to discover the source code, object code, or underlying algorithms of the Platform; (b) rent, lease, resell, distribute, or utilize the Platform on a service bureau or timesharing basis; (c) bypass or circumvent any security features or usage metering mechanisms; or (d) access the Platform to build a competitive product.

2. SERVICE LEVEL AGREEMENT (SLA), 99.9% UPTIME & FINANCIAL SERVICE CREDITS
2.1 Uptime Commitment: Vendor warrants that the Platform shall maintain an aggregate Monthly Uptime Availability of not less than ninety-nine and nine-tenths percent (99.9%), excluding Scheduled Maintenance.
2.2 Support & Incident Matrix: Vendor shall maintain continuous 24/7 Level-3 senior engineering support. Critical Severity-1 outages (production platform down) shall have an initial response time within 15 minutes and target resolution within 2 hours.
2.3 Service Credits: If Monthly Uptime falls below 99.9%, Customer shall receive financial service credits applied against the subsequent billing cycle:
    - 99.0% to 99.89% Uptime: 10% monthly subscription credit;
    - 95.0% to 98.99% Uptime: 25% monthly subscription credit;
    - Less than 95.0% Uptime: 50% monthly subscription credit.
2.4 Chronic Failure: If availability falls below 95.0% in any two (2) consecutive months, Customer may terminate this Agreement immediately for cause without penalty and receive a full pro-rata refund of unearned prepaid fees.

3. CUSTOMER DATA OWNERSHIP, PRIVACY & CYBERSECURITY
3.1 Title in Customer Data: Customer retains sole and exclusive title, copyright, ownership, and all intellectual property rights in and to all electronic data, files, and customer records uploaded or processed on the Platform ("Customer Data"). Vendor acquires no proprietary rights in Customer Data.
3.2 Privacy & Security Compliance: Vendor acts strictly as a Data Processor under applicable Data Protection Legislation (including GDPR Art. 28, India DPDPA 2023, and California CCPA/CPRA). Vendor shall maintain SOC 2 Type II certification, enforce AES-256 bit encryption at rest and TLS 1.3 in transit, and maintain strict logical multi-tenant database isolation.
3.3 Security Incident Notification: Vendor shall notify Customer in writing within twenty-four (24) to forty-eight (48) hours of confirming any unauthorized access, breach, alteration, or disclosure of Customer Data, and shall take immediate remedial action at Vendor's sole expense.

4. COMMERCIAL FEES, INVOICING & AUTOMATIC RENEWAL
4.1 Consideration: Customer shall pay Vendor the recurring subscription fees of {{CONTRACT_VALUE}} {{CURRENCY}} per term, payable Net thirty (30) calendar days from receipt of a valid tax invoice.
4.2 Automatic Renewal: Following the Initial Subscription Term, this Agreement shall automatically renew for successive one (1) year periods unless either Party provides written notice of non-renewal not less than sixty (60) days prior to the expiration of the current term.
4.3 Renewal Cap: Any annual subscription fee adjustment on renewal shall not exceed five percent (5.0%).

5. VENDOR INTELLECTUAL PROPERTY & INDEMNIFICATION
5.1 Proprietary Rights: Vendor and its licensors retain sole and exclusive ownership of all software code, algorithms, user interfaces, documentation, and improvements to the Platform.
5.2 IP Indemnity: Vendor shall defend, indemnify, and hold harmless Customer and its Affiliates against any third-party claims alleging that the Platform infringes any valid patent, copyright, trademark, or trade secret.

6. LIMITATION OF LIABILITY & SUPER-CAP
6.1 Consequential Damages Waiver: Neither Party shall be liable for indirect, incidental, special, or consequential damages, or loss of profits or business opportunities.
6.2 Aggregate Liability Ceiling: Except for indemnification obligations and gross negligence, each Party's aggregate liability shall be capped at the total subscription fees paid by Customer in the preceding twelve (12) months.
6.3 Privacy Super-Cap: For breaches of Section 3 resulting in unauthorized Customer Data disclosure, liability is subject to an enhanced super-cap of two times (2x) the 12-month fees.

7. POST-TERMINATION DATA PORTABILITY & CERTIFIED PURGE
7.1 Retrieval Window: Upon termination, Customer shall have thirty (30) calendar days to export all Customer Data in standard machine-readable format (JSON/CSV/SQL) at no extra charge.
7.2 Certified Erasure: Following the retrieval window, Vendor shall permanently overwrite and cryptographically erase all remaining copies of Customer Data across all environments and deliver a signed Certificate of Destruction.

8. DISPUTE RESOLUTION & GOVERNING LAW
8.1 Governance: This Agreement shall be governed by the substantive laws of {{GOVERNING_LAW}}. Any unresolved dispute shall be finally resolved by binding commercial arbitration administered under {{ARBITRATION_FORUM}} rules in the English language.

IN WITNESS WHEREOF, the Parties' authorized signatories have executed this Agreement:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}} ({{COUNTERPARTY_DESIGNATION}})
Date: ________________________`
  },
  {
    id: 'tmpl-nda-mutual',
    name: 'Mutual Non-Disclosure Agreement (M-NDA)',
    category: 'ip_confidentiality',
    description: 'Bilateral confidentiality agreement safeguarding proprietary technology, trade secrets, financial records, and commercial negotiations.',
    typicalParties: { primary: 'Disclosing / Receiving Party A', counterparty: 'Disclosing / Receiving Party B' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-nda-mutual'] || [],
    defaultClauses: [
      'Definition of Confidential Information & Exclusions (Public, Known, Independent Development)',
      'Non-Disclosure, Non-Use & Standard of Care Obligations',
      'Permitted Disclosures to Representatives & Need-to-Know Standard',
      'Compelled Disclosures & Prior Written Notice Protocol',
      'Return or Certified Destruction of Confidential Materials',
      'No License Grant or Warranty of Accuracy',
      'Term of Agreement & Post-Termination Confidentiality Survival (3-5 Years / Trade Secrets Perpetual)',
      'Injunctive Relief & Specific Performance',
      'Governing Law & Jurisdiction'
    ],
    mandatoryJurisdictionClauses: {
      US: ['Defend Trade Secrets Act (DTSA) Immunity Notice (18 U.S.C. § 1833(b))'],
      IN: ['Section 27 Indian Contract Act Non-Restraint Confirmation'],
      GB: ['Exclusion of Third Party Rights Act 1999'],
      SG: ['SIAC Emergency Arbitrator Injunctive Relief Procedure'],
      AE: ['DIFC Commercial Court Equitable Relief Clause'],
      DE: ['German Trade Secret Act (GeschGehG) Appropriate Safeguards Representation']
    },
    recommendedLiabilityCap: 'Uncapped or significant carve-out for intentional disclosure of trade secrets',
    recommendedGoverningLaw: 'Delaware (US), England & Wales (UK), India, or Singapore',
    sampleDraft: `BILATERAL MUTUAL NON-DISCLOSURE & CONFIDENTIALITY AGREEMENT

This Mutual Non-Disclosure Agreement ("Agreement") is executed as of the Effective Date by and between:

PARTY A: {{PRIMARY_PARTY_NAME}}, having its principal place of business at {{PRIMARY_ADDRESS}}; and

PARTY B: {{COUNTERPARTY_NAME}}, having its principal place of business at {{COUNTERPARTY_ADDRESS}}.

RECITALS
WHEREAS, the Parties wish to engage in exploratory business and commercial discussions concerning {{SCOPE_OF_SERVICES}} ("Permitted Purpose"); and
WHEREAS, in connection with the Permitted Purpose, each Party may disclose to the other Party certain non-public, highly proprietary, technical, financial, operational, and commercial information.

NOW, THEREFORE, the Parties mutually covenant and agree as follows:

1. DEFINITION OF CONFIDENTIAL INFORMATION
1.1 Scope: "Confidential Information" means all non-public, proprietary information disclosed by one Party ("Disclosing Party") to the other Party ("Receiving Party"), whether disclosed orally, visually, in writing, or in electronic format, that is designated as confidential or which reasonably should be understood to be confidential given the nature of the information and circumstances of disclosure.
1.2 Specific Inclusions: Confidential Information includes, without limitation: source code, object code, API specifications, system architectures, database designs, cryptographic keys, technical documentation, product roadmaps, inventions, financial forecasts, customer lists, pricing structures, and the fact that discussions are occurring.

2. EXCLUSIONS FROM CONFIDENTIALITY
2.1 Standard Exclusions: Confidential Information shall not include information that the Receiving Party can establish by contemporaneous written records: (a) is or becomes publicly available without breach of this Agreement; (b) was already in the lawful possession of the Receiving Party without confidentiality restrictions prior to disclosure; (c) is independently developed by employees with no access to or knowledge of Disclosing Party's information; or (d) is rightfully received from an unencumbered third party.

3. NON-DISCLOSURE, NON-USE & REASONABLE STANDARD OF CARE
3.1 Standard of Care: Receiving Party covenants to protect Confidential Information with the same degree of care it exercises to protect its own sensitive confidential materials of like nature, but not less than a reasonable degree of care.
3.2 Limited Use: Receiving Party shall use Confidential Information solely and exclusively to evaluate and further the Permitted Purpose and for no other commercial or competitive purpose.
3.3 Reverse Engineering Bar: Receiving Party shall not decompile, disassemble, decrypt, analyze, or reverse engineer any software, hardware, prototypes, or data models provided hereunder.

4. PERMITTED DISCLOSURES TO REPRESENTATIVES
4.1 Need-to-Know Standard: Receiving Party may disclose Confidential Information only to its directors, officers, employees, legal counsel, and accountants who have a strict need to know for the Permitted Purpose and who are bound by confidentiality obligations no less restrictive than those herein. Receiving Party remains primarily liable for all unauthorized disclosures by its representatives.

5. LEGALLY COMPELLED DISCLOSURES
5.1 Notice Protocol: If Receiving Party is required by valid court order, subpoena, or administrative summons to disclose Confidential Information, it shall provide prompt written notice to Disclosing Party prior to disclosure to enable Disclosing Party to seek a protective order, and shall disclose only the minimum legally required.

6. RETURN OR CERTIFIED DESTRUCTION OF MATERIALS
6.1 14-Day Purge: Upon Disclosing Party's written request or upon termination, Receiving Party shall within fourteen (14) days return or permanently destroy all confidential documents and files, delivering an officer-signed Certificate of Destruction. Routine automated IT disaster recovery backups may be retained subject to ongoing confidentiality until overwritten.

7. TERM & SURVIVAL OF COVENANTS
7.1 Duration: This Agreement covers disclosures made during a two (2) year period from the Effective Date. The confidentiality covenants shall survive for five (5) years following disclosure; provided, however, that all Confidential Information constituting trade secrets under Applicable Law shall be maintained in strict confidence perpetually.

8. INJUNCTIVE RELIEF & SPECIFIC PERFORMANCE
8.1 Equitable Remedies: Receiving Party acknowledges that unauthorized disclosure causes immediate irreparable harm for which monetary damages are inadequate. Disclosing Party shall be entitled to seek immediate injunctive relief and specific performance in any court of competent jurisdiction without the necessity of posting bond.

9. STATUTORY DTSA WHISTLEBLOWER IMMUNITY NOTICE (18 U.S.C. § 1833(b))
9.1 Notice: An individual shall not be held criminally or civilly liable under any trade secret law for confidential disclosure of a trade secret made solely to a government official or attorney for investigating a suspected violation of law, or in a complaint filed under seal.

10. GOVERNING LAW & JURISDICTION
10.1 Law & Venue: This Agreement shall be governed by the laws of {{GOVERNING_LAW}}. The prevailing Party in any enforcement action shall be entitled to recover reasonable attorney's fees and costs.

IN WITNESS WHEREOF, the Parties have executed this Agreement:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}} ({{COUNTERPARTY_DESIGNATION}})
Date: ________________________`
  },
  {
    id: 'tmpl-employment',
    name: 'Executive / Employment Agreement',
    category: 'employment',
    description: 'Comprehensive employment contract detailing compensation, performance incentives, intellectual property assignment, confidentiality, benefits, and termination protocols.',
    typicalParties: { primary: 'Employer / Company', counterparty: 'Executive / Employee' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-employment'] || [],
    defaultClauses: [
      'Job Title, Duties, Reporting Line & Place of Work',
      'Base Compensation, Performance Bonus & Equity Incentive Schedule',
      'Employee Benefits, Health Insurance & Paid Time Off (PTO)',
      'At-Will Employment or Fixed Term with Notice Period',
      'Comprehensive IP Assignment & Invention Disclosure',
      'Confidentiality & Non-Disclosure Obligations',
      'Non-Solicitation of Customers & Employees (12 Months)',
      'Jurisdiction-Compliant Restrictive Covenants',
      'Termination for Cause, Termination Without Cause & Severance Package',
      'Return of Company Property & Post-Termination Undertakings',
      'Governing Law & Dispute Resolution'
    ],
    mandatoryJurisdictionClauses: {
      US: ['California AB 1076 / SB 699 Non-Compete Carve-Out (if CA)', 'DTSA Whistleblower Notice'],
      IN: ['Indian Contract Act Sec 27 Non-Compete Post-Termination Void Notice', 'Provident Fund & Gratuity Act Compliance'],
      GB: ['Employment Rights Act 1996 Written Statement Compliance', 'Garden Leave Clause'],
      SG: ['Employment Act (Cap. 91) Statutory Leave & Working Hours Standards'],
      AE: ['UAE Federal Decree-Law No. 33 of 2021 (Labour Law) Statutory End-of-Service Gratuity'],
      DE: ['German Works Constitution Act (BetrVG) & Notice Period Compliance (§ 622 BGB)']
    },
    recommendedLiabilityCap: 'Not applicable (statutory employment limits apply)',
    recommendedGoverningLaw: 'Jurisdiction where employee physically performs services',
    sampleDraft: `EXECUTIVE EMPLOYMENT & PROPRIETARY INVENTIONS AGREEMENT

This Executive Employment Agreement ("Agreement") is executed as of the Effective Date by and between:

EMPLOYER: {{PRIMARY_PARTY_NAME}}, a corporation organized and existing under the laws of {{JURISDICTION}}, having its principal place of business at {{PRIMARY_ADDRESS}} ("Company"); and

EXECUTIVE: {{COUNTERPARTY_NAME}}, residing at {{COUNTERPARTY_ADDRESS}} ("Executive").

NOW, THEREFORE, the Parties mutually agree as follows:

1. APPOINTMENT, POSITION & DUTIES
1.1 Position: Company hereby employs Executive, and Executive accepts employment with Company, in the executive capacity of {{SCOPE_OF_SERVICES}}. Executive shall report directly to the Chief Executive Officer and Board of Directors.
1.2 Devotion of Time & Fiduciary Duty: Executive shall devote Executive's entire business time, best efforts, and undivided professional loyalty to advancing Company's commercial interests, and owes Company a strict fiduciary duty of loyalty and care.

2. COMPENSATION, BONUS & EQUITY INCENTIVES
2.1 Base Salary: Company shall pay Executive an annual gross base salary of {{CONTRACT_VALUE}} {{CURRENCY}}, payable in equal monthly installments subject to statutory payroll tax withholdings and deductions.
2.2 Annual Performance Bonus: Executive shall be eligible to earn an annual target cash bonus of up to 30% of base salary, contingent upon corporate and individual performance milestones established by the Board.
2.3 Equity Grant: Subject to Board approval, Executive shall receive stock options or RSUs subject to standard four-year vesting (25% cliff at 12 months, followed by equal monthly vesting over 36 months).

3. BENEFITS, HEALTH INSURANCE & PAID TIME OFF
3.1 Benefits: Executive and eligible dependents shall be entitled to participate in all standard Company health, medical, dental, vision, life, disability, and 401(k) / retirement plans.
3.2 Annual Vacation: Executive shall be entitled to four (4) weeks of paid vacation per calendar year.

4. PROPRIETARY INFORMATION & INVENTIONS ASSIGNMENT (PIIA)
4.1 Complete IP Assignment: Executive agrees that all software code, inventions, discoveries, designs, and works of authorship created or conceived by Executive during the period of employment ("Company Inventions") are "works made for hire" and shall belong solely and perpetually to Company. Executive hereby unconditionally assigns all worldwide right, title, and interest in such inventions to Company.
4.2 Moral Rights Waiver: Executive irrevocably waives all moral rights and appoints Company as attorney-in-fact to execute patent and copyright filings if Executive is unavailable.

5. RESTRICTIVE COVENANTS & NON-SOLICITATION (12 MONTHS)
5.1 Employee Non-Solicitation: During employment and for twelve (12) months following termination for any reason, Executive shall not, directly or indirectly, solicit, recruit, or hire any employee or regular contractor of Company.
5.2 Customer Non-Solicitation: For twelve (12) months post-termination, Executive shall not solicit or divert commercial business from any customer or prospective client with whom Executive interacted during the prior 24 months.

6. TERMINATION FRAMEWORK & SEVERANCE
6.1 Termination for Cause: Company may terminate immediately for Cause (felony conviction, fraud, embezzlement, gross insubordination, or uncured material breach).
6.2 Termination Without Cause: Company may terminate without Cause on {{PAYMENT_DUE_DAYS}} days written notice. In such event, upon executing a general release of claims, Executive shall receive six (6) months of base salary continuation and health insurance coverage.

7. GOVERNING LAW & DISPUTE RESOLUTION
7.1 Governance: This Agreement shall be governed by the employment laws of {{GOVERNING_LAW}}. Disputes shall be resolved through binding employment arbitration with employer-paid forum fees.

IN WITNESS WHEREOF, the Parties have executed this Agreement:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}}
Date: ________________________`
  },
  {
    id: 'tmpl-independent-contractor',
    name: 'Independent Contractor / Consultancy Agreement',
    category: 'employment',
    description: 'Engagement contract structured to preserve independent contractor status, prevent worker misclassification, and secure complete IP assignment.',
    typicalParties: { primary: 'Client / Principal', counterparty: 'Independent Consultant / Contractor' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-independent-contractor'] || [],
    defaultClauses: [
      'Independent Contractor Status & Non-Employee Declaration',
      'Scope of Consultancy Services, Deliverables & Timeline',
      'Consulting Fees, Invoicing & Tax Responsibility (Self-Employment)',
      'Immediate Assignment of Inventions & Moral Rights Waiver',
      'Non-Exclusivity & Right to Perform Other Engagements',
      'Confidentiality & Non-Disclosure',
      'Termination on Written Notice (15-30 Days)',
      'Indemnification for Tax Misclassification & Governing Law'
    ],
    mandatoryJurisdictionClauses: {
      US: ['IRS 20-Factor / ABC Classification Test Compliance (Dynamex / CA AB 5)'],
      IN: ['TDS Section 194J Deduction Undertaking', 'No Employer-Employee Relationship Warranty'],
      GB: ['IR35 / Off-Payroll Working Rules Compliance (ITEPA 2003 Part 2 Chapter 10)'],
      SG: ['MOM Independent Contractor Status Safeguard'],
      AE: ['Freelance Permit / Corporate Commercial License Verification'],
      DE: ['Scheinselbständigkeit (False Self-Employment) Prevention Safeguards']
    },
    recommendedLiabilityCap: '100% of fees paid under contract',
    recommendedGoverningLaw: 'Client Home Jurisdiction or Contractor Place of Performance',
    sampleDraft: `INDEPENDENT CONTRACTOR CONSULTING & DELIVERABLES AGREEMENT

This Independent Contractor Agreement ("Agreement") is entered into as of the Effective Date by and between:

CLIENT: {{PRIMARY_PARTY_NAME}}, having its principal place of business at {{PRIMARY_ADDRESS}}; and

CONTRACTOR: {{COUNTERPARTY_NAME}}, having its principal place of business at {{COUNTERPARTY_ADDRESS}}.

NOW, THEREFORE, the Parties agree as follows:

1. INDEPENDENT CONTRACTOR STATUS & TAX INDEPENDENCE
1.1 True Independent Status: Contractor is an independent contractor and not an employee, agent, or partner of Client. Contractor retains full discretion over working methods, schedules, and tools.
1.2 No Employee Benefits: Contractor acknowledges that neither Contractor nor its personnel are entitled to employee benefits, overtime, health insurance, or unemployment compensation.
1.3 Tax Obligations: Contractor assumes sole responsibility for all federal, state, and local income taxes, self-employment taxes, GST, and statutory withholdings.

2. CONSULTANCY SERVICES, DELIVERABLES & FEES
2.1 Services Scope: Contractor shall perform {{SCOPE_OF_SERVICES}} and deliver milestones within agreed timeframes.
2.2 Commercial Fees: Client shall pay Contractor the total fee of {{CONTRACT_VALUE}} {{CURRENCY}}, payable Net thirty (30) calendar days from receipt of a valid itemized tax invoice following acceptance of Deliverables.

3. OWNERSHIP OF DELIVERABLES & IRREVOCABLE IP ASSIGNMENT
3.1 Client Ownership: All custom code, designs, technical documentation, and Deliverables created under this Agreement shall belong exclusively to Client.
3.2 Assignment: Contractor hereby unconditionally and irrevocably assigns to Client all worldwide right, title, and interest in and to all Deliverables, including copyrights, patents, and trade secrets, and irrevocably waives all moral rights.

4. INDEMNIFICATION FOR WORKER MISCLASSIFICATION
4.1 Indemnity: Contractor shall defend, indemnify, and hold harmless Client against any claims, liabilities, tax assessments, penalties, or fines arising from any assertion by tax or labor authorities that Contractor is an employee of Client.

5. TERMINATION & GOVERNING LAW
5.1 Termination: Either Party may terminate upon fourteen (14) days written notice. Client shall pay for accepted Services performed up to termination.
5.2 Governance: This Agreement is governed by the laws of {{GOVERNING_LAW}}.

IN WITNESS WHEREOF, the Parties have executed this Agreement:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}} ({{COUNTERPARTY_DESIGNATION}})
Date: ________________________`
  },
  {
    id: 'tmpl-ip-assignment',
    name: 'Intellectual Property Assignment Agreement',
    category: 'ip_confidentiality',
    description: 'Definitive assignment transferring complete worldwide rights, title, patents, trademarks, copyrights, and trade secrets with moral rights waiver.',
    typicalParties: { primary: 'Assignee / Purchaser', counterparty: 'Assignor / Creator' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-ip-assignment'] || [],
    defaultClauses: [
      'Assignment of All Assigned Intellectual Property',
      'Worldwide Scope, All Media & Future Technologies',
      'Waiver of Moral Rights & Authorship Claims',
      'Further Assurances & Obligation to Sign Patent Filings',
      'Representations of Unencumbered Ownership & Non-Infringement',
      'Consideration & Full Receipt Acknowledgment',
      'Governing Law & Jurisdiction'
    ],
    mandatoryJurisdictionClauses: {
      US: ['USPTO Patent/Trademark Recordation Format Compliance'],
      IN: ['Section 19 Indian Copyright Act Royalty & Term Specification'],
      GB: ['Section 90/91 Copyright, Designs and Patents Act 1988 Compliance'],
      SG: ['Singapore Copyright Act 2021 Assignment Rules'],
      AE: ['UAE Federal Law No. 38 of 2021 on Copyrights and Neighboring Rights'],
      DE: ['German Urheberrecht Moral Rights Protection (§ 29 UrhG Grant of Comprehensive Usage Rights)']
    },
    recommendedLiabilityCap: 'Consideration received or uncapped warranty of clear title',
    recommendedGoverningLaw: 'Assignee Corporate Jurisdiction',
    sampleDraft: `DEFINITIVE INTELLECTUAL PROPERTY ASSIGNMENT AGREEMENT

This Definitive Intellectual Property Assignment Agreement ("Agreement") is executed as of the Effective Date by and between:

ASSIGNEE: {{PRIMARY_PARTY_NAME}}, having its principal place of business at {{PRIMARY_ADDRESS}}; and

ASSIGNOR: {{COUNTERPARTY_NAME}}, having its principal place of business at {{COUNTERPARTY_ADDRESS}}.

RECITALS
WHEREAS, Assignor has created, developed, and owns certain valuable proprietary intellectual property assets, software architectures, inventions, algorithms, and related documentation; and
WHEREAS, Assignee wishes to acquire 100% full, unencumbered, worldwide ownership of all such assets, and Assignor has agreed to assign all right, title, and interest therein for valuable consideration.

NOW, THEREFORE, the Parties agree as follows:

1. ABSOLUTE ASSIGNMENT OF INTELLECTUAL PROPERTY
1.1 Complete Transfer: For the consideration of {{CONTRACT_VALUE}} {{CURRENCY}}, the receipt and legal sufficiency of which are hereby acknowledged, Assignor hereby unconditionally, irrevocably, perpetually, and without reservation transfers and assigns to Assignee all worldwide right, title, and interest in and to {{SCOPE_OF_SERVICES}} ("Assigned IP").
1.2 Inclusions: Assigned IP includes all patents, patent applications, copyrights, moral rights, trademarks, domain names, trade secrets, software source code, algorithms, and architectures.

2. TRANSFER OF ACCRUED CAUSES OF ACTION
2.1 Past & Future Claims: The assignment includes all accrued, existing, and future rights to sue for past, present, or future infringement or misappropriation of the Assigned IP and to collect all damages, royalties, and equitable relief.

3. WAIVER OF MORAL RIGHTS
3.1 Waiver: To the fullest extent permitted by Applicable Law, Assignor unconditionally and irrevocably waives all moral rights, droit moral, and rights of attribution, integrity, or paternity in the Assigned IP.

4. FURTHER ASSURANCES & POWER OF ATTORNEY
4.1 Future Co-operation: Assignor covenants to execute all patent applications, assignments, and declarations requested by Assignee. Assignor irrevocably designates Assignee as its attorney-in-fact to execute such filings if Assignor is unavailable.

5. WARRANTIES OF CLEAR TITLE
5.1 Warranty: Assignor represents and warrants that Assignor is the sole legal owner of the Assigned IP, free of all liens, licenses, and encumbrances, and that the Assigned IP does not infringe third-party rights.

6. GOVERNING LAW: Governed by the laws of {{GOVERNING_LAW}}.

IN WITNESS WHEREOF, the Parties have executed this Agreement:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}} ({{COUNTERPARTY_DESIGNATION}})
Date: ________________________`
  },
  {
    id: 'tmpl-shareholders',
    name: 'Shareholders Agreement (SHA)',
    category: 'corporate',
    description: 'Corporate governance agreement regulating share transfers, board composition, reserved matters, pre-emptive rights, ROFO/ROFR, drag-along, and tag-along rights.',
    typicalParties: { primary: 'Company & Founders', counterparty: 'Investors / Shareholders' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-shareholders'] || [],
    defaultClauses: [
      'Board of Directors Composition & Quorum Requirements',
      'Reserved Matters & Affirmative Voting Thresholds',
      'Right of First Offer (ROFO) & Right of First Refusal (ROFR)',
      'Tag-Along Rights & Drag-Along Rights Thresholds',
      'Pre-Emptive Rights on Future Capital Issuances',
      'Information & Inspection Rights (Audited Financials)',
      'Deadlock Resolution & Escalation Mechanisms',
      'Non-Compete & Founder Vesting Schedules',
      'Liquidation Preference & Exit Waterfall'
    ],
    mandatoryJurisdictionClauses: {
      US: ['Delaware General Corporation Law (DGCL) Alignment'],
      IN: ['Companies Act 2013 Articles of Association (AOA) Amendment Mandate'],
      GB: ['UK Companies Act 2006 Consistency'],
      SG: ['Singapore Companies Act (Cap. 50) S76 Financial Assistance Compliance'],
      AE: ['DIFC Companies Law / ADGM Companies Regulations 2020'],
      DE: ['German GmbH-Gesetz / Notarization Requirement (§ 15 GmbHG)']
    },
    recommendedLiabilityCap: 'Customary share value exposure',
    recommendedGoverningLaw: 'Corporate Incorporation Jurisdiction',
    sampleDraft: `SHAREHOLDERS AGREEMENT & CORPORATE GOVERNANCE FRAMEWORK

This Shareholders Agreement ("Agreement") is executed as of the Effective Date by and among:

COMPANY: {{PRIMARY_PARTY_NAME}}, having its registered office at {{PRIMARY_ADDRESS}};
FOUNDERS: The executive founders holding common equity; and
INVESTORS: {{COUNTERPARTY_NAME}}, holding preferred equity ("Major Investor").

NOW, THEREFORE, the Parties agree as follows:

1. BOARD OF DIRECTORS GOVERNANCE & QUORUM
1.1 Composition: The Board shall comprise five (5) directors: two (2) Founder nominees, one (1) Major Investor nominee ("Investor Director"), the CEO, and one (1) mutually agreed independent director.
1.2 Quorum: A valid quorum requires at least one Founder Director and the Investor Director present in person or via video conference.

2. RESERVED MATTERS & AFFIRMATIVE INVESTOR CONSENT
2.1 Major Actions: The Company shall not take any of the following actions without the prior affirmative written vote of the Investor Director:
    (a) any merger, acquisition, sale of substantially all assets, or corporate dissolution;
    (b) the creation or issuance of new senior equity securities;
    (c) incurring debt or commercial borrowing in excess of $250,000;
    (d) any transactions with related parties or Affiliates.

3. TRANSFER RESTRICTIONS: ROFR & TAG-ALONG RIGHTS
3.1 Right of First Refusal (ROFR): Any transfer of shares by Founders is subject to a 30-day ROFR in favor of the Company, and secondarily the Major Investors.
3.2 Tag-Along Rights: If a Founder sells shares to a third party, Major Investors have the right to participate pro-rata on identical terms.

4. DRAG-ALONG RIGHTS ON APPROVED EXITS
4.1 Drag-Along Trigger: If the Board and 65% of voting shareholders approve a bona fide third-party acquisition ("Approved Exit"), all shareholders are obligated to sell their shares on identical terms.

5. PRE-EMPTIVE RIGHTS & FOUNDER VESTING
5.1 Anti-Dilution: Major Investors have pro-rata pre-emptive rights on all new share issuances.
5.2 Founder Vesting: Founder shares are subject to 4-year reverse vesting with a 1-year cliff.

6. GOVERNING LAW: Governed by the corporate statutes of {{GOVERNING_LAW}}.

IN WITNESS WHEREOF, the Parties have executed this Agreement:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}} ({{COUNTERPARTY_DESIGNATION}})
Date: ________________________`
  },
  {
    id: 'tmpl-commercial-lease',
    name: 'Commercial Real Estate Lease Agreement',
    category: 'real_estate',
    description: 'Commercial tenancy agreement for office, retail, or industrial premises governing rent, operating expenses, security deposit, maintenance, and fit-outs.',
    typicalParties: { primary: 'Landlord / Property Owner', counterparty: 'Tenant / Commercial Lessee' },
    detailedClauses: TEMPLATE_DETAILED_CLAUSES['tmpl-commercial-lease'] || [],
    defaultClauses: [
      'Demised Premises Description & Permitted Use',
      'Lease Term, Possession Date & Rent Commencement Date',
      'Base Rent, Annual Escalation (3-5%) & Operating Expenses (CAM)',
      'Security Deposit Amount, Replenishment & Return Protocol',
      'Fit-Out Period, Alterations & Structural Maintenance',
      'Utilities, Taxes, Insurance & Indemnity',
      'Assignment & Subletting Restrictions',
      'Landlord Access, Quiet Enjoyment & Surrender Condition',
      'Default, Cure Periods & Eviction Procedures'
    ],
    mandatoryJurisdictionClauses: {
      US: ['State Commercial Tenancy Statutes & ADA Compliance'],
      IN: ['Registration Act 1908 Mandate (>11 Months) & Stamp Duty Assessment'],
      GB: ['Landlord and Tenant Act 1954 Contracting Out (Security of Tenure)'],
      SG: ['Singapore Building and Construction Authority / Stamp Duty'],
      AE: ['Ejari Registration (Dubai Land Department) & RERA Tenancy Rules'],
      DE: ['German Commercial Tenancy BGB §§ 535-580a Standards']
    },
    recommendedLiabilityCap: 'Security deposit value + insurance coverage limits',
    recommendedGoverningLaw: 'Jurisdiction where the real estate property is located',
    sampleDraft: `COMMERCIAL REAL ESTATE LEASE AGREEMENT (TRIPLE NET / NNN)

This Commercial Real Estate Lease Agreement ("Lease") is entered into as of the Effective Date by and between:

LANDLORD: {{PRIMARY_PARTY_NAME}}, having its principal address at {{PRIMARY_ADDRESS}}; and

TENANT: {{COUNTERPARTY_NAME}}, having its principal business address at {{COUNTERPARTY_ADDRESS}}.

NOW, THEREFORE, the Parties agree as follows:

1. DEMISED PREMISES & PERMITTED USE
1.1 Leased Premises: Landlord hereby leases to Tenant, and Tenant leases from Landlord, the commercial premises situated at {{PRIMARY_ADDRESS}} ("Demised Premises").
1.2 Permitted Use: Tenant shall use the Premises solely for general commercial office and technology operations, complying with all local zoning and safety ordinances.

2. TERM, POSSESSION & RENT
2.1 Term: The initial term shall be thirty-six (36) months from the Commencement Date.
2.2 Base Rent & Escalation: Tenant shall pay monthly Base Rent of {{CONTRACT_VALUE}} {{CURRENCY}} in advance on the first day of each month, subject to an annual escalation of five percent (5.0%).
2.3 Operating Expenses (CAM): Tenant shall pay its pro-rata share of Common Area Maintenance (CAM), building insurance, and property taxes, subject to annual audited reconciliations.

3. SECURITY DEPOSIT
3.1 Deposit: Tenant shall deposit three (3) months' rent as Security Deposit. Landlord may apply it to cure defaults, upon which Tenant must replenish within ten (10) Business Days.

4. MAINTENANCE & REPAIRS
4.1 Division of Maintenance: Landlord maintains the roof, foundations, exterior structure, and main MEP infrastructure. Tenant maintains the interior premises, finishes, and fixtures.

5. DEFAULT, CURE & GOVERNING LAW
5.1 Cure Periods: Monetary default: five (5) days written notice; Non-monetary default: fifteen (15) days written notice.
5.2 Governance: Governed by the real property laws of {{GOVERNING_LAW}}.

IN WITNESS WHEREOF, the Parties have executed this Lease:
FOR: {{PRIMARY_PARTY_NAME}}
Signatory: {{PRIMARY_SIGNATORY}} ({{PRIMARY_DESIGNATION}})
Date: ________________________

FOR: {{COUNTERPARTY_NAME}}
Signatory: {{COUNTERPARTY_SIGNATORY}} ({{COUNTERPARTY_DESIGNATION}})
Date: ________________________`
  }
];
