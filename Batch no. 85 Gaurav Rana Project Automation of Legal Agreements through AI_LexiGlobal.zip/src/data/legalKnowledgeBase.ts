import { LegalKnowledgeRule, ClauseIntelligenceItem, LegalRule, ClauseBenchmark, RiskLevel } from '../types';
import { COMPREHENSIVE_STATUTORY_RULES } from './statutoryRules';

export const INITIAL_LEGAL_RULES: any[] = [
  {
    id: 'rule-us-001',
    country: 'United States',
    stateOrProvince: 'Delaware',
    jurisdiction: 'Delaware / Federal',
    ruleName: 'Electronic Signatures in Global and National Commerce Act (E-SIGN Act)',
    lawName: 'Electronic Signatures in Global and National Commerce Act (E-SIGN Act)',
    subjectArea: 'e_signature',
    regulationCategory: 'E-Signatures',
    effectiveDate: '2000-10-01',
    statutoryCitation: '15 U.S.C. § 7001; 6 Del. C. § 12A-107',
    statutorySource: '15 U.S.C. § 7001; 6 Del. C. § 12A-107',
    legalRequirement: 'Affirmative consent for electronic records and signature validity with tamper-evident audit retention under 15 U.S.C. § 7001.',
    recommendedWording: 'Each party consents to the use of electronic signatures in accordance with the U.S. Electronic Signatures in Global and National Commerce Act (15 U.S.C. § 7001 et seq.) and applicable state enactments of the Uniform Electronic Transactions Act (UETA).',
    mandatoryProvisions: [
      'Affirmative consent for electronic records and signature validity',
      'Accurate document retention in tamper-evident format'
    ],
    restrictedProvisions: [
      'Denial of legal effect or enforceability solely because a signature is in electronic form (15 U.S.C. § 7001)'
    ],
    isMandatory: true,
    confidenceScore: 99,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-06-15',
    reviewerCredentials: 'Senior Legal Compliance Officer (Bar No. DE-44912)',
    reviewedBy: 'Senior Legal Compliance Officer (Bar No. DE-44912)'
  },
  {
    id: 'rule-us-002',
    country: 'United States',
    stateOrProvince: 'California',
    jurisdiction: 'California',
    ruleName: 'California Post-Employment Restraints Ban (AB 1076 / SB 699)',
    lawName: 'California Business and Professions Code § 16600 & AB 1076 / SB 699 (Post-Employment Restraints)',
    subjectArea: 'employment',
    regulationCategory: 'Employment',
    effectiveDate: '2024-01-01',
    statutoryCitation: 'Cal. Bus. & Prof. Code §§ 16600, 16600.1, 16600.5',
    statutorySource: 'Cal. Bus. & Prof. Code §§ 16600, 16600.1, 16600.5',
    legalRequirement: 'Post-employment non-compete covenants against California residents or employees performing services in CA are void and actionable unfair competition, regardless of chosen governing law.',
    recommendedWording: 'Nothing in this Agreement shall be construed to restrain the Employee or Contractor from engaging in a lawful profession, trade, or business of any kind following the termination of employment or engagement, in compliance with California Business and Professions Code Section 16600.',
    mandatoryProvisions: [
      'Severability of any restrictive covenant attempting to limit lawful trade or profession'
    ],
    restrictedProvisions: [
      'Post-employment non-compete covenants against California residents or employees performing services in CA, regardless of governing law clause'
    ],
    isMandatory: true,
    confidenceScore: 98,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-07-10',
    reviewerCredentials: 'Lead Employment Counsel (CalBar #291044)',
    reviewedBy: 'Lead Employment Counsel (CalBar #291044)'
  },
  {
    id: 'rule-in-001',
    country: 'India',
    stateOrProvince: 'All India',
    jurisdiction: 'All India (Central)',
    ruleName: 'Restraint of Trade Void Doctrine (Section 27 Contract Act)',
    lawName: 'Section 27, Indian Contract Act, 1872 (Agreement in Restraint of Trade Void)',
    subjectArea: 'employment',
    regulationCategory: 'Contract Law',
    effectiveDate: '1872-09-01',
    statutoryCitation: 'Indian Contract Act 1872, Section 27; Supreme Court Precedents',
    statutorySource: 'Indian Contract Act 1872, Section 27; Supreme Court Precedents',
    legalRequirement: 'Agreements in restraint of lawful profession or trade are void post-termination; protection is strictly limited to proprietary trade secrets and non-solicitation during active engagement.',
    recommendedWording: 'During the term of this Agreement, the Consultant shall not undertake conflicting commercial engagements. Post termination, the Consultant remains strictly bound by the Confidentiality and Proprietary Information covenants herein, without restriction on general professional practice pursuant to Section 27 of the Indian Contract Act, 1872.',
    mandatoryProvisions: [
      'Protection of legitimate confidential information without imposing absolute post-employment commercial non-compete covenants'
    ],
    restrictedProvisions: [
      'Any agreement by which anyone is restrained from exercising a lawful profession, trade or business of any kind is to that extent void'
    ],
    isMandatory: true,
    confidenceScore: 100,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-08-01',
    reviewerCredentials: 'Advocate on Record, Supreme Court of India',
    reviewedBy: 'Advocate on Record, Supreme Court of India'
  },
  {
    id: 'rule-in-002',
    country: 'India',
    stateOrProvince: 'All India',
    jurisdiction: 'All India (Central)',
    ruleName: 'Digital Personal Data Protection Act (DPDPA 2023)',
    lawName: 'Digital Personal Data Protection Act, 2023 (DPDPA)',
    subjectArea: 'data_privacy',
    regulationCategory: 'Data Protection',
    effectiveDate: '2023-08-11',
    statutoryCitation: 'DPDP Act 2023, Sections 6, 8, 9 & 16',
    statutorySource: 'DPDP Act 2023, Sections 6, 8, 9 & 16',
    legalRequirement: 'Data Fiduciaries must execute binding contracts with Data Processors specifying technical safeguards, breach notification within statutory windows, and data erasure upon purpose fulfillment.',
    recommendedWording: 'The Service Provider acts solely as a Data Processor under the Digital Personal Data Protection Act, 2023 (DPDPA) and shall process Personal Data exclusively on the documented instructions of the Customer, maintain robust technical safeguards, and notify the Customer within 24 hours of any suspected personal data breach.',
    mandatoryProvisions: [
      'Data Fiduciary obligation to appoint Data Processors only under valid written contract',
      'Reasonable security safeguards against personal data breaches',
      'Erasure upon withdrawal of consent or purpose fulfillment'
    ],
    restrictedProvisions: [
      'Processing personal data of Indian Data Principals without lawful consent or specified legitimate uses',
      'Unrestricted retention of personal data after termination of services'
    ],
    isMandatory: true,
    confidenceScore: 97,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-08-12',
    reviewerCredentials: 'Data Privacy Practice Group Lead',
    reviewedBy: 'Data Privacy Practice Group Lead'
  },
  {
    id: 'rule-in-003',
    country: 'India',
    stateOrProvince: 'All India',
    jurisdiction: 'All India',
    ruleName: 'Prevention of Corruption Act & Anti-Bribery Compliance',
    lawName: 'Prevention of Corruption Act, 1988 (as amended by Amendment Act 2018)',
    subjectArea: 'liability',
    regulationCategory: 'Corporate Governance',
    effectiveDate: '2018-07-26',
    statutoryCitation: 'Prevention of Corruption Act 1988, Sections 7, 8, 9, 10 & 17A',
    statutorySource: 'Prevention of Corruption Act 1988, Sections 7, 8, 9, 10 & 17A',
    legalRequirement: 'Commercial organisations are liable for acts of bribery by associated persons unless they have put in place adequate internal procedures and compliance guidelines.',
    recommendedWording: 'Each party warrants compliance with the Indian Prevention of Corruption Act, 1988, the US Foreign Corrupt Practices Act, and the UK Bribery Act 2010. Neither party nor its employees or sub-contractors shall offer, promise, or give any undue financial or other advantage.',
    mandatoryProvisions: [
      'Zero-tolerance anti-corruption undertaking',
      'Maintenance of adequate anti-bribery policies and compliance records'
    ],
    restrictedProvisions: [
      'Facilitation payments or unrecorded commercial gratuities'
    ],
    isMandatory: true,
    confidenceScore: 98,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-08-15',
    reviewerCredentials: 'White Collar & Regulatory Compliance Counsel',
    reviewedBy: 'White Collar & Regulatory Compliance Counsel'
  },
  {
    id: 'rule-in-004',
    country: 'India',
    stateOrProvince: 'All India',
    jurisdiction: 'All India',
    ruleName: 'CERT-In Cybersecurity Directions (6-Hour Incident Reporting)',
    lawName: 'Information Technology Act, 2000 & CERT-In Directions under Section 70B(6)',
    subjectArea: 'data_privacy',
    regulationCategory: 'Cybersecurity',
    effectiveDate: '2022-06-28',
    statutoryCitation: 'CERT-In Directions No. 20(3)/2022-CERT-In under Section 70B(6) IT Act 2000',
    statutorySource: 'CERT-In Directions No. 20(3)/2022-CERT-In under Section 70B(6) IT Act 2000',
    legalRequirement: 'Service providers and intermediaries must report cyber incidents to CERT-In within 6 hours of notice and maintain system logs securely within Indian jurisdiction for rolling 180 days.',
    recommendedWording: 'Provider shall maintain information security logs for at least 180 days and report any material cybersecurity breach to Customer immediately and no later than six (6) hours following detection, enabling regulatory compliance with CERT-In directions.',
    mandatoryProvisions: [
      'System log retention for minimum 180 days',
      'Prompt cybersecurity incident notification'
    ],
    restrictedProvisions: [
      'Concealment of unauthorized system intrusions or ransomware incidents'
    ],
    isMandatory: true,
    confidenceScore: 99,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-08-10',
    reviewerCredentials: 'Cybersecurity & Tech Law Practice Leader',
    reviewedBy: 'Cybersecurity & Tech Law Practice Leader'
  },
  {
    id: 'rule-uk-001',
    country: 'United Kingdom',
    stateOrProvince: 'England & Wales',
    jurisdiction: 'England & Wales',
    ruleName: 'Third Party Rights Exclusion (Contracts Act 1999)',
    lawName: 'Contracts (Rights of Third Parties) Act 1999',
    subjectArea: 'liability',
    regulationCategory: 'Contract Law',
    effectiveDate: '1999-11-11',
    statutoryCitation: 'Contracts (Rights of Third Parties) Act 1999, c. 31, Section 1',
    statutorySource: 'Contracts (Rights of Third Parties) Act 1999, c. 31, Section 1',
    legalRequirement: 'Express exclusion clause required to prevent unintended non-parties from acquiring and enforcing contractual rights under English law.',
    recommendedWording: 'A person who is not a party to this Agreement shall have no right under the Contracts (Rights of Third Parties) Act 1999 to enforce any of its terms.',
    mandatoryProvisions: [
      'Express exclusion clause if non-parties are not intended to enforce contractual terms'
    ],
    restrictedProvisions: [
      'Allowing unintended third-party beneficiaries to claim rights unless explicitly identified'
    ],
    isMandatory: true,
    confidenceScore: 100,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-05-20',
    reviewerCredentials: 'Solicitor of the Senior Courts of England and Wales',
    reviewedBy: 'Solicitor of the Senior Courts of England and Wales'
  },
  {
    id: 'rule-eu-001',
    country: 'Germany (European Union)',
    stateOrProvince: 'EU Wide',
    jurisdiction: 'Germany / EU',
    ruleName: 'GDPR Article 28 Mandatory Data Processing Terms',
    lawName: 'EU General Data Protection Regulation (GDPR) Article 28 (Controller-Processor)',
    subjectArea: 'data_privacy',
    regulationCategory: 'Data Protection',
    effectiveDate: '2018-05-25',
    statutoryCitation: 'Regulation (EU) 2016/679, Article 28 & Chapter V',
    statutorySource: 'Regulation (EU) 2016/679, Article 28 & Chapter V',
    legalRequirement: 'Mandatory Article 28(3) stipulations: controller instructions, personnel confidentiality, sub-processor consent, security measures, audit rights, and SCCs for international transfers.',
    recommendedWording: 'The parties hereby execute the Data Processing Addendum (Schedule B) compliant with Article 28 of Regulation (EU) 2016/679 (GDPR), incorporating the EU Commission Standard Contractual Clauses for international data transfers where applicable.',
    mandatoryProvisions: [
      'Mandatory Article 28(3) stipulations: subject matter, duration, nature/purpose, types of personal data, categories of data subjects',
      'Commitment to confidentiality by personnel',
      'Sub-processor authorization requirement',
      'Assistance with data subject rights (Articles 15-22)',
      'Deletion or return of data at end of contract',
      'Audit rights and compliance verification'
    ],
    restrictedProvisions: [
      'Processing personal data without documented controller instructions',
      'Cross-border transfers to non-adequate third countries without Standard Contractual Clauses (SCCs) or adequacy decisions'
    ],
    isMandatory: true,
    confidenceScore: 99,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-07-28',
    reviewerCredentials: 'European Certified Data Protection Officer',
    reviewedBy: 'European Certified Data Protection Officer'
  },
  {
    id: 'rule-sg-001',
    country: 'Singapore',
    stateOrProvince: 'Singapore',
    jurisdiction: 'Singapore',
    ruleName: 'SIAC International Arbitration Framework (Cap. 143A)',
    lawName: 'International Arbitration Act (Cap. 143A) & SIAC Model Clause',
    subjectArea: 'dispute_resolution',
    regulationCategory: 'Arbitration',
    effectiveDate: '2020-12-01',
    statutoryCitation: 'Singapore International Arbitration Act (Cap 143A); SIAC Model Clause',
    statutorySource: 'Singapore International Arbitration Act (Cap 143A); SIAC Model Clause',
    legalRequirement: 'Mandatory designation of arbitration seat, administering institution (SIAC), procedural rules, tribunal composition, and official proceeding language.',
    recommendedWording: 'Any dispute arising out of or in connection with this contract, including any question regarding its existence, validity or termination, shall be referred to and finally resolved by arbitration administered by the Singapore International Arbitration Centre (SIAC) in accordance with the Arbitration Rules of the Singapore International Arbitration Centre (SIAC Rules) for the time being in force, which rules are deemed to be incorporated by reference in this clause. The seat of the arbitration shall be Singapore. The Tribunal shall consist of one (1) arbitrator. The language of the arbitration shall be English.',
    mandatoryProvisions: [
      'Clear selection of arbitration seat (Singapore)',
      'Designation of SIAC arbitration rules and appointing authority',
      'Single arbitrator mechanism for accelerated disposition'
    ],
    restrictedProvisions: [
      'Ambiguous multi-tiered clauses lacking definitive fallback forum'
    ],
    isMandatory: false,
    confidenceScore: 99,
    verificationStatus: 'verified',
    status: 'Verified',
    lastVerifiedDate: '2026-06-30',
    reviewerCredentials: 'FSIArb / Member of the Singapore Bar',
    reviewedBy: 'FSIArb / Member of the Singapore Bar'
  }
];

export const INITIAL_CLAUSE_LIBRARY: any[] = [
  // 1. Detailed Definitions
  {
    id: 'clause-def-01',
    name: 'Detailed Definitions & Interpretations',
    clauseName: 'Detailed Definitions & Interpretations',
    category: 'definitions_scope',
    jurisdiction: 'Global / Enterprise Commercial',
    description: 'Establishes precise, unambiguous legal meanings for core defined terms including Services, Deliverables, Work Product, Confidential Information, Customer Data, Personal Data, Business Day, and SLA.',
    explanation: 'Prevents contractual ambiguity and litigation disputes by explicitly bounding critical operational, commercial, and IP terms throughout the agreement.',
    marketStandard: '"Business Day" means any day other than a Saturday, Sunday, or official bank holiday in the governing jurisdiction. "Services" means the technology engineering, AI infrastructure, cybersecurity, and consulting services described in an executed Statement of Work. "Deliverables" means all reports, software modules, algorithms, scripts, documentation, and work output provided to Customer. "Customer Data" means all electronic data, files, and information submitted by or on behalf of Customer. "Personal Data" has the meaning ascribed under applicable Data Protection Legislation. "Work Product" means all custom inventions, code, designs, and Deliverables authored specifically for Customer under this Agreement.',
    standardWording: '"Business Day" means any day other than a Saturday, Sunday, or official bank holiday in the governing jurisdiction. "Services" means the technology engineering, AI infrastructure, cybersecurity, and consulting services described in an executed Statement of Work. "Deliverables" means all reports, software modules, algorithms, scripts, documentation, and work output provided to Customer. "Customer Data" means all electronic data, files, and information submitted by or on behalf of Customer. "Personal Data" has the meaning ascribed under applicable Data Protection Legislation. "Work Product" means all custom inventions, code, designs, and Deliverables authored specifically for Customer under this Agreement.',
    companyFriendly: 'Definitions strictly limit "Work Product" to only final, fully paid custom deliverables while broadly defining Service Provider\'s "Background IP" and proprietary toolkits to prevent unintended IP transfer.',
    companyFriendlyWording: 'Definitions strictly limit "Work Product" to only final, fully paid custom deliverables while broadly defining Service Provider\'s "Background IP" and proprietary toolkits to prevent unintended IP transfer.',
    counterpartyFriendly: 'Comprehensive definitions vesting all created data, derivative works, and technical artifacts under Customer ownership immediately upon inception with expansive Personal Data protections.',
    counterpartyFriendlyWording: 'Comprehensive definitions vesting all created data, derivative works, and technical artifacts under Customer ownership immediately upon inception with expansive Personal Data protections.',
    recommendedCompromise: 'Include comprehensive definitions with distinct separation between Customer Data/Work Product (owned by Customer) and Vendor Pre-Existing Tools (licensed to Customer).',
    fallbackWording: 'Include comprehensive definitions with distinct separation between Customer Data/Work Product and Vendor Pre-Existing Tools.',
    benchmarkRange: 'Essential mandatory clause in all enterprise agreements (100% market presence).',
    industryBenchmarkRange: 'Essential mandatory clause in all enterprise agreements (100% market presence).',
    riskLevel: 'critical',
    legalSource: 'Restatement (Second) of Contracts § 201; Uniform Commercial Code § 1-201',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard UCC Art. 2 and Delaware corporate definitions.',
      'India': 'Conforms to Indian Contract Act 1872 Section 2 and IT Act 2000 definitions.',
      'United Kingdom': 'Interpretation Act 1978 and English commercial drafting conventions.'
    }
  },

  // 2. Detailed Statement of Work / SOW
  {
    id: 'clause-sow-02',
    name: 'Detailed Statement of Work (SOW) & Milestone Acceptance',
    clauseName: 'Detailed Statement of Work (SOW) & Milestone Acceptance',
    category: 'definitions_scope',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Governs specific engagement scope, project phases, milestone deliverables, technical specifications, acceptance testing criteria, and formal change control procedures.',
    explanation: 'Transforms vague verbal understandings into enforceable technical milestones with objective pass/fail acceptance testing and written sign-offs.',
    marketStandard: 'Each SOW executed pursuant to this Agreement shall specify: (a) detailed Scope of Services and technical specifications; (b) milestone schedule and delivery dates; (c) acceptance criteria and review protocol (10 business days for testing, 5 business days for vendor rectification of non-conformity); (d) milestone fee schedule; and (e) designated key personnel. Any scope modifications must be documented in a written Change Order signed by both parties.',
    standardWording: 'Each SOW executed pursuant to this Agreement shall specify: (a) detailed Scope of Services and technical specifications; (b) milestone schedule and delivery dates; (c) acceptance criteria and review protocol (10 business days for testing, 5 business days for vendor rectification of non-conformity); (d) milestone fee schedule; and (e) designated key personnel. Any scope modifications must be documented in a written Change Order signed by both parties.',
    companyFriendly: 'Deemed acceptance if Customer does not provide detailed written rejection within seven (7) days of delivery; out-of-scope requests billed at standard time & material rates.',
    companyFriendlyWording: 'Deemed acceptance if Customer does not provide detailed written rejection within seven (7) days of delivery; out-of-scope requests billed at standard time & material rates.',
    counterpartyFriendly: 'Fourteen (14) business day acceptance window; repeated failure to meet acceptance criteria grants Customer immediate termination rights with full refund of milestone fees.',
    counterpartyFriendlyWording: 'Fourteen (14) business day acceptance window; repeated failure to meet acceptance criteria grants Customer immediate termination rights with full refund of milestone fees.',
    recommendedCompromise: '10 business days inspection window; up to two (2) cure cycles for non-conformity before commercial escalation.',
    fallbackWording: '10 business days inspection window; up to two cure cycles for non-conformity before commercial escalation.',
    benchmarkRange: '10-14 days inspection period with structured change request process.',
    industryBenchmarkRange: '10-14 days inspection period with structured change request process.',
    riskLevel: 'critical',
    legalSource: 'UCC § 2-606 (Acceptance of Goods/Services); English Sale of Goods Act 1979',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Explicit deemed acceptance required to avoid open-ended project acceptance disputes.',
      'India': 'Section 55 Indian Contract Act time-as-essence considerations.'
    }
  },

  // 3. Service Level Agreement (SLA) & 24/7 Support
  {
    id: 'clause-sla-03',
    name: 'Service Level Agreement (SLA) & 24/7 Level-3 Technical Support',
    clauseName: 'Service Level Agreement (SLA) & 24/7 Level-3 Technical Support',
    category: 'sla_support',
    jurisdiction: 'Global / SaaS & Cloud Infrastructure',
    description: 'Guarantees 99.9% uptime availability, 24/7 Level-3 senior technical support, Severity 1-4 incident response/resolution timelines, and tiered service credits for downtime.',
    explanation: 'Vital for cloud, AI, and mission-critical engineering services where downtime directly causes operational paralysis and commercial losses.',
    marketStandard: 'Provider guarantees 99.9% Monthly Uptime Availability (excluding scheduled maintenance with 48h notice). Provider shall deliver 24/7/365 Level-3 Technical Support with target response and resolution times: Severity 1 (Critical System Down): 15-min response, 2-hr resolution; Severity 2 (Major Impairment): 1-hr response, 6-hr resolution; Severity 3 (Moderate Issue): 4-hr response, 24-hr resolution; Severity 4 (Minor/Query): 12-hr response. If Uptime falls below 99.9%, Customer earns Service Credits: 99.0%-99.89% = 10% monthly fee credit; 95.0%-98.99% = 25% credit; <95.0% = 50% credit.',
    standardWording: 'Provider guarantees 99.9% Monthly Uptime Availability (excluding scheduled maintenance with 48h notice). Provider shall deliver 24/7/365 Level-3 Technical Support with target response and resolution times: Severity 1 (Critical System Down): 15-min response, 2-hr resolution; Severity 2 (Major Impairment): 1-hr response, 6-hr resolution; Severity 3 (Moderate Issue): 4-hr response, 24-hr resolution; Severity 4 (Minor/Query): 12-hr response. If Uptime falls below 99.9%, Customer earns Service Credits: 99.0%-99.89% = 10% monthly fee credit; 95.0%-98.99% = 25% credit; <95.0% = 50% credit.',
    companyFriendly: '99.5% uptime target; Service Credits capped at 15% of monthly fees as Customer\'s sole and exclusive monetary remedy for availability failures.',
    companyFriendlyWording: '99.5% uptime target; Service Credits capped at 15% of monthly fees as Customer\'s sole and exclusive monetary remedy for availability failures.',
    counterpartyFriendly: '99.95% uptime commitment; 24/7 L3 phone/video bridge within 10 minutes; chronic SLA failure (<98% in any 2 consecutive months) triggers termination for cause with unearned fee refund.',
    counterpartyFriendlyWording: '99.95% uptime commitment; 24/7 L3 phone/video bridge within 10 minutes; chronic SLA failure triggers termination for cause with full refund.',
    recommendedCompromise: '99.9% uptime, 24/7 L3 support for Severity 1 & 2, max 30% monthly service credit cap, chronic breach termination right if uptime <95% in two consecutive months.',
    fallbackWording: '99.9% uptime, 24/7 L3 support for Severity 1 & 2, max 30% monthly service credit cap.',
    benchmarkRange: '99.5% - 99.99% availability; 15 min - 1 hr Sev-1 response time.',
    industryBenchmarkRange: '99.5% - 99.99% availability; 15 min - 1 hr Sev-1 response time.',
    riskLevel: 'critical',
    legalSource: 'Enterprise ITIL Standards; Cloud SLA Industry Benchmarks',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard service credit sole-and-exclusive remedy drafting.',
      'India': 'Liquidated damages vs penalty analysis under Section 74 Indian Contract Act.'
    }
  },

  // 4. Data Processing Agreement (DPA)
  {
    id: 'clause-dpa-04',
    name: 'Data Processing Agreement & Privacy Compliance (DPDPA / GDPR)',
    clauseName: 'Data Processing Agreement & Privacy Compliance (DPDPA / GDPR)',
    category: 'data_protection',
    jurisdiction: 'India DPDPA 2023 / EU GDPR / Global',
    description: 'Defines Data Controller/Fiduciary and Data Processor obligations, lawful processing instructions, sub-processor rules, technical safeguards, and statutory breach notifications.',
    explanation: 'Mandatory statutory requirement under India DPDPA 2023 Section 8, GDPR Article 28, and CCPA to prevent massive regulatory fines and civil liability.',
    marketStandard: 'Customer is the Data Fiduciary/Controller and Provider is the Data Processor. Provider shall: (a) process Personal Data solely in accordance with Customer\'s documented instructions; (b) ensure personnel authorized to process data are under binding confidentiality; (c) implement technical and organizational security measures matching ISO 27001 / SOC 2 Type II; (d) notify Customer in writing within twenty-four (24) to forty-eight (48) hours of becoming aware of any confirmed Personal Data breach; (e) not engage sub-processors without prior written notification and authorization; and (f) assist Customer in fulfilling Data Principal / Subject rights requests and statutory compliance under the Indian Digital Personal Data Protection Act, 2023 (DPDPA) and EU GDPR.',
    standardWording: 'Customer is the Data Fiduciary/Controller and Provider is the Data Processor. Provider shall: (a) process Personal Data solely in accordance with Customer\'s documented instructions; (b) ensure personnel authorized to process data are under binding confidentiality; (c) implement technical and organizational security measures matching ISO 27001 / SOC 2 Type II; (d) notify Customer in writing within twenty-four (24) to forty-eight (48) hours of becoming aware of any confirmed Personal Data breach; (e) not engage sub-processors without prior written notification and authorization; and (f) assist Customer in fulfilling Data Principal / Subject rights requests and statutory compliance under the Indian Digital Personal Data Protection Act, 2023 (DPDPA) and EU GDPR.',
    companyFriendly: 'Provider acts as independent contractor; notification of confirmed breach within 72 hours; sub-processor list published online with 10-day objection window.',
    companyFriendlyWording: 'Provider acts as independent contractor; notification of confirmed breach within 72 hours; sub-processor list published online with 10-day objection window.',
    counterpartyFriendly: 'Provider indemnifies Customer for all regulatory penalties, legal fees, and mitigation expenses resulting from Provider\'s breach of DPDPA 2023 or GDPR; 24-hour breach notification.',
    counterpartyFriendlyWording: 'Provider indemnifies Customer for all regulatory penalties, legal fees, and mitigation expenses resulting from Provider\'s breach of DPDPA 2023 or GDPR; 24-hour breach notification.',
    recommendedCompromise: 'Standard Controller-to-Processor DPA, 48-hour incident notification, mutual assistance on data subject requests, and standard audit assistance.',
    fallbackWording: 'Standard Controller-to-Processor DPA, 48-hour incident notification, mutual assistance on data subject requests.',
    benchmarkRange: '24 to 72 hour breach notification; full Controller-Processor terms.',
    industryBenchmarkRange: '24 to 72 hour breach notification; full Controller-Processor terms.',
    riskLevel: 'critical',
    legalSource: 'India DPDPA 2023 § 8; EU GDPR Art. 28; California CPRA § 1798.140',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'India': 'Mandatory Data Fiduciary & Data Processor written agreement under DPDPA 2023; CERT-In 6-hour reporting.',
      'European Union': 'GDPR Article 28(3) mandatory clauses; Standard Contractual Clauses (SCCs) for cross-border data transfers.',
      'United States': 'CCPA/CPRA Service Provider certification prohibiting sale, sharing, or retention outside direct service scope.'
    }
  },

  // 5. Information Security & Cybersecurity
  {
    id: 'clause-sec-05',
    name: 'Information Security & Cybersecurity Vulnerability Assessment',
    clauseName: 'Information Security & Cybersecurity Vulnerability Assessment',
    category: 'cybersecurity',
    jurisdiction: 'Global / Enterprise Infrastructure',
    description: 'Mandates strict cybersecurity controls including annual SOC 2 Type II / ISO 27001 audits, regular vulnerability assessments, automated penetration testing, and AES-256 encryption.',
    explanation: 'Crucial for technology agreements involving cloud environments, vulnerability assessments, API integrations, and proprietary software engineering.',
    marketStandard: 'Provider shall maintain a comprehensive written Information Security Program complying with ISO/IEC 27001 and SOC 2 Type II standards. Security safeguards must include: (a) AES-256 encryption for all Customer Data at rest and TLS 1.3 encryption in transit; (b) multi-factor authentication (MFA) and role-based access control (RBAC); (c) quarterly external vulnerability assessments and annual third-party penetration testing with prompt remediation of Critical/High findings within 14 days; (d) continuous security logging and monitoring retained for at least 180 days; and (e) documented incident response and disaster recovery procedures.',
    standardWording: 'Provider shall maintain a comprehensive written Information Security Program complying with ISO/IEC 27001 and SOC 2 Type II standards. Security safeguards must include: (a) AES-256 encryption for all Customer Data at rest and TLS 1.3 encryption in transit; (b) multi-factor authentication (MFA) and role-based access control (RBAC); (c) quarterly external vulnerability assessments and annual third-party penetration testing with prompt remediation of Critical/High findings within 14 days; (d) continuous security logging and monitoring retained for at least 180 days; and (e) documented incident response and disaster recovery procedures.',
    companyFriendly: 'Provider maintains commercially reasonable administrative and physical security controls; penetration testing summaries provided upon request under NDA once per year.',
    companyFriendlyWording: 'Provider maintains commercially reasonable administrative and physical security controls; penetration testing summaries provided upon request under NDA once per year.',
    counterpartyFriendly: 'Customer reserves right to perform independent annual penetration tests on Provider infrastructure; Provider warrants zero unpatched Critical vulnerabilities and provides SOC 2 Type II reports annually.',
    counterpartyFriendlyWording: 'Customer reserves right to perform independent annual penetration tests on Provider infrastructure; Provider warrants zero unpatched Critical vulnerabilities.',
    recommendedCompromise: 'Annual third-party SOC 2 Type II and pen test executive summaries provided under NDA; 30-day remediation SLA for high-severity vulnerabilities.',
    fallbackWording: 'Annual third-party SOC 2 Type II and pen test executive summaries provided under NDA; 30-day remediation SLA for high-severity vulnerabilities.',
    benchmarkRange: 'ISO 27001 / SOC 2 Type II compliance; AES-256 encryption.',
    industryBenchmarkRange: 'ISO 27001 / SOC 2 Type II compliance; AES-256 encryption.',
    riskLevel: 'critical',
    legalSource: 'NIST Cybersecurity Framework 2.0; ISO/IEC 27001:2022; SOC 2 Trust Services Criteria',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'NIST SP 800-53 / SOC 2 Type II standard across enterprise tech.',
      'India': 'CERT-In cybersecurity directions and RBI cybersecurity framework for financial counterparties.',
      'European Union': 'NIS2 Directive (Directive 2022/2555) and DORA for financial entity suppliers.'
    }
  },

  // 6. Substantive Indemnification
  {
    id: 'clause-indem-06',
    name: 'Substantive Mutual Indemnification & Defense Obligations',
    clauseName: 'Substantive Mutual Indemnification & Defense Obligations',
    category: 'liability',
    jurisdiction: 'Global / Enterprise Commercial',
    description: 'Establishes substantive defense, hold harmless, and indemnification obligations for third-party IP infringement, confidentiality breaches, gross negligence, and data security breaches.',
    explanation: 'Solves the critical drafting defect where liability clauses cross-reference an indemnity that was omitted from the substantive text of the agreement.',
    marketStandard: '6.1 Provider Indemnity: Provider shall defend, indemnify, and hold harmless Customer, its affiliates, directors, officers, and employees from and against any third-party claims, liabilities, damages, judgments, and reasonable legal costs arising out of: (a) actual or alleged infringement of any patent, copyright, trademark, or trade secret by the Services or Deliverables; (b) Provider\'s gross negligence or willful misconduct; or (c) material breach of data protection or confidentiality obligations.\n6.2 Customer Indemnity: Customer shall defend and indemnify Provider against third-party claims arising from Customer Data infringing third-party rights or Customer\'s unlawful use of the Services.\n6.3 Indemnification Procedures: The indemnified party must: (i) promptly provide written notice of the claim; (ii) grant the indemnifying party sole control over defense and settlement (provided no settlement admits liability or imposes financial obligations without consent); and (iii) provide reasonable cooperation.',
    standardWording: '6.1 Provider Indemnity: Provider shall defend, indemnify, and hold harmless Customer, its affiliates, directors, officers, and employees from and against any third-party claims, liabilities, damages, judgments, and reasonable legal costs arising out of: (a) actual or alleged infringement of any patent, copyright, trademark, or trade secret by the Services or Deliverables; (b) Provider\'s gross negligence or willful misconduct; or (c) material breach of data protection or confidentiality obligations.\n6.2 Customer Indemnity: Customer shall defend and indemnify Provider against third-party claims arising from Customer Data infringing third-party rights or Customer\'s unlawful use of the Services.\n6.3 Indemnification Procedures: The indemnified party must: (i) promptly provide written notice of the claim; (ii) grant the indemnifying party sole control over defense and settlement; and (iii) provide reasonable cooperation.',
    companyFriendly: 'Indemnity limited strictly to final judicial awards for direct IP infringement, conditional upon prompt notice within 10 days and exclusive control of defense.',
    companyFriendlyWording: 'Indemnity limited strictly to final judicial awards for direct IP infringement, conditional upon prompt notice within 10 days and exclusive control of defense.',
    counterpartyFriendly: 'Broad uncapped indemnity covering all third-party claims, regulatory investigations, fines, data breaches, and attorney fees, with no defense control restrictions.',
    counterpartyFriendlyWording: 'Broad uncapped indemnity covering all third-party claims, regulatory investigations, fines, data breaches, and attorney fees.',
    recommendedCompromise: 'Mutual indemnity covering IP infringement, gross negligence, and breach of confidentiality, structured with standard procedural safeguards and carve-outs.',
    fallbackWording: 'Mutual indemnity covering IP infringement, gross negligence, and breach of confidentiality with standard procedural safeguards.',
    benchmarkRange: 'Uncapped IP indemnity with procedural defense control and standard carve-outs.',
    industryBenchmarkRange: 'Uncapped IP indemnity with procedural defense control and standard carve-outs.',
    riskLevel: 'critical',
    legalSource: 'Restatement (Second) of Contracts § 356; 6 Del. C. § 2-719; Indian Contract Act § 124',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Express duty to defend separate from duty to indemnify is strictly construed under Delaware/NY law.',
      'India': 'Section 124 of Indian Contract Act 1872 governs contracts of indemnity.'
    }
  },

  // 7. Representations & Warranties
  {
    id: 'clause-war-07',
    name: 'Comprehensive Representations & Warranties',
    clauseName: 'Comprehensive Representations & Warranties',
    category: 'warranties',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Express warranties assuring corporate authority, professional workmanlike performance, non-infringement, software free from malicious code/viruses, and full statutory compliance.',
    explanation: 'Ensures the counterparty guarantees quality, legality, and safety beyond mere organizational authority recitals.',
    marketStandard: '7.1 Mutual Warranties: Each party represents and warrants that: (a) it is duly organized, validly existing, and in good standing; (b) it has full corporate power and authority to enter into and perform this Agreement; and (c) execution does not violate any other contractual or legal obligation.\n7.2 Service Provider Warranties: Provider represents and warrants that: (i) Services shall be performed in a professional, workmanlike manner conforming to highest industry standards by qualified personnel; (ii) Deliverables and Services shall substantially conform to the specifications set forth in the applicable SOW for ninety (90) days following acceptance; (iii) Deliverables and Work Product do not and will not infringe any third-party intellectual property or proprietary rights; and (iv) Services and Deliverables do not contain any malware, viruses, worms, Trojan horses, or unauthorized backdoors designed to disrupt or disable Customer systems.',
    standardWording: '7.1 Mutual Warranties: Each party represents and warrants that: (a) it is duly organized, validly existing, and in good standing; (b) it has full corporate power and authority to enter into and perform this Agreement; and (c) execution does not violate any other contractual or legal obligation.\n7.2 Service Provider Warranties: Provider represents and warrants that: (i) Services shall be performed in a professional, workmanlike manner conforming to highest industry standards; (ii) Deliverables shall conform to SOW specifications for 90 days following acceptance; (iii) Work Product does not infringe third-party IP; and (iv) software contains no malware, viruses, or disabling code.',
    companyFriendly: '30-day warranty period from delivery; sole remedy for breach of warranty is re-performance of non-conforming services at Provider\'s expense.',
    companyFriendlyWording: '30-day warranty period from delivery; sole remedy for breach of warranty is re-performance of non-conforming services at Provider\'s expense.',
    counterpartyFriendly: '12-month warranty with immediate repair, replacement, or full refund at Customer\'s sole election, plus uncapped damages for malware or non-infringement breach.',
    counterpartyFriendlyWording: '12-month warranty with immediate repair, replacement, or full refund, plus uncapped damages for malware or non-infringement breach.',
    recommendedCompromise: '90-day warranty on deliverables, standard professional services warranty, re-performance or refund remedy, and express warranty against malicious code.',
    fallbackWording: '90-day warranty on deliverables, standard professional services warranty, re-performance or refund remedy.',
    benchmarkRange: '90-day warranty period on deliverables; perpetual warranty of authority and non-infringement.',
    industryBenchmarkRange: '90-day warranty period on deliverables; perpetual warranty of authority and non-infringement.',
    riskLevel: 'critical',
    legalSource: 'UCC § 2-313 (Express Warranties) & § 2-316; English Supply of Goods and Services Act 1982',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'UCC express warranty rules; conspicuous disclaimer of implied warranties (merchantability/fitness).',
      'India': 'Sale of Goods Act 1930 / Indian Contract Act 1872 warranty doctrines.'
    }
  },

  // 8. Termination Consequences & Exit Management
  {
    id: 'clause-term-08',
    name: 'Termination Consequences & Disentanglement Exit Management',
    clauseName: 'Termination Consequences & Disentanglement Exit Management',
    category: 'term_termination',
    jurisdiction: 'Global / Enterprise IT & Cloud',
    description: 'Defines orderly post-termination disentanglement, transition assistance for up to 90 days, pro-rata refund of unearned fees, immediate payment of undisputed amounts, and return/destruction of data.',
    explanation: 'Prevents operational chaos, vendor lock-in, and dispute over transition costs when an agreement ends or is terminated for convenience/cause.',
    marketStandard: 'Upon expiration or termination of this Agreement for any reason: (a) Provider shall immediately cease all performance under terminated SOWs; (b) Customer shall pay Provider for all undisputed Services properly performed up to the effective termination date; (c) Provider shall promptly refund to Customer all unearned prepaid fees on a pro-rata basis; (d) each party shall immediately return or securely destroy all Confidential Information of the other party; (e) Provider shall provide Customer with full data export in standard format within thirty (30) days; and (f) upon Customer\'s request, Provider shall provide transition and disentanglement assistance for up to ninety (90) days at Provider\'s then-current standard rates or agreed commercial rates.',
    standardWording: 'Upon expiration or termination of this Agreement for any reason: (a) Provider shall immediately cease all performance under terminated SOWs; (b) Customer shall pay Provider for all undisputed Services properly performed up to the effective termination date; (c) Provider shall promptly refund to Customer all unearned prepaid fees on a pro-rata basis; (d) each party shall immediately return or securely destroy all Confidential Information of the other party; (e) Provider shall provide Customer with full data export in standard format within thirty (30) days; and (f) upon Customer\'s request, Provider shall provide transition and disentanglement assistance for up to ninety (90) days at agreed commercial rates.',
    companyFriendly: 'Immediate cessation of services; all unpaid fees become immediately due; transition services subject to separate SOW with advance fee payment.',
    companyFriendlyWording: 'Immediate cessation of services; all unpaid fees become immediately due; transition services subject to separate SOW with advance fee payment.',
    counterpartyFriendly: 'Mandatory 120-day transition period at fixed rates; Provider must transfer all project knowledge, code repos, and assist incoming replacement vendor without delay.',
    counterpartyFriendlyWording: 'Mandatory 120-day transition period at fixed rates; Provider must transfer all project knowledge, code repos, and assist incoming replacement vendor.',
    recommendedCompromise: '60-90 days transition assistance at agreed commercial rates, pro-rata refund of prepaid fees for unperformed services, 30-day data return window.',
    fallbackWording: '60-90 days transition assistance at agreed commercial rates, pro-rata refund of prepaid fees for unperformed services, 30-day data return window.',
    benchmarkRange: '30-90 days transition assistance window; 30-day data return.',
    industryBenchmarkRange: '30-90 days transition assistance window; 30-day data return.',
    riskLevel: 'critical',
    legalSource: 'Enterprise ITIL Exit Management Framework; Common Law Contract Doctrine',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Enforceable transition and data return covenants; explicit restitution rules.',
      'India': 'Section 65 Indian Contract Act (obligation of person who has received advantage under void or terminated agreement).'
    }
  },

  // 9. Business Continuity / Disaster Recovery (BCP/DR)
  {
    id: 'clause-bcp-09',
    name: 'Business Continuity & Disaster Recovery (BCP/DR)',
    clauseName: 'Business Continuity & Disaster Recovery (BCP/DR)',
    category: 'bcp_dr',
    jurisdiction: 'Global / Cloud Infrastructure',
    description: 'Mandates comprehensive business continuity and disaster recovery plans, Recovery Time Objective (RTO <= 4 hours), Recovery Point Objective (RPO <= 1 hour), geographically distributed redundancy, and annual simulation tests.',
    explanation: 'Protects against business disruption caused by data center outages, power failures, regional disasters, or infrastructure meltdowns.',
    marketStandard: 'Provider shall maintain, implement, and regularly test a formal Business Continuity and Disaster Recovery (BCP/DR) Plan designed to ensure uninterrupted operation and rapid recovery of Services. The BCP/DR Plan shall ensure: (a) Recovery Time Objective (RTO) of not more than four (4) hours; (b) Recovery Point Objective (RPO) of not more than one (1) hour; (c) automated daily data backups replicated across geographically separate tier-3 data centers; (d) annual full-scale DR simulation drills; and (e) executive summary of DR test results provided to Customer upon request.',
    standardWording: 'Provider shall maintain, implement, and regularly test a formal Business Continuity and Disaster Recovery (BCP/DR) Plan designed to ensure uninterrupted operation and rapid recovery of Services. The BCP/DR Plan shall ensure: (a) Recovery Time Objective (RTO) of not more than four (4) hours; (b) Recovery Point Objective (RPO) of not more than one (1) hour; (c) automated daily data backups replicated across geographically separate tier-3 data centers; (d) annual full-scale DR simulation drills; and (e) executive summary of DR test results provided to Customer upon request.',
    companyFriendly: 'Provider maintains standard industry disaster recovery plans with RTO of 24 hours and RPO of 12 hours.',
    companyFriendlyWording: 'Provider maintains standard industry disaster recovery plans with RTO of 24 hours and RPO of 12 hours.',
    counterpartyFriendly: 'RTO of 2 hours, RPO of 15 minutes, semi-annual third-party audited DR drills, and Customer right to participate in DR tabletop testing.',
    counterpartyFriendlyWording: 'RTO of 2 hours, RPO of 15 minutes, semi-annual third-party audited DR drills, and Customer right to participate in DR tabletop testing.',
    recommendedCompromise: 'RTO of 4 hours, RPO of 1 hour, annual DR testing with executive summary shared upon request.',
    fallbackWording: 'RTO of 4 hours, RPO of 1 hour, annual DR testing with executive summary shared upon request.',
    benchmarkRange: 'RTO 2-8 hours; RPO 1-4 hours for tier-1 cloud and technology services.',
    industryBenchmarkRange: 'RTO 2-8 hours; RPO 1-4 hours for tier-1 cloud and technology services.',
    riskLevel: 'critical',
    legalSource: 'ISO 22301:2019 (Security and Resilience - Business Continuity Management Systems)',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard FFIEC / SOC 2 BCP/DR requirements for enterprise cloud suppliers.',
      'European Union': 'Digital Operational Resilience Act (DORA) ICT business continuity requirements for EU critical suppliers.'
    }
  },

  // 10. Data Ownership & Data Return / Deletion
  {
    id: 'clause-dataown-10',
    name: 'Customer Data Ownership, Portability & Certified Deletion',
    clauseName: 'Customer Data Ownership, Portability & Certified Deletion',
    category: 'ip',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Explicitly establishes that Customer retains 100% sole and exclusive ownership and intellectual property in all Customer Data, with 30-day export window and certified permanent deletion.',
    explanation: 'Eliminates any vendor assertion of proprietary rights, data hoarding, or commercial lock-in over customer files, logs, and database records.',
    marketStandard: 'Customer retains sole and exclusive ownership of all right, title, and interest (including all intellectual property rights) in and to all Customer Data. Provider acquires no rights in Customer Data other than the limited, non-exclusive right to host, cache, and process Customer Data solely as necessary to deliver the Services under this Agreement. Within thirty (30) days of contract expiration or termination, Provider shall make all Customer Data available for export in standard, machine-readable format (e.g. JSON, CSV, SQL dump), and upon Customer\'s written confirmation of receipt, permanently and securely erase all Customer Data from Provider\'s active and backup systems, providing written certificate of destruction.',
    standardWording: 'Customer retains sole and exclusive ownership of all right, title, and interest in and to all Customer Data. Provider acquires no rights in Customer Data other than the limited right to process data solely to deliver Services. Within 30 days of termination, Provider shall provide full data export in standard machine-readable format and securely erase all Customer Data from systems, providing written certificate of destruction.',
    companyFriendly: 'Customer owns raw data; Provider retains ownership of aggregated, anonymized metadata and telemetry metrics for system enhancement.',
    companyFriendlyWording: 'Customer owns raw data; Provider retains ownership of aggregated, anonymized metadata and telemetry metrics for system enhancement.',
    counterpartyFriendly: 'Complete customer ownership of all data, derivative datasets, models trained on customer data, with immediate export and DOD 5220.22-M certified cryptographic destruction.',
    counterpartyFriendlyWording: 'Complete customer ownership of all data, derivative datasets, and models, with immediate export and certified cryptographic destruction.',
    recommendedCompromise: 'Customer retains 100% ownership of Customer Data; Provider permitted only to use de-identified, aggregated benchmark telemetry that cannot identify Customer.',
    fallbackWording: 'Customer retains 100% ownership of Customer Data; Provider permitted only to use de-identified, aggregated benchmark telemetry.',
    benchmarkRange: '100% customer ownership standard across enterprise agreements.',
    industryBenchmarkRange: '100% customer ownership standard across enterprise agreements.',
    riskLevel: 'high',
    legalSource: 'Trade Secrets Law; India DPDPA 2023 § 8(7); GDPR Art. 28(3)(g)',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Clear title retention; protection against trade secret claims and vendor liens.',
      'India': 'DPDPA 2023 statutory mandate to erase personal data upon withdrawal of consent or purpose completion.'
    }
  },

  // 11. Subcontracting
  {
    id: 'clause-subcon-11',
    name: 'Subcontracting & Third-Party Vendor Management',
    clauseName: 'Subcontracting & Third-Party Vendor Management',
    category: 'operations',
    jurisdiction: 'Global / Enterprise Commercial',
    description: 'Controls vendor engagement of sub-contractors, requiring prior written consent, flow-down of confidentiality/security obligations, and full primary liability.',
    explanation: 'Prevents stealth outsourcing to unvetted, insecure third parties while ensuring accountability rests solely with the primary vendor.',
    marketStandard: 'Provider shall not subcontract any portion of the Services without Customer\'s prior written consent (such consent not to be unreasonably withheld). For all approved subcontractors, Provider shall: (a) ensure each subcontractor enters into written agreements with confidentiality, security, and IP terms at least as stringent as those in this Agreement; and (b) remain fully, directly, and unconditionally responsible and liable to Customer for all acts, omissions, defaults, and breaches of any subcontractor as if performed by Provider itself.',
    standardWording: 'Provider shall not subcontract any portion of the Services without Customer\'s prior written consent. For all approved subcontractors, Provider shall: (a) bind subcontractors to written confidentiality, security, and IP terms at least as stringent as this Agreement; and (b) remain fully and directly liable to Customer for all subcontractor acts and omissions.',
    companyFriendly: 'Provider may engage qualified subcontractors and cloud infrastructure affiliates without prior consent, remaining liable for their performance.',
    companyFriendlyWording: 'Provider may engage qualified subcontractors and cloud infrastructure affiliates without prior consent, remaining liable for their performance.',
    counterpartyFriendly: 'Strict prohibition on subcontracting without 30-day advance written notice and right of veto; Customer must approve every individual contractor resume.',
    counterpartyFriendlyWording: 'Strict prohibition on subcontracting without 30-day advance written notice and right of veto.',
    recommendedCompromise: 'Pre-approved cloud infrastructure vendors (e.g. AWS, GCP, Azure); written consent required for custom engineering or personnel subcontractors; 100% vendor liability.',
    fallbackWording: 'Pre-approved cloud infrastructure vendors; written consent required for custom engineering subcontractors; 100% vendor liability.',
    benchmarkRange: 'Prior written notice or consent required; primary contractor retains 100% vicarious liability.',
    industryBenchmarkRange: 'Prior written notice or consent required; primary contractor retains 100% vicarious liability.',
    riskLevel: 'high',
    legalSource: 'Restatement (Second) of Agency § 406; Common Law Vicarious Liability',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard flow-down and non-delegable duty provisions.',
      'India': 'Section 190 Indian Contract Act (sub-agent delegation doctrine).'
    }
  },

  // 12. Assignment
  {
    id: 'clause-assign-12',
    name: 'Assignment & Corporate Restructuring Restrictions',
    clauseName: 'Assignment & Corporate Restructuring Restrictions',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Restricts either party from transferring or assigning the contract without written consent, while providing standard carve-outs for M&A and corporate reorganizations.',
    explanation: 'Ensures you do not end up under contract with a direct competitor or insolvent successor without your consent.',
    marketStandard: 'Neither party may assign, delegate, or transfer this Agreement or any rights or obligations hereunder, in whole or in part, without the prior written consent of the other party (not to be unreasonably withheld or delayed). Notwithstanding the foregoing, either party may assign this Agreement without consent to an affiliate or to a successor entity in connection with a merger, acquisition, corporate reorganization, or sale of substantially all of its assets, provided the assignee assumes all obligations in writing and is not a direct commercial competitor of the non-assigning party.',
    standardWording: 'Neither party may assign or transfer this Agreement without prior written consent, except to an affiliate or successor in connection with a merger, acquisition, or sale of substantially all assets, provided the assignee assumes all obligations in writing and is not a direct competitor.',
    companyFriendly: 'Company may freely assign this Agreement to any affiliate or successor without notice or consent; Counterparty assignment strictly prohibited without express approval.',
    companyFriendlyWording: 'Company may freely assign this Agreement to any affiliate or successor without notice or consent; Counterparty assignment strictly prohibited without express approval.',
    counterpartyFriendly: 'Strict bilateral prohibition on assignment under any circumstances without prior written consent, including in change of control or asset sales.',
    counterpartyFriendlyWording: 'Strict bilateral prohibition on assignment under any circumstances without prior written consent.',
    recommendedCompromise: 'Mutual prohibition on assignment with standard M&A/merger carve-out, subject to competitor restriction and written assumption of liabilities.',
    fallbackWording: 'Mutual prohibition on assignment with standard M&A carve-out, subject to competitor restriction.',
    benchmarkRange: 'Mutual restriction with standard M&A/affiliate carve-out.',
    industryBenchmarkRange: 'Mutual restriction with standard M&A/affiliate carve-out.',
    riskLevel: 'high',
    legalSource: 'UCC § 2-210 (Delegation of Performance; Assignment of Rights); English Law of Property Act 1925',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard M&A carve-out to preserve business transaction flexibility.',
      'India': 'Section 37 Indian Contract Act (assignment of contractual liabilities vs benefits).'
    }
  },

  // 13. Force Majeure
  {
    id: 'clause-force-13',
    name: 'Force Majeure & Excusable Delays',
    clauseName: 'Force Majeure & Excusable Delays',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Excuses performance delays caused by events beyond reasonable control (natural disasters, war, pandemic, utility grid failure), requiring prompt notice and termination rights after 30 days.',
    explanation: 'Protects parties from breach claims during catastrophic events while establishing strict boundaries so commercial non-performance is not excused indefinitely.',
    marketStandard: 'Neither party shall be liable for any failure or delay in performing its obligations under this Agreement (other than payment of accrued fees) to the extent such failure or delay is caused by a Force Majeure Event beyond its reasonable control, including acts of God, flood, fire, earthquake, war, terrorism, civil unrest, epidemic or pandemic, governmental order, or major public utility/telecom outage. The affected party must: (a) provide prompt written notice within five (5) business days; (b) exercise commercially reasonable efforts to mitigate and resume performance; and (c) if the Force Majeure Event continues for more than thirty (30) consecutive days, the non-affected party may terminate this Agreement immediately upon written notice without penalty.',
    standardWording: 'Neither party shall be liable for delay or failure caused by a Force Majeure Event beyond reasonable control (excluding payment obligations). The affected party must provide notice within 5 business days, mitigate delay, and if disruption exceeds 30 consecutive days, the other party may terminate upon written notice.',
    companyFriendly: 'Broad definition of force majeure including third-party cloud outages and labor strikes; no termination right for customer until 90 days of continuous interruption.',
    companyFriendlyWording: 'Broad definition of force majeure including third-party cloud outages; no termination right for customer until 90 days of continuous interruption.',
    counterpartyFriendly: 'Excludes vendor cloud provider failures and cyber incidents from force majeure; customer may terminate after 14 days of disruption with full refund of advance fees.',
    counterpartyFriendlyWording: 'Excludes cloud provider failures and cyber incidents; customer may terminate after 14 days with full refund of advance fees.',
    recommendedCompromise: 'Standard force majeure excluding payment obligations, 5-day notice, 30-day termination trigger, and requirement that cybersecurity failures are not force majeure if security standards were breached.',
    fallbackWording: 'Standard force majeure excluding payment obligations, 5-day notice, 30-day termination trigger.',
    benchmarkRange: '30 to 60 days continuous delay trigger for termination.',
    industryBenchmarkRange: '30 to 60 days continuous delay trigger for termination.',
    riskLevel: 'high',
    legalSource: 'Restatement (Second) of Contracts § 261 (Impossibility); Indian Contract Act § 56 (Frustration)',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Common law requires express force majeure clause as doctrine of impossibility is narrow.',
      'India': 'Section 56 Indian Contract Act (Doctrine of Frustration) applied strictly by Supreme Court.'
    }
  },

  // 14. Compliance with Laws
  {
    id: 'clause-compl-14',
    name: 'Broad Compliance with Laws & Regulatory Standards',
    clauseName: 'Broad Compliance with Laws & Regulatory Standards',
    category: 'governance',
    jurisdiction: 'Global / Enterprise Commercial',
    description: 'Requires both parties to comply with all applicable local, national, and international laws, labor regulations, environmental standards, and industry rules.',
    explanation: 'Establishes a baseline standard that neither party will engage in unlawful conduct that creates regulatory exposure or reputational taint.',
    marketStandard: 'Each party shall, at its own expense, comply with all applicable local, state, national, and international laws, rules, statutes, and governmental regulations applicable to its business, performance of this Agreement, and provision or receipt of the Services, including but not limited to labor and employment laws, occupational health and safety standards, environmental regulations, data privacy legislation, and industry regulatory frameworks.',
    standardWording: 'Each party shall comply with all applicable local, state, national, and international laws, rules, and regulations applicable to its business and performance under this Agreement, including employment, data privacy, environmental, and industry regulations.',
    companyFriendly: 'Each party complies with laws directly applicable to its own business operations.',
    companyFriendlyWording: 'Each party complies with laws directly applicable to its own business operations.',
    counterpartyFriendly: 'Provider warrants continuous compliance with all current and future industry regulations, codes of practice, and customer internal vendor compliance codes.',
    counterpartyFriendlyWording: 'Provider warrants continuous compliance with all current and future industry regulations, codes of practice, and customer vendor codes.',
    recommendedCompromise: 'Mutual representation of compliance with all applicable laws governing respective performance under the contract.',
    fallbackWording: 'Mutual representation of compliance with all applicable laws governing respective performance.',
    benchmarkRange: 'Standard universal boilerplate present in 99% of enterprise contracts.',
    industryBenchmarkRange: 'Standard universal boilerplate present in 99% of enterprise contracts.',
    riskLevel: 'high',
    legalSource: 'General Commercial Law Principles',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard comprehensive compliance representation.',
      'India': 'Specific reference to statutory compliance (Shops & Establishments, PF, ESI, GST).'
    }
  },

  // 15. Anti-Bribery / Anti-Corruption
  {
    id: 'clause-brib-15',
    name: 'Anti-Bribery & Anti-Corruption (FCPA / UKBA / PCA)',
    clauseName: 'Anti-Bribery & Anti-Corruption (FCPA / UKBA / PCA)',
    category: 'governance',
    jurisdiction: 'Global / FCPA / UKBA / India PCA 1988',
    description: 'Mandates strict compliance with international anti-bribery statutes (US FCPA, UK Bribery Act 2010, Indian Prevention of Corruption Act 1988), prohibiting bribes, kickbacks, and facilitation payments.',
    explanation: 'Essential for enterprise and cross-border commercial relationships to prevent catastrophic criminal penalties and disqualification.',
    marketStandard: 'Each party represents, warrants, and covenants that: (a) it has not and will not directly or indirectly offer, promise, give, authorize, or accept any bribe, kickback, improper payment, or unlawful gift to or from any public official, corporate entity, or individual; and (b) it complies and will comply in all respects with all applicable anti-corruption and anti-bribery legislation, including the US Foreign Corrupt Practices Act (FCPA), the UK Bribery Act 2010, and the Indian Prevention of Corruption Act, 1988. Any breach of this clause constitutes a non-curable material breach entitling immediate termination for cause.',
    standardWording: 'Each party warrants that it complies with all anti-corruption laws including the US FCPA, UK Bribery Act 2010, and Indian Prevention of Corruption Act 1988, and shall not offer, give, or accept any bribe, kickback, or unlawful financial advantage. Breach entitles immediate termination.',
    companyFriendly: 'Mutual standard anti-bribery warranty with knowledge qualification.',
    companyFriendlyWording: 'Mutual standard anti-bribery warranty with knowledge qualification.',
    counterpartyFriendly: 'Extensive anti-corruption warranty with right to audit vendor books, compliance training records, and immediate uncapped indemnity for regulatory investigations.',
    counterpartyFriendlyWording: 'Extensive anti-corruption warranty with audit rights over compliance records and uncapped indemnity for regulatory investigations.',
    recommendedCompromise: 'Mutual anti-bribery warranty covering FCPA, UKBA, and local statutes, with immediate termination right for proven breach.',
    fallbackWording: 'Mutual anti-bribery warranty covering FCPA, UKBA, and local statutes with termination right for breach.',
    benchmarkRange: 'Standard zero-tolerance anti-corruption clause.',
    industryBenchmarkRange: 'Standard zero-tolerance anti-corruption clause.',
    riskLevel: 'high',
    legalSource: '15 U.S.C. § 78dd-1 (FCPA); UK Bribery Act 2010 c. 23; Indian Prevention of Corruption Act 1988',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'FCPA strict accounting and internal controls requirements.',
      'United Kingdom': 'UK Bribery Act 2010 Section 7 adequate procedures defense.',
      'India': 'Prevention of Corruption (Amendment) Act 2018 corporate criminal liability.'
    }
  },

  // 16. Sanctions & Export Controls
  {
    id: 'clause-sanct-16',
    name: 'Trade Sanctions & Export Control Compliance',
    clauseName: 'Trade Sanctions & Export Control Compliance',
    category: 'governance',
    jurisdiction: 'Global / OFAC / BIS / EU / UN',
    description: 'Ensures compliance with US OFAC, BIS, EU, UK, and UN export controls and economic sanctions, verifying no restricted parties are involved in AI or cloud technology transfer.',
    explanation: 'Crucial for cross-border software, AI models, cryptography, and cloud infrastructure services to prevent severe international trade sanctions penalties.',
    marketStandard: 'Each party represents and warrants that: (a) neither it, nor any of its subsidiaries, directors, officers, or employees, is identified on any trade sanctions or denied parties list, including the US OFAC Specially Designated Nationals (SDN) List, the US Bureau of Industry and Security (BIS) Entity List, or EU/UK consolidated sanctions lists; (b) it will not export, re-export, transfer, or provide access to any software, AI technology, technical data, or Deliverables in violation of applicable US, EU, UK, or local export control regulations; and (c) it will notify the other party immediately upon any change in sanctions status.',
    standardWording: 'Each party represents and warrants that neither it nor its affiliates are subject to US OFAC, EU, UK, or UN sanctions, and will not export or transfer software or technical data in violation of applicable export control laws.',
    companyFriendly: 'Standard mutual representation of non-sanctioned status.',
    companyFriendlyWording: 'Standard mutual representation of non-sanctioned status.',
    counterpartyFriendly: 'Broad export warranty with immediate indemnification for any export licensing violation or regulatory embargo impact.',
    counterpartyFriendlyWording: 'Broad export warranty with immediate indemnification for export licensing violations.',
    recommendedCompromise: 'Mutual sanctions warranty covering OFAC, EU, and UK regimes with immediate termination right if either party becomes a sanctioned entity.',
    fallbackWording: 'Mutual sanctions warranty covering OFAC, EU, and UK regimes with termination right if sanctioned.',
    benchmarkRange: 'Standard mandatory clause for all technology, cloud, and cross-border agreements.',
    industryBenchmarkRange: 'Standard mandatory clause for all technology, cloud, and cross-border agreements.',
    riskLevel: 'high',
    legalSource: '31 C.F.R. Chapter V (OFAC Regulations); 15 C.F.R. Parts 730-774 (EAR); Export Control Reform Act',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'US EAR and OFAC strict liability sanctions enforcement.',
      'European Union': 'EU Council Regulations on economic restrictive measures.',
      'United Kingdom': 'OFSI (Office of Financial Sanctions Implementation) regulations.'
    }
  },

  // 17. Insurance Requirements
  {
    id: 'clause-insur-17',
    name: 'Insurance Requirements (Cyber, CGL, E&O)',
    clauseName: 'Insurance Requirements (Cyber, CGL, E&O)',
    category: 'liability',
    jurisdiction: 'Global / Enterprise Commercial',
    description: 'Requires maintenance of comprehensive insurance policies including Commercial General Liability ($2M+), Cyber Risk / Network Security ($5M+), and Professional Liability / E&O ($2M+).',
    explanation: 'Ensures the counterparty possesses sufficient commercial insurance coverage to satisfy indemnification obligations and cover catastrophic cyber or operational claims.',
    marketStandard: 'During the term and for at least twelve (12) months thereafter, Provider shall maintain at its own cost with financially sound insurers rated A- or higher by A.M. Best: (a) Commercial General Liability insurance with limits not less than $2,000,000 per occurrence and $4,000,000 aggregate; (b) Cyber Risk, Network Security, and Privacy Liability insurance with limits not less than $5,000,000 per claim and aggregate; (c) Professional Liability / Errors & Omissions (E&O) insurance with limits not less than $2,000,000 per claim; and (d) Statutory Workers\' Compensation as required by law. Provider shall name Customer as an Additional Insured and provide Certificates of Insurance upon written request.',
    standardWording: 'Provider shall maintain during the term: (a) Commercial General Liability ($2,000,000 per occurrence); (b) Cyber & Privacy Risk ($5,000,000 aggregate); (c) Errors & Omissions ($2,000,000 per claim); and (d) Workers\' Compensation. Provider shall provide Certificates of Insurance upon request.',
    companyFriendly: 'Provider maintains standard commercial policies commensurate with business size; general limits of $1M CGL and $2M Cyber.',
    companyFriendlyWording: 'Provider maintains standard commercial policies commensurate with business size; general limits of $1M CGL and $2M Cyber.',
    counterpartyFriendly: '$10M Cyber/Privacy coverage, primary and non-contributory waiver of subrogation, 30-day advance notice of cancellation to Customer.',
    counterpartyFriendlyWording: '$10M Cyber/Privacy coverage, primary and non-contributory waiver of subrogation, 30-day advance notice of cancellation.',
    recommendedCompromise: '$2M CGL, $5M Cyber/Privacy, $2M E&O, with Certificates of Insurance delivered within 10 days of contract execution.',
    fallbackWording: '$2M CGL, $5M Cyber/Privacy, $2M E&O, with Certificates of Insurance delivered upon execution.',
    benchmarkRange: '$1M - $5M general liability; $2M - $10M cyber liability based on contract value.',
    industryBenchmarkRange: '$1M - $5M general liability; $2M - $10M cyber liability based on contract value.',
    riskLevel: 'high',
    legalSource: 'Standard Enterprise Risk Management Guidelines; Insurance Industry Practice',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard ACORD certificate of insurance format; additional insured endorsement.',
      'India': 'Public Liability Insurance Act 1991 and standard Commercial General Liability policies.'
    }
  },

  // 18. Audit Rights
  {
    id: 'clause-audit-18',
    name: 'Audit, Inspection & Security Verification Rights',
    clauseName: 'Audit, Inspection & Security Verification Rights',
    category: 'operations',
    jurisdiction: 'Global / Enterprise Commercial',
    description: 'Grants Customer and independent certified auditors the right to inspect vendor facilities, security logs, SOC reports, and compliance records upon 10 business days notice.',
    explanation: 'Vital for regulated industries, cybersecurity verification, and confirming billing accuracy without disrupting normal operations.',
    marketStandard: 'Upon at least ten (10) business days prior written notice, Customer (or its designated independent certified third-party auditor subject to customary confidentiality obligations) shall have the right to audit, inspect, and verify Provider\'s compliance with this Agreement, Information Security standards, and billing accuracy. Any such audit shall be conducted during normal business hours, not more than once per twelve (12) month period (unless triggered by a security incident or regulatory mandate), and in a manner that does not unreasonably disrupt operations. Provider shall provide reasonable cooperation and access to relevant compliance records, SOC 2 reports, and audit logs.',
    standardWording: 'Upon 10 business days prior written notice, Customer (or independent auditor under NDA) may audit Provider\'s compliance, security controls, and billing records once per year during normal business hours without disrupting operations.',
    companyFriendly: 'Audit satisfied solely by delivery of annual SOC 2 Type II audit report; on-site audits permitted only upon showing of material security breach at Customer\'s sole expense.',
    companyFriendlyWording: 'Audit satisfied solely by delivery of annual SOC 2 Type II audit report; on-site audits permitted only upon showing of material breach at Customer\'s expense.',
    counterpartyFriendly: 'Unlimited audit rights with 48h notice; full access to facilities, raw logs, sub-processor contracts, and personnel interviews; Provider pays audit cost if overcharge >3%.',
    counterpartyFriendlyWording: 'Unlimited audit rights with 48h notice; Provider pays audit cost if overcharge exceeds 3%.',
    recommendedCompromise: 'Annual audit with 10 business days notice; SOC 2 Type II and pen test summaries provided in first instance; on-site inspection permitted if material deficiency identified; Provider pays audit costs if billing discrepancy exceeds 5%.',
    fallbackWording: 'Annual audit with 10 business days notice; SOC 2 report delivered; on-site inspection permitted for material deficiency.',
    benchmarkRange: 'Once per year with 10-14 days advance written notice.',
    industryBenchmarkRange: 'Once per year with 10-14 days advance written notice.',
    riskLevel: 'high',
    legalSource: 'GDPR Art. 28(3)(h); SOC 2 Trust Services Principles; Sarbanes-Oxley Act § 404',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard SOX / SOC 2 audit verification terms.',
      'European Union': 'Mandatory GDPR Art. 28(3)(h) processor audit and inspection obligation.'
    }
  },

  // 19. Notices
  {
    id: 'clause-notice-19',
    name: 'Formal Notices & Electronic Communication Protocol',
    clauseName: 'Formal Notices & Electronic Communication Protocol',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Establishes clear, formal legal notice mechanisms (registered courier, confirmed email) and deemed receipt delivery timelines.',
    explanation: 'Eliminates arguments regarding whether a termination notice, breach notice, or legal demand was properly served.',
    marketStandard: 'All legal notices, requests, consents, and demands under this Agreement must be in writing and shall be deemed duly given: (a) upon personal delivery; (b) two (2) business days after dispatch by recognized overnight courier (e.g. FedEx, DHL) with tracking confirmation; or (c) on the date of transmission by electronic mail to the designated signatory email address, provided no delivery bounce-back is received and a confirmation copy is dispatched concurrently. Notices must be addressed to the respective party representatives identified in the signature block or as updated by written notice.',
    standardWording: 'All legal notices under this Agreement must be in writing and are deemed given upon personal delivery, 2 business days after dispatch by courier, or on transmission by email with confirmation to the designated contact addresses.',
    companyFriendly: 'Notices validly given via email to designated billing/admin email contact with automatic transmission receipt.',
    companyFriendlyWording: 'Notices validly given via email to designated contact with transmission receipt.',
    counterpartyFriendly: 'Notices must be delivered by certified registered post with return receipt requested; email notices ineffective for termination or breach claims.',
    counterpartyFriendlyWording: 'Notices must be delivered by certified registered post; email notices ineffective for termination.',
    recommendedCompromise: 'Written notice via tracked commercial courier or verified electronic mail with delivery confirmation.',
    fallbackWording: 'Written notice via tracked commercial courier or verified electronic mail.',
    benchmarkRange: '2 business days courier / instant verified email receipt standard.',
    industryBenchmarkRange: '2 business days courier / instant verified email receipt standard.',
    riskLevel: 'medium',
    legalSource: 'Civil Procedure Notice Doctrines; UETA & E-SIGN Notice Rules',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard courier and electronic notice recognition.',
      'India': 'Section 106 Transfer of Property Act principles and IT Act 2000 Section 13 (time and place of dispatch of electronic record).'
    }
  },

  // 20. Entire Agreement
  {
    id: 'clause-entire-20',
    name: 'Entire Agreement & Integration (Four Corners Doctrine)',
    clauseName: 'Entire Agreement & Integration (Four Corners Doctrine)',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Prevents reliance on prior oral promises, pitch decks, email exchanges, or draft negotiation terms, establishing the written contract as the complete and exclusive agreement.',
    explanation: 'Crucial for commercial certainty to prevent parties from asserting verbal representations made during sales meetings.',
    marketStandard: 'This Agreement, together with all executed Statements of Work (SOW), Service Level Agreements (SLA), Data Processing Agreements (DPA), and attached schedules, constitutes the entire and exclusive agreement between the parties with respect to the subject matter hereof, and supersedes all prior and contemporaneous agreements, proposals, representations, negotiations, and understandings, whether oral or written. Neither party has relied on any statement, representation, warranty, or covenant not expressly set forth in this Agreement.',
    standardWording: 'This Agreement, together with all SOWs, SLAs, DPAs, and schedules, constitutes the entire and exclusive agreement between the parties, superseding all prior oral or written agreements, negotiations, and representations.',
    companyFriendly: 'Standard integration clause with express non-reliance representation.',
    companyFriendlyWording: 'Standard integration clause with express non-reliance representation.',
    counterpartyFriendly: 'Standard integration clause preserving pre-existing non-disclosure agreements.',
    counterpartyFriendlyWording: 'Standard integration clause preserving pre-existing non-disclosure agreements.',
    recommendedCompromise: 'Standard four-corners integration clause superseding all prior negotiations while incorporating attached technical schedules and SOWs.',
    fallbackWording: 'Standard four-corners integration clause superseding all prior negotiations.',
    benchmarkRange: 'Universal boilerplate included in 100% of commercial contracts.',
    industryBenchmarkRange: 'Universal boilerplate included in 100% of commercial contracts.',
    riskLevel: 'medium',
    legalSource: 'Parol Evidence Rule; Restatement (Second) of Contracts § 209-216; UCC § 2-202',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Parol evidence rule strictly excludes extrinsic prior representations under Delaware/NY law.',
      'United Kingdom': 'Entire agreement clause precludes collateral warranties, subject to fraudulent misrepresentation carve-out.',
      'India': 'Sections 91 and 92 of Indian Evidence Act, 1872 (exclusion of oral evidence by documentary evidence).'
    }
  },

  // 21. Amendment
  {
    id: 'clause-amend-21',
    name: 'Amendment & Contract Modification Procedure',
    clauseName: 'Amendment & Contract Modification Procedure',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Requires all amendments and changes to be in writing and signed by authorized signatories, preventing accidental verbal or informal email modifications.',
    explanation: 'Protects the enterprise from unauthorized field changes agreed to over Slack or informal correspondence.',
    marketStandard: 'No amendment, modification, supplement, or waiver of any provision of this Agreement or any SOW shall be valid or binding unless set forth in a formal written instrument that specifically references this Agreement and is duly signed and executed by authorized executive representatives of both parties.',
    standardWording: 'No amendment, modification, or supplement to this Agreement shall be valid unless set forth in a written instrument specifically referencing this Agreement and signed by authorized representatives of both parties.',
    companyFriendly: 'Written amendment required; company may update standard online terms and acceptable use policies upon 30 days notice.',
    companyFriendlyWording: 'Written amendment required; company may update standard online terms upon 30 days notice.',
    counterpartyFriendly: 'Strict bilateral written instrument signed by C-level officers only; no unilateral online updates permitted.',
    counterpartyFriendlyWording: 'Strict bilateral written instrument signed by C-level officers only; no unilateral online updates.',
    recommendedCompromise: 'Bilateral written instrument signed by authorized corporate signatories for all contract modifications.',
    fallbackWording: 'Bilateral written instrument signed by authorized corporate signatories.',
    benchmarkRange: 'Mandatory standard written amendment rule.',
    industryBenchmarkRange: 'Mandatory standard written amendment rule.',
    riskLevel: 'medium',
    legalSource: 'UCC § 2-209 (Modification, Rescission and Waiver); English Law MWB v Rock Advertising [2018] UKSC 24',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'No-oral-modification clauses strictly enforced under UCC § 2-209 and Delaware law.',
      'United Kingdom': 'UK Supreme Court Rock Advertising precedent enforces no-oral-modification clauses strictly.'
    }
  },

  // 22. Waiver
  {
    id: 'clause-waive-22',
    name: 'Waiver & Cumulative Remedies',
    clauseName: 'Waiver & Cumulative Remedies',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Ensures that failure or delay in exercising a legal right does not waive that right, and confirms all contractual remedies are cumulative.',
    explanation: 'Prevents a party from claiming that because you did not immediately sue or penalize them on day 1 of a breach, you permanently forfeited your legal rights.',
    marketStandard: 'No failure, delay, or omission by either party in exercising any right, power, or remedy under this Agreement shall operate as a waiver thereof, nor shall any single or partial exercise of any right preclude any other or further exercise thereof or the exercise of any other right, power, or remedy. Any waiver must be in writing signed by the waiving party and shall be effective only in the specific instance and for the specific purpose given. All remedies provided herein are cumulative and not exclusive of any remedies provided by law or in equity.',
    standardWording: 'No failure or delay by either party in exercising any right shall operate as a waiver thereof. Waivers must be in writing. Remedies under this Agreement are cumulative and non-exclusive.',
    companyFriendly: 'Standard mutual non-waiver clause.',
    companyFriendlyWording: 'Standard mutual non-waiver clause.',
    counterpartyFriendly: 'Standard mutual non-waiver clause with express reservation of statutory equitable remedies.',
    counterpartyFriendlyWording: 'Standard mutual non-waiver clause with reservation of equitable remedies.',
    recommendedCompromise: 'Standard mutual non-waiver with cumulative remedies provision.',
    fallbackWording: 'Standard mutual non-waiver with cumulative remedies provision.',
    benchmarkRange: 'Universal boilerplate in 100% of commercial agreements.',
    industryBenchmarkRange: 'Universal boilerplate in 100% of commercial agreements.',
    riskLevel: 'medium',
    legalSource: 'Restatement (Second) of Contracts § 84; Common Law Equitable Doctrines',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard waiver and estoppel protection.',
      'India': 'Section 63 Indian Contract Act (promisee may dispense with or remit performance).'
    }
  },

  // 23. Severability
  {
    id: 'clause-sever-23',
    name: 'Severability & Judicial Reformation',
    clauseName: 'Severability & Judicial Reformation',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Protects the agreement if a specific provision is held invalid or illegal, directing the court to modify the clause to the minimum extent necessary while keeping the rest in effect.',
    explanation: 'Prevents the entire multi-million dollar contract from being struck down because one isolated clause is found partially unenforceable.',
    marketStandard: 'If any provision of this Agreement (or part thereof) is held to be invalid, illegal, or unenforceable by a court or arbitral tribunal of competent jurisdiction, such provision shall be severed or reformed to the minimum extent necessary to make it valid and enforceable while preserving the original commercial intent of the parties, and the remaining provisions of this Agreement shall remain in full force and effect.',
    standardWording: 'If any provision of this Agreement is held invalid, illegal, or unenforceable, such provision shall be modified to the minimum extent necessary, and the remaining provisions shall continue in full force and effect.',
    companyFriendly: 'Standard severability and reformation clause.',
    companyFriendlyWording: 'Standard severability and reformation clause.',
    counterpartyFriendly: 'Standard severability clause preserving core essential commercial terms.',
    counterpartyFriendlyWording: 'Standard severability clause preserving core essential commercial terms.',
    recommendedCompromise: 'Standard severability and blue-pencil reformation clause.',
    fallbackWording: 'Standard severability and blue-pencil reformation clause.',
    benchmarkRange: 'Universal boilerplate in 100% of commercial contracts.',
    industryBenchmarkRange: 'Universal boilerplate in 100% of commercial contracts.',
    riskLevel: 'medium',
    legalSource: 'Blue Pencil Doctrine; Restatement (Second) of Contracts § 184',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Blue pencil doctrine applied to modify overbroad restrictive covenants.',
      'India': 'Section 24 Indian Contract Act (agreements void if considerations and objects unlawful in part).'
    }
  },

  // 24. Survival
  {
    id: 'clause-surv-24',
    name: 'Survival of Core Post-Termination Obligations',
    clauseName: 'Survival of Core Post-Termination Obligations',
    category: 'term_termination',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Explicitly identifies key clauses that continue in full legal force after the contract ends (Definitions, Confidentiality, IP Ownership, Indemnification, Liability, Data Return, Dispute Resolution).',
    explanation: 'Ensures confidentiality and IP ownership rights do not instantly disappear the moment a contract is expired or terminated.',
    marketStandard: 'The provisions of this Agreement that by their nature are intended to survive expiration or termination shall survive, including but not limited to: Section 1 (Definitions), Section 3 (Commercials & Payment for Accrued Fees), Section 4 (Intellectual Property & Work Product Ownership), Section 5 (Confidentiality), Section 6 (Data Protection & Certified Deletion), Section 7 (Substantive Indemnification), Section 8 (Limitation of Liability), Section 9 (Consequences of Termination & Transition), Section 10 (Dispute Resolution & Arbitration), Section 11 (Governing Law), and Section 12 (Miscellaneous Boilerplate).',
    standardWording: 'The provisions of this Agreement that by their nature should survive termination shall survive, including Definitions, IP Ownership, Confidentiality, Indemnification, Limitation of Liability, Data Return, Dispute Resolution, and Governing Law.',
    companyFriendly: 'Express survival of all IP, confidentiality, liability limits, and dispute resolution clauses.',
    companyFriendlyWording: 'Express survival of all IP, confidentiality, liability limits, and dispute resolution clauses.',
    counterpartyFriendly: 'Express survival of indemnity, confidentiality, customer data return, and warranty remedies.',
    counterpartyFriendlyWording: 'Express survival of indemnity, confidentiality, customer data return, and warranty remedies.',
    recommendedCompromise: 'Comprehensive explicit enumeration of all core protective clauses that survive termination.',
    fallbackWording: 'Comprehensive explicit enumeration of all core protective clauses that survive termination.',
    benchmarkRange: 'Universal enterprise standard.',
    industryBenchmarkRange: 'Universal enterprise standard.',
    riskLevel: 'medium',
    legalSource: 'Contract Interpretation Principles; Restatement (Second) of Contracts',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard explicit enumeration practice.',
      'India': 'Preserves post-termination arbitration reference under Arbitration and Conciliation Act 1996 § 16.'
    }
  },

  // 25. Order of Precedence
  {
    id: 'clause-preced-25',
    name: 'Order of Precedence & Conflict Resolution Hierarchy',
    clauseName: 'Order of Precedence & Conflict Resolution Hierarchy',
    category: 'governance',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Establishes clear conflict hierarchy when Master Agreement, Statement of Work (SOW), Service Level Agreement (SLA), Data Processing Addendum (DPA), and Purchase Orders coexist.',
    explanation: 'Avoids operational deadlocks when terms in a purchase order or statement of work contradict the legal protections in the Master Agreement.',
    marketStandard: 'In the event of any conflict, ambiguity, or inconsistency between the terms of this Master Agreement and any attached schedule, exhibit, or ancillary document, the following descending order of precedence shall govern: (1) the Data Processing Addendum (DPA); (2) the applicable Statement of Work (SOW), but only with respect to the specific services covered therein; (3) the Service Level Agreement (SLA); (4) the body of this Master Services Agreement; and (5) any Purchase Order (PO) or invoice issued hereunder. Any pre-printed terms on a Purchase Order are expressly rejected and shall have no legal force.',
    standardWording: 'In the event of conflict, the order of precedence shall be: (1) Data Processing Addendum (DPA); (2) Statement of Work (SOW); (3) Service Level Agreement (SLA); (4) Master Services Agreement; and (5) Purchase Order. Pre-printed PO terms are void.',
    companyFriendly: 'Master Agreement terms strictly control over all SOWs, SLAs, and POs unless the SOW explicitly names the specific section being superseded.',
    companyFriendlyWording: 'Master Agreement terms strictly control over all SOWs and POs unless an SOW explicitly names the specific section being superseded.',
    counterpartyFriendly: 'SOW and DPA terms prevail over Master Agreement to the extent of any conflict.',
    counterpartyFriendlyWording: 'SOW and DPA terms prevail over Master Agreement to the extent of any conflict.',
    recommendedCompromise: 'DPA takes top priority on data matters; SOW controls for project-specific specs; Master Agreement controls for liability, IP, and legal risk allocation; PO pre-printed terms void.',
    fallbackWording: 'DPA takes priority on privacy; SOW controls on project scope; Master Agreement controls on liability and IP.',
    benchmarkRange: 'Standard 4-to-5 tier hierarchy across enterprise contracting.',
    industryBenchmarkRange: 'Standard 4-to-5 tier hierarchy across enterprise contracting.',
    riskLevel: 'medium',
    legalSource: 'Contract Interpretation Rules; Restatement (Second) of Contracts § 203',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard commercial hierarchy rejecting UCC § 2-207 "battle of the forms" pre-printed terms.',
      'India': 'Harmonious construction principle under Indian contract jurisprudence.'
    }
  },

  // 26. Publicity & Trademark Restrictions
  {
    id: 'clause-pub-26',
    name: 'Publicity, Marketing & Trademark Restrictions',
    clauseName: 'Publicity, Marketing & Trademark Restrictions',
    category: 'ip',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Prohibits either party from using the other\'s name, trademarks, logos, or issuing public press releases without prior written consent.',
    explanation: 'Protects brand reputation and prevents vendors from publicly advertising sensitive client engagements without permission.',
    marketStandard: 'Neither party shall issue any press release, public announcement, case study, or promotional material regarding this Agreement or the commercial relationship, nor use the other party\'s name, trade name, trademarks, or logos in customer lists or marketing collateral, without the express prior written consent of the other party in each specific instance.',
    standardWording: 'Neither party shall issue any press release, public announcement, case study, or use the other party\'s name or logo in marketing materials without prior written consent.',
    companyFriendly: 'Provider may include Customer\'s name and logo in its standard customer list and website directory, but press releases require prior consent.',
    companyFriendlyWording: 'Provider may include Customer\'s name and logo in standard customer lists; press releases require consent.',
    counterpartyFriendly: 'Strict zero-publicity covenant; any unauthorized use of customer brand constitutes immediate material breach entitling liquidated damages.',
    counterpartyFriendlyWording: 'Strict zero-publicity covenant without prior written executive approval.',
    recommendedCompromise: 'Standard mutual requirement for prior written approval before any public announcement, press release, or logo use.',
    fallbackWording: 'Standard mutual requirement for prior written approval before any public announcement or logo use.',
    benchmarkRange: 'Prior written consent required standard.',
    industryBenchmarkRange: 'Prior written consent required standard.',
    riskLevel: 'medium',
    legalSource: 'Trademark Law (Lanham Act 15 U.S.C. § 1114; Indian Trade Marks Act 1999)',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Standard Lanham Act trademark protection and brand usage covenants.',
      'India': 'Indian Trade Marks Act, 1999 Section 29 protection against unauthorized commercial use.'
    }
  },

  // 27. Limitation of Liability & Consequential Damages
  {
    id: 'clause-liab-cap-01',
    name: 'Limitation of Liability & Damages Cap',
    clauseName: 'Limitation of Liability & Damages Cap',
    category: 'liability',
    jurisdiction: 'Global / Multi-Jurisdiction',
    description: 'Establishes the ceiling for monetary damages and excludes indirect, consequential, lost profits, or punitive damages.',
    explanation: 'Allocates catastrophic operational downside risk by placing a predictable dollar or multiple-of-fees ceiling on commercial exposure.',
    marketStandard: 'Except for breach of confidentiality, indemnification obligations, or gross negligence/willful misconduct, neither party\'s total aggregate liability under this Agreement shall exceed the total amount of fees paid or payable in the twelve (12) months preceding the incident. Neither party shall be liable for indirect, incidental, consequential, special, or punitive damages.',
    standardWording: 'Except for breach of confidentiality, indemnification obligations, or gross negligence/willful misconduct, neither party\'s total aggregate liability under this Agreement shall exceed the total amount of fees paid or payable in the twelve (12) months preceding the incident. Neither party shall be liable for indirect, incidental, consequential, special, or punitive damages.',
    companyFriendly: 'Total aggregate liability capped strictly at fees actually paid in the preceding three (3) months. Absolute waiver of all lost profits, lost data, and indirect damages without uncapped exceptions.',
    companyFriendlyWording: 'Total aggregate liability capped strictly at fees actually paid in the preceding three (3) months. Absolute waiver of all lost profits, lost data, and indirect damages without uncapped exceptions.',
    counterpartyFriendly: 'Liability cap set at three times (3x) the total contract value or $5,000,000 (whichever is greater), with uncapped exceptions for data breaches, regulatory fines, IP infringement, and confidentiality.',
    counterpartyFriendlyWording: 'Liability cap set at three times (3x) the total contract value, with uncapped exceptions for data breaches, regulatory fines, IP infringement, and confidentiality.',
    recommendedCompromise: '12 months trailing fees liability cap (100% of annual contract value) with standard super-cap (2x) for data protection breaches, and standard uncapped carve-outs for IP indemnity and gross negligence.',
    fallbackWording: '12 months trailing fees liability cap with standard super-cap for data protection breaches.',
    benchmarkRange: '100% to 200% of annual contract value (12 months trailing fees).',
    industryBenchmarkRange: '100% to 200% of annual contract value (12 months trailing fees).',
    riskLevel: 'critical',
    legalSource: 'Delaware UCC § 2-719; English UCTA 1977; German BGB § 307; Indian Contract Act § 73',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'United States': 'Consequential damages disclaimer must be explicit; Delaware enforces 12-month trailing fee caps.',
      'United Kingdom': 'Subject to UCTA 1977 reasonableness test; cannot exclude death or personal injury caused by negligence.',
      'Germany / EU': 'Cannot exclude liability for gross negligence (grobe Fahrlässigkeit) or cardinal obligations (Kardinalpflichten) under BGB § 307.',
      'India': 'Section 73 of Indian Contract Act permits pre-estimated damages, but courts disallow penalty-oriented exclusions.'
    }
  },

  // 28. Dispute Resolution & Arbitration
  {
    id: 'clause-dispute-arb-05',
    name: 'Dispute Resolution & Institutional Arbitration',
    clauseName: 'Dispute Resolution & Institutional Arbitration',
    category: 'dispute_resolution',
    jurisdiction: 'International Arbitration (SIAC / LCIA / AAA / MCIA)',
    description: 'Establishes the forum, rules, seat, and governing mechanism for resolving commercial disagreements without costly court litigation.',
    explanation: 'Establishes the forum, rules, seat, and governing mechanism for resolving commercial disagreements without costly court litigation.',
    marketStandard: 'Any dispute, controversy, or claim arising out of or relating to this contract shall be settled by binding arbitration under the rules of the selected Arbitration Institution. The arbitration shall be conducted in the English language by a single arbitrator appointed in accordance with said rules.',
    standardWording: 'Any dispute, controversy, or claim arising out of or relating to this contract shall be settled by binding arbitration under the rules of the selected Arbitration Institution. The arbitration shall be conducted in the English language by a single arbitrator appointed in accordance with said rules.',
    companyFriendly: 'All disputes shall be submitted to the exclusive jurisdiction of the state and federal courts located in Company\'s home forum, and each party expressly waives any right to a trial by jury or class action proceeding.',
    companyFriendlyWording: 'All disputes shall be submitted to the exclusive jurisdiction of the state and federal courts located in Company\'s home forum, and each party expressly waives any right to a trial by jury or class action proceeding.',
    counterpartyFriendly: 'Disputes shall be resolved through good faith executive escalation for thirty (30) days, failing which either party may initiate institutional international arbitration seated in London (LCIA) or Singapore (SIAC), with full recovery of legal costs to the prevailing party.',
    counterpartyFriendlyWording: 'Disputes shall be resolved through good faith executive escalation for thirty (30) days, failing which either party may initiate institutional international arbitration seated in London (LCIA) or Singapore (SIAC), with full recovery of legal costs to the prevailing party.',
    recommendedCompromise: 'Mandatory 30-day senior executive negotiation period followed by institutional arbitration (SIAC / LCIA / AAA / MCIA) with 1 arbitrator for claims under $1M and 3 arbitrators for larger claims.',
    fallbackWording: 'Mandatory 30-day senior executive negotiation period followed by institutional arbitration with 1 arbitrator.',
    benchmarkRange: 'Single arbitrator for disputes under $1M; 3-arbitrator panel for large multi-million disputes.',
    industryBenchmarkRange: 'Single arbitrator for disputes under $1M; 3-arbitrator panel for large multi-million disputes.',
    riskLevel: 'medium',
    legalSource: 'New York Convention on the Recognition and Enforcement of Foreign Arbitral Awards (1958)',
    lastUpdated: '2026-08-28',
    jurisdictionVariations: {
      'Singapore': 'Seat: Singapore; Administered by SIAC under SIAC Rules; English language.',
      'United Kingdom': 'Seat: London; Administered by LCIA under LCIA Rules; English language.',
      'India': 'Seat: Mumbai/Delhi; Administered by MCIA under Arbitration and Conciliation Act 1996.',
      'United States': 'Seat: New York/San Francisco; Administered by AAA/ICDR under Commercial Arbitration Rules.'
    }
  }
];

export const JURISDICTION_LEGAL_RULES: LegalRule[] = [
  ...COMPREHENSIVE_STATUTORY_RULES,
  ...(INITIAL_LEGAL_RULES.filter(
    (r: any) => !COMPREHENSIVE_STATUTORY_RULES.some(
      (c: LegalRule) => c.id === r.id || c.ruleName.toLowerCase() === (r.ruleName || '').toLowerCase()
    )
  ) as LegalRule[])
];
export const STANDARD_CLAUSE_BENCHMARKS: ClauseBenchmark[] = INITIAL_CLAUSE_LIBRARY as any;
