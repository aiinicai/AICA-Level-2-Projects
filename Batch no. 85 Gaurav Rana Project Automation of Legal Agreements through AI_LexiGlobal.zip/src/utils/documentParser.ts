import mammoth from 'mammoth';
import { normalizeContractText } from './textNormalizer';

export interface ParsedDocumentResult {
  text: string;
  fileName: string;
  fileSizeFormatted: string;
  detectedType: string;
  wordCount: number;
  charCount: number;
  estimatedClauses: number;
  source: 'client-native' | 'client-mammoth' | 'server-parser' | 'gemini-ocr';
}

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

function countEstimatedClauses(text: string): number {
  const matches = text.match(/(?:Section|Article|Clause|\b\d+\.\d+|\b\d+\.)\s+[A-Z]/gi);
  return matches ? Math.max(matches.length, 3) : Math.max(Math.floor(text.split(/\n\n+/).length / 2), 1);
}

/**
 * Extracts raw text from uploaded contract files (.docx, .doc, .pdf, .txt, .md, .rtf, etc.)
 */
export async function parseUploadedContractFile(file: File): Promise<ParsedDocumentResult> {
  const fileName = file.name;
  const lowerName = fileName.toLowerCase();
  const fileSizeFormatted = formatBytes(file.size);

  // 1. Plain Text / Markdown / JSON / CSV
  if (
    lowerName.endsWith('.txt') ||
    lowerName.endsWith('.md') ||
    lowerName.endsWith('.json') ||
    lowerName.endsWith('.csv') ||
    lowerName.endsWith('.rtf') ||
    file.type === 'text/plain' ||
    file.type === 'text/markdown'
  ) {
    try {
      const text = await file.text();
      const cleaned = normalizeContractText(text);
      const words = cleaned ? cleaned.split(/\s+/).length : 0;
      return {
        text: cleaned,
        fileName,
        fileSizeFormatted,
        detectedType: lowerName.endsWith('.md') ? 'Markdown (.md)' : 'Plain Text (.txt)',
        wordCount: words,
        charCount: cleaned.length,
        estimatedClauses: countEstimatedClauses(cleaned),
        source: 'client-native'
      };
    } catch (err) {
      console.warn('[DocParser] Direct text reading failed, falling back to server:', err);
    }
  }

  // 2. Word .docx in browser via mammoth
  if (
    lowerName.endsWith('.docx') ||
    file.type === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
  ) {
    try {
      const arrayBuffer = await file.arrayBuffer();
      const result = await mammoth.extractRawText({ arrayBuffer });
      const text = normalizeContractText(result.value || '');
      if (text && text.length > 20) {
        const words = text.split(/\s+/).length;
        return {
          text,
          fileName,
          fileSizeFormatted,
          detectedType: 'Microsoft Word (.docx)',
          wordCount: words,
          charCount: text.length,
          estimatedClauses: countEstimatedClauses(text),
          source: 'client-mammoth'
        };
      }
    } catch (err) {
      console.warn('[DocParser] Client-side mammoth failed, trying server endpoint:', err);
    }
  }

  // 3. Server API fallback for PDF, legacy .DOC, and complex files
  try {
    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    let binary = '';
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const fileBase64 = btoa(binary);

    const res = await fetch('/api/parse-document', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        fileBase64,
        fileName: file.name,
        mimeType: file.type
      })
    });

    const data = await res.json();
    if (data.success && data.text) {
      const text = normalizeContractText(data.text);
      const words = data.wordCount || (text ? text.split(/\s+/).length : 0);
      return {
        text,
        fileName,
        fileSizeFormatted,
        detectedType: data.detectedType || (lowerName.endsWith('.pdf') ? 'PDF Document (.pdf)' : 'Word Document (.docx)'),
        wordCount: words,
        charCount: data.charCount || text.length,
        estimatedClauses: countEstimatedClauses(text),
        source: 'server-parser'
      };
    }
  } catch (serverErr) {
    console.error('[DocParser] Server document parsing failed:', serverErr);
  }

  // 4. Last resort: Attempt text decode
  try {
    const text = await file.text();
    const cleanText = normalizeContractText(text);
    if (cleanText.length > 50) {
      return {
        text: cleanText,
        fileName,
        fileSizeFormatted,
        detectedType: 'Binary Text Extracted',
        wordCount: cleanText.split(/\s+/).length,
        charCount: cleanText.length,
        estimatedClauses: countEstimatedClauses(cleanText),
        source: 'client-native'
      };
    }
  } catch {
    // Ignore
  }

  throw new Error(`Unable to extract text from "${fileName}". Please ensure the file is an uncorrupted DOCX, PDF, or text document.`);
}
