import { jsPDF } from 'jspdf';
import { saveAs } from 'file-saver';
import { LegalRule } from '../types';
import { getBareActForRule, getFullBareActText } from '../data/bareActsData';

/**
 * Downloads a dedicated, authentic BARE ACT PDF containing the complete unedited statutory text,
 * preamble, arrangement of sections, chapters, subsections, provisos, explanations, and schedules.
 */
export function downloadBareActPdf(rule: LegalRule): void {
  const bareAct = getBareActForRule(rule);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 40;
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin - 30) {
      doc.addPage();
      y = margin;
      drawHeader();
    }
  };

  const drawHeader = () => {
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, pageWidth, 42, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10.5);
    doc.text('OFFICIAL PARLIAMENTARY & STATUTORY BARE ACT', margin, 26);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    const countryLabel = (rule.country || 'GLOBAL').toUpperCase();
    doc.text(
      `JURISDICTION: ${countryLabel} | BARE ACT CODE: ${bareAct.officialActNumberAndYear}`,
      pageWidth - margin,
      26,
      { align: 'right' }
    );
    y = 58;
  };

  drawHeader();

  // Legislative Seal / Header Emblem
  doc.setDrawColor(16, 185, 129); // emerald-500
  doc.setLineWidth(1.5);
  doc.line(margin, y, pageWidth - margin, y);
  y += 16;

  // Official Act Title
  doc.setTextColor(15, 23, 42);
  doc.setFont('times', 'bold');
  doc.setFontSize(18);
  const actTitle = (rule.fullActTitle || rule.ruleName).toUpperCase();
  const titleLines = doc.splitTextToSize(actTitle, contentWidth);
  doc.text(titleLines, margin, y);
  y += titleLines.length * 20 + 2;

  // Act Number & Year
  doc.setFont('times', 'italic');
  doc.setFontSize(11);
  doc.setTextColor(71, 85, 105);
  doc.text(`[${bareAct.officialActNumberAndYear}]`, margin, y);
  y += 16;

  // Metadata Panel
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.rect(margin, y, contentWidth, 54, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8);
  doc.setTextColor(71, 85, 105);
  doc.text('Enactment Date:', margin + 10, y + 15);
  doc.text('Statutory Citation:', margin + 10, y + 29);
  doc.text('Enforcing Authority:', margin + 10, y + 43);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(bareAct.enactmentDate || rule.effectiveDate || 'Statutory Code in Force', margin + 115, y + 15);
  doc.text(bareAct.officialGazetteCitation || rule.statutoryCitation, margin + 115, y + 29);
  doc.text(rule.enforcingAuthority || 'National / Regional Regulatory Agency', margin + 115, y + 43);

  doc.setFont('helvetica', 'bold');
  doc.setTextColor(16, 185, 129);
  doc.text('AUTHENTIC BARE ACT', pageWidth - margin - 10, y + 15, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`${rule.confidenceScore}% Verification Confidence`, pageWidth - margin - 10, y + 29, { align: 'right' });
  doc.text(`Verified: ${rule.lastVerifiedDate}`, pageWidth - margin - 10, y + 43, { align: 'right' });

  y += 66;

  // Preamble Section
  checkPageBreak(70);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 18, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text('PREAMBLE', margin + 8, y + 12);
  y += 24;

  doc.setFont('times', 'italic');
  doc.setFontSize(9.5);
  doc.setTextColor(30, 41, 59);
  const preambleLines = doc.splitTextToSize(bareAct.preamble, contentWidth - 16);
  checkPageBreak(preambleLines.length * 13 + 12);

  doc.setFillColor(16, 185, 129);
  doc.rect(margin, y - 2, 2.5, preambleLines.length * 13 + 4, 'F');
  doc.text(preambleLines, margin + 10, y + 8);
  y += preambleLines.length * 13 + 18;

  // Arrangement of Sections (Table of Contents)
  if (bareAct.arrangementOfSections && bareAct.arrangementOfSections.length > 0) {
    checkPageBreak(50);
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 18, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text('ARRANGEMENT OF SECTIONS', margin + 8, y + 12);
    y += 24;

    for (const item of bareAct.arrangementOfSections) {
      checkPageBreak(16);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(16, 185, 129);
      doc.text(item.section, margin + 4, y);

      doc.setFont('times', 'normal');
      doc.setFontSize(8.5);
      doc.setTextColor(51, 65, 85);
      const titleLine = doc.splitTextToSize(item.title, contentWidth - 110);
      doc.text(titleLine[0] || item.title, margin + 100, y);
      y += 14;
    }
    y += 10;
  }

  // Chapters & Substantive Sections
  for (const chapter of bareAct.chapters) {
    checkPageBreak(40);
    doc.setFillColor(15, 23, 42);
    doc.rect(margin, y, contentWidth, 22, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(255, 255, 255);
    doc.text(`${chapter.chapterNumber} — ${chapter.chapterTitle}`, margin + 8, y + 15);
    y += 30;

    for (const sec of chapter.sections) {
      checkPageBreak(55);

      // Section Header Banner
      doc.setFillColor(248, 250, 252);
      doc.rect(margin, y, contentWidth, 16, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(16, 185, 129);
      doc.text(`${sec.sectionNumber}`, margin + 6, y + 11);

      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      doc.text(sec.sectionTitle, margin + 110, y + 11);
      y += 22;

      // Verbatim Section Text
      doc.setFont('times', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor(30, 41, 59);
      const secLines = doc.splitTextToSize(sec.verbatimText, contentWidth - 8);
      checkPageBreak(secLines.length * 13 + 8);
      doc.text(secLines, margin + 6, y);
      y += secLines.length * 13 + 8;

      // Provisos
      if (sec.provisos && sec.provisos.length > 0) {
        for (const proviso of sec.provisos) {
          doc.setFont('times', 'italic');
          doc.setFontSize(9);
          doc.setTextColor(71, 85, 105);
          const pLines = doc.splitTextToSize(proviso, contentWidth - 18);
          checkPageBreak(pLines.length * 12 + 6);
          doc.text(pLines, margin + 16, y);
          y += pLines.length * 12 + 6;
        }
      }

      // Explanations
      if (sec.explanations && sec.explanations.length > 0) {
        for (const exp of sec.explanations) {
          doc.setFont('times', 'italic');
          doc.setFontSize(8.5);
          doc.setTextColor(100, 116, 139);
          const eLines = doc.splitTextToSize(`Explanation.—${exp}`, contentWidth - 18);
          checkPageBreak(eLines.length * 12 + 6);
          doc.text(eLines, margin + 16, y);
          y += eLines.length * 12 + 6;
        }
      }

      y += 8;
    }
  }

  // Schedules (if present)
  if (bareAct.schedules && bareAct.schedules.length > 0) {
    for (const sch of bareAct.schedules) {
      checkPageBreak(50);
      doc.setFillColor(15, 23, 42);
      doc.rect(margin, y, contentWidth, 20, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(255, 255, 255);
      doc.text(`${sch.scheduleNumber} — ${sch.scheduleTitle}`, margin + 8, y + 14);
      y += 28;

      doc.setFont('times', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(51, 65, 85);
      const schLines = doc.splitTextToSize(sch.content, contentWidth - 8);
      checkPageBreak(schLines.length * 13 + 6);
      doc.text(schLines, margin + 6, y);
      y += schLines.length * 13 + 12;
    }
  }

  // Footer on all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 32, pageWidth - margin, pageHeight - 32);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `Official Statutory Bare Act • ${rule.fullActTitle || rule.ruleName} [${bareAct.officialActNumberAndYear}] • LexiGlobal`,
      margin,
      pageHeight - 20
    );
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 20, { align: 'right' });
  }

  const safeFilename = (rule.ruleName || 'Statutory_Act')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .substring(0, 45);
  doc.save(`${rule.country}_${safeFilename}_Bare_Act.pdf`);
}

/**
 * Downloads the Bare Act in clean, unadulterated Text / Markdown format
 */
export function downloadBareActText(rule: LegalRule): void {
  const bareAct = getBareActForRule(rule);
  const textContent = getFullBareActText(rule, bareAct);

  const blob = new Blob([textContent], { type: 'text/plain;charset=utf-8' });
  const safeFilename = (rule.ruleName || 'Statutory_Act')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .substring(0, 45);
  saveAs(blob, `${rule.country}_${safeFilename}_Bare_Act.txt`);
}

/**
 * Downloads a formal soft copy PDF of a single Statutory Act / Legal Rule
 * Now enriched with both Executive Statutory Analysis AND the Complete Bare Act.
 */
export function downloadActSoftCopyPdf(rule: LegalRule): void {
  const bareAct = getBareActForRule(rule);
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 40;
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin - 30) {
      doc.addPage();
      y = margin;
      drawHeader();
    }
  };

  const drawHeader = () => {
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, pageWidth, 42, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text('OFFICIAL STATUTORY RECORD • LEGISLATIVE COMPENDIUM & BARE ACT', margin, 26);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    const countryLabel = (rule.country || 'GLOBAL').toUpperCase();
    doc.text(`JURISDICTION: ${countryLabel} | STATUS: ${(rule.verificationStatus || 'VERIFIED').toUpperCase()}`, pageWidth - margin, 26, { align: 'right' });
    y = 58;
  };

  drawHeader();

  // Act Title Header Banner
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  const actTitle = rule.fullActTitle || rule.ruleName;
  const titleLines = doc.splitTextToSize(actTitle, contentWidth);
  doc.text(titleLines, margin, y);
  y += titleLines.length * 18 + 4;

  // Metadata Box
  doc.setFillColor(248, 250, 252); // slate-50
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.rect(margin, y, contentWidth, 72, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(71, 85, 105);
  doc.text(`Statutory Citation:`, margin + 10, y + 16);
  doc.text(`Official Act No.:`, margin + 10, y + 30);
  doc.text(`Jurisdiction / Scope:`, margin + 10, y + 44);
  doc.text(`Enforcing Authority:`, margin + 10, y + 58);

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(15, 23, 42);
  doc.text(rule.statutoryCitation || 'N/A', margin + 120, y + 16);
  doc.text(bareAct.officialActNumberAndYear || 'N/A', margin + 120, y + 30);
  doc.text(`${rule.country}${rule.stateOrProvince ? ` (${rule.stateOrProvince})` : ''}`, margin + 120, y + 44);
  doc.text(rule.enforcingAuthority || 'National / Federal Regulatory Agency', margin + 120, y + 58);

  // Confidence & Verification Tag in Box
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(13, 148, 136); // teal-600
  doc.text(`${rule.confidenceScore}% Verification Confidence`, pageWidth - margin - 10, y + 16, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setTextColor(100, 116, 139);
  doc.text(`Verified: ${rule.lastVerifiedDate}`, pageWidth - margin - 10, y + 32, { align: 'right' });
  doc.text(`Effective: ${bareAct.enactmentDate || rule.effectiveDate || 'In Force'}`, pageWidth - margin - 10, y + 48, { align: 'right' });

  y += 86;

  // 1. Legislative Overview / Summary
  checkPageBreak(50);
  doc.setFillColor(241, 245, 249);
  doc.rect(margin, y, contentWidth, 20, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(15, 23, 42);
  doc.text('1. STATUTORY SUMMARY & LEGISLATIVE INTENT', margin + 8, y + 14);
  y += 26;

  doc.setFont('times', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(30, 41, 59);
  const summaryText = rule.actSummary || rule.legalRequirement;
  const summaryLines = doc.splitTextToSize(summaryText, contentWidth);
  checkPageBreak(summaryLines.length * 14 + 10);
  doc.text(summaryLines, margin, y);
  y += summaryLines.length * 14 + 12;

  // 2. Mandatory Provisions Checklist
  if (rule.mandatoryProvisions && rule.mandatoryProvisions.length > 0) {
    checkPageBreak(40);
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 20, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text('2. MANDATORY COMPLIANCE OBLIGATIONS', margin + 8, y + 14);
    y += 26;

    for (const item of rule.mandatoryProvisions) {
      checkPageBreak(25);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(16, 185, 129);
      doc.text('•', margin + 4, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(30, 41, 59);
      const itemLines = doc.splitTextToSize(item, contentWidth - 16);
      doc.text(itemLines, margin + 16, y);
      y += itemLines.length * 13 + 4;
    }
    y += 8;
  }

  // 3. Restricted / Prohibited Provisions
  if (rule.restrictedProvisions && rule.restrictedProvisions.length > 0) {
    checkPageBreak(40);
    doc.setFillColor(254, 242, 242); // rose-50
    doc.rect(margin, y, contentWidth, 20, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(159, 18, 57); // rose-900
    doc.text('3. PROHIBITED / UNENFORCEABLE RESTRICTIONS (VOID AB INITIO)', margin + 8, y + 14);
    y += 26;

    for (const item of rule.restrictedProvisions) {
      checkPageBreak(25);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(225, 29, 72); // rose-600
      doc.text('✖', margin + 4, y);
      doc.setFont('helvetica', 'normal');
      doc.setTextColor(76, 5, 25);
      const itemLines = doc.splitTextToSize(item, contentWidth - 16);
      doc.text(itemLines, margin + 16, y);
      y += itemLines.length * 13 + 4;
    }
    y += 8;
  }

  // 4. Recommended Contractual Standard Wording
  if (rule.recommendedWording) {
    checkPageBreak(60);
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 20, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9.5);
    doc.setTextColor(15, 23, 42);
    doc.text('4. RECOMMENDED STATUTORY MODEL CLAUSE', margin + 8, y + 14);
    y += 26;

    doc.setFont('times', 'italic');
    doc.setFontSize(9.5);
    doc.setTextColor(30, 41, 59);
    const clauseLines = doc.splitTextToSize(`"${rule.recommendedWording}"`, contentWidth - 16);
    
    checkPageBreak(clauseLines.length * 13 + 16);
    doc.setFillColor(16, 185, 129);
    doc.rect(margin, y - 4, 3, clauseLines.length * 13 + 8, 'F');
    doc.text(clauseLines, margin + 10, y + 6);
    y += clauseLines.length * 13 + 16;
  }

  // 5. THE COMPLETE BARE ACT (VERBATIM STATUTORY CODE & PROVISIONS)
  checkPageBreak(70);
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(margin, y, contentWidth, 26, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10.5);
  doc.setTextColor(255, 255, 255);
  doc.text('5. THE BARE ACT: VERBATIM STATUTORY TEXT & PROVISIONS', margin + 8, y + 17);
  y += 34;

  // Preamble
  doc.setFont('times', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(`ACT PREAMBLE:`, margin, y);
  y += 14;

  doc.setFont('times', 'italic');
  doc.setFontSize(9.5);
  doc.setTextColor(51, 65, 85);
  const pLines = doc.splitTextToSize(bareAct.preamble, contentWidth);
  checkPageBreak(pLines.length * 13 + 10);
  doc.text(pLines, margin, y);
  y += pLines.length * 13 + 14;

  // Chapters and Sections
  for (const chapter of bareAct.chapters) {
    checkPageBreak(35);
    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 18, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(`${chapter.chapterNumber}: ${chapter.chapterTitle}`, margin + 8, y + 12);
    y += 24;

    for (const sec of chapter.sections) {
      checkPageBreak(45);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(16, 185, 129);
      doc.text(`${sec.sectionNumber} — ${sec.sectionTitle}`, margin, y);
      y += 13;

      doc.setFont('times', 'normal');
      doc.setFontSize(9.5);
      doc.setTextColor(30, 41, 59);
      const textLines = doc.splitTextToSize(sec.verbatimText, contentWidth);
      checkPageBreak(textLines.length * 13 + 8);
      doc.text(textLines, margin, y);
      y += textLines.length * 13 + 10;

      if (sec.provisos && sec.provisos.length > 0) {
        for (const p of sec.provisos) {
          doc.setFont('times', 'italic');
          doc.setFontSize(8.5);
          doc.setTextColor(71, 85, 105);
          const prvLines = doc.splitTextToSize(p, contentWidth - 12);
          checkPageBreak(prvLines.length * 12 + 6);
          doc.text(prvLines, margin + 12, y);
          y += prvLines.length * 12 + 6;
        }
      }

      if (sec.explanations && sec.explanations.length > 0) {
        for (const exp of sec.explanations) {
          doc.setFont('times', 'italic');
          doc.setFontSize(8.5);
          doc.setTextColor(100, 116, 139);
          const expLines = doc.splitTextToSize(`Explanation.—${exp}`, contentWidth - 12);
          checkPageBreak(expLines.length * 12 + 6);
          doc.text(expLines, margin + 12, y);
          y += expLines.length * 12 + 6;
        }
      }

      y += 4;
    }
  }

  // Official Online Portal Reference
  if (rule.officialUrl) {
    checkPageBreak(30);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text('Official Government Gazette / Legislation Portal:', margin, y);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(37, 99, 235);
    doc.text(rule.officialUrl, margin + 220, y);
    y += 18;
  }

  // Footer on all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 32, pageWidth - margin, pageHeight - 32);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `LexiGlobal Statutory Knowledge Base & Bare Act Record • Reviewed by: ${rule.reviewerCredentials}`,
      margin,
      pageHeight - 20
    );
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 20, { align: 'right' });
  }

  const safeFilename = (rule.ruleName || 'Statutory_Act')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .substring(0, 50);
  doc.save(`${rule.country}_${safeFilename}_SoftCopy.pdf`);
}

/**
 * Downloads a soft copy of the Act in clean Text / Markdown format,
 * now including the complete Bare Act.
 */
export function downloadActSoftCopyText(rule: LegalRule): void {
  const bareAct = getBareActForRule(rule);

  let content = `# ${rule.fullActTitle || rule.ruleName}\n\n`;
  content += `**Jurisdiction**: ${rule.country}${rule.stateOrProvince ? ` (${rule.stateOrProvince})` : ''}\n`;
  content += `**Statutory Citation**: ${rule.statutoryCitation}\n`;
  content += `**Official Act No.**: ${bareAct.officialActNumberAndYear}\n`;
  content += `**Subject Area**: ${rule.subjectArea.toUpperCase()}\n`;
  content += `**Enforcing Authority**: ${rule.enforcingAuthority || 'National / Federal Legislative Authority'}\n`;
  content += `**Effective Date**: ${bareAct.enactmentDate || rule.effectiveDate || 'In Force'}\n`;
  content += `**Verification Status**: ${rule.verificationStatus.toUpperCase()} (${rule.confidenceScore}% Confidence)\n`;
  content += `**Verified By**: ${rule.reviewerCredentials}\n`;
  if (rule.officialUrl) {
    content += `**Official Gazette / Legislation URL**: ${rule.officialUrl}\n`;
  }
  content += `\n---\n\n`;

  content += `## 1. Statutory Summary & Legislative Intent\n\n`;
  content += `${rule.actSummary || rule.legalRequirement}\n\n`;

  if (rule.mandatoryProvisions && rule.mandatoryProvisions.length > 0) {
    content += `## 2. Mandatory Compliance Provisions\n\n`;
    for (const p of rule.mandatoryProvisions) {
      content += `- [MANDATORY] ${p}\n`;
    }
    content += `\n`;
  }

  if (rule.restrictedProvisions && rule.restrictedProvisions.length > 0) {
    content += `## 3. Prohibited / Unenforceable Provisions (Void Ab Initio)\n\n`;
    for (const p of rule.restrictedProvisions) {
      content += `- [PROHIBITED] ${p}\n`;
    }
    content += `\n`;
  }

  if (rule.recommendedWording) {
    content += `## 4. Recommended Contractual Standard Clause\n\n`;
    content += `> "${rule.recommendedWording}"\n\n`;
  }

  content += `\n---\n\n`;
  content += `## 5. THE BARE ACT (VERBATIM STATUTORY TEXT & PROVISIONS)\n\n`;
  content += `### PREAMBLE\n`;
  content += `${bareAct.preamble}\n\n`;

  for (const chapter of bareAct.chapters) {
    content += `### ${chapter.chapterNumber}: ${chapter.chapterTitle}\n\n`;
    for (const sec of chapter.sections) {
      content += `#### ${sec.sectionNumber} — ${sec.sectionTitle}\n`;
      content += `${sec.verbatimText}\n\n`;

      if (sec.provisos && sec.provisos.length > 0) {
        for (const p of sec.provisos) {
          content += `> *${p}*\n\n`;
        }
      }

      if (sec.explanations && sec.explanations.length > 0) {
        for (const exp of sec.explanations) {
          content += `*Explanation.—${exp}*\n\n`;
        }
      }
    }
  }

  if (bareAct.schedules && bareAct.schedules.length > 0) {
    content += `### SCHEDULES\n\n`;
    for (const sch of bareAct.schedules) {
      content += `#### ${sch.scheduleNumber}: ${sch.scheduleTitle}\n`;
      content += `${sch.content}\n\n`;
    }
  }

  content += `---\nGenerated by LexiGlobal Legal Knowledge Base. Last verified: ${rule.lastVerifiedDate}\n`;

  const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
  const safeFilename = (rule.ruleName || 'Statutory_Act')
    .replace(/[^a-zA-Z0-9_-]/g, '_')
    .substring(0, 50);
  saveAs(blob, `${rule.country}_${safeFilename}_SoftCopy.md`);
}

/**
 * Downloads a complete compendium of all acts for a given country in a single PDF document,
 * including both the summaries and the Bare Act provisions.
 */
export function downloadCountryCompendiumPdf(country: string, rules: LegalRule[]): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4'
  });

  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  const margin = 40;
  const contentWidth = pageWidth - margin * 2;
  let y = margin;

  const checkPageBreak = (neededHeight: number) => {
    if (y + neededHeight > pageHeight - margin - 30) {
      doc.addPage();
      y = margin;
      drawHeader();
    }
  };

  const drawHeader = () => {
    doc.setFillColor(15, 23, 42); // slate-900
    doc.rect(0, 0, pageWidth, 42, 'F');

    doc.setTextColor(255, 255, 255);
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(11);
    doc.text(`OFFICIAL STATUTORY COMPENDIUM & BARE ACTS • ${country.toUpperCase()}`, margin, 26);

    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(148, 163, 184);
    doc.text(`TOTAL ACTS: ${rules.length} | LEXIGLOBAL LEGAL REPOSITORY`, pageWidth - margin, 26, { align: 'right' });
    y = 58;
  };

  drawHeader();

  // Cover / Header Banner
  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(20);
  doc.text(`${country} Statutory Legal Compendium & Bare Acts`, margin, y);
  y += 24;

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9.5);
  doc.setTextColor(71, 85, 105);
  doc.text(
    `Comprehensive compilation of official statutory enactments and verbatim Bare Acts. Includes employment codes, contract regulations, data governance, and dispute rules. Compiled on ${new Date().toLocaleDateString()}.`,
    margin,
    y
  );
  y += 24;

  // Table of Contents
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.rect(margin, y, contentWidth, rules.length * 14 + 20, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(15, 23, 42);
  doc.text('TABLE OF ENACTMENTS INCLUDED:', margin + 10, y + 14);

  let tocY = y + 26;
  rules.forEach((r, idx) => {
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(8);
    doc.setTextColor(51, 65, 85);
    doc.text(`${idx + 1}. ${r.fullActTitle || r.ruleName} (${r.statutoryCitation})`, margin + 12, tocY);
    tocY += 14;
  });

  y = tocY + 16;

  // Now output each rule with its Bare Act
  rules.forEach((rule, idx) => {
    const bareAct = getBareActForRule(rule);
    checkPageBreak(120);

    doc.setFillColor(241, 245, 249);
    doc.rect(margin, y, contentWidth, 22, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(15, 23, 42);
    doc.text(`ACT #${idx + 1}: ${rule.fullActTitle || rule.ruleName}`, margin + 8, y + 15);
    y += 28;

    doc.setFont('helvetica', 'bold');
    doc.setFontSize(8.5);
    doc.setTextColor(71, 85, 105);
    doc.text(`Citation: ${rule.statutoryCitation} | [${bareAct.officialActNumberAndYear}]`, margin, y);
    y += 14;

    doc.setFont('times', 'normal');
    doc.setFontSize(9.5);
    doc.setTextColor(30, 41, 59);
    const summaryLines = doc.splitTextToSize(rule.actSummary || rule.legalRequirement, contentWidth);
    checkPageBreak(summaryLines.length * 13 + 10);
    doc.text(summaryLines, margin, y);
    y += summaryLines.length * 13 + 10;

    // Bare Act Chapters & Sections
    for (const ch of bareAct.chapters) {
      checkPageBreak(25);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8.5);
      doc.setTextColor(15, 23, 42);
      doc.text(`${ch.chapterNumber}: ${ch.chapterTitle}`, margin, y);
      y += 12;

      for (const sec of ch.sections) {
        checkPageBreak(35);
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(8.5);
        doc.setTextColor(16, 185, 129);
        doc.text(`• ${sec.sectionNumber}: ${sec.sectionTitle}`, margin, y);
        y += 11;

        doc.setFont('times', 'normal');
        doc.setFontSize(9);
        doc.setTextColor(71, 85, 105);
        const secLines = doc.splitTextToSize(sec.verbatimText, contentWidth - 10);
        checkPageBreak(secLines.length * 12 + 6);
        doc.text(secLines, margin + 8, y);
        y += secLines.length * 12 + 8;
      }
    }

    if (rule.recommendedWording) {
      checkPageBreak(35);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(15, 23, 42);
      doc.text('Recommended Model Clause:', margin, y);
      y += 11;
      doc.setFont('times', 'italic');
      doc.setFontSize(8.5);
      doc.setTextColor(51, 65, 85);
      const wLines = doc.splitTextToSize(`"${rule.recommendedWording}"`, contentWidth);
      checkPageBreak(wLines.length * 11 + 6);
      doc.text(wLines, margin, y);
      y += wLines.length * 11 + 10;
    }

    y += 12;
  });

  // Footer on all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setDrawColor(226, 232, 240);
    doc.line(margin, pageHeight - 32, pageWidth - margin, pageHeight - 32);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(
      `LexiGlobal Statutory Compendium & Bare Acts • ${country} • Official Legal Soft Copy`,
      margin,
      pageHeight - 20
    );
    doc.text(`Page ${i} of ${totalPages}`, pageWidth - margin, pageHeight - 20, { align: 'right' });
  }

  const safeCountry = country.replace(/[^a-zA-Z0-9_-]/g, '_');
  doc.save(`${safeCountry}_Statutory_Acts_Compendium.pdf`);
}
