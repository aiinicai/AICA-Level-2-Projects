/**
 * Normalizes legal contract text extracted from various sources (PDF, Word DOCX, OCR, RTF).
 * Eliminates false positive differences caused by:
 * - PDF line-wrapping hard breaks vs DOCX continuous paragraphs
 * - Word-hyphenation across line margins (e.g. "respon- \n sibility" -> "responsibility")
 * - Smart quotes / typography (“ ” ‘ ’ — – …) vs ASCII equivalents (" ' - ...)
 * - Non-breaking spaces (\u00A0), zero-width characters, multiple spaces
 * - Header/footer page numbering artifacts ("Page 1 of 12")
 */

export function normalizeContractText(rawText: string, options: { preserveParagraphs?: boolean } = {}): string {
  if (!rawText) return '';

  let text = rawText;

  // 1. Normalize line endings
  text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // 2. Remove invisible zero-width characters & non-breaking spaces
  text = text.replace(/[\u200B-\u200D\uFEFF]/g, '');
  text = text.replace(/[\u00A0\u1680\u180e\u2000-\u200a\u202f\u205f\u3000]/g, ' ');

  // 3. Normalize smart quotes, dashes, and typography to standard ASCII
  text = text
    .replace(/[\u201C\u201D\u201E\u201F\u00AB\u00BB]/g, '"') // smart double quotes
    .replace(/[\u2018\u2019\u201A\u201B\u2032\u2035]/g, "'") // smart single quotes / apostrophes
    .replace(/[\u2013\u2014\u2015\u2212]/g, '-') // en-dash, em-dash, minus
    .replace(/\u2026/g, '...') // ellipsis
    .replace(/[\u00AD]/g, ''); // soft hyphen

  // 4. Strip common PDF header/footer artifacts
  text = text.replace(/\n\s*Page\s+\d+\s*(?:of|\/)\s*\d+\s*\n/gi, '\n\n');
  text = text.replace(/\n\s*Page\s+\d+\s*\n/gi, '\n\n');
  text = text.replace(/\n\s*-\s*\d+\s*-\s*\n/g, '\n\n');
  text = text.replace(/\n\s*CONFIDENTIAL\s*\n/gi, '\n\n');

  // 5. Fix hyphenation across line breaks (e.g. "liabil-\n  ity" -> "liability")
  text = text.replace(/(\b[a-zA-Z]{2,})-\s*\n\s*([a-zA-Z]{2,}\b)/g, '$1$2');

  // 6. Fix PDF soft line wraps inside paragraphs
  // When a line ends with a word/comma (not a full stop, colon, section header, or blank line)
  // and the next line starts with lowercase or continuation text, join them with a space.
  const lines = text.split('\n');
  const normalizedLines: string[] = [];

  let currentPara = '';

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    if (!line) {
      if (currentPara) {
        normalizedLines.push(currentPara);
        currentPara = '';
      }
      continue;
    }

    // Check if this line is a formal Section / Numbered Header or Bullet
    const isHeader = /^(?:SECTION\s+\d+|ARTICLE\s+\d+|CLAUSE\s+\d+|SCHEDULE|EXHIBIT|\d+\.\d+|\d+\.)/i.test(line);
    const isBullet = /^[-*•]\s+/.test(line);
    const isAllCapsShort = /^[A-Z\s\d.:_-]{4,40}$/.test(line) && line === line.toUpperCase();

    if (isHeader || isBullet || isAllCapsShort) {
      if (currentPara) {
        normalizedLines.push(currentPara);
        currentPara = '';
      }
      normalizedLines.push(line);
      continue;
    }

    if (!currentPara) {
      currentPara = line;
    } else {
      // Check if previous currentPara ends with a hard sentence terminator or colon
      const lastChar = currentPara.slice(-1);
      const seemsCompleteSentence = ['.', ':', ';', '!', '?'].includes(lastChar) && /^[A-Z]/.test(line);

      if (seemsCompleteSentence) {
        normalizedLines.push(currentPara);
        currentPara = line;
      } else {
        // Join smoothly with space
        currentPara += ' ' + line;
      }
    }
  }

  if (currentPara) {
    normalizedLines.push(currentPara);
  }

  text = normalizedLines.join('\n\n');

  // 7. Collapse multiple spaces within each line
  text = text
    .split('\n')
    .map(l => l.replace(/[ \t]+/g, ' ').trim())
    .join('\n');

  // 8. Normalize multiple blank lines to double newlines
  text = text.replace(/\n{3,}/g, '\n\n').trim();

  return text;
}

/**
 * Compares two strings word-by-word ignoring case and punctuation to determine semantic equality.
 */
export function areTextsSubstantivelyEqual(textA: string, textB: string): boolean {
  const normA = normalizeContractText(textA).toLowerCase().replace(/[^\w\d]/g, '');
  const normB = normalizeContractText(textB).toLowerCase().replace(/[^\w\d]/g, '');
  return normA === normB;
}
