import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } from 'docx';
import { saveAs } from 'file-saver';
import { VettingIssue } from '../types';

export interface ExportWordOptions {
  fileName?: string;
  contractTitle?: string;
  contractType?: string;
  country?: string;
  contractContent: string;
  appliedIssues?: VettingIssue[];
  allIssues?: VettingIssue[];
  overallScore?: number;
}

export async function exportContractToWordDoc({
  fileName = 'Vetted_Contract_Draft.docx',
  contractTitle = 'Institutional Contract Draft',
  contractType = 'Commercial Agreement',
  country = 'United States',
  contractContent,
  appliedIssues = [],
  allIssues = [],
  overallScore = 35
}: ExportWordOptions): Promise<void> {
  const paragraphs: Paragraph[] = [];

  // Header Title
  paragraphs.push(
    new Paragraph({
      text: contractTitle.toUpperCase(),
      heading: HeadingLevel.TITLE,
      alignment: AlignmentType.CENTER,
      spacing: { after: 120 }
    })
  );

  // Subtitle / Metadata badge section
  paragraphs.push(
    new Paragraph({
      children: [
        new TextRun({
          text: `Jurisdiction: ${country} | Type: ${contractType} | Risk Score: ${overallScore}/100`,
          italics: true,
          size: 20, // 10pt
          color: '555555'
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: 240 }
    })
  );

  // Remediation Audit Log / Changes Accepted Summary
  if (appliedIssues.length > 0) {
    paragraphs.push(
      new Paragraph({
        text: 'AI LEGAL VETTING & REMEDIATION LOG (ACCEPTED CHANGES)',
        heading: HeadingLevel.HEADING_2,
        spacing: { before: 200, after: 120 }
      })
    );

    paragraphs.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `This draft incorporates ${appliedIssues.length} accepted countermeasure(s) negotiated for legal protection:`,
            italics: true,
            color: '333333'
          })
        ],
        spacing: { after: 120 }
      })
    );

    appliedIssues.forEach((issue, index) => {
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `${index + 1}. [${issue.riskLevel.toUpperCase()}] ${issue.clauseTitle}: `,
              bold: true,
              color: issue.riskLevel === 'critical' ? '990000' : issue.riskLevel === 'high' ? 'CC6600' : '006633'
            }),
            new TextRun({
              text: issue.issue + ' ',
              italics: true
            }),
            new TextRun({
              text: issue.legalPrinciple ? `(Principle: ${issue.legalPrinciple})` : ''
            })
          ],
          bullet: { level: 0 },
          spacing: { after: 80 }
        })
      );
    });

    paragraphs.push(
      new Paragraph({
        text: '----------------------------------------------------------------------------------------------------',
        alignment: AlignmentType.CENTER,
        spacing: { before: 160, after: 240 }
      })
    );
  }

  // Contract Body Text Processing
  const lines = contractContent.split('\n');

  for (const rawLine of lines) {
    const line = rawLine.trim();

    if (!line) {
      // Empty line spacing
      paragraphs.push(
        new Paragraph({
          text: '',
          spacing: { after: 100 }
        })
      );
      continue;
    }

    // Check if line is a major Section / Article Heading
    const isSectionHeading = /^(SECTION\s+\d+|ARTICLE\s+\d+|CLAUSE\s+\d+|PREAMBLE|RECITALS|SCHEDULE|EXHIBIT\s+[A-Z])/i.test(line);
    const isNumberedHeading = /^\d+\.\s+[A-Z\s]{4,}/.test(line);

    if (isSectionHeading || isNumberedHeading) {
      paragraphs.push(
        new Paragraph({
          text: line,
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 240, after: 120 }
        })
      );
    } else if (/^[A-Z\s]{4,}:?$/.test(line) && line.length < 50) {
      // Sub-heading
      paragraphs.push(
        new Paragraph({
          text: line,
          heading: HeadingLevel.HEADING_3,
          spacing: { before: 180, after: 80 }
        })
      );
    } else {
      // Standard paragraph text
      paragraphs.push(
        new Paragraph({
          children: [
            new TextRun({
              text: rawLine,
              size: 22 // 11pt
            })
          ],
          spacing: { after: 120, line: 276 } // 1.15 line spacing
        })
      );
    }
  }

  // Document Footer Disclaimer
  paragraphs.push(
    new Paragraph({
      children: [
        new TextRun({
          text: `\nGenerated & Remediated via AI Legal Vetting & Contract Engineering Studio. Qualified legal counsel review recommended for specific regulatory compliance.`,
          italics: true,
          size: 18,
          color: '888888'
        })
      ],
      spacing: { before: 360, after: 120 }
    })
  );

  const doc = new Document({
    sections: [
      {
        properties: {
          page: {
            margin: {
              top: 1440, // 1 inch (1440 twips)
              right: 1440,
              bottom: 1440,
              left: 1440
            }
          }
        },
        children: paragraphs
      }
    ]
  });

  const blob = await Packer.toBlob(doc);
  const cleanFileName = fileName.endsWith('.docx') ? fileName : `${fileName}.docx`;
  saveAs(blob, cleanFileName);
}
