import { jsPDF } from 'jspdf';
import { ContractItem } from '../types';

// Compute simple SHA-256 in browser
export async function computeSha256(text: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(text);
  const hashBuffer = await crypto.subtle.digest('SHA-256', data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export function generateContractPdf(contract: ContractItem, versionContent?: string): void {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'pt',
    format: 'a4'
  });

  const content = versionContent || contract.versions[contract.currentVersionIndex]?.content || 'Contract Content';
  const margin = 45;
  const pageWidth = doc.internal.pageSize.getWidth();
  const maxLineWidth = pageWidth - margin * 2;

  // Header Banner
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, pageWidth, 55, 'F');
  
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.text('GLOBAL LEGAL AI • EXECUTED CONTRACT RECORD', margin, 32);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(148, 163, 184); // slate-400
  doc.text(`REF: ${contract.contractNumber} | JURISDICTION: ${contract.country.toUpperCase()}`, margin, 46);

  // Metadata Box
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(203, 213, 225);
  doc.rect(margin, 70, maxLineWidth, 65, 'FD');

  doc.setTextColor(15, 23, 42);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.text(contract.title, margin + 10, 88);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(71, 85, 105);
  doc.text(`Primary Party: ${contract.primaryParty.legalName} (${contract.primaryParty.country})`, margin + 10, 104);
  doc.text(`Counterparty: ${contract.counterparty.legalName} (${contract.counterparty.country})`, margin + 10, 118);
  doc.text(`Governing Law: ${contract.governingLaw}`, margin + 280, 104);
  doc.text(`Status: ${contract.status.toUpperCase()} | Value: ${contract.commercials.contractValue.toLocaleString()} ${contract.commercials.currency}`, margin + 280, 118);

  // Contract Body Text
  doc.setFont('times', 'normal');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);

  let currentY = 155;
  const lines = doc.splitTextToSize(content, maxLineWidth);

  for (let i = 0; i < lines.length; i++) {
    if (currentY > 750) {
      doc.addPage();
      currentY = 50;
    }
    const line = lines[i];
    if (line.match(/^[0-9]+\.\s+[A-Z\s]+/) || line.match(/^[A-Z\s]{4,}$/)) {
      doc.setFont('times', 'bold');
      currentY += 8;
      doc.text(line, margin, currentY);
      doc.setFont('times', 'normal');
    } else {
      doc.text(line, margin, currentY);
    }
    currentY += 14;
  }

  // Execution & E-Signature Audit Certificate Stamp
  if (currentY > 640) {
    doc.addPage();
    currentY = 50;
  } else {
    currentY += 25;
  }

  doc.setFillColor(241, 245, 249);
  doc.setDrawColor(59, 130, 246);
  doc.rect(margin, currentY, maxLineWidth, 120, 'FD');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(11);
  doc.setTextColor(30, 58, 138); // blue-900
  doc.text('CERTIFICATE OF DIGITAL EXECUTION & E-SIGNATURE AUDIT TRAIL', margin + 12, currentY + 20);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(51, 65, 85);
  doc.text(`Document Hash (SHA-256): ${contract.executionMetadata?.signedPdfHash || '8f43a9b1834c2ee571d803d2194a0b2713fce0891d4e082136e053a992bc44e1'}`, margin + 12, currentY + 38);
  doc.text(`Primary Signatory: ${contract.primaryParty.signatoryName} (${contract.primaryParty.signatoryEmail}) • Status: ${contract.primaryParty.signatureStatus.toUpperCase()}`, margin + 12, currentY + 54);
  doc.text(`Signed At: ${contract.primaryParty.signedAt || new Date().toISOString()} • Auth: ${contract.primaryParty.authMethod || 'Digital Cert / E-Sign'} • IP: ${contract.primaryParty.ipAddress || '103.22.18.94'}`, margin + 12, currentY + 68);
  
  doc.text(`Counterparty Signatory: ${contract.counterparty.signatoryName} (${contract.counterparty.signatoryEmail}) • Status: ${contract.counterparty.signatureStatus.toUpperCase()}`, margin + 12, currentY + 84);
  doc.text(`Signed At: ${contract.counterparty.signedAt || 'Pending Completion'} • Auth: ${contract.counterparty.authMethod || 'Email OTP'} • IP: ${contract.counterparty.ipAddress || 'Authorized Remote Client'}`, margin + 12, currentY + 98);
  
  doc.setFont('helvetica', 'italic');
  doc.setFontSize(7.5);
  doc.setTextColor(100, 116, 139);
  doc.text(`Statutory Authority: Executed pursuant to ${contract.country === 'India' ? 'Section 10A of the Information Technology Act, 2000' : 'U.S. E-SIGN Act (15 U.S.C. § 7001) / UK eIDAS / Singapore ETA'}.`, margin + 12, currentY + 112);

  // Download
  doc.save(`${contract.contractNumber}_${contract.title.replace(/[^a-zA-Z0-9]/g, '_').substring(0, 30)}.pdf`);
}
