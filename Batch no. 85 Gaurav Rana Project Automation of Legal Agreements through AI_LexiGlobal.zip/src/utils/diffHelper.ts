import { diffLines, diffWords, diffWordsWithSpace, Change } from 'diff';
import { normalizeContractText } from './textNormalizer';

export interface DiffSegment {
  value: string;
  added?: boolean;
  removed?: boolean;
}

export interface DiffOptions {
  normalizeWhitespace?: boolean;
  normalizePunctuation?: boolean;
}

export function computeLineDiff(oldText: string, newText: string, options: DiffOptions = { normalizeWhitespace: true }): DiffSegment[] {
  try {
    const textA = options.normalizeWhitespace ? normalizeContractText(oldText) : oldText;
    const textB = options.normalizeWhitespace ? normalizeContractText(newText) : newText;
    const changes: Change[] = diffLines(textA, textB);
    return changes.map(c => ({
      value: c.value,
      added: c.added,
      removed: c.removed
    }));
  } catch (err) {
    return [
      { value: oldText, removed: true },
      { value: newText, added: true }
    ];
  }
}

export function computeWordDiff(oldText: string, newText: string, options: DiffOptions = { normalizeWhitespace: true }): DiffSegment[] {
  try {
    const textA = options.normalizeWhitespace ? normalizeContractText(oldText) : oldText;
    const textB = options.normalizeWhitespace ? normalizeContractText(newText) : newText;
    
    // diffWords treats whitespace differences as insignificant, comparing words semantically!
    const changes: Change[] = diffWords(textA, textB);
    return changes.map(c => ({
      value: c.value,
      added: c.added,
      removed: c.removed
    }));
  } catch (err) {
    return [
      { value: oldText, removed: true },
      { value: newText, added: true }
    ];
  }
}

/**
 * Returns true if the two texts have substantive differences after normalization.
 */
export function hasSubstantiveDifferences(textA: string, textB: string): boolean {
  const normA = normalizeContractText(textA);
  const normB = normalizeContractText(textB);
  if (normA === normB) return false;
  
  const segments = computeWordDiff(normA, normB);
  return segments.some(s => s.added || s.removed);
}
