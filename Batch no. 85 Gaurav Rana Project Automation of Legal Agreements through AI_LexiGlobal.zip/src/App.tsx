import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { TopHeader } from './components/TopHeader';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { DashboardView } from './components/DashboardView';
import { DraftingWizardView } from './components/DraftingWizardView';
import { VettingStudioView } from './components/VettingStudioView';
import { RedlineComparisonView } from './components/RedlineComparisonView';
import { ClauseLibraryView } from './components/ClauseLibraryView';
import { RepositoryView } from './components/RepositoryView';
import { ApprovalWorkflowView } from './components/ApprovalWorkflowView';
import { ESignatureStudioView } from './components/ESignatureStudioView';
import { DistributionCenterView } from './components/DistributionCenterView';
import { KnowledgeBaseAdminView } from './components/KnowledgeBaseAdminView';
import { AuditTrailView } from './components/AuditTrailView';
import { ContractDetailModal } from './components/ContractDetailModal';
import { NaturalSearchModal } from './components/NaturalSearchModal';
import { INITIAL_CONTRACTS } from './data/initialContracts';
import { ContractItem, UserRole, VettingIssue, ApprovalStep } from './types';
import { ThemeProvider, useTheme } from './context/ThemeContext';
import { 
  subscribeToContracts, 
  saveContractToCloud, 
  updateContractInCloud 
} from './services/contractDbService';

function MainApp() {
  const { theme } = useTheme();
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [userRole, setUserRole] = useState<UserRole>('legal');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');
  
  // Master Contracts State
  const [contracts, setContracts] = useState<ContractItem[]>(INITIAL_CONTRACTS);
  const [isDbConnected, setIsDbConnected] = useState<boolean>(false);
  const [selectedContractForModal, setSelectedContractForModal] = useState<ContractItem | null>(null);
  const [activeWorkflowContract, setActiveWorkflowContract] = useState<ContractItem | null>(INITIAL_CONTRACTS[0]);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(false);

  // Natural Language Search Modal
  const [isSearchModalOpen, setIsSearchModalOpen] = useState<boolean>(false);

  // Real-time Cloud Database Synchronization
  useEffect(() => {
    const unsubscribe = subscribeToContracts(
      (cloudContracts, isConnected) => {
        if (cloudContracts && cloudContracts.length > 0) {
          setContracts(cloudContracts);
          setActiveWorkflowContract(prev => {
            if (!prev) return cloudContracts[0];
            const match = cloudContracts.find(c => c.id === prev.id);
            return match || cloudContracts[0];
          });
        }
        setIsDbConnected(isConnected);
      },
      (err) => {
        console.warn('[App] Firestore connection error:', err?.message || err);
        setIsDbConnected(false);
      }
    );

    return () => unsubscribe();
  }, []);

  // Keyboard shortcut ⌘K / Ctrl+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Filtered Contracts by Country if set
  const visibleContracts = selectedCountry === 'ALL'
    ? contracts
    : contracts.filter(c => (c.country || '').toLowerCase() === (selectedCountry || '').toLowerCase());

  // Handlers for cross-module transitions with Cloud DB persistence
  const handleContractCreated = (newContract: ContractItem) => {
    setContracts(prev => [newContract, ...prev.filter(c => c.id !== newContract.id)]);
    setActiveWorkflowContract(newContract);
    // Persist immediately in Firestore cloud database
    saveContractToCloud(newContract).catch(err => {
      console.warn('[Cloud Database] Notice saving new contract to Firestore:', err);
    });
  };

  const handleUpdateContractVetting = (contractId: string, issues: VettingIssue[], riskScore: number) => {
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        return {
          ...c,
          vettingIssues: issues,
          riskBreakdown: {
            ...c.riskBreakdown,
            overallScore: riskScore
          }
        };
      }
      return c;
    }));

    // Persist vetting updates in Firestore
    updateContractInCloud(contractId, {
      vettingIssues: issues,
      riskBreakdown: {
        overallScore: riskScore,
        legalScore: Math.max(0, 100 - riskScore),
        financialScore: Math.max(0, 100 - riskScore),
        operationalScore: Math.max(0, 100 - riskScore),
        complianceScore: Math.max(0, 100 - riskScore),
        reputationalScore: Math.max(0, 100 - riskScore)
      } as any
    }, 'VETTING_ANALYSIS_COMPLETED').catch(err => {
      console.warn('[Cloud Database] Notice updating vetting in Firestore:', err);
    });
  };

  const handleUpdateContractApprovals = (contractId: string, steps: ApprovalStep[]) => {
    const allApproved = steps.every(s => s.status === 'approved');
    setContracts(prev => prev.map(c => {
      if (c.id === contractId) {
        return {
          ...c,
          approvals: steps,
          status: allApproved ? 'approved' : c.status
        };
      }
      return c;
    }));

    // Persist approvals in Firestore
    updateContractInCloud(contractId, {
      approvals: steps,
      status: allApproved ? 'approved' : 'legal_review'
    }, 'APPROVALS_UPDATED').catch(err => {
      console.warn('[Cloud Database] Notice updating approvals in Firestore:', err);
    });
  };

  const handleContractExecuted = (executedContract: ContractItem) => {
    setContracts(prev => prev.map(c => c.id === executedContract.id ? executedContract : c));
    setActiveWorkflowContract(executedContract);

    // Persist execution & signatures in Firestore
    saveContractToCloud(executedContract).catch(err => {
      console.warn('[Cloud Database] Notice saving executed contract in Firestore:', err);
    });
  };

  const pendingApprovalsCount = contracts.filter(c => c.status === 'in_approval' || (c.approvals && c.approvals.some(a => a.status === 'pending'))).length;
  const highRiskCount = contracts.filter(c => c.riskBreakdown && c.riskBreakdown.overallScore >= 70).length;

  return (
    <div 
      id="lexiglobal-app-root" 
      data-theme={theme}
      className={`h-screen w-full bg-[#09090b] text-zinc-100 flex overflow-hidden font-sans selection:bg-emerald-600 selection:text-white antialiased relative transition-colors duration-200 theme-${theme}`}
    >
      {/* Subtle Background Glow Accent for Bento Theme */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_80%_80%_at_50%_-20%,rgba(16,185,129,0.08),rgba(255,255,255,0))] pointer-events-none z-0" />

      {/* Frozen Left Vertical Navigation Sidebar */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={() => setIsSidebarCollapsed(prev => !prev)}
        onStartDrafting={() => setActiveTab('drafting')}
        userRole={userRole}
        pendingApprovalsCount={pendingApprovalsCount}
        highRiskCount={highRiskCount}
      />

      {/* Main Right Content Layout (Frozen Sidebar + Independent Scrollable Screen Side-by-Side) */}
      <div className="flex-1 flex flex-col h-screen overflow-y-auto min-w-0 relative z-10">
        {/* Mandatory Legal Disclaimer Banner */}
        <DisclaimerBanner />

        {/* Global Top Control Header */}
        <TopHeader
          activeTab={activeTab}
          userRole={userRole}
          setUserRole={setUserRole}
          selectedCountry={selectedCountry}
          setSelectedCountry={setSelectedCountry}
          onOpenNaturalSearch={() => setIsSearchModalOpen(true)}
          isSidebarCollapsed={isSidebarCollapsed}
          onToggleSidebarCollapse={() => setIsSidebarCollapsed(prev => !prev)}
          onStartDrafting={() => setActiveTab('drafting')}
          isDbConnected={isDbConnected}
        />

        {/* Main App Content View Switcher */}
        <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-16">
        
        {activeTab === 'dashboard' && (
          <DashboardView
            contracts={visibleContracts}
            onSelectContract={(c) => setSelectedContractForModal(c)}
            onStartDrafting={() => setActiveTab('drafting')}
            onStartVetting={() => {
              setActiveWorkflowContract(visibleContracts[0] || null);
              setActiveTab('vetting');
            }}
            onStartRedline={() => setActiveTab('redline')}
            onStartSigning={() => {
              setActiveWorkflowContract(visibleContracts[0] || null);
              setActiveTab('esignature');
            }}
          />
        )}

        {activeTab === 'drafting' && (
          <DraftingWizardView
            onContractCreated={handleContractCreated}
            onNavigateToVetting={(c) => {
              setActiveWorkflowContract(c);
              setActiveTab('vetting');
            }}
            onNavigateToSigning={(c) => {
              setActiveWorkflowContract(c);
              setActiveTab('esignature');
            }}
            onNavigateToRepository={() => setActiveTab('repository')}
          />
        )}

        {activeTab === 'vetting' && (
          <VettingStudioView
            contracts={visibleContracts}
            activeContract={activeWorkflowContract}
            onUpdateContractVetting={handleUpdateContractVetting}
          />
        )}

        {activeTab === 'redline' && (
          <RedlineComparisonView
            contracts={visibleContracts}
          />
        )}

        {activeTab === 'clauses' && (
          <ClauseLibraryView />
        )}

        {activeTab === 'repository' && (
          <RepositoryView
            contracts={visibleContracts}
            userRole={userRole}
            onSelectContract={(c) => setSelectedContractForModal(c)}
            onStartDrafting={() => setActiveTab('drafting')}
            onNavigateToSigning={(c) => {
              setActiveWorkflowContract(c);
              setActiveTab('esignature');
            }}
            onNavigateToVetting={(c) => {
              setActiveWorkflowContract(c);
              setActiveTab('vetting');
            }}
          />
        )}

        {activeTab === 'approvals' && (
          <ApprovalWorkflowView
            contracts={visibleContracts}
            userRole={userRole}
            onUpdateContractApprovals={handleUpdateContractApprovals}
          />
        )}

        {activeTab === 'esignature' && (
          <ESignatureStudioView
            contracts={visibleContracts}
            activeContract={activeWorkflowContract}
            onContractExecuted={handleContractExecuted}
            onNavigateToDistribution={(c) => {
              setActiveWorkflowContract(c);
              setActiveTab('distribution');
            }}
          />
        )}

        {activeTab === 'distribution' && (
          <DistributionCenterView
            contracts={visibleContracts}
            activeContract={activeWorkflowContract}
          />
        )}

        {activeTab === 'knowledge' && (
          <KnowledgeBaseAdminView />
        )}

        {activeTab === 'audit' && (
          <AuditTrailView />
        )}

      </main>
      </div>

      {/* Contract Details & History Modal */}
      <ContractDetailModal
        contract={selectedContractForModal}
        onClose={() => setSelectedContractForModal(null)}
        onNavigateToVetting={(c) => {
          setActiveWorkflowContract(c);
          setActiveTab('vetting');
        }}
        onNavigateToSigning={(c) => {
          setActiveWorkflowContract(c);
          setActiveTab('esignature');
        }}
      />

      {/* Global Natural Language Search Modal */}
      <NaturalSearchModal
        isOpen={isSearchModalOpen}
        onClose={() => setIsSearchModalOpen(false)}
        contracts={contracts}
        onSelectContract={(c) => {
          setSelectedContractForModal(c);
        }}
      />

    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <MainApp />
    </ThemeProvider>
  );
}
