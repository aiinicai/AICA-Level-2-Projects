import { 
  collection, 
  doc, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot, 
  addDoc
} from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ContractItem } from '../types';
import { INITIAL_CONTRACTS } from '../data/initialContracts';

function sanitizeForFirestore(obj: any): any {
  if (obj === undefined) return null;
  if (obj === null) return null;
  if (Array.isArray(obj)) {
    return obj.map(item => sanitizeForFirestore(item));
  }
  if (typeof obj === 'object') {
    const cleaned: Record<string, any> = {};
    for (const [key, value] of Object.entries(obj)) {
      if (value !== undefined) {
        cleaned[key] = sanitizeForFirestore(value);
      }
    }
    return cleaned;
  }
  return obj;
}

export const CONTRACTS_COLLECTION = 'contracts';
export const AUDIT_COLLECTION = 'auditLogs';

/**
 * Subscribes to real-time updates from Firebase Firestore.
 * Automatically bootstraps and seeds the database if empty on first launch.
 */
export function subscribeToContracts(
  onData: (contracts: ContractItem[], isConnected: boolean) => void,
  onError?: (err: Error) => void
): () => void {
  const colRef = collection(db, CONTRACTS_COLLECTION);

  const unsubscribe = onSnapshot(
    colRef,
    async (snapshot) => {
      if (snapshot.empty) {
        // First-time database initialization: seed standard institutional contracts
        try {
          console.log('[Firestore] Database is empty. Seeding initial contracts into Firestore...');
          for (const c of INITIAL_CONTRACTS) {
            await setDoc(doc(db, CONTRACTS_COLLECTION, c.id), sanitizeForFirestore(c));
          }
          onData(INITIAL_CONTRACTS, true);
        } catch (seedErr) {
          console.warn('[Firestore] Error during initial database seed:', seedErr);
          onData(INITIAL_CONTRACTS, false);
        }
      } else {
        const loadedContracts: ContractItem[] = [];
        snapshot.forEach((docSnap) => {
          loadedContracts.push(docSnap.data() as ContractItem);
        });
        // Sort with most recently modified first
        loadedContracts.sort((a, b) => {
          const tA = a.lastModifiedDate || a.createdDate || '';
          const tB = b.lastModifiedDate || b.createdDate || '';
          return tB.localeCompare(tA);
        });
        onData(loadedContracts, true);
      }
    },
    (err) => {
      console.warn('[Firestore] Real-time database subscription fallback:', err?.message || err);
      onData(INITIAL_CONTRACTS, false);
      if (onError) onError(err);
    }
  );

  return unsubscribe;
}

/**
 * Persists a new or updated contract document into Firestore
 */
export async function saveContractToCloud(contract: ContractItem): Promise<void> {
  try {
    const docRef = doc(db, CONTRACTS_COLLECTION, contract.id);
    await setDoc(docRef, sanitizeForFirestore({
      ...contract,
      lastModifiedDate: new Date().toISOString()
    }), { merge: true });

    // Record audit event
    await addDoc(collection(db, AUDIT_COLLECTION), {
      contractId: contract.id,
      contractTitle: contract.title,
      action: 'CONTRACT_CREATED_OR_SAVED',
      performedBy: 'Legal Counsel',
      timestamp: new Date().toISOString(),
      details: `Saved in Firestore database (${contract.contractType || 'Agreement'})`
    }).catch(err => console.warn('[Firestore AuditLog] Audit write note:', err));
  } catch (err) {
    console.error('[Firestore] Error saving contract to cloud database:', err);
    throw err;
  }
}

/**
 * Updates specific fields of an existing contract in Firestore
 */
export async function updateContractInCloud(
  contractId: string, 
  updates: Partial<ContractItem>, 
  actionName?: string
): Promise<void> {
  try {
    const docRef = doc(db, CONTRACTS_COLLECTION, contractId);
    await updateDoc(docRef, sanitizeForFirestore({
      ...updates,
      lastModifiedDate: new Date().toISOString()
    }));

    if (actionName) {
      await addDoc(collection(db, AUDIT_COLLECTION), {
        contractId,
        action: actionName,
        performedBy: 'Legal System',
        timestamp: new Date().toISOString(),
        details: `Updated in Firestore: ${actionName}`
      }).catch(err => console.warn('[Firestore AuditLog] Audit write note:', err));
    }
  } catch (err) {
    console.error('[Firestore] Error updating contract in cloud database:', err);
    throw err;
  }
}

/**
 * Deletes a contract from Firestore
 */
export async function deleteContractFromCloud(contractId: string): Promise<void> {
  try {
    const docRef = doc(db, CONTRACTS_COLLECTION, contractId);
    await deleteDoc(docRef);

    await addDoc(collection(db, AUDIT_COLLECTION), {
      contractId,
      action: 'CONTRACT_DELETED',
      performedBy: 'Authorized Admin',
      timestamp: new Date().toISOString(),
      details: 'Deleted from Firestore database'
    }).catch(err => console.warn('[Firestore AuditLog] Audit write note:', err));
  } catch (err) {
    console.error('[Firestore] Error deleting contract from cloud database:', err);
    throw err;
  }
}
