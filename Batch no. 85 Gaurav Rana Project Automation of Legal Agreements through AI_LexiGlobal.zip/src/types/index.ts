export type AppTheme = 'dark' | 'light' | 'parchment' | 'navy';

export type RiskLevel = 'critical' | 'high' | 'medium' | 'low' | 'informational';

export type ContractStatus = 
  | 'draft'
  | 'ai_review'
  | 'legal_review'
  | 'business_review'
  | 'negotiation'
  | 'approved'
  | 'sent_for_signature'
  | 'partially_signed'
  | 'fully_executed'
  | 'active'
  | 'expiring_soon'
  | 'expired'
  | 'terminated'
  | 'archived';

export type UserRole = 
  | 'admin'
  | 'legal'
  | 'finance'
  | 'procurement'
  | 'hr'
  | 'business'
  | 'management'
  | 'external_signer';

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  department: string;
  organization: string;
  avatar?: string;
}

export interface JurisdictionConfig {
  countryCode: string;
  countryName: string;
  statesOrProvinces?: string[];
  defaultGoverningLaw: string;
  arbitrationInstitutions: { name: string; city: string; rules: string }[];
  eSignatureStatute: string;
  mandatoryClauses: string[];
  restrictedClauses: string[];
  keyRegulations: string[];
  currency: string;
  currencySymbol: string;
  notes: string;
}

export interface ContractParty {
  id: string;
  role: 'primary_party' | 'counterparty' | 'guarantor' | 'agent';
  legalName: string;
  entityType: 'Corporation' | 'LLC' | 'Private Limited' | 'Partnership' | 'Sole Proprietorship' | 'Individual' | 'Public Limited';
  registrationNumber: string;
  registeredAddress: string;
  country: string;
  taxId: string;
  signatoryName: string;
  signatoryDesignation: string;
  signatoryEmail: string;
  signatoryPhone?: string;
  signatureStatus: 'pending' | 'signed' | 'declined';
  signedAt?: string;
  signatureDataUrl?: string;
  authMethod?: 'email_otp' | 'sms_otp' | 'digital_cert' | 'aadhaar_esign' | 'biometric';
  ipAddress?: string;
}

export interface CommercialTerms {
  contractValue: number;
  currency: string;
  pricingModel: 'fixed_fee' | 'hourly_rate' | 'milestone_based' | 'retainer' | 'revenue_share' | 'subscription';
  paymentFrequency: 'monthly' | 'quarterly' | 'annually' | 'on_delivery' | 'milestone_triggered';
  paymentDueDays: number;
  taxTreatment: string;
  latePaymentInterestRate: number;
  expensesReimbursable: boolean;
  retainerAmount?: number;
}

export interface RiskLiabilityConfig {
  liabilityCapType: 'fixed_amount' | 'multiplier_annual_value' | 'unlimited' | 'fees_paid_12_months';
  liabilityCapAmount?: number;
  liabilityCapMultiplier?: number;
  hasUncappedExceptions: boolean; // IP infringement, gross negligence, confidentiality breach
  uncappedExceptionsList: string[];
  indemnificationScope: 'mutual' | 'company_only' | 'counterparty_only' | 'ip_only';
  insuranceRequirement: boolean;
  insuranceCoverageAmount?: number;
  consequentialDamagesExcluded: boolean;
  liquidatedDamages: boolean;
  liquidatedDamagesDetails?: string;
}

export interface ClauseIntelligenceItem {
  id: string;
  clauseName: string;
  category: string;
  jurisdiction: string;
  standardWording: string;
  companyFriendlyWording: string;
  counterpartyFriendlyWording: string;
  fallbackWording?: string;
  riskLevel: RiskLevel;
  explanation: string;
  legalSource: string;
  industryBenchmarkRange: string;
  lastUpdated: string;
}

export interface VettingIssue {
  id: string;
  clauseTitle: string;
  originalText: string;
  issue: string;
  riskLevel: RiskLevel;
  legalPrinciple: string;
  businessImpact: string;
  companyPosition: 'favourable' | 'neutral' | 'unfavourable' | 'highly_unfavourable' | 'missing_protection';
  suggestedWording: string;
  negotiationPriority: 'high' | 'medium' | 'low';
  lawyerReviewRequired: boolean;
  legalSourceCitation?: {
    statute: string;
    jurisdiction: string;
    section?: string;
    confidence: number;
    lastVerified: string;
  };
}

export interface RedlineChange {
  id: string;
  clauseIndex: number;
  clauseTitle: string;
  changeType: 'added' | 'deleted' | 'modified' | 'commercial_change' | 'liability_change';
  previousText: string;
  revisedText: string;
  diffSummary: string;
  whatChanged: string;
  whyItMatters: string;
  whoBenefits: 'My Company' | 'Counterparty' | 'Neutral' | 'Material Risk';
  riskScoreDelta: number;
  aiRecommendation: 'Accept' | 'Reject' | 'Negotiate' | 'Legal Review Required';
  plainEnglishExplanation: string;
  negotiationTactic?: string;
}

export interface ContractDocumentVersion {
  versionNumber: string;
  createdAt: string;
  createdBy: string;
  content: string;
  changeLog: string;
  isAiGenerated: boolean;
  isLocked: boolean;
}

export interface ApprovalStep {
  id: string;
  stepName: string;
  roleRequired: UserRole;
  assignedUserEmail: string;
  status: 'pending' | 'approved' | 'rejected' | 'skipped' | 'revision_requested';
  actionDate?: string;
  actionTimestamp?: string;
  comments?: string;
  thresholdCondition?: string;
}

export interface ContractRiskBreakdown {
  overallScore: number; // 0 - 100
  financialRisk: number;
  legalRisk: number;
  complianceRisk: number;
  dataRisk: number;
  operationalRisk: number;
  keyRiskFactors: string[];
  positiveProtections: string[];
}

export interface ClauseBenchmark {
  id: string;
  name: string;
  clauseName?: string;
  category: string;
  jurisdiction?: string;
  description: string;
  marketStandard: string;
  companyFriendly: string;
  counterpartyFriendly: string;
  recommendedCompromise?: string;
  benchmarkRange?: string;
  jurisdictionVariations?: Record<string, string>;
  standardWording?: string;
  companyFriendlyWording?: string;
  counterpartyFriendlyWording?: string;
  fallbackWording?: string;
  riskLevel?: RiskLevel;
  explanation?: string;
  legalSource?: string;
  industryBenchmarkRange?: string;
  lastUpdated?: string;
}

export interface LegalRuleKeySection {
  section: string;
  title: string;
  text: string;
}

export interface BareActSection {
  sectionNumber: string;
  sectionTitle: string;
  verbatimText: string;
  subSections?: string[];
  provisos?: string[];
  explanations?: string[];
}

export interface BareActChapter {
  chapterNumber: string;
  chapterTitle: string;
  sections: BareActSection[];
}

export interface BareActData {
  officialActNumberAndYear: string;
  preamble: string;
  enactmentDate?: string;
  officialGazetteCitation?: string;
  totalSectionsCount?: number;
  arrangementOfSections?: { section: string; title: string }[];
  chapters: BareActChapter[];
  schedules?: {
    scheduleNumber: string;
    scheduleTitle: string;
    content: string;
  }[];
  fullVerbatimText?: string;
}

export interface LegalRule {
  id: string;
  country: string;
  stateOrProvince?: string;
  jurisdiction?: string;
  subjectArea: 'liability' | 'data_privacy' | 'ip' | 'dispute_resolution' | 'e_signature' | 'employment' | 'taxation' | 'corporate_governance';
  ruleName: string;
  fullActTitle?: string;
  actSummary?: string;
  statutoryCitation: string;
  legalRequirement: string;
  officialUrl?: string;
  keySections?: LegalRuleKeySection[];
  bareAct?: BareActData;
  bareActText?: string;
  mandatoryProvisions?: string[];
  restrictedProvisions?: string[];
  recommendedWording?: string;
  contractTypesAppliedTo?: string[];
  isMandatory: boolean;
  confidenceScore: number;
  lastVerifiedDate: string;
  verificationStatus: 'verified' | 'under_review' | 'outdated' | 'superseded';
  reviewerCredentials: string;
  effectiveDate?: string;
  enforcingAuthority?: string;
  penaltiesForNonCompliance?: string;
}

export interface ContractItem {
  id: string;
  contractNumber: string;
  title: string;
  contractType: string;
  category: 'commercial' | 'ip_confidentiality' | 'employment' | 'corporate' | 'real_estate' | 'procurement';
  country: string;
  stateOrRegion?: string;
  governingLaw: string;
  disputeForum: string;
  arbitrationSeat?: string;
  status: ContractStatus;
  primaryParty: ContractParty;
  counterparty: ContractParty;
  commercials: CommercialTerms;
  riskLiability: RiskLiabilityConfig;
  startDate: string;
  endDate: string;
  renewalNoticeDays: number;
  autoRenew: boolean;
  riskBreakdown: ContractRiskBreakdown;
  versions: ContractDocumentVersion[];
  currentVersionIndex: number;
  approvals: ApprovalStep[];
  vettingIssues: VettingIssue[];
  createdDate: string;
  lastModifiedDate: string;
  contractOwner: string;
  department: string;
  tags: string[];
  executionMetadata?: {
    signedPdfHash?: string;
    certificateId?: string;
    completedAt?: string;
    sentToEmails?: string[];
  };
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: 'login' | 'create_draft' | 'upload_document' | 'ai_vetting' | 'compare_redline' | 'clause_edit' | 'approve' | 'reject' | 'send_signature' | 'sign_document' | 'export_pdf' | 'email_distribution' | 'knowledge_update';
  contractId?: string;
  contractTitle?: string;
  details: string;
  ipAddress: string;
  severity: 'info' | 'warning' | 'security' | 'critical';
}

export interface DetailedClause {
  id: string;
  sectionNumber: string;
  title: string;
  category: 'operational' | 'commercial' | 'ip_data' | 'risk_liability' | 'compliance' | 'governance' | 'boilerplate' | 'dispute';
  summary: string;
  fullLegalText: string;
  jurisdictionNotes?: string;
  standardBenchmark: 'Market Standard' | 'Aggressive / Company-Favorable' | 'Balanced / Neutral';
  isMandatory: boolean;
}

export interface LegalKnowledgeRule {
  id: string;
  country: string;
  jurisdiction: string;
  lawName: string;
  regulationCategory: 'Contract Law' | 'Data Protection' | 'Employment' | 'Arbitration' | 'Tax & Withholding' | 'E-Signatures' | 'IP Law' | 'Anti-Bribery';
  effectiveDate: string;
  mandatoryProvisions: string[];
  restrictedProvisions: string[];
  recommendedWording: string;
  statutorySource: string;
  urlReference: string;
  status: 'Verified' | 'Under Review' | 'Outdated' | 'Superseded';
  lastVerifiedDate: string;
  confidenceScore: number;
  reviewedBy: string;
}
