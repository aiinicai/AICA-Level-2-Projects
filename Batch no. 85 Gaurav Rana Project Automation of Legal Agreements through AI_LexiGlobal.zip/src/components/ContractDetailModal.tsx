import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileText, 
  Globe2, 
  DollarSign, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  PenTool, 
  Send, 
  History, 
  Copy, 
  Check, 
  Share2, 
  ExternalLink,
  Scale
} from 'lucide-react';
import { ContractItem } from '../types';
import { generateContractPdf } from '../utils/pdfExport';

interface ContractDetailModalProps {
  contract: ContractItem | null;
  onClose: () => void;
  onNavigateToVetting: (contract: ContractItem) => void;
  onNavigateToSigning: (contract: ContractItem) => void;
}

export const ContractDetailModal: React.FC<ContractDetailModalProps> = ({
  contract,
  onClose,
  onNavigateToVetting,
  onNavigateToSigning
}) => {
  if (!contract) return null;

  const [activeTab, setActiveTab] = useState<'content' | 'metadata' | 'approvals' | 'history'>('content');
  const [copied, setCopied] = useState(false);
  const currentVersion = contract.versions[contract.currentVersionIndex] || contract.versions[0];

  const handleCopyContent = () => {
    navigator.clipboard.writeText(currentVersion?.content || '');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div id="contract-detail-modal" className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#121215]/95 border border-white/[0.08] rounded-3xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden bento-glow-cyan">
        
        {/* Modal Header */}
        <div className="p-6 border-b border-white/[0.06] flex items-start justify-between gap-4 bg-zinc-950/60">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-xs font-bold text-emerald-400">{contract.contractNumber}</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-zinc-800 text-zinc-300 uppercase border border-zinc-700">
                {contract.status.replace(/_/g, ' ')}
              </span>
              <span className="text-xs text-zinc-400 flex items-center gap-1">
                <Globe2 className="w-3.5 h-3.5 text-cyan-400" />
                {contract.country}
              </span>
            </div>
            <h2 className="text-xl font-bold text-white mt-1.5 font-sans">{contract.title}</h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => generateContractPdf(contract)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-semibold border border-white/[0.08] transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </button>
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center font-bold border border-white/[0.08] transition-all"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Navigation Sub-Tabs */}
        <div className="flex items-center gap-2 px-6 pt-3 border-b border-white/[0.06] bg-[#121215]">
          {[
            { id: 'content', label: 'Agreement Text' },
            { id: 'metadata', label: 'Parties & Commercials' },
            { id: 'approvals', label: 'Approval Pipeline' },
            { id: 'history', label: `Versions (${contract.versions.length})` }
          ].map(t => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`px-3.5 py-2 text-xs font-medium border-b-2 transition-all ${
                activeTab === t.id
                  ? 'border-emerald-500 text-emerald-400 font-semibold'
                  : 'border-transparent text-zinc-400 hover:text-zinc-200'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto flex-1 space-y-4">
          
          {/* TAB 1: Agreement Content */}
          {activeTab === 'content' && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-zinc-400">
                <span>Active Version: <strong className="text-white">{currentVersion?.versionNumber}</strong> • Created by {currentVersion?.createdBy}</span>
                <button
                  onClick={handleCopyContent}
                  className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-semibold transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Text'}</span>
                </button>
              </div>

              <div className="bg-zinc-950 border border-white/[0.06] rounded-2xl p-5 text-xs font-mono text-zinc-300 leading-relaxed max-h-[420px] overflow-y-auto whitespace-pre-wrap">
                {currentVersion?.content}
              </div>
            </div>
          )}

          {/* TAB 2: Metadata, Parties & Commercials */}
          {activeTab === 'metadata' && (
            <div className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] space-y-2">
                  <span className="font-bold text-emerald-400 block">Primary Party (My Company)</span>
                  <div><strong className="text-zinc-400">Legal Name:</strong> {contract.primaryParty.legalName}</div>
                  <div><strong className="text-zinc-400">Entity Type:</strong> {contract.primaryParty.entityType}</div>
                  <div><strong className="text-zinc-400">Tax ID:</strong> {contract.primaryParty.taxId || 'N/A'}</div>
                  <div><strong className="text-zinc-400">Signatory Name:</strong> {contract.primaryParty.signatoryName}</div>
                  <div><strong className="text-zinc-400">Designation:</strong> {contract.primaryParty.signatoryDesignation}</div>
                  <div><strong className="text-zinc-400">Signatory Email:</strong> {contract.primaryParty.signatoryEmail}</div>
                </div>

                <div className="p-4.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] space-y-2">
                  <span className="font-bold text-amber-400 block">Counterparty Details</span>
                  <div><strong className="text-zinc-400">Legal Name:</strong> {contract.counterparty.legalName}</div>
                  <div><strong className="text-zinc-400">Entity Type:</strong> {contract.counterparty.entityType}</div>
                  <div><strong className="text-zinc-400">Tax ID:</strong> {contract.counterparty.taxId || 'N/A'}</div>
                  <div><strong className="text-zinc-400">Signatory Name:</strong> {contract.counterparty.signatoryName}</div>
                  <div><strong className="text-zinc-400">Designation:</strong> {contract.counterparty.signatoryDesignation}</div>
                  <div><strong className="text-zinc-400">Signatory Email:</strong> {contract.counterparty.signatoryEmail}</div>
                </div>
              </div>

              <div className="p-4.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div>
                  <span className="text-zinc-500 text-[10px] uppercase block font-semibold">Contract Value</span>
                  <span className="font-bold text-white text-base mt-0.5 block">{contract.commercials.contractValue.toLocaleString()} {contract.commercials.currency}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] uppercase block font-semibold">Pricing Model</span>
                  <span className="font-semibold text-zinc-200 capitalize mt-0.5 block">{contract.commercials.pricingModel.replace(/_/g, ' ')}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] uppercase block font-semibold">Governing Law</span>
                  <span className="font-semibold text-zinc-200 mt-0.5 block truncate">{contract.governingLaw}</span>
                </div>
                <div>
                  <span className="text-zinc-500 text-[10px] uppercase block font-semibold">Term</span>
                  <span className="font-semibold text-zinc-200 mt-0.5 block">{contract.startDate} to {contract.endDate || 'Perpetual'}</span>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: Approvals Pipeline */}
          {activeTab === 'approvals' && (
            <div className="space-y-3">
              {contract.approvals.map((step, i) => (
                <div key={step.id} className="p-4 rounded-2xl bg-zinc-950/80 border border-white/[0.06] flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-white">Stage {i + 1}: {step.stepName}</span>
                    <span className="text-zinc-400 block text-[11px] mt-0.5">Assigned to: {step.assignedUserEmail} ({step.roleRequired})</span>
                    {step.comments && <p className="text-zinc-300 italic mt-1">&quot;{step.comments}&quot;</p>}
                  </div>
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                    step.status === 'approved' ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20' : 'bg-zinc-800 text-zinc-400 border border-zinc-700'
                  }`}>
                    {step.status}
                  </span>
                </div>
              ))}
            </div>
          )}

          {/* TAB 4: Version History */}
          {activeTab === 'history' && (
            <div className="space-y-3">
              {contract.versions.map((ver, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-zinc-950/80 border border-white/[0.06] text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{ver.versionNumber}</span>
                    <span className="text-zinc-500 text-[11px]">{new Date(ver.createdAt).toLocaleDateString()}</span>
                  </div>
                  <p className="text-zinc-300 text-[11px]">{ver.changeLog || 'Document snapshot.'}</p>
                  <span className="text-zinc-500 text-[10px] block">Author: {ver.createdBy}</span>
                </div>
              ))}
            </div>
          )}

        </div>

        {/* Modal Footer Actions */}
        <div className="p-5 border-t border-white/[0.06] bg-zinc-950/60 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => {
                onClose();
                onNavigateToVetting(contract);
              }}
              className="px-4 py-2.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-amber-600/20 transition-all active:scale-95"
            >
              Run AI Legal Vetting
            </button>
            <button
              onClick={() => {
                onClose();
                onNavigateToSigning(contract);
              }}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 transition-all active:scale-95"
            >
              Open in E-Signature Studio
            </button>
          </div>

          <button
            onClick={onClose}
            className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
};
