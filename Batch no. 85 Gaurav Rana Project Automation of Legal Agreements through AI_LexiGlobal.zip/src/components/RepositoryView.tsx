import React, { useState } from 'react';
import { 
  FolderArchive, 
  Search, 
  Filter, 
  FileText, 
  Globe2, 
  Download, 
  ShieldAlert, 
  CheckCircle2, 
  PenTool, 
  Eye, 
  Clock, 
  PlusCircle, 
  Calendar,
  Layers,
  ChevronRight
} from 'lucide-react';
import { ContractItem, ContractStatus, UserRole } from '../types';
import { generateContractPdf } from '../utils/pdfExport';
import { GLOBAL_JURISDICTIONS } from '../data/jurisdictions';

interface RepositoryViewProps {
  contracts: ContractItem[];
  onSelectContract: (contract: ContractItem) => void;
  onStartDrafting: () => void;
  onNavigateToSigning: (contract: ContractItem) => void;
  onNavigateToVetting: (contract: ContractItem) => void;
  userRole: UserRole;
}

export const RepositoryView: React.FC<RepositoryViewProps> = ({
  contracts,
  onSelectContract,
  onStartDrafting,
  onNavigateToSigning,
  onNavigateToVetting,
  userRole
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const filteredContracts = contracts.filter((c) => {
    const q = searchQuery ? searchQuery.toLowerCase() : '';
    const matchesSearch = !q || 
      (c.title || '').toLowerCase().includes(q) ||
      (c.contractNumber || '').toLowerCase().includes(q) ||
      (c.primaryParty?.legalName || '').toLowerCase().includes(q) ||
      (c.counterparty?.legalName || '').toLowerCase().includes(q);

    const matchesStatus = selectedStatus === 'ALL' || c.status === selectedStatus;
    const matchesCountry = selectedCountry === 'ALL' || c.country === selectedCountry;
    const matchesCategory = selectedCategory === 'ALL' || c.category === selectedCategory;

    return matchesSearch && matchesStatus && matchesCountry && matchesCategory;
  });

  const getStatusBadge = (status: ContractStatus) => {
    switch (status) {
      case 'fully_executed':
      case 'active':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">Active / Executed</span>;
      case 'sent_for_signature':
      case 'partially_signed':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 uppercase">E-Sign In Progress</span>;
      case 'legal_review':
      case 'business_review':
      case 'negotiation':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 uppercase">In Review / Neg.</span>;
      case 'expiring_soon':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 uppercase">Expiring in 60d</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-800 text-slate-300 border border-slate-700 uppercase">{status.replace(/_/g, ' ')}</span>;
    }
  };

  return (
    <div id="contract-repository-view" className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-teal-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <FolderArchive className="w-3.5 h-3.5 text-emerald-400" />
                Enterprise CLM Repository
              </span>
              <span className="text-xs text-zinc-500 font-mono">14 Lifecycle Statuses Tracked</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Global Contract Repository & Document Archive
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Centralized record of all corporate agreements, multi-version histories, execution audit trails, and automated renewal triggers.
            </p>
          </div>

          <button
            onClick={onStartDrafting}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-95 shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Create New Contract</span>
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4 rounded-3xl shadow-xl space-y-3">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2.5 flex-1 min-w-[240px] bg-zinc-950/90 px-3.5 py-2.5 rounded-2xl border border-white/[0.08] shadow-inner">
            <Search className="w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search by title, contract #, parties..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-xs text-white placeholder-zinc-500 focus:outline-none w-full"
            />
          </div>

          {/* Status Dropdown */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
          >
            <option value="ALL" className="bg-zinc-900 text-white">All Statuses (14)</option>
            <option value="draft" className="bg-zinc-900 text-white">Draft</option>
            <option value="ai_review" className="bg-zinc-900 text-white">AI Review</option>
            <option value="legal_review" className="bg-zinc-900 text-white">Legal Review</option>
            <option value="negotiation" className="bg-zinc-900 text-white">Negotiation</option>
            <option value="approved" className="bg-zinc-900 text-white">Approved</option>
            <option value="sent_for_signature" className="bg-zinc-900 text-white">Sent for Signature</option>
            <option value="partially_signed" className="bg-zinc-900 text-white">Partially Signed</option>
            <option value="fully_executed" className="bg-zinc-900 text-white">Fully Executed</option>
            <option value="active" className="bg-zinc-900 text-white">Active</option>
            <option value="expiring_soon" className="bg-zinc-900 text-white">Expiring Soon</option>
          </select>

          {/* Country Dropdown */}
          <select
            value={selectedCountry}
            onChange={(e) => setSelectedCountry(e.target.value)}
            className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
          >
            <option value="ALL" className="bg-zinc-900 text-white">All Countries</option>
            {GLOBAL_JURISDICTIONS.map(j => (
              <option key={j.countryCode} value={j.countryName} className="bg-zinc-900 text-white">{j.countryName}</option>
            ))}
          </select>

          {/* Category Dropdown */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
          >
            <option value="ALL" className="bg-zinc-900 text-white">All Categories</option>
            <option value="commercial" className="bg-zinc-900 text-white">Commercial & Services</option>
            <option value="ip_confidentiality" className="bg-zinc-900 text-white">IP & NDAs</option>
            <option value="employment" className="bg-zinc-900 text-white">Employment & Talent</option>
            <option value="corporate" className="bg-zinc-900 text-white">Corporate & M&A</option>
          </select>
        </div>
      </div>

      {/* Contracts Table */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl shadow-xl overflow-hidden">
        <div className="p-4 sm:p-5 border-b border-white/[0.06] flex items-center justify-between">
          <span className="text-xs font-bold text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            Showing {filteredContracts.length} of {contracts.length} Agreements
          </span>
          <span className="text-[11px] text-zinc-500 font-mono">Real-Time Sync</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950/80 text-zinc-400 uppercase text-[10px] tracking-wider border-b border-white/[0.06]">
              <tr>
                <th className="py-3.5 px-4 font-semibold">Contract Identification</th>
                <th className="py-3.5 px-4 font-semibold">Parties Involved</th>
                <th className="py-3.5 px-4 font-semibold">Jurisdiction & Law</th>
                <th className="py-3.5 px-4 font-semibold">Commercials</th>
                <th className="py-3.5 px-4 font-semibold">Risk Rating</th>
                <th className="py-3.5 px-4 font-semibold">Status</th>
                <th className="py-3.5 px-4 text-right font-semibold">Quick Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {filteredContracts.map((c) => (
                <tr 
                  key={c.id} 
                  className="hover:bg-zinc-900/60 transition-colors cursor-pointer"
                  onClick={() => onSelectContract(c)}
                >
                  <td className="py-4 px-4">
                    <div className="font-bold text-white hover:text-emerald-400 transition-colors">{c.title}</div>
                    <div className="text-[11px] text-zinc-400 flex items-center gap-1.5 mt-0.5">
                      <span className="font-mono text-emerald-400">{c.contractNumber}</span>
                      <span>•</span>
                      <span>v{c.versions.length}.0</span>
                      <span>•</span>
                      <span>{c.createdDate}</span>
                    </div>
                  </td>

                  <td className="py-4 px-4">
                    <div className="font-medium text-zinc-200">{c.primaryParty.legalName}</div>
                    <div className="text-[11px] text-zinc-400 flex items-center gap-1">
                      <span>vs</span>
                      <span className="text-amber-300 font-medium">{c.counterparty.legalName}</span>
                    </div>
                  </td>

                  <td className="py-4 px-4">
                    <div className="font-medium text-zinc-200 flex items-center gap-1">
                      <Globe2 className="w-3 h-3 text-cyan-400" />
                      {c.country}
                    </div>
                    <div className="text-[10px] text-zinc-500 truncate max-w-[130px]">{c.governingLaw}</div>
                  </td>

                  <td className="py-4 px-4">
                    <div className="font-mono font-bold text-zinc-200">
                      {c.commercials.contractValue.toLocaleString()} {c.commercials.currency}
                    </div>
                    <div className="text-[10px] text-zinc-400 capitalize">{c.commercials.pricingModel.replace(/_/g, ' ')}</div>
                  </td>

                  <td className="py-4 px-4">
                    <div className="flex items-center gap-1.5">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                        c.riskBreakdown.overallScore > 60 ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30' :
                        c.riskBreakdown.overallScore > 35 ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' :
                        'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                      }`}>
                        {c.riskBreakdown.overallScore}/100
                      </span>
                    </div>
                  </td>

                  <td className="py-4 px-4">
                    {getStatusBadge(c.status)}
                  </td>

                  <td className="py-4 px-4 text-right" onClick={(e) => e.stopPropagation()}>
                    <div className="flex items-center justify-end gap-1.5">
                      <button
                        title="View Details"
                        onClick={() => onSelectContract(c)}
                        className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl border border-white/[0.06] transition-colors"
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        title="Run AI Legal Vetting"
                        onClick={() => onNavigateToVetting(c)}
                        className="p-2 bg-amber-950/40 hover:bg-amber-800/40 text-amber-300 border border-amber-700/40 rounded-xl transition-colors"
                      >
                        <ShieldAlert className="w-3.5 h-3.5" />
                      </button>
                      <button
                        title="Digital E-Signature"
                        onClick={() => onNavigateToSigning(c)}
                        className="p-2 bg-emerald-950/40 hover:bg-emerald-800/40 text-emerald-300 border border-emerald-700/40 rounded-xl transition-colors"
                      >
                        <PenTool className="w-3.5 h-3.5" />
                      </button>
                      <button
                        title="Export Executed PDF"
                        onClick={() => generateContractPdf(c)}
                        className="p-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 rounded-xl border border-white/[0.06] transition-colors"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
