import React, { useState } from 'react';
import { 
  Globe2, 
  FileText, 
  Users, 
  Briefcase, 
  DollarSign, 
  ShieldAlert, 
  Sparkles, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft, 
  AlertTriangle, 
  Scale, 
  Download, 
  Save, 
  RefreshCw, 
  Copy, 
  PenTool, 
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Search,
  Eye,
  BookOpen,
  Layers,
  X,
  Check
} from 'lucide-react';
import { GLOBAL_JURISDICTIONS } from '../data/jurisdictions';
import { CONTRACT_TEMPLATES } from '../data/contractTemplates';
import { ContractItem, ContractParty, CommercialTerms, RiskLiabilityConfig, DetailedClause } from '../types';
import { generateContractPdf } from '../utils/pdfExport';

interface DraftingWizardProps {
  onContractCreated: (newContract: ContractItem) => void;
  onNavigateToVetting: (contract: ContractItem) => void;
  onNavigateToSigning: (contract: ContractItem) => void;
  onNavigateToRepository?: () => void;
}

export const DraftingWizardView: React.FC<DraftingWizardProps> = ({
  onContractCreated,
  onNavigateToVetting,
  onNavigateToSigning,
  onNavigateToRepository
}) => {
  const [currentStep, setCurrentStep] = useState<number>(1);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [generationError, setGenerationError] = useState<string | null>(null);

  // Form State
  const [selectedCountryCode, setSelectedCountryCode] = useState<string>('US');
  const [selectedState, setSelectedState] = useState<string>('Delaware');
  const [governingLaw, setGoverningLaw] = useState<string>('Laws of the State of Delaware');
  const [disputeForum, setDisputeForum] = useState<string>('American Arbitration Association (AAA), New York');
  
  const [selectedCategory, setSelectedCategory] = useState<string>('commercial');
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('tmpl-msa');

  // Detailed Clauses Architecture state
  const [expandedClauseIds, setExpandedClauseIds] = useState<string[]>([]);
  const [clauseSearch, setClauseSearch] = useState<string>('');
  const [selectedClauseCategory, setSelectedClauseCategory] = useState<string>('all');
  const [excludedClauseIds, setExcludedClauseIds] = useState<string[]>([]);
  const [previewingSampleDraft, setPreviewingSampleDraft] = useState<boolean>(false);
  const [copiedClauseId, setCopiedClauseId] = useState<string | null>(null);

  // Parties
  const [primaryParty, setPrimaryParty] = useState<Partial<ContractParty>>({
    legalName: 'Apex Enterprise Technologies Inc.',
    entityType: 'Corporation',
    registrationNumber: 'DE-991204',
    registeredAddress: '1209 Orange St, Wilmington, DE 19801',
    country: 'United States',
    taxId: 'EIN-84-129481',
    signatoryName: 'Marcus Vance',
    signatoryDesignation: 'Chief Executive Officer',
    signatoryEmail: 'm.vance@apexenterprise.com',
    signatoryPhone: '+1 (302) 555-0100',
    signatureStatus: 'pending'
  });

  const [counterparty, setCounterparty] = useState<Partial<ContractParty>>({
    legalName: 'Vanguard Global Innovations LLC',
    entityType: 'LLC',
    registrationNumber: 'NY-448102',
    registeredAddress: '350 Fifth Ave, Suite 4800, New York, NY 10118',
    country: 'United States',
    taxId: 'EIN-13-982103',
    signatoryName: 'Sophia Reynolds',
    signatoryDesignation: 'VP of Commercial Affairs',
    signatoryEmail: 's.reynolds@vanguardinnovations.com',
    signatoryPhone: '+1 (212) 555-0199',
    signatureStatus: 'pending'
  });

  // Scope
  const [scopeOfWork, setScopeOfWork] = useState<string>(
    'Provision of enterprise cloud software architecture, AI infrastructure engineering, continuous API integration, cybersecurity vulnerability assessments, and 24/7 level-3 technical support.'
  );
  const [deliverables, setDeliverables] = useState<string>(
    'Phase 1: Architecture Blueprint (Month 1)\nPhase 2: Core Platform Deployment (Month 3)\nPhase 3: Production Go-Live & SLA Handover (Month 6)'
  );
  const [startDate, setStartDate] = useState<string>('2026-09-01');
  const [endDate, setEndDate] = useState<string>('2027-08-31');

  // Commercials
  const [contractValue, setContractValue] = useState<number>(350000);
  const [currency, setCurrency] = useState<string>('USD');
  const [pricingModel, setPricingModel] = useState<CommercialTerms['pricingModel']>('milestone_based');
  const [paymentFrequency, setPaymentFrequency] = useState<CommercialTerms['paymentFrequency']>('monthly');
  const [paymentDueDays, setPaymentDueDays] = useState<number>(30);
  const [taxDetails, setTaxDetails] = useState<string>('Exclusive of state sales tax; standard reverse-charge for overseas entities');

  // Risk & Liability
  const [liabilityCapType, setLiabilityCapType] = useState<RiskLiabilityConfig['liabilityCapType']>('fees_paid_12_months');
  const [indemnityScope, setIndemnityScope] = useState<RiskLiabilityConfig['indemnificationScope']>('mutual');
  const [excludeConsequential, setExcludeConsequential] = useState<boolean>(true);
  const [liquidatedDamages, setLiquidatedDamages] = useState<boolean>(false);
  const [liquidatedDamagesDetails, setLiquidatedDamagesDetails] = useState<string>('0.5% per week of unexcused milestone delay capped at 5% total.');

  // Generated Draft State
  const [generatedDraftText, setGeneratedDraftText] = useState<string>('');
  const [lawyerReviewNotes, setLawyerReviewNotes] = useState<string[]>([]);
  const [assumptions, setAssumptions] = useState<string[]>([]);
  const [createdContractObj, setCreatedContractObj] = useState<ContractItem | null>(null);
  const [isSavedToRepo, setIsSavedToRepo] = useState<boolean>(false);

  // Active Jurisdiction Object
  const currentJurisdiction = GLOBAL_JURISDICTIONS.find(j => j.countryCode === selectedCountryCode) || GLOBAL_JURISDICTIONS[0];
  const currentTemplate = CONTRACT_TEMPLATES.find(t => t.id === selectedTemplateId) || CONTRACT_TEMPLATES[0];

  // Detailed Clauses Computations
  const detailedClausesList: DetailedClause[] = currentTemplate.detailedClauses || [];
  const activeDetailedClauses: DetailedClause[] = detailedClausesList.filter(c => !excludedClauseIds.includes(c.id));

  const filteredClauses = detailedClausesList.filter(clause => {
    const matchesCategory = selectedClauseCategory === 'all' || clause.category === selectedClauseCategory;
    const matchesSearch = !clauseSearch || 
      clause.title.toLowerCase().includes(clauseSearch.toLowerCase()) ||
      clause.summary.toLowerCase().includes(clauseSearch.toLowerCase()) ||
      clause.sectionNumber.toLowerCase().includes(clauseSearch.toLowerCase()) ||
      (clause.jurisdictionNotes && clause.jurisdictionNotes.toLowerCase().includes(clauseSearch.toLowerCase())) ||
      clause.fullLegalText.toLowerCase().includes(clauseSearch.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const toggleClauseExpand = (id: string) => {
    setExpandedClauseIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const expandAllClauses = () => {
    setExpandedClauseIds(detailedClausesList.map(c => c.id));
  };

  const collapseAllClauses = () => {
    setExpandedClauseIds([]);
  };

  const toggleClauseInclusion = (id: string, isMandatory: boolean) => {
    if (isMandatory) return;
    setExcludedClauseIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const copyClauseText = (clauseId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedClauseId(clauseId);
    setTimeout(() => setCopiedClauseId(null), 2000);
  };

  const getClauseCategoryBadge = (category: string) => {
    switch (category) {
      case 'operational':
        return 'bg-blue-500/10 text-blue-400 border-blue-500/20';
      case 'commercial':
        return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
      case 'ip_data':
        return 'bg-purple-500/10 text-purple-400 border-purple-500/20';
      case 'risk_liability':
        return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
      case 'compliance':
        return 'bg-teal-500/10 text-teal-400 border-teal-500/20';
      case 'governance':
        return 'bg-indigo-500/10 text-indigo-400 border-indigo-500/20';
      case 'dispute':
        return 'bg-rose-500/10 text-rose-400 border-rose-500/20';
      case 'boilerplate':
      default:
        return 'bg-zinc-800 text-zinc-400 border-white/[0.08]';
    }
  };

  const getBenchmarkBadge = (benchmark: string) => {
    if (benchmark.includes('Aggressive') || benchmark.includes('Company-Favorable')) {
      return 'bg-amber-500/10 text-amber-400 border-amber-500/20';
    }
    if (benchmark.includes('Balanced') || benchmark.includes('Neutral')) {
      return 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20';
    }
    return 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20';
  };

  // Handle Country Change
  const handleCountryChange = (countryCode: string) => {
    setSelectedCountryCode(countryCode);
    const j = GLOBAL_JURISDICTIONS.find(item => item.countryCode === countryCode);
    if (j) {
      setGoverningLaw(j.defaultGoverningLaw);
      if (j.statesOrProvinces && j.statesOrProvinces.length > 0) {
        setSelectedState(j.statesOrProvinces[0]);
      }
      if (j.arbitrationInstitutions && j.arbitrationInstitutions.length > 0) {
        setDisputeForum(`${j.arbitrationInstitutions[0].name}, ${j.arbitrationInstitutions[0].city}`);
      }
      setCurrency(j.currency);
    }
  };

  // Missing Info Validation Check
  const getMissingInfoWarnings = (): string[] => {
    const warnings: string[] = [];
    if (!primaryParty.legalName) warnings.push('Primary Party Legal Name is required');
    if (!primaryParty.signatoryName) warnings.push('Primary Party Signatory Name is required');
    if (!primaryParty.signatoryDesignation) warnings.push('Primary Party Signatory Designation is required');
    if (!counterparty.legalName) warnings.push('Counterparty Legal Name is required');
    if (!counterparty.signatoryName) warnings.push('Counterparty Signatory Name is required');
    if (!counterparty.signatoryDesignation) warnings.push('Counterparty Signatory Designation is required');
    if (!scopeOfWork || scopeOfWork.length < 20) warnings.push('Scope of Work should be detailed (at least 20 characters)');
    if (contractValue <= 0) warnings.push('Contract Value must be greater than 0');
    return warnings;
  };

  // Trigger AI Draft Generation
  const handleGenerateDraft = async () => {
    setIsGenerating(true);
    setGenerationError(null);

    const payload = {
      templateId: currentTemplate.id,
      contractType: currentTemplate.name,
      country: currentJurisdiction.countryName,
      stateOrRegion: selectedState,
      governingLaw,
      disputeForum,
      primaryParty,
      counterparty,
      commercials: {
        contractValue,
        currency,
        pricingModel,
        paymentFrequency,
        paymentDueDays,
        taxTreatment: taxDetails,
        latePaymentInterestRate: 1.5,
        expensesReimbursable: true
      },
      riskLiability: {
        liabilityCapType,
        liabilityCapAmount: contractValue,
        hasUncappedExceptions: true,
        uncappedExceptionsList: ['Gross Negligence', 'IP Infringement', 'Confidentiality'],
        indemnificationScope: indemnityScope,
        insuranceRequirement: true,
        consequentialDamagesExcluded: excludeConsequential,
        liquidatedDamages,
        liquidatedDamagesDetails: liquidatedDamages ? liquidatedDamagesDetails : undefined
      },
      scopeOfServices: scopeOfWork,
      specialTerms: `Milestones: ${deliverables}. Start Date: ${startDate}, End Date: ${endDate}.`,
      detailedClauses: activeDetailedClauses
    };

    try {
      const res = await fetch('/api/draft-contract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (data.success && data.draft) {
        setGeneratedDraftText(data.draft);
        setLawyerReviewNotes(data.lawyerReviewNotes || []);
        setAssumptions(data.assumptions || []);

        // Create the official contract object
        const newContract: ContractItem = {
          id: `cnt-${Date.now()}`,
          contractNumber: `GL-${new Date().getFullYear()}-${currentJurisdiction.countryCode}-${Math.floor(1000 + Math.random() * 9000)}`,
          title: `${primaryParty.legalName || 'Company'} & ${counterparty.legalName || 'Counterparty'} - ${currentTemplate.name}`,
          contractType: currentTemplate.name,
          category: currentTemplate.category,
          country: currentJurisdiction.countryName,
          stateOrRegion: selectedState,
          governingLaw,
          disputeForum,
          status: 'draft',
          primaryParty: primaryParty as ContractParty,
          counterparty: counterparty as ContractParty,
          commercials: {
            contractValue,
            currency,
            pricingModel,
            paymentFrequency,
            paymentDueDays,
            taxTreatment: taxDetails,
            latePaymentInterestRate: 1.5,
            expensesReimbursable: true
          },
          riskLiability: {
            liabilityCapType,
            liabilityCapAmount: contractValue,
            hasUncappedExceptions: true,
            uncappedExceptionsList: ['Gross Negligence', 'IP Infringement', 'Confidentiality'],
            indemnificationScope: indemnityScope,
            insuranceRequirement: true,
            insuranceCoverageAmount: 5000000,
            consequentialDamagesExcluded: excludeConsequential,
            liquidatedDamages
          },
          startDate,
          endDate,
          renewalNoticeDays: 60,
          autoRenew: false,
          riskBreakdown: {
            overallScore: 28,
            financialRisk: 30,
            legalRisk: 25,
            complianceRisk: 22,
            dataRisk: 29,
            operationalRisk: 24,
            keyRiskFactors: ['Standard drafting completed. Awaiting counterparty review.'],
            positiveProtections: [
              `Governed by ${governingLaw}`,
              `Liability capped under ${liabilityCapType}`,
              `Statutory e-signature compliance under ${currentJurisdiction.eSignatureStatute}`
            ]
          },
          versions: [
            {
              versionNumber: 'v1.0 (AI Draft)',
              createdAt: new Date().toISOString(),
              createdBy: `${primaryParty.signatoryName || 'Marcus Vance'} (Creator)`,
              content: data.draft,
              changeLog: `Initial AI-generated draft using ${currentTemplate.name} template under ${currentJurisdiction.countryName} jurisdiction.`,
              isAiGenerated: true,
              isLocked: false
            }
          ],
          currentVersionIndex: 0,
          approvals: [
            { id: 'app-init-1', stepName: 'Department Head Review', roleRequired: 'business', assignedUserEmail: primaryParty.signatoryEmail || 'business@company.com', status: 'pending' },
            { id: 'app-init-2', stepName: 'Legal & Compliance Approval', roleRequired: 'legal', assignedUserEmail: 'legal@company.com', status: 'pending' },
            { id: 'app-init-3', stepName: 'Finance Review', roleRequired: 'finance', assignedUserEmail: 'finance@company.com', status: 'pending', thresholdCondition: 'Value > $100k' }
          ],
          vettingIssues: [],
          createdDate: new Date().toISOString().split('T')[0],
          lastModifiedDate: new Date().toISOString().split('T')[0],
          contractOwner: primaryParty.signatoryName || 'Marcus Vance',
          department: 'Legal & Commercial Operations',
          tags: [currentJurisdiction.countryName, currentTemplate.name, 'AI-Drafted']
        };

        setCreatedContractObj(newContract);
        onContractCreated(newContract);
        setCurrentStep(8); // Move to final generated view
      } else {
        throw new Error(data.error || 'Failed to generate contract');
      }
    } catch (err: any) {
      setGenerationError(err.message || 'An error occurred during AI draft generation.');
    } finally {
      setIsGenerating(false);
    }
  };

  const stepsList = [
    { number: 1, title: 'Country & Jurisdiction' },
    { number: 2, title: 'Contract Type' },
    { number: 3, title: 'Parties Information' },
    { number: 4, title: 'Scope & Deliverables' },
    { number: 5, title: 'Commercials & Taxes' },
    { number: 6, title: 'Risk & Liability' },
    { number: 7, title: 'AI Verification & Missing Info' },
    { number: 8, title: 'AI Generated Agreement' }
  ];

  return (
    <div id="contract-drafting-wizard" className="max-w-5xl mx-auto space-y-6 pb-12">
      
      {/* Wizard Header */}
      <div className="bento-card p-6 md:p-8 rounded-3xl bento-glow-emerald">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1.5">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                Intelligent Drafting Engine
              </span>
              <span className="text-xs text-zinc-400 font-mono">Step {currentStep} of {stepsList.length}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              Global Contract Creation Wizard
            </h1>
            <p className="text-xs text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Jurisdiction-aware intake tailoring clauses, statutory compliance, and commercial safeguards.
            </p>
          </div>

          {/* Step Progress Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto py-1 no-scrollbar">
            {stepsList.map((s) => (
              <button
                key={s.number}
                onClick={() => s.number <= currentStep && setCurrentStep(s.number)}
                className={`w-8 h-8 rounded-xl text-xs font-bold flex items-center justify-center transition-all ${
                  currentStep === s.number
                    ? 'bg-emerald-600 text-white ring-2 ring-emerald-400/40 shadow-lg shadow-emerald-600/30 scale-105'
                    : currentStep > s.number
                    ? 'bg-zinc-800 text-emerald-400 border border-emerald-500/30'
                    : 'bg-zinc-900/80 text-zinc-600 border border-white/[0.04]'
                }`}
                title={s.title}
              >
                {currentStep > s.number ? '✓' : s.number}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* STEP 1: Country & Jurisdiction */}
      {currentStep === 1 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Globe2 className="w-5 h-5 text-emerald-400" />
              Step 1: Select Country, Applicable Jurisdiction & Governing Law
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              The platform automatically configures mandatory legal provisions, arbitration rules, and e-signature standards based on this selection.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Country</label>
              <select
                id="wizard-country-select"
                value={selectedCountryCode}
                onChange={(e) => handleCountryChange(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              >
                {GLOBAL_JURISDICTIONS.map((j) => (
                  <option key={j.countryCode} value={j.countryCode}>
                    {j.countryName} ({j.currency})
                  </option>
                ))}
              </select>
            </div>

            {currentJurisdiction.statesOrProvinces && (
              <div>
                <label className="block text-xs font-semibold text-zinc-300 mb-1.5">State / Province / Region</label>
                <select
                  id="wizard-state-select"
                  value={selectedState}
                  onChange={(e) => setSelectedState(e.target.value)}
                  className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
                >
                  {currentJurisdiction.statesOrProvinces.map((state) => (
                    <option key={state} value={state}>{state}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Governing Law</label>
              <input
                id="wizard-governing-law"
                type="text"
                value={governingLaw}
                onChange={(e) => setGoverningLaw(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Dispute Forum / Arbitration Institution</label>
              <input
                id="wizard-dispute-forum"
                type="text"
                value={disputeForum}
                onChange={(e) => setDisputeForum(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          {/* Legal Rationale & Statutory Intelligence Box */}
          <div className="p-5 rounded-2xl bg-zinc-950/70 border border-emerald-500/20 text-xs space-y-2">
            <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
              <Scale className="w-4 h-4 text-emerald-400" />
              Why this selection matters for {currentJurisdiction.countryName}:
            </div>
            <p className="text-zinc-300 leading-relaxed text-[11px]">
              {currentJurisdiction.notes}
            </p>
            <div className="text-[11px] text-zinc-400 pt-2 border-t border-white/[0.06]">
              <span className="font-semibold text-zinc-300">E-Signature Statute:</span> {currentJurisdiction.eSignatureStatute}
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-white/[0.06]">
            <button
              id="wizard-step1-next"
              onClick={() => setCurrentStep(2)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <span>Next: Select Contract Type</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 2: Contract Category & Type */}
      {currentStep === 2 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <FileText className="w-5 h-5 text-cyan-400" />
              Step 2: Choose Contract Category & Standard Template
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Select from our repository of market-standard agreements. The AI dynamically injects required boilerplate and specialized clauses.
            </p>
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'commercial', label: 'Commercial & Services' },
              { id: 'ip_confidentiality', label: 'IP & Confidentiality' },
              { id: 'employment', label: 'Employment & Contractors' },
              { id: 'corporate', label: 'Corporate & M&A' },
              { id: 'real_estate', label: 'Real Estate & Leases' }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/20'
                    : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-white/[0.06]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Template Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {CONTRACT_TEMPLATES.filter(t => t.category === selectedCategory).map((tmpl) => {
              const isSelected = selectedTemplateId === tmpl.id;
              const clauseCount = tmpl.detailedClauses?.length || tmpl.defaultClauses.length;
              return (
                <div
                  key={tmpl.id}
                  onClick={() => setSelectedTemplateId(tmpl.id)}
                  className={`p-5 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-emerald-950/30 border-emerald-500 shadow-lg shadow-emerald-500/10 ring-1 ring-emerald-500'
                      : 'bg-zinc-950/60 border-white/[0.06] hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white">{tmpl.name}</span>
                    {isSelected && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-1.5 line-clamp-2 leading-relaxed">
                    {tmpl.description}
                  </p>
                  <div className="mt-3 text-[10px] text-zinc-500 flex items-center justify-between">
                    <span>Parties: {tmpl.typicalParties.primary} vs {tmpl.typicalParties.counterparty}</span>
                    <span className="font-mono text-emerald-400 font-semibold">{clauseCount} Detailed Clauses</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* DETAILED STANDARD CLAUSES ARCHITECTURE */}
          <div className="pt-6 border-t border-white/[0.06] space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-zinc-950/80 p-5 rounded-2xl border border-white/[0.08]">
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <BookOpen className="w-4 h-4 text-emerald-400" />
                  <h3 className="text-sm font-bold text-white">
                    Standard Clauses Architecture: {currentTemplate.name}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                    {activeDetailedClauses.length} Active / {detailedClausesList.length} Clauses
                  </span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium bg-zinc-800 text-zinc-300 border border-white/[0.06]">
                    Jurisdiction: {currentJurisdiction.countryName}
                  </span>
                </div>
                <p className="text-xs text-zinc-400 mt-1.5 leading-relaxed">
                  Every standard clause is fully expanded into substantive, institutional-grade legal language with multi-tier subsections, definitions, and statutory citations.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setPreviewingSampleDraft(true)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-white/[0.08] transition-all active:scale-95"
                  title="View full sample agreement"
                >
                  <Eye className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Preview Complete Sample Draft</span>
                </button>
                <button
                  type="button"
                  onClick={expandedClauseIds.length === detailedClausesList.length ? collapseAllClauses : expandAllClauses}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-semibold border border-white/[0.08] transition-all active:scale-95"
                >
                  <Layers className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{expandedClauseIds.length === detailedClausesList.length ? 'Collapse All' : 'Expand All Clauses'}</span>
                </button>
              </div>
            </div>

            {/* Filter Bar */}
            <div className="flex flex-col md:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={clauseSearch}
                  onChange={(e) => setClauseSearch(e.target.value)}
                  placeholder="Filter clauses by title, keyword, statutory reference, or text..."
                  className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-xl pl-9 pr-8 py-2 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 transition-colors"
                />
                {clauseSearch && (
                  <button
                    type="button"
                    onClick={() => setClauseSearch('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-white text-xs"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>

              <div className="flex flex-wrap gap-1.5 items-center">
                {[
                  { id: 'all', label: 'All' },
                  { id: 'operational', label: 'Operational' },
                  { id: 'commercial', label: 'Commercial' },
                  { id: 'ip_data', label: 'IP & Data' },
                  { id: 'risk_liability', label: 'Liability' },
                  { id: 'compliance', label: 'Compliance' },
                  { id: 'dispute', label: 'Dispute' },
                  { id: 'boilerplate', label: 'General' }
                ].map(tab => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setSelectedClauseCategory(tab.id)}
                    className={`px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-all ${
                      selectedClauseCategory === tab.id
                        ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                        : 'bg-zinc-900/80 text-zinc-400 hover:text-zinc-200 border border-white/[0.06]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Clauses List */}
            {filteredClauses.length === 0 ? (
              <div className="p-8 text-center bg-zinc-950/50 rounded-2xl border border-white/[0.06]">
                <p className="text-xs text-zinc-400">No standard clauses match your search query "{clauseSearch}".</p>
                <button
                  type="button"
                  onClick={() => { setClauseSearch(''); setSelectedClauseCategory('all'); }}
                  className="mt-2 text-xs text-emerald-400 underline font-medium hover:text-emerald-300"
                >
                  Clear filters
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredClauses.map((clause) => {
                  const isExpanded = expandedClauseIds.includes(clause.id);
                  const isExcluded = excludedClauseIds.includes(clause.id);
                  const isCopied = copiedClauseId === clause.id;

                  return (
                    <div
                      key={clause.id}
                      className={`rounded-2xl border transition-all ${
                        isExcluded
                          ? 'bg-zinc-950/30 border-white/[0.04] opacity-50'
                          : isExpanded
                          ? 'bg-zinc-950/90 border-emerald-500/40 shadow-lg shadow-emerald-500/5'
                          : 'bg-zinc-950/60 border-white/[0.06] hover:border-zinc-700'
                      }`}
                    >
                      {/* Clause Card Header */}
                      <div className="p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div className="flex items-start sm:items-center gap-3">
                          <input
                            type="checkbox"
                            checked={!isExcluded}
                            disabled={clause.isMandatory}
                            onChange={() => toggleClauseInclusion(clause.id, clause.isMandatory)}
                            className="mt-1 sm:mt-0 w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 focus:ring-offset-zinc-900 bg-zinc-900 border-zinc-700 cursor-pointer disabled:cursor-not-allowed disabled:opacity-75"
                            title={clause.isMandatory ? 'Mandatory institutional clause' : 'Toggle inclusion'}
                          />
                          <div>
                            <div className="flex flex-wrap items-center gap-2">
                              {clause.sectionNumber && (
                                <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-zinc-800 text-zinc-300 border border-white/[0.08]">
                                  {clause.sectionNumber}
                                </span>
                              )}
                              <h4 className="font-bold text-xs sm:text-sm text-white">{clause.title}</h4>
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${getClauseCategoryBadge(clause.category)}`}>
                                {clause.category.replace('_', ' ').toUpperCase()}
                              </span>
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium border ${getBenchmarkBadge(clause.standardBenchmark)}`}>
                                {clause.standardBenchmark}
                              </span>
                              {clause.isMandatory && (
                                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                                  Mandatory
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-zinc-400 mt-1.5 leading-relaxed">
                              {clause.summary}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-2 self-end sm:self-auto shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-white/[0.04]">
                          <button
                            type="button"
                            onClick={() => copyClauseText(clause.id, clause.fullLegalText)}
                            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-[11px] font-medium border border-white/[0.06] transition-all"
                            title="Copy full legal text to clipboard"
                          >
                            {isCopied ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-400">Copied</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5 text-zinc-400" />
                                <span>Copy Text</span>
                              </>
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => toggleClauseExpand(clause.id)}
                            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-all ${
                              isExpanded
                                ? 'bg-emerald-600 text-white shadow-sm'
                                : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/[0.06]'
                            }`}
                          >
                            <span>{isExpanded ? 'Hide Language' : 'View Full Legal Text'}</span>
                            {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                      </div>

                      {/* Expandable Substantive Legal Text */}
                      {isExpanded && (
                        <div className="px-5 pb-5 pt-2 border-t border-white/[0.06] space-y-4">
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                                <FileText className="w-3.5 h-3.5" />
                                Verbatim Substantive Legal Text:
                              </span>
                              <span className="text-[10px] text-zinc-500 font-mono">
                                ~{clause.fullLegalText.split(/\s+/).length} words
                              </span>
                            </div>
                            <div className="p-4 rounded-xl bg-zinc-950/90 border border-white/[0.08] text-xs font-mono text-zinc-300 whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto custom-scrollbar">
                              {clause.fullLegalText}
                            </div>
                          </div>

                          {clause.jurisdictionNotes && (
                            <div className="p-3.5 rounded-xl bg-blue-950/20 border border-blue-500/20 flex items-start gap-2.5">
                              <Scale className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                              <div className="text-xs text-blue-200/90">
                                <span className="font-semibold text-blue-300 block mb-0.5">Statutory & Jurisdiction Compliance Note:</span>
                                {clause.jurisdictionNotes}
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          <div className="flex justify-between pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => setCurrentStep(1)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              id="wizard-step2-next"
              onClick={() => setCurrentStep(3)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <span>Next: Enter Parties Info</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 3: Parties Information */}
      {currentStep === 3 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-400" />
              Step 3: Enter Contract Parties & Signatories
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Provide full corporate details, legal registrations, and authorized signing officers.
            </p>
          </div>

          {/* Primary Party (My Company) */}
          <div className="p-5 rounded-2xl bg-zinc-950/70 border border-white/[0.06] space-y-4">
            <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                Primary Party (My Company / Client)
              </span>
              <span className="text-[10px] text-zinc-500 font-mono bg-zinc-900 px-2 py-0.5 rounded-md border border-white/[0.06]">Party 1</span>
            </div>

            {/* Entity Corporate Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Legal Entity Name</label>
                <input
                  type="text"
                  value={primaryParty.legalName || ''}
                  onChange={(e) => setPrimaryParty({ ...primaryParty, legalName: e.target.value })}
                  placeholder="e.g. Apex Enterprise Technologies Inc."
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Entity Type</label>
                <input
                  type="text"
                  value={primaryParty.entityType || ''}
                  onChange={(e) => setPrimaryParty({ ...primaryParty, entityType: e.target.value as any })}
                  placeholder="e.g. Corporation, LLC, Pvt Ltd"
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Tax ID / GSTIN / EIN</label>
                <input
                  type="text"
                  value={primaryParty.taxId || ''}
                  onChange={(e) => setPrimaryParty({ ...primaryParty, taxId: e.target.value })}
                  placeholder="e.g. EIN-84-129481"
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Registered Corporate Address</label>
              <input
                type="text"
                value={primaryParty.registeredAddress || ''}
                onChange={(e) => setPrimaryParty({ ...primaryParty, registeredAddress: e.target.value })}
                placeholder="e.g. 1209 Orange St, Wilmington, DE 19801"
                className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Dedicated Authorized Signatory Section */}
            <div className="pt-2 border-t border-white/[0.06]">
              <div className="text-[11px] font-semibold text-zinc-300 mb-2.5 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Authorized Signatory Credentials</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Signatory Legal Name</label>
                  <input
                    type="text"
                    value={primaryParty.signatoryName || ''}
                    onChange={(e) => setPrimaryParty({ ...primaryParty, signatoryName: e.target.value })}
                    placeholder="e.g. Marcus Vance"
                    className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Signatory Designation / Official Title</label>
                  <input
                    type="text"
                    value={primaryParty.signatoryDesignation || ''}
                    onChange={(e) => setPrimaryParty({ ...primaryParty, signatoryDesignation: e.target.value })}
                    placeholder="e.g. Chief Executive Officer / Director"
                    className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Signatory Official Email (for E-Sign)</label>
                  <input
                    type="email"
                    value={primaryParty.signatoryEmail || ''}
                    onChange={(e) => setPrimaryParty({ ...primaryParty, signatoryEmail: e.target.value })}
                    placeholder="e.g. m.vance@apexenterprise.com"
                    className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Counterparty */}
          <div className="p-5 rounded-2xl bg-zinc-950/70 border border-white/[0.06] space-y-4">
            <div className="flex items-center justify-between text-xs font-bold text-amber-400">
              <span className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse"></span>
                Counterparty (Vendor / Provider / Employee / Partner)
              </span>
              <span className="text-[10px] text-zinc-500 font-mono bg-zinc-900 px-2 py-0.5 rounded-md border border-white/[0.06]">Party 2</span>
            </div>

            {/* Entity Corporate Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Legal Entity Name</label>
                <input
                  type="text"
                  value={counterparty.legalName || ''}
                  onChange={(e) => setCounterparty({ ...counterparty, legalName: e.target.value })}
                  placeholder="e.g. Vanguard Global Innovations LLC"
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Entity Type</label>
                <input
                  type="text"
                  value={counterparty.entityType || ''}
                  onChange={(e) => setCounterparty({ ...counterparty, entityType: e.target.value as any })}
                  placeholder="e.g. LLC, Corporation, Partnership"
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
              <div>
                <label className="block text-[11px] text-zinc-400 mb-1">Tax ID / GSTIN / EIN</label>
                <input
                  type="text"
                  value={counterparty.taxId || ''}
                  onChange={(e) => setCounterparty({ ...counterparty, taxId: e.target.value })}
                  placeholder="e.g. EIN-13-982103"
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-zinc-400 mb-1">Registered Corporate Address</label>
              <input
                type="text"
                value={counterparty.registeredAddress || ''}
                onChange={(e) => setCounterparty({ ...counterparty, registeredAddress: e.target.value })}
                placeholder="e.g. 350 Fifth Ave, Suite 4800, New York, NY 10118"
                className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Dedicated Authorized Signatory Section */}
            <div className="pt-2 border-t border-white/[0.06]">
              <div className="text-[11px] font-semibold text-zinc-300 mb-2.5 flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                <span>Counterparty Authorized Signatory Credentials</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Signatory Legal Name</label>
                  <input
                    type="text"
                    value={counterparty.signatoryName || ''}
                    onChange={(e) => setCounterparty({ ...counterparty, signatoryName: e.target.value })}
                    placeholder="e.g. Sophia Reynolds"
                    className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Signatory Designation / Official Title</label>
                  <input
                    type="text"
                    value={counterparty.signatoryDesignation || ''}
                    onChange={(e) => setCounterparty({ ...counterparty, signatoryDesignation: e.target.value })}
                    placeholder="e.g. VP of Commercial Affairs / Partner"
                    className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-[11px] text-zinc-400 mb-1">Signatory Official Email (for E-Sign)</label>
                  <input
                    type="email"
                    value={counterparty.signatoryEmail || ''}
                    onChange={(e) => setCounterparty({ ...counterparty, signatoryEmail: e.target.value })}
                    placeholder="e.g. s.reynolds@vanguardinnovations.com"
                    className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => setCurrentStep(2)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              id="wizard-step3-next"
              onClick={() => setCurrentStep(4)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <span>Next: Scope & Deliverables</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 4: Scope & Deliverables */}
      {currentStep === 4 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Briefcase className="w-5 h-5 text-cyan-400" />
              Step 4: Scope of Work, Deliverables & Timeline
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Define the substantive operational commitments, acceptance review periods, and contract duration.
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Scope of Work & Services Description</label>
            <textarea
              id="wizard-scope"
              rows={4}
              value={scopeOfWork}
              onChange={(e) => setScopeOfWork(e.target.value)}
              className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-emerald-500 leading-relaxed transition-colors"
              placeholder="Describe the specific services, technical deliverables, and performance obligations..."
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Key Deliverables & Milestones</label>
            <textarea
              id="wizard-deliverables"
              rows={3}
              value={deliverables}
              onChange={(e) => setDeliverables(e.target.value)}
              className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-emerald-500 leading-relaxed transition-colors"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Start / Effective Date</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">End Date / Expiry Date</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => setCurrentStep(3)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              id="wizard-step4-next"
              onClick={() => setCurrentStep(5)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <span>Next: Commercials & Taxes</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 5: Commercial Terms & Taxes */}
      {currentStep === 5 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-400" />
              Step 5: Commercial Terms, Pricing Model & Tax Structure
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Configure contract value, currency, payment schedules, and withholding/indirect tax obligations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Contract Value</label>
              <input
                id="wizard-value"
                type="number"
                value={contractValue}
                onChange={(e) => setContractValue(Number(e.target.value))}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Currency</label>
              <select
                id="wizard-currency"
                value={currency}
                onChange={(e) => setCurrency(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              >
                <option value="USD">USD ($)</option>
                <option value="INR">INR (₹)</option>
                <option value="GBP">GBP (£)</option>
                <option value="EUR">EUR (€)</option>
                <option value="SGD">SGD (S$)</option>
                <option value="AED">AED (AED)</option>
                <option value="AUD">AUD (A$)</option>
                <option value="CAD">CAD (CA$)</option>
                <option value="SAR">SAR (SAR)</option>
                <option value="JPY">JPY (¥)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Pricing Model</label>
              <select
                value={pricingModel}
                onChange={(e) => setPricingModel(e.target.value as any)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              >
                <option value="fixed_fee">Fixed Fee</option>
                <option value="milestone_based">Milestone-Based</option>
                <option value="monthly">Monthly Retainer</option>
                <option value="hourly_rate">Time & Materials / Hourly</option>
                <option value="subscription">Annual SaaS Subscription</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Payment Terms (Net Days)</label>
              <select
                value={paymentDueDays}
                onChange={(e) => setPaymentDueDays(Number(e.target.value))}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              >
                <option value={15}>Net 15 Days (Vendor-Friendly)</option>
                <option value={30}>Net 30 Days (Market Standard)</option>
                <option value={45}>Net 45 Days</option>
                <option value={60}>Net 60 Days (Enterprise Standard)</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Tax & Withholding Specification</label>
              <input
                type="text"
                value={taxDetails}
                onChange={(e) => setTaxDetails(e.target.value)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              />
            </div>
          </div>

          <div className="flex justify-between pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => setCurrentStep(4)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              id="wizard-step5-next"
              onClick={() => setCurrentStep(6)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <span>Next: Risk & Liability</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 6: Risk & Liability Preferences */}
      {currentStep === 6 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              Step 6: Risk Allocation & Liability Ceiling
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Select the liability cap, consequential damage disclaimers, and indemnity boundaries.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Aggregate Liability Cap Type</label>
              <select
                id="wizard-liability-cap"
                value={liabilityCapType}
                onChange={(e) => setLiabilityCapType(e.target.value as any)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              >
                <option value="fees_paid_12_months">100% of Fees Paid in Preceding 12 Months (Standard)</option>
                <option value="fixed_amount">Fixed Cap Equal to Total Contract Value</option>
                <option value="multiplier_annual_value">2x Annual Contract Value</option>
                <option value="unlimited">Uncapped / Unlimited Liability (High Risk)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-zinc-300 mb-1.5">Indemnification Scope</label>
              <select
                value={indemnityScope}
                onChange={(e) => setIndemnityScope(e.target.value as any)}
                className="w-full bg-zinc-950/80 border border-white/[0.08] rounded-2xl px-4 py-3 text-xs text-white focus:outline-none focus:border-emerald-500 transition-colors"
              >
                <option value="mutual">Mutual Indemnification (Standard)</option>
                <option value="company_only">Company-Friendly (Vendor Indemnifies Only)</option>
                <option value="ip_only">Third-Party IP Infringement Only</option>
              </select>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-zinc-950/70 border border-white/[0.06] space-y-3.5">
            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="check-consequential"
                checked={excludeConsequential}
                onChange={(e) => setExcludeConsequential(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-0 cursor-pointer accent-emerald-500"
              />
              <label htmlFor="check-consequential" className="text-xs text-zinc-200 font-medium cursor-pointer">
                Exclude Consequential, Indirect, Special & Punitive Damages (Strongly Recommended)
              </label>
            </div>

            <div className="flex items-center gap-3">
              <input
                type="checkbox"
                id="check-liquidated"
                checked={liquidatedDamages}
                onChange={(e) => setLiquidatedDamages(e.target.checked)}
                className="w-4 h-4 rounded text-emerald-600 focus:ring-0 cursor-pointer accent-emerald-500"
              />
              <label htmlFor="check-liquidated" className="text-xs text-zinc-200 font-medium cursor-pointer">
                Include Liquidated Damages for Delay (Must be proportionate to actual harm)
              </label>
            </div>

            {liquidatedDamages && (
              <div className="pt-2">
                <label className="block text-[11px] text-zinc-400 mb-1">Liquidated Damages Details</label>
                <input
                  type="text"
                  value={liquidatedDamagesDetails}
                  onChange={(e) => setLiquidatedDamagesDetails(e.target.value)}
                  className="w-full bg-zinc-900 border border-white/[0.08] rounded-xl px-3.5 py-2 text-xs text-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            )}
          </div>

          <div className="flex justify-between pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => setCurrentStep(5)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              id="wizard-step6-next"
              onClick={() => setCurrentStep(7)}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-600/20 active:scale-95 transition-all"
            >
              <span>Next: AI Verification</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* STEP 7: AI Verification & Missing Info Check */}
      {currentStep === 7 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="border-b border-white/[0.06] pb-4">
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-emerald-400" />
              Step 7: AI Intake Pre-Generation Verification
            </h2>
            <p className="text-xs text-zinc-400 mt-1">
              Reviewing contractual inputs against legal knowledge base for {currentJurisdiction.countryName}.
            </p>
          </div>

          {/* Missing info check */}
          {getMissingInfoWarnings().length > 0 ? (
            <div className="p-5 rounded-2xl bg-rose-950/20 border border-rose-500/30 space-y-2">
              <div className="flex items-center gap-2 text-xs font-bold text-rose-300">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                <span>Missing Information Detected:</span>
              </div>
              <ul className="list-disc list-inside text-xs text-rose-200/90 space-y-1">
                {getMissingInfoWarnings().map((w, i) => (
                  <li key={i}>{w}</li>
                ))}
              </ul>
            </div>
          ) : (
            <div className="p-5 rounded-2xl bg-emerald-950/20 border border-emerald-500/30 flex items-center gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
              <div className="text-xs text-emerald-200">
                <span className="font-semibold text-emerald-300 block">Intake Parameters Complete & Validated</span>
                All mandatory commercial, party, and jurisdiction fields are populated.
              </div>
            </div>
          )}

          {/* Intake Summary Card */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 text-xs bg-zinc-950/70 p-5 rounded-2xl border border-white/[0.06]">
            <div>
              <span className="text-zinc-500 block text-[10px] uppercase font-semibold">Jurisdiction</span>
              <span className="font-semibold text-white">{currentJurisdiction.countryName} ({governingLaw})</span>
            </div>
            <div>
              <span className="text-zinc-500 block text-[10px] uppercase font-semibold">Contract Type</span>
              <span className="font-semibold text-white">{currentTemplate.name}</span>
            </div>
            <div>
              <span className="text-zinc-500 block text-[10px] uppercase font-semibold">Value & Term</span>
              <span className="font-semibold text-white">{contractValue.toLocaleString()} {currency} ({startDate} to {endDate})</span>
            </div>
            <div>
              <span className="text-zinc-500 block text-[10px] uppercase font-semibold">Primary Party & Signatory</span>
              <span className="font-semibold text-white block">{primaryParty.legalName}</span>
              <span className="text-[11px] text-emerald-400 font-medium">{primaryParty.signatoryName} ({primaryParty.signatoryDesignation})</span>
            </div>
            <div>
              <span className="text-zinc-500 block text-[10px] uppercase font-semibold">Counterparty & Signatory</span>
              <span className="font-semibold text-white block">{counterparty.legalName}</span>
              <span className="text-[11px] text-amber-400 font-medium">{counterparty.signatoryName} ({counterparty.signatoryDesignation})</span>
            </div>
            <div>
              <span className="text-zinc-500 block text-[10px] uppercase font-semibold">Liability Cap</span>
              <span className="font-semibold text-white">{liabilityCapType.replace(/_/g, ' ')}</span>
            </div>
          </div>

          {/* Substantive Clauses Intake Review */}
          <div className="bg-zinc-950/70 p-5 rounded-2xl border border-white/[0.06] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-emerald-400" />
                <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                  Detailed Clauses Prepared for High-Fidelity AI Expansion ({activeDetailedClauses.length} Clauses)
                </h4>
              </div>
              <span className="text-[11px] text-zinc-400">
                100% Substantive Legal Drafting (No Summaries)
              </span>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5 max-h-56 overflow-y-auto pr-1 custom-scrollbar">
              {activeDetailedClauses.map((c) => (
                <div key={c.id} className="p-2.5 rounded-xl bg-zinc-900/80 border border-white/[0.06] flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 mb-0.5">
                      {c.sectionNumber && (
                        <span className="text-[9px] font-mono font-bold text-zinc-400">{c.sectionNumber}</span>
                      )}
                      <span className={`px-1.5 py-0.2 rounded text-[9px] font-medium border ${getClauseCategoryBadge(c.category)}`}>
                        {c.category.replace('_', ' ')}
                      </span>
                    </div>
                    <p className="text-[11px] font-semibold text-zinc-200 truncate">{c.title}</p>
                  </div>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                </div>
              ))}
            </div>
          </div>

          {generationError && (
            <div className="p-4 bg-rose-950/30 border border-rose-500/30 rounded-2xl text-xs text-rose-300">
              {generationError}
            </div>
          )}

          <div className="flex justify-between pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => setCurrentStep(6)}
              className="flex items-center gap-1.5 px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Back</span>
            </button>
            <button
              id="wizard-generate-draft-btn"
              onClick={handleGenerateDraft}
              disabled={isGenerating || getMissingInfoWarnings().length > 0}
              className={`flex items-center gap-2 px-7 py-3 rounded-xl text-xs font-bold text-white shadow-xl transition-all ${
                isGenerating || getMissingInfoWarnings().length > 0
                  ? 'bg-zinc-800 opacity-60 cursor-not-allowed border border-white/[0.05]'
                  : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30 active:scale-95'
              }`}
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-white" />
                  <span>Drafting Agreement with Gemini AI...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-emerald-200" />
                  <span>Generate Complete Legal Draft</span>
                </>
              )}
            </button>
          </div>
        </div>
      )}

      {/* STEP 8: Final Generated Agreement Review */}
      {currentStep === 8 && (
        <div className="bento-card p-6 md:p-8 rounded-3xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/[0.06] pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 text-xs font-semibold border border-emerald-500/30">
                  Draft Successfully Generated
                </span>
                <span className="text-xs text-zinc-400 font-mono">v1.0 (AI Draft)</span>
              </div>
              <h2 className="text-xl font-bold text-white mt-1.5 font-sans">
                {currentTemplate.name} • {currentJurisdiction.countryName}
              </h2>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(generatedDraftText);
                  alert('Contract draft copied to clipboard!');
                }}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
              >
                <Copy className="w-3.5 h-3.5" />
                <span>Copy</span>
              </button>
              <button
                onClick={() => createdContractObj && generateContractPdf(createdContractObj, generatedDraftText)}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export PDF</span>
              </button>
              <button
                onClick={() => createdContractObj && onNavigateToVetting(createdContractObj)}
                className="flex items-center gap-1.5 px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-amber-600/20 active:scale-95 transition-all"
              >
                <ShieldAlert className="w-3.5 h-3.5" />
                <span>Run AI Legal Vetting</span>
              </button>
              <button
                onClick={() => createdContractObj && onNavigateToSigning(createdContractObj)}
                className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-600/20 active:scale-95 transition-all"
              >
                <PenTool className="w-3.5 h-3.5" />
                <span>Send for E-Signature</span>
              </button>
            </div>
          </div>

          {/* Lawyer Review Notes Banner */}
          {lawyerReviewNotes.length > 0 && (
            <div className="p-5 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-1.5">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300">
                <Scale className="w-4 h-4 text-amber-400" />
                <span>Recommended Attorney Review Items for {currentJurisdiction.countryName}:</span>
              </div>
              <ul className="list-disc list-inside text-xs text-amber-200/90 space-y-1">
                {lawyerReviewNotes.map((note, i) => (
                  <li key={i}>{note}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Editable Draft Text Area */}
          <div className="space-y-2">
            <div className="flex justify-between items-center text-xs text-zinc-400">
              <span className="font-semibold text-zinc-300">Complete Agreement Text (Editable):</span>
              <span>{generatedDraftText.length} characters • {generatedDraftText.split('\n').length} lines</span>
            </div>
            <textarea
              id="wizard-final-draft-editor"
              rows={18}
              value={generatedDraftText}
              onChange={(e) => setGeneratedDraftText(e.target.value)}
              className="w-full bg-zinc-950 border border-white/[0.08] rounded-2xl p-5 text-xs font-mono text-zinc-200 leading-relaxed focus:outline-none focus:border-emerald-500 transition-colors"
            />
          </div>

          {/* Bottom Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/[0.06]">
            <button
              onClick={() => {
                setCurrentStep(1);
                setIsSavedToRepo(false);
              }}
              className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded-xl text-xs font-semibold border border-white/[0.06] transition-all"
            >
              Start New Draft
            </button>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  if (createdContractObj) {
                    // Update contract with any edits made in the textarea
                    const updatedContract: ContractItem = {
                      ...createdContractObj,
                      lastModifiedDate: new Date().toISOString().split('T')[0],
                      versions: createdContractObj.versions && createdContractObj.versions.length > 0
                        ? [
                            {
                              ...createdContractObj.versions[0],
                              content: generatedDraftText
                            },
                            ...createdContractObj.versions.slice(1)
                          ]
                        : [
                            {
                              versionNumber: 'v1.0 (AI Draft)',
                              createdAt: new Date().toISOString(),
                              createdBy: `${primaryParty.signatoryName || 'Marcus Vance'} (Creator)`,
                              content: generatedDraftText,
                              changeLog: 'Initial drafted agreement saved to repository.',
                              isAiGenerated: true,
                              isLocked: false
                            }
                          ]
                    };
                    setCreatedContractObj(updatedContract);
                    onContractCreated(updatedContract);
                    setIsSavedToRepo(true);
                  }
                }}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold border transition-all ${
                  isSavedToRepo
                    ? 'bg-emerald-600/20 text-emerald-400 border-emerald-500/40 shadow-sm'
                    : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border-white/[0.06]'
                }`}
              >
                {isSavedToRepo ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Saved to Repository & Cloud DB</span>
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4 text-zinc-300" />
                    <span>Save to Repository</span>
                  </>
                )}
              </button>

              {isSavedToRepo && onNavigateToRepository && (
                <button
                  onClick={onNavigateToRepository}
                  className="flex items-center gap-1.5 px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
                >
                  <ArrowRight className="w-3.5 h-3.5" />
                  <span>View in Repository</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Full Sample Draft Preview Modal */}
      {previewingSampleDraft && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-zinc-900 border border-white/[0.1] rounded-3xl w-full max-w-4xl max-h-[85vh] flex flex-col shadow-2xl overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 sm:p-6 border-b border-white/[0.08] flex items-center justify-between bg-zinc-950/90">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center shrink-0">
                  <BookOpen className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
                    Full Standard Agreement Sample
                    <span className="text-xs font-normal text-zinc-400">• {currentTemplate.name}</span>
                  </h3>
                  <p className="text-xs text-zinc-400 mt-0.5">
                    Multi-page reference contract containing all {detailedClausesList.length} fully expanded standard clauses.
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => copyClauseText('sample-draft-full', currentTemplate.sampleDraft || '')}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium border border-white/[0.08] transition-all"
                >
                  {copiedClauseId === 'sample-draft-full' ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-zinc-400" />
                      <span>Copy Draft</span>
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => setPreviewingSampleDraft(false)}
                  className="w-8 h-8 rounded-xl bg-zinc-800 hover:bg-zinc-700 text-zinc-400 hover:text-white flex items-center justify-center border border-white/[0.08] transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 overflow-y-auto custom-scrollbar flex-1 bg-zinc-950/40">
              <pre className="text-xs font-mono text-zinc-300 leading-relaxed whitespace-pre-wrap selection:bg-emerald-500/30">
                {currentTemplate.sampleDraft}
              </pre>
            </div>

            {/* Modal Footer */}
            <div className="p-4 border-t border-white/[0.08] bg-zinc-950/90 flex items-center justify-between">
              <span className="text-xs text-zinc-500 font-mono">
                {currentTemplate.sampleDraft?.split('\n').length} lines • {detailedClausesList.length} clauses architecture
              </span>
              <button
                type="button"
                onClick={() => setPreviewingSampleDraft(false)}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all active:scale-95"
              >
                Done Reviewing
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
