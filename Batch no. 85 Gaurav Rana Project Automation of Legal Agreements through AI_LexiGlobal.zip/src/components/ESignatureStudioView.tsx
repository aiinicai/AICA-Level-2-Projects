import React, { useState, useRef } from 'react';
import { 
  PenTool, 
  ShieldCheck, 
  Download, 
  CheckCircle2, 
  Lock, 
  FileText, 
  Sparkles, 
  Smartphone, 
  Mail, 
  Key, 
  RefreshCw, 
  Globe2,
  Send,
  Scale
} from 'lucide-react';
import { ContractItem, ContractParty } from '../types';
import { generateContractPdf, computeSha256 } from '../utils/pdfExport';

interface ESignatureStudioProps {
  contracts: ContractItem[];
  activeContract?: ContractItem | null;
  onContractExecuted?: (contract: ContractItem) => void;
  onNavigateToDistribution?: (contract: ContractItem) => void;
}

export const ESignatureStudioView: React.FC<ESignatureStudioProps> = ({
  contracts,
  activeContract,
  onContractExecuted,
  onNavigateToDistribution
}) => {
  const [selectedContractId, setSelectedContractId] = useState<string>(activeContract?.id || contracts[0]?.id || '');
  const currentContract = contracts.find(c => c.id === selectedContractId) || contracts[0];

  // Signature Input Type: 'type' | 'draw' | 'upload'
  const [sigMode, setSigMode] = useState<'type' | 'draw' | 'upload'>('type');
  const [typedSignatoryName, setTypedSignatoryName] = useState<string>(currentContract?.primaryParty.signatoryName || 'Marcus Vance');
  const [typedSignatoryDesignation, setTypedSignatoryDesignation] = useState<string>(currentContract?.primaryParty.signatoryDesignation || 'Chief Executive Officer');
  const [selectedFont, setSelectedFont] = useState<string>('font-serif italic');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);

  // Canvas drawing ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState<boolean>(false);

  // Authentication State
  const [authMethod, setAuthMethod] = useState<'email_otp' | 'sms_otp' | 'dsc' | 'aadhaar_esign'>('email_otp');
  const [otpCode, setOtpCode] = useState<string>('748291');
  const [isOtpVerified, setIsOtpVerified] = useState<boolean>(true);
  const [isSigning, setIsSigning] = useState<boolean>(false);
  const [isFullySigned, setIsFullySigned] = useState<boolean>(
    currentContract?.status === 'fully_executed' || currentContract?.status === 'active'
  );
  const [docHash, setDocHash] = useState<string>('8f43a9b1834c2ee571d803d2194a0b2713fce0891d4e082136e053a992bc44e1');

  // Canvas Drawing Handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    setIsDrawing(true);
    const rect = canvas.getBoundingClientRect();
    ctx.beginPath();
    ctx.moveTo(e.clientX - rect.left, e.clientY - rect.top);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.lineTo(e.clientX - rect.left, e.clientY - rect.top);
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2.5;
    ctx.stroke();
  };

  const stopDrawing = () => {
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  // Execute Digital Signature
  const handleExecuteSignature = async () => {
    setIsSigning(true);
    
    // Compute fresh SHA-256 hash of content
    const content = currentContract.versions[currentContract.currentVersionIndex]?.content || '';
    const hash = await computeSha256(content + new Date().toISOString());
    setDocHash(hash);

    setTimeout(() => {
      setIsSigning(false);
      setIsFullySigned(true);

      const executedContract: ContractItem = {
        ...currentContract,
        status: 'fully_executed',
        primaryParty: {
          ...currentContract.primaryParty,
          signatoryName: typedSignatoryName,
          signatoryDesignation: typedSignatoryDesignation,
          signatureStatus: 'signed',
          signedAt: new Date().toISOString(),
          ipAddress: '103.22.18.94 (Verified Node)',
          authMethod
        },
        counterparty: {
          ...currentContract.counterparty,
          signatureStatus: 'signed',
          signedAt: new Date().toISOString(),
          ipAddress: '198.51.100.22 (Verified Client)',
          authMethod
        },
        executionMetadata: {
          signedPdfHash: hash,
          certificateId: `CERT-GL-${Date.now()}`,
          signedTimestamp: new Date().toISOString(),
          tamperEvidentSeal: true
        }
      };

      if (onContractExecuted) {
        onContractExecuted(executedContract);
      }
    }, 1200);
  };

  return (
    <div id="esignature-studio-view" className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-cyan-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <PenTool className="w-3.5 h-3.5 text-emerald-400" />
                Cross-Border E-Signature Studio
              </span>
              <span className="text-xs text-zinc-500 font-mono">SHA-256 Tamper-Evident Integrity</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Legally Binding Digital Signature Execution
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Execute cross-border agreements compliant with U.S. E-SIGN, EU eIDAS, Section 10A IT Act (India), Singapore ETA, and UAE Federal Law.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedContractId}
              onChange={(e) => {
                setSelectedContractId(e.target.value);
                const c = contracts.find(item => item.id === e.target.value);
                if (c) {
                  setTypedSignatoryName(c.primaryParty.signatoryName || 'Marcus Vance');
                  setTypedSignatoryDesignation(c.primaryParty.signatoryDesignation || 'Chief Executive Officer');
                  setIsFullySigned(c.status === 'fully_executed' || c.status === 'active');
                }
              }}
              className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-200 rounded-2xl px-4 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
            >
              {contracts.map(c => (
                <option key={c.id} value={c.id} className="bg-zinc-900 text-white">
                  {c.contractNumber} • {c.title.substring(0, 30)}...
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Signing Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (5 cols): Signatory & Authentication Controls */}
        <div className="lg:col-span-5 space-y-5">
          
          {/* Signatory Details Card */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/[0.06] pb-3">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Authorized Signatory Identity
            </h3>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1.5 font-medium">Signatory Legal Name</label>
                <input
                  type="text"
                  value={typedSignatoryName}
                  onChange={(e) => setTypedSignatoryName(e.target.value)}
                  placeholder="e.g. Marcus Vance"
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-zinc-400 font-medium">Signatory Designation / Official Title</label>
                  <span className="text-[10px] text-emerald-400 font-mono">Corporate Capacity</span>
                </div>
                <input
                  type="text"
                  value={typedSignatoryDesignation}
                  onChange={(e) => setTypedSignatoryDesignation(e.target.value)}
                  placeholder="e.g. Chief Executive Officer / Managing Director"
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                />
                {/* Quick Designation Presets */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {['Chief Executive Officer', 'Managing Director', 'VP Operations', 'General Counsel', 'Director', 'Authorized Signatory'].map(title => (
                    <button
                      key={title}
                      type="button"
                      onClick={() => setTypedSignatoryDesignation(title)}
                      className={`text-[10px] px-2 py-0.5 rounded-lg border transition-colors ${
                        typedSignatoryDesignation === title
                          ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                          : 'bg-zinc-900 border-white/[0.06] text-zinc-400 hover:text-zinc-200 hover:border-white/20'
                      }`}
                    >
                      {title}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-zinc-400 mb-1.5 font-medium">Identity Verification Method</label>
                <div className="grid grid-cols-2 gap-2.5">
                  {[
                    { id: 'email_otp', label: 'Email OTP (2FA)', icon: Mail },
                    { id: 'sms_otp', label: 'SMS OTP (2FA)', icon: Smartphone },
                    { id: 'dsc', label: 'Digital Cert (DSC)', icon: Key },
                    { id: 'aadhaar_esign', label: 'Statutory E-Sign', icon: Scale }
                  ].map(m => {
                    const Icon = m.icon;
                    return (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setAuthMethod(m.id as any)}
                        className={`p-2.5 rounded-2xl border text-[11px] font-medium flex items-center gap-2 transition-all ${
                          authMethod === m.id
                            ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300 shadow-sm shadow-emerald-500/10'
                            : 'bg-zinc-950/80 border-white/[0.06] text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/60'
                        }`}
                      >
                        <Icon className="w-3.5 h-3.5" />
                        <span>{m.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* OTP Verification Simulation */}
              <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-emerald-500/20 flex items-center justify-between shadow-inner">
                <div className="flex items-center gap-2 text-xs">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-zinc-300">Identity Token: <strong className="font-mono text-emerald-300">VERIFIED-OTP-748291</strong></span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                  Ready
                </span>
              </div>
            </div>
          </div>

          {/* Signature Creation Palette Card */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <PenTool className="w-4 h-4 text-cyan-400" />
                Select Signature Format
              </h3>

              <div className="flex items-center gap-1 bg-zinc-950/90 p-1 rounded-xl border border-white/[0.08] text-xs">
                <button
                  onClick={() => setSigMode('type')}
                  className={`px-3 py-1 rounded-lg font-medium transition-all ${sigMode === 'type' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
                >
                  Type
                </button>
                <button
                  onClick={() => setSigMode('draw')}
                  className={`px-3 py-1 rounded-lg font-medium transition-all ${sigMode === 'draw' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm' : 'text-zinc-400 hover:text-zinc-200'}`}
                >
                  Draw
                </button>
              </div>
            </div>

            {/* Type Mode */}
            {sigMode === 'type' && (
              <div className="space-y-3">
                <div className="p-4 rounded-2xl bg-zinc-950/90 border border-white/[0.08] flex items-center justify-center min-h-[90px] shadow-inner">
                  <span className={`text-2xl text-emerald-300 tracking-wide ${selectedFont}`}>
                    {typedSignatoryName || 'Marcus Vance'}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-xs text-zinc-400">
                  <span>Font Style:</span>
                  <button
                    onClick={() => setSelectedFont('font-serif italic font-light')}
                    className="px-2.5 py-1 bg-zinc-900 border border-white/[0.08] rounded-xl text-zinc-300 hover:text-white hover:border-white/20 transition-colors"
                  >
                    Classic Serif
                  </button>
                  <button
                    onClick={() => setSelectedFont('font-mono italic')}
                    className="px-2.5 py-1 bg-zinc-900 border border-white/[0.08] rounded-xl text-zinc-300 hover:text-white hover:border-white/20 transition-colors"
                  >
                    Modern Cursive
                  </button>
                </div>
              </div>
            )}

            {/* Draw Mode */}
            {sigMode === 'draw' && (
              <div className="space-y-2">
                <canvas
                  ref={canvasRef}
                  width={340}
                  height={100}
                  onMouseDown={startDrawing}
                  onMouseMove={draw}
                  onMouseUp={stopDrawing}
                  onMouseLeave={stopDrawing}
                  className="w-full bg-zinc-950 border border-white/[0.08] rounded-2xl cursor-crosshair shadow-inner"
                />
                <div className="flex justify-between items-center text-xs">
                  <span className="text-[11px] text-zinc-500">Draw inside using your mouse or touch</span>
                  <button
                    onClick={clearCanvas}
                    className="text-[11px] text-zinc-400 hover:text-rose-400 underline"
                  >
                    Clear Drawing
                  </button>
                </div>
              </div>
            )}

            {/* Execute Signature Action Button */}
            <button
              id="execute-esignature-btn"
              onClick={handleExecuteSignature}
              disabled={isSigning || isFullySigned}
              className={`w-full py-3.5 rounded-2xl text-xs font-bold text-white shadow-xl flex items-center justify-center gap-2 transition-all ${
                isFullySigned
                  ? 'bg-emerald-600 opacity-90 cursor-default shadow-emerald-500/20'
                  : isSigning
                  ? 'bg-zinc-800 opacity-70 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-600 via-teal-600 to-cyan-600 hover:opacity-95 shadow-lg shadow-emerald-600/20 hover:scale-[1.02] active:scale-95'
              }`}
            >
              {isFullySigned ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-white" />
                  <span>Document Fully Executed & Sealed</span>
                </>
              ) : isSigning ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-300" />
                  <span>Affixing Digital Cryptographic Seal...</span>
                </>
              ) : (
                <>
                  <PenTool className="w-4 h-4 text-emerald-300" />
                  <span>Affix Digital Signature & Execute</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Right Column (7 cols): Document Preview & Audit Trail Certificate */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Document Preview Card */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <div>
                <span className="text-xs font-mono text-emerald-400">{currentContract.contractNumber}</span>
                <h3 className="font-bold text-sm text-white mt-0.5">{currentContract.title}</h3>
              </div>

              {isFullySigned && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => generateContractPdf(currentContract)}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-95"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download Signed PDF</span>
                  </button>
                  {onNavigateToDistribution && (
                    <button
                      onClick={() => onNavigateToDistribution(currentContract)}
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold border border-white/[0.08] shadow-md transition-all hover:scale-[1.02] active:scale-95"
                    >
                      <Send className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Distribute</span>
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Document Content Scrollbox */}
            <div className="bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-5 text-xs font-mono text-zinc-300 max-h-[300px] overflow-y-auto leading-relaxed whitespace-pre-wrap shadow-inner">
              {currentContract.versions[currentContract.currentVersionIndex]?.content}
            </div>

            {/* Execution Audit Certificate Stamp Box */}
            <div className="p-5 rounded-2xl bg-zinc-950/90 border border-emerald-500/20 text-xs space-y-3 shadow-inner">
              <div className="flex items-center justify-between border-b border-white/[0.06] pb-2.5">
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-white uppercase text-[11px] tracking-wider">
                    Certificate of Execution & Tamper-Evident Audit Trail
                  </span>
                </div>
                <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono text-emerald-300 bg-emerald-500/10 border border-emerald-500/30">
                  SHA-256 Validated
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-[11px]">
                <div className="bg-zinc-900/60 p-3 rounded-xl border border-white/[0.04]">
                  <span className="text-zinc-500 block text-[10px] font-semibold uppercase">Primary Signatory:</span>
                  <span className="text-zinc-200 font-medium block">{currentContract.primaryParty.signatoryName}</span>
                  <span className="text-zinc-400 text-[10px] block">{currentContract.primaryParty.signatoryDesignation} • {currentContract.primaryParty.signatoryEmail}</span>
                  <span className="text-emerald-400 block text-[10px] mt-1 font-semibold">
                    Status: {isFullySigned ? 'SIGNED & TIMESTAMPED' : 'PENDING SIGNATURE'}
                  </span>
                </div>

                <div className="bg-zinc-900/60 p-3 rounded-xl border border-white/[0.04]">
                  <span className="text-zinc-500 block text-[10px] font-semibold uppercase">Counterparty Signatory:</span>
                  <span className="text-zinc-200 font-medium block">{currentContract.counterparty.signatoryName}</span>
                  <span className="text-zinc-400 text-[10px] block">{currentContract.counterparty.signatoryDesignation} • {currentContract.counterparty.signatoryEmail}</span>
                  <span className="text-emerald-400 block text-[10px] mt-1 font-semibold">
                    Status: {isFullySigned ? 'SIGNED VIA REMOTE 2FA' : 'READY FOR RECIPIENT'}
                  </span>
                </div>
              </div>

              <div className="pt-1 text-[10px] text-zinc-400 font-mono break-all bg-zinc-900/40 p-2 rounded-xl border border-white/[0.04]">
                <span className="text-zinc-500">Document Cryptographic Hash:</span> {docHash}
              </div>
            </div>

          </div>

        </div>

      </div>

    </div>
  );
};
