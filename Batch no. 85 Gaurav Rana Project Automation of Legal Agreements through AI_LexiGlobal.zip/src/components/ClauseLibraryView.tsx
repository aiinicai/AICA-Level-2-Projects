import React, { useState } from 'react';
import { 
  BookOpen, 
  Search, 
  Copy, 
  Check, 
  Sparkles, 
  Sliders, 
  Scale, 
  ShieldCheck, 
  Plus, 
  Globe2, 
  TrendingUp, 
  ChevronRight,
  PlusCircle
} from 'lucide-react';
import { STANDARD_CLAUSE_BENCHMARKS } from '../data/legalKnowledgeBase';
import { ClauseBenchmark } from '../types';

export const ClauseLibraryView: React.FC = () => {
  const [clauses, setClauses] = useState<ClauseBenchmark[]>(STANDARD_CLAUSE_BENCHMARKS);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [selectedClauseId, setSelectedClauseId] = useState<string>(STANDARD_CLAUSE_BENCHMARKS[0]?.id || '');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // New Clause Modal State
  const [isAddingClause, setIsAddingClause] = useState<boolean>(false);
  const [newClauseTitle, setNewClauseTitle] = useState<string>('');
  const [newClauseCategory, setNewClauseCategory] = useState<string>('liability');
  const [newMarketStandard, setNewMarketStandard] = useState<string>('');
  const [newCompanyFriendly, setNewCompanyFriendly] = useState<string>('');
  const [newCounterpartyFriendly, setNewCounterpartyFriendly] = useState<string>('');

  const filteredClauses = clauses.filter(c => {
    const nameStr = c.name || c.clauseName || '';
    const descStr = c.description || c.explanation || '';
    const query = searchQuery ? searchQuery.toLowerCase() : '';
    const matchesSearch = !query || 
                          nameStr.toLowerCase().includes(query) ||
                          descStr.toLowerCase().includes(query);
    const matchesCategory = selectedCategory === 'ALL' || c.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const activeClause = clauses.find(c => c.id === selectedClauseId) || filteredClauses[0] || clauses[0];

  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleCreateClause = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newClauseTitle || !newMarketStandard) return;

    const newClause: ClauseBenchmark = {
      id: `cls-custom-${Date.now()}`,
      name: newClauseTitle,
      category: newClauseCategory as any,
      description: `Custom organizational clause standard for ${newClauseTitle}.`,
      marketStandard: newMarketStandard,
      companyFriendly: newCompanyFriendly || newMarketStandard,
      counterpartyFriendly: newCounterpartyFriendly || newMarketStandard,
      recommendedCompromise: newMarketStandard,
      benchmarkRange: 'Configured per organizational internal governance standard.',
      jurisdictionVariations: {
        'Global': 'Standard universal application.'
      }
    };

    setClauses([newClause, ...clauses]);
    setSelectedClauseId(newClause.id);
    setIsAddingClause(false);
    setNewClauseTitle('');
    setNewMarketStandard('');
    setNewCompanyFriendly('');
    setNewCounterpartyFriendly('');
  };

  return (
    <div id="clause-library-view" className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-teal-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
                Global Clause Benchmark Library
              </span>
              <span className="text-xs text-zinc-500 font-mono">Market Standard vs Aggressive vs Fallback</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Approved Clause Intelligence & Fallback Repository
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Inspect side-by-side variations of core legal provisions across international jurisdictions, market ranges, and organizational playbooks.
            </p>
          </div>

          <button
            onClick={() => setIsAddingClause(true)}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-95 shrink-0"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Add Custom Clause Standard</span>
          </button>
        </div>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4 rounded-3xl shadow-xl flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-1 min-w-[260px] bg-zinc-950/90 px-3.5 py-2.5 rounded-2xl border border-white/[0.08] shadow-inner">
          <Search className="w-4 h-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Search clause library (e.g. 'indemnity', 'liability cap', 'breach notice')..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent text-xs text-white placeholder-zinc-500 focus:outline-none w-full"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto text-xs py-1 scrollbar-thin">
          {[
            { id: 'ALL', label: 'All Clauses' },
            { id: 'definitions_scope', label: 'Definitions & Scope' },
            { id: 'sla_support', label: 'SLA & 24/7 Support' },
            { id: 'data_protection', label: 'Data Protection & DPA' },
            { id: 'cybersecurity', label: 'Cybersecurity & Security' },
            { id: 'liability', label: 'Liability & Indemnity' },
            { id: 'warranties', label: 'Warranties & Authority' },
            { id: 'term_termination', label: 'Term, Exit & Survival' },
            { id: 'bcp_dr', label: 'BCP & Disaster Recovery' },
            { id: 'ip', label: 'IP & Data Ownership' },
            { id: 'operations', label: 'Subcontracting & Audits' },
            { id: 'governance', label: 'Governance & Boilerplate' },
            { id: 'dispute_resolution', label: 'Dispute Resolution' }
          ].map(c => (
            <button
              key={c.id}
              onClick={() => setSelectedCategory(c.id)}
              className={`px-3.5 py-1.5 rounded-xl font-medium whitespace-nowrap transition-all ${
                selectedCategory === c.id
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm'
                  : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/[0.06]'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Left Clause List • Right Detailed 4-Way Variation Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (4 cols): Clause Catalog List */}
        <div className="lg:col-span-4 space-y-2">
          <div className="text-xs font-semibold text-zinc-400 px-1 mb-1 flex items-center justify-between">
            <span>Available Clauses ({filteredClauses.length})</span>
            <span className="text-[10px] text-zinc-500 font-mono">Curated Library</span>
          </div>
          <div className="space-y-2.5 max-h-[640px] overflow-y-auto pr-1">
            {filteredClauses.map((clause) => {
              const isSelected = clause.id === activeClause?.id;
              return (
                <div
                  key={clause.id}
                  onClick={() => setSelectedClauseId(clause.id)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-emerald-950/20 border-emerald-500/40 ring-1 ring-emerald-500/30 shadow-lg'
                      : 'bg-[#121215]/80 border-white/[0.06] hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white">{clause.name}</span>
                    <ChevronRight className={`w-3.5 h-3.5 ${isSelected ? 'text-emerald-400' : 'text-zinc-600'}`} />
                  </div>
                  <p className="text-[11px] text-zinc-400 mt-1 line-clamp-2 leading-relaxed">
                    {clause.description}
                  </p>
                  <div className="mt-2.5 text-[10px] text-zinc-500 flex items-center justify-between">
                    <span className="capitalize">{clause.category.replace(/_/g, ' ')}</span>
                    <span className="text-emerald-400 font-mono">Market Verified</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Column (8 cols): 4-Way Side-by-Side Comparison */}
        {activeClause && (
          <div className="lg:col-span-8 space-y-5">
            
            {/* Clause Header Card */}
            <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-3.5">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.06] pb-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 uppercase">
                      {activeClause.category.replace(/_/g, ' ')}
                    </span>
                    <span className="text-xs text-zinc-500 font-mono">Standard ID: {activeClause.id}</span>
                  </div>
                  <h2 className="text-xl font-bold text-white mt-1">{activeClause.name}</h2>
                </div>

                <div className="p-3 rounded-2xl bg-zinc-950/80 border border-white/[0.06] text-right">
                  <span className="text-[10px] text-zinc-500 uppercase font-semibold block">Market Benchmark Range</span>
                  <span className="text-xs font-bold text-cyan-300 mt-0.5 block">{activeClause.benchmarkRange}</span>
                </div>
              </div>

              <p className="text-xs text-zinc-300 leading-relaxed">
                {activeClause.description}
              </p>
            </div>

            {/* 4-Way Position Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* 1. Market Standard Position */}
              <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-5 shadow-lg space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-white/[0.06] pb-2.5 mb-2.5">
                    <span className="font-bold text-xs text-cyan-300 flex items-center gap-1.5">
                      <Scale className="w-3.5 h-3.5 text-cyan-400" />
                      1. Standard Market Position
                    </span>
                    <span className="text-[10px] text-zinc-500 font-medium">Neutral Balance</span>
                  </div>
                  <p className="font-mono text-xs text-zinc-300 bg-zinc-950/90 p-3.5 rounded-2xl border border-white/[0.08] leading-relaxed min-h-[110px] shadow-inner">
                    {activeClause.marketStandard}
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(activeClause.marketStandard, 'market')}
                  className="flex items-center justify-center gap-1.5 w-full py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 rounded-xl text-xs font-semibold border border-white/[0.06] transition-colors mt-2"
                >
                  {copiedKey === 'market' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'market' ? 'Copied to Clipboard' : 'Copy Market Standard'}</span>
                </button>
              </div>

              {/* 2. Company-Friendly Position */}
              <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-5 shadow-lg space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-white/[0.06] pb-2.5 mb-2.5">
                    <span className="font-bold text-xs text-emerald-300 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      2. Company-Friendly (Aggressive Protection)
                    </span>
                    <span className="text-[10px] text-emerald-400 font-medium">Maximum Defense</span>
                  </div>
                  <p className="font-mono text-xs text-zinc-300 bg-zinc-950/90 p-3.5 rounded-2xl border border-white/[0.08] leading-relaxed min-h-[110px] shadow-inner">
                    {activeClause.companyFriendly}
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(activeClause.companyFriendly, 'company')}
                  className="flex items-center justify-center gap-1.5 w-full py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 rounded-xl text-xs font-semibold border border-white/[0.06] transition-colors mt-2"
                >
                  {copiedKey === 'company' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'company' ? 'Copied to Clipboard' : 'Copy Company-Friendly'}</span>
                </button>
              </div>

              {/* 3. Counterparty-Friendly Position */}
              <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-5 shadow-lg space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-white/[0.06] pb-2.5 mb-2.5">
                    <span className="font-bold text-xs text-amber-300 flex items-center gap-1.5">
                      <Sliders className="w-3.5 h-3.5 text-amber-400" />
                      3. Counterparty-Friendly Position
                    </span>
                    <span className="text-[10px] text-amber-400 font-medium">Vendor / Customer Favored</span>
                  </div>
                  <p className="font-mono text-xs text-zinc-300 bg-zinc-950/90 p-3.5 rounded-2xl border border-white/[0.08] leading-relaxed min-h-[110px] shadow-inner">
                    {activeClause.counterpartyFriendly}
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(activeClause.counterpartyFriendly, 'counterparty')}
                  className="flex items-center justify-center gap-1.5 w-full py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 rounded-xl text-xs font-semibold border border-white/[0.06] transition-colors mt-2"
                >
                  {copiedKey === 'counterparty' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'counterparty' ? 'Copied to Clipboard' : 'Copy Counterparty Position'}</span>
                </button>
              </div>

              {/* 4. Recommended Compromise Fallback */}
              <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-5 shadow-lg space-y-2 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b border-white/[0.06] pb-2.5 mb-2.5">
                    <span className="font-bold text-xs text-teal-300 flex items-center gap-1.5">
                      <Sparkles className="w-3.5 h-3.5 text-teal-400" />
                      4. Recommended Compromise (Negotiation Fallback)
                    </span>
                    <span className="text-[10px] text-teal-400 font-medium">Deal Closer</span>
                  </div>
                  <p className="font-mono text-xs text-zinc-300 bg-zinc-950/90 p-3.5 rounded-2xl border border-white/[0.08] leading-relaxed min-h-[110px] shadow-inner">
                    {activeClause.recommendedCompromise}
                  </p>
                </div>
                <button
                  onClick={() => handleCopy(activeClause.recommendedCompromise, 'compromise')}
                  className="flex items-center justify-center gap-1.5 w-full py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-semibold shadow-md transition-all mt-2"
                >
                  {copiedKey === 'compromise' ? <Check className="w-3.5 h-3.5 text-white" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'compromise' ? 'Copied to Clipboard' : 'Copy Recommended Fallback'}</span>
                </button>
              </div>

            </div>

            {/* Jurisdiction Variations Accordion / Panel */}
            {activeClause.jurisdictionVariations && (
              <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-3.5">
                <h3 className="text-xs font-bold text-white flex items-center gap-2">
                  <Globe2 className="w-4 h-4 text-cyan-400" />
                  Statutory Jurisdictional Requirements & Local Variations
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                  {Object.entries(activeClause.jurisdictionVariations).map(([jur, rule]) => (
                    <div key={jur} className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] space-y-1">
                      <span className="font-bold text-emerald-300">{jur}</span>
                      <p className="text-[11px] text-zinc-400 leading-relaxed">{rule}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}

      </div>

      {/* Add Custom Clause Modal */}
      {isAddingClause && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#121215] border border-white/[0.1] rounded-3xl max-w-2xl w-full p-6 sm:p-7 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3.5">
              <h3 className="font-bold text-lg text-white">Add Custom Clause Benchmark to Library</h3>
              <button onClick={() => setIsAddingClause(false)} className="text-zinc-400 hover:text-white p-1 rounded-lg">✕</button>
            </div>

            <form onSubmit={handleCreateClause} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-zinc-300 font-medium mb-1.5">Clause Title</label>
                  <input
                    type="text"
                    required
                    value={newClauseTitle}
                    onChange={(e) => setNewClauseTitle(e.target.value)}
                    placeholder="e.g. Audit Rights & Inspection"
                    className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 font-medium mb-1.5">Category</label>
                  <select
                    value={newClauseCategory}
                    onChange={(e) => setNewClauseCategory(e.target.value)}
                    className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  >
                    <option value="liability" className="bg-zinc-900 text-white">Liability & Indemnity</option>
                    <option value="data_protection" className="bg-zinc-900 text-white">Data & Privacy</option>
                    <option value="term_termination" className="bg-zinc-900 text-white">Term & Termination</option>
                    <option value="ip" className="bg-zinc-900 text-white">IP Ownership</option>
                    <option value="restrictive_covenants" className="bg-zinc-900 text-white">Non-Compete</option>
                    <option value="dispute_resolution" className="bg-zinc-900 text-white">Governing Law</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-zinc-300 font-medium mb-1.5">Standard Market Wording</label>
                <textarea
                  rows={2}
                  required
                  value={newMarketStandard}
                  onChange={(e) => setNewMarketStandard(e.target.value)}
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-xl p-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div>
                <label className="block text-zinc-300 font-medium mb-1.5">Company-Friendly Wording (Optional)</label>
                <textarea
                  rows={2}
                  value={newCompanyFriendly}
                  onChange={(e) => setNewCompanyFriendly(e.target.value)}
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-xl p-2.5 text-white font-mono text-xs focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div className="flex justify-end gap-2.5 pt-3 border-t border-white/[0.06]">
                <button
                  type="button"
                  onClick={() => setIsAddingClause(false)}
                  className="px-4 py-2 bg-zinc-900 text-zinc-300 rounded-xl font-semibold border border-white/[0.06] hover:bg-zinc-800"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold shadow-lg shadow-emerald-600/20 transition-all"
                >
                  Save to Clause Library
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
