import React, { useState } from 'react';
import { 
  Database, 
  Search, 
  Filter, 
  Scale, 
  ShieldCheck, 
  AlertTriangle, 
  PlusCircle, 
  CheckCircle2, 
  Globe2, 
  BookOpen, 
  ExternalLink,
  ChevronRight,
  Layers,
  Download,
  FileText,
  Copy,
  Check,
  Building2,
  Calendar,
  Sparkles,
  X,
  FileDown,
  Briefcase,
  AlertOctagon,
  HelpCircle
} from 'lucide-react';
import { JURISDICTION_LEGAL_RULES } from '../data/legalKnowledgeBase';
import { LegalRule } from '../types';
import { GLOBAL_JURISDICTIONS } from '../data/jurisdictions';
import { 
  downloadBareActPdf,
  downloadBareActText,
  downloadActSoftCopyPdf, 
  downloadActSoftCopyText, 
  downloadCountryCompendiumPdf 
} from '../utils/actExport';
import { getBareActForRule, getFullBareActText } from '../data/bareActsData';

export const KnowledgeBaseAdminView: React.FC = () => {
  const [rules, setRules] = useState<LegalRule[]>(JURISDICTION_LEGAL_RULES);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCountry, setSelectedCountry] = useState<string>('ALL');
  const [selectedSubject, setSelectedSubject] = useState<string>('ALL');
  const [selectedStatus, setSelectedStatus] = useState<string>('ALL');

  // Act Detail Modal State
  const [selectedRuleForActModal, setSelectedRuleForActModal] = useState<LegalRule | null>(null);
  const [modalActiveTab, setModalActiveTab] = useState<'bare_act' | 'analysis'>('bare_act');
  const [copiedClause, setCopiedClause] = useState<boolean>(false);
  const [copiedFullAct, setCopiedFullAct] = useState<boolean>(false);
  const [copiedSectionIndex, setCopiedSectionIndex] = useState<string | null>(null);

  // Modal State for Adding / Updating Legal Rule
  const [isAddingRule, setIsAddingRule] = useState<boolean>(false);
  const [editingRuleId, setEditingRuleId] = useState<string | null>(null);

  // Form State
  const [ruleName, setRuleName] = useState<string>('');
  const [formCountry, setFormCountry] = useState<string>('India');
  const [statutoryCitation, setStatutoryCitation] = useState<string>('');
  const [subjectArea, setSubjectArea] = useState<LegalRule['subjectArea']>('employment');
  const [requirement, setRequirement] = useState<string>('');
  const [isMandatory, setIsMandatory] = useState<boolean>(true);
  const [confidenceScore, setConfidenceScore] = useState<number>(98);
  const [verificationStatus, setVerificationStatus] = useState<LegalRule['verificationStatus']>('verified');
  const [reviewerCredentials, setReviewerCredentials] = useState<string>('Senior Legal Compliance Counsel');

  const filteredRules = rules.filter(r => {
    const q = searchQuery ? searchQuery.toLowerCase() : '';
    const rName = r.ruleName || '';
    const rActTitle = r.fullActTitle || '';
    const rCitation = r.statutoryCitation || '';
    const rReq = r.legalRequirement || '';
    const rSummary = r.actSummary || '';
    const matchesSearch = !q ||
      rName.toLowerCase().includes(q) ||
      rActTitle.toLowerCase().includes(q) ||
      rCitation.toLowerCase().includes(q) ||
      rReq.toLowerCase().includes(q) ||
      rSummary.toLowerCase().includes(q);

    const matchesCountry = selectedCountry === 'ALL' || r.country === selectedCountry;
    const matchesSubject = selectedSubject === 'ALL' || r.subjectArea === selectedSubject;
    const matchesStatus = selectedStatus === 'ALL' || r.verificationStatus === selectedStatus;

    return matchesSearch && matchesCountry && matchesSubject && matchesStatus;
  });

  const handleSaveRule = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName || !statutoryCitation || !requirement) return;

    if (editingRuleId) {
      setRules(prev => prev.map(r => {
        if (r.id === editingRuleId) {
          return {
            ...r,
            ruleName,
            country: formCountry,
            statutoryCitation,
            subjectArea,
            legalRequirement: requirement,
            isMandatory,
            confidenceScore,
            verificationStatus,
            reviewerCredentials,
            lastVerifiedDate: new Date().toISOString().split('T')[0]
          };
        }
        return r;
      }));
    } else {
      const newRule: LegalRule = {
        id: `rule-custom-${Date.now()}`,
        ruleName,
        country: formCountry,
        statutoryCitation,
        subjectArea,
        legalRequirement: requirement,
        isMandatory,
        confidenceScore,
        verificationStatus,
        reviewerCredentials,
        lastVerifiedDate: new Date().toISOString().split('T')[0]
      };
      setRules(prev => [newRule, ...prev]);
    }

    setIsAddingRule(false);
    setEditingRuleId(null);
  };

  const handleEdit = (rule: LegalRule) => {
    setEditingRuleId(rule.id);
    setRuleName(rule.ruleName);
    setFormCountry(rule.country);
    setStatutoryCitation(rule.statutoryCitation);
    setSubjectArea(rule.subjectArea);
    setRequirement(rule.legalRequirement);
    setIsMandatory(rule.isMandatory);
    setConfidenceScore(rule.confidenceScore);
    setVerificationStatus(rule.verificationStatus);
    setReviewerCredentials(rule.reviewerCredentials);
    setIsAddingRule(true);
  };

  const handleCopyClause = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedClause(true);
    setTimeout(() => setCopiedClause(false), 2000);
  };

  const handleCopyFullBareAct = (rule: LegalRule) => {
    const bareAct = getBareActForRule(rule);
    const text = getFullBareActText(rule, bareAct);
    navigator.clipboard.writeText(text);
    setCopiedFullAct(true);
    setTimeout(() => setCopiedFullAct(false), 2500);
  };

  const handleCopySection = (secTitle: string, secText: string, key: string) => {
    navigator.clipboard.writeText(`${secTitle}\n\n${secText}`);
    setCopiedSectionIndex(key);
    setTimeout(() => setCopiedSectionIndex(null), 2000);
  };

  // Counts for pills
  const totalCount = rules.length;
  const employmentCount = rules.filter(r => r.subjectArea === 'employment').length;
  const privacyCount = rules.filter(r => r.subjectArea === 'data_privacy').length;
  const disputeCount = rules.filter(r => r.subjectArea === 'dispute_resolution').length;
  const liabilityCount = rules.filter(r => r.subjectArea === 'liability').length;
  const eSignCount = rules.filter(r => r.subjectArea === 'e_signature').length;
  const taxCount = rules.filter(r => r.subjectArea === 'taxation').length;
  const indiaActsCount = rules.filter(r => r.country === 'India').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Header Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-teal-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-5">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <Database className="w-3.5 h-3.5 text-emerald-400" />
                Global Statutory Knowledge Base
              </span>
              <span className="text-xs text-zinc-500 font-mono">
                {totalCount} Verified Acts & Codes • Official Soft Copy Repository
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Legal Acts & Statutory Knowledge Base
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Explore verbatim statutory acts, legislative provisions, employment codes, and compliance mandates. Open official acts in legislative gazettes and download soft copies for any jurisdiction.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Download Country / Full Compendium Soft Copy */}
            <button
              onClick={() => {
                const targetRules = selectedCountry === 'ALL' ? filteredRules : rules.filter(r => r.country === selectedCountry);
                const countryLabel = selectedCountry === 'ALL' ? 'Global' : selectedCountry;
                downloadCountryCompendiumPdf(countryLabel, targetRules);
              }}
              className="flex items-center gap-2 px-4 py-2.5 bg-zinc-900/90 hover:bg-zinc-800 text-emerald-300 border border-emerald-500/30 rounded-xl text-xs font-bold shadow-md hover:border-emerald-500/50 transition-all active:scale-95"
              title="Download soft copy compendium of all acts for the selected jurisdiction"
            >
              <FileDown className="w-4 h-4 text-emerald-400" />
              <span>
                Download {selectedCountry === 'ALL' ? 'Compendium' : `${selectedCountry}`} Soft Copy (PDF)
              </span>
            </button>

            <button
              onClick={() => {
                setEditingRuleId(null);
                setRuleName('');
                setStatutoryCitation('');
                setRequirement('');
                setIsAddingRule(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-95 shrink-0"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Add New Provision</span>
            </button>
          </div>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-5 rounded-3xl shadow-xl space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2.5 flex-1 min-w-[260px] bg-zinc-950/90 px-3.5 py-2.5 rounded-2xl border border-white/[0.08] shadow-inner">
            <Search className="w-4 h-4 text-zinc-400" />
            <input
              type="text"
              placeholder="Search legal acts, statutory sections (e.g. Gratuity, POSH, Wages, Section 27, FLSA)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-transparent text-xs text-white placeholder-zinc-500 focus:outline-none w-full"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="text-zinc-500 hover:text-zinc-300">
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Country Filter */}
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-emerald-400 hidden sm:block" />
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
            >
              <option value="ALL" className="bg-zinc-900 text-white">All Jurisdictions ({GLOBAL_JURISDICTIONS.length}+)</option>
              {GLOBAL_JURISDICTIONS.map(j => (
                <option key={j.countryCode} value={j.countryName} className="bg-zinc-900 text-white">
                  {j.countryName} ({rules.filter(r => r.country === j.countryName).length} Acts)
                </option>
              ))}
            </select>
          </div>

          {/* Subject Area Filter */}
          <select
            value={selectedSubject}
            onChange={(e) => setSelectedSubject(e.target.value)}
            className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
          >
            <option value="ALL" className="bg-zinc-900 text-white">All Subject Areas ({totalCount})</option>
            <option value="employment" className="bg-zinc-900 text-emerald-300 font-semibold">
              Employment & Labour Law ({employmentCount})
            </option>
            <option value="data_privacy" className="bg-zinc-900 text-white">Data Privacy & Security ({privacyCount})</option>
            <option value="dispute_resolution" className="bg-zinc-900 text-white">Arbitration & Dispute ({disputeCount})</option>
            <option value="liability" className="bg-zinc-900 text-white">Liability & Damages ({liabilityCount})</option>
            <option value="e_signature" className="bg-zinc-900 text-white">E-Signature Frameworks ({eSignCount})</option>
            <option value="taxation" className="bg-zinc-900 text-white">Stamp Duty & Tax ({taxCount})</option>
          </select>

          {/* Status Filter */}
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
          >
            <option value="ALL" className="bg-zinc-900 text-white">All Verification Statuses</option>
            <option value="verified" className="bg-zinc-900 text-white">Verified</option>
            <option value="under_review" className="bg-zinc-900 text-white">Under Review</option>
            <option value="outdated" className="bg-zinc-900 text-white">Outdated</option>
            <option value="superseded" className="bg-zinc-900 text-white">Superseded</option>
          </select>
        </div>

        {/* Quick Filter Category Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-white/[0.05]">
          <span className="text-[11px] font-semibold text-zinc-400 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3 text-zinc-500" />
            Quick Filters:
          </span>

          <button
            onClick={() => setSelectedSubject('ALL')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              selectedSubject === 'ALL'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/[0.06]'
            }`}
          >
            All Acts ({totalCount})
          </button>

          <button
            onClick={() => setSelectedSubject('employment')}
            className={`px-3 py-1 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all ${
              selectedSubject === 'employment'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 shadow-sm'
                : 'bg-zinc-900/80 text-emerald-400/90 hover:text-emerald-300 border border-emerald-500/20'
            }`}
          >
            <Briefcase className="w-3 h-3 text-emerald-400" />
            <span>Employment & Labour Law ({employmentCount})</span>
          </button>

          <button
            onClick={() => setSelectedCountry('India')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              selectedCountry === 'India'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-amber-300 border border-white/[0.06]'
            }`}
          >
            🇮🇳 India Acts ({indiaActsCount})
          </button>

          <button
            onClick={() => setSelectedSubject('data_privacy')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              selectedSubject === 'data_privacy'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/[0.06]'
            }`}
          >
            Data Privacy ({privacyCount})
          </button>

          <button
            onClick={() => setSelectedSubject('dispute_resolution')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              selectedSubject === 'dispute_resolution'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/[0.06]'
            }`}
          >
            Arbitration ({disputeCount})
          </button>

          <button
            onClick={() => setSelectedSubject('liability')}
            className={`px-3 py-1 rounded-full text-xs font-medium transition-all ${
              selectedSubject === 'liability'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-zinc-900/80 text-zinc-400 hover:text-white border border-white/[0.06]'
            }`}
          >
            Liability & Risk ({liabilityCount})
          </button>

          {(selectedCountry !== 'ALL' || selectedSubject !== 'ALL' || selectedStatus !== 'ALL' || searchQuery) && (
            <button
              onClick={() => {
                setSelectedCountry('ALL');
                setSelectedSubject('ALL');
                setSelectedStatus('ALL');
                setSearchQuery('');
              }}
              className="text-[11px] text-zinc-500 hover:text-rose-400 underline ml-auto"
            >
              Reset Filters
            </button>
          )}
        </div>
      </div>

      {/* India Employment Focus Notice Banner if India or Employment is selected */}
      {(selectedCountry === 'India' || (selectedSubject === 'employment' && selectedCountry === 'ALL')) && (
        <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-200">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <span className="font-bold text-emerald-300 block">
              Indian Statutory Labour Framework & Employment Protections Active
            </span>
            <p className="text-zinc-300 text-[11px] leading-relaxed">
              Included Indian acts: <strong>Industrial Disputes Act 1947 & IR Code 2020</strong> (retrenchment & severance), <strong>Payment of Gratuity Act 1972</strong> (statutory retirement gratuity), <strong>Code on Wages 2019 & Minimum Wages Act</strong> (2x overtime pay), <strong>POSH Act 2013</strong> (Internal Complaints Committee), <strong>Maternity Benefit Act 1961/2017</strong> (26 weeks paid leave), <strong>EPF Act 1952</strong> (12% provident fund), <strong>State Shops & Commercial Establishments Acts</strong> (work hours & leave), and <strong>Section 27 Indian Contract Act</strong> (non-competes void ab initio). Click <em>Open Act</em> on any card to read verbatim provisions or <em>Soft Copy</em> to download official PDF.
            </p>
          </div>
        </div>
      )}

      {/* Results Header Count */}
      <div className="flex items-center justify-between text-xs text-zinc-400 px-1">
        <span>Showing <strong>{filteredRules.length}</strong> statutory acts & legal provisions</span>
        {selectedCountry !== 'ALL' && (
          <span className="text-emerald-400 font-medium">Jurisdiction: {selectedCountry}</span>
        )}
      </div>

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredRules.map((rule) => (
          <div
            key={rule.id}
            className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4 hover:border-emerald-500/40 transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              {/* Header with Title & Badges */}
              <div className="flex items-start justify-between gap-2">
                <div className="space-y-1 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="font-bold text-sm text-white leading-snug">
                      {rule.fullActTitle || rule.ruleName}
                    </h3>
                    {rule.isMandatory ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/30 uppercase">
                        Mandatory
                      </span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 uppercase">
                        Recommended
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
                    <Globe2 className="w-3.5 h-3.5" />
                    <span>{rule.country} {rule.stateOrProvince ? `(${rule.stateOrProvince})` : ''}</span>
                    <span>•</span>
                    <span className="text-zinc-400 capitalize">{rule.subjectArea.replace(/_/g, ' ')}</span>
                  </div>
                </div>

                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase shrink-0 ${
                  rule.verificationStatus === 'verified' ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30' :
                  rule.verificationStatus === 'under_review' ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' :
                  'bg-rose-500/10 text-rose-300 border border-rose-500/30'
                }`}>
                  {rule.verificationStatus.replace(/_/g, ' ')}
                </span>
              </div>

              {/* Statutory Citation Box */}
              <div className="p-3 rounded-2xl bg-zinc-950/90 border border-white/[0.08] text-xs font-mono text-emerald-300 flex items-center justify-between shadow-inner">
                <span className="truncate pr-2">Citation: {rule.statutoryCitation}</span>
                <span className="text-[10px] font-sans text-teal-400 font-bold bg-teal-500/10 px-2 py-0.5 rounded-full border border-teal-500/20 shrink-0">
                  {rule.confidenceScore}% Confidence
                </span>
              </div>

              {/* Requirement Text */}
              <p className="text-xs text-zinc-300 leading-relaxed line-clamp-3">
                {rule.actSummary || rule.legalRequirement}
              </p>

              {/* Highlights badge pills */}
              {rule.keySections && rule.keySections.length > 0 && (
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {rule.keySections.map((sec, i) => (
                    <span key={i} className="text-[10px] bg-white/[0.04] text-zinc-300 px-2 py-0.5 rounded-md border border-white/[0.05]">
                      {sec.section}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Action Bar: Open Act, Bare Act (PDF), Soft Copy Download, External Portal */}
            <div className="pt-3.5 border-t border-white/[0.06] flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex flex-wrap items-center gap-2">
                {/* OPEN ACT BUTTON */}
                <button
                  onClick={() => {
                    setSelectedRuleForActModal(rule);
                    setModalActiveTab('bare_act');
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 rounded-lg font-semibold transition-all hover:scale-[1.02] active:scale-95"
                >
                  <BookOpen className="w-3.5 h-3.5" />
                  <span>Open Act</span>
                </button>

                {/* DOWNLOAD BARE ACT (PDF) BUTTON */}
                <button
                  onClick={() => downloadBareActPdf(rule)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-950/70 hover:bg-emerald-900/80 text-emerald-200 border border-emerald-500/40 rounded-lg font-semibold transition-all hover:text-white active:scale-95 shadow-sm"
                  title="Download Official Bare Act PDF (Complete Verbatim Statutory Code)"
                >
                  <FileText className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Bare Act (PDF)</span>
                </button>

                {/* DOWNLOAD SOFT COPY (PDF) BUTTON */}
                <button
                  onClick={() => downloadActSoftCopyPdf(rule)}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-white/[0.1] rounded-lg font-medium transition-all hover:text-white active:scale-95"
                  title="Download Official Soft Copy PDF (Includes Summary, Analysis & Bare Act)"
                >
                  <Download className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Soft Copy</span>
                </button>

                {/* OFFICIAL GOVERNMENT PORTAL LINK */}
                {rule.officialUrl && (
                  <a
                    href={rule.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 text-zinc-400 hover:text-emerald-400 rounded-lg hover:bg-zinc-800 transition-colors"
                    title="Open in Official Government Gazette / Portal"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>

              <button
                onClick={() => handleEdit(rule)}
                className="text-zinc-500 hover:text-zinc-300 text-[11px] font-medium hover:underline flex items-center gap-0.5"
              >
                <span>Edit / Review</span>
                <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* ACT VIEWER MODAL ("OPEN ACT") */}
      {selectedRuleForActModal && (() => {
        const bareAct = getBareActForRule(selectedRuleForActModal);
        return (
          <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
            <div className="bg-[#121215] border border-white/[0.12] rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl space-y-6 max-h-[92vh] overflow-y-auto bento-glow-emerald">
              {/* Modal Header */}
              <div className="flex items-start justify-between gap-4 border-b border-white/[0.08] pb-4">
                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">
                      {selectedRuleForActModal.country}
                    </span>
                    <span className="text-xs text-zinc-400 capitalize">
                      {selectedRuleForActModal.subjectArea.replace(/_/g, ' ')}
                    </span>
                    <span className="text-xs font-mono text-emerald-400 bg-zinc-900/80 px-2 py-0.5 rounded-md border border-white/[0.06]">
                      {bareAct.officialActNumberAndYear}
                    </span>
                    {selectedRuleForActModal.isMandatory && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/30">
                        MANDATORY STATUTE
                      </span>
                    )}
                  </div>
                  <h2 className="text-lg sm:text-2xl font-bold text-white tracking-tight">
                    {selectedRuleForActModal.fullActTitle || selectedRuleForActModal.ruleName}
                  </h2>
                  <p className="text-xs font-mono text-emerald-400">
                    {selectedRuleForActModal.statutoryCitation}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedRuleForActModal(null)}
                  className="text-zinc-400 hover:text-white p-2 rounded-xl bg-zinc-900 border border-white/[0.08] shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Action Toolbar: Download Bare Act PDF, Download Soft Copy PDF, Download TXT, Copy Bare Act */}
              <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-zinc-950/90 rounded-2xl border border-white/[0.08]">
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => downloadBareActPdf(selectedRuleForActModal)}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
                    title="Download Official Bare Act PDF (Complete Verbatim Statutory Code)"
                  >
                    <FileText className="w-3.5 h-3.5" />
                    <span>Download Bare Act (PDF)</span>
                  </button>

                  <button
                    onClick={() => downloadActSoftCopyPdf(selectedRuleForActModal)}
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-white/[0.1] rounded-xl text-xs font-medium transition-all active:scale-95"
                    title="Download Comprehensive Soft Copy PDF"
                  >
                    <Download className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Soft Copy (PDF)</span>
                  </button>

                  <button
                    onClick={() => downloadBareActText(selectedRuleForActModal)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.08] rounded-xl text-xs font-medium transition-all"
                    title="Download Verbatim Bare Act in Plain Text / Markdown"
                  >
                    <FileDown className="w-3.5 h-3.5 text-zinc-400" />
                    <span>Bare Act (TXT)</span>
                  </button>

                  <button
                    onClick={() => handleCopyFullBareAct(selectedRuleForActModal)}
                    className="flex items-center gap-1.5 px-3 py-2 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.08] rounded-xl text-xs font-medium transition-all"
                    title="Copy Complete Bare Act to Clipboard"
                  >
                    {copiedFullAct ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="text-emerald-300">Bare Act Copied!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5 text-zinc-400" />
                        <span>Copy Bare Act</span>
                      </>
                    )}
                  </button>
                </div>

                {selectedRuleForActModal.officialUrl && (
                  <a
                    href={selectedRuleForActModal.officialUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1.5 px-3 py-2 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 border border-blue-500/30 rounded-xl text-xs font-medium transition-colors"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Gazette Portal</span>
                  </a>
                )}
              </div>

              {/* View Tabs: Bare Act vs Statutory Analysis */}
              <div className="flex border-b border-white/[0.08] gap-4 text-xs font-bold">
                <button
                  onClick={() => setModalActiveTab('bare_act')}
                  className={`pb-3 flex items-center gap-2 border-b-2 transition-all ${
                    modalActiveTab === 'bare_act'
                      ? 'text-emerald-400 border-emerald-400'
                      : 'text-zinc-400 border-transparent hover:text-zinc-200'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>The Bare Act (Verbatim Legislative Code)</span>
                  <span className="px-2 py-0.5 rounded-full text-[10px] bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
                    Official Text
                  </span>
                </button>

                <button
                  onClick={() => setModalActiveTab('analysis')}
                  className={`pb-3 flex items-center gap-2 border-b-2 transition-all ${
                    modalActiveTab === 'analysis'
                      ? 'text-emerald-400 border-emerald-400'
                      : 'text-zinc-400 border-transparent hover:text-zinc-200'
                  }`}
                >
                  <Scale className="w-4 h-4" />
                  <span>Statutory Compliance Analysis & Model Clauses</span>
                </button>
              </div>

              {/* TAB 1: THE BARE ACT */}
              {modalActiveTab === 'bare_act' && (
                <div className="space-y-6">
                  {/* Preamble Box */}
                  <div className="bg-zinc-950 p-5 rounded-2xl border border-white/[0.08] space-y-2.5">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                        Official Legislative Preamble
                      </span>
                      <span className="text-[10px] font-mono text-zinc-500">
                        Enactment: {bareAct.enactmentDate || selectedRuleForActModal.effectiveDate || 'Statutory Code'}
                      </span>
                    </div>
                    <p className="text-xs text-zinc-300 font-serif leading-relaxed italic border-l-2 border-emerald-500/80 pl-3.5">
                      "{bareAct.preamble}"
                    </p>
                  </div>

                  {/* Arrangement of Sections (Table of Contents Jump Pills) */}
                  {bareAct.arrangementOfSections && bareAct.arrangementOfSections.length > 0 && (
                    <div className="space-y-2.5">
                      <h4 className="text-xs font-bold text-zinc-300 uppercase tracking-wider flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5 text-emerald-400" />
                        <span>Arrangement of Sections ({bareAct.arrangementOfSections.length} Provisions)</span>
                      </h4>
                      <div className="flex flex-wrap gap-2 p-3.5 bg-zinc-950/60 rounded-2xl border border-white/[0.06]">
                        {bareAct.arrangementOfSections.map((item, i) => (
                          <div
                            key={i}
                            className="flex items-center gap-1 text-[11px] px-2.5 py-1 bg-zinc-900 border border-white/[0.08] rounded-lg text-zinc-300"
                            title={item.title}
                          >
                            <span className="font-mono text-emerald-400 font-bold">{item.section}:</span>
                            <span className="truncate max-w-[200px]">{item.title}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Chapters & Verbatim Sections */}
                  <div className="space-y-6">
                    {bareAct.chapters.map((chapter, cIdx) => (
                      <div key={cIdx} className="space-y-3">
                        <div className="bg-emerald-950/30 border border-emerald-500/30 px-4 py-2.5 rounded-xl flex items-center justify-between">
                          <span className="text-xs font-bold text-emerald-300 uppercase tracking-wider">
                            {chapter.chapterNumber} — {chapter.chapterTitle}
                          </span>
                          <span className="text-[10px] text-zinc-400 font-mono">
                            {chapter.sections.length} Section{chapter.sections.length > 1 ? 's' : ''}
                          </span>
                        </div>

                        <div className="space-y-3">
                          {chapter.sections.map((sec, sIdx) => {
                            const key = `${cIdx}-${sIdx}`;
                            return (
                              <div
                                key={sIdx}
                                className="bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-5 space-y-3 hover:border-emerald-500/40 transition-colors shadow-inner"
                              >
                                <div className="flex items-start justify-between gap-3 border-b border-white/[0.05] pb-2.5">
                                  <div className="space-y-0.5">
                                    <span className="text-xs font-bold text-emerald-400 font-mono block">
                                      {sec.sectionNumber}
                                    </span>
                                    <h4 className="text-sm font-bold text-white">
                                      {sec.sectionTitle}
                                    </h4>
                                  </div>

                                  <button
                                    onClick={() => handleCopySection(
                                      `${sec.sectionNumber} - ${sec.sectionTitle}`,
                                      sec.verbatimText,
                                      key
                                    )}
                                    className="flex items-center gap-1 text-[11px] text-zinc-400 hover:text-emerald-300 bg-zinc-900 hover:bg-zinc-800 px-2.5 py-1 rounded-lg border border-white/[0.06] shrink-0"
                                    title="Copy section verbatim text"
                                  >
                                    {copiedSectionIndex === key ? (
                                      <>
                                        <Check className="w-3 h-3 text-emerald-400" />
                                        <span className="text-emerald-300">Copied</span>
                                      </>
                                    ) : (
                                      <>
                                        <Copy className="w-3 h-3" />
                                        <span>Copy Section</span>
                                      </>
                                    )}
                                  </button>
                                </div>

                                {/* Verbatim Text */}
                                <div className="text-xs text-zinc-200 font-serif leading-relaxed whitespace-pre-line pl-1">
                                  {sec.verbatimText}
                                </div>

                                {/* Provisos */}
                                {sec.provisos && sec.provisos.length > 0 && (
                                  <div className="space-y-1.5 pt-1">
                                    {sec.provisos.map((p, pIdx) => (
                                      <div
                                        key={pIdx}
                                        className="p-3 bg-zinc-900/80 border-l-2 border-emerald-500/80 rounded-r-xl text-xs text-zinc-300 font-serif italic"
                                      >
                                        {p}
                                      </div>
                                    ))}
                                  </div>
                                )}

                                {/* Explanations */}
                                {sec.explanations && sec.explanations.length > 0 && (
                                  <div className="space-y-1.5 pt-1">
                                    {sec.explanations.map((exp, eIdx) => (
                                      <div
                                        key={eIdx}
                                        className="p-3 bg-zinc-900/60 rounded-xl text-xs text-zinc-400 font-serif leading-relaxed border border-white/[0.04]"
                                      >
                                        <strong className="text-zinc-200 not-italic">Explanation:</strong> {exp}
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    ))}

                    {/* Schedules */}
                    {bareAct.schedules && bareAct.schedules.length > 0 && (
                      <div className="space-y-3 pt-2">
                        <div className="bg-zinc-900 px-4 py-2.5 rounded-xl text-xs font-bold text-white uppercase tracking-wider">
                          Schedules to the Act
                        </div>
                        {bareAct.schedules.map((sch, scIdx) => (
                          <div key={scIdx} className="bg-zinc-950 p-5 rounded-2xl border border-white/[0.08] space-y-2">
                            <span className="text-xs font-bold text-emerald-400 font-mono block">
                              {sch.scheduleNumber}: {sch.scheduleTitle}
                            </span>
                            <div className="text-xs text-zinc-300 font-serif leading-relaxed whitespace-pre-line">
                              {sch.content}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* TAB 2: STATUTORY COMPLIANCE ANALYSIS */}
              {modalActiveTab === 'analysis' && (
                <div className="space-y-6">
                  {/* Metadata Badges */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <div className="bg-zinc-900/60 p-3 rounded-xl border border-white/[0.05]">
                      <span className="text-zinc-500 block text-[10px]">Enforcing Authority</span>
                      <span className="font-semibold text-zinc-200 text-xs">
                        {selectedRuleForActModal.enforcingAuthority || 'National Regulatory Agency'}
                      </span>
                    </div>
                    <div className="bg-zinc-900/60 p-3 rounded-xl border border-white/[0.05]">
                      <span className="text-zinc-500 block text-[10px]">Effective Date</span>
                      <span className="font-semibold text-zinc-200 text-xs">
                        {selectedRuleForActModal.effectiveDate || 'Statutory Code in Force'}
                      </span>
                    </div>
                    <div className="bg-zinc-900/60 p-3 rounded-xl border border-white/[0.05]">
                      <span className="text-zinc-500 block text-[10px]">Verification Confidence</span>
                      <span className="font-semibold text-emerald-400 text-xs">
                        {selectedRuleForActModal.confidenceScore}% (Verified)
                      </span>
                    </div>
                    <div className="bg-zinc-900/60 p-3 rounded-xl border border-white/[0.05]">
                      <span className="text-zinc-500 block text-[10px]">Reviewed By</span>
                      <span className="font-semibold text-zinc-200 text-xs truncate block" title={selectedRuleForActModal.reviewerCredentials}>
                        {selectedRuleForActModal.reviewerCredentials}
                      </span>
                    </div>
                  </div>

                  {/* Statutory Summary & Legislative Intent */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                      <BookOpen className="w-3.5 h-3.5" />
                      <span>1. Statutory Summary & Legislative Intent</span>
                    </h4>
                    <div className="p-4 bg-zinc-950/90 rounded-2xl border border-white/[0.06] text-xs text-zinc-300 leading-relaxed">
                      {selectedRuleForActModal.actSummary || selectedRuleForActModal.legalRequirement}
                    </div>
                  </div>

                  {/* Key Operative Sections / Articles */}
                  {selectedRuleForActModal.keySections && selectedRuleForActModal.keySections.length > 0 && (
                    <div className="space-y-3">
                      <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                        <Scale className="w-3.5 h-3.5" />
                        <span>2. Key Operative Statutory Sections & Articles</span>
                      </h4>
                      <div className="space-y-2.5">
                        {selectedRuleForActModal.keySections.map((sec, i) => (
                          <div key={i} className="p-4 bg-zinc-950/90 rounded-2xl border border-white/[0.06] space-y-1.5">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-emerald-300 font-mono">
                                {sec.section}: {sec.title}
                              </span>
                            </div>
                            <p className="text-xs text-zinc-300 font-serif leading-relaxed italic">
                              "{sec.text}"
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Mandatory Provisions Checklist */}
                  {selectedRuleForActModal.mandatoryProvisions && selectedRuleForActModal.mandatoryProvisions.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>3. Mandatory Compliance Obligations</span>
                      </h4>
                      <div className="p-4 bg-emerald-950/20 border border-emerald-500/20 rounded-2xl space-y-2">
                        {selectedRuleForActModal.mandatoryProvisions.map((item, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-emerald-200">
                            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Prohibited / Unenforceable Provisions */}
                  {selectedRuleForActModal.restrictedProvisions && selectedRuleForActModal.restrictedProvisions.length > 0 && (
                    <div className="space-y-2">
                      <h4 className="text-xs font-bold text-rose-400 uppercase tracking-wider flex items-center gap-1.5">
                        <AlertOctagon className="w-3.5 h-3.5" />
                        <span>4. Prohibited / Void Ab Initio Provisions</span>
                      </h4>
                      <div className="p-4 bg-rose-950/20 border border-rose-500/20 rounded-2xl space-y-2">
                        {selectedRuleForActModal.restrictedProvisions.map((item, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-rose-200">
                            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                            <span>{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Recommended Model Contract Clause */}
                  {selectedRuleForActModal.recommendedWording && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <h4 className="text-xs font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>5. Recommended Statutory Model Clause</span>
                        </h4>
                        <button
                          onClick={() => handleCopyClause(selectedRuleForActModal.recommendedWording!)}
                          className="flex items-center gap-1 text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold"
                        >
                          {copiedClause ? (
                            <>
                              <Check className="w-3 h-3" />
                              <span>Copied to Clipboard!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3 h-3" />
                              <span>Copy Model Clause</span>
                            </>
                          )}
                        </button>
                      </div>
                      <div className="p-4 bg-zinc-950 border-l-2 border-emerald-500 rounded-r-2xl text-xs text-zinc-200 font-serif leading-relaxed italic">
                        "{selectedRuleForActModal.recommendedWording}"
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Footer Modal Close */}
              <div className="pt-4 border-t border-white/[0.08] flex items-center justify-between">
                <span className="text-xs text-zinc-500">
                  Official Statutory Bare Act Record • Verified {selectedRuleForActModal.lastVerifiedDate}
                </span>
                <button
                  onClick={() => setSelectedRuleForActModal(null)}
                  className="px-5 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-xl text-xs font-bold transition-colors"
                >
                  Close Act
                </button>
              </div>
            </div>
          </div>
        );
      })()}

      {/* Add / Edit Rule Modal */}
      {isAddingRule && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#121215] border border-white/[0.12] rounded-3xl max-w-2xl w-full p-7 shadow-2xl space-y-4 bento-glow-emerald">
            <div className="flex items-center justify-between border-b border-white/[0.06] pb-3">
              <h3 className="font-bold text-base text-white">
                {editingRuleId ? 'Edit Legal Provision & Citation' : 'Add New Statutory Legal Rule'}
              </h3>
              <button onClick={() => setIsAddingRule(false)} className="text-zinc-400 hover:text-white p-1 rounded-lg">✕</button>
            </div>

            <form onSubmit={handleSaveRule} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-300 font-medium mb-1">Rule Name</label>
                  <input
                    type="text"
                    required
                    value={ruleName}
                    onChange={(e) => setRuleName(e.target.value)}
                    placeholder="e.g. Industrial Disputes Act, 1947"
                    className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 font-medium mb-1">Jurisdiction</label>
                  <select
                    value={formCountry}
                    onChange={(e) => setFormCountry(e.target.value)}
                    className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  >
                    {GLOBAL_JURISDICTIONS.map(j => (
                      <option key={j.countryCode} value={j.countryName} className="bg-zinc-900 text-white">{j.countryName}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-zinc-300 font-medium mb-1">Statutory Citation / Statute Law</label>
                  <input
                    type="text"
                    required
                    value={statutoryCitation}
                    onChange={(e) => setStatutoryCitation(e.target.value)}
                    placeholder="e.g. Industrial Disputes Act 1947, Sec 25F"
                    className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 font-medium mb-1">Subject Area</label>
                  <select
                    value={subjectArea}
                    onChange={(e) => setSubjectArea(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  >
                    <option value="employment" className="bg-zinc-900 text-white">Employment & Labour Law</option>
                    <option value="liability" className="bg-zinc-900 text-white">Liability & Damages</option>
                    <option value="data_privacy" className="bg-zinc-900 text-white">Data Privacy & Breach</option>
                    <option value="ip" className="bg-zinc-900 text-white">Intellectual Property</option>
                    <option value="dispute_resolution" className="bg-zinc-900 text-white">Arbitration & Dispute</option>
                    <option value="e_signature" className="bg-zinc-900 text-white">E-Signature Frameworks</option>
                    <option value="taxation" className="bg-zinc-900 text-white">Stamp Duty & Withholding</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-zinc-300 font-medium mb-1">Legal Requirement / Principle</label>
                <textarea
                  rows={3}
                  required
                  value={requirement}
                  onChange={(e) => setRequirement(e.target.value)}
                  placeholder="Explain the precise statutory mandate, enforceability boundaries, and required wording..."
                  className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="flex items-center gap-2 pt-4">
                  <input
                    type="checkbox"
                    id="rule-mandatory"
                    checked={isMandatory}
                    onChange={(e) => setIsMandatory(e.target.checked)}
                    className="w-4 h-4 text-emerald-600 rounded cursor-pointer accent-emerald-500"
                  />
                  <label htmlFor="rule-mandatory" className="text-zinc-200 font-medium cursor-pointer">
                    Mandatory Provision
                  </label>
                </div>
                <div>
                  <label className="block text-zinc-300 font-medium mb-1">Confidence Score (%)</label>
                  <input
                    type="number"
                    min={50}
                    max={100}
                    value={confidenceScore}
                    onChange={(e) => setConfidenceScore(Number(e.target.value))}
                    className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  />
                </div>
                <div>
                  <label className="block text-zinc-300 font-medium mb-1">Status</label>
                  <select
                    value={verificationStatus}
                    onChange={(e) => setVerificationStatus(e.target.value as any)}
                    className="w-full bg-zinc-950 border border-white/[0.08] rounded-xl p-2.5 text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                  >
                    <option value="verified" className="bg-zinc-900 text-white">Verified</option>
                    <option value="under_review" className="bg-zinc-900 text-white">Under Review</option>
                    <option value="outdated" className="bg-zinc-900 text-white">Outdated</option>
                    <option value="superseded" className="bg-zinc-900 text-white">Superseded</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-3 border-t border-white/[0.06]">
                <button
                  type="button"
                  onClick={() => setIsAddingRule(false)}
                  className="px-4 py-2 bg-zinc-800 text-zinc-300 rounded-xl font-semibold hover:bg-zinc-700 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl font-bold shadow-md shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-95"
                >
                  Save Legal Rule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
