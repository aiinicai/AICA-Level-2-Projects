import React, { useState } from 'react';
import { 
  Send, 
  Mail, 
  CheckCircle2, 
  FileText, 
  Download, 
  ShieldCheck, 
  RefreshCw, 
  Clock, 
  Users,
  Paperclip
} from 'lucide-react';
import { ContractItem } from '../types';
import { generateContractPdf } from '../utils/pdfExport';

interface DistributionCenterProps {
  contracts: ContractItem[];
  activeContract?: ContractItem | null;
}

export const DistributionCenterView: React.FC<DistributionCenterProps> = ({
  contracts,
  activeContract
}) => {
  const [selectedContractId, setSelectedContractId] = useState<string>(activeContract?.id || contracts[0]?.id || '');
  const currentContract = contracts.find(c => c.id === selectedContractId) || contracts[0];

  const [recipients, setRecipients] = useState<string>(
    `${currentContract?.primaryParty.signatoryEmail || 'legal@company.com'}, ${currentContract?.counterparty.signatoryEmail || 'client@partner.com'}, finance@company.com`
  );
  const [subject, setSubject] = useState<string>(
    `[FULLY EXECUTED] ${currentContract?.contractNumber} - ${currentContract?.title}`
  );
  const [emailBody, setEmailBody] = useState<string>(
    `Dear Parties,\n\nPlease find attached the fully executed, digitally signed contract packet for ${currentContract?.title} (Ref: ${currentContract?.contractNumber}).\n\nThis document has been cryptographically sealed with a SHA-256 tamper-evident audit certificate in accordance with statutory digital signature frameworks.\n\nEffective Date: ${currentContract?.startDate}\nGoverning Law: ${currentContract?.governingLaw}\n\nBest regards,\nGlobal Legal Operations Team`
  );

  const [isSending, setIsSending] = useState<boolean>(false);
  const [sentLog, setSentLog] = useState<{
    timestamp: string;
    recipients: string[];
    contractTitle: string;
    status: string;
  } | null>(null);

  const handleSendDistribution = async () => {
    setIsSending(true);
    try {
      const recipientList = recipients.split(',').map(r => r.trim()).filter(Boolean);
      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contractId: currentContract.id,
          contractTitle: currentContract.title,
          recipients: recipientList,
          subject,
          emailBody
        })
      });
      const data = await res.json();
      if (data.success) {
        setSentLog({
          timestamp: new Date().toISOString(),
          recipients: recipientList,
          contractTitle: currentContract.title,
          status: 'Delivered & Confirmed'
        });
      }
    } catch (err) {
      console.error('Email distribution error:', err);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div id="distribution-center-view" className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-teal-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <Send className="w-3.5 h-3.5 text-emerald-400" />
                Automated Distribution Hub
              </span>
              <span className="text-xs text-zinc-500 font-mono">Secure Packet Delivery</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Executed Contract Distribution & Record Dispatch
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Distribute legally executed contracts, cryptographic audit trails, and execution certificates automatically to all contracting parties and internal finance/legal stakeholders.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedContractId}
              onChange={(e) => {
                setSelectedContractId(e.target.value);
                const c = contracts.find(item => item.id === e.target.value);
                if (c) {
                  setSubject(`[FULLY EXECUTED] ${c.contractNumber} - ${c.title}`);
                  setRecipients(`${c.primaryParty.signatoryEmail || ''}, ${c.counterparty.signatoryEmail || ''}, finance@company.com`);
                }
              }}
              className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-200 rounded-2xl px-4 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
            >
              {contracts.map(c => (
                <option key={c.id} value={c.id} className="bg-zinc-900 text-white">
                  {c.contractNumber} • {c.title.substring(0, 30)}...
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Form & Dispatch Card */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column (7 cols): Email Composer */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/[0.06] pb-3">
              <Mail className="w-4 h-4 text-emerald-400" />
              Dispatch Packet Composer
            </h3>

            <div className="space-y-3.5 text-xs">
              <div>
                <label className="block text-zinc-400 mb-1.5 font-medium">Recipients (Comma-separated emails)</label>
                <input
                  type="text"
                  value={recipients}
                  onChange={(e) => setRecipients(e.target.value)}
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1.5 font-medium">Email Subject</label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-3 text-xs text-white focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              <div>
                <label className="block text-zinc-400 mb-1.5 font-medium">Dispatch Message Body</label>
                <textarea
                  rows={8}
                  value={emailBody}
                  onChange={(e) => setEmailBody(e.target.value)}
                  className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-3.5 text-xs font-mono text-zinc-300 leading-relaxed focus:outline-none focus:border-emerald-500 shadow-inner"
                />
              </div>

              {/* Attachments Pill Box */}
              <div className="p-3.5 rounded-2xl bg-zinc-950/90 border border-white/[0.08] flex items-center justify-between shadow-inner">
                <div className="flex items-center gap-2 text-xs text-zinc-300">
                  <Paperclip className="w-4 h-4 text-cyan-400" />
                  <span>Attached: <strong className="text-white">{currentContract.contractNumber}_Signed_Contract.pdf</strong> (with SHA-256 Audit Seal)</span>
                </div>
                <button
                  type="button"
                  onClick={() => generateContractPdf(currentContract)}
                  className="text-cyan-400 hover:text-cyan-300 text-[11px] font-semibold flex items-center gap-1 hover:underline"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Preview</span>
                </button>
              </div>

              {/* Dispatch Action */}
              <button
                onClick={handleSendDistribution}
                disabled={isSending}
                className="w-full py-3.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-2xl text-xs font-bold shadow-lg shadow-emerald-600/20 flex items-center justify-center gap-2 transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-50"
              >
                {isSending ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Dispatching Encrypted Contract Packet...</span>
                  </>
                ) : (
                  <>
                    <Send className="w-4 h-4" />
                    <span>Send Executed Contract Packet to All Parties</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column (5 cols): Distribution Status & Audit Log */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 border-b border-white/[0.06] pb-3">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Delivery Confirmation & Receipts
            </h3>

            {sentLog ? (
              <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 space-y-2.5 text-xs shadow-inner">
                <div className="flex items-center gap-2 text-emerald-300 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>Packet Dispatched Successfully</span>
                </div>
                <div className="text-zinc-300 space-y-1 text-[11px] bg-zinc-900/40 p-3 rounded-xl border border-white/[0.04]">
                  <div><strong className="text-zinc-400">Time:</strong> {new Date(sentLog.timestamp).toLocaleString()}</div>
                  <div><strong className="text-zinc-400">Contract:</strong> {sentLog.contractTitle}</div>
                  <div><strong className="text-zinc-400">Recipients:</strong> {sentLog.recipients.join(', ')}</div>
                  <div className="text-emerald-400 font-semibold mt-1">Status: {sentLog.status}</div>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-zinc-500 space-y-1">
                <Clock className="w-6 h-6 mx-auto text-zinc-600 mb-2" />
                <p>No new dispatches executed for this session.</p>
                <p className="text-[11px] text-zinc-600">Click &quot;Send Executed Contract Packet&quot; to initiate.</p>
              </div>
            )}

            <div className="p-4 rounded-2xl bg-zinc-950/90 border border-white/[0.08] text-xs text-zinc-400 space-y-1 shadow-inner">
              <span className="font-semibold text-zinc-200 block text-[11px]">Governance Note:</span>
              <p className="text-[11px] leading-relaxed text-zinc-400">
                Distribution records are immutably archived into the audit trail with recipient timestamps for statutory compliance proofs.
              </p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
