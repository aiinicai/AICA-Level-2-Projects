import React from 'react';
import { 
  FileText, 
  ShieldAlert, 
  Clock, 
  CheckCircle2, 
  DollarSign, 
  AlertOctagon, 
  TrendingUp, 
  ArrowUpRight, 
  Globe2, 
  PlusCircle, 
  Search, 
  PenTool, 
  Scale,
  Sparkles,
  ChevronRight,
  Database
} from 'lucide-react';
import { ContractItem } from '../types';

interface DashboardViewProps {
  contracts: ContractItem[];
  onSelectContract: (contract: ContractItem) => void;
  onStartDrafting: () => void;
  onStartVetting: () => void;
  onStartRedline: () => void;
  onStartSigning: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  contracts,
  onSelectContract,
  onStartDrafting,
  onStartVetting,
  onStartRedline,
  onStartSigning
}) => {
  // Statistics Calculations
  const totalContracts = contracts.length;
  const draftContracts = contracts.filter(c => c.status === 'draft' || c.status === 'ai_review').length;
  const underReview = contracts.filter(c => c.status === 'legal_review' || c.status === 'business_review' || c.status === 'negotiation').length;
  const pendingSignature = contracts.filter(c => c.status === 'approved' || c.status === 'sent_for_signature' || c.status === 'partially_signed').length;
  const activeContracts = contracts.filter(c => c.status === 'active' || c.status === 'fully_executed').length;
  const expiringSoon = contracts.filter(c => c.status === 'expiring_soon').length;

  const criticalRiskContracts = contracts.filter(c => c.riskBreakdown.overallScore > 60).length;
  const uncappedLiabilityContracts = contracts.filter(c => c.riskLiability.liabilityCapType === 'unlimited' || c.riskLiability.hasUncappedExceptions).length;

  // Total Contract Value Breakdown
  const totalUsdValue = contracts.reduce((acc, c) => {
    if (c.commercials.currency === 'USD') return acc + c.commercials.contractValue;
    if (c.commercials.currency === 'INR') return acc + (c.commercials.contractValue / 85); // approx conversion
    if (c.commercials.currency === 'GBP') return acc + (c.commercials.contractValue * 1.3);
    if (c.commercials.currency === 'SGD') return acc + (c.commercials.contractValue * 0.75);
    return acc + c.commercials.contractValue;
  }, 0);

  // Average Risk Score
  const avgRiskScore = Math.round(
    contracts.reduce((acc, c) => acc + c.riskBreakdown.overallScore, 0) / (contracts.length || 1)
  );

  return (
    <div id="dashboard-view-container" className="space-y-6 pb-12">
      
      {/* Top Welcome & Quick Actions Bar */}
      <div className="relative overflow-hidden flex flex-col lg:flex-row lg:items-center justify-between gap-6 bg-[#121215]/90 backdrop-blur-xl p-7 rounded-3xl border border-white/[0.08] shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-cyan-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10">
          <div className="flex flex-wrap items-center gap-2 mb-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              Global Legal AI Intelligence Hub
            </span>
            <span className="text-xs text-zinc-500 font-mono hidden sm:inline">Multi-Jurisdiction Engine Active</span>
            <span className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-zinc-900/90 border border-emerald-500/30 text-emerald-300 font-mono flex items-center gap-1.5">
              <Database className="w-3 h-3 text-emerald-400" />
              <span>Cloud Database: Firestore Connected</span>
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Contract Lifecycle & Risk Portfolio
          </h1>
          <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
            AI-driven legal drafting, automated risk vetting, 3-way redline intelligence, and cross-border digital execution across 11+ global jurisdictions.
          </p>
        </div>

        {/* Action Buttons */}
        <div className="relative z-10 flex flex-wrap items-center gap-3">
          <button
            id="dash-draft-btn"
            onClick={onStartDrafting}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-semibold shadow-lg shadow-emerald-600/25 transition-all hover:scale-[1.02] active:scale-95"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Draft New Contract</span>
          </button>
          <button
            id="dash-vet-btn"
            onClick={onStartVetting}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 border border-white/[0.08] hover:border-zinc-700 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-95"
          >
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>AI Legal Vetting</span>
          </button>
          <button
            id="dash-redline-btn"
            onClick={onStartRedline}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-zinc-900/90 hover:bg-zinc-800 text-zinc-200 border border-white/[0.08] hover:border-zinc-700 text-xs font-semibold transition-all hover:scale-[1.02] active:scale-95"
          >
            <TrendingUp className="w-4 h-4 text-cyan-400" />
            <span>Redline Compare</span>
          </button>
        </div>
      </div>

      {/* Bento KPI Cards Row */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {/* Total Contracts */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-lg flex flex-col justify-between hover:border-zinc-700 transition-all group">
          <div className="flex items-center justify-between text-zinc-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">Total Contracts</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <FileText className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-white tracking-tight">{totalContracts}</span>
            <span className="text-[11px] text-zinc-500 block mt-0.5 font-medium">Active repository records</span>
          </div>
        </div>

        {/* Under Review / Negotiation */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-lg flex flex-col justify-between hover:border-amber-500/30 transition-all group">
          <div className="flex items-center justify-between text-amber-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">In Review & Neg.</span>
            <div className="w-7 h-7 rounded-lg bg-amber-500/10 flex items-center justify-center text-amber-400">
              <Clock className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-amber-300 tracking-tight">{underReview}</span>
            <span className="text-[11px] text-amber-400/70 block mt-0.5 font-medium">Pending legal feedback</span>
          </div>
        </div>

        {/* Pending Signature */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-lg flex flex-col justify-between hover:border-indigo-500/30 transition-all group">
          <div className="flex items-center justify-between text-indigo-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">Awaiting Signatures</span>
            <div className="w-7 h-7 rounded-lg bg-indigo-500/10 flex items-center justify-center text-indigo-400">
              <PenTool className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-indigo-300 tracking-tight">{pendingSignature}</span>
            <span className="text-[11px] text-indigo-400/70 block mt-0.5 font-medium">Ready for E-Sign</span>
          </div>
        </div>

        {/* Fully Executed / Active */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-lg flex flex-col justify-between hover:border-emerald-500/30 transition-all group">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">Active & Signed</span>
            <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
              <CheckCircle2 className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-emerald-300 tracking-tight">{activeContracts}</span>
            <span className="text-[11px] text-emerald-400/70 block mt-0.5 font-medium">Enforceable agreements</span>
          </div>
        </div>

        {/* Expiring Soon */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-lg flex flex-col justify-between hover:border-rose-500/30 transition-all group">
          <div className="flex items-center justify-between text-rose-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">Expiring in 60d</span>
            <div className="w-7 h-7 rounded-lg bg-rose-500/10 flex items-center justify-center text-rose-400">
              <AlertOctagon className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-rose-300 tracking-tight">{expiringSoon}</span>
            <span className="text-[11px] text-rose-400/70 block mt-0.5 font-medium">Requires renewal notice</span>
          </div>
        </div>

        {/* Portfolio Value */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-lg flex flex-col justify-between hover:border-cyan-500/30 transition-all group">
          <div className="flex items-center justify-between text-cyan-400">
            <span className="text-[11px] font-semibold uppercase tracking-wider text-zinc-400">Total Value (USD)</span>
            <div className="w-7 h-7 rounded-lg bg-cyan-500/10 flex items-center justify-center text-cyan-400">
              <DollarSign className="w-3.5 h-3.5" />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-2xl font-black text-cyan-300 tracking-tight">
              ${(totalUsdValue / 1000000).toFixed(2)}M
            </span>
            <span className="text-[11px] text-cyan-400/70 block mt-0.5 font-medium">Combined commitments</span>
          </div>
        </div>
      </div>

      {/* Main Analytics Bento Grid: Risk Radar & High Liability Contracts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Contract Portfolio & Risk Breakdown */}
        <div className="lg:col-span-2 space-y-6">
          
          {/* Risk Scoring & Category Breakdown Bento Tile */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-emerald-400" />
                  Portfolio Risk Intelligence & Scoring
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">Automated weighted calculation across 5 key contractual risk vectors</p>
              </div>
              <div className="flex items-center gap-2 bg-zinc-900/90 px-3.5 py-1.5 rounded-xl border border-white/[0.08]">
                <span className="text-xs text-zinc-400">Avg Risk Score:</span>
                <span className={`text-xs font-bold px-2.5 py-0.5 rounded-lg ${
                  avgRiskScore > 60 ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30' :
                  avgRiskScore > 35 ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {avgRiskScore} / 100
                </span>
              </div>
            </div>

            {/* Risk Category Bars */}
            <div className="space-y-4 mt-5">
              <div>
                <div className="flex justify-between text-xs text-zinc-300 mb-1.5">
                  <span className="font-medium">Financial & Liability Exposure (Caps, Consequential Damages, Penalties)</span>
                  <span className="font-semibold text-amber-400">Medium-High (54/100)</span>
                </div>
                <div className="w-full bg-zinc-950 h-2.5 rounded-full overflow-hidden border border-white/[0.05]">
                  <div className="bg-gradient-to-r from-amber-500 to-rose-500 h-full rounded-full" style={{ width: '54%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-zinc-300 mb-1.5">
                  <span className="font-medium">Legal & Dispute Enforceability (Governing Law, Arbitration Seat, Forum Selection)</span>
                  <span className="font-semibold text-emerald-400">Low-Moderate (32/100)</span>
                </div>
                <div className="w-full bg-zinc-950 h-2.5 rounded-full overflow-hidden border border-white/[0.05]">
                  <div className="bg-gradient-to-r from-emerald-500 to-teal-400 h-full rounded-full" style={{ width: '32%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-zinc-300 mb-1.5">
                  <span className="font-medium">Data Protection & Privacy Compliance (GDPR, DPDPA 2023, CCPA, Breach Notice)</span>
                  <span className="font-semibold text-cyan-400">Moderate (46/100)</span>
                </div>
                <div className="w-full bg-zinc-950 h-2.5 rounded-full overflow-hidden border border-white/[0.05]">
                  <div className="bg-gradient-to-r from-cyan-500 to-indigo-500 h-full rounded-full" style={{ width: '46%' }} />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-xs text-zinc-300 mb-1.5">
                  <span className="font-medium">Operational & SLA Commitment (Uptime, Acceptance Deadlines, Milestones)</span>
                  <span className="font-semibold text-emerald-400">Healthy (28/100)</span>
                </div>
                <div className="w-full bg-zinc-950 h-2.5 rounded-full overflow-hidden border border-white/[0.05]">
                  <div className="bg-gradient-to-r from-emerald-500 to-cyan-500 h-full rounded-full" style={{ width: '28%' }} />
                </div>
              </div>
            </div>

            {/* Quick Warning Callout */}
            <div className="mt-6 p-3.5 rounded-2xl bg-amber-950/20 border border-amber-500/20 flex items-center justify-between text-xs text-amber-200">
              <div className="flex items-center gap-2.5">
                <AlertOctagon className="w-4 h-4 text-amber-400 shrink-0" />
                <span><strong>1 High-Risk Contract:</strong> GL-2026-MSA-0881 has counterparty redlines tripling liability exposure to 3x contract value.</span>
              </div>
              <button 
                onClick={onStartRedline}
                className="px-3 py-1.5 bg-amber-600 hover:bg-amber-500 text-white rounded-xl text-[11px] font-semibold transition-all shrink-0 ml-2 shadow-md shadow-amber-600/20"
              >
                Review Redline
              </button>
            </div>
          </div>

          {/* Active Contracts Table Bento Tile */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-2xl">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-base font-bold text-white flex items-center gap-2">
                  <FileText className="w-4 h-4 text-emerald-400" />
                  Key Contract Portfolio
                </h2>
                <p className="text-xs text-zinc-400 mt-0.5">Recent agreements across global jurisdictions</p>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs text-zinc-300">
                <thead className="bg-zinc-950/80 text-zinc-400 uppercase text-[10px] tracking-wider border-b border-white/[0.06]">
                  <tr>
                    <th className="py-3 px-3.5 rounded-l-xl">Contract & Parties</th>
                    <th className="py-3 px-3">Country / Law</th>
                    <th className="py-3 px-3">Value</th>
                    <th className="py-3 px-3">Risk</th>
                    <th className="py-3 px-3">Status</th>
                    <th className="py-3 px-3.5 text-right rounded-r-xl">Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {contracts.map((c) => {
                    const isHighRisk = c.riskBreakdown.overallScore > 50;
                    return (
                      <tr 
                        key={c.id} 
                        className="hover:bg-white/[0.02] transition-colors cursor-pointer group"
                        onClick={() => onSelectContract(c)}
                      >
                        <td className="py-3.5 px-3.5">
                          <div className="font-semibold text-white truncate max-w-xs group-hover:text-emerald-400 transition-colors">{c.title}</div>
                          <div className="text-[11px] text-zinc-400 flex items-center gap-1.5 mt-0.5">
                            <span className="font-mono text-emerald-400/90">{c.contractNumber}</span>
                            <span>•</span>
                            <span>{c.counterparty.legalName}</span>
                          </div>
                        </td>
                        <td className="py-3.5 px-3">
                          <div className="font-medium text-zinc-200 flex items-center gap-1">
                            <Globe2 className="w-3 h-3 text-cyan-400" />
                            {c.country}
                          </div>
                          <div className="text-[10px] text-zinc-500 truncate max-w-[140px]">{c.governingLaw}</div>
                        </td>
                        <td className="py-3.5 px-3 font-mono font-medium text-zinc-200">
                          {c.commercials.contractValue.toLocaleString()} {c.commercials.currency}
                        </td>
                        <td className="py-3.5 px-3">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                            c.riskBreakdown.overallScore > 60 ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30' :
                            c.riskBreakdown.overallScore > 30 ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' :
                            'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                          }`}>
                            {c.riskBreakdown.overallScore}/100
                          </span>
                        </td>
                        <td className="py-3.5 px-3">
                          <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider ${
                            c.status === 'fully_executed' || c.status === 'active' ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20' :
                            c.status === 'negotiation' || c.status === 'legal_review' ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20' :
                            c.status === 'sent_for_signature' ? 'bg-indigo-500/10 text-indigo-300 border border-indigo-500/20' :
                            c.status === 'expiring_soon' ? 'bg-rose-500/10 text-rose-300 border border-rose-500/20' : 'bg-zinc-800 text-zinc-300 border border-zinc-700'
                          }`}>
                            {c.status.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td className="py-3.5 px-3.5 text-right">
                          <span className="text-emerald-400 hover:text-emerald-300 flex items-center justify-end gap-1 font-semibold text-[11px]">
                            Details <ChevronRight className="w-3.5 h-3.5" />
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* Right 1 Col: Expiry Radar, Jurisdictions & High Exposure Alerts */}
        <div className="space-y-6">
          
          {/* Expiry Radar Bento Card */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-2xl">
            <h2 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
              <Clock className="w-4 h-4 text-rose-400" />
              Contract Expiry & Renewal Radar
            </h2>
            <div className="space-y-3">
              <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.05] flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">Next 30 Days</div>
                  <div className="text-[11px] text-rose-400">1 Contract (SG-JP Joint Venture)</div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-rose-500/10 text-rose-300 text-xs font-bold border border-rose-500/20">Expires Sep 30</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.05] flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">31 - 60 Days</div>
                  <div className="text-[11px] text-amber-400">0 Contracts</div>
                </div>
                <span className="text-xs text-zinc-500 font-medium">Clear</span>
              </div>
              <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.05] flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-white">61 - 90 Days</div>
                  <div className="text-[11px] text-zinc-400">2 Contracts (Auto-Renewal Trigger)</div>
                </div>
                <span className="px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 text-xs font-bold border border-cyan-500/20">Review Soon</span>
              </div>
            </div>
          </div>

          {/* Supported Global Jurisdictions Bento Card */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-2xl">
            <h2 className="text-sm font-bold text-white flex items-center gap-2 mb-4">
              <Globe2 className="w-4 h-4 text-cyan-400" />
              Supported Legal Jurisdictions
            </h2>
            <div className="grid grid-cols-2 gap-2.5 text-xs">
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] text-zinc-300 hover:border-zinc-700 transition-colors">
                <span className="font-semibold text-white block">🇺🇸 United States</span>
                <span className="text-[10px] text-zinc-400">Delaware, CA, NY, UCC</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] text-zinc-300 hover:border-zinc-700 transition-colors">
                <span className="font-semibold text-white block">🇮🇳 India</span>
                <span className="text-[10px] text-zinc-400">Contract Act, DPDPA, MCIA</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] text-zinc-300 hover:border-zinc-700 transition-colors">
                <span className="font-semibold text-white block">🇬🇧 United Kingdom</span>
                <span className="text-[10px] text-zinc-400">England & Wales, LCIA</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] text-zinc-300 hover:border-zinc-700 transition-colors">
                <span className="font-semibold text-white block">🇸🇬 Singapore</span>
                <span className="text-[10px] text-zinc-400">SIAC Rules, PDPA</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] text-zinc-300 hover:border-zinc-700 transition-colors">
                <span className="font-semibold text-white block">🇦🇪 UAE</span>
                <span className="text-[10px] text-zinc-400">DIFC, ADGM, DIAC</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] text-zinc-300 hover:border-zinc-700 transition-colors">
                <span className="font-semibold text-white block">🇩🇪 Germany / EU</span>
                <span className="text-[10px] text-zinc-400">BGB, GDPR Art 28</span>
              </div>
            </div>
          </div>

          {/* Quick Legal Safety Tip Bento Card */}
          <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950/30 via-zinc-900/60 to-zinc-900/90 border border-indigo-500/20 text-xs text-indigo-200 shadow-2xl">
            <div className="flex items-center gap-2 font-bold text-indigo-300 mb-1.5">
              <Scale className="w-4 h-4 text-cyan-400" />
              <span>Contracting Best Practice</span>
            </div>
            <p className="text-[11px] text-zinc-300 leading-relaxed">
              When contracting across borders, always explicitly specify the <strong>Arbitration Seat</strong> rather than general municipal courts to ensure reciprocal enforcement under the 1958 New York Convention.
            </p>
          </div>

        </div>

      </div>

    </div>
  );
};
