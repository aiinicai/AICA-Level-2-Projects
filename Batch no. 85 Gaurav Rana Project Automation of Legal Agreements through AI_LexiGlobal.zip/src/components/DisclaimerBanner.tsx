import React from 'react';
import { ShieldCheck, Scale } from 'lucide-react';

export const DisclaimerBanner: React.FC = () => {
  return (
    <div id="legal-disclaimer-banner" className="bg-amber-950/20 border-b border-amber-500/20 px-4 py-2 text-xs text-amber-200/90 flex flex-wrap items-center justify-between gap-3 backdrop-blur-md">
      <div className="flex items-center gap-2 max-w-5xl">
        <Scale className="w-4 h-4 text-amber-400 shrink-0" />
        <span>
          <strong className="text-amber-300 font-semibold uppercase tracking-wider text-[11px] mr-1.5">Legal Notice & Governance:</strong>
          AI-generated drafts, vetting reports, and redline analyses provide decision-support intelligence and do not constitute formal legal advice. For high-risk, multi-jurisdiction, or material financial contracts, review by a licensed attorney in the relevant jurisdiction is strictly recommended.
        </span>
      </div>
      <div className="flex items-center gap-4 text-zinc-400 text-[11px] shrink-0 font-medium">
        <span className="flex items-center gap-1.5 text-emerald-400">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Statutory Compliance Engine Active</span>
        </span>
      </div>
    </div>
  );
};
