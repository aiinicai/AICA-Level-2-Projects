import React, { useState } from 'react';
import { 
  History, 
  Search, 
  Download, 
  ShieldCheck, 
  Filter, 
  FileText, 
  PenTool, 
  CheckCircle2, 
  AlertTriangle, 
  UserCheck, 
  Sparkles,
  Lock
} from 'lucide-react';
import { AuditLogEntry } from '../types';

export const AuditTrailView: React.FC = () => {
  const [logs, setLogs] = useState<AuditLogEntry[]>([
    {
      id: 'aud-9912',
      timestamp: '2026-08-30T06:14:22Z',
      contractId: 'cnt-01',
      contractNumber: 'GL-2026-US-4821',
      user: 'Marcus Vance (CEO / Admin)',
      userRole: 'admin',
      action: 'E-SIGNATURE_EXECUTED',
      details: 'Affixed authorized digital signature with SHA-256 hash validation.',
      ipAddress: '103.22.18.94',
      userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)',
      severity: 'high'
    },
    {
      id: 'aud-9911',
      timestamp: '2026-08-30T05:42:10Z',
      contractId: 'cnt-01',
      contractNumber: 'GL-2026-US-4821',
      user: 'Sophia Reynolds (Legal Counsel)',
      userRole: 'legal',
      action: 'APPROVAL_STAGE_COMPLETED',
      details: 'Stage 2 Legal Review approved with commentary on liability cap adequacy.',
      ipAddress: '198.51.100.44',
      severity: 'medium'
    },
    {
      id: 'aud-9910',
      timestamp: '2026-08-30T04:18:00Z',
      contractId: 'cnt-02',
      contractNumber: 'GL-2026-IN-9104',
      user: 'Priya Sharma (Legal Counsel)',
      userRole: 'legal',
      action: 'AI_LEGAL_VETTING_RUN',
      details: 'Executed AI legal vetting engine. Detected non-compete voidness under Section 27 Indian Contract Act.',
      ipAddress: '182.72.19.102',
      severity: 'medium'
    },
    {
      id: 'aud-9909',
      timestamp: '2026-08-30T03:15:45Z',
      contractId: 'cnt-03',
      contractNumber: 'GL-2026-MSA-0881',
      user: 'David Chen (Procurement)',
      userRole: 'procurement',
      action: 'REDLINE_DIFF_GENERATED',
      details: 'Executed 3-way redline comparison between v1.0 and v1.1. Detected 3x liability expansion.',
      ipAddress: '192.0.2.78',
      severity: 'high'
    },
    {
      id: 'aud-9908',
      timestamp: '2026-08-30T01:30:12Z',
      contractId: 'cnt-01',
      contractNumber: 'GL-2026-US-4821',
      user: 'Marcus Vance (CEO / Admin)',
      userRole: 'admin',
      action: 'CONTRACT_DRAFT_CREATED',
      details: 'Generated v1.0 Master Services Agreement using Delaware statutory parameters.',
      ipAddress: '103.22.18.94',
      severity: 'low'
    }
  ]);

  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedAction, setSelectedAction] = useState<string>('ALL');

  const filteredLogs = logs.filter(l => {
    const q = searchQuery ? searchQuery.toLowerCase() : '';
    const matchesSearch = !q ||
      (l.contractNumber || '').toLowerCase().includes(q) ||
      (l.user || '').toLowerCase().includes(q) ||
      (l.action || '').toLowerCase().includes(q) ||
      (l.details || '').toLowerCase().includes(q);

    const matchesAction = selectedAction === 'ALL' || l.action === selectedAction;
    return matchesSearch && matchesAction;
  });

  const exportCsv = () => {
    const headers = ['Log ID', 'Timestamp', 'Contract Ref', 'User', 'Role', 'Action', 'Details', 'IP Address', 'Severity'];
    const rows = filteredLogs.map(l => [
      l.id,
      l.timestamp,
      l.contractNumber || 'N/A',
      `"${l.user}"`,
      l.userRole,
      l.action,
      `"${l.details.replace(/"/g, '""')}"`,
      l.ipAddress || 'N/A',
      l.severity
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `LexiGlobal_Audit_Trail_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="audit-trail-view" className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-teal-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <History className="w-3.5 h-3.5 text-emerald-400" />
                Immutable Audit Trail
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              System Audit Logs & Regulatory Event Timeline
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Cryptographically timestamped record of every draft creation, risk evaluation, redline markup, approval decision, and e-signature execution.
            </p>
          </div>

          <button
            onClick={exportCsv}
            className="flex items-center gap-2 px-5 py-2.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-200 border border-white/[0.08] rounded-xl text-xs font-bold shadow-md transition-all hover:scale-[1.02] active:scale-95 shrink-0"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export Audit Trail (CSV)</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4 rounded-3xl shadow-xl flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 flex-1 min-w-[240px] bg-zinc-950/90 px-3.5 py-2.5 rounded-2xl border border-white/[0.08] shadow-inner">
          <Search className="w-4 h-4 text-zinc-400" />
          <input
            type="text"
            placeholder="Search audit logs (user, action, contract #, IP address)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent text-xs text-white placeholder-zinc-500 focus:outline-none w-full"
          />
        </div>

        <select
          value={selectedAction}
          onChange={(e) => setSelectedAction(e.target.value)}
          className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-300 rounded-xl px-3.5 py-2.5 focus:outline-none focus:border-emerald-500 shadow-inner"
        >
          <option value="ALL" className="bg-zinc-900 text-white">All Actions</option>
          <option value="E-SIGNATURE_EXECUTED" className="bg-zinc-900 text-white">E-Signature Executed</option>
          <option value="APPROVAL_STAGE_COMPLETED" className="bg-zinc-900 text-white">Approval Stage</option>
          <option value="AI_LEGAL_VETTING_RUN" className="bg-zinc-900 text-white">AI Legal Vetting</option>
          <option value="REDLINE_DIFF_GENERATED" className="bg-zinc-900 text-white">Redline Diff</option>
          <option value="CONTRACT_DRAFT_CREATED" className="bg-zinc-900 text-white">Contract Draft Created</option>
        </select>
      </div>

      {/* Audit Log Table */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-zinc-300">
            <thead className="bg-zinc-950/80 text-zinc-400 uppercase text-[10px] tracking-wider border-b border-white/[0.06]">
              <tr>
                <th className="py-3.5 px-4 font-semibold">Timestamp & ID</th>
                <th className="py-3.5 px-4 font-semibold">Contract Reference</th>
                <th className="py-3.5 px-4 font-semibold">User & Role</th>
                <th className="py-3.5 px-4 font-semibold">Action Type</th>
                <th className="py-3.5 px-4 font-semibold">Action Details</th>
                <th className="py-3.5 px-4 font-semibold">IP & Node</th>
                <th className="py-3.5 px-4 font-semibold">Severity</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/[0.04]">
              {filteredLogs.map((log) => (
                <tr key={log.id} className="hover:bg-zinc-900/60 transition-colors">
                  <td className="py-4 px-4 font-mono text-[11px] text-zinc-400">
                    <div className="text-zinc-300 font-medium">{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</div>
                    <div className="text-[10px] text-zinc-500">{new Date(log.timestamp).toISOString().split('T')[0]}</div>
                  </td>

                  <td className="py-4 px-4 font-mono text-emerald-400 font-medium">
                    {log.contractNumber || 'Global System'}
                  </td>

                  <td className="py-4 px-4">
                    <div className="font-semibold text-white">{log.user}</div>
                    <div className="text-[10px] text-zinc-500 uppercase font-mono">{log.userRole}</div>
                  </td>

                  <td className="py-4 px-4">
                    <span className="px-2.5 py-1 rounded-lg text-[10px] font-mono font-bold bg-zinc-950 text-emerald-300 border border-white/[0.08]">
                      {log.action}
                    </span>
                  </td>

                  <td className="py-4 px-4 text-zinc-300 max-w-xs leading-relaxed">
                    {log.details}
                  </td>

                  <td className="py-4 px-4 font-mono text-[11px] text-zinc-400">
                    {log.ipAddress}
                  </td>

                  <td className="py-4 px-4">
                    <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                      log.severity === 'high' ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30' :
                      log.severity === 'medium' ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' :
                      'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                    }`}>
                      {log.severity}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
