import React, { useState } from 'react';
import { 
  CheckCircle2, 
  Clock, 
  XCircle, 
  AlertTriangle, 
  ArrowRight, 
  FileText, 
  ShieldCheck, 
  UserCheck, 
  Send, 
  Plus, 
  Sliders,
  DollarSign,
  Scale
} from 'lucide-react';
import { ContractItem, ApprovalStep, UserRole } from '../types';

interface ApprovalWorkflowProps {
  contracts: ContractItem[];
  userRole: UserRole;
  onUpdateContractApprovals?: (contractId: string, steps: ApprovalStep[]) => void;
}

export const ApprovalWorkflowView: React.FC<ApprovalWorkflowProps> = ({
  contracts,
  userRole,
  onUpdateContractApprovals
}) => {
  const [selectedContractId, setSelectedContractId] = useState<string>(contracts[0]?.id || '');
  const [activeComment, setActiveComment] = useState<string>('');

  const activeContract = contracts.find(c => c.id === selectedContractId) || contracts[0];
  const [approvalSteps, setApprovalSteps] = useState<ApprovalStep[]>(activeContract?.approvals || []);

  const handleSelectContract = (id: string) => {
    setSelectedContractId(id);
    const found = contracts.find(c => c.id === id);
    if (found) {
      setApprovalSteps(found.approvals);
    }
  };

  // Perform Approval Action
  const handleAction = (stepId: string, action: 'approved' | 'rejected' | 'revision_requested') => {
    const updated = approvalSteps.map(step => {
      if (step.id === stepId) {
        return {
          ...step,
          status: action,
          actionTimestamp: new Date().toISOString(),
          comments: activeComment || (action === 'approved' ? 'Approved without reservations.' : 'Revision requested.')
        };
      }
      return step;
    });

    setApprovalSteps(updated);
    setActiveComment('');
    if (onUpdateContractApprovals) {
      onUpdateContractApprovals(activeContract.id, updated);
    }
  };

  const getStepStatusIcon = (status: ApprovalStep['status']) => {
    switch (status) {
      case 'approved':
        return <CheckCircle2 className="w-5 h-5 text-emerald-400" />;
      case 'rejected':
        return <XCircle className="w-5 h-5 text-rose-400" />;
      case 'revision_requested':
        return <AlertTriangle className="w-5 h-5 text-amber-400" />;
      default:
        return <Clock className="w-5 h-5 text-slate-500" />;
    }
  };

  return (
    <div id="approval-workflow-view" className="space-y-6 pb-12">
      
      {/* Top Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-emerald-500/10 via-teal-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 flex items-center gap-1.5 shadow-sm">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                Governance & Multi-Tier Approvals
              </span>
              <span className="text-xs text-zinc-500 font-mono">Automated Threshold Triggers</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Contract Approval Workflows & Routing Matrix
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Enforce role-based internal reviews and sign-offs triggered dynamically by contract value, risk rating, jurisdiction, and uncapped liability.
            </p>
          </div>

          {/* Contract Selector */}
          <div className="flex items-center gap-2">
            <select
              value={selectedContractId}
              onChange={(e) => handleSelectContract(e.target.value)}
              className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-200 rounded-xl px-3.5 py-2 focus:outline-none focus:border-emerald-500 shadow-inner"
            >
              {contracts.map(c => (
                <option key={c.id} value={c.id} className="bg-zinc-900 text-white">
                  {c.contractNumber} • {c.title.substring(0, 30)}...
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Threshold Rules Summary Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-5 rounded-3xl shadow-xl flex items-start gap-3.5">
          <div className="p-2.5 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <DollarSign className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <span className="font-bold text-white block">Value Threshold Rules</span>
            <p className="text-zinc-400 mt-1 leading-relaxed">&gt; $100k requires CFO sign-off; &gt; $500k requires Executive Committee approval.</p>
          </div>
        </div>

        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-5 rounded-3xl shadow-xl flex items-start gap-3.5">
          <div className="p-2.5 rounded-2xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Scale className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <span className="font-bold text-white block">Liability & Risk Threshold</span>
            <p className="text-zinc-400 mt-1 leading-relaxed">Uncapped liability or risk score &gt; 50 strictly mandates General Counsel sign-off.</p>
          </div>
        </div>

        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-5 rounded-3xl shadow-xl flex items-start gap-3.5">
          <div className="p-2.5 rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <UserCheck className="w-4 h-4" />
          </div>
          <div className="text-xs">
            <span className="font-bold text-white block">HR & IP Restrictive Covenants</span>
            <p className="text-zinc-400 mt-1 leading-relaxed">Non-compete covenants or patent assignment requires HR & Chief Technology Officer sign-off.</p>
          </div>
        </div>
      </div>

      {/* Main Workflow View for Active Contract */}
      {activeContract && (
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 sm:p-7 shadow-2xl space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.06] pb-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-emerald-400">{activeContract.contractNumber}</span>
                <span className="text-xs text-zinc-600">•</span>
                <span className="text-xs text-zinc-300 font-medium">{activeContract.category.toUpperCase()}</span>
              </div>
              <h2 className="text-xl font-bold text-white mt-1">{activeContract.title}</h2>
            </div>

            <div className="flex items-center gap-4 text-xs bg-zinc-950/80 p-3 rounded-2xl border border-white/[0.06]">
              <div>
                <span className="text-[10px] text-zinc-500 block uppercase font-semibold">Total Value</span>
                <span className="font-bold text-white mt-0.5 block">{activeContract.commercials.contractValue.toLocaleString()} {activeContract.commercials.currency}</span>
              </div>
              <div className="border-l border-white/[0.08] pl-4">
                <span className="text-[10px] text-zinc-500 block uppercase font-semibold">Risk Score</span>
                <span className={`font-bold mt-0.5 block ${activeContract.riskBreakdown.overallScore > 50 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {activeContract.riskBreakdown.overallScore}/100
                </span>
              </div>
            </div>
          </div>

          {/* Sequential Stage Stepper */}
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Approval Steps Pipeline</h3>

            <div className="space-y-3.5">
              {approvalSteps.map((step, index) => {
                const isCurrentRoleMatch = userRole === step.roleRequired || userRole === 'admin';
                const isPending = step.status === 'pending';

                return (
                  <div
                    key={step.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      step.status === 'approved' ? 'bg-emerald-950/20 border-emerald-500/30' :
                      step.status === 'rejected' ? 'bg-rose-950/20 border-rose-500/30' :
                      step.status === 'revision_requested' ? 'bg-amber-950/20 border-amber-500/30' :
                      'bg-zinc-950/80 border-white/[0.06]'
                    }`}
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      <div className="flex items-start gap-3.5">
                        <div className="mt-0.5">{getStepStatusIcon(step.status)}</div>
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-bold text-xs text-white">
                              Stage {index + 1}: {step.stepName}
                            </span>
                            <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold bg-zinc-900 text-zinc-300 uppercase border border-white/[0.06]">
                              {step.roleRequired}
                            </span>
                            {step.thresholdCondition && (
                              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-800/60">
                                Trigger: {step.thresholdCondition}
                              </span>
                            )}
                          </div>

                          <div className="text-[11px] text-zinc-400 mt-1.5 flex flex-wrap items-center gap-2">
                            <span>Assigned: <strong className="text-zinc-200">{step.assignedUserEmail}</strong></span>
                            {step.actionTimestamp && (
                              <>
                                <span>•</span>
                                <span>Actioned: {new Date(step.actionTimestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                              </>
                            )}
                          </div>

                          {step.comments && (
                            <p className="mt-2.5 text-xs text-zinc-300 italic bg-zinc-900/90 p-2.5 rounded-xl border border-white/[0.06]">
                              &quot;{step.comments}&quot;
                            </p>
                          )}
                        </div>
                      </div>

                      {/* Approval Action Controls for User */}
                      {isPending && (
                        <div className="flex flex-wrap items-center gap-2 shrink-0">
                          {isCurrentRoleMatch ? (
                            <>
                              <button
                                onClick={() => handleAction(step.id, 'revision_requested')}
                                className="px-3.5 py-1.5 bg-amber-600/10 hover:bg-amber-600/20 text-amber-300 border border-amber-500/30 rounded-xl text-xs font-semibold transition-colors"
                              >
                                Request Revision
                              </button>
                              <button
                                onClick={() => handleAction(step.id, 'rejected')}
                                className="px-3.5 py-1.5 bg-rose-600/10 hover:bg-rose-600/20 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-semibold transition-colors"
                              >
                                Reject
                              </button>
                              <button
                                onClick={() => handleAction(step.id, 'approved')}
                                className="px-4 py-1.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all active:scale-95"
                              >
                                Approve Stage
                              </button>
                            </>
                          ) : (
                            <span className="text-[11px] text-zinc-500 italic">
                              Awaiting {step.roleRequired} sign-off
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Comment input box */}
          <div className="pt-3 border-t border-white/[0.06]">
            <label className="block text-xs font-medium text-zinc-300 mb-1.5">Optional Review Comments / Feedback</label>
            <input
              type="text"
              placeholder="Provide context for approval or specific requested revisions..."
              value={activeComment}
              onChange={(e) => setActiveComment(e.target.value)}
              className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-3 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 shadow-inner"
            />
          </div>

        </div>
      )}

    </div>
  );
};
