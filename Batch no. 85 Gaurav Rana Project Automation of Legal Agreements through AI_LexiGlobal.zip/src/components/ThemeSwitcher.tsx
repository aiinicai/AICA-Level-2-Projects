import React, { useState, useRef, useEffect } from 'react';
import { 
  Sun, 
  Moon, 
  Palette, 
  Check, 
  ChevronDown, 
  Sparkles,
  BookOpen,
  Compass
} from 'lucide-react';
import { useTheme, THEME_OPTIONS } from '../context/ThemeContext';
import { AppTheme } from '../types';

interface ThemeSwitcherProps {
  compact?: boolean;
  showDropdownOnly?: boolean;
}

export const ThemeSwitcher: React.FC<ThemeSwitcherProps> = ({ 
  compact = false,
  showDropdownOnly = false 
}) => {
  const { theme, setTheme, toggleDarkLight, isDark } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  const currentThemeObj = THEME_OPTIONS.find(t => t.id === theme) || THEME_OPTIONS[0];

  const getThemeIcon = (themeId: AppTheme) => {
    switch (themeId) {
      case 'light':
        return <Sun className="w-3.5 h-3.5 text-amber-500" />;
      case 'parchment':
        return <BookOpen className="w-3.5 h-3.5 text-amber-600" />;
      case 'navy':
        return <Compass className="w-3.5 h-3.5 text-sky-400" />;
      case 'dark':
      default:
        return <Moon className="w-3.5 h-3.5 text-emerald-400" />;
    }
  };

  return (
    <div className="relative inline-flex items-center gap-1.5" ref={dropdownRef}>
      {/* Quick 1-Click Toggle between Light and Dark (if not dropdown-only) */}
      {!showDropdownOnly && (
        <button
          type="button"
          id="theme-quick-toggle-btn"
          onClick={toggleDarkLight}
          className="p-1.5 rounded-xl bg-zinc-900/90 border border-white/[0.08] text-zinc-300 hover:text-white hover:bg-zinc-800 transition-all active:scale-95 shadow-sm"
          title={isDark ? "Switch to Executive Light theme" : "Switch to Obsidian Dark theme"}
          aria-label={isDark ? "Switch to light theme" : "Switch to dark theme"}
        >
          {isDark ? (
            <Sun className="w-4 h-4 text-amber-400 animate-in fade-in transition-transform duration-300 hover:rotate-45" />
          ) : (
            <Moon className="w-4 h-4 text-indigo-400 animate-in fade-in transition-transform duration-300 hover:-rotate-12" />
          )}
        </button>
      )}

      {/* Palette Selector Trigger */}
      <button
        type="button"
        id="theme-selector-trigger-btn"
        onClick={() => setIsOpen(prev => !prev)}
        className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-zinc-900/90 border border-white/[0.08] text-xs font-medium text-zinc-200 hover:border-zinc-700 hover:text-white transition-all shadow-sm ${
          isOpen ? 'ring-2 ring-emerald-500/40 border-emerald-500/50' : ''
        }`}
        title="Change application theme & color scheme"
        aria-expanded={isOpen}
      >
        <div className="flex items-center gap-1">
          <Palette className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          {!compact && (
            <span className="hidden sm:inline text-xs font-medium text-zinc-200">
              {currentThemeObj.name.split(' ')[0]}
            </span>
          )}
        </div>
        <div 
          className="w-2.5 h-2.5 rounded-full shrink-0 border border-white/20 shadow-xs" 
          style={{ backgroundColor: currentThemeObj.previewAccent }}
          title={`Active theme: ${currentThemeObj.name}`}
        />
        <ChevronDown className={`w-3 h-3 text-zinc-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div 
          className="absolute right-0 top-full mt-2 w-72 rounded-2xl bg-[#121215] border border-white/[0.12] p-2 shadow-2xl z-50 animate-in fade-in zoom-in-95 duration-150 backdrop-blur-xl bento-glow-emerald"
          role="menu"
          aria-orientation="vertical"
        >
          <div className="px-2.5 py-1.5 border-b border-white/[0.06] mb-1.5 flex items-center justify-between">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
              <Palette className="w-3 h-3 text-emerald-400" />
              <span>Visual Appearance</span>
            </div>
            <span className="text-[10px] text-zinc-500 font-mono">4 Themes</span>
          </div>

          <div className="space-y-1">
            {THEME_OPTIONS.map((opt) => {
              const isSelected = theme === opt.id;
              return (
                <button
                  key={opt.id}
                  type="button"
                  onClick={() => {
                    setTheme(opt.id);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-start gap-3 p-2.5 rounded-xl text-left transition-all group ${
                    isSelected 
                      ? 'bg-emerald-500/10 border border-emerald-500/30 text-white' 
                      : 'hover:bg-zinc-800/60 border border-transparent text-zinc-300 hover:text-white'
                  }`}
                  role="menuitem"
                >
                  {/* Theme preview swatch badge */}
                  <div 
                    className="w-8 h-8 rounded-lg shrink-0 border border-white/10 flex items-center justify-center shadow-md relative overflow-hidden mt-0.5"
                    style={{ backgroundColor: opt.previewBg }}
                  >
                    <div 
                      className="absolute inset-x-1 bottom-1 h-3 rounded-xs opacity-90" 
                      style={{ backgroundColor: opt.previewCard }}
                    />
                    <div 
                      className="w-2.5 h-2.5 rounded-full z-10 shadow-xs" 
                      style={{ backgroundColor: opt.previewAccent }}
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <div className="flex items-center gap-1.5">
                        {getThemeIcon(opt.id)}
                        <span className="text-xs font-bold truncate">{opt.name}</span>
                      </div>
                      {isSelected && (
                        <Check className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      )}
                    </div>
                    <p className="text-[10px] text-zinc-400 leading-snug mt-0.5 line-clamp-1 group-hover:text-zinc-300">
                      {opt.tagline}
                    </p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="mt-2 pt-2 border-t border-white/[0.06] px-2 flex items-center justify-between text-[10px] text-zinc-400">
            <span className="flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span>Instant hot-swapping</span>
            </span>
            <span>Auto-persisted</span>
          </div>
        </div>
      )}
    </div>
  );
};
