import React from 'react';
import { 
  Scale, 
  FileText, 
  ShieldAlert, 
  GitCompare, 
  BookOpen, 
  FolderArchive, 
  CheckCircle2, 
  PenTool, 
  Send, 
  Database, 
  BarChart3, 
  History, 
  Sparkles,
  PlusCircle,
  ChevronRight,
  PanelLeftClose,
  PanelLeftOpen,
  Sun,
  Moon,
  Palette
} from 'lucide-react';
import { UserRole } from '../types';
import { useTheme, THEME_OPTIONS } from '../context/ThemeContext';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  isCollapsed: boolean;
  onToggleCollapse: () => void;
  onStartDrafting: () => void;
  userRole: UserRole;
  pendingApprovalsCount?: number;
  highRiskCount?: number;
}

interface NavSection {
  title: string;
  items: {
    id: string;
    label: string;
    icon: React.ElementType;
    badge?: string;
    badgeColor?: string;
  }[];
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  isCollapsed,
  onToggleCollapse,
  onStartDrafting,
  userRole,
  pendingApprovalsCount,
  highRiskCount
}) => {
  const { theme, setTheme, toggleDarkLight, isDark } = useTheme();

  const navSections: NavSection[] = [
    {
      title: 'CORE WORKFLOWS',
      items: [
        { id: 'dashboard', label: 'Executive Dashboard', icon: BarChart3 },
        { id: 'drafting', label: 'Drafting Wizard', icon: FileText },
        { 
          id: 'vetting', 
          label: 'AI Legal Vetting', 
          icon: ShieldAlert,
          badge: highRiskCount && highRiskCount > 0 ? `${highRiskCount}` : undefined,
          badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30'
        },
        { id: 'redline', label: '3-Way Redline & Diff', icon: GitCompare }
      ]
    },
    {
      title: 'CLM OPERATIONS',
      items: [
        { id: 'clauses', label: 'Clause Intelligence', icon: BookOpen },
        { id: 'repository', label: 'Contract Repository', icon: FolderArchive },
        { 
          id: 'approvals', 
          label: 'Approval Workflows', 
          icon: CheckCircle2,
          badge: pendingApprovalsCount && pendingApprovalsCount > 0 ? `${pendingApprovalsCount}` : undefined,
          badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30'
        },
        { id: 'esignature', label: 'Digital E-Signature', icon: PenTool },
        { id: 'distribution', label: 'Email Distribution', icon: Send }
      ]
    },
    {
      title: 'GOVERNANCE & SYSTEM',
      items: [
        { id: 'knowledge', label: 'Legal Knowledge Base', icon: Database },
        { id: 'audit', label: 'Audit Trail', icon: History }
      ]
    }
  ];

  const roleNames: Record<UserRole, string> = {
    admin: 'Administrator',
    legal: 'General Counsel',
    finance: 'CFO / Finance',
    procurement: 'Procurement Officer',
    hr: 'HR & People Ops',
    business: 'Business Project Lead',
    management: 'Executive Management',
    external_signer: 'External Signatory'
  };

  return (
    <aside 
      id="frozen-vertical-sidebar"
      className={`h-screen flex flex-col shrink-0 bg-[#0c0c0e]/95 backdrop-blur-xl border-r border-white/[0.08] z-30 shadow-2xl select-none transition-all duration-300 ease-in-out ${
        isCollapsed ? 'w-18' : 'w-64 xl:w-72'
      }`}
    >
      {/* Brand Header & Freeze/Collapse Toggle */}
      <div className={`border-b border-white/[0.08] flex items-center shrink-0 ${
        isCollapsed ? 'p-3 flex-col gap-2 justify-center' : 'p-4 justify-between'
      }`}>
        <div 
          className="flex items-center gap-2.5 cursor-pointer group min-w-0"
          onClick={() => setActiveTab('dashboard')}
          title="LexiGlobal AI CLM"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 via-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white font-bold ring-1 ring-white/20 shrink-0 group-hover:scale-105 transition-transform">
            <Scale className="w-5 h-5" />
          </div>
          
          {!isCollapsed && (
            <div className="truncate">
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-sm tracking-tight text-white font-sans">
                  LEXI<span className="text-emerald-400">GLOBAL</span>
                </span>
                <span className="px-1.5 py-0.2 rounded text-[9px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-0.5 shrink-0">
                  <Sparkles className="w-2.5 h-2.5 text-cyan-300" />
                  AI CLM
                </span>
              </div>
              <p className="text-[10px] text-zinc-400 font-medium truncate">Enterprise Legal Suite</p>
            </div>
          )}
        </div>

        {/* Freeze / Collapse Toggle Button */}
        <button
          id="sidebar-freeze-toggle-btn"
          onClick={onToggleCollapse}
          className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors shrink-0"
          title={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
          aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {isCollapsed ? (
            <PanelLeftOpen className="w-4 h-4 text-emerald-400" />
          ) : (
            <PanelLeftClose className="w-4 h-4 text-zinc-400 hover:text-zinc-200" />
          )}
        </button>
      </div>

      {/* Primary Action Button */}
      <div className={`shrink-0 ${isCollapsed ? 'p-2' : 'p-3 pb-1'}`}>
        {isCollapsed ? (
          <button
            id="sidebar-new-contract-btn-collapsed"
            onClick={onStartDrafting}
            className="w-full h-10 flex items-center justify-center bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl shadow-lg shadow-emerald-500/20 transition-all hover:scale-105 active:scale-95 group"
            title="Draft New Contract"
          >
            <PlusCircle className="w-5 h-5 text-emerald-100 group-hover:rotate-90 transition-transform duration-200" />
          </button>
        ) : (
          <button
            id="sidebar-new-contract-btn"
            onClick={onStartDrafting}
            className="w-full flex items-center justify-center gap-2 px-3 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-500/20 transition-all hover:scale-[1.02] active:scale-95 group"
          >
            <PlusCircle className="w-4 h-4 text-emerald-100 group-hover:rotate-90 transition-transform duration-200" />
            <span>Draft New Contract</span>
          </button>
        )}
      </div>

      {/* Navigation Sections (Scrollable within frozen sidebar if needed) */}
      <div className="flex-1 overflow-y-auto px-2 py-3 space-y-4 custom-scrollbar">
        {navSections.map((section) => (
          <div key={section.title} className="space-y-1">
            {!isCollapsed && (
              <h3 className="px-2.5 text-[10px] font-bold text-zinc-400 uppercase tracking-wider font-mono">
                {section.title}
              </h3>
            )}
            {isCollapsed && (
              <div className="w-full border-t border-white/[0.06] my-1" />
            )}
            
            <div className="space-y-0.5 pt-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                
                if (isCollapsed) {
                  return (
                    <button
                      key={item.id}
                      id={`nav-tab-collapsed-${item.id}`}
                      onClick={() => setActiveTab(item.id)}
                      title={item.label}
                      className={`relative w-full h-10 flex items-center justify-center rounded-xl transition-all group ${
                        isActive
                          ? 'bg-emerald-500/15 text-white shadow-sm ring-1 ring-emerald-500/40'
                          : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                      }`}
                    >
                      <Icon 
                        className={`w-5 h-5 transition-colors ${
                          isActive 
                            ? 'text-emerald-400' 
                            : 'text-zinc-400 group-hover:text-zinc-300'
                        }`} 
                      />
                      {/* Active Indicator Bar */}
                      {isActive && (
                        <div className="absolute left-0 top-2 bottom-2 w-1 bg-emerald-500 rounded-r-full" />
                      )}
                      {/* Badge indicator dot if count exists */}
                      {item.badge && (
                        <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-rose-500 ring-2 ring-zinc-950" />
                      )}
                    </button>
                  );
                }

                return (
                  <button
                    key={item.id}
                    id={`nav-tab-${item.id}`}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-2.5 rounded-xl text-xs font-medium transition-all group ${
                      isActive
                        ? 'bg-emerald-500/10 text-white font-semibold border-l-2 border-emerald-500 shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon 
                        className={`w-4 h-4 transition-colors shrink-0 ${
                          isActive 
                            ? 'text-emerald-400' 
                            : 'text-zinc-400 group-hover:text-zinc-300'
                        }`} 
                      />
                      <span className="truncate">{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0 ml-1">
                      {item.badge && (
                        <span className={`px-1.5 py-0.5 rounded-full text-[10px] font-bold border ${item.badgeColor || 'bg-zinc-800 text-zinc-300 border-zinc-700'}`}>
                          {item.badge}
                        </span>
                      )}
                      {isActive && (
                        <ChevronRight className="w-3.5 h-3.5 text-emerald-400/80 shrink-0" />
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Bottom User Role & Theme Card */}
      <div className="p-2.5 border-t border-white/[0.08] bg-zinc-950/40 shrink-0 space-y-2">
        {isCollapsed ? (
          <div className="flex flex-col items-center gap-2">
            <button
              type="button"
              id="sidebar-collapsed-theme-btn"
              onClick={toggleDarkLight}
              className="w-8 h-8 flex items-center justify-center rounded-xl bg-zinc-900/80 border border-white/[0.08] text-zinc-300 hover:text-white hover:bg-zinc-800 transition-all shadow-xs"
              title={`Theme: ${theme.toUpperCase()} (Click to toggle Dark/Light)`}
            >
              {isDark ? (
                <Sun className="w-3.5 h-3.5 text-amber-400" />
              ) : (
                <Moon className="w-3.5 h-3.5 text-indigo-400" />
              )}
            </button>
            <div 
              className="w-full flex flex-col items-center py-2 rounded-xl bg-zinc-900/60 border border-white/[0.06] text-center"
              title={`Active Role: ${roleNames[userRole] || userRole} • AI CLM Active`}
            >
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse mb-1" />
              <span className="text-[9px] font-mono text-zinc-400 uppercase">v2.4</span>
            </div>
          </div>
        ) : (
          <>
            {/* Theme Selector Palette */}
            <div className="p-2 rounded-xl bg-zinc-900/60 border border-white/[0.06] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-zinc-400 uppercase flex items-center gap-1">
                  <Palette className="w-3 h-3 text-emerald-400" />
                  Theme
                </span>
                <span className="text-[10px] text-zinc-400 capitalize font-medium">
                  {theme}
                </span>
              </div>
              <div className="grid grid-cols-4 gap-1 pt-0.5">
                {THEME_OPTIONS.map(opt => {
                  const isSelected = theme === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => setTheme(opt.id)}
                      className={`flex flex-col items-center py-1.5 px-1 rounded-lg border transition-all ${
                        isSelected 
                          ? 'bg-emerald-500/15 border-emerald-500/50 shadow-xs ring-1 ring-emerald-500/40' 
                          : 'bg-zinc-900/90 border-white/[0.06] hover:bg-zinc-800 hover:border-zinc-700'
                      }`}
                      title={`${opt.name}: ${opt.tagline}`}
                    >
                      <span 
                        className="w-2.5 h-2.5 rounded-full border border-white/20 mb-1"
                        style={{ backgroundColor: opt.previewAccent }}
                      />
                      <span className={`text-[9px] truncate max-w-full font-medium ${isSelected ? 'text-emerald-300' : 'text-zinc-400'}`}>
                        {opt.name.split(' ')[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Role & Status */}
            <div className="p-2.5 rounded-xl bg-zinc-900/80 border border-white/[0.06] space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-zinc-400 uppercase">Active Role</span>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-900/50 text-indigo-200 border border-indigo-700 truncate max-w-[130px]">
                  {roleNames[userRole] || userRole}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] pt-1 border-t border-white/[0.04]">
                <span className="flex items-center gap-1.5 text-emerald-400 font-medium text-[11px]">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                  AI CLM Active
                </span>
                <span className="text-[10px] text-zinc-400 font-mono">v2.4 Pro</span>
              </div>
            </div>
          </>
        )}
      </div>
    </aside>
  );
};
