import React, { useState } from 'react';
import { Search, Sparkles, FileText, ChevronRight, Scale, Globe2, ShieldAlert } from 'lucide-react';
import { ContractItem } from '../types';

interface NaturalSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  contracts: ContractItem[];
  onSelectContract: (contract: ContractItem) => void;
}

export const NaturalSearchModal: React.FC<NaturalSearchModalProps> = ({
  isOpen,
  onClose,
  contracts,
  onSelectContract
}) => {
  if (!isOpen) return null;

  const [query, setQuery] = useState<string>('');

  const quickPrompts = [
    'Contracts expiring in 90 days',
    'Agreements with high liability risk (> 50)',
    'India jurisdiction (DPDPA / IT Act)',
    'Uncapped liability or missing indemnity',
    'Master Services Agreements (MSA)'
  ];

  const getResults = () => {
    if (!query.trim()) return contracts.slice(0, 4);

    const q = query.toLowerCase();

    if (q.includes('expir') || q.includes('90 days') || q.includes('renewal')) {
      return contracts.filter(c => c.status === 'expiring_soon' || c.renewalNoticeDays >= 30);
    }
    if (q.includes('risk') || q.includes('high') || q.includes('exposure')) {
      return contracts.filter(c => c.riskBreakdown.overallScore > 35);
    }
    if (q.includes('india') || q.includes('inr')) {
      return contracts.filter(c => c.country === 'India');
    }
    if (q.includes('delaware') || q.includes('us')) {
      return contracts.filter(c => c.country === 'United States' || c.governingLaw.includes('Delaware'));
    }

    return contracts.filter(c => 
      (c.title || '').toLowerCase().includes(q) ||
      (c.contractNumber || '').toLowerCase().includes(q) ||
      (c.primaryParty?.legalName || '').toLowerCase().includes(q) ||
      (c.counterparty?.legalName || '').toLowerCase().includes(q) ||
      (c.contractType || '').toLowerCase().includes(q)
    );
  };

  const results = getResults();

  return (
    <div id="natural-search-modal" className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-start justify-center p-4 pt-20">
      <div className="bg-[#121215]/95 border border-white/[0.08] rounded-3xl max-w-2xl w-full shadow-2xl overflow-hidden space-y-4 p-6 bento-glow-emerald">
        
        {/* Search Input Bar */}
        <div className="flex items-center gap-3 bg-zinc-950/90 px-4 py-3.5 rounded-2xl border border-white/[0.08] focus-within:border-emerald-500/50 transition-colors">
          <Search className="w-5 h-5 text-emerald-400 shrink-0" />
          <input
            autoFocus
            type="text"
            placeholder="Ask or search in natural language (e.g. 'high liability contracts', 'India agreements')..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="bg-transparent text-sm text-white placeholder-zinc-500 focus:outline-none w-full"
          />
          <button onClick={onClose} className="text-zinc-400 hover:text-white text-xs font-bold px-2 py-1 bg-zinc-800 rounded-lg">
            ESC
          </button>
        </div>

        {/* Suggested Quick Filters */}
        <div className="flex flex-wrap items-center gap-2 text-[11px]">
          <span className="text-zinc-500 font-semibold flex items-center gap-1 mr-1">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            Suggestions:
          </span>
          {quickPrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => setQuery(p)}
              className="px-3 py-1 rounded-xl bg-zinc-950/80 hover:bg-zinc-800 border border-white/[0.06] text-zinc-300 transition-colors"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Results List */}
        <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
          <div className="text-[11px] font-semibold text-zinc-400 uppercase tracking-wider px-1">
            Matches ({results.length})
          </div>

          {results.length > 0 ? (
            results.map((c) => (
              <div
                key={c.id}
                onClick={() => {
                  onSelectContract(c);
                  onClose();
                }}
                className="p-4 rounded-2xl bg-zinc-950/60 hover:bg-zinc-900 border border-white/[0.05] hover:border-zinc-700 cursor-pointer transition-all flex items-center justify-between group"
              >
                <div>
                  <div className="font-bold text-xs text-white group-hover:text-emerald-400 transition-colors">{c.title}</div>
                  <div className="text-[11px] text-zinc-400 flex items-center gap-2 mt-0.5">
                    <span className="font-mono text-emerald-400">{c.contractNumber}</span>
                    <span>•</span>
                    <span className="flex items-center gap-1">
                      <Globe2 className="w-3 h-3 text-cyan-400" />
                      {c.country}
                    </span>
                    <span>•</span>
                    <span>{c.commercials.contractValue.toLocaleString()} {c.commercials.currency}</span>
                  </div>
                </div>

                <div className="flex items-center gap-2.5">
                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                    c.riskBreakdown.overallScore > 50 ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30' : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                  }`}>
                    Risk: {c.riskBreakdown.overallScore}/100
                  </span>
                  <ChevronRight className="w-4 h-4 text-zinc-600 group-hover:text-white transition-colors" />
                </div>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-xs text-zinc-500">
              No matching agreements found for &quot;{query}&quot;.
            </div>
          )}
        </div>

      </div>
    </div>
  );
};
