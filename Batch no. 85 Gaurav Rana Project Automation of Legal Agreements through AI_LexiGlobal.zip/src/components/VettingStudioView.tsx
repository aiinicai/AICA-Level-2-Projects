import React, { useState, useRef } from 'react';
import { 
  ShieldAlert, 
  Upload, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  AlertOctagon, 
  Scale, 
  FileText, 
  BookOpen, 
  Copy, 
  Check, 
  ArrowRight, 
  RefreshCw, 
  HelpCircle, 
  Sliders, 
  Globe2, 
  ChevronDown, 
  ChevronUp,
  FileUp,
  FileCheck,
  FileWarning,
  X,
  Loader2,
  FileType,
  Download,
  FileDown
} from 'lucide-react';
import { ContractItem, VettingIssue, RiskLevel } from '../types';
import { GLOBAL_JURISDICTIONS } from '../data/jurisdictions';
import { parseUploadedContractFile, ParsedDocumentResult } from '../utils/documentParser';
import { exportContractToWordDoc } from '../utils/docxExporter';

interface VettingStudioProps {
  contracts: ContractItem[];
  activeContract?: ContractItem | null;
  onUpdateContractVetting?: (contractId: string, issues: VettingIssue[], riskScore: number) => void;
}

export const VettingStudioView: React.FC<VettingStudioProps> = ({
  contracts,
  activeContract,
  onUpdateContractVetting
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedContractId, setSelectedContractId] = useState<string>(activeContract?.id || contracts[0]?.id || '');
  const [contractText, setContractText] = useState<string>(
    activeContract?.versions[activeContract.currentVersionIndex]?.content || contracts[0]?.versions[0]?.content || ''
  );
  const [country, setCountry] = useState<string>(activeContract?.country || 'United States');
  const [contractType, setContractType] = useState<string>(activeContract?.contractType || 'Master Services Agreement (MSA)');
  
  // File Upload & Parsing States
  const [isParsingFile, setIsParsingFile] = useState<boolean>(false);
  const [parseStatusText, setParseStatusText] = useState<string>('');
  const [uploadedFileInfo, setUploadedFileInfo] = useState<ParsedDocumentResult | null>(null);
  const [parseError, setParseError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [uploadToast, setUploadToast] = useState<string | null>(null);

  // "Analyze in Favour of My Company" configuration
  const [analyzeInFavorOfMyCompany, setAnalyzeInFavorOfMyCompany] = useState<boolean>(true);
  const [myCompanyRole, setMyCompanyRole] = useState<string>('Client / Buyer');
  
  // State for AI Vetting
  const [isVetting, setIsVetting] = useState<boolean>(false);
  const [appliedIssueIds, setAppliedIssueIds] = useState<Set<string>>(new Set());
  const [appliedToast, setAppliedToast] = useState<string | null>(null);
  const [overallScore, setOverallScore] = useState<number>(activeContract?.riskBreakdown.overallScore || 58);
  const [categoryScores, setCategoryScores] = useState({
    financial: activeContract?.riskBreakdown.financialRisk || 52,
    legal: activeContract?.riskBreakdown.legalRisk || 64,
    compliance: activeContract?.riskBreakdown.complianceRisk || 48,
    data: activeContract?.riskBreakdown.dataRisk || 68,
    operational: activeContract?.riskBreakdown.operationalRisk || 42
  });
  
  const [riskFilter, setRiskFilter] = useState<'all' | 'critical_high' | 'missing' | 'financial_legal'>('all');
  const [issuesList, setIssuesList] = useState<VettingIssue[]>(
    activeContract?.vettingIssues?.length ? activeContract.vettingIssues : [
      {
        id: 'vet-01',
        clauseTitle: 'Limitation of Liability Cap (3x Over-Exposure)',
        originalText: 'LIABILITY: Capped at three times (3x) the total contract value ($1,440,000 USD).',
        issue: 'Counterparty redline expands liability cap from 1x annual fees to 3x total contract value, creating uninsurable catastrophic downside.',
        riskLevel: 'critical',
        legalPrinciple: 'Under Delaware commercial law and UCC § 2-719, 1x annual fees represents market standard. 3x exposure creates unbalanced financial risk.',
        businessImpact: 'Triples maximum theoretical lawsuit damages without corresponding margin increase.',
        companyPosition: 'highly_unfavourable',
        suggestedWording: 'Except for gross negligence or breach of confidentiality, neither party\'s aggregate liability shall exceed the total fees paid in the twelve (12) months preceding the incident ($480,000 USD).',
        negotiationPriority: 'high',
        lawyerReviewRequired: true,
        legalSourceCitation: {
          statute: '6 Del. C. § 2-719',
          jurisdiction: 'Delaware / US',
          confidence: 99,
          lastVerified: '2026-08-01'
        }
      },
      {
        id: 'vet-02',
        clauseTitle: 'Data Breach Notification Window',
        originalText: 'DATA BREACH: Immediate notice within twelve (12) hours of any suspicion.',
        issue: '12-hour notification for "any suspicion" is operationally unfeasible prior to forensic triage completion.',
        riskLevel: 'high',
        legalPrinciple: 'Market standards and statutory regulations (GDPR Art. 33, state privacy statutes) specify 48 to 72 hours following confirmation of breach.',
        businessImpact: 'Severe risk of technical breach of contract on unverified security false alarms.',
        companyPosition: 'unfavourable',
        suggestedWording: 'Service Provider shall notify Customer in writing within forty-eight (48) hours of confirming a security breach impacting Customer Personal Data.',
        negotiationPriority: 'high',
        lawyerReviewRequired: true
      },
      {
        id: 'vet-03',
        clauseTitle: 'Unilateral Termination Notice',
        originalText: 'Customer may terminate on ten (10) days notice; Provider may only terminate for cause.',
        issue: 'Asymmetrical termination rights lock Service Provider into dedicated resource allocation without reciprocal exit.',
        riskLevel: 'medium',
        legalPrinciple: 'Reciprocal 30-day notice for convenience is standard in multi-jurisdiction commercial services agreements.',
        businessImpact: 'Resource planning volatility and unrecoverable pipeline reallocation costs.',
        companyPosition: 'unfavourable',
        suggestedWording: 'Either party may terminate this Agreement for convenience upon thirty (30) days prior written notice.',
        negotiationPriority: 'medium',
        lawyerReviewRequired: false
      }
    ]
  );

  const [summaryText, setSummaryText] = useState<string>(
    'The agreement exhibits elevated financial and data risks due to counterparty redlines tripling liability exposure and an aggressive 12-hour data incident notification requirement.'
  );

  const [favourableAspects, setFavourableAspects] = useState<string[]>([
    'Clear intellectual property assignment upon milestone payment receipt.',
    'Delaware choice of law with binding AAA arbitration seat in New York.',
    'Clear 10-day deemed acceptance period for submitted deliverables.'
  ]);

  // Plain-English Explanation Modal / Drawer State
  const [explainingIssueId, setExplainingIssueId] = useState<string | null>(null);
  const [plainEnglishExplanation, setPlainEnglishExplanation] = useState<any | null>(null);
  const [isExplaining, setIsExplaining] = useState<boolean>(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Centralized AI Vetting Engine Caller
  const executeVetting = async (
    textToVet: string,
    typeToVet: string,
    jurToVet: string,
    roleToVet: string,
    biasToVet: boolean
  ) => {
    if (!textToVet || !textToVet.trim()) return;
    setIsVetting(true);
    setAppliedIssueIds(new Set());
    try {
      const res = await fetch('/api/vet-contract', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contractText: textToVet,
          contractType: typeToVet,
          country: jurToVet,
          myCompanyRole: roleToVet,
          analyzeInFavorOfMyCompany: biasToVet
        })
      });
      const data = await res.json();
      if (data.success) {
        setOverallScore(data.overallRiskScore || 50);
        if (data.categoryScores) setCategoryScores(data.categoryScores);
        if (data.issues && Array.isArray(data.issues)) {
          setIssuesList(data.issues);
        }
        if (data.summary) setSummaryText(data.summary);
        if (data.favourableAspects) setFavourableAspects(data.favourableAspects);

        if (onUpdateContractVetting && selectedContractId) {
          onUpdateContractVetting(selectedContractId, data.issues, data.overallRiskScore);
        }
      }
    } catch (err) {
      console.error('Vetting failed:', err);
    } finally {
      setIsVetting(false);
    }
  };

  // File Upload Processor
  const processUploadedFile = async (file: File) => {
    if (!file) return;
    setIsParsingFile(true);
    setParseError(null);
    setUploadToast(null);

    const ext = file.name.split('.').pop()?.toLowerCase() || '';
    if (ext === 'docx' || ext === 'doc') {
      setParseStatusText(`Extracting formatted clauses from Word document (${file.name})...`);
    } else if (ext === 'pdf') {
      setParseStatusText(`Parsing text and multi-page contractual sections from PDF (${file.name})...`);
    } else {
      setParseStatusText(`Reading ${file.name}...`);
    }

    try {
      const parsed = await parseUploadedContractFile(file);
      if (!parsed.text || parsed.text.trim().length === 0) {
        throw new Error('No readable textual content could be extracted from this document.');
      }

      setContractText(parsed.text);
      setUploadedFileInfo(parsed);
      setSelectedContractId(''); // Disconnect from preset repo selection

      // Auto-detect contract type if discernible from text or filename
      let detectedType = contractType;
      const textUpper = (file.name + ' ' + parsed.text.substring(0, 1000)).toUpperCase();
      if (textUpper.includes('NON-DISCLOSURE') || textUpper.includes('CONFIDENTIALITY') || textUpper.includes('NDA')) {
        detectedType = 'Non-Disclosure Agreement (NDA)';
      } else if (textUpper.includes('MASTER SERVICES') || textUpper.includes('MSA') || textUpper.includes('SERVICES AGREEMENT')) {
        detectedType = 'Master Services Agreement (MSA)';
      } else if (textUpper.includes('DATA PROCESSING') || textUpper.includes('DPA') || textUpper.includes('GDPR')) {
        detectedType = 'Data Processing Addendum (DPA)';
      } else if (textUpper.includes('SOFTWARE LICENSE') || textUpper.includes('EULA') || textUpper.includes('SAAS')) {
        detectedType = 'Software License / SaaS Agreement';
      } else if (textUpper.includes('EMPLOYMENT') || textUpper.includes('JOB OFFER') || textUpper.includes('CONSULTING')) {
        detectedType = 'Employment / Consulting Agreement';
      }
      setContractType(detectedType);

      setUploadToast(`Successfully captured ${parsed.fileName} (${parsed.detectedType}, ${parsed.wordCount.toLocaleString()} words). Running deep AI Legal Vetting...`);
      setTimeout(() => setUploadToast(null), 7000);

      // Automatically execute vetting on the uploaded document text
      executeVetting(parsed.text, detectedType, country, myCompanyRole, analyzeInFavorOfMyCompany);
    } catch (err: any) {
      console.error('File parsing error:', err);
      setParseError(err.message || 'Failed to parse file. Please upload a valid DOCX, PDF, or text file.');
    } finally {
      setIsParsingFile(false);
      setParseStatusText('');
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Drag and Drop Event Handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files && files.length > 0) {
      processUploadedFile(files[0]);
    }
  };

  // Sample Preset Templates
  const handleLoadSamplePreset = (presetType: 'msa-high-risk' | 'nda-onesided' | 'saas-breach') => {
    setUploadedFileInfo(null);
    setSelectedContractId('');
    let presetText = '';
    let presetTypeTitle = '';
    let presetCountry = country;

    if (presetType === 'msa-high-risk') {
      presetTypeTitle = 'Master Services Agreement (MSA)';
      presetCountry = 'United States';
      presetText = `MASTER SERVICES AGREEMENT (MSA) - REVISED DRAFT

1. SERVICES & ENGAGEMENT
Provider agrees to render cloud infrastructure and artificial intelligence engineering services. Deliverables shall be deemed accepted only after forty-five (45) business days following delivery.

2. PAYMENT & COMMERCIAL TERMS
Total contract value is $480,000 USD. Fees shall be paid net sixty (60) days upon receipt of invoice. Late payments shall not accrue any interest or penalty.

3. UNLIMITED INDEMNITY & EXPANDED LIABILITY
Provider shall defend, indemnify, and hold Customer harmless against any and all claims, including third-party software IP claims, without monetary limitation. Provider's aggregate liability under this Agreement shall be capped at three times (3x) the total contract value ($1,440,000 USD).

4. DATA BREACH NOTIFICATION
Provider shall notify Customer immediately within twelve (12) hours upon any suspicion or unconfirmed allegation of unauthorized data access.

5. UNILATERAL TERMINATION
Customer may terminate this Agreement at any time without cause upon seven (7) days written notice. Provider may only terminate for material non-payment.`;
    } else if (presetType === 'nda-onesided') {
      presetTypeTitle = 'Non-Disclosure Agreement (NDA)';
      presetCountry = 'United States';
      presetText = `MUTUAL NON-DISCLOSURE AND PROPRIETARY INFORMATION AGREEMENT

1. CONFIDENTIAL INFORMATION
Confidential Information includes all technical, business, and financial data disclosed by either party, whether or not marked as proprietary.

2. NON-COMPETE & RESTRICTIVE COVENANTS
Receiving Party covenants that for a period of three (3) years following termination, it shall not engage in, develop, or solicit any business competing in the same commercial market as Disclosing Party.

3. PERPETUAL NON-DISCLOSURE
The obligations of non-disclosure shall survive indefinitely in perpetuity for all information disclosed under this Agreement.

4. INJUNCTIVE RELIEF & LIQUIDATED DAMAGES
Any breach of this Agreement shall entitle Disclosing Party to automatic liquidated damages of $250,000 USD per incident, plus mandatory attorney fees.`;
    } else {
      presetTypeTitle = 'Software License / SaaS Agreement';
      presetCountry = 'United Kingdom';
      presetText = `SOFTWARE AS A SERVICE (SaaS) SUBSCRIPTION AGREEMENT

1. SERVICE LEVEL COMMITMENT & AVAILABILITY
Provider guarantees 99.9% application uptime. In the event of downtime exceeding 0.1%, Customer shall be entitled to a 100% refund of all quarterly subscription fees.

2. INTELLECTUAL PROPERTY & DERIVATIVE WORKS
All custom configurations, scripts, prompt engineering models, and workflow designs created on the platform shall immediately vest exclusively with Customer as works made for hire.

3. DATA PROTECTION & INTERNATIONAL TRANSFERS
Provider shall comply with UK GDPR and Data Protection Act 2018. Provider shall not subcontract or use any sub-processor without sixty (60) days prior written approval from Customer.

4. GOVERNING LAW & JURISDICTION
This Agreement shall be governed by the laws of England and Wales with exclusive jurisdiction in the Courts of London.`;
    }

    setContractText(presetText);
    setContractType(presetTypeTitle);
    setCountry(presetCountry);
    executeVetting(presetText, presetTypeTitle, presetCountry, myCompanyRole, analyzeInFavorOfMyCompany);
  };

  // Handle Contract Selection from Repository
  const handleSelectContract = (id: string) => {
    setSelectedContractId(id);
    setUploadedFileInfo(null);
    const found = contracts.find(c => c.id === id);
    if (found) {
      const text = found.versions[found.currentVersionIndex]?.content || '';
      setContractText(text);
      setCountry(found.country);
      setContractType(found.contractType);
      setOverallScore(found.riskBreakdown.overallScore);
      setCategoryScores({
        financial: found.riskBreakdown.financialRisk,
        legal: found.riskBreakdown.legalRisk,
        compliance: found.riskBreakdown.complianceRisk,
        data: found.riskBreakdown.dataRisk,
        operational: found.riskBreakdown.operationalRisk
      });
      if (found.vettingIssues && found.vettingIssues.length > 0) {
        setIssuesList(found.vettingIssues);
      } else {
        executeVetting(text, found.contractType, found.country, myCompanyRole, analyzeInFavorOfMyCompany);
      }
    }
  };

  // Run AI Legal Vetting Button Trigger
  const handleRunVetting = async () => {
    await executeVetting(contractText, contractType, country, myCompanyRole, analyzeInFavorOfMyCompany);
  };

  // "Explain Like I'm Not a Lawyer" Trigger
  const handleExplainClause = async (issue: VettingIssue) => {
    setExplainingIssueId(issue.id);
    setIsExplaining(true);
    try {
      const res = await fetch('/api/explain-clause', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clauseText: issue.originalText || issue.suggestedWording,
          jurisdiction: country
        })
      });
      const data = await res.json();
      if (data.success) {
        setPlainEnglishExplanation(data);
      }
    } catch (err) {
      console.error('Explanation error:', err);
    } finally {
      setIsExplaining(false);
    }
  };

  // 1-Click Replace Clause into Editor with Smart Matching & Real-Time Remediation Tracking
  const handleApplySuggestedWording = (issue: VettingIssue) => {
    if (!issue.suggestedWording) return;
    
    let updated = contractText;
    let replaced = false;

    // 1. Direct exact match
    if (issue.originalText && !issue.originalText.startsWith('[Missing') && contractText.includes(issue.originalText)) {
      updated = contractText.replace(issue.originalText, issue.suggestedWording);
      replaced = true;
    } 
    // 2. Multi-line / trimmed match
    else if (issue.originalText && !issue.originalText.startsWith('[Missing')) {
      const cleanOriginal = issue.originalText.trim().replace(/\.\.\.$/, '');
      if (cleanOriginal.length > 15 && contractText.includes(cleanOriginal)) {
        updated = contractText.replace(cleanOriginal, issue.suggestedWording);
        replaced = true;
      }
    }

    // 3. Fallback for Missing Section or non-matched clause -> Append or integrate cleanly
    if (!replaced) {
      updated = `${contractText.trim()}\n\n${issue.suggestedWording}`;
    }

    setContractText(updated);
    
    // Mark issue as applied
    setAppliedIssueIds(prev => {
      const next = new Set(prev);
      next.add(issue.id);
      return next;
    });

    // Dynamically improve overall risk score
    setOverallScore(prev => Math.max(15, prev - (issue.riskLevel === 'critical' ? 12 : issue.riskLevel === 'high' ? 8 : 5)));

    // In-app visual toast feedback
    setAppliedToast(`✓ Successfully applied recommended negotiated wording for "${issue.clauseTitle}" into the contract draft.`);
    setTimeout(() => setAppliedToast(null), 5000);
  };

  // State for Word Export
  const [isExportingDocx, setIsExportingDocx] = useState<boolean>(false);

  // Export Contract with Accepted Changes to Microsoft Word (.docx)
  const handleDownloadWordDoc = async () => {
    if (!contractText || !contractText.trim()) return;
    setIsExportingDocx(true);
    try {
      const appliedList = issuesList.filter(i => appliedIssueIds.has(i.id));
      const cleanFileName = uploadedFileInfo?.fileName 
        ? uploadedFileInfo.fileName.replace(/\.[^/.]+$/, "") + "_Vetted_Remediated.docx"
        : `${contractType.replace(/[^a-zA-Z0-9]/g, '_')}_Vetted_Remediated.docx`;

      await exportContractToWordDoc({
        fileName: cleanFileName,
        contractTitle: contractType || 'Vetted Commercial Agreement',
        contractType,
        country,
        contractContent: contractText,
        appliedIssues: appliedList,
        allIssues: issuesList,
        overallScore
      });

      setAppliedToast(`✓ Downloaded "${cleanFileName}" with ${appliedList.length} accepted negotiated changes and full audit log!`);
      setTimeout(() => setAppliedToast(null), 6000);
    } catch (err: any) {
      console.error('Failed to export docx:', err);
      alert('Failed to generate Word document: ' + (err?.message || 'Unknown error'));
    } finally {
      setIsExportingDocx(false);
    }
  };

  const getRiskBadge = (level: RiskLevel) => {
    switch (level) {
      case 'critical':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/10 text-rose-300 border border-rose-500/30">🔴 CRITICAL RISK</span>;
      case 'high':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">🟠 HIGH RISK</span>;
      case 'medium':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-yellow-500/10 text-yellow-300 border border-yellow-500/30">🟡 MEDIUM RISK</span>;
      case 'low':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30">🟢 LOW RISK</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">🔵 INFORMATIONAL</span>;
    }
  };

  return (
    <div id="vetting-studio-view" className="space-y-6 pb-12">
      
      {/* Vetting Studio Top Header */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-emerald">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-amber-500/10 via-emerald-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-500/10 text-amber-400 border border-amber-500/20 flex items-center gap-1.5 shadow-sm">
                <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                AI Legal Risk & Vetting Engine
              </span>
              <span className="text-xs text-zinc-500 font-mono">5-Tier Risk Classification</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              AI Legal Vetting & Contract Risk Diagnostics
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Upload any agreement in DOCX, PDF, or plain text to detect one-sided terms, uninsurable liabilities, missing statutory protections, and negotiation countermeasures.
            </p>
          </div>

          {/* Quick Select Existing Contract */}
          <div className="flex items-center gap-3">
            <select
              id="vetting-contract-select"
              value={selectedContractId}
              onChange={(e) => handleSelectContract(e.target.value)}
              className="bg-zinc-900/90 border border-white/[0.08] text-xs text-zinc-200 rounded-xl px-3.5 py-2 focus:outline-none focus:border-emerald-500 shadow-inner"
            >
              <option value="">-- Load Contract from Repository --</option>
              {contracts.map(c => (
                <option key={c.id} value={c.id} className="bg-zinc-900 text-white">{c.contractNumber} • {c.title.substring(0, 35)}...</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Control Bar: Bias Toggle ("Analyze in Favour of My Company") & Run Button */}
      <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] p-4.5 rounded-2xl shadow-xl flex flex-wrap items-center justify-between gap-4">
        
        {/* Bias Controls */}
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-2 bg-zinc-900/90 px-3.5 py-2 rounded-xl border border-white/[0.08]">
            <input
              type="checkbox"
              id="analyze-in-favor-check"
              checked={analyzeInFavorOfMyCompany}
              onChange={(e) => setAnalyzeInFavorOfMyCompany(e.target.checked)}
              className="w-4 h-4 text-emerald-500 rounded accent-emerald-500 cursor-pointer"
            />
            <label htmlFor="analyze-in-favor-check" className="text-xs text-zinc-200 font-semibold cursor-pointer">
              Analyze in Favour of My Company
            </label>
          </div>

          {analyzeInFavorOfMyCompany && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-zinc-400">My Position:</span>
              <select
                value={myCompanyRole}
                onChange={(e) => setMyCompanyRole(e.target.value)}
                className="bg-zinc-900/90 border border-white/[0.08] text-zinc-200 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-emerald-500"
              >
                <option value="Client / Buyer" className="bg-zinc-900 text-white">Client / Buyer</option>
                <option value="Service Provider / Vendor" className="bg-zinc-900 text-white">Service Provider / Vendor</option>
                <option value="Employer / Principal" className="bg-zinc-900 text-white">Employer / Principal</option>
                <option value="Employee / Contractor" className="bg-zinc-900 text-white">Employee / Contractor</option>
                <option value="Licensor" className="bg-zinc-900 text-white">Licensor</option>
                <option value="Licensee" className="bg-zinc-900 text-white">Licensee</option>
              </select>
            </div>
          )}

          <div className="flex items-center gap-2 text-xs">
            <span className="text-zinc-400">Jurisdiction:</span>
            <select
              value={country}
              onChange={(e) => setCountry(e.target.value)}
              className="bg-zinc-900/90 border border-white/[0.08] text-zinc-200 rounded-xl px-3 py-1.5 text-xs focus:outline-none focus:border-emerald-500"
            >
              {GLOBAL_JURISDICTIONS.map(j => (
                <option key={j.countryCode} value={j.countryName} className="bg-zinc-900 text-white">{j.countryName}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Run Analysis Button */}
        <button
          id="run-ai-vetting-btn"
          onClick={handleRunVetting}
          disabled={isVetting || !contractText.trim()}
          className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white shadow-lg transition-all ${
            isVetting || !contractText.trim()
              ? 'bg-zinc-800 text-zinc-500 opacity-60 cursor-not-allowed border border-white/[0.05]'
              : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 shadow-emerald-600/25 hover:scale-[1.02] active:scale-95'
          }`}
        >
          {isVetting ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-emerald-300" />
              <span>Analyzing Legal Risk with Gemini AI...</span>
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-cyan-300" />
              <span>Run Deep AI Legal Vetting</span>
            </>
          )}
        </button>
      </div>

      {/* Applied Remediated Toast Banner */}
      {appliedToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/50 border border-emerald-500/40 text-emerald-200 text-xs flex items-center justify-between gap-3 shadow-lg animate-fadeIn">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-medium">{appliedToast}</span>
          </div>
          <button 
            onClick={() => setAppliedToast(null)} 
            className="text-emerald-400/70 hover:text-emerald-300 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Upload Toast Banner */}
      {uploadToast && (
        <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-200 text-xs flex items-center justify-between gap-3 shadow-lg animate-fadeIn">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="font-medium">{uploadToast}</span>
          </div>
          <button 
            onClick={() => setUploadToast(null)} 
            className="text-emerald-400/70 hover:text-emerald-300 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Parse Error Alert */}
      {parseError && (
        <div className="p-3.5 rounded-2xl bg-rose-950/40 border border-rose-500/30 text-rose-200 text-xs flex items-center justify-between gap-3 shadow-lg">
          <div className="flex items-center gap-2.5">
            <FileWarning className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{parseError}</span>
          </div>
          <button 
            onClick={() => setParseError(null)} 
            className="text-rose-400/70 hover:text-rose-300 p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Main Grid: Left Contract Text Input • Right Vetting Diagnostics & Issues */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Col (5 cols): Contract Document Text Viewer/Editor & Upload Zone */}
        <div className="lg:col-span-5 space-y-4">
          <div 
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`bg-[#121215]/80 backdrop-blur-md border rounded-3xl p-5 shadow-2xl space-y-3 transition-all ${
              isDragging 
                ? 'border-emerald-500 bg-emerald-950/20 ring-2 ring-emerald-500/30' 
                : 'border-white/[0.08]'
            }`}
          >
            {/* Top Toolbar */}
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-bold text-zinc-200">
                <FileText className="w-4 h-4 text-emerald-400" />
                <span>Agreement Document to Vet</span>
              </div>

              {/* Upload Button & Word Export Button */}
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 hover:from-emerald-500/30 hover:to-teal-500/30 text-emerald-300 border border-emerald-500/30 rounded-xl text-[11px] font-semibold cursor-pointer transition-all shadow-sm">
                  {isParsingFile ? (
                    <Loader2 className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
                  ) : (
                    <FileUp className="w-3.5 h-3.5 text-emerald-400" />
                  )}
                  <span>{isParsingFile ? 'Parsing File...' : 'Upload DOCX / PDF / TXT'}</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".docx,.doc,.pdf,.txt,.md,.rtf,.json"
                    className="hidden"
                    disabled={isParsingFile}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        processUploadedFile(file);
                      }
                    }}
                  />
                </label>

                {/* Download Word Document (.docx) */}
                <button
                  type="button"
                  id="download-word-doc-btn"
                  onClick={handleDownloadWordDoc}
                  disabled={isExportingDocx || !contractText.trim()}
                  title="Download contract as formatted Microsoft Word document with accepted changes audit log"
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-[11px] font-semibold transition-all shadow-sm ${
                    !contractText.trim()
                      ? 'bg-zinc-800 text-zinc-500 border border-white/[0.04] cursor-not-allowed opacity-50'
                      : appliedIssueIds.size > 0
                        ? 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white border border-blue-400/30 shadow-blue-600/20'
                        : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-white/[0.08]'
                  }`}
                >
                  {isExportingDocx ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-300" />
                  ) : (
                    <FileDown className="w-3.5 h-3.5 text-blue-400" />
                  )}
                  <span>
                    {isExportingDocx 
                      ? 'Exporting Word...' 
                      : appliedIssueIds.size > 0 
                        ? `Download Word (${appliedIssueIds.size} Accepted)` 
                        : 'Download Word (.docx)'}
                  </span>
                </button>
              </div>
            </div>

            {/* Active Parsing Loader */}
            {isParsingFile && (
              <div className="p-3 rounded-2xl bg-emerald-950/30 border border-emerald-500/30 flex items-center gap-3 text-xs text-emerald-300 animate-pulse">
                <Loader2 className="w-4 h-4 animate-spin text-emerald-400 shrink-0" />
                <span>{parseStatusText || 'Extracting document text and clauses...'}</span>
              </div>
            )}

            {/* Uploaded File Info Card */}
            {uploadedFileInfo && !isParsingFile && (
              <div className="p-3 rounded-2xl bg-zinc-900/90 border border-emerald-500/30 flex items-center justify-between gap-3 text-xs shadow-inner">
                <div className="flex items-center gap-2.5 overflow-hidden">
                  <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shrink-0">
                    <FileCheck className="w-4 h-4" />
                  </div>
                  <div className="truncate">
                    <div className="font-semibold text-zinc-200 truncate flex items-center gap-1.5">
                      <span>{uploadedFileInfo.fileName}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 font-mono">
                        {uploadedFileInfo.detectedType}
                      </span>
                    </div>
                    <div className="text-[11px] text-zinc-400 flex items-center gap-2 mt-0.5 font-mono">
                      <span>{uploadedFileInfo.fileSizeFormatted}</span>
                      <span>•</span>
                      <span>{uploadedFileInfo.wordCount.toLocaleString()} words</span>
                      <span>•</span>
                      <span>~{uploadedFileInfo.estimatedClauses} clauses</span>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  title="Remove uploaded file and reset"
                  onClick={() => {
                    setUploadedFileInfo(null);
                    setContractText('');
                  }}
                  className="p-1.5 rounded-lg text-zinc-400 hover:text-rose-400 hover:bg-rose-500/10 transition-colors shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            {/* Drag & Drop Visual Hint */}
            <div
              className={`border-2 border-dashed rounded-2xl p-2.5 text-center transition-all ${
                isDragging 
                  ? 'border-emerald-400 bg-emerald-500/10' 
                  : 'border-white/[0.06] hover:border-white/[0.15] bg-zinc-950/40'
              }`}
            >
              <p className="text-[11px] text-zinc-400 flex items-center justify-center gap-1.5">
                <Upload className="w-3 h-3 text-zinc-500" />
                <span>Drag & drop <strong>.docx</strong>, <strong>.pdf</strong>, or <strong>.txt</strong> here or type/paste below</span>
              </p>
            </div>

            {/* Contract Editor Textarea */}
            <textarea
              id="vetting-contract-input"
              rows={20}
              value={contractText}
              onChange={(e) => setContractText(e.target.value)}
              placeholder="Paste agreement text here, upload a Word / PDF file, or choose a sample preset below..."
              className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-4 text-xs font-mono text-zinc-300 leading-relaxed focus:outline-none focus:border-emerald-500 shadow-inner"
            />

            {/* Bottom Footer with Character Count & Quick Sample Presets */}
            <div className="space-y-2 pt-1 border-t border-white/[0.06]">
              <div className="flex items-center justify-between text-[11px] text-zinc-500 font-mono">
                <span>{contractText.length.toLocaleString()} characters ({contractText.trim() ? contractText.trim().split(/\s+/).length.toLocaleString() : 0} words)</span>
                <span>Jurisdiction: {country}</span>
              </div>

              {/* Sample Contract Presets */}
              <div className="flex flex-wrap items-center gap-1.5 pt-1">
                <span className="text-[10px] text-zinc-500 font-medium mr-1">Sample Presets:</span>
                <button
                  type="button"
                  onClick={() => handleLoadSamplePreset('msa-high-risk')}
                  className="text-[10px] px-2 py-0.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.06] hover:border-white/20 transition-colors"
                >
                  ⚡ High-Risk MSA
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadSamplePreset('nda-onesided')}
                  className="text-[10px] px-2 py-0.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.06] hover:border-white/20 transition-colors"
                >
                  ⚡ One-Sided NDA
                </button>
                <button
                  type="button"
                  onClick={() => handleLoadSamplePreset('saas-breach')}
                  className="text-[10px] px-2 py-0.5 rounded-lg bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.06] hover:border-white/20 transition-colors"
                >
                  ⚡ SaaS UK Agreement
                </button>
                {contractText.trim().length > 0 && (
                  <button
                    type="button"
                    onClick={() => {
                      setContractText('');
                      setUploadedFileInfo(null);
                    }}
                    className="text-[10px] px-2 py-0.5 rounded-lg bg-zinc-900 hover:bg-rose-950/40 text-zinc-400 hover:text-rose-300 border border-white/[0.06] hover:border-rose-500/30 transition-colors ml-auto"
                  >
                    Clear
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Right Col (7 cols): Vetting Diagnostic Dashboard & Issues List */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Executive Risk Score Overview Card */}
          <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-2xl space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/[0.06] pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-amber-400" />
                  Contract Risk Assessment Diagnostic
                </h3>
                <p className="text-xs text-zinc-400 mt-1 leading-relaxed">{summaryText}</p>
              </div>

              {/* Overall Score Badge */}
              <div className="flex items-center gap-2 bg-zinc-900/90 p-3 rounded-2xl border border-white/[0.08] shrink-0">
                <span className="text-xs text-zinc-400 font-medium">Overall Risk:</span>
                <span className={`text-sm font-bold px-2.5 py-1 rounded-xl ${
                  overallScore > 60 ? 'bg-rose-500/10 text-rose-300 border border-rose-500/30' :
                  overallScore > 35 ? 'bg-amber-500/10 text-amber-300 border border-amber-500/30' :
                  'bg-emerald-500/10 text-emerald-300 border border-emerald-500/30'
                }`}>
                  {overallScore} / 100
                </span>
              </div>
            </div>

            {/* Category Breakdown Mini-Pills */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-center text-xs">
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05]">
                <span className="text-[10px] text-zinc-400 block uppercase font-semibold">Financial</span>
                <span className="font-bold text-amber-300 mt-0.5 block">{categoryScores.financial}/100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05]">
                <span className="text-[10px] text-zinc-400 block uppercase font-semibold">Legal</span>
                <span className="font-bold text-rose-300 mt-0.5 block">{categoryScores.legal}/100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05]">
                <span className="text-[10px] text-zinc-400 block uppercase font-semibold">Compliance</span>
                <span className="font-bold text-emerald-300 mt-0.5 block">{categoryScores.compliance}/100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05]">
                <span className="text-[10px] text-zinc-400 block uppercase font-semibold">Data & Cyber</span>
                <span className="font-bold text-cyan-300 mt-0.5 block">{categoryScores.data}/100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-zinc-950/80 border border-white/[0.05] col-span-2 sm:col-span-1">
                <span className="text-[10px] text-zinc-400 block uppercase font-semibold">Operational</span>
                <span className="font-bold text-emerald-300 mt-0.5 block">{categoryScores.operational}/100</span>
              </div>
            </div>

            {/* Favourable Protections List */}
            {favourableAspects.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/20 text-xs text-emerald-200 space-y-1.5">
                <span className="font-semibold text-emerald-300 block flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Existing Protective Safeguards in Contract:
                </span>
                <ul className="list-disc list-inside text-[11px] text-emerald-300/80 space-y-1 pl-1">
                  {favourableAspects.map((f, i) => (
                    <li key={i}>{f}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          {/* Vetted Issues & Recommendations List */}
          <div className="space-y-3.5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <AlertOctagon className="w-4 h-4 text-rose-400" />
                  Identified Deficiencies & Countermeasures ({issuesList.length})
                </h3>
                {appliedIssueIds.size > 0 && (
                  <button
                    onClick={handleDownloadWordDoc}
                    disabled={isExportingDocx}
                    className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/40 transition-all shadow-sm"
                    title="Export Word document with accepted changes"
                  >
                    <FileDown className="w-3 h-3 text-blue-400" />
                    <span>Download Word ({appliedIssueIds.size} Accepted)</span>
                  </button>
                )}
              </div>

              {/* Filter Pills */}
              <div className="flex flex-wrap items-center gap-1.5 bg-zinc-950/80 p-1 rounded-xl border border-white/[0.06] text-[11px]">
                <button
                  onClick={() => setRiskFilter('all')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                    riskFilter === 'all' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  All ({issuesList.length})
                </button>
                <button
                  onClick={() => setRiskFilter('critical_high')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                    riskFilter === 'critical_high' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Critical & High ({issuesList.filter(i => i.riskLevel === 'critical' || i.riskLevel === 'high').length})
                </button>
                <button
                  onClick={() => setRiskFilter('missing')}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                    riskFilter === 'missing' ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30' : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Missing Protections ({issuesList.filter(i => i.companyPosition === 'missing_protection' || i.originalText?.startsWith('[Missing')).length})
                </button>
              </div>
            </div>

            {issuesList
              .filter(issue => {
                if (riskFilter === 'critical_high') return issue.riskLevel === 'critical' || issue.riskLevel === 'high';
                if (riskFilter === 'missing') return issue.companyPosition === 'missing_protection' || issue.originalText?.startsWith('[Missing');
                return true;
              })
              .map((issue, idx) => {
              const isApplied = appliedIssueIds.has(issue.id);
              return (
                <div
                  key={issue.id || idx}
                  className={`backdrop-blur-md rounded-3xl p-5 shadow-xl space-y-3.5 transition-all ${
                    isApplied
                      ? 'bg-emerald-950/20 border border-emerald-500/40 ring-1 ring-emerald-500/20 shadow-emerald-900/10'
                      : 'bg-[#121215]/80 border border-white/[0.08] hover:border-zinc-700'
                  }`}
                >
                  {/* Issue Header */}
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] pb-3">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-xs text-white">{issue.clauseTitle}</span>
                      {getRiskBadge(issue.riskLevel)}
                      {isApplied && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                          <Check className="w-3 h-3 text-emerald-400" />
                          Remediated
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase ${
                        issue.companyPosition === 'highly_unfavourable' ? 'bg-rose-950/40 text-rose-300 border border-rose-800/60' :
                        issue.companyPosition === 'unfavourable' ? 'bg-amber-950/40 text-amber-300 border border-amber-800/60' :
                        'bg-zinc-800 text-zinc-300 border border-zinc-700'
                      }`}>
                        {issue.companyPosition.replace(/_/g, ' ')}
                      </span>
                      {issue.lawyerReviewRequired && (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-purple-500/10 text-purple-300 border border-purple-500/20 flex items-center gap-1">
                          <Scale className="w-3 h-3 text-purple-400" />
                          Lawyer Review
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Original Clause Excerpt */}
                  <div className="p-3 rounded-2xl bg-zinc-950/90 border border-white/[0.06] text-xs text-rose-300/90 font-mono leading-relaxed">
                    <span className="text-[10px] text-zinc-500 block font-sans uppercase mb-1 font-semibold">Problematic Excerpt:</span>
                    &quot;{issue.originalText}&quot;
                  </div>

                  {/* Issue Description & Business Impact */}
                  <div className="text-xs text-zinc-300 space-y-1.5 leading-relaxed">
                    <div>
                      <strong className="text-zinc-100">Issue:</strong> {issue.issue}
                    </div>
                    <div className="text-zinc-400">
                      <strong className="text-zinc-300">Business Impact:</strong> {issue.businessImpact}
                    </div>
                    <div className="text-zinc-400">
                      <strong className="text-zinc-300">Legal Consideration:</strong> {issue.legalPrinciple}
                    </div>
                    {issue.legalSourceCitation && (
                      <div className="text-[11px] text-cyan-300/90 flex items-center gap-1.5 pt-1">
                        <Scale className="w-3.5 h-3.5 text-cyan-400" />
                        <span>Statute: <strong>{issue.legalSourceCitation.statute}</strong> ({issue.legalSourceCitation.jurisdiction}) • Confidence: {issue.legalSourceCitation.confidence}%</span>
                      </div>
                    )}
                  </div>

                  {/* Suggested Market-Standard Replacement */}
                  <div className="p-3.5 rounded-2xl bg-emerald-950/20 border border-emerald-500/20 text-xs text-emerald-200 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-300 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                        Recommended Negotiated Wording:
                      </span>
                      <button
                        onClick={() => {
                          navigator.clipboard.writeText(issue.suggestedWording);
                          setCopiedId(issue.id);
                          setTimeout(() => setCopiedId(null), 2000);
                        }}
                        className="text-[11px] text-emerald-400 hover:text-emerald-300 flex items-center gap-1 font-semibold transition-colors"
                      >
                        {copiedId === issue.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                        <span>{copiedId === issue.id ? 'Copied' : 'Copy'}</span>
                      </button>
                    </div>
                    <p className="font-mono text-[11px] text-zinc-200 bg-zinc-950/80 p-3 rounded-xl border border-emerald-900/40 leading-relaxed">
                      {issue.suggestedWording}
                    </p>
                  </div>

                  {/* Actions: Explain Plain-English & 1-Click Apply */}
                  <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-white/[0.06]">
                    <button
                      onClick={() => handleExplainClause(issue)}
                      className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.08] hover:border-zinc-700 text-xs font-semibold transition-all"
                    >
                      <HelpCircle className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Explain Like I&apos;m Not a Lawyer</span>
                    </button>

                    <button
                      onClick={() => handleApplySuggestedWording(issue)}
                      className={`flex items-center gap-1.5 px-4 py-1.5 rounded-xl text-xs font-semibold shadow-md transition-all active:scale-95 ${
                        isApplied
                          ? 'bg-emerald-700/80 hover:bg-emerald-600 text-emerald-100 border border-emerald-500/40 shadow-emerald-900/30'
                          : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-600/20'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>{isApplied ? '✓ Applied & Remediated' : 'Apply Suggested Wording'}</span>
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

        </div>

      </div>

      {/* "Explain Like I'm Not a Lawyer" Modal / Popup */}
      {explainingIssueId && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-[#121215]/95 border border-white/[0.08] rounded-3xl max-w-xl w-full p-6 shadow-2xl space-y-4 bento-glow-cyan">
            <div className="flex items-center justify-between border-b border-white/[0.08] pb-3">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-500/10 text-cyan-400 flex items-center justify-center font-bold border border-cyan-500/20">
                  💡
                </div>
                <div>
                  <h3 className="font-bold text-sm text-white">Plain-English Legal Breakdown</h3>
                  <p className="text-[11px] text-zinc-400">Zero legal jargon • Commercial clarity for executives</p>
                </div>
              </div>
              <button
                onClick={() => {
                  setExplainingIssueId(null);
                  setPlainEnglishExplanation(null);
                }}
                className="w-8 h-8 rounded-lg bg-zinc-900 border border-white/[0.08] text-zinc-400 hover:text-white flex items-center justify-center text-xs font-bold transition-all"
              >
                ✕
              </button>
            </div>

            {isExplaining ? (
              <div className="py-12 flex flex-col items-center justify-center gap-3">
                <RefreshCw className="w-6 h-6 animate-spin text-cyan-400" />
                <span className="text-xs text-zinc-400">Translating legal clause into plain English...</span>
              </div>
            ) : plainEnglishExplanation ? (
              <div className="space-y-3.5 text-xs text-zinc-300">
                <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] space-y-1">
                  <span className="text-zinc-400 text-[10px] uppercase font-bold block">What this clause actually means:</span>
                  <p className="text-zinc-200 leading-relaxed font-medium text-xs">
                    {plainEnglishExplanation.plainEnglish}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] space-y-1">
                    <span className="text-zinc-400 text-[10px] uppercase font-bold block">Who Benefits:</span>
                    <p className="text-amber-300 font-semibold">{plainEnglishExplanation.whoBenefits}</p>
                  </div>
                  <div className="p-3.5 rounded-2xl bg-zinc-950/80 border border-white/[0.06] space-y-1">
                    <span className="text-zinc-400 text-[10px] uppercase font-bold block">Recommendation:</span>
                    <p className="text-emerald-300 font-semibold">{plainEnglishExplanation.negotiationRecommendation}</p>
                  </div>
                </div>

                {plainEnglishExplanation.practicalExample && (
                  <div className="p-3.5 rounded-2xl bg-cyan-950/20 border border-cyan-500/20 text-cyan-200 space-y-1">
                    <span className="font-bold text-cyan-300 text-[10px] uppercase block">Real-World Scenario:</span>
                    <p className="text-[11px] text-zinc-300 leading-relaxed">{plainEnglishExplanation.practicalExample}</p>
                  </div>
                )}
              </div>
            ) : null}

            <div className="flex justify-end pt-3 border-t border-white/[0.08]">
              <button
                onClick={() => {
                  setExplainingIssueId(null);
                  setPlainEnglishExplanation(null);
                }}
                className="px-5 py-2 bg-zinc-900 hover:bg-zinc-800 border border-white/[0.08] text-white rounded-xl text-xs font-semibold transition-all"
              >
                Got It
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
