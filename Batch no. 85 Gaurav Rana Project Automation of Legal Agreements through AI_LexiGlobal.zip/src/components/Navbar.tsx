import React from 'react';
import { 
  Scale, 
  FileText, 
  Search, 
  ShieldAlert, 
  GitCompare, 
  BookOpen, 
  FolderArchive, 
  CheckCircle2, 
  PenTool, 
  Send, 
  Database, 
  BarChart3, 
  Users, 
  History, 
  Globe2, 
  Sparkles,
  PlusCircle
} from 'lucide-react';
import { UserRole } from '../types';
import { GLOBAL_JURISDICTIONS } from '../data/jurisdictions';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  selectedCountry: string;
  setSelectedCountry: (country: string) => void;
  onOpenNaturalSearch: () => void;
  onStartDrafting: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  userRole,
  setUserRole,
  selectedCountry,
  setSelectedCountry,
  onOpenNaturalSearch,
  onStartDrafting
}) => {
  const roleLabels: Record<UserRole, { label: string; badgeColor: string }> = {
    admin: { label: 'Administrator', badgeColor: 'bg-purple-900/50 text-purple-200 border-purple-700' },
    legal: { label: 'General Counsel / Legal', badgeColor: 'bg-blue-900/50 text-blue-200 border-blue-700' },
    finance: { label: 'CFO / Finance Team', badgeColor: 'bg-emerald-900/50 text-emerald-200 border-emerald-700' },
    procurement: { label: 'Procurement Officer', badgeColor: 'bg-amber-900/50 text-amber-200 border-amber-700' },
    hr: { label: 'HR & People Ops', badgeColor: 'bg-rose-900/50 text-rose-200 border-rose-700' },
    business: { label: 'Business Project Lead', badgeColor: 'bg-cyan-900/50 text-cyan-200 border-cyan-700' },
    management: { label: 'Executive Management', badgeColor: 'bg-indigo-900/50 text-indigo-200 border-indigo-700' },
    external_signer: { label: 'External Signatory', badgeColor: 'bg-slate-800 text-slate-300 border-slate-700' }
  };

  const navItems = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: BarChart3 },
    { id: 'drafting', label: 'Drafting Wizard', icon: FileText },
    { id: 'vetting', label: 'AI Legal Vetting', icon: ShieldAlert },
    { id: 'redline', label: '3-Way Redline & Diff', icon: GitCompare },
    { id: 'clauses', label: 'Clause Intelligence', icon: BookOpen },
    { id: 'repository', label: 'Contract Repository', icon: FolderArchive },
    { id: 'approvals', label: 'Approval Workflows', icon: CheckCircle2 },
    { id: 'esignature', label: 'Digital E-Signature', icon: PenTool },
    { id: 'distribution', label: 'Email Distribution', icon: Send },
    { id: 'knowledge', label: 'Legal Knowledge Base', icon: Database },
    { id: 'audit', label: 'Audit Trail', icon: History }
  ];

  return (
    <header id="main-navigation-header" className="bg-[#0c0c0e]/80 backdrop-blur-xl border-b border-white/[0.08] sticky top-0 z-40 shadow-2xl">
      {/* Top Branding & Control Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 via-cyan-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-emerald-500/20 text-white font-bold ring-1 ring-white/20">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-tight text-white font-sans">
                  LEXI<span className="text-emerald-400">GLOBAL</span>
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-cyan-300" />
                  AI CLM
                </span>
              </div>
              <p className="text-[11px] text-zinc-400 font-medium">Global Agreement Drafting, Vetting, Redline & E-Sign</p>
            </div>
          </div>

          {/* Center Search & Quick Actions */}
          <div className="hidden md:flex items-center gap-3 flex-1 max-w-lg">
            <button
              id="global-natural-search-btn"
              onClick={onOpenNaturalSearch}
              className="w-full flex items-center justify-between px-3.5 py-2 rounded-xl bg-zinc-900/90 border border-white/[0.08] text-zinc-400 text-xs hover:border-zinc-700 hover:text-zinc-200 transition-all shadow-inner group"
            >
              <div className="flex items-center gap-2">
                <Search className="w-4 h-4 text-zinc-500 group-hover:text-emerald-400 transition-colors" />
                <span>Search contracts, clauses, parties, statutes (e.g. &quot;expiring in 90 days&quot;)...</span>
              </div>
              <kbd className="px-1.5 py-0.5 text-[10px] bg-zinc-800 border border-zinc-700 rounded-md text-zinc-400 font-mono">⌘K</kbd>
            </button>
          </div>

          {/* Right Controls: Jurisdiction & Role Switcher */}
          <div className="flex items-center gap-3">
            {/* Global Jurisdiction Selector */}
            <div className="flex items-center gap-1.5 bg-zinc-900/90 px-3 py-1.5 rounded-xl border border-white/[0.08]">
              <Globe2 className="w-4 h-4 text-cyan-400 shrink-0" />
              <select
                id="global-jurisdiction-select"
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-none cursor-pointer"
                title="Filter by Country Jurisdiction"
              >
                <option value="ALL" className="bg-zinc-900 text-white">Global (All Countries)</option>
                {GLOBAL_JURISDICTIONS.map((j) => (
                  <option key={j.countryCode} value={j.countryName} className="bg-zinc-900 text-white">
                    {j.countryName} ({j.currency})
                  </option>
                ))}
              </select>
            </div>

            {/* Role Switcher */}
            <div className="flex items-center gap-1.5 bg-zinc-900/90 px-3 py-1.5 rounded-xl border border-white/[0.08]">
              <Users className="w-4 h-4 text-indigo-400 shrink-0" />
              <select
                id="user-role-select"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as UserRole)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-none cursor-pointer"
                title="Switch User Role & Access Perspective"
              >
                <option value="legal" className="bg-zinc-900 text-white">Role: Legal Counsel</option>
                <option value="admin" className="bg-zinc-900 text-white">Role: Administrator</option>
                <option value="finance" className="bg-zinc-900 text-white">Role: Finance / CFO</option>
                <option value="procurement" className="bg-zinc-900 text-white">Role: Procurement</option>
                <option value="hr" className="bg-zinc-900 text-white">Role: HR & Talent</option>
                <option value="business" className="bg-zinc-900 text-white">Role: Business Lead</option>
                <option value="management" className="bg-zinc-900 text-white">Role: Management / Exec</option>
                <option value="external_signer" className="bg-zinc-900 text-white">Role: External Signatory</option>
              </select>
            </div>

            {/* Quick Action Button */}
            <button
              id="nav-new-contract-btn"
              onClick={onStartDrafting}
              className="hidden lg:flex items-center gap-1.5 px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-semibold shadow-lg shadow-emerald-500/20 transition-all active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>Draft Contract</span>
            </button>
          </div>
        </div>

        {/* Bottom Horizontal Nav Tabs */}
        <div className="flex items-center space-x-1.5 overflow-x-auto py-2.5 no-scrollbar border-t border-white/[0.06]">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-zinc-800 text-white border border-white/10 shadow-sm ring-1 ring-emerald-500/30'
                    : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-zinc-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
