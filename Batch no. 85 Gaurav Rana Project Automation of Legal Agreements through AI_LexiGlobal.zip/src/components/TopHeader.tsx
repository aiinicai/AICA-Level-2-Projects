import React from 'react';
import { 
  Search, 
  Globe2, 
  Users, 
  BarChart3, 
  FileText, 
  ShieldAlert, 
  GitCompare, 
  BookOpen, 
  FolderArchive, 
  CheckCircle2, 
  PenTool, 
  Send, 
  Database, 
  History,
  PanelLeftClose,
  PanelLeftOpen
} from 'lucide-react';
import { UserRole } from '../types';
import { GLOBAL_JURISDICTIONS } from '../data/jurisdictions';
import { ThemeSwitcher } from './ThemeSwitcher';

interface TopHeaderProps {
  activeTab: string;
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  selectedCountry: string;
  setSelectedCountry: (country: string) => void;
  onOpenNaturalSearch: () => void;
  isSidebarCollapsed: boolean;
  onToggleSidebarCollapse: () => void;
  onStartDrafting: () => void;
  isDbConnected?: boolean;
}

export const TopHeader: React.FC<TopHeaderProps> = ({
  activeTab,
  userRole,
  setUserRole,
  selectedCountry,
  setSelectedCountry,
  onOpenNaturalSearch,
  isSidebarCollapsed,
  onToggleSidebarCollapse,
  isDbConnected = true
}) => {
  const tabMetadata: Record<string, { label: string; icon: React.ElementType }> = {
    dashboard: { label: 'Executive Dashboard', icon: BarChart3 },
    drafting: { label: 'Drafting Wizard', icon: FileText },
    vetting: { label: 'AI Legal Vetting', icon: ShieldAlert },
    redline: { label: '3-Way Redline & Diff', icon: GitCompare },
    clauses: { label: 'Clause Intelligence', icon: BookOpen },
    repository: { label: 'Contract Repository', icon: FolderArchive },
    approvals: { label: 'Approval Workflows', icon: CheckCircle2 },
    esignature: { label: 'Digital E-Signature', icon: PenTool },
    distribution: { label: 'Email Distribution', icon: Send },
    knowledge: { label: 'Legal Knowledge Base', icon: Database },
    audit: { label: 'Audit Trail', icon: History }
  };

  const currentTab = tabMetadata[activeTab] || { label: 'Contract Management', icon: FileText };
  const CurrentIcon = currentTab.icon;

  return (
    <header id="top-control-header" className="bg-[#0c0c0e]/80 backdrop-blur-xl border-b border-white/[0.08] sticky top-0 z-20 shadow-md shrink-0">
      <div className="px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 gap-4">
          
          {/* Left: Sidebar Collapse/Expand Toggle & Active View Title */}
          <div className="flex items-center gap-3 min-w-0">
            {/* Toggle Freeze / Collapse Button */}
            <button
              id="header-sidebar-toggle-btn"
              onClick={onToggleSidebarCollapse}
              className="p-2 rounded-xl bg-zinc-900/90 border border-white/[0.08] text-zinc-400 hover:text-white hover:bg-zinc-800 transition-all shrink-0"
              title={isSidebarCollapsed ? "Expand frozen sidebar" : "Collapse frozen sidebar"}
              aria-label={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            >
              {isSidebarCollapsed ? (
                <PanelLeftOpen className="w-4 h-4 text-emerald-400" />
              ) : (
                <PanelLeftClose className="w-4 h-4 text-zinc-400" />
              )}
            </button>

            {/* Breadcrumb / Active Module Indicator */}
            <div className="flex items-center gap-2 text-xs truncate">
              <span className="text-zinc-500 font-mono hidden sm:inline">Platform</span>
              <span className="text-zinc-600 hidden sm:inline">/</span>
              <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-zinc-900/80 border border-white/[0.06] text-zinc-200 font-medium">
                <CurrentIcon className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">{currentTab.label}</span>
              </div>
            </div>
          </div>

          {/* Center: Global Natural Language Search */}
          <div className="hidden md:flex items-center gap-3 flex-1 max-w-md mx-2">
            <button
              id="global-natural-search-btn"
              onClick={onOpenNaturalSearch}
              className="w-full flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-zinc-900/90 border border-white/[0.08] text-zinc-400 text-xs hover:border-zinc-700 hover:text-zinc-200 transition-all shadow-inner group"
            >
              <div className="flex items-center gap-2 truncate">
                <Search className="w-4 h-4 text-zinc-500 group-hover:text-emerald-400 transition-colors shrink-0" />
                <span className="truncate">Search contracts, clauses, parties (e.g. &quot;expiring in 90 days&quot;)...</span>
              </div>
              <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] bg-zinc-800 border border-zinc-700 rounded-md text-zinc-400 font-mono shrink-0 ml-2">⌘K</kbd>
            </button>
          </div>

          {/* Right Controls: Database status, Country, Role & Search for mobile */}
          <div className="flex items-center gap-2 shrink-0">
            {/* Cloud Firestore Database Indicator */}
            <div
              id="cloud-database-status"
              className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border text-xs font-medium transition-all ${
                isDbConnected
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-400'
                  : 'bg-amber-950/40 border-amber-500/30 text-amber-400'
              }`}
              title={isDbConnected ? 'Firebase Firestore Cloud Database Connected & Synchronized' : 'Connecting to Cloud Database...'}
            >
              <span className="relative flex h-2 w-2">
                {isDbConnected && (
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                )}
                <span className={`relative inline-flex rounded-full h-2 w-2 ${isDbConnected ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
              </span>
              <Database className="w-3.5 h-3.5" />
              <span className="hidden lg:inline text-[11px] font-mono">
                {isDbConnected ? 'Firestore Active' : 'Connecting DB'}
              </span>
            </div>

            {/* Mobile Search Icon */}
            <button
              onClick={onOpenNaturalSearch}
              className="md:hidden p-1.5 rounded-xl bg-zinc-900/90 border border-white/[0.08] text-zinc-400 hover:text-white"
              aria-label="Search"
              title="Search contracts"
            >
              <Search className="w-4 h-4" />
            </button>

            {/* Global Jurisdiction Selector */}
            <div className="flex items-center gap-1.5 bg-zinc-900/90 px-2.5 py-1.5 rounded-xl border border-white/[0.08]">
              <Globe2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <select
                id="global-jurisdiction-select"
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-none cursor-pointer max-w-[110px] sm:max-w-none"
                title="Filter by Country Jurisdiction"
              >
                <option value="ALL" className="bg-zinc-900 text-white">Global (All)</option>
                {GLOBAL_JURISDICTIONS.map((j) => (
                  <option key={j.countryCode} value={j.countryName} className="bg-zinc-900 text-white">
                    {j.countryName} ({j.currency})
                  </option>
                ))}
              </select>
            </div>

            {/* Role Switcher */}
            <div className="flex items-center gap-1.5 bg-zinc-900/90 px-2.5 sm:px-3 py-1.5 rounded-xl border border-white/[0.08]">
              <Users className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
              <select
                id="user-role-select"
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as UserRole)}
                className="bg-transparent text-xs text-zinc-200 font-medium focus:outline-none cursor-pointer max-w-[90px] sm:max-w-none"
                title="Switch User Role & Access Perspective"
              >
                <option value="legal" className="bg-zinc-900 text-white">Legal Counsel</option>
                <option value="admin" className="bg-zinc-900 text-white">Administrator</option>
                <option value="finance" className="bg-zinc-900 text-white">Finance / CFO</option>
                <option value="procurement" className="bg-zinc-900 text-white">Procurement</option>
                <option value="hr" className="bg-zinc-900 text-white">HR & Talent</option>
                <option value="business" className="bg-zinc-900 text-white">Business Lead</option>
                <option value="management" className="bg-zinc-900 text-white">Management</option>
                <option value="external_signer" className="bg-zinc-900 text-white">External Signer</option>
              </select>
            </div>

            {/* Visual Appearance & Theme Switcher */}
            <div className="flex items-center">
              <ThemeSwitcher />
            </div>
          </div>

        </div>
      </div>
    </header>
  );
};
