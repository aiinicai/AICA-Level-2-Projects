import React, { useState, useMemo } from 'react';
import { 
  GitCompare, 
  Sparkles, 
  Check, 
  X, 
  RefreshCw, 
  FileText, 
  FileUp,
  Loader2,
  CheckCircle2,
  Wand2,
  Copy,
  Download,
  Maximize2
} from 'lucide-react';
import { ContractItem } from '../types';
import { computeWordDiff, computeLineDiff, DiffSegment } from '../utils/diffHelper';
import { parseUploadedContractFile } from '../utils/documentParser';
import { normalizeContractText, areTextsSubstantivelyEqual } from '../utils/textNormalizer';

interface RedlineComparisonProps {
  contracts: ContractItem[];
}

export const RedlineComparisonView: React.FC<RedlineComparisonProps> = ({ contracts }) => {
  const [selectedContractId, setSelectedContractId] = useState<string>(contracts[0]?.id || '');
  const [activeInputTab, setActiveInputTab] = useState<'versionA' | 'versionB'>('versionA');
  const [uploadingA, setUploadingA] = useState<boolean>(false);
  const [uploadingB, setUploadingB] = useState<boolean>(false);
  const [normalizeWhitespace, setNormalizeWhitespace] = useState<boolean>(true);
  const [docAName, setDocAName] = useState<string>('Standard Base (v1.0)');
  const [docBName, setDocBName] = useState<string>('Counterparty Redline (v1.1)');
  const [copiedDiff, setCopiedDiff] = useState<boolean>(false);

  // Upload handlers
  const handleUploadA = async (file: File) => {
    if (!file) return;
    setUploadingA(true);
    setDocAName(file.name);
    try {
      const parsed = await parseUploadedContractFile(file);
      if (parsed.text) {
        setVersionA(parsed.text);
      }
    } catch (err) {
      console.error('Failed to parse document A:', err);
    } finally {
      setUploadingA(false);
    }
  };

  const handleUploadB = async (file: File) => {
    if (!file) return;
    setUploadingB(true);
    setDocBName(file.name);
    try {
      const parsed = await parseUploadedContractFile(file);
      if (parsed.text) {
        setVersionB(parsed.text);
      }
    } catch (err) {
      console.error('Failed to parse document B:', err);
    } finally {
      setUploadingB(false);
    }
  };
  
  // Sample Versions for default comparison
  const [versionA, setVersionA] = useState<string>(`1. SERVICES & MILESTONES
Apex Enterprise Technologies Inc. ("Provider") shall deliver enterprise cloud architecture and AI infrastructure within 6 months. Deliverables shall be deemed accepted within 10 business days unless written notice of deficiency is provided.

2. PAYMENT & COMMERCIAL TERMS
Total contract consideration is $350,000 USD payable on monthly milestone verification. Payment terms are Net 30 days from invoice date. Late payments incur 1.5% interest per month.

3. LIMITATION OF LIABILITY
Neither party's aggregate liability under this Agreement shall exceed 100% of the total fees paid in the twelve (12) months preceding the claim ($350,000 USD). Consequential damages are excluded.

4. DATA BREACH NOTIFICATION
Provider shall notify Customer in writing within forty-eight (48) hours of confirming a security breach impacting Customer Personal Data.`);

  const [versionB, setVersionB] = useState<string>(`1. SERVICES & MILESTONES
Apex Enterprise Technologies Inc. ("Provider") shall deliver enterprise cloud architecture and AI infrastructure within 6 months. Deliverables shall be deemed accepted only upon formal written sign-off from Customer Chief Information Officer within 30 days.

2. PAYMENT & COMMERCIAL TERMS
Total contract consideration is $350,000 USD payable on milestone completion. Payment terms are Net 60 days from invoice date. Late interest is capped at 0.5% per annum.

3. LIMITATION OF LIABILITY
Provider's aggregate liability under this Agreement shall be capped at three times (3x) the total contract value ($1,050,000 USD), and shall not apply to data security incidents. Consequential damages waiver shall not apply to Provider.

4. DATA BREACH NOTIFICATION
Provider shall notify Customer in writing within twelve (12) hours of any suspected security vulnerability or breach.`);

  const [isComparing, setIsComparing] = useState<boolean>(false);
  const [diffMode, setDiffMode] = useState<'word' | 'line'>('word');
  const [overallRiskDelta, setOverallRiskDelta] = useState<number>(45);
  
  // Executive Summary State
  const [overallSummary, setOverallSummary] = useState<string>(
    'Version B shifts substantial operational risk and financial exposure to Provider by expanding the liability cap to 3x ($1.05M USD), carving out data incidents from liability protection, and compressing data breach notification to 12 hours.'
  );

  // Compute Active Diff Segments
  const diffSegments: DiffSegment[] = useMemo(() => {
    return diffMode === 'word' 
      ? computeWordDiff(versionA, versionB, { normalizeWhitespace })
      : computeLineDiff(versionA, versionB, { normalizeWhitespace });
  }, [versionA, versionB, diffMode, normalizeWhitespace]);

  // Compute Diff Word Statistics
  const diffStats = useMemo(() => {
    let addedWords = 0;
    let removedWords = 0;
    let additionsCount = 0;
    let deletionsCount = 0;

    diffSegments.forEach(seg => {
      const words = seg.value.trim().split(/\s+/).filter(Boolean).length;
      if (seg.added) {
        addedWords += words;
        additionsCount++;
      } else if (seg.removed) {
        removedWords += words;
        deletionsCount++;
      }
    });

    return { addedWords, removedWords, additionsCount, deletionsCount };
  }, [diffSegments]);

  const areDocumentsIdentical = useMemo(() => {
    return areTextsSubstantivelyEqual(versionA, versionB);
  }, [versionA, versionB]);

  // Trigger AI Comparison
  const handleRunAiComparison = async () => {
    setIsComparing(true);
    try {
      // Check local equality first
      if (areDocumentsIdentical) {
        setOverallSummary("Both documents were compared clause-by-clause. No substantive wording or legal risk differences were detected between Version A and Version B. All obligations and covenants are identical.");
        setOverallRiskDelta(0);
        setIsComparing(false);
        return;
      }

      const res = await fetch('/api/compare-contracts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          versionA,
          versionB,
          previousContractText: versionA,
          revisedContractText: versionB,
          contractType: 'Master Services Agreement',
          country: 'United States'
        })
      });
      const data = await res.json();
      if (data.success) {
        if (data.executiveSummary || data.overallSummary) {
          setOverallSummary(data.executiveSummary || data.overallSummary);
        }
        if (typeof data.overallRiskDelta === 'number') {
          setOverallRiskDelta(data.overallRiskDelta);
        }
      }
    } catch (err) {
      console.error('Redline comparison error:', err);
    } finally {
      setIsComparing(false);
    }
  };

  // Format Normalization Handler
  const handleNormalizeBothVersions = () => {
    setVersionA(normalizeContractText(versionA));
    setVersionB(normalizeContractText(versionB));
  };

  // Copy Diff Text
  const handleCopyDiff = () => {
    const diffText = diffSegments.map(seg => {
      if (seg.added) return `[+ ${seg.value} +]`;
      if (seg.removed) return `[- ${seg.value} -]`;
      return seg.value;
    }).join('');
    navigator.clipboard.writeText(diffText);
    setCopiedDiff(true);
    setTimeout(() => setCopiedDiff(false), 2000);
  };

  return (
    <div id="redline-comparison-view" className="space-y-6 pb-12">
      
      {/* Top Header Banner */}
      <div className="relative overflow-hidden bg-[#121215]/90 backdrop-blur-xl border border-white/[0.08] p-7 rounded-3xl shadow-2xl bento-glow-cyan">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-cyan-500/10 via-emerald-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 flex items-center gap-1.5 shadow-sm">
                <GitCompare className="w-3.5 h-3.5 text-cyan-400" />
                Redline Engine
              </span>
              <span className="text-xs text-zinc-500 font-mono">Precision Diff & Cross-Format Normalization</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Redline & Document Comparison
            </h1>
            <p className="text-sm text-zinc-400 mt-1 max-w-2xl leading-relaxed">
              Compare PDF, Word (.docx), and text contract versions with smart normalization to eliminate false positive formatting artifacts and highlight exact wording changes.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Normalization Pill */}
            <button
              onClick={() => setNormalizeWhitespace(!normalizeWhitespace)}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-medium border transition-all ${
                normalizeWhitespace 
                  ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30 shadow-sm' 
                  : 'bg-zinc-900 text-zinc-400 border-white/[0.08] hover:text-white'
              }`}
              title="Ignore PDF line breaks, soft hyphens, and whitespace differences"
            >
              <Wand2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Smart PDF/Word Normalization {normalizeWhitespace ? 'ON' : 'OFF'}</span>
            </button>

            <div className="flex items-center bg-zinc-950/90 p-1 rounded-2xl border border-white/[0.08] text-xs">
              <button
                onClick={() => setDiffMode('word')}
                className={`px-3.5 py-1.5 rounded-xl font-medium transition-all ${
                  diffMode === 'word' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Word Diff
              </button>
              <button
                onClick={() => setDiffMode('line')}
                className={`px-3.5 py-1.5 rounded-xl font-medium transition-all ${
                  diffMode === 'line' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-sm' : 'text-zinc-400 hover:text-white'
                }`}
              >
                Line Diff
              </button>
            </div>

            <button
              id="run-ai-comparison-btn"
              onClick={handleRunAiComparison}
              disabled={isComparing}
              className="flex items-center gap-2 px-5 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs font-bold shadow-lg shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-95"
            >
              {isComparing ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin text-emerald-200" />
                  <span>Comparing...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-cyan-200" />
                  <span>Run AI Comparison</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Comparison Summary Banner */}
      <div className={`border p-5 rounded-3xl shadow-xl flex items-start gap-4 transition-all ${
        areDocumentsIdentical
          ? 'bg-emerald-950/20 border-emerald-500/30'
          : 'bg-[#121215]/80 backdrop-blur-md border-white/[0.08]'
      }`}>
        <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 font-bold border shadow-inner ${
          areDocumentsIdentical
            ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
            : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
        }`}>
          {areDocumentsIdentical ? <CheckCircle2 className="w-5 h-5" /> : '⚡'}
        </div>
        <div className="space-y-1.5 w-full">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">Executive Redline Summary</h3>
              {areDocumentsIdentical ? (
                <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 text-[10px] font-bold border border-emerald-500/30 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  Exact Wording Match (0 Differences)
                </span>
              ) : (
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold border ${
                  overallRiskDelta > 0 
                    ? 'bg-rose-500/10 text-rose-300 border-rose-500/30' 
                    : overallRiskDelta < 0
                    ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                    : 'bg-zinc-800 text-zinc-300 border-zinc-700'
                }`}>
                  Net Risk Delta: {overallRiskDelta > 0 ? `+${overallRiskDelta}` : overallRiskDelta} Points
                </span>
              )}
            </div>

            {/* Document Sources Indicator */}
            <div className="flex items-center gap-2 text-[11px] text-zinc-400 font-mono">
              <span className="text-emerald-400 font-semibold">A: {docAName}</span>
              <span>vs</span>
              <span className="text-cyan-400 font-semibold">B: {docBName}</span>
            </div>
          </div>
          <p className="text-xs text-zinc-300 leading-relaxed">{overallSummary}</p>
        </div>
      </div>

      {/* Expanded 2-Column Side-by-Side: Col 1 (Source Documents) • Col 2 (Expanded Visual Redline Difference Screen) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* PANEL 1: Version A & B Source Documents (Tab Switcher + Upload + Edit) */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between border-b border-white/[0.06] pb-3 gap-2">
              <div className="flex items-center gap-1.5 bg-zinc-950/80 p-1 rounded-2xl border border-white/[0.06] text-xs">
                <button
                  type="button"
                  onClick={() => setActiveInputTab('versionA')}
                  className={`px-3.5 py-1.5 rounded-xl font-medium transition-all ${
                    activeInputTab === 'versionA' 
                      ? 'bg-zinc-800 text-emerald-300 font-semibold shadow-sm' 
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Version A (Base)
                </button>
                <button
                  type="button"
                  onClick={() => setActiveInputTab('versionB')}
                  className={`px-3.5 py-1.5 rounded-xl font-medium transition-all ${
                    activeInputTab === 'versionB' 
                      ? 'bg-zinc-800 text-cyan-300 font-semibold shadow-sm' 
                      : 'text-zinc-400 hover:text-zinc-200'
                  }`}
                >
                  Version B (Revised)
                </button>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleNormalizeBothVersions}
                  className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.08] rounded-xl text-xs font-medium transition-all flex items-center gap-1.5"
                  title="Normalize smart quotes, PDF line wraps, and whitespace"
                >
                  <Wand2 className="w-3.5 h-3.5 text-zinc-400" />
                  <span>Clean Text</span>
                </button>

                <label className="flex items-center gap-1.5 px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.08] rounded-xl text-xs font-medium cursor-pointer transition-all shadow-sm">
                  {activeInputTab === 'versionA' ? (
                    uploadingA ? <Loader2 className="w-3.5 h-3.5 text-emerald-400 animate-spin" /> : <FileUp className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    uploadingB ? <Loader2 className="w-3.5 h-3.5 text-cyan-400 animate-spin" /> : <FileUp className="w-3.5 h-3.5 text-cyan-400" />
                  )}
                  <span>{activeInputTab === 'versionA' ? (uploadingA ? 'Parsing...' : 'Upload Base (A)') : (uploadingB ? 'Parsing...' : 'Upload Revised (B)')}</span>
                  <input
                    type="file"
                    accept=".docx,.doc,.pdf,.txt,.md,.rtf"
                    className="hidden"
                    disabled={uploadingA || uploadingB}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        if (activeInputTab === 'versionA') {
                          handleUploadA(file);
                        } else {
                          handleUploadB(file);
                        }
                      }
                      e.target.value = '';
                    }}
                  />
                </label>
              </div>
            </div>

            {activeInputTab === 'versionA' ? (
              <textarea
                rows={22}
                value={versionA}
                onChange={(e) => setVersionA(e.target.value)}
                placeholder="Paste or upload Base Contract Version A (PDF / Word / TXT)..."
                className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-4 text-xs font-mono text-zinc-300 leading-relaxed focus:outline-none focus:border-emerald-500 shadow-inner resize-y min-h-[520px]"
              />
            ) : (
              <textarea
                rows={22}
                value={versionB}
                onChange={(e) => setVersionB(e.target.value)}
                placeholder="Paste or upload Counterparty Revised Version B (PDF / Word / TXT)..."
                className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-4 text-xs font-mono text-zinc-300 leading-relaxed focus:outline-none focus:border-cyan-500 shadow-inner resize-y min-h-[520px]"
              />
            )}
          </div>

          <div className="flex items-center justify-between text-xs text-zinc-500 font-mono pt-3 border-t border-white/[0.04]">
            <span>{activeInputTab === 'versionA' ? `${versionA.length.toLocaleString()} characters (Version A: ${docAName})` : `${versionB.length.toLocaleString()} characters (Version B: ${docBName})`}</span>
            <span>Switch tabs above to edit or upload either document</span>
          </div>
        </div>

        {/* PANEL 2: EXPANDED Difference Screen (Visual Redline Markup) */}
        <div className="bg-[#121215]/80 backdrop-blur-md border border-white/[0.08] rounded-3xl p-6 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between border-b border-white/[0.06] pb-3 gap-2">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <GitCompare className="w-4 h-4" />
                </div>
                <div>
                  <h2 className="text-sm font-bold text-white flex items-center gap-2">
                    Visual Redline & Difference View
                  </h2>
                  <p className="text-[11px] text-zinc-400">Expanded clause-by-clause markup</p>
                </div>
              </div>

              {/* Difference Stats & Actions */}
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 bg-zinc-950/80 px-3 py-1.5 rounded-xl border border-white/[0.06] text-xs">
                  <span className="flex items-center gap-1.5 text-emerald-400 font-semibold">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block shadow-sm" />
                    +{diffStats.addedWords} Words ({diffStats.additionsCount})
                  </span>
                  <span className="text-zinc-600">|</span>
                  <span className="flex items-center gap-1.5 text-rose-400 font-semibold">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block shadow-sm" />
                    -{diffStats.removedWords} Words ({diffStats.deletionsCount})
                  </span>
                </div>

                <button
                  onClick={handleCopyDiff}
                  className="px-3 py-1.5 bg-zinc-900 hover:bg-zinc-800 text-zinc-300 border border-white/[0.08] rounded-xl text-xs font-medium transition-all flex items-center gap-1.5"
                  title="Copy formatted redline markup text to clipboard"
                >
                  {copiedDiff ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-zinc-400" />}
                  <span>{copiedDiff ? 'Copied' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Rendered Live Diff Output - Expanded */}
            <div className="w-full bg-zinc-950/90 border border-white/[0.08] rounded-2xl p-5 text-xs font-mono text-zinc-300 leading-relaxed overflow-y-auto min-h-[520px] max-h-[620px] whitespace-pre-wrap shadow-inner selection:bg-cyan-500/30">
              {areDocumentsIdentical ? (
                <div className="flex flex-col items-center justify-center py-24 text-center space-y-3">
                  <div className="w-14 h-14 rounded-3xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20 shadow-inner">
                    <CheckCircle2 className="w-7 h-7" />
                  </div>
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-emerald-300">Exact Wording Match</p>
                    <p className="text-xs text-zinc-400 max-w-sm leading-relaxed">
                      Version A and Version B have identical wording across all clauses. Formatting, PDF line-wrapping, and soft hyphens have been normalized.
                    </p>
                  </div>
                  <span className="text-[11px] text-zinc-500 bg-zinc-900/80 px-3 py-1 rounded-full border border-white/[0.06]">
                    0 Additions • 0 Deletions
                  </span>
                </div>
              ) : (
                diffSegments.map((segment, i) => {
                  if (segment.added) {
                    return (
                      <span
                        key={i}
                        className="bg-emerald-950/90 text-emerald-300 font-medium px-1.5 py-0.5 rounded border border-emerald-500/40 shadow-sm inline-block my-0.5"
                      >
                        {segment.value}
                      </span>
                    );
                  }
                  if (segment.removed) {
                    return (
                      <span
                        key={i}
                        className="bg-rose-950/90 text-rose-400 line-through px-1.5 py-0.5 rounded border border-rose-500/40 opacity-80 inline-block my-0.5"
                      >
                        {segment.value}
                      </span>
                    );
                  }
                  return <span key={i}>{segment.value}</span>;
                })
              )}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-zinc-500 font-mono pt-3 border-t border-white/[0.04]">
            <span>Mode: {diffMode === 'word' ? 'Word-level Comparison' : 'Line-by-line Comparison'}</span>
            <span>{areDocumentsIdentical ? 'Identical documents' : `${diffStats.additionsCount + diffStats.deletionsCount} redline modifications detected`}</span>
          </div>
        </div>

      </div>

    </div>
  );
};
