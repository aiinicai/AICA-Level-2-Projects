import { GoogleGenAI } from "@google/genai";
import { TEMPLATE_DETAILED_CLAUSES } from "../src/data/detailedStandardClauses.js";
import { CONTRACT_TEMPLATES } from "../src/data/contractTemplates.js";
import { DetailedClause } from "../src/types/index.js";

let aiClient: GoogleGenAI | null = null;

function getAi(): GoogleGenAI | null {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey) {
      aiClient = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });
    }
  }
  return aiClient;
}

export interface DraftContractRequest {
  templateId?: string;
  contractType: string;
  country: string;
  stateOrRegion?: string;
  governingLaw: string;
  disputeForum: string;
  primaryParty: any;
  counterparty: any;
  commercials: any;
  riskLiability: any;
  scopeOfServices: string;
  specialTerms?: string;
  detailedClauses?: DetailedClause[];
}

export interface VetContractRequest {
  contractText: string;
  contractType: string;
  country: string;
  myCompanyRole: string; // 'buyer', 'seller', 'employer', 'client', 'vendor'
  analyzeInFavorOfMyCompany: boolean;
}

export interface CompareContractsRequest {
  previousContractText?: string;
  revisedContractText?: string;
  versionA?: string;
  versionB?: string;
  version1?: string;
  version2?: string;
  contractType?: string;
  country?: string;
}

/**
 * Normalizes legal contract text extracted from various sources (PDF, Word DOCX, OCR, RTF).
 * Eliminates false positive differences caused by:
 * - PDF line-wrapping hard breaks vs DOCX continuous paragraphs
 * - Word-hyphenation across line margins (e.g. "respon- \n sibility" -> "responsibility")
 * - Smart quotes / typography (“ ” ‘ ’ — – …) vs ASCII equivalents (" ' - ...)
 * - Non-breaking spaces (\u00A0), zero-width characters, multiple spaces
 * - Header/footer page numbering artifacts ("Page 1 of 12")
 */
export function normalizeTextForComparison(rawText: string): string {
  if (!rawText) return '';

  let text = rawText;

  // 1. Normalize line endings
  text = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  // 2. Remove zero-width characters & non-breaking spaces
  text = text.replace(/[\u200B-\u200D\uFEFF]/g, '');
  text = text.replace(/[\u00A0\u1680\u180e\u2000-\u200a\u202f\u205f\u3000]/g, ' ');

  // 3. Normalize smart quotes, apostrophes, dashes, ellipses, soft hyphens
  text = text
    .replace(/[\u201C\u201D\u201E\u201F\u00AB\u00BB]/g, '"')
    .replace(/[\u2018\u2019\u201A\u201B\u2032\u2035]/g, "'")
    .replace(/[\u2013\u2014\u2015\u2212]/g, '-')
    .replace(/\u2026/g, '...')
    .replace(/[\u00AD]/g, '');

  // 4. Strip common PDF header/footer artifacts
  text = text.replace(/\n\s*Page\s+\d+\s*(?:of|\/)\s*\d+\s*\n/gi, '\n\n');
  text = text.replace(/\n\s*Page\s+\d+\s*\n/gi, '\n\n');
  text = text.replace(/\n\s*-\s*\d+\s*-\s*\n/g, '\n\n');
  text = text.replace(/\n\s*CONFIDENTIAL\s*\n/gi, '\n\n');

  // 5. Fix hyphenation across line breaks (e.g. "liabil-\n  ity" -> "liability")
  text = text.replace(/(\b[a-zA-Z]{2,})-\s*\n\s*([a-zA-Z]{2,}\b)/g, '$1$2');

  // 6. Fix PDF soft line wraps inside paragraphs
  const lines = text.split('\n');
  const normalizedLines: string[] = [];
  let currentPara = '';

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) {
      if (currentPara) {
        normalizedLines.push(currentPara);
        currentPara = '';
      }
      continue;
    }

    const isHeader = /^(?:SECTION\s+\d+|ARTICLE\s+\d+|CLAUSE\s+\d+|SCHEDULE|EXHIBIT|\d+\.\d+|\d+\.)/i.test(line);
    const isBullet = /^[-*•]\s+/.test(line);
    const isAllCapsShort = /^[A-Z\s\d.:_-]{4,40}$/.test(line) && line === line.toUpperCase();

    if (isHeader || isBullet || isAllCapsShort) {
      if (currentPara) {
        normalizedLines.push(currentPara);
        currentPara = '';
      }
      normalizedLines.push(line);
      continue;
    }

    if (!currentPara) {
      currentPara = line;
    } else {
      const lastChar = currentPara.slice(-1);
      const seemsCompleteSentence = ['.', ':', ';', '!', '?'].includes(lastChar) && /^[A-Z]/.test(line);
      if (seemsCompleteSentence) {
        normalizedLines.push(currentPara);
        currentPara = line;
      } else {
        currentPara += ' ' + line;
      }
    }
  }

  if (currentPara) {
    normalizedLines.push(currentPara);
  }

  text = normalizedLines.join('\n\n');
  text = text.split('\n').map(l => l.replace(/[ \t]+/g, ' ').trim()).join('\n');
  text = text.replace(/\n{3,}/g, '\n\n').trim();

  return text;
}

export function areContractTextsSubstantivelyIdentical(a: string, b: string): boolean {
  const normA = normalizeTextForComparison(a).toLowerCase().replace(/[^\w\d]/g, '');
  const normB = normalizeTextForComparison(b).toLowerCase().replace(/[^\w\d]/g, '');
  return normA === normB;
}

const MODEL_CASCADE = [
  "gemini-2.5-flash",
  "gemini-2.5-flash-lite",
  "gemini-3.7-flash",
  "gemini-3.1-flash-lite",
  "gemini-flash-latest"
];

async function generateWithRetry(
  ai: GoogleGenAI, 
  baseParams: any, 
  preferredModel = "gemini-2.5-flash", 
  maxRetriesPerModel = 1
): Promise<any> {
  const requestedModel = baseParams.model || preferredModel;
  const modelsToTry = [
    requestedModel,
    ...MODEL_CASCADE.filter(m => m !== requestedModel)
  ];

  let lastError: any = null;

  for (const modelName of modelsToTry) {
    let delayMs = 400;
    for (let attempt = 0; attempt <= maxRetriesPerModel; attempt++) {
      try {
        const response = await ai.models.generateContent({
          ...baseParams,
          model: modelName
        });
        return response;
      } catch (err: any) {
        lastError = err;
        const errMsg = (err?.message || String(err)).toLowerCase();
        const isQuotaOrLoad = 
          err?.status === 'UNAVAILABLE' || 
          err?.status === 'RESOURCE_EXHAUSTED' ||
          errMsg.includes('503') || 
          errMsg.includes('429') || 
          errMsg.includes('quota') ||
          errMsg.includes('resource_exhausted') ||
          errMsg.includes('rate-limit') ||
          errMsg.includes('high demand') ||
          errMsg.includes('overloaded');

        if (isQuotaOrLoad) {
          if (attempt < maxRetriesPerModel) {
            const jitter = Math.floor(Math.random() * 200);
            console.warn(`[Gemini API] ${modelName} rate limit / load spike (attempt ${attempt + 1}/${maxRetriesPerModel + 1}). Retrying with cascade in ${delayMs + jitter}ms...`);
            await new Promise((resolve) => setTimeout(resolve, delayMs + jitter));
            delayMs = Math.min(delayMs * 1.5, 1500);
            continue;
          } else {
            console.warn(`[Gemini API] ${modelName} quota/load reached. Switching to next model in pool...`);
            break; // Try next model in cascade
          }
        } else {
          break; // Non-transient error, try next model or fail gracefully
        }
      }
    }
  }

  throw lastError || new Error("All Gemini models in cascade are currently experiencing high load.");
}

export async function generateContractDraft(req: DraftContractRequest): Promise<{ draft: string; lawyerReviewNotes: string[]; assumptions: string[] }> {
  const ai = getAi();
  if (!ai) {
    return generateFallbackDraft(req);
  }

  try {
    // Locate the matching template definition
    const matchedTemplate = CONTRACT_TEMPLATES.find(t => t.id === req.templateId || t.name.toLowerCase() === (req.contractType || '').toLowerCase())
      || CONTRACT_TEMPLATES.find(t => t.category === 'commercial')
      || CONTRACT_TEMPLATES[0];

    // Determine the substantive detailed clauses to require
    const clausesToUse: DetailedClause[] = (req.detailedClauses && req.detailedClauses.length > 0)
      ? req.detailedClauses
      : (matchedTemplate.detailedClauses || TEMPLATE_DETAILED_CLAUSES[matchedTemplate.id] || TEMPLATE_DETAILED_CLAUSES['tmpl-msa'] || []);

    const formattedClauseArchitecture = clausesToUse.map((c, idx) => {
      return `SECTION ${idx + 1}: ${c.sectionNumber ? c.sectionNumber.toUpperCase() + ' - ' : ''}${c.title.toUpperCase()}
- Classification: [${c.category.toUpperCase()}] | Standard Benchmark: ${c.standardBenchmark}
- Mandatory Content Architecture (EXPAND WITH SUBSTANTIVE LEGAL PROSE, DO NOT CONDENSE):
"""
${c.fullLegalText}
"""
${c.jurisdictionNotes ? `- Statutory/Jurisdiction Requirement for ${req.country}: ${c.jurisdictionNotes}` : ''}`;
    }).join('\n\n');

    const prompt = `You are a Senior International Corporate Law Partner and Legal Architect.
Draft an exhaustive, multi-page, market-standard, institutional-grade, and jurisdiction-compliant legal agreement based on the following specifications and standard clause architectures.

CRITICAL DRAFTING MANDATE - FULLY EXPANDED, DETAILED CLAUSES ONLY:
- DO NOT summarize or write one-liner clauses. Each section MUST be fully expanded into exhaustive, multi-paragraph, professional legal drafting containing all relevant subsections, definitions, operational timelines, obligations, standards of performance, and remedies.
- Tailor all sections strictly to ${req.country} (${req.governingLaw}) and dispute resolution under ${req.disputeForum}.
- You MUST incorporate and expand upon every detailed standard clause architecture specified below. Every single clause listed must appear as a full, substantive section in the final agreement.

CONTRACT SPECIFICATIONS:
- Contract Type: ${req.contractType || matchedTemplate.name}
- Country: ${req.country}
- State / Region: ${req.stateOrRegion || 'Standard'}
- Governing Law: ${req.governingLaw}
- Dispute Resolution Forum: ${req.disputeForum}
- Primary Party (My Company): ${req.primaryParty?.legalName || 'Primary Party'} (${req.primaryParty?.entityType || 'Entity'}, ${req.primaryParty?.registeredAddress || 'Address'}, Tax ID: ${req.primaryParty?.taxId || 'N/A'}, Signatory: ${req.primaryParty?.signatoryName || 'Marcus Vance'}, ${req.primaryParty?.signatoryDesignation || 'Officer'})
- Counterparty: ${req.counterparty?.legalName || 'Counterparty'} (${req.counterparty?.entityType || 'Entity'}, ${req.counterparty?.registeredAddress || 'Address'}, Tax ID: ${req.counterparty?.taxId || 'N/A'}, Signatory: ${req.counterparty?.signatoryName || 'Elena Rostova'}, ${req.counterparty?.signatoryDesignation || 'Officer'})
- Scope of Work & Deliverables: ${req.scopeOfServices || 'Comprehensive operational commitments, specifications, and performance milestones'}
- Contract Value: ${req.commercials?.contractValue || 0} ${req.commercials?.currency || 'USD'}
- Pricing Model: ${req.commercials?.pricingModel || 'milestone_based'}, Payment Terms: Net ${req.commercials?.paymentDueDays || 30} days
- Liability Cap: ${req.riskLiability?.liabilityCapType || '1x fees in 12 months'}
- Consequential Damages Waiver: ${req.riskLiability?.consequentialDamagesExcluded !== false ? 'Yes (Strict mutual exclusion)' : 'No'}
- Indemnification Scope: ${req.riskLiability?.indemnificationScope || 'Mutual standard indemnification'}
- Special Conditions: ${req.specialTerms || 'None'}

MANDATORY CLAUSE ARCHITECTURES (EXPAND EACH CLAUSE INTO EXHAUSTIVE, MULTI-PARAGRAPH LEGAL PROSE):
0. FORMAL PREAMBLE, WITNESSETH & RECITALS (Identify parties with entity types, registered addresses, tax IDs, and clear background business recitals)
${formattedClauseArchitecture}
FINAL. EXECUTION & FORMAL SIGNATURE BLOCKS (Include full legal entity names, authorized signatory names, designations, dates, and e-sign lines for both parties)

Output your response strictly in JSON format with the following keys:
{
  "draft": "Complete plain text agreement with all numbered sections, uppercase headings, full multi-paragraph detailed legal drafting, and formal signature blocks",
  "lawyerReviewNotes": ["Array of 4-6 specific provisions where qualified local counsel verification is recommended for this jurisdiction"],
  "assumptions": ["Array of 3-4 key legal/commercial assumptions made during drafting"]
}`;

    const response = await generateWithRetry(ai, {
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const parsed = extractJsonFromResponse(response.text || '{}', null);
    if (parsed?.draft && parsed.draft.length > 500) {
      return parsed;
    }
    return generateFallbackDraft(req);
  } catch (err: any) {
    console.warn("[Gemini Drafting] Falling back gracefully to verified legal template engine:", err?.message || err);
    return generateFallbackDraft(req);
  }
}

export function extractJsonFromResponse<T = any>(rawText: string, fallback: T): T {
  if (!rawText || typeof rawText !== 'string') return fallback;
  
  let cleaned = rawText.trim();
  if (cleaned.startsWith('```')) {
    cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '').trim();
  }

  const firstBrace = cleaned.indexOf('{');
  const firstBracket = cleaned.indexOf('[');
  let startIdx = -1;
  let endIdx = -1;

  if (firstBrace !== -1 && (firstBracket === -1 || firstBrace < firstBracket)) {
    startIdx = firstBrace;
    endIdx = cleaned.lastIndexOf('}');
  } else if (firstBracket !== -1) {
    startIdx = firstBracket;
    endIdx = cleaned.lastIndexOf(']');
  }

  if (startIdx !== -1 && endIdx !== -1 && endIdx > startIdx) {
    cleaned = cleaned.substring(startIdx, endIdx + 1);
  }

  try {
    return JSON.parse(cleaned);
  } catch {
    try {
      const sanitized = cleaned.replace(/,\s*([}\]])/g, '$1');
      return JSON.parse(sanitized);
    } catch (e2) {
      console.warn('[JSON Extractor] Failed to parse model output JSON:', e2);
      return fallback;
    }
  }
}

export async function vetContract(req: VetContractRequest): Promise<{
  overallRiskScore: number;
  categoryScores: { financial: number; legal: number; compliance: number; data: number; operational: number };
  issues: any[];
  summary: string;
  favourableAspects: string[];
  negotiationStrategy: string;
}> {
  const ai = getAi();
  if (!ai) {
    return generateFallbackVetting(req);
  }

  try {
    const prompt = `You are a Principal Legal Counsel, Senior Vetting Partner, and Institutional Contract Risk Specialist.
Conduct an EXHAUSTIVE, COMPREHENSIVE, CLAUSE-BY-CLAUSE legal and commercial vetting of the provided contract.

CONTEXT:
- Country / Jurisdiction: ${req.country}
- Contract Type: ${req.contractType}
- Client Perspective: Analyze strictly in favor of "${req.myCompanyRole}" (My Company).
- Bias: ${req.analyzeInFavorOfMyCompany ? 'Scrutinize all provisions for one-sided exposure, excessive liability, unfair indemnity triggers, unreasonable termination terms, aggressive SLA penalties/breach windows, IP over-reach, missing statutory protections, and favorable negotiation redlines for My Company.' : 'Balanced, objective legal risk assessment'}

CONTRACT TEXT:
${req.contractText.substring(0, 30000)}

DETAILED AUDIT INSTRUCTIONS:
Do NOT limit your review to 2 or 3 issues. Systematically audit EVERY section of the agreement.
Identify ALL problematic, one-sided, ambiguous, or risky clauses in the text, as well as missing standard institutional protections. A typical enterprise contract contains between 5 and 15+ actionable issues across these categories:

1. Limitation of Liability & Multipliers (caps, exclusions, uninsurable super-caps)
2. Indemnification & Defense Obligations (scope, third-party claims, IP indemnity reciprocity)
3. Data Protection, Privacy & Breach Reporting (DPDPA 2023 / GDPR / CCPA, realistic notification windows of 48-72h)
4. Intellectual Property & Background Technology (ownership of custom deliverables vs proprietary reusable tooling)
5. Termination Rights & Notice (unilateral convenience, cure periods, lock-in)
6. Service Level Agreement (SLA) & 24/7 Support (uptime commitments, service credit remedies, escalation)
7. Information Security & Cybersecurity (SOC 2, ISO 27001, encryption standards, vulnerability audits)
8. Exit Management & Disentanglement (90-day transition support, certified data return/deletion)
9. Warranties, Disclaimers & Remedies (as-is disclaimers, performance warranties)
10. Confidentiality & Non-Disclosure (perpetual vs standard 3-5 year survival, definition boundaries)
11. Payment Terms, Price Increases & Late Fees (arbitrary fee escalation, dispute withhold rights)
12. Audit Rights & Inspection Scope (reasonable notice, frequency, cost burden)
13. Force Majeure & Business Continuity (cyberattack exclusions, relief conditions)
14. Governing Law & Dispute Resolution (favorable forum, mandatory arbitration vs court jurisdiction)
15. Non-Solicitation & Restrictive Covenants (scope, duration, enforceability)

For EACH identified issue, provide:
- "id": Unique id ("vet-01", "vet-02", "vet-03", etc.)
- "clauseTitle": Descriptive clause name
- "originalText": Exact verbatim quote from the contract text (or "[Missing Protection]" if omitted)
- "issue": Precise legal/commercial hazard and why it disadvantages My Company
- "riskLevel": "critical" | "high" | "medium" | "low" | "informational"
- "legalPrinciple": Applicable statutory rule or legal doctrine (e.g. UCC § 2-719, Indian Contract Act 1872, UK GDPR / UCTA 1977, Delaware Law)
- "businessImpact": Concrete financial, operational, or reputational consequence
- "companyPosition": "highly_unfavourable" | "unfavourable" | "neutral" | "favourable" | "missing_protection"
- "suggestedWording": Complete, professionally drafted replacement or addition ready for 1-click insertion
- "negotiationPriority": "high" | "medium" | "low"
- "lawyerReviewRequired": boolean
- "legalSourceCitation": { "statute": "Statute name", "jurisdiction": "${req.country}", "confidence": 95, "lastVerified": "2026-08-01" }

Return a JSON object strictly matching this schema:
{
  "overallRiskScore": 62,
  "categoryScores": {
    "financial": 65,
    "legal": 70,
    "compliance": 55,
    "data": 60,
    "operational": 50
  },
  "summary": "Comprehensive executive summary of the entire contract risk posture and strategic redline priorities.",
  "favourableAspects": ["List of terms currently favorable or protective of My Company"],
  "negotiationStrategy": "Structured negotiation roadmap detailing Tier 1 (walk-away), Tier 2 (must-have), and Tier 3 (trade-off) priorities.",
  "issues": [
    {
      "id": "vet-01",
      "clauseTitle": "Limitation of Liability Cap Over-Exposure",
      "originalText": "Exact quote from contract",
      "issue": "Specific explanation of exposure",
      "riskLevel": "critical",
      "legalPrinciple": "Relevant statute or doctrine",
      "businessImpact": "Commercial downside",
      "companyPosition": "highly_unfavourable",
      "suggestedWording": "Precise recommended replacement clause wording",
      "negotiationPriority": "high",
      "lawyerReviewRequired": true,
      "legalSourceCitation": {
        "statute": "Statute name",
        "jurisdiction": "${req.country}",
        "confidence": 98,
        "lastVerified": "2026-08-01"
      }
    }
  ]
}`;

    const response = await generateWithRetry(ai, {
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const parsed = extractJsonFromResponse(response.text || '{}', null);
    if (parsed?.issues && Array.isArray(parsed.issues) && parsed.issues.length > 0) {
      return parsed;
    }
    return generateFallbackVetting(req);
  } catch (err: any) {
    console.warn("[Gemini Vetting] Falling back to intelligent legal rules engine:", err?.message || err);
    return generateFallbackVetting(req);
  }
}

export async function compareContractVersions(req: CompareContractsRequest): Promise<{
  overallRiskDelta: number;
  executiveSummary: string;
  changes: any[];
  clauseDifferences?: any[];
}> {
  const rawTextA = req.previousContractText || req.versionA || req.version1 || '';
  const rawTextB = req.revisedContractText || req.versionB || req.version2 || '';

  const normA = normalizeTextForComparison(rawTextA);
  const normB = normalizeTextForComparison(rawTextB);

  // If both texts are substantively identical after normalization, return 0 changes immediately!
  if (areContractTextsSubstantivelyIdentical(normA, normB)) {
    return {
      overallRiskDelta: 0,
      executiveSummary: "Both documents were compared clause-by-clause. No substantive wording, legal terms, or risk differences were detected between Version A and Version B. All obligations, covenants, and terms are identical across both versions.",
      changes: [],
      clauseDifferences: []
    };
  }

  const ai = getAi();
  if (!ai) {
    return generateFallbackComparison(req);
  }

  try {
    const prompt = `You are a Senior Legal Contract Redline & Risk Comparison Specialist.
Compare the following two contract versions and identify ONLY substantive legal, commercial, and wording changes.

CRITICAL INSTRUCTIONS FOR ACCURACY:
- Different file formats (like PDF vs Word DOCX) may have different line wrapping, hyphenation across line breaks, multiple spaces, or quotation mark styles (smart quotes vs straight quotes).
- YOU MUST STRICTLY IGNORE all whitespace, line breaks, indentation, hyphenation, quotation mark styles, and header/footer page numbers.
- DO NOT report any difference for clauses that have identical wording.
- ONLY report clauses where the actual words, obligations, legal principles, numbers, dates, payment terms, or liability limits have changed.
- If all clauses have the exact same wording, return an empty array for changes: [] and an overallRiskDelta of 0.

VERSION 1 (Original / Base):
${normA.substring(0, 15000)}

VERSION 2 (Revised / Redline):
${normB.substring(0, 15000)}

Output JSON:
{
  "overallRiskDelta": 15, // Positive means risk increased, negative means risk decreased (-100 to +100), 0 if no change
  "executiveSummary": "Concise summary of who benefits and the major commercial/legal shifts (or stating that no substantive differences were found)",
  "changes": [
    {
      "id": "cmp-01",
      "clauseIndex": 1,
      "clauseTitle": "Clause Title",
      "changeType": "liability_change", // 'liability_change' | 'commercial_change' | 'ip_change' | 'termination_change' | 'governance_change' | 'scope_change'
      "previousText": "Exact quote from Version 1",
      "revisedText": "Exact quote from Version 2",
      "diffSummary": "Short 1-line diff summary",
      "whatChanged": "Detailed explanation of textual change",
      "whyItMatters": "Commercial or legal ramification",
      "whoBenefits": "Counterparty", // 'My Company' | 'Counterparty' | 'Neutral'
      "riskScoreDelta": 20, // Shift in risk
      "aiRecommendation": "Reject", // 'Accept' | 'Reject' | 'Negotiate' | 'Propose Compromise'
      "plainEnglishExplanation": "Simple explanation for business stakeholders",
      "negotiationTactic": "Actionable tactic for the negotiating counsel"
    }
  ]
}`;

    const response = await generateWithRetry(ai, {
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    if (parsed && Array.isArray(parsed.changes)) {
      return {
        overallRiskDelta: parsed.overallRiskDelta || 0,
        executiveSummary: parsed.executiveSummary || "Contract comparison completed.",
        changes: parsed.changes,
        clauseDifferences: parsed.changes
      };
    }
    return generateFallbackComparison(req);
  } catch (err: any) {
    console.warn("[Gemini Comparison] Falling back gracefully to verified redline engine:", err?.message || err);
    return generateFallbackComparison(req);
  }
}

// Fallback generators in case of offline / quota
function generateFallbackDraft(req: DraftContractRequest) {
  const pName = req.primaryParty?.legalName || 'Apex Cloud Solutions Inc.';
  const pType = req.primaryParty?.entityType || 'Corporation';
  const pAddr = req.primaryParty?.registeredAddress || '1209 Orange Street, Wilmington, DE 19801, USA';
  const pTax = req.primaryParty?.taxId || 'EIN-84-9912044';
  const pSign = req.primaryParty?.signatoryName || 'Marcus Vance';
  const pDesig = req.primaryParty?.signatoryDesignation || 'Chief Technology Officer';

  const cName = req.counterparty?.legalName || 'Global Fintech Ventures LLC';
  const cType = req.counterparty?.entityType || 'LLC';
  const cAddr = req.counterparty?.registeredAddress || '350 5th Ave, Suite 6200, New York, NY 10118, USA';
  const cTax = req.counterparty?.taxId || 'EIN-13-8829101';
  const cSign = req.counterparty?.signatoryName || 'Elena Rostova';
  const cDesig = req.counterparty?.signatoryDesignation || 'General Counsel & VP Operations';

  const cur = req.commercials?.currency || 'USD';
  const val = req.commercials?.contractValue ? Number(req.commercials.contractValue).toLocaleString() : '480,000';
  const payDays = req.commercials?.paymentDueDays || 30;
  const gLaw = req.governingLaw || 'Laws of the State of Delaware';
  const forum = req.disputeForum || 'American Arbitration Association (AAA), New York, NY';
  const scope = req.scopeOfServices || 'Cloud Infrastructure Architecture, AI Engineering & Cybersecurity Vulnerability Assessment Services';

  // Find template definition if non-default template requested
  const matchedTemplate = CONTRACT_TEMPLATES.find(t => t.id === req.templateId || t.name.toLowerCase() === (req.contractType || '').toLowerCase());

  if (matchedTemplate && matchedTemplate.sampleDraft && matchedTemplate.id !== 'tmpl-msa') {
    let customDraft = matchedTemplate.sampleDraft
      .replace(/Apex Cloud Solutions Inc\./g, pName)
      .replace(/Apex Innovations Inc\./g, pName)
      .replace(/Apex Enterprise Systems Inc\./g, pName)
      .replace(/Global Fintech Ventures LLC/g, cName)
      .replace(/Marcus Vance/g, pSign)
      .replace(/Elena Rostova/g, cSign)
      .replace(/Chief Technology Officer/g, pDesig)
      .replace(/General Counsel & VP Operations/g, cDesig)
      .replace(/EIN-84-9912044/g, pTax)
      .replace(/EIN-13-8829101/g, cTax)
      .replace(/Delaware/g, gLaw.includes('Delaware') ? 'Delaware' : (req.country || 'Delaware'))
      .replace(/USD 480,000/g, `${cur} ${val}`)
      .replace(/\$480,000/g, `${cur} ${val}`)
      .replace(/Net 30 days/g, `Net ${payDays} days`);

    return {
      draft: customDraft,
      lawyerReviewNotes: [
        `Local counsel in ${req.country} should review the statutory enforceability of restrictive covenants and liability limitations.`,
        `Verify cross-border withholding tax (WHT/TDS) requirements for commercial payments between ${req.country} and foreign counterparts.`,
        `Ensure institutional dispute resolution clauses (${forum}) conform to local civil procedure rules.`,
        `Confirm that electronic signature execution satisfies local statutory evidentiary standards.`
      ],
      assumptions: [
        `Assumed that both corporate entities are legally registered and in good standing.`,
        `Assumed arms-length commercial relationship between parties.`,
        `Assumed mutual electronic execution is legally binding under local statutes in ${req.country}.`
      ]
    };
  }

  const draft = `MASTER SERVICES AGREEMENT

This Master Services Agreement ("Agreement") is made and entered into as of the Effective Date by and between:

1. ${pName}, a ${pType} organized under the laws of ${req.country}, having registered office at ${pAddr} (Tax ID: ${pTax}) (hereinafter referred to as "Service Provider"); and
2. ${cName}, a ${cType} organized under the laws of ${req.country}, having registered office at ${cAddr} (Tax ID: ${cTax}) (hereinafter referred to as "Customer").

Service Provider and Customer are individually referred to as a "Party" and collectively as the "Parties".

RECITALS:
WHEREAS, Customer desires to engage Service Provider to perform enterprise cloud infrastructure, AI engineering, cybersecurity vulnerability assessments, and technical consulting services; and
WHEREAS, Service Provider possesses the specialized expertise, personnel, technical certifications, and infrastructure necessary to perform such services;

NOW, THEREFORE, in consideration of the mutual covenants herein contained, the Parties agree as follows:

1. DEFINITIONS & INTERPRETATION
1.1 "Affiliate" means any entity that directly or indirectly controls, is controlled by, or is under common control with a Party.
1.2 "Business Day" means any day other than a Saturday, Sunday, or official public bank holiday in the governing jurisdiction.
1.3 "Confidential Information" means all non-public technical, commercial, financial, operational, and proprietary information disclosed by one Party to the other.
1.4 "Customer Data" means all electronic data, files, records, and databases submitted to, processed by, or accessed by Service Provider on behalf of Customer.
1.5 "Deliverables" means all reports, software modules, architectural schematics, configurations, algorithms, scripts, documentation, and work product developed or provided by Service Provider under an applicable SOW.
1.6 "Personal Data" has the meaning ascribed under applicable Data Protection Legislation (including DPDPA 2023 and GDPR).
1.7 "Services" means the technology engineering, AI infrastructure, cybersecurity vulnerability assessments, and 24/7 technical support services set forth in executed SOWs.
1.8 "Service Level Agreement (SLA)" means the performance standards, availability thresholds, and response metrics set forth in Section 3 and Schedule A.
1.9 "Statement of Work (SOW)" means an executed document referencing this Agreement detailing specific scopes, deliverables, timelines, and fees.
1.10 "Work Product" means all custom code, inventions, and deliverables created specifically for Customer under this Agreement.

2. STATEMENT OF WORK (SOW), DELIVERABLES & ACCEPTANCE TESTING
2.1 Scope of Engagement: Service Provider shall perform the services described as: ${scope}. Specific projects shall be governed by executed SOWs.
2.2 Milestone Acceptance Testing: Customer shall have ten (10) business days from delivery to evaluate and test Deliverables against agreed specifications.
2.3 Rectification of Non-Conformity: If Customer provides written notice of non-conformity within the review period, Service Provider shall, at no additional charge, rectify such non-conformity within five (5) business days.
2.4 Deemed Acceptance: If Customer does not deliver written notice of rejection within ten (10) business days or deploys the Deliverable in production, the Deliverable shall be deemed accepted.
2.5 Change Control Procedure: Any scope changes, timeline modifications, or fee adjustments must be documented in a formal written Change Order signed by authorized representatives of both Parties.

3. SERVICE LEVEL AGREEMENT (SLA) & 24/7 TECHNICAL SUPPORT
3.1 Uptime Availability: Service Provider guarantees 99.9% Monthly Uptime Availability for all hosted cloud systems and infrastructure services (excluding scheduled maintenance with at least 48 hours advance written notice).
3.2 24/7 Level-3 Technical Support: Service Provider shall deliver continuous 24/7/365 Level-3 senior engineering support accessible via telephone, secure portal, and dedicated communication bridge.
3.3 Incident Severity Levels & Response SLA:
    - Severity 1 (Critical Outage / Core System Down): Initial response <= 15 minutes; Target resolution <= 2 hours.
    - Severity 2 (Major Impairment / High Degradation): Initial response <= 1 hour; Target resolution <= 6 hours.
    - Severity 3 (Moderate Issue / Workaround Exists): Initial response <= 4 hours; Target resolution <= 24 hours.
    - Severity 4 (Minor Query / Feature Request): Initial response <= 12 hours.
3.4 Service Credits for Downtime: If Monthly Uptime Availability falls below 99.9%, Customer shall receive Service Credits applied against the subsequent monthly invoice:
    - 99.0% to 99.89% Uptime: 10% credit of monthly service fee.
    - 95.0% to 98.99% Uptime: 25% credit of monthly service fee.
    - Below 95.0% Uptime: 50% credit of monthly service fee.
3.5 Chronic SLA Breach: Uptime below 95.0% in two (2) consecutive billing cycles shall constitute a material breach entitling Customer to terminate for cause.

4. COMMERCIAL TERMS, FEES, INVOICING & TAXES
4.1 Total Contract Consideration: ${val} ${cur}, payable in accordance with the milestone and monthly billing schedules in applicable SOWs.
4.2 Payment Terms: All undisputed invoices are due and payable Net ${payDays} days from the date of receipt of a valid tax invoice.
4.3 Late Payment Interest: Undisputed overdue amounts shall bear interest at 1.5% per month or the maximum statutory rate permitted by ${gLaw}.
4.4 Taxes: Fees are exclusive of applicable GST, VAT, sales tax, or withholding taxes (TDS), which shall be itemized separately on each invoice.

5. INTELLECTUAL PROPERTY & PROPRIETARY RIGHTS
5.1 Work Product Assignment: Upon full payment of applicable milestone fees, all custom software, scripts, documentation, and Deliverables authored specifically for Customer ("Work Product") shall become the sole and exclusive property of Customer.
5.2 Pre-Existing Background IP: Service Provider retains sole and exclusive title to its pre-existing tools, proprietary frameworks, libraries, and background IP ("Background IP"). Service Provider grants Customer a perpetual, irrevocable, worldwide, royalty-free, non-exclusive license to use Background IP embedded in Deliverables.

6. CONFIDENTIALITY & NON-DISCLOSURE
6.1 Non-Disclosure Covenant: Each Party shall preserve the confidentiality of the other Party's Confidential Information with the same degree of care it uses for its own confidential materials (and not less than reasonable care), and shall not disclose such information to third parties without prior written consent.
6.2 Permitted Disclosures: Disclosures are permitted to officers, employees, legal advisors, and vetted subcontractors with a strict need to know under binding confidentiality obligations.
6.3 Survival: Confidentiality obligations survive for five (5) years post-termination, provided that trade secrets and source code remain protected perpetually.

7. DATA PROCESSING AGREEMENT (DPA) & PRIVACY COMPLIANCE
7.1 Roles of Parties: Customer acts as Data Controller / Data Fiduciary, and Service Provider acts as Data Processor.
7.2 Processing Instructions: Service Provider shall process Personal Data exclusively upon documented instructions of Customer and in strict compliance with applicable Data Protection Laws (including India DPDPA 2023 and EU GDPR).
7.3 Security Breach Notification: Service Provider shall notify Customer in writing within twenty-four (24) to forty-eight (48) hours of confirming any unauthorized access, loss, or security incident affecting Customer Personal Data.
7.4 Assistance with Data Subject Rights: Service Provider shall provide reasonable technical assistance to enable Customer to fulfill statutory data subject requests (access, correction, erasure).

8. INFORMATION SECURITY & CYBERSECURITY VULNERABILITY ASSESSMENT
8.1 Security Standards: Service Provider shall maintain an Information Security Management System certified under ISO/IEC 27001 and verified by annual SOC 2 Type II audits.
8.2 Technical Safeguards: Safeguards include AES-256 encryption for data at rest, TLS 1.3 encryption in transit, multi-factor authentication (MFA), role-based access control (RBAC), and 180-day secure log retention.
8.3 Vulnerability Assessments & Pen Testing: Service Provider shall conduct quarterly vulnerability assessments and annual third-party penetration tests, remediating Critical and High findings within fourteen (14) calendar days.

9. SUBSTANTIVE MUTUAL INDEMNIFICATION
9.1 Service Provider Indemnity: Service Provider shall defend, indemnify, and hold harmless Customer, its Affiliates, directors, officers, and employees from and against any third-party claims, damages, liabilities, judgments, and legal fees arising out of: (a) actual or alleged infringement of any patent, copyright, trademark, or trade secret by Services or Deliverables; (b) gross negligence or willful misconduct of Service Provider; or (c) material breach of data protection or confidentiality obligations.
9.2 Customer Indemnity: Customer shall defend and indemnify Service Provider against third-party claims arising from Customer Data infringing third-party intellectual property rights or unlawful instructions.
9.3 Indemnification Procedures: The indemnified Party must: (i) promptly provide written notice of the claim; (ii) grant the indemnifying Party sole control of defense and settlement; and (iii) provide reasonable cooperation.

10. REPRESENTATIONS & WARRANTIES
10.1 Mutual Authority: Each Party represents and warrants that it is duly incorporated, validly existing, and possesses full corporate power to execute and perform this Agreement.
10.2 Service Standards Warranty: Service Provider warrants that Services shall be performed in a professional, workmanlike manner conforming to the highest industry standards by qualified personnel.
10.3 Deliverables Warranty: Service Provider warrants that Deliverables shall conform to SOW specifications for ninety (90) days following acceptance.
10.4 Non-Infringement & Malware Warranty: Service Provider warrants that Deliverables do not infringe third-party IP and are free from computer viruses, malware, worms, trojans, backdoors, or malicious disabling code.

11. LIMITATION OF LIABILITY & DAMAGES DISCLAIMER
11.1 Consequential Damages Disclaimer: Neither Party shall be liable for indirect, incidental, special, consequential, or punitive damages, or lost profits.
11.2 Aggregate Liability Ceiling: Except for breaches of Section 5 (IP), Section 6 (Confidentiality), Section 9 (Indemnification), or gross negligence/willful misconduct, each Party's total aggregate liability shall not exceed the total fees paid or payable under this Agreement in the twelve (12) months preceding the claim.

12. INSURANCE REQUIREMENTS
12.1 Coverage Mandate: During the Term and for twelve (12) months thereafter, Service Provider shall maintain:
    - Commercial General Liability: $2,000,000 per occurrence / $4,000,000 aggregate.
    - Cyber Risk, Network Security & Privacy Liability: $5,000,000 aggregate.
    - Professional Liability / Errors & Omissions: $2,000,000 per claim.
    - Statutory Workers' Compensation as required by law.
12.2 Certificates of Insurance: Certificates naming Customer as Additional Insured shall be provided within ten (10) days of request.

13. TERM, RENEWAL & TERMINATION
13.1 Term: This Agreement is effective from the Effective Date for a period of one (1) year, automatically renewing for successive one-year terms unless either Party gives sixty (60) days prior written notice.
13.2 Termination for Convenience: Either Party may terminate this Agreement or any SOW for convenience upon thirty (30) days prior written notice.
13.3 Termination for Cause: Either Party may terminate immediately upon written notice if the other Party commits a material breach and fails to cure such breach within thirty (30) days of written notice.

14. CONSEQUENCES OF TERMINATION & EXIT MANAGEMENT
14.1 Orderly Wind-Down: Upon termination, Service Provider shall immediately cease performance, and Customer shall pay for all undisputed Services properly performed up to the effective termination date.
14.2 Prepaid Fee Refund: Service Provider shall promptly refund all unearned prepaid fees on a pro-rata basis.
14.3 Disentanglement & Transition Assistance: Upon Customer's request, Service Provider shall provide transition and handover assistance for up to ninety (90) days at agreed commercial rates to ensure uninterrupted business continuity.

15. BUSINESS CONTINUITY & DISASTER RECOVERY (BCP/DR)
15.1 BCP/DR Commitments: Service Provider shall maintain and regularly test a formal BCP/DR Plan guaranteeing a Recovery Time Objective (RTO) of <= 4 hours and a Recovery Point Objective (RPO) of <= 1 hour, backed by automated daily multi-region geographic backups.

16. CUSTOMER DATA OWNERSHIP, PORTABILITY & CERTIFIED DELETION
16.1 Title in Customer Data: Customer retains 100% sole and exclusive title, ownership, and intellectual property rights in all Customer Data.
16.2 Data Return & Certified Erasure: Within thirty (30) days of termination, Service Provider shall provide Customer with full data export in standard machine-readable format (JSON/SQL/CSV) and permanently destroy all remaining copies with written certificate of destruction.

17. SUBCONTRACTING & THIRD-PARTY VENDORS
17.1 Prior Consent & Liability: Service Provider shall not subcontract core engineering without Customer's prior written consent, shall bind subcontractors to identical confidentiality/security terms, and remains 100% primarily liable for all subcontractor acts and omissions.

18. ASSIGNMENT & CORPORATE RESTRUCTURING
18.1 Assignment Restrictions: Neither Party may assign or transfer this Agreement without prior written consent, except to an Affiliate or in connection with a merger, acquisition, or sale of substantially all assets.

19. FORCE MAJEURE & EXCUSABLE DELAYS
19.1 Excusable Events: Neither Party is liable for delays caused by acts of God, war, terrorism, flood, fire, pandemic, or national power grid failures beyond reasonable control, excluding payment obligations.
19.2 Notice & Mitigation: Prompt written notice within five (5) business days is required. If disruption exceeds thirty (30) consecutive days, either Party may terminate without penalty.

20. BROAD COMPLIANCE WITH LAWS
20.1 Ongoing Compliance: Each Party shall comply with all applicable local, state, national, and international laws, regulations, and industry standards applicable to its business and performance under this Agreement.

21. ANTI-BRIBERY & ANTI-CORRUPTION COMPLIANCE
21.1 Zero Tolerance: Each Party warrants compliance with the US Foreign Corrupt Practices Act (FCPA), the UK Bribery Act 2010, and the Indian Prevention of Corruption Act, 1988, strictly prohibiting bribes, kickbacks, or facilitation payments.

22. TRADE SANCTIONS & EXPORT CONTROL COMPLIANCE
22.1 Sanctions Warranty: Each Party represents that neither it nor its officers are listed on US OFAC, BIS Entity List, EU, or UN sanctions lists, and covenants to comply with all applicable dual-use and export control laws.

23. AUDIT, INSPECTION & VERIFICATION RIGHTS
23.1 Audit Scope: Customer or its independent certified auditor under NDA may audit Service Provider's security controls, compliance logs, and billing records once per year upon ten (10) business days prior written notice during normal business hours.

24. FORMAL NOTICES & ELECTRONIC COMMUNICATION
24.1 Delivery Protocol: Formal notices must be in writing and delivered by tracked international courier (deemed received in 2 business days) or verified electronic mail to designated signatory addresses with delivery confirmation.

25. ENTIRE AGREEMENT, AMENDMENTS, WAIVER & SEVERABILITY
25.1 Integration: This Agreement, together with all SOWs, SLAs, DPAs, and schedules, constitutes the entire agreement between the Parties and supersedes all prior proposals, negotiations, and representations.
25.2 Amendments & Waivers: Amendments and waivers are valid only when executed in writing and signed by authorized signatories.
25.3 Severability: If any provision is held unenforceable, it shall be reformed to the minimum extent necessary, and all other terms shall remain in full force.

26. SURVIVAL & ORDER OF PRECEDENCE
26.1 Survival: Sections 1, 4, 5, 6, 7, 9, 10, 11, 14, 16, 25, 26, 28, and 29 survive contract termination.
26.2 Order of Precedence: In the event of conflict, the descending order of precedence is: (1) Data Processing Addendum (DPA); (2) Statement of Work (SOW); (3) Service Level Agreement (SLA); (4) Master Services Agreement; and (5) Purchase Orders (all pre-printed PO terms are void).

27. PUBLICITY & TRADEMARK RESTRICTIONS
27.1 Consent Required: Neither Party shall issue press releases, marketing case studies, or use the other Party's logo or trademarks without express prior written consent.

28. DISPUTE RESOLUTION & ARBITRATION
28.1 Executive Escalation & Arbitration: The Parties shall attempt good-faith executive negotiation for thirty (30) days. Any unresolved dispute shall be finally settled by binding institutional arbitration administered by ${forum} in accordance with its commercial arbitration rules. The arbitration seat shall be ${forum.includes('New York') ? 'New York, NY' : 'Selected Seat'}, conducted in English by a single arbitrator.

29. GOVERNING LAW & JURISDICTION
29.1 Governing Law: This Agreement shall be governed by and construed in accordance with the ${gLaw}, without regard to conflict of laws principles.

30. COUNTERPARTS & ELECTRONIC SIGNATURES
30.1 Electronic Execution: This Agreement may be executed in counterparts by digital or electronic signatures under applicable e-signature statutes (e.g. US E-SIGN Act, UETA, Indian IT Act 2000), each of which shall be deemed an original and binding on the executing Party.

IN WITNESS WHEREOF, the Parties' duly authorized representatives have executed this Master Services Agreement as of the Effective Date:

FOR: ${pName}
Signatory: ${pSign}
Title: ${pDesig}
Email: ${req.primaryParty?.signatoryEmail || 'm.vance@apexcloud.io'}
Date: ________________________

FOR: ${cName}
Signatory: ${cSign}
Title: ${cDesig}
Email: ${req.counterparty?.signatoryEmail || 'e.rostova@globalfintech.com'}
Date: ________________________`;

  return {
    draft,
    lawyerReviewNotes: [
      `Confirm limitation of liability carve-outs for data protection and IP indemnity align with corporate risk thresholds in ${req.country}.`,
      `Verify that the 24/7 Level-3 SLA response tiers (15 min for Sev-1) can be operationally staffed by the engineering team.`,
      `Ensure local tax registration, GST/VAT invoicing rules, and statutory withholding (TDS) clauses are reviewed for ${req.country}.`,
      `Confirm that the chosen arbitration venue (${forum}) is enforceable in both parties' home jurisdictions under the New York Convention.`
    ],
    assumptions: [
      `Assumed standard corporate authority and good legal standing of both entities.`,
      `Assumed services entail cloud infrastructure, AI models, and cybersecurity vulnerability assessments requiring SOC 2 Type II controls.`,
      `Assumed enterprise-grade Controller-to-Processor data processing relationship under DPDPA 2023 / GDPR.`
    ]
  };
}

function findMatchingSnippet(text: string, keywords: string[]): string {
  if (!text) return '';
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  for (const line of lines) {
    const lower = line.toLowerCase();
    if (keywords.some(kw => lower.includes(kw.toLowerCase()))) {
      return line.length > 250 ? line.substring(0, 247) + '...' : line;
    }
  }
  
  // Try paragraph or sentence matching
  const sentences = text.split(/(?<=[.?!])\s+/);
  for (const sent of sentences) {
    const lower = sent.toLowerCase();
    if (keywords.some(kw => lower.includes(kw.toLowerCase()))) {
      const clean = sent.trim();
      return clean.length > 250 ? clean.substring(0, 247) + '...' : clean;
    }
  }
  return '';
}

function generateFallbackVetting(req: VetContractRequest) {
  const text = req.contractText || '';
  const lowerText = text.toLowerCase();
  const issues: any[] = [];
  const favourableAspects: string[] = [];
  let riskScore = 35;
  let finRisk = 35;
  let legRisk = 40;
  let compRisk = 30;
  let dataRisk = 35;
  let opRisk = 30;

  // 1. Liability & Indemnification Analysis
  const liabilitySnippet = findMatchingSnippet(text, ['liability', 'capped at', 'aggregate liability', 'damages', 'indemnif']);
  if (liabilitySnippet) {
    if (lowerText.includes('3x') || lowerText.includes('three times') || lowerText.includes('unlimited liability')) {
      riskScore += 18;
      finRisk += 25;
      legRisk += 20;
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Limitation of Liability Cap Over-Exposure",
        originalText: liabilitySnippet,
        issue: "Contract expands liability ceiling to an aggressive multiplier or unlimited exposure, creating severe financial risk disproportionate to contract margins.",
        riskLevel: "critical",
        legalPrinciple: `Under commercial contract law (${req.country}), liability capped at 12 months fees represents market standard. Multiplier caps create uninsurable downside.`,
        businessImpact: "Multiplies maximum potential legal exposure without corresponding revenue justification.",
        companyPosition: "highly_unfavourable",
        suggestedWording: "Except for gross negligence or breach of confidentiality, each party's total aggregate liability arising out of or related to this Agreement shall be strictly capped at the total fees paid or payable by Customer to Service Provider in the twelve (12) months preceding the incident.",
        negotiationPriority: "high",
        lawyerReviewRequired: true,
        legalSourceCitation: {
          statute: req.country === 'India' ? 'Indian Contract Act, 1872 (§ 73/74)' : req.country === 'United Kingdom' ? 'Unfair Contract Terms Act 1977' : 'UCC § 2-719 / Delaware Commercial Code',
          jurisdiction: req.country,
          confidence: 96,
          lastVerified: '2026-08-01'
        }
      });
    } else {
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Limitation of Liability & Consequential Damages Waiver",
        originalText: liabilitySnippet,
        issue: "Ensure liability cap is bilateral (mutual) and explicitly excludes indirect, special, or consequential damages with clear super-caps.",
        riskLevel: "medium",
        legalPrinciple: "Standard commercial allocations require bilateral caps and express mutual exclusion of lost profits.",
        businessImpact: "Clarifies balance sheet risk boundaries for unexpected operational interruptions.",
        companyPosition: "neutral",
        suggestedWording: "Neither party shall be liable for indirect, special, incidental, or consequential damages. Each party's aggregate liability under this Agreement shall not exceed the fees paid in the trailing twelve (12) months.",
        negotiationPriority: "medium",
        lawyerReviewRequired: false,
        legalSourceCitation: {
          statute: req.country === 'India' ? 'Indian Contract Act 1872 (§ 73)' : 'Uniform Commercial Code § 2-719',
          jurisdiction: req.country,
          confidence: 92,
          lastVerified: '2026-08-01'
        }
      });
    }
  }

  // 2. Data Protection & Breach Notification Analysis
  const dataSnippet = findMatchingSnippet(text, ['data breach', 'personal data', 'gdpr', 'dpdpa', 'incident', 'notice within']);
  if (dataSnippet) {
    if (lowerText.includes('12 hours') || lowerText.includes('twelve (12) hours') || lowerText.includes('immediate notice') || lowerText.includes('any suspicion')) {
      riskScore += 12;
      dataRisk += 25;
      compRisk += 15;
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Data Breach Incident Notification Timeline",
        originalText: dataSnippet,
        issue: "12-hour or 'immediate upon suspicion' notification requirement is operationally hazardous prior to technical triage and confirmation.",
        riskLevel: "high",
        legalPrinciple: `Statutory data protection frameworks (${req.country === 'India' ? 'DPDPA 2023' : req.country === 'United Kingdom' ? 'UK GDPR Art. 33' : 'State Data Breach Laws / FTC'}) benchmark notice at 48 to 72 hours following formal confirmation of a breach.`,
        businessImpact: "Exposes Service Provider to technical breach of contract penalties for investigating normal false positive security alerts.",
        companyPosition: "unfavourable",
        suggestedWording: "Service Provider shall notify Customer in writing without undue delay, and in any event within forty-eight (48) hours, of becoming aware of and confirming a security incident resulting in unauthorized disclosure of Customer Personal Data.",
        negotiationPriority: "high",
        lawyerReviewRequired: true,
        legalSourceCitation: {
          statute: req.country === 'India' ? 'Digital Personal Data Protection Act 2023' : req.country === 'United Kingdom' ? 'UK GDPR Article 33' : 'US Model Security Breach Notification Act',
          jurisdiction: req.country,
          confidence: 97,
          lastVerified: '2026-08-01'
        }
      });
    }
  } else {
    // Missing Data Protection
    riskScore += 10;
    dataRisk += 20;
    compRisk += 15;
    issues.push({
      id: `vet-dyn-${issues.length + 1}`,
      clauseTitle: "Missing Data Processing Agreement (DPA / DPDPA / GDPR)",
      originalText: "[Missing Clause] No comprehensive Data Processing Agreement or GDPR/DPDPA schedule found in agreement text.",
      issue: "Lack of a formal Data Processing Addendum exposes both parties to statutory regulatory penalties for cross-border or vendor personal data processing.",
      riskLevel: "high",
      legalPrinciple: `Mandatory statutory controller-processor compliance requirements under ${req.country === 'India' ? 'Digital Personal Data Protection Act 2023' : req.country === 'United Kingdom' ? 'UK GDPR Art. 28' : 'State Privacy Laws (CCPA/CPRA)'}.`,
      businessImpact: "Severe regulatory exposure and lack of defined data subject access request (DSAR) protocols.",
      companyPosition: "missing_protection",
      suggestedWording: "SECTION 8: DATA PROTECTION. The parties agree to comply with all applicable data protection laws. To the extent Service Provider processes Personal Data on behalf of Customer, the parties shall execute and abide by the Data Processing Addendum (DPA) attached hereto as Exhibit B.",
      negotiationPriority: "high",
      lawyerReviewRequired: true,
      legalSourceCitation: {
        statute: req.country === 'India' ? 'DPDPA 2023' : 'GDPR Article 28',
        jurisdiction: req.country,
        confidence: 99,
        lastVerified: '2026-08-01'
      }
    });
  }

  // 3. Termination & Exit Management Analysis
  const termSnippet = findMatchingSnippet(text, ['terminate', 'termination', 'for convenience', 'notice', 'cure period']);
  if (termSnippet) {
    if (lowerText.includes('10 days') || lowerText.includes('ten (10) days') || lowerText.includes('unilateral') || (lowerText.includes('customer may terminate') && !lowerText.includes('provider may terminate'))) {
      riskScore += 10;
      opRisk += 20;
      legRisk += 10;
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Asymmetrical Termination for Convenience",
        originalText: termSnippet,
        issue: "Asymmetrical or short 10-day termination for convenience creates operational fragility and resource allocation risk without reciprocal rights.",
        riskLevel: "medium",
        legalPrinciple: "Equitable commercial standards require bilateral 30-day notice for convenience with 30-day cure periods for material breach.",
        businessImpact: "Risk of abrupt customer cancellation after significant dedicated engineering capacity deployment.",
        companyPosition: "unfavourable",
        suggestedWording: "Either party may terminate this Agreement or any Statement of Work for convenience upon thirty (30) days prior written notice to the other party, subject to payment of all completed milestones and non-cancelable commitments.",
        negotiationPriority: "medium",
        lawyerReviewRequired: false,
        legalSourceCitation: {
          statute: 'Standard Commercial Contracting Benchmark',
          jurisdiction: req.country,
          confidence: 94,
          lastVerified: '2026-08-01'
        }
      });
    }
  }

  // 4. SLA & 24/7 Support Analysis
  const slaSnippet = findMatchingSnippet(text, ['sla', 'uptime', 'service level', 'availability', 'support']);
  if (!slaSnippet) {
    riskScore += 8;
    opRisk += 15;
    issues.push({
      id: `vet-dyn-${issues.length + 1}`,
      clauseTitle: "Missing Service Level Agreement (SLA) & 24/7 L3 Support",
      originalText: "[Missing Clause] No detailed SLA response matrix, 99.9% uptime commitment, or service credit schedule found in text.",
      issue: "Agreement lacks concrete availability commitments and standardized Severity 1-4 incident response turnaround SLAs.",
      riskLevel: "medium",
      legalPrinciple: "Institutional cloud and software enterprise agreements require binding uptime commitments and tiered service credit remedy tables.",
      businessImpact: "No defined remedy or escalation procedure during mission-critical infrastructure outages.",
      companyPosition: "missing_protection",
      suggestedWording: "SECTION 4: SERVICE LEVEL AGREEMENT (SLA). Service Provider guarantees 99.9% monthly uptime for the Services and 24/7 Level-3 senior engineering support. In the event of critical Severity-1 downtime, Provider shall respond within fifteen (15) minutes, with Service Credit remedies calculated as 10% credit for uptime <99.9% and 25% credit for <99.0%.",
      negotiationPriority: "high",
      lawyerReviewRequired: false
    });
  } else {
    favourableAspects.push("Includes established Service Level Agreement (SLA) framework.");
  }

  // 5. Intellectual Property & Work Product
  const ipSnippet = findMatchingSnippet(text, ['intellectual property', 'work product', 'work made for hire', 'ownership', 'license']);
  if (ipSnippet) {
    if (lowerText.includes('work made for hire') || lowerText.includes('assigns all rights') || lowerText.includes('exclusive property')) {
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Intellectual Property & Background IP Reservation",
        originalText: ipSnippet,
        issue: "Ensure assignment of custom Deliverables explicitly reserves Service Provider's pre-existing Background IP, tools, frameworks, and reusable code libraries.",
        riskLevel: "medium",
        legalPrinciple: "Clear bifurcation between custom Client Work Product and proprietary Background Technology prevents unintentional loss of core IP assets.",
        businessImpact: "Protects core proprietary software tools, algorithms, and developer assets from being transferred to customer.",
        companyPosition: "unfavourable",
        suggestedWording: "Upon full payment of applicable fees, Customer shall own all right, title, and interest in custom Deliverables. Service Provider retains sole ownership of its pre-existing Background IP, software libraries, and proprietary developer tools, granting Customer a non-exclusive, perpetual license to use such Background IP as integrated into Deliverables.",
        negotiationPriority: "high",
        lawyerReviewRequired: true
      });
    } else {
      favourableAspects.push("Intellectual property terms include standard license boundaries.");
    }
  }

  // 6. Cybersecurity & Vulnerability Assessment
  const cyberSnippet = findMatchingSnippet(text, ['soc 2', 'iso 27001', 'vulnerability', 'penetration test', 'encryption', 'security']);
  if (!cyberSnippet) {
    riskScore += 6;
    dataRisk += 10;
    compRisk += 10;
    issues.push({
      id: `vet-dyn-${issues.length + 1}`,
      clauseTitle: "Missing Information Security & Cybersecurity Safeguards",
      originalText: "[Missing Clause] No express SOC 2 Type II, ISO 27001, or annual penetration testing audit obligations found in text.",
      issue: "Agreement lacks contractual commitments to enterprise cybersecurity controls (AES-256 encryption, quarterly vulnerability scans, annual pen testing).",
      riskLevel: "medium",
      legalPrinciple: "Enterprise institutional contracts mandate verifiable adherence to ISO 27001 / SOC 2 Type II controls.",
      businessImpact: "Lack of baseline security standards increases exposure to data breaches and third-party vendor compromise.",
      companyPosition: "missing_protection",
      suggestedWording: "SECTION 9: INFORMATION SECURITY. Service Provider shall maintain a comprehensive written information security program adhering to SOC 2 Type II / ISO 27001 standards, conduct annual independent penetration tests, and enforce AES-256 encryption for Customer Data at rest and TLS 1.3 in transit.",
      negotiationPriority: "medium",
      lawyerReviewRequired: false
    });
  } else {
    favourableAspects.push("Information security and data encryption requirements are contractually identified.");
  }

  // 8. Warranties & Disclaimers
  const warrantySnippet = findMatchingSnippet(text, ['warranty', 'warranties', 'as is', 'disclaimer', 'merchantability']);
  if (warrantySnippet) {
    if (lowerText.includes('as is') || lowerText.includes('without warranty of any kind') || lowerText.includes('disclaims all warranties')) {
      riskScore += 8;
      legRisk += 15;
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Broad 'As-Is' Warranty Disclaimer",
        originalText: warrantySnippet,
        issue: "Sweeping disclaimer of all express or implied warranties deprives My Company of core contractual performance assurances.",
        riskLevel: "medium",
        legalPrinciple: "Standard commercial software/services contracts should provide at minimum a 90-day conformity warranty to documentation.",
        businessImpact: "Risk of receiving defective or non-performing deliverables without warranty recourse or free defect remediation.",
        companyPosition: "unfavourable",
        suggestedWording: "Service Provider warrants that for a period of ninety (90) days from delivery, the Services and Deliverables shall operate in material conformity with the applicable Specifications and SOW. Upon written notice of non-conformity, Provider shall promptly repair or replace the affected Deliverables at no additional charge.",
        negotiationPriority: "medium",
        lawyerReviewRequired: false,
        legalSourceCitation: {
          statute: req.country === 'India' ? 'Sale of Goods Act / Indian Contract Act' : 'Uniform Commercial Code § 2-316',
          jurisdiction: req.country,
          confidence: 93,
          lastVerified: '2026-08-01'
        }
      });
    }
  }

  // 9. Confidentiality Survival & Boundaries
  const confSnippet = findMatchingSnippet(text, ['confidential', 'confidentiality', 'non-disclosure', 'trade secret', 'survive']);
  if (confSnippet) {
    if (lowerText.includes('perpetuity') || lowerText.includes('indefinitely') || lowerText.includes('liquidated damages')) {
      riskScore += 8;
      legRisk += 10;
      issues.push({
        id: `vet-dyn-${issues.length + 1}`,
        clauseTitle: "Perpetual Confidentiality / Disproportionate Liquidated Damages",
        originalText: confSnippet,
        issue: "Perpetual non-disclosure survival or automatic liquidated damage penalties for confidentiality breaches create uninsurable lifetime liabilities.",
        riskLevel: "high",
        legalPrinciple: "Standard commercial market practice bounds confidentiality survival at 3 to 5 years (except genuine trade secrets for as long as they qualify).",
        businessImpact: "Exposes company to indefinite document retention costs and litigation risk long after contract expiration.",
        companyPosition: "unfavourable",
        suggestedWording: "The confidentiality obligations herein shall survive the termination or expiration of this Agreement for a period of three (3) years; provided that trade secrets properly designated under applicable law shall remain confidential for so long as they qualify as trade secrets.",
        negotiationPriority: "high",
        lawyerReviewRequired: true
      });
    }
  }

  // 10. Audit Rights & Inspection Scope
  const auditSnippet = findMatchingSnippet(text, ['audit', 'inspection', 'inspect records', 'books and records']);
  if (!auditSnippet) {
    issues.push({
      id: `vet-dyn-${issues.length + 1}`,
      clauseTitle: "Missing Security & Compliance Audit Rights",
      originalText: "[Missing Clause] Agreement contains no express annual audit or regulatory compliance verification rights.",
      issue: "Lack of audit rights prevents My Company from verifying compliance with security standards, billing accuracy, and data protection mandates.",
      riskLevel: "low",
      legalPrinciple: "Enterprise governance standards require reasonable annual audit rights upon 10 business days prior written notice during normal business hours.",
      businessImpact: "Inability to verify vendor compliance for statutory compliance audits or regulatory investigations.",
      companyPosition: "missing_protection",
      suggestedWording: "SECTION 16: AUDIT RIGHTS. Upon at least ten (10) business days prior written notice, Customer (or its designated independent auditor) shall have the right to audit Service Provider's books, records, and security controls relevant to this Agreement once per calendar year during normal business hours.",
      negotiationPriority: "medium",
      lawyerReviewRequired: false
    });
  }

  // 11. Payment Terms & Late Interest
  const paymentSnippet = findMatchingSnippet(text, ['payment', 'invoice', 'interest', 'late fee', 'due within']);
  if (paymentSnippet && (lowerText.includes('1.5%') || lowerText.includes('2%') || lowerText.includes('immediate suspension') || lowerText.includes('due upon receipt'))) {
    issues.push({
      id: `vet-dyn-${issues.length + 1}`,
      clauseTitle: "Aggressive Payment Terms & Late Interest Penalties",
      originalText: paymentSnippet,
      issue: "Payment due upon receipt or excessive late fees with right to immediately suspend services without cure window impairs cash flow and operations.",
      riskLevel: "medium",
      legalPrinciple: "Standard commercial net terms are Net 30 or Net 45 days with interest capped at 1% per month or statutory ceiling.",
      businessImpact: "Creates risk of sudden service suspension due to routine internal invoice processing cycles.",
      companyPosition: "unfavourable",
      suggestedWording: "Customer shall pay undisputed invoices within thirty (30) days of invoice date (Net 30). Late undisputed payments shall accrue interest at 1.0% per month or the maximum legal rate. Provider shall provide fifteen (15) days written notice and cure opportunity prior to suspending services.",
      negotiationPriority: "medium",
      lawyerReviewRequired: false
    });
  }

  // 12. Exit Management & Disentanglement
  const exitSnippet = findMatchingSnippet(text, ['exit management', 'transition assistance', 'disentanglement', 'return of data', 'data return']);
  if (!exitSnippet) {
    issues.push({
      id: `vet-dyn-${issues.length + 1}`,
      clauseTitle: "Missing 90-Day Exit Transition & Disentanglement Safeguards",
      originalText: "[Missing Clause] Agreement lacks formal post-termination exit management and data migration covenants.",
      issue: "No defined transition window or data export format upon contract termination, risking operational disruption during vendor migration.",
      riskLevel: "low",
      legalPrinciple: "Standard commercial SaaS/services agreements require 30 to 90 days transition assistance at standard commercial rates.",
      businessImpact: "Mitigates vendor lock-in and ensures seamless business continuity during platform migrations.",
      companyPosition: "missing_protection",
      suggestedWording: "SECTION 15: CONSEQUENCES OF TERMINATION & EXIT MANAGEMENT. Upon termination or expiration of this Agreement, Service Provider shall provide up to ninety (90) days of transition assistance to facilitate an orderly transfer to Customer or a successor provider at standard T&M rates, and promptly deliver all Customer Data in standard machine-readable format (JSON/SQL).",
      negotiationPriority: "medium",
      lawyerReviewRequired: false
    });
  } else {
    favourableAspects.push("Includes post-termination transition and data return protocols.");
  }

  if (favourableAspects.length === 0) {
    favourableAspects.push(`Standard choice of law designating ${req.country} jurisdiction.`);
    favourableAspects.push("Written amendment and non-waiver governance clauses intact.");
  }

  const boundedScore = Math.min(95, Math.max(20, riskScore));

  return {
    overallRiskScore: boundedScore,
    categoryScores: {
      financial: Math.min(95, finRisk),
      legal: Math.min(95, legRisk),
      compliance: Math.min(95, compRisk),
      data: Math.min(95, dataRisk),
      operational: Math.min(95, opRisk)
    },
    summary: `Comprehensive legal vetting completed for ${req.contractType} (${req.country}). Identified ${issues.length} critical and high-priority legal/commercial issues in the text, focusing on ${req.analyzeInFavorOfMyCompany ? `protecting ${req.myCompanyRole}` : 'balanced contract risk'}.`,
    favourableAspects,
    negotiationStrategy: `Prioritize adjusting the liability cap to 12 months trailing fees, standardizing data breach notice to 48 hours post-confirmation, and incorporating missing SLA/DPA schedules.`,
    issues
  };
}

function generateFallbackComparison(req: CompareContractsRequest) {
  const rawTextA = req.previousContractText || req.versionA || req.version1 || '';
  const rawTextB = req.revisedContractText || req.versionB || req.version2 || '';

  const normA = normalizeTextForComparison(rawTextA);
  const normB = normalizeTextForComparison(rawTextB);

  if (areContractTextsSubstantivelyIdentical(normA, normB)) {
    return {
      overallRiskDelta: 0,
      executiveSummary: "Both documents were compared clause-by-clause. No substantive wording, legal terms, or risk differences were detected between Version A and Version B. All obligations and covenants are identical.",
      changes: [],
      clauseDifferences: []
    };
  }

  // Split into numbered sections or paragraphs
  const splitSections = (text: string) => {
    const sections: { title: string; body: string }[] = [];
    const blocks = text.split(/\n\n+/);
    for (const block of blocks) {
      const trimmed = block.trim();
      if (!trimmed) continue;
      const lines = trimmed.split('\n');
      const firstLine = lines[0];
      const rest = lines.slice(1).join(' ') || firstLine;
      sections.push({ title: firstLine.substring(0, 60), body: trimmed });
    }
    return sections;
  };

  const sectionsA = splitSections(normA);
  const sectionsB = splitSections(normB);

  const changes: any[] = [];
  let totalRiskDelta = 0;

  for (let i = 0; i < sectionsB.length; i++) {
    const secB = sectionsB[i];
    // Find matching section in A
    const matchA = sectionsA.find(s => 
      s.title.toLowerCase().replace(/[^\w]/g, '') === secB.title.toLowerCase().replace(/[^\w]/g, '')
    ) || (i < sectionsA.length ? sectionsA[i] : null);

    if (!matchA) {
      // New clause added
      changes.push({
        id: `cmp-dyn-${changes.length + 1}`,
        clauseIndex: i + 1,
        clauseTitle: secB.title,
        changeType: 'scope_change',
        previousText: '[Clause omitted in Version A]',
        revisedText: secB.body,
        diffSummary: 'Added new clause or schedule in revised version',
        whatChanged: 'Entire clause is added in Version B',
        whyItMatters: 'Introduces new covenants or obligations not present in Version A',
        whoBenefits: 'Counterparty',
        riskScoreDelta: 10,
        aiRecommendation: 'Negotiate',
        plainEnglishExplanation: 'This clause was newly added in the revised document.',
        negotiationTactic: 'Review necessity of the new clause and confirm alignment with business goals.'
      });
      totalRiskDelta += 10;
    } else {
      // Check if substantively identical
      const cleanA = matchA.body.toLowerCase().replace(/[^\w\d]/g, '');
      const cleanB = secB.body.toLowerCase().replace(/[^\w\d]/g, '');

      if (cleanA !== cleanB) {
        // Real substantive change
        const isLiability = secB.body.toLowerCase().includes('liabilit') || secB.body.toLowerCase().includes('cap');
        const isBreach = secB.body.toLowerCase().includes('breach') || secB.body.toLowerCase().includes('notif');
        const isPayment = secB.body.toLowerCase().includes('payment') || secB.body.toLowerCase().includes('invoice');

        const delta = isLiability ? 25 : isBreach ? 15 : isPayment ? 10 : 5;
        totalRiskDelta += delta;

        changes.push({
          id: `cmp-dyn-${changes.length + 1}`,
          clauseIndex: i + 1,
          clauseTitle: secB.title,
          changeType: isLiability ? 'liability_change' : isPayment ? 'commercial_change' : 'governance_change',
          previousText: matchA.body,
          revisedText: secB.body,
          diffSummary: `Modified terms in ${secB.title}`,
          whatChanged: `Wording modified between Version A and Version B`,
          whyItMatters: `Modifies legal parameters and contractual exposure`,
          whoBenefits: delta > 15 ? 'Counterparty' : 'Neutral',
          riskScoreDelta: delta,
          aiRecommendation: delta > 15 ? 'Reject' : 'Negotiate',
          plainEnglishExplanation: `Changes the wording and rights established under ${secB.title}.`,
          negotiationTactic: `Benchmark against institutional standard wording.`
        });
      }
    }
  }

  if (changes.length === 0) {
    return {
      overallRiskDelta: 0,
      executiveSummary: "Both documents were compared clause-by-clause. No substantive wording, legal terms, or risk differences were detected between Version A and Version B. All obligations and covenants are identical.",
      changes: [],
      clauseDifferences: []
    };
  }

  return {
    overallRiskDelta: totalRiskDelta,
    executiveSummary: `Identified ${changes.length} substantive clause modification(s) shifting risk by net ${totalRiskDelta > 0 ? `+${totalRiskDelta}` : totalRiskDelta} points.`,
    changes,
    clauseDifferences: changes
  };
}

export async function explainClausePlainEnglish(clauseText: string, jurisdiction: string): Promise<{
  plainEnglishSummary: string;
  keyObligations: string[];
  hiddenRisks: string[];
  negotiationTip: string;
}> {
  const ai = getAi();
  if (!ai) {
    return generateFallbackClauseExplanation(clauseText, jurisdiction);
  }

  try {
    const prompt = `You are a Legal Translator and Contract Specialist.
Explain the following complex legal clause in crystal-clear, plain English for a non-lawyer executive or business owner.

JURISDICTION: ${jurisdiction}
CLAUSE TEXT:
${clauseText.substring(0, 4000)}

Output in JSON matching this schema:
{
  "plainEnglishSummary": "2-3 clear sentences explaining exactly what this clause means in practice",
  "keyObligations": ["Array of 2-3 specific obligations imposed on the parties"],
  "hiddenRisks": ["Array of 1-3 hidden legal or commercial traps in this clause"],
  "negotiationTip": "1 practical actionable tactic for redlining or negotiating this clause"
}`;

    const response = await generateWithRetry(ai, {
      model: "gemini-3.7-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      }
    });

    const parsed = JSON.parse(response.text || '{}');
    if (parsed.plainEnglishSummary) {
      return parsed;
    }
    return generateFallbackClauseExplanation(clauseText, jurisdiction);
  } catch (err: any) {
    console.warn("[Gemini Clause Explanation] Falling back to rule-based explanation engine:", err?.message || err);
    return generateFallbackClauseExplanation(clauseText, jurisdiction);
  }
}

function generateFallbackClauseExplanation(clauseText: string, jurisdiction: string) {
  const lower = clauseText.toLowerCase();
  if (lower.includes('indemnif')) {
    return {
      plainEnglishSummary: "This is a promise that one party will pay the legal bills and damages if a third party sues the other party over things like intellectual property infringement, data leaks, or gross negligence.",
      keyObligations: [
        "Pay for qualified defense lawyers if a lawsuit or claim occurs",
        "Hold the protected party harmless against court judgments and agreed settlement costs"
      ],
      hiddenRisks: [
        "Uncapped indemnities can obligate you to pay unlimited sums far exceeding total contract revenue"
      ],
      negotiationTip: "Ensure indemnity is reciprocal (mutual), explicitly subject to the liability cap, and conditioned upon prompt written notice and control of defense."
    };
  }

  if (lower.includes('liabilit') || lower.includes('damages')) {
    return {
      plainEnglishSummary: "This clause sets the absolute maximum financial ceiling that either party can recover in court if a breach occurs, and prevents claims for lost future profits.",
      keyObligations: [
        "Waives entitlement to indirect, special, or consequential damages",
        "Caps direct damages at a defined monetary amount (typically 12 months fees paid)"
      ],
      hiddenRisks: [
        "Asymmetrical caps where only the vendor is protected or super-caps that expose you to 3x-5x fees"
      ],
      negotiationTip: "Benchmark liability to 100% of fees paid over the trailing 12 months, with a 2x super-cap strictly reserved for confirmed data privacy incidents."
    };
  }

  return {
    plainEnglishSummary: "This clause establishes standard legal rights, operational protocols, and commercial obligations between the contracting parties under " + jurisdiction + " law.",
    keyObligations: [
      "Strict compliance with agreed delivery, notice, and operational standards",
      "Adherence to governing statutory rules and dispute resolution channels"
    ],
    hiddenRisks: [
      "One-sided deadlines or ambiguity in defined scope and acceptance protocols"
    ],
    negotiationTip: "Ensure timelines are measured in Business Days and require formal written notice before any default is triggered."
  };
}

export async function parseDocumentContent(
  fileBase64: string,
  fileName: string,
  mimeType?: string
): Promise<{ text: string; wordCount: number; charCount: number; detectedType: string }> {
  const buffer = Buffer.from(fileBase64, 'base64');
  const lowerName = fileName.toLowerCase();
  let extractedText = '';
  let detectedType = 'text/plain';

  // 1. Handle DOCX / DOC
  if (lowerName.endsWith('.docx') || mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
    detectedType = 'Microsoft Word (.docx)';
    try {
      // Dynamic import to avoid CJS/ESM bundling conflicts
      const mammoth = await import('mammoth');
      const mammothExtract = mammoth.default?.extractRawText || (mammoth as any).extractRawText;
      if (mammothExtract) {
        const result = await mammothExtract({ buffer });
        extractedText = result.value || '';
      }
    } catch (err) {
      console.warn('[Docx Parser] mammoth failed, attempting fallback:', err);
    }
  } else if (lowerName.endsWith('.pdf') || mimeType === 'application/pdf') {
    detectedType = 'PDF Document (.pdf)';
    try {
      const pdfParseModule: any = await import('pdf-parse');
      const pdfParse = pdfParseModule.default || pdfParseModule;
      if (typeof pdfParse === 'function') {
        const data = await pdfParse(buffer);
        extractedText = data.text || '';
      }
    } catch (err) {
      console.warn('[PDF Parser] pdf-parse failed:', err);
    }

    // If PDF text is very short (e.g. scanned document or image PDF) and Gemini is available, use Gemini OCR
    if ((!extractedText || extractedText.trim().length < 50) && getAi()) {
      try {
        const ai = getAi();
        if (ai) {
          console.log('[PDF Parser] Attempting multi-modal document extraction for scanned/complex PDF...');
          const response = await generateWithRetry(ai, {
            contents: [
              {
                inlineData: {
                  mimeType: "application/pdf",
                  data: fileBase64
                }
              },
              {
                text: "Extract and transcribe all text, clauses, titles, terms, party names, and numbers from this legal document accurately and completely. Maintain section formatting and clause numbering. Output only the transcribed document text."
              }
            ]
          }, "gemini-3.7-flash", 1);
          if (response?.text) {
            extractedText = response.text;
          }
        }
      } catch (geminiErr: any) {
        console.warn('[PDF Parser] Gemini OCR unavailable, falling back to text stream extraction:', geminiErr?.message || geminiErr);
      }
    }

    // Secondary fallback: extract readable ASCII / UTF-8 text streams from raw PDF buffer
    if (!extractedText || extractedText.trim().length === 0) {
      try {
        const rawStr = buffer.toString('latin1');
        // Match text within PDF parentheses (standard PDF text show operators like (Hello World) Tj)
        const textSnippets: string[] = [];
        const regex = /\(([^)\\]*(?:\\.[^)\\]*)*)\)\s*T[jJ]/g;
        let match;
        while ((match = regex.exec(rawStr)) !== null) {
          const unescaped = match[1].replace(/\\([()\\])/g, '$1');
          if (unescaped.trim().length > 1) {
            textSnippets.push(unescaped);
          }
        }
        if (textSnippets.length > 5) {
          extractedText = textSnippets.join(' ');
        } else {
          // General printable characters
          extractedText = buffer.toString('utf8').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, ' ').replace(/\s+/g, ' ').trim();
        }
      } catch (streamErr) {
        console.warn('[PDF Parser] Text stream extraction fallback failed:', streamErr);
      }
    }
  } else if (lowerName.endsWith('.doc')) {
    detectedType = 'Legacy Word Document (.doc)';
    // Try Gemini if available or extract printable strings
    const ai = getAi();
    if (ai) {
      try {
        const response = await generateWithRetry(ai, {
          contents: [
            {
              text: `Here is the binary/hex content representation of a legacy .doc file. Extract all readable contractual text, clauses, parties, and provisions:\n\n${buffer.toString('utf8').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, ' ').substring(0, 30000)}`
            }
          ]
        }, "gemini-3.7-flash", 1);
        if (response?.text) {
          extractedText = response.text;
        }
      } catch (e: any) {
        console.warn('[Doc Parser] AI parsing fallback:', e?.message || e);
      }
    }
    if (!extractedText) {
      extractedText = buffer.toString('utf8').replace(/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x9F]/g, ' ').trim();
    }
  } else {
    // Plain text, Markdown, RTF, JSON, HTML
    detectedType = lowerName.endsWith('.md') ? 'Markdown (.md)' : 'Plain Text';
    extractedText = buffer.toString('utf8');
  }

  // Clean up and normalize formatting, line wrapping, quotes, and whitespace
  const cleanedText = normalizeTextForComparison(extractedText);

  const words = cleanedText.length > 0 ? cleanedText.split(/\s+/).length : 0;
  const chars = cleanedText.length;

  return {
    text: cleanedText,
    wordCount: words,
    charCount: chars,
    detectedType
  };
}


