import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import {
  generateContractDraft,
  vetContract,
  compareContractVersions,
  explainClausePlainEnglish,
  parseDocumentContent
} from "./server/geminiService.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "25mb" }));
  app.use(express.urlencoded({ extended: true, limit: "25mb" }));

  // --- API Endpoints ---
  app.get("/api/health", (req, res) => {
    res.json({
      status: "ok",
      service: "Global Legal AI Platform API",
      timestamp: new Date().toISOString(),
      hasGeminiKey: !!process.env.GEMINI_API_KEY
    });
  });

  // AI Contract Drafting
  app.post("/api/draft-contract", async (req, res) => {
    try {
      const result = await generateContractDraft(req.body);
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("API Draft Error:", err);
      res.status(500).json({ success: false, error: err.message || "Failed to generate draft" });
    }
  });

  // AI Legal Vetting
  app.post("/api/vet-contract", async (req, res) => {
    try {
      const result = await vetContract(req.body);
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("API Vetting Error:", err);
      res.status(500).json({ success: false, error: err.message || "Failed to vet contract" });
    }
  });

  // AI Document Comparison & Redline
  app.post("/api/compare-contracts", async (req, res) => {
    try {
      const result = await compareContractVersions(req.body);
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("API Comparison Error:", err);
      res.status(500).json({ success: false, error: err.message || "Failed to compare contract versions" });
    }
  });

  // Plain-English Clause Translation
  app.post("/api/explain-clause", async (req, res) => {
    try {
      const { clauseText, jurisdiction } = req.body;
      const result = await explainClausePlainEnglish(clauseText || "", jurisdiction || "General");
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("API Explain Error:", err);
      res.status(500).json({ success: false, error: err.message || "Failed to explain clause" });
    }
  });

  // Document & Contract File Parsing (DOCX, PDF, DOC, TXT, MD, etc.)
  app.post("/api/parse-document", async (req, res) => {
    try {
      const { fileBase64, fileName, mimeType } = req.body;
      if (!fileBase64 || !fileName) {
        return res.status(400).json({ success: false, error: "fileBase64 and fileName are required" });
      }
      const result = await parseDocumentContent(fileBase64, fileName, mimeType);
      res.json({ success: true, ...result });
    } catch (err: any) {
      console.error("API Parse Document Error:", err);
      res.status(500).json({ success: false, error: err.message || "Failed to parse document" });
    }
  });

  // Email & Document Distribution simulation with logged audit
  app.post("/api/send-email", async (req, res) => {
    try {
      const { contractId, contractTitle, recipients, subject, emailBody } = req.body;
      console.log(`[EMAIL DISPATCH] Sent to ${recipients?.join(', ')} for Contract ${contractId} (${contractTitle})`);
      res.json({
        success: true,
        message: `Successfully dispatched signed contract packet to ${recipients?.length || 0} recipients.`,
        dispatchTimestamp: new Date().toISOString(),
        deliveryStatus: 'delivered',
        recipients
      });
    } catch (err: any) {
      res.status(500).json({ success: false, error: err.message });
    }
  });

  // --- Vite Middleware or Static Assets ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Legal AI Platform Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error("Failed to start server:", err);
});
