@echo off
cd /d "%~dp0"
python -c "import pandas, openpyxl" 2>nul || pip install pandas openpyxl
python zomato_to_tally.py
echo.
pause
