MONTHLY STEPS
1. Put the client's Zomato Settlement Report (.xlsx) in the Input folder.
2. Double-click Run_Zomato.bat.
3. Output folder gets: Zomato_GST_<Mon_Year>.xlsx and Zomato_Tally_Import_<Mon_Year>.xml
4. Tally Prime: open company > Alt+O (Import) > Vouchers > select the XML. Behaviour: Add/Create.

FIRST-TIME SETUP
- Install Python 3 (tick "Add to PATH"), once. Needs internet only for that and the first pip install.
- Edit settings.json (gst_rate = 5, plus a Round Off ledger): ledger names MUST match Tally exactly (party, sales, CGST, SGST). Create them in Tally first.
- "company": leave blank to import into the currently open company, or type the exact company name.
- Tally must have the Sales voucher type, and ledgers created, or import will show errors.

NOTES
- One Sales voucher per ORDER, built from the Order Details sheet. Voucher no. = ZOM/<Order ID> (set prefix in settings.json), so re-importing will not duplicate. Zomato order ID is also in Reference; narration has order date and UTR.
- Cancelled orders are excluded. Commission, TCS, TDS 194O and ad charges are NOT posted here.
- Test with one month in a dummy company first.
- GST is computed at the statutory rate: Taxable = Invoice Value / 1.05, CGST = SGST = 2.5% of Taxable. Round Off is paise only.
- Tally entries are built from exactly the same figures as the Order Details sheet.
- Order Details column 'GST Variance vs Zomato' shows where Zomato collected less/more GST than 5% (extra liability).
