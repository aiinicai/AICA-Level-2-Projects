import pandas as pd, sys, os, glob, json
from decimal import Decimal as D, ROUND_HALF_UP
from xml.sax.saxutils import escape
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

def q(x): return D(str(x)).quantize(D('0.01'),rounding=ROUND_HALF_UP)

def load(src,rate):
    df=pd.read_excel(src,sheet_name='Order Level',header=6)
    df=df[pd.to_numeric(df['S.no.'],errors='coerce').notna()].copy()
    c=list(df.columns)
    n=lambda i: pd.to_numeric(df[c[i]],errors='coerce').fillna(0).round(2)
    d=pd.DataFrame({'oid':df[c[1]].astype(str),'odate':pd.to_datetime(df[c[2]]),'status':df[c[8]],
      'disc':df[c[6]].where(df[c[6]].astype(str)!='NA',''),'itm':n(14),'pack':n(15),
      'delv':(n(16)-n(20)+n(19)).round(2),'disc_amt':(n(17)+n(18)).round(2),'zgst':n(21),
      'sstat':df[c[56]],'sdate':df[c[57]].astype(str).str[:10],'utr':df[c[58]]})
    d['inv']=(d.itm+d.pack+d.delv-d.disc_amt+d.zgst).round(2)      # customer-paid value per Zomato
    rate=D(str(rate)); rows=[]
    for v in d.inv:
        W=q(v); tax=(W/(1+rate/100)).quantize(D('0.01'),rounding=ROUND_HALF_UP)
        cg=(tax*rate/200).quantize(D('0.01'),rounding=ROUND_HALF_UP)
        rows.append((float(tax),float(cg),float(cg),float(W-tax-cg-cg)))
    d[['tax','cgst','sgst','rnd']]=pd.DataFrame(rows,index=d.index)
    d=d.sort_values(['odate','oid']).reset_index(drop=True)
    return d[d.status=='DELIVERED'].reset_index(drop=True), d[d.status!='DELIVERED'].reset_index(drop=True), df[c[4]].iloc[0], str(df[c[5]].iloc[0])

NAVY='1F3864'; thin=Side(style='thin',color='BFBFBF'); B=Border(left=thin,right=thin,top=thin,bottom=thin)
hf=Font(bold=True,color='FFFFFF',name='Arial',size=10); hfill=PatternFill('solid',fgColor=NAVY)
bf=Font(name='Arial',size=10); bold=Font(name='Arial',size=10,bold=True); inp=Font(name='Arial',size=10,color='0000FF')
tfill=PatternFill('solid',fgColor='D9E1F2'); NUM='#,##0.00;[Red](#,##0.00);"-"'
def hdr(sh,row,heads):
    for j,h in enumerate(heads,1):
        x=sh.cell(row,j,h); x.font=hf; x.fill=hfill; x.border=B
        x.alignment=Alignment(horizontal='center',vertical='center',wrap_text=True)
    sh.row_dimensions[row].height=42

def build_excel(dl,cx,res,rid,rate,out):
    wb=Workbook(); ws=wb.active; ws.title='GST Summary'; od=wb.create_sheet('Order Details'); cs=wb.create_sheet('Cancelled Orders')
    od['A1']=f'{res} - Order Details (Zomato) | Res ID {rid}'; od['A1'].font=Font(name='Arial',size=13,bold=True,color=NAVY)
    od['A2']=('Invoice Value = amount payable by customer per Zomato. Taxable Amount is back-calculated at the statutory GST rate (blue, editable); '
              'Round Off absorbs paise only. Cancelled orders excluded.'); od['A2'].font=Font(name='Arial',size=9,italic=True)
    H=4
    heads=['S.No','Order ID','Order Date','Items Total','Packaging Charge','Delivery / Brand Pack (net)','Restaurant Discounts',
           'GST Collected by Zomato','Invoice Value (as per Zomato)','GST Rate (%)','Taxable Amount','CGST','SGST','Round Off',
           'Total Invoice Amount','GST Variance vs Zomato','Discount Code','Settlement Status','Settlement Date','Bank UTR']
    hdr(od,H,heads); r0=H+1
    for i,r in dl.iterrows():
        x=r0+i
        for j,v in enumerate([i+1,r.oid,r.odate.to_pydatetime().date(),r.itm,r.pack,r.delv,r.disc_amt,r.zgst],1): od.cell(x,j,v)
        od.cell(x,9,f'=ROUND(D{x}+E{x}+F{x}-G{x}+H{x},2)')
        od.cell(x,10,rate)
        od.cell(x,11,f'=ROUND(I{x}/(1+J{x}/100),2)')
        od.cell(x,12,f'=ROUND(K{x}*J{x}/200,2)')
        od.cell(x,13,f'=L{x}')
        od.cell(x,14,f'=ROUND(I{x}-K{x}-L{x}-M{x},2)')
        od.cell(x,15,f'=K{x}+L{x}+M{x}+N{x}')
        od.cell(x,16,f'=ROUND(L{x}+M{x}-H{x},2)')
        for j,v in enumerate([r.disc,r.sstat,r.sdate,r.utr],17): od.cell(x,j,v)
    rl=r0+len(dl)-1; rt=rl+1; od.cell(rt,2,'TOTAL')
    for col in 'DEFGHIKLMNOP': od[f'{col}{rt}']=f'=SUM({col}{r0}:{col}{rl})'
    for row in od.iter_rows(min_row=r0,max_row=rt,min_col=1,max_col=20):
        for x in row:
            x.font=bf; x.border=B
            if 4<=x.column<=16 and x.column!=10: x.number_format=NUM
            if x.column==3: x.number_format='dd-mmm-yyyy'
    for x in range(r0,rl+1): od.cell(x,10).font=inp; od.cell(x,10).number_format='0.00'
    for x in od[rt]: x.font=bold; x.fill=tfill
    for col,w in zip('ABCDEFGHIJKLMNOPQRST',[6,13,12,11,10,12,11,12,13,8,13,10,10,9,13,12,12,11,12,19]): od.column_dimensions[col].width=w
    od.freeze_panes=f'D{H+1}'; od.sheet_view.showGridLines=False; od.auto_filter.ref=f'A{H}:T{rl}'
    # summary
    ws['A1']=f'{res} - Zomato GST Summary (Date-wise)'; ws['A1'].font=Font(name='Arial',size=14,bold=True,color=NAVY)
    ws['A2']=f'Res ID: {rid}   |   Period: {dl.odate.min():%d-%b-%Y} to {dl.odate.max():%d-%b-%Y}   |   Delivered orders only'; ws['A2'].font=Font(name='Arial',size=10)
    ws['A3']=f'GST at {rate}% (CGST {rate/2}% + SGST {rate/2}%) on Taxable Amount; Round Off = paise difference to Zomato invoice value.'; ws['A3'].font=Font(name='Arial',size=9,italic=True)
    S=5; hdr(ws,S,['Date','No. of Orders','Taxable Amount','GST Rate (%)','CGST Amount','SGST Amount','Round Off','Total Invoice Amount'])
    dates=sorted(dl.odate.dt.date.unique()); s0=S+1
    rg=lambda col: f"'Order Details'!${col}${r0}:${col}${rl}"
    for i,dd in enumerate(dates):
        x=s0+i; ws.cell(x,1,dd)
        ws.cell(x,2,f'=COUNTIF({rg("C")},A{x})')
        for col,src in zip((3,5,6,7),'KLMN'): ws.cell(x,col,f'=SUMIFS({rg(src)},{rg("C")},A{x})')
        ws.cell(x,4,f'=IF(C{x}=0,0,ROUND((E{x}+F{x})/C{x}*100,2))')
        ws.cell(x,8,f'=C{x}+E{x}+F{x}+G{x}')
    sl=s0+len(dates)-1; st=sl+1; ws.cell(st,1,'TOTAL')
    for col in 'BCEFGH': ws[f'{col}{st}']=f'=SUM({col}{s0}:{col}{sl})'
    ws[f'D{st}']=f'=IF(C{st}=0,0,ROUND((E{st}+F{st})/C{st}*100,2))'
    for row in ws.iter_rows(min_row=s0,max_row=st,min_col=1,max_col=8):
        for x in row:
            x.font=bf; x.border=B
            if x.column in (3,5,6,7,8): x.number_format=NUM
            if x.column==4: x.number_format='0.00'
            if x.column==1: x.number_format='dd-mmm-yyyy'; x.alignment=Alignment(horizontal='left')
    for x in ws[st]: x.font=bold; x.fill=tfill
    ck=st+2
    ws.cell(ck,1,'Check: Summary total less Order Details total (should be 0)').font=Font(name='Arial',size=9,italic=True)
    ws.cell(ck,8,f"=ROUND(H{st}-'Order Details'!O{rt},2)").number_format=NUM
    ws.cell(ck+1,1,'GST payable vs GST collected by Zomato (extra liability if positive)').font=Font(name='Arial',size=9,italic=True)
    ws.cell(ck+1,8,f"='Order Details'!P{rt}").number_format=NUM
    for col,w in zip('ABCDEFGH',[16,11,15,11,14,14,11,18]): ws.column_dimensions[col].width=w
    ws.freeze_panes=f'A{S+1}'; ws.sheet_view.showGridLines=False
    cs['A1']='Cancelled / Rejected Orders (excluded from GST)'; cs['A1'].font=Font(name='Arial',size=13,bold=True,color=NAVY)
    hdr(cs,3,['S.No','Order ID','Order Date','Status','Order Value','Settlement Status','Settlement Date'])
    for i,r in cx.iterrows():
        for j,v in enumerate([i+1,r.oid,r.odate.to_pydatetime().date(),r.status,r.inv,r.sstat,r.sdate],1):
            x=cs.cell(4+i,j,v); x.font=bf; x.border=B
            if j==5: x.number_format=NUM
            if j==3: x.number_format='dd-mmm-yyyy'
    for col,w in zip('ABCDEFG',[6,14,13,12,13,16,14]): cs.column_dimensions[col].width=w
    cs.sheet_view.showGridLines=False
    for s in (ws,od,cs):
        s.page_setup.orientation='landscape'; s.page_setup.fitToWidth=1; s.page_setup.fitToHeight=0; s.sheet_properties.pageSetUpPr.fitToPage=True
    wb.save(out)

def tally_xml(dl,cfg,out):
    """One Sales voucher per order, straight from the Order Details figures."""
    E=escape; x=['<ENVELOPE><HEADER><TALLYREQUEST>Import Data</TALLYREQUEST></HEADER><BODY><IMPORTDATA><REQUESTDESC><REPORTNAME>Vouchers</REPORTNAME><STATICVARIABLES>']
    if cfg.get('company'): x.append('<SVCURRENTCOMPANY>%s</SVCURRENTCOMPANY>'%E(cfg['company']))
    x.append('</STATICVARIABLES></REQUESTDESC><REQUESTDATA>')
    def line(name,amt,credit):
        a=amt if credit else -amt
        return '<ALLLEDGERENTRIES.LIST><LEDGERNAME>%s</LEDGERNAME><ISDEEMEDPOSITIVE>%s</ISDEEMEDPOSITIVE><AMOUNT>%.2f</AMOUNT></ALLLEDGERENTRIES.LIST>'%(E(name),'No' if a>0 else 'Yes',a)
    vt=cfg['voucher_type']
    for i,r in dl.iterrows():
        rnd=round(r.inv-r.tax-r.cgst-r.sgst,2)
        nar='Zomato order %s dt %s'%(r.oid,r.odate.strftime('%d-%b-%Y'))
        if str(r.utr) not in ('','nan','None'): nar+=' | UTR %s'%r.utr
        x.append('<TALLYMESSAGE xmlns:UDF="TallyUDF"><VOUCHER VCHTYPE="%s" ACTION="Create" OBJVIEW="Accounting Voucher View">'%E(vt))
        x.append('<DATE>%s</DATE><VOUCHERTYPENAME>%s</VOUCHERTYPENAME><VOUCHERNUMBER>%s</VOUCHERNUMBER><REFERENCE>%s</REFERENCE><PARTYLEDGERNAME>%s</PARTYLEDGERNAME><NARRATION>%s</NARRATION><PERSISTEDVIEW>Accounting Voucher View</PERSISTEDVIEW>'
                 %(r.odate.strftime('%Y%m%d'),E(vt),E(cfg['voucher_prefix']+r.oid),E(r.oid),E(cfg['party_ledger']),E(nar)))
        x.append(line(cfg['party_ledger'],r.inv,False))
        x.append(line(cfg['sales_ledger'],r.tax,True))
        x.append(line(cfg['cgst_ledger'],r.cgst,True)); x.append(line(cfg['sgst_ledger'],r.sgst,True))
        if abs(rnd)>=0.005: x.append(line(cfg['round_off_ledger'],rnd,True))
        x.append('</VOUCHER></TALLYMESSAGE>')
    x.append('</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>')
    open(out,'w',encoding='utf-8').write(''.join(x))

if __name__=='__main__':
    here=os.path.dirname(os.path.abspath(__file__))
    cfg=json.load(open(os.path.join(here,'settings.json'),encoding='utf-8'))
    files=sys.argv[1:] or sorted(glob.glob(os.path.join(here,'Input','*.xlsx')),key=os.path.getmtime)
    files=[f for f in files if not os.path.basename(f).startswith('~$')]
    if not files: sys.exit('No Excel file found. Put the Zomato settlement report in the Input folder.')
    src=files[-1]; print('Reading:',os.path.basename(src))
    rate=cfg.get('gst_rate',5)
    dl,cx,res,rid=load(src,rate)
    tag=dl.odate.min().strftime('%b_%Y'); os.makedirs(os.path.join(here,'Output'),exist_ok=True)
    xl=os.path.join(here,'Output','Zomato_GST_%s.xlsx'%tag); xm=os.path.join(here,'Output','Zomato_Tally_Import_%s.xml'%tag)
    build_excel(dl,cx,res,rid,rate,xl); tally_xml(dl,cfg,xm)
    print('Delivered orders: %d | Cancelled (excluded): %d | Tally vouchers (1 per order): %d'%(len(dl),len(cx),len(dl)))
    print('Taxable %.2f | CGST %.2f | SGST %.2f | Round off %.2f | Total %.2f'%(dl.tax.sum(),dl.cgst.sum(),dl.sgst.sum(),dl.rnd.sum(),dl.inv.sum()))
    print('GST Zomato collected %.2f vs payable %.2f'%(dl.zgst.sum(),dl.cgst.sum()+dl.sgst.sum()))
    print('Saved in Output:',os.path.basename(xl),'|',os.path.basename(xm))
