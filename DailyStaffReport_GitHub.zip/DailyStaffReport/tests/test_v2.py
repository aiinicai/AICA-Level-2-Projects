"""Tests for v2: PIN login, weekly summary, auto email (SMTP mocked), scheduler XML."""
import os, sys, tempfile, shutil
from datetime import date
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
tmp = tempfile.mkdtemp()
os.environ["APPDATA"] = os.path.join(tmp, "appdata")

import dsr_core, dsr_email, demo_data
from dsr_auth import Auth
from dsr_weekly import build_weekly_report, collect_week, week_bounds
from openpyxl import load_workbook

TODAY = date(2026, 11, 24)                      # Tuesday
st = demo_data.make_demo(os.path.join(tmp, "shared"), TODAY)
dsr_core.save_local_settings({"shared_folder": st.root})

# ---------------- auth
a = Auth(st)
assert a.staff_login("Amit Verma", "0000") == (True, True)          # first login -> must change
assert a.staff_login("Amit Verma", "1111") == (False, False)
for bad in ("12", "0000", "1234", "7777", "abcd"):
    try:
        a.set_staff_pin("Amit Verma", bad); raise AssertionError(bad)
    except ValueError:
        pass
a.set_staff_pin("Amit Verma", "5829")
assert a.staff_login("Amit Verma", "5829") == (True, False)
assert a.staff_login("Amit Verma", "0000")[0] is False
raw = open(os.path.join(st.root, "security", "Amit_Verma.json")).read()
assert "5829" not in raw                                           # PIN never stored in clear
a.reset_staff_pin("Amit Verma")
assert a.staff_login("Amit Verma", "0000") == (True, True)
assert a.admin_login("1234") and not a.admin_login("9999")         # default admin PIN
a.set_admin_pin("8642")
assert a.admin_login("8642") and not a.admin_login("1234")
assert "admin_pin" not in st.masters_raw() and "8642" not in open(st.masters_path).read()
# masters edits by admin keep the hashed PIN
m = st.masters(); m["clients"].append("New Client"); st.save_masters(m)
assert a.admin_login("8642")
# recovery: plain admin_pin line wins
m = st.masters_raw(); m["admin_pin"] = "1234"; st.save_masters(m)
assert a.admin_login("1234")
print("auth ok")

# ---------------- weekly
assert week_bounds("2026-11-24") == ("2026-11-23", "2026-11-29")
data = collect_week(st, "2026-11-23", "2026-11-29")
ids = [t["id"] for t in data["tasks"]]
assert len(ids) == len(set(ids))
gst = [t for t in data["tasks"] if t["description"] == "GSTR-3B for October"][0]
assert gst["hours"] == 1.0 and gst["first_seen"] == "2026-11-23"   # 0.5 Mon + 0.5 Tue
out = build_weekly_report(st, "2026-11-25")
wb = load_workbook(out)
assert wb.sheetnames == ["Week Dashboard", "Daily Trend", "Client-wise", "Work-wise",
                         "Staff-wise", "Pending at Week End", "Task Register"]
dash = {r[0].value: r[1].value for r in wb["Week Dashboard"].iter_rows(min_row=4, max_row=10)}
assert dash["Days with reports"] == 2, dash
pend_rows = [r for r in wb["Pending at Week End"].iter_rows(min_row=5, values_only=True) if r[0]]
assert len(pend_rows) == dash["Still pending at week end"]
assert len(wb["Daily Trend"]._charts) == 1
print("weekly ok", dash)

# ---------------- email (SMTP mocked); pin "today" so the test works on any date
class FixedDate(date):
    @classmethod
    def today(cls): return cls(2026, 11, 24)
dsr_email.date = FixedDate
sent = {}
class FakeSMTP:
    def __init__(self, host, port, context=None, timeout=None):
        sent["host"] = (host, port)
    def __enter__(self): return self
    def __exit__(self, *a): pass
    def login(self, u, p): sent["login"] = (u, p)
    def send_message(self, msg): sent["msg"] = msg
dsr_email.smtplib.SMTP_SSL = FakeSMTP
dsr_email.save_email_settings("firm@gmail.com", "abcd efgh ijkl mnop", "partner@gmail.com, x@y.com",
                              "19:00", "Tuesday")
assert "abcdefghijklmnop" not in open(dsr_core.local_settings_path()).read()
assert dsr_email.auto_email_main() == 0
assert sent["host"] == ("smtp.gmail.com", 465)
assert sent["login"] == ("firm@gmail.com", "abcdefghijklmnop")
msg = sent["msg"]
names = [p.get_filename() for p in msg.iter_attachments()]
assert names[0].startswith("Daily_Report_") and names[1].startswith("Weekly_Report_"), names
assert "weekly summary" in msg["Subject"] and msg["To"] == "partner@gmail.com, x@y.com"
html = msg.get_body(("html",)).get_content()
assert "Sneha Iyer" in html and "Ledger export from Tally" in html     # not submitted + data awaited
sent.clear()
assert dsr_email.auto_email_main() == 0 and not sent                  # once per day only
log = open(os.path.join(os.environ["APPDATA"], "DailyStaffReport", "email_log.txt")).read()
assert "SENT:" in log and "skipped" in log
print("email ok:", msg["Subject"])

# ---------------- scheduler XML
x = dsr_email.task_xml("19:00")
assert "T19:00:00" in x and "--auto-email" in x and "<StartWhenAvailable>true" in x
import xml.dom.minidom; xml.dom.minidom.parseString(x.replace('encoding="UTF-16"', ''))
print("ALL V2 TESTS PASSED")
shutil.rmtree(tmp)
