import os, shutil, sys, tempfile
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from openpyxl import load_workbook
from dsr_core import Store, new_task, REASON_DATA, STATUS_PENDING, STATUS_COMPLETED

tmp = tempfile.mkdtemp()
st = Store(tmp)
m = st.masters(); m["staff"] = ["Asha", "Ravi", "Neha"]; m["clients"] = ["ABC Ltd", "XYZ & Co"]
st.save_masters(m)

D1, D2, D3 = "2026-11-20", "2026-11-23", "2026-11-24"   # Fri, Mon (weekend skipped), Tue
p1 = new_task(client="ABC Ltd", work_type="GST Return Filing", description="GSTR-3B Oct",
              status=STATUS_PENDING, pending_reason=REASON_DATA, awaited_details="Purchase register",
              origin_date=D1, hours=1)
p2 = new_task(client="XYZ & Co", work_type="TDS Return", description="24Q Q2",
              status=STATUS_PENDING, pending_reason="Work in progress (will continue)", origin_date=D1)
c1 = new_task(client="XYZ & Co", work_type="Income Tax Return", description="ITR-3 filed",
              status=STATUS_COMPLETED, hours=2, origin_date=D1)
st.save_sheet("Asha", D1, [p1, p2, c1])

# Day 2: opening sheet carries the 2 pending tasks across the weekend
op = st.opening_tasks("Asha", D2)
assert [t["id"] for t in op] == [p1["id"], p2["id"]] and all(t["carried"] for t in op), op
tasks, saved = st.sheet_for_day("Asha", D2)
assert saved is None and len(tasks) == 2
tasks[1].update(status=STATUS_COMPLETED)                  # TDS finished
st.save_sheet("Asha", D2, tasks)

# Day 3: only GST (still pending) carried, origin date preserved -> ageing 4 days
op = st.opening_tasks("Asha", D3)
assert len(op) == 1 and op[0]["id"] == p1["id"] and op[0]["origin_date"] == D1

# delete a carried task -> must not reappear after reload
st.save_sheet("Asha", D3, [], dropped_ids=[p1["id"]])
tasks, saved = st.sheet_for_day("Asha", D3)
assert tasks == [], tasks
# put it back as pending for report test
p1b = dict(op[0]); st.save_sheet("Asha", D3, [p1b])
tasks, _ = st.sheet_for_day("Asha", D3)
assert len(tasks) == 1

st.save_sheet("Ravi", D3, [new_task(client="ABC Ltd", work_type="Tax Audit", description="3CD clauses",
                                    status=STATUS_COMPLETED, hours=5, origin_date=D3)])
status = st.submission_status(D3)
assert [s[0] for s in status if not s[1]] == ["Neha"], status

out = st.compile_report(D3)
wb = load_workbook(out)
assert wb.sheetnames == ["Dashboard", "Client-wise", "Work-wise", "Staff-wise",
                         "Pending - Next Day Opening", "Data Awaited - Follow-up", "All Entries"]
pend = wb["Pending - Next Day Opening"]
assert pend["A5"].value == "ABC Ltd" and pend["I5"].value == 4, (pend["A5"].value, pend["I5"].value)
fu = wb["Data Awaited - Follow-up"]
assert fu["C5"].value == "Purchase register"
dash = {r[0].value: r[1].value for r in wb["Dashboard"].iter_rows(min_row=4, max_row=11)}
assert dash["Staff submitted"] == "2 of 3" and dash["Not yet submitted"] == "Neha"
assert dash["Pending (carried to next day)"] == 1
print("ALL TESTS PASSED ->", out)
shutil.rmtree(tmp)
