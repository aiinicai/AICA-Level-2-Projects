"""Drives the real Tkinter screens (v2: PIN login, weekly, email tabs) and takes screenshots."""
import os, shutil, subprocess, sys, tempfile
from datetime import date
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
tmp = tempfile.mkdtemp()
os.environ["APPDATA"] = os.path.join(tmp, "appdata")
shared = os.path.join(tmp, "shared")
import demo_data, dsr_app, dsr_core, dsr_email
from tkinter import messagebox, simpledialog
demo_data.make_demo(shared, date(2026, 11, 24))
dsr_core.save_local_settings({"shared_folder": shared, "last_staff": "Amit Verma"})
dsr_email.save_email_settings("sharma.associates@gmail.com", "abcdefghijklmnop",
                              "partner@gmail.com", "19:00", "Saturday")

log, answers = [], []
for fn in ("showinfo", "showwarning", "showerror"):
    setattr(messagebox, fn, lambda *a, _f=fn, **k: log.append((_f, a[1] if len(a) > 1 else "")))
messagebox.askyesno = lambda *a, **k: (log.append(("ask", a[1])), True)[1]
simpledialog.askstring = lambda *a, **k: answers.pop(0)
dsr_app.open_path = lambda p: log.append(("open", p))
OUT = sys.argv[1]
app = dsr_app.App()
app.date_var.set("24-11-2026"); app.loaded_key = None; app._load_sheet()

def shot(name):
    app.update(); app.update_idletasks()
    subprocess.run(["import", "-window", "root", os.path.join(OUT, name)], check=True)

def login(name, pin, new=None):
    app.staff_cb.set(name); app.pin_var.set(pin)
    if new: answers.extend([new, new])
    app._login()

def step1():
    shot("01_login_screen.png")
    login("Amit Verma", "9999")
    assert app.user is None and log[-1][0] == "showerror"
    login("Amit Verma", "0000", new="5829")              # first login -> sets own PIN
    assert app.user == "Amit Verma", log
    shot("02_staff_sheet_carried_forward.png")
    app._logout(); login("Amit Verma", "5829"); assert app.user == "Amit Verma"
    app._logout()
    login("Sneha Iyer", "0000", new="4826")
    app.client_cb.set("Green Valley Foods LLP"); app.work_cb.set("Income Tax Return")
    app.desc_var.set("ITR-5 computation"); app.status_var.set("Pending"); app._toggle_pending()
    app.reason_cb.set(dsr_core.REASON_DATA); app.awaited_var.set("Form 26AS & AIS")
    app.hours_var.set("2"); app._add_or_update()
    app.client_cb.set("Kapoor Traders"); app.work_cb.set("GST Return Filing")
    app.desc_var.set("GSTR-1 October"); app.hours_var.set("1.5"); app._add_or_update()
    shot("03_new_entries_before_submit.png")
    app._submit()
    assert dsr_core.Store(shared).load_sheet("Sneha Iyer", "2026-11-24")
    app.after(300, step2)

def step2():
    answers.append("1234")
    app._open_admin()
    adm = [w for w in app.winfo_children() if isinstance(w, dsr_app.AdminWindow)][0]
    app.update(); shot("04_admin_day_end_compile.png")
    adm._compile()
    p = [l for l in log if l[0] == "open"][-1][1]
    shutil.copy(p, os.path.join(OUT, "Sample_Daily_Report.xlsx"))
    nb = adm.winfo_children()[0]
    nb.select(1); app.update(); shot("05_admin_weekly_summary.png")
    adm._compile_week()
    p = [l for l in log if l[0] == "open"][-1][1]
    assert "Weekly_Report_2026-11-23_to_2026-11-29" in p
    shutil.copy(p, os.path.join(OUT, "Sample_Weekly_Report.xlsx"))
    nb.select(2); app.update(); shot("06_admin_auto_email.png")
    nb.select(3); app.update()
    lb = adm.lists["staff"]; lb.selection_set(0); adm._reset_pin()
    shot("07_admin_masters_reset_pin.png")
    adm.destroy()
    app._logout(); login("Sneha Iyer", "4826")
    app.date_var.set("25-11-2026"); app.loaded_key = None; app._load_sheet()
    assert [t["description"] for t in app.tasks] == ["ITR-5 computation"], app.tasks
    shot("08_next_day_opening_sheet.png")
    print("GUI SMOKE PASSED")
    app.destroy()

app.after(800, step1)
app.mainloop()
