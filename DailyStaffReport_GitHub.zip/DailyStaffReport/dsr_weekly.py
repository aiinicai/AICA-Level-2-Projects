"""Weekly summary workbook (Monday–Sunday week containing the chosen date)."""

from __future__ import annotations

from collections import OrderedDict, defaultdict
from datetime import timedelta

from openpyxl import Workbook
from openpyxl.chart import BarChart, Reference
from openpyxl.styles import Alignment, Font

from dsr_core import (REASON_DATA, STATUS_COMPLETED, STATUS_PENDING, days_pending, iso,
                      parse_iso, to_display)
from dsr_report import (BOLD, BOX, DETAIL_COLS, F_DATA, F_DONE, F_HEAD, F_MISS, F_PEND,
                        F_SUB, NAVY, WHITE_B, WRAP, _detail_row, _header, _summary_table,
                        _title)


def week_bounds(day: str) -> tuple[str, str]:
    d = parse_iso(day)
    mon = d - timedelta(days=d.weekday())
    return iso(mon), iso(mon + timedelta(days=6))


def _days(start: str, end: str):
    d, e = parse_iso(start), parse_iso(end)
    while d <= e:
        yield iso(d)
        d += timedelta(days=1)


def collect_week(store, start: str, end: str) -> dict:
    """Merges the week's daily sheets. A task carried over several days is counted once:
    its final status is the last day it appears, its hours are summed across days."""
    per_day = OrderedDict()
    tasks: dict[str, dict] = {}
    latest_sheet: dict[str, dict] = {}
    for day in _days(start, end):
        sheets = store.all_sheets(day)
        per_day[day] = sheets
        for s in sheets:
            latest_sheet[s["staff"]] = s
            for t in s.get("tasks", []):
                agg = tasks.get(t["id"])
                if agg is None:
                    agg = tasks[t["id"]] = {**t, "staff": s["staff"], "hours": 0.0,
                                            "first_seen": day}
                hrs = float(t.get("hours") or 0)
                agg.update({k: t.get(k, "") for k in ("client", "work_type", "description",
                                                      "status", "pending_reason",
                                                      "awaited_details", "remarks")})
                agg["hours"] += hrs
                agg["last_seen"] = day
    return {"per_day": per_day, "tasks": list(tasks.values()), "latest_sheet": latest_sheet}


def build_weekly_report(store, any_day: str, out_path: str | None = None) -> str:
    import os
    start, end = week_bounds(any_day)
    out_path = out_path or os.path.join(store.reports_dir, f"Weekly_Report_{start}_to_{end}.xlsx")
    m = store.masters()
    firm = m.get("firm_name") or "Firm"
    data = collect_week(store, start, end)
    per_day, tasks = data["per_day"], data["tasks"]
    period = f"{to_display(start)} to {to_display(end)}"
    staff_names = list(m["staff"])
    for s in data["latest_sheet"]:
        if s not in staff_names:
            staff_names.append(s)
    working_days = [d for d, sh in per_day.items() if sh]

    pend_end = []
    for staff, s in data["latest_sheet"].items():
        for t in s.get("tasks", []):
            if t.get("status") == STATUS_PENDING:
                pend_end.append({**t, "staff": staff, "_days": days_pending(t, end)})

    wb = Workbook()

    # 1. Dashboard + reporting grid --------------------------------------------
    ws = wb.active
    ws.title = "Week Dashboard"
    _title(ws, firm, f"Weekly Summary ({period})", end, 9)
    ws["A2"] = f"Week: {period}"
    done = [t for t in tasks if t["status"] == STATUS_COMPLETED]
    kpis = [
        ("Days with reports", len(working_days)),
        ("Tasks worked on (unique)", len(tasks)),
        ("Completed during the week", len(done)),
        ("Still pending at week end", len(pend_end)),
        ("   of which: data awaited from client", sum(t.get("pending_reason") == REASON_DATA
                                                       for t in pend_end)),
        ("   of which: pending 7+ days", sum(t["_days"] >= 7 for t in pend_end)),
        ("Total hours logged", round(sum(t["hours"] for t in tasks), 2)),
    ]
    r = 4
    for k, v in kpis:
        a, b = ws.cell(row=r, column=1, value=k), ws.cell(row=r, column=2, value=v)
        a.font, a.fill, a.border, b.border = BOLD, F_SUB, BOX, BOX
        r += 1
    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 14
    r += 1
    ws.cell(row=r, column=1, value="Daily reporting by staff (✓ submitted, ✗ missing)").font = \
        Font(bold=True, size=12, color=NAVY)
    r += 1
    days = list(per_day.keys())
    heads = ["Staff"] + [f"{parse_iso(d).strftime('%a')}\n{to_display(d)[:5]}" for d in days]
    for i, h in enumerate(heads, 1):
        c = ws.cell(row=r, column=i, value=h)
        c.fill, c.font, c.border = F_HEAD, WHITE_B, BOX
        c.alignment = Alignment(horizontal="center", wrap_text=True)
        if i > 2:
            ws.column_dimensions[c.column_letter].width = 11
    ws.row_dimensions[r].height = 30
    submitted = {d: {s["staff"] for s in sh} for d, sh in per_day.items()}
    for name in staff_names:
        r += 1
        ws.cell(row=r, column=1, value=name).border = BOX
        for i, d in enumerate(days, 2):
            ok = name in submitted[d]
            c = ws.cell(row=r, column=i, value="✓" if ok else ("✗" if d in working_days else "–"))
            c.alignment = Alignment(horizontal="center")
            c.border = BOX
            c.fill = F_DONE if ok else (F_MISS if d in working_days else F_SUB)

    # 2. Daily trend + chart ------------------------------------------------------
    ws = wb.create_sheet("Daily Trend")
    _title(ws, firm, "Day-by-day Activity", end, 10)
    ws["A2"] = f"Week: {period}"
    cols = [("Day", 18), ("Staff Reported", 14), ("Tasks", 9), ("Completed", 11),
            ("Pending", 10), ("Hours", 9)]
    _header(ws, 4, cols)
    r = 5
    for d, sheets in per_day.items():
        ts = [t for s in sheets for t in s.get("tasks", [])]
        c_done = sum(t.get("status") == STATUS_COMPLETED for t in ts)
        vals = [f"{parse_iso(d).strftime('%a')} {to_display(d)}", len(sheets), len(ts), c_done,
                len(ts) - c_done, round(sum(float(t.get("hours") or 0) for t in ts), 2)]
        for i, v in enumerate(vals, 1):
            ws.cell(row=r, column=i, value=v).border = BOX
        r += 1
    ch = BarChart()
    ch.type, ch.grouping, ch.overlap = "col", "stacked", 100
    ch.title, ch.y_axis.title = "Tasks completed vs pending by day", "Tasks"
    ch.add_data(Reference(ws, min_col=4, max_col=5, min_row=4, max_row=r - 1), titles_from_data=True)
    ch.set_categories(Reference(ws, min_col=1, min_row=5, max_row=r - 1))
    ch.series[0].graphicalProperties.solidFill = "70AD47"
    ch.series[1].graphicalProperties.solidFill = "FFC000"
    ch.height, ch.width = 8, 18
    ws.add_chart(ch, f"A{r + 2}")

    # 3-5. Client / Work / Staff summaries (unique tasks, summed hours) ----------
    for name, key, label in (("Client-wise", "client", "Client"),
                             ("Work-wise", "work_type", "Work Type"),
                             ("Staff-wise", "staff", "Staff")):
        ws = wb.create_sheet(name)
        _title(ws, firm, f"{label}-wise Summary for the Week", end, 7)
        ws["A2"] = f"Week: {period}   |   'Pending' = still pending at week end"
        _summary_table(ws, 4, key, tasks, label)
        ws.freeze_panes = "A5"

    # 6. Pending at week end -------------------------------------------------------
    ws = wb.create_sheet("Pending at Week End")
    _title(ws, firm, "Pending at Week End (carry into next week)", end, 11)
    ws["A2"] = f"Week: {period}"
    _header(ws, 4, DETAIL_COLS)
    r = 5
    for t in sorted(pend_end, key=lambda x: (-x["_days"], x["staff"])):
        _detail_row(ws, r, t, end)
        r += 1
    if not pend_end:
        ws.cell(row=5, column=1, value="No pending tasks at week end.")
    ws.freeze_panes = "A5"

    # 7. Task register -------------------------------------------------------------
    ws = wb.create_sheet("Task Register")
    _title(ws, firm, "All Tasks Worked On This Week", end, 9)
    ws["A2"] = f"Week: {period}"
    cols = [("Client", 24), ("Work Type", 22), ("Staff", 16), ("Task Description", 40),
            ("First Reported", 13), ("Last Reported", 13), ("Final Status", 12),
            ("Pending Reason", 30), ("Total Hours", 10)]
    _header(ws, 4, cols)
    r = 5
    for t in sorted(tasks, key=lambda x: (str(x["client"]).lower(), x["staff"])):
        pend = t["status"] == STATUS_PENDING
        vals = [t["client"], t["work_type"], t["staff"], t["description"],
                to_display(t.get("origin_date") or t["first_seen"]), to_display(t["last_seen"]),
                t["status"], t.get("pending_reason") if pend else "", round(t["hours"], 2)]
        fill = (F_DATA if t.get("pending_reason") == REASON_DATA else F_PEND) if pend else F_DONE
        for i, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border, c.alignment, c.fill = BOX, WRAP, fill
        r += 1
    ws.auto_filter.ref = f"A4:I{max(r - 1, 4)}"
    ws.freeze_panes = "A5"

    for w in wb.worksheets:
        w.sheet_view.showGridLines = False
        w.page_setup.orientation = "landscape"
        w.sheet_properties.pageSetUpPr.fitToPage = True
        w.page_setup.fitToHeight = 0
    wb.save(out_path)
    return out_path
