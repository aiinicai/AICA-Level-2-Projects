"""
Daily Staff Report (DSR) - core data layer.

Storage layout inside the SHARED folder (LAN drive / OneDrive / Google Drive):

    <shared>/
        masters.json                  admin-managed lists (staff, clients, work types), firm name, PIN
        entries/YYYY-MM-DD/<staff>.json   one file per staff per day (no write clashes)
        reports/Daily_Report_YYYY-MM-DD.xlsx  compiled day-end reports

Each staff member writes only their own file, so 10 people can save at the
same time on a shared folder without overwriting each other.
"""

from __future__ import annotations

import json
import os
import re
import uuid
from datetime import date, datetime, timedelta

APP_NAME = "Daily Staff Report"
APP_VERSION = "2.0"

STATUS_COMPLETED = "Completed"
STATUS_PENDING = "Pending"
STATUSES = [STATUS_COMPLETED, STATUS_PENDING]

REASON_DATA = "Data / documents awaited from client"
PENDING_REASONS = [
    REASON_DATA,
    "Work in progress (will continue)",
    "Query / clarification awaited from client",
    "Awaiting review / approval by partner",
    "Govt. portal / technical issue",
    "Other",
]

DEFAULT_MASTERS = {
    "firm_name": "My CA Firm",
    "admin_pin": "1234",
    "staff": ["Staff 1", "Staff 2"],
    "clients": ["Client A", "Client B"],
    "work_types": [
        "GST Return Filing",
        "GST Reconciliation",
        "Income Tax Return",
        "TDS Return",
        "Tax Audit",
        "Statutory Audit",
        "Internal Audit",
        "Accounting / Bookkeeping",
        "ROC / MCA Compliance",
        "Payroll / PF / ESI",
        "Notice / Assessment Reply",
        "Certification",
        "Project Report / CMA",
        "Other",
    ],
}

TASK_FIELDS = [
    "id", "client", "work_type", "description", "status", "pending_reason",
    "awaited_details", "hours", "remarks", "origin_date", "carried",
]


# --------------------------------------------------------------------------- helpers
def iso(d: date) -> str:
    return d.strftime("%Y-%m-%d")


def parse_iso(s: str) -> date:
    return datetime.strptime(s, "%Y-%m-%d").date()


def to_display(s: str) -> str:
    """YYYY-MM-DD -> DD-MM-YYYY (Indian style)."""
    try:
        return parse_iso(s).strftime("%d-%m-%Y")
    except Exception:
        return s or ""


def from_display(s: str) -> str:
    """DD-MM-YYYY (or DD/MM/YYYY) -> YYYY-MM-DD. Raises ValueError if invalid."""
    s = s.strip().replace("/", "-").replace(".", "-")
    return iso(datetime.strptime(s, "%d-%m-%Y").date())


def safe_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name.strip()) or "unnamed"


def _atomic_write_json(path: str, data) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = f"{path}.{uuid.uuid4().hex[:6]}.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(tmp, path)


def _read_json(path: str, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return default


def new_task(**kw) -> dict:
    t = {k: "" for k in TASK_FIELDS}
    t.update(id=uuid.uuid4().hex[:10], status=STATUS_COMPLETED, hours=0.0, carried=False)
    t.update(kw)
    return t


def days_pending(task: dict, on_date: str) -> int:
    try:
        return (parse_iso(on_date) - parse_iso(task.get("origin_date") or on_date)).days
    except Exception:
        return 0


# --------------------------------------------------------------------------- local settings
def local_settings_path() -> str:
    base = os.environ.get("APPDATA") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, "DailyStaffReport", "settings.json")


def load_local_settings() -> dict:
    return _read_json(local_settings_path(), {}) or {}


def save_local_settings(s: dict) -> None:
    _atomic_write_json(local_settings_path(), s)


# --------------------------------------------------------------------------- store
class Store:
    def __init__(self, shared_folder: str):
        self.root = shared_folder
        os.makedirs(self.entries_dir, exist_ok=True)
        os.makedirs(self.reports_dir, exist_ok=True)
        if not os.path.exists(self.masters_path):
            _atomic_write_json(self.masters_path, DEFAULT_MASTERS)

    # paths
    @property
    def masters_path(self):
        return os.path.join(self.root, "masters.json")

    @property
    def entries_dir(self):
        return os.path.join(self.root, "entries")

    @property
    def reports_dir(self):
        return os.path.join(self.root, "reports")

    def day_dir(self, day: str):
        return os.path.join(self.entries_dir, day)

    def staff_file(self, staff: str, day: str):
        return os.path.join(self.day_dir(day), safe_name(staff) + ".json")

    # masters
    def masters_raw(self) -> dict:
        """masters.json exactly as stored (used for PIN handling)."""
        return _read_json(self.masters_path, None) or dict(DEFAULT_MASTERS)

    def masters(self) -> dict:
        m = {k: v for k, v in DEFAULT_MASTERS.items() if k != "admin_pin"}
        m.update(self.masters_raw())
        return m

    def save_masters(self, m: dict) -> None:
        for k in ("staff", "clients", "work_types"):
            m[k] = sorted({x.strip() for x in m.get(k, []) if x and x.strip()}, key=str.lower)
        _atomic_write_json(self.masters_path, m)

    # daily sheets
    def load_sheet(self, staff: str, day: str):
        return _read_json(self.staff_file(staff, day))

    def save_sheet(self, staff: str, day: str, tasks: list, dropped_ids=()) -> dict:
        prev = self.load_sheet(staff, day) or {}
        dropped = sorted(set(prev.get("dropped_ids", [])) | set(dropped_ids))
        sheet = {
            "staff": staff,
            "date": day,
            "submitted_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "app_version": APP_VERSION,
            "tasks": tasks,
            "dropped_ids": dropped,
        }
        _atomic_write_json(self.staff_file(staff, day), sheet)
        return sheet

    def previous_sheet(self, staff: str, day: str):
        """Most recent sheet of this staff BEFORE `day` (handles holidays / leave)."""
        if not os.path.isdir(self.entries_dir):
            return None
        fname = safe_name(staff) + ".json"
        days = sorted((d for d in os.listdir(self.entries_dir)
                       if re.fullmatch(r"\d{4}-\d{2}-\d{2}", d) and d < day), reverse=True)
        for d in days:
            p = os.path.join(self.entries_dir, d, fname)
            if os.path.exists(p):
                return _read_json(p)
        return None

    def opening_tasks(self, staff: str, day: str) -> list:
        """Pending tasks carried into `day`'s opening sheet."""
        prev = self.previous_sheet(staff, day)
        if not prev:
            return []
        out = []
        for t in prev.get("tasks", []):
            if t.get("status") == STATUS_PENDING:
                c = dict(t)
                c["carried"] = True
                c["origin_date"] = t.get("origin_date") or prev["date"]
                c["hours"] = 0.0
                out.append(c)
        return out

    def sheet_for_day(self, staff: str, day: str):
        """Returns (tasks, saved_sheet_or_None). If not yet saved, starts from the opening sheet.
        If saved, also merges any pending items carried later (e.g. a back-dated entry)."""
        saved = self.load_sheet(staff, day)
        opening = self.opening_tasks(staff, day)
        if saved is None:
            return opening, None
        tasks = list(saved.get("tasks", []))
        have = {t["id"] for t in tasks} | set(saved.get("dropped_ids", []))
        tasks = [t for t in opening if t["id"] not in have] + tasks
        return tasks, saved

    def all_sheets(self, day: str) -> list:
        d = self.day_dir(day)
        if not os.path.isdir(d):
            return []
        out = []
        for f in sorted(os.listdir(d)):
            if f.endswith(".json"):
                s = _read_json(os.path.join(d, f))
                if s:
                    out.append(s)
        return out

    def submission_status(self, day: str) -> list:
        """[(staff, submitted_at or None, n_tasks, n_completed, n_pending)]"""
        sheets = {s["staff"]: s for s in self.all_sheets(day)}
        names = list(self.masters()["staff"])
        for extra in sheets:
            if extra not in names:
                names.append(extra)
        rows = []
        for n in names:
            s = sheets.get(n)
            if s:
                ts = s.get("tasks", [])
                done = sum(1 for t in ts if t.get("status") == STATUS_COMPLETED)
                rows.append((n, s.get("submitted_at"), len(ts), done, len(ts) - done))
            else:
                rows.append((n, None, 0, 0, 0))
        return rows

    # compile
    def compile_report(self, day: str, out_path: str | None = None) -> str:
        from dsr_report import build_report  # local import keeps startup fast
        out_path = out_path or os.path.join(self.reports_dir, f"Daily_Report_{day}.xlsx")
        build_report(self, day, out_path)
        return out_path
