"""
PIN login for staff and admin.

* Staff PINs: one small file per staff in <shared>/security/<staff>.json, holding only a
  salted PBKDF2 hash (the PIN itself is never stored). Each staff member writes only
  their own file, so there are no write clashes on Google Drive.
* New staff (or after an admin reset) log in with the default PIN 0000 and must set
  their own 4-digit PIN immediately.
* Admin PIN: hashed inside masters.json. For recovery, the admin can add the line
  "admin_pin": "1234" to masters.json; a plain admin_pin always takes priority.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import secrets
from datetime import datetime

from dsr_core import _atomic_write_json, _read_json, safe_name

DEFAULT_STAFF_PIN = "0000"
_ITER = 100_000


def _hash(pin: str, salt_hex: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", pin.encode(), bytes.fromhex(salt_hex), _ITER).hex()


def make_record(pin: str, must_change: bool = False) -> dict:
    salt = secrets.token_hex(16)
    return {"salt": salt, "hash": _hash(pin, salt), "must_change": must_change,
            "updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}


def check_record(pin: str, rec: dict) -> bool:
    try:
        return hmac.compare_digest(_hash(pin, rec["salt"]), rec["hash"])
    except Exception:
        return False


def valid_new_pin(pin: str) -> str | None:
    """Returns an error message, or None if the PIN is acceptable."""
    if not (len(pin) == 4 and pin.isdigit()):
        return "PIN must be exactly 4 digits."
    if pin == DEFAULT_STAFF_PIN:
        return "Please choose a PIN other than 0000."
    if len(set(pin)) == 1 or pin in ("1234", "4321"):
        return "PIN is too easy to guess. Choose another."
    return None


class Auth:
    def __init__(self, store):
        self.store = store
        self.dir = os.path.join(store.root, "security")
        os.makedirs(self.dir, exist_ok=True)

    def _path(self, staff: str) -> str:
        return os.path.join(self.dir, safe_name(staff) + ".json")

    # ---------------- staff
    def staff_login(self, staff: str, pin: str) -> tuple[bool, bool]:
        """(ok, must_change)."""
        rec = _read_json(self._path(staff))
        if not rec:
            ok = pin == DEFAULT_STAFF_PIN
            return ok, ok
        ok = check_record(pin, rec)
        return ok, ok and bool(rec.get("must_change"))

    def set_staff_pin(self, staff: str, new_pin: str) -> None:
        err = valid_new_pin(new_pin)
        if err:
            raise ValueError(err)
        _atomic_write_json(self._path(staff), make_record(new_pin))

    def reset_staff_pin(self, staff: str) -> None:
        """Admin action: staff must log in with 0000 and choose a new PIN."""
        try:
            os.remove(self._path(staff))
        except FileNotFoundError:
            pass

    def has_own_pin(self, staff: str) -> bool:
        rec = _read_json(self._path(staff))
        return bool(rec) and not rec.get("must_change")

    # ---------------- admin
    def admin_login(self, pin: str) -> bool:
        m = self.store.masters_raw()
        if m.get("admin_pin"):                      # plain PIN (default / recovery)
            return hmac.compare_digest(str(m["admin_pin"]), pin)
        rec = m.get("admin_pin_record")
        return bool(rec) and check_record(pin, rec)

    def set_admin_pin(self, pin: str) -> None:
        if len(pin) < 4:
            raise ValueError("Admin PIN should be at least 4 characters.")
        m = self.store.masters_raw()
        m.pop("admin_pin", None)
        m["admin_pin_record"] = make_record(pin)
        self.store.save_masters(m)
