"""
Daily Staff Report — desktop app (Tkinter).

Staff:  pick your name + date -> opening sheet shows yesterday's pending tasks ->
        add today's work client-wise / work-wise -> mark Completed or Pending (with reason)
        -> Save & Submit.
Admin:  PIN-protected panel to see who has submitted, compile the day-end Excel report,
        and manage the staff / client / work-type master lists.
"""

from __future__ import annotations

import os
import subprocess
import sys
import tkinter as tk
from datetime import date, datetime, timedelta
from tkinter import filedialog, messagebox, simpledialog, ttk

from dsr_auth import DEFAULT_STAFF_PIN, Auth, valid_new_pin
from dsr_core import (APP_NAME, APP_VERSION, PENDING_REASONS, REASON_DATA,
                      STATUS_COMPLETED, STATUS_PENDING, Store, days_pending,
                      from_display, iso, load_local_settings, local_settings_path, new_task,
                      parse_iso, save_local_settings, to_display)

BG = "#F4F6FA"
NAVY = "#1F3864"
ACCENT = "#2E75B6"


def open_path(path: str) -> None:
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore[attr-defined]
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:  # pragma: no cover
        messagebox.showerror(APP_NAME, f"Could not open:\n{path}\n\n{e}")


class FilterCombo(ttk.Combobox):
    """Combobox that narrows its dropdown as you type (handy for long client lists)."""

    def __init__(self, master, values=(), **kw):
        super().__init__(master, values=list(values), **kw)
        self._all = list(values)
        self.bind("<KeyRelease>", self._filter)

    def set_values(self, values):
        self._all = list(values)
        self["values"] = self._all

    def _filter(self, e):
        if e.keysym in ("Up", "Down", "Return", "Tab", "Escape"):
            return
        txt = self.get().strip().lower()
        self["values"] = [v for v in self._all if txt in v.lower()] if txt else self._all

    def valid(self) -> bool:
        return self.get().strip() in self._all


# =========================================================================== main window
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(f"{APP_NAME} v{APP_VERSION}")
        self.geometry("1250x760")
        self.minsize(1050, 650)
        self.configure(bg=BG)
        self._style()

        self.settings = load_local_settings()
        self.store: Store | None = None
        self.user: str | None = None
        self.tasks: list[dict] = []
        self.dropped: set[str] = set()
        self.dirty = False
        self.edit_id: str | None = None
        self.loaded_key = None

        if not self._connect_shared_folder():
            self.destroy()
            return
        self._build()
        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(100, self._load_sheet)

    # ------------------------------------------------------------------ setup
    def _style(self):
        s = ttk.Style(self)
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure(".", background=BG, font=("Segoe UI", 10))
        s.configure("TLabelframe", background=BG)
        s.configure("TLabelframe.Label", background=BG, foreground=NAVY,
                    font=("Segoe UI", 10, "bold"))
        s.configure("Head.TLabel", background=NAVY, foreground="white",
                    font=("Segoe UI", 15, "bold"))
        s.configure("Sub.TLabel", background=NAVY, foreground="#D9E1F2", font=("Segoe UI", 9))
        s.configure("Status.TLabel", font=("Segoe UI", 10, "bold"))
        s.configure("Big.TButton", font=("Segoe UI", 11, "bold"), padding=8)
        s.configure("Treeview", rowheight=26, font=("Segoe UI", 9))
        s.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"), background="#D9E1F2")

    def _connect_shared_folder(self, force=False) -> bool:
        folder = self.settings.get("shared_folder")
        if force or not folder or not os.path.isdir(folder):
            messagebox.showinfo(
                APP_NAME,
                "Select the SHARED folder where all staff reports are kept.\n\n"
                "Use the same folder on every staff computer — e.g. an office network "
                "drive, or a OneDrive / Google Drive folder shared with all staff.",
            )
            folder = filedialog.askdirectory(title="Select shared Daily Report folder")
            if not folder:
                return bool(self.store)
        try:
            self.store = Store(folder)
            self.auth = Auth(self.store)
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Cannot use this folder:\n{folder}\n\n{e}")
            return False
        self.settings["shared_folder"] = folder
        save_local_settings(self.settings)
        return True

    # ------------------------------------------------------------------ layout
    def _build(self):
        m = self.store.masters()

        head = tk.Frame(self, bg=NAVY)
        head.pack(fill="x")
        self.firm_lbl = ttk.Label(head, text=m["firm_name"], style="Head.TLabel")
        self.firm_lbl.pack(side="left", padx=14, pady=(8, 0))
        ttk.Label(head, text="  Daily Staff Work Report", style="Sub.TLabel").pack(
            side="left", pady=(14, 0))
        ttk.Button(head, text="⚙ Admin / Day-End Compile", command=self._open_admin).pack(
            side="right", padx=10, pady=8)
        ttk.Button(head, text="Shared folder…", command=self._change_folder).pack(
            side="right", pady=8)

        # selection bar
        bar = ttk.Frame(self, padding=(12, 10, 12, 4))
        bar.pack(fill="x")
        who = ttk.Frame(bar)
        who.pack(side="left", padx=(0, 18))
        self.login_fr = ttk.Frame(who)
        ttk.Label(self.login_fr, text="Staff name:").pack(side="left")
        self.staff_cb = ttk.Combobox(self.login_fr, values=m["staff"], state="readonly", width=20)
        self.staff_cb.pack(side="left", padx=(4, 10))
        last = self.settings.get("last_staff")
        if last in m["staff"]:
            self.staff_cb.set(last)
        ttk.Label(self.login_fr, text="PIN:").pack(side="left")
        self.pin_var = tk.StringVar()
        pe = ttk.Entry(self.login_fr, textvariable=self.pin_var, show="•", width=7,
                       justify="center")
        pe.pack(side="left", padx=4)
        pe.bind("<Return>", lambda e: self._login())
        ttk.Button(self.login_fr, text="🔓 Log in", command=self._login).pack(side="left")
        self.user_fr = ttk.Frame(who)
        self.user_lbl = ttk.Label(self.user_fr, text="", font=("Segoe UI", 11, "bold"),
                                  foreground=NAVY)
        self.user_lbl.pack(side="left")
        ttk.Button(self.user_fr, text="Change PIN", command=self._change_pin).pack(
            side="left", padx=(10, 4))
        ttk.Button(self.user_fr, text="Log out", command=self._logout).pack(side="left")
        self.login_fr.pack(side="left")
        pe.focus_set()

        ttk.Label(bar, text="Date (DD-MM-YYYY):").pack(side="left")
        ttk.Button(bar, text="◀", width=3, command=lambda: self._shift_day(-1)).pack(
            side="left", padx=(4, 0))
        self.date_var = tk.StringVar(value=to_display(iso(date.today())))
        de = ttk.Entry(bar, textvariable=self.date_var, width=12, justify="center")
        de.pack(side="left", padx=2)
        de.bind("<Return>", lambda e: self._load_sheet())
        de.bind("<FocusOut>", lambda e: self._load_sheet())
        ttk.Button(bar, text="▶", width=3, command=lambda: self._shift_day(1)).pack(side="left")
        ttk.Button(bar, text="Today", command=self._today).pack(side="left", padx=6)

        self.status_lbl = ttk.Label(bar, text="", style="Status.TLabel")
        self.status_lbl.pack(side="right")

        # task grid
        grid = ttk.LabelFrame(self, text=" Today's Sheet  (blue rows = pending tasks carried "
                                         "forward from the opening sheet) ", padding=6)
        grid.pack(fill="both", expand=True, padx=12, pady=4)
        cols = ("type", "client", "work", "desc", "status", "reason", "awaited", "since",
                "hours", "remarks")
        heads = ("Source", "Client", "Work Type", "Task Description", "Status",
                 "Pending Reason", "Data / Info Awaited", "Pending Since", "Hrs", "Remarks")
        widths = (95, 150, 140, 240, 85, 170, 170, 90, 45, 150)
        self.tree = ttk.Treeview(grid, columns=cols, show="headings", selectmode="extended")
        for c, h, w in zip(cols, heads, widths):
            self.tree.heading(c, text=h)
            self.tree.column(c, width=w, minwidth=40, anchor="center" if w < 100 else "w")
        vs = ttk.Scrollbar(grid, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=vs.set)
        self.tree.pack(side="left", fill="both", expand=True)
        vs.pack(side="right", fill="y")
        self.tree.tag_configure("carried", background="#DDEBF7")
        self.tree.tag_configure("done", background="#E2EFDA")
        self.tree.tag_configure("pending", background="#FFF2CC")
        self.tree.tag_configure("data", background="#FCE4D6")
        self.tree.bind("<<TreeviewSelect>>", self._on_select)
        self.tree.bind("<Delete>", lambda e: self._delete_selected())

        # entry form
        form = ttk.LabelFrame(self, text=" Add / Edit Task ", padding=8)
        form.pack(fill="x", padx=12, pady=4)
        for i in (1, 3, 5):
            form.columnconfigure(i, weight=1)

        ttk.Label(form, text="Client *").grid(row=0, column=0, sticky="w")
        self.client_cb = FilterCombo(form, m["clients"])
        self.client_cb.grid(row=0, column=1, sticky="ew", padx=(4, 12), pady=2)
        ttk.Label(form, text="Work type *").grid(row=0, column=2, sticky="w")
        self.work_cb = FilterCombo(form, m["work_types"])
        self.work_cb.grid(row=0, column=3, sticky="ew", padx=(4, 12), pady=2)
        ttk.Label(form, text="Hours").grid(row=0, column=4, sticky="w")
        self.hours_var = tk.StringVar(value="0")
        ttk.Spinbox(form, from_=0, to=24, increment=0.25, textvariable=self.hours_var,
                    width=7).grid(row=0, column=5, sticky="w", padx=4)

        ttk.Label(form, text="Task description *").grid(row=1, column=0, sticky="w")
        self.desc_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.desc_var).grid(row=1, column=1, columnspan=5,
                                                         sticky="ew", padx=4, pady=2)

        ttk.Label(form, text="Status *").grid(row=2, column=0, sticky="w")
        sf = ttk.Frame(form)
        sf.grid(row=2, column=1, sticky="w", padx=4)
        self.status_var = tk.StringVar(value=STATUS_COMPLETED)
        for s in (STATUS_COMPLETED, STATUS_PENDING):
            ttk.Radiobutton(sf, text=s, value=s, variable=self.status_var,
                            command=self._toggle_pending).pack(side="left", padx=(0, 12))
        ttk.Label(form, text="Pending reason").grid(row=2, column=2, sticky="w")
        self.reason_cb = ttk.Combobox(form, values=PENDING_REASONS, state="readonly")
        self.reason_cb.grid(row=2, column=3, columnspan=3, sticky="ew", padx=4, pady=2)

        ttk.Label(form, text="Data / info awaited").grid(row=3, column=0, sticky="w")
        self.awaited_var = tk.StringVar()
        self.awaited_e = ttk.Entry(form, textvariable=self.awaited_var)
        self.awaited_e.grid(row=3, column=1, columnspan=5, sticky="ew", padx=4, pady=2)

        ttk.Label(form, text="Remarks").grid(row=4, column=0, sticky="w")
        self.remarks_var = tk.StringVar()
        ttk.Entry(form, textvariable=self.remarks_var).grid(row=4, column=1, columnspan=5,
                                                            sticky="ew", padx=4, pady=2)

        btns = ttk.Frame(form)
        btns.grid(row=5, column=0, columnspan=6, sticky="w", pady=(6, 0))
        self.add_btn = ttk.Button(btns, text="➕ Add Task", command=self._add_or_update)
        self.add_btn.pack(side="left")
        ttk.Button(btns, text="Clear form", command=self._clear_form).pack(side="left", padx=6)
        ttk.Button(btns, text="✔ Mark selected Completed",
                   command=self._mark_completed).pack(side="left", padx=6)
        ttk.Button(btns, text="🗑 Delete selected", command=self._delete_selected).pack(
            side="left", padx=6)

        # footer
        foot = ttk.Frame(self, padding=(12, 4, 12, 10))
        foot.pack(fill="x")
        self.totals_lbl = ttk.Label(foot, text="")
        self.totals_lbl.pack(side="left")
        ttk.Button(foot, text="💾  Save & Submit Day-End Report", style="Big.TButton",
                   command=self._submit).pack(side="right")

        self._toggle_pending()

    # ------------------------------------------------------------------ date / staff
    def _current_day(self) -> str | None:
        try:
            return from_display(self.date_var.get())
        except ValueError:
            messagebox.showwarning(APP_NAME, "Enter the date as DD-MM-YYYY, e.g. 24-11-2026")
            return None

    def _shift_day(self, n):
        d = self._current_day()
        if d:
            self.date_var.set(to_display(iso(parse_iso(d) + timedelta(days=n))))
            self._load_sheet()

    def _today(self):
        self.date_var.set(to_display(iso(date.today())))
        self._load_sheet()

    def _confirm_discard(self) -> bool:
        if not self.dirty:
            return True
        return messagebox.askyesno(APP_NAME, "You have unsaved changes. Discard them?")

    def _load_sheet(self):
        staff, day = self.user or "", self._current_day()
        if not day:
            return
        key = (staff, day)
        if key == self.loaded_key:
            return
        if not self._confirm_discard():
            # revert selection
            if self.loaded_key:
                self.date_var.set(to_display(self.loaded_key[1]))
            return
        self.loaded_key = key
        self.dirty = False
        self.dropped = set()
        self._clear_form()
        if not staff:
            self.tasks = []
            self.status_lbl.configure(text="← Log in to begin",
                                      foreground=ACCENT)
            self._refresh_tree()
            return
        self.settings["last_staff"] = staff
        save_local_settings(self.settings)
        self.tasks, saved = self.store.sheet_for_day(staff, day)
        if saved:
            self.status_lbl.configure(
                text=f"✓ Submitted on {saved['submitted_at']}", foreground="#2E7D32")
        else:
            n = sum(t.get("carried") for t in self.tasks)
            self.status_lbl.configure(
                text=f"Not yet submitted • {n} pending task(s) carried forward",
                foreground="#C55A11")
        self._refresh_tree()

    # ------------------------------------------------------------------ grid
    def _refresh_tree(self):
        self.tree.delete(*self.tree.get_children())
        day = self.loaded_key[1] if self.loaded_key else iso(date.today())
        for t in self.tasks:
            pend = t["status"] == STATUS_PENDING
            if pend:
                tag = "data" if t.get("pending_reason") == REASON_DATA else "pending"
            else:
                tag = "done"
            if t.get("carried") and pend:
                tag = "carried"
            src = (f"Carried ({days_pending(t, day)}d)" if t.get("carried") else "New")
            self.tree.insert("", "end", iid=t["id"], tags=(tag,), values=(
                src, t["client"], t["work_type"], t["description"], t["status"],
                t.get("pending_reason", "") if pend else "",
                t.get("awaited_details", "") if pend else "",
                to_display(t.get("origin_date") or day) if pend else "",
                t.get("hours") or "", t.get("remarks", "")))
        done = sum(t["status"] == STATUS_COMPLETED for t in self.tasks)
        pend = len(self.tasks) - done
        hrs = sum(float(t.get("hours") or 0) for t in self.tasks)
        mark = "   •  UNSAVED CHANGES" if self.dirty else ""
        self.totals_lbl.configure(
            text=f"Tasks: {len(self.tasks)}   |   Completed: {done}   |   Pending: {pend}   |"
                 f"   Hours: {hrs:g}{mark}",
            foreground="#C00000" if self.dirty else "black")

    def _find(self, tid):
        return next((t for t in self.tasks if t["id"] == tid), None)

    def _on_select(self, _e=None):
        sel = self.tree.selection()
        if len(sel) != 1:
            return
        t = self._find(sel[0])
        if not t:
            return
        self.edit_id = t["id"]
        self.client_cb.set(t["client"])
        self.work_cb.set(t["work_type"])
        self.desc_var.set(t["description"])
        self.status_var.set(t["status"])
        self.reason_cb.set(t.get("pending_reason", ""))
        self.awaited_var.set(t.get("awaited_details", ""))
        self.hours_var.set(str(t.get("hours") or 0))
        self.remarks_var.set(t.get("remarks", ""))
        self.add_btn.configure(text="💾 Update Task")
        self._toggle_pending()

    # ------------------------------------------------------------------ form
    def _toggle_pending(self):
        pend = self.status_var.get() == STATUS_PENDING
        self.reason_cb.configure(state="readonly" if pend else "disabled")
        self.awaited_e.configure(state="normal" if pend else "disabled")
        if not pend:
            self.reason_cb.set("")
            self.awaited_var.set("")

    def _clear_form(self):
        self.edit_id = None
        for v in (self.desc_var, self.awaited_var, self.remarks_var):
            v.set("")
        self.client_cb.set("")
        self.work_cb.set("")
        self.reason_cb.set("")
        self.hours_var.set("0")
        self.status_var.set(STATUS_COMPLETED)
        self.add_btn.configure(text="➕ Add Task")
        self._toggle_pending()
        if self.tree.selection():
            self.tree.selection_remove(self.tree.selection())

    def _add_or_update(self):
        if not self.user:
            messagebox.showwarning(APP_NAME, "Please log in first.")
            return
        errs = []
        if not self.client_cb.valid():
            errs.append("• Choose a Client from the list (ask Admin to add new clients).")
        if not self.work_cb.valid():
            errs.append("• Choose a Work type from the list.")
        if not self.desc_var.get().strip():
            errs.append("• Enter a short task description.")
        pend = self.status_var.get() == STATUS_PENDING
        if pend and not self.reason_cb.get():
            errs.append("• Select why the task is pending.")
        if pend and self.reason_cb.get() == REASON_DATA and not self.awaited_var.get().strip():
            errs.append("• Mention which data / documents are awaited from the client.")
        try:
            hrs = float(self.hours_var.get() or 0)
            if not 0 <= hrs <= 24:
                raise ValueError
        except ValueError:
            errs.append("• Hours must be a number between 0 and 24.")
            hrs = 0
        if errs:
            messagebox.showwarning(APP_NAME, "Please fix:\n\n" + "\n".join(errs))
            return
        data = dict(client=self.client_cb.get().strip(), work_type=self.work_cb.get().strip(),
                    description=self.desc_var.get().strip(), status=self.status_var.get(),
                    pending_reason=self.reason_cb.get() if pend else "",
                    awaited_details=self.awaited_var.get().strip() if pend else "",
                    hours=hrs, remarks=self.remarks_var.get().strip())
        if self.edit_id and self._find(self.edit_id):
            self._find(self.edit_id).update(data)
        else:
            self.tasks.append(new_task(origin_date=self.loaded_key[1], **data))
        self.dirty = True
        self._clear_form()
        self._refresh_tree()

    def _mark_completed(self):
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo(APP_NAME, "Select one or more rows first.")
            return
        for tid in sel:
            t = self._find(tid)
            if t:
                t.update(status=STATUS_COMPLETED, pending_reason="", awaited_details="")
        self.dirty = True
        self._clear_form()
        self._refresh_tree()

    def _delete_selected(self):
        sel = self.tree.selection()
        if not sel:
            return
        carried = [tid for tid in sel if (self._find(tid) or {}).get("carried")]
        msg = f"Delete {len(sel)} task(s)?"
        if carried:
            msg += ("\n\nNote: carried-forward tasks should normally be marked Completed, "
                    "not deleted. Delete only if the work was cancelled / not required.")
        if not messagebox.askyesno(APP_NAME, msg):
            return
        self.dropped.update(tid for tid in carried)
        self.tasks = [t for t in self.tasks if t["id"] not in sel]
        self.dirty = True
        self._clear_form()
        self._refresh_tree()

    def _submit(self):
        if not self.user or not self.loaded_key:
            messagebox.showwarning(APP_NAME, "Please log in first.")
            return
        if self.desc_var.get().strip() and not self.edit_id:
            if messagebox.askyesno(APP_NAME, "The form has a task that is not added yet. "
                                             "Add it before submitting?"):
                self._add_or_update()
                if self.desc_var.get().strip():
                    return  # validation failed
        if not self.tasks:
            if not messagebox.askyesno(APP_NAME, "No tasks entered. Submit an empty report?"):
                return
        staff, day = self.loaded_key
        try:
            saved = self.store.save_sheet(staff, day, self.tasks, self.dropped)
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not save to the shared folder:\n\n{e}")
            return
        self.dirty = False
        self.status_lbl.configure(text=f"✓ Submitted on {saved['submitted_at']}",
                                  foreground="#2E7D32")
        self._refresh_tree()
        pend = sum(t["status"] == STATUS_PENDING for t in self.tasks)
        messagebox.showinfo(APP_NAME, f"Day-end report submitted for {staff} "
                                      f"({to_display(day)}).\n\n{pend} pending task(s) will "
                                      "appear in your next opening sheet.")

    # ------------------------------------------------------------------ misc
    def _change_folder(self):
        if self._confirm_discard() and self._connect_shared_folder(force=True):
            self.reload_masters()
            self.loaded_key = None
            self.dirty = False
            self._load_sheet()

    def reload_masters(self):
        m = self.store.masters()
        self.firm_lbl.configure(text=m["firm_name"])
        self.staff_cb["values"] = m["staff"]
        self.client_cb.set_values(m["clients"])
        self.work_cb.set_values(m["work_types"])

    # ------------------------------------------------------------------ login
    def _ask_new_pin(self, who: str) -> str | None:
        while True:
            p1 = simpledialog.askstring(APP_NAME, f"{who}: choose your new 4-digit PIN:",
                                        show="•", parent=self)
            if p1 is None:
                return None
            err = valid_new_pin(p1.strip())
            if err:
                messagebox.showwarning(APP_NAME, err)
                continue
            p2 = simpledialog.askstring(APP_NAME, "Type the new PIN again:", show="•", parent=self)
            if p2 is None:
                return None
            if p1.strip() != p2.strip():
                messagebox.showwarning(APP_NAME, "The two PINs do not match. Try again.")
                continue
            return p1.strip()

    def _login(self):
        name, pin = self.staff_cb.get(), self.pin_var.get().strip()
        if not name:
            messagebox.showwarning(APP_NAME, "Select your name first.")
            return
        ok, must_change = self.auth.staff_login(name, pin)
        self.pin_var.set("")
        if not ok:
            messagebox.showerror(APP_NAME, "Wrong PIN.\n\nFirst time? Use 0000.\n"
                                           "Forgot your PIN? Ask the admin to reset it.")
            return
        if must_change:
            messagebox.showinfo(APP_NAME, "Welcome! Please set your own 4-digit PIN now.\n"
                                          "You will use it every time you log in.")
            new = self._ask_new_pin(name)
            if not new:
                return
            self.auth.set_staff_pin(name, new)
            messagebox.showinfo(APP_NAME, "PIN saved.")
        self.user = name
        self.settings["last_staff"] = name
        save_local_settings(self.settings)
        self.user_lbl.configure(text=f"👤 {name}")
        self.login_fr.pack_forget()
        self.user_fr.pack(side="left")
        self.loaded_key = None
        self._load_sheet()

    def _logout(self):
        if not self._confirm_discard():
            return
        self.user = None
        self.dirty = False
        self.user_fr.pack_forget()
        self.login_fr.pack(side="left")
        self.loaded_key = None
        self._load_sheet()

    def _change_pin(self):
        old = simpledialog.askstring(APP_NAME, "Enter your current PIN:", show="•", parent=self)
        if old is None:
            return
        if not self.auth.staff_login(self.user, old.strip())[0]:
            messagebox.showerror(APP_NAME, "Current PIN is wrong.")
            return
        new = self._ask_new_pin(self.user)
        if new:
            self.auth.set_staff_pin(self.user, new)
            messagebox.showinfo(APP_NAME, "PIN changed.")

    def _open_admin(self):
        pin = simpledialog.askstring(APP_NAME, "Enter Admin PIN:", show="*", parent=self)
        if pin is None:
            return
        if not self.auth.admin_login(pin.strip()):
            messagebox.showerror(APP_NAME, "Incorrect PIN.")
            return
        AdminWindow(self)

    def _on_close(self):
        if self._confirm_discard():
            self.destroy()


# =========================================================================== admin
class AdminWindow(tk.Toplevel):
    def __init__(self, app: App):
        super().__init__(app)
        self.app = app
        self.store = app.store
        self.title("Admin — Day-End Compile, Weekly Summary, Email & Masters")
        self.geometry("1000x640")
        self.configure(bg=BG)
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)
        nb.add(self._compile_tab(nb), text="  Day-End Compile  ")
        nb.add(self._weekly_tab(nb), text="  Weekly Summary  ")
        nb.add(self._email_tab(nb), text="  Auto Email  ")
        nb.add(self._masters_tab(nb), text="  Masters (Staff / Clients / Work)  ")
        nb.add(self._settings_tab(nb), text="  Settings  ")
        self.transient(app)
        self.grab_set()

    # ---------------------------------------------------------------- compile tab
    def _compile_tab(self, nb):
        f = ttk.Frame(nb, padding=10)
        top = ttk.Frame(f)
        top.pack(fill="x")
        ttk.Label(top, text="Report date (DD-MM-YYYY):").pack(side="left")
        self.cdate = tk.StringVar(value=self.app.date_var.get())
        ttk.Entry(top, textvariable=self.cdate, width=12, justify="center").pack(
            side="left", padx=6)
        ttk.Button(top, text="Refresh", command=self._refresh_status).pack(side="left")
        ttk.Button(top, text="📊  Compile Excel Report", style="Big.TButton",
                   command=self._compile).pack(side="right")
        ttk.Button(top, text="Open reports folder",
                   command=lambda: open_path(self.store.reports_dir)).pack(side="right", padx=8)

        self.kpi = ttk.Label(f, text="", font=("Segoe UI", 10, "bold"), foreground=NAVY)
        self.kpi.pack(fill="x", pady=8)

        cols = ("staff", "when", "tasks", "done", "pend")
        self.st = ttk.Treeview(f, columns=cols, show="headings")
        for c, h, w in zip(cols, ("Staff", "Submitted at", "Tasks", "Completed", "Pending"),
                           (220, 200, 80, 90, 90)):
            self.st.heading(c, text=h)
            self.st.column(c, width=w, anchor="w" if w > 150 else "center")
        self.st.tag_configure("miss", background="#F4CCCC")
        self.st.tag_configure("ok", background="#E2EFDA")
        self.st.pack(fill="both", expand=True)
        ttk.Label(f, text="Red = not yet submitted. You can compile any time; "
                          "re-compile after late submissions.",
                  foreground="#595959").pack(anchor="w", pady=(6, 0))
        self._refresh_status()
        return f

    def _cday(self):
        try:
            return from_display(self.cdate.get())
        except ValueError:
            messagebox.showwarning(APP_NAME, "Enter the date as DD-MM-YYYY", parent=self)
            return None

    def _refresh_status(self):
        day = self._cday()
        if not day:
            return
        self.st.delete(*self.st.get_children())
        rows = self.store.submission_status(day)
        for name, when, n, d, p in rows:
            self.st.insert("", "end", tags=("ok" if when else "miss",),
                           values=(name, when or "NOT SUBMITTED", n, d, p))
        sub = sum(1 for r in rows if r[1])
        self.kpi.configure(text=f"{to_display(day)}:  {sub}/{len(rows)} staff submitted   |   "
                                f"Tasks {sum(r[2] for r in rows)}   |   Completed "
                                f"{sum(r[3] for r in rows)}   |   Pending {sum(r[4] for r in rows)}")

    def _compile(self):
        day = self._cday()
        if not day:
            return
        self._refresh_status()
        missing = [r[0] for r in self.store.submission_status(day) if not r[1]]
        if missing and not messagebox.askyesno(
                APP_NAME, "Not yet submitted by:\n  " + "\n  ".join(missing) +
                          "\n\nCompile anyway?", parent=self):
            return
        try:
            path = self.store.compile_report(day)
        except PermissionError:
            messagebox.showerror(APP_NAME, "The report file is open in Excel. Close it and "
                                           "try again.", parent=self)
            return
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not compile:\n\n{e}", parent=self)
            return
        if messagebox.askyesno(APP_NAME, f"Report saved:\n{path}\n\nOpen it now?", parent=self):
            open_path(path)

    # ---------------------------------------------------------------- masters tab
    def _masters_tab(self, nb):
        f = ttk.Frame(nb, padding=10)
        self.m = self.store.masters()
        self.lists = {}
        for col, (key, title) in enumerate([("staff", "Staff"), ("clients", "Clients"),
                                            ("work_types", "Work Types")]):
            f.columnconfigure(col, weight=1)
            lf = ttk.LabelFrame(f, text=f" {title} ", padding=6)
            lf.grid(row=0, column=col, sticky="nsew", padx=5)
            lb = tk.Listbox(lf, selectmode="extended", height=18, font=("Segoe UI", 10))
            lb.pack(fill="both", expand=True)
            for v in self.m[key]:
                lb.insert("end", v)
            ent = ttk.Entry(lf)
            ent.pack(fill="x", pady=4)
            ent.bind("<Return>", lambda e, k=key, en=ent: self._m_add(k, en))
            bf = ttk.Frame(lf)
            bf.pack(fill="x")
            ttk.Button(bf, text="Add", command=lambda k=key, en=ent: self._m_add(k, en)).pack(
                side="left")
            ttk.Button(bf, text="Bulk add…", command=lambda k=key: self._m_bulk(k)).pack(
                side="left", padx=4)
            ttk.Button(bf, text="Remove", command=lambda k=key: self._m_remove(k)).pack(
                side="right")
            if key == "staff":
                ttk.Button(lf, text="🔑 Reset PIN of selected staff",
                           command=self._reset_pin).pack(fill="x", pady=(6, 0))
            self.lists[key] = lb
        f.rowconfigure(0, weight=1)
        ttk.Button(f, text="💾  Save Masters", style="Big.TButton",
                   command=self._m_save).grid(row=1, column=2, sticky="e", pady=8)
        ttk.Label(f, text="Tip: 'Bulk add' lets you paste a whole client list from Excel "
                          "(one name per line).", foreground="#595959").grid(
            row=1, column=0, columnspan=2, sticky="w")
        return f

    def _m_add(self, key, ent):
        v = ent.get().strip()
        lb = self.lists[key]
        if v and v.lower() not in (x.lower() for x in lb.get(0, "end")):
            lb.insert("end", v)
        ent.delete(0, "end")

    def _m_bulk(self, key):
        win = tk.Toplevel(self)
        win.title("Bulk add — paste one name per line")
        win.geometry("420x420")
        txt = tk.Text(win, font=("Segoe UI", 10))
        txt.pack(fill="both", expand=True, padx=8, pady=8)

        def done():
            lb = self.lists[key]
            have = {x.lower() for x in lb.get(0, "end")}
            for line in txt.get("1.0", "end").splitlines():
                v = line.strip().split("\t")[0].strip()
                if v and v.lower() not in have:
                    lb.insert("end", v)
                    have.add(v.lower())
            win.destroy()

        ttk.Button(win, text="Add all", command=done).pack(pady=(0, 8))
        win.transient(self)
        win.grab_set()

    def _reset_pin(self):
        lb = self.lists["staff"]
        names = [lb.get(i) for i in lb.curselection()]
        if not names:
            messagebox.showinfo(APP_NAME, "Select a staff name first.", parent=self)
            return
        if not messagebox.askyesno(APP_NAME, "Reset PIN for:\n  " + "\n  ".join(names) +
                                   f"\n\nThey will log in with {DEFAULT_STAFF_PIN} and must "
                                   "choose a new PIN.", parent=self):
            return
        for n in names:
            self.app.auth.reset_staff_pin(n)
        messagebox.showinfo(APP_NAME, "PIN reset done.", parent=self)

    def _m_remove(self, key):
        lb = self.lists[key]
        for i in reversed(lb.curselection()):
            lb.delete(i)

    def _m_save(self):
        m = self.store.masters()
        for k, lb in self.lists.items():
            m[k] = list(lb.get(0, "end"))
        if not m["staff"]:
            messagebox.showwarning(APP_NAME, "Add at least one staff name.", parent=self)
            return
        self.store.save_masters(m)
        self.app.reload_masters()
        messagebox.showinfo(APP_NAME, "Masters saved. All staff will see the updated lists "
                                      "the next time they open the app.", parent=self)

    # ---------------------------------------------------------------- weekly tab
    def _weekly_tab(self, nb):
        from dsr_weekly import week_bounds
        self._week_bounds = week_bounds
        f = ttk.Frame(nb, padding=10)
        top = ttk.Frame(f)
        top.pack(fill="x")
        ttk.Label(top, text="Any date in the week (DD-MM-YYYY):").pack(side="left")
        self.wdate = tk.StringVar(value=self.app.date_var.get())
        e = ttk.Entry(top, textvariable=self.wdate, width=12, justify="center")
        e.pack(side="left", padx=6)
        e.bind("<Return>", lambda _e: self._refresh_week())
        ttk.Button(top, text="◀ Prev week", command=lambda: self._shift_week(-7)).pack(side="left")
        ttk.Button(top, text="Next week ▶", command=lambda: self._shift_week(7)).pack(
            side="left", padx=4)
        ttk.Button(top, text="📅  Compile Weekly Report", style="Big.TButton",
                   command=self._compile_week).pack(side="right")
        self.wlbl = ttk.Label(f, text="", font=("Segoe UI", 10, "bold"), foreground=NAVY)
        self.wlbl.pack(fill="x", pady=8)
        cols = ("day", "staff", "tasks", "done", "pend", "hrs")
        self.wt = ttk.Treeview(f, columns=cols, show="headings", height=9)
        for c, h, w in zip(cols, ("Day", "Staff reported", "Tasks", "Completed", "Pending",
                                  "Hours"), (200, 130, 90, 100, 100, 90)):
            self.wt.heading(c, text=h)
            self.wt.column(c, width=w, anchor="w" if c == "day" else "center")
        self.wt.pack(fill="both", expand=True)
        ttk.Label(f, text="The weekly workbook has: Week Dashboard (who reported each day), Daily "
                          "Trend with chart, Client-wise, Work-wise, Staff-wise, Pending at Week "
                          "End, and a Task Register. A task carried over several days is counted "
                          "once, with its hours added up.", foreground="#595959",
                  wraplength=900).pack(anchor="w", pady=(6, 0))
        self._refresh_week()
        return f

    def _wday(self):
        try:
            return from_display(self.wdate.get())
        except ValueError:
            messagebox.showwarning(APP_NAME, "Enter the date as DD-MM-YYYY", parent=self)
            return None

    def _shift_week(self, n):
        d = self._wday()
        if d:
            self.wdate.set(to_display(iso(parse_iso(d) + timedelta(days=n))))
            self._refresh_week()

    def _refresh_week(self):
        d = self._wday()
        if not d:
            return
        start, end = self._week_bounds(d)
        self.wt.delete(*self.wt.get_children())
        tot = [0, 0, 0, 0.0]
        day = parse_iso(start)
        for _ in range(7):
            sheets = self.store.all_sheets(iso(day))
            ts = [t for s in sheets for t in s.get("tasks", [])]
            done = sum(t.get("status") == STATUS_COMPLETED for t in ts)
            hrs = sum(float(t.get("hours") or 0) for t in ts)
            self.wt.insert("", "end", values=(day.strftime("%A  %d-%m-%Y"), len(sheets), len(ts),
                                              done, len(ts) - done, f"{hrs:g}"))
            tot = [tot[0] + len(ts), tot[1] + done, tot[2] + len(ts) - done, tot[3] + hrs]
            day += timedelta(days=1)
        self.wlbl.configure(text=f"Week {to_display(start)} to {to_display(end)}   |   Task-days "
                                 f"{tot[0]}   |   Completed {tot[1]}   |   Pending entries "
                                 f"{tot[2]}   |   Hours {tot[3]:g}")

    def _compile_week(self):
        from dsr_weekly import build_weekly_report
        d = self._wday()
        if not d:
            return
        try:
            path = build_weekly_report(self.store, d)
        except PermissionError:
            messagebox.showerror(APP_NAME, "The weekly report is open in Excel. Close it and "
                                           "try again.", parent=self)
            return
        except Exception as e:
            messagebox.showerror(APP_NAME, f"Could not compile:\n\n{e}", parent=self)
            return
        if messagebox.askyesno(APP_NAME, f"Weekly report saved:\n{path}\n\nOpen it now?",
                               parent=self):
            open_path(path)

    # ---------------------------------------------------------------- email tab
    def _email_tab(self, nb):
        import dsr_email as de
        self.de = de
        e = de.email_settings()
        f = ttk.Frame(nb, padding=14)
        f.columnconfigure(1, weight=1)
        r = 0
        ttk.Label(f, text="Send the day-end report automatically by Gmail, every day.",
                  font=("Segoe UI", 11, "bold"), foreground=NAVY).grid(row=r, column=0,
                                                                      columnspan=3, sticky="w")
        r += 1
        self.e_sender = tk.StringVar(value=e["sender"])
        self.e_pwd = tk.StringVar()
        self.e_to = tk.StringVar(value=e["recipients"])
        self.e_time = tk.StringVar(value=e["time"])
        self.e_week = tk.StringVar(value=e["weekly_day"])
        saved = "(saved – leave blank to keep)" if e.get("app_password") else "(16 letters)"
        for label, var, kw, note in (
                ("Your Gmail address", self.e_sender, {}, "e.g. yourfirm@gmail.com"),
                ("Gmail App Password", self.e_pwd, {"show": "•"}, saved),
                ("Send report to", self.e_to, {}, "comma-separated; blank = your own Gmail"),
                ("Send at (24-hour HH:MM)", self.e_time, {"width": 8}, "19:00 = 7 pm")):
            ttk.Label(f, text=label).grid(row=r, column=0, sticky="w", pady=4)
            ttk.Entry(f, textvariable=var, **({"width": 45} | kw)).grid(row=r, column=1,
                                                                        sticky="w", padx=6)
            ttk.Label(f, text=note, foreground="#595959").grid(row=r, column=2, sticky="w")
            r += 1
        ttk.Label(f, text="Also attach weekly summary on").grid(row=r, column=0, sticky="w")
        ttk.Combobox(f, textvariable=self.e_week, values=de.WEEKDAYS, state="readonly",
                     width=14).grid(row=r, column=1, sticky="w", padx=6)
        r += 1
        bf = ttk.Frame(f)
        bf.grid(row=r, column=0, columnspan=3, sticky="w", pady=12)
        ttk.Button(bf, text="💾 Save", command=self._e_save).pack(side="left")
        ttk.Button(bf, text="✉ Send today's report now (test)", command=self._e_test).pack(
            side="left", padx=8)
        ttk.Button(bf, text="⏰ Turn ON daily auto email", command=self._e_on).pack(side="left")
        ttk.Button(bf, text="Turn OFF", command=self._e_off).pack(side="left", padx=8)
        ttk.Button(bf, text="View email log", command=self._e_log).pack(side="left")
        r += 1
        self.e_status = ttk.Label(f, text="", font=("Segoe UI", 10, "bold"))
        self.e_status.grid(row=r, column=0, columnspan=3, sticky="w")
        r += 1
        help_txt = (
            "How to get a Gmail App Password (one time):\n"
            "  1. Open myaccount.google.com → Security → turn ON 2-Step Verification.\n"
            "  2. Open myaccount.google.com/apppasswords, type the name 'Daily Report', "
            "click Create.\n"
            "  3. Copy the 16-letter password shown and paste it above. Click Save.\n\n"
            "Notes: email runs from THIS computer, so keep it switched on (or it sends as soon as "
            "it is back on). The password is stored only on this PC, encrypted with your Windows "
            "login, and never in the shared Google Drive folder.")
        ttk.Label(f, text=help_txt, foreground="#404040", justify="left",
                  wraplength=900).grid(row=r, column=0, columnspan=3, sticky="w", pady=(10, 0))
        self._e_refresh_status()
        return f

    def _e_refresh_status(self):
        try:
            st = self.de.schedule_status()
        except Exception as ex:
            st = f"Unknown ({ex})"
        self.e_status.configure(text=f"Daily auto email: {st}",
                                foreground="#2E7D32" if st.startswith("Scheduled") else "#C55A11")

    def _e_save(self, quiet=False) -> bool:
        sender = self.e_sender.get().strip()
        if "@" not in sender:
            messagebox.showwarning(APP_NAME, "Enter your Gmail address.", parent=self)
            return False
        try:
            datetime.strptime(self.e_time.get().strip(), "%H:%M")
        except ValueError:
            messagebox.showwarning(APP_NAME, "Time must be HH:MM, e.g. 19:00", parent=self)
            return False
        if not self.e_pwd.get().strip() and not self.de.email_settings().get("app_password"):
            messagebox.showwarning(APP_NAME, "Enter the Gmail App Password.", parent=self)
            return False
        self.de.save_email_settings(sender, self.e_pwd.get().strip(), self.e_to.get(),
                                    self.e_time.get().strip(), self.e_week.get())
        self.e_pwd.set("")
        if not quiet:
            messagebox.showinfo(APP_NAME, "Email settings saved.", parent=self)
        return True

    def _e_test(self):
        if not self._e_save(quiet=True):
            return
        day = self._cday() or iso(date.today())
        self.configure(cursor="watch")
        self.update()
        try:
            subject = self.de.send_day_report(day, self.store)
            messagebox.showinfo(APP_NAME, f"Email sent:\n{subject}", parent=self)
        except Exception as ex:
            hint = ""
            if "535" in str(ex) or "534" in str(ex) or "Username and Password" in str(ex):
                hint = ("\n\nGmail rejected the login. Use an App Password (not your normal "
                        "Gmail password) and check 2-Step Verification is ON.")
            messagebox.showerror(APP_NAME, f"Email failed:\n{ex}{hint}", parent=self)
        finally:
            self.configure(cursor="")

    def _e_on(self):
        if not self._e_save(quiet=True):
            return
        try:
            self.de.install_schedule(self.e_time.get().strip())
            messagebox.showinfo(APP_NAME, f"Done. The report will be emailed every day at "
                                          f"{self.e_time.get().strip()}.", parent=self)
        except Exception as ex:
            messagebox.showerror(APP_NAME, f"Could not schedule:\n{ex}", parent=self)
        self._e_refresh_status()

    def _e_off(self):
        try:
            self.de.remove_schedule()
            messagebox.showinfo(APP_NAME, "Daily auto email turned off.", parent=self)
        except Exception as ex:
            messagebox.showerror(APP_NAME, f"Could not turn off:\n{ex}", parent=self)
        self._e_refresh_status()

    def _e_log(self):
        p = os.path.join(os.path.dirname(local_settings_path()), "email_log.txt")
        if os.path.exists(p):
            open_path(p)
        else:
            messagebox.showinfo(APP_NAME, "No emails sent yet.", parent=self)

    # ---------------------------------------------------------------- settings tab
    def _settings_tab(self, nb):
        f = ttk.Frame(nb, padding=16)
        m = self.store.masters()
        ttk.Label(f, text="Firm name (shown on app & reports):").grid(row=0, column=0,
                                                                      sticky="w", pady=4)
        self.firm_var = tk.StringVar(value=m["firm_name"])
        ttk.Entry(f, textvariable=self.firm_var, width=45).grid(row=0, column=1, sticky="w")
        ttk.Label(f, text="New admin PIN (leave blank to keep):").grid(row=1, column=0,
                                                                       sticky="w", pady=4)
        self.pin_var = tk.StringVar()
        ttk.Entry(f, textvariable=self.pin_var, width=20, show="*").grid(row=1, column=1,
                                                                         sticky="w")
        ttk.Button(f, text="Save settings", command=self._save_settings).grid(
            row=2, column=1, sticky="w", pady=10)
        ttk.Label(f, text="Shared folder:").grid(row=3, column=0, sticky="nw", pady=(20, 0))
        ttk.Label(f, text=self.store.root, foreground=ACCENT, wraplength=520).grid(
            row=3, column=1, sticky="w", pady=(20, 0))
        ttk.Button(f, text="Open shared folder",
                   command=lambda: open_path(self.store.root)).grid(row=4, column=1, sticky="w",
                                                                    pady=6)
        return f

    def _save_settings(self):
        m = self.store.masters_raw()
        m["firm_name"] = self.firm_var.get().strip() or m.get("firm_name", "")
        self.store.save_masters(m)
        if self.pin_var.get().strip():
            try:
                self.app.auth.set_admin_pin(self.pin_var.get().strip())
            except ValueError as e:
                messagebox.showwarning(APP_NAME, str(e), parent=self)
                return
        self.app.reload_masters()
        self.pin_var.set("")
        messagebox.showinfo(APP_NAME, "Settings saved.", parent=self)


def main():
    if "--auto-email" in sys.argv:          # run by Windows Task Scheduler, no window
        from dsr_email import auto_email_main
        sys.exit(auto_email_main())
    app = App()
    try:
        app.mainloop()
    except tk.TclError:
        pass


if __name__ == "__main__":
    main()
