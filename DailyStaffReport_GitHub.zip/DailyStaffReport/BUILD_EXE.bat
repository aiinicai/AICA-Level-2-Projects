@echo off
REM ==================================================================
REM  Builds DailyStaffReport.exe  (run once, on any Windows 10/11 PC)
REM  Needs Python 3.10+ from https://www.python.org/downloads/
REM  (tick "Add python.exe to PATH" during installation)
REM ==================================================================
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo.
  echo  Python is not installed or not on PATH.
  echo  Install it from https://www.python.org/downloads/  and tick "Add python.exe to PATH".
  pause
  exit /b 1
)
echo Installing build tools...
python -m pip install --upgrade pip
python -m pip install pyinstaller openpyxl
echo.
echo Building the EXE (takes 1-2 minutes)...
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name DailyStaffReport --hidden-import dsr_report --hidden-import dsr_weekly --hidden-import dsr_email --hidden-import dsr_auth dsr_app.py
if errorlevel 1 (
  echo BUILD FAILED - see messages above.
  pause
  exit /b 1
)
echo.
echo ==================================================================
echo  DONE.  Your file is:  %~dp0dist\DailyStaffReport.exe
echo  Send this single file to all staff.
echo ==================================================================
explorer "%~dp0dist"
pause
