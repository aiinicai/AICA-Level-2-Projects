"""
Creates realistic demo data in a folder so you can show the software in your
capstone presentation without waiting for real staff entries.

    python demo_data.py  "D:\\DSR_Demo"
Then open the app, choose that folder as the shared folder (Admin PIN: 1234).
"""
import sys
from datetime import date, timedelta

from dsr_core import (REASON_DATA, STATUS_COMPLETED, STATUS_PENDING, Store, iso, new_task)


def make_demo(folder: str, today: date | None = None) -> Store:
    today = today or date.today()
    d1 = today - timedelta(days=2)
    d2 = today - timedelta(days=1)
    st = Store(folder)
    m = st.masters()
    m.update(
        firm_name="Sharma & Associates, Chartered Accountants",
        staff=["Amit Verma", "Priya Nair", "Rahul Gupta", "Sneha Iyer"],
        clients=["Bharat Textiles Pvt Ltd", "Green Valley Foods LLP", "Kapoor Traders",
                 "Mehta Family Trust", "Sunrise Hospital", "Vision Infotech Pvt Ltd",
                 "Dr. R. K. Singh", "Om Sai Constructions"],
    )
    st.save_masters(m)
    T = new_task
    P, C = STATUS_PENDING, STATUS_COMPLETED

    # ---- day 1 (two days ago)
    st.save_sheet("Amit Verma", iso(d1), [
        T(client="Bharat Textiles Pvt Ltd", work_type="GST Return Filing",
          description="GSTR-3B for October", status=P, pending_reason=REASON_DATA,
          awaited_details="Purchase register & credit notes for October", hours=1.5,
          origin_date=iso(d1)),
        T(client="Kapoor Traders", work_type="Accounting / Bookkeeping",
          description="Bank entries Sep-Oct", status=C, hours=3, origin_date=iso(d1)),
    ])
    st.save_sheet("Priya Nair", iso(d1), [
        T(client="Sunrise Hospital", work_type="Tax Audit", description="Form 3CD clause 26-44",
          status=P, pending_reason="Work in progress (will continue)", hours=5,
          origin_date=iso(d1)),
    ])
    # ---- day 2 (yesterday)
    for name in ("Amit Verma", "Priya Nair"):
        tasks, _ = st.sheet_for_day(name, iso(d2))
        if name == "Priya Nair":
            tasks[0].update(status=C, hours=4, remarks="Sent to partner for review")
            tasks.append(T(client="Mehta Family Trust", work_type="Income Tax Return",
                           description="ITR-7 AY 2026-27", status=P,
                           pending_reason="Query / clarification awaited from client",
                           awaited_details="Donation receipts > Rs 2,000", hours=2,
                           origin_date=iso(d2)))
        else:
            tasks[0]["hours"] = 0.5
            tasks.append(T(client="Vision Infotech Pvt Ltd", work_type="TDS Return",
                           description="24Q & 26Q Q2", status=C, hours=3, origin_date=iso(d2)))
        st.save_sheet(name, iso(d2), tasks)

    # ---- today: Amit, Priya, Rahul submit; Sneha has not yet
    tasks, _ = st.sheet_for_day("Amit Verma", iso(today))
    tasks[0].update(hours=0.5, remarks="Reminder mail sent to accountant")
    tasks += [
        T(client="Green Valley Foods LLP", work_type="ROC / MCA Compliance",
          description="Form 11 LLP annual return", status=C, hours=2, origin_date=iso(today)),
        T(client="Om Sai Constructions", work_type="GST Reconciliation",
          description="GSTR-2B vs books Apr-Sep", status=P, pending_reason=REASON_DATA,
          awaited_details="Ledger export from Tally", hours=1, origin_date=iso(today)),
    ]
    st.save_sheet("Amit Verma", iso(today), tasks)

    tasks, _ = st.sheet_for_day("Priya Nair", iso(today))
    tasks[0].update(status=C, pending_reason="", awaited_details="", hours=1.5,
                    remarks="Receipts received, ITR filed")
    tasks.append(T(client="Sunrise Hospital", work_type="Statutory Audit",
                   description="Fixed asset vouching", status=P,
                   pending_reason="Work in progress (will continue)", hours=5,
                   origin_date=iso(today)))
    st.save_sheet("Priya Nair", iso(today), tasks)

    st.save_sheet("Rahul Gupta", iso(today), [
        T(client="Dr. R. K. Singh", work_type="Notice / Assessment Reply",
          description="Reply to 143(1)(a) intimation", status=C, hours=2.5,
          origin_date=iso(today)),
        T(client="Kapoor Traders", work_type="Payroll / PF / ESI",
          description="PF ECR for October", status=P, pending_reason="Govt. portal / technical issue",
          awaited_details="", hours=1, remarks="EPFO portal down, retry tomorrow",
          origin_date=iso(today)),
        T(client="Bharat Textiles Pvt Ltd", work_type="Certification",
          description="Net-worth certificate for bank", status=P,
          pending_reason=REASON_DATA, awaited_details="Audited B/S FY 2025-26 and ITR-V",
          hours=0.5, origin_date=iso(today)),
    ])
    return st


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)
    s = make_demo(sys.argv[1])
    print("Demo data created in", s.root)
