# Daily Staff Report – AI-Assisted Daily Work Reporting for a CA Firm

A Windows desktop app where every staff member submits a **client-wise, work-wise day-end
report**. Pending work is **carried forward automatically** into the next day's opening sheet,
and the partner receives one compiled **Excel report by email at 7 pm**.

Built as a capstone project for the **ICAI AI Level 2** course, using Python with AI-assisted
development (Claude, by Anthropic).

![Staff sheet with carried-forward work](screenshots/02_staff_sheet_carried_forward.png)

## Features

| Requirement | How the app handles it |
| --- | --- |
| Daily reporting by every staff member | Staff log in with name + 4-digit PIN and submit a day-end sheet |
| Client-wise and work-wise summaries | Clients and work types come from admin-managed dropdown lists |
| Done vs pending due to data availability | Each task is Completed or Pending with a reason; "data awaited from client" records what is awaited |
| Pending tasks in next day's opening sheet | Carried forward automatically with original date and days pending (holidays and leave handled) |
| Compile for all staff | One click builds a 7-sheet Excel report; shows who has not submitted |
| Weekly summary | Monday–Sunday workbook with a daily chart, client/work/staff totals |
| Automatic email | Gmail at 7 pm via Windows Task Scheduler, daily report attached (weekly on a chosen day) |

## Download the EXE (no Python needed)

1. Open the **Actions** tab of this repository.
2. Click the latest successful **Build Windows EXE** run (green tick).
3. Under **Artifacts**, download **DailyStaffReport-exe** and unzip it.
4. Share `DailyStaffReport.exe` with staff (for example through a shared Google Drive folder).

Or build it yourself on Windows: install Python 3.10+ (tick *Add python.exe to PATH*) and
double-click **`BUILD_EXE.bat`**. The file appears in the `dist` folder.

## How it works

```
Staff PCs  ──sync──>  Shared Google Drive folder  <──sync──  Admin PC  ──7 pm──>  Gmail  ──>  Partner
(exe)                 masters.json                         (compile reports,
                      security/<staff>.json (PIN hashes)    Task Scheduler)
                      entries/YYYY-MM-DD/<staff>.json
                      reports/*.xlsx
```

* No server or database. Each staff member writes only their own file per day, so there are
  no clashes on a shared Google Drive / OneDrive / network folder.
* PINs are stored only as salted PBKDF2 hashes. The Gmail App Password stays on the admin's
  PC, encrypted with Windows DPAPI.

## Project files

| File | Purpose |
| --- | --- |
| `dsr_app.py` | Screens: staff entry and admin panel (Tkinter) |
| `dsr_core.py` | Data storage and carry-forward logic |
| `dsr_report.py` | Daily Excel report (openpyxl) |
| `dsr_weekly.py` | Weekly Excel report |
| `dsr_auth.py` | Staff and admin PIN login |
| `dsr_email.py` | Gmail sending and the 7 pm scheduled task |
| `demo_data.py` | Sample data for demonstrations |
| `tests/` | Automated tests (`test_core.py`, `test_v2.py`, `gui_smoke.py`) |
| `BUILD_EXE.bat` | Builds `DailyStaffReport.exe` on Windows |
| `USER_GUIDE.md` | Full user guide |

## Run from source

```
pip install -r requirements.txt
python dsr_app.py
```

Try it with sample data: `python demo_data.py C:\DSR_Demo`, then choose that folder in the app
(admin PIN `1234`; each staff member's first login PIN is `0000`).

Run the tests: `python tests/test_core.py` and `python tests/test_v2.py`.

## Screenshots

| Login | Admin day-end compile |
| --- | --- |
| ![](screenshots/01_login_screen.png) | ![](screenshots/04_admin_day_end_compile.png) |
| **Weekly summary** | **Auto email settings** |
| ![](screenshots/05_admin_weekly_summary.png) | ![](screenshots/06_admin_auto_email.png) |
