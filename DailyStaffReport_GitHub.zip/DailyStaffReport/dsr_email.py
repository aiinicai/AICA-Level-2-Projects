"""
Automatic day-end email through Gmail.

* Sends from the admin's Gmail using a Gmail "App Password" (needs 2-Step Verification),
  via smtp.gmail.com port 465 (SSL).
* Email settings live ONLY on the admin's PC (%APPDATA%\\DailyStaffReport\\settings.json),
  never in the shared Google Drive folder. On Windows the App Password is encrypted with
  the Windows user account (DPAPI), so another user or PC cannot read it.
* A Windows Task Scheduler task runs  DailyStaffReport.exe --auto-email  at the chosen time.
  If the PC was off/asleep at that time, Windows runs it as soon as the PC is back on.
"""

from __future__ import annotations

import base64
import os
import smtplib
import ssl
import subprocess
import sys
import tempfile
from datetime import date, datetime
from email.message import EmailMessage
from html import escape

from dsr_core import (APP_NAME, REASON_DATA, STATUS_COMPLETED, STATUS_PENDING, Store,
                      days_pending, iso, load_local_settings, local_settings_path,
                      save_local_settings, to_display)

SMTP_HOST, SMTP_PORT = "smtp.gmail.com", 465
TASK_NAME = "DailyStaffReport Auto Email"
WEEKDAYS = ["None", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


# ------------------------------------------------------------------ password protection
def _dpapi(data: bytes, encrypt: bool) -> bytes:
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    buf = ctypes.create_string_buffer(data, len(data))
    inp, out = BLOB(len(data), buf), BLOB()
    fn = ctypes.windll.crypt32.CryptProtectData if encrypt else ctypes.windll.crypt32.CryptUnprotectData
    if not fn(ctypes.byref(inp), None, None, None, None, 0, ctypes.byref(out)):
        raise OSError("Windows could not protect/unprotect the password.")
    try:
        return ctypes.string_at(out.pbData, out.cbData)
    finally:
        ctypes.windll.kernel32.LocalFree(out.pbData)


def protect(secret: str) -> str:
    if sys.platform.startswith("win"):
        return "dpapi:" + base64.b64encode(_dpapi(secret.encode(), True)).decode()
    return "b64:" + base64.b64encode(secret.encode()).decode()


def unprotect(token: str) -> str:
    if not token:
        return ""
    kind, _, body = token.partition(":")
    raw = base64.b64decode(body)
    return (_dpapi(raw, False) if kind == "dpapi" else raw).decode()


# ------------------------------------------------------------------ settings
def email_settings() -> dict:
    e = load_local_settings().get("email", {})
    e.setdefault("sender", "")
    e.setdefault("recipients", "")
    e.setdefault("time", "19:00")
    e.setdefault("weekly_day", "Saturday")
    return e


def save_email_settings(sender, app_password, recipients, at_time, weekly_day) -> dict:
    s = load_local_settings()
    e = s.get("email", {})
    e.update(sender=sender.strip(), recipients=recipients.strip(), time=at_time.strip(),
             weekly_day=weekly_day)
    if app_password:
        e["app_password"] = protect(app_password.replace(" ", ""))
    s["email"] = e
    save_local_settings(s)
    return e


# ------------------------------------------------------------------ content
def daily_summary_html(store: Store, day: str) -> tuple[str, str]:
    m = store.masters()
    status = store.submission_status(day)
    rows = [{**t, "staff": s["staff"]} for s in store.all_sheets(day) for t in s.get("tasks", [])]
    pend = [t for t in rows if t.get("status") == STATUS_PENDING]
    data = [t for t in pend if t.get("pending_reason") == REASON_DATA]
    missing = [r[0] for r in status if not r[1]]
    done = len(rows) - len(pend)
    subject = (f"Day-end report {to_display(day)}: {done} completed, {len(pend)} pending"
               + (f", {len(missing)} not submitted" if missing else ""))

    def tr(cells, head=False):
        tag = "th" if head else "td"
        st = ' style="background:#1F3864;color:#fff;padding:4px 8px;text-align:left"' if head \
            else ' style="border-bottom:1px solid #ddd;padding:4px 8px"'
        return "<tr>" + "".join(f"<{tag}{st}>{escape(str(c))}</{tag}>" for c in cells) + "</tr>"

    h = [f"<div style='font-family:Segoe UI,Arial;font-size:14px'>",
         f"<h2 style='color:#1F3864;margin-bottom:4px'>{escape(m['firm_name'])}</h2>",
         f"<p>Day-end staff work report for <b>{to_display(day)}</b></p>",
         "<table cellspacing=0>",
         tr(["Staff submitted", f"{len(status) - len(missing)} of {len(status)}"]),
         tr(["Not submitted", ", ".join(missing) or "None – all submitted"]),
         tr(["Completed today", done]), tr(["Pending", len(pend)]),
         tr(["Pending – data awaited from client", len(data)]), "</table>"]
    if data:
        h += ["<h3 style='color:#C55A11'>Data awaited from clients (follow up)</h3>",
              "<table cellspacing=0>", tr(["Client", "Work", "Awaited", "Days", "Staff"], True)]
        for t in sorted(data, key=lambda x: -days_pending(x, day)):
            h.append(tr([t["client"], t["work_type"], t.get("awaited_details", ""),
                         days_pending(t, day), t["staff"]]))
        h.append("</table>")
    h += ["<p style='color:#595959'>Full client-wise, work-wise and pending details are in the "
          "attached Excel report.</p>", f"<p style='color:#999;font-size:11px'>Sent automatically "
          f"by {APP_NAME}.</p></div>"]
    return subject, "\n".join(h)


# ------------------------------------------------------------------ sending
def send_mail(e: dict, subject: str, html: str, attachments=()) -> None:
    sender = e.get("sender", "")
    pwd = unprotect(e.get("app_password", ""))
    to = [x.strip() for x in (e.get("recipients") or sender).replace(";", ",").split(",") if x.strip()]
    if not sender or not pwd or not to:
        raise ValueError("Email is not set up: enter the Gmail address, App Password and recipients.")
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = sender, ", ".join(to), subject
    msg.set_content("Please view this email in HTML. The Excel report is attached.")
    msg.add_alternative(html, subtype="html")
    for p in attachments:
        with open(p, "rb") as f:
            msg.add_attachment(f.read(), maintype="application",
                               subtype="vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                               filename=os.path.basename(p))
    with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, context=ssl.create_default_context(), timeout=60) as s:
        s.login(sender, pwd)
        s.send_message(msg)


def send_day_report(day: str | None = None, store: Store | None = None) -> str:
    """Compiles the day's report (and the weekly one on the chosen weekday) and emails it."""
    from dsr_weekly import build_weekly_report
    day = day or iso(date.today())
    s = load_local_settings()
    if store is None:
        if not s.get("shared_folder") or not os.path.isdir(s["shared_folder"]):
            raise ValueError("Shared folder not found. Open the app once on this PC and select "
                             "the shared Google Drive folder (and check Google Drive is running).")
        store = Store(s["shared_folder"])
    e = email_settings()
    files = [store.compile_report(day)]
    subject, html = daily_summary_html(store, day)
    if e.get("weekly_day") == datetime.strptime(day, "%Y-%m-%d").strftime("%A"):
        files.append(build_weekly_report(store, day))
        subject += " + weekly summary"
    send_mail(e, subject, html, files)
    return subject


def _log(msg: str) -> None:
    p = os.path.join(os.path.dirname(local_settings_path()), "email_log.txt")
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {msg}\n")


def auto_email_main() -> int:
    """Entry point for the scheduled task (no windows shown). Sends once per day."""
    today = iso(date.today())
    s = load_local_settings()
    if s.get("email", {}).get("last_sent") == today:
        _log("Already sent today - skipped.")
        return 0
    try:
        subject = send_day_report(today)
        s = load_local_settings()
        s.setdefault("email", {})["last_sent"] = today
        save_local_settings(s)
        _log("SENT: " + subject)
        return 0
    except Exception as ex:  # keep a record for the admin
        _log(f"FAILED: {ex!r}")
        return 1


# ------------------------------------------------------------------ Windows Task Scheduler
def _launch_command() -> tuple[str, str]:
    if getattr(sys, "frozen", False):            # running as DailyStaffReport.exe
        return sys.executable, "--auto-email"
    pyw = os.path.join(os.path.dirname(sys.executable), "pythonw.exe")
    script = os.path.abspath(os.path.join(os.path.dirname(__file__), "dsr_app.py"))
    return (pyw if os.path.exists(pyw) else sys.executable), f'"{script}" --auto-email'


def task_xml(at_time: str) -> str:
    exe, args = _launch_command()
    hh, mm = at_time.split(":")
    start = f"{date.today().isoformat()}T{int(hh):02d}:{int(mm):02d}:00"
    esc = lambda x: escape(x, quote=True)
    return f"""<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <RegistrationInfo><Description>Emails the Daily Staff Report every day.</Description></RegistrationInfo>
  <Triggers><CalendarTrigger><StartBoundary>{start}</StartBoundary><Enabled>true</Enabled>
    <ScheduleByDay><DaysInterval>1</DaysInterval></ScheduleByDay></CalendarTrigger></Triggers>
  <Principals><Principal id="Author"><LogonType>InteractiveToken</LogonType>
    <RunLevel>LeastPrivilege</RunLevel></Principal></Principals>
  <Settings><MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <StartWhenAvailable>true</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>true</RunOnlyIfNetworkAvailable>
    <ExecutionTimeLimit>PT30M</ExecutionTimeLimit><Enabled>true</Enabled></Settings>
  <Actions Context="Author"><Exec><Command>{esc(exe)}</Command><Arguments>{esc(args)}</Arguments>
    <WorkingDirectory>{esc(os.path.dirname(exe))}</WorkingDirectory></Exec></Actions>
</Task>"""


def install_schedule(at_time: str) -> None:
    datetime.strptime(at_time, "%H:%M")             # validates HH:MM
    if not sys.platform.startswith("win"):
        raise OSError("Scheduling is available on Windows only.")
    path = os.path.join(tempfile.gettempdir(), "dsr_task.xml")
    with open(path, "w", encoding="utf-16") as f:
        f.write(task_xml(at_time))
    r = subprocess.run(["schtasks", "/Create", "/TN", TASK_NAME, "/XML", path, "/F"],
                       capture_output=True, text=True, creationflags=0x08000000)
    os.remove(path)
    if r.returncode:
        raise OSError((r.stderr or r.stdout).strip())


def remove_schedule() -> None:
    if not sys.platform.startswith("win"):
        raise OSError("Scheduling is available on Windows only.")
    r = subprocess.run(["schtasks", "/Delete", "/TN", TASK_NAME, "/F"], capture_output=True,
                       text=True, creationflags=0x08000000)
    if r.returncode:
        raise OSError((r.stderr or r.stdout).strip())


def schedule_status() -> str:
    if not sys.platform.startswith("win"):
        return "Not available on this system"
    r = subprocess.run(["schtasks", "/Query", "/TN", TASK_NAME, "/FO", "LIST"],
                       capture_output=True, text=True, creationflags=0x08000000)
    if r.returncode:
        return "Not scheduled"
    nxt = [l.split(":", 1)[1].strip() for l in r.stdout.splitlines() if l.startswith("Next Run Time")]
    return f"Scheduled. Next run: {nxt[0]}" if nxt else "Scheduled"
