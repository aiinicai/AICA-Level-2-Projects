# Daily Staff Report v2.0: User Guide

A Windows desktop app that lets every staff member submit a day-end work report.
The app keeps an **opening sheet** of pending work for each person, and the partner/admin
can compile everyone's entries into one Excel report with **client-wise**, **work-wise**
and **pending** summaries.

---

## 1. Problem it solves

| Requirement | How the software handles it |
|---|---|
| Daily reporting by staff at day end | Each staff member picks their name, enters tasks and clicks **Save & Submit Day-End Report** |
| Summary client-wise and work-wise | Clients and work types come from admin-managed dropdowns, so the totals are always consistent. The Excel report has **Client-wise** and **Work-wise** sheets |
| Show work done or pending due to data availability | Every task is **Completed** or **Pending** with a reason. *"Data / documents awaited from client"* is tracked separately, along with what data is awaited |
| Pending tasks appear in the next day's opening sheet | When the app opens a new day, it automatically brings forward every pending task (blue rows). It keeps the original date and counts the **days pending**. Holidays and leave are handled because it looks back to the person's last report |
| Secure staff entry | Each person logs in with their name and own 4-digit PIN (stored only as a salted hash) |
| Weekly picture | **Admin → Weekly Summary** builds a Monday–Sunday workbook with a daily chart |
| Report reaches the partner automatically | **Admin → Auto Email** sends the day-end report by Gmail at 7 pm every day |
| Compile for all staff at day end | **Admin → Day-End Compile** shows who has and hasn't submitted, then creates one Excel workbook for the whole office |

---

## 2. One-time setup (Admin / Partner)

1. **Create the shared folder.** Every staff PC needs to reach it, for example:
   * an office network drive: `\\OFFICE-PC\DailyReports` or `S:\DailyReports`, **or**
   * a OneDrive / Google Drive folder that is shared with all staff and synced on each PC.
2. **Build the EXE** (once, on any Windows PC that has Python installed):
   double-click **`BUILD_EXE.bat`**. Your file will be `dist\DailyStaffReport.exe`.
3. Run the EXE and select the shared folder when it asks.
4. Click **⚙ Admin / Day-End Compile**. The default PIN is **1234**.
   * **Settings** tab: enter the firm name and **change the PIN**.
   * **Masters** tab: add staff names, clients and work types.
     Use **Bulk add…** to paste a whole client list from Excel. Then click **Save Masters**.
5. Send `DailyStaffReport.exe` to all staff by email or WhatsApp, or copy it onto their PCs.
   On first run, each person selects the **same** shared folder.

> Windows may show a "Windows protected your PC" message the first time, because the EXE
> isn't code-signed. Click **More info → Run anyway**.

---

## 3. Daily use: staff

**First login:** select your name, type PIN **0000**, click **Log in**, then choose your own
4-digit PIN when asked. After that, always log in with your own PIN. Forgot it? Ask the admin
to use **Masters → Reset PIN of selected staff**.

1. Open the app. Select **your name**, type your **PIN**, click **Log in**, and check that the
   **date** is today.
2. The grid opens with your **opening sheet**: the blue rows are tasks still pending from your
   last working day.
   * If you finished one today, select it and click **✔ Mark selected Completed**.
     Enter the hours if you like.
   * If it's still pending, click it, update the reason or remarks, and click **Update Task**.
3. For each new piece of work, fill in the form:
   **Client → Work type → Task description → Status**.
   If the status is *Pending*, choose a **reason**. For *data awaited*, also write **what data**
   is awaited (for example, "Purchase register Oct").
   Click **➕ Add Task**.
4. At the end of the day, click **💾 Save & Submit Day-End Report**.
   You can re-submit later the same day if something changes.

Row colours: 🟩 Completed · 🟨 Pending (work) · 🟧 Pending (data awaited) · 🟦 Carried forward

---

## 4. Day-end: admin

**⚙ Admin → Day-End Compile**
* The list shows every staff member. **Red** means they haven't submitted yet.
* Click **📊 Compile Excel Report**. The file is saved as
  `reports\Daily_Report_YYYY-MM-DD.xlsx` in the shared folder.

The workbook contains:

| Sheet | What it shows |
|---|---|
| Dashboard | Who submitted, total tasks, completed, pending, pending due to data, items pending 3+ days, hours |
| Client-wise | Totals per client, then every task grouped by client |
| Work-wise | Totals per work type (GST, ITR, Audit…), then the detailed tasks |
| Staff-wise | Each person's work for the day |
| Pending - Next Day Opening | All pending tasks, oldest first, with days pending |
| Data Awaited - Follow-up | Client-wise list of data or documents to chase, ready for reminder calls or mails |
| All Entries | Raw data with filters |

### Weekly summary
**Admin → Weekly Summary**: pick any date in the week and click **Compile Weekly Report**.
The file `Weekly_Report_<Mon>_to_<Sun>.xlsx` has: Week Dashboard (who reported each day),
Daily Trend with a chart, Client-wise, Work-wise, Staff-wise, Pending at Week End and a Task
Register. A task carried over several days is counted once, with its hours added up.

### Automatic 7 pm email (Gmail)
1. Turn on **2-Step Verification** at myaccount.google.com → Security.
2. Open **myaccount.google.com/apppasswords**, type the name *Daily Report*, click **Create**,
   and copy the 16-letter password.
3. In **Admin → Auto Email**, enter your Gmail, the App Password, who should receive it, and
   the time (19:00). Choose a weekday to also attach the weekly summary.
4. Click **Send today's report now (test)**. When the test email arrives, click
   **Turn ON daily auto email**.

The email runs from the admin's PC through Windows Task Scheduler. If the PC is off at 7 pm,
it sends as soon as the PC is back on. It sends only once per day, and every attempt is
recorded in **View email log**. The App Password is stored only on that PC, encrypted with
the Windows login, and never in the shared folder.

### Forgot the admin PIN
Open `masters.json` in the shared folder with Notepad and add the line
`"admin_pin": "1234",` just after the first `{`. Save, log in with 1234, then set a new PIN
in **Settings**.

---

## 5. How data is stored

```
SharedFolder\
  masters.json                       staff, clients, work types, firm name, admin PIN (hashed)
  security\Amit_Verma.json           each staff member's PIN (salted hash only)
  entries\2026-11-24\Amit_Verma.json  one file per staff per day
  reports\Daily_Report_2026-11-24.xlsx
  reports\Weekly_Report_2026-11-23_to_2026-11-29.xlsx
```
* Each person writes only **their own file**, so several staff can submit at the same time
  without overwriting each other.
* Plain JSON files make the data easy to back up: just copy the folder.

## 6. Demo data for presentations
`python demo_data.py "D:\DSR_Demo"` creates a sample firm with 4 staff and 3 days of
entries. Select that folder in the app to demonstrate the software (admin PIN 1234; each
staff member's first login uses PIN 0000).

## 7. Files
| File | Purpose |
|---|---|
| `dsr_app.py` | Desktop screens (Tkinter) |
| `dsr_core.py` | Data storage, opening-sheet carry-forward logic |
| `dsr_report.py` | Daily Excel report builder (openpyxl) |
| `dsr_weekly.py` | Weekly summary workbook |
| `dsr_auth.py` | Staff and admin PIN login |
| `dsr_email.py` | Gmail sending and the 7 pm scheduled task |
| `demo_data.py` | Sample data generator |
| `tests/` | Automated tests |
| `BUILD_EXE.bat` | Builds `DailyStaffReport.exe` on Windows |
| `.github/workflows/` | Optional: builds the EXE automatically on GitHub |
