"""Builds the compiled day-end Excel workbook for all staff."""

from __future__ import annotations

from collections import OrderedDict, defaultdict
from datetime import datetime

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from dsr_core import (REASON_DATA, STATUS_COMPLETED, STATUS_PENDING, days_pending,
                      to_display)

NAVY = "1F3864"
F_HEAD = PatternFill("solid", fgColor=NAVY)
F_SUB = PatternFill("solid", fgColor="D9E1F2")
F_DONE = PatternFill("solid", fgColor="E2EFDA")
F_PEND = PatternFill("solid", fgColor="FFF2CC")
F_DATA = PatternFill("solid", fgColor="FCE4D6")
F_OLD = PatternFill("solid", fgColor="F8CBAD")
F_MISS = PatternFill("solid", fgColor="F4CCCC")
WHITE_B = Font(bold=True, color="FFFFFF")
BOLD = Font(bold=True)
THIN = Side(style="thin", color="BFBFBF")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")

DETAIL_COLS = [
    ("Client", 24), ("Work Type", 22), ("Staff", 16), ("Task Description", 40),
    ("Status", 11), ("Pending Reason", 30), ("Data / Info Awaited", 30),
    ("Pending Since", 13), ("Days Pending", 9), ("Hours", 7), ("Remarks", 28),
]


def _rows(sheets, day):
    out = []
    for s in sheets:
        for t in s.get("tasks", []):
            out.append({**t, "staff": s["staff"], "_days": days_pending(t, day)})
    return out


def _header(ws, row, cols):
    for i, (name, width) in enumerate(cols, 1):
        c = ws.cell(row=row, column=i, value=name)
        c.fill, c.font, c.border = F_HEAD, WHITE_B, BOX
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[row].height = 30


def _title(ws, firm, title, day, ncols):
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncols)
    ws["A1"] = f"{firm} — {title}"
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    ws["A2"] = (f"Report date: {to_display(day)}    |    Compiled on: "
                f"{datetime.now().strftime('%d-%m-%Y %H:%M')}")
    ws["A2"].font = Font(italic=True, color="595959")


def _detail_row(ws, r, t, day):
    pend = t.get("status") == STATUS_PENDING
    vals = [
        t.get("client"), t.get("work_type"), t.get("staff"), t.get("description"),
        t.get("status"), t.get("pending_reason") if pend else "",
        t.get("awaited_details") if pend else "",
        to_display(t.get("origin_date") or day) if pend else "",
        t["_days"] if pend else "", float(t.get("hours") or 0) or None, t.get("remarks"),
    ]
    fill = F_DONE
    if pend:
        fill = F_DATA if t.get("pending_reason") == REASON_DATA else F_PEND
    for i, v in enumerate(vals, 1):
        c = ws.cell(row=r, column=i, value=v)
        c.border, c.alignment = BOX, WRAP
        c.fill = fill
    if pend and t["_days"] >= 3:
        ws.cell(row=r, column=9).fill = F_OLD
        ws.cell(row=r, column=9).font = BOLD


def _summary_table(ws, start_row, key, rows, label):
    cols = [(label, 30), ("Total Tasks", 11), ("Completed", 11), ("Pending", 10),
            ("Pending – Data Awaited", 14), ("Hours", 9), ("Staff Involved", 36)]
    _header(ws, start_row, cols)
    ws.row_dimensions[start_row].height = 45
    groups = OrderedDict()
    for t in sorted(rows, key=lambda x: (str(x.get(key) or "")).lower()):
        groups.setdefault(t.get(key) or "(blank)", []).append(t)
    r = start_row + 1
    for g, ts in groups.items():
        done = sum(t["status"] == STATUS_COMPLETED for t in ts)
        pend = len(ts) - done
        data = sum(t["status"] == STATUS_PENDING and t.get("pending_reason") == REASON_DATA
                   for t in ts)
        hrs = sum(float(t.get("hours") or 0) for t in ts)
        staff = ", ".join(sorted({t["staff"] for t in ts}))
        for i, v in enumerate([g, len(ts), done, pend, data, round(hrs, 2), staff], 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border, c.alignment = BOX, WRAP
        if pend:
            ws.cell(row=r, column=4).fill = F_PEND
        if data:
            ws.cell(row=r, column=5).fill = F_DATA
        r += 1
    # totals with live formulas
    ws.cell(row=r, column=1, value="TOTAL").font = BOLD
    for col in range(2, 7):
        L = get_column_letter(col)
        c = ws.cell(row=r, column=col, value=f"=SUM({L}{start_row + 1}:{L}{r - 1})")
        c.font, c.fill, c.border = BOLD, F_SUB, BOX
    ws.cell(row=r, column=1).fill = F_SUB
    return r + 2, groups


def _grouped_detail(ws, start_row, groups, day, group_label):
    ws.cell(row=start_row, column=1, value=f"Detailed tasks — {group_label}").font = Font(
        bold=True, size=12, color=NAVY)
    r = start_row + 1
    _header(ws, r, DETAIL_COLS)
    r += 1
    for g, ts in groups.items():
        c = ws.cell(row=r, column=1, value=f"▶ {g}  ({len(ts)} task(s))")
        for i in range(1, len(DETAIL_COLS) + 1):
            ws.cell(row=r, column=i).fill = F_SUB
        c.font = BOLD
        r += 1
        for t in sorted(ts, key=lambda x: (x["status"] != STATUS_PENDING, x["staff"])):
            _detail_row(ws, r, t, day)
            r += 1
    return r


def build_report(store, day: str, out_path: str) -> str:
    m = store.masters()
    firm = m.get("firm_name") or "Firm"
    sheets = store.all_sheets(day)
    rows = _rows(sheets, day)
    status = store.submission_status(day)
    pending = [t for t in rows if t["status"] == STATUS_PENDING]
    data_wait = [t for t in pending if t.get("pending_reason") == REASON_DATA]

    wb = Workbook()

    # 1. Dashboard ----------------------------------------------------------------
    ws = wb.active
    ws.title = "Dashboard"
    _title(ws, firm, "Day-End Staff Work Report", day, 6)
    submitted = [s for s in status if s[1]]
    missing = [s[0] for s in status if not s[1]]
    kpis = [
        ("Staff submitted", f"{len(submitted)} of {len(status)}"),
        ("Not yet submitted", ", ".join(missing) if missing else "None — all submitted ✓"),
        ("Total tasks reported", len(rows)),
        ("Completed today", sum(t["status"] == STATUS_COMPLETED for t in rows)),
        ("Pending (carried to next day)", len(pending)),
        ("   of which: data / documents awaited from client", len(data_wait)),
        ("   of which: pending 3+ days", sum(t["_days"] >= 3 for t in pending)),
        ("Total hours logged", round(sum(float(t.get("hours") or 0) for t in rows), 2)),
    ]
    r = 4
    for k, v in kpis:
        a = ws.cell(row=r, column=1, value=k)
        b = ws.cell(row=r, column=2, value=v)
        a.font, a.border, b.border = BOLD, BOX, BOX
        a.fill = F_SUB
        b.alignment = Alignment(wrap_text=True)
        if k == "Not yet submitted" and missing:
            b.fill = F_MISS
        r += 1
    ws.column_dimensions["A"].width = 46
    ws.column_dimensions["B"].width = 40
    r += 1
    ws.cell(row=r, column=1, value="Staff-wise submission status").font = Font(
        bold=True, size=12, color=NAVY)
    r += 1
    scols = [("Staff", 46), ("Submitted At", 40), ("Tasks", 9), ("Completed", 11),
             ("Pending", 10), ("Hours", 9)]
    for i, (n, _w) in enumerate(scols, 1):
        c = ws.cell(row=r, column=i, value=n)
        c.fill, c.font, c.border = F_HEAD, WHITE_B, BOX
    ws.column_dimensions["C"].width = 9
    ws.column_dimensions["D"].width = 11
    ws.column_dimensions["E"].width = 10
    ws.column_dimensions["F"].width = 9
    hrs_by = defaultdict(float)
    for t in rows:
        hrs_by[t["staff"]] += float(t.get("hours") or 0)
    for name, ts, n, d, p in status:
        r += 1
        vals = [name, ts or "NOT SUBMITTED", n, d, p, round(hrs_by[name], 2)]
        for i, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border = BOX
            if not ts:
                c.fill = F_MISS
    r += 2
    ws.cell(row=r, column=1, value="Colour key:").font = BOLD
    for i, (txt, fill) in enumerate([("Completed", F_DONE), ("Pending – work", F_PEND),
                                     ("Pending – data awaited", F_DATA),
                                     ("Pending 3+ days", F_OLD)], 1):
        c = ws.cell(row=r + i, column=1, value=txt)
        c.fill, c.border = fill, BOX

    # 2. Client-wise -------------------------------------------------------------
    ws = wb.create_sheet("Client-wise")
    _title(ws, firm, "Client-wise Summary", day, 11)
    nxt, groups = _summary_table(ws, 4, "client", rows, "Client")
    _grouped_detail(ws, nxt, groups, day, "grouped by client")
    ws.freeze_panes = "A5"

    # 3. Work-wise ---------------------------------------------------------------
    ws = wb.create_sheet("Work-wise")
    _title(ws, firm, "Work-type-wise Summary", day, 11)
    nxt, groups = _summary_table(ws, 4, "work_type", rows, "Work Type")
    _grouped_detail(ws, nxt, groups, day, "grouped by work type")
    ws.freeze_panes = "A5"

    # 4. Staff-wise --------------------------------------------------------------
    ws = wb.create_sheet("Staff-wise")
    _title(ws, firm, "Staff-wise Work Done", day, 11)
    nxt, groups = _summary_table(ws, 4, "staff", rows, "Staff")
    _grouped_detail(ws, nxt, groups, day, "grouped by staff")
    ws.freeze_panes = "A5"

    # 5. Pending / next-day opening ----------------------------------------------
    ws = wb.create_sheet("Pending - Next Day Opening")
    _title(ws, firm, "Pending Tasks → Next Day Opening Sheet", day, 11)
    _header(ws, 4, DETAIL_COLS)
    r = 5
    for t in sorted(pending, key=lambda x: (-x["_days"], x["staff"], str(x["client"]))):
        _detail_row(ws, r, t, day)
        r += 1
    if not pending:
        ws.cell(row=5, column=1, value="No pending tasks 🎉")
    ws.auto_filter.ref = f"A4:{get_column_letter(len(DETAIL_COLS))}{max(r - 1, 4)}"
    ws.freeze_panes = "A5"

    # 6. Data awaited – client follow-up -----------------------------------------
    ws = wb.create_sheet("Data Awaited - Follow-up")
    _title(ws, firm, "Data / Documents Awaited from Clients (for follow-up)", day, 7)
    cols = [("Client", 26), ("Work Type", 22), ("Data / Documents Awaited", 44),
            ("Pending Since", 13), ("Days", 7), ("Staff Responsible", 18), ("Remarks", 30)]
    _header(ws, 4, cols)
    r = 5
    for t in sorted(data_wait, key=lambda x: (str(x["client"]).lower(), -x["_days"])):
        vals = [t["client"], t["work_type"], t.get("awaited_details") or t.get("description"),
                to_display(t.get("origin_date") or day), t["_days"], t["staff"], t.get("remarks")]
        for i, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=i, value=v)
            c.border, c.alignment, c.fill = BOX, WRAP, F_DATA
        r += 1
    if not data_wait:
        ws.cell(row=5, column=1, value="Nothing awaited from clients.")
    ws.freeze_panes = "A5"

    # 7. All entries (raw, filterable) -------------------------------------------
    ws = wb.create_sheet("All Entries")
    _title(ws, firm, "All Entries (raw data)", day, 11)
    _header(ws, 4, DETAIL_COLS)
    r = 5
    for t in sorted(rows, key=lambda x: (x["staff"], str(x["client"]))):
        _detail_row(ws, r, t, day)
        r += 1
    ws.auto_filter.ref = f"A4:{get_column_letter(len(DETAIL_COLS))}{max(r - 1, 4)}"
    ws.freeze_panes = "A5"

    for w in wb.worksheets:
        w.sheet_view.showGridLines = False
        w.page_setup.orientation = "landscape"
        w.page_setup.fitToWidth = 1
        w.page_setup.fitToHeight = 0
        w.sheet_properties.pageSetUpPr.fitToPage = True

    wb.save(out_path)
    return out_path
