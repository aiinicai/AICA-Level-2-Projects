# PropFlow - cash flow and revenue vs collection (runs on your own computer)

## Start it (IDLE)
1. Open **start_propflow.py** in IDLE (File > Open).
2. Press **F5**. The first time it installs one small free package, openpyxl (internet needed once).
3. PropFlow opens as a normal window (not a browser). Close the window to stop it.

**Interface:** the colourful PyQt6 version starts when PyQt6 can be installed. PyQt6 is a compiled package, so if your
company blocks it (as it blocked pandas), PropFlow automatically opens the plain built-in version instead - same
features, same data. To force the plain version, set the environment variable PROPFLOW_UI=tk.

It uses only Python's built-in parts plus openpyxl, which is plain Python. There is nothing compiled to be
blocked by a company Application Control policy.

(Windows alternative: double-click **START_PROPFLOW.bat**.)

## One-time setup (tab 6 Setup)
1. **Bank accounts**: one row per collection bank account for each country (GL code, name, account number).
   Pick the country at the top first; UAE and KSA are kept completely separate.
2. **Property code mapping**: only if the same property has different codes in different reports, or one code
   must be merged into another (for example `parking` into `ebp2`). The Revenue vs Collection tab warns you
   when a property has collection but no revenue, which is the sign a mapping is needed.

## Every month
1. **Tab 1 Upload**: add each bank ledger (the app guesses the account from the file name; check it), then
   Import. Upload the ERP reports for Revenue vs Collection and set the period they cover.
2. **Tab 5 Review & rules**: anything the rules could not recognise appears as "Unclassified" (red) on the
   report. Pick its category, or add a rule so it is recognised next time.
3. **Tab 2** = the bank-by-bank statement for a month. **Tab 3** = the multi-month summary. **Tab 4** = revenue
   vs collection. Each has a save-as-Excel button (live formulas).

Uploading the same period again replaces it, so re-doing a month is safe. Opening balances roll forward from the
previous month automatically; the first one comes from the first ledger file (or type it in Setup).

## How the numbers are worked out
- **Money in / out**: for a company-books ledger, Debit = money in. For a bank statement, Credit = money in.
  "Auto-detect" decides from the running balance (or from where the R- receipts sit) and tells you what it chose.
- **Rent Collection**: reference starts with `R-` and money in. An `R-` reference with money OUT (a returned cheque)
  reduces Rent Collection instead of being counted as a payment.
- **Bank charges, interbank transfers, etc.**: by words in the description (editable rules, tab 5).
- **Checks on the cash flow**: closing balance is compared with the running balance in the ledger file;
  months with no ledger uploaded are flagged.
- **Revenue** = GL accounts starting with 4 from the trial balance, with credits positive and debits (discounts) negative.
- **VAT** = VAT amount in the receipt register; **Security deposits** = net of all lines (reversals reduce it).
- **Net advance / (receivable)** = Collection - (Revenue + VAT + Security deposits).
- VAT and deposit lines are matched to the period by receipt date (changeable to posting period in Setup > Settings).

## Where your data is
`data/propflow.db` next to the app. Copy that file to back it up (there is also a backup button in Setup).

## Try it with sample files
The `samples` folder has small invented files that imitate your ERP layouts. Upload them to a test country
setup to see how everything works, then delete `data/propflow.db` before loading real data.
