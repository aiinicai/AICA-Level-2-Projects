"""PropFlow - cash flow and revenue-vs-collection reporting.

A normal desktop window (Tkinter, part of Python). Everything runs and stays on this computer.
Needs only the Python standard library plus openpyxl (plain Python, nothing compiled).
Start it with start_propflow.py (open in IDLE and press F5).
"""
import os
import shutil
import sys
import tkinter as tk
from datetime import date, datetime
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from core import cashflow, classify, db, export, ingest, parsers, recon  # noqa: E402
from core.parsers import ParseError  # noqa: E402

LEDGER_TYPES = [("auto", "Auto-detect (recommended)"),
                ("books", "Company books (Debit = money in)"),
                ("statement", "Bank statement (Credit = money in)")]
XLSX = [("Excel / CSV files", "*.xlsx *.xlsm *.xls *.csv"), ("All files", "*.*")]
KIND_TITLE = {"collection": "Cash collection", "tb": "Trial balance", "vat": "VAT register", "deposit": "Security deposits"}
NAVY, ACCENT, BG, CARD, LINE, MUTED = "#0F172A", "#4338CA", "#F4F6FA", "#FFFFFF", "#E2E8F0", "#64748B"
GOOD, WARN, BAD = "#15803D", "#C2410C", "#B91C1C"
BLUE, GREEN, GREY, YELLOW, RED = "#E0E7FF", "#DCFCE7", "#EEF1F6", "#FEF3C7", BAD
FONT, FONT_B = ("Segoe UI", 10), ("Segoe UI", 10, "bold")
NAV = [("sum", "Summary Sheet (Multi-Month)"), ("cf", "Bank Accounts Matrix"), ("rc", "Revenue vs Collection"),
       ("txn", "Transactions"), ("rules", "Rules"), ("up", "Upload"), ("set", "Setup")]


# ----------------------------------------------------------------------------- small helpers
def fmt(v):
    if v is None:
        return ""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    if v != v:
        return ""
    return "-" if abs(v) < 0.005 else f"{v:,.2f}"


def db_interbank_keys():
    from core import defaults
    return set(defaults.INTERBANK_KEYS)


def mlabel(m):
    return cashflow.month_label(m)


def month_keys(y0=2023, y1=2028):
    return [f"{y}-{m:02d}" for y in range(y0, y1 + 1) for m in range(1, 13)]


MONTH_LABELS = {k: mlabel(k) for k in month_keys()}
LABEL_TO_MONTH = {v: k for k, v in MONTH_LABELS.items()}


def make_tree(parent, columns, widths=None, anchors=None, height=12, selectmode="browse"):
    """Treeview with scrollbars. columns = list of heading texts. Returns (frame, tree)."""
    frame = ttk.Frame(parent)
    ids = [f"c{i}" for i in range(len(columns))]
    tree = ttk.Treeview(frame, columns=ids, show="headings", height=height, selectmode=selectmode)
    for i, (cid, head) in enumerate(zip(ids, columns)):
        tree.heading(cid, text=head)
        w = (widths[i] if widths and i < len(widths) else 110)
        a = (anchors[i] if anchors and i < len(anchors) else "w")
        tree.column(cid, width=w, anchor=a, stretch=(i == 0 or w >= 200))
    vs = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
    hs = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
    tree.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
    tree.grid(row=0, column=0, sticky="nsew")
    vs.grid(row=0, column=1, sticky="ns")
    hs.grid(row=1, column=0, sticky="ew")
    frame.rowconfigure(0, weight=1)
    frame.columnconfigure(0, weight=1)
    for tag, bg, fg in (("opening", BLUE, None), ("subtotal", GREEN, None), ("closing", GREEN, None),
                        ("net", GREY, None), ("bad", None, RED), ("total", GREEN, None), ("check", None, MUTED),
                        ("ib", YELLOW, None)):
        kw = {}
        if tag in ("opening", "subtotal", "closing", "total", "net"):
            kw["font"] = FONT_B
        if bg:
            kw["background"] = bg
        if fg:
            kw["foreground"] = fg
        tree.tag_configure(tag, **kw)
    return frame, tree


def clear(tree):
    tree.delete(*tree.get_children())


class Messages(tk.Text):
    """Small read-only area for warnings / checks / notes."""

    def __init__(self, parent, height=4):
        super().__init__(parent, height=height, wrap="word", relief="flat", background=CARD,
                         font=("Segoe UI", 9), state="disabled", borderwidth=0, padx=8, pady=4)
        self.tag_configure("warn", foreground=WARN)
        self.tag_configure("ok", foreground=GOOD)
        self.tag_configure("note", foreground=ACCENT)

    def show(self, warnings=(), checks=(), notes=(), info=()):
        self.configure(state="normal")
        self.delete("1.0", "end")
        for tag, items, prefix in (("warn", warnings, "⚠ "), ("ok", checks, "✓ "),
                                   ("note", notes, "ℹ "), ("note", info, "ℹ ")):
            for t in items:
                self.insert("end", prefix + t + "\n", tag)
        if not self.get("1.0", "end").strip():
            self.insert("end", "No warnings.", "ok")
        self.configure(state="disabled")
        lines = int(self.index("end-1c").split(".")[0])
        self.configure(height=max(2, min(8, lines + 1)))


def save_file(title, default_name, data):
    path = filedialog.asksaveasfilename(title=title, initialfile=default_name, defaultextension=".xlsx",
                                        filetypes=[("Excel workbook", "*.xlsx")])
    if not path:
        return
    try:
        with open(path, "wb") as fh:
            fh.write(data)
    except OSError as e:
        messagebox.showerror("Could not save", f"{e}\n\nIs the file open in Excel? Close it and try again.")
        return
    messagebox.showinfo("Saved", f"Saved to:\n{path}")
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)                      # open in Excel
    except Exception:
        pass


def page_header(parent, crumb, title, desc):
    """White title card. Returns (crumb_label, right_frame) - put action buttons in right_frame."""
    card = tk.Frame(parent, bg=CARD, highlightbackground=LINE, highlightthickness=1)
    card.pack(fill="x", pady=(0, 10))
    inner = tk.Frame(card, bg=CARD)
    inner.pack(fill="x", padx=18, pady=14)
    left = tk.Frame(inner, bg=CARD)
    left.pack(side="left", fill="x", expand=True)
    cl = tk.Label(left, text=crumb, bg=CARD, fg=MUTED, font=("Segoe UI", 9))
    cl.pack(anchor="w")
    tk.Label(left, text=title, bg=CARD, fg=NAVY, font=("Segoe UI", 16, "bold")).pack(anchor="w")
    tk.Label(left, text=desc, bg=CARD, fg=MUTED, font=("Segoe UI", 9), wraplength=950, justify="left").pack(anchor="w", pady=(2, 0))
    right = tk.Frame(inner, bg=CARD)
    right.pack(side="right", anchor="n")
    return cl, right


def kpi_row(parent, items):
    """items = [(title, colour)]. Returns the list of value labels."""
    row = tk.Frame(parent, bg=BG)
    row.pack(fill="x", pady=(0, 10))
    labs = []
    for i, (title, colour) in enumerate(items):
        c = tk.Frame(row, bg=CARD, highlightbackground=LINE, highlightthickness=1)
        c.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
        row.columnconfigure(i, weight=1, uniform="kpi")
        tk.Label(c, text=title, bg=CARD, fg=MUTED, font=("Segoe UI", 8, "bold")).pack(anchor="w", padx=14, pady=(10, 0))
        v = tk.Label(c, text="-", bg=CARD, fg=colour, font=("Segoe UI", 15, "bold"))
        v.pack(anchor="w", padx=14, pady=(0, 10))
        labs.append(v)
    return labs


def set_kpis(labs, values):
    for lab, v in zip(labs, values):
        lab.configure(text="-" if v is None else (f"{v:,.2f}" if abs(v) >= 0.005 else "-"))


class FormDialog(tk.Toplevel):
    """Generic modal form. fields: dict(key, label, kind='entry'|'combo'|'check', options=[...], width)."""

    def __init__(self, parent, title, fields, initial=None, validate=None, hint=None):
        super().__init__(parent)
        self.title(title)
        self.transient(parent)
        self.resizable(False, False)
        self.result = None
        self._vars, self._fields, self._validate = {}, fields, validate
        body = ttk.Frame(self, padding=14)
        body.grid()
        initial = initial or {}
        r = 0
        if hint:
            ttk.Label(body, text=hint, wraplength=460, foreground="#555").grid(row=r, column=0, columnspan=2, sticky="w", pady=(0, 8))
            r += 1
        for f in fields:
            ttk.Label(body, text=f["label"]).grid(row=r, column=0, sticky="w", padx=(0, 10), pady=3)
            val = initial.get(f["key"], f.get("default", ""))
            if f.get("kind") == "check":
                v = tk.BooleanVar(value=bool(int(val)) if str(val) not in ("", "None") else False)
                ttk.Checkbutton(body, variable=v).grid(row=r, column=1, sticky="w")
            elif f.get("kind") == "combo":
                opts = f["options"]
                labels = [o[1] if isinstance(o, tuple) else o for o in opts]
                v = tk.StringVar()
                cb = ttk.Combobox(body, textvariable=v, values=labels, state="readonly", width=f.get("width", 34))
                for o in opts:
                    if (o[0] if isinstance(o, tuple) else o) == val:
                        v.set(o[1] if isinstance(o, tuple) else o)
                if not v.get() and labels:
                    v.set(labels[0])
                cb.grid(row=r, column=1, sticky="w")
            else:
                v = tk.StringVar(value="" if val is None else str(val))
                ttk.Entry(body, textvariable=v, width=f.get("width", 38)).grid(row=r, column=1, sticky="w")
            self._vars[f["key"]] = v
            r += 1
        self._err = ttk.Label(body, text="", foreground="#B00020", wraplength=460)
        self._err.grid(row=r, column=0, columnspan=2, sticky="w", pady=(6, 0))
        bar = ttk.Frame(body)
        bar.grid(row=r + 1, column=0, columnspan=2, sticky="e", pady=(10, 0))
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(bar, text="Save", command=self._ok).pack(side="right")
        self.bind("<Return>", lambda e: self._ok())
        self.bind("<Escape>", lambda e: self.destroy())
        self.grab_set()
        self.wait_visibility()
        parent.wait_window(self)

    def _ok(self):
        out = {}
        for f in self._fields:
            v = self._vars[f["key"]].get()
            if f.get("kind") == "check":
                out[f["key"]] = 1 if v else 0
            elif f.get("kind") == "combo":
                for o in f["options"]:
                    if isinstance(o, tuple) and o[1] == v:
                        v = o[0]
                out[f["key"]] = v
            else:
                out[f["key"]] = v.strip()
        if self._validate:
            msg = self._validate(out)
            if msg:
                self._err.configure(text=msg)
                return
        self.result = out
        self.destroy()


# ----------------------------------------------------------------------------- the application
class App(tk.Tk):
    def __init__(self, db_path=None):
        super().__init__()
        self.title("PropFlow - cash flow & revenue reconciliation")
        self.geometry("1360x840")
        self.minsize(1050, 650)
        self._style()
        self.conn = db.connect(db_path)
        self.country = tk.StringVar(value="UAE")
        self._build_header()
        self.body = tk.Frame(self, bg=BG)
        self.body.pack(fill="both", expand=True)
        builders = {"sum": self._build_sum, "cf": self._build_cf, "rc": self._build_rc, "txn": self._build_txn,
                    "rules": self._build_rules, "up": self._build_upload, "set": self._build_setup}
        self.refreshers = {"sum": self.refresh_sum, "cf": self.refresh_cf, "rc": self.refresh_rc, "txn": self.refresh_rev,
                           "rules": self.refresh_rev, "up": self.refresh_upload, "set": self.refresh_setup}
        self.tabs, self.current = {}, None
        for key, _ in NAV:
            f = ttk.Frame(self.body, padding=(18, 14, 18, 12))
            self.tabs[key] = f
            builders[key](f)
        self.show("sum")
        self.refresh_all()

    def _style(self):
        self.configure(bg=BG)
        st = ttk.Style()
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure(".", background=BG, foreground=NAVY, font=FONT, bordercolor=LINE, lightcolor=BG, darkcolor=BG, troughcolor=BG)
        st.configure("TFrame", background=BG)
        st.configure("TLabel", background=BG, foreground=NAVY)
        st.configure("TCheckbutton", background=BG)
        st.configure("TRadiobutton", background=BG)
        st.configure("TLabelframe", background=BG, bordercolor=LINE, relief="solid")
        st.configure("TLabelframe.Label", background=BG, foreground=NAVY, font=FONT_B)
        st.configure("TButton", background=CARD, foreground=NAVY, bordercolor=LINE, padding=(12, 6), relief="solid", focuscolor=CARD)
        st.map("TButton", background=[("active", BLUE), ("pressed", BLUE)])
        st.configure("Accent.TButton", background=NAVY, foreground="white", bordercolor=NAVY, padding=(14, 7), font=FONT_B)
        st.map("Accent.TButton", background=[("active", ACCENT), ("pressed", ACCENT)], foreground=[("active", "white")])
        st.configure("TCombobox", fieldbackground=CARD, background=CARD, bordercolor=LINE, padding=4, arrowcolor=NAVY)
        st.map("TCombobox", fieldbackground=[("readonly", CARD)], selectbackground=[("readonly", CARD)], selectforeground=[("readonly", NAVY)])
        st.configure("TEntry", fieldbackground=CARD, bordercolor=LINE, padding=4)
        st.configure("Treeview", background=CARD, fieldbackground=CARD, foreground=NAVY, rowheight=28, borderwidth=0, font=FONT)
        st.configure("Treeview.Heading", background="#F1F5F9", foreground=NAVY, font=FONT_B, relief="flat", padding=(8, 9), borderwidth=0)
        st.map("Treeview", background=[("selected", "#C7D2FE")], foreground=[("selected", NAVY)])
        st.map("Treeview.Heading", background=[("active", LINE)])
        st.configure("TNotebook", background=BG, borderwidth=0, tabmargins=(0, 0, 0, 0))
        st.configure("TNotebook.Tab", background=BG, foreground=MUTED, padding=(16, 8), font=FONT_B, borderwidth=0)
        st.map("TNotebook.Tab", foreground=[("selected", ACCENT)], background=[("selected", BG)])
        st.configure("TScrollbar", background=LINE, troughcolor=BG, bordercolor=BG, arrowcolor=MUTED)
        st.configure("TSeparator", background=LINE)

    # ---- shared state
    @property
    def c(self):
        return self.country.get()

    def accounts(self):
        return db.accounts(self.conn, self.c)

    def settings(self):
        return db.get_settings(self.conn, self.c)

    def _build_header(self):
        top = tk.Frame(self, bg=CARD)
        top.pack(fill="x")
        row = tk.Frame(top, bg=CARD)
        row.pack(fill="x", padx=20, pady=(12, 0))
        tk.Label(row, text="PropFlow", bg=CARD, fg=NAVY, font=("Segoe UI", 17, "bold")).pack(side="left")
        seg = tk.Frame(row, bg="#F1F5F9", highlightbackground=LINE, highlightthickness=1)
        seg.pack(side="left", padx=24)
        for code in db.COUNTRIES:
            tk.Radiobutton(seg, text=f"{code} ({db.CURRENCY[code]})", value=code, variable=self.country, indicatoron=False,
                           command=self.refresh_all, bg="#F1F5F9", fg=MUTED, selectcolor=CARD, activebackground=CARD,
                           activeforeground=NAVY, relief="flat", bd=0, padx=16, pady=6, font=("Segoe UI", 9, "bold"),
                           cursor="hand2").pack(side="left", padx=2, pady=2)
        tk.Label(row, text="Offline - your data stays on this computer", bg=CARD, fg=MUTED, font=("Segoe UI", 9)).pack(side="right")
        nav = tk.Frame(top, bg=CARD)
        nav.pack(fill="x", padx=14, pady=(6, 0))
        self.nav = {}
        for key, title in NAV:
            f = tk.Frame(nav, bg=CARD, cursor="hand2")
            f.pack(side="left", padx=(0, 4))
            lab = tk.Label(f, text=title, bg=CARD, fg=MUTED, font=FONT_B, padx=14, pady=8, cursor="hand2")
            lab.pack()
            ul = tk.Frame(f, bg=CARD, height=3)
            ul.pack(fill="x")
            for w in (f, lab):
                w.bind("<Button-1>", lambda e, k=key: self.show(k))
            self.nav[key] = (lab, ul)
        tk.Frame(self, bg=LINE, height=1).pack(fill="x")

    def show(self, key):
        if self.current:
            self.tabs[self.current].pack_forget()
        self.current = key
        self.tabs[key].pack(fill="both", expand=True)
        for k, (lab, ul) in self.nav.items():
            on = k == key
            lab.configure(fg=ACCENT if on else MUTED)
            ul.configure(bg=ACCENT if on else CARD)
        self.refreshers[key]()

    def refresh_all(self):
        done = set()
        for fn in self.refreshers.values():
            if fn not in done:
                done.add(fn)
                fn()

    def goto(self, key):
        self.show(key)

    # ========================================================================= 1. UPLOAD
    def _build_upload(self, f):
        page_header(f, "Step 1 - load your files", "Upload Bank Ledgers & ERP Reports",
                    "Bank ledgers feed the cash flow. The four ERP reports feed Revenue vs Collection. Nothing leaves this computer.")
        a = ttk.LabelFrame(f, text="A.  Bank ledgers (one file per collection bank account)", padding=10)
        a.pack(fill="x")
        row = ttk.Frame(a)
        row.pack(fill="x")
        ttk.Label(row, text="Ledger type:").pack(side="left")
        self.lt_var = tk.StringVar(value=LEDGER_TYPES[0][1])
        ttk.Combobox(row, textvariable=self.lt_var, values=[l for _, l in LEDGER_TYPES], state="readonly", width=36).pack(side="left", padx=8)
        ttk.Button(row, text="Choose bank ledger file(s) and import...", command=self.upload_ledgers).pack(side="left", padx=8)
        ttk.Label(a, foreground="#555", wraplength=1100, justify="left",
                  text="Company books = the bank's GL ledger from your ERP, where receipts (R-...) are DEBITS. Bank statement = "
                       "the bank's own statement, where deposits are CREDITS. Auto-detect reads the running balance to decide "
                       "and tells you what it chose.").pack(anchor="w", pady=(6, 0))

        b = ttk.LabelFrame(f, text="B.  ERP reports for Revenue vs Collection", padding=10)
        b.pack(fill="x", pady=8)
        row = ttk.Frame(b)
        row.pack(fill="x")
        for kind, text in (("collection", "Cash collection report..."), ("tb", "Trial balance..."),
                           ("vat", "VAT register..."), ("deposit", "Security deposit register...")):
            ttk.Button(row, text=text, width=28, command=lambda k=kind: self.upload_erp(k)).pack(side="left", padx=(0, 8))
        ttk.Label(b, foreground="#555", wraplength=1100, justify="left", text=(
            "How to export:  Cash collection = AD Cash Collection Report (Report Type Property, Excel).   Trial balance = Financial "
            "Reports > Property Comparison (TB), Accrual, Excel.   VAT = Register Reports, Tran Type Receipt, tick Show Vat and Show "
            "Property Name, Excel.   Deposits = same register, Charge = secdep, tick Show Detail and Show Property Name.   "
            "VAT and deposit registers can be exported month by month - each upload adds to the earlier ones.")).pack(anchor="w", pady=(6, 0))

        c = ttk.LabelFrame(f, text="What has been uploaded", padding=10)
        c.pack(fill="both", expand=True)
        fr, self.hist = make_tree(c, ["Type", "Detail", "Period / dates", "File", "Rows", "Uploaded"],
                                  [110, 220, 170, 330, 60, 130], height=10)
        fr.pack(fill="both", expand=True)
        bar = ttk.Frame(c)
        bar.pack(fill="x", pady=(6, 0))
        ttk.Button(bar, text="Delete selected upload", command=self.delete_history).pack(side="left")
        ttk.Label(bar, foreground="#555", text="   Uploading the same period again replaces it, so there is no need to delete first.").pack(side="left")

    def refresh_upload(self):
        clear(self.hist)
        accs = {a["id"]: a for a in db.accounts(self.conn, self.c, active_only=False)}
        for r in self.conn.execute("SELECT * FROM ledger_import ORDER BY id DESC"):
            if r["account_id"] in accs:
                self.hist.insert("", "end", iid=f"led:{r['id']}",
                                 values=("Bank ledger", accs[r["account_id"]]["name"], f"{r['date_from']} to {r['date_to']}",
                                         r["filename"], r["n_rows"], r["imported_at"]))
        for u in reversed(recon.uploads(self.conn, self.c)):
            self.hist.insert("", "end", iid=f"erp:{u['id']}",
                             values=(KIND_TITLE.get(u["kind"], u["kind"]), "", f"{mlabel(u['period_from'])} to {mlabel(u['period_to'])}",
                                     u["filename"], u["n_rows"], u["uploaded_at"]))

    def delete_history(self):
        sel = self.hist.selection()
        if not sel:
            messagebox.showinfo("Delete", "Select an upload in the list first.")
            return
        kind, ident = sel[0].split(":")
        if not messagebox.askyesno("Delete upload", "Remove this upload and the data it added?"):
            return
        if kind == "erp":
            ingest.delete_upload(self.conn, int(ident))
        else:
            r = self.conn.execute("SELECT * FROM ledger_import WHERE id=?", (int(ident),)).fetchone()
            self.conn.execute("DELETE FROM ledger_txn WHERE account_id=? AND source=? AND txn_date>=? AND txn_date<=? AND manual=0",
                              (r["account_id"], r["filename"], r["date_from"], r["date_to"]))
            self.conn.execute("DELETE FROM ledger_import WHERE id=?", (int(ident),))
            self.conn.commit()
        self.refresh_all()

    def _ledger_type(self):
        for k, lab in LEDGER_TYPES:
            if lab == self.lt_var.get():
                return k
        return "auto"

    def upload_ledgers(self):
        accounts = self.accounts()
        if not accounts:
            messagebox.showwarning("No bank accounts", "Add the collection bank accounts for this country first (Setup tab).")
            self.goto("set")
            return
        paths = filedialog.askopenfilenames(title="Bank ledger file(s)", filetypes=XLSX)
        S = self.settings()
        for path in paths:
            try:
                p = parsers.parse_ledger(path, self._ledger_type(), S["date_format"])
            except ParseError as e:
                messagebox.showerror(os.path.basename(path), str(e))
                continue
            except Exception as e:
                messagebox.showerror(os.path.basename(path), f"Could not read this file:\n{e}")
                continue
            dlg = LedgerDialog(self, path, p, accounts)
            if dlg.result is None:
                continue
            fname = os.path.basename(path)
            msgs = []
            if p["has_account_col"]:
                groups = {}
                for r in p["rows"]:
                    groups.setdefault(r["account_text"], []).append(r)
                for text, rows in groups.items():
                    acc = ingest.match_account(accounts, text)
                    if not acc:
                        msgs.append(f"No bank account matches '{text}' - {len(rows)} rows skipped.")
                        continue
                    out = ingest.import_ledger(self.conn, self.c, acc["id"], dict(p, opening=None), fname, rows)
                    msgs.append(f"{acc['name']}: {out['rows']} rows ({out['unclassified']} unclassified).")
            else:
                out = ingest.import_ledger(self.conn, self.c, dlg.result, p, fname)
                an = next(a["name"] for a in accounts if a["id"] == dlg.result)
                msgs.append(f"{an}: {out['rows']} rows, {out['date_from']} to {out['date_to']} ({out['unclassified']} unclassified).")
                if out.get("opening_set"):
                    msgs.append(f"Opening balance set to {out['opening_set'][1]:,.2f} at {mlabel(out['opening_set'][0])}.")
                msgs += out["warnings"]
            messagebox.showinfo("Imported " + fname, "\n".join(msgs))
        if paths:
            self.refresh_all()

    def upload_erp(self, kind):
        path = filedialog.askopenfilename(title=KIND_TITLE[kind], filetypes=XLSX)
        if not path:
            return
        S = self.settings()
        fname = os.path.basename(path)
        try:
            if kind == "collection":
                parsed = parsers.parse_collection(path)
            elif kind == "tb":
                parsed = parsers.parse_trial_balance(path)
            else:
                parsed = parsers.parse_register(path, kind, S["date_format"])
        except ParseError as e:
            messagebox.showerror(fname, str(e))
            return
        except Exception as e:
            messagebox.showerror(fname, f"Could not read this file:\n{e}")
            return
        lines = []
        if kind == "collection":
            lines.append(f"{len(parsed['properties'])} properties, months {mlabel(parsed['months'][0])} to {mlabel(parsed['months'][-1])}, "
                         f"total {sum(r['amount'] for r in parsed['rows']):,.2f}")
        elif kind == "tb":
            pref = tuple(x.strip() for x in S["revenue_gl_prefix"].split(",") if x.strip())
            rev = [r for r in parsed["rows"] if r["gl_code"].startswith(pref)]
            sign = -1 if S["tb_credit_is_negative"] == "1" else 1
            lines.append(f"{len(parsed['properties'])} property columns, {len({r['gl_code'] for r in rev})} revenue GL accounts, "
                         f"net revenue {sign * sum(r['amount'] for r in rev):,.2f}")
        elif kind == "vat":
            lines.append(f"{len(parsed['rows'])} lines, VAT {sum(r['vat'] for r in parsed['rows']):,.2f}")
        else:
            main = [r for r in parsed["rows"] if not r["is_detail"]]
            lines.append(f"{len(main)} lines, net deposits {sum(r['amount'] for r in main):,.2f}")
        ErpDialog(self, kind, fname, path, parsed, lines)
        self.refresh_all()

    # ========================================================================= 2. BANK CASH FLOW
    def _build_cf(self, f):
        self.cf_crumb, right = page_header(f, "Collection bank accounts", "Bank Accounts Matrix - Monthly Cash Flow",
                                           "One column per collection bank account. Double-click any figure to see the transactions behind it.")
        ttk.Button(right, text="Export to Excel", style="Accent.TButton", command=self.export_cf).pack(side="right")
        self.cf_month = tk.StringVar()
        self.cf_box = ttk.Combobox(right, textvariable=self.cf_month, state="readonly", width=10)
        self.cf_box.pack(side="right", padx=10)
        self.cf_box.bind("<<ComboboxSelected>>", lambda e: self.refresh_cf(keep=True))
        tk.Label(right, text="Month", bg=CARD, fg=MUTED, font=FONT_B).pack(side="right")
        self.cf_kpi = kpi_row(f, [("OPENING BALANCE", BAD), ("TOTAL RECEIPTS", GOOD), ("TOTAL PAYMENTS", WARN),
                                  ("NET MOVEMENT", NAVY), ("CLOSING BALANCE", NAVY)])
        self.cf_msg = Messages(f)
        self.cf_msg.pack(fill="x", pady=6)
        self.cf_wrap = ttk.Frame(f)
        self.cf_wrap.pack(fill="both", expand=True)
        self.cf_tree = None
        self.cf_res = None

    def refresh_cf(self, keep=False):
        months = cashflow.months_available(self.conn, self.c)
        self.cf_box.configure(values=[mlabel(m) for m in months])
        if not keep or self.cf_month.get() not in [mlabel(m) for m in months]:
            self.cf_month.set(mlabel(months[-1]) if months else "")
        for w in self.cf_wrap.winfo_children():
            w.destroy()
        self.cf_tree, self.cf_res = None, None
        set_kpis(self.cf_kpi, [None] * 5)
        if not months:
            self.cf_msg.show(notes=["Upload bank ledgers first (Upload tab)."])
            return
        month = LABEL_TO_MONTH[self.cf_month.get()]
        res = self.cf_res = cashflow.matrix(self.conn, self.c, month)
        self.cf_msg.show(res["warnings"], res["checks"], res["notes"])
        tot = {r["key"]: r["total"] for r in res["rows"]}
        set_kpis(self.cf_kpi, [tot.get("opening"), tot.get("total_receipts"), tot.get("total_payments"), tot.get("net"), tot.get("closing")])
        self.cf_crumb.configure(text=f"{self.c} operations ({db.CURRENCY[self.c]})  \u00b7  {self.cf_month.get()}")
        accs = res["accounts"]
        cols = ["Line"] + [f"{a['gl_code'] or ''}  {a['name']}".strip() for a in accs] + ["Total"]
        fr, tree = make_tree(self.cf_wrap, cols, [300] + [190] * len(accs) + [140], ["w"] + ["e"] * (len(accs) + 1), height=22)
        fr.pack(fill="both", expand=True)
        for i, r in enumerate(res["rows"]):
            tag = r["kind"] if r["kind"] != "line" else ("bad" if r["key"].startswith("unclassified") else
                                                         "ib" if r["key"] in db_interbank_keys() else "")
            tree.insert("", "end", iid=str(i), tags=(tag,),
                        values=[r["label"]] + [fmt(r["values"].get(a["id"])) for a in accs] + [fmt(r["total"])])
        tree.bind("<Double-1>", self._cf_drill)
        self.cf_tree = tree

    def _cf_drill(self, event):
        if not self.cf_res:
            return
        iid = self.cf_tree.identify_row(event.y)
        col = self.cf_tree.identify_column(event.x)
        if not iid:
            return
        row = self.cf_res["rows"][int(iid)]
        if row["kind"] != "line":
            return
        accs = self.cf_res["accounts"]
        ci = int(col.replace("#", "")) - 2                       # -1 = label, 0.. = banks, len = Total
        bank = accs[ci]["id"] if 0 <= ci < len(accs) else None
        month = LABEL_TO_MONTH[self.cf_month.get()]
        txs = cashflow.transactions_for(self.conn, self.c, month, row["key"], bank)
        TxnWindow(self, f"{row['label']} - {self.cf_month.get()}" + (f" - {accs[ci]['name']}" if bank else ""), txs)

    def export_cf(self):
        if not self.cf_res:
            return
        month = LABEL_TO_MONTH[self.cf_month.get()]
        save_file("Save cash flow", f"{self.c}_cash_flow_{month}.xlsx", export.workbook_bytes(self.c, matrices=[(month, self.cf_res)]))

    # ========================================================================= 3. SUMMARY
    def _build_sum(self, f):
        self.sum_crumb, right = page_header(f, "Multi-month fund flow consolidation", "Cash Flow Statement - Monthly Summary Sheet",
                                            "Roll-forward consolidation of all collection banks: opening balances, rent collections, interbank "
                                            "transfers, payments and closing balances month by month.")
        ttk.Button(right, text="Export to Excel", style="Accent.TButton", command=self.export_sum).pack()
        self.sum_kpi = kpi_row(f, [("INITIAL OPENING BALANCE", BAD), ("TOTAL RENT COLLECTIONS", GOOD), ("INTERBANK TRANSFERS IN", WARN),
                                   ("TOTAL INFLOW", NAVY), ("TOTAL OUTFLOWS", NAVY), ("NET CLOSING BALANCE", NAVY)])
        self.sum_msg = Messages(f)
        self.sum_msg.pack(fill="x", pady=6)
        self.sum_wrap = ttk.Frame(f)
        self.sum_wrap.pack(fill="both", expand=True)
        self.sum_res = None

    def refresh_sum(self):
        for w in self.sum_wrap.winfo_children():
            w.destroy()
        res = self.sum_res = cashflow.summary(self.conn, self.c)
        set_kpis(self.sum_kpi, [None] * 6)
        if not res["labels"]:
            self.sum_msg.show(notes=["Upload bank ledgers first (Upload tab)."])
            return
        self.sum_msg.show(res["warnings"])
        T = res["total"]
        ib = 0.0
        for lab in res["labels"]:
            if lab.startswith("Total Receipts"):
                break
            if lab.lower().startswith("interbank"):
                ib += T[lab] or 0.0
        set_kpis(self.sum_kpi, [T.get("Opening Balance"), T.get("Rent Collection"), ib, T.get("Total Receipts / Inflows"),
                                T.get("Total Payments / Outflows"), T.get("Closing Balance")])
        self.sum_crumb.configure(text=f"{self.c} operations ({db.CURRENCY[self.c]})  \u00b7  {len(res['mlabels'])} months tracked "
                                      f"({res['mlabels'][0]} - {res['mlabels'][-1]})")
        cols = ["Line"] + res["mlabels"] + ["Total"]
        fr, tree = make_tree(self.sum_wrap, cols, [300] + [120] * (len(cols) - 1), ["w"] + ["e"] * (len(cols) - 1), height=22)
        fr.pack(fill="both", expand=True)
        for lab in res["labels"]:
            k = res["kinds"][lab]
            tag = k if k != "line" else ("bad" if lab.startswith("Unclassified") else "ib" if lab.lower().startswith("interbank") else "")
            tree.insert("", "end", tags=(tag,), values=[lab] + [fmt(res["values"][lab].get(m)) for m in res["mlabels"]] + [fmt(res["total"][lab])])

    def export_sum(self):
        if not self.sum_res or not self.sum_res["labels"]:
            return
        mats = [(m, cashflow.matrix(self.conn, self.c, m)) for m in self.sum_res["months"]]
        save_file("Save summary", f"{self.c}_cash_flow_summary.xlsx", export.workbook_bytes(self.c, self.sum_res, mats))

    # ========================================================================= 4. REVENUE VS COLLECTION
    def _build_rc(self, f):
        self.rc_crumb, right = page_header(f, "Report 2 - accrual revenue vs cash collection", "Revenue vs. Collection Reconciliation",
                                           "Trial balance revenue (GL 4xxx) compared with ERP cash collection, after VAT and security deposits. "
                                           "The remainder is the net receivable / advance.")
        ttk.Button(right, text="Export to Excel", style="Accent.TButton", command=self.export_rc).pack()
        self.rc_kpi = kpi_row(f, [("1. REVENUE (GL 4XXX)", NAVY), ("2. (+) VAT AMOUNT", GOOD), ("3. (+) SEC. DEPOSITS", GOOD),
                                  ("SUBTOTAL (1+2+3)", NAVY), ("4. CASH COLLECTION", NAVY), ("NET RECEIVABLE / ADVANCE", ACCENT)])
        bar = ttk.Frame(f)
        bar.pack(fill="x", pady=(0, 6))
        self.rc_from, self.rc_to, self.rc_tb = tk.StringVar(), tk.StringVar(), tk.StringVar()
        labels = [MONTH_LABELS[k] for k in month_keys()]
        ttk.Label(bar, text="From").pack(side="left")
        a = ttk.Combobox(bar, textvariable=self.rc_from, values=labels, state="readonly", width=9)
        a.pack(side="left", padx=4)
        ttk.Label(bar, text="To").pack(side="left", padx=(8, 0))
        b = ttk.Combobox(bar, textvariable=self.rc_to, values=labels, state="readonly", width=9)
        b.pack(side="left", padx=4)
        ttk.Label(bar, text="Trial balance").pack(side="left", padx=(12, 0))
        self.rc_tb_box = ttk.Combobox(bar, textvariable=self.rc_tb, state="readonly", width=44)
        self.rc_tb_box.pack(side="left", padx=4)
        for w in (a, b, self.rc_tb_box):
            w.bind("<<ComboboxSelected>>", lambda e: self.refresh_rc(keep=True))
        self.rc_msg = Messages(f)
        self.rc_msg.pack(fill="x", pady=4)
        self.rc_wrap = ttk.Frame(f)
        self.rc_wrap.pack(fill="both", expand=True)
        ttk.Label(f, foreground="#555", wraplength=1200, justify="left", text=(
            "Net advance / (receivable) = Collection - (Revenue + VAT + Security deposits). Positive = tenants paid more than "
            "revenue + VAT + deposits (advances, or earlier receivables collected); negative = revenue not yet collected. "
            "Double-click a property for its detail.")).pack(anchor="w", pady=(4, 0))
        self.rc_res = None
        self.rc_tb_ids = {}

    def refresh_rc(self, keep=False):
        for w in self.rc_wrap.winfo_children():
            w.destroy()
        self.rc_res = None
        set_kpis(self.rc_kpi, [None] * 6)
        cols_up = recon.uploads(self.conn, self.c, "collection")
        tbs = recon.uploads(self.conn, self.c, "tb")
        self.rc_tb_ids = {"Automatic (matching period)": None}
        for u in tbs:
            self.rc_tb_ids[f"{mlabel(u['period_from'])} to {mlabel(u['period_to'])} - {u['filename']}"] = u["id"]
        self.rc_tb_box.configure(values=list(self.rc_tb_ids))
        if not keep or self.rc_tb.get() not in self.rc_tb_ids:
            self.rc_tb.set("Automatic (matching period)")
        if not cols_up:
            set_kpis(self.rc_kpi, [None] * 6)
            self.rc_msg.show(notes=["Upload at least the cash collection report and the trial balance (Upload tab)."])
            return
        if not keep or not self.rc_from.get():
            self.rc_from.set(mlabel(min(u["period_from"] for u in cols_up)))
            self.rc_to.set(mlabel(max(u["period_to"] for u in cols_up)))
        p_from, p_to = LABEL_TO_MONTH[self.rc_from.get()], LABEL_TO_MONTH[self.rc_to.get()]
        if p_from > p_to:
            self.rc_msg.show(["'From' month is after 'To' month."])
            return
        res = self.rc_res = recon.reconcile(self.conn, self.c, p_from, p_to, self.rc_tb_ids.get(self.rc_tb.get()))
        self.rc_msg.show(res["warnings"], info=res["info"])
        t = res["totals"]
        set_kpis(self.rc_kpi, [t["revenue"], t["vat"], t["deposits"], t["subtotal"], t["collection"], t["difference"]])
        self.rc_crumb.configure(text=f"{self.c} operations ({db.CURRENCY[self.c]})  \u00b7  {self.rc_from.get()} - {self.rc_to.get()}")
        cols = ["Code", "Property", "Revenue (GL 4xxx)", "VAT", "Security deposits", "Revenue+VAT+Deposits", "Collection",
                "Net advance / (receivable)", "Status"]
        fr, tree = make_tree(self.rc_wrap, cols, [80, 220, 150, 110, 140, 170, 140, 190, 120],
                             ["w", "w", "e", "e", "e", "e", "e", "e", "w"], height=14)
        fr.pack(fill="both", expand=True)
        for r in res["rows"]:
            tree.insert("", "end", iid=r["code"], values=[r["code"], r["name"], fmt(r["revenue"]), fmt(r["vat"]), fmt(r["deposits"]),
                                                          fmt(r["subtotal"]), fmt(r["collection"]), fmt(r["difference"]), r["status"]])
        tree.insert("", "end", iid="__total", tags=("total",), values=["", "TOTAL", fmt(t["revenue"]), fmt(t["vat"]), fmt(t["deposits"]),
                                                                       fmt(t["subtotal"]), fmt(t["collection"]), fmt(t["difference"]), ""])
        tree.bind("<Double-1>", self._rc_drill)
        self.rc_tree = tree

    def _rc_drill(self, event):
        iid = self.rc_tree.identify_row(event.y)
        if iid and iid != "__total" and self.rc_res:
            PropertyWindow(self, self.rc_res, iid)

    def export_rc(self):
        if not self.rc_res or not self.rc_res["rows"]:
            return
        r = self.rc_res
        save_file("Save revenue vs collection", f"{self.c}_revenue_vs_collection_{r['p_from']}_{r['p_to']}.xlsx",
                  export.workbook_bytes(self.c, rres=r, tolerance=float(self.settings()["balanced_tolerance"])))

    # ========================================================================= 5. REVIEW & RULES
    def _build_txn(self, f):
        page_header(f, "Review & classify", "Transactions",
                    "Every ledger line and the report line it falls under. Lines no rule recognises show in red - classify them here "
                    "or turn them into a rule.")
        top = ttk.Frame(f)
        top.pack(fill="both", expand=True)
        bar = ttk.Frame(top)
        bar.pack(fill="x")
        self.rv_month, self.rv_bank, self.rv_show = tk.StringVar(value="All"), tk.StringVar(value="All banks"), tk.StringVar(value="Unclassified only")
        ttk.Label(bar, text="Month").pack(side="left")
        self.rv_month_box = ttk.Combobox(bar, textvariable=self.rv_month, state="readonly", width=10)
        self.rv_month_box.pack(side="left", padx=4)
        ttk.Label(bar, text="Bank").pack(side="left", padx=(8, 0))
        self.rv_bank_box = ttk.Combobox(bar, textvariable=self.rv_bank, state="readonly", width=22)
        self.rv_bank_box.pack(side="left", padx=4)
        ttk.Label(bar, text="Show").pack(side="left", padx=(8, 0))
        sh = ttk.Combobox(bar, textvariable=self.rv_show, state="readonly", width=18, values=["Unclassified only", "Everything"])
        sh.pack(side="left", padx=4)
        for w in (self.rv_month_box, self.rv_bank_box, sh):
            w.bind("<<ComboboxSelected>>", lambda e: self.refresh_rev(keep=True))
        fr, self.rv_tree = make_tree(top, ["Date", "Bank", "Reference", "Description", "Money in", "Money out", "Category"],
                                     [90, 140, 120, 380, 110, 110, 230], ["w", "w", "w", "w", "e", "e", "w"], height=9, selectmode="extended")
        fr.pack(fill="both", expand=True, pady=4)
        bar2 = ttk.Frame(top)
        bar2.pack(fill="x")
        ttk.Label(bar2, text="Classify selected as:").pack(side="left")
        self.rv_cat = tk.StringVar()
        self.rv_cat_box = ttk.Combobox(bar2, textvariable=self.rv_cat, state="readonly", width=40)
        self.rv_cat_box.pack(side="left", padx=6)
        ttk.Button(bar2, text="Apply to selected", command=self.apply_category).pack(side="left")
        ttk.Button(bar2, text="Make a rule from selected...", command=self.rule_from_selected).pack(side="left", padx=10)
        self.rv_msg = ttk.Label(bar2, foreground="#555")
        self.rv_msg.pack(side="left", padx=10)

        self.rv_rows = {}

    def _build_rules(self, f):
        page_header(f, "Classification", "Rules",
                    "Words in the description decide the report line. Lowest priority number is tried first; the first match wins. "
                    "Hand-made classifications are never overwritten.")
        bot = ttk.Frame(f)
        bot.pack(fill="both", expand=True)
        fr, self.rule_tree = make_tree(bot, ["Priority", "Name", "Look in", "Match", "Words / pattern", "Direction", "Category", "On"],
                                       [60, 220, 90, 90, 330, 80, 230, 40], height=6)
        fr.pack(fill="both", expand=True)
        bar3 = ttk.Frame(bot)
        bar3.pack(fill="x", pady=(4, 0))
        for text, cmd in (("Add rule...", self.add_rule), ("Edit...", self.edit_rule), ("Delete", self.delete_rule),
                          ("Re-apply rules to all transactions", self.reapply_rules)):
            ttk.Button(bar3, text=text, command=cmd).pack(side="left", padx=(0, 6))
        ttk.Label(bar3, foreground="#555", text="Hand-made classifications are kept.   'out' money sent to a receipt line "
                                                "(e.g. a returned R- cheque to Rent Collection) reduces that line.").pack(side="left", padx=8)

    def _cat_options(self):
        return [(c["key"], c["label"]) for c in db.categories(self.conn, self.c)]

    def refresh_rev(self, keep=False):
        months = cashflow.months_available(self.conn, self.c)
        accs = self.accounts()
        self.rv_month_box.configure(values=["All"] + [mlabel(m) for m in months])
        self.rv_bank_box.configure(values=["All banks"] + [a["name"] for a in accs])
        if not keep:
            self.rv_month.set("All")
            self.rv_bank.set("All banks")
        cats = self._cat_options()
        self.rv_cat_box.configure(values=[l for _, l in cats])
        label = dict(cats)
        q = ("SELECT t.id, t.txn_date, a.name AS bank, t.reference, t.description, t.money_in, t.money_out, t.category "
             "FROM ledger_txn t JOIN bank_accounts a ON a.id=t.account_id WHERE a.country=?")
        prm = [self.c]
        if self.rv_month.get() not in ("All", ""):
            q += " AND t.month=?"
            prm.append(LABEL_TO_MONTH[self.rv_month.get()])
        if self.rv_bank.get() not in ("All banks", ""):
            q += " AND a.name=?"
            prm.append(self.rv_bank.get())
        if self.rv_show.get() == "Unclassified only":
            keys = [k for k, _ in cats]
            q += " AND (t.category IS NULL OR t.category='' OR t.category NOT IN (%s))" % ",".join("?" * len(keys))
            prm += keys
        q += " ORDER BY t.txn_date, t.id LIMIT 2000"
        clear(self.rv_tree)
        self.rv_rows = {}
        for r in self.conn.execute(q, prm):
            self.rv_rows[str(r["id"])] = dict(r)
            self.rv_tree.insert("", "end", iid=str(r["id"]), values=(
                r["txn_date"], r["bank"], r["reference"], r["description"], fmt(r["money_in"]), fmt(r["money_out"]),
                label.get(r["category"], "(unclassified)")), tags=("bad",) if r["category"] not in label else ())
        self.rv_msg.configure(text=f"{len(self.rv_rows)} transaction(s) shown")
        clear(self.rule_tree)
        for r in self.conn.execute("SELECT * FROM rules WHERE country=? ORDER BY priority, id", (self.c,)):
            self.rule_tree.insert("", "end", iid=str(r["id"]), values=(
                r["priority"], r["name"], r["field"], r["match"], r["pattern"], r["direction"], label.get(r["category"], r["category"]),
                "yes" if r["active"] else "no"))

    def apply_category(self):
        sel = self.rv_tree.selection()
        lab = self.rv_cat.get()
        key = next((k for k, l in self._cat_options() if l == lab), None)
        if not sel or not key:
            messagebox.showinfo("Classify", "Select one or more transactions and choose a category first.")
            return
        for iid in sel:
            self.conn.execute("UPDATE ledger_txn SET category=?, manual=1 WHERE id=?", (key, int(iid)))
        self.conn.commit()
        self.refresh_all()

    def _rule_fields(self):
        return [dict(key="name", label="Name"), dict(key="priority", label="Priority (lower = first)", width=8),
                dict(key="field", label="Look in", kind="combo", options=["description", "reference", "both"], width=16),
                dict(key="match", label="Match type", kind="combo", options=["contains", "startswith", "regex"], width=16),
                dict(key="pattern", label="Words / pattern", width=48),
                dict(key="direction", label="Money direction", kind="combo", options=["in", "out", "any"], width=16),
                dict(key="category", label="Category", kind="combo", options=self._cat_options(), width=40),
                dict(key="active", label="Active", kind="check")]

    @staticmethod
    def _rule_validate(v):
        if not v["pattern"]:
            return "Enter the words or pattern to look for (separate alternatives with |)."
        if not v["priority"].lstrip("-").isdigit():
            return "Priority must be a whole number."
        return None

    def _save_rule(self, v, rid=None):
        vals = (int(v["priority"]), v["name"] or v["pattern"], v["field"], v["match"], v["pattern"], v["direction"], v["category"], v["active"])
        if rid is None:
            self.conn.execute("INSERT INTO rules(country,priority,name,field,match,pattern,direction,category,active) VALUES (?,?,?,?,?,?,?,?,?)",
                              (self.c,) + vals)
        else:
            self.conn.execute("UPDATE rules SET priority=?,name=?,field=?,match=?,pattern=?,direction=?,category=?,active=? WHERE id=?", vals + (rid,))
        self.conn.commit()

    def add_rule(self, initial=None):
        d = FormDialog(self, "Add rule", self._rule_fields(), initial or dict(priority=100, field="description", match="contains",
                                                                              direction="any", active=1), self._rule_validate,
                       hint="Words are not case sensitive. Separate alternatives with |, e.g.  bank charge|commission")
        if d.result:
            self._save_rule(d.result)
            self.refresh_rev(keep=True)

    def edit_rule(self):
        sel = self.rule_tree.selection()
        if not sel:
            return
        r = dict(self.conn.execute("SELECT * FROM rules WHERE id=?", (int(sel[0]),)).fetchone())
        d = FormDialog(self, "Edit rule", self._rule_fields(), r, self._rule_validate)
        if d.result:
            self._save_rule(d.result, int(sel[0]))
            self.refresh_rev(keep=True)

    def delete_rule(self):
        sel = self.rule_tree.selection()
        if sel and messagebox.askyesno("Delete rule", "Delete the selected rule?"):
            self.conn.execute("DELETE FROM rules WHERE id=?", (int(sel[0]),))
            self.conn.commit()
            self.refresh_rev(keep=True)

    def rule_from_selected(self):
        sel = self.rv_tree.selection()
        if not sel:
            messagebox.showinfo("Make a rule", "Select a transaction first.")
            return
        t = self.rv_rows[sel[0]]
        words = " ".join((t["description"] or "").split()[:3])
        lab = self.rv_cat.get()
        key = next((k for k, l in self._cat_options() if l == lab), self._cat_options()[0][0])
        self.add_rule(dict(name=f"Rule: {words}", priority=100, field="description", match="contains", pattern=words,
                           direction="in" if t["money_in"] > 0 else "out", category=key, active=1))

    def reapply_rules(self):
        n = classify.reclassify_country(self.conn, self.c)
        messagebox.showinfo("Rules", f"{n} transaction(s) re-classified.")
        self.refresh_all()

    # ========================================================================= 6. SETUP
    def _build_setup(self, f):
        page_header(f, "Configuration", "Setup",
                    "Bank accounts (the matrix columns), property code mapping, report lines and settings - kept separately for each country.")
        nb = ttk.Notebook(f)
        nb.pack(fill="both", expand=True)
        self.setup_trees = {}

        def panel(title, note, columns, widths, add, edit, delete, extra=None):
            fr = ttk.Frame(nb, padding=10)
            nb.add(fr, text=title)
            ttk.Label(fr, text=note, wraplength=1150, justify="left", foreground="#555").pack(anchor="w", pady=(0, 6))
            t_fr, tree = make_tree(fr, columns, widths, height=12)
            t_fr.pack(fill="both", expand=True)
            bar = ttk.Frame(fr)
            bar.pack(fill="x", pady=(6, 0))
            for text, cmd in (("Add...", add), ("Edit...", edit), ("Delete / hide", delete)):
                ttk.Button(bar, text=text, command=cmd).pack(side="left", padx=(0, 6))
            tree.bind("<Double-1>", lambda e: edit())
            return tree

        self.acc_tree = panel("Bank accounts", "One row per collection bank account for the selected country (the columns of the cash flow "
                              "report). Opening balance = balance at the START of the opening month; it is filled from the first ledger you "
                              "upload when the file shows it. After that, each month opens with the previous month's closing balance.",
                              ["Order", "GL code", "Bank / property name", "Account no.", "Currency", "Opening month", "Opening balance", "Active"],
                              [60, 110, 230, 190, 70, 110, 140, 60], self.add_account, self.edit_account, self.delete_account)
        self.map_tree = panel("Property code mapping", "Use when the same property has different codes in different reports, or one code must be merged "
                              "into another (e.g. 'parking' into 'ebp2'). Codes you do not list map to themselves. Codes are lower case.",
                              ["Code in the reports", "Report as code", "Name"], [200, 200, 300], self.add_map, self.edit_map, self.delete_map)
        self.line_tree = panel("Report lines", "The rows of the cash flow statement. 'in' lines are receipts, 'out' lines are payments. Add a line "
                               "(e.g. 'Transfer to/For Indonesia'), then point a rule at it in the Review & rules tab. Hidden lines keep their history.",
                               ["Order", "Key", "Label", "In / out", "Shown"], [70, 220, 380, 80, 70], self.add_line, self.edit_line, self.delete_line)
        st = ttk.Frame(nb, padding=14)
        nb.add(st, text="Settings & backup")
        self.set_lbl = ttk.Label(st, justify="left")
        self.set_lbl.pack(anchor="w")
        ttk.Button(st, text="Change settings...", command=self.edit_settings).pack(anchor="w", pady=10)
        ttk.Separator(st).pack(fill="x", pady=10)
        ttk.Label(st, justify="left", text=f"Your data is one file:\n{db.ROOT / 'data' / 'propflow.db'}\nCopy it to keep a backup; "
                                           "replacing it with a copy restores that backup.").pack(anchor="w")
        ttk.Button(st, text="Save a backup copy...", command=self.backup).pack(anchor="w", pady=10)

    def refresh_setup(self):
        clear(self.acc_tree)
        for a in db.accounts(self.conn, self.c, active_only=False):
            self.acc_tree.insert("", "end", iid=str(a["id"]), values=(a["sort"], a["gl_code"] or "", a["name"], a["account_no"] or "", a["currency"] or "",
                                                                       a["opening_month"] or "", fmt(a["opening_balance"]) if a["opening_balance"] is not None else "",
                                                                       "yes" if a["active"] else "no"))
        clear(self.map_tree)
        for r in self.conn.execute("SELECT * FROM property_map WHERE country=? ORDER BY source_code", (self.c,)):
            self.map_tree.insert("", "end", iid=r["source_code"], values=(r["source_code"], r["group_code"], r["group_name"] or ""))
        clear(self.line_tree)
        for r in self.conn.execute("SELECT * FROM categories WHERE country=? ORDER BY sort, key", (self.c,)):
            self.line_tree.insert("", "end", iid=r["key"], values=(r["sort"], r["key"], r["label"], r["section"], "yes" if r["active"] else "hidden"))
        S = self.settings()
        self.set_lbl.configure(text=(
            f"Settings for {self.c}\n\n"
            f"  Revenue GL accounts start with: {S['revenue_gl_prefix']}\n"
            f"  Revenue shows as negative in the trial balance: {'yes' if S['tb_credit_is_negative'] == '1' else 'no'}\n"
            f"  'Reconciled' when the difference is below: {S['balanced_tolerance']}\n"
            f"  VAT / deposit lines are matched to the period by: {S['cutoff_basis']}\n"
            f"  Dates written as text are: {'month/day/year' if S['date_format'] == 'mdy' else 'day/month/year'}\n"
            f"  Security deposit charge codes: {S['deposit_charge_codes']}   or account codes starting with: {S['deposit_account_prefixes']}\n"
            f"  Negative deposit lines (refunds) ignored: {'yes' if S.get('deposit_ignore_negative', '1') == '1' else 'no'}\n"
            f"  Include register sub-lines without a property: {'yes' if S['include_detail_lines'] == '1' else 'no'}"))

    # ---- bank accounts
    def _acc_fields(self):
        return [dict(key="sort", label="Order in report", width=8), dict(key="gl_code", label="GL code"),
                dict(key="name", label="Bank / property name"), dict(key="account_no", label="Account number"),
                dict(key="currency", label="Currency", width=8),
                dict(key="opening_month", label="Opening month (YYYY-MM)", width=12),
                dict(key="opening_balance", label="Opening balance at start of that month", width=18),
                dict(key="active", label="Active", kind="check")]

    @staticmethod
    def _acc_validate(v):
        if not v["name"]:
            return "Enter a name."
        if v["opening_month"] and not (len(v["opening_month"]) == 7 and v["opening_month"][4] == "-" and v["opening_month"][:4].isdigit() and v["opening_month"][5:].isdigit()):
            return "Opening month must look like 2026-01."
        try:
            if v["opening_balance"]:
                float(v["opening_balance"].replace(",", ""))
        except ValueError:
            return "Opening balance must be a number."
        if v["sort"] and not v["sort"].lstrip("-").isdigit():
            return "Order must be a whole number."
        return None

    def _save_account(self, v, aid=None):
        ob = float(v["opening_balance"].replace(",", "")) if v["opening_balance"] else None
        om = v["opening_month"] or None
        if ob is not None and not om:
            om = month_keys()[0]
        vals = (int(v["sort"] or 0), v["gl_code"] or None, v["name"], v["account_no"] or None, v["currency"] or db.CURRENCY[self.c], om, ob, v["active"])
        if aid is None:
            self.conn.execute("INSERT INTO bank_accounts(country,sort,gl_code,name,account_no,currency,opening_month,opening_balance,active) "
                              "VALUES (?,?,?,?,?,?,?,?,?)", (self.c,) + vals)
        else:
            self.conn.execute("UPDATE bank_accounts SET sort=?,gl_code=?,name=?,account_no=?,currency=?,opening_month=?,opening_balance=?,active=? WHERE id=?",
                              vals + (aid,))
        self.conn.commit()
        self.refresh_all()

    def add_account(self):
        n = len(db.accounts(self.conn, self.c, active_only=False)) + 1
        d = FormDialog(self, "Add bank account", self._acc_fields(), dict(sort=n, currency=db.CURRENCY[self.c], active=1), self._acc_validate)
        if d.result:
            self._save_account(d.result)

    def edit_account(self):
        sel = self.acc_tree.selection()
        if not sel:
            return
        a = dict(self.conn.execute("SELECT * FROM bank_accounts WHERE id=?", (int(sel[0]),)).fetchone())
        a["opening_balance"] = "" if a["opening_balance"] is None else a["opening_balance"]
        d = FormDialog(self, "Edit bank account", self._acc_fields(), a, self._acc_validate)
        if d.result:
            self._save_account(d.result, int(sel[0]))

    def delete_account(self):
        sel = self.acc_tree.selection()
        if not sel:
            return
        aid = int(sel[0])
        n = self.conn.execute("SELECT COUNT(*) FROM ledger_txn WHERE account_id=?", (aid,)).fetchone()[0]
        if n:
            if messagebox.askyesno("Hide account", f"This account has {n} transactions, so it will be hidden (not deleted). Hide it?"):
                self.conn.execute("UPDATE bank_accounts SET active=0 WHERE id=?", (aid,))
        elif messagebox.askyesno("Delete account", "Delete this bank account?"):
            self.conn.execute("DELETE FROM bank_accounts WHERE id=?", (aid,))
        self.conn.commit()
        self.refresh_all()

    # ---- property mapping
    def _map_fields(self):
        return [dict(key="source_code", label="Code in the reports"), dict(key="group_code", label="Report as code"), dict(key="group_name", label="Name (optional)")]

    def add_map(self):
        d = FormDialog(self, "Add mapping", self._map_fields(), None,
                       lambda v: None if v["source_code"] and v["group_code"] else "Enter both codes.")
        if d.result:
            v = d.result
            self.conn.execute("INSERT OR REPLACE INTO property_map VALUES (?,?,?,?)",
                              (self.c, v["source_code"].lower(), v["group_code"].lower(), v["group_name"] or None))
            self.conn.commit()
            self.refresh_all()

    def edit_map(self):
        sel = self.map_tree.selection()
        if not sel:
            return
        r = dict(self.conn.execute("SELECT * FROM property_map WHERE country=? AND source_code=?", (self.c, sel[0])).fetchone())
        d = FormDialog(self, "Edit mapping", self._map_fields(), r, lambda v: None if v["source_code"] and v["group_code"] else "Enter both codes.")
        if d.result:
            v = d.result
            self.conn.execute("DELETE FROM property_map WHERE country=? AND source_code=?", (self.c, sel[0]))
            self.conn.execute("INSERT OR REPLACE INTO property_map VALUES (?,?,?,?)",
                              (self.c, v["source_code"].lower(), v["group_code"].lower(), v["group_name"] or None))
            self.conn.commit()
            self.refresh_all()

    def delete_map(self):
        sel = self.map_tree.selection()
        if sel:
            self.conn.execute("DELETE FROM property_map WHERE country=? AND source_code=?", (self.c, sel[0]))
            self.conn.commit()
            self.refresh_all()

    # ---- report lines
    def _line_fields(self):
        return [dict(key="sort", label="Order", width=8), dict(key="key", label="Key (no spaces)"), dict(key="label", label="Label shown in the report"),
                dict(key="section", label="Section", kind="combo", options=[("in", "in  (receipt)"), ("out", "out  (payment)")], width=20),
                dict(key="active", label="Shown", kind="check")]

    def _line_validate(self, v):
        if not v["key"] or not v["label"]:
            return "Enter a key and a label."
        if not v["sort"].lstrip("-").isdigit():
            return "Order must be a whole number."
        return None

    def _save_line(self, v, old=None):
        key = v["key"].lower().replace(" ", "_")
        if old and old != key:
            self.conn.execute("DELETE FROM categories WHERE country=? AND key=?", (self.c, old))
            self.conn.execute("UPDATE rules SET category=? WHERE country=? AND category=?", (key, self.c, old))
            self.conn.execute("UPDATE ledger_txn SET category=? WHERE category=? AND account_id IN (SELECT id FROM bank_accounts WHERE country=?)", (key, old, self.c))
        self.conn.execute("INSERT OR REPLACE INTO categories(country,key,label,section,sort,active) VALUES (?,?,?,?,?,?)",
                          (self.c, key, v["label"], v["section"], int(v["sort"]), v["active"]))
        self.conn.commit()
        self.refresh_all()

    def add_line(self):
        d = FormDialog(self, "Add report line", self._line_fields(), dict(sort=500, section="out", active=1), self._line_validate)
        if d.result:
            self._save_line(d.result)

    def edit_line(self):
        sel = self.line_tree.selection()
        if not sel:
            return
        r = dict(self.conn.execute("SELECT * FROM categories WHERE country=? AND key=?", (self.c, sel[0])).fetchone())
        d = FormDialog(self, "Edit report line", self._line_fields(), r, self._line_validate)
        if d.result:
            self._save_line(d.result, sel[0])

    def delete_line(self):
        sel = self.line_tree.selection()
        if sel and messagebox.askyesno("Hide line", "Hide this line from the reports? (its history is kept)"):
            self.conn.execute("UPDATE categories SET active=0 WHERE country=? AND key=?", (self.c, sel[0]))
            self.conn.commit()
            self.refresh_all()

    # ---- settings / backup
    def edit_settings(self):
        S = self.settings()
        fields = [dict(key="revenue_gl_prefix", label="Revenue GL accounts start with"),
                  dict(key="tb_credit_is_negative", label="Revenue shows as negative in the trial balance", kind="check"),
                  dict(key="balanced_tolerance", label="'Reconciled' when difference is below", width=10),
                  dict(key="cutoff_basis", label="Match VAT / deposit lines to the period by", kind="combo",
                       options=[("period", "posting month"), ("date", "receipt date")], width=38),
                  dict(key="date_format", label="Dates written as text are", kind="combo",
                       options=[("mdy", "month/day/year (10/31/2026)"), ("dmy", "day/month/year (31/10/2026)")], width=38),
                  dict(key="deposit_charge_codes", label="Security deposit charge codes"),
                  dict(key="deposit_account_prefixes", label="...or account codes starting with"),
                  dict(key="deposit_ignore_negative", label="Ignore negative deposit lines (refunds)", kind="check"),
                  dict(key="include_detail_lines", label="Include register sub-lines without a property", kind="check")]

        def validate(v):
            try:
                float(v["balanced_tolerance"])
            except ValueError:
                return "The tolerance must be a number."
            return None

        d = FormDialog(self, f"Settings - {self.c}", fields, S, validate)
        if d.result:
            for k, v in d.result.items():
                db.set_setting(self.conn, self.c, k, v)
            self.refresh_all()

    def backup(self):
        src = db.ROOT / "data" / "propflow.db"
        if os.environ.get("PROPFLOW_DB"):
            src = Path(os.environ["PROPFLOW_DB"])
        dest = filedialog.asksaveasfilename(title="Save a backup copy", initialfile=f"propflow_backup_{date.today():%Y%m%d}.db",
                                            defaultextension=".db")
        if dest:
            self.conn.commit()
            shutil.copyfile(src, dest)
            messagebox.showinfo("Backup", f"Backup saved to:\n{dest}")


# ----------------------------------------------------------------------------- dialogs
class LedgerDialog(tk.Toplevel):
    """Preview of one bank ledger file; result = chosen account id (or True if rows carry their own account)."""

    def __init__(self, app, path, p, accounts):
        super().__init__(app)
        self.title("Import bank ledger - " + os.path.basename(path))
        self.transient(app)
        self.result = None
        self.geometry("980x600")
        body = ttk.Frame(self, padding=12)
        body.pack(fill="both", expand=True)
        rows = p["rows"]
        ttk.Label(body, text=os.path.basename(path), font=("Segoe UI", 11, "bold")).pack(anchor="w")
        self.acc_var = tk.StringVar()
        if p["has_account_col"]:
            ttk.Label(body, text="This file has a bank / account column - rows are split between your bank accounts automatically.",
                      foreground="#355C9A").pack(anchor="w", pady=4)
        else:
            r = ttk.Frame(body)
            r.pack(fill="x", pady=6)
            ttk.Label(r, text="Bank account for this file:").pack(side="left")
            names = {f"{a['gl_code'] or ''}  {a['name']}".strip(): a["id"] for a in accounts}
            guess = ingest.match_account(accounts, Path(path).stem)
            cb = ttk.Combobox(r, textvariable=self.acc_var, values=list(names), state="readonly", width=44)
            cb.pack(side="left", padx=8)
            pick = next((k for k, v in names.items() if guess and v == guess["id"]), list(names)[0])
            self.acc_var.set(pick)
            self.names = names
        tin = sum(x["money_in"] for x in rows)
        tout = sum(x["money_out"] for x in rows)
        info = (f"{len(rows)} rows,  {min(x['date'] for x in rows)} to {max(x['date'] for x in rows)}      Money in {tin:,.2f}      Money out {tout:,.2f}\n"
                f"Opening balance in file: {'-' if p['opening'] is None else format(p['opening'], ',.2f')}      "
                f"Closing balance in file: {'-' if p['closing_in_file'] is None else format(p['closing_in_file'], ',.2f')}\n"
                f"Treated as: {dict(LEDGER_TYPES)[p['ledger_type']]}" + (f"  -  {p['reason']}" if p["reason"] else ""))
        ttk.Label(body, text=info, justify="left").pack(anchor="w", pady=4)
        for w in p["warnings"]:
            ttk.Label(body, text="⚠ " + w, foreground="#8A5A00", wraplength=920, justify="left").pack(anchor="w")
        fr, tree = make_tree(body, ["Date", "Reference", "Description", "Debit", "Credit", "Balance", "Money in", "Money out"],
                             [90, 110, 300, 100, 100, 110, 100, 100], ["w", "w", "w", "e", "e", "e", "e", "e"], height=10)
        fr.pack(fill="both", expand=True, pady=8)
        for x in rows[:12]:
            tree.insert("", "end", values=(x["date"], x["reference"], x["description"], fmt(x["debit"]), fmt(x["credit"]), fmt(x["balance"]),
                                           fmt(x["money_in"]), fmt(x["money_out"])))
        bar = ttk.Frame(body)
        bar.pack(fill="x")
        ttk.Button(bar, text="Skip this file", command=self.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(bar, text="Import", command=lambda: self._ok(p)).pack(side="right")
        self.grab_set()
        self.wait_visibility()
        app.wait_window(self)

    def _ok(self, p):
        self.result = True if p["has_account_col"] else self.names[self.acc_var.get()]
        self.destroy()


class ErpDialog(tk.Toplevel):
    def __init__(self, app, kind, fname, path, parsed, lines):
        super().__init__(app)
        self.title(f"Import {KIND_TITLE[kind]} - {fname}")
        self.transient(app)
        self.app, self.kind, self.fname, self.path, self.parsed = app, kind, fname, path, parsed
        body = ttk.Frame(self, padding=14)
        body.pack(fill="both", expand=True)
        ttk.Label(body, text=fname, font=("Segoe UI", 11, "bold")).pack(anchor="w")
        for ln in lines:
            ttk.Label(body, text=ln).pack(anchor="w", pady=2)
        for w in parsed["warnings"]:
            ttk.Label(body, text="⚠ " + w, foreground="#8A5A00", wraplength=620, justify="left").pack(anchor="w", pady=2)
        today = date.today()
        d_to = f"{today.year}-{today.month - 1:02d}" if today.month > 1 else f"{today.year - 1}-12"
        self.v_from, self.v_to, self.v_year = tk.StringVar(value=MONTH_LABELS[f"{d_to[:4]}-01"]), tk.StringVar(value=MONTH_LABELS[d_to]), tk.StringVar(value="Auto")
        if kind == "collection":
            r = ttk.Frame(body)
            r.pack(fill="x", pady=8)
            ttk.Label(r, text="Year (only if the report does not show it):").pack(side="left")
            ttk.Combobox(r, textvariable=self.v_year, values=["Auto"] + [str(y) for y in range(2023, 2029)], state="readonly", width=8).pack(side="left", padx=6)
        else:
            r = ttk.LabelFrame(body, text="Period this file covers", padding=8)
            r.pack(fill="x", pady=8)
            labels = list(MONTH_LABELS.values())
            ttk.Label(r, text="From").pack(side="left")
            ttk.Combobox(r, textvariable=self.v_from, values=labels, state="readonly", width=9).pack(side="left", padx=6)
            ttk.Label(r, text="To").pack(side="left", padx=(10, 0))
            ttk.Combobox(r, textvariable=self.v_to, values=labels, state="readonly", width=9).pack(side="left", padx=6)
            if kind == "tb":
                ttk.Label(body, foreground="#555", wraplength=620, text="Set this to the period of the trial balance (for example Jan to Sep). "
                                                                       "Revenue vs Collection matches it to the collection period.").pack(anchor="w")
        self.err = ttk.Label(body, foreground="#B00020")
        self.err.pack(anchor="w")
        bar = ttk.Frame(body)
        bar.pack(fill="x", pady=(10, 0))
        ttk.Button(bar, text="Cancel", command=self.destroy).pack(side="right", padx=(6, 0))
        ttk.Button(bar, text="Import", command=self._ok).pack(side="right")
        self.grab_set()
        self.wait_visibility()
        app.wait_window(self)

    def _ok(self):
        a, c = self.app, self.app.c
        try:
            if self.kind == "collection":
                parsed = self.parsed
                if self.v_year.get() != "Auto":
                    parsed = parsers.parse_collection(self.path, int(self.v_year.get()))
                ingest.import_collection(a.conn, c, parsed, self.fname)
            else:
                p_from, p_to = LABEL_TO_MONTH[self.v_from.get()], LABEL_TO_MONTH[self.v_to.get()]
                if p_from > p_to:
                    self.err.configure(text="'From' month is after 'To' month.")
                    return
                if self.kind == "tb":
                    ingest.import_trial_balance(a.conn, c, self.parsed, self.fname, p_from, p_to)
                else:
                    ingest.import_register(a.conn, c, self.kind, self.parsed, self.fname, p_from, p_to)
        except ParseError as e:
            self.err.configure(text=str(e))
            return
        self.destroy()


class TxnWindow(tk.Toplevel):
    def __init__(self, app, title, txs):
        super().__init__(app)
        self.title(title)
        self.geometry("1000x480")
        fr, tree = make_tree(self, ["Date", "Bank", "Reference", "Description", "Money in", "Money out", "Balance"],
                             [90, 140, 120, 380, 110, 110, 120], ["w", "w", "w", "w", "e", "e", "e"], height=15)
        fr.pack(fill="both", expand=True, padx=8, pady=8)
        for t in txs:
            tree.insert("", "end", values=(t["txn_date"], t["bank"], t["reference"], t["description"], fmt(t["money_in"]), fmt(t["money_out"]), fmt(t["balance"])))
        tin, tout = sum(t["money_in"] for t in txs), sum(t["money_out"] for t in txs)
        ttk.Label(self, text=f"{len(txs)} transaction(s)     in {tin:,.2f}     out {tout:,.2f}").pack(anchor="w", padx=10, pady=(0, 8))


class PropertyWindow(tk.Toplevel):
    def __init__(self, app, res, code):
        super().__init__(app)
        self.title(f"{code} - {res['names'].get(code, code)}")
        self.geometry("980x520")
        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        def tab(title, cols, widths, anchors, rows):
            f = ttk.Frame(nb, padding=6)
            nb.add(f, text=title)
            fr, tree = make_tree(f, cols, widths, anchors, height=14)
            fr.pack(fill="both", expand=True)
            for r in rows:
                tree.insert("", "end", values=r)
            return tree

        gl = {}
        for d in res["tb_detail"]:
            if d["g"] == code:
                k = (d["gl_code"], d["gl_desc"])
                gl[k] = gl.get(k, 0.0) + d["revenue"]
        tab("Revenue by GL", ["GL code", "Description", "Revenue (discounts negative)"], [110, 420, 200], ["w", "w", "e"],
            [(k[0], k[1], fmt(v)) for k, v in sorted(gl.items())] + [("", "Total", fmt(sum(gl.values())))])
        tab("VAT lines", ["Date", "Period", "Tenant", "Control", "Net", "VAT", "Gross"], [90, 80, 300, 100, 110, 100, 110],
            ["w", "w", "w", "w", "e", "e", "e"],
            [(d["txn_date"], d["period"], d["tenant"], d["control"], fmt(d["net"]), fmt(d["vat"]), fmt(d["gross"])) for d in res["vat_detail"] if d["g"] == code])
        tab("Security deposit lines", ["Date", "Period", "Tenant", "Control", "Charge", "Amount"], [90, 80, 300, 100, 100, 120],
            ["w", "w", "w", "w", "w", "e"],
            [(d["txn_date"], d["period"], d["tenant"], d["control"], d["charge_code"], fmt(d["amount"])) for d in res["dep_detail"] if d["g"] == code])
        bm = res["collection_by_month"].get(code, {})
        tab("Collection by month", ["Month", "Collection"], [120, 160], ["w", "e"],
            [(mlabel(m), fmt(v)) for m, v in sorted(bm.items())] + [("Total", fmt(sum(bm.values())))])


def main():
    try:                                            # crisp text on high-resolution Windows screens
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    App().mainloop()


if __name__ == "__main__":
    main()
