"""START HERE.

In IDLE:  File > Open > start_propflow.py, then press F5 (Run > Run Module).
PropFlow opens as a normal window. Close the window to stop it.
The modern interface uses PyQt6 (installed automatically the first time, needs internet once). If your
company's Application Control policy blocks PyQt6, it automatically starts the plain built-in window
version instead (needs only openpyxl). Nothing you upload leaves this computer.
"""
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))


def need(module, pip_name):
    try:
        __import__(module)
        return True
    except ImportError:
        pass
    print("Installing %s (one-time, needs internet) ..." % pip_name)
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", pip_name],
                       stdin=subprocess.DEVNULL)
    try:
        __import__(module)
        return True
    except ImportError:
        print("\nCould not install %s (exit code %s). Check the internet connection and run this file again.\n"
              "If it still fails, send a screenshot of this window." % (pip_name, r.returncode))
        return False


def load_qt():
    """PyQt6 is a compiled package. Some company laptops block compiled packages; then we fall back."""
    try:
        import PyQt6.QtWidgets  # noqa: F401
        return True
    except ImportError:
        pass
    print("Installing PyQt6 (one-time, needs internet) ...")
    subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "PyQt6"], stdin=subprocess.DEVNULL)
    try:
        import PyQt6.QtWidgets  # noqa: F401
        return True
    except Exception as e:  # ImportError, or DLL blocked by Application Control
        print("\nPyQt6 cannot run on this computer (%s).\nStarting the built-in window version instead - same features.\n" % e)
        return False


def main():
    if sys.version_info < (3, 8):
        print("PropFlow needs Python 3.8 or newer.")
        return
    try:
        import sqlite3  # noqa: F401
    except ImportError as e:
        print("This Python is missing a standard part (%s). Re-run the Python installer and choose Modify." % e)
        return
    if not need("openpyxl", "openpyxl"):
        return
    os.chdir(HERE)
    if HERE not in sys.path:
        sys.path.insert(0, HERE)
    if os.environ.get("PROPFLOW_UI") != "tk" and load_qt():
        import qt_app
        qt_app.main()
        return
    try:
        import tkinter  # noqa: F401
    except ImportError as e:
        print("This Python has no tkinter (%s). Re-run the Python installer, choose Modify, tick 'tcl/tk and IDLE'." % e)
        return
    import app
    app.main()


if __name__ == "__main__":
    main()
