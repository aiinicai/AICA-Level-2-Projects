"""PropFlow - PyQt6 desktop interface (vibrant theme).

Same engine as the Tkinter version (core/), nothing is sent anywhere. Start with start_propflow.py.
"""
import os
import shutil
import sys
from datetime import date
from pathlib import Path

from PyQt6.QtCore import QSize, Qt
from PyQt6.QtGui import QBrush, QColor, QFont
from PyQt6.QtWidgets import (QAbstractItemView, QApplication, QButtonGroup, QCheckBox, QComboBox, QDialog,
                             QFileDialog, QFormLayout, QFrame, QGridLayout, QHBoxLayout, QHeaderView, QLabel,
                             QLineEdit, QMainWindow, QMessageBox, QPushButton, QSizePolicy, QStackedWidget,
                             QTableWidget, QTableWidgetItem, QTabWidget, QVBoxLayout, QWidget)

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from core import cashflow, classify, db, defaults, export, ingest, parsers, recon  # noqa: E402
from core.parsers import ParseError  # noqa: E402

# ------------------------------------------------------------------ palette
ORANGE, ORANGE_L = "#F97316", "#FDBA74"          # light orange for headings
INDIGO, VIOLET, PINK = "#4F46E5", "#7C3AED", "#DB2777"
NAVY, MUTED, LINE, BG = "#1E1B4B", "#6B7280", "#E5E7EB", "#F7F5FF"
GOOD, WARN, BAD, SKY, TEAL = "#059669", "#EA580C", "#DC2626", "#0284C7", "#0D9488"

QSS = f"""
* {{ font-family: 'Segoe UI', 'Inter', 'Helvetica Neue', Arial; font-size: 10pt; color: {NAVY}; }}
QMainWindow, QDialog {{ background: {BG}; }}
QWidget#page {{ background: {BG}; }}
QFrame#header {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #4F46E5, stop:0.55 #7C3AED, stop:1 #DB2777); }}
QLabel#logo {{ color: white; font-size: 19pt; font-weight: 800; }}
QLabel#tag {{ color: #E9D5FF; font-size: 9pt; }}
QPushButton[class="pill"] {{ background: transparent; color: #EDE9FE; border: 0; border-radius: 15px; padding: 7px 18px; font-weight: 700; }}
QPushButton[class="pill"]:checked {{ background: white; color: {VIOLET}; }}
QPushButton[class="pill"]:hover:!checked {{ background: rgba(255,255,255,0.18); }}
QFrame#nav {{ background: white; border-bottom: 1px solid {LINE}; }}
QPushButton[class="navbtn"] {{ background: transparent; border: 0; border-bottom: 3px solid transparent; color: {MUTED};
    padding: 11px 16px; font-weight: 700; }}
QPushButton[class="navbtn"]:hover {{ color: {VIOLET}; }}
QPushButton[class="navbtn"]:checked {{ color: {ORANGE}; border-bottom: 3px solid {ORANGE}; }}
QFrame#banner {{ background: qlineargradient(x1:0,y1:0,x2:1,y2:1, stop:0 #1E1B4B, stop:1 #4C1D95); border-radius: 14px; }}
QLabel#bTitle {{ color: {ORANGE_L}; font-size: 20pt; font-weight: 800; }}
QLabel#bCrumb {{ color: #C4B5FD; font-size: 9pt; font-weight: 600; }}
QLabel#bDesc {{ color: #E0E7FF; font-size: 9.5pt; }}
QFrame[class="kpi"] {{ background: white; border: 1px solid {LINE}; border-radius: 12px; }}
QLabel[class="kpiT"] {{ color: {MUTED}; font-size: 8pt; font-weight: 700; }}
QLabel[class="kpiV"] {{ font-size: 16pt; font-weight: 800; }}
QLabel#notes {{ background: white; border: 1px solid {LINE}; border-radius: 10px; padding: 8px 12px; }}
QLabel[class="hint"] {{ color: {MUTED}; font-size: 9pt; }}
QLabel[class="h2"] {{ color: #C2410C; font-size: 11pt; font-weight: 800; }}
QPushButton {{ background: white; border: 1px solid #D1D5DB; border-radius: 8px; padding: 7px 14px; font-weight: 600; }}
QPushButton:hover {{ border-color: {VIOLET}; color: {VIOLET}; background: #F5F3FF; }}
QPushButton[class="primary"] {{ color: white; border: 0; padding: 9px 20px; font-weight: 700;
    background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #F97316, stop:1 #EC4899); }}
QPushButton[class="primary"]:hover {{ color: white; background: qlineargradient(x1:0,y1:0,x2:1,y2:0, stop:0 #EA580C, stop:1 #DB2777); }}
QPushButton[class="danger"] {{ color: {BAD}; }}
QComboBox, QLineEdit {{ background: white; border: 1px solid #D1D5DB; border-radius: 8px; padding: 6px 10px; min-height: 20px; }}
QComboBox:focus, QLineEdit:focus {{ border-color: {VIOLET}; }}
QComboBox QAbstractItemView {{ background: white; selection-background-color: #EDE9FE; selection-color: {NAVY}; }}
QTableWidget {{ background: white; border: 1px solid {LINE}; border-radius: 10px; gridline-color: #F1F5F9;
    selection-background-color: #DDD6FE; selection-color: {NAVY}; }}
QTableWidget::item {{ padding: 5px 8px; border-bottom: 1px solid #F3F4F6; }}
QHeaderView::section {{ background: #FED7AA; color: #7C2D12; font-weight: 800; padding: 9px 8px; border: 0;
    border-right: 1px solid #FDBA74; }}
QTabWidget::pane {{ border: 0; }}
QTabWidget QTabBar::tab {{ background: #FFEDD5; color: #9A3412; padding: 9px 18px; margin-right: 4px; font-weight: 700;
    border-top-left-radius: 8px; border-top-right-radius: 8px; }}
QTabWidget QTabBar::tab:selected {{ background: {ORANGE}; color: white; }}
QScrollBar:vertical {{ background: transparent; width: 11px; }}
QScrollBar::handle:vertical {{ background: #C4B5FD; border-radius: 5px; min-height: 30px; }}
QScrollBar:horizontal {{ background: transparent; height: 11px; }}
QScrollBar::handle:horizontal {{ background: #C4B5FD; border-radius: 5px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QCheckBox {{ spacing: 8px; }}
"""

LEDGER_TYPES = [("auto", "Auto-detect (recommended)"), ("books", "Company books (Debit = money in)"),
                ("statement", "Bank statement (Credit = money in)")]
KIND_TITLE = {"collection": "Cash collection", "tb": "Trial balance", "vat": "VAT register", "deposit": "Security deposits"}
FILES = "Excel / CSV files (*.xlsx *.xlsm *.xls *.csv);;All files (*)"
AL_R = Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter
AL_L = Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter


def fmt(v):
    if v is None or v == "":
        return ""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return str(v)
    return "-" if abs(v) < 0.005 else f"{v:,.2f}"


def month_keys(y0=2023, y1=2028):
    return [f"{y}-{m:02d}" for y in range(y0, y1 + 1) for m in range(1, 13)]


mlabel = cashflow.month_label
MONTH_LABELS = {k: mlabel(k) for k in month_keys()}
LABEL_TO_MONTH = {v: k for k, v in MONTH_LABELS.items()}
INTERBANK = set(defaults.INTERBANK_KEYS)

ROW_STYLE = {"opening": ("#E0E7FF", None, True), "subtotal": ("#DCFCE7", None, True), "closing": ("#DCFCE7", None, True),
             "total": ("#DCFCE7", None, True), "net": ("#F1F5F9", None, True), "ib": ("#FEF3C7", None, False),
             "bad": (None, BAD, False), "check": (None, MUTED, False)}


# ------------------------------------------------------------------ small widgets
def css(widget, cls):
    widget.setProperty("class", cls)
    return widget


def label(text, cls=None, wrap=False):
    w = QLabel(text)
    w.setWordWrap(wrap)
    if cls:
        css(w, cls)
    return w


def button(text, cb=None, cls=None):
    b = QPushButton(text)
    b.setCursor(Qt.CursorShape.PointingHandCursor)
    if cls:
        css(b, cls)
    if cb:
        b.clicked.connect(lambda _=False: cb())
    return b


def make_table(columns, widths=None, numeric=(), stretch=None, multi=False):
    t = QTableWidget(0, len(columns))
    t.setHorizontalHeaderLabels(columns)
    t.verticalHeader().setVisible(False)
    t.verticalHeader().setDefaultSectionSize(32)
    t.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    t.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    t.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection if multi else QAbstractItemView.SelectionMode.SingleSelection)
    t.setShowGrid(False)
    t.setAlternatingRowColors(False)
    t.setWordWrap(False)
    t.horizontalHeader().setStretchLastSection(False)
    t.horizontalHeader().setHighlightSections(False)
    t._numeric = set(numeric)
    for i in range(len(columns)):
        mode = QHeaderView.ResizeMode.Stretch if i == stretch else QHeaderView.ResizeMode.Interactive
        t.horizontalHeader().setSectionResizeMode(i, mode)
        if widths and i < len(widths) and i != stretch:
            t.setColumnWidth(i, widths[i])
    return t


def fill_table(t, rows, kinds=None, ids=None):
    t.setUpdatesEnabled(False)
    t.setRowCount(len(rows))
    for r, row in enumerate(rows):
        st = ROW_STYLE.get(kinds[r]) if kinds and kinds[r] else None
        for c, v in enumerate(row):
            it = QTableWidgetItem("" if v is None else str(v))
            it.setTextAlignment(AL_R if c in t._numeric else AL_L)
            if st:
                bg, fg, bold = st
                if bg:
                    it.setBackground(QBrush(QColor(bg)))
                if fg:
                    it.setForeground(QBrush(QColor(fg)))
                if bold:
                    f = it.font()
                    f.setBold(True)
                    it.setFont(f)
            if c == 0 and ids is not None:
                it.setData(Qt.ItemDataRole.UserRole, ids[r])
            t.setItem(r, c, it)
    t.setUpdatesEnabled(True)


def selected_ids(t):
    out = []
    for idx in t.selectionModel().selectedRows():
        it = t.item(idx.row(), 0)
        if it is not None:
            out.append(it.data(Qt.ItemDataRole.UserRole))
    return out


class Banner(QFrame):
    """Deep violet card with the page title in light orange."""

    def __init__(self, title, crumb, desc):
        super().__init__()
        self.setObjectName("banner")
        lay = QHBoxLayout(self)
        lay.setContentsMargins(24, 18, 24, 18)
        left = QVBoxLayout()
        left.setSpacing(2)
        self.crumb = QLabel(crumb.upper())
        self.crumb.setObjectName("bCrumb")
        t = QLabel(title)
        t.setObjectName("bTitle")
        d = QLabel(desc)
        d.setObjectName("bDesc")
        d.setWordWrap(True)
        for w in (self.crumb, t, d):
            left.addWidget(w)
        lay.addLayout(left, 1)
        self.right = QHBoxLayout()
        self.right.setSpacing(10)
        lay.addLayout(self.right)

    def set_crumb(self, text):
        self.crumb.setText(text.upper())


class KPIRow(QWidget):
    def __init__(self, items):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(12)
        self.vals = []
        for title, colour in items:
            c = css(QFrame(), "kpi")
            c.setStyleSheet(f"QFrame[class='kpi'] {{ border-top: 4px solid {colour}; }}")
            v = QVBoxLayout(c)
            v.setContentsMargins(16, 12, 16, 12)
            v.setSpacing(2)
            v.addWidget(css(QLabel(title), "kpiT"))
            val = css(QLabel("-"), "kpiV")
            val.setStyleSheet(f"color: {colour};")
            v.addWidget(val)
            self.vals.append(val)
            lay.addWidget(c, 1)

    def set(self, values):
        for lab, v in zip(self.vals, values):
            lab.setText("-" if v is None or abs(v) < 0.005 else f"{v:,.2f}")


class Notes(QLabel):
    def __init__(self):
        super().__init__()
        self.setObjectName("notes")
        self.setWordWrap(True)
        self.setTextFormat(Qt.TextFormat.RichText)
        self.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

    def show_msgs(self, warnings=(), checks=(), notes=(), info=()):
        parts = []
        for items, colour, mark in ((warnings, WARN, "&#9888;"), (checks, GOOD, "&#10003;"), (notes, INDIGO, "&#9432;"), (info, INDIGO, "&#9432;")):
            for t in items:
                t = str(t).replace("&", "&amp;").replace("<", "&lt;")
                parts.append(f"<span style='color:{colour}'>{mark} {t}</span>")
        self.setText("<br>".join(parts) if parts else f"<span style='color:{GOOD}'>&#10003; No warnings.</span>")


def save_file(parent, title, default_name, data):
    path, _ = QFileDialog.getSaveFileName(parent, title, default_name, "Excel workbook (*.xlsx)")
    if not path:
        return
    try:
        with open(path, "wb") as fh:
            fh.write(data)
    except OSError as e:
        QMessageBox.critical(parent, "Could not save", f"{e}\n\nIs the file open in Excel? Close it and try again.")
        return
    QMessageBox.information(parent, "Saved", f"Saved to:\n{path}")
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)
    except Exception:
        pass


class FormDialog(QDialog):
    """fields: dict(key, label, kind='entry'|'combo'|'check', options=[str | (key, label)])."""

    def __init__(self, parent, title, fields, initial=None, validate=None, hint=None):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(520)
        self.result_data = None
        self._fields, self._validate, self._w = fields, validate, {}
        initial = initial or {}
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 20, 22, 18)
        lay.addWidget(label(title, "h2"))
        if hint:
            lay.addWidget(label(hint, "hint", True))
        form = QFormLayout()
        form.setHorizontalSpacing(16)
        form.setVerticalSpacing(10)
        for f in fields:
            val = initial.get(f["key"], f.get("default", ""))
            kind = f.get("kind", "entry")
            if kind == "check":
                w = QCheckBox()
                w.setChecked(str(val) not in ("", "0", "None", "False"))
            elif kind == "combo":
                w = QComboBox()
                for o in f["options"]:
                    k, l = o if isinstance(o, tuple) else (o, o)
                    w.addItem(l, k)
                i = w.findData(val)
                w.setCurrentIndex(max(i, 0))
            else:
                w = QLineEdit("" if val is None else str(val))
            self._w[f["key"]] = w
            form.addRow(f["label"], w)
        lay.addLayout(form)
        self.err = QLabel("")
        self.err.setStyleSheet(f"color:{BAD}")
        self.err.setWordWrap(True)
        lay.addWidget(self.err)
        bar = QHBoxLayout()
        bar.addStretch(1)
        bar.addWidget(button("Cancel", self.reject))
        ok = button("Save", self._ok, "primary")
        ok.setDefault(True)
        bar.addWidget(ok)
        lay.addLayout(bar)

    def _ok(self):
        out = {}
        for f in self._fields:
            w = self._w[f["key"]]
            k = f.get("kind", "entry")
            out[f["key"]] = (1 if w.isChecked() else 0) if k == "check" else (w.currentData() if k == "combo" else w.text().strip())
        if self._validate:
            msg = self._validate(out)
            if msg:
                self.err.setText(msg)
                return
        self.result_data = out
        self.accept()

    def get(self):
        return self.result_data if self.exec() else None


class Page(QWidget):
    def __init__(self, win):
        super().__init__()
        self.win = win
        self.setObjectName("page")
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(22, 18, 22, 14)
        self.lay.setSpacing(12)

    @property
    def conn(self):
        return self.win.conn

    @property
    def c(self):
        return self.win.country


# ====================================================================== 1. SUMMARY
class SummaryPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.banner = Banner("Cash Flow Statement - Monthly Summary", "Multi-month fund flow consolidation",
                             "Roll-forward consolidation of all collection banks: opening balances, rent collections, interbank "
                             "transfers, payments and closing balances month by month.")
        self.banner.right.addWidget(button("Export to Excel", self.export, "primary"))
        self.lay.addWidget(self.banner)
        self.kpi = KPIRow([("INITIAL OPENING BALANCE", BAD), ("TOTAL RENT COLLECTIONS", GOOD), ("INTERBANK TRANSFERS IN", ORANGE),
                           ("TOTAL INFLOW", INDIGO), ("TOTAL OUTFLOWS", PINK), ("NET CLOSING BALANCE", VIOLET)])
        self.lay.addWidget(self.kpi)
        self.notes = Notes()
        self.lay.addWidget(self.notes)
        self.table = make_table(["Line"])
        self.lay.addWidget(self.table, 1)
        self.res = None

    def refresh(self):
        res = self.res = cashflow.summary(self.conn, self.c)
        self.kpi.set([None] * 6)
        if not res["labels"]:
            self.notes.show_msgs(notes=["Upload bank ledgers first (Upload tab)."])
            self.table.setRowCount(0)
            self.banner.set_crumb(f"{self.c} operations ({db.CURRENCY[self.c]})")
            return
        self.notes.show_msgs(res["warnings"])
        T = res["total"]
        ib = 0.0
        for lab in res["labels"]:
            if lab.startswith("Total Receipts"):
                break
            if lab.lower().startswith("interbank"):
                ib += T[lab] or 0.0
        self.kpi.set([T.get("Opening Balance"), T.get("Rent Collection"), ib, T.get("Total Receipts / Inflows"),
                      T.get("Total Payments / Outflows"), T.get("Closing Balance")])
        ml = res["mlabels"]
        self.banner.set_crumb(f"{self.c} operations ({db.CURRENCY[self.c]})  ·  {len(ml)} months tracked ({ml[0]} - {ml[-1]})")
        cols = ["Line"] + ml + ["Total"]
        t = self.table
        t.setColumnCount(len(cols))
        t.setHorizontalHeaderLabels(cols)
        t._numeric = set(range(1, len(cols)))
        t.setColumnWidth(0, 300)
        for i in range(1, len(cols)):
            t.horizontalHeader().setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            t.setColumnWidth(i, 130)
        t.horizontalHeader().setSectionResizeMode(len(cols) - 1, QHeaderView.ResizeMode.Stretch)
        rows, kinds = [], []
        for lab in res["labels"]:
            k = res["kinds"][lab]
            rows.append([lab] + [fmt(res["values"][lab].get(m)) for m in ml] + [fmt(res["total"][lab])])
            kinds.append(k if k != "line" else ("bad" if lab.startswith("Unclassified") else "ib" if lab.lower().startswith("interbank") else ""))
        fill_table(t, rows, kinds)

    def export(self):
        if not self.res or not self.res["labels"]:
            return
        mats = [(m, cashflow.matrix(self.conn, self.c, m)) for m in self.res["months"]]
        save_file(self, "Save summary", f"{self.c}_cash_flow_summary.xlsx", export.workbook_bytes(self.c, self.res, mats))


# ====================================================================== 2. MATRIX
class MatrixPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.banner = Banner("Bank Accounts Matrix - Monthly Cash Flow", "Collection bank accounts",
                             "One column per collection bank account. Double-click any figure to see the transactions behind it.")
        self.month = QComboBox()
        self.month.setMinimumWidth(120)
        self.month.activated.connect(lambda _: self.refresh(keep=True))
        self.banner.right.addWidget(self.month)
        self.banner.right.addWidget(button("Export to Excel", self.export, "primary"))
        self.lay.addWidget(self.banner)
        self.kpi = KPIRow([("OPENING BALANCE", BAD), ("TOTAL RECEIPTS", GOOD), ("TOTAL PAYMENTS", PINK), ("NET MOVEMENT", INDIGO),
                           ("CLOSING BALANCE", VIOLET)])
        self.lay.addWidget(self.kpi)
        self.notes = Notes()
        self.lay.addWidget(self.notes)
        self.table = make_table(["Line"])
        self.table.cellDoubleClicked.connect(self.drill)
        self.lay.addWidget(self.table, 1)
        self.res = None

    def refresh(self, keep=False):
        months = cashflow.months_available(self.conn, self.c)
        labs = [mlabel(m) for m in months]
        cur = self.month.currentText()
        self.month.blockSignals(True)
        self.month.clear()
        self.month.addItems(labs)
        if keep and cur in labs:
            self.month.setCurrentText(cur)
        elif labs:
            self.month.setCurrentIndex(len(labs) - 1)
        self.month.blockSignals(False)
        self.kpi.set([None] * 5)
        self.res = None
        self.table.setRowCount(0)
        if not months:
            self.notes.show_msgs(notes=["Upload bank ledgers first (Upload tab)."])
            return
        month = LABEL_TO_MONTH[self.month.currentText()]
        res = self.res = cashflow.matrix(self.conn, self.c, month)
        self.notes.show_msgs(res["warnings"], res["checks"], res["notes"])
        tot = {r["key"]: r["total"] for r in res["rows"]}
        self.kpi.set([tot.get("opening"), tot.get("total_receipts"), tot.get("total_payments"), tot.get("net"), tot.get("closing")])
        self.banner.set_crumb(f"{self.c} operations ({db.CURRENCY[self.c]})  ·  {self.month.currentText()}")
        accs = res["accounts"]
        cols = ["Line"] + [f"{a['gl_code'] or ''}  {a['name']}".strip() for a in accs] + ["Total"]
        t = self.table
        t.setColumnCount(len(cols))
        t.setHorizontalHeaderLabels(cols)
        t._numeric = set(range(1, len(cols)))
        t.setColumnWidth(0, 300)
        for i in range(1, len(cols)):
            t.horizontalHeader().setSectionResizeMode(i, QHeaderView.ResizeMode.Interactive)
            t.setColumnWidth(i, 190 if i <= len(accs) else 140)
        rows, kinds = [], []
        for r in res["rows"]:
            rows.append([r["label"]] + [fmt(r["values"].get(a["id"])) for a in accs] + [fmt(r["total"])])
            kinds.append(r["kind"] if r["kind"] != "line" else ("bad" if r["key"].startswith("unclassified") else "ib" if r["key"] in INTERBANK else ""))
        fill_table(t, rows, kinds)

    def drill(self, r, c):
        if not self.res:
            return
        row = self.res["rows"][r]
        if row["kind"] != "line":
            return
        accs = self.res["accounts"]
        bank = accs[c - 1]["id"] if 1 <= c <= len(accs) else None
        month = LABEL_TO_MONTH[self.month.currentText()]
        txs = cashflow.transactions_for(self.conn, self.c, month, row["key"], bank)
        title = f"{row['label']} - {self.month.currentText()}" + (f" - {accs[c - 1]['name']}" if bank else "")
        TxnDialog(self, title, txs).exec()

    def export(self):
        if self.res:
            month = LABEL_TO_MONTH[self.month.currentText()]
            save_file(self, "Save cash flow", f"{self.c}_cash_flow_{month}.xlsx", export.workbook_bytes(self.c, matrices=[(month, self.res)]))


# ====================================================================== 3. REVENUE VS COLLECTION
class ReconPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.banner = Banner("Revenue vs. Collection Reconciliation", "Report 2 - accrual revenue vs cash collection",
                             "Trial balance revenue (GL 4xxx) compared with ERP cash collection, after VAT and security deposits. "
                             "The remainder is the net receivable / advance.")
        self.banner.right.addWidget(button("Export to Excel", self.export, "primary"))
        self.lay.addWidget(self.banner)
        self.kpi = KPIRow([("1. REVENUE (GL 4XXX)", INDIGO), ("2. (+) VAT AMOUNT", TEAL), ("3. (+) SEC. DEPOSITS", SKY),
                           ("SUBTOTAL (1+2+3)", VIOLET), ("4. CASH COLLECTION", GOOD), ("NET RECEIVABLE / ADVANCE", ORANGE)])
        self.lay.addWidget(self.kpi)
        bar = QHBoxLayout()
        labels = list(MONTH_LABELS.values())
        self.f, self.t, self.tb = QComboBox(), QComboBox(), QComboBox()
        self.f.addItems(labels)
        self.t.addItems(labels)
        self.tb.setMinimumWidth(320)
        for w, name in ((self.f, "From"), (self.t, "To"), (self.tb, "Trial balance")):
            bar.addWidget(QLabel(name))
            bar.addWidget(w)
            w.activated.connect(lambda _: self.refresh(keep=True))
        bar.addStretch(1)
        self.lay.addLayout(bar)
        self.notes = Notes()
        self.lay.addWidget(self.notes)
        self.table = make_table(["Code", "Property", "Revenue (GL 4xxx)", "VAT", "Security deposits", "Revenue+VAT+Deposits", "Collection",
                                 "Net advance / (receivable)", "Status"], [80, 240, 150, 110, 140, 170, 140, 190, 130],
                                numeric=(2, 3, 4, 5, 6, 7), stretch=1)
        self.table.cellDoubleClicked.connect(self.drill)
        self.lay.addWidget(self.table, 1)
        self.lay.addWidget(label("Net advance / (receivable) = Collection - (Revenue + VAT + Security deposits). Positive = tenants paid more "
                                 "than revenue + VAT + deposits; negative = revenue not yet collected. Double-click a property for detail.",
                                 "hint", True))
        self.res, self.tb_ids = None, {}

    def refresh(self, keep=False):
        self.res = None
        self.kpi.set([None] * 6)
        ups = recon.uploads(self.conn, self.c, "collection")
        self.tb_ids = {"Automatic (matching period)": None}
        for u in recon.uploads(self.conn, self.c, "tb"):
            self.tb_ids[f"{mlabel(u['period_from'])} to {mlabel(u['period_to'])} - {u['filename']}"] = u["id"]
        cur = self.tb.currentText()
        self.tb.blockSignals(True)
        self.tb.clear()
        self.tb.addItems(list(self.tb_ids))
        if keep and cur in self.tb_ids:
            self.tb.setCurrentText(cur)
        self.tb.blockSignals(False)
        self.table.setRowCount(0)
        if not ups:
            self.notes.show_msgs(notes=["Upload at least the cash collection report and the trial balance (Upload tab)."])
            return
        if not keep:
            self.f.setCurrentText(mlabel(min(u["period_from"] for u in ups)))
            self.t.setCurrentText(mlabel(max(u["period_to"] for u in ups)))
        p_from, p_to = LABEL_TO_MONTH[self.f.currentText()], LABEL_TO_MONTH[self.t.currentText()]
        if p_from > p_to:
            self.notes.show_msgs(["'From' month is after 'To' month."])
            return
        res = self.res = recon.reconcile(self.conn, self.c, p_from, p_to, self.tb_ids.get(self.tb.currentText()))
        self.notes.show_msgs(res["warnings"], info=res["info"])
        t = res["totals"]
        self.kpi.set([t["revenue"], t["vat"], t["deposits"], t["subtotal"], t["collection"], t["difference"]])
        self.banner.set_crumb(f"{self.c} operations ({db.CURRENCY[self.c]})  ·  {self.f.currentText()} - {self.t.currentText()}")
        rows = [[r["code"], r["name"], fmt(r["revenue"]), fmt(r["vat"]), fmt(r["deposits"]), fmt(r["subtotal"]), fmt(r["collection"]),
                 fmt(r["difference"]), r["status"]] for r in res["rows"]]
        kinds = [""] * len(rows)
        rows.append(["", "TOTAL", fmt(t["revenue"]), fmt(t["vat"]), fmt(t["deposits"]), fmt(t["subtotal"]), fmt(t["collection"]),
                     fmt(t["difference"]), ""])
        kinds.append("total")
        fill_table(self.table, rows, kinds, ids=[r["code"] for r in res["rows"]] + [None])

    def drill(self, r, c):
        it = self.table.item(r, 0)
        code = it.data(Qt.ItemDataRole.UserRole) if it else None
        if code and self.res:
            PropertyDialog(self, self.res, code).exec()

    def export(self):
        if self.res and self.res["rows"]:
            r = self.res
            save_file(self, "Save revenue vs collection", f"{self.c}_revenue_vs_collection_{r['p_from']}_{r['p_to']}.xlsx",
                      export.workbook_bytes(self.c, rres=r, tolerance=float(db.get_settings(self.conn, self.c)["balanced_tolerance"])))


# ====================================================================== 4. TRANSACTIONS
class TxnPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.lay.addWidget(Banner("Transactions", "Review & classify",
                                  "Every ledger line and the report line it falls under. Lines no rule recognises show in red - classify "
                                  "them here or turn them into a rule."))
        bar = QHBoxLayout()
        self.m, self.b, self.s = QComboBox(), QComboBox(), QComboBox()
        self.s.addItems(["Unclassified only", "Everything"])
        for w, n in ((self.m, "Month"), (self.b, "Bank"), (self.s, "Show")):
            bar.addWidget(QLabel(n))
            bar.addWidget(w)
            w.activated.connect(lambda _: self.refresh(keep=True))
        self.count = label("", "hint")
        bar.addStretch(1)
        bar.addWidget(self.count)
        self.lay.addLayout(bar)
        self.table = make_table(["Date", "Bank", "Reference", "Description", "Money in", "Money out", "Category"],
                                [95, 170, 130, 380, 120, 120, 240], numeric=(4, 5), stretch=3, multi=True)
        self.lay.addWidget(self.table, 1)
        bar2 = QHBoxLayout()
        bar2.addWidget(QLabel("Classify selected as"))
        self.cat = QComboBox()
        self.cat.setMinimumWidth(300)
        bar2.addWidget(self.cat)
        bar2.addWidget(button("Apply to selected", self.apply, "primary"))
        bar2.addWidget(button("Make a rule from selected...", self.make_rule))
        bar2.addStretch(1)
        self.lay.addLayout(bar2)
        self.rows = {}

    def refresh(self, keep=False):
        months = cashflow.months_available(self.conn, self.c)
        accs = db.accounts(self.conn, self.c)
        cm, cb = self.m.currentText(), self.b.currentText()
        for combo, items, cur in ((self.m, ["All"] + [mlabel(m) for m in months], cm), (self.b, ["All banks"] + [a["name"] for a in accs], cb)):
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(items)
            if keep and cur in items:
                combo.setCurrentText(cur)
            combo.blockSignals(False)
        cats = [(c["key"], c["label"]) for c in db.categories(self.conn, self.c)]
        self.cat.clear()
        for k, l in cats:
            self.cat.addItem(l, k)
        label_of = dict(cats)
        q = ("SELECT t.id, t.txn_date, a.name AS bank, t.reference, t.description, t.money_in, t.money_out, t.category "
             "FROM ledger_txn t JOIN bank_accounts a ON a.id=t.account_id WHERE a.country=?")
        prm = [self.c]
        if self.m.currentText() not in ("All", ""):
            q += " AND t.month=?"
            prm.append(LABEL_TO_MONTH[self.m.currentText()])
        if self.b.currentText() not in ("All banks", ""):
            q += " AND a.name=?"
            prm.append(self.b.currentText())
        if self.s.currentText() == "Unclassified only":
            keys = [k for k, _ in cats]
            q += " AND (t.category IS NULL OR t.category='' OR t.category NOT IN (%s))" % ",".join("?" * len(keys))
            prm += keys
        q += " ORDER BY t.txn_date, t.id LIMIT 2000"
        data = [dict(r) for r in self.conn.execute(q, prm)]
        self.rows = {r["id"]: r for r in data}
        fill_table(self.table, [[r["txn_date"], r["bank"], r["reference"], r["description"], fmt(r["money_in"]), fmt(r["money_out"]),
                                 label_of.get(r["category"], "(unclassified)")] for r in data],
                   ["" if r["category"] in label_of else "bad" for r in data], ids=[r["id"] for r in data])
        self.count.setText(f"{len(data)} transaction(s) shown")

    def apply(self):
        ids = selected_ids(self.table)
        key = self.cat.currentData()
        if not ids or not key:
            QMessageBox.information(self, "Classify", "Select one or more transactions and choose a category first.")
            return
        for i in ids:
            self.conn.execute("UPDATE ledger_txn SET category=?, manual=1 WHERE id=?", (key, i))
        self.conn.commit()
        self.win.refresh_all()

    def make_rule(self):
        ids = selected_ids(self.table)
        if not ids:
            QMessageBox.information(self, "Make a rule", "Select a transaction first.")
            return
        t = self.rows[ids[0]]
        words = " ".join((t["description"] or "").split()[:3])
        self.win.pages["rules"].add_rule(dict(name=f"Rule: {words}", priority=100, field="description", match="contains", pattern=words,
                                              direction="in" if t["money_in"] > 0 else "out", category=self.cat.currentData(), active=1))


# ====================================================================== 5. RULES
class RulesPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.lay.addWidget(Banner("Rules", "Classification",
                                  "Words in the description decide the report line. Lowest priority number is tried first; the first match "
                                  "wins. Hand-made classifications are never overwritten."))
        self.table = make_table(["Priority", "Name", "Look in", "Match", "Words / pattern", "Direction", "Category", "On"],
                                [75, 240, 110, 110, 340, 90, 250, 50], stretch=4)
        self.table.cellDoubleClicked.connect(lambda *_: self.edit_rule())
        self.lay.addWidget(self.table, 1)
        bar = QHBoxLayout()
        bar.addWidget(button("Add rule...", self.add_rule, "primary"))
        bar.addWidget(button("Edit...", self.edit_rule))
        bar.addWidget(button("Delete", self.delete_rule, "danger"))
        bar.addWidget(button("Re-apply rules to all transactions", self.reapply))
        bar.addStretch(1)
        self.lay.addLayout(bar)
        self.lay.addWidget(label("'out' money sent to a receipt line (e.g. a returned R- cheque to Rent Collection) reduces that line.", "hint"))

    def cats(self):
        return [(c["key"], c["label"]) for c in db.categories(self.conn, self.c)]

    def refresh(self):
        lab = dict(self.cats())
        rules = [dict(r) for r in self.conn.execute("SELECT * FROM rules WHERE country=? ORDER BY priority, id", (self.c,))]
        fill_table(self.table, [[r["priority"], r["name"], r["field"], r["match"], r["pattern"], r["direction"],
                                 lab.get(r["category"], r["category"]), "yes" if r["active"] else "no"] for r in rules],
                   ids=[r["id"] for r in rules])

    def fields(self):
        return [dict(key="name", label="Name"), dict(key="priority", label="Priority (lower = first)"),
                dict(key="field", label="Look in", kind="combo", options=["description", "reference", "both"]),
                dict(key="match", label="Match type", kind="combo", options=["contains", "startswith", "regex"]),
                dict(key="pattern", label="Words / pattern"),
                dict(key="direction", label="Money direction", kind="combo", options=["in", "out", "any"]),
                dict(key="category", label="Category", kind="combo", options=self.cats()),
                dict(key="active", label="Active", kind="check")]

    @staticmethod
    def validate(v):
        if not v["pattern"]:
            return "Enter the words or pattern to look for (separate alternatives with |)."
        if not str(v["priority"]).lstrip("-").isdigit():
            return "Priority must be a whole number."
        return None

    def save(self, v, rid=None):
        vals = (int(v["priority"]), v["name"] or v["pattern"], v["field"], v["match"], v["pattern"], v["direction"], v["category"], v["active"])
        if rid is None:
            self.conn.execute("INSERT INTO rules(country,priority,name,field,match,pattern,direction,category,active) VALUES (?,?,?,?,?,?,?,?,?)",
                              (self.c,) + vals)
        else:
            self.conn.execute("UPDATE rules SET priority=?,name=?,field=?,match=?,pattern=?,direction=?,category=?,active=? WHERE id=?", vals + (rid,))
        self.conn.commit()
        self.win.refresh_all()

    def add_rule(self, initial=None):
        d = FormDialog(self, "Add rule", self.fields(), initial or dict(priority=100, field="description", match="contains", direction="any", active=1),
                       self.validate, "Words are not case sensitive. Separate alternatives with |, e.g.  bank charge|commission")
        v = d.get()
        if v:
            self.save(v)

    def edit_rule(self):
        ids = selected_ids(self.table)
        if not ids:
            return
        r = dict(self.conn.execute("SELECT * FROM rules WHERE id=?", (ids[0],)).fetchone())
        v = FormDialog(self, "Edit rule", self.fields(), r, self.validate).get()
        if v:
            self.save(v, ids[0])

    def delete_rule(self):
        ids = selected_ids(self.table)
        if ids and QMessageBox.question(self, "Delete rule", "Delete the selected rule?") == QMessageBox.StandardButton.Yes:
            self.conn.execute("DELETE FROM rules WHERE id=?", (ids[0],))
            self.conn.commit()
            self.win.refresh_all()

    def reapply(self):
        n = classify.reclassify_country(self.conn, self.c)
        QMessageBox.information(self, "Rules", f"{n} transaction(s) re-classified.")
        self.win.refresh_all()


# ====================================================================== 6. UPLOAD
class UploadPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.lay.addWidget(Banner("Upload Bank Ledgers & ERP Reports", "Step 1 - load your files",
                                  "Bank ledgers feed the cash flow. The four ERP reports feed Revenue vs Collection. Nothing leaves this computer."))
        a = QFrame()
        css(a, "kpi")
        al = QVBoxLayout(a)
        al.setContentsMargins(18, 14, 18, 14)
        al.addWidget(label("A.  Bank ledgers - one file per collection bank account", "h2"))
        row = QHBoxLayout()
        row.addWidget(QLabel("Ledger type"))
        self.lt = QComboBox()
        for k, l in LEDGER_TYPES:
            self.lt.addItem(l, k)
        self.lt.setMinimumWidth(280)
        row.addWidget(self.lt)
        row.addWidget(button("Choose bank ledger file(s) and import...", self.upload_ledgers, "primary"))
        row.addStretch(1)
        al.addLayout(row)
        al.addWidget(label("Company books = the bank's GL ledger from your ERP, where receipts (R-...) are DEBITS. Bank statement = the bank's "
                           "own statement, where deposits are CREDITS. Auto-detect reads the running balance and tells you what it chose.",
                           "hint", True))
        self.lay.addWidget(a)
        b = QFrame()
        css(b, "kpi")
        bl = QVBoxLayout(b)
        bl.setContentsMargins(18, 14, 18, 14)
        bl.addWidget(label("B.  ERP reports for Revenue vs Collection", "h2"))
        row = QHBoxLayout()
        for kind, text in (("collection", "Cash collection report..."), ("tb", "Trial balance..."), ("vat", "VAT register..."),
                           ("deposit", "Security deposit register...")):
            row.addWidget(button(text, lambda k=kind: self.upload_erp(k)))
        row.addStretch(1)
        bl.addLayout(row)
        bl.addWidget(label("Cash collection = AD Cash Collection Report (Property, Excel).  Trial balance = Property Comparison (TB), Accrual, "
                           "Excel.  VAT = Register Reports, Tran Type Receipt, Show Vat + Show Property Name.  Deposits = same register, "
                           "Charge = secdep, Show Detail + Show Property Name.  VAT and deposit registers can be uploaded month by month.",
                           "hint", True))
        self.lay.addWidget(b)
        self.lay.addWidget(label("What has been uploaded", "h2"))
        self.table = make_table(["Type", "Detail", "Period / dates", "File", "Rows", "Uploaded"], [120, 230, 190, 360, 70, 150],
                                numeric=(4,), stretch=3)
        self.lay.addWidget(self.table, 1)
        bar = QHBoxLayout()
        bar.addWidget(button("Delete selected upload", self.delete, "danger"))
        bar.addWidget(label("Uploading the same period again replaces it, so there is no need to delete first.", "hint"))
        bar.addStretch(1)
        self.lay.addLayout(bar)

    def refresh(self):
        accs = {a["id"]: a for a in db.accounts(self.conn, self.c, active_only=False)}
        rows, ids = [], []
        for r in self.conn.execute("SELECT * FROM ledger_import ORDER BY id DESC"):
            if r["account_id"] in accs:
                rows.append(["Bank ledger", accs[r["account_id"]]["name"], f"{r['date_from']} to {r['date_to']}", r["filename"], r["n_rows"], r["imported_at"]])
                ids.append(f"led:{r['id']}")
        for u in reversed(recon.uploads(self.conn, self.c)):
            rows.append([KIND_TITLE.get(u["kind"], u["kind"]), "", f"{mlabel(u['period_from'])} to {mlabel(u['period_to'])}", u["filename"], u["n_rows"], u["uploaded_at"]])
            ids.append(f"erp:{u['id']}")
        fill_table(self.table, rows, ids=ids)

    def delete(self):
        ids = selected_ids(self.table)
        if not ids:
            QMessageBox.information(self, "Delete", "Select an upload in the list first.")
            return
        if QMessageBox.question(self, "Delete upload", "Remove this upload and the data it added?") != QMessageBox.StandardButton.Yes:
            return
        kind, ident = ids[0].split(":")
        if kind == "erp":
            ingest.delete_upload(self.conn, int(ident))
        else:
            r = self.conn.execute("SELECT * FROM ledger_import WHERE id=?", (int(ident),)).fetchone()
            self.conn.execute("DELETE FROM ledger_txn WHERE account_id=? AND source=? AND txn_date>=? AND txn_date<=? AND manual=0",
                              (r["account_id"], r["filename"], r["date_from"], r["date_to"]))
            self.conn.execute("DELETE FROM ledger_import WHERE id=?", (int(ident),))
            self.conn.commit()
        self.win.refresh_all()

    def upload_ledgers(self):
        accounts = db.accounts(self.conn, self.c)
        if not accounts:
            QMessageBox.warning(self, "No bank accounts", "Add the collection bank accounts for this country first (Setup tab).")
            self.win.show_page("set")
            return
        paths, _ = QFileDialog.getOpenFileNames(self, "Bank ledger file(s)", "", FILES)
        S = db.get_settings(self.conn, self.c)
        for path in paths:
            fname = os.path.basename(path)
            try:
                p = parsers.parse_ledger(path, self.lt.currentData(), S["date_format"])
            except ParseError as e:
                QMessageBox.critical(self, fname, str(e))
                continue
            except Exception as e:
                QMessageBox.critical(self, fname, f"Could not read this file:\n{e}")
                continue
            dlg = LedgerDialog(self, path, p, accounts)
            if not dlg.exec():
                continue
            msgs = []
            if p["has_account_col"]:
                groups = {}
                for r in p["rows"]:
                    groups.setdefault(r["account_text"], []).append(r)
                for text, rows in groups.items():
                    acc = ingest.match_account(accounts, text)
                    if not acc:
                        msgs.append(f"No bank account matches '{text}' - {len(rows)} rows skipped.")
                        continue
                    out = ingest.import_ledger(self.conn, self.c, acc["id"], dict(p, opening=None), fname, rows)
                    msgs.append(f"{acc['name']}: {out['rows']} rows ({out['unclassified']} unclassified).")
            else:
                out = ingest.import_ledger(self.conn, self.c, dlg.account_id, p, fname)
                an = next(a["name"] for a in accounts if a["id"] == dlg.account_id)
                msgs.append(f"{an}: {out['rows']} rows, {out['date_from']} to {out['date_to']} ({out['unclassified']} unclassified).")
                if out.get("opening_set"):
                    msgs.append(f"Opening balance set to {out['opening_set'][1]:,.2f} at {mlabel(out['opening_set'][0])}.")
                msgs += out["warnings"]
            QMessageBox.information(self, "Imported " + fname, "\n".join(msgs))
        if paths:
            self.win.refresh_all()

    def upload_erp(self, kind):
        path, _ = QFileDialog.getOpenFileName(self, KIND_TITLE[kind], "", FILES)
        if not path:
            return
        S = db.get_settings(self.conn, self.c)
        fname = os.path.basename(path)
        try:
            if kind == "collection":
                parsed = parsers.parse_collection(path)
            elif kind == "tb":
                parsed = parsers.parse_trial_balance(path)
            else:
                parsed = parsers.parse_register(path, kind, S["date_format"])
        except ParseError as e:
            QMessageBox.critical(self, fname, str(e))
            return
        except Exception as e:
            QMessageBox.critical(self, fname, f"Could not read this file:\n{e}")
            return
        lines = []
        if kind == "collection":
            lines.append(f"{len(parsed['properties'])} properties, months {mlabel(parsed['months'][0])} to {mlabel(parsed['months'][-1])}, "
                         f"total {sum(r['amount'] for r in parsed['rows']):,.2f}")
        elif kind == "tb":
            pref = tuple(x.strip() for x in S["revenue_gl_prefix"].split(",") if x.strip())
            rev = [r for r in parsed["rows"] if r["gl_code"].startswith(pref)]
            sign = -1 if S["tb_credit_is_negative"] == "1" else 1
            lines.append(f"{len(parsed['properties'])} property columns, {len({r['gl_code'] for r in rev})} revenue GL accounts, "
                         f"net revenue {sign * sum(r['amount'] for r in rev):,.2f}")
        elif kind == "vat":
            lines.append(f"{len(parsed['rows'])} lines, VAT {sum(r['vat'] for r in parsed['rows']):,.2f}")
        else:
            main = [r for r in parsed["rows"] if not r["is_detail"]]
            lines.append(f"{len(main)} lines, deposits {sum(r['amount'] for r in main):,.2f} (negative refund lines are ignored in the report)")
        ErpDialog(self, kind, fname, path, parsed, lines).exec()
        self.win.refresh_all()


# ====================================================================== 7. SETUP
class SetupPage(Page):
    def __init__(self, win):
        super().__init__(win)
        self.lay.addWidget(Banner("Setup", "Configuration",
                                  "Bank accounts (the matrix columns), property code mapping, report lines and settings - kept separately for each country."))
        self.tabs = QTabWidget()
        self.lay.addWidget(self.tabs, 1)
        self.acc = self._panel("Bank accounts", "One row per collection bank account (the columns of the cash flow report). Opening balance = "
                               "balance at the START of the opening month; it is filled from the first ledger you upload. After that each "
                               "month opens with the previous month's closing balance.",
                               ["Order", "GL code", "Bank / property name", "Account no.", "Currency", "Opening month", "Opening balance", "Active"],
                               [70, 120, 260, 200, 80, 120, 150, 70], self.add_account, self.edit_account, self.delete_account, (6,), 2)
        self.map = self._panel("Property code mapping", "Use when the same property has different codes in different reports, or one code must be "
                               "merged into another (e.g. 'parking' into 'ebp2'). Codes you do not list map to themselves. Codes are lower case.",
                               ["Code in the reports", "Report as code", "Name"], [220, 220, 360], self.add_map, self.edit_map, self.delete_map, (), 2)
        self.lines = self._panel("Report lines", "The rows of the cash flow statement. 'in' lines are receipts, 'out' lines are payments. Add a line "
                                 "(e.g. 'Transfer to/For Indonesia') then point a rule at it on the Rules tab. Hidden lines keep their history.",
                                 ["Order", "Key", "Label", "In / out", "Shown"], [80, 240, 420, 90, 80], self.add_line, self.edit_line, self.delete_line, (), 2)
        st = QWidget()
        sl = QVBoxLayout(st)
        sl.setContentsMargins(4, 14, 4, 4)
        self.set_lbl = QLabel()
        self.set_lbl.setTextFormat(Qt.TextFormat.RichText)
        sl.addWidget(self.set_lbl)
        row = QHBoxLayout()
        row.addWidget(button("Change settings...", self.edit_settings, "primary"))
        row.addWidget(button("Save a backup copy...", self.backup))
        row.addStretch(1)
        sl.addLayout(row)
        sl.addWidget(label(f"Your data is one file: {db.ROOT / 'data' / 'propflow.db'}  -  copy it to keep a backup; replacing it with a "
                           "copy restores that backup.", "hint", True))
        sl.addStretch(1)
        self.tabs.addTab(st, "Settings && backup")

    def _panel(self, title, note, cols, widths, add, edit, delete, numeric, stretch):
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(4, 12, 4, 4)
        lay.addWidget(label(note, "hint", True))
        t = make_table(cols, widths, numeric=numeric, stretch=stretch)
        t.cellDoubleClicked.connect(lambda *_: edit())
        lay.addWidget(t, 1)
        bar = QHBoxLayout()
        bar.addWidget(button("Add...", add, "primary"))
        bar.addWidget(button("Edit...", edit))
        bar.addWidget(button("Delete / hide", delete, "danger"))
        bar.addStretch(1)
        lay.addLayout(bar)
        self.tabs.addTab(w, title)
        return t

    def refresh(self):
        accs = db.accounts(self.conn, self.c, active_only=False)
        fill_table(self.acc, [[a["sort"], a["gl_code"] or "", a["name"], a["account_no"] or "", a["currency"] or "", a["opening_month"] or "",
                               fmt(a["opening_balance"]) if a["opening_balance"] is not None else "", "yes" if a["active"] else "no"] for a in accs],
                   ids=[a["id"] for a in accs])
        maps = [dict(r) for r in self.conn.execute("SELECT * FROM property_map WHERE country=? ORDER BY source_code", (self.c,))]
        fill_table(self.map, [[m["source_code"], m["group_code"], m["group_name"] or ""] for m in maps], ids=[m["source_code"] for m in maps])
        cats = [dict(r) for r in self.conn.execute("SELECT * FROM categories WHERE country=? ORDER BY sort, key", (self.c,))]
        fill_table(self.lines, [[r["sort"], r["key"], r["label"], r["section"], "yes" if r["active"] else "hidden"] for r in cats], ids=[r["key"] for r in cats])
        S = db.get_settings(self.conn, self.c)
        yn = lambda v: "yes" if str(v) == "1" else "no"  # noqa: E731
        rows = [("Revenue GL accounts start with", S["revenue_gl_prefix"]),
                ("Revenue shows as negative in the trial balance", yn(S["tb_credit_is_negative"])),
                ("'Reconciled' when the difference is below", S["balanced_tolerance"]),
                ("VAT / deposit lines matched to the period by", "posting month" if S["cutoff_basis"] == "period" else "receipt date"),
                ("Dates written as text are", "month/day/year" if S["date_format"] == "mdy" else "day/month/year"),
                ("Security deposit charge codes", S["deposit_charge_codes"]),
                ("...or deposit account codes starting with", S["deposit_account_prefixes"]),
                ("Negative deposit lines (refunds) ignored", yn(S.get("deposit_ignore_negative", "1"))),
                ("Include register sub-lines without a property", yn(S["include_detail_lines"]))]
        html = f"<div style='font-size:12pt;color:#C2410C;font-weight:800'>Settings for {self.c}</div><table cellpadding=5>"
        html += "".join(f"<tr><td style='color:{MUTED}'>{k}</td><td><b>{v}</b></td></tr>" for k, v in rows) + "</table>"
        self.set_lbl.setText(html)

    # ---- bank accounts
    def acc_fields(self):
        return [dict(key="sort", label="Order in report"), dict(key="gl_code", label="GL code"), dict(key="name", label="Bank / property name"),
                dict(key="account_no", label="Account number"), dict(key="currency", label="Currency"),
                dict(key="opening_month", label="Opening month (YYYY-MM)"),
                dict(key="opening_balance", label="Opening balance at start of that month"), dict(key="active", label="Active", kind="check")]

    @staticmethod
    def acc_validate(v):
        om = v["opening_month"]
        if not v["name"]:
            return "Enter a name."
        if om and not (len(om) == 7 and om[4] == "-" and om[:4].isdigit() and om[5:].isdigit()):
            return "Opening month must look like 2026-01."
        try:
            if v["opening_balance"]:
                float(str(v["opening_balance"]).replace(",", ""))
        except ValueError:
            return "Opening balance must be a number."
        if v["sort"] and not str(v["sort"]).lstrip("-").isdigit():
            return "Order must be a whole number."
        return None

    def save_account(self, v, aid=None):
        ob = float(str(v["opening_balance"]).replace(",", "")) if v["opening_balance"] != "" else None
        om = v["opening_month"] or (month_keys()[0] if ob is not None else None)
        vals = (int(v["sort"] or 0), v["gl_code"] or None, v["name"], v["account_no"] or None, v["currency"] or db.CURRENCY[self.c], om, ob, v["active"])
        if aid is None:
            self.conn.execute("INSERT INTO bank_accounts(country,sort,gl_code,name,account_no,currency,opening_month,opening_balance,active) "
                              "VALUES (?,?,?,?,?,?,?,?,?)", (self.c,) + vals)
        else:
            self.conn.execute("UPDATE bank_accounts SET sort=?,gl_code=?,name=?,account_no=?,currency=?,opening_month=?,opening_balance=?,active=? WHERE id=?",
                              vals + (aid,))
        self.conn.commit()
        self.win.refresh_all()

    def add_account(self):
        n = len(db.accounts(self.conn, self.c, active_only=False)) + 1
        v = FormDialog(self, "Add bank account", self.acc_fields(), dict(sort=n, currency=db.CURRENCY[self.c], active=1), self.acc_validate).get()
        if v:
            self.save_account(v)

    def edit_account(self):
        ids = selected_ids(self.acc)
        if not ids:
            return
        a = dict(self.conn.execute("SELECT * FROM bank_accounts WHERE id=?", (ids[0],)).fetchone())
        a["opening_balance"] = "" if a["opening_balance"] is None else a["opening_balance"]
        v = FormDialog(self, "Edit bank account", self.acc_fields(), a, self.acc_validate).get()
        if v:
            self.save_account(v, ids[0])

    def delete_account(self):
        ids = selected_ids(self.acc)
        if not ids:
            return
        n = self.conn.execute("SELECT COUNT(*) FROM ledger_txn WHERE account_id=?", (ids[0],)).fetchone()[0]
        yes = QMessageBox.StandardButton.Yes
        if n:
            if QMessageBox.question(self, "Hide account", f"This account has {n} transactions, so it will be hidden (not deleted). Hide it?") == yes:
                self.conn.execute("UPDATE bank_accounts SET active=0 WHERE id=?", (ids[0],))
        elif QMessageBox.question(self, "Delete account", "Delete this bank account?") == yes:
            self.conn.execute("DELETE FROM bank_accounts WHERE id=?", (ids[0],))
        self.conn.commit()
        self.win.refresh_all()

    # ---- property mapping
    def map_fields(self):
        return [dict(key="source_code", label="Code in the reports"), dict(key="group_code", label="Report as code"), dict(key="group_name", label="Name (optional)")]

    @staticmethod
    def map_validate(v):
        return None if v["source_code"] and v["group_code"] else "Enter both codes."

    def save_map(self, v, old=None):
        if old:
            self.conn.execute("DELETE FROM property_map WHERE country=? AND source_code=?", (self.c, old))
        self.conn.execute("INSERT OR REPLACE INTO property_map VALUES (?,?,?,?)",
                          (self.c, v["source_code"].lower(), v["group_code"].lower(), v["group_name"] or None))
        self.conn.commit()
        self.win.refresh_all()

    def add_map(self):
        v = FormDialog(self, "Add mapping", self.map_fields(), None, self.map_validate).get()
        if v:
            self.save_map(v)

    def edit_map(self):
        ids = selected_ids(self.map)
        if not ids:
            return
        r = dict(self.conn.execute("SELECT * FROM property_map WHERE country=? AND source_code=?", (self.c, ids[0])).fetchone())
        v = FormDialog(self, "Edit mapping", self.map_fields(), r, self.map_validate).get()
        if v:
            self.save_map(v, ids[0])

    def delete_map(self):
        ids = selected_ids(self.map)
        if ids:
            self.conn.execute("DELETE FROM property_map WHERE country=? AND source_code=?", (self.c, ids[0]))
            self.conn.commit()
            self.win.refresh_all()

    # ---- report lines
    def line_fields(self):
        return [dict(key="sort", label="Order"), dict(key="key", label="Key (no spaces)"), dict(key="label", label="Label shown in the report"),
                dict(key="section", label="Section", kind="combo", options=[("in", "in  (receipt)"), ("out", "out  (payment)")]),
                dict(key="active", label="Shown", kind="check")]

    @staticmethod
    def line_validate(v):
        if not v["key"] or not v["label"]:
            return "Enter a key and a label."
        if not str(v["sort"]).lstrip("-").isdigit():
            return "Order must be a whole number."
        return None

    def save_line(self, v, old=None):
        key = v["key"].lower().replace(" ", "_")
        if old and old != key:
            self.conn.execute("DELETE FROM categories WHERE country=? AND key=?", (self.c, old))
            self.conn.execute("UPDATE rules SET category=? WHERE country=? AND category=?", (key, self.c, old))
            self.conn.execute("UPDATE ledger_txn SET category=? WHERE category=? AND account_id IN (SELECT id FROM bank_accounts WHERE country=?)",
                              (key, old, self.c))
        self.conn.execute("INSERT OR REPLACE INTO categories(country,key,label,section,sort,active) VALUES (?,?,?,?,?,?)",
                          (self.c, key, v["label"], v["section"], int(v["sort"]), v["active"]))
        self.conn.commit()
        self.win.refresh_all()

    def add_line(self):
        v = FormDialog(self, "Add report line", self.line_fields(), dict(sort=500, section="out", active=1), self.line_validate).get()
        if v:
            self.save_line(v)

    def edit_line(self):
        ids = selected_ids(self.lines)
        if not ids:
            return
        r = dict(self.conn.execute("SELECT * FROM categories WHERE country=? AND key=?", (self.c, ids[0])).fetchone())
        v = FormDialog(self, "Edit report line", self.line_fields(), r, self.line_validate).get()
        if v:
            self.save_line(v, ids[0])

    def delete_line(self):
        ids = selected_ids(self.lines)
        if ids and QMessageBox.question(self, "Hide line", "Hide this line from the reports? (its history is kept)") == QMessageBox.StandardButton.Yes:
            self.conn.execute("UPDATE categories SET active=0 WHERE country=? AND key=?", (self.c, ids[0]))
            self.conn.commit()
            self.win.refresh_all()

    # ---- settings / backup
    def edit_settings(self):
        S = db.get_settings(self.conn, self.c)
        fields = [dict(key="revenue_gl_prefix", label="Revenue GL accounts start with"),
                  dict(key="tb_credit_is_negative", label="Revenue shows as negative in the trial balance", kind="check"),
                  dict(key="balanced_tolerance", label="'Reconciled' when difference is below"),
                  dict(key="cutoff_basis", label="Match VAT / deposit lines to the period by", kind="combo",
                       options=[("period", "posting month"), ("date", "receipt date")]),
                  dict(key="date_format", label="Dates written as text are", kind="combo",
                       options=[("mdy", "month/day/year (10/31/2026)"), ("dmy", "day/month/year (31/10/2026)")]),
                  dict(key="deposit_charge_codes", label="Security deposit charge codes"),
                  dict(key="deposit_account_prefixes", label="...or account codes starting with"),
                  dict(key="deposit_ignore_negative", label="Ignore negative deposit lines (refunds)", kind="check"),
                  dict(key="include_detail_lines", label="Include register sub-lines without a property", kind="check")]

        def validate(v):
            try:
                float(v["balanced_tolerance"])
            except ValueError:
                return "The tolerance must be a number."
            return None

        v = FormDialog(self, f"Settings - {self.c}", fields, S, validate).get()
        if v:
            for k, val in v.items():
                db.set_setting(self.conn, self.c, k, val)
            self.win.refresh_all()

    def backup(self):
        src = Path(os.environ["PROPFLOW_DB"]) if os.environ.get("PROPFLOW_DB") else db.ROOT / "data" / "propflow.db"
        dest, _ = QFileDialog.getSaveFileName(self, "Save a backup copy", f"propflow_backup_{date.today():%Y%m%d}.db", "Database (*.db)")
        if dest:
            self.conn.commit()
            shutil.copyfile(src, dest)
            QMessageBox.information(self, "Backup", f"Backup saved to:\n{dest}")


# ====================================================================== dialogs
class LedgerDialog(QDialog):
    def __init__(self, parent, path, p, accounts):
        super().__init__(parent)
        self.setWindowTitle("Import bank ledger - " + os.path.basename(path))
        self.resize(1020, 640)
        self.account_id = None
        self.p = p
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 22, 16)
        lay.addWidget(label(os.path.basename(path), "h2"))
        rows = p["rows"]
        self.combo = None
        if p["has_account_col"]:
            lay.addWidget(label("This file has a bank / account column - rows are split between your bank accounts automatically.", "hint"))
        else:
            row = QHBoxLayout()
            row.addWidget(QLabel("Bank account for this file"))
            self.combo = QComboBox()
            guess = ingest.match_account(accounts, Path(path).stem)
            for a in accounts:
                self.combo.addItem(f"{a['gl_code'] or ''}  {a['name']}".strip(), a["id"])
            if guess:
                self.combo.setCurrentIndex(self.combo.findData(guess["id"]))
            self.combo.setMinimumWidth(360)
            row.addWidget(self.combo)
            row.addStretch(1)
            lay.addLayout(row)
        tin, tout = sum(x["money_in"] for x in rows), sum(x["money_out"] for x in rows)
        o, c = p["opening"], p["closing_in_file"]
        lay.addWidget(label(
            f"<b>{len(rows)}</b> rows, {min(x['date'] for x in rows)} to {max(x['date'] for x in rows)} &nbsp;&nbsp; Money in <b>{tin:,.2f}</b> "
            f"&nbsp;&nbsp; Money out <b>{tout:,.2f}</b><br>Opening balance in file: <b>{'-' if o is None else format(o, ',.2f')}</b> &nbsp;&nbsp; "
            f"Closing balance in file: <b>{'-' if c is None else format(c, ',.2f')}</b><br>Treated as: <b>{dict(LEDGER_TYPES)[p['ledger_type']]}</b>"
            + (f" - {p['reason']}" if p["reason"] else ""), wrap=True))
        for w in p["warnings"]:
            l = QLabel("&#9888; " + w)
            l.setStyleSheet(f"color:{WARN}")
            l.setWordWrap(True)
            lay.addWidget(l)
        t = make_table(["Date", "Reference", "Description", "Debit", "Credit", "Balance", "Money in", "Money out"],
                       [95, 120, 300, 110, 110, 120, 110, 110], numeric=(3, 4, 5, 6, 7), stretch=2)
        fill_table(t, [[x["date"], x["reference"], x["description"], fmt(x["debit"]), fmt(x["credit"]), fmt(x["balance"]), fmt(x["money_in"]),
                        fmt(x["money_out"])] for x in rows[:12]])
        lay.addWidget(t, 1)
        bar = QHBoxLayout()
        bar.addStretch(1)
        bar.addWidget(button("Skip this file", self.reject))
        bar.addWidget(button("Import", self.ok, "primary"))
        lay.addLayout(bar)

    def ok(self):
        self.account_id = None if self.combo is None else self.combo.currentData()
        self.accept()


class ErpDialog(QDialog):
    def __init__(self, parent, kind, fname, path, parsed, lines):
        super().__init__(parent)
        self.setWindowTitle(f"Import {KIND_TITLE[kind]} - {fname}")
        self.setMinimumWidth(640)
        self.kind, self.fname, self.path, self.parsed, self.page = kind, fname, path, parsed, parent
        lay = QVBoxLayout(self)
        lay.setContentsMargins(22, 18, 22, 16)
        lay.addWidget(label(fname, "h2"))
        for ln in lines:
            lay.addWidget(label(ln, wrap=True))
        for w in parsed["warnings"]:
            l = QLabel("&#9888; " + w)
            l.setStyleSheet(f"color:{WARN}")
            l.setWordWrap(True)
            lay.addWidget(l)
        labels = list(MONTH_LABELS.values())
        today = date.today()
        last = f"{today.year}-{today.month - 1:02d}" if today.month > 1 else f"{today.year - 1}-12"
        row = QHBoxLayout()
        self.year = QComboBox()
        self.cf, self.ct = QComboBox(), QComboBox()
        if kind == "collection":
            row.addWidget(QLabel("Year (only if the report does not show it)"))
            self.year.addItems(["Auto"] + [str(y) for y in range(2023, 2029)])
            row.addWidget(self.year)
        else:
            row.addWidget(QLabel("Period this file covers:  From"))
            self.cf.addItems(labels)
            self.ct.addItems(labels)
            self.cf.setCurrentText(MONTH_LABELS[f"{last[:4]}-01"])
            self.ct.setCurrentText(MONTH_LABELS[last])
            row.addWidget(self.cf)
            row.addWidget(QLabel("To"))
            row.addWidget(self.ct)
        row.addStretch(1)
        lay.addLayout(row)
        if kind == "tb":
            lay.addWidget(label("Set this to the period of the trial balance (for example Jan to Sep). Revenue vs Collection matches it to the "
                                "collection period.", "hint", True))
        self.err = QLabel("")
        self.err.setStyleSheet(f"color:{BAD}")
        lay.addWidget(self.err)
        bar = QHBoxLayout()
        bar.addStretch(1)
        bar.addWidget(button("Cancel", self.reject))
        bar.addWidget(button("Import", self.ok, "primary"))
        lay.addLayout(bar)

    def ok(self):
        conn, c = self.page.conn, self.page.c
        try:
            if self.kind == "collection":
                parsed = self.parsed
                if self.year.currentText() != "Auto":
                    parsed = parsers.parse_collection(self.path, int(self.year.currentText()))
                ingest.import_collection(conn, c, parsed, self.fname)
            else:
                p_from, p_to = LABEL_TO_MONTH[self.cf.currentText()], LABEL_TO_MONTH[self.ct.currentText()]
                if p_from > p_to:
                    self.err.setText("'From' month is after 'To' month.")
                    return
                if self.kind == "tb":
                    ingest.import_trial_balance(conn, c, self.parsed, self.fname, p_from, p_to)
                else:
                    ingest.import_register(conn, c, self.kind, self.parsed, self.fname, p_from, p_to)
        except ParseError as e:
            self.err.setText(str(e))
            return
        self.accept()


class TxnDialog(QDialog):
    def __init__(self, parent, title, txs):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.resize(1050, 520)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 14)
        lay.addWidget(label(title, "h2"))
        t = make_table(["Date", "Bank", "Reference", "Description", "Money in", "Money out", "Balance"], [95, 170, 130, 380, 120, 120, 130],
                       numeric=(4, 5, 6), stretch=3)
        fill_table(t, [[x["txn_date"], x["bank"], x["reference"], x["description"], fmt(x["money_in"]), fmt(x["money_out"]), fmt(x["balance"])] for x in txs])
        lay.addWidget(t, 1)
        lay.addWidget(label(f"{len(txs)} transaction(s)     in {sum(x['money_in'] for x in txs):,.2f}     out {sum(x['money_out'] for x in txs):,.2f}", "hint"))


class PropertyDialog(QDialog):
    def __init__(self, parent, res, code):
        super().__init__(parent)
        self.setWindowTitle(f"{code} - {res['names'].get(code, code)}")
        self.resize(1000, 560)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(20, 16, 20, 14)
        lay.addWidget(label(f"{res['names'].get(code, code)}  ({code})", "h2"))
        tabs = QTabWidget()
        lay.addWidget(tabs, 1)

        def tab(title, cols, widths, numeric, rows, stretch=None):
            t = make_table(cols, widths, numeric=numeric, stretch=stretch)
            fill_table(t, rows)
            tabs.addTab(t, title)

        gl = {}
        for d in res["tb_detail"]:
            if d["g"] == code:
                k = (d["gl_code"], d["gl_desc"])
                gl[k] = gl.get(k, 0.0) + d["revenue"]
        tab("Revenue by GL", ["GL code", "Description", "Revenue (discounts negative)"], [120, 460, 220], (2,),
            [[k[0], k[1], fmt(v)] for k, v in sorted(gl.items())] + [["", "Total", fmt(sum(gl.values()))]], stretch=1)
        tab("VAT lines", ["Date", "Period", "Tenant", "Control", "Net", "VAT", "Gross"], [95, 90, 320, 110, 120, 110, 120], (4, 5, 6),
            [[d["txn_date"], d["period"], d["tenant"], d["control"], fmt(d["net"]), fmt(d["vat"]), fmt(d["gross"])] for d in res["vat_detail"] if d["g"] == code], stretch=2)
        tab("Security deposit lines", ["Date", "Period", "Tenant", "Control", "Charge", "Amount"], [95, 90, 320, 110, 110, 130], (5,),
            [[d["txn_date"], d["period"], d["tenant"], d["control"], d["charge_code"], fmt(d["amount"])] for d in res["dep_detail"] if d["g"] == code], stretch=2)
        bm = res["collection_by_month"].get(code, {})
        tab("Collection by month", ["Month", "Collection"], [140, 180], (1,),
            [[mlabel(m), fmt(v)] for m, v in sorted(bm.items())] + [["Total", fmt(sum(bm.values()))]])


# ====================================================================== main window
NAV = [("sum", "Summary Sheet (Multi-Month)", SummaryPage), ("cf", "Bank Accounts Matrix", MatrixPage),
       ("rc", "Revenue vs Collection", ReconPage), ("txn", "Transactions", TxnPage), ("rules", "Rules", RulesPage),
       ("up", "Upload", UploadPage), ("set", "Setup", SetupPage)]


class MainWindow(QMainWindow):
    def __init__(self, db_path=None):
        super().__init__()
        self.setWindowTitle("PropFlow - cash flow & revenue reconciliation")
        self.resize(1440, 900)
        self.conn = db.connect(db_path)
        self.country = "UAE"
        root = QWidget()
        self.setCentralWidget(root)
        v = QVBoxLayout(root)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(0)
        header = QFrame()
        header.setObjectName("header")
        hl = QHBoxLayout(header)
        hl.setContentsMargins(24, 12, 24, 12)
        logo = QLabel("PropFlow")
        logo.setObjectName("logo")
        hl.addWidget(logo)
        hl.addSpacing(26)
        pill_bg = QFrame()
        pill_bg.setObjectName("pillbg")
        pill_bg.setStyleSheet("QFrame#pillbg { background: rgba(255,255,255,0.22); border-radius: 17px; }")
        pl = QHBoxLayout(pill_bg)
        pl.setContentsMargins(3, 3, 3, 3)
        pl.setSpacing(2)
        self.cgroup = QButtonGroup(self)
        for i, code in enumerate(db.COUNTRIES):
            b = css(QPushButton(f"{code}  ({db.CURRENCY[code]})"), "pill")
            b.setCheckable(True)
            b.setChecked(i == 0)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, c=code: self.set_country(c))
            self.cgroup.addButton(b)
            pl.addWidget(b)
        hl.addWidget(pill_bg)
        hl.addStretch(1)
        tag = QLabel("Offline  ·  your data stays on this computer")
        tag.setObjectName("tag")
        hl.addWidget(tag)
        v.addWidget(header)
        nav = QFrame()
        nav.setObjectName("nav")
        nl = QHBoxLayout(nav)
        nl.setContentsMargins(16, 0, 16, 0)
        nl.setSpacing(2)
        self.stack = QStackedWidget()
        self.pages, self.navbtns = {}, {}
        self.ngroup = QButtonGroup(self)
        for key, title, cls in NAV:
            b = css(QPushButton(title), "navbtn")
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.clicked.connect(lambda _=False, k=key: self.show_page(k))
            self.ngroup.addButton(b)
            nl.addWidget(b)
            self.navbtns[key] = b
            page = cls(self)
            self.pages[key] = page
            self.stack.addWidget(page)
        nl.addStretch(1)
        v.addWidget(nav)
        v.addWidget(self.stack, 1)
        self.show_page("sum")

    def set_country(self, code):
        self.country = code
        self.refresh_all()

    def show_page(self, key):
        self.navbtns[key].setChecked(True)
        self.stack.setCurrentWidget(self.pages[key])
        self.pages[key].refresh()

    def refresh_all(self):
        for p in self.pages.values():
            p.refresh()


def main():
    app = QApplication(sys.argv)
    app.setStyleSheet(QSS)
    f = QFont("Segoe UI", 10)
    app.setFont(f)
    win = MainWindow()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
