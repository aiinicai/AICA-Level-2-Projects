"""Default categories, classification rules and settings.

Everything here is only a starting point. Categories, rules and settings are copied
into the local database on first run and can be edited in the app (Setup / Rules tabs).
"""

# key, label, section ('in' = receipts / inflows, 'out' = payments / outflows), sort order
# Labels follow the user's "Cash flow Statement" template.
DEFAULT_CATEGORIES = [
    ("rent_collection", "Rent Collection", "in", 10),
    ("other_fees", "Other fees", "in", 20),
    ("bank_interest", "Bank interest", "in", 30),
    ("transfer_marina_in", "Transfer from Marina View account", "in", 40),
    ("family_loan", "Family Loan settlement", "in", 50),
    ("interbank_receipt_owner", "Interbank transfer (receipt-Owner)", "in", 60),
    ("interbank_receipt_intra", "Interbank transfers (Receipt - intra)", "in", 70),
    ("vendor_payments", "Vendor Payments", "out", 110),
    ("project_payments", "Project payments", "out", 120),
    ("utility_payments", "Utility payments", "out", 130),
    ("salary_payments", "Salary Payments & Final settlement", "out", 140),
    ("bonus_payments", "Bonus", "out", 150),
    ("bank_charges", "Bank Charges", "out", 160),
    ("tenant_refund", "Tenant Refund", "out", 170),
    ("vat_payments", "VAT Payments", "out", 180),
    ("petty_cash", "Petty Cash Payment", "out", 190),
    ("transfer_marina_out", "Transfer to Marina View account", "out", 200),
    ("owner_expenses", "Owner's withdrawal/expenses", "out", 210),
    ("transfer_ksa", "Transfer to KSA bank accounts", "out", 220),
    ("transfer_cenova", "Transfer to CENOVA Properties", "out", 230),
    ("other_payments", "Other Payments", "out", 240),
    ("interbank_owner_withdrawal", "Interbank transfers (Owner withdrawal)", "out", 250),
    ("interbank_to_salary", "Interbank transfers (to salary account)", "out", 260),
    ("interbank_to_vendor", "Interbank transfers (To vendor payment ac)", "out", 270),
    ("interbank_payments", "Interbank transfers (Payments)", "out", 280),
]

# Categories that are internal movements between the group's own bank accounts.
# Across ALL accounts of one country these should net to roughly zero; the app checks that.
INTERBANK_KEYS = [
    "interbank_receipt_owner", "interbank_receipt_intra", "interbank_owner_withdrawal",
    "interbank_to_salary", "interbank_to_vendor", "interbank_payments",
]

# Rules are evaluated in priority order (lowest number first); first match wins.
# direction: 'in' = money into the bank, 'out' = money out, 'any'.
# field: 'reference' | 'description' | 'both'.  match: 'startswith' | 'contains' | 'regex'.
# pattern: for startswith/contains, alternatives separated by |  (case-insensitive).
DEFAULT_RULES = [
    # name, priority, field, match, pattern, direction, category
    ("Receipts R- (money in)", 10, "reference", "startswith", "R-", "in", "rent_collection"),
    # A payment against an R- reference is a bounced / reversed receipt: it REDUCES rent collection.
    ("Receipt reversals R- (money out)", 11, "reference", "startswith", "R-", "out", "rent_collection"),
    ("Bank charges", 20, "description", "contains",
     "bank charge|bank fee|service charge|commission|swift charge|chq return|cheque return|stop payment|"
     "account maintenance|telegraphic|vat on charge", "out", "bank_charges"),
    ("Bank interest", 25, "description", "contains", "interest|profit paid|profit credit", "in", "bank_interest"),
    ("VAT payment to authority", 30, "description", "contains", "fta|federal tax|vat payment|vat return|zatca|zakat", "out", "vat_payments"),
    ("Interbank to salary account", 40, "description", "contains", "salary account|to salary|payroll account|wps transfer", "out", "interbank_to_salary"),
    ("Interbank to vendor payment account", 41, "description", "contains", "vendor payment ac|to vendor|vendor account|payment account", "out", "interbank_to_vendor"),
    ("Interbank owner withdrawal", 42, "description", "contains", "owner withdrawal|owner's withdrawal", "out", "interbank_owner_withdrawal"),
    ("Interbank receipt (owner)", 43, "description", "contains", "from owner|owner transfer|owner deposit", "in", "interbank_receipt_owner"),
    ("Interbank receipt (intra)", 50, "description", "contains",
     "interbank|inter bank|internal transfer|ibt|fund transfer from|transfer from|trf from", "in", "interbank_receipt_intra"),
    ("Interbank payment (other)", 51, "description", "contains",
     "interbank|inter bank|internal transfer|ibt|fund transfer to|transfer to|trf to", "out", "interbank_payments"),
    ("Tenant refunds", 60, "description", "contains", "tenant refund|deposit refund|refund", "out", "tenant_refund"),
    ("Salaries", 70, "description", "contains", "salary|payroll|final settlement|end of service", "out", "salary_payments"),
    ("Utilities", 71, "description", "contains", "dewa|sewa|addc|empower|etisalat|du telecom|utility", "out", "utility_payments"),
    ("Petty cash", 80, "description", "contains", "petty cash", "out", "petty_cash"),
]

DEFAULT_SETTINGS = {
    "revenue_gl_prefix": "4",            # GL accounts beginning with this are revenue (comma separate for several)
    "tb_credit_is_negative": "1",        # 1 = credits (revenue) appear negative in the trial balance export
    "deposit_charge_codes": "secdep",    # charge codes counted as security deposits (comma separated)
    "deposit_account_prefixes": "2115",  # OR account codes starting with these
    "cutoff_basis": "period",            # 'period' = posting month (default), 'date' = receipt Date
    "date_format": "mdy",                # 'mdy' (10/31/2026) or 'dmy' (31/10/2026) for text dates
    "deposit_ignore_negative": "1",      # 1 = negative deposit lines are refunds, not deposits received: ignore
    "include_detail_lines": "0",         # 1 = also add register sub-lines that have no property
    "balanced_tolerance": "100",         # |difference| below this is shown as Reconciled
}
