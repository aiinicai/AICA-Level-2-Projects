"""SQLite storage. One local file: data/propflow.db (back it up by copying it)."""
import os
import sqlite3
from pathlib import Path

from . import defaults

ROOT = Path(__file__).resolve().parent.parent
COUNTRIES = ["UAE", "KSA"]
CURRENCY = {"UAE": "AED", "KSA": "SAR"}

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (country TEXT, key TEXT, value TEXT, PRIMARY KEY (country, key));

CREATE TABLE IF NOT EXISTS categories (
    country TEXT, key TEXT, label TEXT, section TEXT, sort INTEGER, active INTEGER DEFAULT 1,
    PRIMARY KEY (country, key));

CREATE TABLE IF NOT EXISTS rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, name TEXT, priority INTEGER,
    field TEXT, match TEXT, pattern TEXT, direction TEXT, category TEXT, active INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS bank_accounts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT NOT NULL, gl_code TEXT, name TEXT NOT NULL,
    account_no TEXT, currency TEXT, sort INTEGER DEFAULT 0,
    opening_month TEXT, opening_balance REAL, active INTEGER DEFAULT 1);

CREATE TABLE IF NOT EXISTS ledger_txn (
    id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER NOT NULL, txn_date TEXT, month TEXT,
    reference TEXT, description TEXT, debit REAL, credit REAL, balance REAL,
    money_in REAL DEFAULT 0, money_out REAL DEFAULT 0,
    category TEXT, manual INTEGER DEFAULT 0, source TEXT,
    FOREIGN KEY (account_id) REFERENCES bank_accounts(id));
CREATE INDEX IF NOT EXISTS ix_txn_acc_month ON ledger_txn(account_id, month);

CREATE TABLE IF NOT EXISTS ledger_import (
    id INTEGER PRIMARY KEY AUTOINCREMENT, account_id INTEGER, filename TEXT, imported_at TEXT,
    date_from TEXT, date_to TEXT, n_rows INTEGER, ledger_type TEXT, closing_in_file REAL);

CREATE TABLE IF NOT EXISTS erp_upload (
    id INTEGER PRIMARY KEY AUTOINCREMENT, country TEXT, kind TEXT, period_from TEXT, period_to TEXT,
    filename TEXT, uploaded_at TEXT, n_rows INTEGER, note TEXT);

CREATE TABLE IF NOT EXISTS collection_row (
    upload_id INTEGER, entity TEXT, property_code TEXT, property_name TEXT, currency TEXT,
    month TEXT, amount REAL);

CREATE TABLE IF NOT EXISTS tb_row (
    upload_id INTEGER, gl_code TEXT, gl_desc TEXT, property_code TEXT, amount REAL);

CREATE TABLE IF NOT EXISTS vat_row (
    upload_id INTEGER, row_key TEXT, doc_no TEXT, period TEXT, txn_date TEXT, tenant TEXT, control TEXT,
    property_code TEXT, property_name TEXT, net REAL, vat REAL, gross REAL, method TEXT);

CREATE TABLE IF NOT EXISTS deposit_row (
    upload_id INTEGER, row_key TEXT, doc_no TEXT, period TEXT, txn_date TEXT, tenant TEXT, control TEXT,
    property_code TEXT, property_name TEXT, acct_code TEXT, charge_code TEXT, amount REAL, method TEXT,
    is_detail INTEGER DEFAULT 0);

CREATE TABLE IF NOT EXISTS property_map (
    country TEXT, source_code TEXT, group_code TEXT, group_name TEXT, PRIMARY KEY (country, source_code));
"""


def connect(path=None):
    """Open the database (created on first use). Pass a path for tests."""
    if path is None:
        path = os.environ.get("PROPFLOW_DB") or (ROOT / "data" / "propflow.db")
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript(SCHEMA)
    seed(conn)
    return conn


def seed(conn):
    """Copy default categories / rules / settings for each country the first time only."""
    for country in COUNTRIES:
        if not conn.execute("SELECT 1 FROM categories WHERE country=? LIMIT 1", (country,)).fetchone():
            conn.executemany(
                "INSERT INTO categories(country,key,label,section,sort) VALUES (?,?,?,?,?)",
                [(country, k, l, s, o) for k, l, s, o in defaults.DEFAULT_CATEGORIES])
        if not conn.execute("SELECT 1 FROM rules WHERE country=? LIMIT 1", (country,)).fetchone():
            conn.executemany(
                "INSERT INTO rules(country,name,priority,field,match,pattern,direction,category) VALUES (?,?,?,?,?,?,?,?)",
                [(country,) + r for r in defaults.DEFAULT_RULES])
        for k, v in defaults.DEFAULT_SETTINGS.items():
            conn.execute("INSERT OR IGNORE INTO settings(country,key,value) VALUES (?,?,?)", (country, k, v))
    conn.commit()


def get_settings(conn, country):
    s = dict(defaults.DEFAULT_SETTINGS)
    for r in conn.execute("SELECT key,value FROM settings WHERE country=?", (country,)):
        s[r["key"]] = r["value"]
    return s


def set_setting(conn, country, key, value):
    conn.execute("INSERT OR REPLACE INTO settings(country,key,value) VALUES (?,?,?)", (country, key, str(value)))
    conn.commit()


def accounts(conn, country, active_only=True):
    q = "SELECT * FROM bank_accounts WHERE country=?" + (" AND active=1" if active_only else "") + " ORDER BY sort, gl_code, id"
    return [dict(r) for r in conn.execute(q, (country,))]


def categories(conn, country):
    return [dict(r) for r in conn.execute(
        "SELECT * FROM categories WHERE country=? AND active=1 ORDER BY sort, key", (country,))]


def rules(conn, country):
    return [dict(r) for r in conn.execute(
        "SELECT * FROM rules WHERE country=? AND active=1 ORDER BY priority, id", (country,))]
