"""Bank cash-flow reports: month matrix (banks as columns) and multi-month summary. Pure Python."""
from __future__ import annotations

import calendar

from . import db

INTRA_IN = ["interbank_receipt_intra"]
INTRA_OUT = ["interbank_to_salary", "interbank_to_vendor", "interbank_payments"]


def month_label(m):
    y, mm = m.split("-")
    return f"{calendar.month_abbr[int(mm)]}-{y[2:]}"


def months_available(conn, country):
    ids = [a["id"] for a in db.accounts(conn, country)]
    if not ids:
        return []
    q = ",".join("?" * len(ids))
    return [r[0] for r in conn.execute(
        f"SELECT DISTINCT month FROM ledger_txn WHERE account_id IN ({q}) AND month IS NOT NULL ORDER BY month", ids)]


def opening_for(conn, acc, month):
    """Opening balance of an account at the start of `month`: seed + all movements since the seed month."""
    seed_m, seed = acc.get("opening_month"), acc.get("opening_balance")
    if seed is None or not seed_m:
        return 0.0, "no opening balance set"
    if month <= seed_m:
        note = "" if month == seed_m else f"before the seed month {seed_m}"
        return float(seed), note
    net = conn.execute("SELECT COALESCE(SUM(money_in),0)-COALESCE(SUM(money_out),0) FROM ledger_txn "
                       "WHERE account_id=? AND month>=? AND month<?", (acc["id"], seed_m, month)).fetchone()[0]
    return float(seed) + float(net or 0), ""


def missing_months(conn, acc, upto_month):
    """Months between the seed month and `upto_month` (exclusive) in which the account has no transactions."""
    seed_m = acc.get("opening_month")
    if not seed_m or upto_month <= seed_m:
        return []
    have = {r[0] for r in conn.execute("SELECT DISTINCT month FROM ledger_txn WHERE account_id=?", (acc["id"],))}
    out, y, m = [], int(seed_m[:4]), int(seed_m[5:])
    while f"{y:04d}-{m:02d}" < upto_month:
        k = f"{y:04d}-{m:02d}"
        if k not in have:
            out.append(k)
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def _txns(conn, ids, month):
    q = ",".join("?" * len(ids))
    return [dict(r) for r in conn.execute(
        f"SELECT * FROM ledger_txn WHERE account_id IN ({q}) AND month=? ORDER BY txn_date, id", list(ids) + [month])]


def matrix(conn, country, month):
    """Build the bank x category matrix for one month.

    Returns dict(rows=[...], accounts=[...], warnings=[...], checks=[...], notes=[...]).
    Each row: dict(key, label, kind, values={account_id: x}, total=x) with kind in
    opening | line | subtotal | net | closing | check.
    """
    accs = db.accounts(conn, country)
    cats = db.categories(conn, country)
    warnings, checks, notes = [], [], []
    if not accs:
        return dict(rows=[], accounts=[], checks=[], notes=[],
                    warnings=["No bank accounts are set up for this country (Setup tab)."])
    tx = _txns(conn, [a["id"] for a in accs], month)
    sec = {c["key"]: c["section"] for c in cats}
    label = {c["key"]: c["label"] for c in cats}
    label["unclassified_in"], label["unclassified_out"] = "Unclassified receipts", "Unclassified payments"
    sec["unclassified_in"], sec["unclassified_out"] = "in", "out"

    acc_sum = {}
    for t in tx:
        c = t["category"]
        if c not in sec:
            c = "unclassified_in" if t["money_in"] > 0 else "unclassified_out"
        t["cat"] = c
        contrib = (t["money_in"] - t["money_out"]) if sec[c] == "in" else (t["money_out"] - t["money_in"])
        acc_sum[(c, t["account_id"])] = acc_sum.get((c, t["account_id"]), 0.0) + contrib

    def vals(key):
        v = {a["id"]: acc_sum.get((key, a["id"]), 0.0) for a in accs}
        return v, sum(v.values())

    rows, opening = [], {}
    for a in accs:
        opening[a["id"]], note = opening_for(conn, a, month)
        if note and a.get("opening_balance") is not None:
            warnings.append(f"{a['name']}: opening balance {note}.")
        gaps = missing_months(conn, a, month)
        if gaps:
            warnings.append(f"{a['name']}: no ledger uploaded for {', '.join(month_label(g) for g in gaps)} - "
                            "the opening balance may be wrong.")
        if a.get("opening_balance") is None:
            warnings.append(f"{a['name']}: no opening balance - set it in Setup > Bank accounts.")
    rows.append(dict(key="opening", label="Opening Balance", kind="opening", values=opening, total=sum(opening.values())))

    def block(section, total_label, total_key):
        keys = [c["key"] for c in cats if c["section"] == section] + [f"unclassified_{section}"]
        tot = {a["id"]: 0.0 for a in accs}
        for k in keys:
            v, t = vals(k)
            if k.startswith("unclassified") and not any(abs(x) > 0.005 for x in v.values()):
                continue
            rows.append(dict(key=k, label=label[k], kind="line", values=v, total=t))
            for i in tot:
                tot[i] += v[i]
        rows.append(dict(key=total_key, label=total_label, kind="subtotal", values=tot, total=sum(tot.values())))
        return tot

    rec = block("in", "Total Receipts / Inflows", "total_receipts")
    pay = block("out", "Total Payments / Outflows", "total_payments")
    net = {i: rec[i] - pay[i] for i in rec}
    rows.append(dict(key="net", label="Net movement", kind="net", values=net, total=sum(net.values())))
    closing = {i: opening[i] + net[i] for i in rec}
    rows.append(dict(key="closing", label="Closing Balance", kind="closing", values=closing, total=sum(closing.values())))

    # check 1: closing balance per ledger file vs computed
    file_close, diffs = {}, {}
    for a in accs:
        with_bal = [t for t in tx if t["account_id"] == a["id"] and t["balance"] is not None]
        if with_bal:
            file_close[a["id"]] = with_bal[-1]["balance"]
            diffs[a["id"]] = closing[a["id"]] - file_close[a["id"]]
    if file_close:
        rows.append(dict(key="file_close", label="Closing balance per ledger file", kind="check",
                         values={i: file_close.get(i) for i in closing}, total=sum(file_close.values())))
        rows.append(dict(key="file_diff", label="Difference (should be 0)", kind="check",
                         values={i: diffs.get(i) for i in closing}, total=sum(diffs.values())))
        bad = [a["name"] for a in accs if a["id"] in diffs and abs(diffs[a["id"]]) > 0.5]
        if bad:
            warnings.append("Closing balance differs from the ledger file for: " + ", ".join(bad)
                            + ". Usually a missing month, a wrong opening balance or a wrong debit/credit direction.")
        else:
            checks.append("Closing balances agree with the running balance in every ledger file.")
    # check 2: intra-group transfers across all accounts
    ti = sum(r["total"] for r in rows if r["key"] in INTRA_IN)
    to = sum(r["total"] for r in rows if r["key"] in INTRA_OUT)
    if abs(ti) > 0.005 or abs(to) > 0.005:
        info = f"Intra-group transfers: received {ti:,.2f}, paid {to:,.2f}, difference {ti - to:,.2f}"
        if abs(ti - to) > 0.5:
            notes.append(info + " - differs; fine if the other side is an account outside this report "
                                "(e.g. salary / vendor account).")
        else:
            checks.append(info + " - nets to zero.")
    return dict(rows=rows, accounts=accs, warnings=warnings, checks=checks, notes=notes)


def summary(conn, country, months=None):
    """Multi-month roll-forward (months as columns, all banks combined) + Total column.

    Returns dict(labels=[...], kinds={label: kind}, months=[keys], mlabels=[...],
                 values={label: {mlabel: x}}, total={label: x}, warnings=[...]).
    """
    months = months or months_available(conn, country)
    if not months:
        return dict(labels=[], kinds={}, months=[], mlabels=[], values={}, total={}, warnings=[])
    labels, kinds, values, by_warning = [], {}, {}, {}
    mlabels = [month_label(m) for m in months]
    for m, ml in zip(months, mlabels):
        res = matrix(conn, country, m)
        for w in res["warnings"]:
            by_warning.setdefault(w, []).append(ml)
        for r in res["rows"]:
            if r["kind"] == "check":
                continue
            if r["label"] not in kinds:
                labels.append(r["label"])
                kinds[r["label"]] = r["kind"]
            values.setdefault(r["label"], {})[ml] = r["total"]
    total = {}
    for lab in labels:
        k, v = kinds[lab], values[lab]
        if k == "opening":
            total[lab] = v.get(mlabels[0])
        elif k == "closing":
            total[lab] = v.get(mlabels[-1])
        else:
            total[lab] = sum(x for x in v.values() if x is not None)
    keep = [lab for lab in labels if kinds[lab] != "line" or any(abs(x or 0) > 0.005 for x in values[lab].values())]
    uniq = [w if len(ms) == len(months) else f"{w} [{', '.join(ms)}]" for w, ms in by_warning.items()]
    return dict(labels=keep, kinds={k: kinds[k] for k in keep}, months=months, mlabels=mlabels,
                values={k: values[k] for k in keep}, total={k: total[k] for k in keep}, warnings=uniq)


def transactions_for(conn, country, month, key, account_id=None):
    """Transactions behind one cell of the matrix (key = category key or unclassified_in / unclassified_out).
    key=None returns every transaction of the month."""
    accs = {a["id"]: a for a in db.accounts(conn, country)}
    if not accs:
        return []
    cats = {c["key"] for c in db.categories(conn, country)}
    out = []
    for t in _txns(conn, list(accs), month):
        c = t["category"] if t["category"] in cats else ("unclassified_in" if t["money_in"] > 0 else "unclassified_out")
        if key is not None and c != key:
            continue
        if account_id and t["account_id"] != account_id:
            continue
        t["cat"] = c
        t["bank"] = accs[t["account_id"]]["name"]
        out.append(t)
    return out
