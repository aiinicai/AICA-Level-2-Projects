"""Excel export. Subtotals, closing balances and differences are written as live formulas so the
workbook can be audited and edited in Excel."""
from __future__ import annotations

import io

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter as L

from . import cashflow

NUM = '#,##0.00;(#,##0.00);"-"'
YELLOW = PatternFill("solid", fgColor="FFFF00")
GREEN = PatternFill("solid", fgColor="C6E0B4")
BLUE = PatternFill("solid", fgColor="D9E1F2")
GREY = PatternFill("solid", fgColor="E7E6E6")
THIN = Side(style="thin", color="999999")
BOX = Border(top=THIN, bottom=THIN, left=THIN, right=THIN)
BOLD = Font(bold=True)


def _sheet_name(s):
    return "".join(ch for ch in s if ch not in "[]:*?/\\")[:31]


def add_matrix_sheet(wb, res, month, country):
    ws = wb.create_sheet(_sheet_name(f"Cash flow {cashflow.month_label(month)}"))
    accs, rows = res["accounts"], res["rows"]
    n = len(accs)
    tot_col = n + 2
    ws["A1"] = f"{country} - bank cash flow statement - {cashflow.month_label(month)}"
    ws["A1"].font = Font(bold=True, size=13)
    for j, a in enumerate(accs, start=2):
        for r, v in ((2, a["gl_code"] or ""), (3, a["name"]), (4, a["account_no"] or "")):
            c = ws.cell(r, j, v)
            c.font, c.alignment, c.border = BOLD, Alignment(horizontal="center", wrap_text=True), BOX
            if r == 2:
                c.fill = YELLOW
    for r, v in ((2, "GL Code"), (3, "Bank / Property name"), (4, "Bank Account No.")):
        ws.cell(r, 1, v).font = BOLD
        ws.cell(r, tot_col, "Total" if r == 3 else None).font = BOLD
    r0 = 5
    first_line = {"in": None, "out": None}
    pos, section = {}, "in"
    for i, row in enumerate(rows):
        r = r0 + i
        pos[row["key"]] = r
        ws.cell(r, 1, row["label"])
        k = row["kind"]
        for j, a in enumerate(accs, start=2):
            v = row["values"].get(a["id"])
            col = L(j)
            if k == "line":
                if first_line[section] is None:
                    first_line[section] = r
                ws.cell(r, j, v)
            elif k == "subtotal":
                sec = "in" if row["key"] == "total_receipts" else "out"
                ws.cell(r, j, f"=SUM({col}{first_line[sec]}:{col}{r - 1})" if first_line[sec] else 0)
            elif k == "net":
                ws.cell(r, j, f"={col}{pos['total_receipts']}-{col}{pos['total_payments']}")
            elif k == "closing":
                ws.cell(r, j, f"={col}{pos['opening']}+{col}{pos['net']}")
            elif k == "check" and row["key"] == "file_diff":
                ws.cell(r, j, f"={col}{pos['closing']}-{col}{pos['file_close']}" if v is not None else None)
            else:
                ws.cell(r, j, v)
        ws.cell(r, tot_col, f"=SUM(B{r}:{L(n + 1)}{r})")
        for j in range(1, tot_col + 1):
            c = ws.cell(r, j)
            c.border = BOX
            if j > 1:
                c.number_format = NUM
            if k in ("opening", "subtotal", "net", "closing"):
                c.font = BOLD
            fill = {"opening": BLUE, "subtotal": GREEN, "closing": GREEN, "net": GREY}.get(k)
            if fill:
                c.fill = fill
            if row["key"].startswith("unclassified"):
                c.font = Font(color="C00000", bold=(j == 1))
        if row["key"] == "total_receipts":
            section = "out"                     # payment lines follow the receipts subtotal
    ws.column_dimensions["A"].width = 44
    for j in range(2, tot_col + 1):
        ws.column_dimensions[L(j)].width = 17
    ws.row_dimensions[3].height = 32
    ws.freeze_panes = "B5"
    nr = r0 + len(rows) + 1
    for tag, items in (("Warning", res["warnings"]), ("Check", res["checks"]), ("Note", res.get("notes", []))):
        for w in items:
            ws.cell(nr, 1, f"{tag}: {w}").font = Font(italic=True, color="7F7F7F")
            nr += 1


def add_summary_sheet(wb, sres, country):
    ws = wb.create_sheet("Summary", 0)
    labels, kinds, mlabels = sres["labels"], sres["kinds"], sres["mlabels"]
    heads = mlabels + ["Total"]
    ws["A1"] = f"{country} - cash flow summary (all collection bank accounts)"
    ws["A1"].font = Font(bold=True, size=13)
    for j, c in enumerate(heads, start=2):
        h = ws.cell(2, j, c)
        h.font, h.alignment, h.border = BOLD, Alignment(horizontal="center"), BOX
    nm = len(mlabels)                           # month columns are B .. (nm+1); Total is the last
    pos, first = {}, {"in": None, "out": None}
    section = "in"
    for i, label in enumerate(labels):
        r = 3 + i
        pos[label] = r
        k = kinds.get(label, "line")
        ws.cell(r, 1, label)
        for j, c in enumerate(heads, start=2):
            col = L(j)
            v = sres["total"][label] if c == "Total" else sres["values"][label].get(c)
            if c == "Total":
                if k == "opening":
                    ws.cell(r, j, f"=B{r}")
                elif k == "closing":
                    ws.cell(r, j, f"={L(nm + 1)}{r}")
                else:
                    ws.cell(r, j, f"=SUM(B{r}:{L(nm + 1)}{r})")
            elif k == "subtotal":
                sec = "in" if label.startswith("Total Receipts") else "out"
                ws.cell(r, j, f"=SUM({col}{first[sec]}:{col}{r - 1})" if first[sec] else 0)
            elif k == "net":
                ws.cell(r, j, f"={col}{pos['Total Receipts / Inflows']}-{col}{pos['Total Payments / Outflows']}")
            elif k == "closing":
                ws.cell(r, j, f"={col}{pos['Opening Balance']}+{col}{pos['Net movement']}")
            else:
                ws.cell(r, j, v)
            if k == "line" and first[section] is None and j == 2:
                first[section] = r
        for j in range(1, len(heads) + 2):
            cell = ws.cell(r, j)
            cell.border = BOX
            if j > 1:
                cell.number_format = NUM
            if k in ("opening", "subtotal", "net", "closing"):
                cell.font = BOLD
            fill = {"opening": BLUE, "subtotal": GREEN, "closing": GREEN, "net": GREY}.get(k)
            if fill:
                cell.fill = fill
            if label.startswith("Unclassified"):
                cell.font = Font(color="C00000", bold=(j == 1))
        if label.startswith("Total Receipts"):
            section = "out"                     # payment lines follow the receipts subtotal
    ws.column_dimensions["A"].width = 44
    for j in range(2, len(heads) + 2):
        ws.column_dimensions[L(j)].width = 16
    ws.freeze_panes = "B3"


def add_recon_sheet(wb, rres, country, tolerance=100.0):
    ws = wb.create_sheet("Revenue vs Collection")
    ws["A1"] = f"{country} - revenue vs collection, {rres['p_from']} to {rres['p_to']}"
    ws["A1"].font = Font(bold=True, size=13)
    heads = ["Property code", "Property", "Revenue (TB GL 4xxx, net of discounts)", "VAT (register)",
             "Security deposits (register)", "Revenue + VAT + deposits", "Collection (ERP cash report)",
             "Net advance / (receivable)", "Status"]
    for j, h in enumerate(heads, start=1):
        c = ws.cell(3, j, h)
        c.font, c.fill, c.border = BOLD, YELLOW, BOX
        c.alignment = Alignment(wrap_text=True, horizontal="center", vertical="center")
    ws.row_dimensions[3].height = 48
    r = 4
    for row in rres["rows"]:
        ws.cell(r, 1, row["code"])
        ws.cell(r, 2, row["name"])
        ws.cell(r, 3, row["revenue"])
        ws.cell(r, 4, row["vat"])
        ws.cell(r, 5, row["deposits"])
        ws.cell(r, 6, f"=C{r}+D{r}+E{r}")
        ws.cell(r, 7, row["collection"])
        ws.cell(r, 8, f"=G{r}-F{r}")
        ws.cell(r, 9, f'=IF(ABS(H{r})<{tolerance},"Reconciled",IF(H{r}>0,"Net advance","Net receivable"))')
        r += 1
    if r > 4:
        ws.cell(r, 2, "Total").font = BOLD
        for j in range(3, 9):
            ws.cell(r, j, f"=SUM({L(j)}4:{L(j)}{r - 1})").font = BOLD
    for rr in range(4, r + 1):
        for j in range(1, 10):
            c = ws.cell(rr, j)
            c.border = BOX
            if 3 <= j <= 8:
                c.number_format = NUM
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 34
    for j in range(3, 10):
        ws.column_dimensions[L(j)].width = 19
    ws.freeze_panes = "C4"
    nr = r + 2
    ws.cell(nr, 1, "Net advance / (receivable) = Collection - (Revenue + VAT + Security deposits). "
                   "Positive = collected more than revenue + VAT + deposits.").font = Font(italic=True)
    for w in rres["info"] + rres["warnings"]:
        nr += 1
        ws.cell(nr, 1, w).font = Font(italic=True, color="7F7F7F")


def workbook_bytes(country, sres=None, matrices=None, rres=None, tolerance=100.0):
    wb = Workbook()
    wb.remove(wb.active)
    if sres is not None and sres["labels"]:
        add_summary_sheet(wb, sres, country)
    for month, res in (matrices or []):
        add_matrix_sheet(wb, res, month, country)
    if rres is not None:
        add_recon_sheet(wb, rres, country, tolerance)
    if not wb.sheetnames:
        wb.create_sheet("Empty")
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
