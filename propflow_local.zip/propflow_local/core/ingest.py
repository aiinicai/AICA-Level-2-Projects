"""Save parsed files into the database."""
from __future__ import annotations

import re
from datetime import datetime

from . import cashflow, classify, db


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


def match_account(accounts, text):
    """Find the bank account a free-text label (file name or a 'Bank' column) refers to."""
    t = re.sub(r"[\s_]+", "", str(text).lower())
    if not t:
        return None
    for a in accounts:
        for key in (a.get("gl_code"), a.get("account_no"), a.get("name")):
            k = re.sub(r"[\s_]+", "", str(key or "").lower())
            if k and (k == t or k in t or t in k):
                return a
    return None


def import_ledger(conn, country, account_id, parsed, filename, rows=None):
    """Replace the account's transactions in the file's date range with the file's rows, classify them,
    and set the opening-balance seed if the account has none yet.

    Returns a summary dict (rows, date range, opening continuity check, unclassified count).
    """
    rows = parsed["rows"] if rows is None else rows
    acc = dict(conn.execute("SELECT * FROM bank_accounts WHERE id=?", (account_id,)).fetchone())
    d0, d1 = min(r["date"] for r in rows), max(r["date"] for r in rows)
    first_month = d0[:7]
    result = dict(rows=len(rows), date_from=d0, date_to=d1, warnings=[])

    # continuity check: does the file's opening agree with what we already hold?
    file_open = parsed.get("opening")
    if file_open is not None and acc.get("opening_balance") is not None and first_month > (acc["opening_month"] or ""):
        expected, _ = cashflow.opening_for(conn, acc, first_month)
        if abs(expected - file_open) > 0.5:
            result["warnings"].append(
                f"Opening balance in this file ({file_open:,.2f}) differs from the roll-forward of earlier months "
                f"({expected:,.2f}) by {file_open - expected:,.2f}. An earlier month may be missing or changed.")
    # replace overlapping rows from earlier imports of the same account (re-uploading is safe)
    conn.execute("DELETE FROM ledger_txn WHERE account_id=? AND txn_date>=? AND txn_date<=? AND manual=0",
                 (account_id, d0, d1))
    rules = db.rules(conn, country)
    manual_cats = set()
    for r in conn.execute("SELECT txn_date, reference, description, money_in, money_out FROM ledger_txn "
                          "WHERE account_id=? AND manual=1 AND txn_date>=? AND txn_date<=?", (account_id, d0, d1)):
        manual_cats.add((r["txn_date"], r["reference"], r["description"], round(r["money_in"], 2), round(r["money_out"], 2)))
    recs, unclassified = [], 0
    for r in rows:
        key = (r["date"], r["reference"], r["description"], round(r["money_in"], 2), round(r["money_out"], 2))
        if key in manual_cats:               # keep rows you categorised by hand
            continue
        cat = classify.classify(r["reference"], r["description"], r["money_in"], r["money_out"], rules)
        unclassified += cat is None
        recs.append((account_id, r["date"], r["date"][:7], r["reference"], r["description"], float(r["debit"]),
                     float(r["credit"]), r["balance"], float(r["money_in"]), float(r["money_out"]), cat, filename))
    conn.executemany("INSERT INTO ledger_txn(account_id,txn_date,month,reference,description,debit,credit,balance,"
                     "money_in,money_out,category,source) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", recs)
    if file_open is not None and (acc.get("opening_balance") is None or first_month < (acc["opening_month"] or "9999")):
        conn.execute("UPDATE bank_accounts SET opening_month=?, opening_balance=? WHERE id=?",
                     (first_month, float(file_open), account_id))
        result["opening_set"] = (first_month, float(file_open))
    conn.execute("INSERT INTO ledger_import(account_id,filename,imported_at,date_from,date_to,n_rows,ledger_type,closing_in_file)"
                 " VALUES (?,?,?,?,?,?,?,?)",
                 (account_id, filename, _now(), d0, d1, len(rows), parsed["ledger_type"], parsed.get("closing_in_file")))
    conn.commit()
    result["unclassified"] = unclassified
    return result


def _new_upload(conn, country, kind, p_from, p_to, filename, n, note=""):
    cur = conn.execute("INSERT INTO erp_upload(country,kind,period_from,period_to,filename,uploaded_at,n_rows,note)"
                       " VALUES (?,?,?,?,?,?,?,?)", (country, kind, p_from, p_to, filename, _now(), n, note))
    return cur.lastrowid


def delete_upload(conn, upload_id):
    for t in ("collection_row", "tb_row", "vat_row", "deposit_row"):
        conn.execute(f"DELETE FROM {t} WHERE upload_id=?", (upload_id,))
    conn.execute("DELETE FROM erp_upload WHERE id=?", (upload_id,))
    conn.commit()


def import_collection(conn, country, parsed, filename):
    p_from, p_to = parsed["months"][0], parsed["months"][-1]
    uid = _new_upload(conn, country, "collection", p_from, p_to, filename, len(parsed["rows"]))
    conn.executemany("INSERT INTO collection_row VALUES (?,?,?,?,?,?,?)",
                     [(uid, r["entity"], r["property_code"], r["property_name"], r["currency"], r["month"], r["amount"])
                      for r in parsed["rows"]])
    conn.commit()
    return uid


def import_trial_balance(conn, country, parsed, filename, p_from, p_to):
    for (old,) in conn.execute("SELECT id FROM erp_upload WHERE country=? AND kind='tb' AND period_from=? AND period_to=?",
                               (country, p_from, p_to)).fetchall():
        delete_upload(conn, old)
    uid = _new_upload(conn, country, "tb", p_from, p_to, filename, len(parsed["rows"]))
    conn.executemany("INSERT INTO tb_row VALUES (?,?,?,?,?)",
                     [(uid, r["gl_code"], r["gl_desc"], r["property_code"], r["amount"]) for r in parsed["rows"]])
    conn.commit()
    return uid


def import_register(conn, country, kind, parsed, filename, p_from, p_to):
    for (old,) in conn.execute("SELECT id FROM erp_upload WHERE country=? AND kind=? AND period_from=? AND period_to=?",
                               (country, kind, p_from, p_to)).fetchall():
        delete_upload(conn, old)
    rows = parsed["rows"]
    uid = _new_upload(conn, country, kind, p_from, p_to, filename, len(rows))
    if kind == "vat":
        conn.executemany("INSERT INTO vat_row VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
                         [(uid, r["row_key"], r["doc_no"], r["period"], r["txn_date"], r["tenant"], r["control"],
                           r["property_code"], r["property_name"], r["net"], r["vat"], r["gross"], r["method"])
                          for r in rows])
    else:
        conn.executemany("INSERT INTO deposit_row VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                         [(uid, r["row_key"], r["doc_no"], r["period"], r["txn_date"], r["tenant"], r["control"],
                           r["property_code"], r["property_name"], r["acct_code"], r["charge_code"], r["amount"],
                           r["method"], r["is_detail"]) for r in rows])
    conn.commit()
    return uid
