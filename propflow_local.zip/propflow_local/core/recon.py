"""Revenue vs Collection reconciliation (pure Python).

    Collection (ERP cash collection report, gross)
  - Revenue    (trial balance, GL accounts starting with 4, net of discounts)
  - VAT        (receipt register, VAT amount)
  - Deposits   (receipt register, security deposits)
  = Net advance / (receivable)

Positive = tenants paid more than revenue + VAT + deposits (advances, or prior-period receivables collected).
Negative = revenue recognised that has not been collected yet (receivables).
"""
from __future__ import annotations

import calendar

from . import db


def _csv(s):
    return [x.strip().lower() for x in str(s).split(",") if x.strip()]


def _bounds(p_from, p_to):
    y, m = int(p_to[:4]), int(p_to[5:])
    return f"{p_from}-01", f"{p_to}-{calendar.monthrange(y, m)[1]:02d}"


def months_between(p_from, p_to):
    out, y, m = [], int(p_from[:4]), int(p_from[5:])
    while f"{y:04d}-{m:02d}" <= p_to:
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def property_map(conn, country):
    return {r["source_code"].lower(): (r["group_code"].lower(), r["group_name"])
            for r in conn.execute("SELECT * FROM property_map WHERE country=?", (country,))}


def uploads(conn, country, kind=None):
    q = "SELECT * FROM erp_upload WHERE country=?" + (" AND kind=?" if kind else "") + " ORDER BY id"
    return [dict(r) for r in conn.execute(q, (country, kind) if kind else (country,))]


def pick_tb(conn, country, p_from, p_to):
    """Return (upload_row or None, note)."""
    tbs = uploads(conn, country, "tb")
    exact = [u for u in tbs if u["period_from"] == p_from and u["period_to"] == p_to]
    if exact:
        return exact[-1], ""
    if not tbs:
        return None, "No trial balance has been uploaded."
    u = tbs[-1]
    return u, (f"No trial balance for exactly {p_from} to {p_to}; using the latest one ({u['period_from']} to "
               f"{u['period_to']}). Revenue and collection cover different periods unless these match.")


def _coverage(conn, country, kind, p_from, p_to):
    need = set(months_between(p_from, p_to))
    have = set()
    for u in uploads(conn, country, kind):
        have |= set(months_between(u["period_from"], u["period_to"]))
    return sorted(need - have)


def _add(d, k, v):
    d[k] = d.get(k, 0.0) + v


def reconcile(conn, country, p_from, p_to, tb_upload_id=None):
    s = db.get_settings(conn, country)
    pm = property_map(conn, country)
    warnings, info = [], []
    names = {}

    def grp(code):
        code = (code or "").lower()
        g, n = pm.get(code, (code, None))
        if n:
            names[g] = n
        return g

    # ---- collection (the latest upload wins for each property + month)
    latest = {}
    for r in conn.execute(
            "SELECT c.* FROM collection_row c JOIN erp_upload u ON u.id=c.upload_id "
            "WHERE u.country=? AND u.kind='collection' AND c.month>=? AND c.month<=? ORDER BY c.upload_id",
            (country, p_from, p_to)):
        latest[(r["property_code"], r["month"])] = dict(r)
    collection, by_month = {}, {}
    for (code, month), r in latest.items():
        g = grp(code)
        names.setdefault(g, r["property_name"])
        _add(collection, g, r["amount"])
        by_month.setdefault(g, {})
        _add(by_month[g], month, r["amount"])
    if not latest:
        warnings.append("No cash collection report covers this period.")
    else:
        miss = _coverage(conn, country, "collection", p_from, p_to)
        if miss:
            warnings.append("Collection report has no data for: " + ", ".join(miss))

    # ---- revenue from the trial balance
    tb_up = None
    if tb_upload_id:
        r = conn.execute("SELECT * FROM erp_upload WHERE id=?", (tb_upload_id,)).fetchone()
        tb_up = dict(r) if r else None
    else:
        tb_up, note = pick_tb(conn, country, p_from, p_to)
        if note:
            warnings.append(note)
    prefixes = tuple(_csv(s["revenue_gl_prefix"]))
    revenue, tb_detail = {}, []
    if tb_up:
        sign = -1.0 if s["tb_credit_is_negative"] == "1" else 1.0
        for r in conn.execute("SELECT * FROM tb_row WHERE upload_id=?", (tb_up["id"],)):
            if not r["gl_code"].lower().startswith(prefixes):
                continue
            g = grp(r["property_code"])
            rev = r["amount"] * sign            # discounts (debits) automatically reduce revenue
            _add(revenue, g, rev)
            tb_detail.append(dict(gl_code=r["gl_code"], gl_desc=r["gl_desc"], g=g, revenue=rev))
        neg_props = [g for g, v in revenue.items() if v < 0]
        if neg_props:
            warnings.append("Net revenue is negative for: " + ", ".join(sorted(neg_props)) +
                            ". If revenue looks reversed, change 'Revenue shows as negative in the trial balance' "
                            "in Setup > Settings.")
        info.append(f"Trial balance used: {tb_up['filename']} ({tb_up['period_from']} to {tb_up['period_to']}); "
                    f"{len({d['gl_code'] for d in tb_detail})} revenue GL accounts.")

    # ---- VAT and deposits (de-duplicated across overlapping uploads, latest upload wins)
    d0, d1 = _bounds(p_from, p_to)
    basis = s["cutoff_basis"]

    def in_range(r):
        if basis == "period":
            key = r["period"] or (r["txn_date"] or "")[:7]
            return bool(key) and p_from <= key <= p_to
        d = r["txn_date"] or (f"{r['period']}-01" if r["period"] else None)
        return d is not None and d0 <= d <= d1

    vat_rows = {}
    for r in conn.execute("SELECT v.* FROM vat_row v JOIN erp_upload u ON u.id=v.upload_id "
                          "WHERE u.country=? AND u.kind='vat' ORDER BY v.upload_id", (country,)):
        vat_rows[r["row_key"]] = dict(r)
    vat_detail = [dict(r, g=grp(r["property_code"])) for r in vat_rows.values() if in_range(r)]
    vat_s = {}
    for r in vat_detail:
        _add(vat_s, r["g"], r["vat"])
    miss = _coverage(conn, country, "vat", p_from, p_to)
    if miss:
        warnings.append("VAT register not uploaded for: " + ", ".join(miss) + " - VAT will be understated.")

    codes_, prefs_ = _csv(s["deposit_charge_codes"]), tuple(_csv(s["deposit_account_prefixes"]))
    dep_rows = {}
    for r in conn.execute("SELECT d.* FROM deposit_row d JOIN erp_upload u ON u.id=d.upload_id "
                          "WHERE u.country=? AND u.kind='deposit' ORDER BY d.upload_id", (country,)):
        dep_rows[r["row_key"]] = dict(r)
    dep_detail = []
    for r in dep_rows.values():
        ok = (r["charge_code"] or "").lower() in codes_ or (bool(prefs_) and (r["acct_code"] or "").lower().startswith(prefs_))
        if not ok or (s["include_detail_lines"] != "1" and r["is_detail"]) or not in_range(r):
            continue
        if s.get("deposit_ignore_negative", "1") == "1" and r["amount"] < 0:
            continue            # refunds are not deposits received
        dep_detail.append(dict(r, g=grp(r["property_code"])))
    dep_s = {}
    for r in dep_detail:
        _add(dep_s, r["g"], r["amount"])
    miss = _coverage(conn, country, "deposit", p_from, p_to)
    if miss:
        warnings.append("Security deposit register not uploaded for: " + ", ".join(miss) + " - deposits will be understated.")

    # ---- combine
    tol = float(s["balanced_tolerance"])
    rows = []
    for c in sorted(set(collection) | set(revenue) | set(vat_s) | set(dep_s)):
        rv, vt, dp, cl = (x.get(c, 0.0) for x in (revenue, vat_s, dep_s, collection))
        if all(abs(x) < 0.005 for x in (rv, vt, dp, cl)):
            continue
        sub = rv + vt + dp
        diff = cl - sub
        status = "Reconciled" if abs(diff) < tol else ("Net advance" if diff > 0 else "Net receivable")
        rows.append(dict(code=c, name=names.get(c, c), revenue=rv, vat=vt, deposits=dp, subtotal=sub,
                         collection=cl, difference=diff, status=status))
        if cl == 0 and rv != 0:
            warnings.append(f"{c}: revenue {rv:,.2f} but no collection - check the property code mapping (Setup > Property mapping).")
        if rv == 0 and cl != 0:
            warnings.append(f"{c}: collection {cl:,.2f} but no revenue - check the property code mapping (Setup > Property mapping).")
    totals = {k: sum(r[k] for r in rows) for k in ("revenue", "vat", "deposits", "subtotal", "collection", "difference")}
    return dict(rows=rows, totals=totals, warnings=warnings, info=info, tb_upload=tb_up, p_from=p_from, p_to=p_to,
                collection_by_month=by_month, tb_detail=tb_detail, vat_detail=vat_detail, dep_detail=dep_detail,
                names=names)
