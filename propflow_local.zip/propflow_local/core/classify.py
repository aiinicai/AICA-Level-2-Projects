"""Rule-based classification of bank transactions into cash-flow categories."""
from __future__ import annotations

import re


def _alts(pattern):
    return [p.strip().lower() for p in str(pattern).split("|") if p.strip()]


def rule_matches(rule, reference, description, money_in, money_out):
    d = rule["direction"]
    if d == "in" and money_in <= 0:
        return False
    if d == "out" and money_out <= 0:
        return False
    f = rule["field"]
    text = reference if f == "reference" else description if f == "description" else f"{reference} {description}"
    text = (text or "").strip()
    if not text:
        return False
    low = text.lower()
    m = rule["match"]
    if m == "startswith":
        return any(low.startswith(a) for a in _alts(rule["pattern"]))
    if m == "contains":
        return any(a in low for a in _alts(rule["pattern"]))
    if m == "regex":
        try:
            return re.search(rule["pattern"], text, re.I) is not None
        except re.error:
            return False
    return False


def classify(reference, description, money_in, money_out, rules):
    """Return the category key of the first matching rule, or None (unclassified)."""
    for rule in rules:
        if rule_matches(rule, reference, description, money_in or 0, money_out or 0):
            return rule["category"]
    return None


def reclassify_country(conn, country, only_unclassified=False):
    """Re-run the rules over every non-manual transaction of a country. Returns number changed."""
    from . import db
    rules = db.rules(conn, country)
    ids = [a["id"] for a in db.accounts(conn, country, active_only=False)]
    if not ids:
        return 0
    q = ",".join("?" * len(ids))
    changed = 0
    for r in conn.execute(f"SELECT id, reference, description, money_in, money_out, category FROM ledger_txn "
                          f"WHERE account_id IN ({q}) AND manual=0", ids).fetchall():
        if only_unclassified and r["category"]:
            continue
        new = classify(r["reference"], r["description"], r["money_in"], r["money_out"], rules)
        if new != r["category"]:
            conn.execute("UPDATE ledger_txn SET category=? WHERE id=?", (new, r["id"]))
            changed += 1
    conn.commit()
    return changed
