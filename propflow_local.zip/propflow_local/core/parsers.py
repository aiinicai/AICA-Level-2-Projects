"""Excel / CSV parsers for the bank ledger and the four ERP exports.

Pure Python (standard library + openpyxl): nothing compiled is needed, so it also runs on
company laptops whose security policy blocks compiled packages such as pandas or numpy.

All parsers tolerate banner rows above the table, blank rows, total rows and slightly different
header spellings. They return plain dicts / lists plus human-readable warnings; nothing here
touches the database.
"""
from __future__ import annotations

import csv
import hashlib
import re
from datetime import date, datetime, timedelta
from html.parser import HTMLParser

MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6,
          "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}


class ParseError(Exception):
    pass


# ----------------------------------------------------------------------------- reading files
class _Tables(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows, self._row, self._cell, self._in = [], None, None, False

    def handle_starttag(self, tag, attrs):
        if tag == "tr":
            self._row = []
        elif tag in ("td", "th"):
            self._cell, self._in = [], True

    def handle_endtag(self, tag):
        if tag in ("td", "th") and self._row is not None:
            self._row.append("".join(self._cell).strip() or None)
            self._in = False
        elif tag == "tr" and self._row is not None:
            self.rows.append(self._row)
            self._row = None

    def handle_data(self, data):
        if self._in:
            self._cell.append(data)


def read_grid(path, sheet=None):
    """Read the first non-empty sheet (or a named one) into a list of rows (list of cell values)."""
    path = str(path)
    with open(path, "rb") as fh:
        head = fh.read(8)
    if head[:2] == b"PK":                                       # .xlsx
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        try:
            for ws in ([wb[sheet]] if sheet else wb.worksheets):
                try:
                    ws.reset_dimensions()
                except Exception:
                    pass
                rows = [list(r) for r in ws.iter_rows(values_only=True)]
                if any(any(c not in (None, "") for c in r) for r in rows):
                    return rows
        finally:
            wb.close()
        raise ParseError("The workbook has no data.")
    if head[:4] == b"\xd0\xcf\x11\xe0":                          # old .xls
        try:
            import xlrd
        except ImportError:
            raise ParseError("This is an old .xls file. Open it in Excel and Save As .xlsx, then upload that.")
        book = xlrd.open_workbook(path)
        for sh in book.sheets():
            rows = []
            for r in range(sh.nrows):
                row = []
                for c in range(sh.ncols):
                    cell = sh.cell(r, c)
                    if cell.ctype == xlrd.XL_CELL_DATE:
                        row.append(xlrd.xldate_as_datetime(cell.value, book.datemode))
                    elif cell.ctype in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK):
                        row.append(None)
                    else:
                        row.append(cell.value)
                rows.append(row)
            if any(any(c not in (None, "") for c in r) for r in rows):
                return rows
        raise ParseError("The workbook has no data.")
    text = open(path, "rb").read().decode("utf-8-sig", "replace")
    if "<table" in text.lower():                                  # ERP "xls" that is really an HTML table
        p = _Tables()
        p.feed(text)
        if p.rows:
            return p.rows
    rows = [[(c if c != "" else None) for c in r] for r in csv.reader(text.splitlines())]
    if not rows:
        raise ParseError("The file is empty.")
    return rows


# ----------------------------------------------------------------------------- basic helpers
def to_num(v):
    """'1,234.50' -> 1234.5 ; '(1,549.00)' -> -1549 ; '-4,000.00' -> -4000 ; '' -> 0."""
    if v is None or isinstance(v, bool):
        return 0.0
    if isinstance(v, (int, float)):
        return 0.0 if v != v else float(v)
    s = str(v).strip().replace("−", "-").replace(" ", " ")
    if s in ("", "-", "–", "—", "nan", "None"):
        return 0.0
    neg = False
    if s.startswith("(") and s.endswith(")"):
        neg, s = True, s[1:-1]
    s = re.sub(r"^[A-Za-z$ ]+", "", s)          # currency prefix such as AED / SAR
    s = re.sub(r"(?i)\s*(cr|dr)$", "", s)
    s = s.replace(",", "").replace(" ", "")
    if s.endswith("-"):
        neg, s = True, s[:-1]
    if s.startswith("-"):
        neg, s = True, s[1:]
    try:
        x = float(s)
    except ValueError:
        return 0.0
    return -x if neg else x


def is_num(v):
    if v is None or isinstance(v, bool):
        return False
    if isinstance(v, (int, float)):
        return v == v
    s = str(v).strip()
    return bool(s) and bool(re.fullmatch(r"\(?-?[A-Za-z$]*\s?-?[\d,]*\.?\d+\)?-?", s))


def txt(v):
    if v is None:
        return ""
    if isinstance(v, float) and v == v and v.is_integer():
        return str(int(v))
    return str(v).strip()


def norm(v):
    return re.sub(r"\s+", " ", re.sub(r"[._]", " ", txt(v).lower())).strip()


def parse_date(v, fmt="mdy"):
    """Return ISO yyyy-mm-dd or None."""
    if v is None or v == "":
        return None
    if isinstance(v, datetime):
        return v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, (int, float)) and not isinstance(v, bool) and 20000 < float(v) < 80000:   # Excel serial
        return (datetime(1899, 12, 30) + timedelta(days=float(v))).date().isoformat()
    s = str(v).strip()
    if not s:
        return None
    order = ["%Y-%m-%d", "%Y/%m/%d", "%m/%d/%Y", "%d/%m/%Y"] if fmt == "mdy" else \
            ["%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y"]
    order += ["%d-%b-%Y", "%d %b %Y", "%b %d, %Y", "%d-%m-%Y", "%m-%d-%Y", "%m/%d/%y", "%d/%m/%y",
              "%Y-%m-%d %H:%M:%S", "%m/%d/%Y %H:%M:%S", "%d/%m/%Y %H:%M:%S"]
    for f in order:
        try:
            return datetime.strptime(s, f).date().isoformat()
        except ValueError:
            continue
    return None


def parse_period(v):
    """'10/2026' | '2026-10' | date  ->  '2026-10'."""
    if v is None or v == "":
        return None
    if isinstance(v, (datetime, date)):
        return f"{v.year:04d}-{v.month:02d}"
    s = str(v).strip()
    m = re.fullmatch(r"(\d{1,2})[/\-.](\d{4})", s)
    if m:
        return f"{int(m.group(2)):04d}-{int(m.group(1)):02d}"
    m = re.fullmatch(r"(\d{4})[/\-.](\d{1,2})", s)
    if m:
        return f"{int(m.group(1)):04d}-{int(m.group(2)):02d}"
    d = parse_date(v)
    return d[:7] if d else None


def split_property(raw, style=None):
    """Split a property cell into (code, name).

    Handles both 'Ghantoot Tower(ghant)' (name then code, used in registers) and
    'ghant  (Ghantoot Tower)' (code then name, used in the collection report).
    """
    s = txt(raw)
    if not s:
        return "", ""
    m = re.fullmatch(r"(.*?)\s*\(([^()]*)\)\s*", s)
    if not m:
        return s.lower().strip(), s
    pre, inner = m.group(1).strip(), m.group(2).strip()
    if not pre:
        return inner.lower(), inner
    pre_is_token = bool(re.fullmatch(r"[A-Za-z0-9_\-.]+", pre))
    inner_is_token = bool(re.fullmatch(r"[A-Za-z0-9_\-.]+", inner))
    if pre_is_token and not inner_is_token:
        return pre.lower(), inner            # code (Name)
    if inner_is_token and not pre_is_token:
        return inner.lower(), pre            # Name(code)
    if pre_is_token and inner_is_token:       # both single words: use the hint, else the lowercase one
        if style == "code_name":
            return pre.lower(), inner
        if style == "name_code":
            return inner.lower(), pre
        return (inner.lower(), pre) if inner == inner.lower() else (pre.lower(), inner)
    return inner.lower(), pre


def _find_cols(header_cells, aliases):
    """Map logical field -> column index. Exact (normalised) matches win over 'contains' matches."""
    cells = [norm(c) for c in header_cells]
    found = {}
    for field, names in aliases.items():
        for n in names:
            if n in cells and cells.index(n) not in found.values():
                found[field] = cells.index(n)
                break
    for field, names in aliases.items():
        if field in found:
            continue
        for n in names:
            if len(n) < 4:
                continue
            for i, c in enumerate(cells):
                if i not in found.values() and n in c:
                    found[field] = i
                    break
            if field in found:
                break
    return found


def _first_year(rows, n=50):
    for r in rows[:n]:
        for c in r:
            m = re.search(r"\b(20\d\d)\b", txt(c))
            if m:
                return int(m.group(1))
    return None


# ----------------------------------------------------------------------------- bank ledger
LEDGER_ALIASES = {
    "date": ["date", "txn date", "transaction date", "value date", "posting date", "post date", "trans date"],
    "reference": ["reference", "ref", "ref no", "chq no", "cheque no", "control", "voucher", "voucher no",
                  "doc no", "document no", "txn ref", "instrument no", "transaction ref"],
    "description": ["description", "narration", "particulars", "details", "remarks", "memo",
                    "transaction description", "notes"],
    "debit": ["debit", "dr", "withdrawal", "withdrawals", "payment", "payments", "paid out", "debits"],
    "credit": ["credit", "cr", "deposit", "deposits", "receipt", "receipts", "paid in", "credits"],
    "amount": ["amount", "net amount", "transaction amount"],
    "balance": ["balance", "running balance", "closing balance", "bal"],
    "account": ["bank", "bank account", "account", "gl code", "account no", "account number", "acct"],
}
_OPENING = re.compile(r"opening\s+bal|balance\s+(b/?f|brought)|brought\s+forward|b/f\b", re.I)
_TOTALISH = re.compile(r"^\s*(grand\s+)?(total|closing\s+bal|balance\s+(c/?f|carried)|carried\s+forward|c/f)", re.I)


def parse_ledger(path, ledger_type="auto", date_fmt="mdy", sheet=None):
    """Parse one bank ledger / statement.

    ledger_type: 'books'     -> company GL ledger of the bank account (DEBIT = money in, CREDIT = money out)
                 'statement' -> bank statement (CREDIT = money in, DEBIT = money out)
                 'auto'      -> decide from the running balance, else from where R- receipts sit.
    """
    rows = read_grid(path, sheet)
    warnings = []
    hdr = cols = None
    for i, r in enumerate(rows[:40]):
        c = _find_cols(r, LEDGER_ALIASES)
        if "date" in c and ("debit" in c or "credit" in c or "amount" in c):
            hdr, cols = i, c
            break
    if hdr is None:
        sample = " | ".join(txt(x) for x in rows[0][:8]) if rows else ""
        raise ParseError("Could not find the header row (need at least Date and Debit/Credit or Amount columns). "
                         f"First row looks like: {sample}")

    recs, opening, closing_in_file, skipped = [], None, None, 0
    for r in rows[hdr + 1:]:
        if all(txt(x) == "" for x in r):
            continue

        def cell(k):
            return r[cols[k]] if k in cols and cols[k] < len(r) else None

        desc, ref = txt(cell("description")), txt(cell("reference"))
        debit, credit = to_num(cell("debit")), to_num(cell("credit"))
        if "amount" in cols and debit == 0 and credit == 0:
            a = to_num(cell("amount"))
            debit, credit = (0.0, a) if a >= 0 else (-a, 0.0)       # signed amount: + = money in
        bal = cell("balance")
        bal_n = to_num(bal) if is_num(bal) else None
        d = parse_date(cell("date"), date_fmt)
        label = f"{desc} {ref}".strip()

        if (_OPENING.search(label) and d is None) or (_OPENING.search(desc) and debit == 0 and credit == 0):
            if bal_n is not None:
                opening = bal_n
            elif debit or credit:
                opening = debit - credit
            continue
        if _TOTALISH.search(desc) or _TOTALISH.search(ref) or (d is None and re.search(r"total", label, re.I)):
            if bal_n is not None:
                closing_in_file = bal_n
            continue
        if d is None:
            if debit or credit:
                skipped += 1
            continue
        if debit == 0 and credit == 0:
            continue
        recs.append(dict(date=d, reference=ref, description=desc, debit=debit, credit=credit,
                         balance=bal_n, account_text=txt(cell("account"))))
    if skipped:
        warnings.append(f"{skipped} row(s) with an amount but no readable date were skipped.")
    if not recs:
        raise ParseError("No transaction rows were found under the header.")

    detected, reason = detect_ledger_type(recs)
    used = ledger_type
    if ledger_type == "auto":
        if detected:
            used = detected
        else:
            used = "books"
            warnings.append("Could not tell from the file whether debit or credit means money in; "
                            "assuming company books (DEBIT = money in). Check the preview and change it if wrong.")
    for r in recs:
        r["money_in"] = r["debit"] if used == "books" else r["credit"]
        r["money_out"] = r["credit"] if used == "books" else r["debit"]
    if ledger_type != "auto" and detected and detected != ledger_type:
        warnings.append(f"You chose '{ledger_type}' but the file looks like '{detected}' ({reason}).")

    # opening balance: explicit row, else back-solved from the first running balance
    opening_src = "opening row in file" if opening is not None else None
    if opening is None and recs[0]["balance"] is not None and detected:
        first = recs[0]
        opening = first["balance"] - (first["money_in"] - first["money_out"])
        opening_src = "first running balance in file"
    bals = [r["balance"] for r in recs if r["balance"] is not None]
    if closing_in_file is None and bals:
        closing_in_file = bals[-1]
    return dict(rows=recs, ledger_type=used, detected=detected, reason=reason, opening=opening,
                opening_source=opening_src, closing_in_file=closing_in_file, columns=cols,
                header_row=hdr, warnings=warnings, has_account_col="account" in cols)


def detect_ledger_type(recs):
    """Return ('books'|'statement'|None, reason)."""
    with_bal = [r for r in recs if r["balance"] is not None]
    if len(with_bal) >= 3:
        ok_books = ok_stmt = tested = 0
        prev = None
        for r in recs:
            if r["balance"] is not None and prev is not None:
                diff = r["balance"] - prev
                net = r["debit"] - r["credit"]
                if abs(net) > 0.005:
                    tested += 1
                    if abs(diff - net) < 0.01:
                        ok_books += 1
                    elif abs(diff + net) < 0.01:
                        ok_stmt += 1
            if r["balance"] is not None:
                prev = r["balance"]
        if tested >= 3 and max(ok_books, ok_stmt) / tested >= 0.8:
            if ok_books >= ok_stmt:
                return "books", f"running balance rises with debits ({ok_books}/{tested} rows)"
            return "statement", f"running balance rises with credits ({ok_stmt}/{tested} rows)"
    refs = [r for r in recs if r["reference"].upper().startswith("R-")]
    if len(refs) >= 3:
        d = sum(1 for r in refs if r["debit"] > 0)
        c = sum(1 for r in refs if r["credit"] > 0)
        if d >= 2 * max(c, 1) - 1 and d > c:
            return "books", f"{d} of {len(refs)} R- receipts sit in the debit column"
        if c >= 2 * max(d, 1) - 1 and c > d:
            return "statement", f"{c} of {len(refs)} R- receipts sit in the credit column"
    return None, ""


# ----------------------------------------------------------------------------- ERP: cash collection
_MONTH_CELL = re.compile(r"^(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?[\s\-/']*(\d{2,4})?$", re.I)


def parse_collection(path, year=None, sheet=None):
    """Cash Collection Property Report (property rows x month columns)."""
    rows = read_grid(path, sheet)
    warnings = []
    hdr = None
    for i, r in enumerate(rows[:50]):
        cells = [norm(c) for c in r]
        if any(c.startswith("property") for c in cells) and sum(1 for c in r if _MONTH_CELL.match(txt(c))) >= 1:
            hdr = i
            break
    if hdr is None:
        raise ParseError("Could not find the header row with 'Property Code' and month columns (Jan, Feb ...).")
    head = rows[hdr]
    cells = [norm(c) for c in head]
    c_prop = next(i for i, c in enumerate(cells) if c.startswith("property"))
    c_ent = next((i for i, c in enumerate(cells) if "legal" in c or "entity" in c), None)
    c_cur = next((i for i, c in enumerate(cells) if "curr" in c), None)
    c_tot = next((i for i, c in enumerate(cells) if c == "total"), None)
    hdr_year = _first_year(rows[:hdr + 1])
    yr_default = year or hdr_year
    if yr_default is None:
        yr_default = datetime.now().year
        warnings.append(f"No year found in the report; assuming {yr_default}.")
    elif year and hdr_year and year != hdr_year:
        warnings.append(f"The report header mentions {hdr_year} but you selected {year}; using {year}.")
    month_cols = {}
    for i, c in enumerate(head):
        m = _MONTH_CELL.match(txt(c))
        if m:
            y = m.group(2)
            yy = (2000 + int(y)) if y and len(y) == 2 else (int(y) if y else yr_default)
            month_cols[i] = f"{yy:04d}-{MONTHS[m.group(1).lower()[:3]]:02d}"
    recs, props, mismatches = [], [], []
    entity = ""
    for r in rows[hdr + 1:]:
        if all(txt(x) == "" for x in r):
            continue
        e = txt(r[c_ent]) if c_ent is not None and c_ent < len(r) else ""
        p = txt(r[c_prop]) if c_prop < len(r) else ""
        if re.search(r"total", e + " " + p, re.I) or not p:
            continue
        if e:
            entity = e
        code, name = split_property(p, "code_name")
        cur = txt(r[c_cur]) if c_cur is not None and c_cur < len(r) else ""
        months_sum = 0.0
        for ci, mk in month_cols.items():
            a = to_num(r[ci]) if ci < len(r) else 0.0
            months_sum += a
            recs.append(dict(entity=entity, property_code=code, property_name=name, currency=cur, month=mk, amount=a))
        if c_tot is not None and c_tot < len(r) and is_num(r[c_tot]) and abs(to_num(r[c_tot]) - months_sum) > 1.0:
            mismatches.append(f"{code}: total {to_num(r[c_tot]):,.2f} vs months {months_sum:,.2f}")
        if code not in props:
            props.append(code)
    if not recs:
        raise ParseError("No property rows found in the collection report.")
    if mismatches:
        warnings.append("Row total differs from the sum of the month columns for: " + "; ".join(mismatches[:5]))
    return dict(rows=recs, months=sorted(set(month_cols.values())), warnings=warnings, properties=sorted(props))


# ----------------------------------------------------------------------------- ERP: trial balance
_GL = re.compile(r"^\s*(\d{4}-\d{4})\b\s*[-–:]?\s*(.*)$")
_SKIP_HDR = re.compile(r"^(total|grand|actual|budget|variance|ytd|%|amounts? in)", re.I)


def parse_trial_balance(path, sheet=None):
    """Property Comparison trial balance (GL rows x property columns). Amounts are kept signed as exported."""
    rows = read_grid(path, sheet)
    warnings = []
    first_gl = None
    for i, r in enumerate(rows):
        for ci, c in enumerate(r[:6]):
            if _GL.match(txt(c)):
                first_gl = (i, ci)
                break
        if first_gl:
            break
    if not first_gl:
        raise ParseError("No GL account rows found (expected codes like 4100-0200).")
    gi, gcol = first_gl
    hdr = None
    for j in range(gi - 1, max(-1, gi - 10), -1):
        texts = [(ci, txt(c)) for ci, c in enumerate(rows[j]) if txt(c) != "" and not is_num(c)]
        if len(texts) >= 2:
            hdr = j
            break
    if hdr is None:
        raise ParseError("Could not find the property column headings above the first GL row.")
    m = _GL.match(txt(rows[gi][gcol]))
    desc_col = gcol
    if not m.group(2).strip():
        desc_col = next((ci for ci in range(gcol + 1, len(rows[gi]))
                         if txt(rows[gi][ci]) and not is_num(rows[gi][ci])), gcol)
    first_data = desc_col + 1
    prop_cols, seen = {}, {}
    for ci, c in enumerate(rows[hdr]):
        t = txt(c)
        if ci >= first_data and t and not _SKIP_HDR.match(t):
            code, _ = split_property(t, "code_name")
            code = code or t.lower()
            seen[code] = seen.get(code, 0) + 1
            prop_cols[ci] = code if seen[code] == 1 else f"{code}_{seen[code]}"
    if not prop_cols:
        raise ParseError("No property columns found to the right of the GL descriptions.")
    recs = []
    for r in rows[gi:]:
        gl = desc = None
        for ci, c in enumerate(r[:6]):
            mm = _GL.match(txt(c))
            if mm:
                gl, desc = mm.group(1), mm.group(2).strip()
                if not desc:
                    desc = next((txt(r[k]) for k in range(ci + 1, min(len(r), ci + 4))
                                 if txt(r[k]) and not is_num(r[k])), "")
                break
        if not gl:
            continue
        for ci, code in prop_cols.items():
            a = to_num(r[ci]) if ci < len(r) else 0.0
            if a != 0:
                recs.append(dict(gl_code=gl, gl_desc=desc, property_code=code, amount=a))
    if not recs:
        warnings.append("The trial balance has GL rows but every amount is zero.")
    return dict(rows=recs, properties=list(prop_cols.values()), warnings=warnings)


# ----------------------------------------------------------------------------- ERP: registers (VAT / security deposits)
REG_ALIASES = {
    "doc_no": ["doc seq no", "doc seq", "doc no"],
    "period": ["period"],
    "date": ["date"],
    "tenant": ["charge to", "tenant", "customer"],
    "control": ["control"],
    "property": ["property"],
    "net": ["net amount"],
    "vat": ["vat amount"],
    "gross": ["gross amount"],
    "acct_code": ["acct code", "account code"],
    "charge_code": ["charge code"],
    "method": ["method of payment", "pay method"],
}


def parse_register(path, kind, date_fmt="mdy", sheet=None):
    """kind = 'vat' (Receipt register, Show Vat ticked) or 'deposit' (Receipt register, charge secdep)."""
    rows = read_grid(path, sheet)
    warnings = []
    hdr = cols = None
    for i, r in enumerate(rows[:50]):
        c = _find_cols(r, REG_ALIASES)
        need = ("vat" in c) if kind == "vat" else ("gross" in c)
        if "property" in c and need:
            hdr, cols = i, c
            break
    if hdr is None:
        want = "'Vat Amount'" if kind == "vat" else "'Gross Amount'"
        raise ParseError(f"Could not find a header row with 'Property' and {want}. "
                         "For VAT tick 'Show Vat'; for deposits tick 'Show Detail'.")
    recs, counts = [], {}
    last = dict(code="", name="", period=None, date=None, tenant="", control="", doc_no="")
    detail_n, detail_sum = 0, 0.0
    for r in rows[hdr + 1:]:
        if all(txt(x) == "" for x in r):
            continue
        if any(re.match(r"^\s*(grand\s+)?total", txt(x), re.I) for x in r[:4]):
            continue

        def cell(k):
            return r[cols[k]] if k in cols and cols[k] < len(r) else None

        prop = txt(cell("property"))
        is_detail = prop == ""
        if not is_detail:
            code, name = split_property(prop, "name_code")
            last = dict(code=code, name=name, period=parse_period(cell("period")),
                        date=parse_date(cell("date"), date_fmt), tenant=txt(cell("tenant")),
                        control=txt(cell("control")), doc_no=txt(cell("doc_no")))
        net, vat, gross = to_num(cell("net")), to_num(cell("vat")), to_num(cell("gross"))
        if kind == "vat" and net == 0 and vat == 0 and gross == 0:
            continue
        if kind == "deposit" and gross == 0:
            continue
        if is_detail:
            if not last["code"]:
                continue
            detail_n += 1
            detail_sum += gross if kind == "deposit" else vat
        key_src = "|".join(map(str, [last["doc_no"], last["control"], last["code"], net, vat, gross, last["date"], is_detail]))
        counts[key_src] = counts.get(key_src, 0) + 1
        row_key = hashlib.md5(f"{key_src}#{counts[key_src]}".encode()).hexdigest()
        rec = dict(row_key=row_key, doc_no=last["doc_no"], period=last["period"], txn_date=last["date"],
                   tenant=last["tenant"], control=last["control"], property_code=last["code"],
                   property_name=last["name"], method=txt(cell("method")), is_detail=int(is_detail))
        if kind == "vat":
            rec.update(net=net, vat=vat, gross=gross)
        else:
            rec.update(acct_code=txt(cell("acct_code")), charge_code=txt(cell("charge_code")).lower(), amount=gross)
        recs.append(rec)
    if not recs:
        raise ParseError("No data rows found under the header.")
    if detail_n:
        warnings.append(f"{detail_n} sub-line(s) without a property (sum {detail_sum:,.2f}) are kept but excluded "
                        "from the reconciliation by default - see Setup > Settings to include them.")
    return dict(rows=recs, warnings=warnings, columns=cols)
