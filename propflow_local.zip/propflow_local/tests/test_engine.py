import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "samples"))

import make_samples  # noqa: E402
from core import cashflow, db, ingest, parsers, recon  # noqa: E402


@pytest.fixture()
def env(tmp_path):
    files = make_samples.build(tmp_path)
    conn = db.connect(tmp_path / "t.db")
    conn.execute("INSERT INTO bank_accounts(country,gl_code,name,account_no,currency) VALUES ('UAE','1110-1910','DIB - AT','097520184288906','AED')")
    conn.commit()
    return conn, files


def load_ledger(conn, f, acct=1):
    p = parsers.parse_ledger(str(f))
    return p, ingest.import_ledger(conn, "UAE", acct, p, Path(f).name)


# ------------------------------------------------------------------ parsers
def test_number_formats():
    assert parsers.to_num("1,342,489.26") == 1342489.26
    assert parsers.to_num("(1,549.00)") == -1549
    assert parsers.to_num("-4,000.00") == -4000
    assert parsers.to_num("1,549.00-") == -1549
    assert parsers.to_num("AED 2,000") == 2000
    assert parsers.to_num(None) == 0 and parsers.to_num("-") == 0


def test_property_split():
    assert parsers.split_property("Ghantoot Tower(ghant)") == ("ghant", "Ghantoot Tower")
    assert parsers.split_property("ghant   (Ghantoot Tower)") == ("ghant", "Ghantoot Tower")
    assert parsers.split_property("atretail(Ayedh Tower Retail)")[0] == "atretail"
    assert parsers.split_property("latifa_t(Latifa Tower)")[0] == "latifa_t"
    assert parsers.split_property("Latifa Tower(latifa_t)")[0] == "latifa_t"
    assert parsers.split_property("kamoon (kamoon Apartment )")[0] == "kamoon"
    assert parsers.split_property("atapts")[0] == "atapts"


def test_ledger_books_detected_and_opening(env):
    conn, f = env
    p = parsers.parse_ledger(f["ledger_books_sep"])
    assert p["ledger_type"] == "books" and p["detected"] == "books"
    assert p["opening"] == 1000000 and len(p["rows"]) == 7     # total + opening rows excluded
    assert p["closing_in_file"] == 1143451


def test_ledger_statement_direction_detected(env):
    _, f = env
    p = parsers.parse_ledger(f["ledger_statement"])
    assert p["detected"] == "statement"
    assert sum(r["money_in"] for r in p["rows"]) == 1500 and sum(r["money_out"] for r in p["rows"]) == 500
    assert p["opening"] == 5000                                # back-solved from first balance


# ------------------------------------------------------------------ cash flow
def test_matrix_september(env):
    conn, f = env
    load_ledger(conn, f["ledger_books_sep"])
    res = cashflow.matrix(conn, "UAE", "2026-09")
    r = {x["key"]: x for x in res["rows"]}
    assert r["opening"]["total"] == 1000000
    assert r["rent_collection"]["total"] == 950000             # 750k + 250k - 50k reversal (R- paid out)
    assert r["interbank_receipt_intra"]["total"] == 200000
    assert r["bank_charges"]["total"] == 1549
    assert r["interbank_to_vendor"]["total"] == 1000000
    assert r["unclassified_out"]["total"] == 5000              # shown, never silently dropped
    assert r["total_receipts"]["total"] == 1150000
    assert r["total_payments"]["total"] == 1006549
    assert r["closing"]["total"] == 1143451
    assert abs(r["file_diff"]["total"]) < 0.01                 # agrees with ledger file balance
    assert not [w for w in res["warnings"] if "differs from the ledger" in w]


def test_rollforward_and_reupload_idempotent(env):
    conn, f = env
    load_ledger(conn, f["ledger_books_sep"])
    p, out = load_ledger(conn, f["ledger_books_oct"])
    assert not out["warnings"]                                  # opening agrees with Sep closing
    load_ledger(conn, f["ledger_books_oct"])                    # upload again: must not double count
    res = cashflow.matrix(conn, "UAE", "2026-10")
    r = {x["key"]: x for x in res["rows"]}
    assert r["opening"]["total"] == 1143451
    assert r["rent_collection"]["total"] == 100000
    assert r["closing"]["total"] == 1242651
    s = cashflow.summary(conn, "UAE")
    assert s["mlabels"] == ["Sep-26", "Oct-26"]
    assert s["total"]["Opening Balance"] == 1000000             # total column opens with first month
    assert s["total"]["Closing Balance"] == 1242651


def test_continuity_warning_when_month_missing(env):
    conn, f = env
    load_ledger(conn, f["ledger_books_oct"])                    # seed from Oct file (1,143,451)
    conn.execute("UPDATE bank_accounts SET opening_month='2026-08', opening_balance=900000")
    conn.commit()
    p = parsers.parse_ledger(f["ledger_books_oct"])
    out = ingest.import_ledger(conn, "UAE", 1, p, "x.xlsx")
    assert any("differs from the roll-forward" in w for w in out["warnings"])
    res = cashflow.matrix(conn, "UAE", "2026-10")
    assert any("no ledger uploaded" in w for w in res["warnings"])


# ------------------------------------------------------------------ revenue vs collection
def import_erp(conn, f):
    ingest.import_collection(conn, "UAE", parsers.parse_collection(f["collection_report"]), "c.xlsx")
    ingest.import_trial_balance(conn, "UAE", parsers.parse_trial_balance(f["trial_balance"]), "tb.xlsx", "2026-01", "2026-09")
    ingest.import_register(conn, "UAE", "vat", parsers.parse_register(f["vat_register"], "vat"), "v.xlsx", "2026-01", "2026-09")
    ingest.import_register(conn, "UAE", "deposit", parsers.parse_register(f["deposit_register"], "deposit"), "d.xlsx", "2026-01", "2026-09")


def test_collection_parser_skips_totals(env):
    _, f = env
    p = parsers.parse_collection(f["collection_report"])
    assert p["properties"] == ["atapts", "ebp2", "kamoon", "parking"]
    assert p["months"][0] == "2026-01" and p["months"][-1] == "2026-09"
    assert sum(r["amount"] for r in p["rows"]) == (100000 + 200000 + 10000 + 5000) * 9


def test_trial_balance_keeps_signs_and_all_gls(env):
    _, f = env
    p = parsers.parse_trial_balance(f["trial_balance"])
    assert set(p["properties"]) == {"acuae", "atapts", "ebp2", "kamoon"}
    amt = [r["amount"] for r in p["rows"] if r["gl_code"] == "4100-1200" and r["property_code"] == "ebp2"]
    assert amt == [100000]                                      # debit stays positive


def test_reconciliation_numbers(env):
    conn, f = env
    import_erp(conn, f)
    conn.execute("INSERT INTO property_map VALUES ('UAE','parking','ebp2','Emaar Business Park 2')")
    conn.commit()
    res = recon.reconcile(conn, "UAE", "2026-01", "2026-09")
    d = {r["code"]: r for r in res["rows"]}
    # atapts: revenue 800k + 50k service - 20k discount = 830k ; VAT 5000-1000 ; deposits 3000+6000 (the -6000 refund is ignored)
    assert d["atapts"]["revenue"] == 830000
    assert d["atapts"]["vat"] == 4000                       # NSF reversal netted, Oct row excluded
    assert d["atapts"]["deposits"] == 9000                  # negative refund line ignored, sub-lines excluded
    assert d["atapts"]["collection"] == 900000
    assert d["atapts"]["difference"] == 900000 - (830000 + 4000 + 9000)
    # ebp2: revenue 1.5m - 100k discount ; non-secdep 99,999 receipt ignored ; parking collection mapped in
    assert d["ebp2"]["revenue"] == 1400000
    assert d["ebp2"]["deposits"] == 25000
    assert d["ebp2"]["collection"] == 1800000 + 90000
    assert "parking" not in d
    # non-revenue GLs (3300, 5100) never leak in
    assert sum(r["revenue"] for r in d.values()) == 830000 + 1400000 + 40000


def test_cutoff_basis_period(env):
    conn, f = env
    import_erp(conn, f)
    res = recon.reconcile(conn, "UAE", "2026-10", "2026-10")
    # only the October VAT row falls in October
    assert {r["code"]: r for r in res["rows"]}["atapts"]["vat"] == 999


def test_warnings_for_missing_months(env):
    conn, f = env
    import_erp(conn, f)
    res = recon.reconcile(conn, "UAE", "2026-01", "2026-12")
    text = " ".join(res["warnings"])
    assert "2026-10" in text and "VAT register not uploaded" in text
