import sys

# The app must run on laptops that block compiled packages: make any import of them fail loudly.
for _m in ("pandas", "numpy", "pyarrow", "streamlit"):
    sys.modules[_m] = None
