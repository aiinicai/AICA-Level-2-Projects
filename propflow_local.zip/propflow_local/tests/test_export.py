"""Exports are written with live formulas; recalculate them in LibreOffice and compare with the engine."""
import shutil
import subprocess
import sys
from pathlib import Path

import pytest
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "samples"))

from core import cashflow, export, recon  # noqa: E402
from test_engine import env, import_erp, load_ledger  # noqa: E402,F401

pytestmark = pytest.mark.skipif(shutil.which("soffice") is None, reason="LibreOffice not available")


def recalc(path, outdir):
    subprocess.run(["soffice", "--headless", "--convert-to", "xlsx", "--outdir", str(outdir), str(path)],
                   check=True, capture_output=True, timeout=120)
    return load_workbook(Path(outdir) / Path(path).name, data_only=True)


def test_export_formulas_match_engine(env, tmp_path):
    conn, f = env
    load_ledger(conn, f["ledger_books_sep"])
    load_ledger(conn, f["ledger_books_oct"])
    import_erp(conn, f)
    sres = cashflow.summary(conn, "UAE")
    mats = [(m, cashflow.matrix(conn, "UAE", m)) for m in ("2026-09", "2026-10")]
    rres = recon.reconcile(conn, "UAE", "2026-01", "2026-09")
    data = export.workbook_bytes("UAE", sres, mats, rres)
    p = tmp_path / "out.xlsx"
    p.write_bytes(data)
    wb = recalc(p, tmp_path / "calc")
    assert wb.sheetnames[0] == "Summary"

    def find(ws, label, col=1):
        for row in ws.iter_rows():
            if row[col - 1].value == label:
                return row
        raise AssertionError(label)

    sep = wb["Cash flow Sep-26"]
    assert find(sep, "Total Receipts / Inflows")[-1].value == 1150000          # SUM formulas recalc correctly
    assert find(sep, "Total Payments / Outflows")[-1].value == 1006549
    assert find(sep, "Closing Balance")[-1].value == 1143451
    assert abs(find(sep, "Difference (should be 0)")[-1].value) < 0.01
    summ = wb["Summary"]
    assert find(summ, "Closing Balance")[-1].value == 1242651
    assert find(summ, "Opening Balance")[1].value == 1000000
    rc = wb["Revenue vs Collection"]
    row = find(rc, "atapts")
    assert row[5].value == 830000 + 4000 + 9000 and row[7].value == 900000 - 843000
    assert row[8].value == "Net advance"
    # no Excel error values anywhere
    for ws in wb:
        for r in ws.iter_rows():
            for c in r:
                assert not (isinstance(c.value, str) and c.value.startswith("#")), (ws.title, c.coordinate, c.value)
