@echo off
rem Double-click alternative to IDLE (Windows). Needs Python installed.
cd /d "%~dp0"
where py >nul 2>nul && (py start_propflow.py) || (python start_propflow.py)
pause
