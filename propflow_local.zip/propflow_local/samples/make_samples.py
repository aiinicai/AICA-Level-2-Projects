"""Creates small demo Excel files that imitate the layouts of your ERP exports and bank ledger.

Run:  python samples/make_samples.py        (files appear in the samples folder)
They are used by the automated tests and are handy for trying the app before you load real files.
The numbers are invented.
"""
import sys
from datetime import datetime
from pathlib import Path

from openpyxl import Workbook

MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "June", "Jul", "Aug", "Sep"]


def _save(wb, folder, name):
    p = Path(folder) / name
    wb.save(p)
    return p


def ledger_books_sep(folder):
    """Company-books ledger of one bank account: DEBIT = money in."""
    wb = Workbook(); ws = wb.active; ws.title = "Ledger"
    ws.append(["DIB - AT (1110-1910)  General ledger"]); ws.append([])
    ws.append(["Date", "Reference", "Description", "Debit", "Credit", "Balance"])
    ws.append([None, None, "Opening Balance", None, None, 1000000.00])
    rows = [
        ("09/01/2026", "R-1001", "Rent receipt Unit 402", 750000, 0, 1750000),
        ("09/03/2026", "R-1002", "Rent receipt Unit 510", 250000, 0, 2000000),
        ("09/05/2026", "CHG-1", "Bank charges Aug", 0, 1549, 1998451),
        ("09/10/2026", "TRF-1", "Interbank transfer to vendor payment ac", 0, 1000000, 998451),
        ("09/12/2026", "R-1003", "Cheque returned NSF", 0, 50000, 948451),
        ("09/15/2026", "TRF-2", "Fund transfer from DIB EBP2", 200000, 0, 1148451),
        ("09/20/2026", "X-9", "Mystery payment", 0, 5000, 1143451),
    ]
    for r in rows:
        ws.append(list(r))
    ws.append([None, None, "Total", 1200000, 1056549, None])
    return _save(wb, folder, "UAE_ledger_DIB-AT_Sep26.xlsx")


def ledger_books_oct(folder):
    wb = Workbook(); ws = wb.active
    ws.append(["Date", "Reference", "Description", "Debit", "Credit", "Balance"])
    ws.append([None, None, "Opening Balance", None, None, 1143451.00])
    ws.append([datetime(2026, 10, 2), "R-2001", "Rent receipt Unit 402", 100000, 0, 1243451])
    ws.append([datetime(2026, 10, 9), "CHG-2", "Bank charges Sep", 0, 800, 1242651])
    return _save(wb, folder, "UAE_ledger_DIB-AT_Oct26.xlsx")


def ledger_statement(folder):
    """Bank statement: CREDIT = money in (no R- references, balance rises with credits)."""
    wb = Workbook(); ws = wb.active
    ws.append(["Txn Date", "Narration", "Withdrawal", "Deposit", "Balance"])
    ws.append(["2026-09-02", "CHEQUE DEPOSIT 000123", 0, 500, 5500])
    ws.append(["2026-09-03", "SERVICE CHARGE", 25, 0, 5475])
    ws.append(["2026-09-04", "INCOMING TRF", 0, 1000, 6475])
    ws.append(["2026-09-05", "PAYMENT", 475, 0, 6000])
    return _save(wb, folder, "bank_statement_style.xlsx")


def collection_report(folder):
    wb = Workbook(); ws = wb.active
    ws.append(["AD Cash Collection Report"]); ws.append(["Cash Collection Property Report"])
    ws.append(["Period = Jan 2026 - Sep 2026"]); ws.append([])
    ws.append(["Legal Entity", "Property Code", "Base Curr.", "Total"] + MONTHS)
    data = {"atapts (Ayedh Tower)": 100000, "ebp2   (Emaar Business Park 2)": 200000,
            "parking (Parking for EBP2 & EBP4)": 10000, "kamoon (kamoon Apartment )": 5000}
    tot = 0
    for k, v in data.items():
        ws.append(["ayd", k, "AED", v * 9] + [v] * 9)
        tot += v * 9
    ws.append(["LegalEntity Total", None, "AED", tot] + [sum(data.values())] * 9)
    ws.append(["Grand Total", None, None, tot] + [sum(data.values())] * 9)
    return _save(wb, folder, "UAE_cash_collection_Jan-Sep26.xlsx")


def trial_balance(folder):
    wb = Workbook(); ws = wb.active
    ws.append(["Financial Reports"]); ws.append(["* Amounts in aed"])
    ws.append([None, "acuae", "atapts", "ebp2", "kamoon"])
    rows = [
        ("3300-0200 Previous Year Retained Earnings", 0, -96000, 42000, 0),
        ("4100-0500 Base Rent - Office", 0, 0, -1500000, 0),
        ("4100-0800 Base Rent - Residential", 0, -800000, 0, -40000),
        ("4100-1200 Base Rent Discount Commercial", 0, 0, 100000, 0),      # debit -> reduces revenue
        ("4100-1600 Base Rent Discount Lineshop", 0, 20000, 0, 0),         # debit -> reduces revenue
        ("4400-0100 Service Charge", 0, -50000, 0, 0),
        ("5100-0100 FM - Cleaning Charges", 0, 9999, 5000, 0),            # not revenue
    ]
    for r in rows:
        ws.append([r[0]] + list(r[1:]))
    return _save(wb, folder, "UAE_trial_balance_Jan-Sep26.xlsx")


REG_HDR = ["Doc. Seq. No.", "Period", "Date", "Charge To", "Batch", "Control", "Legal Entity", "Property",
           "Base Curr.", "Net Amount", "Vat Amount", "Gross Amount", "Method of Payment", "Reference"]


def vat_register(folder):
    wb = Workbook(); ws = wb.active
    ws.append(["Register Reports"]); ws.append([])
    ws.append(REG_HDR)
    r = [
        ["202600000001", "03/2026", "03/15/2026", "Tenant A(t1)", 1, "R-1", "ayd", "Ayedh Tower(atapts)", "aed", 100000, 5000, 105000, "Cheque", ""],
        ["202600000002", "03/2026", "03/20/2026", "Tenant A(t1)", 2, "R-2", "ayd", "Ayedh Tower(atapts)", "aed", -20000, -1000, -21000, "Cheque", "NSF"],
        ["202600000003", "03/2026", datetime(2026, 3, 22), "Tenant B(t2)", 3, "R-3", "ayd", "Emaar Business Park 2(ebp2)", "aed", 1200000, 60000, 1260000, "EFT", ""],
        ["202600000004", "10/2026", "10/05/2026", "Tenant A(t1)", 4, "R-4", "ayd", "Ayedh Tower(atapts)", "aed", 19980, 999, 20979, "EFT", ""],   # outside Jan-Sep
    ]
    for x in r:
        ws.append(x)
    return _save(wb, folder, "UAE_vat_register_Jan-Sep26.xlsx")


def deposit_register(folder):
    hdr = ["Doc. Seq. No.", "Period", "Date", "Charge To", "Batch", "Control", "Legal Entity", "Property", "Acct Code",
           "Acct Description", "Charge Code", "Base Curr.", "Gross Amount", "Method of Payment", "Reference"]
    wb = Workbook(); ws = wb.active
    ws.append(["Register Reports"]); ws.append([])
    ws.append(hdr)
    sd = ["2115-0100", "Security Deposit - Tenant", "secdep"]
    rows = [
        ["202600000011", "02/2026", "02/03/2026", "Tenant A(t1)", 1, "R-11", "ayd", "Ayedh Tower(atapts)"] + sd + ["aed", 3000, "EFT", ""],
        ["202600000012", "04/2026", "04/10/2026", "Tenant C(t3)", 2, "R-12", "ayd", "Ayedh Tower(atapts)"] + sd + ["aed", 6000, "EFT", ""],
        ["202600000013", "04/2026", "04/12/2026", "Tenant C(t3)", 3, "R-13", "ayd", "Ayedh Tower(atapts)"] + sd + ["aed", -6000, "EFT", "reversal"],
        ["202600000014", "05/2026", "05/02/2026", "Tenant D(t4)", 4, "R-14", "ayd", "Emaar Business Park 2(ebp2)"] + sd + ["aed", 25000, "EFT", ""],
        ["202600000015", "05/2026", "05/05/2026", "Tenant D(t4)", 5, "R-15", "ayd", "Emaar Business Park 2(ebp2)", "4100-0500", "Base Rent", "rent", "aed", 99999, "EFT", ""],
        ["202600000016", "06/2026", "06/05/2026", "Tenant E(t5)", 6, "R-16", "ayd", "Ayedh Tower(atapts)"] + sd + ["aed", 0, "Cheque:", ""],
        [None, None, None, None, None, "R-16", None, None] + sd + ["aed", 4000, "Cheque:", ""],     # detail sub-lines
        [None, None, None, None, None, "R-16", None, None] + sd + ["aed", -4000, "Cheque:", ""],
    ]
    for x in rows:
        ws.append(x)
    return _save(wb, folder, "UAE_security_deposits_Jan-Sep26.xlsx")


def build(folder):
    folder = Path(folder); folder.mkdir(parents=True, exist_ok=True)
    return {f.__name__: f(folder) for f in (ledger_books_sep, ledger_books_oct, ledger_statement, collection_report,
                                           trial_balance, vat_register, deposit_register)}


if __name__ == "__main__":
    out = build(Path(__file__).resolve().parent)
    for k, v in out.items():
        print("created", v)
