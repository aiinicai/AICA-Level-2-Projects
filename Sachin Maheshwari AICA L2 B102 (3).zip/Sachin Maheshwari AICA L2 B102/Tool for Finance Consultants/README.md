# Dafria Finance Desk — Simple Financial Intelligence for Office Staff

**Financial Planning, Loan Advisory, CMA Working Capital Assessment & Document Management**  
*Designed for Chartered Accountants, Credit Underwriters, and Office Staff (Dafria & Co., Ratlam Practice, Madhya Pradesh, India)*

---

## 1. Executive Summary & Design Philosophy

**Dafria Finance Desk** is engineered specifically for **ordinary office staff members** who possess varying levels of computer knowledge and financial experience. It eliminates the steep learning curve, obscure banking jargon, crowded spreadsheets, and confusing menus typical of legacy banking software.

### What Any Office Employee Can Do Without Technical Assistance:
1. **Register a New Client:** Guided form with automatic sequential Case ID generation (`DFD-2026-0001`).
2. **Determine Loan Eligibility & EMI:** Instant calculation of monthly payments (EMI), income affordability (FOIR), and collateral value (LTV).
3. **Manage Document Vault & Checklists:** Clear visibility into which documents are needed, why they are needed, which are uploaded, and which are missing.
4. **Prepare CMA & Working Capital Reports:** Automated assessment under RBI Nayak Committee (Turnover Method) and Tandon Committee Method II (MPBF).
5. **Analyse Financial Statements:** 3-year comparative Balance Sheet & P&L review with plain-language observations.
6. **Audit Bank Statements:** Monthly cash flow turnover, Average Bank Balance (ABB), cheque bounce tracking, and statement reconciliation check.
7. **Generate Client-Ready Reports:** Multi-format exports in **PDF**, **Excel (.xlsx)**, and **Word (.docx)**, with a mandatory **1-Page Executive Summary** on Page 1.

---

## 2. The 9 Clearly Labelled Home Screen Options

The home screen presents 9 large, clearly labelled cards with intuitive icons and familiar terminology:

| # | Home Screen Option | Plain-Language Purpose | Primary Action |
|---|-------------------|------------------------|----------------|
| **1** | **👤 New Client** | Register a new client and setup their loan requirement file | Open guided registration form |
| **2** | **📂 Existing Clients** | Search, filter, reopen previous cases, or export files | Open client directory & search |
| **3** | **🧮 Loan Eligibility & EMI** | Calculate monthly payment (EMI) and maximum affordable loan | Run cash flow & property assessment |
| **4** | **📊 CMA / Project Report** | Working Capital (Turnover/MPBF), Project Cost & 5-Year DSCR | Assess credit limits & loan repayment |
| **5** | **📈 Financial Statement Analysis** | Review past 3 years Balance Sheets, P&L, growth, and margins | View comparative multi-year trends |
| **6** | **🏦 Bank Statement Analysis** | Audit bank turnover, average balances, and statement integrity | Upload transactions & check balance |
| **7** | **📋 Documents & Missing Information** | Track uploaded files, missing documents, and checklist status | Upload, replace, preview & verify docs |
| **8** | **📑 Reports** | Generate professional reports in PDF, Excel, and Word formats | Export 1-Page Summary & audit model |
| **9** | **⚙️ Settings & Backup** | Firm profile letterhead, technical logs, and 1-click backup | Backup database & configure firm |

---

## 3. Consistent 6-Step Workflow Pattern

Every client consultation follows an identical, predictable sequence with live visual progress bars:

```
[1. Enter Details] ➔ [2. Upload Documents] ➔ [3. Review Information] ➔ [4. Analyse] ➔ [5. View Results] ➔ [6. Generate Report]
```

At every step, the application displays:
- **Current Step Number**
- **Recommended Next Action Banner** (e.g. *"Your bank statement has been uploaded successfully. Please check the opening and closing balances before continuing."*)

---

## 4. No Unexplained Banking or Technical Jargon

All technical banking terms, ratios, and acronyms are translated into simple, everyday English with short definitions and benchmarks:

| Banking Term | Plain-English Title | What It Means | Banking Benchmark |
|--------------|-------------------|---------------|-------------------|
| **DSCR** | **Ability to Repay the Loan** | Compares net cash profit with yearly loan instalments and interest due | 1.50 or higher is safe; below 1.20 is tight |
| **LTV** | **Loan Compared with Property Value** | Percentage of the property market value the bank will finance | 75% to 80% for housing; 65% for commercial |
| **FOIR** | **Affordable Monthly Payment %** | Portion of monthly net income allowed for all loan payments combined | Usually 50% to 65% of net monthly income |
| **MPBF** | **Maximum Permissible Bank Finance** | Maximum working capital limit allowed based on current assets and gap | Tandon Method II (min 25% owner margin) |
| **TOL / TNW** | **Liabilities Compared with Owner's Capital** | Total outside debt compared with owner's net worth | Below 3.0 : 1 for trading; 2.5 : 1 for factory |
| **Current Ratio** | **Short-Term Payment Ability (Liquidity)** | Short-term assets compared with short-term bills due | Minimum 1.33 : 1 required by banks |
| **EMI** | **Monthly Loan Instalment** | Fixed amount paid to bank every month (principal + interest) | Equal monthly outflow |
| **OCR Check** | **Text Recognition Check** | Automated reading of figures from scanned PDF or image documents | Verification prompt before calculations |
| **Reconciliation** | **Statement Balance Check** | Verifies Opening + Deposits - Withdrawals = Closing Balance | Must match to ₹ 0 difference |

---

## 5. Clear Guidance on Every Screen (The 3 Questions)

Every screen answers three fundamental questions for office staff:
1. **What information is required?**
2. **Why is it needed?**
3. **What should the user do next?**

Inputs provide live Indian Rupee previews (e.g. typing `2500000` immediately shows `₹ 25.00 Lakh (₹ 25,00,000)`) preventing miscounted zeroes.

---

## 6. Document Vault & The 5 Standard Statuses

The Document Vault tracks every document with the 5 standard statuses mandated in Section 5:

- ⭕ **Not Uploaded** (Red badge) — Critical document still required from client.
- 📄 **Uploaded** (Blue badge) — Document safely placed into local vault.
- ⏳ **Being Processed** (Sky blue badge) — Figures currently being extracted.
- ⚠️ **Please Check** (Amber badge) — Document uploaded; requires staff review of figures before calculations.
- ✓ **Ready to Use** (Green badge) — Verified and approved for final calculations and reports.

### Safe Staff Safeguards:
- **Replacement Warning:** If staff clicks *Replace* on an existing document, a confirmation dialog appears to prevent accidental overwrites.
- **Client Deletion Safeguard:** Requires explicit confirmation before removing client files.
- **Automatic Saving:** Database commits changes automatically with a status bar indicator (*"✓ All changes saved automatically"*).

---

## 7. Reports — Executive Summary First

All major reports (PDF, Excel, Word) prioritize an **Executive Summary on Page 1**:
- Client Name, Case ID, Constitution, and Business Nature
- Facilities Requested and Reviewing CA / Officer
- Summary of Verified Documents & Period Covered
- Key Financial Highlights (Turnover, Profit, Net Worth, Bank Credits)
- Main Positive Findings
- Critical Matters Requiring Verification
- Recommended Next Step for the CA, Staff, and Bank

Subsequent sections contain complete schedules, loan amortization tables, comparative financial ratios, CMA working capital computations, and document checklists.

---

## 8. Verification & Test Results

The entire codebase is verified with automated tests covering all 12 requirement sections:

```bash
python -m pytest -v
```

### Test Suite Summary:
- `tests/test_engines.py`: Mathematical verification of EMI, reverse loan capacity, FOIR, LTV, Nayak Turnover Method, Tandon MPBF Method II, 5-Year DSCR projections, and statement balance reconciliation.
- `tests/test_database.py`: SQLite initialization, sequential Case ID generation, client CRUD, document checklist population, full backup archive creation, and restore.
- `tests/test_reports.py`: PDF generation with `NumberedCanvas` (headers/footers/page numbers), multi-tab Excel workbook creation, and editable Word document generation.
- `tests/test_staff_workflow.py`: End-to-end 10-step staff acceptance test simulating complete office workflow.
- `tests/test_gui.py`: Offscreen GUI integration verifying rendering and navigation across all 9 screens.

**Result: 13 / 13 Passed (100% Pass Rate)**

---

## 9. Launching & Standalone Windows Packaging

### Direct Windows Launch:
Double-click `Dafria_Finance_Desk.bat` to automatically detect your Python runtime and launch the application.

### Building Standalone Windows Executable (No Python Required):
To package the application so it can run on any other Windows laptop without Python installed:
```bash
python build_exe.py
```
The output is created in `dist/Dafria_Finance_Desk/`. This entire folder can be copied to a USB drive or zipped and sent to any Windows computer.
