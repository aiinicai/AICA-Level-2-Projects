OFFICELINK — SOURCE CODE AND MAINTENANCE COPY
R & A Group | Saved 27 October 2026

Open MAINTENANCE_AND_RECOVERY.html first.

The OfficeLink_Office_Only folder contains the complete editable Python source
from the package supplied for your working installation. Its original files
are preserved byte-for-byte. This copy adds maintenance documentation only.

Main launcher: OfficeLink_Office_Only/Start_OfficeLink.cmd
Python/IDLE entry point: OfficeLink_Office_Only/OfficeLink.py

Keep the entire folder together; OfficeLink.py imports the other Python files.
You can read/edit the .py files with IDLE or a code editor.

Your current host address: 192.168.70.122, HTTPS port 8443.
The address and certificates are configured on your host, not baked into
this clean source-code archive. Your staff ZIP is generated on the host.

THIS ARCHIVE DOES NOT CONTAIN YOUR LIVE USERS, CHATS, DOCUMENTS, PASSWORDS,
PRIVATE CERTIFICATE KEYS OR HOST CONFIGURATION. Those were created locally
on your Windows computer. Use Back up database there and separately retain
the host configuration and certificates as explained in the guide.

You do not need to reinstall a working application to keep this code backup.
Save this ZIP in a protected backup location. For a future error, preserve
the working folder and data before replacing any files.

Source files are not a compiled Windows installer. Python and the required
libraries are separate runtime dependencies. The launcher installs missing
libraries when needed; it does not install Python itself.

For future assistance, provide the exact error message, the action that
caused it, whether it occurred on the host or a staff PC, and the relevant
source file. Do not send passwords, private keys or the live database.
