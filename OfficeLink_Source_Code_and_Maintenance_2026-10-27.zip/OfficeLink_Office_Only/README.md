# OfficeLink — office-only pilot package

Prepared for R & A Group on 27 October 2026.

Start with **START_HERE.html**. Extract the ZIP completely before running it.

**Moving to the different computer at 192.168.70.122?** Read **SERVER_MIGRATION.html** first. Choose **Move office from another computer** to import a consistent database backup, create certificates for the new IP and export a new staff package. The startup-task option prepares an XML file for Windows Task Scheduler import; import and a reboot-without-logon check must be completed on the host. Windows 10 Pro 22H2 needs current commercial ESU coverage/updates or replacement with a supported OS before confidential live use.

**Already using the working two-PC pilot?** Read **UPDATE_5GB_SHORTCUTS.html** first. This revision raises the shared attachment quota to 5 GiB and creates a desktop shortcut automatically through the launcher. It reuses the existing accounts, history, certificates and connection profile.

OfficeLink is a desktop messenger for colleagues connected to the same office LAN or Wi-Fi. One host computer runs the local server. Staff sign in with their own username and password, select a colleague, send messages and attach documents. No email account, phone number or client-wise organisation is required. The existing optional group and voice controls remain available; ordinary messaging does not require them.

## What is supplied

- The existing OfficeLink v0.2 source, consolidated with the v0.3 document/password changes and v0.4 optional retention changes.
- A new `OfficeLink.py` entry point that installs missing dependencies in a local virtual environment and can be opened in Windows IDLE (F5).
- Automatic current-user desktop shortcut after dependency setup, using the actual Python runtime. A separate `Create_Desktop_Shortcut.cmd` recreates the shortcut. Host and staff shortcuts are named **OfficeLink Host** and **OfficeLink** respectively. Keep the application folder in its final location.
- A local host console: new/existing setup, start/stop, add staff, reset passwords, disable accounts, create staff ZIP and database backup.
- Different-computer migration preserving the source backup, a headless server runner, per-database process lock, graceful background stop, and Windows startup-task XML generation. Task Scheduler runs under the selected Windows account with normal privileges and handles its credentials through Windows' own prompt. Native Windows import/startup verification remains required.
- Staff packages contain only allowlisted client source and public connection information. Private keys, databases, host tools and passwords are excluded.
- Tests, a current validation record and synthetic interface previews.

This is a source-based pilot package. It is not a signed Windows installer. No office computer, account, firewall or router was changed during preparation.

## Requirements

- 64-bit Windows with a compatible 64-bit Python installation (Python 3.11 or later).
- One host computer with a reserved private IPv4 address. It must stay awake while staff use the messenger.
- All employee computers must be able to reach that host over the office network. Guest Wi-Fi isolation may prevent this.
- Internet for first-time dependency installation, or an IT-prepared local wheelhouse. Normal chat and file transfers run within the office network after setup.

Run `Start_OfficeLink.cmd`, or open `OfficeLink.py` in IDLE and press F5. If libraries are missing, the launcher shows progress and installs them into `.officelink-env`. It does not install Python itself.

After the runtime is ready, Windows receives a desktop shortcut with an OfficeLink icon. The launcher resolves the current user's desktop through Windows, including redirected desktop locations. It does not require administrator elevation or change execution policy. If company policy blocks shortcut creation, the app displays the reason and continues opening; the CMD launcher remains usable. If a shortcut with the same name belongs to a different application/folder, a numbered shortcut is used instead of overwriting it. Repeated launches reuse this folder's managed shortcut.

Fallback dependency command:

```text
python -m pip install "PyQt6>=6.7,<7" "sounddevice>=0.5,<1" "cryptography>=41"
```

## Keep an existing pilot intact

Stop the old host and back up its entire data and certificate folders before migration. Extract this package into a **new folder**. Choose **Use existing host setup** and select the existing DATA folder and CERTS folder. Enter the existing reserved IPv4 address and port. The console validates the certificate/key, issuing CA, validity and IP identity before saving configuration. Accounts and history are reused. On start the inherited server applies its additive schema migrations if needed. It does not enable attachment expiry.

Do not run two server processes against the same database. Current GUI, CLI and background launch paths use an OS-held lock to prevent this; older builds do not participate. For a same-address update, preserve the certificates. For a different-computer/address migration, use SERVER_MIGRATION.html to generate new certificates and staff profiles while preserving accounts and history.

If the existing setup uses a DNS-only certificate, this simplified host console cannot import it: use the existing command-line launch path or ask IT to issue an IP-compatible certificate and refresh staff profiles.

## Current limits

- Default maximum document size: **50 MiB**. Total active attachment quota: **5 GiB (5,368,709,120 bytes)**, shared by the whole office. This uses the same binary units as the previous 1 GiB limit. One document transfer at a time at the server; a competing transfer receives a retry message. The quota counts retained attachment content, not SQLite overhead, messages or backups, so the host needs additional free disk space.
- Supported attachment extensions: PDF, DOCX, XLSX, PPTX, TXT, CSV, PNG, JPG, JPEG and ZIP. Older DOC/XLS files and other extensions are not accepted by default.
- Newly added/reset users must change their temporary password. Sessions last up to eight hours; restarting the host requires users to sign in again.
- New offices retain attachments by default. The inherited optional 24-hour attachment-expiry command is not enabled by this launcher. Imported offices retain their existing retention policy.
- TLS protects network traffic. This is not end-to-end encryption: the host can access stored content. Database files, keys and backups need Windows account/folder protection and an appropriate disk/backup encryption policy.
- The host's local Windows account is the administration boundary. Messenger login roles do not stop someone with filesystem access from changing the database.
- Alerts depend on the client staying open and on Windows notification settings. A closed application cannot receive alerts.
- Existing voice calling is experimental. It is outside the requested chat/document pilot and has not been tested on your hardware in this revision.

## Backup and recovery

Use **Back up database** for a consistent SQLite backup, including accounts, messages and attachment content. Store it in a restricted backup location. Separately back up `host_config.json`, the public CA certificate, server certificate/private key and encrypted CA key. Keep the certificate recovery passphrase in the administrator's password manager. Never include these host assets in staff packages.

To restore: stop every process using the database, preserve the current data folder, restore the backup as `office.db` into a new data folder, and use a fresh extracted host package to select that folder and the correct existing certificate folder. Run a two-PC verification before wider use. Backups contain confidential content; do not distribute them through a staff group.

## Evidence and references

See `TEST_RESULTS_CURRENT.md` for executed tests and remaining Windows checks. Earlier design/migration records are in `technical_history/` and describe older revisions; this README and START_HERE.html govern this consolidated package.

Technical references:
- Python TLS: https://docs.python.org/3/library/ssl.html
- Python virtual environments: https://docs.python.org/3/library/venv.html
- PyQt supplier information and licensing: https://www.riverbankcomputing.com/software/pyqt/
- Microsoft Windows shortcut creation: https://learn.microsoft.com/en-us/troubleshoot/windows-client/admin-development/create-desktop-shortcut-with-wsh
- Microsoft desktop-folder resolution: https://learn.microsoft.com/en-us/dotnet/api/system.environment.specialfolder

The source imports PyQt6, sounddevice and cryptography. Their licences and notices remain applicable. The supplier pages, rather than this package, govern third-party licensing terms.
