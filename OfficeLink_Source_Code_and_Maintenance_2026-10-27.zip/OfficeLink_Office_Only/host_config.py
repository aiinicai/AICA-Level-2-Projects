"""Host configuration validation, without a desktop dependency."""
import ipaddress
import json
import ssl
from pathlib import Path
from datetime import datetime, timezone

def private_host(value):
    address = ipaddress.IPv4Address(value.strip())
    if not any(address in ipaddress.IPv4Network(n) for n in
               ('10.0.0.0/8', '172.16.0.0/12', '192.168.0.0/16')):
        raise ValueError('Enter the host computer’s private office IPv4 address, such as 192.168.1.20.')
    return str(address)


def public_profile(config):
    from deployment_profile import validate_profile
    from create_profile import validate_ca
    value = {'version': 1, 'server': f'https://{private_host(config["host"])}:{int(config["port"])}',
             'ca_pem': Path(config['ca']).read_text(encoding='ascii'),
             'organization': config['organization']}
    validate_profile(value); validate_ca(value['ca_pem'])
    return value


def validate_config(config):
    value = dict(config)
    value['host'] = private_host(value['host'])
    if not 1024 <= int(value['port']) <= 65535:
        raise ValueError('Choose a port between 1024 and 65535.')
    if not (Path(value['data']) / 'office.db').is_file():
        raise ValueError('The selected data folder does not contain office.db.')
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(value['cert'], value['key'])
    public_profile(value)
    # Check identity and validity before saving; no network is contacted.
    from cryptography import x509
    from cryptography.x509.oid import ExtensionOID
    certificate = x509.load_pem_x509_certificate(Path(value['cert']).read_bytes())
    authority = x509.load_pem_x509_certificate(Path(value['ca']).read_bytes())
    certificate.verify_directly_issued_by(authority)
    now = datetime.now(timezone.utc)
    before = getattr(certificate, 'not_valid_before_utc', None) or certificate.not_valid_before.replace(tzinfo=timezone.utc)
    after = getattr(certificate, 'not_valid_after_utc', None) or certificate.not_valid_after.replace(tzinfo=timezone.utc)
    if not before <= now <= after:
        raise ValueError('The server certificate is expired or not yet valid.')
    san = certificate.extensions.get_extension_for_oid(ExtensionOID.SUBJECT_ALTERNATIVE_NAME).value
    if ipaddress.IPv4Address(value['host']) not in san.get_values_for_type(x509.IPAddress):
        raise ValueError('The server certificate does not cover this IP address. Use the existing reserved IP or renew the certificate through IT.')
    return value


def save_config(config, path):
    path = Path(path)
    if path.exists():
        raise FileExistsError("This folder already has a host configuration. It has not been overwritten.")
    value = validate_config(config)
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2)
    return value
