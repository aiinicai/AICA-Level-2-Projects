"""Current-user Windows shortcut using documented WScript.Shell COM.

No administrator rights, registry edits or execution-policy changes.
Application paths are JSON data on stdin, never interpolated PowerShell code.
"""
import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


POWERSHELL_SCRIPT = r'''
$ErrorActionPreference = 'Stop'
[Console]::InputEncoding = [System.Text.UTF8Encoding]::new($false)
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
try {
    $p = [Console]::In.ReadToEnd() | ConvertFrom-Json
    if (-not (Test-Path -LiteralPath $p.target -PathType Leaf)) { throw 'Python executable is missing.' }
    if (-not (Test-Path -LiteralPath $p.folder -PathType Container)) { throw 'OfficeLink folder is missing.' }
    $desktop = [Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)
    if ([string]::IsNullOrWhiteSpace($desktop) -or -not (Test-Path -LiteralPath $desktop -PathType Container)) {
        throw 'Windows did not return an accessible desktop folder.'
    }
    $shell = New-Object -ComObject WScript.Shell
    $path = $null
    for ($i = 0; $i -lt 100; $i++) {
        $name = if ($i -eq 0) { $p.name + '.lnk' } else { $p.name + ' (' + ($i+1) + ').lnk' }
        $candidate = Join-Path $desktop $name
        if (Test-Path -LiteralPath $candidate) {
            $existing = $shell.CreateShortcut($candidate)
            if ($existing.Description -ne $p.description) { continue }
        }
        $path = $candidate
        break
    }
    if ($null -eq $path) { throw 'No available OfficeLink shortcut name was found.' }
    $link = $shell.CreateShortcut($path)
    $link.TargetPath = $p.target
    $link.Arguments = $p.arguments
    $link.WorkingDirectory = $p.folder
    $link.Description = $p.description
    $link.WindowStyle = 1
    $link.IconLocation = $p.icon
    $link.Save()
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'Windows did not save the shortcut.' }
    $verified = $shell.CreateShortcut($path)
    if ($verified.TargetPath -ine $p.target -or $verified.Arguments -cne $p.arguments -or
        $verified.WorkingDirectory -ine $p.folder -or $verified.Description -cne $p.description) {
        throw 'Shortcut verification failed.'
    }
    @{path=$path; name=[System.IO.Path]::GetFileName($path)} | ConvertTo-Json -Compress
} catch {
    [Console]::Error.WriteLine($_.Exception.Message)
    exit 1
}
'''


def shortcut_payload(root, interpreter):
    root = Path(root).resolve()
    launcher = root / 'OfficeLink.py'
    if not launcher.is_file():
        raise FileNotFoundError('OfficeLink.py is missing. Extract the full application folder first.')
    python = Path(interpreter).resolve()
    # pythonw avoids a console for normal desktop use; fall back to python.exe.
    windowed = python.with_name('pythonw.exe')
    if windowed.is_file():
        python = windowed
    if not python.is_file():
        raise FileNotFoundError('The selected Python executable is missing.')
    host = (root / 'office_setup.py').is_file()
    name = 'OfficeLink Host' if host else 'OfficeLink'
    identity = hashlib.sha256(os.path.normcase(str(root)).encode('utf-8')).hexdigest()[:16]
    icon = root / 'officelink.ico'
    return {'name': name, 'target': str(python),
            'arguments': subprocess.list2cmdline([str(launcher)]),
            'folder': str(root),
            'description': 'OfficeLink managed desktop shortcut | ' + identity,
            'icon': str(icon if icon.is_file() else python) + ',0'}


def create_desktop_shortcut(root, interpreter=None):
    """Idempotent for this package folder; preserves unrelated named shortcuts."""
    if sys.platform != 'win32':
        return None
    payload = shortcut_payload(root, interpreter or sys.executable)
    system_root = os.environ.get('SystemRoot', r'C:\Windows')
    powershell = Path(system_root) / 'System32/WindowsPowerShell/v1.0/powershell.exe'
    if not powershell.is_file():
        raise RuntimeError('Windows PowerShell is unavailable. Use Start_OfficeLink.cmd to open the app.')
    encoded = base64.b64encode(POWERSHELL_SCRIPT.encode('utf-16le')).decode('ascii')
    try:
        result = subprocess.run([str(powershell), '-NoLogo', '-NoProfile', '-NonInteractive',
                                 '-EncodedCommand', encoded],
                                input=json.dumps(payload, ensure_ascii=True),
                                text=True, encoding='utf-8', errors='replace',
                                capture_output=True, check=False, timeout=25,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    except subprocess.TimeoutExpired:
        raise RuntimeError('Windows took too long to create the shortcut. The messenger can still run.') from None
    if result.returncode:
        raise RuntimeError((result.stderr or 'Windows could not create the desktop shortcut.').strip())
    try:
        answer = json.loads(result.stdout.lstrip('\ufeff').strip())
        if not isinstance(answer.get('path'), str) or not answer['path'].lower().endswith('.lnk'):
            raise ValueError()
        return answer['path']
    except (ValueError, AttributeError):
        raise RuntimeError('Windows did not confirm a valid shortcut path.') from None


if __name__ == '__main__':
    print(create_desktop_shortcut(Path(__file__).resolve().parent) or 'Desktop shortcuts are available on Windows.')
