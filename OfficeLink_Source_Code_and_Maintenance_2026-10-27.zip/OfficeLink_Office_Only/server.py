"""Office Link reviewable LAN MVP. No external services; TLS mandatory."""
import argparse, base64, collections, hashlib, hmac, ipaddress, json, os, re, secrets, sqlite3, ssl, threading, time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, parse_qs

from transfer_limits import DEFAULT_MAX_FILE_BYTES, encoded_body_limit, validate_limit, TRANSFER_TIMEOUT
MAX_FILE = DEFAULT_MAX_FILE_BYTES
MAX_STORAGE = 5 * 1024 * 1024 * 1024
ALLOWED = {'.pdf','.docx','.xlsx','.pptx','.txt','.csv','.png','.jpg','.jpeg','.zip'}

def password_hash(password, salt=None):
    salt = salt or secrets.token_hex(16)
    return salt + ':' + hashlib.scrypt(password.encode(), salt=bytes.fromhex(salt), n=16384, r=8, p=1).hex()

def verify_password(password, encoded):
    return hmac.compare_digest(password_hash(password, encoded.split(':')[0]), encoded)

class App:
    def __init__(self, data, max_file_bytes=MAX_FILE):
        self.max_file_bytes=validate_limit(max_file_bytes)
        self.path = Path(data); self.path.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(self.path/'office.db', check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.lock = threading.RLock(); self.sessions = {}; self.attempts = {}; self.password_attempts = {}; self.calls = {}; self.audio = {}
        self.db.executescript('''PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,display_name TEXT NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,enabled INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS conversations(id INTEGER PRIMARY KEY,name TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS members(conversation_id INTEGER REFERENCES conversations(id),user_id INTEGER REFERENCES users(id),PRIMARY KEY(conversation_id,user_id));
        CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY,conversation_id INTEGER REFERENCES conversations(id),name TEXT NOT NULL,data BLOB NOT NULL);
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,conversation_id INTEGER REFERENCES conversations(id),sender_id INTEGER REFERENCES users(id),text TEXT NOT NULL,created_at REAL NOT NULL,file_id TEXT REFERENCES files(id));''')
        # Additive migration: existing accounts stay usable and are not unexpectedly reset.
        if 'must_change_password' not in {row[1] for row in self.db.execute('PRAGMA table_info(users)')}:
            self.db.execute('ALTER TABLE users ADD COLUMN must_change_password INTEGER NOT NULL DEFAULT 0')
        columns={row[1] for row in self.db.execute('PRAGMA table_info(files)')}
        for name in ('uploaded_at','expires_at','expired_at'):
            if name not in columns:self.db.execute(f'ALTER TABLE files ADD COLUMN {name} REAL')
        self.db.execute('CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
        self.db.execute("INSERT OR IGNORE INTO settings VALUES('retention_enabled','0')")
        self.db.execute('CREATE INDEX IF NOT EXISTS files_expiry_idx ON files(expires_at,expired_at)')
        self.db.execute('CREATE INDEX IF NOT EXISTS messages_conversation_id_idx ON messages(conversation_id,id)')
        self.db.commit()
    def retention_enabled(self):
        return self.db.execute("SELECT value FROM settings WHERE key='retention_enabled'").fetchone()[0]=='1'
    def set_retention(self,enabled):
        # Local administrator only; no remote endpoint changes deletion policy.
        with self.lock,self.db:
            self.db.execute("UPDATE settings SET value=? WHERE key='retention_enabled'",('1' if enabled else '0',))
            if not enabled:
                # Disabling preserves every remaining attachment and cancels its deadline.
                self.db.execute('UPDATE files SET expires_at=NULL WHERE expired_at IS NULL')
    def storage_status(self):
        with self.lock:
            row=self.db.execute('SELECT coalesce(sum(length(data)),0) used,sum(CASE WHEN expired_at IS NULL AND expires_at IS NULL THEN 1 ELSE 0 END) unmanaged,sum(CASE WHEN expired_at IS NOT NULL THEN 1 ELSE 0 END) expired FROM files').fetchone()
            return {'used_bytes':row['used'],'quota_bytes':MAX_STORAGE,'retention_enabled':self.retention_enabled(),'retention_hours':24,'legacy_unmanaged_files':row['unmanaged'] or 0,'expired_files':row['expired'] or 0,'server_time':time.time()}
    def expire_attachments(self,now=None):
        """Logical expiry only for explicitly assigned deadlines; no legacy backfill."""
        now=time.time() if now is None else now
        with self.lock,self.db:
            if not self.retention_enabled():return 0
            cursor=self.db.execute("UPDATE files SET data=X'',expired_at=? WHERE expires_at IS NOT NULL AND expires_at<=? AND expired_at IS NULL",(now,now))
            return cursor.rowcount
    def add_user(self, username, name, password, role='staff', must_change_password=False):
        if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,40}',username): raise ValueError('Username: 1–40 letters, numbers, dot, dash or underscore')
        if not 1 <= len(name.strip()) <= 80: raise ValueError('Name required, maximum 80 characters')
        if len(password)<12 or len(password)>256: raise ValueError('Password must be 12–256 characters')
        if role not in ('staff','admin'): raise ValueError('Invalid role')
        with self.lock, self.db:
            self.db.execute('INSERT INTO users(username,display_name,password,role,must_change_password) VALUES(?,?,?,?,?)',(username,name.strip(),password_hash(password),role,int(bool(must_change_password))))
    def member(self, uid, cid):
        if not self.db.execute('SELECT 1 FROM members WHERE user_id=? AND conversation_id=?',(uid,cid)).fetchone(): raise APIError(403,'Conversation access denied')
    def auth(self, token):
        s=self.sessions.get(token)
        if not s or time.time()-s['started']>8*3600: self.sessions.pop(token,None); raise APIError(401,'Please sign in again')
        u=self.db.execute('SELECT * FROM users WHERE id=? AND enabled=1',(s['uid'],)).fetchone()
        if not u or s.get('credential') != u['password']: raise APIError(401,'Account disabled or credentials changed')
        s['seen']=time.time(); return u
    def public_call(self,c): return {k:v for k,v in c.items() if k not in ('updated','seen')}
    def dispatch(self, method, path, q, body, token, ip):
        with self.lock:
            if method=='POST' and path=='/login':
                username=str(body.get('username',''))[:40]; password=str(body.get('password',''))
                if len(password)>256: raise APIError(400,'Invalid credentials')
                now=time.time(); key=(ip,username)
                # Bound rate-limit memory; no passwords or bearer tokens are logged.
                self.attempts={k:v for k,v in self.attempts.items() if now-v[0]<300}
                count=self.attempts.get(key,(now,0))
                ip_count=sum(v[1] for k,v in self.attempts.items() if k[0]==ip)
                if count[1]>=8 or ip_count>=40: raise APIError(429,'Too many attempts; wait five minutes')
                self.attempts[key]=(count[0],count[1]+1)
                u=self.db.execute('SELECT * FROM users WHERE username=? AND enabled=1',(username,)).fetchone()
                encoded=u['password'] if u else password_hash('dummy-password', '00'*16)
                valid=verify_password(password,encoded)
                if not u or not valid: raise APIError(401,'Invalid username or password')
                self.attempts.pop(key,None)
                self.sessions={k:v for k,v in self.sessions.items() if now-v['started']<8*3600}
                if len(self.sessions)>=200: raise APIError(503,'Session limit reached')
                t=secrets.token_urlsafe(32); self.sessions[t]={'uid':u['id'],'started':now,'seen':now,'credential':u['password']}
                return {'token':t,'limits':{'max_file_bytes':self.max_file_bytes,'storage_quota_bytes':MAX_STORAGE},'user':dict({k:u[k] for k in ('id','username','display_name','role')},must_change_password=bool(u['must_change_password']))}
            u=self.auth(token); uid=u['id']
            if method=='POST' and path=='/logout':
                self.sessions.pop(token,None)
                for c in self.calls.values():
                    if uid in (c['caller_id'],c['callee_id']): c['status']='ended'; self.audio.pop(c['id'],None)
                return {'ok':True}
            if method=='POST' and path=='/heartbeat': return {'ok':True}
            if method=='POST' and path=='/change-password':
                now=time.time()
                self.password_attempts={key:value for key,value in self.password_attempts.items() if now-value[0]<300}
                started,attempts=self.password_attempts.get(uid,(now,0))
                if attempts>=5: raise APIError(429,'Too many password-change attempts; wait five minutes')
                self.password_attempts[uid]=(started,attempts+1)
                current=body.get('current_password'); new=body.get('new_password')
                if not isinstance(current,str) or not isinstance(new,str) or not 1<=len(current)<=256:
                    raise APIError(400,'Current and new passwords are required')
                if not 12<=len(new)<=256: raise APIError(400,'New password must contain 12–256 characters')
                if not verify_password(current,u['password']): raise APIError(403,'Current password is incorrect')
                if hmac.compare_digest(current.encode('utf-8'),new.encode('utf-8')):
                    raise APIError(400,'Choose a different password from the current or temporary password')
                with self.db:
                    self.db.execute('UPDATE users SET password=?,must_change_password=0 WHERE id=?',(password_hash(new),uid))
                # Reauthenticate every device, including the requesting client. No replacement token is issued.
                self.sessions={key:value for key,value in self.sessions.items() if value['uid']!=uid}
                self.password_attempts.pop(uid,None)
                for call in self.calls.values():
                    if uid in (call['caller_id'],call['callee_id']):
                        call['status']='ended'; self.audio.pop(call['id'],None)
                return {'ok':True,'reauthenticate':True}
            if u['must_change_password']:
                raise APIError(403,'Change your temporary password before using OfficeLink')
            if method=='GET' and path=='/storage':
                self.expire_attachments();return self.storage_status()
            if method=='GET' and path=='/users':
                online={s['uid'] for s in self.sessions.values() if time.time()-s['seen']<30 and time.time()-s['started']<8*3600}
                return {'users':[dict(r,online=r['id'] in online) for r in self.db.execute('SELECT id,username,display_name,role FROM users WHERE enabled=1')]}
            if path=='/conversations':
                if method=='GET':
                    rows=self.db.execute('SELECT c.* FROM conversations c JOIN members m ON c.id=m.conversation_id WHERE m.user_id=? ORDER BY c.id DESC',(uid,)).fetchall()
                    result=[]
                    for r in rows:
                        cid=r['id']
                        latest=self.db.execute('SELECT id,sender_id,text,created_at FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT 1',(cid,)).fetchone()
                        incoming=self.db.execute('SELECT id,sender_id,text,created_at FROM messages WHERE conversation_id=? AND sender_id!=? ORDER BY id DESC LIMIT 1',(cid,uid)).fetchone()
                        counts=self.db.execute('SELECT count(*) total,coalesce(sum(sender_id!=?),0) incoming FROM messages WHERE conversation_id=?',(uid,cid)).fetchone()
                        result.append(dict(r,members=[x[0] for x in self.db.execute('SELECT user_id FROM members WHERE conversation_id=?',(cid,))],
                            latest_message_id=latest['id'] if latest else 0,message_count=counts['total'],
                            latest_sender_id=latest['sender_id'] if latest else None,latest_text=latest['text'] if latest else '',latest_created_at=latest['created_at'] if latest else None,
                            incoming_count=counts['incoming'],latest_incoming_id=incoming['id'] if incoming else 0,
                            latest_incoming_sender_id=incoming['sender_id'] if incoming else None,latest_incoming_sender_name=self.db.execute('SELECT display_name FROM users WHERE id=?',(incoming['sender_id'],)).fetchone()[0] if incoming else '',latest_incoming_text=incoming['text'] if incoming else '',latest_incoming_created_at=incoming['created_at'] if incoming else None))
                    return {'conversations':result}
                if method=='POST':
                    name=str(body.get('name','')).strip(); members=body.get('members',[])
                    if not name or len(name)>100 or not isinstance(members,list) or not 1<=len(members)<=30: raise APIError(400,'Name and 1–30 members required')
                    ids=set(int(i) for i in members); ids.add(uid)
                    for i in ids:
                        if not self.db.execute('SELECT 1 FROM users WHERE id=? AND enabled=1',(i,)).fetchone(): raise APIError(400,'Unknown member')
                    with self.db:
                        cid=self.db.execute('INSERT INTO conversations(name) VALUES(?)',(name,)).lastrowid
                        self.db.executemany('INSERT INTO members VALUES(?,?)',[(cid,i) for i in ids])
                    return {'id':cid}
            if path=='/messages':
                cid=int(q.get('conversation_id',['0'])[0]) if method=='GET' else int(body.get('conversation_id',0)); self.member(uid,cid)
                if method=='GET':
                    self.expire_attachments()
                    after=max(0,int(q.get('after',['0'])[0]))
                    rows=self.db.execute('SELECT m.*,u.display_name sender_name,f.name file_name,(f.expired_at IS NOT NULL) file_expired,f.expires_at file_expires_at FROM messages m JOIN users u ON m.sender_id=u.id LEFT JOIN files f ON f.id=m.file_id WHERE m.conversation_id=? AND m.id>? ORDER BY m.id LIMIT 200',(cid,after))
                    return {'messages':[dict(r) for r in rows],'attachment_states':[{'file_id':r['id'],'file_expired':bool(r['expired_at'] is not None),'file_expires_at':r['expires_at']} for r in self.db.execute('SELECT id,expired_at,expires_at FROM files WHERE conversation_id=?',(cid,))]}
                if method=='POST':
                    text=str(body.get('text','')).strip()
                    if not text or len(text)>4000: raise APIError(400,'Message must contain 1–4000 characters')
                    with self.db: mid=self.db.execute('INSERT INTO messages(conversation_id,sender_id,text,created_at) VALUES(?,?,?,?)',(cid,uid,text,time.time())).lastrowid
                    return {'id':mid}
            if method=='POST' and path=='/uploads':
                cid=int(body.get('conversation_id',0)); self.member(uid,cid); name=str(body.get('name',''))
                if not name or len(name)>150 or any(c in name for c in '/\\\x00:') or any(ord(c)<32 for c in name) or Path(name).suffix.lower() not in ALLOWED: raise APIError(400,'Unsupported or unsafe filename')
                raw=base64.b64decode(body.get('data',''),validate=True)
                if not raw or len(raw)>self.max_file_bytes: raise APIError(413,f'File must be between 1 byte and {self.max_file_bytes//(1024*1024)} MiB')
                self.expire_attachments()
                if self.db.execute('SELECT COALESCE(SUM(length(data)),0) FROM files').fetchone()[0]+len(raw)>MAX_STORAGE: raise APIError(507,f'Office attachment storage quota ({MAX_STORAGE // (1024**3)} GiB) reached; contact administrator')
                fid=secrets.token_hex(16)
                with self.db:
                    uploaded=time.time();expires=uploaded+24*3600 if self.retention_enabled() else None
                    self.db.execute('INSERT INTO files(id,conversation_id,name,data,uploaded_at,expires_at) VALUES(?,?,?,?,?,?)',(fid,cid,name,raw,uploaded,expires))
                    mid=self.db.execute('INSERT INTO messages(conversation_id,sender_id,text,created_at,file_id) VALUES(?,?,?,?,?)',(cid,uid,'Shared a document',time.time(),fid)).lastrowid
                return {'id':mid,'file_id':fid,'expires_at':expires}
            if method=='GET' and path.startswith('/files/'):
                self.expire_attachments()
                f=self.db.execute('SELECT * FROM files WHERE id=?',(path.rsplit('/',1)[1],)).fetchone()
                if not f: raise APIError(404,'File not found')
                self.member(uid,f['conversation_id'])
                if f['expired_at'] is not None:raise APIError(410,'Attachment expired after 24 hours and is no longer available from the server. Ask the sender for a new copy.')
                if len(f['data'])>self.max_file_bytes:raise APIError(413,'Stored document exceeds the current transfer limit; ask your administrator to adjust it.')
                return {'name':f['name'],'data':base64.b64encode(f['data']).decode()}
            now=time.time()
            for c in self.calls.values():
                stale=now-c['updated']>45 or (c['status']=='active' and any(now-t>45 for t in c['seen'].values()))
                enabled=self.db.execute('SELECT count(*) FROM users WHERE id IN (?,?) AND enabled=1',(c['caller_id'],c['callee_id'])).fetchone()[0]==2
                if (stale or not enabled) and c['status']!='ended': c['status']='ended'; self.audio.pop(c['id'],None)
            self.calls={k:c for k,c in self.calls.items() if now-c['updated']<3600}
            if path=='/calls':
                if method=='GET':
                    return {'calls':[self.public_call(c) for c in self.calls.values() if uid in (c['caller_id'],c['callee_id']) and c['status']!='ended']}
                if method=='POST':
                    peer=int(body.get('peer_id',0)); p=self.db.execute('SELECT * FROM users WHERE id=? AND enabled=1',(peer,)).fetchone()
                    if not p or peer==uid: raise APIError(400,'Choose another enabled colleague')
                    if any(c['status']!='ended' and {uid,peer}&{c['caller_id'],c['callee_id']} for c in self.calls.values()): raise APIError(409,'A participant is already in a call')
                    cid=secrets.token_hex(12); c={'id':cid,'caller_id':uid,'callee_id':peer,'caller_name':u['display_name'],'callee_name':p['display_name'],'status':'ringing','updated':now,'seen':{uid:now,peer:now}}; self.calls[cid]=c; self.audio[cid]={uid:collections.deque(maxlen=20),peer:collections.deque(maxlen=20)}
                    return {'call':self.public_call(c)}
            if path.startswith('/calls/'):
                parts=path.split('/'); cid=parts[2]; action=parts[3] if len(parts)==4 else ''; c=self.calls.get(cid)
                if not c: raise APIError(404,'Call not found')
                if uid not in (c['caller_id'],c['callee_id']): raise APIError(403,'Call access denied')
                if action=='end' and method=='POST': c['status']='ended'; self.audio.pop(cid,None); return {'ok':True}
                if action=='accept' and method=='POST':
                    if uid!=c['callee_id'] or c['status']!='ringing': raise APIError(409,'Call cannot be accepted')
                    c['status']='active'; c['updated']=now; c['seen']={c['caller_id']:now,c['callee_id']:now}; return {'call':self.public_call(c)}
                if action=='audio':
                    if c['status']!='active': raise APIError(409,'Call is not active')
                    c['updated']=now; c['seen'][uid]=now
                    if method=='POST':
                        raw=base64.b64decode(body.get('data',''),validate=True)
                        if not raw or len(raw)>16000 or len(raw)%2: raise APIError(400,'Invalid PCM frame')
                        peer=c['callee_id'] if uid==c['caller_id'] else c['caller_id']; self.audio[cid][peer].append(base64.b64encode(raw).decode()); return {'ok':True}
                    if method=='GET':
                        frames=list(self.audio[cid][uid]); self.audio[cid][uid].clear(); return {'frames':frames}
            raise APIError(404,'Endpoint not found')

class APIError(Exception):
    def __init__(self,status,message): self.status=status; self.message=message

class Handler(BaseHTTPRequestHandler):
    server_version='OfficeLink'; sys_version=''
    def log_message(self,*args): pass
    def do_GET(self): self.handle_api()
    def do_POST(self): self.handle_api()
    def handle_api(self):
        transfer_acquired=False
        try:
            self.connection.settimeout(10)
            if self.headers.get('Transfer-Encoding'): raise APIError(400,'Transfer encoding not supported')
            url=urlsplit(self.path); auth=self.headers.get('Authorization',''); token=auth[7:] if auth.startswith('Bearer ') else ''
            login=self.command=='POST' and url.path=='/login'
            if not login:
                with self.server.app.lock: self.server.app.auth(token)
            is_transfer=(self.command=='POST' and url.path=='/uploads') or (self.command=='GET' and url.path.startswith('/files/'))
            if is_transfer:
                transfer_acquired=self.server.transfer_slot.acquire(blocking=False)
                if not transfer_acquired: raise APIError(503,'Another document transfer is in progress. Wait a moment and try again.')
                self.connection.settimeout(TRANSFER_TIMEOUT)
            length=int(self.headers.get('Content-Length','0'))
            limit=4096 if login else (encoded_body_limit(self.server.app.max_file_bytes) if url.path=='/uploads' and self.command=='POST' else 65536)
            if length<0 or length>limit: raise APIError(413,'Request too large')
            body=json.loads(self.rfile.read(length)) if length else {}
            if not isinstance(body,dict): raise APIError(400,'JSON object required')
            result=self.server.app.dispatch(self.command,url.path,parse_qs(url.query),body,token,self.client_address[0]); status=200
        except APIError as e: status=e.status; result={'error':e.message}
        except (ValueError,TypeError,KeyError,OverflowError): status=400; result={'error':'Malformed request'}
        except Exception: status=500; result={'error':'Server error; ask administrator to inspect storage and restart if needed'}
        try:
            payload=json.dumps(result).encode()
            self.send_response(status); self.send_header('Content-Type','application/json'); self.send_header('Content-Length',str(len(payload))); self.send_header('Cache-Control','no-store'); self.send_header('X-Content-Type-Options','nosniff'); self.end_headers(); self.wfile.write(payload)
        except (BrokenPipeError,ConnectionResetError,ssl.SSLError,TimeoutError,MemoryError): pass
        finally:
            if transfer_acquired:self.server.transfer_slot.release()

class Server(ThreadingHTTPServer):
    daemon_threads=True; request_queue_size=64
    def __init__(self,address,app,context):
        self.app=app; self.transfer_slot=threading.BoundedSemaphore(1); self.slots=threading.BoundedSemaphore(64); self.context=context
        self.retention_stop=threading.Event()
        super().__init__(address,Handler)
        self.app.expire_attachments()
        self.retention_worker=threading.Thread(target=self._retention_loop,daemon=True,name='OfficeLink-retention')
        self.retention_worker.start()
    def _retention_loop(self):
        while not self.retention_stop.wait(60):
            try:self.app.expire_attachments()
            except sqlite3.Error:pass  # A later request/tick retries; never bypass database errors.
    def server_close(self):
        self.retention_stop.set()
        worker=getattr(self,'retention_worker',None)
        if worker is not None:worker.join(timeout=10)
        super().server_close()
    def get_request(self):
        sock,addr=super().get_request(); sock.settimeout(10)
        try: return self.context.wrap_socket(sock,server_side=True,do_handshake_on_connect=False),addr
        except Exception: sock.close(); raise
    def process_request(self,request,address):
        if not self.slots.acquire(blocking=False): request.close(); return
        try: super().process_request(request,address)
        except Exception: self.slots.release(); raise
    def process_request_thread(self,request,address):
        try:
            request.do_handshake()
            super().process_request_thread(request,address)
        except (OSError, ssl.SSLError):
            self.shutdown_request(request)
        finally: self.slots.release()

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--host',required=True,help='Specific LAN IPv4 address (never internet-facing)'); p.add_argument('--port',type=int,default=8443); p.add_argument('--data',default='data'); p.add_argument('--cert',required=True); p.add_argument('--key',required=True); p.add_argument('--max-file-mib',type=int,default=50,choices=range(1,101),metavar='1-100',help='Per-file limit in MiB (default 50); aggregate attachment quota 5 GiB'); args=p.parse_args()
    try:
        host=ipaddress.IPv4Address(args.host)
    except ipaddress.AddressValueError: p.error('Use a numeric RFC1918 LAN IPv4 address or 127.0.0.1 for local tests')
    allowed=host==ipaddress.IPv4Address('127.0.0.1') or any(host in ipaddress.IPv4Network(net) for net in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16'))
    if not allowed: p.error('Only RFC1918 LAN IPv4 or 127.0.0.1 bindings are allowed; no wildcard/public binding')
    from host_lock import HostLock
    if not (Path(args.data)/'office.db').is_file(): p.error('Create an administrator with admin.py first')
    with HostLock(args.data):
        app=App(args.data,max_file_bytes=args.max_file_mib*1024*1024); server=None
        try:
            if not app.db.execute('SELECT 1 FROM users WHERE enabled=1 AND role="admin"').fetchone(): p.error('Create an administrator with admin.py first')
            context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); context.minimum_version=ssl.TLSVersion.TLSv1_2; context.load_cert_chain(args.cert,args.key)
            server=Server((args.host,args.port),app,context); server.daemon_threads=False
            print(f'Office Link HTTPS listening on {args.host}:{args.port}. Ctrl+C to stop.')
            try: server.serve_forever()
            except KeyboardInterrupt: pass
        finally:
            if server is not None: server.server_close()
            app.db.close()

if __name__=='__main__': main()
