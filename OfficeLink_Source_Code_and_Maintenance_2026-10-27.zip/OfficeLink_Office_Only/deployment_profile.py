"""IT provisioned connection identity. No runtime server/CA override or saved secrets.

An embedded profile is only as authentic as the application package delivering it.
Its digest is a settings namespace, NOT a signature or an independent trust anchor.
"""
import hashlib
import ipaddress
import json
import os
from pathlib import Path
import re
import ssl
import sys
from urllib.parse import urlsplit

# Static optional import lets PyInstaller collect IT's generated module into PYZ.
try:
    from office_profile import PROFILE as _EMBEDDED_PROFILE
except ModuleNotFoundError as exc:
    if exc.name != 'office_profile':
        raise
    _EMBEDDED_PROFILE = None


def validate_profile(value):
    if not isinstance(value, dict) or set(value) != {'version', 'server', 'ca_pem', 'organization'}:
        raise ValueError('Office profile has an invalid schema. Ask IT for a fresh application package.')
    if type(value['version']) is not int or value['version'] != 1:
        raise ValueError('Unsupported office profile version.')
    server, pem, organization = (value[k] for k in ('server', 'ca_pem', 'organization'))
    if not all(isinstance(x, str) for x in (server, pem, organization)):
        raise ValueError('Office profile fields must be text.')
    if not 1 <= len(organization.strip()) <= 80 or any(ord(c) < 32 for c in organization):
        raise ValueError('Organization must contain 1–80 printable characters.')
    if len(server) > 300 or any(c.isspace() for c in server):
        raise ValueError('Invalid office server address.')
    parsed = urlsplit(server)
    try:
        port = parsed.port
    except ValueError:
        raise ValueError('Invalid office server port.') from None
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.path not in ('','/') or parsed.query or parsed.fragment:
        raise ValueError('Use an HTTPS server origin without credentials, path, query or fragment.')
    if port is not None and not 1 <= port <= 65535:
        raise ValueError('Invalid office server port.')
    host = parsed.hostname
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        # DNS names are provisioned by IT; TLS still verifies the hostname and selected private CA.
        if len(host) > 253 or not all(re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?',label) for label in host.rstrip('.').split('.')):
            raise ValueError('Invalid office DNS name.')
    else:
        private_v4 = isinstance(address, ipaddress.IPv4Address) and (address == ipaddress.IPv4Address('127.0.0.1') or any(address in ipaddress.IPv4Network(net) for net in ('10.0.0.0/8','172.16.0.0/12','192.168.0.0/16')))
        if not private_v4:
            raise ValueError('Numeric endpoints must be an RFC1918 office IPv4 address or 127.0.0.1 for a local pilot.')
    if len(pem) > 20000 or 'PRIVATE KEY' in pem or pem.count('-----BEGIN CERTIFICATE-----') != 1 or pem.count('-----END CERTIFICATE-----') != 1:
        raise ValueError('Supply exactly one public CA certificate, never a private key or chain bundle.')
    if not re.fullmatch(r'\s*-----BEGIN CERTIFICATE-----\s+[A-Za-z0-9+/=\s]+-----END CERTIFICATE-----\s*',pem):
        raise ValueError('Invalid public CA certificate PEM.')
    try:
        # Explicit cadata means no system trust store is loaded by create_default_context.
        context = ssl.create_default_context(cadata=pem)
        context.verify_flags |= ssl.VERIFY_X509_STRICT
        der = ssl.PEM_cert_to_DER_cert(pem.strip())
    except (ssl.SSLError, ValueError):
        raise ValueError('The public CA certificate cannot be loaded.') from None
    normalized = {'server':server.rstrip('/'), 'ca_pem':pem.strip()+'\n', 'organization':organization.strip()}
    # Stable, nonsecret preference namespace, NOT proof of who supplied this profile.
    normalized['profile_id'] = hashlib.sha256((normalized['server']+'\0'+normalized['organization']).encode()+der).hexdigest()
    return normalized


def load_profile():
    """Return the IT embedded profile, or None when this build is not provisioned."""
    if _EMBEDDED_PROFILE is None:
        return None
    return validate_profile(_EMBEDDED_PROFILE)


def _preferences_path():
    if sys.platform == 'win32':
        base = os.environ.get('APPDATA') or str(Path.home()/'AppData'/'Roaming')
    else:
        base = os.environ.get('XDG_CONFIG_HOME') or str(Path.home()/'.config')
    return Path(base)/'OfficeLink'/'preferences.json'


DEFAULT_PREFERENCES = {'username':'', 'remember_username':True,
    'notifications_enabled':True, 'sound_enabled':False, 'minimize_to_tray':False}


def _validated_preferences(value):
    if not isinstance(value,dict) or set(value)-set(DEFAULT_PREFERENCES):
        raise ValueError('Unsupported preference; secrets and connection settings cannot be saved.')
    result=dict(DEFAULT_PREFERENCES)
    for key,setting in value.items():
        if key=='username':
            if not isinstance(setting,str) or not re.fullmatch(r'[A-Za-z0-9_.-]{0,40}',setting):
                raise ValueError('Invalid username preference.')
        elif type(setting) is not bool:
            raise ValueError('Notification and interface preferences must be true or false.')
        result[key]=setting
    if not result['remember_username']:
        result['username']=''
    return result


def load_preferences(profile):
    try:
        path=_preferences_path()
        if path.stat().st_size>65536:
            return dict(DEFAULT_PREFERENCES)
        data=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data,dict) or set(data)!={'version','profiles'} or data['version']!=1:
            return dict(DEFAULT_PREFERENCES)
        return _validated_preferences(data['profiles'].get(profile['profile_id'],{}))
    except (OSError,ValueError,TypeError,AttributeError,KeyError):
        return dict(DEFAULT_PREFERENCES)


def save_preferences(profile, **changes):
    """Strict allowlist: nonsecret username/UI choices only, never credentials or CA."""
    identifier=profile.get('profile_id','')
    if not re.fullmatch(r'[a-f0-9]{64}',identifier):
        raise ValueError('Invalid profile preference identifier.')
    # Validate before merging: unknown/password/token fields are never silently retained.
    _validated_preferences(changes)
    current=load_preferences(profile);current.update(changes)
    current=_validated_preferences(current)
    data={'version':1,'profiles':{identifier:current}}
    path=_preferences_path();path.parent.mkdir(parents=True,exist_ok=True)
    import tempfile
    temporary=None
    try:
        with tempfile.NamedTemporaryFile(mode='w',encoding='utf-8',dir=path.parent,
                prefix='preferences-',suffix='.tmp',delete=False) as stream:
            temporary=Path(stream.name);json.dump(data,stream,indent=2)
        os.replace(temporary,path)
    finally:
        if temporary is not None:
            try:temporary.unlink(missing_ok=True)
            except OSError:pass


def load_username(profile):
    return load_preferences(profile)['username']


def save_username(profile, value):
    save_preferences(profile,username=value)
