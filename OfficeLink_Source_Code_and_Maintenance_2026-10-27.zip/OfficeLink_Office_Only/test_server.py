"""Real loopback HTTPS integration tests; no Windows/audio-hardware claims."""
import base64
import concurrent.futures
import socket
import subprocess
import sys
from unittest.mock import patch
import datetime
import ipaddress
import http.client
import json
from pathlib import Path
import secrets
import shutil
import ssl
import tempfile
import threading
import time
import unittest
import urllib.error
import urllib.request
from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID
from server import App, Server, MAX_FILE, password_hash

class IntegrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cert_temp=tempfile.TemporaryDirectory()
        root=Path(cls.cert_temp.name)
        key=rsa.generate_private_key(public_exponent=65537,key_size=2048)
        name=x509.Name([x509.NameAttribute(NameOID.COMMON_NAME,'Ephemeral test localhost')])
        now=datetime.datetime.now(datetime.timezone.utc)
        cert=(x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key()).serial_number(x509.random_serial_number()).not_valid_before(now-datetime.timedelta(minutes=1)).not_valid_after(now+datetime.timedelta(hours=1)).add_extension(x509.BasicConstraints(ca=True,path_length=None),critical=True).add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()),critical=False).add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(key.public_key()),critical=False).add_extension(x509.KeyUsage(digital_signature=True,content_commitment=False,key_encipherment=True,data_encipherment=False,key_agreement=False,key_cert_sign=True,crl_sign=True,encipher_only=False,decipher_only=False),critical=True).add_extension(x509.SubjectAlternativeName([x509.IPAddress(ipaddress.ip_address('127.0.0.1'))]),critical=False).sign(key,hashes.SHA256()))
        cls.cert=root/'cert.pem'; cls.key=root/'key.pem'
        cls.cert.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        cls.key.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()))
        cls.context=ssl.create_default_context(cafile=str(cls.cert))
    @classmethod
    def tearDownClass(cls): cls.cert_temp.cleanup()
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.password=secrets.token_urlsafe(20)
        self.app=App(self.temp.name)
        for username,role in [('alice','admin'),('bob','staff'),('eve','staff')]: self.app.add_user(username,username.title(),self.password,role)
        self.start(); self.tokens={}; self.ids={}
        for name in ('alice','bob','eve'):
            _,body=self.api('POST','/login',{'username':name,'password':self.password})
            self.tokens[name]=body['token']; self.ids[name]=body['user']['id']
    def start(self):
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); context.minimum_version=ssl.TLSVersion.TLSv1_2; context.load_cert_chain(self.cert,self.key)
        self.server=Server(('127.0.0.1',0),self.app,context); self.url='https://127.0.0.1:'+str(self.server.server_port)
        self.thread=threading.Thread(target=self.server.serve_forever,daemon=True); self.thread.start()
    def stop(self): self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=5)
    def tearDown(self): self.stop(); self.app.db.close(); self.temp.cleanup()
    def api(self,method,path,body=None,user=None,token=None):
        headers={'Content-Type':'application/json'}
        if user: token=self.tokens[user]
        if token: headers['Authorization']='Bearer '+token
        req=urllib.request.Request(self.url+path,json.dumps(body).encode() if body is not None else None,headers,method=method)
        try:
            with urllib.request.urlopen(req,context=self.context,timeout=10) as r: return r.status,json.load(r)
        except urllib.error.HTTPError as e: return e.code,json.load(e)
    def conversation(self,members=('bob',)):
        code,body=self.api('POST','/conversations',{'name':'Test room','members':[self.ids[x] for x in members]},'alice')
        self.assertEqual(code,200); return body['id']
    def call(self):
        code,body=self.api('POST','/calls',{'peer_id':self.ids['bob']},'alice'); self.assertEqual(code,200); return body['call']['id']
    def test_tls_untrusted_certificate_rejected(self):
        with self.assertRaises(urllib.error.URLError): urllib.request.urlopen(self.url+'/users',context=ssl.create_default_context(),timeout=5)
        with self.assertRaises(urllib.error.URLError): urllib.request.urlopen(self.url.replace('127.0.0.1','localhost')+'/users',context=self.context,timeout=5)
        self.assertEqual(self.api('GET','/users',user='alice')[0],200)
    def test_auth_logout_expiry_and_no_password_in_roster(self):
        self.assertEqual(self.api('GET','/users')[0],401)
        self.assertEqual(self.api('GET','/users',token='bogus')[0],401)
        code,body=self.api('GET','/users',user='alice'); self.assertEqual(code,200)
        self.assertTrue(all('password' not in u for u in body['users']))
        self.assertTrue(all(u['online'] for u in body['users']))
        self.api('POST','/logout',{},'bob'); self.assertEqual(self.api('GET','/users',user='bob')[0],401)
        with self.app.lock: self.app.sessions[self.tokens['eve']]['started']-=8*3600+1
        self.assertEqual(self.api('GET','/users',user='eve')[0],401)
    def test_disabled_user_and_login_rate_limit(self):
        with self.app.lock,self.app.db: self.app.db.execute('UPDATE users SET enabled=0 WHERE id=?',(self.ids['bob'],))
        self.assertEqual(self.api('GET','/users',user='bob')[0],401)
        for i in range(8): self.assertEqual(self.api('POST','/login',{'username':'alice','password':'wrong'})[0],401)
        self.assertEqual(self.api('POST','/login',{'username':'alice','password':self.password})[0],429)
    def test_private_message_authorization_and_cursor(self):
        cid=self.conversation()
        code,body=self.api('POST','/messages',{'conversation_id':cid,'text':'Hello, colleague'},'alice'); self.assertEqual(code,200)
        mid=body['id']; code,body=self.api('GET',f'/messages?conversation_id={cid}',user='bob'); self.assertEqual(body['messages'][0]['text'],'Hello, colleague')
        self.assertEqual(body['messages'][0]['sender_name'],'Alice')
        self.assertEqual(self.api('GET',f'/messages?conversation_id={cid}&after={mid}',user='bob')[1]['messages'],[])
        self.assertEqual(self.api('GET',f'/messages?conversation_id={cid}',user='eve')[0],403)
        self.assertEqual(self.api('POST','/messages',{'conversation_id':cid,'text':'intrusion'},'eve')[0],403)
        self.assertEqual(self.api('GET','/conversations',user='eve')[1]['conversations'],[])
    def test_group_membership_and_input_validation(self):
        cid=self.conversation(('bob','eve'))
        self.assertEqual(self.api('POST','/messages',{'conversation_id':cid,'text':'Group hello'},'eve')[0],200)
        self.assertEqual(self.api('POST','/messages',{'conversation_id':cid,'text':'x'*4001},'alice')[0],400)
        self.assertEqual(self.api('POST','/conversations',{'name':'Bad','members':[99999]},'alice')[0],400)
        self.assertEqual(self.api('POST','/conversations',{'name':'Bad','members':['nonnumeric']},'alice')[0],400)
    def test_conversation_summaries_count_only_incoming_for_requester(self):
        cid=self.conversation()
        self.api('POST','/messages',{'conversation_id':cid,'text':'Incoming one'},'bob')
        self.api('POST','/messages',{'conversation_id':cid,'text':'Incoming two'},'bob')
        self.api('POST','/messages',{'conversation_id':cid,'text':'Own latest message'},'alice')
        alice=self.api('GET','/conversations',user='alice')[1]['conversations'][0]
        bob=self.api('GET','/conversations',user='bob')[1]['conversations'][0]
        self.assertEqual(alice['message_count'],3);self.assertEqual(alice['incoming_count'],2)
        self.assertEqual(alice['latest_text'],'Own latest message')
        self.assertEqual(alice['latest_incoming_text'],'Incoming two')
        self.assertEqual(alice['latest_incoming_sender_name'],'Bob')
        self.assertEqual(bob['incoming_count'],1)
        self.assertEqual(self.api('GET','/conversations',user='eve')[1]['conversations'],[])

    def test_files_roundtrip_and_authorization(self):
        cid=self.conversation(); raw=b'%PDF-test\x00\xff'+secrets.token_bytes(100)
        code,body=self.api('POST','/uploads',{'conversation_id':cid,'name':'internal.pdf','data':base64.b64encode(raw).decode()},'alice'); self.assertEqual(code,200)
        fid=body['file_id']; code,body=self.api('GET','/files/'+fid,user='bob'); self.assertEqual(code,200); self.assertEqual(base64.b64decode(body['data']),raw)
        self.assertEqual(body['name'],'internal.pdf'); self.assertEqual(self.api('GET','/files/'+fid,user='eve')[0],403)
        self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':'a.txt','data':'eA=='},'eve')[0],403)
    def test_unsafe_upload_names_and_invalid_payload(self):
        cid=self.conversation()
        for name in ['../escape.pdf','a\\b.pdf','a.exe','C:a.pdf','a\x00.pdf','a\n.pdf']:
            with self.subTest(name=name): self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':name,'data':'eA=='},'alice')[0],400)
        self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':'x.pdf','data':'not base64!'},'alice')[0],400)
        self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':'x.pdf','data':''},'alice')[0],413)
    def test_upload_size_limit(self):
        cid=self.conversation(); data=base64.b64encode(b'x'*(MAX_FILE+1)).decode()
        self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':'large.pdf','data':data},'alice')[0],413)
    def test_restart_persists_messages_files_not_sessions(self):
        cid=self.conversation(); self.api('POST','/messages',{'conversation_id':cid,'text':'Persistent message'},'alice')
        fid=self.api('POST','/uploads',{'conversation_id':cid,'name':'a.txt','data':'aGVsbG8='},'alice')[1]['file_id']
        self.stop(); self.app.db.close(); self.app=App(self.temp.name); self.start()
        self.assertEqual(self.api('GET','/users',user='alice')[0],401)
        self.tokens['alice']=self.api('POST','/login',{'username':'alice','password':self.password})[1]['token']
        self.assertEqual(self.api('GET',f'/messages?conversation_id={cid}',user='alice')[1]['messages'][0]['text'],'Persistent message')
        self.assertEqual(self.api('GET','/files/'+fid,user='alice')[1]['data'],'aGVsbG8=')
    def test_call_consent_authorization_and_busy(self):
        cid=self.call()
        self.assertEqual(self.api('GET','/calls',user='bob')[1]['calls'][0]['status'],'ringing')
        self.assertEqual(self.api('POST',f'/calls/{cid}/audio',{'data':'AAA='},'alice')[0],409)
        self.assertEqual(self.api('POST',f'/calls/{cid}/accept',{},'alice')[0],409)
        self.assertEqual(self.api('POST',f'/calls/{cid}/accept',{},'eve')[0],403)
        self.assertEqual(self.api('POST','/calls',{'peer_id':self.ids['bob']},'eve')[0],409)
        self.assertEqual(self.api('POST',f'/calls/{cid}/accept',{},'bob')[0],200)
        self.assertEqual(self.api('GET',f'/calls/{cid}/audio',user='eve')[0],403)
    def test_pcm_audio_bidirectional_roundtrip_and_end(self):
        cid=self.call(); self.api('POST',f'/calls/{cid}/accept',{},'bob')
        # PCM16 mono 16 kHz synthetic samples; not microphone/speaker validation.
        for sender,recipient in [('alice','bob'),('bob','alice')]:
            pcm=b'\x00\x00\xff\x7f\x00\x80'*100
            self.assertEqual(self.api('POST',f'/calls/{cid}/audio',{'data':base64.b64encode(pcm).decode()},sender)[0],200)
            frames=self.api('GET',f'/calls/{cid}/audio',user=recipient)[1]['frames']; self.assertEqual([base64.b64decode(f) for f in frames],[pcm])
            self.assertEqual(self.api('GET',f'/calls/{cid}/audio',user=recipient)[1]['frames'],[])
        self.api('POST',f'/calls/{cid}/end',{},'alice')
        self.assertEqual(self.api('GET','/calls',user='bob')[1]['calls'],[])
        self.assertEqual(self.api('POST',f'/calls/{cid}/audio',{'data':'AAA='},'bob')[0],409)
    def test_media_bounds_queue_and_timeout(self):
        cid=self.call(); self.api('POST',f'/calls/{cid}/accept',{},'bob')
        for i in range(25): self.assertEqual(self.api('POST',f'/calls/{cid}/audio',{'data':base64.b64encode(i.to_bytes(2,'little')).decode()},'alice')[0],200)
        frames=self.api('GET',f'/calls/{cid}/audio',user='bob')[1]['frames']; self.assertEqual(len(frames),20); self.assertEqual(base64.b64decode(frames[0]),(5).to_bytes(2,'little'))
        for raw in (b'x',b'x'*16002): self.assertEqual(self.api('POST',f'/calls/{cid}/audio',{'data':base64.b64encode(raw).decode()},'alice')[0],400)
        with self.app.lock: self.app.calls[cid]['updated']-=46
        self.assertEqual(self.api('GET','/calls',user='alice')[1]['calls'],[])
    def test_request_limits_before_reading_large_body(self):
        for path,length,token,expected in [('/uploads',14000000,None,401),('/login',5000,None,413),('/messages',100000,self.tokens['alice'],413)]:
            with self.subTest(path=path):
                conn=http.client.HTTPSConnection('127.0.0.1',self.server.server_port,context=self.context,timeout=3)
                try:
                    conn.putrequest('POST',path); conn.putheader('Content-Length',str(length))
                    if token: conn.putheader('Authorization','Bearer '+token)
                    conn.endheaders()  # Deliberately no body: rejection must happen before a read.
                    response=conn.getresponse(); self.assertEqual(response.status,expected); response.read()
                finally: conn.close()
    def test_aggregate_upload_quota(self):
        cid=self.conversation()
        with patch('server.MAX_STORAGE',5):
            self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':'a.txt','data':'aGVsbG8='},'alice')[0],200)
            self.assertEqual(self.api('POST','/uploads',{'conversation_id':cid,'name':'b.txt','data':'eA=='},'alice')[0],507)
        self.assertEqual(self.app.db.execute('SELECT count(*) FROM files').fetchone()[0],1)
    def test_password_change_revokes_existing_sessions(self):
        new_password=secrets.token_urlsafe(24)
        with self.app.lock,self.app.db: self.app.db.execute('UPDATE users SET password=? WHERE id=?',(password_hash(new_password),self.ids['alice']))
        self.assertEqual(self.api('GET','/users',user='alice')[0],401)
        self.assertEqual(self.api('POST','/login',{'username':'alice','password':self.password})[0],401)
        self.assertEqual(self.api('POST','/login',{'username':'alice','password':new_password})[0],200)
    def test_public_wildcard_and_hostname_bind_rejected(self):
        for host in ('0.0.0.0','8.8.8.8','::','example.com'):
            with self.subTest(host=host):
                result=subprocess.run([sys.executable,str(Path(__file__).with_name('server.py')),'--host',host,'--cert','unused.pem','--key','unused.pem','--data',self.temp.name],capture_output=True,text=True,timeout=5)
                self.assertEqual(result.returncode,2)
                self.assertNotIn('Traceback',result.stderr)
    def test_logout_ends_call_and_single_peer_timeout(self):
        cid=self.call(); self.api('POST',f'/calls/{cid}/accept',{},'bob')
        with self.app.lock: self.app.calls[cid]['seen'][self.ids['bob']]-=46
        self.assertEqual(self.api('GET','/calls',user='alice')[1]['calls'],[])
        cid=self.call(); self.api('POST',f'/calls/{cid}/accept',{},'bob')
        self.api('POST','/logout',{},'bob')
        self.assertEqual(self.api('GET','/calls',user='alice')[1]['calls'],[])
    def test_twenty_concurrent_clients_smoke(self):
        # 20 isolated sessions, concurrent TLS requests on one cloud loopback host.
        members=[]
        tokens=[]
        for i in range(20):
            username=f'staff{i}'
            self.app.add_user(username,username,self.password)
            code,body=self.api('POST','/login',{'username':username,'password':self.password})
            self.assertEqual(code,200); members.append(body['user']['id']); tokens.append(body['token'])
        code,body=self.api('POST','/conversations',{'name':'Concurrency smoke','members':members},'alice')
        self.assertEqual(code,200); cid=body['id']
        gate=threading.Barrier(20)
        def worker(index):
            gate.wait(timeout=10)
            return self.api('POST','/messages',{'conversation_id':cid,'text':f'Concurrent client {index}'},token=tokens[index])[0]
        with concurrent.futures.ThreadPoolExecutor(max_workers=20) as pool:
            statuses=list(pool.map(worker,range(20)))
        self.assertEqual(statuses,[200]*20)
        messages=self.api('GET',f'/messages?conversation_id={cid}',user='alice')[1]['messages']
        self.assertEqual(len(messages),20)
        self.assertEqual(len({m['sender_id'] for m in messages}),20)
    def test_stalled_tls_handshake_does_not_block_accept(self):
        stalled=socket.create_connection(('127.0.0.1',self.server.server_port),timeout=5)
        try:
            before=time.monotonic()
            self.assertEqual(self.api('GET','/users',user='alice')[0],200)
            self.assertLess(time.monotonic()-before,5)
        finally: stalled.close()
    def test_offline_backup_restore(self):
        cid=self.conversation(); self.api('POST','/messages',{'conversation_id':cid,'text':'Restore me'},'alice')
        self.stop(); self.app.db.close()
        with tempfile.TemporaryDirectory() as backup:
            shutil.copytree(self.temp.name,Path(backup)/'data')
            restored=App(Path(backup)/'data')
            self.assertEqual(restored.db.execute('SELECT text FROM messages').fetchone()[0],'Restore me'); restored.db.close()
        self.app=App(self.temp.name); self.start()

if __name__=='__main__': unittest.main(verbosity=2)
