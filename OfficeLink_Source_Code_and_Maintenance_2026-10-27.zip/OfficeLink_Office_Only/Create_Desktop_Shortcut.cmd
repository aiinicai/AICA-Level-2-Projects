@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3 OfficeLink.py --shortcut-only
) else (
    python OfficeLink.py --shortcut-only
)
if errorlevel 1 (
    echo.
    echo Shortcut setup could not finish. Check the error above.
    pause
)
