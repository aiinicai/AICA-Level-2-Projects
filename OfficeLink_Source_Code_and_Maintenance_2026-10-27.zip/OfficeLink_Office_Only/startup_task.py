"""Prepare a Windows task XML; Windows handles account credentials at import."""
import csv
import io
import os
from pathlib import Path
import re
import subprocess
import sys
import xml.etree.ElementTree as ET


def task_xml(root, interpreter, user_sid):
    root = Path(root).resolve()
    interpreter = Path(interpreter)
    if interpreter.name.lower() == 'pythonw.exe':
        interpreter = interpreter.with_name('python.exe')
    if not re.fullmatch(r'S-1-(?:\d+-)+\d+', user_sid):
        raise ValueError('A valid Windows account SID is required.')
    if not interpreter.is_file(): raise FileNotFoundError('The Python runtime cannot be found.')
    for name in ('server_runner.py', 'host_config.json'):
        if not (root / name).is_file(): raise FileNotFoundError('Missing ' + name)
    namespace = 'http://schemas.microsoft.com/windows/2004/02/mit/task'
    ET.register_namespace('', namespace)
    def add(parent, name, value=None, **attrs):
        item = ET.SubElement(parent, '{'+namespace+'}'+name, attrs)
        if value is not None: item.text = str(value)
        return item
    task = ET.Element('{'+namespace+'}Task', version='1.2')
    info = add(task, 'RegistrationInfo')
    add(info, 'Description', 'OfficeLink office LAN host. Configuration: '+str(root / 'host_config.json'))
    trigger = add(add(task, 'Triggers'), 'BootTrigger')
    add(trigger, 'Enabled', 'true'); add(trigger, 'Delay', 'PT30S')
    principal = add(add(task, 'Principals'), 'Principal', id='Author')
    add(principal, 'UserId', user_sid)
    add(principal, 'LogonType', 'Password'); add(principal, 'RunLevel', 'LeastPrivilege')
    settings = add(task, 'Settings')
    for name, value in (
        ('MultipleInstancesPolicy','IgnoreNew'), ('DisallowStartIfOnBatteries','false'),
        ('StopIfGoingOnBatteries','false'), ('AllowHardTerminate','true'),
        ('StartWhenAvailable','true'), ('RunOnlyIfNetworkAvailable','false'),
        ('AllowStartOnDemand','true'), ('Enabled','true'), ('Hidden','false'),
        ('RunOnlyIfIdle','false'), ('WakeToRun','false'), ('ExecutionTimeLimit','PT0S'),
        ('Priority','7')): add(settings, name, value)
    restart = add(settings, 'RestartOnFailure')
    add(restart, 'Interval', 'PT1M'); add(restart, 'Count', '10')
    execute = add(add(task, 'Actions', Context='Author'), 'Exec')
    add(execute, 'Command', str(interpreter))
    # Windows argv quoting only; no shell or command substitution is involved.
    add(execute, 'Arguments', subprocess.list2cmdline([
        str(root / 'server_runner.py'), '--config', str(root / 'host_config.json')]))
    add(execute, 'WorkingDirectory', str(root))
    ET.indent(task)
    return ET.tostring(task, encoding='utf-16', xml_declaration=True)


def prepare_task(root, destination):
    if os.name != 'nt': raise RuntimeError('Prepare this task on the Windows host computer.')
    from server_runner import load_config, check_database
    root = Path(root).resolve()
    check_database(load_config(root / 'host_config.json'))
    # A fixed executable/arguments request a SID; no username is inferred from
    # a screenshot, profile directory, or localized command output headings.
    system = Path(os.environ['SystemRoot']) / 'System32'
    result = subprocess.run([str(system / 'whoami.exe'), '/user', '/fo', 'csv', '/nh'],
        capture_output=True, text=True, errors='replace', check=True, timeout=10,
        creationflags=subprocess.CREATE_NO_WINDOW)
    rows = list(csv.reader(io.StringIO(result.stdout.strip())))
    if len(rows) != 1 or len(rows[0]) != 2: raise RuntimeError('Cannot identify the Windows task account.')
    blob = task_xml(root, sys.executable, rows[0][1])
    with Path(destination).open('xb') as stream: stream.write(blob)
    return ('Startup task file saved. Import it in Windows Task Scheduler using '
            'SERVER_MIGRATION.html. Automatic startup is not installed until that step is completed.')
