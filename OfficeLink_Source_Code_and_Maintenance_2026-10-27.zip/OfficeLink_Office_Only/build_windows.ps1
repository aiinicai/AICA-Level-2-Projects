# OfficeLink: explicitly invoked, local Windows client build only.
# No downloads, dependency installation, certificate generation, server or network changes.
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

Push-Location $PSScriptRoot
try {
    if ($env:OS -ne 'Windows_NT') { throw 'Build this Windows client on Windows, not Linux/macOS.' }
    $python = Join-Path $PSScriptRoot '.venv\Scripts\python.exe'
    if (-not (Test-Path -LiteralPath $python -PathType Leaf)) {
        throw 'The project .venv was not found. Ask IT to prepare the approved Windows Python environment first.'
    }
    $profile = Join-Path $PSScriptRoot 'deployment\profile.json'
    $module = Join-Path $PSScriptRoot 'deployment\office_profile.py'
    if (-not (Test-Path -LiteralPath $profile -PathType Leaf) -or -not (Test-Path -LiteralPath $module -PathType Leaf)) {
        throw 'Missing IT deployment profile. Run create_profile.py with the approved endpoint and existing PUBLIC CA first.'
    }
    # Never silently install dependencies. This is a build-machine preflight only.
    & $python -c "import sys, struct; assert sys.platform == 'win32' and struct.calcsize('P') == 8, 'Use the approved 64-bit Windows Python environment'; import PyInstaller, PyQt6.QtWidgets, sounddevice, _cffi_backend; print('Build dependencies available; PyInstaller ' + PyInstaller.__version__)"
    if ($LASTEXITCODE -ne 0) {
        throw 'Build dependencies unavailable. With explicit approval, install PyInstaller and pyinstaller-hooks-contrib into this .venv, then retry. No installation was attempted.'
    }
    # Checks CA/endpoint/schema and that the embedded Python module matches its review copy.
    & $python create_profile.py --check $profile
    if ($LASTEXITCODE -ne 0) { throw 'Profile validation failed. No build attempted.' }

    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $work = Join-Path $PSScriptRoot ('.staff-build\' + $stamp)
    $dist = Join-Path $PSScriptRoot ('staff-dist\' + $stamp)
    if ((Test-Path -LiteralPath $work) -or (Test-Path -LiteralPath $dist)) {
        throw 'This build output already exists. Wait a moment and run again; existing output was not overwritten.'
    }
    New-Item -ItemType Directory -Path $work | Out-Null
    Write-Host 'Building the staff client. The public profile is embedded as Python bytecode, not a replaceable JSON data file.'
    Write-Host 'No server, database, private key, password, certificate folder or whole-project data is added.'
    $arguments = @(
        '-m', 'PyInstaller', '--onedir', '--windowed', '--noupx',
        '--name', 'OfficeLink', '--paths', (Join-Path $PSScriptRoot 'deployment'),
        '--hidden-import', 'office_profile', '--hidden-import', 'sounddevice',
        '--hidden-import', '_cffi_backend', '--distpath', $dist,
        '--workpath', (Join-Path $work 'work'), '--specpath', $work,
        (Join-Path $PSScriptRoot 'client.py')
    )
    & $python @arguments
    if ($LASTEXITCODE -ne 0) { throw 'PyInstaller failed. Review its output; do not distribute this build.' }
    $bundle = Join-Path $dist 'OfficeLink'
    $executable = Join-Path $bundle 'OfficeLink.exe'
    if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) { throw 'Expected OfficeLink.exe was not produced.' }
    $portaudio = @(Get-ChildItem -LiteralPath $bundle -Recurse -File -Filter 'libportaudio*.dll')
    if ($portaudio.Count -eq 0) { throw 'PortAudio DLL missing from bundle. Do not distribute; inspect the sounddevice hook/build warnings.' }
    $forbidden = @(Get-ChildItem -LiteralPath $bundle -Recurse -File | Where-Object {
        $_.Name -match '^(office\.db(?:-wal|-shm)?|server-key\.pem|ca-key\.pem|profile\.json|office_profile\.py)$'
    })
    if ($forbidden.Count -gt 0) { throw 'Unexpected project data/profile/key file in bundle. Do not distribute; inspect its contents.' }
    Write-Host ''
    Write-Host ('Build produced: ' + $executable)
    Write-Host ('Staff need the ENTIRE folder: ' + $bundle)
    Write-Host 'Next: inspect warnings, test this EXE on the pilot, review licensing, sign/package and distribute through your approved IT channel.'
    Write-Host 'This is a portable folder, NOT an installer. Staff run OfficeLink.exe; Python is bundled.'
    Write-Host 'No app launch, network/firewall change, startup entry, installation or distribution was performed.'
}
finally { Pop-Location }
