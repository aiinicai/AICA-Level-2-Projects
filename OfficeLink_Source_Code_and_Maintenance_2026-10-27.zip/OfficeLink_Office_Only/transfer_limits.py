"""Shared bounded document-transfer limits. MiB = 1,048,576 bytes."""
MIB=1024*1024
DEFAULT_MAX_FILE_BYTES=50*MIB
HARD_MAX_FILE_BYTES=100*MIB
LEGACY_MAX_FILE_BYTES=10*MIB
TRANSFER_TIMEOUT=120

def encoded_body_limit(max_file_bytes):
    return 4*((max_file_bytes+2)//3)+8192

def validate_limit(value):
    if type(value) is not int or not MIB<=value<=HARD_MAX_FILE_BYTES:
        raise ValueError('Document limit must be between 1 and 100 MiB.')
    return value
