"""Local host console for OfficeLink. Never distributed in the staff package."""
import ipaddress
import json
import os
from pathlib import Path
import re
import socket
import sqlite3
import ssl
import subprocess
import sys
import threading
import zipfile
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone

from PyQt6.QtCore import QObject, pyqtSignal
from PyQt6.QtWidgets import (QApplication, QDialog, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QLineEdit, QListWidget, QMessageBox, QPushButton,
    QVBoxLayout, QWidget, QSpinBox)

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / 'host_config.json'
STAFF_FILES = ('OfficeLink.py', 'client.py', 'deployment_profile.py',
               'notification_policy.py', 'transfer_limits.py', 'Start_OfficeLink.cmd',
               'desktop_shortcut.py', 'Create_Desktop_Shortcut.cmd', 'officelink.ico')


from host_config import private_host, public_profile, save_config as _save_config

def save_config(config, path=CONFIG):
    return _save_config(config, path)


def suggested_host():
    try:
        for address in socket.gethostbyname_ex(socket.gethostname())[2]:
            try: return private_host(address)
            except ValueError: pass
    except OSError:
        pass
    return ''


def create_office(root, organization, host, port, username, name, password, ca_password):
    from make_cert import generate
    from server import App
    host = private_host(host)
    if not 1024 <= int(port) <= 65535: raise ValueError('Invalid port.')
    if not 1 <= len(organization.strip()) <= 80: raise ValueError('Enter your office name, up to 80 characters.')
    if not re.fullmatch(r'[a-zA-Z0-9_.-]{1,40}', username): raise ValueError('Use letters, numbers, dots, dashes or underscores for the username.')
    if not 1 <= len(name.strip()) <= 80: raise ValueError('Enter a display name.')
    if not 12 <= len(password) <= 256: raise ValueError('The login password must contain 12–256 characters.')
    if len(ca_password) < 12: raise ValueError('The certificate recovery passphrase must contain at least 12 characters.')
    root = Path(root).resolve()
    root.mkdir(parents=True, exist_ok=False)  # Never initializes over an existing office.
    generate(root / 'certs', [host], ca_password)
    app = App(root / 'data')
    try: app.add_user(username, name, password, 'admin')
    finally: app.db.close()
    return {'organization': organization.strip(), 'host': host, 'port': int(port),
            'data': str(root / 'data'), 'ca': str(root / 'certs/ca.pem'),
            'cert': str(root / 'certs/server.pem'), 'key': str(root / 'certs/server-key.pem')}


def export_staff(config, destination, source=ROOT):
    """Explicit allowlist: no globbing, symlinks, databases, keys or saved accounts."""
    from create_profile import module_text
    profile = public_profile(config)
    destination = Path(destination)
    if destination.exists(): raise FileExistsError('Choose a new filename; existing files are not overwritten.')
    for name in STAFF_FILES:
        if not (source / name).is_file() or (source / name).is_symlink():
            raise ValueError('Missing or unsafe staff source file: ' + name)
    archive = zipfile.ZipFile(destination, 'x', compression=zipfile.ZIP_DEFLATED)
    try:
        with archive:
            for name in STAFF_FILES: archive.write(source / name, 'OfficeLink_Staff/' + name)
            archive.writestr('OfficeLink_Staff/office_profile.py', module_text(profile))
            archive.writestr('OfficeLink_Staff/READ_ME.txt',
                'OFFICELINK STAFF\n\nExtract this entire folder to your own computer.\n'
                'Install 64-bit Python 3.11 or later if needed.\n'
                'Open Start_OfficeLink.cmd, or OfficeLink.py in IDLE and press F5.\n'
                'First setup installs the desktop libraries. Internet is needed only for setup, unless IT supplies an offline wheelhouse.\n'
                'The launcher creates your OfficeLink desktop shortcut automatically after setup.\n'
                'To recreate it later, open Create_Desktop_Shortcut.cmd. Keep this folder in its final location.\n'
                'Sign in with the individual username and temporary password supplied by your administrator.\n'
                'Select a colleague under People to chat. Use Attach to send a document.\n'
                'Minimize the application to continue receiving alerts. Quitting stops alerts.\n'
                'Connect to the office Wi-Fi or wired network. Guest Wi-Fi may block access.\n'
                'Do not share your password. Contact your administrator for a reset.\n')
    except Exception:
        destination.unlink(missing_ok=True)
        raise


class HostService:
    def __init__(self): self.server = self.app = self.thread = self.host_lock = None
    def start(self, config):
        if self.server is not None: raise ValueError('The host is already running.')
        from server import App, Server
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(config['cert'], config['key'])
        from host_lock import HostLock
        host_lock = HostLock(config['data']).acquire()
        app = None
        try:
            app = App(config['data'])
            server = Server((private_host(config['host']), int(config['port'])), app, context)
            server.daemon_threads = False  # Finish active requests before closing the DB.
        except Exception:
            if app is not None: app.db.close()
            host_lock.release(); raise
        thread = threading.Thread(target=server.serve_forever, daemon=True, name='OfficeLink-host')
        self.app, self.server, self.thread, self.host_lock = app, server, thread, host_lock
        thread.start()
        return 'Host running. Keep this computer awake and this window open.'
    def stop(self):
        if self.server is not None:
            self.server.shutdown(); self.server.server_close(); self.thread.join()
            self.app.db.close()
            self.host_lock.release(); self.host_lock = None
            self.server = self.app = self.thread = None
        return 'Host stopped. Saved messages and documents remain in the data folder.'


class Bridge(QObject):
    result = pyqtSignal(object, object)


class Fields(QDialog):
    def __init__(self, title, fields, parent=None):
        super().__init__(parent); self.setWindowTitle(title); self.setMinimumWidth(520)
        layout = QVBoxLayout(self); form = QFormLayout(); self.fields = {}
        for key, caption, value, secret in fields:
            edit = QLineEdit(value)
            if secret: edit.setEchoMode(QLineEdit.EchoMode.Password)
            form.addRow(caption, edit); self.fields[key] = edit
        layout.addLayout(form)
        actions = QHBoxLayout(); ok = QPushButton('Continue'); cancel = QPushButton('Cancel')
        ok.clicked.connect(self.accept); cancel.clicked.connect(self.reject)
        actions.addWidget(cancel); actions.addWidget(ok); layout.addLayout(actions)
    def values(self): return {k: v.text() for k, v in self.fields.items()}
    def clear_secrets(self):
        for field in self.fields.values():
            if field.echoMode() == QLineEdit.EchoMode.Password: field.clear()


class HostWindow(QWidget):
    def __init__(self):
        super().__init__(); self.setWindowTitle('OfficeLink · Office host'); self.resize(780, 640)
        self.service = HostService(); self.pool = ThreadPoolExecutor(max_workers=1)
        self.bridge = Bridge(); self.bridge.result.connect(self.finished); self.busy = False
        self.config = json.loads(CONFIG.read_text()) if CONFIG.exists() else None
        layout = QVBoxLayout(self); layout.setContentsMargins(28, 24, 28, 24); layout.setSpacing(15)
        title = QLabel('OfficeLink'); title.setStyleSheet('font-size:30px;font-weight:700;color:#173e74;')
        layout.addWidget(title); layout.addWidget(QLabel('OFFICE NETWORK ONLY  ·  Individual logins  ·  Chat and documents'))
        self.description = QLabel('Set up the host once, then give each colleague the staff package.'); self.description.setWordWrap(True); layout.addWidget(self.description)
        first = QHBoxLayout(); self.new_button = QPushButton('Set up a new office'); self.existing_button = QPushButton('Use existing host setup')
        self.new_button.clicked.connect(self.new_office); self.existing_button.clicked.connect(self.existing)
        first.addWidget(self.new_button); first.addWidget(self.existing_button); layout.addLayout(first)
        self.migrate_button = QPushButton('Move office from another computer')
        self.migrate_button.clicked.connect(self.migrate); layout.addWidget(self.migrate_button)
        row = QHBoxLayout(); self.start_button = QPushButton('Start host'); self.stop_button = QPushButton('Stop host')
        self.start_button.clicked.connect(lambda: self.run(lambda: self.service.start(self.config)))
        self.stop_button.clicked.connect(self.stop_host); row.addWidget(self.start_button); row.addWidget(self.stop_button); layout.addLayout(row)
        self.users = QListWidget(); layout.addWidget(self.users, 1)
        row = QHBoxLayout(); self.add_button = QPushButton('Add employee'); self.reset_button = QPushButton('Reset password'); self.disable_button = QPushButton('Disable selected account')
        for button, fn in [(self.add_button,self.add_user),(self.reset_button,self.reset_password),(self.disable_button,self.disable_user)]:
            button.clicked.connect(fn); row.addWidget(button)
        layout.addLayout(row)
        row = QHBoxLayout(); self.export_button = QPushButton('Create staff ZIP'); self.chat_button = QPushButton('Open my messenger'); self.backup_button = QPushButton('Back up database')
        for button, fn in [(self.export_button,self.export),(self.chat_button,self.chat),(self.backup_button,self.backup)]:
            button.clicked.connect(fn); row.addWidget(button)
        layout.addLayout(row)
        row = QHBoxLayout()
        self.task_button = QPushButton('Prepare Windows startup task')
        self.background_stop_button = QPushButton('Stop background host')
        self.task_button.clicked.connect(self.prepare_startup)
        self.background_stop_button.clicked.connect(self.stop_background)
        row.addWidget(self.task_button); row.addWidget(self.background_stop_button); layout.addLayout(row)
        self.status = QLabel('Ready.'); self.status.setWordWrap(True); layout.addWidget(self.status)
        note = QLabel('This host window controls local accounts. Keep the host folder and Windows account restricted to your administrator.'); note.setWordWrap(True); layout.addWidget(note)
        self.refresh()
    def refresh(self):
        ready = self.config is not None; running = self.service.server is not None
        self.new_button.setEnabled(not ready and not self.busy); self.existing_button.setEnabled(not ready and not self.busy)
        self.migrate_button.setEnabled(not ready and not self.busy)
        self.task_button.setEnabled(ready and not running and not self.busy)
        self.background_stop_button.setEnabled(ready and not running and not self.busy)
        self.start_button.setEnabled(ready and not running and not self.busy); self.stop_button.setEnabled(running and not self.busy)
        for b in (self.add_button,self.reset_button,self.disable_button,self.export_button,self.chat_button,self.backup_button): b.setEnabled(ready and not self.busy)
        self.users.clear()
        if ready:
            self.description.setText(f'{self.config["organization"]}  |  https://{self.config["host"]}:{self.config["port"]}\nData: {self.config["data"]}')
            path = Path(self.config['data'])/'office.db'
            if path.is_file():
                con = sqlite3.connect(path.as_uri()+'?mode=ro', uri=True)
                try:
                    from PyQt6.QtCore import Qt
                    from PyQt6.QtWidgets import QListWidgetItem
                    for uid,name,role,enabled in con.execute('SELECT username,display_name,role,enabled FROM users ORDER BY display_name'):
                        item=QListWidgetItem(f'{name}  ·  {uid}  ·  {role}' + ('  [disabled]' if not enabled else ''))
                        item.setData(Qt.ItemDataRole.UserRole,uid);self.users.addItem(item)
                finally:con.close()
    def run(self, fn, callback=None):
        if self.busy:return
        self.busy=True;self.status.setText('Working…');self.refresh()
        future=self.pool.submit(fn);future.add_done_callback(lambda f:self.bridge.result.emit(f,callback))
    def finished(self, future, callback):
        self.busy=False
        try:
            result=future.result()
            if callback:callback(result)
            self.status.setText(result if isinstance(result,str) else 'Completed.')
        except Exception as exc:
            self.status.setText('Action could not be completed.');QMessageBox.warning(self,'OfficeLink',str(exc))
        self.refresh()
    def new_office(self):
        dialog=Fields('New office host',[
            ('organization','Office name','R & A Group',False),('host','Reserved office IPv4 address',suggested_host(),False),
            ('username','Your login name','',False),('name','Your display name','',False),
            ('password','Your password (12+ characters)','',True),('repeat','Repeat password','',True),
            ('ca_password','Certificate recovery passphrase (12+ characters)','',True),('ca_repeat','Repeat recovery passphrase','',True)],self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        v=dialog.values();dialog.clear_secrets()
        if v.pop('repeat')!=v['password'] or v.pop('ca_repeat')!=v['ca_password']:
            QMessageBox.warning(self,'Passwords','The repeated passwords do not match.');return
        root=ROOT/('host_state_'+datetime.now().strftime('%Y%m%d_%H%M%S'))
        def work():return save_config(create_office(root,port=8443,**v))
        self.run(work,lambda result:setattr(self,'config',result))
    def existing(self):
        dialog=Fields('Use your existing host',[
            ('organization','Office name','R & A Group',False),('host','Existing reserved IPv4 address',suggested_host(),False),
            ('port','Existing HTTPS port','8443',False)],self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        v=dialog.values();data=QFileDialog.getExistingDirectory(self,'Select the existing DATA folder containing office.db')
        if not data:return
        certs=QFileDialog.getExistingDirectory(self,'Select the existing CERTS folder containing ca.pem, server.pem and server-key.pem')
        if not certs:return
        v.update(data=data,ca=str(Path(certs)/'ca.pem'),cert=str(Path(certs)/'server.pem'),key=str(Path(certs)/'server-key.pem'))
        self.run(lambda:save_config(v),lambda result:setattr(self,'config',result))
    def with_database(self, fn):
        from server import App
        if self.service.app is not None:
            with self.service.app.lock:return fn(self.service.app)
        app=App(self.config['data'])
        try:return fn(app)
        finally:app.db.close()
    def migrate(self):
        QMessageBox.information(self, 'Move an existing office',
            'On the OLD host: stop messaging, then use Back up database. Copy that backup to this computer. '
            'Keep the old host stopped during the move.\n\nChoose that database backup next. '
            'The backup includes users, chats and documents. It will not be changed.')
        source,_ = QFileDialog.getOpenFileName(self, 'Select the database backup from the old host', '', 'Database (*.db)')
        if not source: return
        dialog = Fields('New host address', [
            ('organization','Office name','R & A Group',False),
            ('host','New reserved IPv4 address','192.168.70.122',False),
            ('ca_password','New certificate recovery passphrase (12+ characters)','',True),
            ('repeat','Repeat recovery passphrase','',True)], self)
        if dialog.exec() != QDialog.DialogCode.Accepted: return
        values = dialog.values(); dialog.clear_secrets()
        if values.pop('repeat') != values['ca_password']:
            QMessageBox.warning(self,'Passphrase','The passphrases do not match.'); return
        target = ROOT / ('host_state_' + datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
        def work():
            from migrate_host import migrate_backup
            return save_config(migrate_backup(source, target, port=8443, **values))
        def complete(config):
            self.config = config
            QMessageBox.information(self, 'Office copied',
                'Existing accounts, chats and documents have been copied.\n'
                'Use Create staff ZIP to give every employee the new server address and certificate. '
                'Keep using the existing usernames and passwords.\n\nRead SERVER_MIGRATION.html for startup and the reboot test.')
        self.run(work, complete)
    def prepare_startup(self):
        target,_ = QFileDialog.getSaveFileName(self, 'Prepare Windows startup task',
            str(ROOT / 'OfficeLink_Server_Task.xml'), 'Task file (*.xml)')
        if target:
            from startup_task import prepare_task
            self.run(lambda: prepare_task(ROOT, target))
    def stop_background(self):
        if QMessageBox.question(self, 'Stop background host',
            'Disconnect employees and stop the background host? It will start again at the next Windows boot, '
            'or when you choose Run in Task Scheduler.') != QMessageBox.StandardButton.Yes: return
        def work():
            (Path(self.config['data']) / 'background.stop').touch()
            return 'Stop requested. Allow active file transfers to finish (up to about two minutes). Check Task Scheduler before restarting.'
        self.run(work)
    def add_user(self):
        dialog=Fields('Add employee',[
            ('username','Login name','',False),('name','Display name','',False),
            ('password','Temporary password (12+ characters)','',True),('repeat','Repeat temporary password','',True)],self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        v=dialog.values();dialog.clear_secrets()
        if v.pop('repeat')!=v['password']:QMessageBox.warning(self,'Passwords','Passwords do not match.');return
        def work():
            self.with_database(lambda app:app.add_user(**v,must_change_password=True))
            return 'Employee added. Give the temporary password to that employee privately; they must change it at first sign-in.'
        self.run(work)
    def selected_user(self):
        from PyQt6.QtCore import Qt
        item=self.users.currentItem()
        if item is None:QMessageBox.information(self,'Select employee','Select an employee in the list first.');return None
        return item.data(Qt.ItemDataRole.UserRole)
    def reset_password(self):
        username=self.selected_user()
        if not username:return
        dialog=Fields('Reset '+username,[('password','New temporary password','',True),('repeat','Repeat password','',True)],self)
        if dialog.exec()!=QDialog.DialogCode.Accepted:return
        v=dialog.values();dialog.clear_secrets()
        if v['password']!=v['repeat'] or not 12<=len(v['password'])<=256:QMessageBox.warning(self,'Password','Use matching passwords of 12–256 characters.');return
        def update(app):
            from server import password_hash
            with app.db:app.db.execute('UPDATE users SET password=?,must_change_password=1 WHERE username=?',(password_hash(v['password']),username))
        self.run(lambda:(self.with_database(update),'Temporary password set. Existing sessions lose access on their next request.')[1])
    def disable_user(self):
        username=self.selected_user()
        if not username:return
        if QMessageBox.question(self,'Disable account',f'Disable {username}? This blocks their next authenticated request.')!=QMessageBox.StandardButton.Yes:return
        def update(app):
            row=app.db.execute('SELECT role FROM users WHERE username=?',(username,)).fetchone()
            if row and row[0]=='admin' and app.db.execute('SELECT count(*) FROM users WHERE role="admin" AND enabled=1').fetchone()[0]<=1:raise ValueError('The last administrator cannot be disabled.')
            with app.db:app.db.execute('UPDATE users SET enabled=0 WHERE username=?',(username,))
        self.run(lambda:(self.with_database(update),'Account disabled.')[1])
    def export(self):
        target,_=QFileDialog.getSaveFileName(self,'Create a new staff package','OfficeLink_Staff.zip','ZIP archive (*.zip)')
        if target:self.run(lambda:(export_staff(self.config,target),'Staff package created. Distribute this ZIP, never the host folder.')[1])
    def chat(self):
        try:
            from create_profile import module_text
            profile=public_profile(self.config)
            # Public host-specific module, never passwords or private keys.
            (ROOT/'office_profile.py').write_text(module_text(profile),encoding='utf-8')
            subprocess.Popen([sys.executable,str(ROOT/'client.py')],cwd=ROOT)
        except Exception as exc:QMessageBox.warning(self,'Cannot open messenger',str(exc))
    def backup(self):
        target,_=QFileDialog.getSaveFileName(self,'Database backup','OfficeLink_Backup_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.db','Database (*.db)')
        if not target:return
        def work():
            path=Path(target)
            with path.open('xb'):pass
            try:
                con=sqlite3.connect(path)
                try:self.with_database(lambda app:app.db.backup(con))
                finally:con.close()
            except Exception:path.unlink(missing_ok=True);raise
            return 'Database backup saved. Also protect and back up the certificates and host_config.json separately.'
        self.run(work)
    def stop_host(self):
        if QMessageBox.question(self,'Stop office messenger','Stop the host? All employees will disconnect until it is started again.')==QMessageBox.StandardButton.Yes:self.run(self.service.stop)
    def closeEvent(self,event):
        if self.busy:QMessageBox.information(self,'Working','Please wait for the current action to finish.');event.ignore();return
        if self.service.server is not None:
            if QMessageBox.question(self,'Host is running','Closing this window stops messaging for everyone. Stop the host now?')==QMessageBox.StandardButton.Yes:
                self.run(self.service.stop)
            event.ignore();return
        self.pool.shutdown(wait=False);event.accept()


def main(startup_notice=None):
    from client import STYLE
    app=QApplication(sys.argv);app.setStyleSheet(STYLE);app.setApplicationName('OfficeLink Host')
    if startup_notice:QMessageBox.warning(None,'OfficeLink desktop shortcut',startup_notice)
    try:window=HostWindow()
    except Exception as exc:QMessageBox.critical(None,'Host configuration',str(exc));return
    window.show();app.exec()


if __name__=='__main__':main()
