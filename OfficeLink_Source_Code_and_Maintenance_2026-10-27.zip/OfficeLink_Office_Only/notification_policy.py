"""Read-only Windows attention policy. Never changes notification/Focus settings."""
import sys

def _windows_notification_state():
    import ctypes
    state=ctypes.c_int()
    query=ctypes.WinDLL('shell32.dll',use_last_error=True).SHQueryUserNotificationState
    query.argtypes=[ctypes.POINTER(ctypes.c_int)];query.restype=ctypes.c_long
    if query(ctypes.byref(state)) != 0:return None
    return state.value

def attention_allowed():
    """Allow Windows popup/sound/attention only when the shell explicitly permits it.

    Unread badges remain available even when this returns False. Modern Windows
    notification policy may impose further restrictions; no guaranteed delivery.
    """
    if sys.platform!='win32':return True
    try:return _windows_notification_state()==5 # QUNS_ACCEPTS_NOTIFICATIONS
    except (OSError,AttributeError):return False
