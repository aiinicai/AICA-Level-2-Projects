"""Local-only administration: filesystem access is the administrator boundary."""
import argparse, getpass
from server import App

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('--data',default='data'); sub=p.add_subparsers(dest='command',required=True)
    sub.add_parser('init'); add=sub.add_parser('add-user'); add.add_argument('--username',required=True); add.add_argument('--name',required=True); add.add_argument('--role',choices=['staff','admin'],default='staff')
    disable=sub.add_parser('disable-user'); disable.add_argument('--username',required=True); sub.add_parser('list-users')
    reset=sub.add_parser('reset-password'); reset.add_argument('--username',required=True)
    sub.add_parser('retention-status')
    enable=sub.add_parser('enable-retention');enable.add_argument('--confirm-permanent-expiry',action='store_true')
    sub.add_parser('disable-retention')
    args=p.parse_args(); app=App(args.data)
    try:
        if args.command=='retention-status':
            import json
            print(json.dumps(app.storage_status(),indent=2))
        elif args.command=='enable-retention':
            if not args.confirm_permanent_expiry:
                raise ValueError('No retention change made. New uploads will lose server re-download access after 24 hours, even if recipients have not saved them. Existing files, downloaded copies and backups remain untouched. Re-run with --confirm-permanent-expiry only after approving this policy.')
            app.set_retention(True)
            print('24-hour expiry ENABLED for future uploads only. Existing files remain unchanged. Expired server attachment bytes are discarded; chat entries remain. Downloaded copies and backups are untouched.')
        elif args.command=='disable-retention':
            app.set_retention(False)
            print('Expiry DISABLED; all remaining attachment deadlines canceled. Already-expired bytes cannot be restored by this command.')
        elif args.command=='list-users':
            for r in app.db.execute('SELECT username,display_name,role,enabled,must_change_password FROM users'): print(dict(r))
        elif args.command=='disable-user':
            row=app.db.execute('SELECT * FROM users WHERE username=?',(args.username,)).fetchone()
            if not row: raise ValueError('User not found')
            if row['role']=='admin' and app.db.execute('SELECT count(*) FROM users WHERE role="admin" AND enabled=1').fetchone()[0]<=1: raise ValueError('Cannot disable last administrator')
            with app.db: app.db.execute('UPDATE users SET enabled=0 WHERE id=?',(row['id'],))
            print('Disabled. Restart server to terminate active calls and clear sessions.')
        elif args.command=='reset-password':
            from server import password_hash
            password=getpass.getpass('New temporary password (12–256 characters): ')
            if not 12<=len(password)<=256: raise ValueError('Password length invalid')
            if password!=getpass.getpass('Confirm password: '): raise ValueError('Passwords differ')
            with app.db:
                cur=app.db.execute('UPDATE users SET password=?,must_change_password=1 WHERE username=?',(password_hash(password),args.username))
                if not cur.rowcount: raise ValueError('User not found')
            print('Temporary password set; the user must change it at next sign-in. Existing sessions fail their next authenticated request. Restart the server to clear active calls immediately.')
        else:
            if args.command=='init':
                if app.db.execute('SELECT 1 FROM users').fetchone(): raise ValueError('Already initialized; use add-user')
                username=input('Admin username: ').strip(); name=input('Admin display name: ').strip(); role='admin'
            else: username,name,role=args.username,args.name,args.role
            password=getpass.getpass(('Initial administrator password' if args.command=='init' else 'Temporary password')+' (12–256 characters): ')
            if password!=getpass.getpass('Confirm password: '): raise ValueError('Passwords differ')
            app.add_user(username,name,password,role,must_change_password=args.command!='init'); print('Administrator created.' if args.command=='init' else 'User created with a temporary password; password change is required before chat. Give it to that person privately, never in a shared chat.')
    finally: app.db.close()

if __name__=='__main__':
    try: main()
    except (ValueError, __import__('sqlite3').IntegrityError) as e: raise SystemExit(str(e))
