"""Render real Qt widgets with synthetic demo data; no server or microphone access."""
import os,sys,time
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from client import QApplication,Login,Window,STYLE
app=QApplication([]);app.setStyleSheet(STYLE)
output=ROOT/'screenshots';output.mkdir(exist_ok=True)
profile={'server':'https://127.0.0.1:8443','ca_pem':'','organization':'R & A Group · Example only','profile_id':'demo-preview'}
login=Login(profile);login.show();app.processEvents();login.grab().save(str(output/'login-preview.png'));login.reject()
class PreviewWindow(Window):
    def poll(self):pass
class FakeAPI:
    max_file_bytes=50*1024*1024
    def request(self,*args,**kwargs):return{}
w=PreviewWindow(FakeAPI(),{'id':1,'username':'maya','display_name':'Maya Patel'},'R & A Group · Example only');w.show();app.processEvents()
users=[{'id':1,'display_name':'Maya Patel','online':True},{'id':2,'display_name':'Daniel Lewis','online':True},{'id':3,'display_name':'Sofia Chen','online':True},{'id':4,'display_name':'Omar Ahmed','online':False},{'id':5,'display_name':'Priya Nair','online':True}]
rooms=[{'id':1,'name':'All Staff','members':[1,2,3],'incoming_count':2},{'id':2,'name':'Daniel Lewis','members':[1,2],'incoming_count':0}]
w.refreshed(({'users':users},{'conversations':rooms},{'messages':[]},{'calls':[]}),None,0)
w.select_room(rooms[1]);now=time.time();w.render_messages([{'id':1,'sender_id':2,'text':'Good morning. Please come to my cabin when you are free.','created_at':now-300},{'id':2,'sender_id':1,'text':'Certainly. I will be there in a moment.','created_at':now-220},{'id':3,'sender_id':2,'text':'Here is the document you requested.','file_id':'a'*32,'file_name':'Sample document.pdf','created_at':now-120}]);w.update_storage_info({'used_bytes':128*1024,'quota_bytes':5*1024**3,'retention_enabled':False,'legacy_unmanaged_files':0});w.status.setText('DESIGN PREVIEW · Synthetic people and messages. Not an office-network test.');app.processEvents();w.grab().save(str(output/'workspace-preview.png'));w.force_quit=True;w.close();app.processEvents()
print('Rendered login-preview.png and workspace-preview.png from real Qt widgets.')
