"""New host-console boundaries and twenty-account HTTPS smoke tests."""
import base64
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import socket
import ssl
import tempfile
import unittest
from unittest.mock import patch
import zipfile

os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import office_setup as setup
from client import API
from make_cert import generate
from server import App


class OfficeSetupTests(unittest.TestCase):
    def test_private_network_guard(self):
        for ip in ['192.168.1.20','10.2.3.4','172.16.8.1']:
            self.assertEqual(setup.private_host(ip),ip)
        for ip in ['8.8.8.8','0.0.0.0','127.0.0.1','::1','172.32.0.1']:
            with self.assertRaises(ValueError):setup.private_host(ip)

    def test_new_office_export_and_no_overwrite(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            config=setup.create_office(root/'office','Test office','192.168.1.20',8443,
                'admin','Office administrator','temporary-test-password','separate-ca-test-password')
            saved=setup.save_config(config,root/'host_config.json')
            self.assertEqual(saved['host'],'192.168.1.20')
            self.assertNotIn('temporary-test-password',(root/'host_config.json').read_text())
            with self.assertRaises(FileExistsError):setup.save_config(config,root/'host_config.json')
            with self.assertRaises(FileExistsError):
                setup.create_office(root/'office','Test office','192.168.1.20',8443,
                    'admin','Office administrator','temporary-test-password','separate-ca-test-password')
            package=root/'staff.zip';setup.export_staff(config,package)
            with zipfile.ZipFile(package) as archive:
                names=archive.namelist()
                self.assertEqual(set(names),{'OfficeLink_Staff/'+n for n in setup.STAFF_FILES}|{'OfficeLink_Staff/office_profile.py','OfficeLink_Staff/READ_ME.txt'})
                blob=b'\n'.join(archive.read(n) for n in names)
                self.assertNotIn(b'temporary-test-password',blob)
                self.assertNotIn((root/'office/certs/server-key.pem').read_bytes(),blob)
                self.assertNotIn((root/'office/certs/ca-key.pem').read_bytes(),blob)
                self.assertNotIn('OfficeLink_Staff/office_setup.py',names)
                namespace={};exec(archive.read('OfficeLink_Staff/office_profile.py'),namespace)
                self.assertEqual(namespace['PROFILE']['server'],'https://192.168.1.20:8443')
            original=package.read_bytes()
            with self.assertRaises(FileExistsError):setup.export_staff(config,package)
            self.assertEqual(package.read_bytes(),original)
            wrong=dict(config,host='192.168.1.21')
            with self.assertRaises(ValueError):setup.save_config(wrong,root/'wrong.json')
            self.assertFalse((root/'wrong.json').exists())

    def test_twenty_accounts_https_messages_documents_and_restart(self):
        # Loopback replaces only the host-console LAN guard inside this test.
        # The real application still rejects loopback in its office setup screen.
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);generate(root/'certs',['127.0.0.1'],'temporary-test-ca-passphrase')
            database=App(root/'data')
            for i in range(20):database.add_user('staff'+str(i),'Staff '+str(i),'test-password-for-account-'+str(i),'admin' if i==0 else 'staff')
            database.db.close()
            config={'host':'127.0.0.1','port':0,'data':str(root/'data'),
                    'cert':str(root/'certs/server.pem'),'key':str(root/'certs/server-key.pem')}
            host=setup.HostService()
            with patch.object(setup,'private_host',lambda value:value):host.start(config)
            url='https://127.0.0.1:'+str(host.server.server_port)
            def login(i):
                client=API(url,ca=str(root/'certs/ca.pem'))
                result=client.request('POST','/login',{'username':'staff'+str(i),'password':'test-password-for-account-'+str(i)})
                client.token=result['token'];client.configure_limits(result['limits'])
                return client,result['user']['id']
            try:
                with ThreadPoolExecutor(max_workers=20) as pool:clients=list(pool.map(login,range(20)))
                admin,admin_id=clients[0]
                self.assertEqual(len(admin.request('GET','/users')['users']),20)
                def exchange(item):
                    index,(client,uid)=item
                    room=client.request('POST','/conversations',{'name':'Direct '+str(index),'members':[admin_id]})['id']
                    client.request('POST','/messages',{'conversation_id':room,'text':'Please come to my desk '+str(index)})
                    return room
                with ThreadPoolExecutor(max_workers=19) as pool:rooms=list(pool.map(exchange,enumerate(clients[1:],1)))
                self.assertEqual(len(set(rooms)),19)
                for room in rooms:self.assertEqual(len(admin.request('GET','/messages?conversation_id='+str(room))['messages']),1)
                raw=os.urandom(128*1024)
                sent=admin.request('POST','/uploads',{'conversation_id':rooms[0],'name':'sample.pdf','data':base64.b64encode(raw).decode()})
                received=clients[1][0].request('GET','/files/'+sent['file_id'])
                self.assertEqual(base64.b64decode(received['data']),raw)
                with self.assertRaisesRegex(RuntimeError,'403'):clients[2][0].request('GET','/files/'+sent['file_id'])
            finally:host.stop()
            self.assertIsNone(host.server)
            # Restart the same database/certificates and verify persisted content.
            with patch.object(setup,'private_host',lambda value:value):host.start(config)
            try:
                restored=API('https://127.0.0.1:'+str(host.server.server_port),ca=str(root/'certs/ca.pem'))
                auth=restored.request('POST','/login',{'username':'staff0','password':'test-password-for-account-0'});restored.token=auth['token']
                self.assertEqual(len(restored.request('GET','/conversations')['conversations']),19)
                self.assertEqual(base64.b64decode(restored.request('GET','/files/'+sent['file_id'])['data']),raw)
            finally:host.stop()


if __name__=='__main__':unittest.main()
