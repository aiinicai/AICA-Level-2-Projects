"""Real offscreen Qt widget behavior; not a Windows tray/notification delivery test."""
import os
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
import sys, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
try:
    from client import QApplication,Window,Login,STYLE
    HAS_QT=True
except ImportError: HAS_QT=False

@unittest.skipUnless(HAS_QT,'PyQt6 not installed')
class WidgetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app=QApplication.instance() or QApplication([]);cls.app.setStyleSheet(STYLE)
    def setUp(self):
        class NoNetworkWindow(Window):
            def poll(self):pass
        class FakeAPI:
            def request(self,*args,**kwargs):return{}
        self.w=NoNetworkWindow(FakeAPI(),{'id':1,'username':'demo','display_name':'Demo'})
        self.w.isActiveWindow=lambda:False
        self.w.conversations=[{'id':1,'name':'Design','members':[1,2],'incoming_count':7},{'id':2,'name':'Finance','members':[1,3],'incoming_count':4}]
    def tearDown(self):self.w.force_quit=True;self.w.close();self.app.processEvents()
    def test_composer_disabled_before_chat(self):
        self.assertFalse(self.w.send.isEnabled());self.assertFalse(self.w.input.isEnabled())
        self.w.select_room(self.w.conversations[0]);self.assertTrue(self.w.send.isEnabled())
    def test_initial_history_not_unread_and_new_counts_exact(self):
        self.w.preferences['notifications_enabled']=False
        self.w.process_notifications(self.w.conversations);self.assertEqual(self.w.unread,{})
        self.w.conversations[0]['incoming_count']=10
        self.w.process_notifications(self.w.conversations);self.assertEqual(self.w.unread,{1:3})
        self.w.process_notifications(self.w.conversations);self.assertEqual(self.w.unread,{1:3})
    def test_visible_reply_after_stale_summary_is_not_alerted_again(self):
        self.w.preferences['notifications_enabled']=False
        room=self.w.conversations[0];room['incoming_count']=0
        self.w.process_notifications(self.w.conversations)
        self.w.select_room(room);self.w.isActiveWindow=lambda:True
        self.w.render_messages([{'id':1,'sender_id':2,'text':'Already visible','created_at':0}])
        self.assertEqual(self.w.incoming_counts[1],1)
        self.w.process_notifications(self.w.conversations)  # A stale summary must not move backwards.
        self.assertEqual(self.w.incoming_counts[1],1)
        self.w.isActiveWindow=lambda:False
        room['incoming_count']=2
        self.w.process_notifications(self.w.conversations)
        self.assertEqual(self.w.unread[1],1)

    def test_notification_multiple_rooms_routes_chat_list_not_wrong_chat(self):
        self.w.unread={1:2,2:1};self.w.restore_window=lambda:None
        self.w.open_notified_chat();self.assertEqual(self.w.tabs.currentIndex(),1);self.assertIsNone(self.w.current)
    def test_notification_single_room_opens_that_chat(self):
        self.w.unread={2:1};self.w.restore_window=lambda:None
        self.w.open_notified_chat();self.assertEqual(self.w.current,2)
    def test_group_voice_disabled(self):
        room={'id':3,'name':'Group','members':[1,2,3]};self.w.conversations.append(room)
        self.w.select_room(room);self.assertFalse(self.w.call_button.isEnabled())
    def test_profile_login_has_no_server_or_ca_picker(self):
        p={'profile_id':'ui-test','organization':'Demo','server':'https://127.0.0.1:8443','ca_pem':''}
        login=Login(p)
        self.assertFalse(hasattr(login,'server'));self.assertFalse(hasattr(login,'ca'))
        self.assertTrue(login.remember.isChecked());self.assertEqual(login.password.text(),'')
        login.reject()

if __name__=='__main__':unittest.main()
