"""Migration preservation, duplicate-process protection and headless TLS hosting."""
import base64
import hashlib
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import tempfile
import threading
import time
import unittest
import xml.etree.ElementTree as ET

from client import API
from host_config import save_config
from host_lock import HostLock
from make_cert import generate
from migrate_host import migrate_backup
from office_setup import export_staff
from server import App
from server_runner import load_config, run
from startup_task import task_xml


class ServerMigrationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()

    def backup(self):
        app = App(self.root/'old')
        try:
            app.add_user('admin','Administrator','test-admin-password','admin')
            app.add_user('colleague','Colleague','test-staff-password',must_change_password=True)
            app.set_retention(True)
            with app.db:
                app.db.execute("INSERT INTO conversations VALUES(1,'Preserved conversation')")
                app.db.execute('INSERT INTO members VALUES(1,1)')
                app.db.execute('INSERT INTO members VALUES(1,2)')
                app.db.execute("INSERT INTO files(id,conversation_id,name,data) VALUES('doc',1,'original.pdf',?)",(b'%PDF-test-content',))
                app.db.execute("INSERT INTO messages VALUES(1,1,1,'Preserved chat',12345,'doc')")
            backup=self.root/'backup.db'
            dest=sqlite3.connect(backup)
            try: app.db.backup(dest)
            finally: dest.close()
            return backup
        finally: app.db.close()

    def test_migration_preserves_every_table_source_credentials_and_new_profile(self):
        backup=self.backup(); digest=hashlib.sha256(backup.read_bytes()).digest()
        config=migrate_backup(backup,self.root/'new','R & A Group','192.168.70.122',8443,'new-recovery-passphrase')
        save_config(config,self.root/'host_config.json')
        self.assertEqual(load_config(self.root/'host_config.json')['host'],'192.168.70.122')
        src=sqlite3.connect(backup); dst=sqlite3.connect(Path(config['data'])/'office.db')
        try:
            for table in ('users','conversations','members','messages','files','settings'):
                self.assertEqual(src.execute('SELECT * FROM '+table).fetchall(),dst.execute('SELECT * FROM '+table).fetchall(),table)
        finally: src.close();dst.close()
        self.assertEqual(hashlib.sha256(backup.read_bytes()).digest(),digest)
        app=App(config['data'])
        try:
            auth=app.dispatch('POST','/login',{}, {'username':'admin','password':'test-admin-password'},None,'127.0.0.1')
            self.assertEqual(auth['user']['username'],'admin')
            self.assertTrue(app.retention_enabled())
        finally: app.db.close()
        staff=self.root/'staff.zip'; export_staff(config,staff)
        import zipfile
        with zipfile.ZipFile(staff) as archive:
            profile=archive.read('OfficeLink_Staff/office_profile.py')
            self.assertIn(b'https://192.168.70.122:8443',profile)
            blobs=b''.join(archive.read(n) for n in archive.namelist())
            for key in ('server-key.pem','ca-key.pem'):
                self.assertFalse((self.root/'new/certs'/key).read_bytes() in blobs)
            self.assertFalse(any('server_runner' in n or 'host_lock' in n for n in archive.namelist()))
        with self.assertRaises(FileExistsError):
            migrate_backup(backup,self.root/'new','R & A Group','192.168.70.122',8443,'new-recovery-passphrase')

    def test_invalid_backup_does_not_create_destination(self):
        bad=self.root/'wrong.db'; bad.write_bytes(b'not a database')
        with self.assertRaises(sqlite3.DatabaseError):
            migrate_backup(bad,self.root/'new','Office','192.168.70.122',8443,'new-recovery-passphrase')
        self.assertFalse((self.root/'new').exists())
        missing=self.root/'missing.db'
        with self.assertRaises(FileNotFoundError):
            migrate_backup(missing,self.root/'new','Office','192.168.70.122',8443,'new-recovery-passphrase')
        self.assertFalse(missing.exists())

    def test_cross_process_lock_is_released_after_owner_closes(self):
        data=self.root/'data'; data.mkdir()
        code='from host_lock import HostLock; import sys; lock=HostLock(sys.argv[1]).acquire(); lock.release()'
        env=dict(os.environ, PYTHONPATH=str(Path(__file__).resolve().parents[1]))
        with HostLock(data):
            blocked=subprocess.run([sys.executable,'-c',code,str(data)],env=env,capture_output=True,text=True)
            self.assertNotEqual(blocked.returncode,0)
            self.assertIn('already running',blocked.stderr)
        unblocked=subprocess.run([sys.executable,'-c',code,str(data)],env=env,capture_output=True,text=True)
        self.assertEqual(unblocked.returncode,0,unblocked.stderr)

    def test_headless_https_stop_restart_and_document(self):
        backup=self.backup()
        config=migrate_backup(backup,self.root/'new','Office','192.168.70.122',8443,'new-recovery-passphrase')
        # Only this isolated fixture uses loopback; production config rejects it.
        generate(self.root/'loopback',['127.0.0.1'],'test-loopback-passphrase')
        with socket.socket() as sock:
            sock.bind(('127.0.0.1',0)); port=sock.getsockname()[1]
        config.update(host='127.0.0.1',port=port,cert=str(self.root/'loopback/server.pem'),key=str(self.root/'loopback/server-key.pem'))
        failures=[]
        def host():
            try: run(config)
            except Exception as exc: failures.append(exc)
        for repeat in range(2):
            thread=threading.Thread(target=host); thread.start()
            try:
                client=API('https://127.0.0.1:'+str(port),ca=str(self.root/'loopback/ca.pem'))
                deadline=time.monotonic()+8
                while True:
                    try:
                        auth=client.request('POST','/login',{'username':'admin','password':'test-admin-password'})
                        break
                    except Exception:
                        if failures or time.monotonic()>deadline: raise
                        time.sleep(0.05)
                client.token=auth['token']
                content=client.request('GET','/files/doc')
                self.assertEqual(base64.b64decode(content['data']),b'%PDF-test-content')
                self.assertEqual(client.request('GET','/messages?conversation_id=1')['messages'][0]['text'],'Preserved chat')
                with self.assertRaises(RuntimeError): HostLock(config['data']).acquire()
            finally:
                (Path(config['data'])/'background.stop').touch()
                thread.join(10)
            self.assertFalse(thread.is_alive())
            self.assertEqual(failures,[])

    def test_startup_xml_is_password_logon_limited_recoverable_and_has_no_duration_cap(self):
        root=self.root/'Office R & A'; root.mkdir()
        for name in ('server_runner.py','host_config.json','python.exe'): (root/name).touch()
        blob=task_xml(root,root/'python.exe','S-1-5-21-111-222-333-1001')
        task=ET.fromstring(blob); ns={'t':'http://schemas.microsoft.com/windows/2004/02/mit/task'}
        def field(path): return task.find(path,ns).text
        self.assertEqual(field('t:Principals/t:Principal/t:LogonType'),'Password')
        self.assertEqual(field('t:Principals/t:Principal/t:RunLevel'),'LeastPrivilege')
        self.assertEqual(field('t:Settings/t:ExecutionTimeLimit'),'PT0S')
        self.assertEqual(field('t:Settings/t:RestartOnFailure/t:Count'),'10')
        self.assertEqual(field('t:Triggers/t:BootTrigger/t:Delay'),'PT30S')
        self.assertIn('"'+str(root/'server_runner.py')+'"',field('t:Actions/t:Exec/t:Arguments'))
        self.assertEqual(field('t:Actions/t:Exec/t:WorkingDirectory'),str(root))
        with self.assertRaises(ValueError): task_xml(root,root/'python.exe','SYSTEM')


if __name__=='__main__': unittest.main()
