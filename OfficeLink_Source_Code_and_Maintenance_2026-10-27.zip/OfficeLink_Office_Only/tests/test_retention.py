"""Prospective attachment expiry checks. All databases/files/keys are temporary."""
import base64,contextlib,io,json,secrets,sqlite3,ssl,sys,tempfile,threading,time,unittest,urllib.error,urllib.request
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import admin
from server import App,APIError,Server
from make_cert import generate

class RetentionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.certs=tempfile.TemporaryDirectory();generate(cls.certs.name,['127.0.0.1'],'temporary-retention-certificate-passphrase')
    @classmethod
    def tearDownClass(cls):cls.certs.cleanup()
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.app=App(self.root/'data')
        password=secrets.token_urlsafe(20);self.tokens={};self.ids={}
        for name in ('alice','bob','eve'):
            self.app.add_user(name,name.title(),password)
            result=self.app.dispatch('POST','/login',{}, {'username':name,'password':password},'','127.0.0.1')
            self.tokens[name]=result['token'];self.ids[name]=result['user']['id']
        self.cid=self.request('POST','/conversations',{'name':'Retention test','members':[self.ids['bob']]})['id']
    def tearDown(self):self.app.db.close();self.temp.cleanup()
    def request(self,method,path,body=None,user='alice',q=None):
        return self.app.dispatch(method,path,q or {},body or {},self.tokens.get(user,''),'127.0.0.1')
    def upload(self,data=b'temporary document',name='sample.pdf'):
        return self.request('POST','/uploads',{'conversation_id':self.cid,'name':name,'data':base64.b64encode(data).decode()})['file_id']
    def row(self,fid):return self.app.db.execute('SELECT * FROM files WHERE id=?',(fid,)).fetchone()
    def due(self,fid):
        with self.app.db:self.app.db.execute('UPDATE files SET expires_at=? WHERE id=?',(time.time()-1,fid))
    def expect_status(self,status,method,path,**kwargs):
        with self.assertRaises(APIError) as caught:self.request(method,path,**kwargs)
        self.assertEqual(caught.exception.status,status)
    def tls_server(self):
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(Path(self.certs.name)/'server.pem',Path(self.certs.name)/'server-key.pem')
        server=Server(('127.0.0.1',0),self.app,ctx);worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start();return server,worker
    def test_legacy_schema_migration_never_backfills_or_deletes(self):
        path=self.root/'legacy';path.mkdir();db=sqlite3.connect(path/'office.db')
        db.execute('CREATE TABLE files(id TEXT PRIMARY KEY,conversation_id INTEGER,name TEXT NOT NULL,data BLOB NOT NULL)')
        db.execute('INSERT INTO files VALUES(?,?,?,?)',('legacy',999,'old.pdf',b'legacy bytes'));db.commit();db.close()
        legacy=App(path)
        try:
            row=legacy.db.execute('SELECT * FROM files').fetchone()
            self.assertEqual(row['data'],b'legacy bytes');self.assertIsNone(row['uploaded_at']);self.assertIsNone(row['expires_at']);self.assertIsNone(row['expired_at'])
            legacy.set_retention(True);self.assertEqual(legacy.expire_attachments(time.time()+9999999),0)
            self.assertEqual(legacy.db.execute('SELECT data FROM files').fetchone()[0],b'legacy bytes')
        finally:legacy.db.close()
    def test_default_off_upload_has_no_deadline_and_never_expires(self):
        self.assertFalse(self.app.retention_enabled());fid=self.upload()
        self.assertIsNotNone(self.row(fid)['uploaded_at']);self.assertIsNone(self.row(fid)['expires_at'])
        self.assertEqual(self.app.expire_attachments(time.time()+9999999),0)
        self.assertTrue(self.row(fid)['data'])
    def test_enable_only_future_uploads_and_exact_deadline_boundary(self):
        old=self.upload();self.app.set_retention(True);fid=self.upload();row=self.row(fid)
        self.assertEqual(row['expires_at']-row['uploaded_at'],86400)
        self.assertIsNone(self.row(old)['expires_at'])
        self.assertEqual(self.app.expire_attachments(row['expires_at']-.01),0)
        self.assertEqual(self.app.expire_attachments(row['expires_at']),1)
        self.assertEqual(self.row(fid)['data'],b'');self.assertTrue(self.row(old)['data'])
    def test_expiry_preserves_chat_and_authorization_but_returns_gone(self):
        self.app.set_retention(True);fid=self.upload();self.due(fid)
        self.expect_status(410,'GET','/files/'+fid,user='bob')
        self.expect_status(403,'GET','/files/'+fid,user='eve')
        result=self.request('GET','/messages',q={'conversation_id':[str(self.cid)],'after':['0']})
        message=result['messages'][0];self.assertEqual(message['text'],'Shared a document');self.assertEqual(message['file_id'],fid)
        self.assertTrue(message['file_expired']);self.assertEqual(message['file_name'],'sample.pdf')
        delta=self.request('GET','/messages',q={'conversation_id':[str(self.cid)],'after':[str(message['id'])]})
        self.assertEqual(delta['messages'],[]);self.assertEqual(delta['attachment_states'][0]['file_id'],fid);self.assertTrue(delta['attachment_states'][0]['file_expired'])
        self.expect_status(403,'GET','/messages',user='eve',q={'conversation_id':[str(self.cid)]})
    def test_storage_quota_accounting_freed_without_touching_saved_copy(self):
        self.app.set_retention(True);data=b'local saved bytes'*100;fid=self.upload(data)
        downloaded=self.root/'downloaded-copy.pdf';downloaded.write_bytes(data)
        before=self.request('GET','/storage');self.assertEqual(before['used_bytes'],len(data))
        self.due(fid);after=self.request('GET','/storage')
        self.assertEqual(after['used_bytes'],0);self.assertEqual(after['quota_bytes'],before['quota_bytes']);self.assertEqual(after['expired_files'],1)
        self.assertEqual(downloaded.read_bytes(),data)
    def test_disabled_policy_cancels_pending_deadlines_and_reenable_not_retroactive(self):
        self.app.set_retention(True);fid=self.upload();self.app.set_retention(False)
        self.assertIsNone(self.row(fid)['expires_at']);self.assertTrue(self.row(fid)['data'])
        self.app.set_retention(True);self.assertEqual(self.app.expire_attachments(time.time()+9999999),0)
        self.assertTrue(self.row(fid)['data']);new=self.upload();self.assertIsNotNone(self.row(new)['expires_at'])
    def test_admin_enable_requires_explicit_confirmation(self):
        args=['admin.py','--data',str(self.root/'data'),'enable-retention']
        with patch.object(sys,'argv',args),self.assertRaisesRegex(ValueError,'No retention change made'):admin.main()
        self.assertFalse(self.app.retention_enabled())
        with patch.object(sys,'argv',args+['--confirm-permanent-expiry']),contextlib.redirect_stdout(io.StringIO()) as output:admin.main()
        self.assertTrue(self.app.retention_enabled());self.assertIn('future uploads only',output.getvalue())
    def test_admin_status_and_app_constructor_do_not_purge(self):
        self.app.set_retention(True);fid=self.upload();self.due(fid);self.app.db.close();self.app=App(self.root/'data')
        self.assertTrue(self.row(fid)['data'])
        with patch.object(sys,'argv',['admin.py','--data',str(self.root/'data'),'retention-status']),contextlib.redirect_stdout(io.StringIO()) as output:admin.main()
        self.assertGreater(json.loads(output.getvalue())['used_bytes'],0);self.assertTrue(self.row(fid)['data'])
    def test_restart_server_cleans_overdue_attachment_and_stops_worker(self):
        self.app.set_retention(True);fid=self.upload();self.due(fid)
        server,worker=self.tls_server()
        try:self.assertEqual(self.row(fid)['data'],b'');self.assertTrue(server.retention_worker.is_alive())
        finally:server.shutdown();server.server_close();worker.join(5)
        self.assertFalse(server.retention_worker.is_alive())
    def test_already_started_download_snapshot_survives_expiry(self):
        self.app.set_retention(True);data=b'accepted before expiry';fid=self.upload(data)
        snapshot=self.request('GET','/files/'+fid,user='bob');self.due(fid);self.app.expire_attachments()
        self.assertEqual(base64.b64decode(snapshot['data']),data);self.expect_status(410,'GET','/files/'+fid,user='bob')
    def test_expiry_obeys_database_lock_and_is_idempotent(self):
        self.app.set_retention(True);fid=self.upload();self.due(fid);started=threading.Event();finished=threading.Event()
        def expire():started.set();self.app.expire_attachments();finished.set()
        with self.app.lock:
            worker=threading.Thread(target=expire);worker.start();self.assertTrue(started.wait(1));self.assertFalse(finished.wait(.05));self.assertTrue(self.row(fid)['data'])
        worker.join(2);self.assertTrue(finished.is_set());self.assertEqual(self.app.expire_attachments(),0)
    def test_periodic_worker_retries_expiry_on_tick(self):
        self.app.set_retention(True);fid=self.upload();self.due(fid)
        class Stop:
            calls=0
            def wait(self,seconds):self.calls+=1;return self.calls>1
        fake=type('WorkerHarness',(),{'app':self.app,'retention_stop':Stop()})()
        Server._retention_loop(fake);self.assertEqual(self.row(fid)['data'],b'')
    def test_real_strict_https_expired_download_and_storage(self):
        self.app.set_retention(True);fid=self.upload();server,worker=self.tls_server()
        context=ssl.create_default_context(cafile=str(Path(self.certs.name)/'ca.pem'));context.verify_flags|=ssl.VERIFY_X509_STRICT
        def get(path,user='bob'):
            req=urllib.request.Request('https://127.0.0.1:'+str(server.server_port)+path,headers={'Authorization':'Bearer '+self.tokens[user]})
            try:
                with urllib.request.urlopen(req,context=context,timeout=5) as response:return response.status,json.load(response)
            except urllib.error.HTTPError as error:return error.code,json.load(error)
        try:
            self.assertEqual(get('/files/'+fid)[0],200);self.due(fid)
            code,result=get('/files/'+fid);self.assertEqual(code,410);self.assertIn('expired',result['error'])
            self.assertEqual(get('/files/'+fid,'eve')[0],403)
            code,status=get('/storage');self.assertEqual(code,200);self.assertEqual(status['used_bytes'],0)
        finally:server.shutdown();server.server_close();worker.join(5)

if __name__=='__main__':unittest.main(verbosity=2)
