"""Deployment bootstrap tests; no trust-store, office-network or user-profile changes."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import deployment_profile as dp
from create_profile import prepare,check,validate_ca
from make_cert import generate

class Profiles(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory();cls.root=Path(cls.temp.name)
        generate(cls.root/'certs',['127.0.0.1'],'temporary-profile-test-password')
        cls.ca=cls.root/'certs'/'ca.pem'
        cls.profile={'version':1,'server':'https://127.0.0.1:8443','organization':'Test Office','ca_pem':cls.ca.read_text()}
    @classmethod
    def tearDownClass(cls):cls.temp.cleanup()
    def test_profile_roundtrip_and_exact_module_check(self):
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/'profile.json'
            result=prepare(self.profile['server'],self.ca,'Test Office',output)
            self.assertEqual(result,check(output));self.assertEqual(len(result['profile_id']),64)
            text=output.with_name('office_profile.py').read_text()
            self.assertNotIn('PRIVATE KEY',text)
            output.with_name('office_profile.py').write_text(text+'# tamper\n')
            with self.assertRaisesRegex(ValueError,'does not exactly match'):check(output)
    def test_no_overwrite(self):
        with tempfile.TemporaryDirectory() as folder:
            output=Path(folder)/'profile.json'
            prepare(self.profile['server'],self.ca,'Office',output)
            with self.assertRaises(FileExistsError):prepare(self.profile['server'],self.ca,'Office',output)
    def test_bad_origin_rejected(self):
        for origin in ('http://127.0.0.1','https://user:pass@office','https://office/path','https://office?q=x','https://office#x','https://8.8.8.8','https://0.0.0.0','https://[::]','https://office:0','https://office:99999','https://a_b'):
            with self.subTest(origin=origin),self.assertRaises(ValueError):dp.validate_profile(dict(self.profile,server=origin))
    def test_private_dns_and_ipv4(self):
        for origin in ('https://office-server:8443','https://office.example:8443','https://192.168.10.20:8443','https://10.0.0.5','https://172.16.1.5'):
            self.assertEqual(dp.validate_profile(dict(self.profile,server=origin))['server'],origin)
    def test_secrets_unknown_fields_and_bad_ca_rejected(self):
        for profile in (dict(self.profile,password='secret'),dict(self.profile,token='secret'),dict(self.profile,ca_pem='-----BEGIN PRIVATE KEY-----'),dict(self.profile,ca_pem=self.profile['ca_pem']*2),dict(self.profile,version=True)):
            with self.assertRaises(ValueError):dp.validate_profile(profile)
        with self.assertRaises(ValueError):validate_ca((self.root/'certs'/'server.pem').read_text())
    def test_missing_profile_and_invalid_embedded_profile(self):
        with patch.object(dp,'_EMBEDDED_PROFILE',None):self.assertIsNone(dp.load_profile())
        with patch.object(dp,'_EMBEDDED_PROFILE',{'server':'evil'}):
            with self.assertRaises(ValueError):dp.load_profile()
        with patch.object(dp,'_EMBEDDED_PROFILE',self.profile):self.assertEqual(dp.load_profile()['organization'],'Test Office')
    def test_username_only_and_profile_scoped(self):
        profile=dp.validate_profile(self.profile)
        other=dp.validate_profile(dict(self.profile,server='https://other-office:8443'))
        with tempfile.TemporaryDirectory() as folder,patch.object(dp,'_preferences_path',return_value=Path(folder)/'preferences.json'):
            self.assertEqual(dp.load_username(profile),'')
            dp.save_username(profile,'alice');self.assertEqual(dp.load_username(profile),'alice');self.assertEqual(dp.load_username(other),'')
            data=json.loads((Path(folder)/'preferences.json').read_text())
            self.assertEqual(set(data),{'version','profiles'})
            self.assertEqual(data['profiles'][profile['profile_id']]['username'],'alice')
            with self.assertRaises(ValueError):dp.save_username(profile,{'password':'secret'})
            (Path(folder)/'preferences.json').write_text('{broken')
            self.assertEqual(dp.load_username(profile),'')
    def test_preferences_allowlist_and_no_remember(self):
        profile=dp.validate_profile(self.profile)
        with tempfile.TemporaryDirectory() as folder,patch.object(dp,'_preferences_path',return_value=Path(folder)/'preferences.json'):
            self.assertFalse(dp.load_preferences(profile)['sound_enabled'])
            self.assertTrue(dp.load_preferences(profile)['notifications_enabled'])
            dp.save_preferences(profile,username='alice',sound_enabled=True,notifications_enabled=False)
            dp.save_username(profile,'bob')
            self.assertTrue(dp.load_preferences(profile)['sound_enabled'])
            self.assertFalse(dp.load_preferences(profile)['notifications_enabled'])
            dp.save_preferences(profile,remember_username=False)
            self.assertEqual(dp.load_username(profile),'')
            for values in ({'password':'secret'},{'server':'https://evil'},{'ca_pem':'fake'},{'notifications_enabled':'true'},{'token':'secret'}):
                with self.assertRaises(ValueError):dp.save_preferences(profile,**values)
            self.assertNotIn('secret',(Path(folder)/'preferences.json').read_text())
    def test_digest_is_not_present_as_self_authentication(self):
        self.assertEqual(set(self.profile),{'version','server','organization','ca_pem'})
        self.assertNotEqual(dp.validate_profile(self.profile)['profile_id'],dp.validate_profile(dict(self.profile,server='https://other-office'))['profile_id'])

if __name__=='__main__':unittest.main()
