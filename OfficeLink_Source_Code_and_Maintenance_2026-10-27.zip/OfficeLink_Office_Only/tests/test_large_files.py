"""Bounded-transfer tests: real loopback HTTPS; no office files or Windows claims."""
import ast
import base64
import hashlib
import http.client
import json
from pathlib import Path
import subprocess
import sys
import threading
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import test_server as fixture
from transfer_limits import MIB,DEFAULT_MAX_FILE_BYTES,HARD_MAX_FILE_BYTES,LEGACY_MAX_FILE_BYTES,TRANSFER_TIMEOUT,encoded_body_limit,validate_limit

# Exercise the exact client transport class without requiring a GUI or devices.
source=Path(__file__).resolve().parents[1]/'client.py'
tree=ast.parse(source.read_text())
nodes=[n for n in tree.body if (isinstance(n,(ast.Import,ast.ImportFrom)) and not (isinstance(n,ast.ImportFrom) and n.module.startswith('PyQt6'))) or (isinstance(n,ast.ClassDef) and n.name in ('NoRedirect','API'))]
namespace={};exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),namespace)
API=namespace['API']

class LargeTransfers(unittest.TestCase):
    setUpClass=classmethod(fixture.IntegrationTests.setUpClass.__func__)
    tearDownClass=classmethod(fixture.IntegrationTests.tearDownClass.__func__)
    setUp=fixture.IntegrationTests.setUp
    tearDown=fixture.IntegrationTests.tearDown
    start=fixture.IntegrationTests.start
    stop=fixture.IntegrationTests.stop
    api=fixture.IntegrationTests.api
    conversation=fixture.IntegrationTests.conversation

    def client(self,name='alice'):
        api=API(self.url,ca=str(self.cert))
        result=api.request('POST','/login',{'username':name,'password':self.password})
        api.token=result['token'];api.configure_limits(result.get('limits'))
        return api

    def test_50_mib_actual_tls_client_roundtrip_sha256(self):
        cid=self.conversation();alice=self.client();bob=self.client('bob')
        self.assertEqual(alice.max_file_bytes,50*MIB)
        raw=(b'OfficeLink synthetic large PDF fixture\n'*1500000)[:50*MIB]
        if len(raw)<50*MIB:raw+=b'X'*(50*MIB-len(raw))
        self.assertEqual(len(raw),50*MIB)
        expected=hashlib.sha256(raw).hexdigest()
        payload={'conversation_id':cid,'name':'synthetic-50MiB.pdf','data':base64.b64encode(raw).decode()}
        del raw
        result=alice.request('POST','/uploads',payload);del payload
        received=bob.request('GET','/files/'+result['file_id'])
        decoded=base64.b64decode(received['data'],validate=True)
        self.assertEqual(len(decoded),50*MIB)
        self.assertEqual(hashlib.sha256(decoded).hexdigest(),expected)
        self.assertEqual(received['name'],'synthetic-50MiB.pdf')

    def test_33_mib_actual_tls_client_roundtrip_sha256(self):
        cid=self.conversation();alice=self.client();bob=self.client('bob')
        raw=b'3'*(33*MIB);expected=hashlib.sha256(raw).hexdigest()
        payload={'conversation_id':cid,'name':'synthetic-33MiB.pdf','data':base64.b64encode(raw).decode()}
        del raw
        result=alice.request('POST','/uploads',payload);del payload
        received=bob.request('GET','/files/'+result['file_id'])
        decoded=base64.b64decode(received['data'],validate=True)
        self.assertEqual(len(decoded),33*MIB)
        self.assertEqual(hashlib.sha256(decoded).hexdigest(),expected)

    def test_configured_one_mib_limit_boundary_and_clear_error(self):
        self.app.max_file_bytes=MIB
        cid=self.conversation();api=self.client()
        self.assertEqual(api.max_file_bytes,MIB)
        api.request('POST','/uploads',{'conversation_id':cid,'name':'boundary.pdf','data':base64.b64encode(b'a'*MIB).decode()})
        with self.assertRaisesRegex(RuntimeError,'413:.*1 MiB'):
            api.request('POST','/uploads',{'conversation_id':cid,'name':'too-large.pdf','data':base64.b64encode(b'a'*(MIB+1)).decode()})
        self.assertEqual(self.app.db.execute('SELECT count(*) FROM files').fetchone()[0],1)

    def test_server_single_transfer_slot_rejects_busy_without_blocking_chat(self):
        self.server.transfer_slot.acquire()
        try:
            self.assertEqual(self.api('POST','/uploads',{},user='alice')[0],503)
            self.assertEqual(self.api('GET','/files/unknown',user='alice')[0],503)
            self.assertEqual(self.api('GET','/users',user='alice')[0],200)
            self.assertEqual(self.api('POST','/uploads',{})[0],401)
        finally:self.server.transfer_slot.release()
        self.assertEqual(self.api('GET','/files/unknown',user='alice')[0],404)

    def test_declared_oversize_body_rejected_before_read_and_slot_released(self):
        self.app.max_file_bytes=MIB
        conn=http.client.HTTPSConnection('127.0.0.1',self.server.server_port,context=self.context,timeout=5)
        try:
            conn.putrequest('POST','/uploads');conn.putheader('Authorization','Bearer '+self.tokens['alice'])
            conn.putheader('Content-Length',str(encoded_body_limit(MIB)+1));conn.endheaders()
            response=conn.getresponse();self.assertEqual(response.status,413);response.read()
        finally:conn.close()
        self.assertTrue(self.server.transfer_slot.acquire(timeout=2));self.server.transfer_slot.release()

    def test_aggregate_quota_unchanged(self):
        cid=self.conversation()
        with patch('server.MAX_STORAGE',5):
            code,body=self.api('POST','/uploads',{'conversation_id':cid,'name':'small.pdf','data':base64.b64encode(b'123456').decode()},user='alice')
            self.assertEqual(code,507);self.assertIn('quota',body['error'])

class ClientTransferBounds(unittest.TestCase):
    def bare_api(self):
        api=API.__new__(API);api.url='https://127.0.0.1:8443';api.token=None
        api.max_file_bytes=50*MIB;api.transfer_slot=threading.BoundedSemaphore(1)
        return api

    def test_advertised_limits_validation_and_legacy_fallback(self):
        api=self.bare_api();api.configure_limits(None);self.assertEqual(api.max_file_bytes,10*MIB)
        api.configure_limits({'max_file_bytes':100*MIB});self.assertEqual(api.max_file_bytes,100*MIB)
        for value in (0,MIB-1,HARD_MAX_FILE_BYTES+1,'52428800',True):
            with self.subTest(value=value),self.assertRaises(ValueError):api.configure_limits({'max_file_bytes':value})

    def test_file_timeout_and_bounded_response_read(self):
        api=self.bare_api();observed=[]
        class Response:
            headers={}
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):observed.append(('read',n));return b'{}'
        class Opener:
            def open(self,request,timeout):observed.append(('timeout',timeout));return Response()
        api.opener=Opener();api.request('GET','/files/example')
        self.assertEqual(observed,[('timeout',120),('read',encoded_body_limit(50*MIB)+1)])
        observed.clear();api.request('GET','/users')
        self.assertEqual(observed,[('timeout',6),('read',4*MIB+1)])

    def test_declared_response_oversize_rejected_before_read(self):
        api=self.bare_api()
        class Response:
            headers={'Content-Length':str(encoded_body_limit(50*MIB)+1)}
            def __enter__(self):return self
            def __exit__(self,*args):pass
            def read(self,n):raise AssertionError('Oversize response should not be read')
        class Opener:
            def open(self,*args,**kwargs):return Response()
        api.opener=Opener()
        with self.assertRaisesRegex(RuntimeError,'exceeds'):api.request('GET','/files/example')
        self.assertTrue(api.transfer_slot.acquire(blocking=False));api.transfer_slot.release()

    def test_client_busy_transfer_refused(self):
        api=self.bare_api();api.transfer_slot.acquire()
        try:
            with self.assertRaisesRegex(RuntimeError,'already transferring'):api.request('GET','/files/example')
        finally:api.transfer_slot.release()

    def test_cli_limit_range_rejected_before_server_start(self):
        for value in ('0','101'):
            result=subprocess.run([sys.executable,str(source.parent/'server.py'),'--host','127.0.0.1','--cert','not-used.pem','--key','not-used.key','--max-file-mib',value],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0);self.assertIn('invalid choice',result.stderr)

if __name__=='__main__':unittest.main(verbosity=2)
