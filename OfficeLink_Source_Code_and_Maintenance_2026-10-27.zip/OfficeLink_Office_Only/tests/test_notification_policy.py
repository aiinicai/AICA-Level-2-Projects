import sys,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import notification_policy
class NotificationPolicy(unittest.TestCase):
    def test_windows_only_explicitly_accepting_state(self):
        with patch.object(notification_policy.sys,'platform','win32'):
            for state in (None,1,2,3,4,5,6,7):
                with self.subTest(state=state),patch.object(notification_policy,'_windows_notification_state',return_value=state):
                    self.assertEqual(notification_policy.attention_allowed(),state==5)
    def test_windows_query_failure_fails_quiet(self):
        with patch.object(notification_policy.sys,'platform','win32'),patch.object(notification_policy,'_windows_notification_state',side_effect=OSError('unavailable')):
            self.assertFalse(notification_policy.attention_allowed())
    def test_nonwindows_dev_context(self):
        with patch.object(notification_policy.sys,'platform','linux'):
            self.assertTrue(notification_policy.attention_allowed())
if __name__=='__main__':unittest.main()
