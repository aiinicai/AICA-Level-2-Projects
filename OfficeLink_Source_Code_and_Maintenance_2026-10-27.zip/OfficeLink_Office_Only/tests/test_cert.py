"""Certificate provisioning checks; temporary files only."""
import sys, tempfile, unittest, ssl, socket, threading
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from make_cert import generate
from cryptography import x509
from cryptography.hazmat.primitives import serialization

class Certificates(unittest.TestCase):
    def test_generation_and_overwrite_refusal(self):
        with tempfile.TemporaryDirectory() as folder:
            password='temporary-certificate-test-passphrase'
            fp=generate(folder,['127.0.0.1','office-server'],password)
            root=Path(folder)
            self.assertEqual(len(fp),64)
            ca=x509.load_pem_x509_certificate((root/'ca.pem').read_bytes())
            self.assertTrue(ca.extensions.get_extension_for_class(x509.BasicConstraints).value.ca)
            cert=x509.load_pem_x509_certificate((root/'server.pem').read_bytes())
            self.assertFalse(cert.extensions.get_extension_for_class(x509.BasicConstraints).value.ca)
            self.assertIn('office-server',cert.extensions.get_extension_for_class(x509.SubjectAlternativeName).value.get_values_for_type(x509.DNSName))
            serialization.load_pem_private_key((root/'ca-key.pem').read_bytes(),password.encode())
            context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            context.load_cert_chain(root/'server.pem',root/'server-key.pem')
            with self.assertRaises(FileExistsError): generate(folder,['127.0.0.1'],password)
    def test_generated_chain_passes_strict_tls_handshake(self):
        with tempfile.TemporaryDirectory() as folder:
            generate(folder,['127.0.0.1'],'temporary-strict-test-passphrase')
            root=Path(folder)
            ca=x509.load_pem_x509_certificate((root/'ca.pem').read_bytes())
            cert=x509.load_pem_x509_certificate((root/'server.pem').read_bytes())
            ski=ca.extensions.get_extension_for_class(x509.SubjectKeyIdentifier).value.digest
            self.assertEqual(cert.extensions.get_extension_for_class(x509.AuthorityKeyIdentifier).value.key_identifier,ski)
            server_context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
            server_context.load_cert_chain(root/'server.pem',root/'server-key.pem')
            client_context=ssl.create_default_context(cafile=str(root/'ca.pem'))
            client_context.verify_flags |= ssl.VERIFY_X509_STRICT
            errors=[]
            with socket.socket() as listener:
                listener.bind(('127.0.0.1',0));listener.listen();listener.settimeout(5)
                def serve():
                    try:
                        connection,_=listener.accept();connection.settimeout(5)
                        with server_context.wrap_socket(connection,server_side=True) as stream:
                            self.assertEqual(stream.recv(4),b'ping');stream.sendall(b'pong')
                    except Exception as exc:errors.append(exc)
                worker=threading.Thread(target=serve);worker.start()
                try:
                    with socket.create_connection(listener.getsockname(),timeout=5) as connection:
                        with client_context.wrap_socket(connection,server_hostname='127.0.0.1') as stream:
                            stream.sendall(b'ping');self.assertEqual(stream.recv(4),b'pong')
                finally:worker.join(timeout=6)
                self.assertFalse(worker.is_alive());self.assertEqual(errors,[])
    def test_weak_passphrase_refused(self):
        with tempfile.TemporaryDirectory() as folder:
            with self.assertRaises(ValueError): generate(folder,['127.0.0.1'],'short')
            self.assertEqual(list(Path(folder).iterdir()),[])

if __name__=='__main__': unittest.main()
