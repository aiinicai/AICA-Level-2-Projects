"""Offscreen Qt password workflow tests. No real account/password or Windows claim."""
import importlib.util,os,sys,tempfile,threading,time,unittest
from pathlib import Path
from concurrent.futures import Future
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
HAS_QT=importlib.util.find_spec('PyQt6') is not None
if HAS_QT:
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PyQt6.QtWidgets import QApplication,QDialog
    from client import PasswordDialog,Login

class FakeAPI:
    def __init__(self,error=None,gate=None):self.token='temporary-test-token';self.calls=[];self.error=error;self.gate=gate
    def request(self,method,path,body):
        self.calls.append((method,path,body))
        if self.gate:self.gate.wait(3)
        if self.error:raise RuntimeError(self.error)
        return {'ok':True,'reauthenticate':True}

@unittest.skipUnless(HAS_QT,'PyQt6 unavailable')
class PasswordUITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.app=QApplication.instance() or QApplication([])
    def wait_for(self,predicate):
        until=time.monotonic()+4
        while time.monotonic()<until:
            self.app.processEvents()
            if predicate():return
            time.sleep(.01)
        self.fail('Qt password workflow timeout')
    def fill(self,d):
        d.current.setText('temporary-old-password');d.new.setText('new-personal-password');d.confirm.setText('new-personal-password')
    def test_success_clears_fields_and_requires_login(self):
        api=FakeAPI();d=PasswordDialog(api);self.fill(d);d.change_password()
        self.wait_for(lambda:d.result()==QDialog.DialogCode.Accepted)
        self.assertEqual(api.calls[0][1],'/change-password');self.assertIsNone(api.token)
        self.assertTrue(all(not f.text() for f in (d.current,d.new,d.confirm)));d.pool.shutdown(wait=True)
    def test_validation_does_not_send_mismatched_or_same_password(self):
        api=FakeAPI();d=PasswordDialog(api);self.fill(d);d.confirm.setText('mismatch');d.change_password();self.assertEqual(api.calls,[])
        d.new.setText(d.current.text());d.confirm.setText(d.current.text());d.change_password();self.assertEqual(api.calls,[])
        d.reject();self.assertTrue(all(not f.text() for f in (d.current,d.new,d.confirm)))
    def test_cancel_mandatory_revokes_token(self):
        api=FakeAPI();d=PasswordDialog(api,mandatory=True);self.fill(d);d.reject();d.pool.shutdown(wait=True)
        self.assertEqual(api.calls,[('POST','/logout',{})]);self.assertIsNone(api.token)
        self.assertTrue(all(not f.text() for f in (d.current,d.new,d.confirm)))
    def test_cancel_optional_preserves_session(self):
        api=FakeAPI();d=PasswordDialog(api);self.fill(d);d.reject();self.assertEqual(api.calls,[]);self.assertIsNotNone(api.token)
    def test_pending_close_and_repeat_submit_are_guarded(self):
        gate=threading.Event();api=FakeAPI(gate=gate);d=PasswordDialog(api);self.fill(d);d.change_password();d.change_password();d.reject()
        self.assertTrue(d.pending);self.assertFalse(d.closed);gate.set()
        self.wait_for(lambda:d.closed);self.assertEqual(len(api.calls),1);d.pool.shutdown(wait=True)
    def test_server_error_keeps_workspace_locked_and_fields_empty(self):
        api=FakeAPI(error='403: Current password is incorrect');d=PasswordDialog(api,mandatory=True);self.fill(d);d.change_password()
        self.wait_for(lambda:not d.pending)
        self.assertNotEqual(d.result(),QDialog.DialogCode.Accepted);self.assertIn('incorrect',d.status.text())
        self.assertTrue(all(not f.text() for f in (d.current,d.new,d.confirm)));api.error=None;d.reject();d.pool.shutdown(wait=True)
    def test_real_tls_password_dialog_revokes_session_and_reauthenticates(self):
        from test_server import IntegrationTests
        from client import API
        IntegrationTests.setUpClass()
        fixture=IntegrationTests(methodName='test_auth_logout_expiry_and_no_password_in_roster')
        fixture.setUp()
        try:
            with fixture.app.lock,fixture.app.db:
                fixture.app.db.execute('UPDATE users SET must_change_password=1 WHERE username=?',('alice',))
            api=API(fixture.url,ca_pem=fixture.cert.read_text())
            result=api.request('POST','/login',{'username':'alice','password':fixture.password});api.token=result['token']
            self.assertTrue(result['user']['must_change_password'])
            old_token=api.token;dialog=PasswordDialog(api,mandatory=True)
            dialog.current.setText(fixture.password);dialog.new.setText('new-tls-test-password');dialog.confirm.setText('new-tls-test-password');dialog.change_password()
            self.wait_for(lambda:dialog.result()==QDialog.DialogCode.Accepted);dialog.pool.shutdown(wait=True)
            api.token=old_token
            with self.assertRaisesRegex(RuntimeError,'401:'):api.request('GET','/users')
            api.token=None
            result=api.request('POST','/login',{'username':'alice','password':'new-tls-test-password'})
            self.assertFalse(result['user']['must_change_password'])
        finally:
            fixture.tearDown();IntegrationTests.tearDownClass()

    def test_mandatory_login_does_not_accept_workspace(self):
        profile={'organization':'Test office','server':'https://127.0.0.1:8443','ca_pem':'','profile_id':'a'*64}
        with tempfile.TemporaryDirectory() as folder,patch('deployment_profile._preferences_path',return_value=Path(folder)/'preferences.json'):
            login=Login(profile);api=FakeAPI();future=Future();future.set_result((api,{'username':'alice','must_change_password':True}))
            with patch.object(PasswordDialog,'exec',return_value=QDialog.DialogCode.Accepted):login.finished_login(future,None,None)
            self.assertNotEqual(login.result(),QDialog.DialogCode.Accepted);self.assertIsNone(login.api)
            self.assertIn('Sign in again',login.status.text());login.reject()
if __name__=='__main__':unittest.main()
