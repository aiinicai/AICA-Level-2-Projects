"""Headless tests of exact extracted client helpers; not a Qt/Windows hardware test."""
import ast
import base64
from pathlib import Path
import sys
import threading
import types
import unittest
from unittest.mock import patch

source = Path(__file__).resolve().parents[1] / 'client.py'
tree = ast.parse(source.read_text())
nodes = [node for node in tree.body if
    (isinstance(node, (ast.Import, ast.ImportFrom)) and not
     (isinstance(node, ast.ImportFrom) and node.module.startswith('PyQt6'))) or
    (isinstance(node, ast.ClassDef) and node.name in ('API', 'NoRedirect', 'Voice'))]
namespace = {}
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(source), 'exec'), namespace)
API, NoRedirect, Voice = (namespace[k] for k in ('API', 'NoRedirect', 'Voice'))


class ClientHelpers(unittest.TestCase):
    def test_reject_unsafe_origins_before_tls(self):
        for url in ('http://server:8443', 'https://user:password@server',
                    'https://server/path', 'https://server?query=1', 'https://server/#secret'):
            with self.subTest(url=url), self.assertRaises(ValueError):
                API(url, 'not-a-real-ca.pem')

    def test_redirect_never_follows_even_to_https(self):
        with self.assertRaisesRegex(RuntimeError, 'redirect refused'):
            NoRedirect().redirect_request(None, None, 302, 'Found', {}, 'https://elsewhere')

    def test_certificate_error_is_actionable(self):
        import ssl, urllib.error
        error=ssl.SSLCertVerificationError(1,'certificate verify failed')
        error.verify_message='Missing Authority Key Identifier'
        class FailingOpener:
            def open(self,*args,**kwargs):raise urllib.error.URLError(error)
        api=API.__new__(API);api.url='https://127.0.0.1:8443';api.token=None;api.opener=FailingOpener()
        with self.assertRaisesRegex(RuntimeError,'Missing Authority Key Identifier'):
            api.request('GET','/users')

    def test_tls_requires_real_ca(self):
        with self.assertRaises((FileNotFoundError, OSError)):
            API('https://office-server:8443', 'not-a-real-ca.pem')

    def test_synthetic_pcm_capture_relay_playback(self):
        pcm = b'\x20\x01' * 3200
        captured, played, errors = [], [], []
        complete = threading.Event()
        class Stream:
            def __init__(self, **kwargs): self.callback = kwargs.get('callback')
            def __enter__(self):
                if self.callback: self.callback(pcm, 3200, None, None)
                return self
            def __exit__(self, *args): pass
            def write(self, frame):
                played.append(frame); complete.set()
        class Relay:
            def request(self, method, path, data=None):
                if method == 'POST':
                    captured.append(base64.b64decode(data['data'])); return {}
                return {'frames': [base64.b64encode(pcm).decode()]}
        fake_sd = types.SimpleNamespace(RawInputStream=Stream, RawOutputStream=Stream)
        with patch.dict(sys.modules, {'sounddevice': fake_sd}):
            voice = Voice(Relay(), 'test-call', errors.append)
            self.assertTrue(complete.wait(2))
            voice.stop(); voice.thread.join(2)
        self.assertFalse(voice.thread.is_alive())
        self.assertEqual(captured[0], pcm)
        self.assertEqual(played[0], pcm)
        self.assertEqual(errors, [])

    def test_device_error_stops_voice(self):
        errors = []
        def missing(**kwargs): raise RuntimeError('No audio input device')
        with patch.dict(sys.modules, {'sounddevice': types.SimpleNamespace(RawInputStream=missing)}):
            voice = Voice(None, 'test-call', errors.append); voice.thread.join(2)
        self.assertTrue(voice.stop_event.is_set())
        self.assertEqual(errors, ['No audio input device'])


if __name__ == '__main__': unittest.main()
