"""Visible document errors and single-transfer UI guards using actual offscreen Qt."""
import os,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]));os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
try:
    import client
    from PyQt6.QtCore import QUrl
    HAS_QT=True
except ImportError:HAS_QT=False
@unittest.skipUnless(HAS_QT,'PyQt6 not installed')
class FileUI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):cls.qt=client.QApplication.instance() or client.QApplication([])
    def setUp(self):
        class NoNetworkWindow(client.Window):
            def poll(self):pass
        class API:
            max_file_bytes=1024*1024
            def request(self,*args,**kwargs):return{}
        self.window=NoNetworkWindow(API(),{'id':1,'username':'test','display_name':'Test'})
    def tearDown(self):self.window.force_quit=True;self.window.close();self.window.pool.shutdown(wait=True);self.qt.processEvents()
    def test_oversize_file_has_visible_actionable_error(self):
        self.window.current=1
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'large.pdf'
            with path.open('wb') as f:f.truncate(1024*1024+1)
            with patch.object(client.QFileDialog,'getOpenFileName',return_value=(str(path),'')),patch.object(client.QMessageBox,'warning') as warning:
                self.window.upload()
                end=time.monotonic()+3
                while self.window.transfer_busy and time.monotonic()<end:self.qt.processEvents();time.sleep(.01)
                self.assertFalse(self.window.transfer_busy);warning.assert_called_once()
                self.assertIn('1 MiB',warning.call_args.args[2]);self.assertIn('exceeds',self.window.status.text())
    def test_no_selected_chat_explains_action(self):
        with patch.object(client.QMessageBox,'information') as info:
            self.window.upload();info.assert_called_once();self.assertIn('conversation',info.call_args.args[1].lower())
    def test_busy_download_is_visible_and_not_started(self):
        self.window.transfer_busy=True
        with patch.object(client.QMessageBox,'information') as info,patch.object(self.window,'submit') as submit:
            self.window.download(QUrl('file:'+'a'*32));info.assert_called_once();submit.assert_not_called()
    def test_save_cancel_releases_busy_state(self):
        self.window.current=1;self.window.transfer_busy=True
        with patch.object(client.QFileDialog,'getSaveFileName',return_value=('','')):
            self.window.save_file({'name':'test.pdf','data':'eA=='})
        self.assertFalse(self.window.transfer_busy);self.assertTrue(self.window.attach.isEnabled())
if __name__=='__main__':unittest.main()
