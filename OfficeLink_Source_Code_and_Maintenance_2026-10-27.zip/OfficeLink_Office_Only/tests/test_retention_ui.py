"""Real offscreen Qt retention rendering; no real files are deleted by these tests."""
import os,sys,time,unittest
from pathlib import Path
os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
try:
    from client import QApplication,Window,STYLE
    HAS_QT=True
except ImportError:HAS_QT=False

@unittest.skipUnless(HAS_QT,'PyQt6 not installed')
class RetentionUI(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt=QApplication.instance() or QApplication([]);cls.qt.setStyleSheet(STYLE)
    def setUp(self):
        class NoNetworkWindow(Window):
            def poll(self):pass
        class FakeAPI:
            def request(self,*args,**kwargs):return{}
        self.w=NoNetworkWindow(FakeAPI(),{'id':1,'username':'test','display_name':'Test'})
        self.w.isActiveWindow=lambda:False
        self.w.current=1
        self.room={'id':1,'name':'Room','members':[1,2],'incoming_count':1}
        self.message={'id':7,'sender_id':2,'text':'Shared a document','created_at':1,'file_id':'a'*32,'file_name':'Report <final>.pdf','file_expired':False,'file_expires_at':time.time()+86400}
    def tearDown(self):
        self.w.force_quit=True;self.w.close();self.w.pool.shutdown(wait=True);self.qt.processEvents()
    def refresh_state(self,state):
        self.w.refreshed(({'users':[]},{'conversations':[self.room]},{'messages':[],'attachment_states':[state]},{'calls':[]}),1,self.w.generation)
    def test_expired_attachment_is_tombstone_without_download_link(self):
        self.w.render_messages([dict(self.message,file_expired=True)])
        self.assertIn('Attachment expired — no longer available from server',self.w.chat.toPlainText())
        self.assertIn('Report <final>.pdf',self.w.chat.toPlainText())
        self.assertNotIn('href="file:',self.w.chat.toHtml())
        self.assertIn('Shared a document',self.w.chat.toPlainText())
    def test_unexpired_attachment_has_deadline_and_download_link(self):
        self.w.render_messages([self.message])
        self.assertIn('Server attachment expires',self.w.chat.toPlainText())
        self.assertIn('local time',self.w.chat.toPlainText())
        self.assertIn('href="file:',self.w.chat.toHtml())
    def test_state_refresh_expires_cached_attachment_without_new_text(self):
        self.w.render_messages([self.message])
        self.refresh_state({'file_id':'a'*32,'file_expired':True,'file_expires_at':self.message['file_expires_at']})
        self.assertEqual(len(self.w.messages),1)
        self.assertTrue(self.w.messages[0]['file_expired'])
        self.assertIn('Attachment expired',self.w.chat.toPlainText())
        self.assertNotIn('href="file:',self.w.chat.toHtml())
    def test_disabling_pending_expiry_refreshes_cached_deadline(self):
        self.w.render_messages([self.message])
        self.refresh_state({'file_id':'a'*32,'file_expired':False,'file_expires_at':None})
        self.assertNotIn('Server attachment expires',self.w.chat.toPlainText())
        self.assertIn('href="file:',self.w.chat.toHtml())
    def test_no_local_clock_guess_of_permanent_expiry(self):
        self.w.render_messages([dict(self.message,file_expires_at=1,file_expired=False)])
        self.assertNotIn('Attachment expired',self.w.chat.toPlainText())
        self.assertIn('href="file:',self.w.chat.toHtml())
    def test_storage_warning_thresholds_and_existing_file_disclosure(self):
        for used,expected in ((80,'Storage filling up'),(90,'Storage almost full'),(100,'Storage full')):
            with self.subTest(used=used):
                self.w.update_storage_info({'used_bytes':used,'quota_bytes':100,'retention_enabled':True,'legacy_unmanaged_files':3})
                self.assertIn(expected,self.w.storage_info.text())
                self.assertIn('3 existing file(s) have no automatic expiry',self.w.storage_info.text())
        self.w.update_storage_info({'used_bytes':0,'quota_bytes':100,'retention_enabled':False,'legacy_unmanaged_files':0})
        self.assertIn('expiry OFF',self.w.storage_info.text())
        self.assertIn('Downloaded copies',self.w.storage_info.toolTip())
    def test_old_server_storage_404_does_not_break_chat_poll(self):
        class OldAPI:
            def request(self,method,path,*args):
                if path=='/storage':raise RuntimeError('404: Endpoint not found')
                return {'users':[]} if path=='/users' else {'conversations':[]} if path=='/conversations' else {'messages':[]} if path.startswith('/messages') else {'calls':[]}
        self.w.api=OldAPI()
        self.w.submit=lambda work,success=None,failure=None:success(work())
        Window.poll(self.w)
        self.assertFalse(self.w.polling)
        self.assertFalse(self.w.storage_supported)
        self.assertIn('unavailable on this server version',self.w.storage_info.text())
    def test_invalid_storage_metadata_is_handled(self):
        self.w.update_storage_info({'used_bytes':-1,'quota_bytes':0})
        self.assertIn('unavailable',self.w.storage_info.text())

if __name__=='__main__':unittest.main()
