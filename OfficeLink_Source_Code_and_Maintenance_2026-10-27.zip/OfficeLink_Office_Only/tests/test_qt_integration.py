"""Real offscreen Qt + loopback HTTPS smoke, not Windows GUI/hardware validation."""
import importlib.util, os, secrets, ssl, sys, tempfile, threading, time, unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
HAS_QT=importlib.util.find_spec('PyQt6') is not None
if HAS_QT:
    os.environ.setdefault('QT_QPA_PLATFORM','offscreen')
    from PyQt6.QtWidgets import QApplication, QDialog
    from client import API, Login, Window, STYLE
    from deployment_profile import validate_profile
    from make_cert import generate
    from server import App, Server

@unittest.skipUnless(HAS_QT,'PyQt6 not installed: run with approved dev dependencies for offscreen UI test')
class QtIntegration(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.qt=QApplication.instance() or QApplication([])
        cls.qt.setStyleSheet(STYLE);cls.qt.setQuitOnLastWindowClosed(False)
    def wait_for(self,predicate,seconds=8):
        end=time.monotonic()+seconds
        while time.monotonic()<end:
            self.qt.processEvents()
            if predicate():return
            time.sleep(.015)
        self.fail('Timed out waiting for Qt/HTTPS condition')
    def test_preconfigured_login_and_actual_two_way_messages(self):
        with tempfile.TemporaryDirectory() as folder:
            previous=os.environ.get('XDG_CONFIG_HOME');os.environ['XDG_CONFIG_HOME']=folder
            root=Path(folder);generate(root/'certs',['127.0.0.1'],'temporary-qt-certificate-passphrase')
            app=App(root/'data');password=secrets.token_urlsafe(20)
            app.add_user('alice','Alice',password,'admin');app.add_user('bob','Bob',password)
            ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);ctx.load_cert_chain(root/'certs/server.pem',root/'certs/server-key.pem')
            server=Server(('127.0.0.1',0),app,ctx);worker=threading.Thread(target=server.serve_forever,daemon=True);worker.start()
            url='https://127.0.0.1:'+str(server.server_port)
            profile=validate_profile({'version':1,'server':url,'ca_pem':(root/'certs/ca.pem').read_text(),'organization':'UI test office'})
            login=Login(profile);window=None
            try:
                self.assertFalse(hasattr(login,'server'));self.assertFalse(hasattr(login,'ca'))
                login.username.setText('alice');login.password.setText(password);login.login()
                self.wait_for(lambda:login.result()==QDialog.DialogCode.Accepted)
                self.assertEqual(login.password.text(),'')
                bob=API(url,ca_pem=profile['ca_pem']);result=bob.request('POST','/login',{'username':'bob','password':password});bob.token=result['token']
                room=login.api.request('POST','/conversations',{'name':'Test conversation','members':[result['user']['id']]})
                window=Window(login.api,login.user,profile['organization']);window.show()
                self.wait_for(lambda:not window.polling and len(window.conversations)==1)
                window.select_room(window.conversations[0]);self.wait_for(lambda:not window.polling)
                window.input.setPlainText('Hello from the real Qt client');window.send_message()
                self.wait_for(lambda:window.send.isEnabled() and not window.input.toPlainText())
                messages=bob.request('GET','/messages?conversation_id='+str(room['id']))['messages']
                self.assertEqual(messages[-1]['text'],'Hello from the real Qt client')
                bob.request('POST','/messages',{'conversation_id':room['id'],'text':'Reply from the colleague over HTTPS'})
                self.wait_for(lambda:not window.polling);window.poll()
                self.wait_for(lambda:any(m['text']=='Reply from the colleague over HTTPS' for m in window.messages))
                window.preferences['notifications_enabled']=False  # DND must not suppress unread bookkeeping.
                window.showMinimized();self.qt.processEvents()
                before=window.unread.get(room['id'],0)
                bob.request('POST','/messages',{'conversation_id':room['id'],'text':'A real background message'})
                self.wait_for(lambda:not window.polling);window.poll()
                self.wait_for(lambda:window.incoming_counts.get(room['id'],0)>=2)
                self.assertEqual(window.unread.get(room['id'],0),before+1)
                self.assertIn('('+str(sum(window.unread.values()))+')',window.windowTitle())
                prefs=root/'OfficeLink/preferences.json'
                if prefs.exists():
                    saved=prefs.read_text();self.assertNotIn(password,saved);self.assertNotIn(login.api.token,saved)
            finally:
                if window is not None:
                    window.sign_out();self.qt.processEvents();window.pool.shutdown(wait=True)
                else:login.reject()
                server.shutdown();server.server_close();worker.join(5);app.db.close()
                if previous is None:os.environ.pop('XDG_CONFIG_HOME',None)
                else:os.environ['XDG_CONFIG_HOME']=previous
