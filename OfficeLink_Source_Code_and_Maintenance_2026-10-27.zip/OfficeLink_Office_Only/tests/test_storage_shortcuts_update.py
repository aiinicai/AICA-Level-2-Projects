"""5 GiB aggregate-boundary and Windows-shortcut orchestration regression tests.

Shortcut COM is mocked on Linux; run the supplied Windows check on a real PC.
Quota boundary tests use synthetic SQL length accounting, not 5 GiB of RAM/disk.
"""
import base64
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import desktop_shortcut
import OfficeLink
import client
from server import App, APIError, MAX_STORAGE


class StorageUpdate(unittest.TestCase):
    def test_metadata_and_exact_aggregate_boundary_preserve_saved_content(self):
        with tempfile.TemporaryDirectory() as folder:
            app = App(folder)
            try:
                app.add_user('alice','Alice','temporary-alice-password','admin')
                auth=app.dispatch('POST','/login',{},dict(username='alice',password='temporary-alice-password'),None,'127.0.0.1')
                token=auth['token']
                self.assertEqual(MAX_STORAGE,5*1024**3)
                self.assertEqual(auth['limits']['storage_quota_bytes'],5*1024**3)
                self.assertEqual(auth['limits']['max_file_bytes'],50*1024**2)
                room=app.dispatch('POST','/conversations',{},dict(name='Saved conversation',members=[auth['user']['id']]),token,'127.0.0.1')['id']
                marker=b'synthetic-existing-file'
                with app.db:app.db.execute('INSERT INTO files(id,conversation_id,name,data) VALUES(?,?,?,?)',('baseline',room,'saved.pdf',marker))
                logical=[1024**3]  # A pre-existing dataset already at the previous ceiling.
                app.db.create_function('length',1,lambda data:logical[0] if data==marker else len(data))
                def upload(raw):
                    return app.dispatch('POST','/uploads',{},dict(conversation_id=room,name='new.pdf',data=base64.b64encode(raw).decode()),token,'127.0.0.1')
                upload(b'allowed above the old quota')
                self.assertGreater(app.storage_status()['used_bytes'],1024**3)
                other=app.db.execute('SELECT data FROM files WHERE id<>?',('baseline',)).fetchone()[0]
                final=b'exactly reaches quota'
                logical[0]=MAX_STORAGE-len(other)-len(final)
                upload(final)
                self.assertEqual(app.storage_status()['used_bytes'],MAX_STORAGE)
                with self.assertRaises(APIError) as caught:upload(b'x')
                self.assertIn('5 GiB',str(caught.exception))
                self.assertEqual(app.storage_status()['used_bytes'],MAX_STORAGE)
                self.assertEqual(app.db.execute('SELECT data FROM files WHERE id=?',('baseline',)).fetchone()[0],marker)
                self.assertFalse(app.retention_enabled())
                self.assertEqual(app.db.execute('SELECT count(*) FROM users').fetchone()[0],1)
            finally:app.db.close()


class DesktopShortcutUpdate(unittest.TestCase):
    @unittest.skipUnless(sys.platform == 'win32', 'Native Windows shortcut verification requires Windows.')
    def test_native_windows_shortcut_reuse_and_launch(self):
        shortcut = None
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/"Office team's & café $(literal)";root.mkdir()
            (root/'OfficeLink.py').write_text("from pathlib import Path\nPath(__file__).with_name('opened.txt').write_text('launched')\n",encoding='utf-8')
            try:
                shortcut=desktop_shortcut.create_desktop_shortcut(root,sys.executable)
                self.assertTrue(Path(shortcut).is_file())
                self.assertEqual(desktop_shortcut.create_desktop_shortcut(root,sys.executable),shortcut)
                os.startfile(shortcut)
                deadline=time.monotonic()+10
                while time.monotonic()<deadline and not (root/'opened.txt').exists():time.sleep(.05)
                self.assertEqual((root/'opened.txt').read_text(),'launched')
            finally:
                if shortcut:Path(shortcut).unlink(missing_ok=True)

    def test_safe_payload_windowed_runtime_and_distinct_host_name(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/"Office team's & café $(literal)";root.mkdir()
            (root/'OfficeLink.py').write_text('# app')
            python=root/'python.exe';python.write_text('stub')
            pythonw=root/'pythonw.exe';pythonw.write_text('stub')
            payload=desktop_shortcut.shortcut_payload(root,python)
            self.assertEqual(payload['target'],str(pythonw))
            self.assertEqual(payload['folder'],str(root))
            self.assertEqual(payload['name'],'OfficeLink')
            self.assertEqual(payload['arguments'],subprocess.list2cmdline([str(root/'OfficeLink.py')]))
            self.assertNotIn('password',payload)
            (root/'office_setup.py').write_text('# host')
            self.assertEqual(desktop_shortcut.shortcut_payload(root,python)['name'],'OfficeLink Host')

    def test_windows_command_uses_data_stdin_and_parses_verified_path(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'OfficeLink.py').write_text('# app')
            ps=root/'System32/WindowsPowerShell/v1.0/powershell.exe';ps.parent.mkdir(parents=True);ps.write_text('stub')
            expected=r'C:\Users\Employee\OneDrive\Desktop\OfficeLink.lnk'
            result=subprocess.CompletedProcess([],0,json.dumps({'path':expected}), '')
            with patch.object(desktop_shortcut.sys,'platform','win32'),patch.dict(os.environ,{'SystemRoot':str(root)}),patch.object(desktop_shortcut.subprocess,'run',return_value=result) as run:
                self.assertEqual(desktop_shortcut.create_desktop_shortcut(root,sys.executable),expected)
                args=run.call_args.args[0];kwargs=run.call_args.kwargs
                self.assertFalse(kwargs.get('shell',False))
                self.assertEqual(base64.b64decode(args[-1]).decode('utf-16le'),desktop_shortcut.POWERSHELL_SCRIPT)
                self.assertEqual(json.loads(kwargs['input'])['folder'],str(root))
                self.assertNotIn(str(root/'OfficeLink.py'),args[-1])
                run.return_value=subprocess.CompletedProcess([],1,'','Blocked by Windows policy')
                with self.assertRaisesRegex(RuntimeError,'Blocked'):desktop_shortcut.create_desktop_shortcut(root,sys.executable)
                run.return_value=subprocess.CompletedProcess([],0,'not JSON','')
                with self.assertRaisesRegex(RuntimeError,'confirm'):desktop_shortcut.create_desktop_shortcut(root,sys.executable)

    def test_shortcut_failure_does_not_block_staff_messenger(self):
        previous=Path.cwd()
        try:
            with tempfile.TemporaryDirectory() as folder,patch.object(OfficeLink,'ROOT',Path(folder)),patch.object(desktop_shortcut,'create_desktop_shortcut',side_effect=OSError('Desktop access denied')),patch.object(client,'main') as main:
                OfficeLink.run_application()
                main.assert_called_once()
                self.assertIn('Desktop access denied',main.call_args.kwargs['startup_notice'])
                self.assertIn('Create_Desktop_Shortcut.cmd',main.call_args.kwargs['startup_notice'])
        finally:os.chdir(previous)


if __name__=='__main__':unittest.main()
