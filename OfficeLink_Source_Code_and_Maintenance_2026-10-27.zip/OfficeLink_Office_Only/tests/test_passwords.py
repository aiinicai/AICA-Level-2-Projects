"""Temporary-password migration and password lifecycle checks; only temporary accounts."""
import contextlib, io, json, secrets, sqlite3, ssl, sys, tempfile, threading, unittest, urllib.error, urllib.request
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import admin
from server import App, APIError, Server, password_hash, verify_password
from make_cert import generate

class PasswordTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.app=App(self.root/'data');self.old=secrets.token_urlsafe(20);self.new=secrets.token_urlsafe(22)
        self.app.add_user('alice','Alice',self.old,must_change_password=True)
        self.app.add_user('bob','Bob',self.old)
    def tearDown(self):self.app.db.close();self.temp.cleanup()
    def request(self,method,path,body=None,token=''):
        return self.app.dispatch(method,path,{},body or {},token,'127.0.0.1')
    def login(self,name='alice',password=None):
        return self.request('POST','/login',{'username':name,'password':password or self.old})
    def rejected(self,status,method,path,body=None,token=''):
        with self.assertRaises(APIError) as caught:self.request(method,path,body,token)
        self.assertEqual(caught.exception.status,status)
        return caught.exception.message
    def test_existing_database_additive_migration_preserves_access(self):
        legacy=self.root/'legacy';legacy.mkdir();db=sqlite3.connect(legacy/'office.db')
        hashed=password_hash(self.old)
        db.execute('CREATE TABLE users(id INTEGER PRIMARY KEY,username TEXT UNIQUE NOT NULL,display_name TEXT NOT NULL,password TEXT NOT NULL,role TEXT NOT NULL,enabled INTEGER DEFAULT 1)')
        db.execute('INSERT INTO users(username,display_name,password,role) VALUES(?,?,?,?)',('existing','Existing',hashed,'staff'));db.commit();db.close()
        migrated=App(legacy)
        try:
            row=migrated.db.execute('SELECT * FROM users').fetchone()
            self.assertEqual(row['password'],hashed);self.assertEqual(row['must_change_password'],0)
            login=migrated.dispatch('POST','/login',{}, {'username':'existing','password':self.old},'','127.0.0.1')
            self.assertFalse(login['user']['must_change_password'])
        finally:migrated.db.close()
    def test_temporary_session_cannot_access_workspace(self):
        login=self.login();token=login['token'];self.assertTrue(login['user']['must_change_password'])
        for method,path in [('GET','/users'),('GET','/conversations'),('POST','/conversations'),('GET','/messages'),('POST','/messages'),('POST','/uploads'),('GET','/files/anything'),('GET','/calls'),('POST','/calls')]:
            with self.subTest(path=path):self.assertIn('temporary password',self.rejected(403,method,path,token=token))
        self.assertTrue(self.request('POST','/heartbeat',token=token)['ok'])
        self.assertTrue(self.request('POST','/logout',token=token)['ok'])
    def test_change_clears_requirement_and_requires_reauthentication(self):
        token=self.login()['token']
        result=self.request('POST','/change-password',{'current_password':self.old,'new_password':self.new},token)
        self.assertEqual(result,{'ok':True,'reauthenticate':True})
        self.rejected(401,'GET','/users',token=token)
        self.rejected(401,'POST','/login',{'username':'alice','password':self.old})
        current=self.login(password=self.new);self.assertFalse(current['user']['must_change_password'])
        self.assertTrue(self.request('GET','/users',token=current['token'])['users'])
        saved=self.app.db.execute('SELECT password FROM users WHERE username="alice"').fetchone()[0]
        self.assertNotEqual(saved,self.new);self.assertTrue(verify_password(self.new,saved))
    def test_wrong_current_password_does_not_change_or_revoke(self):
        token=self.login()['token'];before=self.app.db.execute('SELECT password FROM users WHERE username="alice"').fetchone()[0]
        self.rejected(403,'POST','/change-password',{'current_password':'incorrect current','new_password':self.new},token)
        self.assertEqual(before,self.app.db.execute('SELECT password FROM users WHERE username="alice"').fetchone()[0])
        self.assertTrue(self.request('POST','/heartbeat',token=token)['ok'])
    def test_invalid_and_reused_new_passwords_rejected(self):
        token=self.login()['token']
        for new in ('short','x'*257,self.old,None):
            with self.subTest(length=len(new) if new else None):self.rejected(400,'POST','/change-password',{'current_password':self.old,'new_password':new},token)
    def test_account_wide_rate_limit_and_expiry(self):
        one=self.login()['token'];two=self.login()['token'];uid=self.app.auth(one)['id']
        for index in range(5):self.rejected(403,'POST','/change-password',{'current_password':'not the password','new_password':self.new},one if index%2 else two)
        self.rejected(429,'POST','/change-password',{'current_password':self.old,'new_password':self.new},two)
        started,count=self.app.password_attempts[uid];self.app.password_attempts[uid]=(started-301,count)
        self.assertTrue(self.request('POST','/change-password',{'current_password':self.old,'new_password':self.new},one)['ok'])
    def test_change_revokes_all_own_sessions_and_calls_only(self):
        self.app.db.execute('UPDATE users SET must_change_password=0 WHERE username="alice"');self.app.db.commit()
        alice=self.login()['token'];alice_other=self.login()['token'];bob=self.login('bob')['token']
        bob_id=self.app.auth(bob)['id'];call=self.request('POST','/calls',{'peer_id':bob_id},alice)['call']
        self.request('POST','/calls/'+call['id']+'/accept',token=bob)
        self.request('POST','/change-password',{'current_password':self.old,'new_password':self.new},alice)
        for token in (alice,alice_other):self.rejected(401,'GET','/users',token=token)
        self.assertTrue(self.request('GET','/users',token=bob)['users'])
        self.assertEqual(self.request('GET','/calls',token=bob)['calls'],[])
        self.assertNotIn(call['id'],self.app.audio)
    def test_admin_reset_requires_change_and_never_prints_password(self):
        token=self.login('bob')['token'];output=io.StringIO()
        with patch.object(sys,'argv',['admin.py','--data',str(self.root/'data'),'reset-password','--username','bob']),patch('getpass.getpass',side_effect=[self.new,self.new]),contextlib.redirect_stdout(output):admin.main()
        self.assertNotIn(self.new,output.getvalue())
        self.rejected(401,'GET','/users',token=token)
        self.assertTrue(self.login('bob',self.new)['user']['must_change_password'])
    def test_admin_add_user_uses_temporary_password(self):
        output=io.StringIO()
        with patch.object(sys,'argv',['admin.py','--data',str(self.root/'data'),'add-user','--username','newstaff','--name','New Staff']),patch('getpass.getpass',side_effect=[self.new,self.new]),contextlib.redirect_stdout(output):admin.main()
        self.assertNotIn(self.new,output.getvalue())
        self.assertTrue(self.login('newstaff',self.new)['user']['must_change_password'])
    def test_change_endpoint_requires_authenticated_token(self):
        self.rejected(401,'POST','/change-password',{'current_password':self.old,'new_password':self.new})
    def test_actual_strict_https_password_change(self):
        certs=self.root/'certs';generate(certs,['127.0.0.1'],'temporary-password-test-cert-passphrase')
        context=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER);context.load_cert_chain(certs/'server.pem',certs/'server-key.pem')
        server=Server(('127.0.0.1',0),self.app,context);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        client=ssl.create_default_context(cafile=str(certs/'ca.pem'));client.verify_flags |= ssl.VERIFY_X509_STRICT
        origin='https://127.0.0.1:'+str(server.server_port)
        def api(path,data,token=None):
            headers={'Content-Type':'application/json'}
            if token:headers['Authorization']='Bearer '+token
            request=urllib.request.Request(origin+path,json.dumps(data).encode(),headers,method='POST')
            with urllib.request.urlopen(request,context=client,timeout=5) as response:return json.load(response)
        try:
            login=api('/login',{'username':'alice','password':self.old});self.assertTrue(login['user']['must_change_password'])
            self.assertTrue(api('/change-password',{'current_password':self.old,'new_password':self.new},login['token'])['reauthenticate'])
            self.assertFalse(api('/login',{'username':'alice','password':self.new})['user']['must_change_password'])
        finally:server.shutdown();server.server_close();thread.join(5)

if __name__=='__main__':unittest.main()
