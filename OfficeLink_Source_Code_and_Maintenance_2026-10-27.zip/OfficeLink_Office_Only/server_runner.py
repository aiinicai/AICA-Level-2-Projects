"""Headless host for Windows Task Scheduler. Uses an existing host_config.json."""
import argparse
import errno
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import sqlite3
import ssl
import sys
import time

from host_config import validate_config
from host_lock import HostLock


def load_config(path):
    return validate_config(json.loads(Path(path).read_text(encoding='utf-8')))


def check_database(config):
    path = Path(config['data']) / 'office.db'
    db = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
    try:
        if db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('Database integrity check failed.')
        if not db.execute("SELECT 1 FROM users WHERE enabled=1 AND role='admin'").fetchone():
            raise ValueError('An enabled OfficeLink administrator is required.')
    finally: db.close()


def run(config, logger=None):
    from server import App, Server
    logger = logger or logging.getLogger('officelink')
    data = Path(config['data'])
    stop = data / 'background.stop'
    with HostLock(data):
        stop.unlink(missing_ok=True)  # Only after obtaining exclusive ownership.
        check_database(config)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(config['cert'], config['key'])
        app = App(data); server = None
        try:
            # DHCP may finish after the boot trigger. Retry only an unavailable
            # local address; an occupied port or other failure exits nonzero.
            deadline = time.monotonic() + 180
            while server is None:
                if stop.exists(): return
                try: server = Server((config['host'], int(config['port'])), app, context)
                except OSError as exc:
                    if (exc.errno != errno.EADDRNOTAVAIL and getattr(exc, 'winerror', None) != 10049) or time.monotonic() >= deadline:
                        raise
                    time.sleep(2)
            server.daemon_threads = False
            server.timeout = 0.5
            logger.info('Host started on %s:%s', config['host'], config['port'])
            while not stop.exists(): server.handle_request()
            logger.info('Stop requested; finishing active requests.')
        finally:
            if server is not None: server.server_close()
            app.db.close()
            stop.unlink(missing_ok=True)
            logger.info('Host stopped.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', default=str(Path(__file__).resolve().parent / 'host_config.json'))
    action = parser.add_mutually_exclusive_group()
    action.add_argument('--check', action='store_true')
    action.add_argument('--stop', action='store_true')
    args = parser.parse_args()
    logger = logging.getLogger('officelink')
    try:
        config = load_config(args.config)
        if args.check:
            check_database(config)
            print('Configuration, certificate and database checks passed.'); return 0
        if args.stop:
            # Filesystem access to this restricted host folder is the local
            # administration boundary. No PID killing or network control port.
            (Path(config['data']) / 'background.stop').touch()
            print('Graceful stop requested.'); return 0
        handler = RotatingFileHandler(Path(config['data']) / 'server.log', maxBytes=1024*1024, backupCount=3, encoding='utf-8')
        handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(handler); logger.setLevel(logging.INFO)
        run(config, logger); return 0
    except KeyboardInterrupt: return 0
    except Exception as exc:
        logger.error('Host failed: %s', exc)
        print('OfficeLink host failed: ' + str(exc), file=sys.stderr)
        return 1


if __name__ == '__main__': sys.exit(main())
