# OfficeLink — different-computer migration and background host

Prepared 27 October 2026. Python 3.12.14, Linux, PyQt6 6.11.0 and Qt 6.11.2.

## Executed validation

**117 tests passed; 58 subtests passed; 1 Windows-only shortcut test skipped.** Complete suite duration: 43.56 seconds.

- A synthetic previous-office backup was migrated to a new folder and certified for 192.168.70.122. All rows in users, conversations, members, messages, files and settings matched the source after migration. Existing password login and the retention-enabled choice were preserved. The source backup's SHA-256 stayed unchanged.
- Missing/invalid backups are rejected without creating a destination office. Existing destination directories are not overwritten. Migration checks SQLite integrity, foreign-key references and an enabled administrator.
- The new staff export points to https://192.168.70.122:8443. Tests verify that generated private-key contents and background-host modules are excluded from the allowlisted staff ZIP.
- The headless runner was exercised through real HTTPS on loopback with a test certificate: existing login, persisted chat/document retrieval, graceful stop and a second startup passed. This is a local network-protocol test, not a test on the user's office LAN.
- A separate Python subprocess could not acquire the held per-database lock and could acquire it once the owner released it. Current GUI, CLI and background entry points use this lock. Older packages do not participate.
- Generated startup XML was parsed and checked for the intended Windows SID, Password logon, least-privilege execution, boot delay, no execution-duration limit, restart attempts and correctly quoted paths containing spaces/ampersands. This does not prove Windows Task Scheduler registration or execution.
- Existing TLS, account/password controls, document access restrictions, attachment retention, notification policy, UI and twenty-simultaneous-account loopback tests passed again.
- Previous 5 GiB capacity tests still pass: synthetic SQLite length accounting checks acceptance beyond the former 1 GiB limit, acceptance exactly at 5 GiB, and rejection of an extra byte. No physical 5 GiB database was written. Per-file default remains 50 MiB.
- Desktop shortcut payload/policy/error tests still pass. The Windows-only actual COM shortcut creation/launch test remains skipped on Linux.
- Updated host UI was rendered from real Qt widgets and visually inspected. New modules compile successfully.

The initial migration export test searched the client source for the words PRIVATE KEY, which also occur in its validation code. That assertion was corrected to check the actual generated private-key bytes; the final full suite above passed.

## Required on the real Windows host

The user reported that the preceding pilot worked on two actual office PCs. This revision has not been installed or tested on their Windows host.

1. Confirm OS maintenance (current commercial ESU for Windows 10 or a supported replacement), 64-bit system/runtime, a reserved IP, protected host folder and available disk space.
2. Import the old host's consistent backup, check existing accounts/chats/documents, and distribute the new staff profile to two test PCs.
3. Apply the scoped firewall rule and confirm actual office-network messaging and document transfer.
4. Generate/import the startup XML under the intended Windows account. Verify Windows credential storage, applicable batch-logon policy, task execution, restart settings and runtime path.
5. Reboot and verify staff access before anyone logs in on the host. Check graceful background stop and subsequent task start.
6. Verify actual desktop shortcuts and backups/restoration.

Native Windows task registration, firewall changes, no-logon reboot, and COM shortcuts cannot be verified in this Linux environment. Task import and the scoped firewall command are explicit local installation steps; neither is claimed to be installed automatically here. Failed migrations leave the source intact and may leave a new attempt folder for diagnosis.

Read SERVER_MIGRATION.html for this move. Same-computer updates continue to use UPDATE_5GB_SHORTCUTS.html. The package is reviewable Python source, not a signed executable installer. Automatic scheduled backups are not installed.
