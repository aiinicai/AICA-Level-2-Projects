"""Copy an OfficeLink database backup into a fresh host; preserve the source."""
import sqlite3
from pathlib import Path


def migrate_backup(source, destination, organization, host, port, ca_password):
    from host_config import private_host, validate_config
    from make_cert import generate
    from server import App
    source = Path(source).resolve(strict=True)
    destination = Path(destination).resolve()
    host = private_host(host)
    if not 1024 <= int(port) <= 65535: raise ValueError('Invalid port.')
    if not 1 <= len(organization.strip()) <= 80: raise ValueError('Enter your office name.')
    if len(ca_password) < 12: raise ValueError('Use a recovery passphrase of at least 12 characters.')
    if destination.exists(): raise FileExistsError('Choose a new destination folder. Existing data is never overwritten.')
    # Open the supplied SQLite backup read-only: never create a blank office at a typo.
    original = sqlite3.connect(source.as_uri() + '?mode=ro', uri=True)
    try:
        if original.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('The backup failed its database integrity check.')
        tables = {r[0] for r in original.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        if not {'users','messages','files','members','conversations'} <= tables:
            raise ValueError('This is not an OfficeLink database backup.')
        if not original.execute("SELECT 1 FROM users WHERE enabled=1 AND role='admin'").fetchone():
            raise ValueError('The backup has no enabled OfficeLink administrator.')
        destination.mkdir(parents=True, exist_ok=False)
        data = destination / 'data'; data.mkdir()
        copied = sqlite3.connect(data / 'office.db')
        try: original.backup(copied, pages=256)
        finally: copied.close()
    finally: original.close()
    # Only the new copy receives additive schema updates. Password hashes,
    # messages, file BLOBs and the existing retention choice are preserved.
    app = App(data)
    try:
        if app.db.execute('PRAGMA quick_check').fetchone()[0] != 'ok':
            raise ValueError('The copied database failed its integrity check.')
        if app.db.execute('PRAGMA foreign_key_check').fetchone():
            raise ValueError('The backup has inconsistent account/chat/document references.')
    finally: app.db.close()
    certs = destination / 'certs'
    generate(certs, [host], ca_password)
    return validate_config({'organization': organization.strip(), 'host': host, 'port': int(port),
        'data': str(data), 'ca': str(certs / 'ca.pem'),
        'cert': str(certs / 'server.pem'), 'key': str(certs / 'server-key.pem')})
