"""Opt-in dependency check. Run with Python 3.11+; never installs silently."""
import importlib.util
import subprocess
import sys

PACKAGES = {'PyQt6': 'PyQt6>=6.7,<7', 'sounddevice': 'sounddevice>=0.5,<1'}
missing = [package for module, package in PACKAGES.items() if importlib.util.find_spec(module) is None]
if missing:
    command = [sys.executable, '-m', 'pip', 'install', *missing]
    print('Missing desktop dependencies. Installation downloads third-party code.')
    print('One-command fallback:', subprocess.list2cmdline(command))
    if input('Install these dependencies in this Python environment now? [y/N] ').strip().lower() != 'y':
        sys.exit('No changes made. Install in a virtual environment and retry when ready.')
    try:
        subprocess.run(command, check=True)
    except subprocess.CalledProcessError:
        sys.exit('Installation failed. Use the fallback command above, then run again.')
from client import main
main()
