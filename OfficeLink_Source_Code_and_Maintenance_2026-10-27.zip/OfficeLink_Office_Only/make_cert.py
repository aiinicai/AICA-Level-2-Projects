"""Generate a private CA and server TLS certificate. Never changes system trust."""
import argparse
import getpass
import ipaddress
import os
from pathlib import Path
from datetime import datetime, timedelta, timezone


def generate(output, hosts, password):
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.x509.oid import NameOID, ExtendedKeyUsageOID
    output = Path(output)
    if len(password) < 12:
        raise ValueError('CA key passphrase must be at least 12 characters')
    if not hosts:
        raise ValueError('At least one server IP address or DNS name is required')
    names = []
    for host in hosts:
        if not host or '/' in host or ':' in host and not host.count(':') > 1:
            raise ValueError('Supply bare DNS names or IP addresses, without URL or port')
        try:
            names.append(x509.IPAddress(ipaddress.ip_address(host)))
        except ValueError:
            names.append(x509.DNSName(host.encode('idna').decode('ascii')))
    output.mkdir(parents=True, exist_ok=True)
    filenames = ['ca.pem', 'ca-key.pem', 'server.pem', 'server-key.pem']
    if any((output / f).exists() for f in filenames):
        raise FileExistsError('Refusing to overwrite certificates or keys; select a new directory')
    now = datetime.now(timezone.utc)
    ca_key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    ca_name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, 'OfficeLink Private CA')])
    ca = (x509.CertificateBuilder().subject_name(ca_name).issuer_name(ca_name)
          .public_key(ca_key.public_key()).serial_number(x509.random_serial_number())
          .not_valid_before(now - timedelta(minutes=5)).not_valid_after(now + timedelta(days=1825))
          .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
          .add_extension(x509.SubjectKeyIdentifier.from_public_key(ca_key.public_key()), critical=False)
          .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
          .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
              key_encipherment=False, data_encipherment=False, key_agreement=False,
              key_cert_sign=True, crl_sign=True, encipher_only=False, decipher_only=False), critical=True)
          .sign(ca_key, hashes.SHA256()))
    key = rsa.generate_private_key(public_exponent=65537, key_size=3072)
    cert = (x509.CertificateBuilder()
            .subject_name(x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, hosts[0])]))
            .issuer_name(ca.subject).public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(now - timedelta(minutes=5)).not_valid_after(now + timedelta(days=365))
            .add_extension(x509.BasicConstraints(ca=False, path_length=None), critical=True)
            .add_extension(x509.SubjectKeyIdentifier.from_public_key(key.public_key()), critical=False)
            .add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(ca_key.public_key()), critical=False)
            .add_extension(x509.SubjectAlternativeName(names), critical=False)
            .add_extension(x509.ExtendedKeyUsage([ExtendedKeyUsageOID.SERVER_AUTH]), critical=False)
            .add_extension(x509.KeyUsage(digital_signature=True, content_commitment=False,
              key_encipherment=True, data_encipherment=False, key_agreement=False,
              key_cert_sign=False, crl_sign=False, encipher_only=False, decipher_only=False), critical=True)
            .sign(ca_key, hashes.SHA256()))
    blobs = [ca.public_bytes(serialization.Encoding.PEM),
             ca_key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                  serialization.BestAvailableEncryption(password.encode())),
             cert.public_bytes(serialization.Encoding.PEM),
             key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                               serialization.NoEncryption())]
    for name, blob in zip(filenames, blobs):
        # Exclusive creation prevents accidental overwrite, even with simultaneous runs.
        fd = os.open(output / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'wb') as stream:
            stream.write(blob)
    return ca.fingerprint(hashes.SHA256()).hex()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', default='certs')
    parser.add_argument('--host', action='append', required=True,
                        help='Actual reserved LAN IP/DNS name; repeat to add another SAN')
    args = parser.parse_args()
    try:
        import cryptography  # noqa: F401
    except ImportError:
        raise SystemExit('Setup dependency missing. With approval, run: python -m pip install cryptography')
    password = getpass.getpass('New CA private-key passphrase (12+ characters): ')
    if password != getpass.getpass('Repeat passphrase: '):
        raise SystemExit('Passphrases do not match; no certificates created')
    fingerprint = generate(args.out, args.host, password)
    print('Created private CA and server certificate in', args.out)
    print('CA SHA-256 fingerprint:', fingerprint)
    print('Distribute ONLY ca.pem. Keep server-key.pem private; secure Windows ACLs before use.')
    print('Store encrypted ca-key.pem offline. No trust store or network settings were changed.')


if __name__ == '__main__':
    main()
