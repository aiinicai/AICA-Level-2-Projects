"""OfficeLink desktop prototype. Credentials are memory-only. No insecure TLS mode."""
import base64
import json
import queue
import re
from datetime import datetime
import ssl
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from transfer_limits import encoded_body_limit, validate_limit, LEGACY_MAX_FILE_BYTES, TRANSFER_TIMEOUT

from PyQt6.QtCore import QObject, Qt, QTimer, QSize, QEvent, pyqtSignal
from PyQt6.QtGui import QKeySequence, QShortcut, QIcon, QPixmap, QPainter, QColor, QFont, QAction
from PyQt6.QtWidgets import (QApplication, QDialog, QFileDialog, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QListWidget, QListWidgetItem, QMainWindow, QMessageBox,
    QPushButton, QSplitter, QTabWidget, QTextBrowser, QTextEdit, QVBoxLayout, QWidget, QCheckBox, QFrame, QSystemTrayIcon, QMenu)


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RuntimeError('Server redirect refused: verify the configured office server address.')


class API:
    def __init__(self, url, ca=None, *, ca_pem=None):
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password:
            raise ValueError('Use an HTTPS server address without embedded credentials.')
        if parsed.path not in ('', '/') or parsed.query or parsed.fragment:
            raise ValueError('Enter only the server origin, e.g. https://office-server:8443')
        self.url = url.rstrip('/')
        if not ca and not ca_pem:
            raise ValueError('A trusted office CA is required.')
        self.context = ssl.create_default_context(cafile=ca, cadata=ca_pem)
        self.context.verify_flags |= ssl.VERIFY_X509_STRICT
        self.token = None
        self.max_file_bytes=LEGACY_MAX_FILE_BYTES
        self.transfer_slot=threading.BoundedSemaphore(1)
        # LAN connection goes directly to the configured server; do not leak tokens via proxy.
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect(),
            urllib.request.HTTPSHandler(context=self.context))

    def configure_limits(self, limits):
        self.max_file_bytes=validate_limit((limits or {}).get('max_file_bytes',LEGACY_MAX_FILE_BYTES))

    def request(self, method, path, data=None):
        transfer=path=='/uploads' or path.startswith('/files/')
        slot=getattr(self,'transfer_slot',None)
        acquired=False
        if transfer and slot is not None:
            acquired=slot.acquire(blocking=False)
            if not acquired:raise RuntimeError('A document is already transferring. Wait for it to finish, then try again.')
        try:return self._request(method,path,data,transfer)
        finally:
            if acquired:slot.release()

    def _request(self, method, path, data, transfer):
        body = json.dumps(data).encode() if data is not None else None
        headers = {'Content-Type': 'application/json'}
        if self.token:
            headers['Authorization'] = 'Bearer ' + self.token
        req = urllib.request.Request(self.url + path, data=body, headers=headers, method=method)
        try:
            with self.opener.open(req, timeout=TRANSFER_TIMEOUT if transfer else 6) as response:
                cap=encoded_body_limit(getattr(self,'max_file_bytes',LEGACY_MAX_FILE_BYTES)) if path.startswith('/files/') else 4*1024*1024
                declared=response.headers.get('Content-Length')
                if declared is not None and int(declared)>cap:raise RuntimeError('Server response exceeds the configured document limit.')
                raw = response.read(cap+1)
                if len(raw)>cap:raise RuntimeError('Server response exceeds the configured limit.')
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            try:
                detail = json.loads(exc.read(8192)).get('error', 'Request rejected')
            except Exception:
                detail = 'Request rejected'
            raise RuntimeError(f'{exc.code}: {detail}') from None
        except (urllib.error.URLError, TimeoutError) as exc:
            reason = getattr(exc, 'reason', exc)
            if isinstance(reason, ssl.SSLCertVerificationError):
                detail = getattr(reason, 'verify_message', str(reason))
                raise RuntimeError('TLS certificate verification failed: ' + detail +
                    '. Ask the administrator to check the certificate and trusted CA; verification has not been bypassed.') from exc
            raise RuntimeError('Server unavailable or TLS connection failed. Check the server address, port and Wi-Fi.') from exc


class Bridge(QObject):
    done = pyqtSignal(object, object, object)


class Voice:
    """200 ms mono PCM over HTTPS relay. No recording; bounded, ephemeral queues."""
    def __init__(self, api, call_id, error):
        self.api, self.call_id, self.error = api, call_id, error
        self.stop_event = threading.Event()
        self.frames = queue.Queue(maxsize=5)
        self.thread = threading.Thread(target=self.run, daemon=True)
        self.thread.start()

    def stop(self):
        self.stop_event.set()

    def run(self):
        try:
            import sounddevice as sd
            def capture(data, frames, timing, status):
                if not self.stop_event.is_set():
                    try:
                        self.frames.put_nowait(bytes(data))
                    except queue.Full:
                        pass
            with sd.RawInputStream(samplerate=16000, channels=1, dtype='int16',
                                   blocksize=3200, callback=capture), sd.RawOutputStream(
                                   samplerate=16000, channels=1, dtype='int16', blocksize=3200) as output:
                while not self.stop_event.is_set():
                    try:
                        frame = self.frames.get(timeout=.2)
                        self.api.request('POST', f'/calls/{self.call_id}/audio',
                                         {'data': base64.b64encode(frame).decode()})
                    except queue.Empty:
                        pass
                    incoming = self.api.request('GET', f'/calls/{self.call_id}/audio')
                    for encoded in incoming.get('frames', []):
                        frame = base64.b64decode(encoded, validate=True)
                        if len(frame) <= 16000 and len(frame) % 2 == 0 and not self.stop_event.is_set():
                            output.write(frame)
        except Exception as exc:
            self.error(str(exc))
        finally:
            self.stop_event.set()


STYLE = """
QWidget {font-family: 'Segoe UI', 'DejaVu Sans'; font-size: 14px; color: #20334a; background: #f3f6fb;}
QWidget#white, QDialog, QFrame#card {background: #ffffff;}
QFrame#card {border: 1px solid #e1e8f1; border-radius: 18px;}
QFrame#hero {background: qlineargradient(x1:0,y1:0,x2:1,y2:1,stop:0 #113b50,stop:1 #177a79);border-radius:18px;}
QFrame#hero QLabel {background: transparent;color:#ffffff;}
QLabel {background:transparent;}
QLabel#brand {font-size:25px;font-weight:700;color:#193c58;}
QLabel#eyebrow {font-size:11px;font-weight:700;color:#76879c;letter-spacing:2px;}
QLabel#muted {color:#758399;font-size:12px;}
QLabel#title {font-size:26px;font-weight:700;color:#18374e;}
QLabel#heroTitle {font-size:32px;font-weight:700;}
QLabel#heroCopy {font-size:15px;color:#d2e9e9;}
QLabel#badge {background:#dcf4eb;color:#156951;border-radius:12px;padding:6px 12px;font-size:12px;}
QLabel#avatar {background:#e8edf9;color:#4e59a7;border-radius:18px;font-size:14px;font-weight:700;}
QLabel#messageHint {color:#7c8ba0;font-size:11px;}
QLineEdit, QTextEdit {background:#ffffff;border:1px solid #d8e1ec;border-radius:10px;padding:11px;color:#22364d;selection-background-color:#5266b4;}
QLineEdit:focus, QTextEdit:focus {border:2px solid #508a9c;}
QLineEdit:disabled, QTextEdit:disabled {background:#f5f7fa;color:#91a0b3;}
QTextBrowser {background:#ffffff;border:0;padding:12px;}
QPushButton {background:#186d70;color:#ffffff;border:0;border-radius:9px;padding:11px 18px;font-weight:600;}
QPushButton:hover {background:#125b60;}
QPushButton:pressed {background:#104b50;}
QPushButton:disabled {background:#e2e8ef;color:#8c99aa;}
QPushButton#secondary {background:#eef2f8;color:#445b78;}
QPushButton#secondary:hover {background:#e0e8f2;}
QPushButton#secondary:disabled {background:#f5f7fa;color:#a8b4c4;}
QPushButton#danger {background:#fff0ef;color:#b24848;}
QPushButton#danger:hover {background:#ffe0df;}
QPushButton#textButton {background:transparent;color:#52718e;padding:7px;}
QListWidget {background:#ffffff;border:0;outline:0;}
QListWidget::item {border-radius:10px;padding:5px;margin:2px 0;}
QListWidget::item:hover {background:#f1f5fb;}
QListWidget::item:selected {background:#e6f2f2;color:#175b60;}
QTabWidget::pane {background:#ffffff;border:0;}
QTabBar::tab {background:#ffffff;padding:12px 20px;color:#7a899c;font-weight:600;border-bottom:2px solid transparent;}
QTabBar::tab:selected {color:#176b70;border-bottom:2px solid #176b70;}
QCheckBox {background:transparent;color:#6a7b90;font-size:12px;spacing:8px;}
QCheckBox::indicator {width:14px;height:14px;border:1px solid #a6b6c8;border-radius:3px;background:#ffffff;}
QCheckBox::indicator:checked {background:#18777a;border:2px solid #18777a;}
QCheckBox::indicator:disabled {background:#e6ebf1;border-color:#d2dbe6;}
QSplitter::handle {background:#e8edf4;width:1px;}
QScrollBar:vertical {background:#f6f8fc;width:9px;border:0;}
QScrollBar::handle:vertical {background:#cdd7e4;min-height:30px;border-radius:4px;}
QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {height:0;}
"""


def label(text, name=None):
    widget = QLabel(text)
    widget.setTextFormat(Qt.TextFormat.PlainText)
    if name: widget.setObjectName(name)
    return widget


def friendly_error(error):
    if error.startswith('401:'): return 'The username or password was not accepted. Please try again.'
    if error.startswith('429:'): return 'Too many sign-in attempts. Please wait five minutes, then try again.'
    if 'certificate' in error.lower(): return 'We could not verify your office server. Contact IT before continuing. ' + error
    if 'unavailable' in error.lower() or 'connection failed' in error.lower():
        return 'Your office server is not reachable. Check that you are on the office Wi-Fi and the server is on.'
    return error


class PasswordDialog(QDialog):
    """Memory-only password change; server revokes all sessions after success."""
    def __init__(self, api, mandatory=False, parent=None):
        super().__init__(parent)
        self.api=api; self.mandatory=mandatory; self.pending=False; self.closed=False
        self.setWindowTitle('OfficeLink · Choose your password' if mandatory else 'OfficeLink · Change password')
        self.setMinimumWidth(470)
        layout=QVBoxLayout(self); layout.setContentsMargins(28,24,28,24); layout.setSpacing(12)
        layout.addWidget(label('Choose your own password' if mandatory else 'Change your password','title'))
        notice=label('Your administrator supplied a temporary password. Choose a new one before entering your workspace.' if mandatory else 'This signs you out on all devices. Sign in again with your new password afterwards.','muted')
        notice.setWordWrap(True);layout.addWidget(notice)
        self.current=QLineEdit();self.new=QLineEdit();self.confirm=QLineEdit()
        for title,field in (('Temporary password' if mandatory else 'Current password',self.current),('New password (12–256 characters)',self.new),('Confirm new password',self.confirm)):
            layout.addWidget(label(title));field.setEchoMode(QLineEdit.EchoMode.Password);field.setMaxLength(256);layout.addWidget(field)
        self.status=label('Passwords are never saved on this computer.','muted');self.status.setWordWrap(True);layout.addWidget(self.status)
        buttons=QHBoxLayout();self.cancel=QPushButton('Cancel sign-in' if mandatory else 'Cancel');self.cancel.setObjectName('secondary');self.cancel.clicked.connect(self.reject)
        self.save=QPushButton('Save new password');self.save.clicked.connect(self.change_password)
        buttons.addWidget(self.cancel);buttons.addWidget(self.save);layout.addLayout(buttons)
        self.confirm.returnPressed.connect(self.change_password)
        self.pool=ThreadPoolExecutor(max_workers=1);self.bridge=Bridge();self.bridge.done.connect(self.finished_change)

    def clear_passwords(self):
        for field in (self.current,self.new,self.confirm):field.clear()

    def change_password(self):
        if self.pending or self.closed:return
        current,new,confirm=self.current.text(),self.new.text(),self.confirm.text()
        if not current or not 12<=len(new)<=256:
            self.status.setText('Enter your current password and a new password of 12–256 characters.');return
        if new!=confirm:self.status.setText('The new passwords do not match.');return
        if new==current:self.status.setText('Choose a password different from your current password.');return
        self.pending=True;self.save.setEnabled(False);self.cancel.setEnabled(False)
        self.clear_passwords();self.status.setText('Updating securely… Please wait before closing this window.')
        future=self.pool.submit(self.api.request,'POST','/change-password',{'current_password':current,'new_password':new})
        future.add_done_callback(lambda f:self.bridge.done.emit(f,None,None))

    def finished_change(self,future,_a,_b):
        if self.closed:return
        self.pending=False;self.save.setEnabled(True);self.cancel.setEnabled(True)
        try:
            result=future.result()
            if not result.get('ok'):raise RuntimeError('The server did not confirm the password change. Ask your administrator before retrying.')
        except Exception as exc:
            error=str(exc)
            if error.startswith('401:'):error='The current password was not accepted or your session expired. Check it, or cancel and sign in again.'
            elif error.startswith('404:'):error='Ask your administrator to update the server before changing your password.'
            self.status.setText(friendly_error(error));self.current.setFocus();return
        self.api.token=None;self.closed=True;self.clear_passwords();self.pool.shutdown(wait=False);super().accept()

    def reject(self):
        if self.closed:return
        if self.pending:
            self.status.setText('The password change is still in progress. Please wait for its result.');return
        self.closed=True;self.clear_passwords()
        if self.mandatory:
            def revoke():
                try:self.api.request('POST','/logout',{})
                except Exception:pass
                finally:self.api.token=None
            self.pool.submit(revoke)
        self.pool.shutdown(wait=False,cancel_futures=False);super().reject()

    def closeEvent(self,event):
        if self.pending:event.ignore();self.status.setText('Please wait for the password-change result before closing.');return
        self.reject();event.accept()


class Login(QDialog):
    def __init__(self, profile):
        super().__init__()
        self.profile = profile
        self.setWindowTitle('OfficeLink · Sign in')
        self.setMinimumSize(850, 550)
        self.api = self.user = None
        self.closed = False
        layout = QHBoxLayout(self); layout.setContentsMargins(20,20,20,20); layout.setSpacing(28)
        hero = QFrame(); hero.setObjectName('hero'); hl = QVBoxLayout(hero); hl.setContentsMargins(34,38,34,34)
        hl.addWidget(label('OFFICELINK', 'eyebrow'))
        hl.addStretch()
        title = label('Your people.\nOne workspace.', 'heroTitle'); hl.addWidget(title)
        copy = label('A simpler way to talk, share documents\nand stay connected at the office.', 'heroCopy'); copy.setWordWrap(True); hl.addWidget(copy)
        hl.addSpacing(28)
        for text in ('01   Find your colleagues', '02   Keep conversations together', '03   Share work with confidence'):
            row = label(text, 'heroCopy'); hl.addWidget(row); hl.addSpacing(9)
        hl.addStretch(); hl.addWidget(label('PRIVATE OFFICE NETWORK', 'heroCopy')); layout.addWidget(hero,1)
        right = QWidget(); right.setObjectName('white'); form = QVBoxLayout(right); form.setContentsMargins(4,28,22,24); form.setSpacing(13)
        form.addStretch(); form.addWidget(label(profile['organization'].upper(), 'eyebrow'))
        form.addWidget(label('Welcome back', 'title'))
        form.addWidget(label('Sign in to your office workspace.', 'muted')); form.addSpacing(17)
        form.addWidget(label('Username'))
        self.username = QLineEdit(); self.username.setPlaceholderText('Your office username'); self.username.setMaxLength(40)
        from deployment_profile import load_username, load_preferences
        preferences=load_preferences(profile)
        self.username.setText(load_username(profile)); form.addWidget(self.username)
        form.addWidget(label('Password'))
        password_row = QHBoxLayout(); self.password = QLineEdit(); self.password.setPlaceholderText('Enter your password'); self.password.setMaxLength(256)
        self.password.setEchoMode(QLineEdit.EchoMode.Password); password_row.addWidget(self.password)
        self.show_password = QPushButton('Show'); self.show_password.setObjectName('textButton'); self.show_password.setCheckable(True)
        self.show_password.toggled.connect(lambda show: self.password.setEchoMode(QLineEdit.EchoMode.Normal if show else QLineEdit.EchoMode.Password))
        password_row.addWidget(self.show_password); form.addLayout(password_row)
        self.remember = QCheckBox('Remember my username on this PC'); self.remember.setChecked(preferences['remember_username']); form.addWidget(self.remember)
        self.button = QPushButton('Sign in'); self.button.setMinimumHeight(45); self.button.clicked.connect(self.login); form.addWidget(self.button)
        self.password.returnPressed.connect(self.login); self.username.returnPressed.connect(lambda:self.password.setFocus())
        self.status = label('Your password is never saved.', 'muted'); self.status.setWordWrap(True); self.status.setMinimumHeight(55); form.addWidget(self.status)
        form.addStretch(); form.addWidget(label('Need access? Ask your office administrator.', 'muted')); layout.addWidget(right,1)
        self.pool = ThreadPoolExecutor(max_workers=1)
        self.bridge = Bridge(); self.bridge.done.connect(self.finished_login)
        (self.password if self.username.text() else self.username).setFocus()

    def login(self):
        if self.closed or not self.button.isEnabled(): return
        if not self.username.text().strip() or not self.password.text():
            self.status.setText('Enter your username and password to continue.'); return
        self.button.setEnabled(False); self.button.setText('Signing in…')
        self.status.setText('Connecting securely to your office…')
        username, password = self.username.text().strip(), self.password.text()
        self.password.clear()
        def work():
            api = API(self.profile['server'], ca_pem=self.profile['ca_pem'])
            result = api.request('POST', '/login', {'username': username, 'password': password})
            api.token = result['token']
            api.configure_limits(result.get('limits'))
            if self.closed:
                api.request('POST', '/logout', {})
                raise RuntimeError('Sign-in canceled')
            return api, result['user']
        future = self.pool.submit(work)
        future.add_done_callback(lambda f: self.bridge.done.emit(f, None, None))

    def finished_login(self, future, _a, _b):
        if self.closed: return
        self.button.setEnabled(True); self.button.setText('Sign in')
        try:
            self.api, self.user = future.result()
        except Exception as exc:
            self.status.setText(friendly_error(str(exc))); self.password.setFocus(); return
        if self.user.get('must_change_password'):
            self.button.setEnabled(False)
            dialog=PasswordDialog(self.api,mandatory=True,parent=self)
            changed=dialog.exec()==QDialog.DialogCode.Accepted
            self.api=self.user=None
            self.button.setEnabled(True)
            self.status.setText('Password changed. Sign in again with your new password.' if changed else 'Sign-in canceled. Your temporary password must be changed before using OfficeLink.')
            self.password.setFocus()
            return
        from deployment_profile import save_preferences
        try: save_preferences(self.profile, username=self.user['username'] if self.remember.isChecked() else '', remember_username=self.remember.isChecked())
        except OSError: pass  # Remembering a name is optional; sign-in must still work.
        self.pool.shutdown(wait=False)
        self.accept()

    def reject(self):
        self.closed = True; self.password.clear()
        self.pool.shutdown(wait=False, cancel_futures=True)
        super().reject()

    def closeEvent(self, event):
        self.reject(); event.accept()


class Window(QMainWindow):
    def __init__(self, api, user, organization='Your office', profile=None):
        super().__init__()
        self.api, self.user = api, user
        self.transfer_busy=False; self.transfer_message=''
        self.storage_next_check=0; self.storage_supported=True
        self.profile=profile; self.unread={}; self.incoming_counts={}; self.alerts_initialized=False; self.notice_room=None; self.tray=None; self.force_quit=False
        from deployment_profile import load_preferences
        self.preferences=load_preferences(profile) if profile else {'notifications_enabled':True,'sound_enabled':False,'minimize_to_tray':False}
        self.pool = ThreadPoolExecutor(max_workers=4)
        self.bridge = Bridge(); self.bridge.done.connect(self.completed)
        self.generation = 0
        self.current = None; self.polling = False; self.voice = None; self.call = None
        self.consented_calls = set(); self.opening_person = False; self.relogin = False
        self.closed = False; self.messages = []; self.users = []; self.conversations = []
        self.setWindowTitle('OfficeLink · ' + organization); self.resize(1160, 800); self.setMinimumSize(900,650)
        root = QWidget(); self.setCentralWidget(root); outer = QVBoxLayout(root); outer.setContentsMargins(26,20,26,20); outer.setSpacing(18)
        header = QHBoxLayout(); header.addWidget(label('OfficeLink', 'brand')); header.addSpacing(20); header.addWidget(label(organization, 'muted')); header.addStretch()
        self.connection = label('Connecting…', 'badge'); header.addWidget(self.connection); header.addSpacing(18)
        header.addWidget(label(user.get('display_name',user.get('username','Staff'))))
        self.changing_password=False
        account=QPushButton('Change password');account.setObjectName('textButton');account.clicked.connect(self.change_password);header.addWidget(account)
        logout = QPushButton('Sign out'); logout.setObjectName('textButton'); logout.clicked.connect(self.sign_out); header.addWidget(logout); outer.addLayout(header)
        split = QSplitter(); outer.addWidget(split,1)
        left = QFrame(); left.setObjectName('card'); ll = QVBoxLayout(left); ll.setContentsMargins(18,20,18,18); ll.setSpacing(12)
        ll.addWidget(label('YOUR WORKSPACE', 'eyebrow'))
        self.search = QLineEdit(); self.search.setPlaceholderText('Search people and chats'); self.search.textChanged.connect(self.filter_lists); ll.addWidget(self.search)
        self.tabs = QTabWidget(); self.people = QListWidget(); self.rooms = QListWidget()
        self.tabs.addTab(self.people,'People'); self.tabs.addTab(self.rooms,'Chats'); ll.addWidget(self.tabs,1)
        self.people.itemClicked.connect(self.open_person); self.rooms.itemClicked.connect(self.open_room)
        self.dnd=QCheckBox('Do not disturb'); self.dnd.setChecked(not self.preferences['notifications_enabled']); self.dnd.toggled.connect(lambda checked:self.set_preference('notifications_enabled',not checked)); ll.addWidget(self.dnd)
        self.sound=QCheckBox('Play a sound for new messages'); self.sound.setChecked(self.preferences['sound_enabled']); self.sound.toggled.connect(lambda checked:self.set_preference('sound_enabled',checked)); ll.addWidget(self.sound)
        self.keep_running=QCheckBox('Keep running when I close the window'); self.keep_running.setChecked(self.preferences['minimize_to_tray']); self.keep_running.toggled.connect(lambda checked:self.set_preference('minimize_to_tray',checked)); self.keep_running.setEnabled(QSystemTrayIcon.isSystemTrayAvailable()); self.keep_running.setToolTip('Only available when Windows has a system tray. Minimize always keeps you connected.'); ll.addWidget(self.keep_running)
        self.group = QPushButton('+  New group'); self.group.setObjectName('secondary'); self.group.clicked.connect(self.new_group); ll.addWidget(self.group)
        help_label=label('Click a colleague to start a conversation.', 'muted'); help_label.setWordWrap(True); ll.addWidget(help_label)
        right = QFrame(); right.setObjectName('card'); rl = QVBoxLayout(right); rl.setContentsMargins(22,20,22,18); rl.setSpacing(12)
        top = QHBoxLayout(); titles = QVBoxLayout(); self.heading=label('A good day starts with a hello.', 'title'); self.heading.setWordWrap(True); titles.addWidget(self.heading)
        self.chat_detail=label('Choose a colleague or a group to get started.', 'muted'); titles.addWidget(self.chat_detail); top.addLayout(titles,1)
        self.call_button=QPushButton('Voice call'); self.call_button.setObjectName('secondary'); self.call_button.clicked.connect(self.start_call); top.addWidget(self.call_button)
        self.end_button=QPushButton('End call'); self.end_button.setObjectName('danger'); self.end_button.clicked.connect(self.end_call); self.end_button.setVisible(False); top.addWidget(self.end_button); rl.addLayout(top)
        divider=QFrame(); divider.setFrameShape(QFrame.Shape.HLine); divider.setStyleSheet('color:#e7edf4;'); rl.addWidget(divider)
        self.chat=QTextBrowser(); self.chat.setOpenLinks(False); self.chat.anchorClicked.connect(self.download); rl.addWidget(self.chat,1)
        self.show_empty()
        self.input=QTextEdit(); self.input.setPlaceholderText('Write a message…'); self.input.setMaximumHeight(105); self.input.setTabChangesFocus(True); rl.addWidget(self.input)
        actions=QHBoxLayout(); self.attach=QPushButton('Attach document'); self.attach.setObjectName('secondary'); self.attach.clicked.connect(self.upload); actions.addWidget(self.attach)
        actions.addWidget(label('Up to '+str(getattr(api,'max_file_bytes',LEGACY_MAX_FILE_BYTES)//(1024*1024))+' MiB  ·  Ctrl+Enter to send','messageHint'),1)
        self.send=QPushButton('Send message  →'); self.send.clicked.connect(self.send_message); actions.addWidget(self.send); rl.addLayout(actions)
        shortcut=QShortcut(QKeySequence('Ctrl+Return'),self); shortcut.activated.connect(self.send_message)
        split.addWidget(left); split.addWidget(right); split.setSizes([300,820]); split.setChildrenCollapsible(False)
        self.status=label('Connecting securely to your office…','muted'); self.status.setWordWrap(True); outer.addWidget(self.status)
        self.storage_info=label('Attachment storage: checking office policy…','muted');self.storage_info.setWordWrap(True)
        self.storage_info.setToolTip('Expiry affects only the server attachment. Downloaded copies and original documents are not removed. Existing files are not assigned expiry merely by enabling the policy.')
        outer.addWidget(self.storage_info)
        self.enable_chat(False); self.setup_tray()
        self.timer=QTimer(self); self.timer.timeout.connect(self.poll); self.timer.start(2000); self.poll()

    def set_preference(self, key, value):
        self.preferences[key]=value
        if self.profile:
            from deployment_profile import save_preferences
            try: save_preferences(self.profile, **{key:value})
            except OSError: self.status.setText('This preference works now, but could not be saved on this PC.')

    def setup_tray(self):
        pixmap=QPixmap(64,64); pixmap.fill(Qt.GlobalColor.transparent)
        painter=QPainter(pixmap); painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        painter.setBrush(QColor('#176d70')); painter.setPen(Qt.PenStyle.NoPen); painter.drawRoundedRect(2,2,60,60,15,15)
        painter.setPen(QColor('white')); painter.setFont(QFont('Segoe UI',27,QFont.Weight.Bold)); painter.drawText(pixmap.rect(),Qt.AlignmentFlag.AlignCenter,'O'); painter.end()
        icon=QIcon(pixmap); self.setWindowIcon(icon)
        if not QSystemTrayIcon.isSystemTrayAvailable(): return
        self.tray=QSystemTrayIcon(icon,self); self.tray.setToolTip('OfficeLink · Connected to your office')
        menu=QMenu(self)
        for name,callback in (('Open OfficeLink',self.restore_window),('Sign out',self.sign_out),('Quit OfficeLink',self.quit_app)):
            action=menu.addAction(name); action.triggered.connect(callback)
        self.tray.setContextMenu(menu); self.tray.activated.connect(lambda reason:self.restore_window() if reason==QSystemTrayIcon.ActivationReason.DoubleClick else None)
        self.tray.messageClicked.connect(self.open_notified_chat); self.tray.show()

    def restore_window(self):
        self.showNormal(); self.raise_(); self.activateWindow()
        self.mark_current_read()

    def open_notified_chat(self):
        unread_rooms=[r for r in self.conversations if self.unread.get(r['id'],0)>0]
        if len(unread_rooms)==1:self.select_room(unread_rooms[0])
        else:self.tabs.setCurrentIndex(1)  # Qt click events have no stable toast ID; never guess a different chat.
        self.restore_window()

    def quit_app(self):
        self.force_quit=True; self.close()

    def update_unread_title(self):
        total=sum(self.unread.values())
        self.setWindowTitle(('('+str(total)+') ' if total else '')+'OfficeLink · '+self.user.get('display_name','Office workspace'))
        if self.tray:self.tray.setToolTip('OfficeLink'+(' · '+str(total)+' unread messages' if total else ' · No unread messages'))

    def mark_current_read(self):
        if self.current and self.isActiveWindow() and not self.isMinimized():
            self.unread[self.current]=0; self.update_unread_title()

    def changeEvent(self,event):
        super().changeEvent(event)
        if event.type()==QEvent.Type.ActivationChange and hasattr(self,'unread'):self.mark_current_read()

    def process_notifications(self,rooms):
        for room in rooms:
            cid=room['id']; count=room.get('incoming_count')
            if not isinstance(count,int):continue  # Requires v0.2 server summaries; never invent unread history.
            previous=self.incoming_counts.get(cid,0)
            self.incoming_counts[cid]=max(previous,count)
            if not self.alerts_initialized:continue
            delta=max(0,count-previous)
            if not delta:continue
            visible=cid==self.current and self.isActiveWindow() and not self.isMinimized()
            if visible:self.unread[cid]=0;continue
            self.unread[cid]=self.unread.get(cid,0)+delta
            if not self.preferences['notifications_enabled']:continue
            from notification_policy import attention_allowed
            if not attention_allowed():continue
            self.notice_room=cid
            if self.tray and self.tray.supportsMessages():
                self.tray.showMessage('OfficeLink · New office messages','Click to view your unread conversations.',QSystemTrayIcon.MessageIcon.Information,5000)
            QApplication.alert(self,5000)
            if self.preferences['sound_enabled']:QApplication.beep()
        self.alerts_initialized=True;self.update_unread_title()

    def change_password(self):
        if self.closed or self.changing_password:return
        self.changing_password=True;self.timer.stop()
        if self.call:self.end_call()
        dialog=PasswordDialog(self.api,parent=self)
        changed=dialog.exec()==QDialog.DialogCode.Accepted
        self.changing_password=False
        if changed:
            self.sign_out()
        elif not self.closed:
            self.timer.start(2000);self.poll()

    def sign_out(self):
        self.relogin=True; self.close()

    def enable_chat(self, enabled):
        self.input.setEnabled(enabled); self.attach.setEnabled(enabled and not self.transfer_busy); self.send.setEnabled(enabled)
        self.call_button.setEnabled(enabled and not self.call)

    def show_empty(self, conversation=False):
        heading='Say hello.' if conversation else 'Make room for better teamwork.'
        copy='Your conversation starts here. Write a message below.' if conversation else 'Find someone in People, or open a conversation in Chats.<br>Messages and documents stay on your office server.'
        self.chat.setHtml('<div style="text-align:center;color:#7790a4;padding:60px"><p style="font-size:42px;color:#178080">✦</p><h2 style="color:#24465d">'+heading+'</h2><p style="line-height:160%">'+copy+'</p></div>')

    def filter_lists(self):
        needle=self.search.text().strip().casefold()
        for widget in (self.people,self.rooms):
            for i in range(widget.count()):
                item=widget.item(i); item.setHidden(needle not in item.text().casefold())

    def update_chat_detail(self):
        room=next((r for r in self.conversations if r['id']==self.current),None)
        if not room: return
        members=room.get('members',[])
        if len(members)==2:
            peer=next((u for u in self.users if u['id'] in members and u['id']!=self.user['id']),None)
            self.chat_detail.setText('Online now' if peer and peer.get('online') else 'Offline · messages are saved for later')
        else: self.chat_detail.setText(str(len(members))+' people · Group conversation')
        self.call_button.setEnabled(len(members)==2 and not self.call)

    def submit(self, work, success=None, failure=None):
        if self.closed: return
        future = self.pool.submit(work)
        future.add_done_callback(lambda f: self.bridge.done.emit(f, success, failure))

    def completed(self, future, success, failure):
        if self.closed: return
        try: result = future.result()
        except Exception as exc:
            if failure: failure(str(exc))
            else: self.status.setText(str(exc))
            return
        if success: success(result)

    def poll(self):
        if self.polling: return
        self.polling = True; current = self.current
        after = max((m['id'] for m in self.messages), default=0)
        generation = self.generation
        storage_due=self.storage_supported and time.monotonic()>=self.storage_next_check
        def work():
            result=(self.api.request('GET', '/users'), self.api.request('GET', '/conversations'),
                self.api.request('GET', f'/messages?conversation_id={current}&after={after}') if current else [],
                self.api.request('GET', '/calls'))
            storage=None
            if storage_due:
                try:storage=self.api.request('GET','/storage')
                except RuntimeError as exc:
                    if str(exc).startswith('404:'):storage={'unavailable':True}
                    else:raise
            return result+(storage,)
        self.submit(work, lambda data: self.refreshed(data, current, generation), self.poll_error)

    def poll_error(self, error):
        self.polling = False; self.connection.setText('Reconnecting…'); self.status.setText(friendly_error(error) + ' We will retry automatically.')
        if error.startswith('401:'):
            if self.changing_password:return
            self.timer.stop()
            QMessageBox.information(self, 'Sign in again', 'Your session has ended. Please sign in again to continue.')
            self.relogin=True; self.close()
            return
        if self.voice: self.voice.stop(); self.voice = None

    @staticmethod
    def rows(data, key):
        return data.get(key, []) if isinstance(data, dict) else data

    def refreshed(self, data, current, generation):
        self.polling = False
        self.connection.setText('●  Connected'); self.status.setText(self.transfer_message or 'Your office connection is encrypted. Messages are saved on the office server.')
        users, rooms, messages, calls = data[:4]
        storage=data[4] if len(data)>4 else None
        if storage is not None:
            self.storage_next_check=time.monotonic()+30
            self.update_storage_info(storage)
        self.users = self.rows(users, 'users'); self.conversations = self.rows(rooms, 'conversations')
        self.process_notifications(self.conversations)
        if any('incoming_count' not in room for room in self.conversations):
            self.status.setText('Chat is connected. Ask IT to update the office server to enable new-message notifications.')
        self.people.clear()
        for person in self.users:
            if person['id'] == self.user['id']: continue
            item = QListWidgetItem(('●  ' if person.get('online') else '○  ') + person.get('display_name', person.get('username', 'Staff')) + ('\n     Online now' if person.get('online') else '\n     Offline')); item.setSizeHint(QSize(230,60))
            item.setData(Qt.ItemDataRole.UserRole, person); self.people.addItem(item)
        self.rooms.clear()
        for room in self.conversations:
            item = QListWidgetItem(self.room_name(room)+('  ('+str(self.unread[room['id']])+')' if self.unread.get(room['id']) else '')+'\n'+('Private conversation' if len(room.get('members',[]))==2 else 'Group conversation')); item.setSizeHint(QSize(230,60)); item.setData(Qt.ItemDataRole.UserRole, room)
            self.rooms.addItem(item)
            if room['id'] == self.current:
                item.setSelected(True)
                self.heading.setText(self.room_name(room))
        if current == self.current and current and generation == self.generation:
            combined=self.messages+self.rows(messages,'messages')
            states=messages.get('attachment_states',[]) if isinstance(messages,dict) else []
            by_id={state.get('file_id'):state for state in states if isinstance(state,dict)}
            refreshed=[]
            for message in combined:
                state=by_id.get(message.get('file_id'))
                if state is not None:
                    message=dict(message,file_expired=bool(state.get('file_expired',False)),file_expires_at=state.get('file_expires_at'))
                refreshed.append(message)
            self.render_messages(refreshed)
        self.filter_lists(); self.update_chat_detail(); self.check_calls(self.rows(calls, 'calls'))

    def update_storage_info(self, storage):
        if storage.get('unavailable'):
            self.storage_supported=False
            self.storage_info.setText('Attachment storage policy is unavailable on this server version. Ask IT for details.')
            return
        used,quota=storage.get('used_bytes'),storage.get('quota_bytes')
        if type(used) is not int or type(quota) is not int or used<0 or quota<=0:
            self.storage_info.setText('Attachment storage information is unavailable. Ask IT for details.')
            return
        percent=100*used/quota
        policy='24-hour expiry ON for new uploads' if storage.get('retention_enabled') else 'Automatic attachment expiry OFF'
        capacity=f'{quota/(1024**3):g} GiB' if quota>=1024**3 else f'{quota/(1024**2):g} MiB'
        text=f'Server attachments: {used/(1024**2):.1f} MiB used / {capacity} total · {policy}'
        unmanaged=storage.get('legacy_unmanaged_files',0)
        if isinstance(unmanaged,int) and unmanaged>0:text+=f' · {unmanaged} existing file(s) have no automatic expiry'
        if percent>=100:text+=' · Storage full: contact your administrator.'
        elif percent>=90:text+=' · Storage almost full. Contact your administrator.'
        elif percent>=80:text+=' · Storage filling up; it can fill before 24 hours.'
        self.storage_info.setText(text)
        self.storage_info.setStyleSheet('color:#b54708;' if percent>=80 else '')

    def render_messages(self, messages):
        import html
        if messages == self.messages: return
        self.messages = messages
        if self.current and self.isActiveWindow() and not self.isMinimized():
            # Summaries and message pages are separate requests. A reply can arrive
            # between them: visible messages must advance the alert baseline too.
            # Preserve a larger summary baseline while paging through old history.
            seen_incoming=sum(1 for message in messages if message.get('sender_id')!=self.user['id'])
            self.incoming_counts[self.current]=max(self.incoming_counts.get(self.current,0),seen_incoming)
            self.unread[self.current]=0
            self.update_unread_title()
        if not messages: self.show_empty(True); return
        names = {u['id']: u.get('display_name', u.get('username', 'Staff')) for u in self.users}
        bar=self.chat.verticalScrollBar(); position=bar.value(); at_bottom=position>=bar.maximum()-30
        content=['<body style="font-family:Segoe UI;font-size:14px">']
        for msg in messages:
            mine=msg.get('sender_id')==self.user['id']; name='You' if mine else names.get(msg.get('sender_id'),msg.get('sender_name','Staff'))
            timestamp=datetime.fromtimestamp(msg['created_at']).strftime('%d %b · %H:%M') if isinstance(msg.get('created_at'),(int,float)) else str(msg.get('created_at',''))
            alignment='right' if mine else 'left'; color='#e4f3ef' if mine else '#f0f3f9'
            body=html.escape(msg.get('text','')).replace(chr(10),'<br>')
            if msg.get('file_id'):
                filename=html.escape(msg.get('file_name') or 'document')
                if msg.get('file_expired'):
                    body+='<br><br><b>'+filename+'</b><br><span style="color:#8a5a34">Attachment expired — no longer available from server</span>'
                else:
                    body+='<br><br><a style="color:#176c72" href="file:'+html.escape(str(msg['file_id']),quote=True)+'">↓ Save '+filename+'</a>'
                    expiry=msg.get('file_expires_at')
                    if isinstance(expiry,(int,float)):
                        try:expiry_text=datetime.fromtimestamp(expiry).strftime('%d %b %Y · %H:%M')
                        except (ValueError,OSError,OverflowError):expiry_text='time unavailable; ask your administrator'
                        body+='<br><small style="color:#8a5a34">Server attachment expires '+html.escape(expiry_text)+' (local time). Save a copy before then.</small>'

            content.append('<table width="100%" cellspacing="0" cellpadding="0"><tr><td align="'+alignment+'"><table width="82%" cellspacing="0" cellpadding="13" bgcolor="'+color+'"><tr><td><b style="color:#32596b">'+html.escape(name)+'</b><br><span style="color:#223d50">'+body+'</span><br><small style="color:#78899b">'+html.escape(timestamp)+'</small></td></tr></table></td></tr></table><br>')
        self.chat.setHtml(''.join(content)+'</body>')
        bar.setValue(bar.maximum() if at_bottom else position)

    def room_name(self, room):
        members = room.get('members', [])
        if len(members) == 2 and self.user['id'] in members:
            peer = next((u for u in self.users if u['id'] in members and u['id'] != self.user['id']), None)
            if peer: return peer.get('display_name', peer.get('username', 'Private chat'))
        return room.get('name') or 'Private chat'

    def select_room(self, room):
        self.generation += 1
        self.current = room['id']; self.messages = []; self.show_empty(True); self.enable_chat(True); self.input.setFocus()
        self.heading.setText(self.room_name(room)); self.mark_current_read(); self.update_chat_detail(); self.poll()

    def open_room(self, item): self.select_room(item.data(Qt.ItemDataRole.UserRole))

    def open_person(self, item):
        if self.opening_person: return
        person = item.data(Qt.ItemDataRole.UserRole)
        wanted = {self.user['id'], person['id']}
        room = next((r for r in self.conversations if set(r.get('members', [])) == wanted), None)
        if room:
            self.select_room(room); return
        self.opening_person = True
        def done(room):
            self.opening_person = False
            room.setdefault('name', person.get('display_name', 'Private chat'))
            room.setdefault('members', list(wanted))
            self.conversations.append(room)
            self.select_room(room)
        def failed(error): self.opening_person = False; self.status.setText(error)
        self.submit(lambda: self.api.request('POST', '/conversations', {'name': person.get('display_name', 'Private chat'), 'members': [person['id']]}), done, failed)

    def new_group(self):
        dialog = QDialog(self); dialog.setWindowTitle('Create an office group'); layout = QVBoxLayout(dialog)
        name = QLineEdit(); name.setPlaceholderText('Group name'); layout.addWidget(name)
        people = QListWidget(); layout.addWidget(people)
        for person in self.users:
            if person['id'] == self.user['id']: continue
            item = QListWidgetItem(person.get('display_name', person.get('username', 'Staff')))
            item.setData(Qt.ItemDataRole.UserRole, person['id']); item.setCheckState(Qt.CheckState.Unchecked); people.addItem(item)
        create = QPushButton('Create group'); layout.addWidget(create); create.clicked.connect(dialog.accept)
        if dialog.exec() != QDialog.DialogCode.Accepted: return
        members = [people.item(i).data(Qt.ItemDataRole.UserRole) for i in range(people.count()) if people.item(i).checkState() == Qt.CheckState.Checked]
        if not name.text().strip() or not members: return
        payload = {'name': name.text().strip(), 'members': members}
        self.submit(lambda: self.api.request('POST', '/conversations', payload), self.select_room)

    def send_message(self):
        text = self.input.toPlainText().strip()
        if not self.current or not text or not self.send.isEnabled(): return
        if len(text)>4000:
            self.status.setText('Please keep each message under 4,000 characters.'); return
        current=self.current
        payload = {'conversation_id': current, 'text': text}
        self.send.setEnabled(False)
        def done(_):
            self.send.setEnabled(True)
            if self.current==current and self.input.toPlainText().strip()==text: self.input.clear()
            self.poll()
        def failed(error): self.send.setEnabled(True); self.status.setText(error)
        self.submit(lambda: self.api.request('POST', '/messages', payload), done, failed)

    def transfer_failed(self,error):
        self.transfer_busy=False;self.transfer_message='';self.attach.setEnabled(bool(self.current));self.attach.setText('Attach document')
        self.status.setText('Document transfer did not finish: '+str(error))
        QMessageBox.warning(self,'Document not shared or saved',str(error)+'\n\nNo automatic retry was made. Check the file size and office connection, then try again. If a send timed out, check the chat for its attachment before resending.')

    def upload(self):
        if self.transfer_busy:
            QMessageBox.information(self,'Document transfer in progress','Please wait for the current document transfer to finish.');return
        if not self.current:
            QMessageBox.information(self,'Choose a conversation','Open a colleague or group chat before attaching a document.');return
        path, _ = QFileDialog.getOpenFileName(self, 'Share a document', '', 'Office documents (*.pdf *.docx *.xlsx *.pptx *.txt *.csv *.png *.jpg *.jpeg *.zip);;All files (*)')
        if not path:return
        current=self.current;limit=self.api.max_file_bytes
        def work():
            file=Path(path)
            if file.stat().st_size>limit:raise ValueError(f'This file exceeds the office limit of {limit//(1024*1024)} MiB ({limit:,} bytes). Choose a smaller file or ask your administrator.')
            with file.open('rb') as source:raw=source.read(limit+1)
            if not raw or len(raw)>limit:raise ValueError(f'Choose a nonempty document up to {limit//(1024*1024)} MiB.')
            return self.api.request('POST','/uploads',{'conversation_id':current,'name':file.name,'data':base64.b64encode(raw).decode()})
        self.transfer_busy=True;self.transfer_message='Sharing document… Keep OfficeLink open until it finishes.'
        self.attach.setEnabled(False);self.attach.setText('Sharing…');self.status.setText(self.transfer_message)
        def done(_):
            self.transfer_busy=False;self.transfer_message='';self.attach.setEnabled(bool(self.current));self.attach.setText('Attach document')
            self.status.setText('Document shared successfully.');self.poll()
        self.submit(work,done,self.transfer_failed)

    def download(self,url):
        if url.scheme()!='file':return
        file_id=url.path()
        if not re.fullmatch(r'[0-9a-f]{32}',file_id):return
        if self.transfer_busy:
            QMessageBox.information(self,'Document transfer in progress','Please wait for the current document transfer to finish.');return
        self.transfer_busy=True;self.transfer_message='Receiving document… Keep OfficeLink open until it finishes.'
        self.attach.setEnabled(False);self.status.setText(self.transfer_message)
        self.submit(lambda:self.api.request('GET',f'/files/{file_id}'),self.save_file,self.transfer_failed)

    def save_file(self,data):
        # Never execute or auto-open attachments. Save only after explicit destination selection.
        safe_name=Path(data['name'].replace('\\','/')).name
        path,_=QFileDialog.getSaveFileName(self,'Save document (scan before opening)',safe_name)
        if not path:
            self.transfer_busy=False;self.transfer_message='';self.attach.setEnabled(bool(self.current));self.status.setText('Save canceled.');return
        def work():
            if len(data['data'])>encoded_body_limit(self.api.max_file_bytes):raise ValueError('File exceeds the office document limit.')
            raw=base64.b64decode(data['data'],validate=True)
            if not raw or len(raw)>self.api.max_file_bytes:raise ValueError('File exceeds the office document limit or is empty.')
            # Write a complete temporary file in the chosen directory, then replace the confirmed destination.
            import tempfile,os
            target=Path(path);temporary=None
            try:
                with tempfile.NamedTemporaryFile(dir=target.parent,prefix='.officelink-',delete=False) as stream:
                    temporary=Path(stream.name);stream.write(raw)
                os.replace(temporary,target)
            finally:
                if temporary is not None:temporary.unlink(missing_ok=True)
        def done(_):
            self.transfer_busy=False;self.transfer_message='';self.attach.setEnabled(bool(self.current));self.status.setText('Saved. Scan the document with your antivirus before opening.')
        self.submit(work,done,self.transfer_failed)

    def start_call(self):
        if self.call: return
        room = next((r for r in self.conversations if r['id'] == self.current), None)
        members = room.get('members', []) if room else []
        peer_ids = [m['id'] if isinstance(m, dict) else m for m in members]
        peer_ids = [m for m in peer_ids if m != self.user['id']]
        if len(peer_ids) != 1:
            self.status.setText('Select a private two-person chat to make a voice call.'); return
        if QMessageBox.question(self, 'Start voice call?', 'When answered, this call will use your microphone. Use a headset for best results.') != QMessageBox.StandardButton.Yes: return
        self.call_button.setEnabled(False)
        def done(call): self.call = call.get('call', call); self.consented_calls.add(self.call['id']); self.end_button.setEnabled(True); self.end_button.setVisible(True); self.status.setText('Calling…'); self.poll()
        def failed(error): self.call_button.setEnabled(True); self.status.setText(error)
        self.submit(lambda: self.api.request('POST', '/calls', {'peer_id': peer_ids[0]}), done, failed)

    def check_calls(self, calls):
        active = next((c for c in calls if c.get('status') in ('ringing', 'active')), None)
        if not active:
            if self.voice: self.voice.stop(); self.voice = None
            self.call = None; self.end_button.setEnabled(False); self.end_button.setVisible(False); self.update_chat_detail(); return
        self.call = active; self.end_button.setEnabled(True); self.end_button.setVisible(True); self.call_button.setEnabled(False)
        if active.get('status') == 'ringing' and active.get('callee_id') == self.user['id']:
            # Mark before modal dialog: nested Qt events must not show repeated prompts.
            if getattr(self, 'offered_call', None) == active['id']: return
            self.offered_call = active['id']
            answer = QMessageBox.question(self, 'Incoming voice call', str(active.get('caller_name','A colleague'))+' is calling. Accept and turn on your microphone?')
            action = 'accept' if answer == QMessageBox.StandardButton.Yes else 'end'
            if action == 'accept': self.consented_calls.add(active['id'])
            self.submit(lambda: self.api.request('POST', f'/calls/{active["id"]}/{action}', {}), lambda _: self.poll())
        elif active.get('status') == 'active' and not self.voice and active['id'] in self.consented_calls:
            call_id = active['id']
            self.voice = Voice(self.api, call_id, lambda error: self.bridge.done.emit(self.failed_future(error), None, lambda detail: self.voice_error(call_id, detail)))
            self.status.setText('Voice call active · Microphone on')

    @staticmethod
    def failed_future(error):
        from concurrent.futures import Future
        future = Future(); future.set_exception(RuntimeError(error)); return future

    def voice_error(self, call_id, error):
        if not self.call or self.call['id'] != call_id: return
        self.status.setText('Voice stopped: ' + error); self.end_call()

    def end_call(self):
        if self.voice: self.voice.stop(); self.voice = None
        if self.call:
            call_id = self.call['id']; self.consented_calls.discard(call_id); self.call = None
            self.submit(lambda: self.api.request('POST', f'/calls/{call_id}/end', {}), lambda _: self.poll())
        self.end_button.setEnabled(False); self.end_button.setVisible(False); self.update_chat_detail()

    def closeEvent(self, event):
        if not self.relogin and not self.force_quit:
            if self.preferences.get('minimize_to_tray') and self.tray:
                self.hide(); event.ignore()
                if not getattr(self,'tray_close_explained',False):
                    self.tray_close_explained=True; self.tray.showMessage('OfficeLink is still running','You will stay connected. Right-click the OfficeLink tray icon to quit.',QSystemTrayIcon.MessageIcon.Information,5000)
                return
            if QMessageBox.question(self,'Quit OfficeLink?','Quitting stops messages and calls until you open OfficeLink again. To stay connected, use Minimize.',QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
                event.ignore(); return
        if self.tray:self.tray.hide()
        self.timer.stop()
        if self.voice: self.voice.stop()
        # Best-effort revocation without blocking the GUI; tokens also expire server-side.
        call_id = self.call['id'] if self.call else None
        self.consented_calls.clear()
        def disconnect():
            try:
                if call_id: self.api.request('POST', f'/calls/{call_id}/end', {})
            finally:
                self.api.request('POST', '/logout', {})
        self.pool.submit(disconnect)
        self.closed = True; self.pool.shutdown(wait=False, cancel_futures=False)
        event.accept()
        QApplication.instance().quit()


def main(startup_notice=None):
    app=QApplication(sys.argv); app.setApplicationName('OfficeLink'); app.setStyleSheet(STYLE); app.setQuitOnLastWindowClosed(False)
    if startup_notice: QMessageBox.warning(None, 'OfficeLink desktop shortcut', startup_notice)
    from deployment_profile import load_profile
    try:
        profile=load_profile()
        if not profile:raise ValueError('The administrator has not included an office profile in this build.')
    except Exception as exc:
        box=QMessageBox(); box.setWindowTitle('OfficeLink · Setup needed')
        box.setIcon(QMessageBox.Icon.Information); box.setText('Your office app is not configured yet.')
        box.setInformativeText('Please ask your IT administrator for the configured OfficeLink app. You do not need to enter a server address or certificate.')
        box.setDetailedText(str(exc)); box.exec(); return
    while True:
        login=Login(profile)
        if login.exec()!=QDialog.DialogCode.Accepted: return
        window=Window(login.api,login.user,profile['organization'],profile); window.show(); app.exec()
        if not window.relogin: break


if __name__=='__main__': main()
