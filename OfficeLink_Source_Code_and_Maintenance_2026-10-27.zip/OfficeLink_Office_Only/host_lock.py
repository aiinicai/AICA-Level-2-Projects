"""An OS-released lock prevents two current host processes using one database."""
import os
from pathlib import Path


class HostLock:
    def __init__(self, data):
        self.path = Path(data) / 'host.lock'
        self.stream = None

    def acquire(self):
        self.stream = self.path.open('a+b')
        try:
            if self.path.stat().st_size == 0:
                self.stream.write(b'0'); self.stream.flush()
            self.stream.seek(0)
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            self.stream.close(); self.stream = None
            raise RuntimeError('This office database is already running in another host process.') from exc
        return self

    def release(self):
        if self.stream is not None:
            self.stream.close(); self.stream = None

    def __enter__(self): return self.acquire()
    def __exit__(self, *args): self.release()
