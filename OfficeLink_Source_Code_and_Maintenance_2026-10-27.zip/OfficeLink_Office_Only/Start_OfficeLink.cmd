@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (
    py -3 OfficeLink.py
) else (
    python OfficeLink.py
)
if errorlevel 1 (
    echo.
    echo OfficeLink could not start. Install 64-bit Python 3.11 or later, then retry.
    pause
)
