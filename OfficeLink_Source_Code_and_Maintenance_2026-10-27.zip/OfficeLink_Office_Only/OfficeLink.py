"""OfficeLink office-only launcher. Run this file from Windows IDLE or Python.

First run installs missing dependencies into a local virtual environment.
It never changes the firewall, system trust, startup settings or router.
"""
import importlib.util
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading

ROOT = Path(__file__).resolve().parent
PACKAGES = ('PyQt6>=6.7,<7', 'sounddevice>=0.5,<1', 'cryptography>=41')
MODULES = ('PyQt6', 'sounddevice', 'cryptography')
FALLBACK = 'python -m pip install "PyQt6>=6.7,<7" "sounddevice>=0.5,<1" "cryptography>=41"'


def runtime_ready():
    return all(importlib.util.find_spec(name) is not None for name in MODULES)


def prepare_runtime(report):
    """Use an existing complete runtime or provision an isolated one."""
    if runtime_ready():
        return sys.executable
    folder = ROOT / '.officelink-env'
    interpreter = folder / ('Scripts/python.exe' if os.name == 'nt' else 'bin/python')
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    if not interpreter.is_file():
        report('Creating the OfficeLink Python environment…')
        subprocess.run([sys.executable, '-m', 'venv', str(folder)], check=True,
                       capture_output=True, text=True, creationflags=flags)
    code = 'import PyQt6, sounddevice, cryptography'
    check = subprocess.run([str(interpreter), '-c', code], capture_output=True,
                           creationflags=flags)
    if check.returncode == 0:
        return str(interpreter)
    command = [str(interpreter), '-m', 'pip', 'install', '--disable-pip-version-check']
    wheels = ROOT / 'wheelhouse'
    if wheels.is_dir():
        command += ['--no-index', '--find-links', str(wheels)]
        report('Installing dependencies from the local wheelhouse…')
    else:
        report('Downloading desktop dependencies. Internet is needed for this first setup only…')
    command += PACKAGES
    with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                          text=True, encoding='utf-8', errors='replace',
                          creationflags=flags) as process:
        for line in process.stdout:
            report(line.rstrip())
        if process.wait():
            raise RuntimeError('Dependency installation failed. Check internet access or your Python installation.\n\nFallback:\n' + FALLBACK)
    subprocess.run([str(interpreter), '-c', code], check=True, capture_output=True,
                   creationflags=flags)
    return str(interpreter)


def run_application(shortcut_only=False):
    os.chdir(ROOT)
    from desktop_shortcut import create_desktop_shortcut
    notice = None
    try:
        shortcut_path = create_desktop_shortcut(ROOT, sys.executable)
    except Exception as exc:
        shortcut_path = None
        notice = ('The desktop shortcut could not be created. OfficeLink can still open.\n\n'
                  + str(exc) + '\n\nYou can retry with Create_Desktop_Shortcut.cmd.')
    if shortcut_only:
        from PyQt6.QtWidgets import QApplication, QMessageBox
        app = QApplication.instance() or QApplication(sys.argv)
        if notice:
            QMessageBox.warning(None, 'OfficeLink shortcut', notice)
        else:
            QMessageBox.information(None, 'OfficeLink shortcut',
                'Desktop shortcut ready:\n' + shortcut_path if shortcut_path
                else 'Automatic desktop shortcuts are available on Windows.')
        return
    if (ROOT / 'office_setup.py').is_file():
        from office_setup import main
    else:
        from client import main
    main(startup_notice=notice)


def main():
    if '--app' in sys.argv or runtime_ready():
        run_application(shortcut_only='--shortcut-only' in sys.argv)
        return
    # Tk ships with the Windows Python distribution and can show setup progress
    # before the Qt dependency is installed. UI actions stay on the main thread.
    import tkinter as tk
    from tkinter import messagebox, scrolledtext
    window = tk.Tk()
    window.title('OfficeLink · First-time setup')
    window.geometry('700x380')
    tk.Label(window, text='Preparing your office messenger', font=('Segoe UI', 17, 'bold')).pack(pady=16)
    log = scrolledtext.ScrolledText(window, wrap='word', font=('Consolas', 10))
    log.pack(fill='both', expand=True, padx=15, pady=12)
    events = queue.Queue()
    window.protocol('WM_DELETE_WINDOW', lambda: messagebox.showinfo('Setup in progress', 'Please wait for setup to finish.'))

    def work():
        try:
            events.put(('ready', prepare_runtime(lambda text: events.put(('log', text)))))
        except Exception as exc:
            events.put(('error', str(exc) + '\n\n' + FALLBACK))

    def poll():
        try:
            while True:
                kind, value = events.get_nowait()
                if kind == 'log':
                    log.insert('end', value + '\n'); log.see('end')
                elif kind == 'ready':
                    try:
                        command = [value, str(ROOT / 'OfficeLink.py'), '--app']
                        if '--shortcut-only' in sys.argv: command.append('--shortcut-only')
                        subprocess.Popen(command, cwd=ROOT)
                    except OSError as exc:
                        messagebox.showerror('Cannot start OfficeLink', str(exc))
                    window.destroy(); return
                else:
                    messagebox.showerror('OfficeLink setup failed', value)
                    window.protocol('WM_DELETE_WINDOW', window.destroy)
                    return
        except queue.Empty:
            pass
        window.after(100, poll)
    threading.Thread(target=work, daemon=True).start()
    window.after(100, poll)
    window.mainloop()


if __name__ == '__main__':
    main()
