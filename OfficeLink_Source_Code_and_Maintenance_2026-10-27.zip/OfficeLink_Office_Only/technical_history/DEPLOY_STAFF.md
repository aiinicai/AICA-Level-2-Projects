# OfficeLink: a simple staff experience

## What staff do

After explicit pilot/rollout approval, IT copies the trusted, preconfigured **OfficeLink** application folder to an IT-managed location and can create a desktop shortcut. Staff double-click **OfficeLink**, enter their username the first time (it is remembered afterwards) and their password at each login, and chat. They do not install Python, run commands, enter a server address, or select a certificate. The client may remember the non-secret username; it never saves passwords or session tokens.

Keep the whole application folder together, including `_internal`. Do not copy just the EXE. This deliverable is source and a build helper for a **portable Windows application**, not an already-built or signed installer.

## What IT configures once per office

Preserve the existing working server configuration, accounts and **public CA certificate**. Update `server.py` from this revision during a planned stop/restart with the same data/certificate arguments: its conversation summaries are required for background unread alerts. See [MIGRATION_V02.md](MIGRATION_V02.md). Do not recreate the database, initialize accounts again or regenerate certificates just to adopt this client. The server certificate must already cover the approved server address/DNS name, and the existing pilot network permissions still apply. A localhost (`127.0.0.1`) profile works only on the server computer, not on a colleague's PC.

From the project folder and its approved Windows `.venv`, create the office deployment profile:

```powershell
.\.venv\Scripts\python.exe create_profile.py --server https://192.168.1.20:8443 --ca certs\ca.pem --organization "Your Office" --out deployment\profile.json
```

**The address, CA path and organization above are examples.** Replace them with the already-approved, working pilot values. Do not expand firewall access or change the office network to match an example.

The tool creates a readable `deployment\profile.json` for IT review and a matching `deployment\office_profile.py` to embed in the client. Both contain only non-secret configuration and a public CA. Creation refuses existing profile files; to revise a profile, have IT explicitly choose a new output folder and review the new trust configuration, rather than silently overwriting it. The helper below deliberately uses `deployment\profile.json`; an approved replacement requires reviewing and placing the intended new pair there before rebuilding. Review the endpoint, office name and CA fingerprint against the known server. Never supply `server-key.pem`, `ca-key.pem`, a certificate directory, credentials or database files.

The profile does not create a new trust relationship by itself: it tells the client which IT-approved server/CA to trust. IT must securely authenticate the source CA and distribute the resulting app through an already-trusted channel.

## Build on the existing Windows x64 pilot machine

Close running copies of the client before testing a new build. Build Windows binaries on Windows; a Linux build is not a Windows executable. These are administrator/developer steps only, not staff instructions.

If build tools are missing, obtain approval before installing them:

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade "pyinstaller==6.22.3" pyinstaller-hooks-contrib
```

Then explicitly run the reviewed helper:

```powershell
.\build_windows.ps1
```

If organizational PowerShell policy blocks the script, do not bypass policy; ask IT to approve the reviewed script or use its equivalent PyInstaller command under the organization's normal controls. The helper uses the existing `.venv`, validates the profile and builds a timestamped `staff-dist\YYYYMMDD-HHMMSS\OfficeLink` folder. It does not download dependencies, generate certificates, start the server, alter firewall settings, install the client, add startup entries or distribute anything. It refuses a missing/invalid profile and checks that a PortAudio DLL exists in the output.

The bundle uses `client.py` as the entry point—not `bootstrap_client.py`—and embeds the generated `office_profile` Python module inside the application's bytecode archive. It does **not** use `--add-data` on the JSON, source tree, certificate folder, data folder or keys. No raw `office_profile.py` or `profile.json` should appear in the distribution.

## Trust, licensing and rollout gates

- The organization/server/CA profile is embedded in the application's bytecode rather than read from a freely editable JSON next to the EXE. This is not secret storage: configuration and public certificates are public.
- A self-generated hash does **not** prove publisher identity. Authenticate the complete package through IT's existing trusted distribution channel; where available, use organizational code signing and a signed release manifest. Signing only an EXE does not authenticate every external DLL in an onedir folder. Protect the entire installed folder against unauthorized changes with appropriate OS permissions. Staff should not accept a replacement app/profile from an unknown sender.
- PyInstaller packaging does not resolve PyQt/Qt licensing obligations. Review the chosen GPL/commercial licensing path and include required dependency notices/source offers where applicable before distribution. Do not remove `_internal` dependency/license files simply to reduce size.
- This build is unsigned unless IT signs it separately. Do not tell users to disable Defender/SmartScreen or bypass warnings. IT should investigate warnings and use its approved signing/distribution process.
- Preserve the existing server, account database, public CA and pilot configuration. Back up before changes using the existing deployment guide. This revision does not authorize office-wide deployment or additional network access.
- Windows sign-in autostart is optional, per-user opt-in only. No startup item or scheduled task is created. If a user requests it, IT can create a normal shortcut to the verified EXE using its approved procedure. Staff still enter their password; there is no saved-password automatic login.

## Verify before handing it to staff

1. Inspect build warnings and confirm `OfficeLink.exe`, Qt runtime files and `libportaudio*.dll` beneath the new folder. A present DLL is not proof of working audio.
2. Launch the packaged EXE on the current pilot machine. Confirm the office name is correct and the login needs only account credentials—not server/CA selection.
3. Sign in, confirm the remembered username works after restart, and confirm no password is retained. Incorrect credentials must give a clear error.
4. Run the whole folder on the authorized second Windows pilot PC with no separate Python dependency. Confirm login, a message in both directions, a non-sensitive document round trip, and an explicitly accepted voice call. Test sign-out, server shutdown/restart and unavailable microphone.
5. Confirm a malformed/missing profile and an untrusted or hostname-mismatched server certificate fail closed, with no fallback to unverified TLS. A maliciously replaced whole application can replace its trust configuration; detecting that depends on the trusted IT distribution/signature process, not a self-hash. Review the complete package through that process.
6. Only after the pilot and licensing/security review should IT approve broader distribution. Existing source tests do not certify the packaged Windows binary, physical audio or twenty-user capacity.

## Primary build references

- [PyInstaller usage: onedir/windowed/module/data options](https://pyinstaller.org/en/stable/usage.html)
- [PyInstaller manual: build on the target OS; users need no Python](https://pyinstaller.org/en/stable/index.html)
- [PyInstaller Python 3.14 support changelog](https://pyinstaller.org/en/stable/CHANGES.html)
- [Official sounddevice hook: PortAudio binary collection](https://raw.githubusercontent.com/pyinstaller/pyinstaller-hooks-contrib/master/_pyinstaller_hooks_contrib/stdhooks/hook-sounddevice.py)

These instructions were reviewed in the cloud. The helper's actual Windows execution and revised packaged client must be verified on the pilot; no Windows installer or binary is claimed to have been built here.
