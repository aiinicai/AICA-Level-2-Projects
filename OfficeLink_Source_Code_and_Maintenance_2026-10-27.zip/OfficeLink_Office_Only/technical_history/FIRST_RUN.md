# OfficeLink: first run for your IT administrator

**Goal:** a test-only two-Windows-PC pilot, not a full-office rollout. Nothing has been installed or changed on your machines yet.

## Before starting

Confirm the Windows builds, licensing path, Python/wheel compatibility and an approved office-only firewall rule. Read [DEPLOYMENT.md](DEPLOYMENT.md). Choose a server PC with a reserved private IPv4 address. The example below is `192.168.1.20`; replace it everywhere with your real address. Obtain approval before installing dependencies, creating real accounts, storing private keys or changing network/startup settings.

## On the server PC

Open PowerShell in the extracted source folder. The examples use an installed Python 3.11; IT may select another compatible supported Python version after testing.

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-setup.txt
.\.venv\Scripts\python.exe make_cert.py --host 192.168.1.20 --out certs
.\.venv\Scripts\python.exe admin.py --data data init
.\.venv\Scripts\python.exe admin.py --data data add-user --username alice --name "Alice" --role staff
.\.venv\Scripts\python.exe admin.py --data data add-user --username bob --name "Bob" --role staff
.\.venv\Scripts\python.exe server.py --host 192.168.1.20 --port 8443 --data data --cert certs\server.pem --key certs\server-key.pem
```

Use new test passwords at the hidden prompts. Secure the private keys and data with Windows ACLs; move the encrypted CA private key offline. Keep the server running and awake. A network administrator must approve a narrow Private-profile TCP 8443 rule for the office client subnet if required. Do not open router ports.

## Prepare the easy staff client

Follow [DEPLOY_STAFF.md](DEPLOY_STAFF.md). IT prepares one public connection profile and builds the Windows app. The same approved build can then be supplied to pilot staff without Python, commands, IP entry or certificate selection. Each person signs in with their own username/password; remembering the username is optional and passwords are never saved.

**Existing working pilot?** Do not regenerate certificates or reinitialize accounts. Follow [MIGRATION_V02.md](MIGRATION_V02.md) instead. Replace the server code during a planned stop/restart using the same existing data and certificate paths; the new conversation summaries enable background alerts.

**Do not expand beyond the authorized pilot** until the revised packaged app, notifications, documents and real audio pass [VALIDATION.md](VALIDATION.md). No new firewall, startup or office-wide deployment change is authorized by this source package.
