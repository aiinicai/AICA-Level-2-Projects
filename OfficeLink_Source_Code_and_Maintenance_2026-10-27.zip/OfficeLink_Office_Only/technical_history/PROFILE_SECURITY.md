# Staff profile and trust boundary

## Staff experience

The IT-created staff build contains the office name, HTTPS endpoint and **public CA certificate**. Staff enter their account and password; there is no editable server address or certificate picker. The application may remember the nonsecret username and explicit interface/notification choices. Passwords and session tokens are never written to preferences.

A source tree or build without an embedded profile must stop at a clear “contact IT” screen. It must not accept an arbitrary nearby profile JSON file or downgrade TLS verification.

## Prepare with the existing valid pilot CA

Using the project's approved Python environment, IT runs:

```powershell
.\.venv\Scripts\python.exe create_profile.py --server "https://192.168.10.20:8443" --ca "certs-lan\ca.pem" --organization "Your Office" --out "deployment\profile.json"
```

The address above is only an example: use the server origin already approved for the pilot, covered by the server certificate's SAN. `ca.pem` must be the existing valid public CA, not `server.pem`, a private key, or a certificate from an unverified message. This command **does not regenerate certificates, modify accounts, access the network, or change running settings**. It refuses to overwrite an existing profile/module; use a new deployment folder for a deliberate replacement.

The command writes:

- `profile.json`: a public, human-reviewable IT input; not loaded by the running client.
- `office_profile.py`: the same public configuration as a generated Python constant. This is compiled into PyInstaller's PYZ application archive.

Pre-build validation:

```powershell
.\.venv\Scripts\python.exe create_profile.py --check "deployment\profile.json"
```

This validates public certificate constraints, certificate-signing key usage, subject key identifier and validity dates, and checks that the generated module matches the reviewed JSON exactly. It does not execute that generated module while checking it. The runtime validates endpoint/schema/public PEM with standard-library code; TLS performs certificate-chain and hostname verification using only the configured CA and with strict X.509 verification enabled.

See `DEPLOY_STAFF.md` for the complete build workflow. Do not use `--add-data profile.json:.` as an alternative: onedir data files remain external to the EXE and signing the EXE alone does not authenticate them. Instead include the generated module with the documented build search path and hidden import.

## Authenticity, not merely a checksum

The profile's computed `profile_id` only namespaces nonsecret preferences. A hash delivered beside an untrusted package is **not** independent proof of authenticity. This release is not digitally signed.

The trust bootstrap is the organization's approved IT delivery process: verify the complete package/hash through an independent trusted IT channel, install in a directory protected against unauthorized modification, and use organizational signing/endpoint controls where available. Embedding the profile reduces accidental or casual configuration replacement, but does not make an untrusted package safe. Signing only the EXE does not protect every adjacent DLL in an onedir folder; the complete folder must be protected and reviewed. A malicious local administrator or someone able to replace the application can alter the trust anchor.

Staff must receive only the prepared client bundle. Never copy the source project wholesale to staff, because it may contain server data or private keys created during the pilot. Source code licensing obligations should be handled separately through IT, not by including operational secrets.

## Preference boundary

The preference file is `%APPDATA%\OfficeLink\preferences.json` on Windows. Allowed fields are strictly limited to:

- `username`, controlled by `remember_username`;
- `notifications_enabled` (default on; OS policy can still suppress notifications);
- `sound_enabled` (default off);
- `minimize_to_tray` (default off; never autostart).

No endpoint, certificate, password, token, account role or executable command is accepted. Malformed preferences reset to safe defaults. Turning off remember-username clears it from the saved preference schema. No setting registers Windows autostart. Runtime notification/GUI behavior requires Windows pilot validation.

## Validation performed here

Nine automated profile checks pass: valid profile/module matching, refusal to overwrite, invalid origins, private-IP/DNS handling, rejection of private-key/unknown fields and server certificates, absent/invalid embedded profile, username isolation, preference allowlist and remember-off clearing, and preference-ID changes. Tests use only temporary public/test certificate files and temporary preferences; no real account secrets, user settings or office network were accessed.
