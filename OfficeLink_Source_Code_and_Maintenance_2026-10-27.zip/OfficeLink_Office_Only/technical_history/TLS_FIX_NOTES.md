# OfficeLink TLS certificate correction — 0.1.1

## Confirmed defect
The original certificate generator omitted X.509 Subject Key Identifier / Authority Key Identifier extensions. Its generated server chain failed a real loopback TLS handshake with strict verification enabled: `Missing Authority Key Identifier`. Python 3.13 and newer enable strict verification by default in `ssl.create_default_context()`; see https://docs.python.org/3/library/ssl.html#ssl.create_default_context .

## Correction
`make_cert.py` now includes SKI and AKI on the CA and server certificate. `client.py` now displays the actual certificate validation reason instead of conflating it with an unavailable server. TLS certificate and hostname verification remain enabled; there is no security bypass.

Existing certificate files are NOT repaired merely by replacing the script. With the user's approval, generate a fresh certificate set into a NEW folder, stop/restart the existing server using that set, and select its new public CA certificate in the client. Keep the existing data folder/account database unchanged. Do not re-run account initialization. Do not overwrite or delete old certificate files as part of diagnosis. No trust-store or firewall changes are required for a localhost pilot.

For the current localhost pilot only, after approved replacement and certificate creation, the new generator command would be:
`python make_cert.py --host 127.0.0.1 --out certs-local-fixed`
Use the same virtual-environment Python used for the original setup. Follow the assistant's one-step-at-a-time instructions; do not run unattended. This generates new private keys and a new CA fingerprint. Never share private-key files or passphrases.

## Verification on 26 October 2026
Cloud Linux Python 3.12.14 / OpenSSL 3.5.8, with `VERIFY_X509_STRICT` explicitly enabled for the regression:
- Original generated chain: real handshake FAILED with missing AKI (reproduced).
- Corrected generated chain: real certificate-verified TLS ping/pong PASSED with strict mode enabled.
- Nine certificate/client-helper tests PASSED in 0.832 seconds.
- Twenty HTTPS server integration tests PASSED in 18.471 seconds.
- Python syntax checks PASSED.
- Server test certificate fixture also updated for strict interpreter defaults.

This is not a claim of a completed Windows retest: the user's exact diagnostic and retry outcome still need confirmation. No user machine or user certificates were accessed or changed by these tests. Temporary test certificates were discarded.
