# Administrator setup and recovery

## Approval and prerequisites

These are **manual instructions**, not actions already taken. Obtain the owner's approval for each machine installation, account creation, firewall change, startup task and credential-storage decision. Do not enter real credentials into development tests.

Confirm supported Windows edition/build, 64-bit Python 3.11 or newer compatibility with the selected dependency wheels, administrator access where needed, available disk space, and microphone/headset support. Start with a current supported Windows release. Older Windows versions and the exact office PCs have not been qualified. Resolve PyQt/Qt and dependency licensing before distribution. This source delivery is not a signed Windows executable. Python support depends on the chosen release; the [Python 3.11 Windows documentation](https://docs.python.org/3.11/using/windows.html) states a Windows 8.1 minimum, but that is **not** a promise that modern Qt wheels or this application support old Windows. Prefer an OS currently supported by your organization and verify the complete stack.

Select the office server PC. Reserve its LAN IP in DHCP (with network-admin approval) or use a stable internal DNS name. Keep it powered and awake during office hours. Do not use the guest network. Clients need to reach that PC; Wi-Fi AP isolation or VLAN rules may block access even when people see the same Wi-Fi name.

## 1. Prepare Python in an isolated folder

Use a private folder such as `C:\OfficeMessenger`, not a shared writable network folder. Copy the source there and use a standard non-administrator Windows account for runtime where possible. Commands below are PowerShell, run inside that folder. Substitute paths and the **actual** reserved LAN address for `192.168.1.20`.

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-setup.txt
```

Only certificate generation requires `cryptography`; the running server uses Python's standard library. Installation normally needs internet access to acquire packages, but runtime does not. For an offline office, an administrator can prepare compatible Windows wheels on a trusted connected machine, verify them, and install from that local wheelhouse. Dependency ranges are not a reproducible deployment lock: resolve, record versions/hashes and retain the tested wheel set before a staff rollout.

## 2. Create TLS identity

```powershell
.\.venv\Scripts\python.exe make_cert.py --host 192.168.1.20 --out certs
```

Add `--host messenger.office.example` only if that real internal DNS name resolves correctly. The certificate must match the address staff enter. The tool asks for a 12+ character CA-key passphrase, creates a one-year server certificate and refuses to overwrite existing files. It does not change Windows trust stores.

- Distribute **only `certs\ca.pem`** to clients over a trusted channel. Verify its displayed SHA-256 fingerprint independently with the administrator before trusting it.
- Never distribute `server-key.pem` or `ca-key.pem`. Secure server folder ACLs so only the designated runtime/admin accounts can read the server private key, data and backups. Python's POSIX file mode does not enforce Windows ACLs.
- `server-key.pem` is unencrypted so the server can start unattended if later authorized. This must be approved and protected by Windows ACLs/disk encryption before deployment. `ca-key.pem` is encrypted; store it and its passphrase separately offline after setup.
- Record certificate expiry. This utility creates a new CA rather than renewing an existing one; plan a maintenance window to generate replacements and redistribute/verify the new CA before expiry. Never work around expiry or a name mismatch by disabling TLS verification.

## 3. Create staff identities locally

Stop the server before account-maintenance commands. Passwords are entered through hidden prompts, never command-line arguments.

```powershell
.\.venv\Scripts\python.exe admin.py --data data init
.\.venv\Scripts\python.exe admin.py --data data add-user --username alice --name "Alice" --role staff
.\.venv\Scripts\python.exe admin.py --data data list-users
```

Use unique staff usernames and strong unique passwords. Give the admin role only to designated administrators. Roles are account metadata in this MVP; administration is local CLI only, governed by Windows filesystem permissions, not a remote admin API. Do not share one account across staff. Local server administrators can access the database and files; role controls do not protect against the server's Windows administrator. This prototype does not integrate Active Directory/Windows login.

To disable someone:

```powershell
.\.venv\Scripts\python.exe admin.py --data data disable-user --username alice
```

To reset a forgotten password, run `admin.py --data data reset-password --username alice` with the server stopped; enter a new password at the hidden prompt. Restart the server after account changes. Keep account administration local; no public registration is intended.

## 4. Start the server

```powershell
.\.venv\Scripts\python.exe server.py --host 192.168.1.20 --port 8443 --data data --cert certs\server.pem --key certs\server-key.pem
```

Bind the **specific numeric office LAN IPv4 address**, not all adapters or a DNS hostname. The server accepts RFC1918 addresses (10/8, 172.16/12, 192.168/16), plus 127.0.0.1 for isolated local tests; wildcard and public addresses are rejected. Clients may use a correctly resolving DNS name that is included in the certificate. Stop with Ctrl+C before shutting down Windows. Do not put this service behind a public proxy, forward router ports or open an internet-facing listener.

If Windows Firewall blocks access, ask the network administrator to create one inbound TCP rule for port 8443, restricted to the trusted **Private** profile, the server application and the exact office client subnet/IP range. Do not enable it on Public networks or allow all remote addresses. Review routing/VPN adapters too. No firewall command is supplied because the office's subnet and policies are not yet known. Windows client/device and network access licensing should be reviewed by your IT administrator for this proposed deployment; no licensing determination is made here.

## 5. Prepare each client

The v0.2 staff app is preconfigured by IT. Follow [DEPLOY_STAFF.md](DEPLOY_STAFF.md) to bind the approved endpoint and existing public CA into the client, then build its Windows portable folder. Staff launch `OfficeLink.exe` and enter their account credentials; there are no server-address or certificate-selection fields. Missing profiles fail closed with an IT-help message.

Do not distribute server data, private keys or real account passwords. For source-only development, place the generated `office_profile.py` in the trusted source directory before launching `bootstrap_client.py`; the packaged build helper instead reads the reviewed module from `deployment`. Do not copy source to staff as the normal deployment method.

Microphone access remains explicit when calling/accepting; approve Windows permissions only when intended. PortAudio bundling and headset operation require Windows pilot tests. See [sounddevice installation](https://github.com/spatialaudio/python-sounddevice/blob/master/doc/installation.rst).

## Optional start at Windows sign-in — only after approval

Only if the user explicitly opts in, IT can manually create a shortcut in that user's Startup folder targeting the verified packaged `OfficeLink.exe`. Keep the entire application folder intact. This launches the login window, **not an automatically authenticated session**. Do not place passwords in shortcuts or scripts.

For the server, a designated administrator may later create a Task Scheduler task using the exact tested server command and absolute paths. Prefer a dedicated least-privileged account and start only once; test reboot, shutdown and task failure. Running while no Windows user is logged in may involve credential storage and requires separate explicit approval. This package does not register a service or startup task.

## Backups, shutdown and restore

1. Arrange an office-hours maintenance window; notify users and end calls.
2. Stop the server cleanly. Copy the **entire data directory** to restricted backup storage, preserving database and uploaded files together. Do not casually copy a live SQLite database or only its main file.
3. Back up TLS files separately with restricted access; keep the CA private key offline. Protect backups with the organization's approved encryption and retention process. Stored message/file contents are not application-encrypted.
4. Restore the complete data snapshot into an isolated test directory. Start a test server on loopback or a separate approved test address/port, with a matching certificate. Verify accounts, memberships, messages and downloaded-file hashes with test users before restoring production.
5. After a normal restart, clients log in again. Do not promise delivery for unsent/in-flight messages or recovery of calls interrupted by shutdown. Test the UI error/retry behavior and avoid blindly resending duplicates.

The server limits each upload to 10 MiB and total stored document content to 1 GiB. There is no document-retention/delete UI; administrators must plan capacity and a reviewed maintenance procedure rather than deleting database rows or files ad hoc. Maintain enough free disk space for the database and backups as well. Agree a retention/deletion policy before sensitive documents enter the system; this prototype is not a records-management or regulated-compliance platform.

## Troubleshooting without weakening security

- **Certificate error:** check clock, CA file, certificate expiry and the exact hostname/IP. Never disable verification.
- **Connection refused/time-out:** verify server running/awake, reserved IP, Private network profile, the narrow firewall rule and AP isolation. Do not expand firewall scope as a shortcut.
- **Login failed:** ask the administrator to check the username, account status and approved recovery process; do not share accounts.
- **No audio:** check default input/output and Windows microphone permission. Use headsets; verify two-way calling on two physical PCs. The relay may have noticeable latency.
- **Server PC switched off:** service is unavailable by design outside office hours. Saved history returns when it starts again.
