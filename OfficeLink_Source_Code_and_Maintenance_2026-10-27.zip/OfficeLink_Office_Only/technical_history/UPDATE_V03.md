# OfficeLink 0.3 update — larger documents and personal passwords

## What changes

- Default per-document limit: **50 MiB (52,428,800 bytes)**. The reported 33 MB PDF exceeds the previous 10 MiB cap but fits the new default. Synthetic 33 MiB and 50 MiB transfers are tested; the actual office PDF was not accessed.
- Upload/request and download/response bounds now account for base64/JSON overhead. File-only network timeout is 120 seconds; normal chat/call requests retain their short timeout.
- One document transfer per server at a time and one per client limits concurrent memory use. Other file requests receive an explicit busy message and can be retried manually; chat endpoints remain available. This is still bounded in-memory/base64 transfer, not a streaming implementation. A large transfer can use several times its file size in memory and may affect calls on slow Wi-Fi. Validate the revised Windows pilot before expansion.
- Oversize/read/network/busy errors appear in a visible dialog, not just a status line that polling can overwrite. Progress text stays visible; saving happens in a worker and uses a temporary file before replacing the chosen destination. No file is auto-opened. A timed-out upload is not automatically repeated: check the chat before resending to avoid duplicates.
- Each newly created or administrator-reset account gets a temporary password requiring first-login change. Existing pilot accounts keep their current password and access. Staff can use **Change password** later; successful change signs out all sessions. See PASSWORDS.md.

## Minimal upgrade of the existing successful pilot

No new certificate, profile, Python environment, firewall rule or account initialization is needed. Do not delete or replace `data*`, `certs*`, `.venv` or `deployment`.

1. Arrange a short stop/restart and cleanly stop the current server. Back up the complete existing data folder. Keep the previous source/client build for reference; never overwrite your backup.
2. Copy these four files from this update into the existing trusted project folder: **server.py, client.py, admin.py, transfer_limits.py**. The last file is new and must be included beside the others. Preserve all existing configuration/data.
3. Restart the server with the same working command/paths. The default is now 50 MiB. For an explicit alternative, an administrator can add `--max-file-mib N`, where N is 1–100. This is not needed for the requested 50 MiB default. The server communicates the limit at login, so staff must sign in again after a limit change.
4. Rebuild the Windows client using the existing approved `build_windows.ps1` and existing deployment profile. No new package installation or profile generation should be needed. The helper produces a new timestamped folder; replace the whole old client folder during the pilot, not just its EXE. Do not share the source project or operational secrets with staff.
5. Test the revised EXE on the two already-approved PCs: resend a non-sensitive 33 MB document, confirm receipt/save, test a file above the cap for a clear error, and confirm messaging/notification/voice still work. Separately test one new temporary account only when its creation is explicitly approved; do not create all staff accounts automatically.

## Limits and compatibility

The aggregate document quota remains **1 GiB**, separate from the 50 MiB per-file limit. That is only about twenty maximum-size files; plan retention/backups before wider use. The prototype still has no deletion/retention UI. Raising the per-file limit does not raise this quota.

The hard maximum configurable file size is 100 MiB to keep requests bounded. Lowering the limit below an already-stored document's size will block transferring that document until IT raises the limit again. Current clients learn the current limit at login. An old server without limit metadata is treated as a 10 MiB server by the revised client. Old clients cannot receive larger documents or complete the new mandatory password-change flow; update server and clients together.

Do not roll back to old server code expecting it to enforce temporary-password restrictions: it does not know that policy. The additive database migration preserves existing accounts/hashes/history; it does not force existing users to reset.

## Known evidence

The user reported real two-PC messaging, minimized notifications, smaller PDF/Excel transfers and voice calls working before this update. Those are user-reported pilot results, not cloud-observed tests. This revision's precise automated results are in UPDATE_TEST_RESULTS.md. The revised Windows build, actual 33 MB office PDF and password dialogs require the next pilot check; no Windows EXE was built in the cloud.
