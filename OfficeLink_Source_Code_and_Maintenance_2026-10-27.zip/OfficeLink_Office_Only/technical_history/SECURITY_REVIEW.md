> Historical v0.1 evidence. For the revised staff UI/profile/notifications, see `REVISION_TEST_RESULTS.md` and `PROFILE_SECURITY.md`.

# OfficeLink MVP — focused security review

Review date: 26 October 2026. Scope: source inspection of `server.py`, `admin.py`, `client.py`, and `bootstrap_client.py`. This is not a penetration test, certification, Windows validation, or production-readiness approval. Integration test evidence is separately recorded in `TEST_RESULTS.md`; desktop/hardware gaps are in `VALIDATION.md`.

## Intended trust boundary

A small trusted office LAN, with named individual accounts, a managed Windows server, a privately distributed CA certificate, and a narrowly scoped Windows firewall rule. The server and its administrators are trusted with message/document content and relayed audio. TLS encrypts transport; this is **not end-to-end encryption**. Wi-Fi membership alone must not grant account access. Do not expose the service through router forwarding, a public reverse proxy, VPN publishing, or public firewall rules.

## Controls observed in the reviewed source

- TLS is mandatory; server minimum TLS 1.2. Client checks the supplied CA and server hostname, bypasses system proxies, and refuses redirects rather than forwarding credentials elsewhere.
- Normal server CLI accepts only numeric RFC1918 IPv4 addresses or `127.0.0.1`, not wildcard/public bindings. This does **not** replace firewall/network isolation.
- Salted scrypt password hashes, random memory-only bearer sessions, eight-hour session expiry, failed-login throttling, and account/password checks on authenticated requests. Client does not save passwords or bearer tokens.
- Conversation membership is checked for message reads/writes and document upload/download. Call signaling and media require participant membership; only the callee can accept.
- Call media is unavailable before acceptance. Local microphone consent is tracked per call, and the client discards that consent before hanging up. Old call-worker errors are tagged so they cannot terminate a newer call.
- Fixed SQL parameter binding; uploads are database BLOBs rather than attacker-selected filesystem paths. File IDs are random, filenames restricted, file size capped at 10 MiB, and aggregate document storage capped at 1 GiB. Downloads require an explicit save destination and are never automatically opened.
- HTTP body limits are checked before allocation: 4 KiB login, 64 KiB ordinary endpoints, 14 MiB authenticated upload. Authentication precedes non-login body reading. TLS handshakes run in bounded worker threads; socket timeouts and a 64-worker cap reduce simple resource exhaustion.
- Audio queues are bounded, ephemeral, and cleared when calls end. Inactive/disconnected participants and disabled accounts end calls when call activity is next processed.
- Administration is local CLI only. The staff/admin role is account metadata, not a remote administration privilege. Windows filesystem access to the database/keys is the actual administrator boundary.
- Dependency installation is explicit opt-in and uses one pip invocation; no silent dependency installation or trust-store/firewall/startup modification is included.

## Issues found and corrected during this review

The final source was re-inspected for these changes; see integration/client test records for what was executed:

1. Default urllib redirects could carry Authorization to another origin. Redirects are now refused.
2. The original host guard rejected wildcard addresses but still allowed public addresses. CLI binding now requires RFC1918 IPv4 or loopback.
3. Large request bodies were accepted before authentication. Authentication now precedes reads, with smaller endpoint-specific limits.
4. An in-flight poll could restart microphone capture after End. Hangup now removes local consent before its asynchronous request; delayed audio errors are call-scoped, and window close ends the call before logout.
5. A single call activity timestamp could let one remaining participant keep a disconnected call alive. Active calls now also track each participant's media activity; logout ends account calls.

## Remaining limitations / gates before real staff documents

- **Endpoint and at-rest security are prerequisites.** SQLite, saved files, backups, and private key files are not application-encrypted. Apply administrator-only write access to server data/keys and appropriate Windows ACLs, full-disk encryption where available, account controls, and encrypted backup storage. A person who can edit the database can change accounts or read content.
- **Uploads are not malware-scanned or content-validated.** An allowed filename extension is not proof of a safe document; ZIP archives may contain executable or malicious files. Use endpoint antivirus and a review policy. No archive extraction occurs in this application.
- **Availability hardening is limited.** This is a small Python `http.server`-based prototype, not an internet-hardened deployment. A malicious or compromised authenticated colleague can still flood messages/conversations or consume quota/worker capacity. No comprehensive request-rate quota, content retention, storage cleanup UI, monitoring, or audit trail is provided. Scope the pilot to trusted users and non-sensitive sample documents.
- **Dependency supply chain is not locked.** Requirements use version ranges rather than a hash-locked, vetted wheel set. Before rollout, select/test exact builds, retain an internal wheelhouse, scan it, and resolve PyQt licensing. Do not treat a future pip resolution as the already-reviewed build.
- **Local accounts only.** No Active Directory/SSO, MFA, account recovery UI, remote admin console, or per-user device revocation exists. Password reset invalidates sessions on their next request; server restart clears all in-memory sessions/calls.
- **Audio is a prototype relay.** No echo cancellation, codec/jitter-buffer sophistication, packet-loss testing, or verified Windows microphone behavior is claimed. A stop event prevents new frames from being enqueued/sent, but an in-flight network request may take up to its timeout to unwind. Use headsets and verify end/reject/disconnect behavior on two real PCs.
- **No Windows or office-network security qualification was performed here.** Certificate distribution, private-key ACLs, firewall scope, Wi-Fi client isolation, backup restoration, reboot behavior, and actual headset/media behavior require the staged tests in `VALIDATION.md` before broader use.

## Review conclusion

Suitable for **source review and an administrator-controlled two-PC pilot using sample data**, after environment and licensing prerequisites are checked. Do not describe this artifact as audited, production-ready, end-to-end encrypted, or proven for twenty staff. Complete the documented pilot and resolve its findings before any office-wide rollout.
