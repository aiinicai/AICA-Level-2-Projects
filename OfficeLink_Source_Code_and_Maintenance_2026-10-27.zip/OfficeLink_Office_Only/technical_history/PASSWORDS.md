# Individual accounts and password changes

No real accounts or passwords were created or changed by this source revision. Each person should have their own account. Never post temporary or permanent passwords in this conversation, a group chat, screenshots, command arguments or a shared document.

## Administrator: issue a temporary password privately

Use the existing local admin tool on the server, with its existing data path. `add-user` prompts invisibly for a new temporary password and confirmation; no password is printed. Every newly added account—including an added admin account—must change that password before using chat, files, the staff directory or calls. The initial `admin.py init` account remains permanent so initial setup can proceed. Do not rerun `init` on an existing installation.

Examples are illustrative; creating a real user still requires the administrator's explicit action:

```powershell
.\.venv\Scripts\python.exe admin.py --data EXISTING_DATA_PATH add-user --username alice --name "Alice"
```

Choose a unique unpredictable temporary password of 12–256 characters and deliver it directly to the intended person through an approved private channel. Temporary means change-required, not automatically time-expiring in this prototype. Do not reuse one password for the whole office.

## Staff: first sign-in

Sign in with the assigned account and temporary password. The revised client requires a password change before opening the workspace. Enter the current temporary password, a new personal password and its confirmation. Canceling this required step signs out; no partial workspace access is allowed. After success, sign in again using the new password.

The server, not just the UI, enforces this restriction. New passwords must contain 12–256 characters and differ from the current password. Passwords are hashed with salted scrypt on the server; they are never saved in client preferences. The client may remember only the username and nonsecret interface choices.

## Later changes

Use **Change password** while signed in. Enter the current password and a new password. A successful change revokes every session for that account, including other computers, and ends its active calls. Sign in again afterwards. Canceling an optional change leaves the existing session intact.

Five failed/invalid change attempts for one account in a five-minute window trigger a temporary rate limit. Opening another session does not reset that account-wide limit.

## Forgotten password: local administrator reset

```powershell
.\.venv\Scripts\python.exe admin.py --data EXISTING_DATA_PATH reset-password --username alice
```

The administrator enters a new temporary password at hidden prompts, then delivers it privately. The user must choose a different personal password next sign-in. Existing sessions fail on their next authenticated request because their credential marker no longer matches. Restarting the server clears all existing calls immediately; otherwise disconnected-peer timeouts apply. Preserve the existing database, CA, certificates and profile.

## Existing pilot and compatibility

The server adds a `must_change_password` column to existing accounts with default false. Existing pilot users are **not** forced into an unexpected reset and their hashes/history remain unchanged. Only newly added users and explicit administrator resets receive the change-required flag. Normal users can still elect to change their own password.

Update server and client together for this feature. An old client cannot complete mandatory password change; the new server will refuse its workspace requests until it uses the new flow. Do not roll back to an old server expecting it to enforce change-required accounts: that older code does not know this policy.

## Executed evidence

Eleven dedicated tests passed in the cloud, including a real strict-TLS login/change/relogin, old-database migration, mandatory access blocking, validation/rate limits, all-session/call invalidation and local administrator create/reset behavior. All accounts, passwords, databases and certificates used were temporary test fixtures; no real user password was accessed. The revised Windows password dialogs still need the approved pilot test.
