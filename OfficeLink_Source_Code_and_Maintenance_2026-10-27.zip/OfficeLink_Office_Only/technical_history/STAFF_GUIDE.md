# OfficeLink: staff quick guide

Your administrator supplies the preconfigured app. Double-click **OfficeLink**, enter your username and password, and click **Sign in**. The app can remember your username; it never saves your password. No server address, certificate or command is needed.

- **People:** click a colleague to chat. **Chats:** reopen private/group conversations. Search filters both lists.
- **Send:** click Send message or press Ctrl+Enter. Attach document saves files on the office server; recipients choose where to save them. Scan received files before opening.
- **Voice:** select a private chat and click Voice call. A microphone is used only after the call is accepted. Use a headset; voice is still experimental.
- **Minimize:** stays signed in and checks for new messages while the server and connection are available.
- **Unread messages:** chat badges and the window title show unread counts. With alerts enabled, the app requests a tray notification and taskbar attention. First sign-in establishes a baseline rather than alerting for old history; unread counts are for the current signed-in session.
- **Click an alert:** with one unread conversation, it opens that chat. With several, it opens the Chats list so you can select the correct badge. Alerts do not expose message content.
- **Do Not Disturb:** turn off notifications to silence app popups/attention/sound; unread badges remain. Sound is optional and off by default. Windows may suppress notifications, and the app checks the Windows shell's quiet/presentation/availability state before requesting attention. Delivery is not guaranteed. Modern Focus/notification settings must be checked in the Windows pilot.
- **Close:** normally asks whether to quit; confirming signs out and exits. Optional “Close to tray” keeps the app running only if a system tray is available; enable it only if you want this behavior. Use tray Open to return, Sign out to change account, or Quit to disconnect.
- **Sign out:** disconnects and returns to login. Server shutdown, sleep, network loss or expired sessions can interrupt delivery. Startup launch is not configured automatically; ask IT if you want an opt-in shortcut.

If you see “Setup needed” or a certificate warning, ask your administrator. Never bypass certificate verification or install a replacement from an unknown sender.
