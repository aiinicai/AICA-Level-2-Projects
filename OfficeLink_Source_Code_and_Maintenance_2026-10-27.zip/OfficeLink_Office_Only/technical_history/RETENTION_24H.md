# OfficeLink 0.4 — optional one-day attachment retention

## Read before enabling

**One day means 24 elapsed hours after a new upload is accepted**, not midnight, one office day, or closing a chat. At expiry, the attachment can no longer be downloaded from the server, even if some recipients have not saved it. The message, filename and an **Attachment expired** notice remain in chat.

Downloaded copies on staff computers, the sender's original, and backups are **not deleted**. This is logical removal from active application storage, not a promise of forensic secure erasure: SQLite pages/WAL and backups may retain recoverable historical bytes. Do not treat this feature as a full information-destruction policy.

The feature is **OFF by default**. Installing updated source does not turn it on. The administrator must explicitly approve permanent loss of server re-download access before running the enable command below. No real office data was accessed or deleted while preparing this update.

## Existing files are protected

Existing attachments receive no guessed upload date or automatic deadline during migration. Files uploaded while the policy is off also remain unscheduled. Enabling applies only to uploads accepted afterwards; it never silently schedules older files for deletion. The storage display counts unscheduled files so IT can see why old attachments still occupy quota. Cleaning up existing files requires a separate reviewed decision; this update contains no bulk legacy-delete command.

## Minimal update — no fresh setup

1. Stop the current pilot server cleanly and back up its complete existing data folder.
2. Replace only **server.py, admin.py and client.py** in the existing trusted source folder. Keep the v0.3 `transfer_limits.py`, existing certificates, deployment profile, data, accounts and `.venv`. Do not run account initialization or generate certificates.
3. Restart the server with its existing approved arguments. Rebuild the client once with the existing Windows helper/profile and test it on the already-approved two-PC pilot. Retention remains OFF. The new database fields are additive and nullable; old records are preserved.
4. Verify the new client shows automatic attachment expiry OFF and the expected storage/unscheduled-file information. No firewall, startup or broader rollout changes are needed.
5. Only after the loss-of-access warning above is understood and approved, enable the policy on the server using the existing data path. Enabling/disabling is a runtime setting, so subsequent policy changes need **no rebuild or server restart**.

## Administrator commands

Replace `EXISTING_DATA_PATH` with the real existing data folder. These are instructions, not actions already performed. Never point them at a new folder by guesswork.

Read status (does not itself purge files):

```powershell
.\.venv\Scripts\python.exe admin.py --data EXISTING_DATA_PATH retention-status
```

**After explicit informed approval only:**

```powershell
.\.venv\Scripts\python.exe admin.py --data EXISTING_DATA_PATH enable-retention --confirm-permanent-expiry
```

Without the confirmation flag the tool refuses to enable it. Enabling leaves all existing attachments unchanged. Staff see expiry dates on newly uploaded attachments and an updated policy/storage indicator within about 30 seconds.

To stop future expiry and cancel deadlines for all attachments still present:

```powershell
.\.venv\Scripts\python.exe admin.py --data EXISTING_DATA_PATH disable-retention
```

Disabling preserves remaining bytes, but cannot restore attachments that have already expired. Re-enabling is prospective again; canceled/unscheduled files are not retroactively put back on a timer.

## Cleanup timing and transfers

The server checks deadlines at startup, about once a minute while running, and before relevant attachment/message/storage requests. An upload is dated when accepted into storage. If the office server is off at expiry, overdue eligible attachments are removed on its next startup. No background cloud service is used.

Database cleanup and attachment reads share a lock. A download whose bytes were already retrieved just before expiry may finish; new downloads after expiry are rejected with an explicit expired-attachment message. Text chat is not purged. Existing chat views refresh expired attachment states even if there are no new messages.

Use an accurately synchronized server clock. A wrong system time can change when deadlines are judged due.

## Capacity is still finite

The **50 MiB per-file default** and **1 GiB active document quota** are unchanged. One day of large uploads can still fill the quota; unscheduled older files also keep using it. Staff see warnings at 80%, 90% and full usage. Expired payload removal frees application quota and makes database pages reusable, but the `.db` file need not get smaller on the Windows disk. No automatic VACUUM or filesystem shrinking is performed. Any later offline compaction should be separately planned by IT with a verified backup and sufficient disk space.

## Pilot checks

Check a new dummy attachment's deadline, a preserved legacy attachment, policy OFF/ON display and storage warnings. The automated tests accelerate time only in temporary fixtures; do not change the real server clock for a test. Let a non-sensitive pilot attachment reach its real deadline if practical, then verify the tombstone/no re-download, unchanged saved local copy and quota reuse. The revised Windows binary and real overnight-office behavior remain pilot validation items.
