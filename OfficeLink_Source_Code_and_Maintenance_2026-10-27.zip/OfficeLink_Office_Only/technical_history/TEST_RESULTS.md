> Historical v0.1 evidence. For the revised staff UI/profile/notifications, see `REVISION_TEST_RESULTS.md` and `PROFILE_SECURITY.md`.

# Executed test evidence

Date: 26 October 2026. Environment: Linux cloud workspace; Python 3.12.14.

## Result

**20 of 20 automated server integration tests passed in 18.136 seconds.** Final recorded command:

```text
python -m unittest -v test_server
```

Each test starts the actual threaded HTTP server on an ephemeral **127.0.0.1 TLS port** and uses certificate-verifying HTTPS requests. Certificates, database, users and randomly generated test passwords exist only in temporary directories and are removed afterwards. No office computer, firewall, trust store, real credential, microphone or speaker was accessed or changed.

## Verified scope

- Trusted TLS requests work; an untrusted certificate and mismatched hostname are rejected.
- A stalled TLS handshake does not block other connections from being accepted.
- Public/wildcard/hostname server bind arguments are rejected by the CLI before startup.
- Unauthorized upload requests and oversized login/message requests are rejected before reading their body.
- Missing/invalid/expired/logged-out tokens rejected; disabled users denied; password changes revoke existing sessions; login attempts rate-limited; passwords excluded from roster.
- Private-conversation messages and files are restricted to members; group-member messaging works; unknown members and malformed identifiers are rejected.
- Message cursor behavior and message-size validation.
- Exact uploaded/downloaded bytes, including binary data; unsafe names, forbidden file extensions, malformed base64, empty files and files above 10 MiB rejected.
- SQLite messages/files survive a server restart; sessions do not survive.
- Cleanly stopped database copied to a separate temporary location and successfully read back (offline backup/restore smoke).
- 1:1 ringing/accept/end flow, callee-only acceptance, nonparticipant rejection, preacceptance media rejection and busy-participant handling.
- Synthetic PCM16 audio bytes travel in both directions after acceptance, with exact byte comparison; draining, 20-frame queue bound, media size validation, timeout and post-end rejection. A single missing peer times out independently; logout ends the involved call.
- **20 separate authenticated clients** concurrently sent messages successfully through loopback TLS into one room; all 20 distinct senders persisted. This is a small cloud concurrency smoke, **not** an office load, latency or production-readiness certification.

## Not verified

- Windows launch, packaging/installer, startup integration, UI rendering or interactive GUI flows.
- Actual two-PC office Wi-Fi networking, client isolation, certificate distribution, firewall rule or server hardware.
- Microphone capture, speaker output, audio-device permissions, echo, real-time quality, sustained calls or simultaneous voice-call load.
- Production penetration testing, comprehensive denial-of-service resistance, audit/retention controls, malware scanning, or sustained 20-user capacity.
- Abrupt power-loss recovery and Windows ACL enforcement. The backup test used a clean shutdown, not a live database copy.
- Aggregate document quota enforcement passed with the storage-limit constant temporarily set to 5 bytes; physical 1 GiB storage filling was not performed.

These results support a **reviewable MVP and supervised two-computer pilot**, not an assertion that office deployment is already complete.

## Final aggregate checks

- `python -m py_compile server.py admin.py client.py bootstrap_client.py make_cert.py test_server.py tests/*.py` — passed.
- `python -m unittest -v test_server` — 20 passed, 18.136 seconds.
- `python -m unittest discover -s tests -v` — 7 passed, 0.560 seconds.

The seven helper checks exercise extracted client API/voice classes without importing Qt: unsafe origins rejected, CA required, redirects refused, synthetic capture/relay/playback bytes using a mocked sounddevice, and missing-device cleanup. Two further checks generate temporary certificates, validate constraints/SANs/encrypted CA key/server TLS loading and overwrite refusal, and reject a weak passphrase. These are **not a GUI or physical audio test**.

## Raw final server output

```text
test_aggregate_upload_quota (test_server.IntegrationTests.test_aggregate_upload_quota) ... ok
test_auth_logout_expiry_and_no_password_in_roster (test_server.IntegrationTests.test_auth_logout_expiry_and_no_password_in_roster) ... ok
test_call_consent_authorization_and_busy (test_server.IntegrationTests.test_call_consent_authorization_and_busy) ... ok
test_disabled_user_and_login_rate_limit (test_server.IntegrationTests.test_disabled_user_and_login_rate_limit) ... ok
test_files_roundtrip_and_authorization (test_server.IntegrationTests.test_files_roundtrip_and_authorization) ... ok
test_group_membership_and_input_validation (test_server.IntegrationTests.test_group_membership_and_input_validation) ... ok
test_logout_ends_call_and_single_peer_timeout (test_server.IntegrationTests.test_logout_ends_call_and_single_peer_timeout) ... ok
test_media_bounds_queue_and_timeout (test_server.IntegrationTests.test_media_bounds_queue_and_timeout) ... ok
test_offline_backup_restore (test_server.IntegrationTests.test_offline_backup_restore) ... ok
test_password_change_revokes_existing_sessions (test_server.IntegrationTests.test_password_change_revokes_existing_sessions) ... ok
test_pcm_audio_bidirectional_roundtrip_and_end (test_server.IntegrationTests.test_pcm_audio_bidirectional_roundtrip_and_end) ... ok
test_private_message_authorization_and_cursor (test_server.IntegrationTests.test_private_message_authorization_and_cursor) ... ok
test_public_wildcard_and_hostname_bind_rejected (test_server.IntegrationTests.test_public_wildcard_and_hostname_bind_rejected) ... ok
test_request_limits_before_reading_large_body (test_server.IntegrationTests.test_request_limits_before_reading_large_body) ... ok
test_restart_persists_messages_files_not_sessions (test_server.IntegrationTests.test_restart_persists_messages_files_not_sessions) ... ok
test_stalled_tls_handshake_does_not_block_accept (test_server.IntegrationTests.test_stalled_tls_handshake_does_not_block_accept) ... ok
test_tls_untrusted_certificate_rejected (test_server.IntegrationTests.test_tls_untrusted_certificate_rejected) ... ok
test_twenty_concurrent_clients_smoke (test_server.IntegrationTests.test_twenty_concurrent_clients_smoke) ... ok
test_unsafe_upload_names_and_invalid_payload (test_server.IntegrationTests.test_unsafe_upload_names_and_invalid_payload) ... ok
test_upload_size_limit (test_server.IntegrationTests.test_upload_size_limit) ... ok

----------------------------------------------------------------------
Ran 20 tests in 18.136s

OK
```

## Raw final helper output

```text
test_generation_and_overwrite_refusal (test_cert.Certificates.test_generation_and_overwrite_refusal) ... ok
test_weak_passphrase_refused (test_cert.Certificates.test_weak_passphrase_refused) ... ok
test_device_error_stops_voice (test_client_helpers.ClientHelpers.test_device_error_stops_voice) ... ok
test_redirect_never_follows_even_to_https (test_client_helpers.ClientHelpers.test_redirect_never_follows_even_to_https) ... ok
test_reject_unsafe_origins_before_tls (test_client_helpers.ClientHelpers.test_reject_unsafe_origins_before_tls) ... ok
test_synthetic_pcm_capture_relay_playback (test_client_helpers.ClientHelpers.test_synthetic_pcm_capture_relay_playback) ... ok
test_tls_requires_real_ca (test_client_helpers.ClientHelpers.test_tls_requires_real_ca) ... ok

----------------------------------------------------------------------
Ran 7 tests in 0.560s

OK
```
