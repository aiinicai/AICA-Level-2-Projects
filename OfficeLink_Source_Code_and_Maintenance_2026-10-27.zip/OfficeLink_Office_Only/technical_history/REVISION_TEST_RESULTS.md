# OfficeLink 0.2 — revised validation evidence

26 October 2026. Cloud Linux, Python 3.12.14, OpenSSL 3.5.8. For real UI checks, PyQt6 6.11.0 / Qt 6.11.2 was installed only in a temporary cloud development directory, not on an office computer. No real office credentials, certificates, data or network settings were accessed.

## Final result: 50 tests passed

- `python -m unittest -v test_server`: **21 passed in 19.323 seconds**, actual certificate-verifying localhost HTTPS.
- `QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v` with the temporary Qt dependency directory on PYTHONPATH: **29 passed in 3.371 seconds**.
- `python -m py_compile *.py tests/*.py`: **passed**.

The helper suite comprises 3 certificate checks, 6 API/audio helper checks, 9 deployment-profile/preference checks, 3 Windows notification-policy logic checks, 7 Qt widget checks and 1 actual Qt/HTTPS integration flow. Tests without installed Qt skip the 8 Qt checks; a skipped test is not a pass.

## What this establishes

- The real redesigned Qt login authenticates through strict-verified TLS with a temporary generated CA; there are no server or certificate fields in the staff login.
- The real Qt compose/send flow successfully sends a message, a second authenticated colleague receives it, and the GUI displays that colleague's HTTPS reply.
- A new message received while the real Qt window is minimized increases its unread count/title even with Do Not Disturb enabled. An observed stale-summary race was fixed and given a deterministic regression: already displayed replies are not counted again after minimizing.
- Initial history is baselined without alerts; incoming counts exclude the user's own messages, including mixed-message batches. Conversation summaries are still membership-restricted.
- Notification clicks open the single unread chat or the Chats list when multiple chats are unread; no false per-toast routing guarantee is made.
- The Windows shell policy wrapper suppresses app attention unless the mocked shell reports the accepting state, and fails quiet if querying fails. This is logic testing, not a real Windows Focus/tray test.
- Public-profile provisioning validates approved HTTPS origin, CA constraints/validity/SKI, exact schema and generated-module matching. It rejects private keys and secret/unrecognized preferences. Username/UI choices only are saved; credentials are not.
- Prior server protections, safe document byte transfers, restart/offline backup, call signaling and synthetic PCM tests still pass. Twenty concurrent loopback senders remain only a cloud smoke, not a 20-staff capacity claim.
- Strict certificate validation remains on, including the corrected AKI/SKI certificate generator.

## Real visual previews

`screenshots/login-preview.png` and `screenshots/workspace-preview.png` are screenshots of actual Qt widgets rendered offscreen and visually reviewed. They contain clearly labeled synthetic names/content. They are not office screenshots or proof of Windows behavior. `tests/render_previews.py` reproduces them without server/microphone access.

## Still unrun / pilot gates

- Building and running this **revised** Windows EXE/portable folder. No Windows binary or installer was produced in Linux; `build_windows.ps1` is reviewed source, not a tested Windows build result.
- Actual Windows tray delivery, taskbar attention, sound, Focus/Do Not Disturb interaction, click behavior, close-to-tray and screen scaling.
- Real revised-client two-PC office exchange, physical microphones/headsets, voice latency/echo, document/file-dialog behavior and interruption recovery.
- Office-wide rollout, sustained twenty-person mixed load, penetration testing, code signing, organizational licensing compliance and machine ACL enforcement.

Existing pilot certificates/accounts/data must be preserved. Follow MIGRATION_V02.md; no new firewall rule or certificate generation is required by this revision. The updated server summaries require deploying revised server.py at a planned restart using existing arguments.

## Raw final server results

```text
test_aggregate_upload_quota (test_server.IntegrationTests.test_aggregate_upload_quota) ... ok
test_auth_logout_expiry_and_no_password_in_roster (test_server.IntegrationTests.test_auth_logout_expiry_and_no_password_in_roster) ... ok
test_call_consent_authorization_and_busy (test_server.IntegrationTests.test_call_consent_authorization_and_busy) ... ok
test_conversation_summaries_count_only_incoming_for_requester (test_server.IntegrationTests.test_conversation_summaries_count_only_incoming_for_requester) ... ok
test_disabled_user_and_login_rate_limit (test_server.IntegrationTests.test_disabled_user_and_login_rate_limit) ... ok
test_files_roundtrip_and_authorization (test_server.IntegrationTests.test_files_roundtrip_and_authorization) ... ok
test_group_membership_and_input_validation (test_server.IntegrationTests.test_group_membership_and_input_validation) ... ok
test_logout_ends_call_and_single_peer_timeout (test_server.IntegrationTests.test_logout_ends_call_and_single_peer_timeout) ... ok
test_media_bounds_queue_and_timeout (test_server.IntegrationTests.test_media_bounds_queue_and_timeout) ... ok
test_offline_backup_restore (test_server.IntegrationTests.test_offline_backup_restore) ... ok
test_password_change_revokes_existing_sessions (test_server.IntegrationTests.test_password_change_revokes_existing_sessions) ... ok
test_pcm_audio_bidirectional_roundtrip_and_end (test_server.IntegrationTests.test_pcm_audio_bidirectional_roundtrip_and_end) ... ok
test_private_message_authorization_and_cursor (test_server.IntegrationTests.test_private_message_authorization_and_cursor) ... ok
test_public_wildcard_and_hostname_bind_rejected (test_server.IntegrationTests.test_public_wildcard_and_hostname_bind_rejected) ... ok
test_request_limits_before_reading_large_body (test_server.IntegrationTests.test_request_limits_before_reading_large_body) ... ok
test_restart_persists_messages_files_not_sessions (test_server.IntegrationTests.test_restart_persists_messages_files_not_sessions) ... ok
test_stalled_tls_handshake_does_not_block_accept (test_server.IntegrationTests.test_stalled_tls_handshake_does_not_block_accept) ... ok
test_tls_untrusted_certificate_rejected (test_server.IntegrationTests.test_tls_untrusted_certificate_rejected) ... ok
test_twenty_concurrent_clients_smoke (test_server.IntegrationTests.test_twenty_concurrent_clients_smoke) ... ok
test_unsafe_upload_names_and_invalid_payload (test_server.IntegrationTests.test_unsafe_upload_names_and_invalid_payload) ... ok
test_upload_size_limit (test_server.IntegrationTests.test_upload_size_limit) ... ok

----------------------------------------------------------------------
Ran 21 tests in 19.323s

OK
```

## Raw final helper/UI results

```text
test_generated_chain_passes_strict_tls_handshake (test_cert.Certificates.test_generated_chain_passes_strict_tls_handshake) ... ok
test_generation_and_overwrite_refusal (test_cert.Certificates.test_generation_and_overwrite_refusal) ... ok
test_weak_passphrase_refused (test_cert.Certificates.test_weak_passphrase_refused) ... ok
test_certificate_error_is_actionable (test_client_helpers.ClientHelpers.test_certificate_error_is_actionable) ... ok
test_device_error_stops_voice (test_client_helpers.ClientHelpers.test_device_error_stops_voice) ... ok
test_redirect_never_follows_even_to_https (test_client_helpers.ClientHelpers.test_redirect_never_follows_even_to_https) ... ok
test_reject_unsafe_origins_before_tls (test_client_helpers.ClientHelpers.test_reject_unsafe_origins_before_tls) ... ok
test_synthetic_pcm_capture_relay_playback (test_client_helpers.ClientHelpers.test_synthetic_pcm_capture_relay_playback) ... ok
test_tls_requires_real_ca (test_client_helpers.ClientHelpers.test_tls_requires_real_ca) ... ok
test_nonwindows_dev_context (test_notification_policy.NotificationPolicy.test_nonwindows_dev_context) ... ok
test_windows_only_explicitly_accepting_state (test_notification_policy.NotificationPolicy.test_windows_only_explicitly_accepting_state) ... ok
test_windows_query_failure_fails_quiet (test_notification_policy.NotificationPolicy.test_windows_query_failure_fails_quiet) ... ok
test_bad_origin_rejected (test_profile.Profiles.test_bad_origin_rejected) ... ok
test_digest_is_not_present_as_self_authentication (test_profile.Profiles.test_digest_is_not_present_as_self_authentication) ... ok
test_missing_profile_and_invalid_embedded_profile (test_profile.Profiles.test_missing_profile_and_invalid_embedded_profile) ... ok
test_no_overwrite (test_profile.Profiles.test_no_overwrite) ... ok
test_preferences_allowlist_and_no_remember (test_profile.Profiles.test_preferences_allowlist_and_no_remember) ... ok
test_private_dns_and_ipv4 (test_profile.Profiles.test_private_dns_and_ipv4) ... ok
test_profile_roundtrip_and_exact_module_check (test_profile.Profiles.test_profile_roundtrip_and_exact_module_check) ... ok
test_secrets_unknown_fields_and_bad_ca_rejected (test_profile.Profiles.test_secrets_unknown_fields_and_bad_ca_rejected) ... ok
test_username_only_and_profile_scoped (test_profile.Profiles.test_username_only_and_profile_scoped) ... ok
test_preconfigured_login_and_actual_two_way_messages (test_qt_integration.QtIntegration.test_preconfigured_login_and_actual_two_way_messages) ... ok
test_composer_disabled_before_chat (test_qt_ui.WidgetTests.test_composer_disabled_before_chat) ... ok
test_group_voice_disabled (test_qt_ui.WidgetTests.test_group_voice_disabled) ... ok
test_initial_history_not_unread_and_new_counts_exact (test_qt_ui.WidgetTests.test_initial_history_not_unread_and_new_counts_exact) ... ok
test_notification_multiple_rooms_routes_chat_list_not_wrong_chat (test_qt_ui.WidgetTests.test_notification_multiple_rooms_routes_chat_list_not_wrong_chat) ... ok
test_notification_single_room_opens_that_chat (test_qt_ui.WidgetTests.test_notification_single_room_opens_that_chat) ... ok
test_profile_login_has_no_server_or_ca_picker (test_qt_ui.WidgetTests.test_profile_login_has_no_server_or_ca_picker) ... ok
test_visible_reply_after_stale_summary_is_not_alerted_again (test_qt_ui.WidgetTests.test_visible_reply_after_stale_summary_is_not_alerted_again) ... ok

----------------------------------------------------------------------
Ran 29 tests in 3.371s

OK
```
