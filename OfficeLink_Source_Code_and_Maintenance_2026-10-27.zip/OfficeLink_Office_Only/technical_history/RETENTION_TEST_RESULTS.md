# OfficeLink 0.4 — retention validation

26 October 2026. Cloud Linux Python 3.12.14, OpenSSL 3.5.8, actual Qt offscreen widgets where applicable. No real office files, database, account, keys or network settings were accessed or deleted.

## Final: 105 tests passed

- `python -m unittest -v test_server`: **21 passed in 19.533 seconds**.
- `QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v` with the temporary cloud Qt dependency path: **84 passed in 18.907 seconds**.
- `python -m py_compile *.py tests/*.py`: passed.

Thirteen new retention backend/administrator tests establish default-OFF and legacy migration preservation; future-only 24-hour deadlines; exact expiry boundary; disabled-policy cancellation; quota release without removing chat metadata; member expiry410 versus outsider403; downloaded local copy unchanged; status/admin construction does not purge; explicit enable confirmation; startup cleanup; periodic worker logic; lock serialization, idempotency and an already-started download snapshot. A real strict-HTTPS flow checks the attachment expiry endpoint. Time is advanced only in temporary test fixtures, never on a user's machine. Periodic scheduling is exercised with a controlled wait function, not a day-long wall-clock run.

Eight new actual Qt widget tests cover expired tombstones with no download link, displayed pending deadlines, merging expired states into already-cached messages without new text, safe malformed-time handling, no local-clock deletion inference, storage warning thresholds, unscheduled files, and older-server fallback.

Prior 33 MiB/50 MiB strict-HTTPS roundtrips, password lifecycle, messaging/unread, access controls, backup/restart and synthetic voice checks remain passing.

## Explicit limits

This is not a Windows binary build, a real overnight-office expiry observation, or forensic secure-erasure certification. Updated Windows display, real scheduled deadline behavior, office clock accuracy and continued pilot messaging/audio/file behavior require verification. SQLite quota/pages are freed for reuse; OS-level database-file shrinking and VACUUM were not performed or promised. Local downloads, originals and backups remain outside this policy. Existing unscheduled files stay unscheduled.

The source update leaves policy OFF. The included administrator command requires an explicit confirmation flag before future uploads receive permanent server re-download expiry. No live enable command or cleanup was run.

User-reported prior pilot successes (v0.3 real33MB transfer/open and own-password change/relogin, plus earlier messaging/alerts/audio/smallfiles) are context only, not independently observed cloud tests. Real temporary-first-login testing remains a separate pilot item.

See RETENTION_24H.md for the informed-enable warning and minimal update from v0.3. No new certificates, profile, dependency installation, firewall rule or bulk account action is required.

## Raw server results

```text
test_aggregate_upload_quota (test_server.IntegrationTests.test_aggregate_upload_quota) ... ok
test_auth_logout_expiry_and_no_password_in_roster (test_server.IntegrationTests.test_auth_logout_expiry_and_no_password_in_roster) ... ok
test_call_consent_authorization_and_busy (test_server.IntegrationTests.test_call_consent_authorization_and_busy) ... ok
test_conversation_summaries_count_only_incoming_for_requester (test_server.IntegrationTests.test_conversation_summaries_count_only_incoming_for_requester) ... ok
test_disabled_user_and_login_rate_limit (test_server.IntegrationTests.test_disabled_user_and_login_rate_limit) ... ok
test_files_roundtrip_and_authorization (test_server.IntegrationTests.test_files_roundtrip_and_authorization) ... ok
test_group_membership_and_input_validation (test_server.IntegrationTests.test_group_membership_and_input_validation) ... ok
test_logout_ends_call_and_single_peer_timeout (test_server.IntegrationTests.test_logout_ends_call_and_single_peer_timeout) ... ok
test_media_bounds_queue_and_timeout (test_server.IntegrationTests.test_media_bounds_queue_and_timeout) ... ok
test_offline_backup_restore (test_server.IntegrationTests.test_offline_backup_restore) ... ok
test_password_change_revokes_existing_sessions (test_server.IntegrationTests.test_password_change_revokes_existing_sessions) ... ok
test_pcm_audio_bidirectional_roundtrip_and_end (test_server.IntegrationTests.test_pcm_audio_bidirectional_roundtrip_and_end) ... ok
test_private_message_authorization_and_cursor (test_server.IntegrationTests.test_private_message_authorization_and_cursor) ... ok
test_public_wildcard_and_hostname_bind_rejected (test_server.IntegrationTests.test_public_wildcard_and_hostname_bind_rejected) ... ok
test_request_limits_before_reading_large_body (test_server.IntegrationTests.test_request_limits_before_reading_large_body) ... ok
test_restart_persists_messages_files_not_sessions (test_server.IntegrationTests.test_restart_persists_messages_files_not_sessions) ... ok
test_stalled_tls_handshake_does_not_block_accept (test_server.IntegrationTests.test_stalled_tls_handshake_does_not_block_accept) ... ok
test_tls_untrusted_certificate_rejected (test_server.IntegrationTests.test_tls_untrusted_certificate_rejected) ... ok
test_twenty_concurrent_clients_smoke (test_server.IntegrationTests.test_twenty_concurrent_clients_smoke) ... ok
test_unsafe_upload_names_and_invalid_payload (test_server.IntegrationTests.test_unsafe_upload_names_and_invalid_payload) ... ok
test_upload_size_limit (test_server.IntegrationTests.test_upload_size_limit) ... ok

----------------------------------------------------------------------
Ran 21 tests in 19.533s

OK
```

## Raw helper/UI results

```text
test_generated_chain_passes_strict_tls_handshake (test_cert.Certificates.test_generated_chain_passes_strict_tls_handshake) ... ok
test_generation_and_overwrite_refusal (test_cert.Certificates.test_generation_and_overwrite_refusal) ... ok
test_weak_passphrase_refused (test_cert.Certificates.test_weak_passphrase_refused) ... ok
test_certificate_error_is_actionable (test_client_helpers.ClientHelpers.test_certificate_error_is_actionable) ... ok
test_device_error_stops_voice (test_client_helpers.ClientHelpers.test_device_error_stops_voice) ... ok
test_redirect_never_follows_even_to_https (test_client_helpers.ClientHelpers.test_redirect_never_follows_even_to_https) ... ok
test_reject_unsafe_origins_before_tls (test_client_helpers.ClientHelpers.test_reject_unsafe_origins_before_tls) ... ok
test_synthetic_pcm_capture_relay_playback (test_client_helpers.ClientHelpers.test_synthetic_pcm_capture_relay_playback) ... ok
test_tls_requires_real_ca (test_client_helpers.ClientHelpers.test_tls_requires_real_ca) ... ok
test_busy_download_is_visible_and_not_started (test_file_ui.FileUI.test_busy_download_is_visible_and_not_started) ... ok
test_no_selected_chat_explains_action (test_file_ui.FileUI.test_no_selected_chat_explains_action) ... ok
test_oversize_file_has_visible_actionable_error (test_file_ui.FileUI.test_oversize_file_has_visible_actionable_error) ... ok
test_save_cancel_releases_busy_state (test_file_ui.FileUI.test_save_cancel_releases_busy_state) ... ok
test_advertised_limits_validation_and_legacy_fallback (test_large_files.ClientTransferBounds.test_advertised_limits_validation_and_legacy_fallback) ... ok
test_cli_limit_range_rejected_before_server_start (test_large_files.ClientTransferBounds.test_cli_limit_range_rejected_before_server_start) ... ok
test_client_busy_transfer_refused (test_large_files.ClientTransferBounds.test_client_busy_transfer_refused) ... ok
test_declared_response_oversize_rejected_before_read (test_large_files.ClientTransferBounds.test_declared_response_oversize_rejected_before_read) ... ok
test_file_timeout_and_bounded_response_read (test_large_files.ClientTransferBounds.test_file_timeout_and_bounded_response_read) ... ok
test_33_mib_actual_tls_client_roundtrip_sha256 (test_large_files.LargeTransfers.test_33_mib_actual_tls_client_roundtrip_sha256) ... ok
test_50_mib_actual_tls_client_roundtrip_sha256 (test_large_files.LargeTransfers.test_50_mib_actual_tls_client_roundtrip_sha256) ... ok
test_aggregate_quota_unchanged (test_large_files.LargeTransfers.test_aggregate_quota_unchanged) ... ok
test_configured_one_mib_limit_boundary_and_clear_error (test_large_files.LargeTransfers.test_configured_one_mib_limit_boundary_and_clear_error) ... ok
test_declared_oversize_body_rejected_before_read_and_slot_released (test_large_files.LargeTransfers.test_declared_oversize_body_rejected_before_read_and_slot_released) ... ok
test_server_single_transfer_slot_rejects_busy_without_blocking_chat (test_large_files.LargeTransfers.test_server_single_transfer_slot_rejects_busy_without_blocking_chat) ... ok
test_nonwindows_dev_context (test_notification_policy.NotificationPolicy.test_nonwindows_dev_context) ... ok
test_windows_only_explicitly_accepting_state (test_notification_policy.NotificationPolicy.test_windows_only_explicitly_accepting_state) ... ok
test_windows_query_failure_fails_quiet (test_notification_policy.NotificationPolicy.test_windows_query_failure_fails_quiet) ... ok
test_cancel_mandatory_revokes_token (test_password_ui.PasswordUITests.test_cancel_mandatory_revokes_token) ... ok
test_cancel_optional_preserves_session (test_password_ui.PasswordUITests.test_cancel_optional_preserves_session) ... ok
test_mandatory_login_does_not_accept_workspace (test_password_ui.PasswordUITests.test_mandatory_login_does_not_accept_workspace) ... ok
test_pending_close_and_repeat_submit_are_guarded (test_password_ui.PasswordUITests.test_pending_close_and_repeat_submit_are_guarded) ... ok
test_real_tls_password_dialog_revokes_session_and_reauthenticates (test_password_ui.PasswordUITests.test_real_tls_password_dialog_revokes_session_and_reauthenticates) ... ok
test_server_error_keeps_workspace_locked_and_fields_empty (test_password_ui.PasswordUITests.test_server_error_keeps_workspace_locked_and_fields_empty) ... ok
test_success_clears_fields_and_requires_login (test_password_ui.PasswordUITests.test_success_clears_fields_and_requires_login) ... ok
test_validation_does_not_send_mismatched_or_same_password (test_password_ui.PasswordUITests.test_validation_does_not_send_mismatched_or_same_password) ... ok
test_account_wide_rate_limit_and_expiry (test_passwords.PasswordTests.test_account_wide_rate_limit_and_expiry) ... ok
test_actual_strict_https_password_change (test_passwords.PasswordTests.test_actual_strict_https_password_change) ... ok
test_admin_add_user_uses_temporary_password (test_passwords.PasswordTests.test_admin_add_user_uses_temporary_password) ... ok
test_admin_reset_requires_change_and_never_prints_password (test_passwords.PasswordTests.test_admin_reset_requires_change_and_never_prints_password) ... ok
test_change_clears_requirement_and_requires_reauthentication (test_passwords.PasswordTests.test_change_clears_requirement_and_requires_reauthentication) ... ok
test_change_endpoint_requires_authenticated_token (test_passwords.PasswordTests.test_change_endpoint_requires_authenticated_token) ... ok
test_change_revokes_all_own_sessions_and_calls_only (test_passwords.PasswordTests.test_change_revokes_all_own_sessions_and_calls_only) ... ok
test_existing_database_additive_migration_preserves_access (test_passwords.PasswordTests.test_existing_database_additive_migration_preserves_access) ... ok
test_invalid_and_reused_new_passwords_rejected (test_passwords.PasswordTests.test_invalid_and_reused_new_passwords_rejected) ... ok
test_temporary_session_cannot_access_workspace (test_passwords.PasswordTests.test_temporary_session_cannot_access_workspace) ... ok
test_wrong_current_password_does_not_change_or_revoke (test_passwords.PasswordTests.test_wrong_current_password_does_not_change_or_revoke) ... ok
test_bad_origin_rejected (test_profile.Profiles.test_bad_origin_rejected) ... ok
test_digest_is_not_present_as_self_authentication (test_profile.Profiles.test_digest_is_not_present_as_self_authentication) ... ok
test_missing_profile_and_invalid_embedded_profile (test_profile.Profiles.test_missing_profile_and_invalid_embedded_profile) ... ok
test_no_overwrite (test_profile.Profiles.test_no_overwrite) ... ok
test_preferences_allowlist_and_no_remember (test_profile.Profiles.test_preferences_allowlist_and_no_remember) ... ok
test_private_dns_and_ipv4 (test_profile.Profiles.test_private_dns_and_ipv4) ... ok
test_profile_roundtrip_and_exact_module_check (test_profile.Profiles.test_profile_roundtrip_and_exact_module_check) ... ok
test_secrets_unknown_fields_and_bad_ca_rejected (test_profile.Profiles.test_secrets_unknown_fields_and_bad_ca_rejected) ... ok
test_username_only_and_profile_scoped (test_profile.Profiles.test_username_only_and_profile_scoped) ... ok
test_preconfigured_login_and_actual_two_way_messages (test_qt_integration.QtIntegration.test_preconfigured_login_and_actual_two_way_messages) ... ok
test_composer_disabled_before_chat (test_qt_ui.WidgetTests.test_composer_disabled_before_chat) ... ok
test_group_voice_disabled (test_qt_ui.WidgetTests.test_group_voice_disabled) ... ok
test_initial_history_not_unread_and_new_counts_exact (test_qt_ui.WidgetTests.test_initial_history_not_unread_and_new_counts_exact) ... ok
test_notification_multiple_rooms_routes_chat_list_not_wrong_chat (test_qt_ui.WidgetTests.test_notification_multiple_rooms_routes_chat_list_not_wrong_chat) ... ok
test_notification_single_room_opens_that_chat (test_qt_ui.WidgetTests.test_notification_single_room_opens_that_chat) ... ok
test_profile_login_has_no_server_or_ca_picker (test_qt_ui.WidgetTests.test_profile_login_has_no_server_or_ca_picker) ... ok
test_visible_reply_after_stale_summary_is_not_alerted_again (test_qt_ui.WidgetTests.test_visible_reply_after_stale_summary_is_not_alerted_again) ... ok
test_admin_enable_requires_explicit_confirmation (test_retention.RetentionTests.test_admin_enable_requires_explicit_confirmation) ... ok
test_admin_status_and_app_constructor_do_not_purge (test_retention.RetentionTests.test_admin_status_and_app_constructor_do_not_purge) ... ok
test_already_started_download_snapshot_survives_expiry (test_retention.RetentionTests.test_already_started_download_snapshot_survives_expiry) ... ok
test_default_off_upload_has_no_deadline_and_never_expires (test_retention.RetentionTests.test_default_off_upload_has_no_deadline_and_never_expires) ... ok
test_disabled_policy_cancels_pending_deadlines_and_reenable_not_retroactive (test_retention.RetentionTests.test_disabled_policy_cancels_pending_deadlines_and_reenable_not_retroactive) ... ok
test_enable_only_future_uploads_and_exact_deadline_boundary (test_retention.RetentionTests.test_enable_only_future_uploads_and_exact_deadline_boundary) ... ok
test_expiry_obeys_database_lock_and_is_idempotent (test_retention.RetentionTests.test_expiry_obeys_database_lock_and_is_idempotent) ... ok
test_expiry_preserves_chat_and_authorization_but_returns_gone (test_retention.RetentionTests.test_expiry_preserves_chat_and_authorization_but_returns_gone) ... ok
test_legacy_schema_migration_never_backfills_or_deletes (test_retention.RetentionTests.test_legacy_schema_migration_never_backfills_or_deletes) ... ok
test_periodic_worker_retries_expiry_on_tick (test_retention.RetentionTests.test_periodic_worker_retries_expiry_on_tick) ... ok
test_real_strict_https_expired_download_and_storage (test_retention.RetentionTests.test_real_strict_https_expired_download_and_storage) ... ok
test_restart_server_cleans_overdue_attachment_and_stops_worker (test_retention.RetentionTests.test_restart_server_cleans_overdue_attachment_and_stops_worker) ... ok
test_storage_quota_accounting_freed_without_touching_saved_copy (test_retention.RetentionTests.test_storage_quota_accounting_freed_without_touching_saved_copy) ... ok
test_disabling_pending_expiry_refreshes_cached_deadline (test_retention_ui.RetentionUI.test_disabling_pending_expiry_refreshes_cached_deadline) ... ok
test_expired_attachment_is_tombstone_without_download_link (test_retention_ui.RetentionUI.test_expired_attachment_is_tombstone_without_download_link) ... ok
test_invalid_storage_metadata_is_handled (test_retention_ui.RetentionUI.test_invalid_storage_metadata_is_handled) ... ok
test_no_local_clock_guess_of_permanent_expiry (test_retention_ui.RetentionUI.test_no_local_clock_guess_of_permanent_expiry) ... ok
test_old_server_storage_404_does_not_break_chat_poll (test_retention_ui.RetentionUI.test_old_server_storage_404_does_not_break_chat_poll) ... ok
test_state_refresh_expires_cached_attachment_without_new_text (test_retention_ui.RetentionUI.test_state_refresh_expires_cached_attachment_without_new_text) ... ok
test_storage_warning_thresholds_and_existing_file_disclosure (test_retention_ui.RetentionUI.test_storage_warning_thresholds_and_existing_file_disclosure) ... ok
test_unexpired_attachment_has_deadline_and_download_link (test_retention_ui.RetentionUI.test_unexpired_attachment_has_deadline_and_download_link) ... ok

----------------------------------------------------------------------
Ran 84 tests in 18.907s

OK
```
