# Validation and two-PC pilot checklist

This checklist separates code checks from evidence on actual Windows PCs. A passing local integration test does **not** establish Windows GUI operation, real audio quality or 20-person production capacity.

## Automated checks

See the packaged test report for exact commands, environment and results. Use temporary directories, randomly generated test passwords and non-sensitive dummy files. Do not reuse test credentials. Repeat all checks after security-relevant changes.

| Area | Evidence required | Status to record |
|---|---|---|
| Python syntax | Compile all source files | Refer to final test report |
| HTTPS identity | Correct CA and hostname succeed; wrong CA/name fail | Refer to final test report |
| Authentication | Wrong password, disabled user, session expiry/logout rejected | Refer to final test report |
| Conversation authorization | Nonmembers cannot list/read/post/download another conversation | Refer to final test report |
| Documents | Valid transfer round-trip hash; malformed/oversize/unsafe file rejected | Refer to final test report |
| Persistence | Stop/recreate server, verify history/memberships/files | Refer to final test report |
| Voice signaling | Ring, accept, reject/end and unauthorized callers | Refer to final test report |
| Voice media relay | Synthetic PCM bytes delivered only to correct peer over TLS | Refer to final test report |
| Real microphone/speaker | Physical Windows two-way audio | **Not run here** |
| Windows GUI | Login, layout, file dialogs, notifications and worker-thread behavior | **Not run here** |
| Office network | Firewall, AP isolation, Wi-Fi loss, day-close/restart | **Not run here** |
| Capacity | 20 active users with realistic text/file/call mix | **Not run here** |

## First pilot — administrator and two volunteers only

Record date, operator, server/client Windows builds, Python and dependency versions, PC specs, network type, reserved address, latency/loss, headset models and any failures. Use three test accounts (Alice, Bob, outsider Carol) even if only two physical clients are available.

1. **Install and trust:** approve dependencies explicitly. Check the CA fingerprint with the administrator. Confirm wrong CA and wrong server hostname fail visibly; there must be no “ignore certificate” path.
2. **Login and interrupted login:** correct credentials succeed; incorrect password does not. Cancel before login, double-click login, close during connection, reopen and verify no password/session was persisted. Check screen scaling at 100%, 125% and 150% on the target laptops.
3. **Identity and presence:** confirm display names map to the right people. Sign Bob out and interrupt Wi-Fi; confirm presence eventually turns offline. Restore Wi-Fi and sign in again without duplicate confusing windows.
4. **Private/group text:** exchange accented/non-Latin names and multi-line messages. Create a group with Alice and Bob; verify Carol cannot access its content using the API. Repeat clicks, switch conversations while requests run and confirm replies go to the intended conversation.
5. **Documents:** transfer a dummy PDF/DOCX/spreadsheet and compare SHA-256 hashes. Confirm save prompts, cancellation, repeated download, unsafe filename handling and rejection of files outside the permitted size/types. Never auto-open attachments. Scan received files with normal endpoint protection.
6. **Calls:** Alice calls Bob; test accept, reject, caller cancel, either side hanging up, busy participant, sign-out, connection loss and interrupted ringing. Confirm audio starts only after acceptance and capture stops after hang-up/close. On both PCs use headsets, test microphone permission denial, unplug/replug and unavailable default devices. Listen both ways for several minutes; record dropouts, echo and one-way latency. Synthetic PCM tests do not substitute for this.
7. **Restart:** send a message and upload a file, close clients, stop server cleanly, shut down/restart the server PC, start server and log in again. Confirm history and download hashes; establish expected behavior for a send/call interrupted mid-flight. Verify unsent messages are not falsely shown as delivered.
8. **Account controls:** stop server, disable a test account, restart and verify it cannot log in. Reset another test password; verify the old password no longer works. Confirm account administration is local CLI only and restricted through Windows filesystem access; staff/admin role labels are not a substitute for OS permissions.
9. **Backup recovery:** stop server; copy the complete data folder. Restore to an isolated location/address with correct TLS identity and verify the same records/file hashes. Record a recoverable backup before any real data is admitted.
10. **Security and scope:** verify only the office client subnet can reach TCP 8443, Public-network access is blocked, no router forwarding exists, and server keys/data/backups have restricted ACLs. Verify no runtime internet service is needed. Have IT review supported Windows version and licensing constraints.

## Expansion gate

Only expand beyond the pilot after the above is signed off, open defects are assessed, dependencies are pinned and retained, backup restore is proven, and the organization approves handling confidential documents. Then perform a staged concurrency test (5, 10, then approximately 20 staff) measuring CPU, RAM, disk, response latency, failed operations and call quality under simultaneous uploads. Test on the actual server and office Wi-Fi. Do not promise a supported maximum from a small local test.

**Pilot approval:** ____________________  **Date:** __________

**Open defects / accepted limitations:** ______________________________________
