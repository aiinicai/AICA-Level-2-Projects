# Existing pilot → OfficeLink 0.2

Keep the existing working CA/server certificates, server address, staff accounts and data. This revision does NOT need new private keys, account initialization, another firewall rule or a different network profile.

1. Arrange a short pilot maintenance window and stop the running server cleanly. Back up the complete data folder following the existing guide. Keep the old source/build separately for rollback; never overwrite backups.
2. Replace the application source with this revision, without replacing the real `data*`, `certs*`, `.venv` or deployment configuration folders. `server.py` adds per-user incoming-message summaries and an index; it preserves existing records and account passwords.
3. Start the revised server with exactly the existing approved host/port/data/cert/key arguments. The server CLI is unchanged. A restart requires staff to sign in again.
4. On the approved Windows build machine, use `create_profile.py` with the existing actual LAN endpoint and its existing public `ca.pem`, then follow `DEPLOY_STAFF.md`. This binds the public identity into the staff app. Do not use the localhost profile for another PC. The tool refuses accidental overwrite; review replacement profiles explicitly.
5. Test the new packaged app locally and on the already-approved colleague pilot. Verify real sends both ways; then minimize and check new-message badges/alerts/click routing. Test DND, quiet/full-screen mode, notification-disabled Windows settings, close-to-tray, sign-out, file transfer and explicitly accepted audio. No additional machine or network rollout is authorized here.

The revised client can still chat against an older server, but shows a warning that background notifications require a server update. An older client can use the revised server; extra response fields do not change existing messages.

Rollback means stopping the server and restoring the previous source/configuration or approved backup as needed, not deleting the current database. Keep backup and key access restricted.
