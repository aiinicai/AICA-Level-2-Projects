# OfficeLink 0.2 — staff-friendly LAN prototype

A custom Windows desktop messenger for a small office, provisionally named **OfficeLink**. The server can run on the office's ordinary Windows PC during working hours. Staff do not need internet access to use it after installation.

## Included

- Named staff accounts; online/offline presence; private and group text conversations.
- Conversation-restricted document sharing and persistent chat history.
- One-to-one voice calling using a server-relayed audio prototype.
- TLS-encrypted client/server transport with a private CA; no insecure-certificate bypass.
- A preconfigured, redesigned staff sign-in: username/password only; optional username memory, never saved passwords.
- Background unread badges, tray notifications/taskbar attention, Do Not Disturb and optional sound.
- Local administration, SQLite storage, secure IT profile preparation and a Windows build helper.

**This is source code for review and a two-PC pilot, not an installed product or a production-readiness claim.** This revision has not been installed on your office machines by these cloud build tools. No office firewall, startup setting, credential store or router has been changed. Windows compatibility, real microphones/speakers, office Wi-Fi and 20-person capacity still need qualification.

## Start here

1. Start with [FIRST_RUN.md](FIRST_RUN.md), then have your IT administrator read [DEPLOYMENT.md](DEPLOYMENT.md), including certificate, Windows-version and licensing prerequisites.
3. Build a test setup on the server PC and one other Windows PC using **test accounts and non-sensitive documents**.
4. Complete [VALIDATION.md](VALIDATION.md) before adding staff or confidential files.

The server is a Python standard-library HTTPS service. The desktop client uses PyQt6; voice uses sounddevice/PortAudio. Client passwords and session tokens are kept in memory, not saved for automatic login. Windows sign-in can launch the app, but staff must sign in again.

## Important limitations

- All users need access to the same trusted office LAN; guest Wi-Fi/client isolation may prevent connection. No port forwarding or internet exposure.
- The server must remain awake and running. When it is switched off, messaging and calls stop. On restart, saved messages/files remain, but staff sign in again.
- Transport encryption is **not end-to-end encryption**: the server processes messages, documents and voice. The database/files are not application-encrypted at rest; protect the Windows account, disk, folder ACLs and backups.
- One-to-one voice is an experimental HTTPS PCM relay, not a mature WebRTC/VoIP stack. Use headsets. Echo cancellation, optimized codecs and production congestion management are not promised; test delay and stability on your Wi-Fi.
- Uploads are limited to 10 MiB each and 1 GiB total stored document content. No retention/delete UI is included.
- A document extension allowlist is not malware scanning. Do not automatically open received files; use your endpoint protection and normal document handling rules.
- No executable installer, code signing, enterprise SSO or unattended service integration is supplied. Packaging and organizational licensing review are deployment gates.

## Files

`server.py` — HTTPS server; `admin.py` — local account administration; `client.py` — desktop UI; `bootstrap_client.py` — explicit opt-in client dependency setup; `make_cert.py` — private CA/server certificate generator; `requirements*.txt` — dependency declarations; tests and validation records accompany the source.

## Dependency licensing

PyQt is offered under GPL v3 or a commercial license. Have your organization determine the appropriate licensing path before distributing or packaging this application; using it internally is not a blanket licensing conclusion. Review Qt, PortAudio and all transitive dependency notices too. Primary references: [Riverbank licensing](https://en.riverbankcomputing.com/software/pyqt), [Riverbank license FAQ](https://www.riverbankcomputing.com/commercial/license-faq), [sounddevice installation](https://python-sounddevice.readthedocs.io/en/0.5.0/installation.html).

## Revised UI and alerts

See [STAFF_GUIDE.md](STAFF_GUIDE.md) for minimize/close/sign-out and alert behavior. `screenshots/` contains real offscreen Qt renders with synthetic preview data, not proof of Windows runtime. [REVISION_TEST_RESULTS.md](REVISION_TEST_RESULTS.md) records this revision’s exact checks.
