# OfficeLink office-only package — current validation

Date: 27 October 2026. Runtime: CPython 3.12.14 on Linux; PyQt6 6.11.0 / Qt 6.11.2. Tests used temporary accounts, certificates and sample bytes. No employee credentials or real client documents were used.

## Executed checks

- Consolidated inherited suite: **105 tests passed; 58 subtests passed**, 38.86 seconds.
- New host-console suite after final certificate checks: **3 tests passed**, 4.14 seconds.
- Total distinct test cases across those two runs: **108 passed**, plus the 58 subtests. This is not a claim of independent security certification.
- New-office creation, correct issuing certificate, private IPv4 guard, certificate IP mismatch refusal, and refusal to overwrite existing configuration/data.
- Staff ZIP exact allowlist and contents: public profile and client code included; database, host console, CA private key, server private key and test password excluded. Existing ZIP protected against overwrite.
- Twenty simultaneous simulated employee clients signed in over certificate-verified loopback HTTPS. Nineteen private messages were sent to the first account and read back. A sample attachment was transferred byte-for-byte, an unrelated colleague was denied access, and host restart preserved conversations and file content.
- Existing suite covers wrong credentials, expired/disabled sessions, mandatory password change, TLS verification, conversation/file membership, file limits, temporary retention behaviour, UI errors and background unread handling.
- Actual Qt host screen rendered offscreen; setup buttons and unconfigured start guard checked. Login and chat interfaces rendered with synthetic content and visually inspected.
- Source compilation passed.

## Not yet verified in your office

Windows installation/first-run bootstrap, Windows tray/notification behaviour, host power settings, actual Wi-Fi/firewall reachability, server CPU/memory use during a working day, twenty real PCs, sustained large-file load, microphone/headset behaviour, antivirus integration and backup restoration on your Windows machines.

## Practical pilot

1. Keep the existing pilot backed up and stopped before importing its data.
2. Use two Windows PCs on the office network and a non-sensitive PDF/Excel file.
3. Check direct messages, minimized alerts, document save, temporary-password change and restart/history.
4. Retain a protected database/certificate backup and test a restore into a separate data folder.
5. Introduce the remaining staff after these checks work in your environment.

The source-based package is ready for that pilot. It has not been installed or deployed by this preparation session. The default attachment limits remain 50 MiB per file and 1 GiB total; expiry is off for a new office and unchanged for an imported office.
