# OfficeLink 0.3 — executed update checks

26 October 2026; cloud Linux Python 3.12.14, OpenSSL 3.5.8; actual offscreen Qt6 widgets where applicable. No real office document, account, password, certificate or network setting was accessed or modified.

## Final result: 84 automated tests passed

- `python -m unittest -v test_server`: **21 passed in 19.828 seconds**.
- `QT_QPA_PLATFORM=offscreen python -m unittest discover -s tests -v` with approved temporary cloud Qt dependencies on PYTHONPATH: **63 passed in 14.098 seconds**.
- `python -m py_compile *.py tests/*.py`: passed.

The additional transfer suite performs real **33 MiB and 50 MiB** uploads/downloads through the actual client API and strict-verified loopback HTTPS, with exact SHA-256 byte comparisons. Other checks cover over-cap rejection, declared oversized bodies before reading, server/client one-transfer slots, bounded responses, 120-second file-only timeout, configured limits and unchanged aggregate quota. Four actual Qt widget checks verify a visible actionable oversize error, no-selected-chat explanation, busy-download explanation and canceled-save cleanup.

Eleven backend/admin password checks and eight Qt/password-dialog checks cover legacy account migration, temporary-password workspace blocking, current-password verification, validation/rate limiting, all-session revocation/call cleanup, hidden administrator create/reset prompts and real strict-HTTPS password change plus fresh login. Passwords are never stored in client preferences or printed by the administrator tool. The tests use ephemeral fixtures only.

Prior messaging, authorization, safe-document handling, notification/unread, TLS, backup/restart and synthetic voice-relay tests remain green. The update preserves existing profile/certificate/data paths. Existing pilot accounts migrate without forced resets; only new or explicitly reset accounts are change-required.

## Limits of this evidence

- These are cloud tests, not a Windows EXE build or a rerun on the office Wi-Fi.
- The real user's 33 MB PDF was not inspected or transferred; size matching used synthetic bytes.
- One bounded in-memory/base64 transfer is allowed at a time per server. It is not streaming; memory can be several multiples of file size. Real Windows resource use, transfer duration and simultaneous call quality need pilot confirmation.
- The 1 GiB aggregate quota is unchanged. No file-retention/deletion interface or production-capacity certification is added.
- User-reported prior pilot successes (two-PC messages, minimized notifications, small PDF/Excel and voice) are preserved as context, not claimed as independently observed tests of this revision.

Use UPDATE_V03.md for the minimal four-file source update and rebuild with the already-approved Windows build helper/profile. No certificate regeneration, new firewall rule, new dependency installation or bulk user creation is required or performed.

## Raw final server output

```text
test_aggregate_upload_quota (test_server.IntegrationTests.test_aggregate_upload_quota) ... ok
test_auth_logout_expiry_and_no_password_in_roster (test_server.IntegrationTests.test_auth_logout_expiry_and_no_password_in_roster) ... ok
test_call_consent_authorization_and_busy (test_server.IntegrationTests.test_call_consent_authorization_and_busy) ... ok
test_conversation_summaries_count_only_incoming_for_requester (test_server.IntegrationTests.test_conversation_summaries_count_only_incoming_for_requester) ... ok
test_disabled_user_and_login_rate_limit (test_server.IntegrationTests.test_disabled_user_and_login_rate_limit) ... ok
test_files_roundtrip_and_authorization (test_server.IntegrationTests.test_files_roundtrip_and_authorization) ... ok
test_group_membership_and_input_validation (test_server.IntegrationTests.test_group_membership_and_input_validation) ... ok
test_logout_ends_call_and_single_peer_timeout (test_server.IntegrationTests.test_logout_ends_call_and_single_peer_timeout) ... ok
test_media_bounds_queue_and_timeout (test_server.IntegrationTests.test_media_bounds_queue_and_timeout) ... ok
test_offline_backup_restore (test_server.IntegrationTests.test_offline_backup_restore) ... ok
test_password_change_revokes_existing_sessions (test_server.IntegrationTests.test_password_change_revokes_existing_sessions) ... ok
test_pcm_audio_bidirectional_roundtrip_and_end (test_server.IntegrationTests.test_pcm_audio_bidirectional_roundtrip_and_end) ... ok
test_private_message_authorization_and_cursor (test_server.IntegrationTests.test_private_message_authorization_and_cursor) ... ok
test_public_wildcard_and_hostname_bind_rejected (test_server.IntegrationTests.test_public_wildcard_and_hostname_bind_rejected) ... ok
test_request_limits_before_reading_large_body (test_server.IntegrationTests.test_request_limits_before_reading_large_body) ... ok
test_restart_persists_messages_files_not_sessions (test_server.IntegrationTests.test_restart_persists_messages_files_not_sessions) ... ok
test_stalled_tls_handshake_does_not_block_accept (test_server.IntegrationTests.test_stalled_tls_handshake_does_not_block_accept) ... ok
test_tls_untrusted_certificate_rejected (test_server.IntegrationTests.test_tls_untrusted_certificate_rejected) ... ok
test_twenty_concurrent_clients_smoke (test_server.IntegrationTests.test_twenty_concurrent_clients_smoke) ... ok
test_unsafe_upload_names_and_invalid_payload (test_server.IntegrationTests.test_unsafe_upload_names_and_invalid_payload) ... ok
test_upload_size_limit (test_server.IntegrationTests.test_upload_size_limit) ... ok

----------------------------------------------------------------------
Ran 21 tests in 19.828s

OK
```

## Raw final helper/UI output

```text
test_generated_chain_passes_strict_tls_handshake (test_cert.Certificates.test_generated_chain_passes_strict_tls_handshake) ... ok
test_generation_and_overwrite_refusal (test_cert.Certificates.test_generation_and_overwrite_refusal) ... ok
test_weak_passphrase_refused (test_cert.Certificates.test_weak_passphrase_refused) ... ok
test_certificate_error_is_actionable (test_client_helpers.ClientHelpers.test_certificate_error_is_actionable) ... ok
test_device_error_stops_voice (test_client_helpers.ClientHelpers.test_device_error_stops_voice) ... ok
test_redirect_never_follows_even_to_https (test_client_helpers.ClientHelpers.test_redirect_never_follows_even_to_https) ... ok
test_reject_unsafe_origins_before_tls (test_client_helpers.ClientHelpers.test_reject_unsafe_origins_before_tls) ... ok
test_synthetic_pcm_capture_relay_playback (test_client_helpers.ClientHelpers.test_synthetic_pcm_capture_relay_playback) ... ok
test_tls_requires_real_ca (test_client_helpers.ClientHelpers.test_tls_requires_real_ca) ... ok
test_busy_download_is_visible_and_not_started (test_file_ui.FileUI.test_busy_download_is_visible_and_not_started) ... ok
test_no_selected_chat_explains_action (test_file_ui.FileUI.test_no_selected_chat_explains_action) ... ok
test_oversize_file_has_visible_actionable_error (test_file_ui.FileUI.test_oversize_file_has_visible_actionable_error) ... ok
test_save_cancel_releases_busy_state (test_file_ui.FileUI.test_save_cancel_releases_busy_state) ... ok
test_advertised_limits_validation_and_legacy_fallback (test_large_files.ClientTransferBounds.test_advertised_limits_validation_and_legacy_fallback) ... ok
test_cli_limit_range_rejected_before_server_start (test_large_files.ClientTransferBounds.test_cli_limit_range_rejected_before_server_start) ... ok
test_client_busy_transfer_refused (test_large_files.ClientTransferBounds.test_client_busy_transfer_refused) ... ok
test_declared_response_oversize_rejected_before_read (test_large_files.ClientTransferBounds.test_declared_response_oversize_rejected_before_read) ... ok
test_file_timeout_and_bounded_response_read (test_large_files.ClientTransferBounds.test_file_timeout_and_bounded_response_read) ... ok
test_33_mib_actual_tls_client_roundtrip_sha256 (test_large_files.LargeTransfers.test_33_mib_actual_tls_client_roundtrip_sha256) ... ok
test_50_mib_actual_tls_client_roundtrip_sha256 (test_large_files.LargeTransfers.test_50_mib_actual_tls_client_roundtrip_sha256) ... ok
test_aggregate_quota_unchanged (test_large_files.LargeTransfers.test_aggregate_quota_unchanged) ... ok
test_configured_one_mib_limit_boundary_and_clear_error (test_large_files.LargeTransfers.test_configured_one_mib_limit_boundary_and_clear_error) ... ok
test_declared_oversize_body_rejected_before_read_and_slot_released (test_large_files.LargeTransfers.test_declared_oversize_body_rejected_before_read_and_slot_released) ... ok
test_server_single_transfer_slot_rejects_busy_without_blocking_chat (test_large_files.LargeTransfers.test_server_single_transfer_slot_rejects_busy_without_blocking_chat) ... ok
test_nonwindows_dev_context (test_notification_policy.NotificationPolicy.test_nonwindows_dev_context) ... ok
test_windows_only_explicitly_accepting_state (test_notification_policy.NotificationPolicy.test_windows_only_explicitly_accepting_state) ... ok
test_windows_query_failure_fails_quiet (test_notification_policy.NotificationPolicy.test_windows_query_failure_fails_quiet) ... ok
test_cancel_mandatory_revokes_token (test_password_ui.PasswordUITests.test_cancel_mandatory_revokes_token) ... ok
test_cancel_optional_preserves_session (test_password_ui.PasswordUITests.test_cancel_optional_preserves_session) ... ok
test_mandatory_login_does_not_accept_workspace (test_password_ui.PasswordUITests.test_mandatory_login_does_not_accept_workspace) ... ok
test_pending_close_and_repeat_submit_are_guarded (test_password_ui.PasswordUITests.test_pending_close_and_repeat_submit_are_guarded) ... ok
test_real_tls_password_dialog_revokes_session_and_reauthenticates (test_password_ui.PasswordUITests.test_real_tls_password_dialog_revokes_session_and_reauthenticates) ... ok
test_server_error_keeps_workspace_locked_and_fields_empty (test_password_ui.PasswordUITests.test_server_error_keeps_workspace_locked_and_fields_empty) ... ok
test_success_clears_fields_and_requires_login (test_password_ui.PasswordUITests.test_success_clears_fields_and_requires_login) ... ok
test_validation_does_not_send_mismatched_or_same_password (test_password_ui.PasswordUITests.test_validation_does_not_send_mismatched_or_same_password) ... ok
test_account_wide_rate_limit_and_expiry (test_passwords.PasswordTests.test_account_wide_rate_limit_and_expiry) ... ok
test_actual_strict_https_password_change (test_passwords.PasswordTests.test_actual_strict_https_password_change) ... ok
test_admin_add_user_uses_temporary_password (test_passwords.PasswordTests.test_admin_add_user_uses_temporary_password) ... ok
test_admin_reset_requires_change_and_never_prints_password (test_passwords.PasswordTests.test_admin_reset_requires_change_and_never_prints_password) ... ok
test_change_clears_requirement_and_requires_reauthentication (test_passwords.PasswordTests.test_change_clears_requirement_and_requires_reauthentication) ... ok
test_change_endpoint_requires_authenticated_token (test_passwords.PasswordTests.test_change_endpoint_requires_authenticated_token) ... ok
test_change_revokes_all_own_sessions_and_calls_only (test_passwords.PasswordTests.test_change_revokes_all_own_sessions_and_calls_only) ... ok
test_existing_database_additive_migration_preserves_access (test_passwords.PasswordTests.test_existing_database_additive_migration_preserves_access) ... ok
test_invalid_and_reused_new_passwords_rejected (test_passwords.PasswordTests.test_invalid_and_reused_new_passwords_rejected) ... ok
test_temporary_session_cannot_access_workspace (test_passwords.PasswordTests.test_temporary_session_cannot_access_workspace) ... ok
test_wrong_current_password_does_not_change_or_revoke (test_passwords.PasswordTests.test_wrong_current_password_does_not_change_or_revoke) ... ok
test_bad_origin_rejected (test_profile.Profiles.test_bad_origin_rejected) ... ok
test_digest_is_not_present_as_self_authentication (test_profile.Profiles.test_digest_is_not_present_as_self_authentication) ... ok
test_missing_profile_and_invalid_embedded_profile (test_profile.Profiles.test_missing_profile_and_invalid_embedded_profile) ... ok
test_no_overwrite (test_profile.Profiles.test_no_overwrite) ... ok
test_preferences_allowlist_and_no_remember (test_profile.Profiles.test_preferences_allowlist_and_no_remember) ... ok
test_private_dns_and_ipv4 (test_profile.Profiles.test_private_dns_and_ipv4) ... ok
test_profile_roundtrip_and_exact_module_check (test_profile.Profiles.test_profile_roundtrip_and_exact_module_check) ... ok
test_secrets_unknown_fields_and_bad_ca_rejected (test_profile.Profiles.test_secrets_unknown_fields_and_bad_ca_rejected) ... ok
test_username_only_and_profile_scoped (test_profile.Profiles.test_username_only_and_profile_scoped) ... ok
test_preconfigured_login_and_actual_two_way_messages (test_qt_integration.QtIntegration.test_preconfigured_login_and_actual_two_way_messages) ... ok
test_composer_disabled_before_chat (test_qt_ui.WidgetTests.test_composer_disabled_before_chat) ... ok
test_group_voice_disabled (test_qt_ui.WidgetTests.test_group_voice_disabled) ... ok
test_initial_history_not_unread_and_new_counts_exact (test_qt_ui.WidgetTests.test_initial_history_not_unread_and_new_counts_exact) ... ok
test_notification_multiple_rooms_routes_chat_list_not_wrong_chat (test_qt_ui.WidgetTests.test_notification_multiple_rooms_routes_chat_list_not_wrong_chat) ... ok
test_notification_single_room_opens_that_chat (test_qt_ui.WidgetTests.test_notification_single_room_opens_that_chat) ... ok
test_profile_login_has_no_server_or_ca_picker (test_qt_ui.WidgetTests.test_profile_login_has_no_server_or_ca_picker) ... ok
test_visible_reply_after_stale_summary_is_not_alerted_again (test_qt_ui.WidgetTests.test_visible_reply_after_stale_summary_is_not_alerted_again) ... ok

----------------------------------------------------------------------
Ran 63 tests in 14.098s

OK
```
