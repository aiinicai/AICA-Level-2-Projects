# -*- coding: utf-8 -*-
"""
ITR Computation - Single-file Desktop ITR Computation Tool
==========================================================
Target: Python 3.10+

Core design:
- One single .py file.
- Local JSON case storage.
- Privacy-first document workflow: local PDF extraction -> sensitive-data review ->
  optional redaction preview -> explicit API analysis.
- API/AI is used for extraction/classification only; tax calculations are deterministic.
- Income-tax Act, 2025 common Individual/HUF computations for Tax Year 2026-27.
- Excel export for computation, bank tabs and complete working file.
- PDF export for the computation.

Important professional note:
This is a computation/workpaper tool, not an e-filing utility. Tax law has many fact-specific
exceptions. The software deliberately flags edge cases for CA review instead of silently
assuming facts.

Recommended install command (one line):
pip install PySide6 PyMuPDF openpyxl reportlab google-genai openai

Run:
python "ITR Computation.py"
"""

from __future__ import annotations

import sys
import os
import re
import json
import math
import html
import traceback
import uuid
from pathlib import Path
from datetime import datetime, date
from typing import Any, Dict, List, Tuple, Optional

APP_NAME = "ITR Computation"
APP_VERSION = "1.9.0"
TAX_YEAR = "2026-27"

# --------------------------------------------------------------------------------------
# Dependency bootstrap
# --------------------------------------------------------------------------------------
try:
    from PySide6.QtCore import Qt, Signal, QTimer, QSize, QDate, QThread
    from PySide6.QtGui import QAction, QFont, QColor, QIcon, QKeySequence, QTextCharFormat, QTextCursor
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout,
        QLabel, QPushButton, QListWidget, QListWidgetItem, QStackedWidget, QFrame,
        QLineEdit, QComboBox, QTableWidget, QTableWidgetItem, QHeaderView, QFileDialog,
        QMessageBox, QDialog, QDialogButtonBox, QFormLayout, QDateEdit, QCheckBox,
        QTabWidget, QTextBrowser, QTextEdit, QGroupBox, QScrollArea, QSplitter,
        QMenu, QToolButton, QSizePolicy, QAbstractItemView, QSpinBox, QDoubleSpinBox,
        QProgressBar
    )
except Exception:
    print("PySide6 is required. Install dependencies with:\n"
          "pip install PySide6 PyMuPDF openpyxl reportlab google-genai openai")
    raise

# Optional dependencies are loaded lazily where possible.

# --------------------------------------------------------------------------------------
# Theme
# --------------------------------------------------------------------------------------
COLORS = {
    "navy": "#0B1220",
    "navy2": "#111B2E",
    "panel": "#FFFFFF",
    "canvas": "#F3F6FA",
    "border": "#DCE3EC",
    "text": "#172033",
    "muted": "#697586",
    "accent": "#2457E6",
    "accent2": "#17A673",
    "warning": "#F0A202",
    "danger": "#D64545",
    "purple": "#6C4DD9",
    "softblue": "#EAF0FF",
    "softgreen": "#E8F8F1",
    "softyellow": "#FFF7D6",
    "softred": "#FFECEC",
}

QSS = f"""
* {{ font-family: 'Segoe UI'; font-size: 10pt; color: {COLORS['text']}; }}
QMainWindow, QWidget#Root {{ background: {COLORS['canvas']}; }}
QFrame#Sidebar {{ background: {COLORS['navy']}; border: none; }}
QFrame#Topbar {{ background: #FFFFFF; border-bottom: 1px solid {COLORS['border']}; }}
QFrame#Card {{ background: #FFFFFF; border: 1px solid {COLORS['border']}; border-radius: 12px; }}
QLabel#AppTitle {{ color: white; font-size: 18pt; font-weight: 700; }}
QLabel#AppSub {{ color: #94A3B8; font-size: 9pt; }}
QLabel#PageTitle {{ font-size: 20pt; font-weight: 700; color: {COLORS['text']}; }}
QLabel#SectionTitle {{ font-size: 12pt; font-weight: 700; color: {COLORS['text']}; }}
QLabel#Muted {{ color: {COLORS['muted']}; }}
QLabel#KpiValue {{ font-size: 18pt; font-weight: 800; }}
QLabel#KpiLabel {{ color: {COLORS['muted']}; font-size: 9pt; }}
QListWidget#Nav {{ background: transparent; border: none; color: white; outline: none; }}
QListWidget#Nav::item {{ color: #C7D2E3; padding: 12px 14px; margin: 2px 8px; border-radius: 8px; }}
QListWidget#Nav::item:selected {{ background: #1F2D49; color: white; font-weight: 600; }}
QListWidget#Nav::item:hover {{ background: #17253D; color: white; }}
QPushButton {{ background: #FFFFFF; border: 1px solid {COLORS['border']}; border-radius: 8px; padding: 8px 12px; font-weight: 600; }}
QPushButton:hover {{ border-color: #AFC0D8; background: #FAFCFF; }}
QPushButton#Primary {{ background: {COLORS['accent']}; color: white; border: 1px solid {COLORS['accent']}; }}
QPushButton#Primary:hover {{ background: #1D49C4; }}
QPushButton#Success {{ background: {COLORS['accent2']}; color: white; border: 1px solid {COLORS['accent2']}; }}
QPushButton#Danger {{ background: #FFFFFF; color: {COLORS['danger']}; border: 1px solid #F0B7B7; }}
QToolButton {{ background: #FFFFFF; border: 1px solid {COLORS['border']}; border-radius: 8px; padding: 8px 12px; font-weight: 600; }}
QLineEdit, QComboBox, QDateEdit, QSpinBox, QDoubleSpinBox, QTextEdit {{
    background: #FFFFFF; border: 1px solid #CBD5E1; border-radius: 7px; padding: 7px 9px;
}}
QLineEdit:focus, QComboBox:focus, QDateEdit:focus, QTextEdit:focus {{ border: 1px solid {COLORS['accent']}; }}
QTableWidget {{ background: white; alternate-background-color: #F8FAFD; border: 1px solid {COLORS['border']}; border-radius: 8px; gridline-color: #E6EBF2; }}
QTableWidget::item {{ padding: 5px; }}
QTableWidget::item:selected {{ background: #DCE7FF; color: #102044; }}
QHeaderView::section {{ background: #EEF2F7; color: #364152; border: none; border-right: 1px solid #DCE3EC; border-bottom: 1px solid #DCE3EC; padding: 8px; font-weight: 700; }}
QTabWidget::pane {{ border: 1px solid {COLORS['border']}; background: white; border-radius: 8px; }}
QTabBar::tab {{ background: #EEF2F7; padding: 9px 14px; margin-right: 2px; border-top-left-radius: 7px; border-top-right-radius: 7px; }}
QTabBar::tab:selected {{ background: white; color: {COLORS['accent']}; font-weight: 700; }}
QGroupBox {{ border: 1px solid {COLORS['border']}; border-radius: 9px; margin-top: 10px; padding-top: 10px; font-weight: 700; background: white; }}
QGroupBox::title {{ subcontrol-origin: margin; left: 12px; padding: 0 5px; }}
QScrollArea {{ border: none; background: transparent; }}
QTextBrowser {{ background: #FFFFFF; border: 1px solid {COLORS['border']}; border-radius: 8px; padding: 8px; }}
QProgressBar {{ border: 1px solid {COLORS['border']}; border-radius: 5px; background: white; text-align: center; }}
QProgressBar::chunk {{ background: {COLORS['accent']}; border-radius: 4px; }}
"""

# --------------------------------------------------------------------------------------
# Utilities
# --------------------------------------------------------------------------------------
def now_iso() -> str:
    return datetime.now().isoformat(timespec="seconds")


def to_float(v: Any) -> float:
    if v is None:
        return 0.0
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "").replace("₹", "").replace("Rs.", "").replace("Rs", "")
    if s in ("", "-", "—", "None"):
        return 0.0
    neg = s.startswith("(") and s.endswith(")")
    if neg:
        s = s[1:-1]
    try:
        val = float(s)
        return -val if neg else val
    except Exception:
        return 0.0


def money(v: Any) -> str:
    x = to_float(v)
    sign = "-" if x < 0 else ""
    x = abs(x)
    # Indian grouping
    whole, dot, dec = f"{x:.2f}".partition(".")
    if len(whole) > 3:
        last3 = whole[-3:]
        rest = whole[:-3]
        chunks = []
        while len(rest) > 2:
            chunks.insert(0, rest[-2:])
            rest = rest[:-2]
        if rest:
            chunks.insert(0, rest)
        whole = ",".join(chunks + [last3])
    return f"{sign}₹{whole}.{dec}"


def round10(v: float) -> float:
    sign = -1.0 if v < 0 else 1.0
    return sign * float(int(math.floor((abs(v) + 5) / 10.0) * 10))


def clamp(v: float, lo: float = 0.0, hi: Optional[float] = None) -> float:
    v = max(lo, v)
    if hi is not None:
        v = min(hi, v)
    return v


def json_deepcopy(obj: Any) -> Any:
    return json.loads(json.dumps(obj))


def safe_json_from_text(text: str) -> Any:
    text = (text or "").strip()
    if not text:
        return {}

    # 1. Extract markdown code block ```json ... ``` anywhere in text
    m = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text, re.I)
    if m:
        text = m.group(1).strip()
    else:
        text = re.sub(r"^```(?:json)?\s*", "", text, flags=re.I)
        text = re.sub(r"\s*```$", "", text)

    # 2. Try direct json.loads with strict=False (allows raw newlines/tabs inside string literals)
    try:
        return json.loads(text, strict=False)
    except Exception:
        pass

    # 3. Find outermost { ... } or [ ... ]
    first_brace = text.find("{")
    first_bracket = text.find("[")
    
    starts = [p for p in [first_brace, first_bracket] if p >= 0]
    if not starts:
        raise ValueError("API response did not contain JSON.")
    
    start = min(starts)
    is_bracket = (start == first_bracket)
    end_char = "]" if is_bracket else "}"
    end = text.rfind(end_char)
    
    if end > start:
        snippet = text[start:end+1].strip()
        try:
            return json.loads(snippet, strict=False)
        except Exception:
            snippet_clean = re.sub(r"[\x00-\x1f\x7f-\x9f]", " ", snippet)
            try:
                return json.loads(snippet_clean, strict=False)
            except Exception:
                pass

    raise ValueError("Could not parse JSON from API response.")


def table_item(text: Any = "", editable: bool = True, align: Optional[Qt.AlignmentFlag] = None) -> QTableWidgetItem:
    full_text = str(text if text is not None else "")
    item = QTableWidgetItem(full_text)
    # Always expose the complete cell value on mouse hover. This is especially
    # useful where a narrow column displays an elided value such as "...".
    item.setToolTip(full_text)
    if not editable:
        item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
    if align is not None:
        item.setTextAlignment(align)
    return item


def bind_combo_tooltip(combo: QComboBox):
    """Keep a combo box's full selected text visible on hover when the cell is narrow."""
    combo.setToolTip(combo.currentText())
    combo.currentTextChanged.connect(lambda text, cb=combo: cb.setToolTip(text))


def make_table_combo_readable(combo: QComboBox, options=None, height: int = 34, popup_min_width: int = 260):
    """Make table-cell dropdowns easier to read without forcing oversized table rows."""
    combo.setFixedHeight(height)
    combo.setMinimumContentsLength(18)
    try:
        combo.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToMinimumContentsLengthWithIcon)
    except Exception:
        pass
    texts = [str(x) for x in (options or []) if x is not None]
    if combo.count():
        texts.extend(combo.itemText(i) for i in range(combo.count()))
    try:
        fm = combo.fontMetrics()
        longest = max((fm.horizontalAdvance(t) for t in texts), default=0)
        popup_width = min(520, max(popup_min_width, longest + 56))
        combo.view().setMinimumWidth(popup_width)
    except Exception:
        pass
    bind_combo_tooltip(combo)


def large_text_input(parent, title: str, label: str, initial: str = "") -> Tuple[str, bool]:
    """Large, readable editor used instead of Qt's tiny default cell/input editor."""
    dlg = QDialog(parent)
    dlg.setWindowTitle(title)
    dlg.resize(900, 500)
    lay = QVBoxLayout(dlg)
    lab = QLabel(label)
    lab.setWordWrap(True)
    lay.addWidget(lab)
    editor = QTextEdit()
    editor.setAcceptRichText(False)
    editor.setPlainText(str(initial or ""))
    editor.setMinimumHeight(340)
    editor.setStyleSheet("font-size: 12pt; padding: 12px;")
    lay.addWidget(editor, 1)
    bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
    bb.accepted.connect(dlg.accept)
    bb.rejected.connect(dlg.reject)
    lay.addWidget(bb)
    editor.setFocus()
    editor.selectAll()
    ok = dlg.exec() == QDialog.DialogCode.Accepted
    return (editor.toPlainText().strip() if ok else str(initial or ""), ok)


def open_large_table_editor(table: QTableWidget, row: int, col: int):
    """Double-click any editable table cell to get a large editor instead of a tiny oval box."""
    if table.cellWidget(row, col) is not None:
        return
    item = table.item(row, col)
    if item is None or not (item.flags() & Qt.ItemFlag.ItemIsEditable):
        return
    header_item = table.horizontalHeaderItem(col)
    header = header_item.text() if header_item else "Cell"
    value, ok = large_text_input(table, f"Edit {header}", f"{header}:", item.text())
    if ok:
        item.setText(value)


def set_table_defaults(table: QTableWidget, alternating: bool = True):
    table.setAlternatingRowColors(alternating)
    table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
    table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
    # Avoid Qt's tiny inline editor on double-click; our large editor handles double-clicks.
    table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
    table.verticalHeader().setVisible(False)
    table.verticalHeader().setDefaultSectionSize(30)
    table.verticalHeader().setMinimumSectionSize(24)
    table.horizontalHeader().setStretchLastSection(True)
    table.setWordWrap(False)
    table.setMouseTracking(True)
    # Keep hover text synced after a user edits a cell through the large editor.
    table.itemChanged.connect(lambda item: item.setToolTip(item.text()) if item is not None else None)
    # A double-click always opens a large readable editor for ordinary editable cells.
    table.cellDoubleClicked.connect(lambda r, c, t=table: open_large_table_editor(t, r, c))


# --------------------------------------------------------------------------------------
# Tax parameters - Tax Year 2026-27 common Individual/HUF cases
# Official basis used by this application:
# - Section 202, Income-tax Act, 2025: New regime slabs.
# - First Schedule to Finance Act, 2026: Old regime slabs.
# - Section 19: salary standard deduction (75k new / 50k other).
# - Section 22: 30% HP deduction + eligible interest.
# - Section 58: presumptive business/profession/goods-carriage mechanics.
# --------------------------------------------------------------------------------------
TAX_PARAMS = {
    "tax_year": TAX_YEAR,
    "new_slabs": [
        (400000, 0.00), (800000, 0.05), (1200000, 0.10), (1600000, 0.15),
        (2000000, 0.20), (2400000, 0.25), (float("inf"), 0.30),
    ],
    "salary_std_new": 75000.0,
    "salary_std_old": 50000.0,
    "hp_standard_pct": 0.30,
    "cess": 0.04,
    "new_rebate_limit": 1200000.0,
    "new_rebate_max": 60000.0,
    "old_rebate_limit": 500000.0,
    "old_rebate_max": 12500.0,
    "equity_ltcg_exemption": 125000.0,
    "equity_stcg_rate": 0.20,
    "ltcg_rate": 0.125,
    "presumptive_business_digital": 0.06,
    "presumptive_business_other": 0.08,
    "presumptive_profession": 0.50,
    "presumptive_business_limit": 20000000.0,
    "presumptive_business_limit_low_cash": 30000000.0,
    "presumptive_profession_limit": 5000000.0,
    "presumptive_profession_limit_low_cash": 7500000.0,
}


def slab_tax(income: float, slabs: List[Tuple[float, float]]) -> float:
    income = max(0.0, income)
    tax = 0.0
    lower = 0.0
    for upper, rate in slabs:
        if income <= lower:
            break
        taxable = min(income, upper) - lower
        tax += taxable * rate
        lower = upper
        if math.isinf(upper):
            break
    return max(0.0, tax)


def new_regime_tax_on_normal_income(income: float) -> float:
    return slab_tax(income, TAX_PARAMS["new_slabs"])


def old_regime_slabs(status: str, resident: bool, age: int) -> List[Tuple[float, float]]:
    # HUF and non-resident individuals use the normal 2.5L basic threshold.
    if status == "Individual" and resident and age >= 80:
        return [(500000, 0.00), (1000000, 0.20), (float("inf"), 0.30)]
    if status == "Individual" and resident and age >= 60:
        return [(300000, 0.00), (500000, 0.05), (1000000, 0.20), (float("inf"), 0.30)]
    return [(250000, 0.00), (500000, 0.05), (1000000, 0.20), (float("inf"), 0.30)]


def old_regime_tax_on_normal_income(income: float, status: str, resident: bool, age: int) -> float:
    return slab_tax(income, old_regime_slabs(status, resident, age))


def basic_exemption(regime: str, status: str, resident: bool, age: int) -> float:
    if regime == "New":
        return 400000.0
    slabs = old_regime_slabs(status, resident, age)
    return slabs[0][0]


def surcharge_rate(total_income: float, regime: str) -> float:
    if total_income <= 5000000:
        return 0.0
    if total_income <= 10000000:
        return 0.10
    if total_income <= 20000000:
        return 0.15
    if total_income <= 50000000:
        return 0.25
    return 0.25 if regime == "New" else 0.37


def age_on_tax_year_end(dob_str: str, tax_year: str = TAX_YEAR) -> int:
    try:
        dob = datetime.strptime(dob_str, "%Y-%m-%d").date()
        end_year = int(tax_year.split("-")[1]) + 2000
        end = date(end_year, 3, 31)
        return end.year - dob.year - ((end.month, end.day) < (dob.month, dob.day))
    except Exception:
        return 0



def default_head_for_nature(nature: str) -> str:
    if nature in {"Opening Balance", "Closing Balance"}: return "Not Income"
    if nature in {"Salary", "Pension"}: return "Salary"
    if nature == "Rent": return "House Property"
    if nature in {"Business Receipt","Professional Receipt","Presumptive Business Receipt","Presumptive Professional Receipt","Presumptive Goods Carriage Receipt","F&O Broker Withdrawal","Speculative / Intraday Receipt"}: return "PGBP"
    if nature in {"Mutual Fund Redemption","Share / Broker Receipt","Property Sale Receipt","Other Capital Asset Sale Receipt"}: return "Capital Gains"
    if nature in {"Savings Bank Interest","FD Interest","Bond Interest","Other Interest","Dividend","Other Taxable Income"}: return "Other Sources"
    if nature == "Agricultural Receipt": return "Agricultural Income – Exempt"
    if nature in {"PPF Interest","PPF Withdrawal / Maturity","Other Exempt Income"}: return "Other Exempt Income"
    if nature in {"Loan Received","Loan Repayment Received","Reimbursement","Own Account Transfer","Capital Introduction","Security Deposit","Income-tax Refund","GST Refund","Expense Reversal / Refund"}: return "Not Income"
    if nature in {"Gift – Review Taxability","Insurance Receipt – Review Taxability","Pending Review","Other"}: return "Pending Review"
    return "Pending Review"

# --------------------------------------------------------------------------------------
# Data model
# --------------------------------------------------------------------------------------
INCOME_KEYS = [
    ("salary", "Salary"),
    ("house_property", "House Property"),
    ("pgbp_regular", "PGBP – Regular Books"),
    ("pgbp_presumptive_business", "PGBP – Presumptive Business"),
    ("pgbp_presumptive_profession", "PGBP – Presumptive Profession"),
    ("pgbp_goods_carriage", "PGBP – Goods Carriage"),
    ("pgbp_fo", "PGBP – F&O"),
    ("pgbp_speculative", "PGBP – Speculative / Intraday"),
    ("capital_gains", "Capital Gains"),
    ("other_interest", "Other Sources – Interest"),
    ("other_dividend", "Other Sources – Dividend"),
    ("other_other", "Other Sources – Other"),
    ("agriculture", "Agricultural Income"),
    ("exempt", "PPF / Other Exempt Income"),
]

FINAL_NATURES = [
    "", "Opening Balance", "Closing Balance", "Salary", "Pension", "Rent",
    "Business Receipt", "Professional Receipt",
    "Presumptive Business Receipt", "Presumptive Professional Receipt",
    "Presumptive Goods Carriage Receipt", "F&O Broker Withdrawal", "Speculative / Intraday Receipt",
    "Savings Bank Interest", "FD Interest", "Bond Interest", "Other Interest", "Dividend", "Other Taxable Income",
    "Mutual Fund Redemption", "Share / Broker Receipt", "Property Sale Receipt", "Other Capital Asset Sale Receipt",
    "Agricultural Receipt", "PPF Interest", "PPF Withdrawal / Maturity", "Other Exempt Income",
    "Loan Received", "Loan Repayment Received", "Reimbursement", "Own Account Transfer",
    "Capital Introduction", "Security Deposit", "Income-tax Refund", "GST Refund",
    "Gift – Review Taxability", "Insurance Receipt – Review Taxability",
    "Expense Reversal / Refund", "Other", "Pending Review"
]

HEADS = [
    "", "Salary", "House Property", "PGBP", "Capital Gains", "Other Sources",
    "Agricultural Income – Exempt", "Other Exempt Income", "Not Income", "Pending Review"
]

CONSIDER_OPTIONS = ["Review", "Yes", "No"]
STATUS_OPTIONS = ["Not Applicable", "Review", "Incomplete", "Complete", "Difference"]


def default_case() -> Dict[str, Any]:
    applicability = {k: {"applicable": "No", "status": "Not Applicable", "remarks": ""} for k, _ in INCOME_KEYS}
    return {
        "meta": {
            "app_version": APP_VERSION,
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "tax_year": TAX_YEAR,
        },
        "assessee": {
            "name": "",
            "pan": "",
            "status": "Individual",
            "dob": "",
            "residential_status": "Resident",
            "business_income": False,
        },
        "income_applicability": applicability,
        "salary": {"employers": []},
        "house_property": {"properties": []},
        "pgbp": {
            "regular": {"net_profit": 0, "additions": 0, "deductions_new": 0, "deductions_old": 0, "turnover": 0, "remarks": ""},
            "presumptive_business": {"digital_turnover": 0, "other_turnover": 0, "declared_profit": 0, "remarks": ""},
            "presumptive_profession": {"gross_receipts": 0, "cash_receipts": 0, "declared_profit": 0, "remarks": ""},
            "goods_carriage": {"vehicles": []},
            "fo": {"turnover": 0, "pnl": 0, "expenses": 0, "remarks": "", "source_file": ""},
            "speculative": {"turnover": 0, "pnl": 0, "expenses": 0, "remarks": ""},
        },
        "capital_gains": {"transactions": [], "remarks": ""},
        "other_sources": {"items": []},
        "agriculture": {"activities": []},
        "exempt_income": {"items": []},
        "deductions": [],
        "taxes_paid": [],
        "banks": [],
        "documents": [],
        "settings": {
            "api_provider": "Gemini",
            "api_model": "gemini-3.6-flash",
            "api_key": "",
            "remember_api_key": False,
            "privacy_default": "Always review before API",
            "auto_fetch_use_final": True,
        }
    }


class CaseStore:
    @staticmethod
    def save(path: str, data: Dict[str, Any]):
        data["meta"]["updated_at"] = now_iso()
        payload = json_deepcopy(data)
        if not payload.get("settings", {}).get("remember_api_key", False):
            payload.setdefault("settings", {})["api_key"] = ""
        Path(path).write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    @staticmethod
    def load(path: str) -> Dict[str, Any]:
        raw = json.loads(Path(path).read_text(encoding="utf-8"))
        base = default_case()
        # light schema migration
        for k, v in raw.items():
            base[k] = v
        base.setdefault("income_applicability", default_case()["income_applicability"])
        for key, _ in INCOME_KEYS:
            base["income_applicability"].setdefault(key, {"applicable": "No", "status": "Not Applicable", "remarks": ""})
        base.setdefault("settings", {})
        base["settings"].setdefault("auto_fetch_use_final", True)
        return base


# --------------------------------------------------------------------------------------
# Tax engine
# --------------------------------------------------------------------------------------
class TaxEngine:
    @staticmethod
    def bank_confirmed_sums(case: Dict[str, Any], use_final: Optional[bool] = None) -> Dict[str, float]:
        if use_final is None:
            use_final = bool(case.get("settings", {}).get("auto_fetch_use_final", True))
        out = {
            "salary": 0.0, "house_property": 0.0, "pgbp": 0.0, "capital_gains": 0.0,
            "interest": 0.0, "dividend": 0.0, "other_sources": 0.0,
            "agriculture": 0.0, "exempt": 0.0,
        }
        for bank in case.get("banks", []):
            for tx in bank.get("transactions", []):
                credit = to_float(tx.get("credit"))
                if credit <= 0:
                    continue
                consider = str(tx.get("consider", "Review"))
                if consider == "No":
                    continue

                if use_final:
                    head = str(tx.get("head") or "").strip()
                    nature = str(tx.get("final_nature") or "").strip()
                    if not nature or head in ("", "Pending Review", "Not Income", "Opening Balance", "Closing Balance"):
                        continue
                else:
                    head = tx.get("head") if tx.get("head") and tx.get("head") != "Pending Review" else (tx.get("suggested_head") or "")
                    nature = tx.get("final_nature") or tx.get("suggested_nature") or ""
                    if not head or head in ("Not Income", "Opening Balance", "Closing Balance"):
                        continue

                if head == "Salary": out["salary"] += credit
                elif head == "House Property": out["house_property"] += credit
                elif head == "PGBP": out["pgbp"] += credit
                elif head == "Capital Gains": out["capital_gains"] += credit
                elif head == "Other Sources":
                    if "Interest" in nature: out["interest"] += credit
                    elif nature == "Dividend": out["dividend"] += credit
                    else: out["other_sources"] += credit
                elif head == "Agricultural Income – Exempt": out["agriculture"] += credit
                elif head == "Other Exempt Income": out["exempt"] += credit
        return out

    @staticmethod
    def bank_detected_sums(case: Dict[str, Any], use_final: Optional[bool] = None) -> Dict[str, float]:
        """Credits detected/suggested by the imported bank workflow."""
        return TaxEngine.bank_confirmed_sums(case, use_final=use_final)

    @staticmethod
    def bank_detected_by_income_key(case: Dict[str, Any], use_final: Optional[bool] = None) -> Dict[str, float]:
        """Granular bank auto-fetch totals used by the Computation screen."""
        if use_final is None:
            use_final = bool(case.get("settings", {}).get("auto_fetch_use_final", True))
        out = {k: 0.0 for k, _ in INCOME_KEYS}
        for bank in case.get("banks", []):
            for tx in bank.get("transactions", []):
                credit = to_float(tx.get("credit"))
                if credit <= 0:
                    continue
                consider = str(tx.get("consider", "Review"))
                if consider == "No":
                    continue

                if use_final:
                    head = str(tx.get("head") or "").strip()
                    nature = str(tx.get("final_nature") or "").strip()
                    if not nature or head in ("", "Pending Review", "Not Income", "Opening Balance", "Closing Balance"):
                        continue
                else:
                    head = tx.get("head") if tx.get("head") and tx.get("head") != "Pending Review" else (tx.get("suggested_head") or "")
                    nature = tx.get("final_nature") or tx.get("suggested_nature") or ""
                    if not head or head in ("Not Income", "Opening Balance", "Closing Balance"):
                        continue

                if head == "Salary":
                    out["salary"] += credit
                elif head == "House Property":
                    out["house_property"] += credit
                elif head == "PGBP":
                    if nature == "Presumptive Business Receipt": out["pgbp_presumptive_business"] += credit
                    elif nature == "Presumptive Professional Receipt": out["pgbp_presumptive_profession"] += credit
                    elif nature == "Presumptive Goods Carriage Receipt": out["pgbp_goods_carriage"] += credit
                    elif nature == "F&O Broker Withdrawal": out["pgbp_fo"] += credit
                    elif nature == "Speculative / Intraday Receipt": out["pgbp_speculative"] += credit
                    else: out["pgbp_regular"] += credit
                elif head == "Capital Gains":
                    out["capital_gains"] += credit
                elif head == "Other Sources":
                    if nature == "Dividend": out["other_dividend"] += credit
                    elif "Interest" in nature: out["other_interest"] += credit
                    else: out["other_other"] += credit
                elif head == "Agricultural Income – Exempt":
                    out["agriculture"] += credit
                elif head == "Other Exempt Income":
                    out["exempt"] += credit
        return out

    @staticmethod
    def bank_other_source_breakdown(case: Dict[str, Any], confirmed_only: bool = False, use_final: Optional[bool] = None) -> Dict[str, Any]:
        """Bank-wise Other Sources breakup used in the detailed review dialog."""
        if use_final is None:
            use_final = bool(case.get("settings", {}).get("auto_fetch_use_final", True))
        banks = []
        dividend_total = 0.0
        other_total = 0.0
        for idx, bank in enumerate(case.get("banks", [])):
            row = {
                "bank": bank.get("bank_name") or f"Bank {idx + 1}",
                "savings": 0.0, "fd": 0.0, "bond": 0.0, "other_interest": 0.0,
                "dividend": 0.0, "other": 0.0,
            }
            for tx in bank.get("transactions", []):
                consider = str(tx.get("consider", "Review"))
                if consider == "No" or (confirmed_only and consider != "Yes"):
                    continue
                if use_final:
                    head = str(tx.get("head") or "").strip()
                    nature = str(tx.get("final_nature") or "").strip()
                    if not nature or head in ("", "Pending Review", "Not Income", "Opening Balance", "Closing Balance"):
                        continue
                else:
                    head = tx.get("head") if tx.get("head") and tx.get("head") != "Pending Review" else (tx.get("suggested_head") or "")
                    nature = tx.get("final_nature") or tx.get("suggested_nature") or ""

                credit = to_float(tx.get("credit"))
                if credit <= 0 or head != "Other Sources":
                    continue
                if nature == "Savings Bank Interest": row["savings"] += credit
                elif nature == "FD Interest": row["fd"] += credit
                elif nature == "Bond Interest": row["bond"] += credit
                elif "Interest" in nature: row["other_interest"] += credit
                elif nature == "Dividend": row["dividend"] += credit
                else: row["other"] += credit
            row["total_interest"] = row["savings"] + row["fd"] + row["bond"] + row["other_interest"]
            dividend_total += row["dividend"]
            other_total += row["other"]
            if row["total_interest"] or row["dividend"] or row["other"]:
                banks.append(row)
        return {"banks": banks, "dividend": dividend_total, "other": other_total}

    @staticmethod
    def salary(case: Dict[str, Any]) -> Dict[str, float]:
        employers = case.get("salary", {}).get("employers", [])
        manual_gross = sum(to_float(x.get("gross_salary")) for x in employers)
        bank_gross = TaxEngine.bank_confirmed_sums(case)["salary"]
        gross = max(manual_gross, bank_gross)
        exemptions_new = sum(to_float(x.get("exemptions_new")) for x in employers)
        exemptions_old = sum(to_float(x.get("exemptions_old")) for x in employers)
        other_new = sum(to_float(x.get("other_ded_new")) for x in employers)
        other_old = sum(to_float(x.get("other_ded_old")) for x in employers)
        professional_tax = sum(to_float(x.get("professional_tax")) for x in employers)
        std_new = min(max(0.0, gross - exemptions_new), TAX_PARAMS["salary_std_new"])
        std_old = min(max(0.0, gross - exemptions_old), TAX_PARAMS["salary_std_old"])
        # Section 202(2)(a)(iv) disallows section 19(1) Table Sl.No.1 professional tax under new regime.
        new = max(0.0, gross - exemptions_new - std_new - other_new)
        old = max(0.0, gross - exemptions_old - std_old - professional_tax - other_old)
        return {
            "gross": gross, "exemptions_new": exemptions_new, "exemptions_old": exemptions_old,
            "std_new": std_new, "std_old": std_old, "professional_tax": professional_tax,
            "other_new": other_new, "other_old": other_old, "new": new, "old": old,
        }

    @staticmethod
    def house_property(case: Dict[str, Any]) -> Dict[str, Any]:
        rows = []
        total_new = total_old = 0.0
        for p in case.get("house_property", {}).get("properties", []):
            status = p.get("property_status", "Let Out")
            share = clamp(to_float(p.get("share_pct", 100)), 0, 100) / 100.0
            actual_rent = to_float(p.get("actual_rent"))
            expected_rent = to_float(p.get("expected_rent"))
            vacancy_adj = to_float(p.get("vacancy_adjustment"))
            unrealised = to_float(p.get("unrealised_rent"))
            municipal = to_float(p.get("municipal_taxes"))
            interest = to_float(p.get("interest"))
            precon = to_float(p.get("preconstruction_interest"))
            arrears = to_float(p.get("arrears_recovered"))

            if status == "Self Occupied":
                gav = 0.0
                municipal_allowed = 0.0
                nav = 0.0
                std = 0.0
                # Common old-regime cap; fact-specific ₹30k cases should be reviewed by CA.
                interest_old = min(max(0.0, interest + precon), 200000.0)
                interest_new = 0.0  # Section 202(2)(a)(v) restriction for section 21(6) property.
            else:
                gav = max(actual_rent - vacancy_adj - unrealised, expected_rent if expected_rent > 0 else 0.0)
                municipal_allowed = min(max(0.0, municipal), max(0.0, gav))
                nav = max(0.0, gav - municipal_allowed)
                std = nav * TAX_PARAMS["hp_standard_pct"]
                interest_old = max(0.0, interest + precon)
                interest_new = max(0.0, interest + precon)

            arrears_taxable = max(0.0, arrears) * 0.70
            hp_old = (nav - std - interest_old + arrears_taxable) * share
            hp_new = (nav - std - interest_new + arrears_taxable) * share
            total_old += hp_old
            total_new += hp_new
            rows.append({
                "address": p.get("address", ""), "status": status, "share": share,
                "gav": gav, "municipal": municipal_allowed, "nav": nav, "std": std,
                "interest_old": interest_old, "interest_new": interest_new,
                "arrears_taxable": arrears_taxable, "old": hp_old, "new": hp_new,
                "bank_rent": to_float(p.get("bank_rent")),
            })
        return {"rows": rows, "new": total_new, "old": total_old}

    @staticmethod
    def pgbp(case: Dict[str, Any]) -> Dict[str, float]:
        p = case.get("pgbp", {})
        reg = p.get("regular", {})
        reg_new = to_float(reg.get("net_profit")) + to_float(reg.get("additions")) - to_float(reg.get("deductions_new"))
        reg_old = to_float(reg.get("net_profit")) + to_float(reg.get("additions")) - to_float(reg.get("deductions_old"))

        pb = p.get("presumptive_business", {})
        digital = to_float(pb.get("digital_turnover"))
        other = to_float(pb.get("other_turnover"))
        deemed_pb = digital * TAX_PARAMS["presumptive_business_digital"] + other * TAX_PARAMS["presumptive_business_other"]
        declared_pb = to_float(pb.get("declared_profit"))
        pb_income = max(deemed_pb, declared_pb)

        pp = p.get("presumptive_profession", {})
        gross = to_float(pp.get("gross_receipts"))
        deemed_pp = gross * TAX_PARAMS["presumptive_profession"]
        pp_income = max(deemed_pp, to_float(pp.get("declared_profit")))

        gc_income = 0.0
        for v in p.get("goods_carriage", {}).get("vehicles", []):
            months = max(0, int(to_float(v.get("months"))))
            declared = to_float(v.get("declared_profit"))
            if str(v.get("vehicle_type", "Other")) == "Heavy":
                deemed = 1000.0 * to_float(v.get("weight_tons")) * months
            else:
                deemed = 7500.0 * months
            gc_income += max(deemed, declared)

        fo = p.get("fo", {})
        fo_income = to_float(fo.get("pnl")) - to_float(fo.get("expenses"))
        sp = p.get("speculative", {})
        speculative = to_float(sp.get("pnl")) - to_float(sp.get("expenses"))
        return {
            "regular_new": reg_new, "regular_old": reg_old,
            "presumptive_business": pb_income, "presumptive_profession": pp_income,
            "goods_carriage": gc_income, "fo": fo_income, "speculative": speculative,
            "new": reg_new + pb_income + pp_income + gc_income + fo_income + speculative,
            "old": reg_old + pb_income + pp_income + gc_income + fo_income + speculative,
        }

    @staticmethod
    def capital_gains(case: Dict[str, Any]) -> Dict[str, float]:
        out = {
            "normal_stcg": 0.0, "special_stcg_20": 0.0,
            "equity_ltcg": 0.0, "other_ltcg_12_5": 0.0,
        }
        for tx in case.get("capital_gains", {}).get("transactions", []):
            gain = to_float(tx.get("sale_value")) - to_float(tx.get("cost")) - to_float(tx.get("expenses"))
            category = tx.get("tax_category", "Normal-rate STCG")
            if category == "STCG – Special 20%": out["special_stcg_20"] += gain
            elif category == "LTCG – Equity 12.5% above ₹1.25L": out["equity_ltcg"] += gain
            elif category == "LTCG – Other 12.5%": out["other_ltcg_12_5"] += gain
            else: out["normal_stcg"] += gain
        out["equity_ltcg_taxable"] = max(0.0, out["equity_ltcg"] - TAX_PARAMS["equity_ltcg_exemption"])
        out["special_taxable"] = max(0.0, out["special_stcg_20"]) + max(0.0, out["equity_ltcg_taxable"]) + max(0.0, out["other_ltcg_12_5"])
        out["total_gain"] = sum(out[k] for k in ["normal_stcg", "special_stcg_20", "equity_ltcg", "other_ltcg_12_5"])
        return out

    @staticmethod
    def other_sources(case: Dict[str, Any]) -> Dict[str, float]:
        bank = TaxEngine.bank_confirmed_sums(case)
        manual = case.get("other_sources", {}).get("items", [])
        result = {"interest": 0.0, "dividend": 0.0, "other": 0.0}
        for x in manual:
            kind = x.get("kind", "Other")
            amt = to_float(x.get("amount"))
            if "Interest" in kind: result["interest"] += amt
            elif kind == "Dividend": result["dividend"] += amt
            else: result["other"] += amt
        # For direct bank-income categories, use the higher of confirmed bank receipts and
        # reviewed detailed amount. If a bank item is not income, mark Consider = No in Bank Statements.
        result["interest"] = max(result["interest"], bank["interest"])
        result["dividend"] = max(result["dividend"], bank["dividend"])
        result["other"] = max(result["other"], bank["other_sources"])
        result["total"] = result["interest"] + result["dividend"] + result["other"]
        return result

    @staticmethod
    def agriculture(case: Dict[str, Any]) -> Dict[str, float]:
        gross = expenses = 0.0
        for x in case.get("agriculture", {}).get("activities", []):
            share = clamp(to_float(x.get("ownership_pct", 100)), 0, 100) / 100.0
            gross += to_float(x.get("gross_receipts")) * share
            expenses += to_float(x.get("expenses")) * share
        gross = max(gross, TaxEngine.bank_confirmed_sums(case)["agriculture"])
        return {"gross": gross, "expenses": expenses, "net": max(0.0, gross - expenses)}

    @staticmethod
    def exempt(case: Dict[str, Any]) -> Dict[str, float]:
        bank = TaxEngine.bank_confirmed_sums(case)
        manual = sum(to_float(x.get("amount")) for x in case.get("exempt_income", {}).get("items", []))
        return {"other_exempt": max(manual, bank["exempt"])}

    @staticmethod
    def deductions(case: Dict[str, Any]) -> Dict[str, float]:
        new = old = 0.0
        for d in case.get("deductions", []):
            amt = max(0.0, to_float(d.get("amount")))
            if d.get("allow_new", False): new += amt
            if d.get("allow_old", True): old += amt
        return {"new": new, "old": old}

    @staticmethod
    def taxes_paid(case: Dict[str, Any]) -> Dict[str, float]:
        out = {"TDS": 0.0, "TCS": 0.0, "Advance Tax": 0.0, "Self-Assessment Tax": 0.0}
        for x in case.get("taxes_paid", []):
            typ = x.get("type", "TDS")
            out.setdefault(typ, 0.0)
            out[typ] += max(0.0, to_float(x.get("amount")))
        out["total"] = sum(v for k, v in out.items() if k != "total")
        return out

    @staticmethod
    def agricultural_rate_tax(regime: str, normal_non_agri_income: float, agri_income: float,
                              status: str, resident: bool, age: int) -> float:
        # Partial integration if agricultural income > 5,000 and non-agri normal income exceeds basic exemption.
        if agri_income <= 5000:
            return 0.0
        be = basic_exemption(regime, status, resident, age)
        if normal_non_agri_income <= be:
            return 0.0
        if regime == "New":
            a = new_regime_tax_on_normal_income(normal_non_agri_income + agri_income)
            b = new_regime_tax_on_normal_income(be + agri_income)
        else:
            a = old_regime_tax_on_normal_income(normal_non_agri_income + agri_income, status, resident, age)
            b = old_regime_tax_on_normal_income(be + agri_income, status, resident, age)
        return max(0.0, a - b)

    @staticmethod
    def compute_regime(case: Dict[str, Any], regime: str) -> Dict[str, float]:
        salary = TaxEngine.salary(case)
        hp = TaxEngine.house_property(case)
        pgbp = TaxEngine.pgbp(case)
        cg = TaxEngine.capital_gains(case)
        other = TaxEngine.other_sources(case)
        agri = TaxEngine.agriculture(case)
        ded = TaxEngine.deductions(case)
        taxes = TaxEngine.taxes_paid(case)
        assessee = case.get("assessee", {})
        status = assessee.get("status", "Individual")
        resident = assessee.get("residential_status", "Resident") == "Resident"
        age = age_on_tax_year_end(assessee.get("dob", ""))

        salary_i = salary["new"] if regime == "New" else salary["old"]
        hp_i = hp["new"] if regime == "New" else hp["old"]
        pgbp_i = pgbp["new"] if regime == "New" else pgbp["old"]

        # Normal-rate income excludes special-rate capital gains.
        normal_cg = cg["normal_stcg"]
        normal_before_hp_restriction = salary_i + hp_i + pgbp_i + normal_cg + other["total"]
        # Under section 202(2)(b)(ii), HP loss cannot be set off against another head in new regime.
        if regime == "New" and hp_i < 0:
            normal_income_pre_ded = salary_i + pgbp_i + normal_cg + other["total"]
            hp_for_total = 0.0
        else:
            normal_income_pre_ded = normal_before_hp_restriction
            hp_for_total = hp_i

        deduction = ded["new"] if regime == "New" else ded["old"]
        normal_income = max(0.0, normal_income_pre_ded - deduction)

        if regime == "New":
            normal_tax = TaxEngine.agricultural_rate_tax("New", normal_income, agri["net"], status, resident, age)
            if normal_tax == 0 and not (agri["net"] > 5000 and normal_income > 400000):
                normal_tax = new_regime_tax_on_normal_income(normal_income)
        else:
            normal_tax = TaxEngine.agricultural_rate_tax("Old", normal_income, agri["net"], status, resident, age)
            if normal_tax == 0 and not (agri["net"] > 5000 and normal_income > basic_exemption("Old", status, resident, age)):
                normal_tax = old_regime_tax_on_normal_income(normal_income, status, resident, age)

        special_stcg_tax = max(0.0, cg["special_stcg_20"]) * TAX_PARAMS["equity_stcg_rate"]
        equity_ltcg_tax = max(0.0, cg["equity_ltcg_taxable"]) * TAX_PARAMS["ltcg_rate"]
        other_ltcg_tax = max(0.0, cg["other_ltcg_12_5"]) * TAX_PARAMS["ltcg_rate"]
        special_tax = special_stcg_tax + equity_ltcg_tax + other_ltcg_tax

        # Rebate is intentionally applied against normal-rate tax only; special-rate income is kept separate for review.
        rebate = 0.0
        total_income_before_round = normal_income + max(0.0, cg["special_stcg_20"]) + max(0.0, cg["equity_ltcg_taxable"]) + max(0.0, cg["other_ltcg_12_5"])
        if status == "Individual" and resident:
            if regime == "New":
                if total_income_before_round <= TAX_PARAMS["new_rebate_limit"]:
                    rebate = min(normal_tax, TAX_PARAMS["new_rebate_max"])
                elif total_income_before_round > TAX_PARAMS["new_rebate_limit"]:
                    excess = total_income_before_round - TAX_PARAMS["new_rebate_limit"]
                    if normal_tax > excess:
                        rebate = max(0.0, normal_tax - excess)
            else:
                if total_income_before_round <= TAX_PARAMS["old_rebate_limit"]:
                    rebate = min(normal_tax, TAX_PARAMS["old_rebate_max"])

        tax_after_rebate = max(0.0, normal_tax - rebate) + special_tax
        sr = surcharge_rate(total_income_before_round, regime)
        surcharge_normal = max(0.0, normal_tax - rebate) * sr
        surcharge_special = special_tax * min(sr, 0.15)
        surcharge = surcharge_normal + surcharge_special
        cess = (tax_after_rebate + surcharge) * TAX_PARAMS["cess"]
        liability = round10(tax_after_rebate + surcharge + cess)
        payable = round10(liability - taxes["total"])
        return {
            "salary": salary_i, "house_property": hp_for_total, "house_property_actual": hp_i,
            "pgbp": pgbp_i, "normal_cg": normal_cg, "other_sources": other["total"],
            "gross_total_income": salary_i + hp_for_total + pgbp_i + normal_cg + other["total"] + max(0.0, cg["special_stcg_20"]) + max(0.0, cg["equity_ltcg_taxable"]) + max(0.0, cg["other_ltcg_12_5"]),
            "deductions": deduction, "normal_income": normal_income,
            "special_stcg": cg["special_stcg_20"], "equity_ltcg_taxable": cg["equity_ltcg_taxable"],
            "other_ltcg": cg["other_ltcg_12_5"], "total_income": total_income_before_round,
            "normal_tax": normal_tax, "special_tax": special_tax, "rebate": rebate,
            "surcharge": surcharge, "cess": cess, "tax_liability": liability,
            "taxes_paid": taxes["total"], "payable": payable, "agriculture": agri["net"],
        }

    @staticmethod
    def _auto_pair_text(new_value: float, old_value: float) -> str:
        """Compact dual-regime display for the single Auto-Fetched column."""
        n = to_float(new_value)
        o = to_float(old_value)
        if abs(n - o) < 0.005:
            return money(n) if abs(n) >= 0.005 else "—"
        return f"N: {money(n)} | O: {money(o)}"

    @staticmethod
    def auto_fetched_computation(case: Dict[str, Any], use_final: Optional[bool] = None) -> Dict[str, Any]:
        """Build a full dual-regime computation from the bank Auto-Fetched base.

        Direct bank-derived income heads (Salary gross, HP gross rent, Interest,
        Dividend and Other Sources) use the selected bank-classification source.
        Statutory deductions are then applied deterministically. PGBP and Capital
        Gains continue to use their detailed schedules because bank receipts are
        controls, not taxable profit/gain. Deductions and taxes-paid use the normal
        detailed schedules.
        """
        if use_final is None:
            use_final = bool(case.get("settings", {}).get("auto_fetch_use_final", True))
        auto = TaxEngine.bank_detected_by_income_key(case, use_final=use_final)

        # Salary: bank-derived gross + the detailed statutory adjustments already entered.
        employers = case.get("salary", {}).get("employers", [])
        sal_gross = max(0.0, to_float(auto.get("salary")))
        sal_ex_new = sum(to_float(x.get("exemptions_new")) for x in employers)
        sal_ex_old = sum(to_float(x.get("exemptions_old")) for x in employers)
        sal_other_new = sum(to_float(x.get("other_ded_new")) for x in employers)
        sal_other_old = sum(to_float(x.get("other_ded_old")) for x in employers)
        sal_prof_tax = sum(to_float(x.get("professional_tax")) for x in employers)
        sal_std_new = min(max(0.0, sal_gross - sal_ex_new), TAX_PARAMS["salary_std_new"])
        sal_std_old = min(max(0.0, sal_gross - sal_ex_old), TAX_PARAMS["salary_std_old"])
        sal_new = max(0.0, sal_gross - sal_ex_new - sal_std_new - sal_other_new)
        sal_old = max(0.0, sal_gross - sal_ex_old - sal_std_old - sal_prof_tax - sal_other_old)
        salary = {
            "gross": sal_gross, "exemptions_new": sal_ex_new, "exemptions_old": sal_ex_old,
            "std_new": sal_std_new, "std_old": sal_std_old, "professional_tax": sal_prof_tax,
            "other_new": sal_other_new, "other_old": sal_other_old, "new": sal_new, "old": sal_old,
        }

        # House Property: bank-derived gross rent/GAV, while municipal taxes, interest and
        # arrears come from Add Details. This is a review computation, not a substitute for
        # property-wise annual-value determination.
        auto_gav = max(0.0, to_float(auto.get("house_property")))
        hp_detail = TaxEngine.house_property(case)
        raw_municipal = 0.0
        for prop in case.get("house_property", {}).get("properties", []):
            share = clamp(to_float(prop.get("share_pct", 100)), 0, 100) / 100.0
            raw_municipal += max(0.0, to_float(prop.get("municipal_taxes"))) * share
        hp_municipal = min(auto_gav, raw_municipal)
        hp_nav = max(0.0, auto_gav - hp_municipal)
        hp_std = hp_nav * TAX_PARAMS["hp_standard_pct"]
        hp_interest_new = sum(x["interest_new"] * x["share"] for x in hp_detail["rows"])
        hp_interest_old = sum(x["interest_old"] * x["share"] for x in hp_detail["rows"])
        hp_arrears = sum(x["arrears_taxable"] * x["share"] for x in hp_detail["rows"])
        hp_new = hp_nav - hp_std - hp_interest_new + hp_arrears
        hp_old = hp_nav - hp_std - hp_interest_old + hp_arrears
        hp = {
            "gav": auto_gav, "municipal": hp_municipal, "nav": hp_nav, "std": hp_std,
            "interest_new": hp_interest_new, "interest_old": hp_interest_old,
            "arrears": hp_arrears, "new": hp_new, "old": hp_old,
        }

        # PGBP/CG must come from detailed tax schedules, never from gross bank receipts.
        pgbp = TaxEngine.pgbp(case)
        cg = TaxEngine.capital_gains(case)

        # Direct Other Sources use the selected Auto-Fetched bank classification.
        other = {
            "interest": max(0.0, to_float(auto.get("other_interest"))),
            "dividend": max(0.0, to_float(auto.get("other_dividend"))),
            "other": max(0.0, to_float(auto.get("other_other"))),
        }
        other["total"] = other["interest"] + other["dividend"] + other["other"]

        # Auto agricultural net uses bank-derived gross less detailed agricultural expenses.
        agri_expenses = 0.0
        for activity in case.get("agriculture", {}).get("activities", []):
            share = clamp(to_float(activity.get("ownership_pct", 100)), 0, 100) / 100.0
            agri_expenses += max(0.0, to_float(activity.get("expenses"))) * share
        agri_gross = max(0.0, to_float(auto.get("agriculture")))
        agri = {"gross": agri_gross, "expenses": agri_expenses, "net": max(0.0, agri_gross - agri_expenses)}
        exempt = max(0.0, to_float(auto.get("exempt")))

        ded = TaxEngine.deductions(case)
        taxes = TaxEngine.taxes_paid(case)
        assessee = case.get("assessee", {})
        status = assessee.get("status", "Individual")
        resident = assessee.get("residential_status", "Resident") == "Resident"
        age = age_on_tax_year_end(assessee.get("dob", ""))

        def regime_result(regime: str) -> Dict[str, float]:
            salary_i = salary["new"] if regime == "New" else salary["old"]
            hp_i = hp["new"] if regime == "New" else hp["old"]
            pgbp_i = pgbp["new"] if regime == "New" else pgbp["old"]
            normal_cg = cg["normal_stcg"]
            if regime == "New" and hp_i < 0:
                normal_income_pre_ded = salary_i + pgbp_i + normal_cg + other["total"]
                hp_for_total = 0.0
            else:
                normal_income_pre_ded = salary_i + hp_i + pgbp_i + normal_cg + other["total"]
                hp_for_total = hp_i
            deduction = ded["new"] if regime == "New" else ded["old"]
            normal_income = max(0.0, normal_income_pre_ded - deduction)

            if regime == "New":
                normal_tax = TaxEngine.agricultural_rate_tax("New", normal_income, agri["net"], status, resident, age)
                if normal_tax == 0 and not (agri["net"] > 5000 and normal_income > 400000):
                    normal_tax = new_regime_tax_on_normal_income(normal_income)
            else:
                normal_tax = TaxEngine.agricultural_rate_tax("Old", normal_income, agri["net"], status, resident, age)
                if normal_tax == 0 and not (agri["net"] > 5000 and normal_income > basic_exemption("Old", status, resident, age)):
                    normal_tax = old_regime_tax_on_normal_income(normal_income, status, resident, age)

            special_stcg_tax = max(0.0, cg["special_stcg_20"]) * TAX_PARAMS["equity_stcg_rate"]
            equity_ltcg_tax = max(0.0, cg["equity_ltcg_taxable"]) * TAX_PARAMS["ltcg_rate"]
            other_ltcg_tax = max(0.0, cg["other_ltcg_12_5"]) * TAX_PARAMS["ltcg_rate"]
            special_tax = special_stcg_tax + equity_ltcg_tax + other_ltcg_tax
            total_income = normal_income + max(0.0, cg["special_stcg_20"]) + max(0.0, cg["equity_ltcg_taxable"]) + max(0.0, cg["other_ltcg_12_5"])

            rebate = 0.0
            if status == "Individual" and resident:
                if regime == "New":
                    if total_income <= TAX_PARAMS["new_rebate_limit"]:
                        rebate = min(normal_tax, TAX_PARAMS["new_rebate_max"])
                    else:
                        excess = total_income - TAX_PARAMS["new_rebate_limit"]
                        if normal_tax > excess:
                            rebate = max(0.0, normal_tax - excess)
                elif total_income <= TAX_PARAMS["old_rebate_limit"]:
                    rebate = min(normal_tax, TAX_PARAMS["old_rebate_max"])

            tax_after_rebate = max(0.0, normal_tax - rebate) + special_tax
            sr = surcharge_rate(total_income, regime)
            surcharge = max(0.0, normal_tax - rebate) * sr + special_tax * min(sr, 0.15)
            cess = (tax_after_rebate + surcharge) * TAX_PARAMS["cess"]
            liability = round10(tax_after_rebate + surcharge + cess)
            payable = round10(liability - taxes["total"])
            return {
                "salary": salary_i, "house_property": hp_for_total, "house_property_actual": hp_i,
                "pgbp": pgbp_i, "normal_cg": normal_cg, "other_sources": other["total"],
                "gross_total_income": salary_i + hp_for_total + pgbp_i + normal_cg + other["total"] + max(0.0, cg["special_stcg_20"]) + max(0.0, cg["equity_ltcg_taxable"]) + max(0.0, cg["other_ltcg_12_5"]),
                "deductions": deduction, "normal_income": normal_income, "total_income": total_income,
                "normal_tax": normal_tax, "special_tax": special_tax, "rebate": rebate,
                "surcharge": surcharge, "cess": cess, "tax_liability": liability,
                "taxes_paid": taxes["total"], "payable": payable,
            }

        return {
            "source": auto, "salary": salary, "hp": hp, "pgbp": pgbp, "cg": cg,
            "other": other, "agri": agri, "exempt": exempt,
            "new": regime_result("New"), "old": regime_result("Old"),
        }

    @staticmethod
    def compute(case: Dict[str, Any]) -> Dict[str, Any]:
        return {
            "new": TaxEngine.compute_regime(case, "New"),
            "old": TaxEngine.compute_regime(case, "Old"),
            "salary": TaxEngine.salary(case),
            "hp": TaxEngine.house_property(case),
            "pgbp": TaxEngine.pgbp(case),
            "cg": TaxEngine.capital_gains(case),
            "other": TaxEngine.other_sources(case),
            "agri": TaxEngine.agriculture(case),
            "exempt": TaxEngine.exempt(case),
            "taxes": TaxEngine.taxes_paid(case),
            "bank": TaxEngine.bank_confirmed_sums(case),
            "bank_detected": TaxEngine.bank_detected_sums(case),
        }

# --------------------------------------------------------------------------------------
# Local PDF extraction and privacy detection
# --------------------------------------------------------------------------------------
class PDFPrivacyEngine:
    PATTERNS = {
        "PAN": re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b", re.I),
        "Aadhaar": re.compile(r"(?<!\d)(?:\d{4}[ -]?){2}\d{4}(?!\d)"),
        "Mobile": re.compile(r"(?<!\d)(?:\+?91[-\s]?)?[6-9]\d{9}(?!\d)"),
        "Email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I),
        "IFSC": re.compile(r"\b[A-Z]{4}0[A-Z0-9]{6}\b", re.I),
        "GSTIN": re.compile(r"\b\d{2}[A-Z]{5}\d{4}[A-Z][A-Z0-9]Z[A-Z0-9]\b", re.I),
        "TAN": re.compile(r"\b[A-Z]{4}\d{5}[A-Z]\b", re.I),
        "UPI ID": re.compile(r"\b[A-Z0-9._-]{2,}@[A-Z]{2,}\b", re.I),
        # Account number detection is intentionally conservative to reduce highlighting ordinary amounts/dates.
        "Account Number": re.compile(r"(?i)(?:a/c|account(?:\s+no\.?|\s+number)?|acct)\s*[:\-]?\s*([0-9X*]{6,20})"),
        "Customer ID/CIF": re.compile(r"(?i)(?:customer\s*id|cust\s*id|cif)\s*[:\-]?\s*([A-Z0-9-]{5,25})"),
        # Conservative address-line detector: only text explicitly labelled as an address.
        "Address": re.compile(r"(?im)^(?:communication\s+address|residential\s+address|mailing\s+address|address)\s*[:\-]\s*(.{6,160})$"),
    }

    @staticmethod
    def extract_pdf_text(path: str) -> Dict[str, Any]:
        try:
            import pymupdf as fitz
        except ImportError:
            try:
                import fitz
            except Exception as e:
                raise RuntimeError("PyMuPDF is required for PDF extraction. Install with: pip install PyMuPDF") from e
        doc = fitz.open(path)
        pages = []
        for i, page in enumerate(doc):
            text = page.get_text("text") or ""
            pages.append({"page": i + 1, "text": text})
        doc.close()
        full = "\n\n".join(f"--- PAGE {p['page']} ---\n{p['text']}" for p in pages)
        return {"pages": pages, "text": full, "page_count": len(pages)}

    @classmethod
    def detect(cls, text: str) -> List[Dict[str, Any]]:
        detections = []
        for typ, pat in cls.PATTERNS.items():
            for m in pat.finditer(text):
                # For patterns with a capture group, redact only the captured sensitive token.
                if m.lastindex:
                    start, end = m.span(m.lastindex)
                    val = m.group(m.lastindex)
                else:
                    start, end = m.span()
                    val = m.group(0)
                detections.append({"type": typ, "start": start, "end": end, "value": val})
        detections.sort(key=lambda x: (x["start"], x["end"]))
        # remove exact overlaps, favor longer detection
        cleaned = []
        for d in detections:
            if cleaned and d["start"] < cleaned[-1]["end"]:
                if (d["end"] - d["start"]) > (cleaned[-1]["end"] - cleaned[-1]["start"]):
                    cleaned[-1] = d
                continue
            cleaned.append(d)
        return cleaned

    @staticmethod
    def highlighted_html(text: str, detections: List[Dict[str, Any]]) -> str:
        parts = []
        pos = 0
        for d in detections:
            parts.append(html.escape(text[pos:d["start"]]))
            token = html.escape(text[d["start"]:d["end"]])
            parts.append(f"<span style='background:#FFE88A;color:#111827;font-weight:600'>{token}</span>")
            pos = d["end"]
        parts.append(html.escape(text[pos:]))
        return "<pre style='white-space:pre-wrap;font-family:Consolas,monospace;font-size:10pt'>" + "".join(parts) + "</pre>"

    @staticmethod
    def redact(text: str, detections: List[Dict[str, Any]], redact_types: set[str]) -> str:
        out = []
        pos = 0
        for d in detections:
            out.append(text[pos:d["start"]])
            if d["type"] in redact_types:
                out.append(f"[REDACTED {d['type'].upper()}]")
            else:
                out.append(text[d["start"]:d["end"]])
            pos = d["end"]
        out.append(text[pos:])
        return "".join(out)

    @classmethod
    def analyse_bank_statement(cls, text: str) -> Dict[str, Any]:
        """Extensive non-API bank statement analyzer.
        Automatically extracts bank metadata, statement period, dates, narrations, debits, credits,
        running balances, rule-based suggested income heads, and generates starting OPENING BALANCE
        and ending CLOSING BALANCE entries.
        """
        bank_name_m = re.search(r'(?i)\b(?:HDFC|ICICI|SBI|STATE BANK|AXIS|KOTAK|PUNJAB NATIONAL|PNB|CANARA|BOB|BANK OF BARODA|UNION BANK|YES BANK|IDFC|INDUSIND|FEDERAL BANK|STANDARD CHARTERED|HSBC|INDIAN BANK|BANK OF INDIA|CENTRAL BANK|[A-Z0-9\s]+BANK)\b', text[:2000])
        bank_name = bank_name_m.group(0).strip() if bank_name_m else ''

        period_m = re.search(r'(?i)(?:statement period|period|for the period)\s*[:\-]?\s*(?:from\s+)?([0-9a-z/-]+)\s+(?:to|till|-)\s+([0-9a-z/-]+)', text)
        stmt_from = period_m.group(1) if period_m else ''
        stmt_to = period_m.group(2) if period_m else ''

        acc_m = re.search(r'(?i)(?:account\s*number|a/c\s*no\.?|acct|account)\s*[:\-]?\s*([0-9xX*]{6,20})', text)
        account_masked = acc_m.group(1) if acc_m else ''

        date_pat = re.compile(
            r'(?i)\b('
            r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|'
            r'\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}|'
            r'\d{1,2}[/-][A-Za-z]{3,9}[/-]\d{2,4}|'
            r'[A-Za-z]{3,9}\s+\d{1,2},\s*\d{2,4}|'
            r'\d{4}[/-]\d{1,2}[/-]\d{1,2}'
            r')\b'
        )
        amount_pat = re.compile(r'(?<!\w)(-?\d{1,3}(?:,\d{2,3})*(?:\.\d{2})|-?\d+(?:\.\d{2}))(?!\w)')

        header_keywords = [
            'STATEMENT PERIOD', 'ACCOUNT STATEMENT', 'SAMPLE / FICTIONAL', 'FOR SOFTWARE TESTING ONLY',
            'ACCOUNT NUMBER', 'CUSTOMER ID', 'DATE       NARRATION', 'VALUE DATE', 'TXN DATE',
            'STATEMENT FROM', 'COMMUNICATION ADDRESS', 'RESIDENTIAL ADDRESS', 'PAGE ',
            'S.NO.', 'CHEQUE NO', 'WITHDRAWAL', 'DEPOSIT', 'BALANCE(INR)', 'DESCRIPTION', 'REMARKS'
        ]

        # Search for explicit Opening / Closing Balance in text header/summary
        explicit_op_bal = None
        explicit_op_date = None
        op_m = re.search(r'(?i)(?:opening\s+bal(?:ance)?|bal(?:ance)?\s+b/f|bal(?:ance)?\s+brought\s+forward)\s*[:\-]?\s*([0-9\.,]+)', text)
        if op_m:
            explicit_op_bal = to_float(op_m.group(1))

        explicit_cl_bal = None
        explicit_cl_date = None
        cl_m = re.search(r'(?i)(?:closing\s+bal(?:ance)?|bal(?:ance)?\s+c/f|bal(?:ance)?\s+carried\s+forward)\s*[:\-]?\s*([0-9\.,]+)', text)
        if cl_m:
            explicit_cl_bal = to_float(cl_m.group(1))

        summary_markers = [
            'TRANSACTION TOTAL', 'TOTAL DEBIT', 'TOTAL CREDIT', 'GRAND TOTAL', 'TOTALS',
            'OPENING BAL', 'CLOSING BAL', 'BAL B/F', 'BAL C/F', 'BALANCE BROUGHT FORWARD', 'BALANCE CARRIED FORWARD'
        ]

        lines = text.splitlines()
        blocks = []
        current_block = None

        for raw in lines:
            line = raw.strip()
            if not line or line.startswith('--- PAGE'):
                continue
            line_upper = line.upper()
            if any(hk in line_upper for hk in ['STATEMENT PERIOD', 'ACCOUNT STATEMENT', 'ACCOUNT NUMBER', 'CUSTOMER ID', 'STATEMENT FROM']):
                continue

            is_summary = any(sm in line_upper for sm in summary_markers)
            m_date = date_pat.search(line)

            if m_date and m_date.start() < 25:
                dt = m_date.group(1)
                rest = line[m_date.end():].strip()
                if current_block:
                    blocks.append(current_block)
                current_block = {'date': dt, 'lines': [rest] if rest else []}
            elif is_summary:
                if current_block:
                    blocks.append(current_block)
                    current_block = None
                blocks.append({'date': '', 'lines': [line]})
            elif current_block:
                if len(line) < 250:
                    current_block['lines'].append(line)

        if current_block:
            blocks.append(current_block)

        parsed_txs = []
        prev_bal = explicit_op_bal

        for b in blocks:
            dt = b['date']
            block_text = ' '.join(b['lines']).strip()
            b_upper = block_text.upper()

            if any(k in b_upper for k in ['OPENING BAL', 'BAL B/F', 'BALANCE BROUGHT FORWARD']):
                nums = amount_pat.findall(block_text)
                if nums:
                    explicit_op_bal = to_float(nums[-1])
                    explicit_op_date = dt
                    prev_bal = explicit_op_bal
                continue
            elif any(k in b_upper for k in ['CLOSING BAL', 'BAL C/F', 'BALANCE CARRIED FORWARD', 'TRANSACTION TOTAL', 'TOTAL DEBIT', 'TOTAL CREDIT']):
                nums = amount_pat.findall(block_text)
                if nums and any(k in b_upper for k in ['CLOSING BAL', 'BAL C/F', 'BALANCE CARRIED FORWARD']):
                    explicit_cl_bal = to_float(nums[-1])
                    explicit_cl_date = dt
                continue

            nums = [(mm.group(0), mm.start(), mm.end()) for mm in amount_pat.finditer(block_text)]
            if not nums:
                continue

            # Strip trailing integer branch codes (e.g. Axis branch code 268/248) if decimal numbers precede it
            if len(nums) >= 3 and '.' not in nums[-1][0] and '.' in nums[-2][0]:
                nums = nums[:-1]

            balance_str = nums[-1][0]
            b_num = to_float(balance_str)

            txamt = 0.0
            c_num = 0.0
            d_num = 0.0
            narr_end = nums[-1][0]

            if len(nums) >= 3:
                d_val = to_float(nums[-3][0])
                c_val = to_float(nums[-2][0])
                if d_val > 0 and c_val == 0:
                    d_num = d_val
                elif c_val > 0 and d_val == 0:
                    c_num = c_val
                else:
                    txamt = d_val or c_val
                narration = block_text[:nums[-3][1]].strip()
            elif len(nums) == 2:
                txamt = to_float(nums[-2][0])
                narration = block_text[:nums[-2][1]].strip()
            else:
                narration = block_text[:nums[-1][1]].strip()

            narration = re.sub(r'\s+(CR|DR|Credit|Debit)\s*$', '', narration, flags=re.I).strip()
            # Strip duplicate leading value date from narration
            m_lead = date_pat.search(narration)
            if m_lead and m_lead.start() < 5:
                narration = narration[m_lead.end():].strip()

            # 1. Delta math as primary ground truth for running balance statements
            if prev_bal is not None and b_num > 0:
                diff = round(b_num - prev_bal, 2)
                if diff > 0.001:
                    c_num = diff
                    d_num = 0.0
                elif diff < -0.001:
                    d_num = abs(diff)
                    c_num = 0.0
            elif not d_num and not c_num:
                # 2. Fallback to word boundary CR / DR matching
                sub_between = block_text[nums[-2][2]:nums[-1][1]] if len(nums) >= 2 else ''
                is_cr = bool(re.search(r'\b(CR|CREDIT|DEPOSIT)\b', sub_between, re.I) or re.search(r'\b(CR|CREDIT)\b', block_text, re.I))
                is_dr = bool(re.search(r'\b(DR|DEBIT|WITHDRAWAL)\b', sub_between, re.I) or re.search(r'\b(DR|DEBIT)\b', block_text, re.I))

                if is_cr and not is_dr:
                    c_num = txamt; d_num = 0.0
                elif is_dr and not is_cr:
                    d_num = txamt; c_num = 0.0
                elif is_cr:
                    c_num = txamt; d_num = 0.0
                elif is_dr:
                    d_num = txamt; c_num = 0.0

            if b_num > 0:
                prev_bal = b_num

            narr_upper = narration.upper()
            sug_nature = ''
            sug_head = ''

            if any(k in narr_upper for k in ['SALARY', 'PAYROLL', 'SAL CREDIT', 'SALARY CREDIT', 'ACH SALARY', 'NEFT SALARY', 'BY SALARY']):
                sug_nature = 'Salary'; sug_head = 'Salary'
            elif any(k in narr_upper for k in ['RENT', 'LEASE RENT', 'HOUSE RENT', 'RENT CREDIT', 'RENT RECEIVED']):
                sug_nature = 'Rent'; sug_head = 'House Property'
            elif any(k in narr_upper for k in ['FD INTEREST', 'FD INT', 'TERM DEPOSIT INT', 'TERM DEPOSIT INTEREST', 'FIXED DEPOSIT INT', 'FIXED DEPOSIT INTEREST', 'INT ON FD']) or ('INTEREST' in narr_upper and any(k in narr_upper for k in ['FD', 'TERM DEPOSIT', 'FIXED DEPOSIT'])):
                sug_nature = 'FD Interest'; sug_head = 'Other Sources'
            elif any(k in narr_upper for k in ['SAVINGS INTEREST', 'SAVINGS BANK INTEREST', 'SAVING BANK INTEREST', 'SAVINGS INT', 'SAVING INT', 'SB INT', 'INT ON SAVINGS', 'SAVINGS BANK INT', 'CREDIT INTEREST', 'INT. PAID', 'INT PAID', 'INT CREDIT', 'INTEREST CREDIT', 'INTEREST PAID', 'INTEREST RECD']) or 'INTEREST' in narr_upper:
                sug_nature = 'Savings Bank Interest'; sug_head = 'Other Sources'
            elif 'BOND INT' in narr_upper or 'BOND INTEREST' in narr_upper:
                sug_nature = 'Bond Interest'; sug_head = 'Other Sources'
            elif 'DIVIDEND' in narr_upper or 'DIV ' in narr_upper or 'ACH DIV' in narr_upper:
                sug_nature = 'Dividend'; sug_head = 'Other Sources'
            elif 'INCOME TAX REFUND' in narr_upper or 'IT REFUND' in narr_upper or 'TAX REFUND' in narr_upper:
                sug_nature = 'Income-tax Refund'; sug_head = 'Not Income'
            elif 'GST REFUND' in narr_upper:
                sug_nature = 'GST Refund'; sug_head = 'Not Income'
            elif any(k in narr_upper for k in ['MUTUAL FUND', 'MF REDEMPTION', 'MUTUAL FUND REDEMPTION', 'SIP REDEMPTION', 'AMC REDEMPTION']):
                sug_nature = 'Mutual Fund Redemption'; sug_head = 'Capital Gains'
            elif any(k in narr_upper for k in ['BROKER', 'ZERODHA', 'GROWW', 'UPSTOX', 'ANGEL', 'ICICIDIRECT', 'MOTILAL', 'SHARE SALE', 'EQUITY SALE']):
                sug_nature = 'Share / Broker Receipt'; sug_head = 'Capital Gains'
            elif any(k in narr_upper for k in ['PROPERTY SALE', 'LAND SALE', 'FLAT SALE', 'PLOT SALE']):
                sug_nature = 'Property Sale Receipt'; sug_head = 'Capital Gains'
            elif any(k in narr_upper for k in ['AGRICULTUR', 'CROP SALE', 'MANDI RECEIPT', 'KRISHI']):
                sug_nature = 'Agricultural Receipt'; sug_head = 'Agricultural Income – Exempt'
            elif 'PPF INT' in narr_upper or 'PPF INTEREST' in narr_upper:
                sug_nature = 'PPF Interest'; sug_head = 'Other Exempt Income'
            elif 'PPF' in narr_upper:
                sug_nature = 'PPF Withdrawal / Maturity'; sug_head = 'Other Exempt Income'
            elif any(k in narr_upper for k in ['LOAN REPAYMENT', 'EMI RECEIVED', 'LOAN RECOVERY']):
                sug_nature = 'Loan Repayment Received'; sug_head = 'Not Income'
            elif any(k in narr_upper for k in ['LOAN RECEIVED', 'LOAN DISBURSAL', 'PERSONAL LOAN', 'HOME LOAN']):
                sug_nature = 'Loan Received'; sug_head = 'Not Income'
            elif any(k in narr_upper for k in ['OWN ACCOUNT', 'SELF TRANSFER', 'TRANSFER TO SELF', 'INTERNAL TRANSFER']):
                sug_nature = 'Own Account Transfer'; sug_head = 'Not Income'
            elif any(k in narr_upper for k in ['REIMBURSEMENT', 'EXPENSE CLAIM', 'CLAIM SETTLEMENT']):
                sug_nature = 'Reimbursement'; sug_head = 'Not Income'
            elif any(k in narr_upper for k in ['PROFESSIONAL', 'CLIENT', 'CONSULTING', 'CONSULTANCY', 'TECHNICAL FEE']):
                sug_nature = 'Professional Receipt'; sug_head = 'PGBP'
            elif any(k in narr_upper for k in ['BUSINESS', 'CUSTOMER', 'VENDOR RECEIPT', 'MERCHANT']):
                sug_nature = 'Business Receipt'; sug_head = 'PGBP'

            head = sug_head if sug_head else ('Pending Review' if c_num > 0 else 'Not Income')

            if head in {'Salary', 'House Property', 'PGBP', 'Capital Gains', 'Other Sources', 'Agricultural Income – Exempt', 'Other Exempt Income'}:
                consider = 'Yes'
            elif head in {'Not Income', 'Opening Balance', 'Closing Balance'}:
                consider = 'No'
            else:
                consider = 'Review'

            parsed_txs.append({
                'date': dt,
                'narration': narration,
                'debit': d_num,
                'credit': c_num,
                'balance': b_num,
                'suggested_nature': sug_nature,
                'suggested_head': sug_head,
                'final_nature': sug_nature,
                'head': head,
                'consider': consider,
                'remarks': ''
            })

        op_balance = 0.0
        cl_balance = 0.0

        if explicit_op_bal is not None and explicit_op_bal > 0:
            op_balance = explicit_op_bal
            op_date = explicit_op_date or stmt_from
        elif parsed_txs:
            t0 = parsed_txs[0]
            b0 = t0['balance']
            c0 = t0['credit']
            d0 = t0['debit']
            if c0 > 0: op_balance = round(b0 - c0, 2)
            elif d0 > 0: op_balance = round(b0 + d0, 2)
            else: op_balance = round(b0, 2)
            op_date = stmt_from or t0['date']
        else:
            op_date = stmt_from or ''

        if explicit_cl_bal is not None and explicit_cl_bal > 0:
            cl_balance = explicit_cl_bal
            cl_date = explicit_cl_date or stmt_to
        elif parsed_txs:
            tn = parsed_txs[-1]
            cl_balance = round(tn['balance'], 2)
            cl_date = stmt_to or tn['date']
        else:
            cl_date = stmt_to or ''

        op_entry = {
            'date': op_date,
            'narration': 'OPENING BALANCE',
            'debit': 0.0,
            'credit': 0.0,
            'balance': round(op_balance, 2),
            'suggested_nature': 'Opening Balance',
            'suggested_head': 'Not Income',
            'final_nature': 'Opening Balance',
            'head': 'Not Income',
            'consider': 'No',
            'remarks': 'Statement Opening Balance'
        }

        cl_entry = {
            'date': cl_date,
            'narration': 'CLOSING BALANCE',
            'debit': 0.0,
            'credit': 0.0,
            'balance': round(cl_balance, 2),
            'suggested_nature': 'Closing Balance',
            'suggested_head': 'Not Income',
            'final_nature': 'Closing Balance',
            'head': 'Not Income',
            'consider': 'No',
            'remarks': 'Statement Closing Balance'
        }

        final_txs = [op_entry] + parsed_txs + [cl_entry]

        return {
            'bank_name': bank_name,
            'account_masked': account_masked,
            'statement_from': stmt_from,
            'statement_to': stmt_to,
            'opening_balance': round(op_balance, 2),
            'closing_balance': round(cl_balance, 2),
            'transactions': final_txs,
            'local_only': True
        }

    @classmethod
    def analyse_cg_statement(cls, text: str) -> Dict[str, Any]:
        """Extensive non-API Capital Gains / Broker Statement analyzer.
        Extracts broker metadata, ISIN, security names, buy dates, sell dates, quantities,
        cost of acquisition, sale consideration, expenses, STT, and automatically computes
        holding period & STCG/LTCG tax category.
        """
        broker_m = re.search(r'(?i)\b(?:ZERODHA|GROWW|UPSTOX|ICICI DIRECT|HDFC SECURITIES|ANGEL ONE|SHAREKHAN|MOTILAL OSWAL|KOTAK SECURITIES|PAYTM MONEY|CAMS|KFINTECH|NSDL|CDSL)\b', text[:2000])
        broker = broker_m.group(0).strip() if broker_m else 'Broker Statement'

        date_pat = re.compile(
            r'(?i)\b('
            r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|'
            r'\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}|'
            r'\d{1,2}[/-][A-Za-z]{3,9}[/-]\d{2,4}|'
            r'[A-Za-z]{3,9}\s+\d{1,2},\s*\d{2,4}|'
            r'\d{4}[/-]\d{1,2}[/-]\d{1,2}'
            r')\b'
        )
        cg_num_pat = re.compile(r'(?<!\w)-?\d+(?:,\d{3})*(?:\.\d+)?(?!\w)')
        isin_pat = re.compile(r'\b(IN[A-Z0-9]{10})\b')

        lines = text.splitlines()
        transactions = []

        def parse_date_obj(d_str):
            if not d_str: return None
            for fmt in ('%d/%m/%Y', '%d-%m-%Y', '%d/%m/%y', '%d-%m-%y', '%d-%b-%Y', '%d %b %Y', '%Y-%m-%d'):
                try: return datetime.strptime(d_str.strip(), fmt)
                except Exception: pass
            return None

        def calc_tax_cat(asset_type, buy_d, sell_d):
            bd = parse_date_obj(buy_d)
            sd = parse_date_obj(sell_d)
            is_eq = any(k in asset_type.upper() for k in ['EQUITY', 'SHARE', 'STOCKS', 'MUTUAL FUND', 'MF', 'ETF', 'FUND'])
            if bd and sd:
                m = (sd.year - bd.year) * 12 + (sd.month - bd.month)
                if is_eq:
                    return 'STCG – Special 20%' if m <= 12 else 'LTCG – Equity 12.5% above ₹1.25L'
                else:
                    return 'Normal-rate STCG' if m <= 36 else 'LTCG – Other 12.5%'
            return 'STCG – Special 20%' if is_eq else 'Normal-rate STCG'

        header_keywords = [
            'STATEMENT PERIOD', 'CAPITAL GAINS REPORT', 'TAX P&L', 'SR. NO.', 'SECURITY NAME',
            'ISIN', 'PAGE ', 'PERIOD:', 'FOR THE PERIOD', 'PAN:', 'ACCOUNT STATEMENT', 'TOTAL', 'GRAND TOTAL'
        ]

        for line in lines:
            line_clean = line.strip()
            line_upper = line_clean.upper()
            if not line_clean or any(hk in line_upper for hk in header_keywords):
                continue

            isin_m = isin_pat.search(line_clean)
            isin = isin_m.group(1) if isin_m else ''

            date_matches = list(date_pat.finditer(line_clean))
            if len(date_matches) >= 2:
                buy_date = date_matches[0].group(1)
                sell_date = date_matches[1].group(1)

                sec_end = date_matches[0].start()
                security = line_clean[:sec_end].strip()
                if isin and isin in security:
                    security = security.replace(isin, '').strip()
                security = re.sub(r'^\d+[\s\.\-]+', '', security).strip()

                if not security:
                    continue

                after_dates = line_clean[date_matches[1].end():]
                nums = [to_float(m.group(0)) for m in cg_num_pat.finditer(after_dates)]

                qty = nums[0] if len(nums) >= 1 and nums[0] > 0 else 1.0
                cost = nums[1] if len(nums) >= 2 else 0.0
                sale_value = nums[2] if len(nums) >= 3 else 0.0
                expenses = nums[3] if len(nums) >= 4 else 0.0
                stt = nums[4] if len(nums) >= 5 else 0.0

                asset_type = 'Mutual Funds' if any(k in security.upper() for k in ['FUND', 'MF', 'ETF', 'GROWTH', 'SCHEME']) else 'Equity Shares'
                tax_cat = calc_tax_cat(asset_type, buy_date, sell_date)

                transactions.append({
                    'security': security,
                    'isin': isin,
                    'asset_type': asset_type,
                    'buy_date': buy_date,
                    'sell_date': sell_date,
                    'quantity': qty,
                    'cost': cost,
                    'sale_value': sale_value,
                    'expenses': expenses,
                    'stt': stt,
                    'tax_category': tax_cat,
                    'source_reference': 'Local Extraction'
                })

        return {
            'broker': broker,
            'transactions': transactions,
            'local_only': True
        }

    @classmethod
    def heuristic_bank_rows(cls, text: str) -> List[Dict[str, Any]]:
        """Best-effort generic bank parser. API analysis is recommended for unfamiliar formats."""
        res = cls.analyse_bank_statement(text)
        return res.get("transactions", [])


# --------------------------------------------------------------------------------------
# AI client - document interpretation only
# --------------------------------------------------------------------------------------
class AIClient:
    @staticmethod
    def call(provider: str, api_key: str, model: str, prompt: str) -> str:
        if not api_key.strip():
            raise RuntimeError("Enter an API key in Settings / API first.")
        provider = provider.strip().lower()
        if provider == "gemini":
            try:
                from google import genai
            except Exception as e:
                raise RuntimeError("Gemini SDK missing. Install with: pip install google-genai") from e
            client = genai.Client(api_key=api_key.strip())
            candidate_models = [m for m in [model.strip(), "gemini-3.6-flash", "gemini-2.5-flash", "gemini-1.5-flash"] if m]
            candidate_models = list(dict.fromkeys(candidate_models))
            errs = []
            for target_model in candidate_models:
                try:
                    resp = client.models.generate_content(model=target_model, contents=prompt)
                    if hasattr(resp, "text") and resp.text:
                        return resp.text
                    if hasattr(resp, "output_text") and resp.output_text:
                        return resp.output_text
                except Exception as e1:
                    errs.append(f"{target_model}: {e1}")

                try:
                    resp = client.interactions.create(model=target_model, input=prompt)
                    text = getattr(resp, "output_text", None) or getattr(resp, "text", None)
                    if text:
                        return text
                except Exception as e2:
                    errs.append(f"{target_model} interactions: {e2}")

            raise RuntimeError(f"Gemini API call failed across candidate models: {'; '.join(errs)}")
        elif provider == "openai":
            try:
                from openai import OpenAI
            except Exception as e:
                raise RuntimeError("OpenAI SDK missing. Install with: pip install openai") from e
            client = OpenAI(api_key=api_key.strip())
            model_name = model.strip() or "gpt-4o"
            errs = []
            try:
                resp = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": prompt}],
                    temperature=0.1
                )
                if resp.choices and resp.choices[0].message.content:
                    return resp.choices[0].message.content
            except Exception as e1:
                errs.append(str(e1))
            try:
                resp = client.responses.create(model=model_name, input=prompt)
                text = getattr(resp, "output_text", None)
                if text:
                    return text
                return str(resp)
            except Exception as e2:
                errs.append(str(e2))
            raise RuntimeError(f"OpenAI API call failed: {'; '.join(errs)}")
        raise RuntimeError(f"Unsupported provider: {provider}")

    @staticmethod
    def verify(provider: str, api_key: str, model: str) -> str:
        result = AIClient.call(provider, api_key, model,
            "Reply with exactly: API_OK")
        return result.strip()

    @staticmethod
    def bank_prompt(text: str) -> str:
        natures = ", ".join([x for x in FINAL_NATURES if x])
        heads = ", ".join([x for x in HEADS if x])
        return f"""
You are extracting and reviewing an Indian bank statement for a Chartered Accountant's ITR workpaper.
The text may contain [REDACTED ...] labels. Do not try to reconstruct redacted data.

TASK
1. Extract transaction rows as accurately as possible.
2. For each CREDIT, suggest the likely nature and likely Head of Income.
3. For debits, preserve the transaction but suggested nature may be blank unless clearly useful.
4. Never decide final taxability. Set consider to "Review" unless the item is obviously a non-income transfer/refund,
   in which case you may still use "Review" so the CA confirms it.
5. Do not invent dates or amounts.
6. Return ONLY valid JSON, no prose.

Allowed suggested nature vocabulary (prefer exact values):
{natures}

Allowed head vocabulary:
{heads}

JSON schema:
{{
  "bank_name": "string or blank",
  "account_masked": "string or blank",
  "statement_from": "string or blank",
  "statement_to": "string or blank",
  "transactions": [
    {{
      "date":"string",
      "narration":"string",
      "debit":0,
      "credit":0,
      "balance":0,
      "suggested_nature":"string",
      "suggested_head":"string",
      "consider":"Review"
    }}
  ]
}}

BANK STATEMENT TEXT:
{text}
"""

    @staticmethod
    def cg_prompt(text: str) -> str:
        return f"""
You are extracting a Capital Gain / broker / investment statement for an Indian Chartered Accountant.
The text may contain [REDACTED ...] labels. Do not reconstruct redacted information.
Extract source facts only. Do NOT calculate final tax or apply legal conclusions beyond a review-friendly suggested category.
Return ONLY valid JSON, no prose.

For tax_category use one of:
- Normal-rate STCG
- STCG – Special 20%
- LTCG – Equity 12.5% above ₹1.25L
- LTCG – Other 12.5%

JSON schema:
{{
 "broker":"string or blank",
 "transactions":[
   {{
    "security":"string",
    "isin":"string",
    "asset_type":"string",
    "buy_date":"string",
    "sell_date":"string",
    "quantity":0,
    "cost":0,
    "sale_value":0,
    "expenses":0,
    "stt":0,
    "tax_category":"one allowed value",
    "source_reference":"page/sheet/row if available"
   }}
 ]
}}

STATEMENT TEXT:
{text}
"""

    @staticmethod
    def fo_prompt(text: str) -> str:
        return f"""
You are extracting an F&O / derivatives tax P&L or broker statement for an Indian Chartered Accountant.
Return ONLY JSON. Do not calculate income tax. Extract statement figures faithfully.
Schema:
{{
 "broker":"string or blank",
 "turnover":0,
 "net_trading_pnl":0,
 "brokerage":0,
 "exchange_charges":0,
 "gst":0,
 "stt":0,
 "stamp_duty":0,
 "other_charges":0,
 "remarks":"string"
}}

STATEMENT TEXT:
{text}
"""


# --------------------------------------------------------------------------------------
# Small UI helpers
# --------------------------------------------------------------------------------------
class Card(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("Card")
        self.layout_ = QVBoxLayout(self)
        self.layout_.setContentsMargins(16, 14, 16, 14)
        self.layout_.setSpacing(8)


class PageHeader(QWidget):
    def __init__(self, title: str, subtitle: str = "", actions: Optional[List[QWidget]] = None):
        super().__init__()
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 4)
        left = QVBoxLayout()
        t = QLabel(title); t.setObjectName("PageTitle")
        left.addWidget(t)
        if subtitle:
            s = QLabel(subtitle); s.setObjectName("Muted"); s.setWordWrap(True)
            left.addWidget(s)
        lay.addLayout(left, 1)
        for w in actions or []:
            lay.addWidget(w)


class KPI(Card):
    def __init__(self, label: str, value: str = "₹0.00", accent: str = COLORS["accent"]):
        super().__init__()
        self.value_label = QLabel(value); self.value_label.setObjectName("KpiValue")
        self.value_label.setStyleSheet(f"color:{accent};")
        self.label = QLabel(label); self.label.setObjectName("KpiLabel")
        self.layout_.addWidget(self.value_label)
        self.layout_.addWidget(self.label)

    def set_value(self, value: str):
        self.value_label.setText(value)


class MoneyEdit(QLineEdit):
    def __init__(self, value: Any = 0):
        super().__init__()
        self.setText(f"{to_float(value):.2f}")
        self.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.setPlaceholderText("0.00")

    def value(self) -> float:
        return to_float(self.text())


class AssesseeDialog(QDialog):
    def __init__(self, parent, data: Dict[str, Any]):
        super().__init__(parent)
        self.setWindowTitle("Assessee & Tax Year Details")
        self.resize(520, 430)
        self.data = data
        lay = QVBoxLayout(self)
        form = QFormLayout()
        self.name = QLineEdit(data.get("name", ""))
        self.pan = QLineEdit(data.get("pan", "")); self.pan.setMaxLength(10)
        self.status = QComboBox(); self.status.addItems(["Individual", "HUF"]); self.status.setCurrentText(data.get("status", "Individual"))
        self.dob = QDateEdit(); self.dob.setCalendarPopup(True); self.dob.setDisplayFormat("dd-MM-yyyy")
        if data.get("dob"):
            qd = QDate.fromString(data["dob"], "yyyy-MM-dd")
            if qd.isValid(): self.dob.setDate(qd)
        else:
            self.dob.setDate(QDate(1990, 1, 1))
        self.res = QComboBox(); self.res.addItems(["Resident", "Non-Resident"]); self.res.setCurrentText(data.get("residential_status", "Resident"))
        self.business = QCheckBox("Assessee has business/professional income")
        self.business.setChecked(bool(data.get("business_income", False)))
        form.addRow("Name of Assessee", self.name)
        form.addRow("PAN", self.pan)
        form.addRow("Status", self.status)
        form.addRow("Date of Birth", self.dob)
        form.addRow("Residential Status", self.res)
        form.addRow("", self.business)
        ty = QLabel(f"Tax Year: {TAX_YEAR}  •  Income-tax Act, 2025")
        ty.setStyleSheet(f"background:{COLORS['softblue']};padding:10px;border-radius:7px;color:{COLORS['accent']};font-weight:700")
        lay.addWidget(ty)
        lay.addLayout(form)
        lay.addStretch()
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.accept); bb.rejected.connect(self.reject)
        lay.addWidget(bb)

    def result_data(self):
        return {
            "name": self.name.text().strip(),
            "pan": self.pan.text().strip().upper(),
            "status": self.status.currentText(),
            "dob": self.dob.date().toString("yyyy-MM-dd"),
            "residential_status": self.res.currentText(),
            "business_income": self.business.isChecked(),
        }


# --------------------------------------------------------------------------------------
# Privacy/API import dialog
# --------------------------------------------------------------------------------------
class ApiWorkerThread(QThread):
    finished_signal = Signal(dict)
    error_signal = Signal(str)
    progress_signal = Signal(int, int, str)

    def __init__(self, doc_type: str, provider: str, key: str, model: str, text: str):
        super().__init__()
        self.doc_type = doc_type
        self.provider = provider
        self.key = key
        self.model = model
        self.text = text
        self._is_cancelled = False

    def cancel(self):
        self._is_cancelled = True

    def run(self):
        try:
            text = self.text
            chunk_size = 45000
            chunks = [text[i:i+chunk_size] for i in range(0, len(text), chunk_size)] or [""]
            if self.doc_type == "fo": chunks = [text]
            merged: Dict[str, Any] = {"transactions": []}
            total = len(chunks)

            for i, chunk in enumerate(chunks, 1):
                if self._is_cancelled:
                    return
                self.progress_signal.emit(i, total, f"Analysing part {i} of {total} via {self.provider} API...")
                if self.doc_type == "bank": prompt = AIClient.bank_prompt(chunk)
                elif self.doc_type == "cg": prompt = AIClient.cg_prompt(chunk)
                elif self.doc_type == "fo": prompt = AIClient.fo_prompt(chunk)
                else: prompt = "Return JSON summary of this document:\n" + chunk

                response = AIClient.call(self.provider, self.key, self.model, prompt)
                if self._is_cancelled:
                    return
                data = safe_json_from_text(response)
                if isinstance(data, list): data = {"transactions": data}
                if self.doc_type in ("bank", "cg"):
                    merged["transactions"].extend(data.get("transactions", []) if isinstance(data, dict) else [])
                    for k2, v2 in (data.items() if isinstance(data, dict) else []):
                        if k2 != "transactions" and v2 and not merged.get(k2): merged[k2] = v2
                else:
                    merged = data if isinstance(data, dict) else {"result": data}

            merged["api_truncated"] = False
            if not self._is_cancelled:
                self.finished_signal.emit(merged)
        except Exception as e:
            if not self._is_cancelled:
                self.error_signal.emit(str(e))


class PrivacyImportDialog(QDialog):
    """Common workflow for Bank, CG and F&O statements."""
    def __init__(self, parent, file_path: str, doc_type: str, settings: Dict[str, Any]):
        super().__init__(parent)
        self.setWindowTitle("Privacy-first Document Import")
        self.resize(1100, 760)
        self.file_path = file_path
        self.doc_type = doc_type
        self.settings = settings
        self.analysis_data: Dict[str, Any] = {}
        self.redacted_text = ""
        self.worker: Optional[ApiWorkerThread] = None
        self.extraction = PDFPrivacyEngine.extract_pdf_text(file_path)
        self.detections = PDFPrivacyEngine.detect(self.extraction["text"])

        root = QVBoxLayout(self)
        title = QLabel("Local extraction → sensitive-data review → preview → optional API analysis")
        title.setObjectName("SectionTitle")
        root.addWidget(title)
        info = QLabel(f"<b>{Path(file_path).name}</b> • {self.extraction['page_count']} page(s) • "
                      f"{len(self.detections)} sensitive-data candidate(s). Nothing has been sent to an API yet.")
        info.setWordWrap(True); info.setStyleSheet(f"background:{COLORS['softgreen']};padding:10px;border-radius:8px")
        root.addWidget(info)

        split = QSplitter(Qt.Orientation.Horizontal)
        left = QWidget(); ll = QVBoxLayout(left); ll.setContentsMargins(0,0,0,0)
        box = QGroupBox("Redaction categories")
        bl = QVBoxLayout(box)
        self.category_checks: Dict[str, QCheckBox] = {}
        counts = {}
        for d in self.detections: counts[d["type"]] = counts.get(d["type"], 0) + 1
        for typ in sorted(counts):
            cb = QCheckBox(f"{typ} ({counts[typ]})")
            cb.setChecked(typ in {"PAN", "Aadhaar", "Account Number", "Customer ID/CIF", "Mobile", "Email", "GSTIN", "TAN", "UPI ID", "Address"})
            cb.stateChanged.connect(self.update_redacted_preview)
            self.category_checks[typ] = cb; bl.addWidget(cb)
        if not counts:
            bl.addWidget(QLabel("No pattern-based sensitive data detected."))
        allrow = QHBoxLayout()
        allbtn = QPushButton("Redact All"); allbtn.clicked.connect(lambda: self.set_all_redaction(True))
        nonebtn = QPushButton("Do Not Redact"); nonebtn.clicked.connect(lambda: self.set_all_redaction(False))
        allrow.addWidget(allbtn); allrow.addWidget(nonebtn); bl.addLayout(allrow)
        ll.addWidget(box)
        warning = QLabel("Pattern-based detection is a review aid and can miss sensitive data. Inspect the yellow-highlight preview before API use. Normally redact PAN/Aadhaar/account/mobile/email/address, but keep transaction narrations and counterparties where needed for classification.")
        warning.setWordWrap(True); warning.setStyleSheet(f"background:{COLORS['softyellow']};padding:10px;border-radius:8px")
        ll.addWidget(warning)
        ll.addStretch()
        split.addWidget(left)

        tabs = QTabWidget()
        self.original_preview = QTextBrowser(); self.original_preview.setHtml(PDFPrivacyEngine.highlighted_html(self.extraction["text"], self.detections))
        self.redacted_preview = QTextBrowser()
        tabs.addTab(self.original_preview, "Yellow Highlight Review")
        tabs.addTab(self.redacted_preview, "Redacted Preview")
        split.addWidget(tabs)
        split.setStretchFactor(1, 1)
        root.addWidget(split, 1)

        prog_layout = QHBoxLayout()
        self.status_lbl = QLabel("")
        self.progress = QProgressBar(); self.progress.setVisible(False)
        self.cancel_api_btn = QPushButton("Cancel API & Use Local Import")
        self.cancel_api_btn.setVisible(False)
        self.cancel_api_btn.clicked.connect(self.cancel_api_worker)
        prog_layout.addWidget(self.status_lbl)
        prog_layout.addWidget(self.progress, 1)
        prog_layout.addWidget(self.cancel_api_btn)
        root.addLayout(prog_layout)

        actions = QHBoxLayout()
        self.api_btn = QPushButton("Analyse Using API"); self.api_btn.setObjectName("Primary"); self.api_btn.clicked.connect(self.analyse)
        local_btn = QPushButton("Import Without API"); local_btn.clicked.connect(self.local_import)
        cancel = QPushButton("Cancel"); cancel.clicked.connect(self.reject)
        actions.addStretch(); actions.addWidget(local_btn); actions.addWidget(self.api_btn); actions.addWidget(cancel)
        root.addLayout(actions)
        self.update_redacted_preview()

    def selected_types(self) -> set[str]:
        return {typ for typ, cb in self.category_checks.items() if cb.isChecked()}

    def set_all_redaction(self, checked: bool):
        for cb in self.category_checks.values(): cb.setChecked(checked)
        self.update_redacted_preview()

    def update_redacted_preview(self):
        self.redacted_text = PDFPrivacyEngine.redact(self.extraction["text"], self.detections, self.selected_types())
        self.redacted_preview.setPlainText(self.redacted_text)

    def local_import(self):
        if self.worker:
            self.worker.cancel()
        if self.doc_type == "bank":
            analysis = PDFPrivacyEngine.analyse_bank_statement(self.extraction["text"])
            self.analysis_data = analysis
        elif self.doc_type == "cg":
            analysis = PDFPrivacyEngine.analyse_cg_statement(self.extraction["text"])
            self.analysis_data = analysis
        else:
            self.analysis_data = {"transactions": [], "local_only": True, "raw_text": self.redacted_text}
        self.accept()

    def cancel_api_worker(self):
        if self.worker:
            self.worker.cancel()
        self.local_import()

    def analyse(self):
        if not self.selected_types() and self.detections:
            ans = QMessageBox.warning(self, "Unredacted API analysis",
                "Sensitive information was detected, but you selected no redaction.\n\n"
                "The extracted content may be sent to the selected external AI provider. Continue?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)
            if ans != QMessageBox.StandardButton.Yes:
                return
        provider = self.settings.get("api_provider", "Gemini")
        key = self.settings.get("api_key", "")
        model = self.settings.get("api_model", "")
        if not key:
            reply = QMessageBox.question(
                self, "API Key Missing",
                "API key is not configured in Settings / API.\n\n"
                "Would you like to import automatically using the fast offline Non-API Parser?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.local_import()
            return

        self.progress.setVisible(True)
        self.cancel_api_btn.setVisible(True)
        self.api_btn.setEnabled(False)
        self.status_lbl.setText("Connecting to API...")

        self.worker = ApiWorkerThread(self.doc_type, provider, key, model, self.redacted_text)
        self.worker.progress_signal.connect(self.on_api_progress)
        self.worker.finished_signal.connect(self.on_api_success)
        self.worker.error_signal.connect(self.on_api_error)
        self.worker.start()

    def on_api_progress(self, step: int, total: int, msg: str):
        self.progress.setRange(0, total)
        self.progress.setValue(step)
        self.status_lbl.setText(msg)

    def on_api_success(self, merged: Dict[str, Any]):
        if self.doc_type == "bank":
            txs = merged.get("transactions", [])
            if txs:
                has_op = any("OPENING BAL" in str(t.get("narration","")).upper() or str(t.get("suggested_nature","")) == "Opening Balance" for t in txs)
                has_cl = any("CLOSING BAL" in str(t.get("narration","")).upper() or str(t.get("suggested_nature","")) == "Closing Balance" for t in txs)
                b0 = to_float(txs[0].get("balance"))
                c0 = to_float(txs[0].get("credit"))
                d0 = to_float(txs[0].get("debit"))
                op_bal = b0 - c0 if c0 > 0 else (b0 + d0 if d0 > 0 else b0)
                cl_bal = to_float(txs[-1].get("balance"))
                merged["opening_balance"] = round(op_bal, 2)
                merged["closing_balance"] = round(cl_bal, 2)
                if not has_op:
                    op_entry = {"date": merged.get("statement_from") or txs[0].get("date",""), "narration": "OPENING BALANCE", "debit": 0, "credit": 0, "balance": round(op_bal, 2), "suggested_nature": "Opening Balance", "suggested_head": "Not Income", "final_nature": "Opening Balance", "head": "Not Income", "consider": "No", "remarks": "Statement Opening Balance"}
                    txs.insert(0, op_entry)
                if not has_cl:
                    cl_entry = {"date": merged.get("statement_to") or txs[-1].get("date",""), "narration": "CLOSING BALANCE", "debit": 0, "credit": 0, "balance": round(cl_bal, 2), "suggested_nature": "Closing Balance", "suggested_head": "Not Income", "final_nature": "Closing Balance", "head": "Not Income", "consider": "No", "remarks": "Statement Closing Balance"}
                    txs.append(cl_entry)

        self.analysis_data = merged
        self.accept()

    def on_api_error(self, err_msg: str):
        self.progress.setVisible(False)
        self.cancel_api_btn.setVisible(False)
        self.api_btn.setEnabled(True)
        self.status_lbl.setText("")

        reply = QMessageBox.question(
            self, "API Analysis Failed",
            f"API analysis failed or timed out:\n{err_msg}\n\n"
            "Would you like to import automatically using the fast offline Non-API Parser?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes
        )
        if reply == QMessageBox.StandardButton.Yes:
            self.local_import()


# --------------------------------------------------------------------------------------
# Income detail dialogs
# --------------------------------------------------------------------------------------
class SalaryDialog(QDialog):
    COLS = ["Employer", "Employer PAN", "Employer TAN", "Gross Salary", "Exemptions New", "Exemptions Old",
            "Professional Tax", "Other Deduction New", "Other Deduction Old", "Remarks"]
    KEYS = ["employer", "pan", "tan", "gross_salary", "exemptions_new", "exemptions_old", "professional_tax", "other_ded_new", "other_ded_old", "remarks"]

    def __init__(self, parent, case: Dict[str, Any]):
        super().__init__(parent); self.case = case
        self.setWindowTitle("Salary Working"); self.resize(1200, 560)
        root = QVBoxLayout(self)
        banner = QLabel("Standard deduction is calculated automatically on aggregate salary: ₹75,000 New Regime / ₹50,000 Old Regime (subject to salary). Professional tax is excluded in New Regime.")
        banner.setWordWrap(True); banner.setStyleSheet(f"background:{COLORS['softblue']};padding:10px;border-radius:8px")
        root.addWidget(banner)
        self.table = QTableWidget(0, len(self.COLS)); self.table.setHorizontalHeaderLabels(self.COLS); set_table_defaults(self.table)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        root.addWidget(self.table, 1)
        btns = QHBoxLayout()
        add = QPushButton("+ Add Employer"); add.clicked.connect(self.add_row)
        rem = QPushButton("Remove Selected"); rem.setObjectName("Danger"); rem.clicked.connect(self.remove_row)
        btns.addWidget(add); btns.addWidget(rem); btns.addStretch()
        root.addLayout(btns)
        self.summary = QLabel(); self.summary.setObjectName("SectionTitle"); root.addWidget(self.summary)
        bb = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        bb.accepted.connect(self.save_accept); bb.rejected.connect(self.reject); root.addWidget(bb)
        for row in case.get("salary", {}).get("employers", []): self.add_row(row)
        self.table.itemChanged.connect(self.update_summary); self.update_summary()

    def add_row(self, data=None):
        data = data or {}; r = self.table.rowCount(); self.table.insertRow(r)
        for c, key in enumerate(self.KEYS):
            self.table.setItem(r, c, table_item(data.get(key, "" if key in ("employer","pan","tan","remarks") else 0)))
        self.update_summary()

    def remove_row(self):
        r = self.table.currentRow()
        if r >= 0: self.table.removeRow(r); self.update_summary()

    def rows(self):
        out=[]
        for r in range(self.table.rowCount()):
            row={}
            for c,key in enumerate(self.KEYS):
                val=self.table.item(r,c).text() if self.table.item(r,c) else ""
                row[key] = val if key in ("employer","pan","tan","remarks") else to_float(val)
            out.append(row)
        return out

    def update_summary(self):
        tmp = json_deepcopy(self.case); tmp.setdefault("salary", {})["employers"] = self.rows()
        s=TaxEngine.salary(tmp)
        self.summary.setText(f"Gross Salary {money(s['gross'])}   |   Income from Salary — New {money(s['new'])}   |   Old {money(s['old'])}")

    def save_accept(self):
        self.case.setdefault("salary", {})["employers"] = self.rows(); self.accept()


class HousePropertyDialog(QDialog):
    COLS = ["Address", "Status", "Tenant Name", "Tenant PAN", "Tenant TAN", "Share %", "Co-owner Name", "Co-owner PAN", "Co-owner Share %",
            "Actual Rent", "Expected Rent", "Vacancy Adj.", "Unrealised Rent", "Municipal Taxes", "Interest", "Pre-constr. Interest", "Arrears Recovered", "Bank Rent", "Remarks"]
    KEYS = ["address","property_status","tenant_name","tenant_pan","tenant_tan","share_pct","coowner_name","coowner_pan","coowner_share_pct",
            "actual_rent","expected_rent","vacancy_adjustment","unrealised_rent","municipal_taxes","interest","preconstruction_interest","arrears_recovered","bank_rent","remarks"]

    def __init__(self, parent, case: Dict[str, Any]):
        super().__init__(parent); self.case=case
        self.setWindowTitle("House Property Working"); self.resize(1400, 590)
        root=QVBoxLayout(self)
        banner=QLabel("Each property computes Gross/Net Annual Value → Municipal Taxes → 30% standard deduction → eligible interest → assessee's ownership share. Self-occupied New Regime interest is restricted by section 202.")
        banner.setWordWrap(True); banner.setStyleSheet(f"background:{COLORS['softblue']};padding:10px;border-radius:8px"); root.addWidget(banner)
        self.table=QTableWidget(0,len(self.COLS)); self.table.setHorizontalHeaderLabels(self.COLS); set_table_defaults(self.table)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents); self.table.setHorizontalScrollMode(QAbstractItemView.ScrollMode.ScrollPerPixel)
        root.addWidget(self.table,1)
        row=QHBoxLayout(); a=QPushButton("+ Add Property"); a.clicked.connect(self.add_row); d=QPushButton("Remove Selected"); d.setObjectName("Danger"); d.clicked.connect(self.remove_row); row.addWidget(a); row.addWidget(d); row.addStretch(); root.addLayout(row)
        self.summary=QLabel(); self.summary.setObjectName("SectionTitle"); root.addWidget(self.summary)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel); bb.accepted.connect(self.save_accept); bb.rejected.connect(self.reject); root.addWidget(bb)
        for p in case.get("house_property",{}).get("properties",[]): self.add_row(p)
        self.table.itemChanged.connect(self.update_summary); self.update_summary()

    def add_row(self,data=None):
        d=data or {}; r=self.table.rowCount(); self.table.insertRow(r)
        for c,key in enumerate(self.KEYS):
            default=""
            if key=="property_status": default="Let Out"
            elif key=="share_pct": default=100
            elif key=="coowner_share_pct": default=0
            elif key not in ("address","property_status","tenant_name","tenant_pan","tenant_tan","coowner_name","coowner_pan","remarks"): default=0
            self.table.setItem(r,c,table_item(d.get(key,default)))

    def remove_row(self):
        r=self.table.currentRow()
        if r>=0: self.table.removeRow(r); self.update_summary()

    def rows(self):
        texts={"address","property_status","tenant_name","tenant_pan","tenant_tan","coowner_name","coowner_pan","remarks"}
        out=[]
        for r in range(self.table.rowCount()):
            d={}
            for c,key in enumerate(self.KEYS):
                val=self.table.item(r,c).text() if self.table.item(r,c) else ""
                d[key]=val if key in texts else to_float(val)
            out.append(d)
        return out

    def update_summary(self):
        tmp=json_deepcopy(self.case); tmp.setdefault("house_property",{})["properties"]=self.rows(); hp=TaxEngine.house_property(tmp)
        self.summary.setText(f"House Property Income/(Loss) — New {money(hp['new'])}   |   Old {money(hp['old'])}")

    def save_accept(self):
        for p in self.rows():
            share=to_float(p.get("share_pct")); co=to_float(p.get("coowner_share_pct"))
            if share < 100:
                if not p.get("coowner_name") or not p.get("coowner_pan"):
                    QMessageBox.warning(self,"Co-owner details required",f"Property '{p.get('address','')}' has assessee share below 100%. Enter co-owner name and PAN.")
                    return
                if abs((share+co)-100) > 0.01:
                    QMessageBox.warning(self,"Ownership check",f"Property '{p.get('address','')}' ownership shares total {share+co:.2f}%, not 100%. Please review.")
                    return
        self.case.setdefault("house_property",{})["properties"]=self.rows(); self.accept()


class PGBPDialog(QDialog):
    def __init__(self, parent, case: Dict[str, Any], settings: Dict[str, Any], import_callback):
        super().__init__(parent); self.case=case; self.settings=settings; self.import_callback=import_callback
        self.setWindowTitle("PGBP Working"); self.resize(900,590)
        root=QVBoxLayout(self); self.tabs=QTabWidget(); root.addWidget(self.tabs,1)
        p=case.setdefault("pgbp",{})
        # Regular
        w=QWidget(); f=QFormLayout(w); r=p.setdefault("regular",{})
        self.reg_net=MoneyEdit(r.get("net_profit")); self.reg_add=MoneyEdit(r.get("additions")); self.reg_dn=MoneyEdit(r.get("deductions_new")); self.reg_do=MoneyEdit(r.get("deductions_old")); self.reg_turn=MoneyEdit(r.get("turnover")); self.reg_rem=QLineEdit(r.get("remarks",""))
        f.addRow("Net Profit as per P&L",self.reg_net); f.addRow("Add: Tax adjustments / disallowances",self.reg_add); f.addRow("Less: Adjustments allowed – New",self.reg_dn); f.addRow("Less: Adjustments allowed – Old",self.reg_do); f.addRow("Turnover / Gross Receipts",self.reg_turn); f.addRow("Remarks",self.reg_rem); self.tabs.addTab(w,"Regular Books")
        # Presumptive business
        w=QWidget(); f=QFormLayout(w); r=p.setdefault("presumptive_business",{})
        self.pb_dig=MoneyEdit(r.get("digital_turnover")); self.pb_other=MoneyEdit(r.get("other_turnover")); self.pb_profit=MoneyEdit(r.get("declared_profit")); self.pb_rem=QLineEdit(r.get("remarks","")); self.pb_calc=QLabel()
        for ed in (self.pb_dig,self.pb_other,self.pb_profit): ed.textChanged.connect(self.update_calc)
        f.addRow("Turnover received by specified banking/online mode",self.pb_dig); f.addRow("Other / cash turnover",self.pb_other); f.addRow("Profit actually declared",self.pb_profit); f.addRow("Section 58 deemed income",self.pb_calc); f.addRow("Remarks",self.pb_rem); self.tabs.addTab(w,"Presumptive Business")
        # Presumptive profession
        w=QWidget(); f=QFormLayout(w); r=p.setdefault("presumptive_profession",{})
        self.pp_gross=MoneyEdit(r.get("gross_receipts")); self.pp_cash=MoneyEdit(r.get("cash_receipts")); self.pp_profit=MoneyEdit(r.get("declared_profit")); self.pp_rem=QLineEdit(r.get("remarks","")); self.pp_calc=QLabel()
        for ed in (self.pp_gross,self.pp_cash,self.pp_profit): ed.textChanged.connect(self.update_calc)
        f.addRow("Gross professional receipts",self.pp_gross); f.addRow("Cash receipts",self.pp_cash); f.addRow("Profit actually declared",self.pp_profit); f.addRow("Section 58 deemed income",self.pp_calc); f.addRow("Remarks",self.pp_rem); self.tabs.addTab(w,"Presumptive Profession")
        # Goods carriage
        w=QWidget(); l=QVBoxLayout(w); self.gc=QTableWidget(0,5); self.gc.setHorizontalHeaderLabels(["Vehicle No.","Vehicle Type","Weight Tons","Months Owned","Declared Profit"]); set_table_defaults(self.gc); l.addWidget(self.gc); br=QHBoxLayout(); ba=QPushButton("+ Vehicle"); ba.clicked.connect(self.add_vehicle); bd=QPushButton("Remove"); bd.clicked.connect(lambda:self.gc.removeRow(self.gc.currentRow()) if self.gc.currentRow()>=0 else None); br.addWidget(ba);br.addWidget(bd);br.addStretch();l.addLayout(br);self.tabs.addTab(w,"Goods Carriage")
        for v in p.setdefault("goods_carriage",{}).get("vehicles",[]): self.add_vehicle(v)
        # F&O
        w=QWidget(); f=QFormLayout(w); r=p.setdefault("fo",{})
        self.fo_turn=MoneyEdit(r.get("turnover")); self.fo_pnl=MoneyEdit(r.get("pnl")); self.fo_exp=MoneyEdit(r.get("expenses")); self.fo_rem=QLineEdit(r.get("remarks","")); self.fo_src=QLineEdit(r.get("source_file","")); self.fo_src.setReadOnly(True)
        imp=QPushButton("Import F&O Statement (Privacy → API)"); imp.clicked.connect(self.import_fo)
        f.addRow(imp); f.addRow("F&O Turnover",self.fo_turn); f.addRow("Net Trading P&L",self.fo_pnl); f.addRow("Allowable Expenses / Charges",self.fo_exp); f.addRow("Source File",self.fo_src); f.addRow("Remarks",self.fo_rem); self.tabs.addTab(w,"F&O")
        # Speculative
        w=QWidget(); f=QFormLayout(w); r=p.setdefault("speculative",{})
        self.sp_turn=MoneyEdit(r.get("turnover")); self.sp_pnl=MoneyEdit(r.get("pnl")); self.sp_exp=MoneyEdit(r.get("expenses")); self.sp_rem=QLineEdit(r.get("remarks","")); f.addRow("Turnover",self.sp_turn); f.addRow("Trading P&L",self.sp_pnl); f.addRow("Expenses",self.sp_exp); f.addRow("Remarks",self.sp_rem); self.tabs.addTab(w,"Speculative / Intraday")
        self.summary=QLabel(); self.summary.setObjectName("SectionTitle"); root.addWidget(self.summary)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel); bb.accepted.connect(self.save_accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        self.update_calc()

    def add_vehicle(self,d=None):
        d=d or {}; r=self.gc.rowCount(); self.gc.insertRow(r)
        vals=[d.get("vehicle_no",""),d.get("vehicle_type","Other"),d.get("weight_tons",0),d.get("months",0),d.get("declared_profit",0)]
        for c,v in enumerate(vals):self.gc.setItem(r,c,table_item(v))

    def import_fo(self):
        path,_=QFileDialog.getOpenFileName(self,"Select F&O/Broker Statement","","PDF Files (*.pdf)")
        if not path:return
        dlg=PrivacyImportDialog(self,path,"fo",self.settings)
        if dlg.exec()==QDialog.DialogCode.Accepted:
            d=dlg.analysis_data
            if d:
                self.fo_turn.setText(str(to_float(d.get("turnover"))))
                pnl=to_float(d.get("net_trading_pnl")); self.fo_pnl.setText(str(pnl))
                exp=sum(to_float(d.get(k)) for k in ["brokerage","exchange_charges","gst","stt","stamp_duty","other_charges"])
                self.fo_exp.setText(str(exp)); self.fo_src.setText(Path(path).name); self.fo_rem.setText(d.get("remarks",""))
                self.import_callback(path,"F&O / Broker Statement","PGBP – F&O",dlg)

    def vehicles(self):
        out=[]
        for r in range(self.gc.rowCount()):
            vals=[self.gc.item(r,c).text() if self.gc.item(r,c) else "" for c in range(5)]
            out.append({"vehicle_no":vals[0],"vehicle_type":vals[1],"weight_tons":to_float(vals[2]),"months":int(to_float(vals[3])),"declared_profit":to_float(vals[4])})
        return out

    def update_calc(self):
        pb=max(self.pb_dig.value()*.06+self.pb_other.value()*.08,self.pb_profit.value())
        pp=max(self.pp_gross.value()*.50,self.pp_profit.value())
        self.pb_calc.setText(money(pb));self.pp_calc.setText(money(pp))
        # threshold warning
        pb_total=self.pb_dig.value()+self.pb_other.value(); cash_pct=(self.pb_other.value()/pb_total*100) if pb_total else 0
        if (cash_pct<=5 and pb_total>30000000) or (cash_pct>5 and pb_total>20000000): self.pb_calc.setText(self.pb_calc.text()+"  ⚠ Turnover exceeds section 58 threshold")
        gross=self.pp_gross.value(); cashp=(self.pp_cash.value()/gross*100) if gross else 0
        if (cashp<=5 and gross>7500000) or (cashp>5 and gross>5000000): self.pp_calc.setText(self.pp_calc.text()+"  ⚠ Gross receipts exceed section 58 threshold")

    def save_accept(self):
        p=self.case.setdefault("pgbp",{})
        p["regular"]={"net_profit":self.reg_net.value(),"additions":self.reg_add.value(),"deductions_new":self.reg_dn.value(),"deductions_old":self.reg_do.value(),"turnover":self.reg_turn.value(),"remarks":self.reg_rem.text()}
        p["presumptive_business"]={"digital_turnover":self.pb_dig.value(),"other_turnover":self.pb_other.value(),"declared_profit":self.pb_profit.value(),"remarks":self.pb_rem.text()}
        p["presumptive_profession"]={"gross_receipts":self.pp_gross.value(),"cash_receipts":self.pp_cash.value(),"declared_profit":self.pp_profit.value(),"remarks":self.pp_rem.text()}
        p["goods_carriage"]={"vehicles":self.vehicles()}
        p["fo"]={"turnover":self.fo_turn.value(),"pnl":self.fo_pnl.value(),"expenses":self.fo_exp.value(),"remarks":self.fo_rem.text(),"source_file":self.fo_src.text()}
        p["speculative"]={"turnover":self.sp_turn.value(),"pnl":self.sp_pnl.value(),"expenses":self.sp_exp.value(),"remarks":self.sp_rem.text()}
        self.accept()


class CapitalGainsDialog(QDialog):
    COLS=["Security","ISIN","Asset Type","Buy Date","Sell Date","Qty","Cost","Sale Value","Expenses","STT","Tax Category","Source Reference"]
    KEYS=["security","isin","asset_type","buy_date","sell_date","quantity","cost","sale_value","expenses","stt","tax_category","source_reference"]
    CATEGORIES=["Normal-rate STCG","STCG – Special 20%","LTCG – Equity 12.5% above ₹1.25L","LTCG – Other 12.5%"]
    def __init__(self,parent,case,settings,import_callback):
        super().__init__(parent);self.case=case;self.settings=settings;self.import_callback=import_callback
        self.setWindowTitle("Capital Gains Working");self.resize(1400,610)
        root=QVBoxLayout(self)
        banner=QLabel("Import any broker/CG PDF using the common privacy workflow. AI extracts source facts; this program computes gain and special-rate tax categories. Review every imported line before finalisation.")
        banner.setWordWrap(True);banner.setStyleSheet(f"background:{COLORS['softblue']};padding:10px;border-radius:8px");root.addWidget(banner)
        self.table=QTableWidget(0,len(self.COLS));self.table.setHorizontalHeaderLabels(self.COLS);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents);root.addWidget(self.table,1)
        bar=QHBoxLayout();imp=QPushButton("Import CG / Broker Statement");imp.setObjectName("Primary");imp.clicked.connect(self.import_statement);add=QPushButton("+ Manual Row");add.clicked.connect(self.add_row);rem=QPushButton("Remove Selected");rem.setObjectName("Danger");rem.clicked.connect(self.remove_row);bar.addWidget(imp);bar.addWidget(add);bar.addWidget(rem);bar.addStretch();root.addLayout(bar)
        self.summary=QLabel();self.summary.setObjectName("SectionTitle");root.addWidget(self.summary)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel);bb.accepted.connect(self.save_accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        for tx in case.get("capital_gains",{}).get("transactions",[]):self.add_row(tx)
        self.table.itemChanged.connect(self.update_summary);self.update_summary()

    def add_row(self,d=None):
        d=d or {};r=self.table.rowCount();self.table.insertRow(r)
        for c,key in enumerate(self.KEYS):
            default="Normal-rate STCG" if key=="tax_category" else (0 if key in {"quantity","cost","sale_value","expenses","stt"} else "")
            self.table.setItem(r,c,table_item(d.get(key,default)))

    def remove_row(self):
        r=self.table.currentRow()
        if r>=0:self.table.removeRow(r);self.update_summary()

    def import_statement(self):
        path,_=QFileDialog.getOpenFileName(self,"Select Capital Gain / Broker Statement","","PDF Files (*.pdf)")
        if not path:return
        dlg=PrivacyImportDialog(self,path,"cg",self.settings)
        if dlg.exec()==QDialog.DialogCode.Accepted:
            txs=dlg.analysis_data.get("transactions",[]) if isinstance(dlg.analysis_data,dict) else []
            if not txs and dlg.analysis_data.get("local_only"):
                QMessageBox.information(self,"Local import","Text was extracted locally. Use API analysis for automatic CG row extraction, or add rows manually.")
            for tx in txs:self.add_row(tx)
            self.import_callback(path,"Capital Gain / Broker Statement","Capital Gains",dlg)
            self.update_summary()

    def rows(self):
        nums={"quantity","cost","sale_value","expenses","stt"};out=[]
        for r in range(self.table.rowCount()):
            d={}
            for c,key in enumerate(self.KEYS):
                val=self.table.item(r,c).text() if self.table.item(r,c) else ""
                d[key]=to_float(val) if key in nums else val
            if d.get("tax_category") not in self.CATEGORIES:d["tax_category"]="Normal-rate STCG"
            out.append(d)
        return out

    def update_summary(self):
        tmp=json_deepcopy(self.case);tmp.setdefault("capital_gains",{})["transactions"]=self.rows();cg=TaxEngine.capital_gains(tmp)
        self.summary.setText(f"Total Gain/(Loss) {money(cg['total_gain'])}   |   STCG Special {money(cg['special_stcg_20'])}   |   Equity LTCG {money(cg['equity_ltcg'])}   |   Other LTCG {money(cg['other_ltcg_12_5'])}")

    def save_accept(self):
        self.case.setdefault("capital_gains",{})["transactions"]=self.rows();self.accept()


class OtherSourcesDialog(QDialog):
    KINDS = ["Savings Bank Interest", "FD Interest", "Bond Interest", "Other Interest", "Dividend", "Other"]
    def __init__(self,parent,case):
        super().__init__(parent);self.case=case;self.setWindowTitle("Income from Other Sources – Detailed Working");self.resize(1180,610)
        root=QVBoxLayout(self)
        banner=QLabel("Bank-fetched interest and dividend are shown bank-wise below. The Computation screen already shows the total auto-fetched amount for Interest and Dividend, so this view focuses on source-wise breakup. Enter or adjust reviewed/additional gross amounts in the lower table. For direct bank-income categories, computation uses the higher of confirmed bank receipts and the reviewed detailed amount.")
        banner.setWordWrap(True);banner.setStyleSheet(f"background:{COLORS['softblue']};padding:10px;border-radius:8px");root.addWidget(banner)

        grp=QGroupBox("Auto-fetched from Bank Statements – Bank-wise breakup");gl=QVBoxLayout(grp)
        self.auto_table=QTableWidget(0,7);self.auto_table.setHorizontalHeaderLabels(["Bank","Savings Interest","FD Interest","Bond Interest","Other Interest","Total Interest","Dividend"]);set_table_defaults(self.auto_table,False)
        self.auto_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.auto_table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        for c in range(1,7): self.auto_table.horizontalHeader().setSectionResizeMode(c,QHeaderView.ResizeMode.ResizeToContents)
        self.auto_table.setMaximumHeight(205)
        gl.addWidget(self.auto_table)
        breakdown=TaxEngine.bank_other_source_breakdown(case,confirmed_only=False)
        self.auto_table.setRowCount(len(breakdown["banks"]))
        for r,b in enumerate(breakdown["banks"]):
            vals=[b["bank"],money(b["savings"]),money(b["fd"]),money(b["bond"]),money(b["other_interest"]),money(b["total_interest"]),money(b["dividend"])]
            for c,v in enumerate(vals):self.auto_table.setItem(r,c,table_item(v,False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter if c else None))
        note=QLabel("Totals are already visible in the Computation tab under Amount Auto Fetched; no duplicate dividend-total line is shown here.")
        note.setObjectName("Muted");gl.addWidget(note);root.addWidget(grp)

        manual_grp=QGroupBox("Reviewed / Additional Details");ml=QVBoxLayout(manual_grp)
        self.table=QTableWidget(0,4);self.table.setHorizontalHeaderLabels(["Kind","Particulars / Bank / Source","Gross Amount","Remarks"]);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);self.table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.Stretch);ml.addWidget(self.table,1)
        row=QHBoxLayout();a=QPushButton("+ Add Detail");a.clicked.connect(self.add_row);d=QPushButton("Remove Selected");d.setObjectName("Danger");d.clicked.connect(lambda:self.table.removeRow(self.table.currentRow()) if self.table.currentRow()>=0 else None);row.addWidget(a);row.addWidget(d);row.addStretch();ml.addLayout(row);root.addWidget(manual_grp,1)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel);bb.accepted.connect(self.save_accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        for x in case.get("other_sources",{}).get("items",[]):self.add_row(x)
    def add_row(self,d=None):
        d=d or {};r=self.table.rowCount();self.table.insertRow(r)
        kind=d.get("kind","Other Interest")
        if kind=="Interest": kind="Other Interest"
        vals=[kind,d.get("particulars",""),d.get("amount",0),d.get("remarks","")]
        for c,v in enumerate(vals):self.table.setItem(r,c,table_item(v))
    def rows(self):
        out=[]
        for r in range(self.table.rowCount()):
            vals=[self.table.item(r,c).text() if self.table.item(r,c) else "" for c in range(4)]
            kind=vals[0] if vals[0] in self.KINDS else ("Other Interest" if "Interest" in vals[0] else "Other")
            out.append({"kind":kind,"particulars":vals[1],"amount":to_float(vals[2]),"remarks":vals[3]})
        return out
    def save_accept(self):self.case.setdefault("other_sources",{})["items"]=self.rows();self.accept()


class AgricultureDialog(QDialog):
    COLS=["Land/Farm","Address/Location","Ownership %","Crop/Activity","Gross Receipts","Expenses","Bank Receipts","Cash Receipts","Remarks"]
    KEYS=["farm","address","ownership_pct","activity","gross_receipts","expenses","bank_receipts","cash_receipts","remarks"]
    def __init__(self,parent,case):
        super().__init__(parent);self.case=case;self.setWindowTitle("Agricultural Income Computation");self.resize(1100,520)
        root=QVBoxLayout(self);b=QLabel("Agricultural income is kept outside Total Income but is considered for partial-integration rate calculation where applicable. Enter gross agricultural receipts and attributable expenses.");b.setWordWrap(True);b.setStyleSheet(f"background:{COLORS['softgreen']};padding:10px;border-radius:8px");root.addWidget(b)
        self.table=QTableWidget(0,len(self.COLS));self.table.setHorizontalHeaderLabels(self.COLS);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents);root.addWidget(self.table,1)
        row=QHBoxLayout();a=QPushButton("+ Add Activity");a.clicked.connect(self.add_row);d=QPushButton("Remove");d.clicked.connect(lambda:self.table.removeRow(self.table.currentRow()) if self.table.currentRow()>=0 else None);row.addWidget(a);row.addWidget(d);row.addStretch();root.addLayout(row)
        self.sum=QLabel();self.sum.setObjectName("SectionTitle");root.addWidget(self.sum)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel);bb.accepted.connect(self.save_accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        for x in case.get("agriculture",{}).get("activities",[]):self.add_row(x)
        self.table.itemChanged.connect(self.update_sum);self.update_sum()
    def add_row(self,d=None):
        d=d or {};r=self.table.rowCount();self.table.insertRow(r)
        for c,key in enumerate(self.KEYS):
            default=100 if key=="ownership_pct" else (0 if key in {"gross_receipts","expenses","bank_receipts","cash_receipts"} else "")
            self.table.setItem(r,c,table_item(d.get(key,default)))
    def rows(self):
        nums={"ownership_pct","gross_receipts","expenses","bank_receipts","cash_receipts"};out=[]
        for r in range(self.table.rowCount()):
            d={}
            for c,key in enumerate(self.KEYS):
                val=self.table.item(r,c).text() if self.table.item(r,c) else "";d[key]=to_float(val) if key in nums else val
            # Apply ownership share to income inputs if not already proportionate.
            out.append(d)
        return out
    def update_sum(self):
        tmp=json_deepcopy(self.case);tmp.setdefault("agriculture",{})["activities"]=self.rows();a=TaxEngine.agriculture(tmp);self.sum.setText(f"Gross {money(a['gross'])}   |   Expenses {money(a['expenses'])}   |   Net Agricultural Income {money(a['net'])}")
    def save_accept(self):self.case.setdefault("agriculture",{})["activities"]=self.rows();self.accept()


class ExemptIncomeDialog(QDialog):
    def __init__(self,parent,case):
        super().__init__(parent);self.case=case;self.setWindowTitle("PPF / Other Exempt Income");self.resize(700,420)
        root=QVBoxLayout(self);self.table=QTableWidget(0,3);self.table.setHorizontalHeaderLabels(["Nature","Amount","Remarks"]);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);root.addWidget(self.table,1)
        row=QHBoxLayout();a=QPushButton("+ Add");a.clicked.connect(self.add_row);d=QPushButton("Remove");d.clicked.connect(lambda:self.table.removeRow(self.table.currentRow()) if self.table.currentRow()>=0 else None);row.addWidget(a);row.addWidget(d);row.addStretch();root.addLayout(row)
        bb=QDialogButtonBox(QDialogButtonBox.StandardButton.Save|QDialogButtonBox.StandardButton.Cancel);bb.accepted.connect(self.save_accept);bb.rejected.connect(self.reject);root.addWidget(bb)
        for x in case.get("exempt_income",{}).get("items",[]):self.add_row(x)
    def add_row(self,d=None):
        d=d or {};r=self.table.rowCount();self.table.insertRow(r);vals=[d.get("nature","PPF Interest"),d.get("amount",0),d.get("remarks","")]
        for c,v in enumerate(vals):self.table.setItem(r,c,table_item(v))
    def rows(self):
        out=[]
        for r in range(self.table.rowCount()):
            vals=[self.table.item(r,c).text() if self.table.item(r,c) else "" for c in range(3)];out.append({"nature":vals[0],"amount":to_float(vals[1]),"remarks":vals[2]})
        return out
    def save_accept(self):self.case.setdefault("exempt_income",{})["items"]=self.rows();self.accept()

# --------------------------------------------------------------------------------------
# Main pages
# --------------------------------------------------------------------------------------
class ComputationPage(QWidget):
    """Single-scroll computation working paper.

    Each actual income head/category carries its own Applicable, Add Details,
    Amount Auto Fetched, New/Old regime result, Status and Remarks controls.
    The statutory working lines sit directly below that head so there is no
    second independent table/scroll area.
    """
    def __init__(self, main):
        super().__init__(); self.main=main; self._building=False; self.row_to_key={}
        root=QVBoxLayout(self); root.setContentsMargins(16,14,16,14); root.setSpacing(8)
        root.addWidget(PageHeader(
            "Computation — Single Working Paper",
            "Each income head carries Add / View Details beside the head. For Salary and House Property, the bank-derived Auto-Fetched amount is shown against the relevant Gross line rather than against the final taxable head. Detailed statutory workings follow immediately below in one compact scroll."
        ))
        k=QHBoxLayout();self.k_new=KPI("New Regime Tax Payable / (Refund)",accent=COLORS["accent"]);self.k_old=KPI("Old Regime Tax Payable / (Refund)",accent=COLORS["purple"]);self.k_low=KPI("Lower Tax Liability",value="—",accent=COLORS["accent2"]);k.addWidget(self.k_new);k.addWidget(self.k_old);k.addWidget(self.k_low);root.addLayout(k)

        info=QLabel("Amount Auto Fetched displays income extracted automatically based on System Suggested Nature & Head. New Regime & Old Regime columns compute taxable income and tax liability strictly when Final Nature & Head of Income are selected/confirmed by the CA/user.")
        info.setWordWrap(True);info.setStyleSheet(f"background:{COLORS['softblue']};padding:9px;border-radius:8px");root.addWidget(info)

        source_bar=QHBoxLayout()
        self.auto_source_label=QLabel("Amount Auto Fetched: System Suggested Nature & Head  |  New & Old Regime: Final Nature & Head of Income")
        self.auto_source_label.setStyleSheet(f"font-weight:700;color:{COLORS['accent']};padding:4px 0px;")
        source_bar.addWidget(self.auto_source_label);source_bar.addStretch()
        root.addLayout(source_bar)

        headers=["Particulars","Applicable?","Add Details","Amount Auto Fetched","New Regime","Old Regime","Status","Remarks"]
        self.table=QTableWidget(0,len(headers));self.table.setHorizontalHeaderLabels(headers);set_table_defaults(self.table,False)
        self.table.verticalHeader().setDefaultSectionSize(30)
        self.table.verticalHeader().setMinimumSectionSize(24)
        h=self.table.horizontalHeader();h.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);h.setSectionResizeMode(1,QHeaderView.ResizeMode.ResizeToContents);h.setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents);h.setSectionResizeMode(3,QHeaderView.ResizeMode.ResizeToContents);h.setSectionResizeMode(4,QHeaderView.ResizeMode.ResizeToContents);h.setSectionResizeMode(5,QHeaderView.ResizeMode.ResizeToContents);h.setSectionResizeMode(6,QHeaderView.ResizeMode.ResizeToContents);h.setSectionResizeMode(7,QHeaderView.ResizeMode.Stretch)
        self.table.itemChanged.connect(self.on_item_changed);root.addWidget(self.table,1)
        note=QLabel("Professional-use safeguard: specialised exemptions, loss carry-forwards, treaty positions, AMT/MAT, surcharge marginal-relief edge cases and uncommon special-rate provisions require CA review. This tool does not file an ITR.")
        note.setWordWrap(True);note.setStyleSheet(f"background:{COLORS['softyellow']};padding:10px;border-radius:8px");root.addWidget(note)

    def values_for_key(self,key,comp):
        if key=="salary":return comp["salary"]["new"],comp["salary"]["old"]
        if key=="house_property":return comp["hp"]["new"],comp["hp"]["old"]
        p=comp["pgbp"]
        if key=="pgbp_regular":return p["regular_new"],p["regular_old"]
        if key=="pgbp_presumptive_business":return p["presumptive_business"],p["presumptive_business"]
        if key=="pgbp_presumptive_profession":return p["presumptive_profession"],p["presumptive_profession"]
        if key=="pgbp_goods_carriage":return p["goods_carriage"],p["goods_carriage"]
        if key=="pgbp_fo":return p["fo"],p["fo"]
        if key=="pgbp_speculative":return p["speculative"],p["speculative"]
        if key=="capital_gains":return comp["cg"]["total_gain"],comp["cg"]["total_gain"]
        if key=="other_interest":return comp["other"]["interest"],comp["other"]["interest"]
        if key=="other_dividend":return comp["other"]["dividend"],comp["other"]["dividend"]
        if key=="other_other":return comp["other"]["other"],comp["other"]["other"]
        if key=="agriculture":return comp["agri"]["net"],comp["agri"]["net"]
        if key=="exempt":return comp["exempt"]["other_exempt"],comp["exempt"]["other_exempt"]
        return 0,0

    def _set_row_style(self,r,kind=""):
        if kind=="section":
            self.table.setRowHeight(r,28)
            for c in range(self.table.columnCount()):
                it=self.table.item(r,c)
                if it is None:
                    it=table_item("",False);self.table.setItem(r,c,it)
                it.setBackground(QColor("#E8EDF5"));it.setFont(QFont("Segoe UI",10,QFont.Weight.Bold))
        elif kind in ("total","grand"):
            self.table.setRowHeight(r,30)
            bg=QColor("#E8F8F1" if kind=="grand" else "#F2F6FC")
            for c in range(self.table.columnCount()):
                it=self.table.item(r,c)
                if it is None:
                    it=table_item("",False);self.table.setItem(r,c,it)
                it.setBackground(bg);it.setFont(QFont("Segoe UI",10,QFont.Weight.Bold))

    def _append_section(self,name):
        r=self.table.rowCount();self.table.insertRow(r)
        self.table.setItem(r,0,table_item(name,False))
        for c in range(1,self.table.columnCount()):self.table.setItem(r,c,table_item("",False))
        self._set_row_style(r,"section");return r

    def _append_detail(self,name,nv=None,ov=None,kind="",indent=True,auto_value=None,auto_tooltip=""):
        r=self.table.rowCount();self.table.insertRow(r);self.table.setRowHeight(r,28);label=("    "+name) if indent else name
        self.table.setItem(r,0,table_item(label,False))
        self.table.setItem(r,1,table_item("",False));self.table.setItem(r,2,table_item("",False))
        if auto_value is None:
            auto_txt = ""
        elif isinstance(auto_value, str):
            auto_txt = auto_value
        else:
            auto_txt = money(auto_value) if abs(to_float(auto_value)) >= 0.005 else "—"
        auto_it = table_item(auto_txt,False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter)
        if auto_tooltip: auto_it.setToolTip(auto_tooltip)
        self.table.setItem(r,3,auto_it)
        self.table.setItem(r,4,table_item("" if nv is None else money(nv),False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter))
        self.table.setItem(r,5,table_item("" if ov is None else money(ov),False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter))
        self.table.setItem(r,6,table_item("",False));self.table.setItem(r,7,table_item("",False))
        if kind:self._set_row_style(r,kind)
        return r

    def _append_income_row(self,key,label,comp,auto,exempt=False,show_auto=True):
        r=self.table.rowCount();self.table.insertRow(r);self.table.setRowHeight(r,36);self.row_to_key[r]=key
        name_item=table_item(label,False);name_item.setFont(QFont("Segoe UI",10,QFont.Weight.Bold));name_item.setBackground(QColor("#F7FAFD"));self.table.setItem(r,0,name_item)
        ap=self.main.case["income_applicability"].setdefault(key,{"applicable":"No","status":"Not Applicable","remarks":""})
        cb=QComboBox();cb.addItems(["No","Yes","Review"]);cb.setCurrentText(ap.get("applicable","No"));cb.setFixedHeight(30);bind_combo_tooltip(cb);cb.currentTextChanged.connect(lambda val,k=key:self.change_app(k,val));self.table.setCellWidget(r,1,cb)
        btn=QPushButton("Add / View Details");btn.setMinimumWidth(145);btn.setFixedHeight(30);btn.clicked.connect(lambda checked=False,k=key:self.open_details(k));self.table.setCellWidget(r,2,btn)
        a=auto.get(key,0) if show_auto else 0
        if not show_auto:
            auto_str = ""
        elif key=="capital_gains":
            auto_str = f"Receipts: {money(a)}" if a else "Receipts: —"
        elif key=="pgbp_presumptive_business":
            auto_str = f"R: {money(a)} | I: {money(a * TAX_PARAMS['presumptive_business_other'])}" if a else "—"
        elif key=="pgbp_presumptive_profession":
            auto_str = f"R: {money(a)} | I: {money(a * TAX_PARAMS['presumptive_profession'])}" if a else "—"
        else:
            auto_str = money(a) if a else "—"

        auto_item=table_item(auto_str,False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter)
        if key=="capital_gains":
            auto_item.setToolTip("Bank receipt / redemption control for Capital Gains.")
        elif key=="pgbp_presumptive_business":
            auto_item.setToolTip("R: Bank Receipts | I: Deemed Income at default 8% (or 6% for digital).")
        elif key=="pgbp_presumptive_profession":
            auto_item.setToolTip("R: Bank Receipts | I: Deemed Income at default 50%.")
        elif key.startswith("pgbp_"):
            auto_item.setToolTip("Bank receipt/control only. Taxable PGBP comes from Add Details.")
        else:
            auto_item.setToolTip("Auto-fetched from system suggested bank classifications; New/Old regime tax comes when Final Nature & Head are selected.")
        self.table.setItem(r,3,auto_item)
        nv,ov=self.values_for_key(key,comp)
        self.table.setItem(r,4,table_item("Exempt" if exempt else money(nv),False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter))
        self.table.setItem(r,5,table_item("Exempt" if exempt else money(ov),False,Qt.AlignmentFlag.AlignRight|Qt.AlignmentFlag.AlignVCenter))
        st=QComboBox();st.addItems(STATUS_OPTIONS);st.setCurrentText(ap.get("status","Not Applicable"));st.setFixedHeight(30);bind_combo_tooltip(st);st.currentTextChanged.connect(lambda val,k=key:self.change_status(k,val));self.table.setCellWidget(r,6,st)
        rem=table_item(ap.get("remarks",""));rem.setBackground(QColor("#FFFDF6"));self.table.setItem(r,7,rem)
        return r

    def change_app(self,key,val):
        if self._building:return
        ap=self.main.case["income_applicability"][key];ap["applicable"]=val
        if val=="No":ap["status"]="Not Applicable"
        elif ap.get("status")=="Not Applicable":ap["status"]="Review"
        self.main.mark_dirty();self.main.refresh_all()

    def change_status(self,key,val):
        if self._building:return
        self.main.case["income_applicability"][key]["status"]=val;self.main.mark_dirty()

    def on_item_changed(self,item):
        if self._building or item.column()!=7:return
        key=self.row_to_key.get(item.row())
        if key:
            self.main.case["income_applicability"][key]["remarks"]=item.text();self.main.mark_dirty()

    def open_details(self,key):
        dlg=None
        if key=="salary":dlg=SalaryDialog(self,self.main.case)
        elif key=="house_property":dlg=HousePropertyDialog(self,self.main.case)
        elif key.startswith("pgbp_"):dlg=PGBPDialog(self,self.main.case,self.main.runtime_settings(),self.main.register_imported_document)
        elif key=="capital_gains":dlg=CapitalGainsDialog(self,self.main.case,self.main.runtime_settings(),self.main.register_imported_document)
        elif key in ("other_interest","other_dividend","other_other"):dlg=OtherSourcesDialog(self,self.main.case)
        elif key=="agriculture":dlg=AgricultureDialog(self,self.main.case)
        elif key=="exempt":dlg=ExemptIncomeDialog(self,self.main.case)
        if dlg and dlg.exec()==QDialog.DialogCode.Accepted:
            self.main.case["income_applicability"][key]["applicable"]="Yes";self.main.case["income_applicability"][key]["status"]="Complete";self.main.mark_dirty();self.main.refresh_all()

    def refresh(self):
        comp=TaxEngine.compute(self.main.case);n=comp["new"];o=comp["old"];sal=comp["salary"];hp=comp["hp"];p=comp["pgbp"];cg=comp["cg"];other=comp["other"];ag=comp["agri"];ex=comp["exempt"]
        self.k_new.set_value(money(n["payable"]));self.k_old.set_value(money(o["payable"]))
        if n["tax_liability"] < o["tax_liability"]: low="New Regime"
        elif o["tax_liability"] < n["tax_liability"]: low="Old Regime"
        else: low="Same"
        self.k_low.set_value(low)
        self._building=True
        auto=TaxEngine.bank_detected_by_income_key(self.main.case,use_final=False)
        auto_comp=TaxEngine.auto_fetched_computation(self.main.case,use_final=False);an=auto_comp["new"];ao=auto_comp["old"];asal=auto_comp["salary"];ahp=auto_comp["hp"];aother=auto_comp["other"];aag=auto_comp["agri"]
        pair=TaxEngine._auto_pair_text
        self.row_to_key={};self.table.blockSignals(True);self.table.clearContents();self.table.setRowCount(0)

        # Salary: the actual head row carries all controls, its statutory deductions sit below it.
        self._append_income_row("salary","Income from Salary",comp,auto,show_auto=False)
        self._append_detail("Gross Salary",sal["gross"],sal["gross"],auto_value=asal["gross"],auto_tooltip="Salary credits from the selected bank classification source. The Auto-Fetched column then applies salary deductions below to produce a full review computation.")
        self._append_detail("Less: Eligible salary exemptions",sal["exemptions_new"],sal["exemptions_old"],auto_value=pair(asal["exemptions_new"],asal["exemptions_old"]))
        self._append_detail("Less: Standard Deduction",sal["std_new"],sal["std_old"],auto_value=pair(asal["std_new"],asal["std_old"]),auto_tooltip="Auto-computed separately for New and Old regime from the bank-derived Gross Salary.")
        self._append_detail("Less: Professional Tax",0,sal["professional_tax"],auto_value=pair(0,asal["professional_tax"]))
        self._append_detail("Less: Other Salary deductions",sal["other_new"],sal["other_old"],auto_value=pair(asal["other_new"],asal["other_old"]))

        # House property: one head row + visible statutory working immediately below.
        self._append_income_row("house_property","Income/(Loss) from House Property",comp,auto,show_auto=False)
        gav=sum(x["gav"]*x["share"] for x in hp["rows"]);mun=sum(x["municipal"]*x["share"] for x in hp["rows"]);std=sum(x["std"]*x["share"] for x in hp["rows"]);intn=sum(x["interest_new"]*x["share"] for x in hp["rows"]);into=sum(x["interest_old"]*x["share"] for x in hp["rows"]);arr=sum(x["arrears_taxable"]*x["share"] for x in hp["rows"])
        self._append_detail("Gross Annual Value",gav,gav,auto_value=ahp["gav"],auto_tooltip="Rent receipts from the selected bank classification source. The Auto-Fetched column carries this through municipal taxes, NAV, 30% standard deduction and interest below.")
        self._append_detail("Less: Municipal / Local Authority Taxes",mun,mun,auto_value=ahp["municipal"])
        self._append_detail("Net Annual Value",gav-mun,gav-mun,auto_value=ahp["nav"])
        self._append_detail("Less: 30% Standard Deduction",std,std,auto_value=ahp["std"],auto_tooltip="30% of the Auto-Fetched Net Annual Value.")
        self._append_detail("Less: Interest / Pre-construction Interest",intn,into,auto_value=pair(ahp["interest_new"],ahp["interest_old"]))
        self._append_detail("Add: Taxable Arrears / Unrealised Rent Recovery",arr,arr,auto_value=ahp["arrears"])

        self._append_section("PROFITS & GAINS OF BUSINESS OR PROFESSION")
        for key,label in [
            ("pgbp_regular","PGBP – Regular Books"),
            ("pgbp_presumptive_business","PGBP – Presumptive Business"),
            ("pgbp_presumptive_profession","PGBP – Presumptive Profession"),
            ("pgbp_goods_carriage","PGBP – Goods Carriage"),
            ("pgbp_fo","PGBP – F&O"),
            ("pgbp_speculative","PGBP – Speculative / Intraday"),
        ]: self._append_income_row(key,label,comp,auto)
        self._append_detail("Total PGBP",p["new"],p["old"],"total",False,auto_value=pair(auto_comp["pgbp"]["new"],auto_comp["pgbp"]["old"]),auto_tooltip="Taxable PGBP from Add Details. Bank PGBP receipts above remain reconciliation controls only.")

        self._append_section("CAPITAL GAINS")
        self._append_income_row("capital_gains","Total Capital Gain/(Loss)",comp,auto)
        self._append_detail("Normal-rate STCG",cg["normal_stcg"],cg["normal_stcg"],auto_value=cg["normal_stcg"],auto_tooltip="From Capital Gains Add Details; bank sale/redemption receipts are not treated as gain.")
        self._append_detail("STCG – Special 20%",cg["special_stcg_20"],cg["special_stcg_20"],auto_value=cg["special_stcg_20"])
        self._append_detail("LTCG – Equity (gross gain)",cg["equity_ltcg"],cg["equity_ltcg"],auto_value=cg["equity_ltcg"])
        self._append_detail("LTCG – Equity taxable after ₹1.25L threshold",cg["equity_ltcg_taxable"],cg["equity_ltcg_taxable"],auto_value=cg["equity_ltcg_taxable"])
        self._append_detail("LTCG – Other 12.5%",cg["other_ltcg_12_5"],cg["other_ltcg_12_5"],auto_value=cg["other_ltcg_12_5"])

        self._append_section("INCOME FROM OTHER SOURCES")
        self._append_income_row("other_interest","Interest Income",comp,auto)
        self._append_income_row("other_dividend","Dividend Income",comp,auto)
        self._append_income_row("other_other","Other Income",comp,auto)
        self._append_detail("Total Other Sources",other["total"],other["total"],"total",False,auto_value=aother["total"])

        self._append_section("TOTAL INCOME & TAX")
        self._append_detail("Gross Total Income",n["gross_total_income"],o["gross_total_income"],"total",False,auto_value=pair(an["gross_total_income"],ao["gross_total_income"]))
        self._append_detail("Less: Deductions",n["deductions"],o["deductions"],"",False,auto_value=pair(an["deductions"],ao["deductions"]))
        self._append_detail("Total Income",n["total_income"],o["total_income"],"total",False,auto_value=pair(an["total_income"],ao["total_income"]))
        self._append_detail("Tax at Normal Rates / Agricultural Rate Effect",n["normal_tax"],o["normal_tax"],"",False,auto_value=pair(an["normal_tax"],ao["normal_tax"]))
        self._append_detail("Tax at Special Rates",n["special_tax"],o["special_tax"],"",False,auto_value=pair(an["special_tax"],ao["special_tax"]))
        self._append_detail("Less: Rebate",n["rebate"],o["rebate"],"",False,auto_value=pair(an["rebate"],ao["rebate"]))
        self._append_detail("Surcharge",n["surcharge"],o["surcharge"],"",False,auto_value=pair(an["surcharge"],ao["surcharge"]))
        self._append_detail("Health & Education Cess @ 4%",n["cess"],o["cess"],"",False,auto_value=pair(an["cess"],ao["cess"]))
        self._append_detail("Total Tax Liability",n["tax_liability"],o["tax_liability"],"total",False,auto_value=pair(an["tax_liability"],ao["tax_liability"]),auto_tooltip="Full tax liability computed from the Auto-Fetched review base for both regimes.")
        self._append_detail("Less: TDS/TCS/Advance/SAT",n["taxes_paid"],o["taxes_paid"],"",False,auto_value=pair(an["taxes_paid"],ao["taxes_paid"]))
        self._append_detail("Tax Payable / (Refund)",n["payable"],o["payable"],"grand",False,auto_value=pair(an["payable"],ao["payable"]),auto_tooltip="Auto-Fetched review computation payable/refund for New and Old regime.")

        self._append_section("EXEMPT INCOME / INCOME NOT FORMING PART OF TOTAL INCOME")
        self._append_income_row("agriculture","Agricultural Income",comp,auto,True)
        self._append_income_row("exempt","PPF / Other Exempt Income",comp,auto,True)
        self._append_detail("Total Exempt Income",ag["net"]+ex["other_exempt"],ag["net"]+ex["other_exempt"],"total",False,auto_value=aag["net"]+auto_comp["exempt"])

        self.table.blockSignals(False);self._building=False


class BankTableWidget(QWidget):
    def __init__(self,main,bank_index):
        super().__init__();self.main=main;self.bank_index=bank_index;self._loading=False
        root=QVBoxLayout(self);root.setContentsMargins(8,8,8,8)
        bar=QHBoxLayout();self.search=QLineEdit();self.search.setPlaceholderText("Search narration / suggested nature / final nature / head…");self.search.textChanged.connect(self.apply_filter);self.credits=QCheckBox("Credits only");self.credits.stateChanged.connect(self.apply_filter);bar.addWidget(self.search,1);bar.addWidget(self.credits);root.addLayout(bar)
        cols=["Sr. No.","Transaction Date","Narration","Debit","Credit","Balance","System Suggested Nature","Final Nature","Head of Income","Remarks"]
        self.table=QTableWidget(0,len(cols));self.table.setHorizontalHeaderLabels(cols);set_table_defaults(self.table)
        self.table.verticalHeader().setDefaultSectionSize(38);self.table.verticalHeader().setMinimumSectionSize(34)
        h=self.table.horizontalHeader()
        h.setSectionResizeMode(0,QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(1,QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(2,QHeaderView.ResizeMode.Interactive)
        h.setSectionResizeMode(3,QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(4,QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(5,QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(6,QHeaderView.ResizeMode.Interactive)
        h.setSectionResizeMode(7,QHeaderView.ResizeMode.Interactive)
        h.setSectionResizeMode(8,QHeaderView.ResizeMode.Interactive)
        h.setSectionResizeMode(9,QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(2,460)
        self.table.setColumnWidth(6,235)
        self.table.setColumnWidth(7,245)
        self.table.setColumnWidth(8,240)
        root.addWidget(self.table,1)
        self.table.itemChanged.connect(self.item_changed);self.refresh()

    def bank(self):return self.main.case["banks"][self.bank_index]

    def _suggested_head(self,tx):
        nature=str(tx.get("suggested_nature") or "").strip()
        head=str(tx.get("suggested_head") or "").strip()
        if (not head or head not in HEADS) and nature:
            head=default_head_for_nature(nature)
        if head and head in HEADS:
            tx["suggested_head"]=head
        return head

    def _adjust_narration_width(self):
        """Fit Narration to actual content, cap it, and keep it user-resizable."""
        try:
            self.table.resizeColumnToContents(2)
            fitted=self.table.columnWidth(2)+24
            self.table.setColumnWidth(2,max(420,min(720,fitted)))
        except Exception:
            self.table.setColumnWidth(2,500)

    def _apply_head_mismatch_style(self,r):
        tx=self.bank()["transactions"][r]
        suggested=self._suggested_head(tx)
        final=str(tx.get("head") or "").strip()
        actual_suggested=suggested not in ("","Pending Review")
        actual_final=final not in ("","Pending Review")
        mismatch=actual_suggested and actual_final and suggested!=final
        head_combo=self.table.cellWidget(r,8)
        if isinstance(head_combo,QComboBox):
            if mismatch:
                head_combo.setStyleSheet(f"QComboBox {{background:{COLORS['softred']};color:{COLORS['danger']};border:1px solid {COLORS['danger']};border-radius:7px;padding:6px 8px;font-weight:700;}}")
                head_combo.setToolTip(f"Final Head: {final}\nSystem Suggested Head: {suggested}\nMismatch — review this classification.")
            else:
                head_combo.setStyleSheet("");head_combo.setToolTip(final)

    def refresh(self):
        self._loading=True;txs=self.bank().get("transactions",[]);self.table.setRowCount(len(txs))
        for r,tx in enumerate(txs):
            self._suggested_head(tx)
            vals=[r+1,tx.get("date",""),tx.get("narration",""),money(tx.get("debit",0)) if to_float(tx.get("debit")) else "",money(tx.get("credit",0)) if to_float(tx.get("credit")) else "",money(tx.get("balance",0)) if str(tx.get("balance","")) not in ("","0","0.0") else "",tx.get("suggested_nature","")]
            for c,v in enumerate(vals):
                self.table.setItem(r,c,table_item(v,editable=(c in [1,2,3,4,5])))
            nature=QComboBox();nature.addItems(FINAL_NATURES);current=tx.get("final_nature") or tx.get("suggested_nature") or ""
            if current and current not in FINAL_NATURES:nature.addItem(current)
            nature.setCurrentText(current if current else "")
            make_table_combo_readable(nature,FINAL_NATURES,height=34,popup_min_width=390)
            nature.currentTextChanged.connect(lambda val,rr=r:self.combo_change(rr,"final_nature",val));self.table.setCellWidget(r,7,nature)
            head=QComboBox();head.addItems(HEADS);curh=tx.get("head") or tx.get("suggested_head") or default_head_for_nature(current) or "Pending Review";head.setCurrentText(curh if curh in HEADS else "Pending Review")
            make_table_combo_readable(head,HEADS,height=34,popup_min_width=315)
            head.currentTextChanged.connect(lambda val,rr=r:self.combo_change(rr,"head",val));self.table.setCellWidget(r,8,head)
            self.table.setItem(r,9,table_item(tx.get("remarks","")))
            self.table.setRowHeight(r,38)
            self._apply_head_mismatch_style(r)
        self._adjust_narration_width()
        self._loading=False;self.apply_filter()

    def combo_change(self,r,key,val):
        if self._loading:return
        tx=self.bank()["transactions"][r]
        if key=="final_nature" and val=="Other":
            custom,ok=large_text_input(self,"Other Nature","Enter custom nature / description:",tx.get("final_nature", ""))
            if ok and custom.strip():
                val=custom.strip()
                nature=self.table.cellWidget(r,7)
                if isinstance(nature,QComboBox):
                    nature.blockSignals(True)
                    if nature.findText(val)<0:nature.addItem(val)
                    nature.setCurrentText(val);nature.blockSignals(False)
            else:
                val=""
        tx[key]=val
        if key=="final_nature" and val:
            final_head=default_head_for_nature(val)
            tx["head"]=final_head
            head=self.table.cellWidget(r,8)
            if isinstance(head,QComboBox):
                head.blockSignals(True);head.setCurrentText(final_head);head.blockSignals(False)

        # Auto sync consider state based on head
        cur_head = tx.get("head", "")
        if cur_head in {"Salary", "House Property", "PGBP", "Capital Gains", "Other Sources", "Agricultural Income – Exempt", "Other Exempt Income"}:
            tx["consider"] = "Yes"
        elif cur_head in {"Not Income", "Opening Balance", "Closing Balance"}:
            tx["consider"] = "No"
        else:
            tx["consider"] = "Review"

        self._apply_head_mismatch_style(r)
        self.main.mark_dirty();self.main.refresh_all(except_bank=True)

    def item_changed(self,item):
        if self._loading:return
        r,c=item.row(),item.column();tx=self.bank()["transactions"][r]
        if c==9:
            tx["remarks"]=item.text()
        elif c in (1,2,3,4,5):
            key={1:"date",2:"narration",3:"debit",4:"credit",5:"balance"}[c]
            tx[key]=to_float(item.text().replace(",","")) if c in (3,4,5) else item.text().strip()
            if c==2:self._adjust_narration_width()
        else:
            return
        self.main.mark_dirty();self.main.refresh_all(except_bank=True)

    def apply_filter(self):
        q=self.search.text().lower().strip();credit_only=self.credits.isChecked()
        for r,tx in enumerate(self.bank().get("transactions",[])):
            blob=" ".join(str(tx.get(k,"")) for k in ["narration","suggested_nature","suggested_head","final_nature","head","remarks"]).lower()
            hide=(q and q not in blob) or (credit_only and to_float(tx.get("credit"))<=0);self.table.setRowHidden(r,bool(hide))
            blob=" ".join(str(tx.get(k,"")) for k in ["narration","suggested_nature","suggested_head","final_nature","head","remarks"]).lower()
            hide=(q and q not in blob) or (credit_only and to_float(tx.get("credit"))<=0);self.table.setRowHidden(r,bool(hide))


class BankStatementsPage(QWidget):
    def __init__(self,main):
        super().__init__();self.main=main
        root=QVBoxLayout(self);root.setContentsMargins(18,18,18,18)
        add=QPushButton("+ Import Bank Statement");add.setObjectName("Primary");add.clicked.connect(self.import_bank)
        export_review=QPushButton("Export Client Review Excel");export_review.clicked.connect(self.main.export_bank_review_excel)
        import_review=QPushButton("Import Client Review Excel");import_review.clicked.connect(self.main.import_bank_review_excel)
        root.addWidget(PageHeader("Bank Statements", "Import locally before API or analyse with API. At either stage, export a client-review Excel with dropdowns and re-import the client's classifications into these same bank transactions.",[add,export_review,import_review]))
        self.tabs=QTabWidget();root.addWidget(self.tabs,1)
    def refresh(self):
        while self.tabs.count():self.tabs.removeTab(0)
        for i,b in enumerate(self.main.case.get("banks",[])):
            name=b.get("bank_name") or f"Bank {i+1}";self.tabs.addTab(BankTableWidget(self.main,i),name[:30])
        if not self.main.case.get("banks"):
            lab=QLabel("No bank statement imported. Click ‘Import Bank Statement’.\n\nThe PDF is extracted locally first; sensitive information is highlighted in yellow before any API analysis.");lab.setAlignment(Qt.AlignmentFlag.AlignCenter);lab.setStyleSheet(f"color:{COLORS['muted']};font-size:12pt;padding:40px");self.tabs.addTab(lab,"Start")
    def import_bank(self):
        path,_=QFileDialog.getOpenFileName(self,"Select Bank Statement","","PDF Files (*.pdf)")
        if not path:return
        dlg=PrivacyImportDialog(self,path,"bank",self.main.runtime_settings())
        if dlg.exec()!=QDialog.DialogCode.Accepted:return
        d=dlg.analysis_data or {};txs=d.get("transactions",[])
        bank={"bank_name":d.get("bank_name") or Path(path).stem,"account_masked":d.get("account_masked",""),"statement_from":d.get("statement_from",""),"statement_to":d.get("statement_to",""),"opening_balance":to_float(d.get("opening_balance",0)),"closing_balance":to_float(d.get("closing_balance",0)),"source_file":Path(path).name,"transactions":[]}
        for tx in txs:
            suggested_nature=str(tx.get("suggested_nature") or "").strip()
            suggested_head=str(tx.get("suggested_head") or "").strip()
            if (not suggested_head or suggested_head not in HEADS) and suggested_nature:
                suggested_head=default_head_for_nature(suggested_nature)
            final_nat = str(tx.get("final_nature","")).strip()
            final_h = str(tx.get("head","")).strip()
            cons_val = str(tx.get("consider","Review")).strip()
            bank["transactions"].append({"date":tx.get("date",""),"narration":tx.get("narration",""),"debit":to_float(tx.get("debit")),"credit":to_float(tx.get("credit")),"balance":to_float(tx.get("balance")),"suggested_nature":suggested_nature,"suggested_head":suggested_head,"final_nature":final_nat if final_nat in FINAL_NATURES else suggested_nature,"head":final_h if final_h in HEADS else (suggested_head if suggested_head in HEADS else "Pending Review"),"consider":cons_val if cons_val in CONSIDER_OPTIONS else "Review","remarks":tx.get("remarks","")})
        self.main.case.setdefault("banks",[]).append(bank);self.main.register_imported_document(path,"Bank Statement","Bank Review / Income Detection",dlg);self.main.mark_dirty();self.main.refresh_all()


class DeductionsPage(QWidget):
    def __init__(self,main):
        super().__init__();self.main=main;self._load=False
        root=QVBoxLayout(self);root.setContentsMargins(18,18,18,18)
        add=QPushButton("+ Add Deduction");add.clicked.connect(self.add_row);rem=QPushButton("Remove Selected");rem.setObjectName("Danger");rem.clicked.connect(self.remove_row)
        root.addWidget(PageHeader("Deductions", "Enter deduction evidence and mark eligibility separately for New and Old Regime. New-regime eligibility should be used only for deductions permitted by section 202(2).",[add,rem]))
        self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(["Deduction / Particulars","Section / Reference","Amount","Allowed – New","Allowed – Old","Remarks"]);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch);self.table.horizontalHeader().setSectionResizeMode(5,QHeaderView.ResizeMode.Stretch);root.addWidget(self.table,1);self.table.itemChanged.connect(self.changed)
    def refresh(self):
        self._load=True;ds=self.main.case.get("deductions",[]);self.table.setRowCount(len(ds))
        for r,d in enumerate(ds):
            self.table.setItem(r,0,table_item(d.get("particulars","")));self.table.setItem(r,1,table_item(d.get("section","")));self.table.setItem(r,2,table_item(d.get("amount",0)))
            cn=QCheckBox();cn.setChecked(bool(d.get("allow_new",False)));cn.stateChanged.connect(lambda _,rr=r,cb=cn:self.check(rr,"allow_new",cb.isChecked()));self.table.setCellWidget(r,3,cn)
            co=QCheckBox();co.setChecked(bool(d.get("allow_old",True)));co.stateChanged.connect(lambda _,rr=r,cb=co:self.check(rr,"allow_old",cb.isChecked()));self.table.setCellWidget(r,4,co)
            self.table.setItem(r,5,table_item(d.get("remarks","")))
        self._load=False
    def add_row(self):self.main.case.setdefault("deductions",[]).append({"particulars":"","section":"","amount":0,"allow_new":False,"allow_old":True,"remarks":""});self.main.mark_dirty();self.refresh()
    def remove_row(self):
        r=self.table.currentRow()
        if r>=0:self.main.case["deductions"].pop(r);self.main.mark_dirty();self.main.refresh_all()
    def check(self,r,key,val):
        if self._load:return
        self.main.case["deductions"][r][key]=val;self.main.mark_dirty();self.main.refresh_all(except_deductions=True)
    def changed(self,item):
        if self._load:return
        r=item.row();key={0:"particulars",1:"section",2:"amount",5:"remarks"}.get(item.column())
        if key:self.main.case["deductions"][r][key]=to_float(item.text()) if key=="amount" else item.text();self.main.mark_dirty();self.main.refresh_all(except_deductions=True)


class TaxesPage(QWidget):
    def __init__(self,main):
        super().__init__();self.main=main;self._load=False
        root=QVBoxLayout(self);root.setContentsMargins(18,18,18,18)
        add=QPushButton("+ Add Tax Credit / Payment");add.clicked.connect(self.add_row);rem=QPushButton("Remove Selected");rem.setObjectName("Danger");rem.clicked.connect(self.remove_row)
        root.addWidget(PageHeader("Taxes Paid", "TDS, TCS, Advance Tax and Self-Assessment Tax.",[add,rem]))
        self.table=QTableWidget(0,6);self.table.setHorizontalHeaderLabels(["Type","Deductor / Challan","Date","Amount","Verified?","Remarks"]);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);self.table.horizontalHeader().setSectionResizeMode(5,QHeaderView.ResizeMode.Stretch);root.addWidget(self.table,1);self.table.itemChanged.connect(self.changed)
    def refresh(self):
        self._load=True;xs=self.main.case.get("taxes_paid",[]);self.table.setRowCount(len(xs))
        for r,x in enumerate(xs):
            cb=QComboBox();cb.addItems(["TDS","TCS","Advance Tax","Self-Assessment Tax"]);cb.setCurrentText(x.get("type","TDS"));cb.currentTextChanged.connect(lambda val,rr=r:self.combo(rr,val));self.table.setCellWidget(r,0,cb)
            for c,key in [(1,"reference"),(2,"date"),(3,"amount"),(5,"remarks")]:self.table.setItem(r,c,table_item(x.get(key,"" if key!="amount" else 0)))
            ck=QCheckBox();ck.setChecked(bool(x.get("verified",False)));ck.stateChanged.connect(lambda _,rr=r,cb=ck:self.verify(rr,cb.isChecked()));self.table.setCellWidget(r,4,ck)
        self._load=False
    def add_row(self):self.main.case.setdefault("taxes_paid",[]).append({"type":"TDS","reference":"","date":"","amount":0,"verified":False,"remarks":""});self.main.mark_dirty();self.refresh()
    def remove_row(self):
        r=self.table.currentRow()
        if r>=0:self.main.case["taxes_paid"].pop(r);self.main.mark_dirty();self.main.refresh_all()
    def combo(self,r,val):
        if not self._load:self.main.case["taxes_paid"][r]["type"]=val;self.main.mark_dirty();self.main.refresh_all(except_taxes=True)
    def verify(self,r,val):
        if not self._load:self.main.case["taxes_paid"][r]["verified"]=val;self.main.mark_dirty()
    def changed(self,item):
        if self._load:return
        key={1:"reference",2:"date",3:"amount",5:"remarks"}.get(item.column())
        if key:self.main.case["taxes_paid"][item.row()][key]=to_float(item.text()) if key=="amount" else item.text();self.main.mark_dirty();self.main.refresh_all(except_taxes=True)


class DocumentsPage(QWidget):
    def __init__(self,main):
        super().__init__();self.main=main;root=QVBoxLayout(self);root.setContentsMargins(18,18,18,18);root.addWidget(PageHeader("Documents Used","Source-document register and privacy/API audit trail."));self.table=QTableWidget(0,11);self.table.setHorizontalHeaderLabels(["Sr.","Document Type","Document Name","Tax Year","Used For","Python Extracted","Sensitive Data Reviewed","Redacted Before API","API Analysed","Status","Remarks"]);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.Stretch);self.table.horizontalHeader().setSectionResizeMode(10,QHeaderView.ResizeMode.Stretch);root.addWidget(self.table,1)
    def refresh(self):
        docs=self.main.case.get("documents",[]);self.table.setRowCount(len(docs))
        for r,d in enumerate(docs):
            vals=[r+1,d.get("document_type",""),d.get("document_name",""),d.get("tax_year",TAX_YEAR),d.get("used_for",""),d.get("python_extracted",""),d.get("sensitive_review",""),d.get("redacted",""),d.get("api_analysed",""),d.get("status",""),d.get("remarks","")]
            for c,v in enumerate(vals):self.table.setItem(r,c,table_item(v,False))


class ReviewPage(QWidget):
    def __init__(self,main):
        super().__init__();self.main=main;root=QVBoxLayout(self);root.setContentsMargins(18,18,18,18);root.addWidget(PageHeader("Review & Reconciliation","Automatically surfaces pending bank classifications, missing supporting details and schedule/bank differences."));self.table=QTableWidget(0,5);self.table.setHorizontalHeaderLabels(["Area","Issue","Amount / Difference","Status","Remarks"]);set_table_defaults(self.table);self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.Stretch);self.table.horizontalHeader().setSectionResizeMode(4,QHeaderView.ResizeMode.Stretch);root.addWidget(self.table,1)
    def issues(self):
        issues=[];comp=TaxEngine.compute(self.main.case);bank=comp["bank"]
        for b in self.main.case.get("banks",[]):
            for tx in b.get("transactions",[]):
                if to_float(tx.get("credit"))>0 and (tx.get("consider","Review")=="Review" or tx.get("head") in ("","Pending Review")):
                    issues.append((b.get("bank_name","Bank"),f"Credit pending classification: {str(tx.get('narration',''))[:70]}",to_float(tx.get("credit")),"Pending",tx.get("remarks","")))
        # Salary control
        if comp["salary"]["gross"] and bank["salary"]:
            diff=comp["salary"]["gross"]-bank["salary"]
            if abs(diff)>1:issues.append(("Salary","Gross salary vs bank salary credits (control only)",diff,"Review","Net salary credits need not equal gross salary."))
        # HP property controls
        for x in comp["hp"]["rows"]:
            if x["bank_rent"]:
                diff=(x["gav"]-x["bank_rent"])
                if abs(diff)>1:issues.append(("House Property",f"Rent working vs bank control: {x['address'][:50]}",diff,"Review","Check timing/TDS/security deposit/cash receipt."))
        # Applicable without details
        detail_presence={"salary":bool(self.main.case.get("salary",{}).get("employers")),"house_property":bool(self.main.case.get("house_property",{}).get("properties")),"capital_gains":bool(self.main.case.get("capital_gains",{}).get("transactions")),"agriculture":bool(self.main.case.get("agriculture",{}).get("activities"))}
        for key,present in detail_presence.items():
            if self.main.case["income_applicability"].get(key,{}).get("applicable")=="Yes" and not present:issues.append((dict(INCOME_KEYS).get(key,key),"Applicable = Yes but detailed working is empty",0,"Pending","Add details."))
        return issues
    def refresh(self):
        xs=self.issues();self.table.setRowCount(len(xs))
        for r,x in enumerate(xs):
            for c,v in enumerate(x):self.table.setItem(r,c,table_item(money(v) if c==2 and isinstance(v,(int,float)) and v else ("—" if c==2 else v),False))
        if not xs:self.table.setRowCount(1);self.table.setItem(0,0,table_item("✓",False));self.table.setItem(0,1,table_item("No automatic review exceptions currently detected.",False));self.table.setItem(0,2,table_item("",False));self.table.setItem(0,3,table_item("Clear",False));self.table.setItem(0,4,table_item("",False))


class SettingsPage(QWidget):
    def __init__(self,main):
        super().__init__();self.main=main
        root=QVBoxLayout(self);root.setContentsMargins(18,18,18,18);root.addWidget(PageHeader("Settings / API","API is optional and used only after local extraction and privacy review."))
        card=Card();form=QFormLayout();card.layout_.addLayout(form)
        self.provider=QComboBox();self.provider.addItems(["Gemini","OpenAI"]);self.model=QLineEdit();self.key=QLineEdit();self.key.setEchoMode(QLineEdit.EchoMode.Password);self.remember=QCheckBox("Remember API key in local JSON (plain text; not recommended)");self.privacy=QComboBox();self.privacy.addItems(["Always review before API","Redact detected information by default","Do not redact automatically"])
        form.addRow("API Provider",self.provider);form.addRow("Model",self.model);form.addRow("API Key",self.key);form.addRow("",self.remember);form.addRow("Privacy Default",self.privacy)
        row=QHBoxLayout();verify=QPushButton("Verify API Key");verify.setObjectName("Primary");verify.clicked.connect(self.verify_key);save=QPushButton("Save Settings");save.clicked.connect(self.save_settings);row.addWidget(verify);row.addWidget(save);row.addStretch();card.layout_.addLayout(row)
        note=QLabel("Gemini default model follows the currently configured model field. If your provider retires/renames a model, simply update the model name here. API keys are session-only unless you explicitly enable local storage.");note.setWordWrap(True);note.setObjectName("Muted");card.layout_.addWidget(note);root.addWidget(card);root.addStretch();self.refresh()
    def refresh(self):
        s=self.main.case.get("settings",{});self.provider.setCurrentText(s.get("api_provider","Gemini"));self.model.setText(s.get("api_model","gemini-3.6-flash"));self.key.setText(self.main.session_api_key or s.get("api_key",""));self.remember.setChecked(bool(s.get("remember_api_key",False)));self.privacy.setCurrentText(s.get("privacy_default","Always review before API"))
    def save_settings(self):
        s=self.main.case.setdefault("settings",{});s["api_provider"]=self.provider.currentText();s["api_model"]=self.model.text().strip();s["remember_api_key"]=self.remember.isChecked();s["privacy_default"]=self.privacy.currentText();self.main.session_api_key=self.key.text().strip();s["api_key"]=self.main.session_api_key if self.remember.isChecked() else "";self.main.mark_dirty();QMessageBox.information(self,"Settings","Settings saved for this case.")
    def verify_key(self):
        self.save_settings()
        QApplication.setOverrideCursor(Qt.CursorShape.WaitCursor)
        try:
            result=AIClient.verify(self.provider.currentText(),self.key.text().strip(),self.model.text().strip());QMessageBox.information(self,"API Verification",f"API responded successfully.\n\n{result[:200]}")
        except Exception as e:QMessageBox.critical(self,"API Verification Failed",str(e))
        finally:QApplication.restoreOverrideCursor()


# --------------------------------------------------------------------------------------
# Exporters
# --------------------------------------------------------------------------------------
class Exporter:
    @staticmethod
    def _wb():
        try:
            from openpyxl import Workbook
            return Workbook()
        except Exception as e:raise RuntimeError("openpyxl is required for Excel export. Install: pip install openpyxl") from e
    @staticmethod
    def _style_sheet(ws,title):
        from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
        ws.sheet_view.showGridLines=False;ws.freeze_panes="A4";ws["A1"]=title;ws["A1"].font=Font(size=16,bold=True,color="1F4E78");ws.merge_cells(start_row=1,start_column=1,end_row=1,end_column=max(3,ws.max_column or 3));ws["A1"].alignment=Alignment(horizontal="left")
    @staticmethod
    def income_control_rows(case):
        c=TaxEngine.compute(case);auto=TaxEngine.bank_detected_by_income_key(case);rows=[]
        def vals(key):
            if key=="salary":return c["salary"]["new"],c["salary"]["old"]
            if key=="house_property":return c["hp"]["new"],c["hp"]["old"]
            p=c["pgbp"]
            if key=="pgbp_regular":return p["regular_new"],p["regular_old"]
            if key=="pgbp_presumptive_business":return p["presumptive_business"],p["presumptive_business"]
            if key=="pgbp_presumptive_profession":return p["presumptive_profession"],p["presumptive_profession"]
            if key=="pgbp_goods_carriage":return p["goods_carriage"],p["goods_carriage"]
            if key=="pgbp_fo":return p["fo"],p["fo"]
            if key=="pgbp_speculative":return p["speculative"],p["speculative"]
            if key=="capital_gains":return c["cg"]["total_gain"],c["cg"]["total_gain"]
            if key=="other_interest":return c["other"]["interest"],c["other"]["interest"]
            if key=="other_dividend":return c["other"]["dividend"],c["other"]["dividend"]
            if key=="other_other":return c["other"]["other"],c["other"]["other"]
            if key=="agriculture":return c["agri"]["net"],c["agri"]["net"]
            if key=="exempt":return c["exempt"]["other_exempt"],c["exempt"]["other_exempt"]
            return 0.0,0.0
        for key,label in INCOME_KEYS:
            ap=case.get("income_applicability",{}).get(key,{})
            nv,ov=vals(key)
            rows.append((label,auto.get(key,0.0),ap.get("applicable","No"),nv,ov,ap.get("status","Not Applicable"),ap.get("remarks","")))
        return rows

    @staticmethod
    def computation_rows(case):
        c=TaxEngine.compute(case);n=c["new"];o=c["old"];sal=c["salary"];hp=c["hp"];p=c["pgbp"];cg=c["cg"];other=c["other"];ag=c["agri"];ex=c["exempt"]
        rows=[]
        def s(x):rows.append((x,None,None,"section"))
        def r(x,a,b,k=""):rows.append((x,a,b,k))
        s("INCOME FROM SALARY");r("Gross Salary",sal["gross"],sal["gross"]);r("Less: Eligible salary exemptions",sal["exemptions_new"],sal["exemptions_old"]);r("Less: Standard Deduction",sal["std_new"],sal["std_old"]);r("Less: Professional Tax",0,sal["professional_tax"]);r("Less: Other Salary deductions",sal["other_new"],sal["other_old"]);r("Income from Salary",sal["new"],sal["old"],"total")
        s("INCOME FROM HOUSE PROPERTY")
        gav=sum(x["gav"]*x["share"] for x in hp["rows"]);mun=sum(x["municipal"]*x["share"] for x in hp["rows"]);std=sum(x["std"]*x["share"] for x in hp["rows"]);intn=sum(x["interest_new"]*x["share"] for x in hp["rows"]);into=sum(x["interest_old"]*x["share"] for x in hp["rows"]);arr=sum(x["arrears_taxable"]*x["share"] for x in hp["rows"])
        r("Gross Annual Value",gav,gav);r("Less: Municipal / Local Authority Taxes",mun,mun);r("Net Annual Value",gav-mun,gav-mun);r("Less: 30% Standard Deduction",std,std);r("Less: Interest / Pre-construction Interest",intn,into);r("Add: Taxable Arrears / Unrealised Rent Recovery",arr,arr);r("Income/(Loss) from House Property",hp["new"],hp["old"],"total")
        s("PGBP");r("Regular Books",p["regular_new"],p["regular_old"]);r("Presumptive Business",p["presumptive_business"],p["presumptive_business"]);r("Presumptive Profession",p["presumptive_profession"],p["presumptive_profession"]);r("Goods Carriage",p["goods_carriage"],p["goods_carriage"]);r("F&O",p["fo"],p["fo"]);r("Speculative / Intraday",p["speculative"],p["speculative"]);r("Total PGBP",p["new"],p["old"],"total")
        s("CAPITAL GAINS");r("Normal-rate STCG",cg["normal_stcg"],cg["normal_stcg"]);r("STCG – Special 20%",cg["special_stcg_20"],cg["special_stcg_20"]);r("Equity LTCG – gross gain",cg["equity_ltcg"],cg["equity_ltcg"]);r("Equity LTCG taxable after ₹1.25L threshold",cg["equity_ltcg_taxable"],cg["equity_ltcg_taxable"]);r("Other LTCG 12.5%",cg["other_ltcg_12_5"],cg["other_ltcg_12_5"]);r("Total Capital Gain/(Loss)",cg["total_gain"],cg["total_gain"],"total")
        s("OTHER SOURCES");r("Interest",other["interest"],other["interest"]);r("Dividend",other["dividend"],other["dividend"]);r("Other",other["other"],other["other"]);r("Total Other Sources",other["total"],other["total"],"total")
        s("TOTAL INCOME & TAX");r("Gross Total Income",n["gross_total_income"],o["gross_total_income"],"total");r("Less: Deductions",n["deductions"],o["deductions"]);r("Total Income",n["total_income"],o["total_income"],"total");r("Tax at Normal Rates / Agricultural Rate Effect",n["normal_tax"],o["normal_tax"]);r("Tax at Special Rates",n["special_tax"],o["special_tax"]);r("Less: Rebate",n["rebate"],o["rebate"]);r("Surcharge",n["surcharge"],o["surcharge"]);r("Cess",n["cess"],o["cess"]);r("Total Tax Liability",n["tax_liability"],o["tax_liability"],"total");r("Taxes Paid",n["taxes_paid"],o["taxes_paid"]);r("Tax Payable / (Refund)",n["payable"],o["payable"],"grand")
        s("EXEMPT INCOME");r("Agricultural Income",ag["net"],ag["net"]);r("PPF / Other Exempt Income",ex["other_exempt"],ex["other_exempt"]);r("Total Exempt Income",ag["net"]+ex["other_exempt"],ag["net"]+ex["other_exempt"],"total")
        return rows
    @staticmethod
    def add_computation_sheet(wb,case):
        from openpyxl.styles import Font,PatternFill,Alignment
        ws=wb.active;ws.title="Computation";name=case.get("assessee",{}).get("name","");pan=case.get("assessee",{}).get("pan","")
        ws["A1"]="ITR COMPUTATION";ws["A1"].font=Font(size=18,bold=True,color="1F4E78");ws["A2"]=f"{name}  |  PAN: {pan}  |  Tax Year {TAX_YEAR}";ws.merge_cells("A1:G1");ws.merge_cells("A2:G2")
        ws["A4"]="INCOME SELECTION, AUTO-FETCH & DETAILS CONTROL";ws["A4"].font=Font(size=12,bold=True,color="1F4E78");ws.merge_cells("A4:G4")
        headers=["Income / Source","Amount Auto Fetched","Applicable?","New Regime","Old Regime","Status","Remarks"]
        for c,h in enumerate(headers,1):ws.cell(5,c,h)
        for cell in ws[5]:cell.font=Font(bold=True,color="FFFFFF");cell.fill=PatternFill("solid",fgColor="1F4E78");cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
        rno=6
        for label,auto,app,nv,ov,status,remarks in Exporter.income_control_rows(case):
            vals=[label,auto,app,nv,ov,status,remarks]
            for c,v in enumerate(vals,1):ws.cell(rno,c,v)
            for c in [2,4,5]:ws.cell(rno,c).number_format='₹#,##0.00;[Red]-₹#,##0.00'
            rno+=1
        rno+=1;ws.cell(rno,1,"DETAILED TAX COMPUTATION");ws.cell(rno,1).font=Font(size=12,bold=True,color="1F4E78");ws.merge_cells(start_row=rno,start_column=1,end_row=rno,end_column=3);rno+=1
        for c,h in enumerate(["Particulars","New Regime","Old Regime"],1):ws.cell(rno,c,h)
        for c in range(1,4):ws.cell(rno,c).font=Font(bold=True,color="FFFFFF");ws.cell(rno,c).fill=PatternFill("solid",fgColor="1F4E78");ws.cell(rno,c).alignment=Alignment(horizontal="center")
        detail_header_row=rno;rno+=1
        for item_name,nv,ov,kind in Exporter.computation_rows(case):
            ws.cell(rno,1,item_name)
            if kind=="section":
                for c in range(1,4):ws.cell(rno,c).fill=PatternFill("solid",fgColor="E8EDF5");ws.cell(rno,c).font=Font(bold=True)
            else:
                ws.cell(rno,2,nv);ws.cell(rno,3,ov)
                for c in [2,3]:ws.cell(rno,c).number_format='₹#,##0.00;[Red]-₹#,##0.00'
                if kind in ("total","grand"):
                    for c in range(1,4):ws.cell(rno,c).font=Font(bold=True);ws.cell(rno,c).fill=PatternFill("solid",fgColor="EAF7F1" if kind=="grand" else "F2F6FC")
            rno+=1
        widths={"A":48,"B":20,"C":16,"D":20,"E":20,"F":18,"G":48}
        for col,w in widths.items():ws.column_dimensions[col].width=w
        ws.freeze_panes="A6";ws.sheet_view.showGridLines=False;ws.page_setup.orientation="landscape";ws.page_setup.fitToWidth=1
        return ws
    @staticmethod
    def add_bank_sheets(wb,case,include_suggestion=True):
        from openpyxl.styles import Font,PatternFill,Alignment
        from openpyxl.utils import get_column_letter
        for idx,b in enumerate(case.get("banks",[])):
            title=(b.get("bank_name") or f"Bank {idx+1}")[:31];base=title;n=1
            while title in wb.sheetnames:n+=1;title=(base[:27]+f" {n}")[:31]
            ws=wb.create_sheet(title);ws["A1"]=b.get("bank_name",title);ws["A2"]=f"Statement: {b.get('statement_from','')} to {b.get('statement_to','')}  |  Source: {b.get('source_file','')}"
            headers=["Sr. No.","Transaction Date","Narration","Debit","Credit","Balance"]
            if include_suggestion:headers += ["System Suggested Nature"]
            headers += ["Final Nature","Head of Income","Remarks"]
            ws.append([]);ws.append(headers)
            for cell in ws[4]:cell.font=Font(bold=True,color="FFFFFF");cell.fill=PatternFill("solid",fgColor="1F4E78");cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
            for i,tx in enumerate(b.get("transactions",[]),1):
                row=[i,tx.get("date",""),tx.get("narration",""),to_float(tx.get("debit")),to_float(tx.get("credit")),to_float(tx.get("balance"))]
                if include_suggestion:row += [tx.get("suggested_nature","")]
                row += [tx.get("final_nature",""),tx.get("head",""),tx.get("remarks","")];ws.append(row)
            for row in ws.iter_rows(min_row=5):
                for c in [4,5,6]:row[c-1].number_format='₹#,##0.00;[Red]-₹#,##0.00'
            widths={1:8,2:15,3:62,4:16,5:16,6:16}
            c=7
            if include_suggestion:
                widths[c]=30;c+=1
            widths[c]=32;widths[c+1]=24;widths[c+2]=42
            for col,w in widths.items():ws.column_dimensions[get_column_letter(col)].width=w
            ws.auto_filter.ref=f"A4:{ws.cell(4,len(headers)).column_letter}{ws.max_row}";ws.freeze_panes="A5";ws.sheet_view.showGridLines=False

    @staticmethod
    def ensure_bank_review_ids(case):
        """Persist stable IDs used only for Excel round-trip matching."""
        for bank in case.get("banks", []):
            bank.setdefault("review_id", uuid.uuid4().hex)
            for tx in bank.get("transactions", []):
                tx.setdefault("review_id", uuid.uuid4().hex)

    @staticmethod
    def export_bank_review_excel(case, path, include_suggestion=True):
        """Create a client-facing bank review workbook with dropdowns.

        It can be exported before or after API analysis. System Suggested Nature
        is a read-only reference; the yellow columns are the client's final review.
        Hidden IDs support safe re-import even after sorting.
        """
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.worksheet.datavalidation import DataValidation
        from openpyxl.utils import get_column_letter
        Exporter.ensure_bank_review_ids(case)
        wb=Workbook();wb.remove(wb.active)
        lists=wb.create_sheet("_Lists")
        nature_values=[x for x in FINAL_NATURES if x];head_values=[x for x in HEADS if x]
        for i,v in enumerate(nature_values,1):lists.cell(i,1,v)
        for i,v in enumerate(head_values,1):lists.cell(i,2,v)
        lists.sheet_state="hidden"
        editable_fill=PatternFill("solid",fgColor="FFF2CC");source_fill=PatternFill("solid",fgColor="E7E6E6");header_fill=PatternFill("solid",fgColor="1F4E78");mismatch_fill=PatternFill("solid",fgColor="F4CCCC")
        border=Border(bottom=Side(style="thin",color="D9E2F3"))
        for idx,bank in enumerate(case.get("banks",[])):
            title=(bank.get("bank_name") or f"Bank {idx+1}")[:31];base=title;n=1
            while title in wb.sheetnames:n+=1;title=(base[:27]+f" {n}")[:31]
            ws=wb.create_sheet(title)
            ws["A1"]="CLIENT BANK REVIEW – ITR COMPUTATION";ws["A1"].font=Font(bold=True,size=14,color="1F4E78")
            ws["A2"]="Fill the yellow columns only: Final Nature, Head of Income, and Remarks. System Suggested Nature is a reference column only. Use the dropdowns; do not delete rows."
            ws["A2"].alignment=Alignment(wrap_text=True)
            ws["A3"]=f"Bank: {bank.get('bank_name','')} | Statement: {bank.get('statement_from','')} to {bank.get('statement_to','')} | Source: {bank.get('source_file','')}"
            headers=["Sr. No.","Transaction Date","Narration","Debit","Credit","Balance"]
            if include_suggestion:headers += ["System Suggested Nature"]
            headers += ["Final Nature","Head of Income","Remarks","_Bank Review ID","_Transaction Review ID"]
            for c,h in enumerate(headers,1):
                cell=ws.cell(5,c,h);cell.font=Font(bold=True,color="FFFFFF");cell.fill=header_fill;cell.alignment=Alignment(horizontal="center",vertical="center",wrap_text=True)
            for i,tx in enumerate(bank.get("transactions",[]),1):
                row=[i,tx.get("date",""),tx.get("narration",""),to_float(tx.get("debit")),to_float(tx.get("credit")),to_float(tx.get("balance"))]
                if include_suggestion:row += [tx.get("suggested_nature","")]
                row += [tx.get("final_nature",""),tx.get("head",""),tx.get("remarks",""),bank.get("review_id",""),tx.get("review_id","")]
                ws.append(row)
            final_col=8 if include_suggestion else 7
            head_col=final_col+1;remarks_col=final_col+2;bank_id_col=final_col+3;tx_id_col=final_col+4
            dv_nature=DataValidation(type="list",formula1=f"'_Lists'!$A$1:$A${max(1,len(nature_values))}",allow_blank=True)
            dv_head=DataValidation(type="list",formula1=f"'_Lists'!$B$1:$B${max(1,len(head_values))}",allow_blank=True)
            ws.add_data_validation(dv_nature);ws.add_data_validation(dv_head)
            if ws.max_row>=6:
                dv_nature.add(f"{get_column_letter(final_col)}6:{get_column_letter(final_col)}{ws.max_row}")
                dv_head.add(f"{get_column_letter(head_col)}6:{get_column_letter(head_col)}{ws.max_row}")
            for r in range(6,ws.max_row+1):
                for c in range(1,final_col):ws.cell(r,c).fill=source_fill
                for c in [final_col,head_col,remarks_col]:ws.cell(r,c).fill=editable_fill
                for c in range(1,remarks_col+1):ws.cell(r,c).border=border;ws.cell(r,c).alignment=Alignment(vertical="top",wrap_text=(c in [3,remarks_col]))
                for c in [4,5,6]:ws.cell(r,c).number_format='₹#,##0.00;[Red]-₹#,##0.00'
            widths={1:8,2:15,3:62,4:16,5:16,6:16};c=7
            if include_suggestion:widths[c]=30;c+=1
            widths[final_col]=32;widths[head_col]=24;widths[remarks_col]=42
            for c,w in widths.items():ws.column_dimensions[get_column_letter(c)].width=w
            ws.column_dimensions[get_column_letter(bank_id_col)].hidden=True;ws.column_dimensions[get_column_letter(tx_id_col)].hidden=True
            ws.freeze_panes="A6";ws.auto_filter.ref=f"A5:{get_column_letter(remarks_col)}{ws.max_row}";ws.sheet_view.showGridLines=False
        if len(wb.sheetnames)==1:
            ws=wb.create_sheet("Bank Review");ws["A1"]="No bank statements imported."
        wb.save(path)

    @staticmethod
    def import_bank_review_excel(case, path):
        """Import client classifications from a previously exported review workbook."""
        from openpyxl import load_workbook
        Exporter.ensure_bank_review_ids(case)
        wb=load_workbook(path,data_only=False)
        bank_map={b.get("review_id"): b for b in case.get("banks",[]) if b.get("review_id")}
        tx_map={}
        for b in case.get("banks",[]):
            for tx in b.get("transactions",[]):
                if tx.get("review_id"): tx_map[tx.get("review_id")]=(b,tx)
        updated=unmatched=invalid=0
        sheet_count=0
        for ws in wb.worksheets:
            if ws.title=="_Lists": continue
            header_row=None;headers={}
            for rr in range(1,min(12,ws.max_row)+1):
                vals=[ws.cell(rr,c).value for c in range(1,ws.max_column+1)]
                if "Final Nature" in vals and "Head of Income" in vals:
                    header_row=rr;headers={str(v):i+1 for i,v in enumerate(vals) if v is not None};break
            if not header_row: continue
            sheet_count += 1
            for r in range(header_row+1,ws.max_row+1):
                txid=ws.cell(r,headers.get("_Transaction Review ID",0)).value if headers.get("_Transaction Review ID") else None
                target=tx_map.get(str(txid)) if txid else None
                if not target:
                    unmatched += 1;continue
                b,tx=target
                final=str(ws.cell(r,headers["Final Nature"]).value or "").strip()
                head=str(ws.cell(r,headers["Head of Income"]).value or "").strip()
                remarks=str(ws.cell(r,headers["Remarks"]).value or "").strip() if "Remarks" in headers else ""
                if head and head not in HEADS:
                    invalid += 1; head=""
                if final: tx["final_nature"]=final
                if head: tx["head"]=head
                elif final: tx["head"]=default_head_for_nature(final)

                cur_head = tx.get("head", "")
                if cur_head in {"Salary", "House Property", "PGBP", "Capital Gains", "Other Sources", "Agricultural Income – Exempt", "Other Exempt Income"}:
                    tx["consider"] = "Yes"
                elif cur_head in {"Not Income", "Opening Balance", "Closing Balance"}:
                    tx["consider"] = "No"
                else:
                    tx["consider"] = "Review"

                tx["remarks"]=remarks
                updated += 1
        return {"updated":updated,"unmatched":unmatched,"invalid":invalid,"sheets":sheet_count}

    @staticmethod
    def export_computation_excel(case,path):
        wb=Exporter._wb();Exporter.add_computation_sheet(wb,case);wb.save(path)
    @staticmethod
    def export_banks_excel(case,path,include_suggestion=True):
        wb=Exporter._wb();default=wb.active;wb.remove(default);Exporter.add_bank_sheets(wb,case,include_suggestion); 
        if not wb.sheetnames:ws=wb.create_sheet("Bank Statements");ws["A1"]="No bank statements imported."
        wb.save(path)
    @staticmethod
    def export_complete_excel(case,path):
        from openpyxl.styles import Font,PatternFill
        wb=Exporter._wb();Exporter.add_computation_sheet(wb,case)
        # Deductions
        ws=wb.create_sheet("Deductions");ws.append(["Particulars","Section / Reference","Amount","Allowed New","Allowed Old","Remarks"])
        for d in case.get("deductions",[]):ws.append([d.get("particulars",""),d.get("section",""),to_float(d.get("amount")),"Yes" if d.get("allow_new") else "No","Yes" if d.get("allow_old") else "No",d.get("remarks","")])
        # Taxes
        ws=wb.create_sheet("Taxes Paid");ws.append(["Type","Deductor / Challan","Date","Amount","Verified","Remarks"])
        for x in case.get("taxes_paid",[]):ws.append([x.get("type",""),x.get("reference",""),x.get("date",""),to_float(x.get("amount")),"Yes" if x.get("verified") else "No",x.get("remarks","")])
        # Documents
        ws=wb.create_sheet("Documents Used");ws.append(["Document Type","Document Name","Tax Year","Used For","Python Extracted","Sensitive Reviewed","Redacted","API Analysed","Status","Remarks"])
        for d in case.get("documents",[]):ws.append([d.get("document_type",""),d.get("document_name",""),d.get("tax_year",""),d.get("used_for",""),d.get("python_extracted",""),d.get("sensitive_review",""),d.get("redacted",""),d.get("api_analysed",""),d.get("status",""),d.get("remarks","")])
        Exporter.add_bank_sheets(wb,case,True);wb.save(path)
    @staticmethod
    def export_pdf(case,path):
        try:
            from reportlab.lib import colors
            from reportlab.lib.pagesizes import A4
            from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
            from reportlab.lib.enums import TA_CENTER
            from reportlab.platypus import SimpleDocTemplate,Table,TableStyle,Paragraph,Spacer,PageBreak
        except Exception as e:raise RuntimeError("reportlab is required for PDF export. Install: pip install reportlab") from e
        doc=SimpleDocTemplate(path,pagesize=A4,rightMargin=30,leftMargin=30,topMargin=30,bottomMargin=30);styles=getSampleStyleSheet();story=[];name=case.get("assessee",{}).get("name","");pan=case.get("assessee",{}).get("pan","")
        story.append(Paragraph("ITR COMPUTATION",ParagraphStyle("t",parent=styles["Title"],alignment=TA_CENTER,textColor=colors.HexColor("#1F4E78"))));story.append(Paragraph(f"{html.escape(name)} | PAN: {html.escape(pan)} | Tax Year {TAX_YEAR}",styles["Normal"]));story.append(Spacer(1,12))
        data=[["Particulars","New Regime","Old Regime"]]
        kinds=[]
        for nm,nv,ov,k in Exporter.computation_rows(case):data.append([nm,"" if nv is None else money(nv),"" if ov is None else money(ov)]);kinds.append(k)
        t=Table(data,colWidths=[280,110,110],repeatRows=1);sty=[("BACKGROUND",(0,0),(-1,0),colors.HexColor("#1F4E78")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("GRID",(0,0),(-1,-1),0.3,colors.HexColor("#DCE3EC")),("VALIGN",(0,0),(-1,-1),"TOP"),("ALIGN",(1,1),(-1,-1),"RIGHT"),("FONTSIZE",(0,0),(-1,-1),8)]
        for i,k in enumerate(kinds,1):
            if k=="section":sty += [("BACKGROUND",(0,i),(-1,i),colors.HexColor("#E8EDF5")),("FONTNAME",(0,i),(-1,i),"Helvetica-Bold")]
            elif k in ("total","grand"):sty += [("FONTNAME",(0,i),(-1,i),"Helvetica-Bold"),("BACKGROUND",(0,i),(-1,i),colors.HexColor("#EAF7F1" if k=="grand" else "#F2F6FC"))]
        t.setStyle(TableStyle(sty));story.append(t);story.append(Spacer(1,10));story.append(Paragraph("Prepared as a computation/workpaper under the Income-tax Act, 2025. Review specialised provisions before filing.",styles["Italic"]));doc.build(story)

# --------------------------------------------------------------------------------------
# Main window
# --------------------------------------------------------------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.case = default_case()
        self.case_path: Optional[str] = None
        self.dirty = False
        self.session_api_key = ""
        self.setWindowTitle(f"{APP_NAME} {APP_VERSION}")
        self.resize(1500, 900)
        self.setMinimumSize(1180, 720)
        self._build_ui()
        self._build_menu()
        self.refresh_all()
        QTimer.singleShot(250, self.ensure_assessee)

    def _build_ui(self):
        root = QWidget(); root.setObjectName("Root"); self.setCentralWidget(root)
        main = QHBoxLayout(root); main.setContentsMargins(0,0,0,0); main.setSpacing(0)
        # Sidebar
        side = QFrame(); side.setObjectName("Sidebar"); side.setFixedWidth(235)
        sl = QVBoxLayout(side); sl.setContentsMargins(12,18,12,14); sl.setSpacing(10)
        title = QLabel("ITR\nComputation"); title.setObjectName("AppTitle"); sl.addWidget(title)
        sub = QLabel("Income-tax Act, 2025\nTax Year 2026-27"); sub.setObjectName("AppSub"); sl.addWidget(sub)
        sl.addSpacing(8)
        self.nav = QListWidget(); self.nav.setObjectName("Nav"); self.nav.setSpacing(2)
        self.nav_names = [
            "Computation", "Bank Statements", "Deductions",
            "Taxes Paid", "Documents Used", "Review & Reconciliation", "Settings / API"
        ]
        for n in self.nav_names: self.nav.addItem(QListWidgetItem(n))
        sl.addWidget(self.nav,1)
        ver = QLabel(f"v{APP_VERSION}\nLocal-first workpaper"); ver.setObjectName("AppSub"); sl.addWidget(ver)
        main.addWidget(side)
        # Right
        right = QWidget(); rl = QVBoxLayout(right); rl.setContentsMargins(0,0,0,0); rl.setSpacing(0)
        top = QFrame(); top.setObjectName("Topbar"); tl = QHBoxLayout(top); tl.setContentsMargins(18,10,18,10)
        self.case_label = QLabel("New Case"); self.case_label.setStyleSheet("font-weight:700;font-size:11pt")
        self.case_sub = QLabel("Unsaved"); self.case_sub.setObjectName("Muted")
        cbox=QVBoxLayout();cbox.setSpacing(1);cbox.addWidget(self.case_label);cbox.addWidget(self.case_sub);tl.addLayout(cbox);tl.addStretch()
        details=QPushButton("Assessee Details");details.clicked.connect(self.edit_assessee);tl.addWidget(details)
        save=QPushButton("Save");save.clicked.connect(self.save_case);tl.addWidget(save)
        self.export_btn=QToolButton();self.export_btn.setText("Export ▾");self.export_btn.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup);menu=QMenu(self.export_btn)
        a=menu.addAction("Computation Excel");a.triggered.connect(self.export_computation_excel)
        a=menu.addAction("Bank Statements Excel");a.triggered.connect(self.export_banks_excel)
        a=menu.addAction("Client Bank Review Excel");a.triggered.connect(self.export_bank_review_excel)
        a=menu.addAction("Complete Working Excel");a.triggered.connect(self.export_complete_excel)
        menu.addSeparator();a=menu.addAction("Computation PDF");a.triggered.connect(self.export_pdf)
        self.export_btn.setMenu(menu);tl.addWidget(self.export_btn)
        rl.addWidget(top)
        self.stack=QStackedWidget();rl.addWidget(self.stack,1);main.addWidget(right,1)
        self.pages=[]
        self.comp_page=ComputationPage(self); self.pages.append(self.comp_page)
        self.bank_page=BankStatementsPage(self); self.pages.append(self.bank_page)
        self.ded_page=DeductionsPage(self); self.pages.append(self.ded_page)
        self.tax_page=TaxesPage(self); self.pages.append(self.tax_page)
        self.docs_page=DocumentsPage(self); self.pages.append(self.docs_page)
        self.review_page=ReviewPage(self); self.pages.append(self.review_page)
        self.settings_page=SettingsPage(self); self.pages.append(self.settings_page)
        for p in self.pages:self.stack.addWidget(p)
        self.nav.currentRowChanged.connect(self.stack.setCurrentIndex);self.nav.setCurrentRow(0)

    def _build_menu(self):
        mb=self.menuBar();file=mb.addMenu("File")
        a=file.addAction("New Case");a.setShortcut(QKeySequence.StandardKey.New);a.triggered.connect(self.new_case)
        a=file.addAction("Open Case…");a.setShortcut(QKeySequence.StandardKey.Open);a.triggered.connect(self.open_case)
        a=file.addAction("Save");a.setShortcut(QKeySequence.StandardKey.Save);a.triggered.connect(self.save_case)
        a=file.addAction("Save As…");a.setShortcut(QKeySequence.StandardKey.SaveAs);a.triggered.connect(self.save_case_as)
        file.addSeparator();a=file.addAction("Exit");a.triggered.connect(self.close)
        ex=mb.addMenu("Export")
        ex.addAction("Computation Excel",self.export_computation_excel);ex.addAction("Bank Statements Excel",self.export_banks_excel);ex.addAction("Client Bank Review Excel",self.export_bank_review_excel);ex.addAction("Complete Working Excel",self.export_complete_excel);ex.addAction("Computation PDF",self.export_pdf)
        imp=mb.addMenu("Import")
        imp.addAction("Client Bank Review Excel",self.import_bank_review_excel)
        helpm=mb.addMenu("Help")
        helpm.addAction("About",lambda:QMessageBox.information(self,"About",f"{APP_NAME} v{APP_VERSION}\n\nSingle-file desktop ITR computation workpaper for Tax Year {TAX_YEAR}.\nAI is used only for document interpretation; calculations remain deterministic."))

    def ensure_assessee(self):
        if not self.case.get("assessee",{}).get("name"):
            self.edit_assessee()

    def runtime_settings(self):
        s=json_deepcopy(self.case.get("settings",{}));s["api_key"]=self.session_api_key or s.get("api_key","");return s

    def mark_dirty(self):
        self.dirty=True;self.update_case_header()

    def update_case_header(self):
        a=self.case.get("assessee",{});name=a.get("name") or "New Case";pan=a.get("pan","");self.case_label.setText(f"{name}  •  T.Y. {TAX_YEAR}")
        if pan:self.case_label.setText(self.case_label.text()+f"  •  {pan}")
        loc=Path(self.case_path).name if self.case_path else "Unsaved JSON case";self.case_sub.setText(loc + ("  •  Unsaved changes" if self.dirty else ""))

    def refresh_all(self, except_bank=False, except_deductions=False, except_taxes=False):
        self.update_case_header()
        try:self.comp_page.refresh()
        except Exception:traceback.print_exc()
        if not except_bank:
            try:self.bank_page.refresh()
            except Exception:traceback.print_exc()
        if not except_deductions:
            try:self.ded_page.refresh()
            except Exception:traceback.print_exc()
        if not except_taxes:
            try:self.tax_page.refresh()
            except Exception:traceback.print_exc()
        try:self.docs_page.refresh()
        except Exception:traceback.print_exc()
        try:self.review_page.refresh()
        except Exception:traceback.print_exc()
        try:self.settings_page.refresh()
        except Exception:traceback.print_exc()

    def edit_assessee(self):
        dlg=AssesseeDialog(self,self.case.get("assessee",{}))
        if dlg.exec()==QDialog.DialogCode.Accepted:
            self.case["assessee"]=dlg.result_data();self.mark_dirty();self.refresh_all()

    def maybe_discard(self):
        if not self.dirty:return True
        ans=QMessageBox.question(self,"Unsaved changes","Save changes before continuing?",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No|QMessageBox.StandardButton.Cancel,QMessageBox.StandardButton.Yes)
        if ans==QMessageBox.StandardButton.Cancel:return False
        if ans==QMessageBox.StandardButton.Yes:return self.save_case()
        return True

    def new_case(self):
        if not self.maybe_discard():return
        self.case=default_case();self.case_path=None;self.session_api_key="";self.dirty=False;self.refresh_all();self.edit_assessee()

    def open_case(self):
        if not self.maybe_discard():return
        path,_=QFileDialog.getOpenFileName(self,"Open ITR Computation Case","","ITR Case JSON (*.json);;JSON (*.json)")
        if not path:return
        try:
            self.case=CaseStore.load(path);self.case_path=path;self.session_api_key=self.case.get("settings",{}).get("api_key","");self.dirty=False;self.refresh_all()
        except Exception as e:QMessageBox.critical(self,"Open failed",str(e))

    def save_case(self):
        if not self.case_path:return self.save_case_as()
        try:CaseStore.save(self.case_path,self.case);self.dirty=False;self.update_case_header();return True
        except Exception as e:QMessageBox.critical(self,"Save failed",str(e));return False

    def save_case_as(self):
        name=re.sub(r"[^A-Za-z0-9_-]+","_",self.case.get("assessee",{}).get("name","").strip()) or "ITR_Case";suggest=f"{name}_TY_{TAX_YEAR.replace('-','_')}.json"
        path,_=QFileDialog.getSaveFileName(self,"Save ITR Computation Case",suggest,"ITR Case JSON (*.json)")
        if not path:return False
        if not path.lower().endswith(".json"):path+=".json"
        self.case_path=path;return self.save_case()

    def register_imported_document(self,path,doc_type,used_for,privacy_dialog:Optional[PrivacyImportDialog]=None):
        redacted="N/A";api="No";sens="N/A";extracted="Yes"
        if privacy_dialog:
            sens="Yes";redacted="Yes" if privacy_dialog.selected_types() else "No";api="Yes" if privacy_dialog.analysis_data and not privacy_dialog.analysis_data.get("local_only") else "No"
        self.case.setdefault("documents",[]).append({"document_type":doc_type,"document_name":Path(path).name,"tax_year":TAX_YEAR,"used_for":used_for,"python_extracted":extracted,"sensitive_review":sens,"redacted":redacted,"api_analysed":api,"status":"Complete" if api=="Yes" else "Reviewed","remarks":"API input truncated for size; review source." if privacy_dialog and privacy_dialog.analysis_data.get("api_truncated") else ""})
        self.mark_dirty()

    def _export_path(self,title,default,filter_):
        path,_=QFileDialog.getSaveFileName(self,title,default,filter_);return path
    def export_computation_excel(self):
        path=self._export_path("Export Computation Excel","ITR_Computation.xlsx","Excel Workbook (*.xlsx)")
        if not path:return
        try:Exporter.export_computation_excel(self.case,path);QMessageBox.information(self,"Export complete",f"Computation exported to:\n{path}")
        except Exception as e:QMessageBox.critical(self,"Export failed",str(e))
    def export_banks_excel(self):
        if not self.case.get("banks"):QMessageBox.information(self,"No banks","No bank statements have been imported.");return
        ans=QMessageBox.question(self,"Bank export","Include System Suggested Nature + Suggested Head of Income in the exported bank sheets?",QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,QMessageBox.StandardButton.Yes);inc=ans==QMessageBox.StandardButton.Yes
        path=self._export_path("Export Bank Statements Excel","ITR_Bank_Statements.xlsx","Excel Workbook (*.xlsx)")
        if not path:return
        try:Exporter.export_banks_excel(self.case,path,inc);QMessageBox.information(self,"Export complete",f"Bank statements exported to:\n{path}")
        except Exception as e:QMessageBox.critical(self,"Export failed",str(e))
    def export_bank_review_excel(self):
        if not self.case.get("banks"):
            QMessageBox.information(self,"No banks","Import at least one bank statement first. You may use 'Import Without API' in the privacy screen if you want the client to classify it before API analysis.");return
        ans=QMessageBox.question(
            self,"Client bank review",
            "Include System Suggested Nature + Suggested Head of Income in the client workbook?\n\nChoose Yes after API analysis; choose No if you are sending the locally extracted bank statement to the client before API analysis.",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.Yes
        )
        inc=ans==QMessageBox.StandardButton.Yes
        path=self._export_path("Export Client Bank Review Excel","ITR_Client_Bank_Review.xlsx","Excel Workbook (*.xlsx)")
        if not path:return
        try:
            Exporter.export_bank_review_excel(self.case,path,inc)
            self.mark_dirty()
            if self.case_path:self.save_case()
            QMessageBox.information(
                self,"Client review exported",
                f"Client bank-review workbook exported to:\n{path}\n\nThe client should fill the yellow dropdown/remarks columns and return the same workbook for re-import."
            )
        except Exception as e:QMessageBox.critical(self,"Export failed",str(e))

    def import_bank_review_excel(self):
        if not self.case.get("banks"):
            QMessageBox.information(self,"No banks","Import the corresponding bank statement(s) into this case before importing a client review workbook.");return
        path,_=QFileDialog.getOpenFileName(self,"Import Client Bank Review Excel","","Excel Workbook (*.xlsx)")
        if not path:return
        try:
            result=Exporter.import_bank_review_excel(self.case,path)
            self.mark_dirty();self.refresh_all()
            QMessageBox.information(
                self,"Client review imported",
                f"Updated transactions: {result['updated']}\nUnmatched rows: {result['unmatched']}\nInvalid dropdown values ignored: {result['invalid']}\nSheets read: {result['sheets']}"
            )
        except Exception as e:QMessageBox.critical(self,"Import failed",str(e))

    def export_complete_excel(self):
        path=self._export_path("Export Complete Working Excel","ITR_Complete_Working.xlsx","Excel Workbook (*.xlsx)")
        if not path:return
        try:Exporter.export_complete_excel(self.case,path);QMessageBox.information(self,"Export complete",f"Complete working file exported to:\n{path}")
        except Exception as e:QMessageBox.critical(self,"Export failed",str(e))
    def export_pdf(self):
        path=self._export_path("Export Computation PDF","ITR_Computation.pdf","PDF (*.pdf)")
        if not path:return
        try:Exporter.export_pdf(self.case,path);QMessageBox.information(self,"Export complete",f"Computation PDF exported to:\n{path}")
        except Exception as e:QMessageBox.critical(self,"Export failed",str(e))

    def closeEvent(self,event):
        if self.maybe_discard():event.accept()
        else:event.ignore()


def main():
    app=QApplication(sys.argv);app.setApplicationName(APP_NAME);app.setStyle("Fusion");app.setStyleSheet(QSS)
    # Use a crisp default font without bundling external fonts.
    app.setFont(QFont("Segoe UI",10))
    win=MainWindow();win.show();sys.exit(app.exec())


if __name__ == "__main__":
    main()
