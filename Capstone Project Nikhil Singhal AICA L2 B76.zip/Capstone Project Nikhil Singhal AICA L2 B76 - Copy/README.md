# ITR Computation — Single-File Desktop ITR Workpaper Tool

**Target Platform:** Python 3.10+  
**Target Tax Year:** Tax Year 2026-27 (Assessment Year 2026-27)  
**Applicable Tax Law:** Income-tax Act, 2025 (Section 202 New Regime) & First Schedule to Finance Act, 2026 (Old Regime)  
**Assessee Types:** Individual / HUF  

---

## 📌 Overview

**ITR Computation** is a privacy-first, local-first desktop application designed for Chartered Accountants (CAs), tax professionals, and individual assessees in India. It serves as an interactive computation and audit workpaper engine to analyze income sources, process bank and capital gains statements, compare tax liabilities under the **New and Old Tax Regimes**, and generate client-ready Excel and PDF reports.

The tool combines deterministic Python tax calculation logic with local PDF extraction and optional AI-assisted document classification (Google Gemini / OpenAI). 

> [!IMPORTANT]
> **Professional & Legal Note:** This application is a computation and audit workpaper utility, not an automated e-filing platform. Tax law contains fact-specific exceptions. The application deliberately flags potential edge cases and control mismatches for CA review instead of silently assuming facts.

---

## ✨ Key Features

### 🧮 1. Deterministic Dual-Regime Tax Engine
- **Side-by-Side Comparison:** Instant dual-column computation comparing the **New Regime** (Section 202, Income-tax Act, 2025) vs **Old Regime** (First Schedule, Finance Act, 2026).
- **Salary Income:** Auto-calculates standard deduction (₹75,000 New Regime / ₹50,000 Old Regime), exemptions, professional tax disallowances, and custom deductions.
- **House Property:** Handles Let-Out and Self-Occupied properties, Gross/Net Annual Value (GAV/NAV), 30% statutory deduction, Section 202 interest caps, co-ownership share splitting, and arrears recovery.
- **PGBP (Business & Profession):** Supports Regular Books, Section 58 Presumptive Business (6%/8% turnover thresholds up to ₹2Cr/₹3Cr), Section 58 Presumptive Profession (50% threshold up to ₹50L/₹75L), Heavy/Light Goods Carriage, F&O Trading, and Speculative/Intraday P&L.
- **Capital Gains:** Computes STCG (Normal & Special 20%), Equity LTCG (12.5% with ₹1.25L exemption threshold), and Other LTCG (12.5%).
- **Other Sources & Agriculture:** Aggregates bank-wise interest and dividend receipts, and incorporates agricultural income via partial integration rate mechanics.

### 🔒 2. Privacy-First Document & PII Review Engine
- **Local Text Extraction:** PDF text is extracted locally using `PyMuPDF` (`fitz`) before any external API calls.
- **Automated PII Detection:** High-accuracy regex detection highlights sensitive tokens (PAN, Aadhaar, Mobile, Email, IFSC, GSTIN, TAN, UPI ID, Account Numbers, Addresses).
- **Yellow-Highlight & Redaction Preview:** Interactive dialog allows reviewers to inspect detected sensitive data and apply category-based redactions before opting to use AI analysis.
- **Offline Parser Fallback:** Built-in heuristic engine allows full bank and capital gains statement extraction without an internet connection or API key.

### 🤖 3. Optional AI-Assisted Classification
- **Supported Providers:** Google Gemini (`google-genai` / `gemini-3.6-flash`) and OpenAI (`openai` / `gpt-4o`).
- **Strict Role Boundary:** AI/API is strictly restricted to extracting raw transaction rows and suggesting likely income heads/natures. All tax calculations remain 100% deterministic inside Python.
- **Security First:** API keys are held in session memory by default and are never transmitted unless requested by the user.

### 📊 4. Bank Statement Processing & Two-Way Excel Sync
- **Rule-Based & AI Parser:** Automatic classification of bank credits into Salary, Rent, Interest, Dividend, Capital Gains, Business Receipts, Refunds, or Non-Income Transfers.
- **Opening & Closing Balance Balancing:** Auto-detects and inserts balancing opening and closing entries for statement reconciliation.
- **Two-Way Client Review Excel:** Export interactive Excel workbooks with data validation dropdowns for client review. Includes hidden tracking IDs (`_Bank Review ID`, `_Transaction Review ID`) so client inputs can be seamlessly re-imported into the master case file.

### 🔍 5. Review & Reconciliation Audit Engine
- Flags unclassified credit transactions and items marked as `Pending Review`.
- Detects discrepancies between bank receipts and declared schedule totals (e.g., Gross Salary vs Net Bank Credits, declared Rent vs Bank Rent).
- Identifies missing detail schedules for applicable income heads.

### 📄 6. Comprehensive Multi-Format Exports
- **Computation Excel:** Formatted working paper sheet.
- **Bank Statements Excel:** Multi-tab bank transaction ledger with system suggestions.
- **Client Bank Review Excel:** Color-coded client review workbook with dropdown controls.
- **Complete Working Excel:** All-in-one workbook containing Computation, Deductions, Taxes Paid, Documents Used, and Bank tabs.
- **Computation PDF:** Print-ready, formatted PDF report using `ReportLab`.

---

## 🛠️ Tech Stack & Dependencies

- **Language:** Python 3.10+
- **GUI Framework:** PySide6 (Qt for Python with custom CSS styling)
- **PDF Processing:** PyMuPDF (`fitz`)
- **Spreadsheet Engine:** openpyxl
- **PDF Report Generation:** ReportLab
- **AI Integrations (Optional):** `google-genai`, `openai`

---

## 📦 Installation & Setup

### Prerequisites
Ensure Python 3.10 or higher is installed on your system.

### 1. Install Dependencies
Run the following one-line command in your terminal or command prompt:

```bash
pip install PySide6 PyMuPDF openpyxl reportlab google-genai openai
```

### 2. Run the Application
Execute the main script:

```bash
python ITR_Computation_v1_20.py
```

---

## 🚀 Application Workflow Guide

```mermaid
flowchart TD
    A[Launch App & Set Assessee Details] --> B[Import Source Documents - PDF]
    B --> C{Privacy Review Dialog}
    C -->|Offline Mode| D[Local Non-API Extraction]
    C -->|API Mode| E[Redact PII & Run Gemini/OpenAI API]
    D --> F[Review Bank & Income Schedules]
    E --> F
    F --> G[Export Client Review Excel - Optional]
    G -->|Client Classifies & Returns| H[Re-import Client Excel]
    H --> F
    F --> I[Inspect Dual-Regime Computation Paper]
    I --> J[Run Review & Reconciliation Checks]
    J --> K[Export Final Excel / PDF Reports & Save JSON Case]
```

### Workflow Steps:
1. **Assessee Setup:** Enter assessee name, PAN, DOB, status (Individual/HUF), residential status, and tax year context.
2. **Document Import & Privacy Check:** Load bank or capital gains PDF statements. Review yellow-highlighted sensitive data and choose offline extraction or redacted API analysis.
3. **Client Collaboration (Optional):** Export a **Client Bank Review Excel**, allow the client to select Final Nature/Head via dropdowns, and re-import the file into the case.
4. **Income Schedule Working:** Add details for Salary, House Property, PGBP, Capital Gains, Other Sources, Agriculture, and Exempt Income.
5. **Computation Review:** Compare New Regime vs Old Regime side-by-side on a single unified working paper.
6. **Audit & Export:** Review reconciliation warnings, save the case as a JSON file, and export the final computation to Excel or PDF.

---

## 📁 Repository Structure

```
.
├── ITR_Computation_v1_20.py  # Main Desktop Application (GUI, Engine, Exporters)
└── README.md                 # Project Documentation
```

### Source Code Component Map (`ITR_Computation_v1_20.py`)

| Section / Class | Purpose |
| :--- | :--- |
| `TAX_PARAMS` & `slab_tax` | Tax slabs, deductions, rates, and slab math for TY 2026-27 |
| `TaxEngine` | Deterministic tax computation methods for all income heads |
| `PDFPrivacyEngine` | Local PyMuPDF extraction, PII regex detection, and offline statement parsers |
| `AIClient` & `ApiWorkerThread` | Async API wrapper for Google Gemini and OpenAI document interpretation |
| `PrivacyImportDialog` | Interactive PII review, yellow-highlight preview, and redaction UI |
| `SalaryDialog`, `HousePropertyDialog`, etc. | Income head detail editing modal dialogs |
| `ComputationPage` | Master single-scroll dual-regime computation view |
| `BankStatementsPage` & `BankTableWidget` | Bank statement transaction ledger and classification UI |
| `ReviewPage` | Audit, reconciliation, and exception detection screen |
| `Exporter` | OpenPyXL Excel and ReportLab PDF document generators |
| `MainWindow` | Primary PySide6 application window, navigation sidebar, menu, and file storage |

---

## 🔐 Privacy & Security Guarantees

1. **Local-First Case Files:** Case data is saved in structured, human-readable JSON files on your local device.
2. **Zero Unintended API Calls:** No document content or metadata is sent to external servers unless you explicitly click **Analyse Using API**.
3. **Session-Only API Keys:** API keys entered in settings are kept in RAM memory for the active session unless you explicitly opt into local key storage.
4. **Redaction Safeguards:** Pattern-based PII redaction ensures sensitive identifiers (Aadhaar, PAN, Account Numbers) are stripped before sending prompts to AI providers.

---

## 📜 License & Disclaimer

This software is provided as an open workpaper utility for tax professionals. 

- **Tax Law Compliance:** Tax computations are structured under the Income-tax Act, 2025 and Finance Act, 2026 for Assessment Year 2026-27.
- **Professional Responsibility:** Users must verify facts, loss set-offs, specialized exemptions, treaty claims, and MAT/AMT requirements before finalizing returns. The authors assume no liability for tax positions taken based on output generated by this software.
